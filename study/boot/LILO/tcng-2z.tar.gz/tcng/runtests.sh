#!/bin/bash
#
# runtests.sh - Run regression tests from standard input
#
# Written 2001 by Werner Almesberger
# Copyright 2001 EPFL-ICA, Network Robots
#
#
# Note: "filter.pl" and "trinity.sh" are only valid identifiers if using
# /bin/bash, but not with /bin/sh
#

set -a
. config
set +a


usage()
{
    echo "usage: $0 [-d] [-i] [-Xphase,arg] [file ...]" 1>&2
    echo "  -d           print test output, don't compare with reference" 1>&2
    echo "  -i           continue after errors" 1>&2
    echo "  -Xphase,arg  verbatim argument for specific build phase" 1>&2
    echo "               phases: c=tcc, m=tcc-module, k=kmod_cc, s=tcsim," 1>&2
    echo "                       t=tcmod_cc" 1>&2
    exit 1
}


phase_arg()
{
    phase=`echo "$1" | sed 's/^-X\(.\).*/\1/'`;
    arg=`echo "$1" | sed 's/^-X.,//'`;
    case "$phase" in
        c)      tcc_args="$tcc_args $arg";;
        s)      tcsim_args="$tcsim_args $arg";;
	[mkt])	phase_args="$phase_args -X$phase,$arg";;
        *)      usage;;
    esac
}

tcc_args=
tcsim_args=
phase_args=

debug=false
stop_on_error=true

while [ ! -z "$1" ]; do
    case "$1" in
	-d) debug=true;;
	-i) stop_on_error=false;;
	-X[cmkst],*) phase_arg "$1";;
	-X) shift; phase_arg "-X$1";;
	-*) usage;;
	*)  break;;
    esac
    shift
done

for n in "$@"; do
    <$n || exit 1
done


tcsim()
{
    $TOPDIR/bin/tcsim -g $tcsim_args $phase_args "$@" 2>_tmp_err.$$
    retval=$?
    sed '/^ *$/d;/^ *Electric Fence/d' <_tmp_err.$$ 1>&2
    rm -rf _tmp_err.$$
    return $retval
}


tcc()
{
    $TCC -q $tcc_args $phase_args "$@" 2>_tmp_err.$$
    retval=$?
    sed '/^ *$/d;/^ *Electric Fence/d' <_tmp_err.$$ 1>&2
    rm -rf _tmp_err.$$
    return $retval
}


trinity.sh()
{
    $TOPDIR/scripts/trinity.sh "$@" 2>_tmp_err.$$
    retval=$?
    sed '/^ *$/d;/^ *Electric Fence/d' <_tmp_err.$$ 1>&2
    rm -rf _tmp_err.$$
    return $retval
}


filter.pl()
{
    $TOPDIR/bin/filter.pl $*
}


stderr()
{
    if [ -s _err.$$ ]; then
	echo "  Standard error:"
	sed 's/^/  | /' <_err.$$
    fi
    rm -f _err.$$
}


stdout()
{
    echo "  Standard output:"
    sed 's/^/  | /' <_out.$$
}


refout()
{
    echo "  Reference output:"
    sed 's/^/  | /' <_ref.$$
}


failed()
{
    echo "$1"
    stderr
    echo "Command:   $cmd"
    echo "Input:     _in.$$"
    echo "Output:    _out.$$"
    echo "Reference: _ref.$$"
    $stop_on_error && exit 1
    echo
    failed=`expr $failed + 1`
}

#
# Input/output;
#   Variable:
#     l			next line in input
#
# Output:
#   Variables:
#     title		test title
#     cmd		test command
#     expect_error	true if test succeeds if command fails
#
#   Files:
#     _in.$$		standard input for test
#     _ref.$$		expected test output
#

read_test()
{
    title="`echo "$l" | sed 's/# //'`"
    read cmd
    >_ref.$$
    >_in.$$
    expect_error=false
    while read l; do
	echo "$l" | grep -s '^# ' >/dev/null && break
	if [ "$l" = ERROR ]; then
	    expect_error=true
	elif [ "$l" = EOF ]; then
	    mv _ref.$$ _in.$$
	    >_ref.$$
	else
	    echo "$l" >>_ref.$$
	fi
    done
}


run_tests()
{
    c=0
    w=0
    read l
    while [ ! -z "$l" ]; do
	read_test
	echo -n "$title: "
	eval "$cmd" <_in.$$ >_tmp_out.$$ 2>_err.$$
	result=$?
	sed 's/ *$//' <_tmp_out.$$ >_out.$$
	rm -f _tmp_out.$$
	cmp -s _out.$$ _ref.$$
	equal=$?
	if $expect_error; then
	    if [ $result = 0 ]; then
		failed "FAILED (expected error)"
	    else
		if [ $equal = 0 ]; then
		    echo PASSED
		    rm -f _err.$$
		    c=`expr $c + 1`
		else
		    echo "PASSED (warning: output differs)"
		    stderr
		    stdout
		    refout
		    c=`expr $c + 1`
		    w=`expr $w + 1`
		fi
	    fi
	else
	    if [ $result != 0 ]; then
		failed "FAILED (got error)"
	    else
		if [ $equal = 0 ]; then
		    echo PASSED
		    stderr
		    c=`expr $c + 1`
		else
		    failed FAILED
		fi
	    fi
	fi
	rm -f _in.$$ _out.$$ _ref.$$
    done
    echo -n "Passed all $c tests"
    if [ $w = 0 ]; then
	echo
    elif [ $w = 1 ]; then
	echo " (1 warning)"
    else
	echo " ($w warnings)"
    fi
    if [ $failed -gt 0 ]; then
	echo "$failed test(s) FAILED !"
    fi
}


fill()
{
    # superbly inefficient, but hey, CPU cycles are cheap :-)
    s="$2$1$2"
    while [ `echo "$s" | wc -c` -lt 79 ]; do
	s="$2$s$2"
    done
    echo $s
}

debug_tests()
{
    read l
    while [ ! -z "$l" ]; do
	read_test
	fill " $title " =
	echo "$cmd"
	fill "" -
	eval "$cmd" <_in.$$
	rm -f _in.$$ _ref.$$
	echo
    done
}


failed=0
if $debug; then
    cat "$@" | debug_tests
else
    cat "$@" | run_tests
fi
