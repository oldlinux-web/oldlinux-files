/*
 * var.h - Variable handling
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA
 */


#ifndef VAR_H
#define VAR_H

#include <inttypes.h>

#include "command.h"


enum var_type { vt_unum,vt_cmd };

struct var {
    const char *name;
    enum var_type type;
    union {
	uint32_t value;
	struct command *cmd;
    } u;
    struct var *next;
};


void set_var_unum(const char *name,uint32_t value);
void set_var_cmd(const char *name,struct command *cmd);
uint32_t get_var_unum(const char *name);
struct command *get_var_cmd(const char *name);

#endif /* VAR_H */
