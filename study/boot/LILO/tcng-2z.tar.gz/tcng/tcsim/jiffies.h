/*
 * jiffies.h - Time handling functions
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA
 */


#ifndef JIFFIES_H
#define JIFFIES_H

struct jiffval {
    unsigned long jiffies;
    unsigned long ujiffies;
};

extern struct jiffval now;

struct jiffval dtojiffval(double value);
double jiffvaltod(struct jiffval jiff);
struct jiffval stoj(struct jiffval secs);
struct jiffval jtos(struct jiffval jiff);
void print_time(struct jiffval jiff);

#endif /* JIFFIES_H */
