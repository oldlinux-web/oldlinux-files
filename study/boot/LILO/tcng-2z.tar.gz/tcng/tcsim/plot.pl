#!/usr/bin/perl
#
# plot.pl - Plot various aspects of filter.pl output
#
# Written 2001 by Werner Almesberger, EPFL-ICA
#

use IO::Handle;

$color = 1;
undef $ps_file;
$type = "rate";
$jiffies = 0;
$avg = 1;


sub usage
{
    print STDERR "usage: $0 [-a samples] [-j] [-m] [-p ps_file] ".
      "[-t plot_type] [file ...]\n";
    print STDERR "  -a samples    Average over the number of samples\n";
    print STDERR "  -j            Time is in jiffies, not seconds\n";
    print STDERR "  -m            Monochrome output\n";
    print STDERR "  -p ps_file    Generate Postscript output\n";
    print STDERR "  -t plot_type  rate, iat, cumul, delay\n";
    exit(1);
}


while ($ARGV[0] =~ /^-/) {
    $arg = shift;
    if ($arg eq "-m") { $color = 0; }
    elsif ($arg eq "-a") {
	$avg = shift;
	&usage unless $avg =~ /^\d+$/;
    }
    elsif ($arg eq "-p") {
	$ps_file = shift;
	&usage unless defined $ps_file;
    }
    elsif ($arg eq "-t") {
	$type = shift;
	&usage unless $type =~ /^(rate|iat|cumul|delay)$/;
    }
    else {
	&usage;
    }
}

$tmp_num = 0;
while (<>) {
    chop;
    die "unrecognized input - did you rember to use filter.pl ?" if
      /\d+\.\d+\s+\S\s+:\s+/;
    die unless /^(\d+\.\d+)\s+(\S+)\s+(\d+)/;
    if (($type eq "rate" || $type eq "iat") && !defined $last_time{$2}) {
	$last_time{$2} = $1;
	$last_size{$2} = $3;
	next;
    }
    if (!defined $fh{$2}) {
	$fh{$2} = IO::Handle->new();
	$name = ".plot_$tmp_num.tmp";
	$tmp_num++;
	open($fh{$2},">$name") || die "create $name: $!";
	$set{$2} = $name;
	$unused{$2} = 1;
	if ($type eq "cumul") {
	    print { $fh{$2} } "0 0\n" || die "write $name: $!";
	}
    }
    if ($type eq "rate") {
	if ($last_time{$2} == $1) {
	    $last_size{$2} += $3;
	    next;
	}
	$y = $last_size{$2}*8.0/($1-$last_time{$2});
    }
    if ($type eq "iat") {
	$y = $1-$last_time{$2};
    }
    if ($type eq "cumul") {
	$cumul{$2} += $3;
	$y =  $cumul{$2};
    }
    if ($type eq "delay") {
	if (substr($2,0,1) eq "E") {
	    $enq{$'} = $1;
	    next;
	}
	die "ghost packet$' from nowhere" unless defined $enq{$'};
	$y = $1-$enq{$'};
	delete $enq{$'};
    }
    $sum{$2} -= shift @{ $hist{$2} } if @{ $hist{$2} } == $avg;
    $sum{$2} += $y;
    push(@{ $hist{$2} },$y);
    print { $fh{$2} } "$1 ".($sum{$2}/@{ $hist{$2} })."\n" || die "write: $!";
    delete $unused{$2};
    $last_time{$2} = $1;
    $last_size{$2} = $3;
}

for (values %fh) {
    close $_ || die "close: $!";
}

if (defined $ps_file) {
    $gp = "set terminal postscript eps ".($color ? "color solid" :
      "monochrome"). "\n";
    $gp .= "set output \"$ps_file\"\n";
    $opt = "";
}
else {
    $opt = ($color ? "" : "-mono ")."-persist";
}
if ($jiffies) {
    $gp .= "set xlabel \"Time (jiffies)\"\n";
}
else {
    $gp .= "set xlabel \"Time (sec)\"\n";
}

if ($type eq "rate") {
    $gp .= "set ylabel \"Rate (bps)\"\n";
}
if ($type eq "iat") {
    $gp .= "set ylabel \"Inter-arrival time (sec)\"\n";
}
if ($type eq "cumul") {
    $gp .= "set ylabel \"Cumulative (bytes)\"\n";
}
if ($type eq "delay") {
    $gp .= "set ylabel \"Queuing delay (sec)\"\n";
}
$gp .= "set yrange [0:]\n";

if (!keys %set) {
    print STDERR "no data sets\n";
    exit(1);
}

@tmpfile = values %set;
for (keys %unused) {
    delete $set{$_};
}

$gp .= "plot";
# open(GP,">.gnuplot") || die "open .gnuplot: $!";
for (@tmp = sort keys %set) {
    $gp .= " \"$set{$_}\" title \"$_\" with lines";
    $gp .= $_ eq $tmp[$#tmp] ? "\n" : ", \\\n";
}

push(@tmpfile,".gnuplot");
open(GP,">.gnuplot") || die "open .gnuplot: $!";
print GP $gp || die "write .gnuplot: $!";
close GP || die "close .gnuplot: $!";

system("gnuplot $opt .gnuplot");

unlink(@tmpfile);
