/*
 * data.h - Data type containers
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA
 */


#ifndef DATA_H
#define DATA_H


#include <stdint.h>
#include <stdio.h>


/* including tree.h would cause circular dependency via param.h:PARAM */
struct _qdisc;
struct _class;
struct _filter;
struct _police;
/* ditto for op.h */
struct _op;
/* ditto for field.h */
struct _field;


typedef enum {
    dt_none,	/* no data */
    dt_unum,	/* unsigned integer (don't trust double to preserve a u32) */
    dt_fnum,	/* floating-point number */
    dt_string,	/* string (malloc'ed) */
    dt_rate,	/* rate (bits per second) */
    dt_size,	/* size (Bytes) */
    dt_prate,	/* rate (packets per second) */
    dt_psize,	/* size (packets) */
    dt_time,	/* time (seconds) */
    dt_qdisc,	/* queuing discipline */
    dt_class,	/* class */
    dt_filter,	/* filter */
    dt_police,	/* policer */
    dt_list,	/* list of data elements */
    dt_field,	/* field */
    dt_class_if,/* like class, but only used internally for "if" */
} DATA_TYPE;

#define DT_NON_NUMERIC	dt_qdisc /* limit for numeric types */


struct _data;


typedef struct _data_list {
    struct _data *ref;		/* pointer to actual data */
    struct _data_list *next;	/* next list element */
} DATA_LIST;

typedef struct _data {
    DATA_TYPE type;
    struct _op *op;
	/* if non-NULL, u is invalid and the expression is variable */
    union {
	uint32_t unum;		/* dt_unum */
	double fnum;		/* dt_fnum, dt_p?rate, dt_p?size, dt_time */
	char *string;		/* dt_string */
	struct _qdisc *qdisc;	/* dt_qdisc */
	struct _class *class;	/* dt_class */
	struct _filter *filter;	/* dt_filter */
	struct _police *police;	/* dt_police */
	DATA_LIST *list;	/* dt_list */
	struct _field *field;	/* dt_field */
    } u;
} DATA;


DATA data_none(void);
DATA data_unum(uint32_t in);
DATA data_fnum(double in);
DATA data_string(const char *in);
DATA data_qdisc(struct _qdisc *in);
DATA data_class(struct _class *in);
DATA data_class_if(struct _class *in);
DATA data_filter(struct _filter *in);
DATA data_police(struct _police*in);
DATA data_list(DATA_LIST *list);
DATA_LIST *data_list_element(DATA *ref);
DATA data_field(struct _field *field);

int all_unum(DATA a,DATA b);

DATA data_convert(DATA in,DATA_TYPE type);

uint32_t data_to_unum(DATA in);

/*
 * unit.type must be dt_none, dt_p?rate, dt_p?size, or dt_time
 */

DATA data_add_unit(DATA in,DATA unit);

DATA data_clone(DATA d);
int data_equal(DATA a,DATA b);

#define data_destroy_1(x) ((void) &x)	/* @@@ l8r */
#define data_destroy(x) ((void) &x)	/* @@@ l8r */

void print_data(FILE *file,DATA d);

#endif /* DATA_H */
