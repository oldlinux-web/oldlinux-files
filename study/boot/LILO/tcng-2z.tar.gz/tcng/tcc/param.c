/*
 * param.c - Parameter handling
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#include <stddef.h> /* NULL */
#include <stdlib.h>
#include <math.h>

#include "util.h"
#include "error.h"
#include "param.h"


#include "param_dsc.inc"


PARAM *param_make(PARAM_DSC *dsc,DATA data)
{
    PARAM *p;

    p = alloc_t(PARAM);
    p->dsc = dsc;
    if (dsc->type != dt_none) data = data_convert(data,dsc->type);
    if ((data.type == dt_size || data.type == dt_psize ||
      data.type == dt_rate || data.type == dt_time) &&
      fmod(data.u.fnum,data.type == dt_rate ? 8 : 1) != 0.0)
	warnf("parameter %s (%f) will be truncated",dsc->id,data.u.fnum);
    p->data = data;
    p->next = NULL;
    return p;
}


/*
 * Canonical format:
 *  size:  bytes
 *  rate:  bytes/second
 *  psize: packets
 *  unum:  "as is"
 *  fnum:  not handled
 */


void param_get(const PARAM *params)
{
    const PARAM *param;

#include "param_reset.inc"

    for (param = params; param; param = param->next) {
	double value;

	param->dsc->present = 1;
	switch (param->dsc->type) {
	    case dt_none:
		break;
	    case dt_fnum:
		/* can't assign fnums */
		break;
	    case dt_unum:
		param->dsc->v = param->data.u.unum;
		break;
	    case dt_string:
		/* can't assign strings */
		break;
	    case dt_size:
	    case dt_psize:
	    case dt_rate:
	    case dt_time:
		value = param->data.u.fnum; /* ugly but harmless */
		if (param->dsc->type == dt_rate) value /= 8.0;
		if (value > 0x7fffffffUL)
		    errorf("parameter %s (%f) is too big",param->dsc->id,
		      value);
		param->dsc->v = value;
		break;
	    case dt_list:
		/* can't assign lists */
		break;
	    case dt_police:
		/* can't assign policers */
		break;
	    default:
		abort();
	}
    }
}


void check_required(const PARAM *params,const PARAM_DSC **required)
{
    if (!required) return;
    while (*required) {
	const PARAM *walk;

	for (walk = params; walk; walk = walk->next)
	    if (walk->dsc == *required) break;
	if (!walk)
	    yyerrorf("required parameter \"%s\" is missing",(*required)->id);
	required++;
    }
}


void check_optional(const PARAM *param,const PARAM_DSC **required,
  const PARAM_DSC **optional)
{
    static const PARAM_DSC *null = NULL;
    const PARAM_DSC **walk = &null;

    if (required)
	for (walk = required; *walk; walk++)
	    if (*walk == param->dsc) break;
    if (optional && !*walk)
	for (walk = optional; *walk; walk++)
	    if (*walk == param->dsc) break;
    if (!*walk) yyerrorf("unrecognized parameter \"%s\"",param->dsc->id);
}



void check_params(const PARAM *params,const PARAM_DSC **required,
  const PARAM_DSC **optional)
{
    check_required(params,required);
    while (params) {
	check_optional(params,required,optional);
	params = params->next;
    }
}


static PARAM *lookup(PARAM *params,const PARAM_DSC *dsc)
{
    while (params)
	if (params->dsc == dsc) break;
	else params = params->next;
    return params;
}


int prm_present(PARAM *params,const PARAM_DSC *dsc)
{
    return !!lookup(params,dsc);
}


DATA prm_data(PARAM *params,const PARAM_DSC *dsc)
{
    return lookup(params,dsc)->data;
}


uint32_t prm_unum(PARAM *params,const PARAM_DSC *dsc)
{
    return prm_data(params,dsc).u.unum;
}
