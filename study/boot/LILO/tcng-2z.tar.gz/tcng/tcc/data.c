/*
 * data.c - Data type containers
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#include <stddef.h>
#include <stdio.h>
#include <string.h>

#include "util.h"
#include "tree.h"
#include "op.h"
#include "field.h"
#include "error.h"
#include "data.h"


DATA data_none(void)
{
    DATA d;

    d.type = dt_none;
    d.op = NULL;
    return d;
}


DATA data_unum(uint32_t in)
{
    DATA d;

    d.type = dt_unum;
    d.op = NULL;
    d.u.unum = in;
    return d;
}


DATA data_fnum(double in)
{
    DATA d;

    d.type = dt_fnum;
    d.op = NULL;
    d.u.fnum = in;
    return d;
}


DATA data_string(const char *in)
{
    DATA d;

    d.type = dt_string;
    d.op = NULL;
    d.u.string = stralloc(in);
    return d;
}


DATA data_qdisc(QDISC *in)
{
    DATA d;

    d.type = dt_qdisc;
    d.op = NULL;
    d.u.qdisc = in;
    return d;
}


DATA data_class(CLASS *in)
{
    DATA d;

    d.type = dt_class;
    d.op = NULL;
    d.u.class = in;
    return d;
}


DATA data_class_if(CLASS *in)
{
    DATA d;

    d.type = dt_class_if;
    d.op = NULL;
    d.u.class = in;
    return d;
}


DATA data_filter(FILTER *in)
{
    DATA d;

    d.type = dt_filter;
    d.op = NULL;
    d.u.filter = in;
    return d;
}


DATA data_police(POLICE *in)
{
    DATA d;

    d.type = dt_police;
    d.op = NULL;
    d.u.police = in;
    return d;
}


DATA data_list(DATA_LIST *list)
{
    DATA d;

    d.type = dt_list;
    d.op = NULL;
    d.u.list = list;
    return d;
}


DATA_LIST *data_list_element(DATA *ref)
{
    DATA_LIST *elem;

    elem = alloc_t(DATA_LIST);
    elem->ref = ref;
    elem->next = NULL;
    return elem;
}


DATA data_field(FIELD *field)
{
    DATA d;

    d.type = dt_field;
    d.op = NULL;
    d.u.field = field;
    return d;
}


int all_unum(DATA a,DATA b)
{
    return a.type == dt_unum && b.type == dt_unum;
}


DATA data_convert(DATA in,DATA_TYPE type)
{
    if (in.op) yyerror("constant expression required");
    if (in.type == type) return in;
    if (in.type == dt_fnum && type == dt_unum) in.u.unum = in.u.fnum;
    else if (in.type == dt_unum && type == dt_fnum) in.u.fnum = in.u.unum;
    else yyerror("invalid type conversion");
    in.type = type;
    return in;
}


uint32_t data_to_unum(DATA in)
{
    if (in.type == dt_unum) return in.u.unum;
    if (in.type == dt_none || in.type >= DT_NON_NUMERIC)
	error("invalid type conversion");
    return in.u.fnum;
}


DATA data_add_unit(DATA in,DATA unit)
{
    if (unit.type == dt_none) return in;
    if (in.type != dt_fnum) {
	if (in.type != dt_unum) yyerror("invalid type conversion");
	in.u.fnum = in.u.unum;
    }
    in.type = unit.type;
    in.u.fnum *= unit.u.fnum;
    return in;
}


DATA data_clone(DATA d)
{
    OP *new_op;

    if (!d.op) return d;
    new_op = alloc_t(OP);
    *new_op = *d.op;
    new_op->a = data_clone(d.op->a);
    new_op->b = data_clone(d.op->b);
    new_op->c = data_clone(d.op->c);
    d.op = new_op;
    return d;
}


int data_equal(DATA a,DATA b)
{
    if (a.type != b.type) return 0;
    switch (a.type) {
	case dt_none:
	    return 1;
	case dt_unum:
	    return a.u.unum == b.u.unum;
	case dt_fnum:
	case dt_rate:
	case dt_prate:
	case dt_size:
	case dt_psize:
	case dt_time:
	    return a.u.fnum == b.u.fnum;
	case dt_string:
	    return !strcmp(a.u.string,b.u.string);
	case dt_qdisc:
	    return a.u.qdisc == b.u.qdisc;
	case dt_class:
	case dt_class_if:
	    return a.u.class == b.u.class;
	case dt_filter:
	    return a.u.filter == b.u.filter;
	case dt_police:
	    return a.u.police == b.u.police;
	default:
	    errorf("data_equal can't handle type %d",a.type);
    }
    return 0; /* not reached */
}


void print_data(FILE *file,DATA d)
{
    switch (d.type) {
	case dt_none:
	    fprintf(file,"(none)");
	    break;
	case dt_unum:
	    fprintf(file,"%lu",(unsigned long) d.u.unum);
	    break;
	case dt_fnum:
	    fprintf(file,"%#g",d.u.fnum);
	    break;
	case dt_string:
	    fprintf(file,"\"%s\"",d.u.string);
	    break;
	case dt_rate:
	    fprintf(file,"%g bps",d.u.fnum);
	    break;
	case dt_size:
	    fprintf(file,"%g B",d.u.fnum);
	    break;
	case dt_prate:
	    fprintf(file,"%g pps",d.u.fnum);
	    break;
	case dt_psize:
	    fprintf(file,"%g p",d.u.fnum);
	    break;
	case dt_time:
	    fprintf(file,"%g s",d.u.fnum);
	    break;
	case dt_qdisc:
	    fprintf(file,"<qdisc>");
	    break;
	case dt_class:
	case dt_class_if:
	    fprintf(file,"<class %lx:%lx>",
	      (unsigned long) d.u.class->parent.qdisc->number,
	      (unsigned long) d.u.class->number);
	    break;
	case dt_filter:
	    fprintf(file,"<filter>");
	    break;
	case dt_police:
	    fprintf(file,"<police %lu>",(unsigned long) d.u.police->number);
	    break;
	case dt_list:
	    fprintf(file,"<list>");
	    break;
	case dt_field:
	    fprintf(file,"%s",d.u.field->name);
	    break;
	default:
	    errorf("internal error: unknown data type %d",d.type);
    }
}
