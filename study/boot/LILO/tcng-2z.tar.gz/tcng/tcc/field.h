/*
 * field.h - Packet field definition
 *
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA
 */


#ifndef FIELD_H
#define FIELD_H

#include "data.h"


typedef struct _field {
    const char *name;
    DATA condition;
    DATA access;
    struct _field *next;
} FIELD;


FIELD *field_find(const char *name);
void field_set(const char *name,DATA access,DATA condition);
DATA field_expand(DATA d);

#endif /* FIELD_H */
