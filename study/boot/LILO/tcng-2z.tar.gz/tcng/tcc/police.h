/*
 * police.h - Policing handling
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA
 */


#ifndef POLICE_H
#define POLICE_H

#include "data.h"
#include "param.h"
#include "tree.h"


extern PARAM_DEF police_def;


void check_police(POLICE *police);
void dump_police(POLICE *police);
void add_police(POLICE *police);

#endif /* POLICE_H */
