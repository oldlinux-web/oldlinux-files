/*
 * var.h - Variable handling
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA
 */


#ifndef VAR_H
#define VAR_H

#include "data.h"


typedef enum {
    vu_new,		/* just created */
    vu_unused,		/* initialized but never read */
    vu_used,		/* also read */
    vu_forward		/* forward-declaration, will be set later */
} VAR_USAGE;

typedef struct _var {
    const char *name;
    DATA data;
    DATA *data_ref; /* for forward-declared variables */
    int level;
    VAR_USAGE usage;
    struct _var *next;
} VAR;


VAR *var_find(const char *name);

void var_begin_level(void);
void var_end_level(void);

void var_set(VAR *var,DATA data);
DATA *var_forward(VAR *var); /* also allocates data */
DATA var_get(VAR *var);

#endif /* VAR_H */
