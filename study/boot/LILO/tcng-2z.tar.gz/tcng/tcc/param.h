/*
 * param.h - Parameter handling
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA
 */


#ifndef PARAM_H
#define PARAM_H

#include <stdint.h>

#include "data.h"


typedef struct _param_dsc {
    const char *id;
    DATA_TYPE type;
    /* ---- the following field are set when evaluating parameter lists ----- */
    uint32_t v; /* value */
    int present;
} PARAM_DSC;

typedef struct _param {
    PARAM_DSC *dsc;	/* prm_... */
    DATA data;
    struct _param *next;
} PARAM;

typedef struct {
    const PARAM_DSC **required;
    const PARAM_DSC **optional;
} PARAM_DEF;


#include "param_decl.inc"


PARAM *param_make(PARAM_DSC *dsc,DATA data);
void param_get(const PARAM *params);

void check_required(const PARAM *params,const PARAM_DSC **required);
void check_optional(const PARAM *param,const PARAM_DSC **required,
  const PARAM_DSC **optional);
void check_params(const PARAM *params,const PARAM_DSC **required,
  const PARAM_DSC **optional);

int prm_present(PARAM *params,const PARAM_DSC *dsc);
DATA prm_data(PARAM *params,const PARAM_DSC *dsc);
uint32_t prm_unum(PARAM *params,const PARAM_DSC *dsc);

#endif /* PARAM_H */
