/*
 * if_ext.c - Processing of the "if" command, using external matcher
 *
 * Written 2001 by Werner Almesberger 
 * Copyright 2001 Network Robots
 */

/*
 * Description of invocation and data format in ../doc/external.tex
 *
 * NOTE: if_ext.c does not yet implement the functionality described in
 *       external.tex !
 */


#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <time.h>
#include <sys/wait.h>

#include "config.h"
#include "util.h"
#include "error.h"
#include "tree.h"
#include "data.h"
#include "op.h"
#include "tc.h"
#include "iflib.h"
#include "if.h"


static struct offset_group {
    int base;		/* offset group this group adds to */
    int value_base;	/* offset group of the access */
    int offset;		/* constant offset of access */
    int length;		/* length of access */
    int shift;		/* left-shift by that many bits */
    struct offset_group *next;
} *offset_groups = NULL;


static int lookup_offset_group(int base,int value_base,int offset,int length,
  int shift)
{
    struct offset_group **walk;
    int n = 1;

    if (debug > 1)
	debugf("lookup_offset_group(base %d,%d:%d:%d)",base,value_base,offset,
	  length);
    for (walk = &offset_groups; *walk; walk = &(*walk)->next) {
	if ((*walk)->base == base && (*walk)->value_base == value_base &&
	  (*walk)->offset == offset && (*walk)->length == length &&
	  (*walk)->shift == shift) {
	    if (debug > 1) debugf("lookup_offset_group: found %d",n);
	    return n;
	}
	n++;
    }
    *walk = alloc_t(struct offset_group);
    (*walk)->base = base;
    (*walk)->value_base = value_base;
    (*walk)->offset = offset;
    (*walk)->length = length;
    (*walk)->shift = shift;
    (*walk)->next = NULL;
    if (debug > 1) debugf("lookup_offset_group: new %d",n);
    return n;
}


static int build_offset_group(int base,int value_base,DATA d);


/*
 * @@@ Merge this with iflib_red.c:do_optimize_eq
 */

static int new_offset_group(int base,int value_base,DATA d)
{
    uint32_t mask = 0xffffffff;
    int shift = 3; /* we're bit-based, op_offset is byte-based */
    int offset,length;

    if (debug > 1)
	debugf("new_offset_group(base %d,value_base %d)",base,value_base);
    while (d.op && d.op->dsc != &op_access) {
	if (d.op->dsc == &op_shift_left) {
	    if (d.op->b.op || d.op->b.type != dt_unum) dump_failed(d);
	    shift += d.op->b.u.unum;
	    mask >>= d.op->b.u.unum;
	    d = d.op->a;
	}
	else if (d.op->dsc == &op_shift_right) {
	    if (d.op->b.op || d.op->b.type != dt_unum) dump_failed(d);
	    shift -= d.op->b.u.unum;
	    mask <<= d.op->b.u.unum;
	    d = d.op->a;
	}
	else if (d.op->dsc == &op_and) {
	     if (!d.op->a.op && d.op->a.type == dt_unum) {
		mask &= d.op->a.u.unum;
		d = d.op->b;
	    }
	    else {
		if (d.op->b.op || d.op->b.type != dt_unum) dump_failed(d);
		mask &= d.op->b.u.unum;
		d = d.op->a;
            }
        }
	else if (d.op->dsc == &op_offset) {
	    value_base = build_offset_group(value_base,value_base,d.op->b);
	    d = d.op->a;
	}
        else dump_failed(d);
    }
    assert(d.op && d.op->dsc == &op_access);
    assert(!d.op->b.op && d.op->b.type == dt_unum);
    assert(!d.op->c.op && d.op->c.type == dt_unum);
    offset = d.op->b.u.unum*8;
    length = d.op->c.u.unum;
    if (!mask) return base;
    while (!(mask & 1)) {
	length--;
	mask >>= 1;
	shift++;
    }
    if (shift < 0) dump_failed(d);
    mask <<= 32-length;
    if (!mask) return base;
    while (!(mask & 0x80000000)) {
	offset++;
	length--;
	mask <<= 1;
    }
    return lookup_offset_group(base,value_base,offset,length,shift);
}


static int build_offset_group(int base,int value_base,DATA d)
{
    if (debug > 1)
	debugf("build_offset_group(base %d,value_base %d)",base,value_base);
    while (d.op && d.op->dsc == &op_plus) {
	base = build_offset_group(base,value_base,d.op->a);
	d = d.op->b;
    }
    return new_offset_group(base,value_base,d);
}


static int get_offset_group(DATA d,int base)
{
    assert(d.op && d.op->dsc == &op_offset);
    if (debug > 1) debugf("get_offset_group(base %d)",base);
    return build_offset_group(base,base,d.op->b);
}


static void scan_offsets(DATA d,int base)
{
    if (debug > 1) debugf("scan_offsets(base %d)",base);
    if (!d.op) return;
    if (d.op->dsc == &op_offset) base = get_offset_group(d,base);
    scan_offsets(d.op->a,base);
    scan_offsets(d.op->b,base);
    scan_offsets(d.op->c,base);
}


static void dump_offsets(FILE *file,DATA d)
{
    struct offset_group *group;
    int n = 1;

    scan_offsets(d,0);
    for (group = offset_groups; group; group = group->next) {
	fprintf(file,"offset %d = %d+(%d:%d:%d << %d)\n",n,group->base,
	  group->value_base,group->offset,group->length,group->shift);
	n++;
    }
}


/*
 * This isn't exactly optimized for speed ...
 */


static struct bit_match {
    int offset_group;
    int offset;
    int value;
    struct bit_match *next;
} *bits = NULL,**next_bit = &bits;



static void sort_bits(void)
{
    /* @@@ sort by offset_group, then offset */
    /* TODO: check if this is really valid wrt ordering constraints */
}


static void collect_bits(FILE *file)
{
    struct bit_match *walk,*end;

    for (walk = bits; walk; walk = end) {
	struct bit_match *scan;
	int length = 1;
	int next_offset = walk->offset;
	int nibble = 0;

	for (end = walk->next; end && walk->offset_group == end->offset_group
	  && end->offset == ++next_offset; end = end->next)
	    length++;
	fprintf(file," %d:%d:%d=0x",walk->offset_group,walk->offset,length);
	for (scan = walk; length; scan = scan->next) {
	    length--;
	    nibble |= scan->value << (length & 3);
	    if (!(length & 3)) {
		fputc(nibble >= 10 ? nibble+'A'-10 : nibble+'0',file);
		nibble = 0;
	    }
	}
    }
}


static void drop_bits(void)
{
    struct bit_match *next;

    while (bits) {
	next = bits->next;
	free(bits);
	bits = next;
    }
    next_bit = &bits;
}


static void bit_match(int offset_group,int offset,int value)
{
    struct bit_match *new;

    new = alloc_t(struct bit_match);
    new->offset_group = offset_group;
    new->offset = offset;
    new->value = value;
    new->next = NULL;
    *next_bit = new;
    next_bit = &new->next;
}


static void do_decompose_match(int offset_group,int offset,int length,
  uint32_t mask,uint32_t value)
{
    while (mask) {
	if (!(mask & 0x80000000)) {
	    mask <<= 1;
	    value <<= 1;
	    offset++;
	    length--;
	    continue;
	}
	bit_match(offset_group,offset,value >> 31);
	mask &= ~0x80000000;
    }
}


static void decompose_match(int offset_group,int offset,int length,
  uint32_t mask,uint32_t value)
{
    do_decompose_match(offset_group,offset,length,mask << (32-length),
      value << (32-length));
}


static void dump_match(DATA d,int offset_group)
{
    DATA a,b;
    int bits;
    uint32_t mask = 0xffffffff;

    assert(d.op && d.op->dsc == &op_eq);
    /* @@@ policing */
    a = d.op->a;
    b = d.op->b;
    if (!a.op) {
	if (!b.op) dump_failed(d);
	a = b;
	b = d.op->a;
    }
    if (b.type != dt_unum) dump_failed(d);
    while (a.op && a.op->dsc != &op_access) {
	if (a.op->dsc == &op_and) {
	    /* @@@ handle also  const && access */
	    if (a.op->b.op || a.op->b.type != dt_unum) dump_failed(d);
	    mask = a.op->b.u.unum;
	    a = a.op->a;
	}
	else if (a.op->dsc == &op_offset) {
	    offset_group = get_offset_group(a,offset_group);
	    a = a.op->a;
	}
	else dump_failed(d);
    }
    if (!a.op || a.op->dsc != &op_access) dump_failed(d);
    bits = a.op->c.u.unum;
    mask &= (((1 << (bits-1))-1) << 1) | 1; /* (1 << bits)-1 */
    decompose_match(offset_group,a.op->b.u.unum*8,bits,mask,b.u.unum);
}


static int action_tree(DATA d)
{
    if (!d.op) return d.type == dt_class_if;
    if (d.op->dsc == &op_conform || d.op->dsc == &op_count) return 1;
    if (d.op->dsc == &op_logical_and || d.op->dsc == &op_logical_or)
	return action_tree(d.op->a) && action_tree(d.op->b);
    return 0;
}


static void dump_action(FILE *file,DATA d,int *index)
{
    sort_bits();
    collect_bits(file);
    drop_bits();
    fprintf(file," action %d\n",(*index)++);
}


static void dump_and(FILE *file,DATA d,int offset_group,int *index);


static void dump_other(FILE *file,DATA d,int offset_group,int *index)
{
    if (debug > 1) debugf("dump_other(offset_group %d)",offset_group);
    if (d.op && d.op->dsc == &op_eq) dump_match(d,offset_group);
    else if (action_tree(d)) dump_action(file,d,index);
    else if (d.op && d.op->dsc == &op_offset)
	dump_and(file,d.op->a,get_offset_group(d,offset_group),index);
    else dump_failed(d);
}


static void dump_and(FILE *file,DATA d,int offset_group,int *index)
{
    if (debug > 1) debugf("dump_and(offset_group %d)",offset_group);
    while (d.op && d.op->dsc == &op_logical_and && !action_tree(d)) {
	dump_other(file,d.op->a,offset_group,index);
	d = d.op->b;
    }
    dump_other(file,d,offset_group,index);
}


static void dump_rules(FILE *file,DATA d)
{
    int index = 0;

    if (debug) printf("--- dump_rules ---\n");
    while (d.op && d.op->dsc == &op_logical_or && !action_tree(d)) {
	fprintf(file,"match");
	dump_and(file,d.op->a,0,&index);
	d = d.op->b;
    }
    fprintf(file,"match");
    dump_and(file,d,0,&index);
}


static void dump_or_action(FILE *file,DATA d,DATA otherwise);
static void do_dump_actions(FILE *file,DATA d);


static void dump_and_action(FILE *file,DATA d,DATA next,DATA otherwise)
{
    if (debug > 1) debugf("dump_and_action");
    if (d.op && d.op->dsc == &op_conform) {
	fprintf(file," conform %lu",(unsigned long) d.op->a.u.police->number);
	dump_or_action(file,next,otherwise);
	do_dump_actions(file,otherwise);
	return;
    }
    if (d.op && d.op->dsc == &op_count) {
	fprintf(file," count %lu",(unsigned long) d.op->a.u.police->number);
	dump_or_action(file,next,otherwise);
	return;
    }
    if (!d.op && d.type == dt_class_if) {
	fprintf(file," class %d:%d",(int) d.u.class->parent.qdisc->number,
	  (int) d.u.class->number);
	return;
    }
    dump_failed(d);
}


static void dump_or_action(FILE *file,DATA d,DATA otherwise)
{
    if (debug > 1) debugf("dump_or_action");
    if (d.op && d.op->dsc == &op_logical_and) {
	dump_and_action(file,d.op->a,d.op->b,otherwise);
	return;
    }
    dump_and_action(file,d,data_none(),otherwise);
}


static void do_dump_actions(FILE *file,DATA d)
{
    if (debug > 1) debugf("do_dump_action");
    if (d.op && d.op->dsc == &op_logical_or) {
	dump_or_action(file,d.op->a,d.op->b);
	return;
    }
    if (d.op && d.op->dsc == &op_logical_and) {
	dump_and_action(file,d.op->a,d.op->b,data_none());
	return;
    }
    dump_and_action(file,d,data_none(),data_none());
}


/*
 * @@@ hack: need to re-arrange expressions if final sub-tree does not
 * consist exclusively of actions.
 */


static void find_actions(FILE *file,DATA d,int *index)
{
    if (debug > 1) debugf("find_actions");
    if (action_tree(d)) {
	fprintf(file,"action %d =",(*index)++);
	do_dump_actions(file,d);
	fputc('\n',file);
	return;
    }
    if (!d.op) return;
    find_actions(file,d.op->a,index);
    find_actions(file,d.op->b,index);
    find_actions(file,d.op->c,index);
}


static void dump_actions(FILE *file,DATA d)
{
    int index = 0;

    find_actions(file,d,&index);
}


static void dump_qdiscs(FILE *file,DATA d)
{
    /* @@@ TODO */
}


static struct bucket {
    const POLICE *p;
    struct bucket *next;
} *buckets = NULL;


static void add_bucket(const POLICE *p)
{
    struct bucket **last;

    param_get(p->params);
    if (!prm_rate.present && prm_peakrate.present)
	error("if_ext only supports single-rate token bucket policer");
    for (last = &buckets; *last; last = &(*last)->next)
	if ((*last)->p == p) return;
    *last = alloc_t(struct bucket);
    (*last)->p = p;
    (*last)->next = NULL;
}


static void collect_buckets(const DATA *d,const DATA *root)
{
    if (!d->op && d->type == dt_police) {
	const POLICE *p = d->u.police;

	param_get(p->params);
	if (prm_present(p->params,&prm_overflow))
	    add_bucket(prm_data(p->params,&prm_overflow).u.police);
	add_bucket(d->u.police);
	return;
    }
    if (d->op) {
	collect_buckets(&d->op->a,root);
	collect_buckets(&d->op->b,root);
	collect_buckets(&d->op->c,root);
    }
}


static void dump_buckets(FILE *file,DATA d)
{
    struct bucket *bucket;

    collect_buckets(&d,&d);
    for (bucket = buckets; bucket; bucket = bucket->next) {
	int overflow = 0;

	param_get(bucket->p->params);
	if (prm_present(bucket->p->params,&prm_overflow))
	    overflow =
	      prm_data(bucket->p->params,&prm_overflow).u.police->number;
	fprintf(file,"bucket %d = %lu %lu %lu %lu %d\n",
	  (int) bucket->p->number,(unsigned long) prm_rate.v,
	  prm_mpu.present ? (unsigned long) prm_mpu.v : 0,
	  (unsigned long) prm_burst.v,(unsigned long) prm_burst.v,
	  overflow);
    }
    while (buckets) {
	struct bucket *next;

	next = buckets->next;
	free(buckets);
	buckets = next;
    }
}


void dump_if_ext(const FILTER *filter,const char *target)
{
    DATA d = filter->parent.qdisc->if_expr;
    FILE *pipe;
    char name[100],cmd[200]; /* @@@ */
    int status;

    sprintf(name,"_%02x%03x",(int) (filter->parent.qdisc->number & 0xff),
      (int) (filter->number & 0xfff));
    /*
     * Normalize again, possibly undoing previous optimizations.
     * External program will do its own expression optimization.
     */
    iflib_normalize(&d);
    iflib_offset(&d);
    debug_expr("BEFORE dump_offsets",d);
    sprintf(cmd,"tcc-ext-%s %s >/dev/null",target,name);
    fflush(stdout);
    fflush(stderr);
    pipe = popen(cmd,"w");
    dump_qdiscs(pipe,d);
    dump_offsets(pipe,d);
    dump_buckets(pipe,d);
    dump_actions(pipe,d);
    dump_rules(pipe,d);
    if (ferror(pipe)) errorf("error writing to \"%s\"",cmd);
    status = pclose(pipe);
    if (!WIFEXITED(status) || WEXITSTATUS(status))
	errorf("\"%s\" returns %d",cmd,status);
    printf("insmod cls_%s.o\n",name);
    __tc_filter_add(filter);
    tc_more(" %s\n",name);
}
