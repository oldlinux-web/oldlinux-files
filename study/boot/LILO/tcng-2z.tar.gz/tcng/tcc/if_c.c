/*
 * if_c.c - Processing of the "if" command, generating a C function
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Werner Almesberger
 */

/*
 * In GCC we trust. There's absolutely zero optimization happening in this
 * file. It's up to the C compiler to figure out what to do. Since optimizing
 * arithmetic expressions is about the oldest issue in compiler design, most
 * compilers are really good at this.
 */


#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

#include "config.h"
#include "error.h"
#include "data.h"
#include "op.h"
#include "tree.h"
#include "tc.h"
#include "iflib.h"
#include "if.h"


#define MAX_CLASSES 1024

static int elements;
static unsigned long class[MAX_CLASSES];


static void dump_c_data(FILE *file,DATA d)
{
    switch (d.type) {
	case dt_unum:
	    fprintf(file,"0x%lx",(unsigned long) d.u.unum);
	    break;
	case dt_class_if:
	    class[elements] = (d.u.class->parent.qdisc->number << 16) |
              d.u.class->number;
	    fprintf(file,"({ RESULT(%d); 0; })",elements);
	    elements++;
	    break;
	default:
	    dump_failed(d);
    }
}


static void dump_c_expr(FILE *file,DATA d);


static void dump_math_op(FILE *file,const OP *op)
{
    if (op->b.type == dt_none) {
	fprintf(file," %s",op->dsc->name);
	dump_c_expr(file,op->a);
    }
    else {
	fputc('(',file);
	dump_c_expr(file,op->a);
	fprintf(file," %s ",op->dsc->name);
	dump_c_expr(file,op->b);
	fputc(')',file);
	
    }
}


static void dump_c_op(FILE *file,DATA d)
{
    if (d.op->dsc == &op_plus || d.op->dsc == &op_minus || 
      d.op->dsc == &op_mult || d.op->dsc == &op_div || d.op->dsc == &op_mod ||
      d.op->dsc == &op_not || d.op->dsc == &op_and || d.op->dsc == &op_or ||
      d.op->dsc == &op_xor || d.op->dsc == &op_shift_left ||
      d.op->dsc == &op_shift_right || d.op->dsc == &op_eq ||
      d.op->dsc == &op_ne || d.op->dsc == &op_gt || d.op->dsc == &op_le ||
      d.op->dsc == &op_logical_not || d.op->dsc == &op_logical_or ||
      d.op->dsc == &op_logical_and) {
	dump_math_op(file,d.op);
	return;
    }
    if (d.op->dsc == &op_access) {
	fprintf(file,"ACCESS%d(",d.op->c.u.unum);
	dump_c_expr(file,d.op->b);
	fprintf(file,")");
	return;
    }
    dump_failed(d);
/* missing: mask */
}


static void dump_c_expr(FILE *file,DATA d)
{
    if (!d.op) dump_c_data(file,d);
    else dump_c_op(file,d);
}


static char tcc_module_args[1024] = ""; /* @@@ */


void add_tcc_module_arg(int local,const char *arg)
{
    strcat(tcc_module_args," '");
    if (local) strcat(tcc_module_args,arg+2);
    else {
	strcat(tcc_module_args,"-X");
	strcat(tcc_module_args,arg);
    }
    strcat(tcc_module_args,"'");
}


void dump_if_c(const FILTER *filter)
{
    char name[100],file_name[100],cmd[200]; /* @@@ */
    FILE *file;
    int i;

    sprintf(name,"_c%02x%02x%01x%01x",
      (int) (filter->parent.qdisc->number & 0xff),
      (int) (filter->number & 0xff),(int) (getpid() & 0xf),
      (int) (time(NULL) & 0xf));
    sprintf(file_name,"%s.mdi",name);
    file = fopen(file_name,"w");
    if (!file) {
	perror(file_name);
	exit(1);
    }
    elements = 0;
    fprintf(file,"#define NAME %s\n\n",name);
    fprintf(file,"#define EXPRESSION \\\n");
    dump_c_expr(file,filter->parent.qdisc->if_expr);
    fprintf(file,"\n\n#define ELEMENTS %d\n#define ELEMENT(f) \\\n",elements);
    for (i = 0; i < elements; i++)
	fprintf(file,"  f(%d,0x%lx)%s\n",i,class[i],
	  i == elements-1 ? "" : "\\");
    if (ferror(file)) errorf("error writing to %s",file_name);
    if (fclose(file) == EOF) {
	perror(file_name);
	exit(1);
    }
    sprintf(cmd,TCC_MODULE_CMD "%s cls %s %s",tcc_module_args,file_name,name);
    fflush(stdout);
    fflush(stderr);
    if (system(cmd)) errorf("system(%s) failed",cmd);
    printf("insmod cls_%s.o\n",name);
    __tc_filter_add(filter);
    tc_more(" %s\n",name);
}
