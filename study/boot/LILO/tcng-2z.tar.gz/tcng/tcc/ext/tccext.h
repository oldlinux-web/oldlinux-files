/*
 * tccext.h - Parse information received from tcc's external interface
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 Network Robots.
 * Distributed under the LGPL.
 */


#ifndef TCCEXT_H
#define TCCEXT_H


#include <stdint.h>
#include <stdio.h>


#define __TE_SIZEOF(user_size,default_size) \
  ({ if ((user_size) && (user_size) < (default_size)) abort(); \
    (user_size) ? (user_size) : (default_size); })

#define TE_SIZEOF(ctx,field,dflt) __TE_SIZEOF(ctx->sizes.field,sizeof(dflt))


struct _tccext_offset;

typedef struct _tccext_field {
    struct _tccext_offset *offset_group;/* base offset group; NULL for 0/raw */
    int offset;				/* bit offset within offset group */
    int length;				/* field length in bits */
} TCCEXT_FIELD;

typedef struct _tccext_offset {
    struct _tccext_offset *base;	/* base offset group; NULL for 0/raw */
    TCCEXT_FIELD field;			/* field containing increment */
    int shift_left;			/* increment scaling (to yield bits) */
    int group_number;			/* group number (semi-private) */
    struct _tccext_offset *next;	/* next offset group; NULL if last
					   (semi-private) */
} TCCEXT_OFFSET;

typedef struct _tccext_bucket {
    uint32_t rate;			/* bucket rate, in bytes per second */
    int mpu;				/* minimum policed unit, in bytes */
    uint32_t depth;			/* bucket depth, in bytes */
    uint32_t initial_tokens;		/* inital "credit", in bytes */
    int index;				/* bucket index (semi-private) */
    struct _tccext_bucket *overflow;	/* bucket to send excess tokens to */
    struct _tccext_bucket *next;	/* next bucket; NULL if last
					   (semi-private) */
} TCCEXT_BUCKET;

typedef enum { tat_conform,tat_count,tat_class } TCCEXT_ACTION_TYPE;

typedef struct _tccext_action {
    TCCEXT_ACTION_TYPE type;
    union {
	struct {
	    TCCEXT_BUCKET *bucket;
	    struct _tccext_action *yes_action;
	    struct _tccext_action *no_action;
	} conform;
	struct {
	    TCCEXT_BUCKET *bucket;
	    struct _tccext_action *action;
	} count;
	struct {
	    int qdisc;			/* qdisc number; THIS WILL CHANGE ! */
	    int class;			/* class number; THIS WILL CHANGE ! */
	} class;
    } u;
} TCCEXT_ACTION;

typedef struct _tccext_actions {
    TCCEXT_ACTION *action;		/* action expression */
    int index;				/* action index (semi-private) */
    struct _tccext_actions *next;	/* next actions; NULL if last
					   (semi-private) */
} TCCEXT_ACTIONS;

typedef struct _tccext_match {
    TCCEXT_FIELD field;			/* field to match with */
    uint8_t *data;			/* data, right-aligned to byte
					   boundary */
    struct _tccext_match *next;		/* next match in rule; NULL if last */
    struct _tccext_context *context;	/* back pointer; PRIVATE */
} TCCEXT_MATCH;

typedef struct _tccext_rule {
    TCCEXT_MATCH *matches;		/* ordered list of matches */
    TCCEXT_ACTIONS *actions;		/* actions if match */
    struct _tccext_rule *next;		/* next rule; NULL if last */
} TCCEXT_RULE;

typedef struct _tccext_queue {
    /* TBD */
    struct _tccext_queue *next;		/* next queue; NULL if last */
} TCCEXT_QUEUE;

typedef struct {
    int offset;				/* user offset size; 0 for default */
    int bucket;				/* user bucket size; 0 for default */
    int action;				/* user action size; 0 for default */
    int actions;			/* user actions size; 0 for default */
    int match;				/* user match size; 0 for default */
    int rule;				/* user rule size; 0 for default */
    int queue;				/* user queue size; 0 for default */
    int device;				/* user device size; 0 for default */
    int context;			/* user context size; 0 for default */
} TCCEXT_SIZES;

typedef struct _tccext_context {
    TCCEXT_BUCKET *buckets;		/* list of buckets; NULL if none */
    TCCEXT_OFFSET *offset_groups;	/* offset groups (semi-private) */
    TCCEXT_ACTIONS *actions;		/* list of actions; NULL if none */
    TCCEXT_RULE *rules;			/* ordered list of rules; NULL if
					   none */
    TCCEXT_QUEUE *queues;		/* ordered list of queues; NULL if
					   none */
    TCCEXT_SIZES sizes;
} TCCEXT_CONTEXT;


TCCEXT_CONTEXT *tccext_parse(FILE *file,TCCEXT_SIZES *sizes);
    /* pass NULL in sizes to use defaults */

void tccext_destroy(TCCEXT_CONTEXT *ctx);
    /* Delete structure returned by tccext_parse. tccext_destroy does not
       de-allocate memory objects attached to user fields ! */

#endif
