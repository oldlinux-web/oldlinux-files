/*
 * match.c - Simple packet matcher using tccext
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 Network Robots
 */

/*
 * Note: the code is really sloppy with value ranges in policing. So be sure
 * to use it only with broad safety margins.
 */


#include <inttypes.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

#include "tccext.h"


#define _S(x) #x
#define S(x) _S(x)


extern double get_time(void); /* from cls_ext_test.c */


static uint32_t extract_bits(uint8_t *data,int start,int bits)
{
    uint32_t res = 0;

    if ((bits+(start & 7)) > 32) abort();
    data += start >> 3;
    start &= 7;
    res = *data++ & ((1 << (8-start))-1);
    bits -= 8-start;
    while (bits > 0) {
	res = (res << 8) | *data++;
	bits -= 8;
    }
    if (bits) res >>= -bits;
    return res;
}


static int offset(const TCCEXT_OFFSET *group,uint8_t *raw)
{
    if (!group) return 0;
    return offset(group->base,raw)+
      (extract_bits(raw,offset(group->field.offset_group,raw)+
      group->field.offset,group->field.length) << group->shift_left);
}


static int match_1(const TCCEXT_MATCH *m,uint8_t *raw)
{
    return extract_bits(raw,offset(m->field.offset_group,raw)+m->field.offset,
      m->field.length) == extract_bits(m->data,(-m->field.length) & 7,
      m->field.length);
}


struct my_bucket {
    TCCEXT_BUCKET b;	/* tccext's bucket data */
    int tokens;		/* current number of tokens in bucket */
    double last_refill;	/* time of last bucket refill */
    double max_time;	/* maximum delta time for bucket, with overflow chain */
    int initialized;	/* 1 if initialized, 0 otherwise (set to 0 by tccext) */
};


static void initialize_bucket(struct my_bucket *bucket)
{
    TCCEXT_BUCKET *overflow;
    int max_tokens;

    if (bucket->initialized) return;
    bucket->tokens = bucket->b.initial_tokens;
    max_tokens = bucket->b.depth;
    for (overflow = bucket->b.overflow; overflow; overflow = overflow->overflow)
	max_tokens += overflow->depth;
    bucket->max_time = max_tokens/bucket->b.rate;
    bucket->last_refill = get_time();
    bucket->initialized = 1;
}


static int action(const TCCEXT_ACTION *a,int len)
{
    TCCEXT_BUCKET *walk;
    struct my_bucket *bucket;
    int policed_len,tokens;
    double now,delta;

    switch (a->type) {
	case tat_class:
	    return (a->u.class.qdisc << 16) | a->u.class.class;
	case tat_conform:
	    bucket = (struct my_bucket *) a->u.conform.bucket;
	    initialize_bucket(bucket);
	    now = get_time();
	    delta = now-bucket->last_refill;
	    if (delta > bucket->max_time) delta = bucket->max_time;
	    tokens = delta*bucket->b.rate;
	    for (walk = &bucket->b; walk && tokens; walk = walk->overflow) {
		struct my_bucket *b = (struct my_bucket *) walk;

		b->tokens += tokens;
		if (b->tokens <= walk->depth) tokens = 0;
		else {
		    tokens = b->tokens-walk->depth;
		    b->tokens = walk->depth;
		}
	    }
	    bucket->last_refill = now;
	    policed_len = len > bucket->b.mpu ? len : bucket->b.mpu;
	    return bucket->tokens >= policed_len ?
	      action(a->u.conform.yes_action,len) :
	      action(a->u.conform.no_action,len);
	case tat_count:
	    bucket = (struct my_bucket *) a->u.count.bucket;
	    initialize_bucket(bucket);
	    assert(len <= bucket->tokens);
	    policed_len = len > bucket->b.mpu ? len : bucket->b.mpu;
	    if (bucket->tokens < policed_len) bucket->tokens = 0;
	    else bucket->tokens -= policed_len;
	    return action(a->u.count.action,len);
	default:
	    fprintf(stderr,"\"match\" can't handle action type %d\n",
	      (int) a->type);
	    exit(1);
    }
}


int match(uint8_t *raw,int len); /* extern in cls_ext_test.c */

int match(uint8_t *raw,int len)
{
    static TCCEXT_CONTEXT *context;
    TCCEXT_RULE *r;

    if (!context) {
	static TCCEXT_SIZES sizes = { .bucket = sizeof(struct my_bucket) };
	FILE *file;

	file = fopen("_" S(NAME) ".out","r");
	if (!file) {
	    perror("_" S(NAME) ".out");
	    exit(1);
	}
	context = tccext_parse(file,&sizes);
    }
    for (r = context->rules; r; r = r->next) {
	TCCEXT_MATCH *m;

	for (m = r->matches; m; m = m->next)
	    if (!match_1(m,raw)) break;
	if (!m) return action(r->actions->action,len);
    }
    return 0; /* @@@ change once a default value is selected */
}
