/*
 * tccext.c - Parse information received from tcc's external interface
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 Network Robots.
 * Distributed under the LGPL.
 */


#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <sys/types.h>

#include "tccext.h"


#define MAX_LINE	65536	/* maximum input line */
#define MAX_BUF		1024	/* maximum token length */


#define _S(x) #x
#define S(x) _S(x)


static void *alloc_zero(size_t size)
{
    void *p;

    p = malloc(size);
    if (!p) {
	perror("malloc");
	exit(1);
    }
    memset(p,0,size);
    return p;
}


static TCCEXT_OFFSET *find_group(TCCEXT_CONTEXT *ctx,int number)
{
    TCCEXT_OFFSET *group;

    if (!number) return NULL;
    for (group = ctx->offset_groups; group; group = group->next)
	if (group->group_number == number) return group;
    fprintf(stderr,"offset group %d not found\n",number);
    exit(1);
}


static TCCEXT_FIELD parse_field(TCCEXT_CONTEXT *ctx,const char *line,int *len)
{
    TCCEXT_FIELD field;
    int base,pos;

    if (sscanf(line,"%i:%i:%i%n",&base,&field.offset,&field.length,&pos) < 3) {
	fprintf(stderr,"invalid field expression \"%s\"\n",line);
	exit(1);
    }
    field.offset_group = find_group(ctx,base);
    if (len) *len = pos;
    return field;
}


static void parse_offset(TCCEXT_CONTEXT *ctx,const char *line)
{
    TCCEXT_OFFSET *offset;
    int base,pos;

    offset = alloc_zero(TE_SIZEOF(ctx,offset,TCCEXT_OFFSET));
    if (sscanf(line,"%i = %i+(%n",&offset->group_number,&base,&pos) >= 2) {
	int pos2;

	offset->base = find_group(ctx,base);
	offset->field = parse_field(ctx,line+pos,&pos2);
	if (sscanf(line+pos+pos2+1,"<< %i)",&offset->shift_left) == 1) {
	    offset->next = ctx->offset_groups;
	    ctx->offset_groups = offset;
	    return;
	}
    }
    fprintf(stderr,"invalid offset expression \"%s\"\n",line);
    exit(1);
}


static TCCEXT_ACTIONS *find_actions(TCCEXT_CONTEXT *ctx,int index)
{
    TCCEXT_ACTIONS *actions;

    for (actions = ctx->actions; actions; actions = actions->next)
	if (actions->index == index) break;
    return actions;
}


static int nibble(char c)
{
    return c >= 'a' ? c-'a'+10 : c >= 'A' ? c-'A'+10 : c-'0';
}


static TCCEXT_MATCH *parse_match(TCCEXT_CONTEXT *ctx,const char *line,int *len)
{
    TCCEXT_MATCH *match;
    int pos;

    match = alloc_zero(TE_SIZEOF(ctx,match,TCCEXT_MATCH));
    match->field = parse_field(ctx,line,&pos);
    if (!strncmp(line+pos,"=0x",3)) {
	int nibbles = 0,bytes;
	const char *walk;
	uint8_t *p;

	while (line[pos+3] == '0') pos++; /* avoid overflow on 0x000000... */
	for (walk = line+pos+3; *walk && isxdigit(*walk); walk++)
	    nibbles++;
	bytes = (match->field.length+7) >> 3;
	match->data = alloc_zero(bytes);
	p = match->data+bytes-((nibbles+1) >> 1);
	walk = line+pos+3;
	if (nibbles & 1) {
	    *p++ = nibble(*walk++);
	    nibbles--;
	}
	while (nibbles) {
	    *p = nibble(*walk++) << 4;
	    *p++ |= nibble(*walk++);
	    nibbles -= 2;
	}
	match->next = NULL;
	match->context = ctx;
	if (len) *len = walk-line;
	return match;
    }
    fprintf(stderr,"invalid match \"%s\"\n",line);
    exit(1);
}


static void parse_rule(TCCEXT_CONTEXT *ctx,const char *line)
{
    TCCEXT_RULE *rule,**walk;
    TCCEXT_MATCH **next;
    int actions,pos;

    rule = alloc_zero(TE_SIZEOF(ctx,rule,TCCEXT_RULE));
    rule->matches = NULL;
    next = &rule->matches;
    while (*line && isdigit(*line)) {
	*next = parse_match(ctx,line,&pos);
	next = &(*next)->next;
	line += pos+1;
    }
    if (sscanf(line," action %i",&actions) != 1) {
	fprintf(stderr,"invalid actions \"%s\"\n",line);
	exit(1);
    }
    rule->actions = find_actions(ctx,actions);
    if (!rule->actions) {
	fprintf(stderr,"no actions %d\n",actions);
	exit(1);
    }
    rule->next = NULL;
    for (walk = &ctx->rules; *walk; walk =&(*walk)->next);
    *walk = rule;
}


static void parse_queue(TCCEXT_CONTEXT *ctx,const char *name,const char *line)
{
    /* @@@ TODO */
}


static TCCEXT_BUCKET *find_bucket(TCCEXT_CONTEXT *ctx,int index)
{
    TCCEXT_BUCKET *bucket;

    for (bucket = ctx->buckets; bucket; bucket = bucket->next)
	if (bucket->index == index) return bucket;
    fprintf(stderr,"no bucket %d\n",index);
    exit(1);
}


static void parse_bucket(TCCEXT_CONTEXT *ctx,const char *line)
{
    TCCEXT_BUCKET *bucket;
    unsigned long rate,depth,initial;
    int overflow;

    /* @@@ %lu should allow hex too %i */
    bucket = alloc_zero(TE_SIZEOF(ctx,bucket,TCCEXT_BUCKET));
    if (sscanf(line,"%i = %lu %i %lu %lu %i",&bucket->index,&rate,&bucket->mpu,
      &depth,&initial,&overflow) != 6) {
	fprintf(stderr,"unrecognized bucket \"%s\"\n",line);
	exit(1);
    }
    bucket->rate = rate;
    bucket->depth = depth;
    bucket->initial_tokens = initial;
    bucket->overflow = overflow ? find_bucket(ctx,overflow) : NULL;
    bucket->next = ctx->buckets;
    ctx->buckets = bucket;
}


static TCCEXT_ACTION *parse_action(TCCEXT_CONTEXT *ctx,const char **line)
{
    TCCEXT_ACTION *action;
    int bucket,pos;

    action = alloc_zero(TE_SIZEOF(ctx,action,TCCEXT_ACTION));
    if (sscanf(*line,"class %i:%i%n",&action->u.class.qdisc,
      &action->u.class.class,&pos) >= 2 ) {
	action->type = tat_class;
	*line += pos+1;
	return action;
    }
    if (sscanf(*line,"conform %i%n",&bucket,&pos) >= 1) {
	action->type = tat_conform;
	action->u.conform.bucket = find_bucket(ctx,bucket);
	*line += pos+1;
	action->u.conform.yes_action = parse_action(ctx,line);
	action->u.conform.no_action = parse_action(ctx,line);
	return action;
    }
    if (sscanf(*line,"count %i%n",&bucket,&pos) >= 1) {
	action->type = tat_count;
	action->u.count.bucket = find_bucket(ctx,bucket);
	*line += pos+1;
	action->u.count.action = parse_action(ctx,line);
	return action;
    }
    fprintf(stderr,"unrecognized action \"%s\"\n",*line);
    exit(1);
}


static void parse_actions(TCCEXT_CONTEXT *ctx,const char *line)
{
    TCCEXT_ACTIONS *actions;
    int pos;

    actions = alloc_zero(TE_SIZEOF(ctx,actions,TCCEXT_ACTIONS));
    if (!sscanf(line,"%i =%n",&actions->index,&pos)) {
	fprintf(stderr,"unrecognized action definition \"%s\"\n",line);
	exit(1);
    }
    line += pos+1;
    actions->action = parse_action(ctx,&line);
    actions->next = ctx->actions;
    ctx->actions = actions;
}


TCCEXT_CONTEXT *tccext_parse(FILE *file,TCCEXT_SIZES *sizes)
{
    TCCEXT_CONTEXT *ctx;
    char line[MAX_LINE];
    
    ctx = alloc_zero(__TE_SIZEOF(sizes ? sizes->context : 0,
      sizeof(TCCEXT_CONTEXT)));
    ctx->offset_groups = NULL;
    ctx->rules = NULL;
    ctx->queues = NULL;
    if (sizes) ctx->sizes = *sizes;
    else memset(&ctx->sizes,0,sizeof(TCCEXT_SIZES));
    while (fgets(line,sizeof(line),file)) {
	char buf[MAX_BUF];
	char *here;
	int pos;

	here = strchr(line,'\n');
	if (here) *here = 0;
	here = strchr(line,'#');
	if (here) *here = 0;
	if (!*line) continue;
	if (!sscanf(line,"%" S(MAX_BUF) "s%n",buf,&pos)) {
	    fprintf(stderr,"unrecognized line \"%s\"\n",line);
	    exit(1);
	}
	if (!strcmp(buf,"queue")) parse_queue(ctx,buf,line+pos+1);
	else if (!strcmp(buf,"offset")) parse_offset(ctx,line+pos+1);
	else if (!strcmp(buf,"bucket")) parse_bucket(ctx,line+pos+1);
	else if (!strcmp(buf,"action")) parse_actions(ctx,line+pos+1);
	else if (!strcmp(buf,"match")) parse_rule(ctx,line+pos+1);
	else {
	    fprintf(stderr,"unrecognized line \"%s\"\n",line);
	    exit(1);
	}
    }
    return ctx;
}


void tccext_destroy(TCCEXT_CONTEXT *ctx)
{
    while (ctx->offset_groups) {
	TCCEXT_OFFSET *next_offset;

	next_offset = ctx->offset_groups->next;
	free(ctx->offset_groups);
	ctx->offset_groups = next_offset;
    }
    while (ctx->rules) {
	TCCEXT_RULE *next_rule;

	while (ctx->rules->matches) {
	    TCCEXT_MATCH *next_match;
	    next_match = ctx->rules->matches->next;
	    free(ctx->rules->matches->data);
	    free(ctx->rules->matches);
	    ctx->rules->matches = next_match;
	}
	next_rule = ctx->rules->next;
	free(ctx->rules);
	ctx->rules = next_rule;
    }
    while (ctx->queues) {
	TCCEXT_QUEUE *next_queue;

	next_queue = ctx->queues;
	free(ctx->queues);
	ctx->queues = next_queue;
    }
}
