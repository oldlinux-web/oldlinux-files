/*
 * qdisc.h - Qdisc handling
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA
 */


#ifndef QDISC_H
#define QDISC_H

#include "tree.h"


extern QDISC_DSC ingress_dsc;
extern QDISC_DSC cbq_dsc;
extern QDISC_DSC dsmark_dsc;
extern QDISC_DSC fifo_dsc;
extern QDISC_DSC gred_dsc;
extern QDISC_DSC prio_dsc;
extern QDISC_DSC red_dsc;
extern QDISC_DSC sfq_dsc;
extern QDISC_DSC tbf_dsc;


void assign_qdisc_ids(QDISC *root);
void add_class(CLASS *class);
void check_qdisc(QDISC *qdisc);
void dump_qdisc(QDISC *qdisc);

#endif /* QDISC_H */
