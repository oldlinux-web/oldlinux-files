/* @@@ CHECK:
   - range of user-assigned ids (also filter)
   - their uniqueness
  (done for qdiscs and filter, classes missing)
*/

/*
 * qdisc.c - Qdisc handling
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#include <stddef.h>

#include "tcdefs.h"
#include "util.h"
#include "error.h"
#include "param.h"
#include "tree.h"
#include "device.h"
#include "tc.h"
#include "filter.h"
#include "qdisc.h"


/* ---------------- Helper functions for structure checking ---------------- */


static void check_childless(const CLASS *class)
{
    if (class->child)
	errorf("%s does not have nested classes",
	  class->parent.qdisc->dsc->name);
    if (class->filters)
	errorf("%s classes don't have local filters",
	  class->parent.qdisc->dsc->name);
}


/* ----------------------- Assignment of unique IDs ------------------------ */


struct recurse_tmp {
    int (*fn)(QDISC *qdisc,void *user);
    void *user;
};

static uint32_t curr_id;


static int recurse_class(CLASS *class,int (*fn)(CLASS *class,void *user),
  void *user)
{
    int count = 0;

    while (class) {
	if (fn(class,user)) return 1;
	if (class->child) count += recurse_class(class->child,fn,user);
	class = class->next;
    }
    return count;
}


static int recurse_qdisc(QDISC *qdisc,int (*fn)(QDISC *qdisc,void *user),
  void *user);


static int class_to_qdisc(CLASS *class,void *user)
{
    struct recurse_tmp *tmp = user;

    if (!class->qdisc) return 0;
    return recurse_qdisc(class->qdisc,tmp->fn,tmp->user);
}


static int recurse_qdisc(QDISC *qdisc,int (*fn)(QDISC *qdisc,void *user),
  void *user)
{
    struct recurse_tmp tmp;

    if (!qdisc) return 0;
    tmp.fn = fn;
    tmp.user = user;
    return fn(qdisc,user)+recurse_class(qdisc->classes,class_to_qdisc,&tmp);
}


static int count_class_ids(CLASS *class,void *user)
{
    return class->number == *(uint32_t *) user;
}


static int assign_class_id(CLASS *class,void *user)
{
    CLASS *root = user;

    if (class->number != UNDEF_U32) {
	if (recurse_class(root,count_class_ids,&class->number) > 1)
	    errorf("duplicate class ID 0x%x",class->number);
    }
    else {
	while (recurse_class(root,count_class_ids,&curr_id)) curr_id++;
	class->number = curr_id;
    }
    if (class->number & ~0xffff)
	errorf("invalid class disc ID 0x%x",class->number);
    return 0;
}


static int count_qdisc_ids(QDISC *qdisc,void *user)
{
    return qdisc->number == *(uint32_t *) user;
}


static int assign_qdisc_id(QDISC *qdisc,void *user)
{
    QDISC *root = user;

    if (qdisc->number != UNDEF_U32) {
	if (recurse_qdisc(root,count_qdisc_ids,&qdisc->number) > 1)
	    errorf("duplicate qdisc ID 0x%x",qdisc->number);
    }
    else {
	while (recurse_qdisc(root,count_qdisc_ids,&curr_id)) curr_id++;
	qdisc->number = curr_id;
    }
    if (!qdisc->number || (qdisc->number & ~0xffff))
	errorf("invalid qdisc ID 0x%x",qdisc->number);
    return 0;
}


void assign_qdisc_ids(QDISC *root)
{
    curr_id = 1;
    (void) recurse_qdisc(root,assign_qdisc_id,root);
}


/* ------------------------- Common RED functions -------------------------- */


static void red_parameters(PARAM *params,uint32_t bandwidth)
{
    tc_add_size("limit",prm_limit.v);
    tc_add_size("min",prm_min.v);
    tc_add_size("max",prm_max.v);
#if 0 /* @@@ more correct if avpkt is no integer (e.g. if calaculated)  */
    tc_more(" burst %d",(int) (prm_data(qdisc->params,&prm_burst).u.fnum/
      prm_data(qdisc->params,&prm_avpkt).u.fnum));
#endif
    tc_add_unum("burst",prm_burst.v/prm_avpkt.v);
    tc_add_size("avpkt",prm_avpkt.v);
    tc_add_rate("bandwidth",bandwidth);
    if (prm_probability.present)
	tc_add_fnum("probability",prm_data(params,&prm_probability));
}


/* -------------------------------- INGRESS -------------------------------- */


static void ingress_check(QDISC *qdisc)
{
    CLASS *class;

    qdisc->number = 0xffff; /* ingress magic number */
    for (class = qdisc->classes; class; class = class->next) {
	check_childless(class);
	if (class->qdisc) error("ingress has no inner qdiscs");
	if (class->number == UNDEF_U32)
	    error("ingress does not auto-assign class numbers");
    }
    check_filters(qdisc->filters);
}


static void ingress_dump_tc(QDISC *qdisc)
{
    tc_qdisc_add(qdisc);
    tc_nl();
    dump_filters(qdisc->filters);
}


static PARAM_DEF ingress_qdisc = {
    .required = NULL,
    .optional = NULL,
};

static PARAM_DEF ingress_class = {
    .required = NULL,
    .optional = NULL,
};

QDISC_DSC ingress_dsc = {
    .name = "ingress",
    .qdisc_param = &ingress_qdisc,
    .class_param = &ingress_class,
    .check = &ingress_check,
    .dump_tc = &ingress_dump_tc,
};



/* ---------------------------------- CBQ ---------------------------------- */


#define __DEFAULT_PRM(f) f(allot) f(avpkt) f(bandwidth) f(ewma) f(maxburst) \
			 f(minburst) f(mpu) f(prio) f(weight)
#define __DEFAULT_PRM_REQ(f) f(bandwidth) f(maxburst) f(rate) \
  /* the following parameters are theoretically optional. Practically, they \
     aren't */ \
  f(avpkt) f(allot)


static void cbq_check_priomap(const QDISC *qdisc,const CLASS *class,
  DATA_LIST *priomap)
{
    DATA_LIST *walk;
    int n = 0;

    if (!priomap) return;
    for (walk = priomap; walk; walk = walk->next) {
	CLASS *ref = walk->ref->u.class;
	CLASS *scan;

	if (++n > TC_PRIO_MAX) error("too many entries in priomap");
	if (walk->ref->type != dt_class)
		errorf("invalid type %d%s entry of \"priomap\"",n,
		  n == 1 ? "st" : n == 2 ? "nd" : "th");
	if (ref->parent.qdisc != qdisc) /* can this ever happen ? */
	    errorf("class %x:%x in priomap belongs to different qdisc",
	      (int) ref->parent.qdisc->number,(int) ref->number);
	if (!class) continue;
	for (scan = ref->parent.class; scan && scan != class;
	  scan = scan->parent.class);
	if (!scan)
	    errorf("class 0x%x in priomap is not child of class 0x%x",
	      (int) ref->number,(int) class->number);
    }
}


static void cbq_check_classes(CLASS *classes,DEFAULT_ARGS,int depth)
{
    CLASS *class;

    if (!classes) return;
    if (depth == TC_CBQ_MAXLEVEL)
	errorf("can't nest CBQ classes deeper than %d levels",TC_CBQ_MAXLEVEL);
    for (class = classes; class; class = class->next) {
	DEFAULT_DECL_SAVED;
	DATA_LIST *priomap = NULL;

	param_get(class->params);
	DEFAULT_GET;
	DEFAULT_CHECK;
	DEFAULT_SAVE;
	if (prm_minburst.present && prm_minburst.v > prm_maxburst.v)
	    errorf("\"minburst\" (%lu) > \"maxburst\" (%lu)",
	      (unsigned long) prm_minburst.v,(unsigned long) prm_maxburst.v);
	if (prm_prio.present && prm_prio.v > TC_CBQ_MAXPRIO)
	    errorf("\"prio\" (%lu) > %d",(unsigned long) prm_prio.v,
	      TC_CBQ_MAXPRIO);
	if (!prm_rate.v) error("rate must be non-zero");
	if (prm_rate.v > prm_bandwidth.v)
	errorf("\"rate\" (%lu) > \"bandwidth\" (%lu)",
	  (unsigned long) prm_rate.v,(unsigned long) prm_bandwidth.v);
	if (prm_priomap.present)
	    priomap = prm_data(class->params,&prm_priomap).u.list;
	cbq_check_classes(class->child,DEFAULT_PASS_SAVED,depth+1);
	cbq_check_priomap(class->parent.qdisc,class,priomap);
	check_qdisc(class->qdisc);
	check_filters(class->filters);
    }
}


static void cbq_check(QDISC *qdisc)
{
    DATA_LIST *priomap = NULL;

    curr_id = 1;
    (void) recurse_class(qdisc->classes,assign_class_id,qdisc->classes);
    param_get(qdisc->params);
    if (prm_priomap.present)
	priomap = prm_data(qdisc->params,&prm_priomap).u.list;
    cbq_check_classes(qdisc->classes,DEFAULT_PASS,0);
    cbq_check_priomap(qdisc,NULL,priomap);
    check_filters(qdisc->filters);
}


/*
 * Name confusion ? Well, we call the concept "priomap", but in the case of
 * CBQ, tc and the kernel call it "defmap". So the tc-specific functions use
 * "defmap", while the output-independent ones use "priomap".
 */

static void cbq_dump_defmaps_1_tc(PARAM *params,const CLASS *class,
  uint32_t major,uint32_t minor)
{
    DATA_LIST *walk;
    uint32_t mask = 0;
    int n;

    param_get(params);
    if (!prm_priomap.present) return;
    n = 0;
    for (walk = prm_data(params,&prm_priomap).u.list; walk; walk = walk->next) {
	if (walk->ref->u.class == class) mask |= 1 << n;
	n++;
    }
    if (!mask) return;
    tc_class_change(class);
    tc_more(" split %x:%x",(int) major,(int) minor);
    tc_more(" defmap %lx/%lx",(unsigned long) mask,(unsigned long) mask);
    tc_nl();
}


static void cbq_dump_defmaps_tc(const CLASS *class)
{
    const CLASS *parent;

    cbq_dump_defmaps_1_tc(class->parent.qdisc->params,class,
      class->parent.qdisc->number,0);
    for (parent = class->parent.class; parent; parent = parent->parent.class)
	cbq_dump_defmaps_1_tc(parent->params,class,class->parent.qdisc->number,
	  parent->number);
}


static void cbq_dump_classes_tc(CLASS *classes,DEFAULT_ARGS)
{
    CLASS *class;

    if (!classes) return;
    for (class = classes; class; class = class->next) {
	DEFAULT_DECL_SAVED;

	param_get(class->params);
	DEFAULT_GET;
	DEFAULT_CHECK;
	DEFAULT_SAVE;
	tc_class_add(class);
	tc_add_rate("bandwidth",prm_bandwidth.v);
	tc_add_rate("rate",prm_rate.v);
	if (prm_allot.present) tc_add_size("allot",prm_allot.v);
	if (prm_avpkt.present) tc_add_size("avpkt",prm_avpkt.v);
	if (prm_ewma.present) tc_add_unum("ewma",prm_ewma.v);
	if (prm_maxburst.present) tc_add_psize("maxburst",prm_maxburst.v);
	if (prm_minburst.present) tc_add_psize("minburst",prm_minburst.v);
	if (prm_mpu.present) tc_add_size("mpu",prm_mpu.v);
	if (prm_prio.present) tc_add_unum("prio",prm_prio.v);
/* @@@ AAAARRRRRRRRGGG!!!! */
	if (prm_weight.present) tc_add_size("weight",prm_weight.v);
	if (prm_bounded.present) tc_more(" bounded");
	if (prm_isolated.present) tc_more(" isolated");
	tc_nl();
	cbq_dump_defmaps_tc(class);
	dump_qdisc(class->qdisc);
	cbq_dump_classes_tc(class->child,DEFAULT_PASS_SAVED);
	dump_filters(class->filters);
    }
}


static void cbq_dump_tc(QDISC *qdisc)
{
    tc_qdisc_add(qdisc);
    param_get(qdisc->params);
    tc_add_rate("bandwidth",prm_bandwidth.v);
    if (prm_avpkt.present) tc_add_size("avpkt",prm_avpkt.v);
    if (prm_ewma.present) tc_add_unum("ewma",prm_ewma.v);
    if (prm_mpu.present) tc_add_size("mpu",prm_mpu.v);
    tc_nl();
    cbq_dump_classes_tc(qdisc->classes,DEFAULT_PASS);
    dump_filters(qdisc->filters);
}


static const PARAM_DSC *cbq_qdisc_req[] = {
    &prm_bandwidth,	/* rate */
    NULL
};

static const PARAM_DSC *cbq_qdisc_opt[] = {
    &prm_priomap,	/* list of classes */
    DEFAULT_LIST	/* NB: no trailing comma */
    NULL
};

static const PARAM_DSC *cbq_class_req[] = {
    &prm_rate,		/* rate */
    NULL
};

static const PARAM_DSC *cbq_class_opt[] = {
    &prm_bounded,	/* flag */
    &prm_isolated,	/* flag */
    &prm_priomap,	/* list of class */
    DEFAULT_LIST	/* NB: no trailing comma */
    NULL
};

static PARAM_DEF cbq_qdisc = {
    .required = cbq_qdisc_req,
    .optional = cbq_qdisc_opt,
};

static PARAM_DEF cbq_class = {
    .required = cbq_class_req,
    .optional = cbq_class_opt,
};

QDISC_DSC cbq_dsc = {
    .name = "cbq",
    .qdisc_param = &cbq_qdisc,
    .class_param = &cbq_class,
    .check = &cbq_check,
    .dump_tc = &cbq_dump_tc,
};


#undef __DEFAULT_PRM
#undef __DEFAULT_PRM_REQ


/* -------------------------------- DSMARK --------------------------------- */


#define __DEFAULT_PRM(f) f(mask)


static void dsmark_check(QDISC *qdisc)
{
    DEFAULT_DECL;
    int tmp;
    CLASS *class;
    int got_qdisc = 0;

    param_get(qdisc->params);
    DEFAULT_SET;
    for (tmp = prm_indices.v; tmp != 1; tmp >>= 1)
	if (tmp & 1) error("indices must be a power of two");
    for (class = qdisc->classes; class; class = class->next) {
	check_childless(class);
	param_get(class->params);
	DEFAULT_GET;
	if (class->qdisc && (class->number != UNDEF_U32 ||
	  prm_mask.present || prm_value.present))
	    warn("suggest unnumbered and parameter-less class for dsmark's "
	      "inner qdisc");
	if (class->number == UNDEF_U32) {
	    if (class->qdisc) class->number = 0;
	    else error("dsmark does not auto-assign class numbers");
	}
	if ((prm_mask.present || prm_value.present) &&
	  class->number >= prm_indices.v)
	    errorf("dsmark class number (%lu) must be < indices (%lu) if "
	      "using parameters",(unsigned long) class->number,
	      (unsigned long) prm_indices.v-1);
	if (prm_mask.present && prm_mask.v > 0xff)
	    errorf("mask 0x%x above limit 0xff",prm_mask.v);
	if (!class->qdisc) continue;
	if (got_qdisc) error("dsmark has only one inner qdisc");
	check_qdisc(class->qdisc);
	got_qdisc = 1;
    }
    check_filters(qdisc->filters);
}


static void dsmark_dump_tc(QDISC *qdisc)
{
    DEFAULT_DECL;
    CLASS *class;

    param_get(qdisc->params);
    DEFAULT_SET;
    tc_qdisc_add(qdisc);
    tc_more(" indices %d",(int) prm_indices.v);
    if (prm_default_index.present)
	tc_add_unum("default_index",prm_default_index.v);
    if (prm_set_tc_index.present) tc_more(" set_tc_index");
    tc_nl();
    for (class = qdisc->classes; class; class = class->next) {
	param_get(class->params);
	DEFAULT_GET;
	if (prm_mask.present || prm_value.present) {
	    tc_class_change(class);
	    if (prm_mask.present) tc_add_hex("mask",prm_mask.v);
	    if (prm_value.present) tc_add_hex("value",prm_value.v);
	    tc_nl();
	}
	dump_qdisc(class->qdisc);
    }
    dump_filters(qdisc->filters);
}


static const PARAM_DSC *dsmark_qdisc_req[] = {
    &prm_indices,
    NULL
};

static const PARAM_DSC *dsmark_qdisc_opt[] = {
    &prm_default_index,
    &prm_set_tc_index,
    DEFAULT_LIST	/* NB: no trailing comma */
    NULL
};

static const PARAM_DSC *dsmark_class_opt[] = {
    &prm_value,
    DEFAULT_LIST	/* NB: no trailing comma */
    NULL
};

static PARAM_DEF dsmark_qdisc = {
    .required = dsmark_qdisc_req,
    .optional = dsmark_qdisc_opt,
};

static PARAM_DEF dsmark_class = {
    .required = NULL,
    .optional = dsmark_class_opt,
};

QDISC_DSC dsmark_dsc = {
    .name = "dsmark",
    .qdisc_param = &dsmark_qdisc,
    .class_param = &dsmark_class,
    .check = &dsmark_check,
    .dump_tc = &dsmark_dump_tc,
};


#undef __DEFAULT_PRM


/* --------------------------------- FIFO ---------------------------------- */


static void fifo_check(QDISC *qdisc)
{
    /* never fails */
}


static void fifo_dump_tc(QDISC *qdisc)
{
    param_get(qdisc->params);
    if (prm_limit.present) {
	__tc_qdisc_add(qdisc,"bfifo");
	tc_add_size("limit",prm_limit.v);
    }
    else {
	__tc_qdisc_add(qdisc,"pfifo");
	if (prm_plimit.present) tc_add_psize("limit",prm_plimit.v);
    }
    tc_nl();
}


static const PARAM_DSC *fifo_qdisc_opt[] = {
    &prm_limit,		/* size */
    &prm_plimit,	/* psize */
    NULL
};

static PARAM_DEF fifo_qdisc = {
    .required = NULL,
    .optional = fifo_qdisc_opt,
};

QDISC_DSC fifo_dsc = {
    .name = "fifo",
    .qdisc_param = &fifo_qdisc,
    .class_param = NULL,
    .check = &fifo_check,
    .dump_tc = &fifo_dump_tc,
};


/* --------------------------------- GRED ---------------------------------- */


#define __DEFAULT_PRM(f) f(avpkt) f(burst) f(limit) f(max) f(min)
#define __DEFAULT_PRM_REQ(f) __DEFAULT_PRM(f)


static void gred_check(QDISC *qdisc)
{
    DEFAULT_DECL;
    CLASS *class;
    int grio,dp,got_default = 0;

    param_get(qdisc->params);
    DEFAULT_SET;
    grio = prm_grio.present;
    if (qdisc->filters) error("gred does not have filters");
    dp = 0;
    for (class = qdisc->classes; class; class = class->next) {
	check_childless(class);
	if (class->qdisc) error("gred has no inner qdiscs");
	if (class->number == UNDEF_U32) {
	    const CLASS *walk;

	    for (walk = qdisc->classes; walk; walk = walk->next)
		if (walk->number == dp)
		    error("can't auto-assign gred class IDs in this case");
	    class->number = dp;
	}
	else {
	    const CLASS *walk;

	    if (class->number >= TCQ_GRED_MAX_DPs)
		errorf("gred class number must be in the range 0..%d",
		  TCQ_GRED_MAX_DPs-1);
	    for (walk = qdisc->classes; walk; walk = walk->next)
		if (walk != class && walk->number == class->number)
		    errorf("duplicate class ID 0x%x",class->number);
	    dp = class->number;
	}
	dp++;
	param_get(class->params);
	DEFAULT_GET;
	DEFAULT_CHECK;
/* @@@ perform value checks listed for red */
	if (prm_default.present) {
	    if (!class->number) error("can't use DP 0 as default");
	    if (got_default) error("more than one class marked as \"default\"");
	    got_default = 1;
	}
	if (prm_grio.present && !prm_prio.present)
	    error("\"prio\" is required when using grio");
	if (!prm_grio.present && prm_prio.present)
	    error("\"prio\" is not allowed if not using grio");
    }
    for (class = qdisc->classes; class; class = class->next) {
	param_get(class->params);
	if (prm_prio.present && prm_prio.v > dp)
	    errorf("\"prio\" (%d) larger than number of DPs (%d)",
	      (int) prm_prio.v,dp);
    }
    if (!got_default)
	error("gred requires one class to be marked as \"default\"");
}


static void gred_dump_tc(QDISC *qdisc)
{
    DEFAULT_DECL;
    CLASS *class;
    uint32_t bandwidth;
    uint32_t default_dp = 0; /* initialize for gcc */

    param_get(qdisc->params);
    DEFAULT_SET;
    tc_qdisc_add(qdisc);
    tc_more(" setup");
    bandwidth = prm_bandwidth.v;
    if (prm_grio.present) tc_more(" grio");
    for (class = qdisc->classes; class; class = class->next) {
	param_get(class->params);
	if (prm_default.present) default_dp = class->number;
	if (!class->next) tc_add_unum("DPs",class->number+1);
    }
    tc_add_unum("default",default_dp);
    tc_nl();
    for (class = qdisc->classes; class; class = class->next) {
	param_get(class->params);
	DEFAULT_GET;
	tc_qdisc_change(qdisc);
	tc_add_unum("DP",class->number);
	if (prm_prio.present) tc_add_unum("prio",prm_prio.v);
	red_parameters(class->params,bandwidth);
	tc_nl();
    }
}


static const PARAM_DSC *gred_qdisc_req[] = {
    &prm_bandwidth,	/* rate */
    NULL
};

static const PARAM_DSC *gred_qdisc_opt[] = {
    &prm_grio,		/* flag */
    DEFAULT_LIST	/* NB: no trailing comma */
    NULL
};

static const PARAM_DSC *gred_class_opt[] = {
    &prm_default,	/* flag */
    &prm_probability,	/* default: 0.02 */
    &prm_prio,		/* unum */
    DEFAULT_LIST	/* NB: no trailing comma */
    NULL
};

static PARAM_DEF gred_qdisc = {
    .required = gred_qdisc_req,
    .optional = gred_qdisc_opt,
};

static PARAM_DEF gred_class = {
    .required = NULL,
    .optional = gred_class_opt,
};

QDISC_DSC gred_dsc = {
    .name = "gred",
    .qdisc_param = &gred_qdisc,
    .class_param = &gred_class,
    .check = &gred_check,
    .dump_tc = &gred_dump_tc,
};


#undef __DEFAULT_PRM
#undef __DEFAULT_PRM_REQ


/* --------------------------------- PRIO ---------------------------------- */


static void prio_check(QDISC *qdisc)
{
    static int default_priomap[16] = { 1,2,2,2,1,2,0,0,1,1,1,1,1,1,1,1 };
	/* from iproute2/tc/q_prio.c:prio_parse_opt */
    CLASS *class;

    curr_id = 1;
    (void) recurse_class(qdisc->classes,assign_class_id,qdisc->classes);
    param_get(qdisc->params);
    if (!prm_bands.present) prm_bands.v = TCQ_PRIO_DEFAULT_BANDS;
    if (prm_bands.v < 3 && !prm_priomap.present)
	/* see iproute2/tc/q_prio.c or
	   linux/net/sched/sch_generic.c:prio2band */
	error("must set priomap if < 3 bands, because default priomap uses "
	  "3rd band");
    if (prm_priomap.present) {
	DATA_LIST *walk;
	int n = 0;

	for (walk = prm_data(qdisc->params,&prm_priomap).u.list; walk;
	  walk = walk->next) {
	    if (++n > TC_PRIO_MAX) error("too many entries in priomap");
	    if (walk->ref->type != dt_class)
		errorf("invalid type in %d%s entry of \"priomap\"",n,
		  n == 1 ? "st" : n == 2 ? "nd" : "th");
	}
	while (n < TC_PRIO_MAX) {
	    if (default_priomap[n] >= prm_bands.v)
		error("\"priomap\" too short to cover default entries "
		  "exceeding allowed bands");
	    n++;
	}
    }
    for (class = qdisc->classes; class; class = class->next) {
	if (!class->number || class->number > prm_bands.v)
	    errorf("prio class number must be in the range 1..%d",
	      (int) prm_bands.v);
	check_childless(class);
	check_qdisc(class->qdisc);
    }
    check_filters(qdisc->filters);
}


static void prio_dump_tc(QDISC *qdisc)
{
    CLASS *class;

    param_get(qdisc->params);
    tc_qdisc_add(qdisc);
    if (prm_bands.present) tc_add_unum("bands",prm_bands.v);
    if (prm_priomap.present) {
	DATA_LIST *walk;

	tc_more(" priomap");
	for (walk = prm_data(qdisc->params,&prm_priomap).u.list; walk;
	  walk = walk->next)
	    tc_more(" %d",(int) walk->ref->u.class->number-1);
    }
    tc_nl();
    for (class = qdisc->classes; class; class = class->next)
	dump_qdisc(class->qdisc);
    dump_filters(qdisc->filters);
}


static const PARAM_DSC *prio_qdisc_opt[] = {
    &prm_bands,		/* unum */
    &prm_priomap,	/* list of classes */
    NULL
};

static PARAM_DEF prio_qdisc = {
    .required = NULL,
    .optional = prio_qdisc_opt,
};

static PARAM_DEF prio_class = {
    .required = NULL,
    .optional = NULL,
};

QDISC_DSC prio_dsc = {
    .name = "prio",
    .qdisc_param = &prio_qdisc,
    .class_param = &prio_class,
    .check = &prio_check,
    .dump_tc = &prio_dump_tc,
};


/* ---------------------------------- RED ---------------------------------- */


static void red_check(QDISC *qdisc)
{
/* @@@ warn if rounding ? avoid conversion ? */
/* @@@ missing checks:
 * max <= limit
 * min <= max
 * pretty much everything: > 0 or >= 0
 */
}


static void red_dump_tc(QDISC *qdisc)
{
    param_get(qdisc->params);
    tc_qdisc_add(qdisc);
    red_parameters(qdisc->params,prm_bandwidth.v);
    if (prm_ecn.present) tc_more(" ecn");
    tc_nl();
}


static const PARAM_DSC *red_qdisc_req[] = {
    &prm_limit,		/* size */
    &prm_min,		/* size */
    &prm_max,		/* size */
    &prm_burst,		/* size (tc uses number of packets) */
    &prm_avpkt,		/* size */
    &prm_bandwidth,	/* rate (tc defaults to 10 Mbps) */
    NULL
};

static const PARAM_DSC *red_qdisc_opt[] = {
    &prm_ecn,		/* default: off */
    &prm_probability,	/* default: 0.02 */
    NULL
};

static PARAM_DEF red_qdisc = {
    .required = red_qdisc_req,
    .optional = red_qdisc_opt,
};

QDISC_DSC red_dsc = {
    .name = "red",
    .qdisc_param = &red_qdisc,
    .class_param = NULL,
    .check = &red_check,
    .dump_tc = &red_dump_tc,
};


/* ---------------------------------- SFQ ---------------------------------- */


static void sfq_check(QDISC *qdisc)
{
    int guessed_mtu;

    param_get(qdisc->params);
    if (!prm_quantum.present) return;
    guessed_mtu = guess_mtu(qdisc->parent.device);
    if (guessed_mtu > prm_quantum.v)
	warnf("real MTU (guessed %d) may be larger than quantum %d",
	  guessed_mtu,(int) prm_quantum.v);
}


static void sfq_dump_tc(QDISC *qdisc)
{
    param_get(qdisc->params);
    tc_qdisc_add(qdisc);
    if (prm_perturb.present) tc_add_time("perturb",prm_perturb.v);
    if (prm_quantum.present) tc_add_size("quantum",prm_quantum.v);
    tc_nl();
}


static const PARAM_DSC *sfq_qdisc_opt[] = {
    &prm_perturb,	/* default: 0 */
    &prm_quantum,	/* default: MTU */
    NULL
};

static PARAM_DEF sfq_qdisc = {
    .required = NULL,
    .optional = sfq_qdisc_opt,
};

QDISC_DSC sfq_dsc = {
    .name = "sfq",
    .qdisc_param = &sfq_qdisc,
    .class_param = NULL,
    .check = &sfq_check,
    .dump_tc = &sfq_dump_tc,
};


/* ---------------------------------- TBF ---------------------------------- */


static void tbf_check(QDISC *qdisc)
{
    int guessed_mtu;

    param_get(qdisc->params);
    guessed_mtu = guess_mtu(qdisc->parent.device);
    if (guessed_mtu > prm_mtu.v)
	warnf("real MTU (guessed %d) may be larger than %d",guessed_mtu,
	  (int) prm_mtu.v);
    if (prm_burst.v < prm_mtu.v)
	errorf("burst (%d) must be larger than MTU (%d)",(int) prm_burst.v,
	  (int) prm_mtu.v);
/* @@@ check that burst and limit >= rate/HZ */
    if (prm_mpu.present && prm_mpu.v < prm_mtu.v)
	errorf("MPU (%d) smaller than MTU (%d)",(int) prm_mpu.v,
	  (int) prm_mtu.v);
    if (!prm_rate.v) error("rate must be non-zero");
    if (prm_peakrate.present && prm_rate.v > prm_peakrate.v)
	errorf("peakrate (%d) must be greater than rate (%d)",
	  (int) prm_peakrate.v,(int) prm_rate.v);
}


static void tbf_dump_tc(QDISC *qdisc)
{
    param_get(qdisc->params);
    tc_qdisc_add(qdisc);
    tc_add_size("burst",prm_burst.v);
    tc_add_size("limit",prm_limit.v);
    tc_add_size("mtu",prm_mtu.v);
    tc_add_rate("rate",prm_rate.v);
    if (prm_mpu.present) tc_add_size("mpu",prm_mpu.v);
    if (prm_peakrate.present) tc_add_rate("peakrate",prm_peakrate.v);
    tc_nl();
}


static const PARAM_DSC *tbf_qdisc_req[] = {
    &prm_rate,		/* rate */
    &prm_burst,		/* size */
    &prm_limit,		/* size; users can calculate latency in tcng */
    &prm_mtu,		/* size (tc sometimes defaults to 2047) */
    NULL
};

static const PARAM_DSC *tbf_qdisc_opt[] = {
    &prm_mpu,		/* size */
    &prm_peakrate,	/* rate */
    NULL
};

static PARAM_DEF tbf_qdisc = {
    .required = tbf_qdisc_req,
    .optional = tbf_qdisc_opt,
};

QDISC_DSC tbf_dsc = {
    .name = "tbf",
    .qdisc_param = &tbf_qdisc,
    .class_param = NULL,
    .check = &tbf_check,
    .dump_tc = &tbf_dump_tc,
};


/* ------------------------------------------------------------------------- */


void add_class(CLASS *class)
{
    CLASS **anchor;

    if (!class->parent.qdisc) yyerror("class without qdisc");
    for (anchor = class->parent.class ? &class->parent.class->child :
      &class->parent.qdisc->classes; *anchor; anchor = &(*anchor)->next);
    *anchor = class;
}


void check_qdisc(QDISC *qdisc)
{
    if (qdisc) qdisc->dsc->check(qdisc);
}


void dump_qdisc(QDISC *qdisc)
{
    if (qdisc) qdisc->dsc->dump_tc(qdisc);
}
