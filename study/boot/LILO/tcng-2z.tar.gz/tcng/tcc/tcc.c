/*
 * tcc.c - TC compiler
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>

#include "config.h"
#include "util.h"
#include "tree.h"
#include "device.h"
#include "target.h"
#include "if.h"


#define STRING(s) #s


extern int yyparse(void);


const char *default_device = DEFAULT_DEVICE;
int remove_qdiscs = 0;
int quiet = 0;
int debug = 0;


static pid_t pid;


static void kill_cpp(void)
{
    (void) kill(pid,SIGTERM);
}


static void run_cpp(int argc,char *const *argv)
{
    int fds[2];

    if (pipe(fds) < 0) {
	perror("pipe");
	exit(1);
    }
    pid = fork();
    if (pid < 0) {
	perror("fork");
	exit(1);
    }
    if (!pid) {
	if (dup2(fds[1],1) < 0) {
	    perror("dup2");
	    exit(1);
	}
	if (execvp(CPP,argv) < 0) {
	    perror("execvp");
	    exit(1);
	}
	/* not reached */
    }
    if (dup2(fds[0],0) < 0) {
	perror("dup2");
	exit(1);
    }
    if (close(fds[1]) < 0) {
	perror("close");
	exit(1);
    }
    atexit(kill_cpp);
}



static void usage(const char *name)
{
    fprintf(stderr,"usage: %s [-c] [-d ...] [-i default_interface] [-q] [-r]\n",
      name);
    fprintf(stderr,"%10s [-x elem:ext_target ...] [-t [no]target ...] "
      "[-Xphase,arg]\n","");
    fprintf(stderr,"%10s [cpp_option ...] [file]\n","");
    fprintf(stderr,"%6s %s -V\n\n","",name);
    fprintf(stderr,"  -c                    only check validity\n");
    fprintf(stderr,"  -d ...                increase debugging level\n");
    fprintf(stderr,"  -i default_interface  interface if not specified in "
      "description file\n");
    fprintf(stderr,"                        (default: "
      STRING(DEFAULT_DEVICE) ")\n");
    fprintf(stderr,"  -q                    quiet, produce terse output\n");
    fprintf(stderr,"  -r                    remove old qdiscs\n");
    fprintf(stderr,"  -t [elem:][no]target  enable or disable target\n");
    fprintf(stderr,"                        elements: if\n");
    fprintf(stderr,"                        targets: all, tc, c, ext; default: "
      "tc\n");
    fprintf(stderr,"  -V                    print version number and exit\n");
    fprintf(stderr,"  -x elem:ext_target    register external target\n");
    fprintf(stderr,"  -Xphase,arg           verbatim argument for specific "
      "build phase\n");
    fprintf(stderr,"                        phases: m=tcc-module, k=kmod_cc, "
      "t=tcmod_cc\n");
    fprintf(stderr,"  cpp_option            -Idir, -Dname[=value], or "
      "-Uname\n");
    exit(1);
}


int main(int argc,char *const *argv)
{
    char opt[3] = "-?";
    char **cpp_argv;
    int check_only = 0;
    int c,cpp_argc = 1;

    target_register("if","tc",1);
    target_register("if","c",0);
    target_register("if","ext",0);
    cpp_argv = alloc(sizeof(char *)*(argc*2+1));
    cpp_argv[cpp_argc++] = "-I" TOPDIR "/include";
    while ((c = getopt(argc,argv,"cdhi:qrt:x:D:U:I:VX:")) != EOF)
	switch (c) {
	    case 'c':
		check_only = 1;
		break;
	    case 'd':
		debug++;
		break;
	    case 'h':
		usage(argv[0]);
	    case 'i':
		default_device = optarg;
		break;
	    case 'q':
		quiet = 1;
		break;
	    case 'r':
		remove_qdiscs = 1;
		break;
	    case 't':
		switch_target(optarg);
		break;
	    case 'V':
		printf("tcc (tcng) version %s\n",VERSION);
		return 0;
	    case 'x':
		ext_target_register(optarg);
		break;
            case 'X':
		if (!optarg[0] || !strchr("mkt",optarg[0]) || optarg[1] != ',')
		    usage(argv[0]);
		add_tcc_module_arg(optarg[0] == 'm',optarg);
                break;
	    case 'D':
	    case 'U':
	    case 'I':
		opt[1] = c;
		cpp_argv[cpp_argc++] = stralloc(opt);
		cpp_argv[cpp_argc++] = optarg;
		break;
	    default:
		usage(argv[0]);
	}
    while (optind < argc) cpp_argv[cpp_argc++] = argv[optind++];
    cpp_argv[0] = argv[0];
    cpp_argv[cpp_argc] = NULL;
    run_cpp(cpp_argc,cpp_argv);
    (void) yyparse();
    check_devices();
    if (!check_only) dump_devices();
    return 0;
}
