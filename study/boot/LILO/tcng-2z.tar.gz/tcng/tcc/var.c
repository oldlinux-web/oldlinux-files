/*
 * var.c - Variable handling
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA
 */


#include <stdlib.h>
#include <string.h>

#include "util.h"
#include "error.h"
#include "var.h"


static VAR *variables = NULL;
static VAR **last = &variables;
static int level = 0;


static VAR *var_new(const char *name)
{
    VAR *var;

    var = alloc_t(VAR);
    var->name = stralloc(name);
    var->data_ref = NULL;
    var->level = -1;
    var->level = level;
    var->usage = vu_new;
    var->next = NULL;
    *last = var;
    last = &var->next;
    return var;
}


VAR *var_find(const char *name)
{
    VAR **walk;

    for (walk = &variables; *walk; walk = &(*walk)->next)
	if (!strcmp((*walk)->name,name)) break;
    if (!*walk) *walk = var_new(name);
    return *walk;
}


void var_begin_level(void)
{
    level++;
}


void var_end_level(void)
{
    for (last = &variables; *last; last= &(*last)->next)
	if ((*last)->level == level) break;
    while (*last) {
	VAR *this;

	this = *last;
	*last = this->next;
	if (this->usage == vu_unused) yywarnf("unused variable %s",this->name);
	if (this->usage == vu_forward)
	    yyerrorf("unresolved forward-declared variable %s",this->name);
	/*
	 * Don't destroy object - we need it for output
	 */
	free(this);
    }
    level--;
}


void var_set(VAR *var,DATA data)
{
    if (var->usage == vu_forward) {
	var->usage = vu_used;
	var->data = *var->data_ref = data;
	return;
    }
    if (var->usage != vu_new && var->level == level)
	yyerrorf("variable %s redefined",var->name);
    if (var->level != level) var = var_new(var->name);
    var->usage = vu_unused;
    var->data = data;
}


DATA *var_forward(VAR *var)
{
    if (var->usage != vu_new && var->usage != vu_forward && var->level == level)
	yyerrorf("variable %s redefined",var->name);
    if (var->level != level) var = var_new(var->name);
    if (!var->data_ref) var->data_ref = alloc_t(DATA);
    var->usage = vu_forward;
    return var->data_ref;
}


DATA var_get(VAR *var)
{
    if (var->usage == vu_new || var->usage == vu_forward)
	yyerrorf("variable %s is uninitialized",var->name);
    var->usage = vu_used;
    return var->data;
}
