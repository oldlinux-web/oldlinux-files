/*
 * iflib.h - Functions for processing if expressions
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#ifndef IFLIB_H
#define IFLIB_H

#include "data.h"
#include "tree.h"


DATA iflib_combine(const QDISC *qdisc);

/* Generate if expression from all filters on that qdisc */

void iflib_normalize(DATA *d);

/* Normalize && and || */

void iflib_reduce(DATA *d);

/* General optimizations */

void iflib_offset(DATA *d);

/* Add and reduce explicit offset operators */

int expr_equal(DATA a,DATA b);

#define dump_failed(d) __dump_failed(d,__FILE__,__LINE__)
void __dump_failed(DATA d,const char *file,int line);

#endif /* IFLIB_H */
