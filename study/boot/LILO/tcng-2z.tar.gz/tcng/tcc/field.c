/*
 * field.c - Packet field definition
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001, EPFL-ICA, Network Robots
 */


#include <string.h>

#include "util.h"
#include "error.h"
#include "data.h"
#include "op.h"
#include "field.h"


static FIELD *fields = NULL;


FIELD *field_find(const char *name)
{
    FIELD *field;

    for (field = fields; field; field = field->next)
	if (!strcmp(field->name,name)) break;
    return field;
}


void field_set(const char *name,DATA access,DATA condition)
{
    FIELD *field;

    if (field_find(name)) yyerrorf("field \"%s\" already exists",name);
	/* the parser actually already disallows this */
    field = alloc_t(FIELD);
    field->name = stralloc(name);
    field->condition = condition;
    field->access = access;
    field->next = fields;
    fields = field;
}


static void do_field_expand(DATA *d,DATA *root)
{
    if (d->type == dt_none) return;
    while (d->op && d->op->dsc == &op_access && d->op->a.type == dt_field) {
	FIELD *field = d->op->a.u.field;
	DATA access = data_clone(field->access);

	/*
	 * disallow things like
	 *   field foo = bar+5
	 *   field baz = foo[0]
	 */
	if ((d->op->b.type != dt_none || d->op->c.u.unum) &&
	  field->access.type != dt_none &&
	  (!field->access.op || field->access.op->dsc != &op_access))
	    yyerrorf("access not allowed for field \"%s\"",field->name);
	if (field->condition.type != dt_none) {
	    DATA condition;

	    condition = data_clone(field->condition);
	    do_field_expand(&condition,&condition);
	    *root = op_binary(&op_logical_and,condition,*root);
	    /* resolve pointer alias */
	    if (root == d) d = &root->op->b;
	}
	/*
	 * We reduce
	 *   access(field,O1,S1) with
	 *   field = X
	 * to
	 *   X
	 * If X is access(D,O2,S2)
	 *   access(access(D,O2,S2),O1,S1)
	 * we reduce it to
	 *   access(D,O1+O2,S1 ? S1 : S2)
	 */
	if (access.op && access.op->dsc == &op_access) {
	    if (access.op->b.type == dt_none)
		access.op->b = data_clone(d->op->b);
	    else if (d->op->b.type != dt_none)
		access.op->b = op_binary(&op_plus,d->op->b,access.op->b);
	    if (!access.op->c.u.unum) access.op->c.u.unum = d->op->c.u.unum;
	    if (!access.op->c.u.unum) access.op->c.u.unum = 8;
	}
	data_destroy_1(*d);
	*d = access;
    }
    if (!d->op) return;
    if (d->op->dsc == &op_logical_or) {
	do_field_expand(&d->op->a,&d->op->a);
	do_field_expand(&d->op->b,&d->op->b);
    }
    else {
	do_field_expand(&d->op->a,root);
	do_field_expand(&d->op->b,root);
	do_field_expand(&d->op->c,root);
    }
}


DATA field_expand(DATA d)
{
    do_field_expand(&d,&d);
    return d;
}
