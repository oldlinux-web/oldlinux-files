/*
 * if.h - Processing of the "if" command
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#ifndef IF_H
#define IF_H

#include "tree.h"

void dump_if_u32(const FILTER *filter);
void dump_if_c(const FILTER *filter);
void dump_if_ext(const FILTER *filter,const char *target);
void add_tcc_module_arg(int local,const char *arg); /* @@@ move elsewhere ? */

#endif /* IF_H */
