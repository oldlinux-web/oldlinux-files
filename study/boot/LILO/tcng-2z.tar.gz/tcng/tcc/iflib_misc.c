/*
 * iflib_misc.c - Miscellaneous functions
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#include <stdlib.h>
#include <stdio.h>

#include "config.h"
#include "op.h"
#include "iflib.h"


#define dump_failed(d) __dump_failed(d,__FILE__,__LINE__)


void __dump_failed(DATA d,const char *file,int line)
{
    putchar('\n'); /* we're probably in the middle of a line */
    fflush(stdout);
    fprintf(stderr,"don't know how to dump subexpression (%s:%d)\n\n",file,
      line);
    if (!quiet) print_expr(stderr,d);
    exit(1);
}
