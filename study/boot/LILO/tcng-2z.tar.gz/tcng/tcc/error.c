/*
 * error.c - Error reporting functions
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#include <stdarg.h>
#include <stdio.h>
#include <execinfo.h>

#include "config.h"
#include "error.h"


static int stack_zero; /* minimum stack depth */


static int backtrace_len(void)
{
    void *dummy[MAX_STACK_DEPTH];

    return backtrace(dummy,MAX_STACK_DEPTH);
}


void debugf(const char *msg,...)
{
    va_list ap;
    int depth,i;

    if (!debug) return;
    depth = backtrace_len(); /* auto-calibrate */
    if (!stack_zero || depth < stack_zero) stack_zero = depth;
    for (i = depth-stack_zero; i; i--) putchar(' ');
    va_start(ap,msg);
    vprintf(msg,ap);
    va_end(ap);
    putchar('\n');
}
