/*
 * tree.h - All qdisc/class/filter data structures
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA
 */


#ifndef TREE_H
#define TREE_H

#include <stdint.h>

#include "param.h"


struct _device;
struct _qdisc;
struct _class;
struct _filter;
struct _tunnel;


typedef struct {
    struct _device *device;
    struct _qdisc *qdisc;
    struct _class *class;
    struct _filter *filter;
    struct _tunnel *tunnel;
} PARENT;

typedef enum {
    pd_ok = 1,
    pd_drop = 2,
    pd_continue = 4,
    pd_reclassify = 8,
} DECISION;

typedef struct _police {
    uint32_t number;
    PARAM *params;
    DECISION in_profile;
    DECISION out_profile;
    int created; /* if non-zero, we can just reference it */
    struct _police *next;
} POLICE;

typedef struct _element {
    PARENT parent;
    uint32_t number;
    PARAM *params;
    POLICE *police;
    struct _element *next;
} ELEMENT;

typedef struct {
    const char *name;
    PARAM_DEF *filter_param;
    PARAM_DEF *element_param;
    void (*check)(struct _filter *filter);
    void (*dump_tc)(struct _filter *filter);
} FILTER_DSC;

typedef struct _filter {
    PARENT parent;
    uint32_t number;
    const FILTER_DSC *dsc;
    PARAM *params;
    ELEMENT *elements;
    struct _filter *next;
} FILTER;

typedef struct _tunnel {
    PARENT parent;
    uint32_t number;
    PARAM *params;
} TUNNEL;

typedef struct _class {
    PARENT parent;
    uint32_t number;
    PARAM *params;
    struct _qdisc *qdisc;
    FILTER *filters;
    struct _class *child;
    struct _class *next;
} CLASS;

typedef struct {
    const char *name;
    PARAM_DEF *qdisc_param;
    PARAM_DEF *class_param; /* NULL if classless */
    void (*check)(struct _qdisc *qdisc); /* assign IDs and check parameters */
    void (*dump_tc)(struct _qdisc *qdisc);
} QDISC_DSC;

typedef struct _qdisc {
    PARENT parent;
    QDISC_DSC *dsc;
    uint32_t number;
    PARAM *params;
    CLASS *classes;
    FILTER *filters;
    DATA if_expr; /* dt_none if we don't have if */
} QDISC;

typedef struct _device {
    const char *name;
    QDISC *qdisc;
    QDISC *ingress;
    struct _device *next;
} DEVICE;

#endif /* TREE_H */
