/*
 * police.c - Policing handling
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>

#include "util.h"
#include "error.h"
#include "param.h"
#include "tree.h"
#include "tc.h"
#include "police.h"


static POLICE *policers = NULL;
static POLICE **last = &policers;
static int ids_assigned = 0;


/* ----------------------- Assignment of unique IDs ------------------------ */


static void assign_policer_ids(POLICE *list)
{
    POLICE *walk;
    uint32_t ind = 1;

    for (walk = list; walk; walk = walk->next) {
	const POLICE *check;

	if (walk->number != UNDEF_U32) continue;
	do {
	    for (check = list; check; check = check->next)
		if (check->number == ind) break;
	    walk->number = ind++;
	}
	while (check);
    }
}


/* ------------------------------- Policing -------------------------------- */


static const PARAM_DSC *police_rate_req[] = {
    &prm_burst,
    &prm_mtu,
    NULL
};

static const PARAM_DSC *police_norate_opt[] = {
    &prm_avrate,
    NULL
};

static const PARAM_DSC *police_opt[] = {
    &prm_avrate,	/* rate */
    &prm_burst,		/* size */
    &prm_mpu,		/* size */
    &prm_mtu,		/* size */
    &prm_overflow,	/* police */
    &prm_peakrate,	/* rate */
    &prm_rate,		/* rate */
    NULL
};


static const char *police_action(DECISION act)
{
    switch (act) {
	case pd_ok:
	    return "pass";
	case pd_drop:
	    return "drop";
	case pd_continue:
	    return "continue";
	case pd_reclassify:
	    return "reclassify";
	default:
	    abort();
    }
}


void check_police(POLICE *police)
{
    if (!ids_assigned) {
	assign_policer_ids(policers);
	ids_assigned = 1;
    }
    param_get(police->params);
    if (!prm_rate.present) check_params(police->params,NULL,police_norate_opt);
    else check_params(police->params,police_rate_req,police_opt);
}


static void dump_police_tc(POLICE *police)
{
    param_get(police->params);
    tc_more(" police");
    tc_more(" index %lu",(unsigned long) police->number);
    if (police->created) return;
    police->created = 1;
    if (prm_avrate.present) tc_add_rate("avrate",prm_avrate.v);
    if (prm_rate.present) {
	tc_add_rate("rate",prm_rate.v);
	tc_add_size("burst",prm_burst.v);
	tc_add_size("mtu",prm_mtu.v);
	if (prm_peakrate.present) tc_add_rate("peakrate",prm_peakrate.v);
	if (prm_mpu.present) tc_add_rate("mpu",prm_mpu.v);
    }
    tc_more(" action %s/%s",police_action(police->out_profile),
      police_action(police->in_profile));
}


void dump_police(POLICE *police)
{
    dump_police_tc(police);
}


PARAM_DEF police_def = {
    .required = NULL,
    .optional = police_opt,
};


/* ------------------------------------------------------------------------- */


void add_police(POLICE *police)
{
    if (!police->number) error("policer index must not be zero");
    if (police->number != UNDEF_U32) {
	const POLICE *check;

	for (check = policers; check; check = check->next)
	    if (check->number == police->number)
		errorf("duplicate policer index %d",(int) police->number);
    }
    police->created = 0;
    *last = police;
    last = &police->next;
}
