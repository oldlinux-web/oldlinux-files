/*
 * iflib_red.c - Normalize and reduce (optimize) an if expression
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#include <stdlib.h>

#include "util.h"
#include "error.h"
#include "data.h"
#include "tree.h"
#include "op.h"
#include "iflib.h"


/*
 * @@@ does not handle nested ifs properly
 */


#define BUNDLE_THRESHOLD 2 /* bundle if at least that many common entries */
			   /* MUST be > 1 */


/* --------------------- Normalize boolean expression ---------------------- */


static void bubble_or(DATA *d)
{
    DATA new;

    while (1) {
	if (d->type == dt_none) return;
	if (d->op) {
	    bubble_or(&d->op->a);
	    bubble_or(&d->op->b);
	    bubble_or(&d->op->c);
	}
	if (!d->op || d->op->dsc != &op_logical_and) return;

	/* (a || b) && c -> (a && c) || (b && c) */
	if (d->op->a.op && d->op->a.op->dsc == &op_logical_or) {
	    new = op_binary(&op_logical_or,
	      op_binary(&op_logical_and,data_clone(d->op->a.op->a),
		data_clone(d->op->b)),
	      op_binary(&op_logical_and,data_clone(d->op->a.op->b),
		data_clone(d->op->b)));
	    data_destroy(*d);
	    *d = new;
	    continue;
	}

	/* a && (b || c) -> (a && b) || (a && c) */
	if (d->op->b.op && d->op->b.op->dsc == &op_logical_or) {
	    new = op_binary(&op_logical_or,
	      op_binary(&op_logical_and,data_clone(d->op->a),
		data_clone(d->op->b.op->a)),
	      op_binary(&op_logical_and,data_clone(d->op->a),
		data_clone(d->op->b.op->b)));
	    data_destroy(*d);
	    *d = new;
	    continue;
	}
	break;
    }
}


static void linearize(DATA *d)
{
    if (d->type == dt_none) return;

    /* (a || b) || c -> a || (b || c)   (idem for &&) */
    while (d->op &&
      (d->op->dsc == &op_logical_or || d->op->dsc == &op_logical_and) &&
      d->op->a.op && d->op->a.op->dsc == d->op->dsc) {
	DATA tmp;

	tmp = d->op->a;
	d->op->a = tmp.op->b;
	tmp.op->b = *d;
	*d = tmp;
    }
    if (d->op) {
	linearize(&d->op->a);
	linearize(&d->op->b);
	linearize(&d->op->c);
    }
}


void iflib_normalize(DATA *d)
{
    bubble_or(d);
    debug_expr("AFTER bubble_or",*d);
    linearize(d);
    debug_expr("AFTER linearize",*d);
}


/* --------------- Eliminate redundant common subexpressions --------------- */


int expr_equal(DATA a,DATA b)
{
    if (a.op) {
	if (!b.op) return 0;
	if (a.op->dsc != b.op->dsc) return 0;
	return expr_equal(a.op->a,b.op->a) && expr_equal(a.op->b,b.op->b) &&
	  expr_equal(a.op->c,b.op->c);
    }
    if (b.op) return 0;
    return data_equal(a,b);
}


static void common_subexpressions(DATA *d)
{
    while (d->op && (d->op->dsc == &op_or || d->op->dsc == &op_and ||
      d->op->dsc == &op_logical_or || d->op->dsc == &op_logical_and)) {
	DATA *walk;
	int again = 0;

	for (walk = &d->op->b; walk->op && walk->op->dsc == d->op->dsc;
	  walk = &walk->op->b) {
	    DATA next;

	    /* a && ... && a && ... -> a && ... && ... */
	    if (expr_equal(d->op->a,walk->op->a)) {
		next = walk->op->b;
		data_destroy_1(*walk);
		data_destroy(walk->op->a);
		*walk = next;
		again = 1;
		break;
	    }

	    /* a && ... && a -> a && ... */
	    if (expr_equal(d->op->a,walk->op->b)) {
		next = walk->op->a;
		data_destroy_1(*walk);
		data_destroy(walk->op->b);
		*walk = next;
		break;
	    }
	}
	if (!again) break;
    }
    if (d->op) {
	common_subexpressions(&d->op->a);
	common_subexpressions(&d->op->b);
	common_subexpressions(&d->op->c);
    }
}


/* ------------------ Bundle common && prefix in || chain ------------------ */

/*
 * (a && b) || (a && c) || d -> (a && (b || c) || d
 *
 * Note: (a && x) expressions must be consecutive, e.g. we can't bundle
 * (a && b) || c || (a && d)  to  (a && (b || d) || c, because shortcut
 * evaluation would be different if a = c = d = 1, b = 0
 *
 * Also, "a" must be a sequence of &&s right at the beginning of
 * the expression, e.g. we can't bundle (a && b && c) || (b && a && c)
 *
 * Note: none of this is really binding. In fact, we could relax the
 * reordering constraints quite a bit it we take into account that they
 * are caused by a) accepting states (i.e. class_if), and b) field
 * accessibility. E.g. in the example above, we know that "a" and "b"
 * can each be evaluated without precondition, so they're in fact
 * commutative.
 */

/*
 * First, convert the ||-then-&& structure into a matrix, for easier handling
 */

struct or_row {
    DATA *and;
    int ands;
    DATA **cells;
};

struct matrix {
    int ors;
    struct or_row *rows;
};

static void bundle_make_matrix(DATA *d,struct matrix *m)
{
    DATA *or;
    int i;

    m->ors = 0;
    for (or = d; 1; or = &or->op->b) {
	m->ors++;
	if (!or->op || or->op->dsc != &op_logical_or) break;
    }
    m->rows = alloc(sizeof(struct or_row)*m->ors);
    or = d;
    for (i = 0; i < m->ors-1; i++) {
	m->rows[i].and = &or->op->a;
	or = &or->op->b;
    }
    m->rows[i].and = or;
    for (i = 0; i < m->ors; i++) {
	struct or_row *r = m->rows+i;
	DATA *and;
	int j;

	r->ands = 0;
	for (and = r->and; 1; and = &and->op->b) {
	    r->ands++;
	    if (!and->op || and->op->dsc != &op_logical_and) break;
	}
	r->cells = alloc(sizeof(DATA *)*r->ands);
	and = r->and;
	for (j = 0; j < r->ands-1; j++) {
	    r->cells[j] = &and->op->a;
	    and = &and->op->b;
	}
	r->cells[j] = and;
    }
}


static void bundle_free_matrix(struct matrix *m)
{
    int i;

    for (i = 0; i < m->ors; i++)
	free(m->rows[i].cells);
    free(m->rows);
}


/*
 * Find best optimization. Actually, this isn't optimal yet. We should also
 * take into account how we could bundle adjacent areas. But this is probably
 * overkill.
 */


static void bundle_find_best(struct matrix *m,int *best_or,int *best_ors,
  int *best_ands)
{
    int first_or;

    *best_ors = *best_ands = 0;
    for (first_or = 0; first_or < m->ors; first_or++) {
	int ors;

	for (ors = 2; first_or+ors <= m->ors; ors++) {
	    int min_ands = -1;
	    int i,j,ands;

	    for (i = first_or; i < first_or+ors; i++)
		if (m->rows[i].ands < min_ands || min_ands == -1)
		    min_ands = m->rows[i].ands;
	    if (ors*min_ands < *best_ors**best_ands) continue;
	    for (ands = 1; ands <= min_ands; ands++) {
		for (i = first_or+1; i < first_or+ors; i++)
		    for (j = 0; j < ands; j++)
			if (!expr_equal(*m->rows[first_or].cells[j],
			  *m->rows[i].cells[j]))
			    goto out;
		if (ors*ands > *best_ors**best_ands) {
		    *best_or = first_or;
		    *best_ors = ors;
		    *best_ands = ands;
		}
	    }
out:
	}
    }
}


/*
 * Build a new tree
 *
 *          |-| ands=2
 * 	    a b c
 * first -> d e f-- ors=2
 *          d e g--
 *          h
 *          i j k
 *
 * becomes
 * (a && b && c) || (d && e && (f || g)) || h || (i && j && k)
 *
 * Note: we data_clone a lot here. This keeps the whole design reasonably
 * simple, but it's bad for performance.
 */


static DATA bundle_ands(struct or_row *r,int from,int ands,DATA add)
{
    DATA tmp = add;
    int j,last = ands == -1 ? r->ands-1 : from+ands-1;

    if (add.type == dt_none) {
	if (!ands) return data_none();
	tmp = data_clone(*r->cells[last]);
    }
    else last++;
    for (j = last-1; j >= from; j--)
	tmp = op_binary(&op_logical_and,data_clone(*r->cells[j]),tmp);
    return tmp;
}


static DATA bundle_ors(struct matrix *m,int from,int ors,int from_ands,
  int ands,DATA add)
{
    DATA tmp = add;
    int i,last = ors == -1 ? m->ors-1 : from+ors-1;

    if (add.type == dt_none) {
	if (!ors) return data_none();
	tmp = bundle_ands(m->rows+last,from_ands,ands,data_none());
    }
    else last++;
    for (i = last-1; i >= from; i--)
	tmp = op_binary(&op_logical_or,bundle_ands(m->rows+i,from_ands,ands,
	  data_none()),tmp);
    return tmp;
}


static DATA bundle_rebuild(struct matrix *m,int from,int ors,int ands)
{
    DATA d,new;

    new = bundle_ors(m,from,ors,ands,-1,data_none());
    new = bundle_ands(m->rows+from,0,ands,new);
    d = from+ors == m->ors ? new :
      op_binary(&op_logical_or,new,bundle_ors(m,from+ors,-1,0,-1,data_none()));
    if (from) d = bundle_ors(m,0,from,0,-1,d);
    return d;
}


/*
 * Skip all ors
 */


static void bundle(DATA *d);


static void bundle_skip(DATA *d,int skip_current)
{
    if (!d->op) return;
    if (d->op->dsc == &op_logical_or || skip_current) {
	bundle_skip(&d->op->a,0);
	bundle_skip(&d->op->b,0);
	bundle_skip(&d->op->c,0);
    }
    else {
	bundle(&d->op->a);
	bundle(&d->op->b);
	bundle(&d->op->c);
    }
}


static void bundle(DATA *d)
{
    int skip_current = 1;

    if (!d->op) return;
    if (d->op->dsc == &op_logical_or) {
	struct matrix m;
	int from,ors,ands;

	bundle_make_matrix(d,&m);
	bundle_find_best(&m,&from,&ors,&ands);
	if (ors*ands >= BUNDLE_THRESHOLD) {
	    DATA old = *d;

	    *d = bundle_rebuild(&m,from,ors,ands);
	    data_destroy(old);
	    skip_current = 0;
	}
	bundle_free_matrix(&m);
    }
    bundle_skip(d,skip_current);
}


/* ---------------------- Optimize tests for quality ----------------------- */


/*
 * Turn comparison between a constant value and an access into a regular
 * structure of the type  (x & y) == z.
 *
 * The access can be combined with any number of <<, >>, and & operations.
 */

static void do_optimize_eq(DATA *expr,DATA *val)
{
    DATA acc = *expr;
    DATA old;
    uint32_t value,mask = 0xffffffff,mask_mask;
    int shift = 0,default_mask = 1;
    int bits;

    if (acc.op && acc.op->dsc == &op_access) return; /* already perfect */
    while (acc.op && acc.op->dsc != &op_access) {
	uint32_t b = acc.op->b.u.unum; /* may be undefined ! */

	if (acc.op->dsc == &op_shift_left) {
	    if (acc.op->b.op || acc.op->b.type != dt_unum) return;
	    if (b > 31) errorf("shifting by %d bits",b);
	    mask >>= b;
	    shift += b;
	    acc = acc.op->a;
	}
	else if (acc.op->dsc == &op_shift_right) {
	    if (acc.op->b.op || acc.op->b.type != dt_unum) return;
	    if (b > 31) errorf("shifting by %d bits",b);
	    mask <<= b;
	    shift -= b;
	    acc = acc.op->a;
	}
	else if (acc.op->dsc == &op_and) {
	    uint32_t this_mask;

	    if (!acc.op->a.op && acc.op->a.type == dt_unum) {
		this_mask = acc.op->a.u.unum;
		acc = acc.op->b;
	    }
	    else {
		if (acc.op->b.op || acc.op->b.type != dt_unum) return;
		this_mask = acc.op->b.u.unum;
		acc = acc.op->a;
	    }
	    if (this_mask & ~mask) 
		warnf("mask 0x%lx will be masked with 0x%lx",
		  (unsigned long) this_mask,(unsigned long) mask);
	    mask &= this_mask;
	    default_mask = 0;
	}
	else return; /* expect trouble */
    }
    if (!acc.op) return;
    if (shift > 32  || shift < -32)
	errorf("shifting by %d bits",shift < 0 ? -shift : shift);
    bits = acc.op->c.u.unum;
    value = val->u.unum;
    mask_mask = 0xffffffff >> (32-bits);
    if (shift < 0) {
	if (value >> (32+shift)) return;
	value <<= -shift;
	mask_mask >>= -shift;
    }
    if (shift > 0) {
	if (value & (0xffffffff >> (32-shift))) return;
	value >>= shift;
	mask_mask <<= shift;
    }
    if (default_mask) mask &= mask_mask;
    if (shift < 0 && bits < 32 && (mask >> bits))
	errorf("%s:%d: this can't happen",__FILE__,__LINE__);
    val->u.unum = value;
    old = *expr;
    *expr = op_binary(&op_and,acc,data_unum(mask));
    data_destroy(old);
}


static void optimize_eq(DATA d)
{
    if (!d.op) return;
    if (d.op->dsc == &op_eq) {
	if (!d.op->a.op && d.op->a.type == dt_unum)
	    do_optimize_eq(&d.op->b,&d.op->a);
	else if (!d.op->b.op && d.op->b.type == dt_unum)
	    do_optimize_eq(&d.op->a,&d.op->b);
	else return; /* will probably fail later */
    }
    else {
	optimize_eq(d.op->a);
	optimize_eq(d.op->b);
	optimize_eq(d.op->c);
    } 
}


/* ---------- Remove dead branches caused by shortcut evaluation ----------- */


static int no_class(DATA d)
{
    if (!d.op) return d.type != dt_class_if;
    return no_class(d.op->a) && no_class(d.op->b) && no_class(d.op->c);
}


static void prune_shortcuts(DATA *d)
{
    DATA old = *d;

    if (!d->op) return;
    prune_shortcuts(&d->op->a);
    prune_shortcuts(&d->op->b);
    prune_shortcuts(&d->op->c);

    /* <class X> || ... -> <class X>  and <class X> && ... -> <class X> */
    if ((d->op->dsc == &op_logical_or || d->op->dsc == &op_logical_and) &&
      d->op->a.type == dt_class_if) {
	*d = d->op->a;
	data_destroy(old.op->b);
	data_destroy_1(old);
	return;
    }

    if (d->op->dsc == &op_logical_and) {
	if (!d->op->a.op && d->op->a.type == dt_unum) {
	    /* 0 && X -> 0 */
	    if (!d->op->a.u.unum) {
		*d = data_unum(0);
		data_destroy(old);
		return;
	    }
	    /* 1 && X -> X */
	    if (d->op->a.u.unum) {
		*d = old.op->b;
		data_destroy_1(old);
		return;
	    }
	}
	if (!d->op->b.op && d->op->b.type == dt_unum) {
	    /* X && 0 -> 0, unless X contains class */
	    if (!d->op->b.u.unum && no_class(d->op->a)) {
		*d = data_unum(0);
		data_destroy(old);
		return;
	    }
	    /* X && 1 -> X */
	    if (d->op->b.u.unum) {
		*d = old.op->a;
		data_destroy_1(old);
		return;
	    }
	}
    }

    if (d->op->dsc == &op_logical_or) {
	if (!d->op->a.op && d->op->a.type == dt_unum) {
	    /* 1 || X -> 1 */
	    if (!d->op->a.u.unum) {
		*d = data_unum(1);
		data_destroy(old);
		return;
	    }
	    /* 0 || X -> X */
	    if (!d->op->a.u.unum) {
		*d = old.op->b;
		data_destroy_1(old);
		return;
	    }
	}
	if (!d->op->b.op && d->op->b.type == dt_unum) {
	    /* X || 1 -> 1, unless X contains class */
	    if (d->op->b.u.unum && no_class(d->op->a)) {
		*d = data_unum(1);
		data_destroy(old);
		return;
	    }
	    /* X || 0 -> X */
	    if (!d->op->b.u.unum) {
		*d = old.op->a;
		data_destroy_1(old);
		return;
	    }
	}
    }
}


/* --------------------- Optimize the "if" expression ---------------------- */


void iflib_reduce(DATA *d)
{
    debug_expr("BEFORE iflib_reduce",*d);
    iflib_normalize(d);
    common_subexpressions(d);
    debug_expr("AFTER common_subexpressions",*d);
    bundle(d);
    debug_expr("AFTER bundle",*d);
    optimize_eq(*d);
    debug_expr("AFTER optimize_eq",*d);
    prune_shortcuts(d);
    debug_expr("AFTER prune_shortcuts",*d);
}
