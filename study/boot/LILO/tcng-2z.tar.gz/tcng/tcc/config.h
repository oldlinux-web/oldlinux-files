/*
 * config.h - Configuration definitions and variables
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#ifndef CONFIG_H
#define CONFIG_H

#define DEFAULT_DEVICE	"eth0"
#define CPP		"/lib/cpp"
#define MAX_COMMENT	1024	/* maximum comment line(s) in tc output */
#define TCC_MODULE_CMD	TOPDIR "/bin/tcc-module"
#define MAX_STACK_DEPTH	100	/* stack depth for debugf; okay to guess */

extern const char *default_device;
extern int remove_qdiscs; /* issue tc commands to remove old qdiscs */
extern int quiet; /* produce terse output */
extern int debug; /* debugging message level (0 = none) */

#endif /* CONFIG_H */
