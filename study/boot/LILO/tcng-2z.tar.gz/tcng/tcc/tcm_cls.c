/*
 * tcm_cls.c - Common code for tcc-generated classifiers, kernel part
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 Werner Almesberger
 */


#include <linux/config.h>
#include <linux/module.h>
#include <linux/types.h>
#include <linux/kernel.h> /* for debugging */
#include <linux/netdevice.h> /* net/pkt_cls.h needs things from here */
#include <linux/skbuff.h>
#include <linux/errno.h>
#include <linux/pkt_sched.h> /* linux/pkt_cls.h needs tc_ratespec */
#include <linux/pkt_cls.h>
#include <net/pkt_cls.h>
#include <net/pkt_sched.h>


#define _C(a,b) a##b
#define C(a,b) _C(a,b)

#define _C3(a,b,c) a##b##c
#define C3(a,b,c) _C3(a,b,c)

#define _S(x) #x
#define S(x) _S(x)


#define _ACCESS8(off)	(*(u8 *) (skb->nh.raw+(off)))
#define _ACCESS16(off)	ntohs(*(u16 *) (skb->nh.raw+(off)))
#define _ACCESS32(off)	ntohl(*(u32 *) (skb->nh.raw+(off)))

#define _DEBUG_ACCESS(b,off) \
  ({ printk(KERN_DEBUG "u%d @ %d -> 0x%lx\n",b,(off), \
     (unsigned long) _ACCESS##b(off)); _ACCESS##b(off); })

#ifndef DEBUG
#define ACCESS8(off)	_ACCESS8(off)
#define ACCESS16(off)	_ACCESS16(off)
#define ACCESS32(off)	_ACCESS32(off)
#else
#define ACCESS8(off)	_DEBUG_ACCESS(8,off)
#define ACCESS16(off)	_DEBUG_ACCESS(16,off)
#define ACCESS32(off)	_DEBUG_ACCESS(32,off)
#endif

#include MDI_FILE


static struct tcf_result results[ELEMENTS];


static int C(NAME,_classify)(struct sk_buff *skb,struct tcf_proto *tp,
  struct tcf_result *res)
{
	#define RESULT(n) *res = results[n]; return 0;
	(void) EXPRESSION;
	return TC_POLICE_UNSPEC;
}


static void cleanup(struct Qdisc *q)
{
	int i;

	for (i = 0; results[i].class && i < ELEMENTS; i++)
		q->ops->cl_ops->unbind_tcf(q,results[i].class);
}


static int C(NAME,_init)(struct tcf_proto *tp)
{
	#define __INIT(n,c) \
	  results[n].classid = c; \
          results[n].class = tp->q->ops->cl_ops->bind_tcf(tp->q, \
	    0 /* qdisc */,c); \
	  if (!results[n].class) goto error;
	  ELEMENT(__INIT);
	  MOD_INC_USE_COUNT;
	  return 0;

error:
	cleanup(tp->q);
	return -EINVAL;
}


static void C(NAME,_destroy)(struct tcf_proto *tp)
{
	cleanup(tp->q);
	MOD_DEC_USE_COUNT;
}


static unsigned long C(NAME,_get)(struct tcf_proto *tp,u32 handle)
{
	return 0;
}


static int C(NAME,_change)(struct tcf_proto *tp,unsigned long base,u32 handle,
  struct rtattr **tca,unsigned long *arg)
{
	struct rtattr *opt = tca[TCA_OPTIONS-1];

	return opt ? -EINVAL : 0;
}


static int C(NAME,_delete)(struct tcf_proto *tp,unsigned long arg)
{
	return -EINVAL;
}


struct tcf_proto_ops C3(cls_,NAME,_ops) = {
	NULL,
	S(NAME),
	C(NAME,_classify),
	C(NAME,_init),
	C(NAME,_destroy),

	C(NAME,_get),
	NULL,		/* no put */
	C(NAME,_change),
	C(NAME,_delete),
	NULL,		/* no walk */
	NULL		/* no dump */
};


#ifdef MODULE

int init_module(void)
{
	return register_tcf_proto_ops(&C3(cls_,NAME,_ops));
}


void cleanup_module(void)
{
	unregister_tcf_proto_ops(&C3(cls_,NAME,_ops));
}

#endif
