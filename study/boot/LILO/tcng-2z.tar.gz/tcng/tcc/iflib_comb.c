/*
 * iflib_comb.c - Generation of if expressions
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#include <stdlib.h>

#include "data.h"
#include "tree.h"
#include "param.h"
#include "op.h"
#include "filter.h"
#include "iflib.h"


/*
 * @@@ does not handle nested ifs properly
 */


/* ----------------- Generate the complete "if" expression ----------------- */


static void if_add_filters(const FILTER *filters,DATA *root)
{
    const FILTER *filter;

    for (filter = filters; filter; filter = filter->next)
	if (filter->dsc == &if_dsc) {
	    const ELEMENT *element;

	    for (element = filter->elements; element; element = element->next) {
		DATA expr = data_clone(prm_data(element->params,&prm_if_expr));

		expr = op_binary(&op_logical_and,expr,
		  data_class_if(element->parent.class));
		if (root->type == dt_none) *root = expr;
		else *root = op_binary(&op_logical_or,*root,expr);
	    }
	}
}


static void if_add_classes(const CLASS *classes,DATA *root)
{
    const CLASS *class;

    for (class = classes; class; class = class->next) {
	if_add_filters(class->filters,root);
	if (class->child) if_add_classes(class->child,root);
    }
}


DATA iflib_combine(const QDISC *qdisc)
{
    DATA d = data_none();

    if_add_filters(qdisc->filters,&d);
    if_add_classes(qdisc->classes,&d);
    return d;
}
