/*
 * filter.c - Filter handling
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <netinet/in.h>

#include "util.h"
#include "error.h"
#include "param.h"
#include "op.h"
#include "tree.h"
#include "tc.h"
#include "police.h"
#include "if.h"
#include "iflib.h"
#include "target.h"
#include "filter.h"


/* ----------------------- Assignment of unique IDs ------------------------ */


static void assign_filter_ids(FILTER *list)
{
    uint32_t prio = 1;

    while (list) {
	if (list->number == UNDEF_U32) list->number = prio++;
	else {
	    if (list->number < prio)
		errorf("assigned priority (%u) below minimum available "
		  "priority (%u)",list->number,prio);
	    prio = list->number+1;
	}
	if (list->number & ~0xffff) /* @@@ correct ? */
	    errorf("invalid filter ID 0x%x",list->number);
	list = list->next;
    }
}


/* -------------------------------- Tunnels -------------------------------- */


CLASS class_is_tunnel;


static void no_tunnel(ELEMENT *element)
{
    if (element->parent.tunnel)
	errorf("filter \"%s\" does not support tunnels",
	  element->parent.filter->dsc->name);
}


static void assign_tunnel_ids(ELEMENT *elements)
{
    ELEMENT *element;
    uint32_t id = 1;

    for (element = elements; element; element = element->next) {
	if (!element->parent.tunnel) continue;
	if (element->parent.tunnel->number != UNDEF_U32) {
	    id = element->parent.tunnel->number;
	    if (!id || id > 255)
		errorf("tunnel ID must be in the range 1..255, not %lu",
		  (unsigned long) id);
	}
	while (1) {
	    ELEMENT *walk;

	    for (walk = elements; walk; walk = walk->next)
		if (walk->parent.tunnel &&
		  walk->parent.tunnel != element->parent.tunnel &&
		  walk->parent.tunnel->number == id)
		    break;
	    if (!walk) break;
	    if (element->parent.tunnel->number != UNDEF_U32)
		errorf("duplicate tunnel ID %lu",id);
	    if (++id == 256) id = 1;
	}
	element->parent.tunnel->number = id;
    }
}


static const PARAM_DSC *tunnel_req[] = {
    &prm_skip,		/* size */
    NULL
};

PARAM_DEF tunnel_param = {
    .required = tunnel_req,
    .optional = NULL,
};


/* ---------------------------------- FW ----------------------------------- */


static void fw_check(FILTER *filter)
{
    ELEMENT *element;

    for (element = filter->elements; element; element = element->next) {
	no_tunnel(element);
	if (element->number == UNDEF_U32)
	    error("fw does not auto-assign element numbers");
	if (element->police) check_police(element->police);
    }
}


static void fw_dump_tc(FILTER *filter)
{
    ELEMENT *element;

    tc_filter_add(filter);
    tc_nl();
    for (element = filter->elements; element; element = element->next) {
	tc_element_add(element);
	tc_add_classid(element->parent.class);
	if (element->police) dump_police(element->police);
	tc_nl();
    }
}


static PARAM_DEF fw_filter = {
    .required = NULL,
    .optional = NULL,
};

static PARAM_DEF fw_element = {
    .required = NULL,
    .optional = NULL,
};

FILTER_DSC fw_dsc = {
    .name = "fw",
    .filter_param = &fw_filter,
    .element_param = &fw_element,
    .check = fw_check,
    .dump_tc = fw_dump_tc,
};


/* --------------------------------- ROUTE --------------------------------- */


#define __DEFAULT_PRM(f) f(from) f(fromif) f(order) f(to)


static void route_check(FILTER *filter)
{
    ELEMENT *element;

    for (element = filter->elements; element; element = element->next) {
	no_tunnel(element);
	if (element->number != UNDEF_U32)
	    error("route has no user-settable element numbers");
	if (element->police) check_police(element->police);
    }
}


static void route_dump_tc(FILTER *filter)
{
    DEFAULT_DECL;
    ELEMENT *element;

    param_get(filter->params);
    DEFAULT_SET;
    tc_filter_add(filter);
    tc_nl();
    for (element = filter->elements; element; element = element->next) {
	param_get(element->params);
	DEFAULT_GET;
	tc_element_add(element);
	if (prm_from.present) tc_add_unum("from",prm_from.v);
	if (prm_fromif.present)
	    tc_add_string("fromif",prm_data(element->params,&prm_fromif));
	if (prm_to.present) tc_add_unum("to",prm_to.v);
	if (prm_order.present) tc_add_unum("order",prm_order.v);
	tc_add_classid(element->parent.class);
	if (element->police) dump_police(element->police);
	tc_nl();
    }
}


static const PARAM_DSC *route_element_opt[] = {
    DEFAULT_LIST	/* NB: no trailing comma */
    NULL
};

static PARAM_DEF route_filter = {
    .required = NULL,
    .optional = route_element_opt, /* all parameters can be defaulted */
};

static PARAM_DEF route_element = {
    .required = NULL,
    .optional = route_element_opt,
};

FILTER_DSC route_dsc = {
    .name = "route",
    .filter_param = &route_filter,
    .element_param = &route_element,
    .check = route_check,
    .dump_tc = route_dump_tc,
};


#undef __DEFAULT_PRM


/* --------------------------------- RSVP ---------------------------------- */


#define __DEFAULT_PRM(f) f(dst) f(src) f(sport) f(dport) f(ipproto) f(ah) f(esp)
#define __DEFAULT_PRM_REQ(f) f(dst)


enum protocol_style { ps_none,ps_ah,ps_esp,ps_ipproto };


static enum protocol_style get_protocol(enum protocol_style proto)
{
    int protocols = 0;

    if (proto != dt_none) return proto;
    if (prm_ah.present) {
	protocols++;
	proto = ps_ah;
    }
    if (prm_esp.present) {
	protocols++;
	proto = ps_esp;
    }
    if (prm_ipproto.present) {
	protocols++;
	proto = ps_ipproto;
    }
    if (protocols > 1)
	error("exactly one of \"ah\", \"esp\", or \"ipproto\" must be "
	  "specified");
    return proto;
}


static void rsvp_check(FILTER *filter)
{
    DEFAULT_DECL;
    ELEMENT *element;

    param_get(filter->params);
    DEFAULT_SET;
    (void) get_protocol(ps_none);
    if (!filter->elements) warnf("RSVP filter without elements is useless");
    assign_tunnel_ids(filter->elements);
    for (element = filter->elements; element; element = element->next) {
	enum protocol_style protocol_style;

	param_get(element->params);
	protocol_style = get_protocol(ps_none);
	DEFAULT_GET;
	DEFAULT_CHECK;
	protocol_style = get_protocol(protocol_style);
	if (element->number != UNDEF_U32)
	    error("rsvp has no user-settable element numbers");
	if ((protocol_style == ps_ah || protocol_style == ps_esp) &&
	  (prm_sport.present || prm_dport.present))
	    error("specify either ports or \"ah\"/\"esp\"");
	if (protocol_style == ps_none)
	    error("exactly one of \"ah\", \"esp\", or \"ipproto\" must be "
	      "specified");
        if (element->police) check_police(element->police);
    }
}


static void rsvp_dump_tc(FILTER *filter)
{
    DEFAULT_DECL;
    ELEMENT *element;

    param_get(filter->params);
    DEFAULT_SET;
    tc_filter_add(filter);
    tc_nl();
    for (element = filter->elements; element; element = element->next) {
	enum protocol_style protocol_style;

	param_get(element->params);
	protocol_style = get_protocol(ps_none);
	DEFAULT_GET;
	protocol_style = get_protocol(protocol_style);
	tc_element_add(element);
	if (protocol_style == ps_ipproto) tc_add_unum("ipproto",prm_ipproto.v);
	tc_add_ipv4("session",prm_dst.v);
	if (prm_dport.present) tc_more("/%d",(int) prm_dport.v);
	if (protocol_style == ps_ah) tc_add_hex("spi/ah",prm_ah.v);
	if (protocol_style == ps_esp) tc_add_hex("spi/esp",prm_esp.v);
	if (prm_src.present) tc_add_ipv4("sender",prm_src.v);
	if (prm_sport.present) {
	    if (!prm_src.present) tc_more(" sender any");
	    tc_more("/%d",(int) prm_sport.v);
	}
	if (element->parent.class != &class_is_tunnel) {
	    tc_add_classid(element->parent.class);
	    if (element->parent.tunnel)
		tc_add_unum("tunnelid",element->parent.tunnel->number);
	}
	else {
	    if (element->parent.tunnel->parent.tunnel)
		tc_add_unum("tunnelid",
		  element->parent.tunnel->parent.tunnel->number);
	    param_get(element->parent.tunnel->params);
	    tc_add_unum("tunnel",element->parent.tunnel->number);
	    tc_add_unum("skip",prm_skip.v);
	}
	if (element->police) dump_police(element->police);
	tc_nl();
    }
}


static const PARAM_DSC *rsvp_element_opt[] = {
    DEFAULT_LIST	/* NB: no trailing comma */
    NULL
};

static PARAM_DEF rsvp_filter = {
    .required = NULL,
    .optional = rsvp_element_opt, /* all parameters can be defaulted */
};

static PARAM_DEF rsvp_element = {
    .required = NULL,
    .optional = rsvp_element_opt,
};

FILTER_DSC rsvp_dsc = {
    .name = "rsvp",
    .filter_param = &rsvp_filter,
    .element_param = &rsvp_element,
    .check = rsvp_check,
    .dump_tc = rsvp_dump_tc,
};


#undef __DEFAULT_PRM
#undef __DEFAULT_PRM_REQ


/* -------------------------------- TCINDEX -------------------------------- */


static void tcindex_check(FILTER *filter)
{
    ELEMENT *element;

    param_get(filter->params);
    if (!prm_mask.present) prm_mask.v = 0xffff;
    if (!prm_hash.present) prm_hash.v = prm_mask.v+1;
    else {
	if (prm_hash.v < prm_mask.v+1)
	    errorf("tcindex: hash 0x%x must be greater than mask 0x%x",
	      (int) prm_hash.v,(int) prm_mask.v);
    }
    for (element = filter->elements; element; element = element->next) {
	no_tunnel(element);
	if (element->number == UNDEF_U32)
	    error("tcindex does not auto-assign element numbers");
/* @@@ check for any impossible number */
	if (element->number > prm_mask.v)
	    errorf("tcindex element number 0x%x greater than mask 0x%x",
	      (int) element->number,(int) prm_mask.v);
	if (element->police) check_police(element->police);
    }
}


static void tcindex_dump_tc(FILTER *filter)
{
    ELEMENT *element;

    param_get(filter->params);
    tc_filter_add(filter);
    if (prm_mask.present) tc_add_hex("mask",prm_mask.v);
    if (prm_hash.present) tc_add_unum("hash",prm_hash.v);
    if (prm_shift.present) tc_add_unum("shift",prm_shift.v);
    if (prm_fall_through.present)
	tc_more(" %s",prm_fall_through.v ? "fall_through" : "pass_on");
    tc_nl();
    for (element = filter->elements; element; element = element->next) {
	tc_element_add(element);
	tc_add_classid(element->parent.class);
	if (element->police) dump_police(element->police);
	tc_nl();
    }
}


static const PARAM_DSC *tcindex_filter_opt[] = {
    &prm_hash,		/* unum */
    &prm_mask,		/* unum */
    &prm_shift,		/* unum */
    &prm_fall_through,	/* flag */
    NULL
};

static PARAM_DEF tcindex_filter = {
    .required = NULL,
    .optional = tcindex_filter_opt,
};

static PARAM_DEF tcindex_element = {
    .required = NULL,
    .optional = NULL,
};

FILTER_DSC tcindex_dsc = {
    .name = "tcindex",
    .filter_param = &tcindex_filter,
    .element_param = &tcindex_element,
    .check = tcindex_check,
    .dump_tc = tcindex_dump_tc,
};


/* ---------------------------------- IF ----------------------------------- */


static void if_check(FILTER *filter)
{
    ELEMENT *element;

    for (element = filter->elements; element; element = element->next)
	if (element->police) check_police(element->police);
}


static void if_dump_tc(FILTER *filter)
{
    QDISC *qdisc = filter->parent.qdisc;
    struct ext_target *target;

    if (qdisc->if_expr.type != dt_none) return;
    qdisc->if_expr = iflib_combine(qdisc);
    iflib_reduce(&qdisc->if_expr);
    for (target = ext_targets; target; target = target->next)
	if (have_target("if",target->name)) {
	    dump_if_ext(filter,target->name);
	    return;
	}
    if (have_target("if","c")) dump_if_c(filter);
    else if (have_target("if","tc")) dump_if_u32(filter);
    else error("no targets available for \"if\"");
}


static PARAM_DEF if_filter = {
    .required = NULL,
    .optional = NULL,
};

FILTER_DSC if_dsc = {
    .name = "if",
    .filter_param = &if_filter,
    .element_param = NULL,
    .check = if_check,
    .dump_tc = if_dump_tc,
};


/* ------------------------------------------------------------------------- */


void add_element(ELEMENT *element,PARENT parent)
{
    ELEMENT **anchor;

    if (!parent.filter) yyerror("filter element without filter");
    element->parent = parent;
    for (anchor = &parent.filter->elements; *anchor; anchor = &(*anchor)->next);
    *anchor = element;
}


void add_filter(FILTER *filter)
{
    FILTER **anchor;

    if (!filter->parent.qdisc) yyerror("filter without qdisc");
    for (anchor = filter->parent.class ? &filter->parent.class->filters :
      &filter->parent.qdisc->filters; *anchor; anchor = &(*anchor)->next);
    *anchor = filter;
}


/*
 * Add a dummy filter element for "if" to the current qdisc, unless one
 * already exists. Then append a filter element for this if expression.
 * Note: there is currently no way to attach an if expression to a class @@@
 * instead of a qdisc.
 */


static void unum_only(DATA d)
{
    if (d.type == dt_none) return;
    if (d.op && (d.op->dsc == &op_conform || d.op->dsc == &op_count)) return;
    if (d.type != dt_unum && d.type != dt_field)
	error("only integer expressions allowed in if");
    if (!d.op) return;
    unum_only(d.op->a);
    unum_only(d.op->b);
    unum_only(d.op->c);
}


static void if_check_policers(DATA d)
{
    /*
     * If is wicked - it may also use policers in the expression !
     * @@@ in fact, it should propagate element->police into the expression
     */
    if (d.type == dt_police) check_police(d.u.police);
    if (!d.op) return;
    if_check_policers(d.op->a);
    if_check_policers(d.op->b);
    if_check_policers(d.op->c);
}


void add_if(DATA expression,PARENT parent,FILTER *filter)
{
    ELEMENT **element;

    unum_only(expression);
    if_check_policers(expression);
    if (!filter) {
	FILTER **anchor;

#if 0
	for (anchor = parent.class->parent.class ?
	  &parent.class->parent.class->filters :
	  &parent.class->parent.qdisc->filters; *anchor;
	  anchor= &(*anchor)->next)
#endif
	for (anchor = &parent.class->parent.qdisc->filters; *anchor;
	  anchor= &(*anchor)->next)
	    if ((*anchor)->dsc == &if_dsc) break;
	if (*anchor) filter = *anchor;
	else {
	    filter = alloc_t(FILTER);
	    filter->parent = parent;
	    filter->parent.class = parent.class->parent.class;
		/* current parent.class is local class; need to get outer one */
	    filter->number = UNDEF_U32;
	    filter->dsc = &if_dsc;
	    filter->params = NULL;
	    filter->elements = NULL;
	    filter->next = NULL;
	    *anchor = filter;
	}
    }
    for (element = &filter->elements; *element; element = &(*element)->next);
    *element = alloc_t(ELEMENT);
    (*element)->parent = parent;
    (*element)->parent.filter = filter;
    (*element)->number = UNDEF_U32;
    (*element)->params = param_make(&prm_if_expr,expression);
    (*element)->police = NULL; /* @@@ sure ? */
    (*element)->next = NULL;
}


void check_filters(FILTER *list)
{
    assign_filter_ids(list);
    while (list) {
	list->dsc->check(list);
	list = list->next;
    }
}


void dump_filters(FILTER *list)
{
    while (list) {
	list->dsc->dump_tc(list);
	list = list->next;
    }
}
