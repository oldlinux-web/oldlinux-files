/*
 * if_u32.c - Processing of the "if" command, using the "u32" classifier
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA, Network Robots
 */


#include <stdint.h>
#include <netinet/in.h>

#include "tcdefs.h"
#include "error.h"
#include "data.h"
#include "op.h"
#include "tc.h"
#include "iflib.h"
#include "if.h"


static uint32_t handle;


static uint32_t new_handle(void)
{
    handle += 0x100000;
    return handle;
}


static void dump_handle(const char *tag,uint32_t handle)
{
    tc_more(" %s %x:%x:%x",tag,TC_U32_USERHTID(handle),TC_U32_HASH(handle),
	  TC_U32_KEY(handle));
}


/*
 * Ugly hack: always have one hash table ready for use @@@
 */


static void next_hash(const FILTER *filter)
{
    __tc_filter_add(filter);
    dump_handle("handle",handle+0x100000);
    tc_more(" u32 divisor 1");
    tc_nl();
}


static int keys;

static struct {
    int offset;
    uint32_t value,mask;
} key[1024]; /* @@@ */


static void reset_unique(void)
{
    keys = 0;
}


static void check_unique(int bits,uint32_t value,uint32_t mask,int offset)
{
    int i;

    switch (bits) {
	case 8:
	    if (offset & 1) {
		offset--;
		value >>= 8;
		mask >>= 8;
	    }
	    /* fall through */
	case 16:
	    if (offset & 2) {
		offset -= 2;
		value >>= 16;
		mask >>= 16;
	    }
	    /* fall through */
	case 32:
	    break;
    }
    for (i = 0; i < keys; i++)
	if (key[i].offset == offset)
	    if ((key[i].value^value) & key[i].mask & mask)
		error("key conflict yields match that is always false");
    key[keys].offset = offset;
    key[keys].value = value;
    key[keys].mask = mask;
    keys++;
}


static void insert_dummy(void)
{
    /*
     * Now there's a really gross hack ! @@@
     *
     * We work around the problem that cls_u32 doesn't allow hash table
     * entries without keys by adding a dummy key that always succeeds.
     *
     * Background: this is needed in three types of cases:
     *  - if (1)  ; we can't generate this yet
     *  - && could in fact be used associatively, but tcc doesn't realize it,
     *    e.g. udp_port == 53 && ip_src == 127.0.0.1, so the expression with
     *    the offset comes first (optimization having already removed the
     *    pre-condition check)
     *  - other cases, where optimization makes the offset appear at an
     *    inconvenient spot
     */
    tc_more(" match u32 0 0 at 0");
}


static void dump_or(const FILTER *filter,DATA d,uint32_t curr_handle);


static uint32_t __dump_link(const FILTER *filter,int first)
{
    uint32_t next = new_handle();

    if (first) insert_dummy();
    dump_handle("link",TC_U32_HTID(next));
    tc_nl();
    next_hash(filter);
    return next;
}


static void dump_link(const FILTER *filter,DATA d,int first)
{
    uint32_t next;

    next = __dump_link(filter,first);
    dump_or(filter,d,next);
}


static void dump_offset(const FILTER *filter,DATA d,int first)
{
    DATA off;

    off = d.op->b;
    if (!off.op) {
	if (off.type != dt_unum) dump_failed(off);
	if (off.u.unum & 3)
	    errorf("offset must be a multiple of 4 (%ld)",
	      (unsigned long) off.u.unum);
	tc_more(" offset plus %d",off.u.unum);
    }
    else {
	uint32_t mask = 0xffff;
	int offset,shift,bytes;

	while (off.op->dsc == &op_shift_left ||
	  off.op->dsc == &op_shift_right) {
	    if (off.op->b.op || off.op->b.type != dt_unum) dump_failed(off);
	    shift = off.op->b.u.unum;
	    if (off.op->dsc == &op_shift_right) shift = -shift;
	    off = off.op->a;
	}
	if (off.op && off.op->dsc == &op_and) {
	    if (!off.op->a.op && off.op->a.type == dt_unum) {
		mask = off.op->a.u.unum;
		off = off.op->b;
	    }
	    else {
		if (off.op->b.op || off.op->b.type != dt_unum)
		    dump_failed(off);
		mask = off.op->b.u.unum;
		off = off.op->a;
	    }
	    if (mask > 0xffff)
		errorf("offset mask must be < 0x10000 (not 0x%lx)",mask);
	}
	if (!off.op || off.op->dsc != &op_access) dump_failed(off);
	if (off.op->b.op || off.op->b.type != dt_unum) dump_failed(off);
	offset = off.op->b.u.unum;
	bytes = off.op->c.u.unum/8;
	if (bytes == 1) {
	    shift -= 8;
	    mask = (mask & 0xff) << 8;
	}
	if (offset & 1) {
	    offset -= 1;
	    shift += 8;
	    if (mask & 0xff) errorf("offset adjustment removes non-zero bits");
	    mask >>= 8;
	}
	if (shift > 0) errorf("u32 can't left-shift (%d)",shift);
	if (shift < -15) errorf("u32 can't right-shift by %d",-shift);
	if (mask & ~(0xffff << -shift))
	    warnf("some non-zero bits of mask 0x%lx are always zero in value",
	      (unsigned long) mask,-shift);
	/*
	 * Brief history of mask and value:
	 *   iproute2/tc: mask read in natural order from line
 	 *   iproute2/tc: htons(mask) -> offmask
	 *   cls_u32: offset = ntohs(offmask & *(u16 *) ...) ...
	 *
	 * So we get:
	 *   offset = ntohs(htons(mask) & *(u16 *) ...)
	 *	    = mask & ntohs(*(u16 *) ...)
	 */
	tc_more(" offset at %d mask %04x shift %d eat",offset,mask,-shift);
    }
    dump_link(filter,d.op->a,first);
}


static void tc_match(int bits,uint32_t *value,uint32_t *mask,int *offset,
  int *bytes)
{
    int size = bits >> 3;

    if (*bytes < size || (*offset & (size-1))) return;
    check_unique(bits,*value,*mask,*offset);
    tc_more(" match u%d 0x%lx 0x%lx at %d",bits,*value >> (32-bits),
      *mask >> (32-bits),*offset);
    *value <<= bits;
    *mask <<= bits;
    *bytes -= size;
    *offset += size;
}


static void dump_eq(DATA d,DATA constant,DATA var)
{
    uint32_t value,mask,default_mask = 1;
    int offset,bytes;

    if (constant.op || constant.type != dt_unum) dump_failed(d);
    if (!var.op) dump_failed(d);
    if (var.op->dsc == &op_and) {
	if (var.op->a.type == dt_unum && !var.op->a.op) {
	    mask = var.op->a.u.unum;
	    var = var.op->b;
	}
	else {
	    if (var.op->b.type != dt_unum || var.op->b.op) dump_failed(d);
	    mask = var.op->b.u.unum;
	    var = var.op->a;
	}
	default_mask = 0;
    }
    if (!var.op || var.op->dsc != &op_access) dump_failed(d);
    if (var.op->b.op || var.op->b.type != dt_unum) dump_failed(d);
    offset = var.op->b.u.unum;
    bytes = var.op->c.u.unum/8;
    value = constant.u.unum;
    if (default_mask) mask = 0xffffffff >> (32-var.op->c.u.unum);
    if (bytes < 4 && (mask >> var.op->c.u.unum))
	warnf("mask 0x%lx larger than %d byte%s access",(unsigned long) mask,
	  bytes,bytes == 1 ? "" : "s");
    if (value & ~mask)
	warnf("value 0x%lx never matches with mask 0x%lx",
	  (unsigned long) value,(unsigned long) mask);
    value <<= 32-var.op->c.u.unum;
    mask <<= 32-var.op->c.u.unum;
    tc_match(32,&value,&mask,&offset,&bytes);
    tc_match(16,&value,&mask,&offset,&bytes);
    tc_match(8,&value,&mask,&offset,&bytes);
    tc_match(16,&value,&mask,&offset,&bytes);
    tc_match(8,&value,&mask,&offset,&bytes);
    if (bytes) errorf("internal error: %d bytes left",bytes);
}


static int dump_other(const FILTER *filter,DATA d,int first)
{
    if (d.op && d.op->dsc == &op_logical_and)
	error("internal error: && on left-hand side of &&");
    if (!d.op) {
	switch (d.type) {
	    case dt_class_if:
		if (first) insert_dummy();
		tc_add_classid(d.u.class);
		tc_nl();
		return 0;
	    default:
		break;
	}
    }
    else {
	 if (d.op->dsc == &op_logical_or) {
	    dump_link(filter,d,first);
	    return first;
	}
	if (d.op->dsc == &op_offset) {
	    dump_offset(filter,d,first);
	    return first;
	}
	if (d.op->dsc == &op_eq) {
	    if (d.op->a.type == dt_unum && !d.op->a.op) {
		dump_eq(d,d.op->a,d.op->b);
		return 0;
	    }
	    if (d.op->b.type == dt_unum && !d.op->b.op) {
		dump_eq(d,d.op->b,d.op->a);
		return 0;
	    }
	}
    }
    dump_failed(d);
    return 0; /* not reached */
}


static void dump_and(const FILTER *filter,DATA d,uint32_t *curr_handle)
{
    int first;

    /* @@@ check: 0-based key allowed ? also: check key overflow */
    if (d.op && d.op->dsc == &op_logical_or)
	error("internal error: || on left-hand side of ||");
    reset_unique();
    __tc_filter_add(filter);
    (*curr_handle)++;
    if (TC_U32_HTID(*curr_handle) == TC_U32_ROOT) tc_more(" u32");
    else {
	dump_handle("handle",*curr_handle);
	tc_more(" u32");
	dump_handle("ht",TC_U32_HTID(*curr_handle));
    }
    first = 1;
    while (d.op && d.op->dsc == &op_logical_and) {
	first = dump_other(filter,d.op->a,first);
	d = d.op->b;
    }
    dump_other(filter,d,first);
}


static void dump_or(const FILTER *filter,DATA d,uint32_t curr_handle)
{
    while (d.op && d.op->dsc == &op_logical_or) {
	dump_and(filter,d.op->a,&curr_handle);
	d = d.op->b;
    }
    dump_and(filter,d,&curr_handle);
}


void dump_if_u32(const FILTER *filter)
{
    DATA d = filter->parent.qdisc->if_expr;

    iflib_offset(&d);
    handle = 0;
    if (!d.op && d.type == dt_unum && !d.u.unum) return;
    next_hash(filter);
    dump_or(filter,d,TC_U32_ROOT);
}
