/*
 * device.c - Device handling
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA
 */


#include <string.h>

#include "config.h"
#include "error.h"
#include "tc.h"
#include "tree.h"
#include "qdisc.h"
#include "device.h"


DEVICE *devices = NULL;


int guess_mtu(DEVICE *device)
{
    return 1510; /* @@@ */
}


void add_device(DEVICE *device)
{
    DEVICE **walk;

    for (walk = &devices; *walk; walk = &(*walk)->next)
	if (!strcmp((*walk)->name,device->name))
	    yyerror("duplicate device name");
    *walk = device;
}


void check_devices(void)
{
    DEVICE *device;

    for (device = devices; device; device = device->next) {
	if (device->ingress) check_qdisc(device->ingress);
	if (device->qdisc) {
	    assign_qdisc_ids(device->qdisc);
	    check_qdisc(device->qdisc);
	}
    }
}


void dump_devices(void)
{
    DEVICE *device;

    for (device = devices; device; device = device->next) {
	if (remove_qdiscs) {
	    tc_more("tc qdisc del dev %s root",device->name);
	    tc_nl();
	}
	if (!device->qdisc && !device->ingress) continue;
	tc_comment('=',"Device %s",device->name);
	if (device->ingress) dump_qdisc(device->ingress);
	if (device->qdisc) dump_qdisc(device->qdisc);
    }
}
