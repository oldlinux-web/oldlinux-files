/*
 * util.c - Utility functions
 *
 * Written 2001 by Werner Almesberger
 * Copyright 2001 EPFL-ICA
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "util.h"


void *alloc(size_t size)
{
    void *new;

    new = malloc(size);
    if (new) return new;
    perror("malloc");
    exit(1);
}


char *stralloc(const char *s)
{
    char *new;

    new = strdup(s);
    if (new) return new;
    perror("strdup");
    exit(1);
}
