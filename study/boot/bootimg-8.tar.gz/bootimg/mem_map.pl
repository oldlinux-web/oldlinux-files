#!/usr/bin/perl

$PAGE_SIZE = 4096;
@name = (
  "locked",	"error",	"referenced",	"uptodate",	# 0
  "4",		"decr_after",	"6",		"7",		# 4
  "slab",	"swap_cache",	"skip",		"swap_entry",	# 8
  "highmem",	"13",		"14",		"15",		# 12
  "16",		"17",		"18",		"19",		# 16
  "20",		"21",		"20",		"21",		# 20
  "24",		"25",		"26",		"27",		# 24
  "28",		"29",		"30",		"reserved");	# 28

sub peek
{
    local ($pos,$size,$fmt) = @_;
    local ($buf);

    sysseek(KMEM,$pos,0); # || die "sysseek: $!";
    sysread(KMEM,$buf,$size) || die "sysread: $!";
    return unpack($fmt,$buf);
}

sub decode
{
    local ($val) = @_;
    local (@r,$i);

    for ($i = 0; $val; $i++) {
	push(@r,$name[$i]) if $val & 1;
	$val >>= 1;
    }
    return defined @r ? @r : "-";
}

sub flush
{
    print sprintf("%08x-%08x  %4d  %s\n",$start*$PAGE_SIZE,$i*$PAGE_SIZE-1,
      $i-$start,join(",",&decode(hex $last)),$last);
    $start = $i;
}


open(KSYMS,"/proc/ksyms") || die "open /proc/ksyms: $!";
while (<KSYMS>) {
    next unless /^(\S+)\s+(\S+)/;
    $mem_map = hex($1) if $2 eq "mem_map";
    $max_mapnr = hex($1) if $2 eq "max_mapnr";
}
die "no mem_map" unless defined $mem_map;
die "no max_mapnr" unless defined $max_mapnr;
open(KMEM,"/dev/kmem") || die "open /dev/kmem: $!";
$map = peek($mem_map,4,"l");
$nr = peek($max_mapnr,4,"l");
#
#  $size and $off are only valid for 2.3.49, without SMP !
#
$size = (2*2+5+4+(2+2+1))*4;
#        2 list_head
#            5 pointers
#              4 (long) ints
#                1 wait_queue_head_t
$off = 6*4;
$start = 0;
$last = -1;
for ($i = 0; $i < $nr; $i++) {
    $curr = sprintf("%04x\n",peek($map+$i*$size+$off,4,"l"));
    &flush if $curr != $last && $i;
    $last = $curr;
}
&flush;
