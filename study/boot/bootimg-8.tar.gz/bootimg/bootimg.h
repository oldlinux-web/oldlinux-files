/* bootimg.h - Global definitions and declarations */

/* Written 2000 by Werner Almesberger */


#ifndef BOOTIMG_H
#define BOOTIMG_H

#include <linux/bootimg.h>


extern struct image_type image_type[];
extern int image_types;
extern int verbose;
extern char *command_line;
extern void *initrd;
extern int initrd_size;


struct image_type {
    const char *name;
    int (*identify)(const void *data,int size);
    void (*map)(struct boot_image *dsc,void *data,int size);
};


#define ENTRIES(x) (sizeof(x)/sizeof(*x))

#ifndef PAGE_SIZE /* should use getpagesize instead */
#define PAGE_SIZE 4096
#endif

void map_data(struct boot_image *dsc,void *data,unsigned long addr,int size);
void *read_memory(unsigned long addr,int size);


#endif
