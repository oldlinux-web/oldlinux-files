/* bootimg.c - Boot an arbitrary (kernel) image */

/* Written 2000 by Werner Almesberger */


#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <linux/unistd.h>

#include "bootimg.h"


#define MEM_DEV	"/dev/mem"


_syscall1(int,bootimg,const struct boot_image *,image)


int verbose = 0;
char *command_line = NULL;
void *initrd = NULL;
int initrd_size;


void map_data(struct boot_image *dsc,void *data,unsigned long addr,int size)
{
    int pages;

    if (!size) return;
    pages = (size+PAGE_SIZE-1)/PAGE_SIZE;
    dsc->image_map = realloc(dsc->image_map,
      sizeof(void *)*(dsc->pages+pages));
    dsc->load_map = realloc(dsc->load_map,
      sizeof(unsigned long)*(dsc->pages+pages));
    if (!dsc->load_map) {
	perror("realloc");
	exit(1);
    }
    if (verbose)
	fprintf(stderr,"  %d byte%s (%d page%s) %p-%p -> 0x%lx-0x%lx\n",
	  size,size == 1 ? "" : "s",pages,pages == 1 ? "" : "s",data,
	 (char *) data+pages*PAGE_SIZE-1,addr,addr+pages*PAGE_SIZE-1);
    while (pages--) {
	dsc->image_map[dsc->pages] = data;
	dsc->load_map[dsc->pages] = addr;
	data = (char *) data+PAGE_SIZE;
	addr += PAGE_SIZE;
	dsc->pages++;
    }
}


static void *read_and_close(int fd,off_t offset,int size)
{
    void *data;
    ssize_t got;

    data = malloc(size+PAGE_SIZE);
	/* make sure we have a valid page after the end */
    if (!data) {
	perror("malloc");
	exit(1);
    }
    if (offset)
	if (lseek(fd,offset,SEEK_SET) < 0) {
	    perror("lseek");
	    exit(1);
	}
    got = read(fd,data,size);
    if (got < 0) {
	perror("read");
	exit(1);
    }
    if (got < size) {
	fprintf(stderr,"short read (%d < %d)\n",got,size);
	exit(1);
    }
    if (close(fd)) {
	perror("close");
	exit(1);
    }
    return data;
}


void *read_memory(unsigned long addr,int size)
{
    int fd;

    fd = open(MEM_DEV,O_RDONLY);
    if (fd < 0) {
	perror(MEM_DEV);
	exit(1);
    }
    return read_and_close(fd,addr,size);
}


static void *load_file(const char *name,int *size)
{
    int fd;
    struct stat st;

    fd = open(name,O_RDONLY);
    if (fd < 0) {
	perror(name);
	exit(1);
    }
    if (fstat(fd,&st) < 0) {
	perror("fstat");
	exit(1);
    }
    if (!S_ISREG(st.st_mode)) {
	fprintf(stderr,"%s: not a regular file\n",name);
	exit(1);
    }
    if (size) *size = st.st_size;
    return read_and_close(fd,0,st.st_size);
}


static void usage(const char *name)
{
    fprintf(stderr,"usage: %s [ -f type ] [ -i initrd ] [ -t ] [ -v ] file "
      "[ args ... ]\n",name);
    fprintf(stderr,"       %s -l\n",name);
    fprintf(stderr,"  -f type    force image type\n");
    fprintf(stderr,"  -i initrd  initial RAM disk file\n");
    fprintf(stderr,"  -t         test only - do not attempt to boot\n");
    fprintf(stderr,"  -v         verbose\n");
    fprintf(stderr,"  -l         list supported image types\n");
    exit(1);
}


int main(int argc,char **argv)
{
    int list = 0,test = 0;
    const char *force = NULL;
    struct boot_image image;
    const char *file_name;
    void *file;
    int size;
    int c,i;

    while ((c = getopt(argc,argv,"f:i:ltv")) != EOF)
	switch (c) {
	    case 'f':
		force = optarg;
		break;
	    case 'i':
		initrd = load_file(optarg,&initrd_size);
		break;
	    case 'l':
		list = 1;
		break;
	    case 't':
		test = 1;
		break;
	    case 'v':
		verbose = 1;
		break;
	    default:
		usage(*argv);
	}
    if (list) {
	if (force || test || verbose || argc != optind) usage(*argv);
	printf("Supported image types:\n");
	for (i = 0; i < image_types; i++)
	    printf("  %s\n",image_type[i].name);
	return 0;
    }
    if (argc < optind+1) usage(*argv);
    file_name = argv[optind];
    file = load_file(file_name,&size);
    while (++optind < argc) {
	int length;

	length = command_line ? strlen(command_line) : 0;
	command_line = realloc(command_line,
	  length+(!!command_line)+strlen(argv[optind])+1);
	if (!command_line) {
	    perror("realloc");
	    return 1;
	}
	if (length) command_line[length++] = ' ';
	strcpy(command_line+length,argv[optind]);
    }
    if (force) {
	for (i = 0; i < image_types; i++)
	    if (!strcasecmp(force,image_type[i].name)) break;
	if (i == image_types) {
	    fprintf(stderr,"%s: no such image type\n",force);
	    return 1;
	}
    }
    else {
	for (i = 0; i < image_types; i++)
	    if (!image_type[i].identify(file,size)) break;
	if (i == image_types) {
	    fprintf(stderr,"%s: unable to identify\n",file_name);
	    return 1;
	}
    }
    memset(&image,0,sizeof(image));
    image_type[i].map(&image,file,size);
    if (verbose)
	fprintf(stderr,"Total %d page%s, start address is %p\n",
	  image.pages,image.pages == 1 ? "" : "s",(void *) image.start);
    if (test) return 0;
    fflush(stdout);
    fprintf(stderr,"Booting NOW\n");
    if (bootimg(&image) < 0) {
	perror("bootimg");
	return 1;
    }
    return 0; /* can't happen */
}
