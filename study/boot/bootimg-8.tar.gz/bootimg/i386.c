/* i386.h - Boot image handling for the i386 architecture */

/* Written 2000 by Werner Almesberger */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <elf.h>

#include "bootimg.h"


#define I386_START_HIGH		0x100000
#define I386_START_LOW		0x001000
#define I386_ENTRY_VADDR	0xc0100000
#define I386_VADDR_OFFSET	0xc0000000

/* --- Lots of goodies, stolen from LILO --- */

#ifndef SECTOR_SIZE
#define SECTOR_SIZE 512
#endif

#define VSS_NUM	497

#define NEW_HDR_SIG     "HdrS"  /* setup header signature */
#define NEW_HDR_VERSION 0x200   /* header version number */
#define LOADED_HIGH	1       /* SETUP_HDR.flags */
#define RELOADS_GDT	2

#define BOOT_SIGNATURE  0xaa55  /* boot signature */
#define BOOT_SIG_OFFSET 510     /* boot signature offset */


struct setup_hdr {
    unsigned short jump;        /*  0: jump to startup code */
    char signature[4];          /*  2: "HdrS" */
    unsigned short version;     /*  6: header version */
    unsigned short x,y,z;       /*  8: LOADLIN hacks */
    unsigned short ver_offset;  /* 14: kernel version string */
    unsigned char loader;       /* 16: loader type */
    unsigned char flags;        /* 17: loader flags */
    unsigned short a;           /* 18: more LOADLIN hacks */
    unsigned long start;        /* 20: kernel start, filled in by loader */
    unsigned long ramdisk;      /* 24: RAM disk start address */
    unsigned long ramdisk_size; /* 28: RAM disk size */
    unsigned short b,c;         /* 32: bzImage hacks */
    unsigned short heap_end_ptr;/* 36: end of free area after setup code */
};

/* --- end --- */

#define PARAM_ADDR	0x90000
#define CL_MAGIC_OFF	0x20
#define CL_MAGIC	0xa33f
#define CL_BASE_ADDR	0x90000
#define CL_OFFSET	0x800
#define CL_OFFSET_OFF	0x22


static int check_setup(const void *data,int size)
{
    int sectors,offset;

    sectors = ((char *) data)[VSS_NUM];
    if (!sectors) return -1; /* kernel is too old anyway */
    offset = (sectors+1)*SECTOR_SIZE;
    if (offset > size) return -1;
    return 0;
}


static void skip_over_setup(void **data,int *size)
{
    int sectors,offset;

    sectors = (*(char **) data)[VSS_NUM];
    offset = (sectors+1)*SECTOR_SIZE;
    *(char **) data += offset;
    *size -= offset;
}


static void i386_common(struct boot_image *dsc)
{
    unsigned char *param;
    struct setup_hdr *hdr;

    param = read_memory(PARAM_ADDR,PAGE_SIZE);
    hdr = (struct setup_hdr *) (param+SECTOR_SIZE);
    if (!command_line) *(unsigned short *) (param+CL_MAGIC_OFF) = 0;
    else {
	*(unsigned short *) (param+CL_MAGIC_OFF) = CL_MAGIC;
	*(unsigned short *) (param+CL_OFFSET_OFF) = CL_OFFSET;
	strcpy(param+CL_OFFSET,command_line);
    }
    if (!initrd) hdr->ramdisk = 0;
    else {
	hdr->ramdisk_size = initrd_size;
/* uuuuuuhhhgggly!!!!  should determine effective memory size */
	hdr->ramdisk = 0x1000000-initrd_size-0x10000; /* slack */
	map_data(dsc,initrd,hdr->ramdisk,initrd_size);
    }
    hdr->loader = 0x50;
    map_data(dsc,param,PARAM_ADDR,PAGE_SIZE);
}


static int check_kernel_header(const void *data,int size)
{
    struct setup_hdr hdr;

    if (size < SECTOR_SIZE+sizeof(hdr)) return -1;
    if (*(const unsigned short *) ((char *) data+BOOT_SIG_OFFSET) !=
      BOOT_SIGNATURE)
	return -1;
    memcpy(&hdr,(char *) data+SECTOR_SIZE,sizeof(hdr));
    if (strncmp(hdr.signature,NEW_HDR_SIG,4)) return -1; /* too old */
    if (hdr.version < NEW_HDR_VERSION) {
	fprintf(stderr,"kernel is too old (version 0x%x < 0x%x)\n",
	  hdr.version,NEW_HDR_VERSION);
	exit(1);
    }
    if (!(hdr.flags & RELOADS_GDT)) {
	fprintf(stderr,"kernel does not support being loaded by bootimg\n");
	exit(1);
    }
    return !!(hdr.flags & LOADED_HIGH);
}


static const char *version_from_setup(const unsigned char *data)
{
    return (const char *) data+SECTOR_SIZE+
      *(unsigned short *) (data+SECTOR_SIZE+14);
}


static int i386_bzImage_identify(const void *data,int size)
{
    int big;

    big = check_kernel_header(data,size);
    if (big <= 0) return -1;
    if (check_setup(data,size)) return -1;
    return 0;
}


static void i386_bzImage_map(struct boot_image *dsc,void *data,int size)
{
    const char *version = version_from_setup(data);

    skip_over_setup(&data,&size);
    if (verbose) printf("bzImage \"%s\"\n",version);
    dsc->start = I386_START_HIGH;
    map_data(dsc,data,I386_START_HIGH,size);
    i386_common(dsc);
}


static int i386_zImage_identify(const void *data,int size)
{
    int big;

    big = check_kernel_header(data,size);
    if (big) return -1;
    if (check_setup(data,size)) return -1;
    return 0;
}


static void i386_zImage_map(struct boot_image *dsc,void *data,int size)
{
    const char *version = version_from_setup(data);

    skip_over_setup(&data,&size);
    if (verbose) printf("zImage \"%s\"\n",version);
    dsc->start = I386_START_LOW;
    map_data(dsc,data,I386_START_LOW,size);
    i386_common(dsc);
}


static int i386_plain_identify(const void *data,int size)
{
    return -1; /* never auto-identify */
}


static void i386_plain_map(struct boot_image *dsc,void *data,int size)
{
    if (verbose) printf("Plain binary file\n");
    dsc->start = I386_START_HIGH;
    map_data(dsc,data,I386_START_HIGH,size);
    i386_common(dsc);
}


static int i386_elf_identify(const void *data,int size)
{
    const unsigned char *p = data;
    Elf32_Ehdr elf_ex;

    memcpy(&elf_ex,p,sizeof(elf_ex));
    if (memcmp(elf_ex.e_ident,ELFMAG,SELFMAG)) return -1;
    if (elf_ex.e_type != ET_EXEC) return -1;
    if (elf_ex.e_entry != I386_ENTRY_VADDR) return -1;
    return 0;
}


static void i386_elf_map(struct boot_image *dsc,void *data,int size)
{
    unsigned char *p = data;
    Elf32_Ehdr elf_ex;
    const Elf32_Shdr *sh;
    int i;
    unsigned long low,high,min,max,min_offset;

    if (verbose) printf("ELF (32 bit)\n");
    memcpy(&elf_ex,p,sizeof(elf_ex));
    sh = (const Elf32_Shdr *) (p+elf_ex.e_shoff);
    min = 0xffffffff;
    max = 0;
    min_offset = 0xffffffff;
    for (i = 0; i < elf_ex.e_shnum; i++, sh++) {
	if (sh->sh_type != SHT_PROGBITS || !(sh->sh_flags & SHF_ALLOC))
	    continue;
	low = sh->sh_addr;
	high = low+sh->sh_size;
	if (low < min) min = low;
	if (high > max) max = high;
	if (sh->sh_offset < min_offset) min_offset = sh->sh_offset;
    }
    sh = (const Elf32_Shdr *) (p+elf_ex.e_shoff);
    for (i = 0; i < elf_ex.e_shnum; i++, sh++) {
	if (sh->sh_type != SHT_PROGBITS || !(sh->sh_flags & SHF_ALLOC))
	    continue;
	if (((sh->sh_addr-min)-(sh->sh_offset-min_offset)) & (PAGE_SIZE-1))
	    break;
    }
    sh = (const Elf32_Shdr *) (p+elf_ex.e_shoff);
    if (i == elf_ex.e_shnum) {
	unsigned long offset,addr,size;

	offset = min_offset;
	addr = min;
	size = 0;
	for (i = 0; i < elf_ex.e_shnum; i++, sh++) {
	    if (sh->sh_type != SHT_PROGBITS || !(sh->sh_flags & SHF_ALLOC))
		continue;
	    if (sh->sh_addr-addr == sh->sh_offset-offset &&
	      sh->sh_offset >= offset) {
		size = sh->sh_addr+sh->sh_size-addr;
		continue;
	    }
	    map_data(dsc,p+offset,addr-I386_VADDR_OFFSET,size);
	    size = sh->sh_size;
	    offset = sh->sh_offset;
	    addr = sh->sh_addr;
	}
        map_data(dsc,p+offset,addr-I386_VADDR_OFFSET,size);
    }
    else { /* can this ever happen ? */
	unsigned char *image;

	if (verbose)
	    printf("  ELF sections are not properly aligned, copying ...\n");
	image = malloc(max-min+PAGE_SIZE-1);
	if (!image) {
	    perror("malloc");
	    exit(1);
	}
	for (i = 0; i < elf_ex.e_shnum; i++, sh++) {
	    if (sh->sh_type != SHT_PROGBITS || !(sh->sh_flags & SHF_ALLOC))
		continue;
	    memcpy(image+sh->sh_addr-min,p+sh->sh_offset,sh->sh_size);
	}
        map_data(dsc,image,I386_START_HIGH,max-min);
    }
    dsc->start = I386_START_HIGH;
    i386_common(dsc);
}


struct image_type image_type[] = {
    { "bzImage",i386_bzImage_identify,	i386_bzImage_map },
    { "zImage",	i386_zImage_identify,	i386_zImage_map },
    { "ELF",	i386_elf_identify,	i386_elf_map },
    { "plain",	i386_plain_identify,	i386_plain_map },
};

int image_types = ENTRIES(image_type);
