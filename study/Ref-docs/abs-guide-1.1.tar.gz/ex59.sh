#!/bin/bash

funky ()
{
  echo "This is a funky function."
  echo "Now exiting funky function."
} # Function declaration must precede call.

  # Now, call the function.

funky

exit 0
