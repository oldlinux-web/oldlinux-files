#!/bin/bash

exec echo "Exiting \"$0\"."   # Exit from script.

# The following lines never execute.

echo "This will never echo."

exit 0  # Will not exit here.
