/* C code produced by gperf version 2.7.2 */
/* Command-line: gperf -'-key-positions=1-2,4-6,9,$' --language=C --struct-type --slot-name=name --hash-fn-name=php_hash --lookup-fn-name=php_lookup  */
#define START_VARIABLE	1001
#define START_WORD	2001
#define START_SHARP	3001
#define START_YACC	4001
#define IS_RESERVED(a)	((a) >= START_WORD)
#define IS_RESERVED_VARIABLE(a)	((a) >= START_VARIABLE && (a) < START_WORD)

#define PHP___FILE__	2001
#define PHP___LINE__	2002
#define PHP___FUNCTION__	2003
#define PHP___CLASS__	2004
#define PHP_AND	2005
#define PHP_ARRAY	2006
#define PHP_AS	2007
#define PHP_BREAK	2008
#define PHP_CASE	2009
#define PHP_CFUNCTION	2010
#define PHP_CLASS	2011
#define PHP_CONST	2012
#define PHP_CONTINUE	2013
#define PHP_DECLARE	2014
#define PHP_DEFAULT	2015
#define PHP_DEFINE	2016
#define PHP_DO	2017
#define PHP_DIE	2018
#define PHP_EACH	2019
#define PHP_ECHO	2020
#define PHP_ELSE	2021
#define PHP_ELSEIF	2022
#define PHP_EMPTY	2023
#define PHP_ENDDECLARE	2024
#define PHP_ENDFOR	2025
#define PHP_ENDFOREACH	2026
#define PHP_ENDIF	2027
#define PHP_ENDWHILE	2028
#define PHP_ENDSWITCH	2029
#define PHP_EVAL	2030
#define PHP_EXIT	2031
#define PHP_FAILURE	2032
#define PHP_FALSE	2033
#define PHP_FOR	2034
#define PHP_FOREACH	2035
#define PHP_FUNCTION	2036
#define PHP_GLOBAL	2037
#define PHP_HEADER	2038
#define PHP_LIST	2039
#define PHP_IF	2040
#define PHP_INCLUDE	2041
#define PHP_INCLUDE_ONCE	2042
#define PHP_IS_ARRAY	2043
#define PHP_IS_SET	2044
#define PHP_NEW	2045
#define PHP_OLD_FUNCTION	2046
#define PHP_OR	2047
#define PHP_PRINT	2048
#define PHP_PRINTF	2049
#define PHP_RETURN	2050
#define PHP_REQUIRE	2051
#define PHP_REQUIRE_ONCE	2052
#define PHP_SETCOOKIE	2053
#define PHP_SUCCESS	2054
#define PHP_STATIC	2055
#define PHP_SWITCH	2056
#define PHP_TRUE	2057
#define PHP_VAR	2058
#define PHP_WHILE	2059
#define PHP_UNSET	2060
#define PHP_XOR	2061
#define PHP_GLOBALS	1001
#define PHP_HTTP_COOKIE_VARS	1002
#define PHP_HTTP_ENV_VARS	1003
#define PHP_HTTP_GET_VARS	1004
#define PHP_HTTP_POST_FILES	1005
#define PHP_HTTP_POST_VARS	1006
#define PHP_HTTP_SERVER_VARS	1007
#define PHP_HTTP_SESSION_VARS	1008
#define PHP__COOKIE	1009
#define PHP__ENV	1010
#define PHP__FILES	1011
#define PHP__GET	1012
#define PHP__POST	1013
#define PHP__REQUEST	1014
#define PHP__SERVER	1015
#define PHP__SESSION	1016
struct keyword { char *name; int token; };

#define TOTAL_KEYWORDS 206
#define MIN_WORD_LENGTH 2
#define MAX_WORD_LENGTH 17
#define MIN_HASH_VALUE 2
#define MAX_HASH_VALUE 980
/* maximum key range = 979, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
php_hash (str, len)
     register const char *str;
     register unsigned int len;
{
  static unsigned short asso_values[] =
    {
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 245,  45,  80, 238,  30,
       15,  45,  40, 240, 981,   5, 150,  10,  15, 210,
       15,   5,  75,   0,   0,  85,   5,  25,  20,  15,
      981, 981, 981, 981, 981,   0, 981,  40,  55,  98,
      135,   0, 205,   5,  10,   5, 981,   0, 164,  45,
        0,   0,   0, 981,   0,  10, 216,   5,  20, 230,
       10, 125, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981, 981, 981, 981, 981,
      981, 981, 981, 981, 981, 981
    };
  register int hval = len;

  switch (hval)
    {
      default:
      case 9:
        hval += asso_values[(unsigned char)str[8]];
      case 8:
      case 7:
      case 6:
        hval += asso_values[(unsigned char)str[5]];
      case 5:
        hval += asso_values[(unsigned char)str[4]];
      case 4:
        hval += asso_values[(unsigned char)str[3]];
      case 3:
      case 2:
        hval += asso_values[(unsigned char)str[1]];
      case 1:
        hval += asso_values[(unsigned char)str[0]];
        break;
    }
  return hval + asso_values[(unsigned char)str[len - 1]];
}

#ifdef __GNUC__
__inline
#endif
struct keyword *
php_lookup (str, len)
     register const char *str;
     register unsigned int len;
{
  static struct keyword wordlist[] =
    {
      {""}, {""},
      {"or", PHP_OR},
      {""},
      {"True", PHP_TRUE},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"return", PHP_RETURN},
      {""},
      {"xor", PHP_XOR},
      {""}, {""}, {""},
      {"require", PHP_REQUIRE},
      {"For", PHP_FOR},
      {""},
      {"_POST", PHP__POST},
      {""},
      {"require_once", PHP_REQUIRE_ONCE},
      {"Xor", PHP_XOR},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
      {"_ENV", PHP__ENV},
      {""}, {""}, {""},
      {"Var", PHP_VAR},
      {"_GET", PHP__GET},
      {""},
      {"EndFor", PHP_ENDFOR},
      {""}, {""},
      {"EXIT", PHP_EXIT},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"as", PHP_AS},
      {"var", PHP_VAR},
      {"each", PHP_EACH},
      {""}, {""}, {""}, {""}, {""},
      {"False", PHP_FALSE},
      {""},
      {"HTTP_SESSION_VARS", PHP_HTTP_SESSION_VARS},
      {"NEW", PHP_NEW},
      {""},
      {"EMPTY", PHP_EMPTY},
      {"HTTP_SERVER_VARS", PHP_HTTP_SERVER_VARS},
      {""},
      {"EndWhile", PHP_ENDWHILE},
      {""}, {""}, {""}, {""}, {""},
      {"HTTP_POST_VARS", PHP_HTTP_POST_VARS},
      {"HTTP_POST_FILES", PHP_HTTP_POST_FILES},
      {"Return", PHP_RETURN},
      {""}, {""},
      {"SetCookie", PHP_SETCOOKIE},
      {"Break", PHP_BREAK},
      {""},
      {"Require", PHP_REQUIRE},
      {""},
      {"Each", PHP_EACH},
      {""}, {""},
      {"Require_once", PHP_REQUIRE_ONCE},
      {"HTTP_ENV_VARS", PHP_HTTP_ENV_VARS},
      {""},
      {"break", PHP_BREAK},
      {""},
      {"echo", PHP_ECHO},
      {""}, {""}, {""}, {""},
      {"Setcookie", PHP_SETCOOKIE},
      {""}, {""},
      {"PRINT", PHP_PRINT},
      {""}, {""},
      {"HTTP_GET_VARS", PHP_HTTP_GET_VARS},
      {""}, {""}, {""},
      {"setcookie", PHP_SETCOOKIE},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"Case", PHP_CASE},
      {""}, {""}, {""}, {""}, {""},
      {"Success", PHP_SUCCESS},
      {""},
      {"Echo", PHP_ECHO},
      {""}, {""},
      {"UNSET", PHP_UNSET},
      {""},
      {"do", PHP_DO},
      {""},
      {"TRUE", PHP_TRUE},
      {"success", PHP_SUCCESS},
      {"PRINTF", PHP_PRINTF},
      {"case", PHP_CASE},
      {"die", PHP_DIE},
      {""}, {""},
      {"define", PHP_DEFINE},
      {""}, {""}, {""}, {""},
      {"header", PHP_HEADER},
      {""}, {""}, {""}, {""},
      {"HTTP_COOKIE_VARS", PHP_HTTP_COOKIE_VARS},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"EndForeach", PHP_ENDFOREACH},
      {""}, {""}, {""}, {""},
      {"else", PHP_ELSE},
      {""},
      {"Foreach", PHP_FOREACH},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"and", PHP_AND},
      {""}, {""},
      {"Header", PHP_HEADER},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"is_array", PHP_IS_ARRAY},
      {""}, {""},
      {"SWITCH", PHP_SWITCH},
      {"_SERVER", PHP__SERVER},
      {""}, {""}, {""}, {""}, {""},
      {"Else", PHP_ELSE},
      {""},
      {"ForEach", PHP_FOREACH},
      {"_FILES", PHP__FILES},
      {"SUCCESS", PHP_SUCCESS},
      {"_REQUEST", PHP__REQUEST},
      {"While", PHP_WHILE},
      {""}, {""}, {""},
      {"for", PHP_FOR},
      {""}, {""},
      {"endfor", PHP_ENDFOR},
      {"Or", PHP_OR},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"true", PHP_TRUE},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"CFUNCTION", PHP_CFUNCTION},
      {""},
      {"Failure", PHP_FAILURE},
      {""},
      {"new", PHP_NEW},
      {""},
      {"CLASS", PHP_CLASS},
      {""}, {""}, {""}, {""},
      {"Do", PHP_DO},
      {"Endfor", PHP_ENDFOR},
      {""},
      {"enddeclare", PHP_ENDDECLARE},
      {"ELSE", PHP_ELSE},
      {""},
      {"Die", PHP_DIE},
      {"AS", PHP_AS},
      {"New", PHP_NEW},
      {"Define", PHP_DEFINE},
      {""}, {""}, {""},
      {"endwhile", PHP_ENDWHILE},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"false", PHP_FALSE},
      {""}, {""},
      {"_SESSION", PHP__SESSION},
      {""}, {""}, {""},
      {"As", PHP_AS},
      {""}, {""}, {""}, {""},
      {"IF", PHP_IF},
      {"Enddeclare", PHP_ENDDECLARE},
      {"endswitch", PHP_ENDSWITCH},
      {""},
      {"IS_SET", PHP_IS_SET},
      {""}, {""},
      {"Class", PHP_CLASS},
      {"WHILE", PHP_WHILE},
      {""}, {""},
      {"Endwhile", PHP_ENDWHILE},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"__LINE__", PHP___LINE__},
      {"EndSwitch", PHP_ENDSWITCH},
      {"CONST", PHP_CONST},
      {""},
      {"class", PHP_CLASS},
      {""}, {""}, {""},
      {"RETURN", PHP_RETURN},
      {""},
      {"FOR", PHP_FOR},
      {"Endswitch", PHP_ENDSWITCH},
      {""}, {""},
      {"Require_Once", PHP_REQUIRE_ONCE},
      {"XOR", PHP_XOR},
      {"Continue", PHP_CONTINUE},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"include", PHP_INCLUDE},
      {""}, {""}, {""},
      {"ENDIF", PHP_ENDIF},
      {"include_once", PHP_INCLUDE_ONCE},
      {""},
      {"endforeach", PHP_ENDFOREACH},
      {""},
      {"FALSE", PHP_FALSE},
      {""},
      {"continue", PHP_CONTINUE},
      {"VAR", PHP_VAR},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"array", PHP_ARRAY},
      {""}, {""}, {""},
      {"EVAL", PHP_EVAL},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"declare", PHP_DECLARE},
      {"Function", PHP_FUNCTION},
      {""}, {""}, {""}, {""},
      {"eval", PHP_EVAL},
      {"Endforeach", PHP_ENDFOREACH},
      {""}, {""}, {""}, {""}, {""},
      {"EACH", PHP_EACH},
      {"foreach", PHP_FOREACH},
      {""},
      {"OR", PHP_OR},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
      {"EndDeclare", PHP_ENDDECLARE},
      {""}, {""}, {""},
      {"BREAK", PHP_BREAK},
      {""},
      {"Eval", PHP_EVAL},
      {"And", PHP_AND},
      {""}, {""}, {""}, {""},
      {"ENDWHILE", PHP_ENDWHILE},
      {"CASE", PHP_CASE},
      {""}, {""}, {""}, {""},
      {"LIST", PHP_LIST},
      {""}, {""}, {""}, {""},
      {"ENDSWITCH", PHP_ENDSWITCH},
      {""}, {""},
      {"__FUNCTION__", PHP___FUNCTION__},
      {""},
      {"__CLASS__", PHP___CLASS__},
      {""},
      {"STATIC", PHP_STATIC},
      {""}, {""},
      {"while", PHP_WHILE},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"if", PHP_IF},
      {"CFunction", PHP_CFUNCTION},
      {""},
      {"endif", PHP_ENDIF},
      {"failure", PHP_FAILURE},
      {""},
      {"Is_array", PHP_IS_ARRAY},
      {""}, {""},
      {"ENDFOR", PHP_ENDFOR},
      {""},
      {"__FILE__", PHP___FILE__},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"print", PHP_PRINT},
      {""}, {""}, {""}, {""},
      {"unset", PHP_UNSET},
      {"FUNCTION", PHP_FUNCTION},
      {""}, {""},
      {"exit", PHP_EXIT},
      {""}, {""},
      {"Declare", PHP_DECLARE},
      {"Endif", PHP_ENDIF},
      {""},
      {"Print", PHP_PRINT},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
      {"is_set", PHP_IS_SET},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
      {"ENDFOREACH", PHP_ENDFOREACH},
      {"Exit", PHP_EXIT},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"ELSEIF", PHP_ELSEIF},
      {"OLD_FUNCTION", PHP_OLD_FUNCTION},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"HEADER", PHP_HEADER},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"AND", PHP_AND},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"ENDDECLARE", PHP_ENDDECLARE},
      {""}, {""},
      {"DIE", PHP_DIE},
      {""}, {""}, {""}, {""},
      {"empty", PHP_EMPTY},
      {""}, {""}, {""}, {""}, {""},
      {"Unset", PHP_UNSET},
      {""}, {""}, {""}, {""},
      {"Const", PHP_CONST},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"ECHO", PHP_ECHO},
      {""}, {""},
      {"function", PHP_FUNCTION},
      {""}, {""},
      {"Array", PHP_ARRAY},
      {""},
      {"REQUIRE", PHP_REQUIRE},
      {""}, {""},
      {"const", PHP_CONST},
      {"Empty", PHP_EMPTY},
      {""}, {""}, {""}, {""},
      {"Include", PHP_INCLUDE},
      {""}, {""}, {""}, {""},
      {"Include_once", PHP_INCLUDE_ONCE},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
      {"default", PHP_DEFAULT},
      {""}, {""},
      {"Switch", PHP_SWITCH},
      {""},
      {"_COOKIE", PHP__COOKIE},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"switch", PHP_SWITCH},
      {""}, {""},
      {"CONTINUE", PHP_CONTINUE},
      {""},
      {"elseif", PHP_ELSEIF},
      {""}, {""}, {""},
      {"DEFINE", PHP_DEFINE},
      {""},
      {"List", PHP_LIST},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"global", PHP_GLOBAL},
      {"SETCOOKIE", PHP_SETCOOKIE},
      {"ARRAY", PHP_ARRAY},
      {""},
      {"old_function", PHP_OLD_FUNCTION},
      {""}, {""},
      {"list", PHP_LIST},
      {""},
      {"FAILURE", PHP_FAILURE},
      {"Cfunction", PHP_CFUNCTION},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"Elseif", PHP_ELSEIF},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"Old_Function", PHP_OLD_FUNCTION},
      {""}, {""}, {""},
      {"cfunction", PHP_CFUNCTION},
      {"FOREACH", PHP_FOREACH},
      {"Is_Array", PHP_IS_ARRAY},
      {""}, {""}, {""},
      {"printf", PHP_PRINTF},
      {""}, {""}, {""}, {""}, {""},
      {"Global", PHP_GLOBAL},
      {"Static", PHP_STATIC},
      {""}, {""},
      {"GLOBALS", PHP_GLOBALS},
      {""}, {""}, {""}, {""},
      {"Printf", PHP_PRINTF},
      {""},
      {"static", PHP_STATIC},
      {""}, {""},
      {"If", PHP_IF},
      {""}, {""}, {""}, {""}, {""},
      {"IS_ARRAY", PHP_IS_ARRAY},
      {""},
      {"DO", PHP_DO},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"Default", PHP_DEFAULT},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
      {"EndIf", PHP_ENDIF},
      {""}, {""},
      {"Is_Set", PHP_IS_SET},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"Is_set", PHP_IS_SET},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
      {"DEFAULT", PHP_DEFAULT},
      {""},
      {"REQUIRE_ONCE", PHP_REQUIRE_ONCE},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"INCLUDE", PHP_INCLUDE},
      {"Include_Once", PHP_INCLUDE_ONCE},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"DECLARE", PHP_DECLARE},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"GLOBAL", PHP_GLOBAL},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
      {"Old_function", PHP_OLD_FUNCTION},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
      {"ElseIf", PHP_ELSEIF},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
      {"INCLUDE_ONCE", PHP_INCLUDE_ONCE}
    };

  if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH)
    {
      register int key = php_hash (str, len);

      if (key <= MAX_HASH_VALUE && key >= 0)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}
static int reserved_word(const char *, int);
static int
reserved_word(str, len)
const char *str;
int len;
{
	struct keyword *keyword = php_lookup(str, len);
	int n = keyword ? keyword->token : 0;
	return IS_RESERVED(n) ? n : 0;
}
static int reserved_variable(const char *, int);
static int
reserved_variable(str, len)
const char *str;
int len;
{
	struct keyword *keyword = php_lookup(str, len);
	int n = keyword ? keyword->token : 0;
	return IS_RESERVED_VARIABLE(n) ? n : 0;
}
