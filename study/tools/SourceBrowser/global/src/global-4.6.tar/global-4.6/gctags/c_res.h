/* C code produced by gperf version 2.7.2 */
/* Command-line: gperf -'-key-positions=1-3,6,$' --language=C --struct-type --slot-name=name --hash-fn-name=c_hash --lookup-fn-name=c_lookup  */
#define START_VARIABLE	1001
#define START_WORD	2001
#define START_SHARP	3001
#define START_YACC	4001
#define IS_RESERVED(a)	((a) >= START_WORD)
#define IS_RESERVED_VARIABLE(a)	((a) >= START_VARIABLE && (a) < START_WORD)

#define C___P	2001
#define C___ATTRIBUTE__	2002
#define C___EXTENSION__	2003
#define C_ASM	2004
#define C_CONST	2005
#define C_INLINE	2006
#define C_RESTRICT	2007
#define C_SIGNED	2008
#define C_VOLATILE	2009
#define C__BOOL	2010
#define C__COMPLEX	2011
#define C__IMAGINARY	2012
#define C_AUTO	2013
#define C_BREAK	2014
#define C_CASE	2015
#define C_CHAR	2016
#define C_CONTINUE	2017
#define C_DEFAULT	2018
#define C_DO	2019
#define C_DOUBLE	2020
#define C_ELSE	2021
#define C_ENUM	2022
#define C_EXTERN	2023
#define C_FLOAT	2024
#define C_FOR	2025
#define C_GOTO	2026
#define C_IF	2027
#define C_INT	2028
#define C_LONG	2029
#define C_REGISTER	2030
#define C_RETURN	2031
#define C_SHORT	2032
#define C_SIZEOF	2033
#define C_STATIC	2034
#define C_STRUCT	2035
#define C_SWITCH	2036
#define C_TYPEDEF	2037
#define C_UNION	2038
#define C_UNSIGNED	2039
#define C_VOID	2040
#define C_WHILE	2041
#define SHARP_SHARP	3001
#define SHARP_ASSERT	3002
#define SHARP_DEFINE	3003
#define SHARP_ELIF	3004
#define SHARP_ELSE	3005
#define SHARP_ENDIF	3006
#define SHARP_ERROR	3007
#define SHARP_IDENT	3008
#define SHARP_IF	3009
#define SHARP_IFDEF	3010
#define SHARP_IFNDEF	3011
#define SHARP_INCLUDE	3012
#define SHARP_LINE	3013
#define SHARP_PRAGMA	3014
#define SHARP_UNDEF	3015
#define SHARP_WARNING	3016
#define YACC_SEP	4001
#define YACC_LEFT	4002
#define YACC_NONASSOC	4003
#define YACC_RIGHT	4004
#define YACC_START	4005
#define YACC_TERM	4006
#define YACC_TOKEN	4007
#define YACC_TYPE	4008
#define YACC_UNION	4009
#define YACC_BEGIN	4010
#define YACC_END	4011
struct keyword { char *name; int token; };

#define TOTAL_KEYWORDS 81
#define MIN_WORD_LENGTH 2
#define MAX_WORD_LENGTH 13
#define MIN_HASH_VALUE 2
#define MAX_HASH_VALUE 313
/* maximum key range = 312, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
c_hash (str, len)
     register const char *str;
     register unsigned int len;
{
  static unsigned short asso_values[] =
    {
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314,  10, 314,   0, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314,  25,  10, 314, 314,
      314, 314, 314,  15, 314, 314, 314, 314, 314, 314,
       30, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314,   0, 314,  35,  30,  45,
       70,   0,  50,  25,   0, 127, 314,   0,  30,  15,
        0,  65,  35, 314,   5,  15,   0,  75,  35,   0,
       10,   0,  10,   5, 314,  10, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314, 314, 314, 314, 314,
      314, 314, 314, 314, 314, 314
    };
  register int hval = len;

  switch (hval)
    {
      default:
      case 6:
        hval += asso_values[(unsigned char)str[5]];
      case 5:
      case 4:
      case 3:
        hval += asso_values[(unsigned char)str[2]];
      case 2:
        hval += asso_values[(unsigned char)str[1]];
      case 1:
        hval += asso_values[(unsigned char)str[0]];
        break;
    }
  return hval + asso_values[(unsigned char)str[len - 1]];
}

#ifdef __GNUC__
__inline
#endif
struct keyword *
c_lookup (str, len)
     register const char *str;
     register unsigned int len;
{
  static struct keyword wordlist[] =
    {
      {""}, {""},
      {"%%", YACC_SEP},
      {""}, {""},
      {"%type", YACC_TYPE},
      {""}, {""}, {""}, {""}, {""},
      {"return", C_RETURN},
      {"%{", YACC_BEGIN},
      {"__extension__", C___EXTENSION__},
      {""},
      {"__restrict", C_RESTRICT},
      {"extern", C_EXTERN},
      {"__restrict__", C_RESTRICT},
      {""}, {""},
      {"%term", YACC_TERM},
      {"%start", YACC_START},
      {"%}", YACC_END},
      {""}, {""},
      {"__signed__", C_SIGNED},
      {"struct", C_STRUCT},
      {""}, {""}, {""}, {""},
      {"#error", SHARP_ERROR},
      {"##", SHARP_SHARP},
      {""}, {""},
      {"%left", YACC_LEFT},
      {""}, {""}, {""}, {""},
      {"break", C_BREAK},
      {""},
      {"__asm__", C_ASM},
      {"register", C_REGISTER},
      {""},
      {"#else", SHARP_ELSE},
      {""}, {""}, {""},
      {"else", C_ELSE},
      {""},
      {"__attribute", C___ATTRIBUTE__},
      {""},
      {"__attribute__", C___ATTRIBUTE__},
      {""},
      {"__asm", C_ASM},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"__P", C___P},
      {""}, {""}, {""},
      {"__const", C_CONST},
      {""},
      {"__const__", C_CONST},
      {""},
      {"%token", YACC_TOKEN},
      {"#assert", SHARP_ASSERT},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"__volatile", C_VOLATILE},
      {"%union", YACC_UNION},
      {"__volatile__", C_VOLATILE},
      {"asm", C_ASM},
      {""},
      {"short", C_SHORT},
      {""},
      {"#define", SHARP_DEFINE},
      {""},
      {"char", C_CHAR},
      {""}, {""},
      {"typedef", C_TYPEDEF},
      {"__signed", C_SIGNED},
      {"enum", C_ENUM},
      {"#elif", SHARP_ELIF},
      {""}, {""}, {""},
      {"case", C_CASE},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"#pragma", SHARP_PRAGMA},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"const", C_CONST},
      {"#endif", SHARP_ENDIF},
      {""},
      {"continue", C_CONTINUE},
      {""}, {""}, {""}, {""},
      {"_Complex", C__COMPLEX},
      {"long", C_LONG},
      {"_Bool", C__BOOL},
      {""}, {""},
      {"for", C_FOR},
      {""},
      {"int", C_INT},
      {""},
      {"while", C_WHILE},
      {""},
      {"%nonassoc", YACC_NONASSOC},
      {""}, {""}, {""},
      {"%right", YACC_RIGHT},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"static", C_STATIC},
      {""},
      {"switch", C_SWITCH},
      {""},
      {"float", C_FLOAT},
      {""}, {""}, {""}, {""},
      {"restrict", C_RESTRICT},
      {""},
      {"default", C_DEFAULT},
      {""},
      {"goto", C_GOTO},
      {""}, {""}, {""},
      {"inline", C_INLINE},
      {""}, {""}, {""},
      {"_Imaginary", C__IMAGINARY},
      {"unsigned", C_UNSIGNED},
      {""}, {""}, {""},
      {"#line", SHARP_LINE},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"auto", C_AUTO},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
      {"#undef", SHARP_UNDEF},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
      {"do", C_DO},
      {""}, {""},
      {"#warning", SHARP_WARNING},
      {""},
      {"union", C_UNION},
      {""}, {""}, {""}, {""}, {""},
      {"#ident", SHARP_IDENT},
      {""}, {""},
      {"double", C_DOUBLE},
      {""}, {""}, {""},
      {"#include", SHARP_INCLUDE},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"if", C_IF},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""},
      {"#if", SHARP_IF},
      {""}, {""}, {""},
      {"#ifndef", SHARP_IFNDEF},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
      {"sizeof", C_SIZEOF},
      {""}, {""}, {""},
      {"__inline", C_INLINE},
      {""},
      {"__inline__", C_INLINE},
      {"volatile", C_VOLATILE},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"#ifdef", SHARP_IFDEF},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"void", C_VOID},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
      {"signed", C_SIGNED}
    };

  if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH)
    {
      register int key = c_hash (str, len);

      if (key <= MAX_HASH_VALUE && key >= 0)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}
static int reserved_word(const char *, int);
static int
reserved_word(str, len)
const char *str;
int len;
{
	struct keyword *keyword = c_lookup(str, len);
	int n = keyword ? keyword->token : 0;
	return IS_RESERVED(n) ? n : 0;
}
