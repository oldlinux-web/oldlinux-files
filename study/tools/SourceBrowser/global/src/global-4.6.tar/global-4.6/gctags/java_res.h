/* C code produced by gperf version 2.7.2 */
/* Command-line: gperf -'-key-positions=1-3,6,$' --language=C --struct-type --slot-name=name --hash-fn-name=java_hash --lookup-fn-name=java_lookup  */
#define START_VARIABLE	1001
#define START_WORD	2001
#define START_SHARP	3001
#define START_YACC	4001
#define IS_RESERVED(a)	((a) >= START_WORD)
#define IS_RESERVED_VARIABLE(a)	((a) >= START_VARIABLE && (a) < START_WORD)

#define JAVA_ABSTRACT	2001
#define JAVA_BOOLEAN	2002
#define JAVA_BREAK	2003
#define JAVA_BYTE	2004
#define JAVA_CASE	2005
#define JAVA_CATCH	2006
#define JAVA_CHAR	2007
#define JAVA_CLASS	2008
#define JAVA_CONST	2009
#define JAVA_CONTINUE	2010
#define JAVA_DEFAULT	2011
#define JAVA_DO	2012
#define JAVA_DOUBLE	2013
#define JAVA_ELSE	2014
#define JAVA_EXTENDS	2015
#define JAVA_FALSE	2016
#define JAVA_FINAL	2017
#define JAVA_FINALLY	2018
#define JAVA_FLOAT	2019
#define JAVA_FOR	2020
#define JAVA_GOTO	2021
#define JAVA_IF	2022
#define JAVA_IMPLEMENTS	2023
#define JAVA_IMPORT	2024
#define JAVA_INSTANCEOF	2025
#define JAVA_INT	2026
#define JAVA_INTERFACE	2027
#define JAVA_LONG	2028
#define JAVA_NATIVE	2029
#define JAVA_NEW	2030
#define JAVA_NULL	2031
#define JAVA_PACKAGE	2032
#define JAVA_PRIVATE	2033
#define JAVA_PROTECTED	2034
#define JAVA_PUBLIC	2035
#define JAVA_RETURN	2036
#define JAVA_SHORT	2037
#define JAVA_STATIC	2038
#define JAVA_STRICTFP	2039
#define JAVA_SUPER	2040
#define JAVA_SWITCH	2041
#define JAVA_SYNCHRONIZED	2042
#define JAVA_THIS	2043
#define JAVA_THROW	2044
#define JAVA_THROWS	2045
#define JAVA_UNION	2046
#define JAVA_TRANSIENT	2047
#define JAVA_TRUE	2048
#define JAVA_TRY	2049
#define JAVA_VOID	2050
#define JAVA_VOLATILE	2051
#define JAVA_WHILE	2052
#define JAVA_WIDEFP	2053
struct keyword { char *name; int token; };

#define TOTAL_KEYWORDS 53
#define MIN_WORD_LENGTH 2
#define MAX_WORD_LENGTH 12
#define MIN_HASH_VALUE 3
#define MAX_HASH_VALUE 149
/* maximum key range = 147, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
java_hash (str, len)
     register const char *str;
     register unsigned int len;
{
  static unsigned char asso_values[] =
    {
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150,  20,  40,  36,
       35,  35,  35,   5,  48,   0, 150,   5,  15,   5,
        0,  25,  26, 150,   0,   0,   0,   5,  20,  40,
        5,  20, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150, 150, 150, 150, 150,
      150, 150, 150, 150, 150, 150
    };
  register int hval = len;

  switch (hval)
    {
      default:
      case 6:
        hval += asso_values[(unsigned char)str[5]];
      case 5:
      case 4:
      case 3:
        hval += asso_values[(unsigned char)str[2]];
      case 2:
        hval += asso_values[(unsigned char)str[1]];
      case 1:
        hval += asso_values[(unsigned char)str[0]];
        break;
    }
  return hval + asso_values[(unsigned char)str[len - 1]];
}

#ifdef __GNUC__
__inline
#endif
struct keyword *
java_lookup (str, len)
     register const char *str;
     register unsigned int len;
{
  static struct keyword wordlist[] =
    {
      {""}, {""}, {""},
      {"int", JAVA_INT},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"union", JAVA_UNION},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"transient", JAVA_TRANSIENT},
      {""}, {""}, {""}, {""},
      {"strictfp", JAVA_STRICTFP},
      {""},
      {"super", JAVA_SUPER},
      {"import", JAVA_IMPORT},
      {""},
      {"null", JAVA_NULL},
      {""},
      {"return", JAVA_RETURN},
      {""},
      {"try", JAVA_TRY},
      {"true", JAVA_TRUE},
      {"instanceof", JAVA_INSTANCEOF},
      {"implements", JAVA_IMPLEMENTS},
      {""}, {""},
      {"long", JAVA_LONG},
      {""}, {""},
      {"this", JAVA_THIS},
      {""},
      {"throws", JAVA_THROWS},
      {"final", JAVA_FINAL},
      {""}, {""}, {""},
      {"goto", JAVA_GOTO},
      {""}, {""}, {""},
      {"for", JAVA_FOR},
      {""}, {""},
      {"const", JAVA_CONST},
      {"synchronized", JAVA_SYNCHRONIZED},
      {"private", JAVA_PRIVATE},
      {""}, {""}, {""},
      {"if", JAVA_IF},
      {""}, {""}, {""},
      {"class", JAVA_CLASS},
      {"finally", JAVA_FINALLY},
      {"short", JAVA_SHORT},
      {"interface", JAVA_INTERFACE},
      {"float", JAVA_FLOAT},
      {""},
      {"extends", JAVA_EXTENDS},
      {""},
      {"void", JAVA_VOID},
      {"break", JAVA_BREAK},
      {""},
      {"do", JAVA_DO},
      {"abstract", JAVA_ABSTRACT},
      {"else", JAVA_ELSE},
      {""}, {""}, {""},
      {"throw", JAVA_THROW},
      {""},
      {"case", JAVA_CASE},
      {"native", JAVA_NATIVE},
      {""},
      {"static", JAVA_STATIC},
      {"byte", JAVA_BYTE},
      {""}, {""}, {""},
      {"volatile", JAVA_VOLATILE},
      {"continue", JAVA_CONTINUE},
      {""}, {""}, {""},
      {"char", JAVA_CHAR},
      {"catch", JAVA_CATCH},
      {"false", JAVA_FALSE},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"boolean", JAVA_BOOLEAN},
      {"new", JAVA_NEW},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"default", JAVA_DEFAULT},
      {"while", JAVA_WHILE},
      {"package", JAVA_PACKAGE},
      {""},
      {"protected", JAVA_PROTECTED},
      {""},
      {"widefp", JAVA_WIDEFP},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"double", JAVA_DOUBLE},
      {"switch", JAVA_SWITCH},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"public", JAVA_PUBLIC}
    };

  if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH)
    {
      register int key = java_hash (str, len);

      if (key <= MAX_HASH_VALUE && key >= 0)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}
static int reserved_word(const char *, int);
static int
reserved_word(str, len)
const char *str;
int len;
{
	struct keyword *keyword = java_lookup(str, len);
	int n = keyword ? keyword->token : 0;
	return IS_RESERVED(n) ? n : 0;
}
