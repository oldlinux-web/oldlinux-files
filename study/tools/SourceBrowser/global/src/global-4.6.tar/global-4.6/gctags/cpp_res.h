/* C code produced by gperf version 2.7.2 */
/* Command-line: gperf -'-key-positions=1-3,6,$' --language=C --struct-type --slot-name=name --hash-fn-name=cpp_hash --lookup-fn-name=cpp_lookup  */
#define START_VARIABLE	1001
#define START_WORD	2001
#define START_SHARP	3001
#define START_YACC	4001
#define IS_RESERVED(a)	((a) >= START_WORD)
#define IS_RESERVED_VARIABLE(a)	((a) >= START_VARIABLE && (a) < START_WORD)

#define CPP___P	2001
#define CPP___ATTRIBUTE__	2002
#define CPP___EXTENSION__	2003
#define CPP_ASM	2004
#define CPP_CONST	2005
#define CPP_INLINE	2006
#define CPP_SIGNED	2007
#define CPP_VOLATILE	2008
#define CPP_AUTO	2009
#define CPP_BOOL	2010
#define CPP_BREAK	2011
#define CPP_CASE	2012
#define CPP_CATCH	2013
#define CPP_CHAR	2014
#define CPP_CLASS	2015
#define CPP_CONST_CAST	2016
#define CPP_CONTINUE	2017
#define CPP_DEFAULT	2018
#define CPP_DELETE	2019
#define CPP_DO	2020
#define CPP_DOUBLE	2021
#define CPP_DYNAMIC_CAST	2022
#define CPP_ELSE	2023
#define CPP_ENUM	2024
#define CPP_EXPLICIT	2025
#define CPP_EXPORT	2026
#define CPP_EXTERN	2027
#define CPP_FALSE	2028
#define CPP_FLOAT	2029
#define CPP_FOR	2030
#define CPP_FRIEND	2031
#define CPP_GOTO	2032
#define CPP_IF	2033
#define CPP_INT	2034
#define CPP_LONG	2035
#define CPP_MUTABLE	2036
#define CPP_NAMESPACE	2037
#define CPP_NEW	2038
#define CPP_OPERATOR	2039
#define CPP_PRIVATE	2040
#define CPP_PROTECTED	2041
#define CPP_PUBLIC	2042
#define CPP_REGISTER	2043
#define CPP_REINTERPRET_CAST	2044
#define CPP_RETURN	2045
#define CPP_SHORT	2046
#define CPP_SIZEOF	2047
#define CPP_STATIC	2048
#define CPP_STATIC_CAST	2049
#define CPP_STRUCT	2050
#define CPP_SWITCH	2051
#define CPP_TEMPLATE	2052
#define CPP_THIS	2053
#define CPP_THROW	2054
#define CPP_TRUE	2055
#define CPP_TRY	2056
#define CPP_TYPEDEF	2057
#define CPP_TYPENAME	2058
#define CPP_TYPEID	2059
#define CPP_UNION	2060
#define CPP_UNSIGNED	2061
#define CPP_USING	2062
#define CPP_VIRTUAL	2063
#define CPP_VOID	2064
#define CPP_WCHAR_T	2065
#define CPP_WHILE	2066
#define SHARP_SHARP	3001
#define SHARP_ASSERT	3002
#define SHARP_DEFINE	3003
#define SHARP_ELIF	3004
#define SHARP_ELSE	3005
#define SHARP_ENDIF	3006
#define SHARP_ERROR	3007
#define SHARP_IDENT	3008
#define SHARP_IF	3009
#define SHARP_IFDEF	3010
#define SHARP_IFNDEF	3011
#define SHARP_INCLUDE	3012
#define SHARP_LINE	3013
#define SHARP_PRAGMA	3014
#define SHARP_UNDEF	3015
#define SHARP_WARNING	3016
struct keyword { char *name; int token; };

#define TOTAL_KEYWORDS 93
#define MIN_WORD_LENGTH 2
#define MAX_WORD_LENGTH 16
#define MIN_HASH_VALUE 13
#define MAX_HASH_VALUE 453
/* maximum key range = 441, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
cpp_hash (str, len)
     register const char *str;
     register unsigned int len;
{
  static unsigned short asso_values[] =
    {
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454,   5, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
       10, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454,   0, 454,  30,  30,  25,
       15,   0, 105,  40,  85, 127, 454,  10,  65,  35,
        0,  50,   5, 454, 122,  15,   0,  55,  55, 100,
      110,  55,   5, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454, 454, 454, 454, 454,
      454, 454, 454, 454, 454, 454
    };
  register int hval = len;

  switch (hval)
    {
      default:
      case 6:
        hval += asso_values[(unsigned char)str[5]];
      case 5:
      case 4:
      case 3:
        hval += asso_values[(unsigned char)str[2]];
      case 2:
        hval += asso_values[(unsigned char)str[1]];
      case 1:
        hval += asso_values[(unsigned char)str[0]];
        break;
    }
  return hval + asso_values[(unsigned char)str[len - 1]];
}

#ifdef __GNUC__
__inline
#endif
struct keyword *
cpp_lookup (str, len)
     register const char *str;
     register unsigned int len;
{
  static struct keyword wordlist[] =
    {
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
      {"__extension__", CPP___EXTENSION__},
      {""}, {""}, {""},
      {"##", SHARP_SHARP},
      {""}, {""}, {""}, {""}, {""},
      {"__P", CPP___P},
      {""},
      {"__signed__", CPP_SIGNED},
      {""},
      {"#define", SHARP_DEFINE},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"__asm__", CPP_ASM},
      {"__signed", CPP_SIGNED},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"__const", CPP_CONST},
      {""},
      {"__const__", CPP_CONST},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
      {"__asm", CPP_ASM},
      {""}, {""},
      {"template", CPP_TEMPLATE},
      {"case", CPP_CASE},
      {"#else", SHARP_ELSE},
      {""}, {""}, {""},
      {"namespace", CPP_NAMESPACE},
      {"const", CPP_CONST},
      {"static_cast", CPP_STATIC_CAST},
      {""},
      {"continue", CPP_CONTINUE},
      {"else", CPP_ELSE},
      {"const_cast", CPP_CONST_CAST},
      {"delete", CPP_DELETE},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"unsigned", CPP_UNSIGNED},
      {"enum", CPP_ENUM},
      {"__volatile", CPP_VOLATILE},
      {"typeid", CPP_TYPEID},
      {"__volatile__", CPP_VOLATILE},
      {"typename", CPP_TYPENAME},
      {""}, {""},
      {"static", CPP_STATIC},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""},
      {"extern", CPP_EXTERN},
      {"do", CPP_DO},
      {"asm", CPP_ASM},
      {""}, {""},
      {"export", CPP_EXPORT},
      {""}, {""}, {""}, {""},
      {"double", CPP_DOUBLE},
      {""},
      {"return", CPP_RETURN},
      {""},
      {"int", CPP_INT},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"auto", CPP_AUTO},
      {"class", CPP_CLASS},
      {""}, {""},
      {"struct", CPP_STRUCT},
      {"goto", CPP_GOTO},
      {"catch", CPP_CATCH},
      {"public", CPP_PUBLIC},
      {""},
      {"explicit", CPP_EXPLICIT},
      {""}, {""}, {""}, {""},
      {"#ident", SHARP_IDENT},
      {""},
      {"short", CPP_SHORT},
      {""}, {""}, {""},
      {"long", CPP_LONG},
      {""}, {""},
      {"mutable", CPP_MUTABLE},
      {"__attribute", CPP___ATTRIBUTE__},
      {""},
      {"__attribute__", CPP___ATTRIBUTE__},
      {""},
      {"break", CPP_BREAK},
      {""}, {""}, {""}, {""},
      {"typedef", CPP_TYPEDEF},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"#assert", SHARP_ASSERT},
      {"#elif", SHARP_ELIF},
      {"true", CPP_TRUE},
      {""}, {""}, {""},
      {"operator", CPP_OPERATOR},
      {""},
      {"union", CPP_UNION},
      {""}, {""}, {""}, {""},
      {"default", CPP_DEFAULT},
      {""}, {""},
      {"#include", SHARP_INCLUDE},
      {""}, {""},
      {"inline", CPP_INLINE},
      {"bool", CPP_BOOL},
      {""}, {""},
      {"#line", SHARP_LINE},
      {"new", CPP_NEW},
      {"#pragma", SHARP_PRAGMA},
      {"false", CPP_FALSE},
      {""}, {""}, {""},
      {"dynamic_cast", CPP_DYNAMIC_CAST},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"wchar_t", CPP_WCHAR_T},
      {"signed", CPP_SIGNED},
      {""}, {""},
      {"#endif", SHARP_ENDIF},
      {""}, {""}, {""},
      {"float", CPP_FLOAT},
      {"protected", CPP_PROTECTED},
      {""}, {""}, {""}, {""},
      {"this", CPP_THIS},
      {""}, {""}, {""},
      {"try", CPP_TRY},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"using", CPP_USING},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"void", CPP_VOID},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"private", CPP_PRIVATE},
      {"__inline", CPP_INLINE},
      {""},
      {"__inline__", CPP_INLINE},
      {"reinterpret_cast", CPP_REINTERPRET_CAST},
      {"char", CPP_CHAR},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"#undef", SHARP_UNDEF},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""},
      {"register", CPP_REGISTER},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
      {"volatile", CPP_VOLATILE},
      {""}, {""}, {""}, {""},
      {"#warning", SHARP_WARNING},
      {""},
      {"throw", CPP_THROW},
      {""}, {""}, {""}, {""},
      {"while", CPP_WHILE},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
      {"if", CPP_IF},
      {""}, {""}, {""}, {""}, {""},
      {"#if", SHARP_IF},
      {""}, {""}, {""},
      {"#ifndef", SHARP_IFNDEF},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
      {"sizeof", CPP_SIZEOF},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""},
      {"#error", SHARP_ERROR},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""},
      {"friend", CPP_FRIEND},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
      {"for", CPP_FOR},
      {""}, {""}, {""},
      {"virtual", CPP_VIRTUAL},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""},
      {"switch", CPP_SWITCH},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {""}, {""}, {""}, {""}, {""}, {""}, {""},
      {"#ifdef", SHARP_IFDEF}
    };

  if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH)
    {
      register int key = cpp_hash (str, len);

      if (key <= MAX_HASH_VALUE && key >= 0)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return 0;
}
static int reserved_word(const char *, int);
static int
reserved_word(str, len)
const char *str;
int len;
{
	struct keyword *keyword = cpp_lookup(str, len);
	int n = keyword ? keyword->token : 0;
	return IS_RESERVED(n) ? n : 0;
}
