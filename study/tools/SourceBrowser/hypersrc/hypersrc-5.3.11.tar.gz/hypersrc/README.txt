Jim Brooks
hypersrc@jimbrooks.org
2003/01/16

Synopsis
========

"hypersrc" is a freeware GTK+/GNOME program for browsing source code. 

Webpage & Updates
=================

The latest version is available at:
http://www.jimbrooks.org/hypersrc/
http://freshmeat.net/projects/hypersrc/

Requirements
============

- A UNIX system with GNU tools (GNU make, bison, Perl, etc).

  Has been known to compile/run on Linux (Red Hat) and FreeBSD 4.2.

- GTK+ 1.2.6 (or newer) and GNOME

  At least one old GTK+ version (1.2.3) definitely has a bug
  that causes a segfault when a tag is clicked (see below).

- "Exuberant ctags" 3.2 (or newer) by Darren Hiebert.

  You probably already have it, if you have a recent Linux distribution.

  hypersrc requires a program capable of producing output equivalent
  to Exuberant ctags -x option.  hypersrc won't work with plain-old GNU ctags.

  Exuberant ctags webpage is: http://ctags.sourceforge.net
  and various versions of it are at: http://www.rpmfind.net

Building/Installing/Quickstart
==============================

See INSTALL.txt

Running hypersrc
================

Use the provided Perl script "Hypersrc.pl" to run hypersrc.

If Hypersrc.pl is called without options, by default, it will gather C src files
in the CWD and in a few subdir levels, and will pass them to hypersrc.

See "Hypersrc.pl -help".

Examples:

  Hypersrc.pl                        # browse C based on CWD (descends a few subdirs)
  Hypersrc.pl  src/gui  src/inc      # browse C in two dirs  (descends a few subdirs)
  Hypersrc.pl  *.f77                 # browse Fortran files  (in CWD only)
  Hypersrc.pl  myprog/perl           # this will browse C files, not Perl scripts
  Hypersrc.pl  myprog/perl/*.pl      # this will browse Perl scripts

More Examples:

  Hypersrc.pl  -descend 0            # don't descend down to any subdir
  Hypersrc.pl  -descend 1            # descend only one subdir level
  Hypersrc.pl  -lang c++,perl        # browse only C++ and Perl source files
  Hypersrc.pl  -lang c++ perl        # WRONG, must be one comma-separated word
  Hypersrc.pl  -exclude obj/,bak/    # exclude files in these subdirs
  Hypersrc.pl  -ext .cc              # browse only source files ending with .cc
  Hypersrc.pl  -geom 80 160 940 600  # set size/position of main window
  Hypersrc.pl  -max-tags 500000      # set limit of tags to process

Customization and Options
=========================

Many preferences can be edited/saved via the GUI.
Preferences can be overridden by corresponding cmd-line options.
All preferences can be ignored by passing "-ignore-prefs".

hypersrc has a set of command line options to support customizing
the maximum amount of tags, tab width, window geometries, fonts, etc.
See "hypersrc -help".

Hypersrc.pl also has its own set of options (see "Hypersrc.pl -help").
Options not recognized by Hypersrc.pl will be passed thru to hypersrc.

Speed/Memory Options
====================

Pass -no-functree to speed startup and conserve memory (but forfeit tree views).

For the daring, build an optimized executable:  "make speed install"
But the drawback is that many self-checks won't be compiled.

Testing
=======

Recent development (2001/12/30) has been done using:

- GTK+ 1.2.10
- Exuberant ctags 5.2 and 4.0.3
- Mandrake 8, Red Hat 6/7, FreeBSD 4.2
- XFree86 4.0.1 and 3.3.5
- flex 2.5.4, bison 1.28
- gcc [egcs] 2.96-81

Limitations
===========

- The maximum amount of tags is ultimately limited by #define MAX_TAGS_ABSOLUTE.

- Be warned that trying to browse everything in a very large source tree will
  TAKE A LARGE AMOUNT OF MEMORY and several minutes to start.
  For example, on a Pentium II, the program will take more than 90 minutes
  and 105 megs when starting to browse the entire Linux 2.4.0 source!

- Can't handle filenames containing spaces.

Solutions to Common Problems
============================

- Hypersrc.pl complains about ctags even though my system has it.

  Probably, it only located the GNU (emacs) version of ctags,
  which hypersrc can't use.

  Copy Exuberant ctags to somewhere in PATH.
  Or, if you prefer to copy it somewhere outside of PATH,
  then edit the line with $ctags in Hypersrc.pl.

Known Problems/Issues
=====================

- hypersrc quits silently while trying to jump to a tag.

  Upgrade to GTK+ 1.2.8 if you are using an older version.
  GTK+ 1.2.3 definitely has a bug which hypersrc encounters.
  Other old versions might have this bug also.

  If this problem still persists, as a last resort, try deselecting the
  preference: "Misc / process GTK+ events while busy".
  However, be advised the program won't redraw itself while it is busy.

- Rarely, parser fails to recognize some function calls/blocks,
  resulting in an empty tree view.

- All functions with the same name will appear in the the "called by"
  tree, regardless if some don't really call this function.

- Rarely, the scrollbar beside a tree will stop working if the tree tries
  to show too many nodes/leafs, which can happen if a browsed function
  is called hundreds of times.

- To browse everything in a humongous source tree, such as the Linux 2.4
  kernel, hypersrc takes a long time to start and lots of memory.

  Yes.

  Try passing any of:

  -descend     : to limit the amount of subdirs to descend
  -max-tags    : to limit the amount of tags to be processed
  -exclude     : to exclude some dirs/files
  -no-functree : to speed startup by sacrificing tree views

Trouble-shooting
================

To run hypersrc under gdb (and this enables warning messages, extra checks):

   ./configure.sh
   make debug install

   Hypersrc.pl -gdb

Unsupported Source Files
========================

If you have a source file that Exuberant ctags doesn't support,
then you could write your own parser that produces output
that is similar to the -x option of Exuberant ctags,
and pass the output directly to hypersrc (see "Directly Invoking hypersrc").

Directly Invoking hypersrc
==========================

The only mandatory option for hypersrc is "-ctags-x <file>" which specifies a file
that contains tags in the format used by the -x option of Exuberant ctags, eg:

   ctags  -x *.c  >  tags
   hypersrc  -ctags-x  tags

[ Or instead, -stdin can be used to pipe ctags -x output into hypersrc. ]

See "hypersrc -help" for other options.

Legal
=====

This is "copy-left software" that is distributed with, protected by,
and licensed under the GNU General Public License (see "LICENSE.txt").
This software is provided "AS-IS" without any express or implied warranty nor guarantee.
In no event will the author be held liable for any damages arising from
the use of this software nor derivative works.
