/******************************************************************************
 * $Id: misc.c,v 1.4 2003/01/14 21:47:14 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Misc. functions.
 ******************************************************************************/

#include "common.h"
#include "misc.h"

/*****************************************************************************
 * Simple function to lock an arbitrary resource.
 *
 * Returns TRUE if resource was unlocked (caller allowed access)
 * and then resource is locked by this function.
 *
 * Returns FALSE if resource was locked (caller forbidden access).
 *
 * Lock variables must be declared static and initialized with UNLOCKED, eg:
 * static lock_t  my_lock  =  UNLOCKED;
 *****************************************************************************/
gboolean
Lock( lock_t* pLock )  /* ### MUST BE A STATIC VAR ### */
{
   if ( *pLock == UNLOCKED )
   {
      *pLock = LOCKED;
      return TRUE;
   }
   else
   {
      return FALSE;
   }
}

/*****************************************************************************
 * Simple function to unlock an arbitrary resource.
 *****************************************************************************/
void
Unlock( lock_t* pLock )  /* ### MUST BE A STATIC VAR ### */
{
   *pLock = UNLOCKED;
}

/*****************************************************************************
 * Schedule a GTK+ idle callback.
 *
 * Parms   : pCbId (OUT)
 *           Pointer to GTK+ id of callback.
 *
 *           func, data
 *           Pointer to callback func and its one parm.
 *****************************************************************************/
void
ScheduleIdleCallback( guint*      pCbId,
                      GtkFunction func,
                      gpointer    pData )
{
   if ( pCbId  &&  *pCbId == CALLBACK_ID_OFF )
   {
      *pCbId = gtk_idle_add( func, pData );
   }
   else
   {
#ifdef HYPERSRC_DEBUG
      g_return_if_fail(0);
#endif
   }
}

/*****************************************************************************
 * Unschedule a GTK+ idle callback.
 *
 * Parms   : pCbId (IN/OUT)
 *           Pointer to GTK+ id of callback.
 *****************************************************************************/
void
UnscheduleIdleCallback( guint* pCbId )
{
   if ( pCbId  &&  *pCbId != CALLBACK_ID_OFF )
   {
      gtk_idle_remove( *pCbId );
      *pCbId = CALLBACK_ID_OFF;
   }
   else
   {
#ifdef HYPERSRC_DEBUG
      g_return_if_fail(0);
#endif
   }
}
