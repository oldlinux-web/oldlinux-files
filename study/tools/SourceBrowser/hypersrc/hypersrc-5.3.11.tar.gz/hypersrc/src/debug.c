/******************************************************************************
 * $Id: debug.c,v 1.6 2003/01/14 21:47:14 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Functions for debugging, profiling.
 ******************************************************************************/

#include "common.h"
#include "debug.h"

/*****************************************************************************
 * For measuring execution time using GLIB, eg:
 *
 * GTimeVal timeval1;
 * GTimeVal timeval2;
 * g_get_current_time( &timeval1 );
 * [..code to measure..]
 * g_get_current_time( &timeval2 );
 * PrintUsecElapsed( &timeval1, &timeval2 );
 *****************************************************************************/
void
PrintUsecElapsed( GTimeVal* pTimeval1,
                  GTimeVal* pTimeval2 )
{
   long usecs1, usecs2;

   usecs1 = pTimeval1->tv_sec * 1000000 + pTimeval1->tv_usec;
   usecs2 = pTimeval2->tv_sec * 1000000 + pTimeval2->tv_usec;

   printf( "usecs elapsed: %d \n", abs(usecs2 - usecs1) );
}
