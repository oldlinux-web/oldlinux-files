/******************************************************************************
 * $Id: notebook.c,v 1.8 2003/01/14 21:47:14 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: notebook functions.
 ******************************************************************************/

#include "common.h"
#include "notebook.h"

#include "widgets.h"
#include "handlers.h"

/******************************************************************************
 * Create the notebook widget (to hold the tags/modules clist widgets).
 *
 * The caller is responsible for packing this widget.
 *
 * The notebook widget will occupy the left half of the main window.
 * This functions adds several other widgets to the notebook widget,
 * which should already be created.
 *
 * Parms   : pWidgetScrolledTags (GLOBAL)
 *           Added to the notebook.
 *
 *         : pWidgetScrolledModules (GLOBAL)
 *           Added to the notebook.
 ******************************************************************************/
void
CreateNotebook( void )
{
   GtkWidget*	pWidgetLabel;

  /*
   * Create the notebook widget with its tabs on top.
   */
   pWidgetNotebook = gtk_notebook_new();
   gtk_notebook_set_tab_pos( GTK_NOTEBOOK(pWidgetNotebook),
                             GTK_POS_TOP );
   gtk_notebook_set_scrollable( GTK_NOTEBOOK(pWidgetNotebook),
                                TRUE );
   gtk_notebook_popup_enable( GTK_NOTEBOOK(pWidgetNotebook) );

  /*
   * Part of a KLUDGE (see clist draw handler).
   */
   gtk_signal_connect( GTK_OBJECT(pWidgetNotebook),
                       "switch-page",
                       GTK_SIGNAL_FUNC(HandlerSwitchPageNotebook),
                       NULL );

  /*
   * Add the tags clist widget (which is contained by a scrolled widget).
   */
   pWidgetLabel = gtk_label_new( "tags" );
   gtk_notebook_append_page( GTK_NOTEBOOK(pWidgetNotebook),
                             pWidgetScrolledTags,
                             pWidgetLabel );

  /*
   * Add the modules clist widget.
   */
   pWidgetLabel = gtk_label_new( "modules" );
   gtk_notebook_append_page( GTK_NOTEBOOK(pWidgetNotebook),
                             pWidgetScrolledModules,
                             pWidgetLabel );

  /*
   * Add the tag-history clist widget.
   */
   pWidgetLabel = gtk_label_new( "history" );
   gtk_notebook_append_page( GTK_NOTEBOOK(pWidgetNotebook),
                             pWidgetScrolledHistory,
                             pWidgetLabel );

  /*
   * Install handlers for when a notebook page gains/loses focus.
   * (Installation for search results page is defered).
   */
   InstallFocusHandlers( pWidgetNotebook );
   InstallFocusHandlers( pWidgetClistTags );
   InstallFocusHandlers( pWidgetClistModules );
   InstallFocusHandlers( pWidgetClistHistory );

   return;
}

/*****************************************************************************
 * Return page enums (dynamically).
 *****************************************************************************/
int
NotebookPageTags( void )
{
   return 0;
}
int
NotebookPageModules( void )
{
   return 1;
}
int
NotebookPageHistory( void )
{
   return 2;
}
int
NotebookPageFunctions( void )
{
   if ( ! skipFuncTree )
      return 3;
   else
      return -1; /* oops */
}
int
NotebookPageFound( void )
{
   if ( skipFuncTree )
      return 3;
   else
      return 4;
}
