/******************************************************************************
 * $Id: hilite_c.c,v 1.18 2003/01/14 21:47:14 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Functions for hiliting C/C++/Java/ASM code in a text widget.
 * Notes        : Because of the huge function HiliteCString(),
 *                this code is very slow.  Slowness becomes a problem
 *                while trying to hilite a source file > 1MB because
 *                the program will appear to hang.
 ******************************************************************************/

#include "common.h"
#include "hilite_c.h"

#include "hilite.h"
#include "widgets.h"
#include "statusbar.h"
#include "text.h"

/*
 * C keywords
 */
static const char keywords_c[] =
   " if"
   " else"
   " return"
   " for"
   " while"
   " do"
   " continue"
   " break"
   " switch"
   " case"
   " default"
   " sizeof"
/* " goto"  is handled/colored specially */
   " asm"
   "                 "; /* padding just in case */

/*
 * C preprocessor keywords
 */
static const char keywords_cpreproc[] =
   " #define"
   " #ifdef"
   " #ifndef"
   " #if"
   " #else"
   " #elif"
   " #endif"
   " #include"
   " #undef"
   " #error"
   " #pragma"
   "                 "; /* padding just in case */

/*
 * C++ keywords
 */
static const char keywords_cplusplus[] =
   " catch"
   " delete"
   " inline"
   " new"
   " operator"
   " this"
   " throw"
   " try"
   "                 "; /* padding just in case */

/*
 * Java keywords
 */
static const char keywords_java[] =
   " import"
   " package"
   " extends"
   "                 "; /* padding just in case */

/*
 * ASM keywords
 */
static const char keywords_asm[] =
   /*--MASM (isn't case-sens)--*/
   " align ALIGN"
   " segment SEGMENT"
   " group GROUP"
   " equ EQU"
   " assume ASSUME"
   " macro MACRO"
   " endm ENDM"
   " extern EXTERN"
   " externdef EXTERNDEF"
   " else ELSE"
   " endif ENDIF"
   " if IF"
   " ifdef IFDEF"
   " ife IFE"
   " ifdif IFDIF"
   " ifidn IFIDN"
   " ifb IFB"
   " ifnb IFNB"
   " include INCLUDE"
   " invoke INVOKE"
   " label LABEL"
   " offset OFFSET"
   " org ORG"
   " proc PROC"
   " endp ENDP"
   " public PUBLIC"
   " rept REPT"
   " seg SEG"
   " size SIZE"
   " sizeof SIZEOF"
   " lengthof LENGTHOF"
   " textequ TEXTEQU"
   /*--UNIX as/gas--*/
   /* text/data etc should be .text/.data but '.' is parsed separately */
   " text"
   " data"
   " globl"
   " global"
   " bss"
   " space"
   " section"
   " previous"
   " code16"
   "                 "; /* padding just in case */

/*
 * C types.
 *
 * Note that including "void*" would be ineffective since alphabetic chars
 * and symbols are parsed separately.
 */
static const char types_c[] =
   " void"
   " char"
   " short"
   " int"
   " long"
   " float"
   " double"
   " const"
   " volatile"
   " register"
   " static"
   " extern"
   " signed"
   " unsigned"
   " struct"
   " union"
   " typedef"
   " enum"
   "                 "; /* padding just in case */

/*
 * C++ types.
 */
static const char types_cplusplus[] =
   " bool"
   " class"
   " friend"
   " private"
   " protected"
   " public"
   " template"
   " virtual"
   "                 "; /* padding just in case */

/*
 * Non-standard C types.
 *
 * Note that including "void*" would be ineffective since alphabetic chars
 * and symbols are parsed separately.
 */
static const char types_c_nonstd[] =
   " byte"
   " uchar"
   " uint"
   " uint8"
   " uint16"
   " uint32"
   " uint64"
   " int8"
   " int16"
   " int32"
   " int64"
   /* Linux kernel */
   " __u8"
   " __u16"
   " __u32"
   " __u64"
   " __s8"
   " __s16"
   " __s32"
   " __s64"
   " u8"
   " u16"
   " u32"
   " u64"
   " s8"
   " s16"
   " s32"
   " s64"
   /* GLIB: */
   " gpointer"
   " gconstpointer"
   " gboolean"
   " gchar"
   " guchar"
   " gint"
   " gint8"
   " gint16"
   " gint32"
   " gint64"
   " guint"
   " guint8"
   " guint16"
   " guint32"
   " guint64"
   " glong"
   " gulong"
   " gfloat"
   "                 "; /* padding just in case */

/*
 * ASM types.
 */
static const char types_asm[] =
   /*--MASM (isn't case-sens)--*/
   " dw DW"
   " db DB"
   " dd DD"
   " byte BYTE"
   " word WORD"
   " dword DWORD"
   " ptr PTR"
   " far FAR"
   " far16 FAR16"
   " far32 FAR32"
   " near NEAR"
   " near16 NEAR16"
   " near32 NEAR32"
   " low LOW"
   " lowword LOWWORD"
   " high HIGH"
   " highword HIGHWORD"
   " ascii"
   " byte"
   " char"
   " word"
   " long"
   "                 "; /* padding just in case */

/*
 * C/C++/other symbol chars.
 */
const char symbols_c_other[] =
   " ="
   " =="
   " !="
   " <"
   " >"
   " <="
   " >="
   " +"
   " -"
   " *"
   " /"
   " %"
   " ||"
   " &&"
   " ?"
   " !"
   " &"
   " |"
   " ^"
   " ~"
   " ,"
   " ["
   " ]"
   " ."
   " <<"
   " >>"
   " ++"
   " --"
   " +="
   " -="
   " *="
   " /="
   " %="
   " &="
   " ^="
   " |="
   " <<="
   " >>="
   " :"
   "                 "; /* padding just in case */

/*****************************************************************************
 * Load a text widget with hilited C/C++/ASM source code.
 *
 * Precond : The text widget must be empty and frozen.
 *
 * Returns : true if successful
 *
 * Parms   : pWidget
 *           Pointer to a text widget.
 *
 *           pBuffer
 *           Pointer to a buffer containing source code text.
 *           Buffer must have a trailing null char.
 *
 *           bufferSize
 *           Size of buffer (excluding trailing null char).
 *
 *           srcFileKind
 *           One of SRC_FILE_*
 *****************************************************************************/
gboolean
HiliteC( GtkWidget* pWidget,
         char*      pBuffer,
         int        bufferSize,
         int        srcFileKind )
{
   const char*	pc;
   const char*	pcAfter;
   const char*	pcTmp1;
   const char*	pcTmp2;
   const char*	pcPrevious;
   const char*	pcPrePastWhitespace;
   const char*	pCommentAfter;
   char*		pScratch;
   int			textWidgetSize;
   int          breakout = 0;
   static char	commentStartChars[] = "/" "*"; /* avoid preprocessor misinterpretation */ 
   static char	commentEndChars[]   = "*" "/";

#define REMAINING_BUFFER_SIZE(p)	(bufferSize - (p - pBuffer))

  /*
   * Allocate mem for a temp string as large as module buffer.
   * Will be re-used many times by lower-level functions.
   */
   pScratch = g_malloc( bufferSize );

  /*
   * Parse buffer for strings to hilite.
   */
   pcPrevious = NULL;
   for ( pc = pBuffer; pc < &pBuffer[bufferSize]; )
   {
     /*
      * Break loop if pc is stuck (due to parser bug).
      */
      if ( pc == pcPrevious )
      {
         ++breakout;
         if ( breakout > 100 )
         {
            Warning( "Hilite code is stuck." );
            WarningMalfunction();
            break;
         }
      }
      pcPrevious = pc;

     /*
      * Note: Loop should be stopped using break, not return.
      */
g_return_val_if_fail( pc >= pBuffer  &&  pc < &pBuffer[bufferSize], FALSE );

     /*
      * Has end of buffer been reached?
      */
g_return_val_if_fail( pc != NULL, FALSE );	/* should not be NULL at this point */
      if ( pc >= &pc[bufferSize]  ||  *pc == '\0' )
         break;

     /*
      * Move past whitespace, but remember prior pointer.
      */
      pcPrePastWhitespace = pc;
      pc = (char*)PastWhitespace( pc, REMAINING_BUFFER_SIZE(pc) );

     /*
      * Does only whitespace remain?
      */
      if ( pc == NULL )
      {
         gtk_text_insert( GTK_TEXT(pWidget),
                          NULL,
                          NULL,
                          NULL,
                          pcPrePastWhitespace,
                          REMAINING_BUFFER_SIZE(pcPrePastWhitespace ) );
         break;
      }

     /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

     /*
      * Is the beginning of a comment being pointed to?
      */
      if (    (pc[0] == '/'  &&  pc[1] == '*') 	/* trailing \0 obviates checking ptr near buffer end */
           || (pc[0] == '/'  &&  pc[1] == '/')
              /* UNIX asm uses '!', MASM uses ';' */
           || (srcFileKind == SRC_FILE_ASM  &&  (*pc == '!' || *pc == ';')) )
      {
         char* pCommentEndDef = commentEndChars;	/* for C comments */

        /*
         * Is this a one-line comment?
         */
         if (    (pc[0] == '/'  &&  pc[1] == '/')	/* C++ comment */
              || (srcFileKind == SRC_FILE_ASM  && (pc[0] != '/' || pc[1] != '*') ) /* unless asm file has C comment */
            )
            pCommentEndDef = "\n";

        /*
         * Parse/insert comment.
         */
         pCommentAfter = \
         HiliteComment( pWidget,
                        pcPrePastWhitespace,
                        pCommentEndDef,
                        REMAINING_BUFFER_SIZE(pcPrePastWhitespace) );

        /*
         * Was the end of the comment parsed?
         */
         if ( pCommentAfter )
         {
           /*
            * From after comment, iterate.
            */
            pc = pCommentAfter;
            continue;
         }
         else
         {
           /*
            * End of buffer must have been prematurely encountered.
            */
            break;
         }
      }

     /*
      * Is this a double-quoted string?
      */
      if ( *pc == '"' )
      {
         if ( HiliteQuotedString( pWidget,
                                  &colorString,
                                  NULL, /* default font */
                                  pcPrePastWhitespace,
                                  pc,
                                  &pBuffer[bufferSize],
                                  &pcAfter ) == FUNC_OK )
         {
            pc = pcAfter;
            continue;
         }
      }

     /*
      * Try to scoop contiguous symbol chars.
      */
      if ( ! isalpha( *pc ) )	/* perhaps non-alpha is a symbol char? */
      {
        /*
         * For each symbol char after any whitespace...
         */
         for( pcAfter = pc;
              IsCSymbolChar( *pcAfter );	/* trailing \0 obviates checking ptr near end */
              ++pcAfter )
         {
#ifdef HYPERSRC_PEDANTIC
g_return_val_if_fail( pcAfter < &pBuffer[bufferSize], FALSE );
#endif
           /*
            * Break if a dquote is found unless it is the first char.
            * If dquote is first, then the dquote was earlier determined
            * as not part of a dquoted string (eg it could be '"').
            */
            if ( *pcAfter == '"'  &&  pcAfter > pc ) break;

           /*
            * Break if a slash is found unless it is the first char.
            * If slash is first, then the slash was earlier determined
            * as not part of a comment.
            */
            if ( *pcAfter == '/'  &&  pcAfter > pc ) break;
         }

        /*
         * Were any symbol chars counted?
         */
         if ( pcAfter > pc )
         {
            gtk_text_insert( GTK_TEXT(pWidget),
                             pFontSymbol,
                             &colorSymbol,
                             NULL,
                             pcPrePastWhitespace,
                             pcAfter - pcPrePastWhitespace );
           /*
            * Move pointer, continue (stopping cases are checked above).
            */
            pc = pcAfter;
            continue;
         }

        /*
         * Fall thru.
         */
      }

     /*
      * Scoop all text until:
      * start of C comment, or symbol char (excluding dquote), or buffer end.
      */
      pcTmp1 = strstr( pc, commentStartChars );
      pcTmp2 = FindCSymbolChar( pc, REMAINING_BUFFER_SIZE(pc) );

      if ( pcTmp1 == NULL )					/* process lower ptr unless it is NULL */
         pcAfter = pcTmp2;
      else if ( pcTmp2 == NULL )
         pcAfter = pcTmp1;
      else
         pcAfter = MIN( pcTmp1, pcTmp2 );	/* neither was NULL */

      if ( pcAfter == NULL )				/* was both NULL (buffer end)? */
      {
        /*
         * Encountered buffer end.
         */
         pcAfter = &pBuffer[bufferSize];
      }

#if 0
      gtk_text_insert( GTK_TEXT(pWidget),
                       NULL,
                       NULL,
                       NULL,
                       pcPrePastWhitespace,
                       pcAfter - pcPrePastWhitespace );
#else
      HiliteCString( pWidgetTextActive,
                     pcPrePastWhitespace,
                     pcAfter - pcPrePastWhitespace,
                     pcPrePastWhitespace > pBuffer ? *(pcPrePastWhitespace-1) : 0,
                     pScratch,
                     srcFileKind );
#endif

     /*
      * Move pointer, continue (stopping cases are checked above).
      */
      pc = pcAfter;
   }

  /*
   * There's a bug here if the size of the text widget
   * does not equal the size of the buffer.
   */
   textWidgetSize = gtk_text_get_length( GTK_TEXT(pWidgetTextActive) );
#ifdef HYPERSRC_DEBUG
   if ( textWidgetSize != bufferSize )
   {
      DebugMsg( __FUNCTION__ "(): gtk_text_get_length() != bufferSize in module %s", ActiveModuleName() );
      DebugMsg( __FUNCTION__ "(): gtk_text_get_length() = %d  bufferSize = %d", textWidgetSize, bufferSize );
   }
#endif

  /*
   * Dealloc, return.
   */
   g_free( pScratch );
   return TRUE;
}

/*****************************************************************************
 * Parse a string of code (text outside of comment enclosures).
 * Insert the string as hilited text into a text widget.
 *
 * Returns : true if no errors.
 *
 * Parms   : pWidget
 *           Pointer to a text widget.
 *
 *           pStr
 *			 Pointer to a string of code (uncommented).
 *
 *           strSize
 *           Size of string of code.
 *
 *           precedingChar
 *           Pass zero if none (ie true beginning of buffer).
 *
 *           pScratch
 *           Should point to a buffer as large as corresponding module buffer.
 *
 *           srcFileKind
 *           One of SRC_FILE_*
 *
 *           pFont[Keyword,Type,Symbol,..] (GLOBAL)
 *           Hilite font (can be NULL).
 *
 *           color[Keyword,Type,Symbol,..] (GLOBAL)
 *           Hilite color.
 *****************************************************************************/
gboolean
HiliteCString( GtkWidget*  pWidget,
               const char* pStr,
               int         strSize,
               char        precedingChar,
               char*       pScratch,
               int         srcFileKind )
{
   const char*	pc = NULL;
   const char*	pWord;
   int          sizeWord;
#ifdef HYPERSRC_PEDANTIC
   int          cnt = 0;
#endif

   if ( strSize == 0 ) return TRUE;

g_return_val_if_fail( pStr && strSize > 0, FALSE );

   for ( pc = pStr;
         pc < &pStr[strSize];
         pc = (char*)PastWord( pWord, sizeWord ) )
   {
#ifdef HYPERSRC_PEDANTIC
      g_return_val_if_fail( cnt++ < 1000, FALSE );
#endif
     /*
      * Parse next word.
      */
      sizeWord = ParseWordAlphanum( pc,
                                    &pWord,
                                    strSize - (pc - pStr) );

     /*
      * If no word was parsed (or word was too big to parse),
      * insert remainder into text widget, return.
      */
      if ( sizeWord <= 0  ||  pWord == NULL )	/* ParseWord() can return negative */
      {
         gtk_text_insert( GTK_TEXT(pWidget),
                          NULL,
                          NULL,
                          NULL,
                          pc,
                          strSize - (pc - pStr) );
         return TRUE;
      }

#ifdef HYPERSRC_PEDANTIC
g_return_val_if_fail( pWord >= pc  &&  pWord < &pStr[strSize], FALSE );
#endif

     /*
      * For comparing strings, extract word into a ASCIIZ string.
      */
      memcpy( pScratch, pWord, sizeWord );
      pScratch[sizeWord] = '\0';

     /*
      * Is this word a keyword?
      */
      if ( /* C keywords */
              FindWord( keywords_c, pScratch, sizeWord )

           /* C preprocessor keywords (sometimes used by non-C src files) */
           || FindWord( keywords_cpreproc, pScratch, sizeWord )

           /* C++ keywords */
           || FindWord( keywords_cplusplus, pScratch, sizeWord )

           /* Java keywords */
           || (srcFileKind == SRC_FILE_JAVA  &&  FindWord( keywords_java, pScratch, sizeWord ))

           /* ASM keywords */
           || (srcFileKind == SRC_FILE_ASM  &&  FindWord( keywords_asm,  pScratch, sizeWord ))
         )
      {
        /*
         * Special case: don't hilite #include <asm/..>
         */
         if ( strcmp( pScratch, "asm" ) == 0  &&  pc[3] == '/' )
            goto insert_no_hilite;

        /*
         * Insert the parsed word along with preceding whitespace.
         */
         gtk_text_insert( GTK_TEXT(pWidget),
                          pFontKeyword,
                          &colorKeyword,
                          NULL,
                          pc,
                          (pWord - pc) + sizeWord );
         continue;
      }

     /*
      * Is this word a type?
      */
      if (    FindWord( types_c,         pScratch, sizeWord )
           || FindWord( types_cplusplus, pScratch, sizeWord )
           || FindWord( types_c_nonstd,  pScratch, sizeWord ) 
           || (srcFileKind == SRC_FILE_ASM  &&  FindWord( types_asm, pScratch, sizeWord ))
           || ResemblesCUserType( pScratch, sizeWord )
         )
      {
        /*
         * Don't hilite struct members (written with . or ->).
         */
         if ( precedingChar == '.'  ||  precedingChar == '>' )
         {
           /*
            * Do hilite if new lines are between struct member and this type.
            */
            if ( ! ToEol( pStr, pc - pStr + 1 ) )
               goto insert_no_hilite;
         }

        /*
         * Insert the parsed word along with preceding whitespace.
         */
         gtk_text_insert( GTK_TEXT(pWidget),
                          pFontType,
                          &colorType,
                          NULL,
                          pc,
                          (pWord - pc) + sizeWord );
         continue;
      }

     /*
      * Is this word a symbol char?
      */
      if ( FindWord( symbols_c_other, pScratch, sizeWord ) )
      {
        /*
         * Insert the parsed word along with preceding whitespace.
         */
         gtk_text_insert( GTK_TEXT(pWidget),
                          pFontSymbol,
                          &colorSymbol,
                          NULL,
                          pc,
                          (pWord - pc) + sizeWord );
         continue;
      }

     /*
      * Is this word "goto"?
      */
      if ( strcmp( pScratch, "goto" ) == 0 )
      {
        /*
         * Insert the parsed word along with preceding whitespace.
         */
         gtk_text_insert( GTK_TEXT(pWidget),
                          pFontKeyword,
                          &colorGoto,
                          NULL,
                          pc,
                          (pWord - pc) + sizeWord );
         continue;
      }

     /*
      * Is this word a label?
      * Though not originally intended, this also hilites C++ colon syntax
      * such as "MyClass::method()" and "class MyClass public: MyBaseClass {".
      */
      if ( pWord[sizeWord] == ':' )
      {
         gtk_text_insert( GTK_TEXT(pWidget),
                          pFontKeyword,  /* no special label font */
                          &colorLabel,   /* use special label color */
                          NULL,
                          pc,
                          (pWord - pc) + sizeWord );
         continue;
      }

     /*
      * This word was not recognized.
      * Using normal font/color, insert the parsed word
      * along with preceding whitespace.
      */
insert_no_hilite:
      gtk_text_insert( GTK_TEXT(pWidget),
                       NULL,
                       NULL,
                       NULL,
                       pc,
                       (pWord - pc) + sizeWord );

     /*
      * Iterate...
      */
   }

   return FALSE; /* won't reach here but stifles compiler */
}

/*****************************************************************************
 * Return TRUE if a word resembles a C user-type.
 *****************************************************************************/
gboolean
ResemblesCUserType( const char* pWord,
                    int         wordLen )
{
  /*
   * Does this word have a _t suffix?
   */
   if ( wordLen > 2  &&  pWord[wordLen-2] == '_'  &&  (pWord[wordLen-1] == 't' || pWord[wordLen-1] == 'T') )
      return TRUE;

   return FALSE;
}
