/******************************************************************************
 * $Id: popup.c,v 1.16 2003/01/14 21:47:14 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Functions for popup windows.
 ******************************************************************************/

#include "common.h"
#include "popup.h"

#include "widgets.h"

/******************************************************************************
 * Display a popup message with a single OK button.
 *
 * Parms   : pMsg
 *           Message to display.
 *
 *			 pTitle
 *           The title of the popup widget.
 *
 *           whichFont
 *           FONT_MONOSPACED or FONT_PROPORTIONAL
 ******************************************************************************/
void
Popup( char* pMsg,
       char* pTitle,
       int   whichFont )
{
   GtkWidget*	pWidgetLabel;
   GtkWidget*	pWidgetButton;
   GtkWidget*	pWidgetDialog;

  /*
   * Create a dialog window.
   */
   pWidgetDialog = gtk_dialog_new();

  /*
   * Trap the window close signal to release the grab.
   */
   gtk_signal_connect( GTK_OBJECT(pWidgetDialog),
                       "destroy",
                       GTK_SIGNAL_FUNC(PopupClosing),
                       &pWidgetDialog );
  /*
   * Title the popup.
   */
   gtk_window_set_title( GTK_WINDOW(pWidgetDialog),
                         pTitle );

  /*
   * Create a small border.
   */
   gtk_container_border_width( GTK_CONTAINER(pWidgetDialog), 5 );

  /*
   * Create a label widget for the message.
   */
   pWidgetLabel = gtk_label_new( pMsg );

  /*
   * Put padding around the label.
   */
   gtk_misc_set_padding( GTK_MISC(pWidgetLabel),
                         10,
                         10 );

  /*
   * Set the justification of the label.
   */
   gtk_label_set_justify( GTK_LABEL(pWidgetLabel),
                          GTK_JUSTIFY_LEFT );

  /*
   * Use monospaced font if specified.
   * GTK defaults to proportional fonts.
   */
   if ( whichFont == FONT_MONOSPACED )
     ChangeStyleFont( pWidgetLabel, "fixed" );

  /*
   * Add the label to the dialog.
   */
   gtk_box_pack_start( GTK_BOX( GTK_DIALOG(pWidgetDialog)->vbox),
                       pWidgetLabel,
                       TRUE,
                       TRUE,
                       0 );
  /*
   * Show the label.
   */
   gtk_widget_show( pWidgetLabel );

  /*
   * Create the OK button.
   */
   pWidgetButton = gtk_button_new_with_label( "OK" );

  /*
   * Prepare for closing the popup when OK is pressed.
   */
   gtk_signal_connect( GTK_OBJECT(pWidgetButton),
                       "clicked",
                       GTK_SIGNAL_FUNC(PopupClose),
                       pWidgetDialog );

  /*
   * Let OK be the default button.
   */
   GTK_WIDGET_SET_FLAGS( pWidgetButton,
                         GTK_CAN_DEFAULT );

  /*
   * Add the button to the dialog.
   */
   gtk_box_pack_start( GTK_BOX( GTK_DIALOG(pWidgetDialog)->action_area),
                       pWidgetButton,
                       TRUE,
                       TRUE,
                       0 );
  /*
   * Make the OK button the default.
   */
   gtk_widget_grab_default( pWidgetButton );

  /*
   * Show the button.
   */
   gtk_widget_show( pWidgetButton );

  /*
   * Show the dialog.
   */
   PositionShowDialogAtMiddle( pWidgetDialog );

  /*
   * Grab the dialog.
   */
   gtk_grab_add( pWidgetDialog );

   return;
}

/******************************************************************************
 * Callback that closes the popup window.
 ******************************************************************************/
void
PopupClose( GtkWidget* pWidget,
            gpointer   pData )
{
  /*
   * Close the popup window.
   */
   gtk_widget_destroy( GTK_WIDGET(pData) );
}

/******************************************************************************
 * Callback for when the popup window is being closed.
 ******************************************************************************/
void
PopupClosing( GtkWidget* pWidget,
              gpointer   pData )
{
  /*
   * Release the grab which made the dialog window modal.
   */
   gtk_grab_remove( GTK_WIDGET(pWidget) );
}
