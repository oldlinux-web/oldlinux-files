/******************************************************************************
 * $Id: font.c,v 1.5 2003/01/14 21:47:14 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Functions for fonts.
 ******************************************************************************/

#include "common.h"
#include "font.h"

#include "widgets.h"

/*****************************************************************************
 * Find a bold version of a base font.
 * Returns TRUE if it is available and its (XFLD) name.
 *****************************************************************************/
gboolean
FindFontBold( char*       pFontNameBold, /*OUT*/
              const char* pFontNameBase )
{
   return FindFontVariation( pFontNameBold,
                             pFontNameBase,
                             "-bold-r-",
                             "-medium-r-" );
}

/*****************************************************************************
 * Find an italic version of a base font.
 * Returns TRUE if it is available and its (XFLD) name.
 *****************************************************************************/
gboolean
FindFontItalic( char*       pFontNameItalic, /*OUT*/
                const char* pFontNameBase )
{
  /*
   * Try oblique if italic is unavailable.
   */
   if ( FindFontVariation( pFontNameItalic,
                           pFontNameBase,
                           "-medium-i-",
                           "-medium-r-" ) )
      return TRUE;

   if ( FindFontVariation( pFontNameItalic,
                           pFontNameBase,
                           "-medium-o-",
                           "-medium-r-" ) )
      return TRUE;

   return FALSE;
}

/*****************************************************************************
 * Find a variation (italic/bold) of a base font.
 * Returns TRUE if it is available and its (XFLD) name.
 *****************************************************************************/
gboolean
FindFontVariation( char*       pFontNameVar, /*OUT*/
                   const char* pFontNameBase,
                   const char* pPartVar,
                   const char* pPartBase )
{
   const char*	pc;
   int          len;

  /*
   * Try to find "-pPartBase-" in base font name.
   */
   pc = FindSubstr( pFontNameBase, pPartBase );
   if ( !pc ) return FALSE;

  /*
   * Construct a string with "-pPartBase-" replaced with "-pPartVar-".
   * Eg "-medium-r-" --> "-bold-r-"
   */
  /* to ensure string is terminated */
   bzero( pFontNameVar,
          MIN( StrLen(pFontNameBase)+20, MAX_FONT_NAME_LEN ) );
  /* copy substr preceding "-pPartBase-" */
   CopyChars( pFontNameVar,
              pFontNameBase,
              pc-pFontNameBase );
  /* append "-pPartVar-" */
   len = StrLen(pPartVar);
g_return_val_if_fail( len, FALSE );
   CopyChars( pFontNameVar + (pc-pFontNameBase),
              pPartVar,
              len );
  /* copy remainder (including null char) */
   len = StrLen(pFontNameBase) - (pc-pFontNameBase) - StrLen(pPartBase) + 1;
g_return_val_if_fail( len, FALSE );
   CopyChars( pFontNameVar + (pc-pFontNameBase) + StrLen(pPartVar),
              pc + StrLen(pPartBase),
              len );

  /*
   * Is the font available?
   */
   return gdk_font_load( pFontNameVar ) != NULL;
}
