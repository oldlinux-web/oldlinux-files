/******************************************************************************
 * $Id: funcgraph.c,v 1.46 2003/01/14 21:47:14 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Functions to build a graph of function relationships.
 * Notes        :
 ******************************************************************************/

#include "common.h"
#include "funcgraph.h"

#include "parser.h"
#include "tags.h"
#include "module.h"
#include "file.h"
#include "widgets.h"
#include "statusbar.h"

static GSList*		pGslistFuncCall		= NULL;		/* list of calls in one func def */
static char*		cur_pModuleName		= NULL;		/* current module being parsed */
static GList*		cur_pLinkModule		= NULL;		/* current module being parsed */

#if 0
#define DEBUG_ADD_TO_GRAPH_PRINTF
#endif

#if 1
#define COUNT_GRAPH
static int cntFuncDefs  = 0;
static int cntFuncCalls = 0;
#endif

/*****************************************************************************
 * Callback to free the hash table of func-like tags of one module.
 *****************************************************************************/
static void
cb_FreeHashFuncTags( gpointer pKey,
                          gpointer pData,
                          gpointer unused )
{
   module_t* pModule = (module_t*) pData;
   g_hash_table_destroy( pModule->pHashFuncTags );
   pModule->pHashFuncTags = NULL;
}

/******************************************************************************
 * Build a graph of functions.
 * (see types.h for an illustration of the graph)
 ******************************************************************************/
void
BuildFuncGraph( void )
{
   char*	pBuf		= NULL;
   guint	moduleSize  = 0;

#ifdef HYPERSRC_PEDANTIC
  /*
   * Prerequisites.
   */
   g_assert( pGlistTags );
   g_assert( pGlistModuleNames );
   g_assert( pHashModules );
   g_assert( pHashFuncTagsAll );
#endif

   pHashTagsFabricated = g_hash_table_new( g_str_hash, g_str_equal );

  /*
   * Pass the contents of each module to the function call parser.
   */
   for ( cur_pLinkModule = pGlistModuleNames;
         cur_pLinkModule;
         cur_pLinkModule = cur_pLinkModule->next )
   {
      pBuf				= NULL;
      cur_pModuleName	= (char*) cur_pLinkModule->data;
g_assert( cur_pModuleName );

      ProcessPendingEvents();

     /*
      * The parser only supports C/C++/Java source files.
      */
      if ( !IsSrcFileCish( cur_pModuleName ) )
         continue;

#if defined(HYPERSRC_DEBUG) && defined(DEBUG_ADD_TO_GRAPH_PRINTF)
      DebugMsg( "\n*******************************************************************" );
      DebugMsg( "Parsing module %s ", cur_pModuleName );
      DebugMsg( "*******************************************************************\n" );
#endif

     /*
      * Reset state before parsing another module.
      */
      pGslistFuncCall = NULL;

     /*
      * Read the contents of this module.
      */
      pBuf = ModuleBuffer( cur_pModuleName, &moduleSize );
      if ( pBuf == NULL  ||  moduleSize <= 0 )
      {
         /* --module.c has already called Warning()--*/
         /*Warning( "Couldn't open module %s for parsing.", cur_pModuleName );*/
         continue;	/* can happen if a src file is empty, eg Mesa3D has a few */
      }

#if !defined(HYPERSRC_SPEED)  &&  !defined(HYPERSRC_PROFILE)
      StartupStatusMsg( "Graphing functions: ", cur_pModuleName, " " );
#endif

     /*
      * Pass the contents of this module to the parser.
      */
      if ( IsSrcFileCPlusPlus( cur_pModuleName )  ||  IsSrcFileJava( cur_pModuleName )
           /* Try to determine if this is a C++ header file that contains classes */
           /* so that methods will appear in func trees. */
           || (    browsingCPlusPlus
                && FileSuffixMatch( cur_pModuleName, ".h" )
                && strstr( pBuf, "class" ) )
         )
      {
        /*
         * C++/Java are specially pre-processed (see PreprocessJavaCPlusPlus() ).
         */
         char*	pBuf2;
         if ( (pBuf2 = PreprocessCPlusPlusJava( pBuf, moduleSize )) )
         {
            ParseFuncsInModule( pBuf2, moduleSize, cur_pModuleName, FALSE );
            g_free( pBuf2 );
         }
      }
      else /* C */
      {
         ParseFuncsInModule( pBuf, moduleSize, cur_pModuleName, FALSE );
      }

     /*
      * To next module...
      */
      if ( conserveMemory ) FreeModuleBuffer( cur_pModuleName );
   }

#if 0
#if defined(HYPERSRC_DEBUG)  &&  !defined(DEBUG_ADD_TO_GRAPH_PRINTF)
   DumpFuncGraph();
#endif
#endif

#ifdef COUNT_GRAPH
   StatusMsg( "func defs  = %d \n", cntFuncDefs );
   StatusMsg( "func calls = %d \n", cntFuncCalls );
#endif

  /*
   * Free data structs that are no longer needed.
   */
   g_hash_table_destroy( pHashTagsFabricated );
   pHashTagsFabricated = NULL;

   g_hash_table_destroy( pHashFuncTagsAll );
   pHashFuncTagsAll = NULL;

   g_hash_table_foreach( pHashModules,
                         cb_FreeHashFuncTags,
                         NULL );
   return;
}

/*****************************************************************************
 * This is called as soon as the identifier of a function call is parsed.
 * Appends a funcCall_t struct to a list (see types.h).
 * Later, when the function definition is completely parsed,
 * AddFuncDefToGraph() will be called which will attach the func call list
 * to a funcDef_t struct.
 *****************************************************************************/
void
AddFuncCallToGraph( char* pFuncCallId,
                    int   lenFuncCallId,
                    int   line )
{
   funcCall_t*	pFuncCall;
   tag_t*		pTag;

#ifdef HYPERSRC_DEBUG /* too frequent for PEDANTIC */
   g_assert( !IsStringEmpty(cur_pModuleName) );
   g_return_if_fail( pFuncCallId  &&  StrLen(pFuncCallId) < MAX_TAG_NAME_LEN );
   g_return_if_fail( line > 0  &&  line < MAX_LINES );
#endif

#if defined(HYPERSRC_DEBUG)  &&  defined(DEBUG_ADD_TO_GRAPH_PRINTF)
   /*---DEBUG---*/
   DebugMsg( "    calls %s() line # %d ", pFuncCallId, line );
   return;
   /*---DEBUG---*/
#endif

  /*
   * Preferably, try to find the tag of the parsed function call in the current module.
   */
   pTag = FindFuncTag( pFuncCallId, pModuleLoaded );
   if ( pTag == NULL )
   {
     /*
      * Try to find first matching function (or macro) tag in any module.
      */
      pTag = FindFuncTagAnyOtherModule( pFuncCallId, cur_pLinkModule );
   }

   if ( pTag == NULL )
   {
     /*
      * Tag wasn't found, so fabricate one.
      */
      pTag = FabricateFuncCallTag( pFuncCallId, lenFuncCallId );
   }

  /*
   * Allocate a funcCall_t struct.
   */
   pFuncCall = (funcCall_t*) g_malloc( sizeof(funcCall_t) );

  /*
   * Fill struct.
   */
   pFuncCall->pTagFuncCall = pTag;

  /*
   * Append struct to func call list (which is pointed to by funcDef_t).
   * (pGslistFuncCall must be NULLified before starting to parse a func def.)
   */
   pGslistFuncCall = g_slist_append( pGslistFuncCall, pFuncCall );

#ifdef COUNT_GRAPH
   ++cntFuncCalls;
#endif

   return;
}

/*****************************************************************************
 * Appends a funcDef_t struct to a list for the module being parsed
 * (head of list is pointed to by module_t).
 *
 * This is called when the parsing of a function definition completes,
 * which typically is after multiple calls to AddFuncCallToGraph().
 *
 * Parms	: pHashModules, pModuleLoaded (OUT/GLOBAL)
 *            Updates hash item's "pGslistFuncDef" member.
 *            pModuleLoaded points to hash item of module being parsed.
 *
 *            pGslistFuncCall (OUT/GLOBAL)
 *            NULLified before returning to prepare for next time.
 *****************************************************************************/
void
AddFuncDefToGraph( char* pFuncDefId,
                   int   lineLeftBrace,
                   int   lineRightBrace )
{
   funcDef_t*	pFuncDef;
   tag_t*		pTag;

#ifdef HYPERSRC_DEBUG /* too frequent for PEDANTIC */
   g_assert( pHashModules  &&  pModuleLoaded  &&  !IsStringEmpty(cur_pModuleName) );
   g_return_if_fail( pFuncDefId  &&  StrLen(pFuncDefId) < MAX_TAG_NAME_LEN );
   g_return_if_fail( lineLeftBrace  > 0  &&  lineLeftBrace  < MAX_LINES );
   g_return_if_fail( lineRightBrace > 0  &&  lineRightBrace < MAX_LINES );
   g_return_if_fail( lineLeftBrace <= lineRightBrace );
#endif

#if defined(HYPERSRC_DEBUG)  &&  defined(DEBUG_ADD_TO_GRAPH_PRINTF)
   /*---DEBUG---*/
   DebugMsg( "  %s{} body resides at lines %d..%d \n", pFuncDefId, lineLeftBrace, lineRightBrace );
   /*---DEBUG---*/
#endif

  /*
   * Find tag of parsed function definition.
   */
   pTag = FindFuncTag( pFuncDefId, pModuleLoaded );
   if ( pTag  &&  *(guint32*)pTag->pType != ('m'|'a'<<8|'c'<<16|'r'<<24) )
   {
     /*
      * Allocate a funcDef_t struct.
      */
      pFuncDef = (funcDef_t*) g_malloc( sizeof(funcDef_t) );

     /*
      * Fill struct.
      */
      pFuncDef->pTagFuncDef		= pTag;
      pFuncDef->pGslistFuncCall = pGslistFuncCall;	/* could stay NULL if def lacks calls */
      pFuncDef->lineStart		= lineLeftBrace;
      pFuncDef->lineLast		= lineRightBrace;

     /*
      * Append struct to func def list (pointed to by module_t).
      */
      pModuleLoaded->pGslistFuncDef = \
      g_slist_append( pModuleLoaded->pGslistFuncDef,
                      pFuncDef );
#ifdef COUNT_GRAPH
   ++cntFuncDefs;
#endif
   }

  /*
   * Prepare for the next function definition.
   */
   pGslistFuncCall = NULL; /* so that g_slist_append() will create a new gslist */
   return;
}

/*****************************************************************************
 * Return FALSE if a function identifier is actually a C keyword
 * in which case it shouldn't be graphed.
 *****************************************************************************/
int
ShouldFuncIdBeGraphed( char* pFuncId )
{
  /*
   * This func must be fast as possible.
   */
   static char keywords[] = "if"      /* in order of frequency */
                            "return"
                            "sizeof"
                            "while";
#if 0 /* infrequent or filtered-out by lex: */
                            "for"
                            "switch"
                            "defined";
#endif

   return strstr( keywords, pFuncId ) == NULL;
}

/*****************************************************************************
 * Return true if the name of a function isn't of a real function.
 *****************************************************************************/
int
IgnoreFuncName( char* pFuncName )
{
  /*
   * This is called by functree and doesn't need to be fast,
   * but it needs to be thorough.
   */
   static char keywords[] = "if"      /* in order of frequency */
                            "return"
                            "sizeof"
                            "while"
                            "for"
                            "switch"
                            "defined";

   return strstr( keywords, pFuncName ) != NULL;
}

/*****************************************************************************
 * Callback for PreprocessCPlusPlusJava().
 *****************************************************************************/
static void
PreprocessCPlusPlusJava_cb( gpointer pKey,
                            gpointer pTag,
                            gpointer pBuf )
{
   char*	pc;
   int		brace;
   guint32  type4;

  /*
   * Only preprocess functions/methods (not macros).
   */
   type4 = *(guint32*) ((tag_t*)pTag)->pType;
   if ( type4 == ('m'|'a'<<8|'c'<<16|'r'<<24) )
      return;

  /*
   * Compute a pointer to the method from its line #.
   */
   pc = (char*) ToLine( pBuf, ((tag_t*)pTag)->lineInt - 1, MAX_LINE_LEN );
g_return_if_fail( pc );

  /*
   * Until outermost end brace.
   */
   for ( brace = 0; *pc; ++pc )
   {
     /*
      * Overwrite outermost braces with chars that
      * are specially interpreted by the lexer.
      * And overwrite inner braces with spaces.
      */
      if ( *pc == '{' )
      {
         if ( brace ) *pc = ' '; else *pc = '\2';
         ++brace;
      }
      else if ( *pc == '}' )
      {
         --brace;
         if ( brace ) *pc = ' '; else *pc = '\3';

         if ( brace <= 0 )
            return;
      }
   }
}

/*****************************************************************************
 * C++/Java can contain methods that are written with braces that
 * aren't on beginning of lines -- which the yacc parser can't accept.
 * To overcome this inability, a buffer containing C++/Java src
 * is preprocessed in a way the yacc parser can accept.
 *
 * Parms	: pBufIn, sizeIn
 *            Original buffer (won't be modified)
 *
 *            pModuleLoaded (GLOBAL)
 *
 * Returns  : Pointer to ## g_malloc-ed ## pre-processed buffer (same size).
 *            Caller should free it using g_free().
 *****************************************************************************/
char*
PreprocessCPlusPlusJava( const char* pBufIn,
                         int         sizeIn )
{
   char* pBufOut;

  /*
   * Modify a copy of the buffer.
   */
   pBufOut = g_malloc( sizeIn + 500 );
   memcpy( pBufOut, pBufIn, sizeIn );
   pBufOut[sizeIn] = '\0';

  /*
   * For each item in the hash table of methods in this module.
   * The hash table was built by ProcessCtags*().
   */
   if ( pModuleLoaded->pHashFuncTags )
   {
      g_hash_table_foreach( pModuleLoaded->pHashFuncTags,
                            PreprocessCPlusPlusJava_cb,
                            (gpointer) pBufOut );
   }

   return pBufOut;
}


/*==============================================================================
 *
 * DEBUG.
 *
 *==============================================================================*/


#ifdef HYPERSRC_DEBUG

/*****************************************************************************
 * For debugging, print func graph.
 *****************************************************************************/
void
DumpFuncGraph( void )
{
   g_hash_table_foreach( pHashModules, CallbackDumpFuncGraph, NULL );
}
void
CallbackDumpFuncGraph( gpointer key,
                       gpointer val,
                       gpointer unused )
{
   module_t*	pModule = (module_t*) val;
   GSList*		pGslistFuncDefDbg	= NULL;
   GSList*		pGslistFuncCallDbg	= NULL;

  /*
   * This callback is passed a hash item from the module hash table.
   */
   DebugMsg( "\n------- module '%s' ---------------------------------------",
             pModule->pModuleName );

  /*
   * Get start of list of funcDef structs (from hash item).
   */
   pGslistFuncDefDbg = pModule->pGslistFuncDef;
   if ( pGslistFuncDefDbg == NULL )
   {
      DebugMsg( "(no function definitions were parsed or tags weren't found)\n" );
      return;
   }

  /*
   * For each funcDef struct in the list.
   */
   for ( ; pGslistFuncDefDbg; pGslistFuncDefDbg = pGslistFuncDefDbg->next )
   {
      funcDef_t*	pFuncDef = pGslistFuncDefDbg->data; /* pointer to funcDef per se */

      DebugMsg( "\n  %s(){..} defined at lines %d..%d",
                pFuncDef->pTagFuncDef->pName,
                pFuncDef->lineStart,
                pFuncDef->lineLast );

     /*
      * Get start of list of funcCall structs (pointed to by this funcDef struct).
      */
      pGslistFuncCallDbg = pFuncDef->pGslistFuncCall;
      if ( pGslistFuncCallDbg == NULL )
      {
         DebugMsg( "      (no func calls were parsed or tags weren't found)" );
         continue;
      }

     /*
      * For each parsed func call.
      */
      for ( ; pGslistFuncCallDbg; pGslistFuncCallDbg = pGslistFuncCallDbg->next )
      {
         funcCall_t* pFuncCall = pGslistFuncCallDbg->data; /* pointer to funcCall per se */

         DebugMsg( "      %s() called",
                   pFuncCall->pTagFuncCall->pName );
      }
   }
}

#endif /* HYPERSRC_DEBUG */
