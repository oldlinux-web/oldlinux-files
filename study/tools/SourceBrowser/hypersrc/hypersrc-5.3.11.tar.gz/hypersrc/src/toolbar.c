/******************************************************************************
 * $Id: toolbar.c,v 1.14 2003/01/14 21:47:14 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Toolbar functions.
 ******************************************************************************/

#include "common.h"
#include "toolbar.h"

#include "handlers.h"
#include "text.h"

#include <gdk/gdk.h>
#include <gdk/gdkkeysyms.h>

/******************************************************************************
 * Create the toolbar.
 ******************************************************************************/
void
CreateToolbar( GtkWidget* pWidgetHbox )
{
  /*
   * Create the toolbar.
   */
   pWidgetToolbar = gtk_toolbar_new( GTK_ORIENTATION_HORIZONTAL,
                                     GTK_TOOLBAR_TEXT );
   gtk_toolbar_set_space_size( GTK_TOOLBAR(pWidgetToolbar), 2 );

  /*
   * Create the toolbar button "Goto Line".
   */
   pWidgetToolbarButtonGotoLine = \
   gtk_toolbar_append_item ( GTK_TOOLBAR(pWidgetToolbar),
                             " Goto Line ",
                             "goto line",
                             NULL,
                             NULL,
                             GotoLine,
                             NULL );
   gtk_toolbar_append_space( GTK_TOOLBAR(pWidgetToolbar) );

  /*
   * Create the toolbar button "Goto Tag".
   */
   pWidgetToolbarButtonGotoTag = \
   gtk_toolbar_append_item ( GTK_TOOLBAR(pWidgetToolbar),
                             " Goto Tag  F5 ",
                             "goto tag under cursor",
                             NULL,
                             NULL,
                             HandlerToolbarButtonGotoTag,
                             NULL );
   gtk_toolbar_append_space( GTK_TOOLBAR(pWidgetToolbar) );

  /*
   * Create the toolbar button "Earlier Tag".
   */
   gtk_toolbar_prepend_space( GTK_TOOLBAR(pWidgetToolbar) );
   pWidgetToolbarButtonEarlierTag = \
   gtk_toolbar_append_item ( GTK_TOOLBAR(pWidgetToolbar),
                             " Earlier Tag  F6 ",
                             "jump to earlier tag in history",
                             NULL,
                             NULL,
                             HandlerToolbarButtonEarlierTag,
                             NULL );
   gtk_toolbar_append_space( GTK_TOOLBAR(pWidgetToolbar) );

  /*
   * Create the toolbar button "Later Tag".
   */
   pWidgetToolbarButtonLaterTag = \
   gtk_toolbar_append_item ( GTK_TOOLBAR(pWidgetToolbar),
                             " Later Tag  F7 ",
                             "jump to later tag in history",
                             NULL,
                             NULL,
                             HandlerToolbarButtonLaterTag,
                             NULL );
   gtk_toolbar_append_space( GTK_TOOLBAR(pWidgetToolbar) );

  /*
   * Create the toolbar button "Find Matches".
   */
   pWidgetToolbarButtonFindMatches = \
   gtk_toolbar_append_item ( GTK_TOOLBAR(pWidgetToolbar),
                             " Find Matches F8 ",
                             "find all strings matching string under cursor",
                             NULL,
                             NULL,
                             HandlerToolbarButtonFindMatches,
                             NULL );
   gtk_toolbar_append_space( GTK_TOOLBAR(pWidgetToolbar) );

  /*
   * Create the toolbar button "Record Cursor".
   */
   gtk_toolbar_prepend_space( GTK_TOOLBAR(pWidgetToolbar) );
   pWidgetToolbarButtonRecordCursor = \
   gtk_toolbar_append_item ( GTK_TOOLBAR(pWidgetToolbar),
                             " Record Cursor F9 ",
                             "record cursor position into history",
                             NULL,
                             NULL,
                             HandlerToolbarButtonRecordCursor,
                             NULL );
   gtk_toolbar_append_space( GTK_TOOLBAR(pWidgetToolbar) );

  /*
   * Put the toolbar in the hbox.
   *
   * gtk_box_start() will place toolbar near to menubar (towards left).
   * gtk_box_end() wil place toolbar always at extreme right, and toolbar will move
   * right when main widget is resized wider.
   */
   gtk_box_pack_start( GTK_BOX( pWidgetHbox ),
                       pWidgetToolbar,
                       FALSE, FALSE, 0 );
   return;
}
