/******************************************************************************
 * $Id: text.c,v 1.171 2003/01/14 21:47:14 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Functions for the text widget.
 ******************************************************************************/

#include "common.h"
#include "text.h"

#include "module.h"
#include "file.h"
#include "widgets.h"
#include "hilite.h"
#include "statusbar.h"
#include "focusbar.h"
#include "tags.h"
#include "treefunc.h"
#include "handlers.h"

/******************************************************************************
 * Creates a text widget and ancillary widgets (vbox/scrollbar/focusbar/etc).
 * Connects to keypress/focus handlers.
 ******************************************************************************/
void
CreateTextWidgetEtAl( GtkWidget**  ppWidgetText,	/*OUT*/
                      GtkWidget**  ppWidgetVbox,	/*OUT*/
                      GtkWidget**  ppWidgetTable,	/*OUT*/
                      GtkWidget**  ppWidgetVscroll,	/*OUT*/
                      GtkWidget**  ppWidgetHscroll,	/*OUT*/
                      focusbar_t** ppFocusbar		/*OUT*/ )
{
  /*
   * Create a text widget.
   */
   *ppWidgetText = gtk_text_new( NULL, NULL );
   gtk_text_set_editable( GTK_TEXT(*ppWidgetText),
#if 1
/* ### KLUDGE: To show the cursor, text widget must be set editable. ### */
                          TRUE );
#else
                          FALSE );
#endif

  /*
   * Install a keyboard event handler.
   */
   gtk_signal_connect( GTK_OBJECT(*ppWidgetText),
                       "key-press-event",
                       (GtkSignalFunc)HandlerKeyPressText,
                       NULL );
   gtk_signal_connect( GTK_OBJECT(*ppWidgetText),
                       "key-release-event",
                       (GtkSignalFunc)HandlerKeyRelease,
                       NULL );
   gtk_widget_add_events( *ppWidgetText,
                          GDK_KEY_RELEASE_MASK );	/* to enable key release events */

  /*
   * Install handlers for when text widget gains/loses focus.
   */
   InstallFocusHandlers( *ppWidgetText );

  /*
   * Change the tab width only if specified by the command line (or GNOME config).
   * The default tab width is usually best.
   */
   ApplyTabWidth( *ppWidgetText, tabWidth );

#if 0
/* ## Scrollbars do not work using scrolled windows. ## */
   textScrolled = gtk_scrolled_window_new( NULL, NULL );
   gtk_scrolled_window_set_policy( GTK_SCROLLED_WINDOW(pWidgetTextScrolled),
                                   GTK_POLICY_ALWAYS,
                                   GTK_POLICY_ALWAYS);
   gtk_scrolled_window_add_with_viewport( GTK_SCROLLED_WINDOW(pWidgetTextScrolled),
                                          *ppWidgetText );
#endif

  /*
   * Change its color.
   */
   ChangeStyleColorText( *ppWidgetText,
                         &colorTextWidgetTextFg,
                         &colorTextWidgetTextBg );
   ChangeStyleColorSel( *ppWidgetText,
                        &colorTextWidgetSelFg,
                        &colorTextWidgetSelBg );

  /*
   * Change its font.
   */
   ChangeStyleFont( *ppWidgetText,
                    fontNameText );

  /*
   * Create a 2x2 table to hold the text widget and its scrollbars.
   */
   *ppWidgetTable = gtk_table_new( 2, 2, FALSE );

  /*
   * Attach the text window to the 2x2 table.
   */
   gtk_table_attach( GTK_TABLE(*ppWidgetTable),
                               *ppWidgetText,
                               0, 1, 0, 1,
                               GTK_EXPAND | GTK_SHRINK | GTK_FILL,
                               GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0 );

  /*
   * Create the scrollbars for the text widget.
   * Attach the scrollbars to the 2x2 table.
   */
   *ppWidgetHscroll = gtk_hscrollbar_new( GTK_TEXT(*ppWidgetText)->hadj );
   *ppWidgetVscroll = gtk_vscrollbar_new( GTK_TEXT(*ppWidgetText)->vadj );
   gtk_table_attach( GTK_TABLE(*ppWidgetTable),
                               *ppWidgetHscroll,
                               0, 1, 1, 2,
                               GTK_EXPAND | GTK_FILL | GTK_SHRINK,
                               GTK_FILL,
                               0, 0);
   gtk_table_attach( GTK_TABLE(*ppWidgetTable),
                               *ppWidgetVscroll,
                               1, 2, 0, 1,
                               GTK_FILL,
                               GTK_EXPAND | GTK_SHRINK | GTK_FILL,
                               0, 0);

  /*
   * Create a "focus bar" to be placed above the text widget.
   */
#if 0
   *ppFocusbar = FocusbarCreate( "8x13" );
#else
   *ppFocusbar = FocusbarCreate( "6x12" );
#endif

  /*
   * In focusbar, handle GDK mouse button events.
   * Since a GDK event, not a GTK+ signal, will be handled,
   * calling gtk_widget_add_events() is necessary.
   */
   gtk_signal_connect( GTK_OBJECT((*ppFocusbar)->pWidget),
                       "button-press-event",
                       (GtkSignalFunc) HandlerFocusbarButtonEvent,
                       *ppFocusbar );
   gtk_widget_add_events( (*ppFocusbar)->pWidget,
                          GDK_BUTTON_PRESS_MASK );

  /*
   * Create a 2-slot vbox to hold text widget and its "focus bar".
   */
   *ppWidgetVbox = gtk_vbox_new( FALSE, 0 );
   gtk_box_pack_start( GTK_BOX(*ppWidgetVbox),		/* pack focusbar */
                       (*ppFocusbar)->pWidget,
                       FALSE, FALSE, 2 );			/* padding to avoid clipping paned slider */
   gtk_box_pack_end( GTK_BOX(*ppWidgetVbox),		/* pack table containing text widget/scrollbars */
                     *ppWidgetTable,
                     TRUE, TRUE, 0 );

   return;
}

/*****************************************************************************
 * Connect to handlers for a text widget (main or aux).
 *****************************************************************************/
void
ConnectHandlersForTextWidget( GtkWidget* pWidget )
{
#if 0
/* HANDLER WILL NEVER BE CALLED */
/* LEFT HERE AS INFO */
   gtk_signal_connect( GTK_OBJECT(pWidget),
                       "move_cursor",
                       (GtkSignalFunc)HandlerLineNum,
                       NULL );
#endif
   gtk_signal_connect( GTK_OBJECT(pWidget),
                       "button-press-event",
                       (GtkSignalFunc)HandlerLineNum,
                       NULL );
   gtk_signal_connect( GTK_OBJECT(pWidget),
                       "key-press-event",
                       (GtkSignalFunc)HandlerLineNum,
                       NULL );
   gtk_signal_connect( GTK_OBJECT(pWidget),
                       "changed",
                       (GtkSignalFunc)HandlerLineNum,
                       NULL );
   return;
}

/*****************************************************************************
 * Apply a tab width to a text widget.
 * Does NOT redraw the text widget.
 * Does NOT affect global vars.
 *
 * Parms   : pWidget
 *           Must be a text widget.
 *
 *           width
 *****************************************************************************/
void
ApplyTabWidth( GtkWidget* pWidget,
               int        width )
{
  /*
   * Has text widget been created?
   */
   if ( pWidget == NULL ) return;

  /*
   * width can be 0 (which selects GTK+ default).
   */
   g_assert( width >= 0  &&  width < 30 );

   if ( width > 0 )
   {
     /*
      * Stolen from GXedit ;-)
      */
      GTK_TEXT(pWidget)->default_tab_width = width;
      GTK_TEXT(pWidget)->tab_stops = g_list_remove( GTK_TEXT(pWidget)->tab_stops,
                                                    GTK_TEXT(pWidget)->tab_stops->data );
      GTK_TEXT(pWidget)->tab_stops = NULL;
      GTK_TEXT(pWidget)->tab_stops = g_list_prepend( GTK_TEXT(pWidget)->tab_stops,
                                                     (gpointer)tabWidth );
   }

   return;
}

/******************************************************************************
 * Load the text widget with a module (ie source file).
 * Also moves the cursor to the specified line.
 * Frees buffer holding previous module depending on conserveMemory.
 *
 * Returns : FUNC_OK or FUNC_FAIL
 *
 * Parms   : pModuleName
 *           Name of module (typically a file name).
 *
 *           cursor
 *           Which line to move the cursor to.
 *
 *           row
 *           The associated list widget row (use ROW_NONE if N/A).
 *
 *           ActiveModule() (OUT/GLOBAL)
 *           This function will cause ActiveModule() to return
 *           the hash item of the module loaded by this function.
 *
 *           pHashModules (GLOBAL)
 *           The module hash will be updated if the text widget is copied out
 *           (into a new buffer) before being loaded with another module.
 *
 *           reload
 *           If TRUE then the text widget will be loaded, even if it already
 *           contains the requested module.
 ******************************************************************************/
FUNC_X
LoadTextWidgetWithModule( gchar*   pModuleName,
                          gint	   cursor,
                          gint     row,
                          gboolean reload )
{
   char*		pBuffer = NULL;
   guint		size;
   const char*	pLine = NULL;

  /*
   * Load the text widget only if it does not already contain the specified module
   * (or a reload is requested).
   */
   if ( reload  ||  CompareStrings( pModuleName, ActiveModuleName() ) )
   {
      RecordActiveModule( NULL );

#if 0
      CopyOutTextWidget();
#endif

     /*
      * Discard previous text buffer (if configured so).
      */
      if ( conserveMemory )
         FreeModuleBuffer( ActiveModuleName() );

     /*
      * Obtain a pointer to the buffer that holds the specified module
      * (loading it from a file if necessary).
      */
      pBuffer = ModuleBuffer( pModuleName, &size/*OUT*/ );
      if ( ! pBuffer ) return FUNC_FAIL;

     /*
      * Actually load the text widget with the module buffer.
      */
      LoadTextWidgetWithBuffer( pBuffer,
                                size,
                                WhichKindOfSrcFile( pModuleName ) );

     /*
      * Record the name of the module loaded into the text widget.
      */
      RecordActiveModuleName( pModuleName );

     /*
      * Remember hash item (to speed functree).
      */
      RecordActiveModule( pModuleLoaded );
   }
   else
   {
     /*
      * Text widget already contains the requested module.
      * Just get a pointer to its buffer (for the following).
      */
      pBuffer = ModuleBuffer( pModuleName, &size/*OUT*/ );
      if ( ! pBuffer ) return FUNC_FAIL;
   }

  /*
   * Move the cursor to the specified line.
   */
   pLine = ToLine( pBuffer, cursor, MAX_LINE_LEN );
   if ( ! pLine )
   {
     /*
      * Unable to find this line.
      */
      PrintStatusbarForRow( "This line is beyond the end.  Tag information probably is stale.",
                            row );
      return FUNC_FAIL;
   }
   ScrollTextWidgetToLine( cursor,
                           SCROLL_TEXT_VERT_FRAC );

  /*
   * Update the text widget's focusbar label, to show which module is being shown.
   */
   FocusbarLabelSet( pFocusbarTextActive, pModuleName );

   return FUNC_OK;
}

/******************************************************************************
 * Load the text widget with a memory buffer (overwriting current contents).
 *
 * (This function is generic, therefore, it is ignorant of what the buffer is.)
 *
 * Parms   : pBuffer
 *
 *           bufferSize
 *
 *           srcFileKind
 *           One of SRC_FILE_*
 ******************************************************************************/
void
LoadTextWidgetWithBuffer( gpointer pBuffer,
                          gint     bufferSize,
                          int      srcFileKind )
{
   gtk_text_freeze( GTK_TEXT(pWidgetTextActive) );

  /*
   * Clear the text widget.
   */
   ClearTextWidget();

  /*
   * Insert the buffer into the text widget.
   */
   if ( hilite  &&  srcFileKind != SRC_FILE_OTHER )
      HiliteLoadCode( pWidgetTextActive,
                      pBuffer,
                      bufferSize,
                      srcFileKind );
   else
      gtk_text_insert( GTK_TEXT(pWidgetTextActive),
                       NULL,
                       NULL,
                       NULL,
                       pBuffer,
                       bufferSize );

   gtk_text_thaw( GTK_TEXT(pWidgetTextActive) );

   return;
}

/******************************************************************************
 * Clear the text widget.
 *
 * Precond : The caller should first freeze the text widget.
 ******************************************************************************/
void
ClearTextWidget( void )
{
  /*
   * First, move the cursor to the first char.
   */
   gtk_text_set_point( GTK_TEXT(pWidgetTextActive), 0 );

  /*
   * Now, delete all following chars.
   */
   gtk_text_forward_delete( GTK_TEXT(pWidgetTextActive),
                            gtk_text_get_length( GTK_TEXT(pWidgetTextActive) ) );

   return;
}

/*****************************************************************************
 * Redraw the text widgets (unless empty).
 *****************************************************************************/
void
RedrawBothTextWidgets( void )
{
   GtkWidget*	pWidgetTextActiveSaved;

  /*
   * Redraw both the main and aux text widgets,
   * afterwards restore the active one.
   */
   pWidgetTextActiveSaved = pWidgetTextActive;

      SetActiveTextWidget( pWidgetTextMain );	/* redraw main text widget */
      RedrawActiveTextWidget();

      SetActiveTextWidget( pWidgetTextAux );	/* redraw aux text widget */
      RedrawActiveTextWidget();

   SetActiveTextWidget( pWidgetTextActiveSaved );

   return;
}
void
RedrawActiveTextWidget( void )
{
   int			line;
   gchar		moduleThatWasLoaded[MAX_FILENAME_LEN];

   if ( ! IsTextWidgetEmpty() )
   {
      line = LineAtCursor();
      strcpy( moduleThatWasLoaded, ActiveModuleName() );
      LoadTextWidgetWithModule( moduleThatWasLoaded,
                                line,
                                ROW_NONE,
                                DO_RELOAD );
   }
   return;
}

/******************************************************************************
 * Return true if the text widget is empty (or isn't created yet).
 ******************************************************************************/
int
IsTextWidgetEmpty( void )
{
   if ( pWidgetTextActive == NULL ) return TRUE;
   if ( ActiveModuleName()[0] == '\0' ) return TRUE; /* if a char is typed into a empty text widget */
   return gtk_text_get_length( GTK_TEXT(pWidgetTextActive) ) == 0;
}

/******************************************************************************
 * Return the line where the cursor is at in the text widget.
 * Returns -1 upon failure.
 ******************************************************************************/
int
LineAtCursor( void )
{
   gchar*	pText = NULL;

   if ( pWidgetTextActive == NULL ) return -1;

   pText = ActiveTextWidgetContents( NULL );
   if ( pText == NULL ) return -1;

#if 0
   return LineIdx2LineNum( pText,
                           gtk_text_get_point( GTK_TEXT(pWidgetTextActive) ) );
#else
   return LineIdx2LineNum( pText,
                           gtk_editable_get_position( GTK_EDITABLE(pWidgetTextActive) ) );
#endif
}

/******************************************************************************
 * Scroll the text widget so that a line is visible.
 * Also moves the cursor to the line.
 *
 * Parms   : line
 *           Which line # to scroll to.
 *
 *           vertFrac
 *           {0.0 ... 1.0} in which 0.0 scrolls line to top, 1.0 to bottom.
 *
 *			 pWidgetTextActive (GLOBAL)
 *
 * Notes   : This code was stolen from GXedit ;-)
 *
 * - - - - - OLD JUNK LEFT AS INFO - - - - - -
 * Skip setting an scroll increment (ie adjustment) value if the text widget
 * has only one page, otherwise, the unnecessary scroll is annoying to user.
 *
 * One page is indicated if upper == pageinc (multiple pages if upper > paginc).
 * if (   GTK_ADJUSTMENT(GTK_TEXT(pWidgetTextActive)->vadj)->upper
 *      > GTK_ADJUSTMENT(GTK_TEXT(pWidgetTextActive)->vadj)->page_increment )
 * { <if text widget is more than a page> }
 *
 * A 0.5 page_increment is what causes the scrolled-to-line
 * to be positioned at the middle of the text widget.
 * - - - - - - - - - - - - - - - - - - - - - - -
 ******************************************************************************/
void
ScrollTextWidgetToLine( gint    line,
                        gfloat vertFrac )
{
   gint				idx;
   gint				cl			= 0;		/* current line */
   gint				tl			= 0;		/* total lines */
   gint				lenText		= 0;
   gchar*			pText		= NULL;
   gfloat			adjust;
   gfloat			upper;
   gfloat			pageInc;
   GtkAdjustment*	pVadj;

g_return_if_fail( pWidgetTextActive );
   pVadj = GTK_ADJUSTMENT( GTK_TEXT(pWidgetTextActive)->vadj );
g_return_if_fail( pVadj );
g_return_if_fail( line >= 0  &&  line <= MAX_LINES );

   scrolling = TRUE;	/* reported if SIGSEGV happens */
   scrollLine = line;	/* reported if SIGSEGV happens */

  /*
   * line == 0 causes gtk_text_insert() to erratically assert.
   */
   if ( line == 0 ) line = 1;

  /*
   * Get contents of text widget.
   */
   pText = ActiveTextWidgetContents( &lenText );
   if ( pText == NULL  ||  lenText == 0 )
      goto quit; /* NULL is very unexpected, but an empty file is plausible */

   for ( idx = 0; idx < lenText; idx++ )
   {
      if ( IsEol( &pText[idx] ) ) tl++;
   }

   for ( idx = 0; idx < lenText; idx++ )
   {
      if ( IsEol( &pText[idx] ) ) cl++;
      if ( cl == line ) break;
   }
   ++idx;

  /*
   * Overshot?  If this is not checked then GTK+ will abort program!!!
   */
   if ( idx >= lenText )
      goto quit;

  /*
   * To make scrolling appear instantaneous, compute an adjustment,
   * but ensure it is within range.
   */
   upper	= pVadj->upper;
   pageInc	= pVadj->page_increment;

   if ( tl == 0 ) tl = 1; /* don't divide by zero! */

   adjust = (cl * upper) / tl - vertFrac * pageInc;

   SetAdjustmentValue( pVadj, adjust );

  /*
   * A trick to move the cursor.
   */
   gtk_editable_insert_text( GTK_EDITABLE(pWidgetTextActive),
                             " ",
                             1,
                             &idx ); /* GTK+ will increment idx */
   gtk_editable_delete_text( GTK_EDITABLE(pWidgetTextActive),
                             (idx > 0) ? idx - 1 : 0, /* ensure idx isn't negative */
                             idx );
quit:
   scrolling = FALSE;
   return;
}

/*****************************************************************************
 * Set the adjustment value of a widget.
 * The value will be forced to be within the range {lower..upper}.
 *****************************************************************************/
void
SetAdjustmentValue( GtkAdjustment* pAdj,
                    gfloat         adjust )
{
   gfloat lower;
   gfloat upper;

g_return_if_fail( pAdj );

   lower = pAdj->lower;
   upper = pAdj->upper;

   if      ( adjust < lower )
      adjust = lower;
   else if ( adjust > upper )
      adjust = upper;

   gtk_adjustment_set_value( pAdj, adjust );

   return;
}

/******************************************************************************
 * Ie emulate emacs's Ctrl+L.
 ******************************************************************************/
void
RecenterTextWidget( void )
{
  /*
   * ScrollTextWidgetToLine() will do so by passing the current line #.
   */
   if ( ! IsTextWidgetEmpty()  &&  LineAtCursor() > -1 )
   {
      ScrollTextWidgetToLine( LineAtCursor(),
                              0.5 );
   }
   return;
}

/*****************************************************************************
 * Create/show a dialog widget for jumping to a line # entered by user.
 * This is called when the user selects the menu item /Goto/Line.
 *
 * Parms   : pWidgetDialogLine (OUT/GLOBAL)
 *           Pointer to the created dialog widget for /Goto/Line.
 *****************************************************************************/
void
GotoLine( void )
{
   GtkWidget*	pWidgetHbox;
   GtkWidget*	pWidgetLabel;

  /*
   * Is the text widget empty?
   */
   if ( IsTextWidgetEmpty() )
   {
      PrintStatusbar( "Text widget is empty." );
      return;
   }

  /*
   * Create the dialog widget.
   */
   pWidgetDialogLine = gtk_dialog_new();

  /*
   * Install a key press event handler (to close dialog if ESC is pressed).
   */
   gtk_signal_connect( GTK_OBJECT(pWidgetDialogLine),
                       "key-press-event",
                       (GtkSignalFunc)HandlerKeyPressDialogLine,
                       NULL );

  /*
   * Title the dialog.
   */
   gtk_window_set_title( GTK_WINDOW(pWidgetDialogLine),
                         "Goto Line" );

  /*
   * Widen the border of the dialog.
   */
   gtk_container_border_width( GTK_CONTAINER(pWidgetDialogLine),
                               16 );

  /*
   * Create a hbox to hold the widgets of the dialog.
   */
   pWidgetHbox = gtk_hbox_new( FALSE, 8 );

  /*
   * Create/pack a label for the dialog.
   */
   pWidgetLabel = gtk_label_new( "Line: " );
   gtk_box_pack_start( GTK_BOX(pWidgetHbox),
                       pWidgetLabel,
                       TRUE, TRUE, 0 );

  /*
   * Create/pack the combo (text entry field) of the dialog.
   * Do not add pop-down strings if this is the first instance.
   * gtk_combo_disable_active() makes Enter key work as expected.
   */
   pWidgetComboLine = gtk_combo_new();
   gtk_combo_disable_activate( GTK_COMBO(pWidgetComboLine) );
   if ( pGlistLineStrings != NULL )
      gtk_combo_set_popdown_strings( GTK_COMBO(pWidgetComboLine),
                                     pGlistLineStrings );
   gtk_box_pack_start( GTK_BOX(pWidgetHbox),
                       pWidgetComboLine,
                       TRUE, TRUE, 0 );

  /*
   * Clear the text entry widget (it repeats the last item typed).
   */
   gtk_entry_set_text( GTK_ENTRY(GTK_COMBO(pWidgetComboLine)->entry),
                       "" );

  /*
   * The final pack is to pack the hbox into the dialog's vbox.
   */
   gtk_box_pack_start( GTK_BOX(GTK_DIALOG(pWidgetDialogLine)->vbox),
                       pWidgetHbox,
                       TRUE, TRUE, 0 );

  /*
   * Connect to signals.
   */
   gtk_signal_connect( GTK_OBJECT(GTK_COMBO(pWidgetComboLine)->entry),
                       "activate",
                       GTK_SIGNAL_FUNC(HandlerActivateComboLine),
                       pWidgetDialogLine );

  /*
   * Position/show the dialog (and its sub-widgets).
   */
   PositionShowDialogAtMiddle( pWidgetDialogLine );

  /*
   * Grab the focus for the entry widget.
   */
   gtk_widget_grab_focus( GTK_WIDGET(GTK_COMBO(pWidgetComboLine)->entry) );

   return;
}

/******************************************************************************
 * Highlight a line in the text widget.
 *
 * Returns false if line is invalid.
 ******************************************************************************/
gboolean
HighlightLine( int line )
{
   char*	pText;
   char*	pLine;
   char*	pLineEnd;

  /*
   * Obtain pointer to contents of text widget.
   */
   pText = ActiveTextWidgetContents( NULL );
   if ( pText == NULL ) return FALSE;

  /*
   * Compute pointer to specified line.
   */
   pLine = (char*) ToLine( pText,
                           line,
                           MAX_LINE_LEN );
   if ( pLine == NULL ) return FALSE;

  /*
   * Compute pointer to end of specified line.
   */
   pLineEnd = ToEol( pLine, MAX_LINE_LEN ) - 1;

  /*
   * Return if NULLs.
   */
   if ( pLine == NULL  ||  pLineEnd == NULL )
      return FALSE;

  /*
   * Actually highlight the line.
   */
   gtk_editable_select_region( GTK_EDITABLE(pWidgetTextActive),
                               pLine    - pText,
                               pLineEnd - pText );

   return TRUE;
}

/******************************************************************************
 * Highlight the first matching word in the current line of the text widget.
 * If unable to find a match, as a contigency, highlight the entire line.
 *
 * The GTK "point" must point to the first char of the current line,
 * as set by gtk_text_set_point().
 *
 * Parms   : pWord
 *           Pointer to word (or regex) to highlight.
 *
 *           caseSens
 *
 *           searchMethod
 *           SEARCH_NORMAL or SEARCH_REGEX
 ******************************************************************************/
void
HighlightWordInCurrentLine( const char* pWord,
                            gboolean    caseSens,
                            int         searchMethod )
{
   int		i;
   int		end;
   char*    pText = NULL;
   gchar*	pLine = NULL;			/* holds extracted line */
   int		idxLineStart;			/* index to start of current line in text widget */
   int		idxLineEndTentative;	/* likely will index past the end, TBD */
   int		found = FALSE;
   int      matchLen = 0;

  /*
   * Extract enough from the text widget to include the current line.
   * The end index (which is guessed) must be chosen so that it is not beyond
   * the end of the text widget.
   */
   idxLineStart        = gtk_text_get_point( GTK_TEXT(pWidgetTextActive) );
   idxLineEndTentative = idxLineStart + MAX_LINE_LEN;
   if ( idxLineEndTentative >= gtk_text_get_length( GTK_TEXT(pWidgetTextActive) ) )
      idxLineEndTentative = gtk_text_get_length( GTK_TEXT(pWidgetTextActive) ) - 1;
   pText = ActiveTextWidgetContents( NULL );
   if ( pText == NULL ) return;
   pLine = &pText[idxLineStart];

  /*
   * Find the index of the first matching word in the line.
   * The loop ends when the last char of the sought word
   * would hit the tentative end of the line.
   */
   end = idxLineEndTentative - idxLineStart - strlen( pWord );
   if ( end < 0 || end > MAX_LINE_LEN ) return;		/* oops, bail out */

   if ( searchMethod == SEARCH_NORMAL )
   {
      matchLen = strlen( pWord );
      for ( i = 0; i <= end; ++i )
      {
         if ( Strncmpx( &pLine[i], pWord, matchLen, caseSens ) == 0 )
         {
            found = TRUE;
            break;
         }
      }
   }
   else /* regex */
   {
      char* pMatch;
      pMatch = FindRegexSegment( &matchLen,
                                 pLine,
                                 idxLineEndTentative - idxLineStart,
                                 pWord,
                                 caseSens,
                                 FALSE, /* forward */
                                 REG_NEWLINE );
      if ( pMatch )
      {
         found = TRUE;
         i = pMatch - pLine;
         if ( i < 0 || i > MAX_LINE_LEN )
            found = FALSE; /* failsafe */         
      }
      else
      {
         found = i = FALSE;
      }
   }

  /*
   * Highlight the first match (if found).
   */
   if ( found )
   {
      SelectRegion( GTK_TEXT(pWidgetTextActive),
                    idxLineStart + i,
                    idxLineStart + i + matchLen );
      return;
   }

  /*
   * No match.  As a contigency plan, highlight the entire line.
   * Now find the exact end of the current line.
   */
   for ( i = 0; i <= (idxLineEndTentative - idxLineStart); ++i )
   {
      if ( pLine[i] == '\0'  ||  IsEol( &pLine[i] ) )
      {
         gtk_editable_select_region( GTK_EDITABLE(pWidgetTextActive),
                                     idxLineStart,
                                     idxLineStart + i );
         break;
      }
   }

   return;
}

/*****************************************************************************
 * Highlight a string in the text widget.
 *
 * The text widget will be scrolled to show the string.
 *
 * Parms   : pText
 *           Pointer to the first char of the text of the text widget.
 *
 *           idx
 *           Index of the string to highlight.
 *
 *           len
 *           Length of string to highlight.
 *****************************************************************************/
void
HighlightTextString( gchar* pText,
                     gint   idx,
                     gint   len )
{
   g_return_if_fail( pText );
   g_return_if_fail( idx >= 0  &&  idx <= MAX_LINE_LEN * MAX_LINES );
   g_return_if_fail( len > 0 /*&&  len <= MAX_LINE_LEN*/ );
                             /*^^ disabled to allow multi-line regex matches */
  /*
   * Scroll the text widget to the string.
   */
   ScrollTextWidgetToLine( LineIdx2LineNum( pText, idx ),
                           SCROLL_TEXT_VERT_FRAC );

  /*
   * Highlight the string.
   */
   SelectRegion( GTK_TEXT(pWidgetTextActive),
                 idx,
                 idx + len );

   return;
}

/*****************************************************************************
 * Highlight the tag in the text widget.
 *
 * Parms   : pTag
 *
 *           idxCursor
 *           For restoring a recorded cursor position (from history).
 *           Pass -1 if not restoring.
 *****************************************************************************/
void
HighlightTag( tag_t* pTag,
              guint  idxCursor )
{
  /*
   * Highlight the tag in the text widget.
   * ctags inserts a space between "operatorX",
   * so to ensure the highlight search works, just specify "operator".
   */
   if ( ! strstr( pTag->pName, "operator" ) )
      if ( ! strstr( pTag->pName, "(recorded position)" ) )
         if ( idxCursor != -1 )
            HighlightChar( pTag->lineInt, idxCursor );
         else
            HighlightWordInCurrentLine( pTag->pName, TRUE, SEARCH_NORMAL );
      else
         if ( idxCursor != -1 )
            HighlightChar( pTag->lineInt, idxCursor );
         else
            HighlightLine( pTag->lineInt );
   else
      HighlightWordInCurrentLine( "operator", TRUE, SEARCH_NORMAL );

   return;
}

/*****************************************************************************
 * Highlight a char in a text widget.
 *
 * Parms   : line
 *           Line # that contains the char (for scrolling).
 *
 *           idxCursor
 *           Index of char (from start of contents of text widget).
 *****************************************************************************/
void
HighlightChar( int line,
               int idxText )
{
   ScrollTextWidgetToLine( line,
                           SCROLL_TEXT_VERT_FRAC );

   SelectRegion( GTK_TEXT(pWidgetTextActive),
                 idxText,
                 idxText + 1 );
   return;
}

/*****************************************************************************
 * Print the line # in the statusbar.
 * Also returns the line # (starting with 1) or -1 if text widget is empty.
 *****************************************************************************/
int
PrintLineNum( void )
{
   char msg[20];
   int	line;

  /*
   * Skip if text widget is empty.
   */
   if ( IsTextWidgetEmpty() ) return -1;

  /*
   * Print the line # in the statusbar.
   */
   line = LineAtCursor() + 1;
   sprintf( msg, " line: %d", line ); /* !!! Change PrintStatusbar() if the below parm #2 is changed !!! */
   PrintStatusbar( msg );

   return line;
}

/*****************************************************************************
 * Prints the line # in the statusbar, and updates the functree.
 * Called by GTK+ when GTK+ is idle, then shuts off.
 * Does nothing if the text widget is empty.
 *****************************************************************************/
gint
IdleLineNum( gpointer dontCare )
{
  int	line;

  /*
   * Returning zero causes GTK+ to stop calling this idle func.
   *
   * Is the text widget empty?
   */
   if ( IsTextWidgetEmpty() ) return FALSE;

   line = PrintLineNum();

  /*
   * Update functree if necessary.
   */
   if ( !IsAnyMajorFunctionBusy(0)  &&  !IsAnyTreeFunctionBusy() )
      UpdateFuncTree( line, FALSE );

   return FALSE;  /* FALSE tells GTK+ to stop calling an idle callback */
}

/*****************************************************************************
 * Select a region in a text widget.
 *****************************************************************************/
static GtkText*	 selectRegion_pGtkText;
static int		 selectRegion_idxStart;
static int		 selectRegion_idxEnd;

void
SelectRegion( GtkText* pGtkText,
              int      idxStart,
              int      idxEnd )
{
g_return_if_fail(     pGtkText
                  &&  idxStart >= 0
                  &&  idxEnd   > idxStart
                  &&  idxEnd   < MAX_TEXT_BUFFER_LEN
                  &&  idxEnd   < ActiveTextWidgetSize() );

   selectRegion_pGtkText	= pGtkText;
   selectRegion_idxStart	= idxStart;
   selectRegion_idxEnd		= idxEnd;

  /*
   * KLUDGE:
   * The highlight on the selection often will disappear if
   * gtk_editable_select_region() is called immediately after
   * gtk_editable_set_position().  Processing events in between
   * the two ensures the highlight stays, but for stability,
   * use an idle function rather than ProcessPendingEvents().
   */
#if 1
   gtk_editable_set_position( GTK_EDITABLE( GTK_WIDGET(pGtkText) ),
                              idxStart );
#endif

   gtk_idle_add( IdleSelectRegion, NULL );

   return;
}
gint
IdleSelectRegion( gpointer unused )
{
   gtk_editable_select_region( GTK_EDITABLE(selectRegion_pGtkText),
                               selectRegion_idxStart,
                               selectRegion_idxEnd );

   return FALSE;  /* FALSE tells GTK+ to stop calling an idle callback */
}

/*****************************************************************************
 * Return index of cursor of text widget.
 * Caller should ensure text widget is not empty!
 *****************************************************************************/
guint
TextCursorIdx( void )
{
g_assert( ! IsTextWidgetEmpty() );

#if 1
   return gtk_editable_get_position( GTK_EDITABLE(pWidgetTextActive) );
#else
   return gtk_text_get_point( GTK_TEXT(pWidgetTextActive) );
#endif
}

/******************************************************************************
 * Return true if cursor is over a word in the text widget.
 ******************************************************************************/
gboolean
IsCursorOverWord( void )
{
   gchar*	pText	= NULL;

   if ( IsTextWidgetEmpty() ) return FALSE;

  /*
   * Obtain pointer to contents of text widget.
   */
   pText = ActiveTextWidgetContents( NULL );
   if ( pText == NULL ) return FALSE;

  /*
   * Return whether cursor is over a char which is/isnt part of a word.
   */
   return IsTagChar( pText[gtk_editable_get_position( GTK_EDITABLE(pWidgetTextActive))] );
}

/*****************************************************************************
 * Scoop the word which the cursor is over (in text widget).
 *
 * Parms   : maxWordLen
 *           Returns failure if word is larger.
 *
 *           pText
 *           Pointer to word extracted from text widget.
 *
 *           textLen
 *           Length of word extracted from text widget.
 *
 *           idxCursor
 *           Index of cursor
 *
 * Returns : Pointer to a GString, or NULL.
 *****************************************************************************/
GString*
ScoopWordAtCursor( int   maxWordLen,
                   char* pText,
                   int   textLen,
                   int   idxCursor )
{
   GString* pGstr	= NULL;
   int		idxWordStart;
   int		idxWordEnd;
   int		i;

   g_assert(    pText
             && textLen > 0
             && textLen < MAX_TEXT_BUFFER_LEN
             && idxCursor >= 0
             && idxCursor <= textLen );		/* GTK lets cursor idx equal text len */

   idxWordStart = idxCursor;

  /*
   * Is the cursor is over a non-word char (ie whitespace)?
   */
   if ( ! IsWordChar( pText[idxWordStart] ) )
      return NULL;

  /*
   * Compute idxWordStart.
   *
   * If the cursor looks like it is over the middle of a word,
   * then scan backwards for the start of the word.
   */
   for ( i = 0; i < maxWordLen; ++i )
   {
     /*
      * To next preceding char.
      */
      --idxWordStart;

     /*
      * Break if encountered the first preceding non-word char,
      * or beginning of text widget.
      */
      if (    (idxWordStart < 0)
           || (! IsWordChar( pText[idxWordStart] )) )
      {
        /*
         * Move index forward to start of word, break.
         */
         ++idxWordStart;
         break;
      }

     /*
      * Index is still at a word char.
      * Break if the index is now 0 (word is at beginning of text widget).
      */
      if ( idxWordStart == 0 ) break;
   }
   if ( i >= maxWordLen ) return NULL;

  /*
   * Compute idxWordEnd.
   */
   idxWordEnd = idxWordStart + 1;
   for ( i = 0; i < maxWordLen; ++i )
   {
     /*
      * Break if end of text reached.
      */
      if ( idxWordEnd >= textLen )
      {
         idxWordEnd = textLen - 1;
         break;
      }

     /*
      * Scan until the first non-word char that trails the word.
      */
      if ( ! IsWordChar( pText[idxWordEnd] ) )
      {
         --idxWordEnd;
         break;
      }

     /*
      * Forward to next char.
      */
      ++idxWordEnd;
   }
   if ( i >= maxWordLen ) return NULL;

  /*
   * Abort if the indexes were somehow miscomputed.
   */
   g_assert(    idxWordEnd >= idxWordStart
             && (idxWordEnd - idxWordStart + 1) > 0
             && (idxWordEnd - idxWordStart + 1) <= maxWordLen );

  /*
   * Copy the word into a GString.
   */
   pGstr = CreateGString( &pText[idxWordStart],
                          &pText[idxWordEnd] - &pText[idxWordStart] + 1 );

  /*
   * Return GString.
   */
   return pGstr;
}

/*****************************************************************************
 * Record the current position in the text widget.
 *
 * Parms   : pCursor (OUT)
 *           Pointer to a struct that defines state of the cursor position.
 *****************************************************************************/
void
SaveCursor( cursor_t* pCursor )
{
  /*
   * If text widget is empty then invalidate struct, silently return.
   */
   if ( IsTextWidgetEmpty()  ||  !pWidgetTextActive )
   {
      pCursor->valid = FALSE;
      return;
   }

  /*
   * Fill the passed cursor_t struct.
   */
   pCursor->valid           = TRUE;
   pCursor->pWidgetText     = pWidgetTextActive;
   pCursor->adjustmentValue = GTK_ADJUSTMENT(GTK_TEXT(pWidgetTextActive)->vadj)->value;
   pCursor->idxCursor       = TextCursorIdx();
   strncpy( pCursor->module, ActiveModuleName(), MAX_FILENAME_LEN );

   return;
}

/*****************************************************************************
 * Restore the current position in the text widget.
 *
 * Parms   : pCursor (IN)
 *           Pointer to a struct that defines state of the cursor position.
 *****************************************************************************/
void
RestoreCursor( cursor_t* pCursor )
{
  /*
   * Quit if cursor_t struct is not valid
   * (if so, text widget was empty when SaveCursor() was called)
   */
   if ( ! pCursor->valid )
      return;

  /*
   * Did user switch to the other text widget?
   * If so, then return, because the state in cursor_t is N/A.
   */
   if ( pCursor->pWidgetText != pWidgetTextActive )
      return;

  /*
   * This func will only load a module if the text widget
   * is not already holding it.
   */
   LoadTextWidgetWithModule( pCursor->module,
                             0,
                             ROW_NONE,
                             DONT_RELOAD );

  /*
   * Restore the cursor position and the state of the text widget.
   */
   SetAdjustmentValue( GTK_ADJUSTMENT(GTK_TEXT(pWidgetTextActive)->vadj),
                       pCursor->adjustmentValue );
   gtk_editable_set_position( GTK_EDITABLE(pWidgetTextActive),
                              pCursor->idxCursor );

   return;
}

/*****************************************************************************
 * Return a pointer to active text widget's contents.
 * !!! DO NOT TRY TO FREE THE CONTENTS USING G_MALLOC() !!!
 *
 * Returns	: NULL if failure (unexpected).
 *
 * Parms	: pSizeOut (OUT)
 *            Pass NULL if size isn't wanted.
 *****************************************************************************/
char*
ActiveTextWidgetContents( guint* pSizeOut )
{
   char*	pBuf;
   guint	bufSize;

   pBuf = ModuleBuffer( ActiveModuleName(), &bufSize );

  /*
   * Return size if requested.
   */
   if ( pSizeOut )
   {
      if ( pBuf )
         *pSizeOut = bufSize;
      else
         *pSizeOut = 0; /* oops, ModuleBuffer() failed */
   }
      
   return pBuf;
}

/*****************************************************************************
 * Return size of module loaded in active text widget.
 *****************************************************************************/
guint
ActiveTextWidgetSize( void )
{
   if ( pWidgetTextActive  &&  !IsStringEmpty( ActiveModuleName() ) )
   {
#ifdef HYPERSRC_DEBUG
guint bufSize = 0;
guint lenText = gtk_text_get_length( GTK_TEXT(pWidgetTextActive) );
char* pBuf    = ModuleBuffer( ActiveModuleName(), &bufSize );
g_return_val_if_fail( pBuf  &&  lenText == bufSize, lenText );
#endif
      return gtk_text_get_length( GTK_TEXT(pWidgetTextActive) );
   }

   return 0;
}

/*****************************************************************************
 * Set the active text widget (the one that will be hyperjumped into).
 * Pass pWidgetTextMain[Aux].
 * This doesn't affect focus (which GiveFocusToTextWidget() is meant for).
 *****************************************************************************/
void
SetActiveTextWidget( GtkWidget* pWidget )
{
g_return_if_fail( pWidget );

   if ( pWidget == pWidgetTextMain )
   {
      pWidgetTextActive   = pWidgetTextMain;
      pFocusbarTextActive = pFocusbarTextMain;
   }
   else if ( pWidget == pWidgetTextAux )
   {
      pWidgetTextActive   = pWidgetTextAux;
      pFocusbarTextActive = pFocusbarTextAux;
   }
   else
      g_return_if_fail(0);
}

/*****************************************************************************
 * Give the focus to a text widget.
 * Pass pWidgetTextMain[Aux].
 *****************************************************************************/
void
GiveFocusToTextWidget( GtkWidget* pWidget )
{
g_return_if_fail( pWidget );

  /*
   * Avoid endless cycle with HandlerFocusIn() which calls this function!
   */
   if ( pWidget == pWidgetTextMain )
   {
      if ( pWidgetWithFocus != pWidgetTextMain )
         gtk_widget_grab_focus( pWidgetTextMain );
   }
   else if ( pWidget == pWidgetTextAux )
   {
      if ( pWidgetWithFocus != pWidgetTextAux )
         gtk_widget_grab_focus( pWidgetTextAux );
   }
   else
      g_return_if_fail(0);
}

/*****************************************************************************
 * Switch the active text widget if the aux text key is pressed.
 *
 * Parms	: howtoSwitch
 *            Pass DONT_SWITCH_UNLESS_AUX_TEXT_KEY or SWITCH_PER_AUX_TEXT_KEY.
 *****************************************************************************/
void
SwitchActiveTextWidget( int howtoSwitch )
{
  /*
   * Disregard passed parameter unless user has set a preference
   * (if so, then textWidgetBehavior != SWITCH_PER_AUX_TEXT_KEY)
   * to hyperjump in text widget that has the focus.
   */
   if (    textWidgetBehavior == SWITCH_PER_AUX_TEXT_KEY
        || howtoSwitch        == SWITCH_PER_AUX_TEXT_KEY )
   {
     /*
      * Disregard focus, activate either text widget based on whether
      * the aux text key is pressed or released.
      * This makes sense when the user has the cursor in one text widget
      * but wants to hyperjump in the other widget by pressing F5 or Shift+F5.
      */
      SetActiveTextWidget( !auxKeyPressed ? pWidgetTextMain : pWidgetTextAux );
   }
   else if ( howtoSwitch == DONT_SWITCH_UNLESS_AUX_TEXT_KEY )
   {
     /*
      * Let whichever text widget has the focus remain activated,
      * unless the aux text key is pressed by user.
      * Eg, this makes sense when the user clicks one of the text widgets
      * and uses Find/Module, and wants the module to be loaded into
      * text widget that was clicked (that has the focus).
      */
      if ( auxKeyPressed ) SetActiveTextWidget( pWidgetTextAux );
   }
   else
   {
      g_return_if_fail(0);
   }
}

/*****************************************************************************
 * Functions for assigning/obtaining the name of the module loaded
 * in either the main or aux text widget.
 *****************************************************************************/

static gchar moduleInTextMain[MAX_FILENAME_LEN] = "";	/* shouldn't be used elsewhere */
static gchar moduleInTextAux[MAX_FILENAME_LEN]  = "";

void
RecordActiveModuleName( char* pModuleName )
{
   if ( pWidgetTextActive == pWidgetTextMain )
   {
      strncpy( moduleInTextMain, pModuleName, MAX_FILENAME_LEN  );
   }
   else if ( pWidgetTextActive == pWidgetTextAux )
   {
      strncpy( moduleInTextAux, pModuleName, MAX_FILENAME_LEN );
   }
   else g_assert(0);
}
char*
ActiveModuleName( void )
{
   if ( pWidgetTextActive == pWidgetTextMain )
   {
      return moduleInTextMain;
   }
   else if ( pWidgetTextActive == pWidgetTextAux )
   {
      return moduleInTextAux;
   }
   else { g_assert(0); return NULL; }
}

/*****************************************************************************
 * Functions for recording/obtaining information about the module displayed
 * in the main/aux text widget.
 *****************************************************************************/

static module_t* pModuleTextMain;	/* shouldn't be used elsewhere */
static module_t* pModuleTextAux;

void
RecordActiveModule( module_t* pModule ) /* NULL is allowed */
{
   if ( pWidgetTextActive == pWidgetTextMain )
   {
      pModuleTextMain = pModule;
   }
   else if ( pWidgetTextActive == pWidgetTextAux )
   {
      pModuleTextAux = pModule;
   }
   else g_assert(0);
}
module_t*
ActiveModule( void )
{
   if ( pWidgetTextActive == pWidgetTextMain )
   {
      return pModuleTextMain;
   }
   else if ( pWidgetTextActive == pWidgetTextAux )
   {
      return pModuleTextAux;
   }
   else { g_assert(0); return NULL; }
}
