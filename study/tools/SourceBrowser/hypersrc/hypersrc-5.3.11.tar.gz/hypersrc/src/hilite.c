/******************************************************************************
 * $Id: hilite.c,v 1.73 2003/01/14 21:47:14 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Functions for hiliting src code in a text widget.
 ******************************************************************************/

#define DEFINE_HILITE_GLOBALS
#include "common.h"
#include "hilite.h"

#include "hilite_c.h"
#include "hilite_forth.h"
#include "hilite_perl.h"
#include "widgets.h"
#include "statusbar.h"
#include "text.h"

/*****************************************************************************
 * Load a text widget with highlighted source code.
 *
 * Precond : The text widget must be empty and frozen.
 *
 * Parms   : pWidget
 *           Pointer to a text widget.
 *
 *           pBuffer
 *           Pointer to a buffer containing source code text.
 *           Buffer must have a trailing null char.
 *
 *           bufferSize
 *           Size of buffer (excluding trailing null char).
 *
 *           srcFileKind
 *           One of SRC_FILE_*
 *****************************************************************************/
void
HiliteLoadCode( GtkWidget* pWidget,
                char*      pBuffer,
                int        bufferSize,
                int        srcFileKind )
{
   gboolean	hilited = FALSE;

  /*
   * Load fonts.
   * (Must be done every time, in case user selects different fonts.)
   */
   pFontComment = gdk_font_load( fontNameHiliteComment );
   pFontKeyword = gdk_font_load( fontNameHiliteKeyword );
   pFontType    = gdk_font_load( fontNameHiliteType );
   pFontSymbol  = gdk_font_load( fontNameHiliteSymbol );

  /*
   * Ensure the buffer is terminated by a null char,
   * otherwise the parsing of it would overrun.
   */
g_return_if_fail( pBuffer[bufferSize] == '\0' );

  /*
   * Is buffer tiny or too big?
   * This code is so slow that trying to hilite a source file > 1MB
   * will make the program appear to hang.
   */
   if ( bufferSize < 10  ||  bufferSize > MAX_HILITE_BUFFER_LEN )
   {
      gtk_text_insert( GTK_TEXT(pWidget),
                       NULL,
                       NULL,
                       NULL,
                       pBuffer,
                       bufferSize );

      if ( bufferSize > MAX_HILITE_BUFFER_LEN )
         PrintStatusbar( "Buffer is too large to highlight." );

      return;
   }

  /*
   * Switch to a language-specific function that
   * will load a text widget with hilited src code.
   */
   switch ( srcFileKind )
   {
      case SRC_FILE_C:
      case SRC_FILE_CPLUSPLUS:
      case SRC_FILE_JAVA:
      case SRC_FILE_ASM:  /* asm files often sent to C preprocessor */
         hilited = HiliteC( pWidget, pBuffer, bufferSize, srcFileKind );
         break;

      case SRC_FILE_FORTH:
         hilited = HiliteForth( pWidget, pBuffer, bufferSize, srcFileKind );
         break;

      case SRC_FILE_PERL:
         hilited = HilitePerl( pWidget, pBuffer, bufferSize, srcFileKind );
         break;

      default:
         hilited = TRUE; /* just lie -- Bill Clinton */
         gtk_text_insert( GTK_TEXT(pWidget),
                          NULL,
                          NULL,
                          NULL,
                          pBuffer,
                          bufferSize );
         break;
   }

   if ( !hilited )
   {
     /*
      * Hiliting failed.
      * Plan B: insert text without hiliting.
      */
      ClearTextWidget();
      gtk_text_insert( GTK_TEXT(pWidget),
                       NULL,
                       NULL,
                       NULL,
                       pBuffer,
                       bufferSize );
   }

   return;
}

/*****************************************************************************
 * Parse the comment that is being pointed to.
 * Insert the comment as hilited text into a text widget.
 *
 * Parms   : pWidget
 *           Pointer to a text widget.
 *
 *           pCommentStartApprox
 *           This can point to either the exact start of a comment (to "/"),
 *           or can point to whitespace that precedes the comment.
 *
 *			 pCommentEndDef
 *           Pointer to a string that defines what the end of comment is.
 *           Eg, "/""*" or "\n" for C or C++, resp.
 *
 *           bufferSize
 *           Size of buffer, measurement based on "pCommentStart" as the start.
 *
 *           pFontComment (GLOBAL)
 *           Hilite font (can be NULL).
 *
 *           colorComment (GLOBAL)
 *           Hilite color.
 *
 * Returns : If a comment end was present, returns a pointer after it,
 *           or returns NULL.
 *****************************************************************************/
const char*
HiliteComment( GtkWidget*  pWidget,
               const char* pCommentStartApprox,
               const char* pCommentEndDef,
               int         bufferSize )
{
   char*	pCommentEnd;
   int      commentLen;

#ifdef HYPERSRC_PEDANTIC
g_return_val_if_fail( pCommentStartApprox  &&  pCommentStartApprox[0]  &&  bufferSize > 0, NULL );
#endif

  /*
   * Try to find end of comment.
   */
   pCommentEnd = strstr( pCommentStartApprox, pCommentEndDef );

  /*
   * Compute length of comment.
   * If the comment epilogue is missing then use end-of-buffer.
   */
   if ( pCommentEnd != NULL )
      commentLen = (pCommentEnd + strlen(pCommentEndDef)) - pCommentStartApprox;
   else
      commentLen = bufferSize;

  /*
   * Insert comment into text widget.
   */
   gtk_text_insert( GTK_TEXT(pWidget),
                    pFontComment,
                    &colorComment,
                    NULL,
                    pCommentStartApprox,
                    commentLen );

  /*
   * Return pointer to after end of comment, or NULL.
   */
   if ( pCommentEnd )
      return pCommentEnd + strlen(pCommentEndDef);
   else
      return NULL;
}

/*****************************************************************************
 * Hilite a double-quoted string.
 *
 * Parms   : pWidget
 *           Pointer to a text widget.
 *
 *           pFont
 *           Hilite font (NULL can be passed).
 *
 *           pColor
 *           Hilite color (NULL can be passed).
 *
 *           pStart
 *           Actual start of string (typically, contains leading whitespace).
 *
 *           pDquote1
 *           Pointer to first dquote.
 *
 *           pBufEnd
 *           Pointer to end of buffer.
 *
 *           pAfter (OUT)
 *           Points to next char after the ending dquote.
 *
 * Returns : FUNC_OK if successful.
 *****************************************************************************/
FUNC_X
HiliteQuotedString( GtkWidget*   pWidget,
                    GdkColor*    pColor,
                    GdkFont*     pFont,
                    const char*  pStart,
                    const char*  pDquote1,
                    const char*  pBufEnd,
                    const char** ppAfter /*OUT*/ )
{
   const char* pc;
   const char* pEol;
   const char* pDquote2;

#ifdef HYPERSRC_PEDANTIC
   if (    pStart == NULL
        || pDquote1 == NULL
        || pBufEnd == NULL
        || pDquote1 < pStart
        || pDquote1 >= pBufEnd )
   {
      WarningMalfunction();
      return FUNC_FAIL;
   }
#endif

  /*
   * Ensure first dquote is pointed to.
   */
   if ( *pDquote1 != '"' ) return FUNC_FAIL;

  /*
   * Find second dquote.  Ignore \"
   */
   pEol = ToEol( pDquote1, pBufEnd-pDquote1 );
   if ( pEol == NULL ) return FUNC_FAIL;

   pDquote2	= NULL;
   for ( pc = pDquote1+1; pc < pEol; ++pc )		/* skip first dquote */
   {
      if ( *pc == '"'  &&  *(pc-1) != '\\' )	/* ignore \" */
      {
         pDquote2 = pc;
         break;
      }
   }
   if ( pDquote2 == NULL ) return FUNC_FAIL;	/* was second dquote found? */

  /*
   * Insert dquoted string and any leading whitespace.
   */
   gtk_text_insert( GTK_TEXT(pWidget),
                    pFont,
                    pColor,
                    NULL,
                    pStart,
                    pDquote2 - pStart + 1 );

   *ppAfter = pDquote2 + 1;
   return FUNC_OK;
}

/*****************************************************************************
 * Search for an exact word in a string of words (the entire word must match).
 * Each word in the string must be separated by a leading space,
 * to avoid matches on part of a word.
 *
 * Parms   : pWords
 *           String of words (each word must be preceded by a space).
 *
 *           pSought, soughtLen
 *           Word that is sought (matched against words in pWords).
 *****************************************************************************/
int
FindWord( const char* pWords,
          char*       pSought,
          int         soughtLen )
{
   char*		pMatch;
   const char*	pWordsNext;
   int			i;

#ifdef HYPERSRC_PEDANTIC
   if ( pWords[0] != ' ' )
   {
      DebugMsg( __FUNCTION__ "() was passed an incorrect string of words." );
      return FALSE;
   }
#endif

   pWordsNext = pWords;

   for ( i = 0; i < 100; i++ ) /* prevent infinite loop */
   {
      pMatch = strstr( pWordsNext, pSought );

      if ( pMatch == NULL )
         return FALSE;

     /*
      * If the word matches exactly, there should be a leading space -and-
      * either a trailing space or null char.
      */
      if (    *(pMatch-1) == ' '
           && ( pMatch[soughtLen] == ' '  ||  pMatch[soughtLen] == 0 ) )
         return TRUE;

     /*
      * Move past the impartial match.
      */
      pWordsNext = pMatch + soughtLen;

#ifdef HYPERSRC_PEDANTIC
      if ( pWordsNext > (pWords + strlen(pWords)) )
      {
         DebugMsg( "pWordsNext > (pWords + strlen(pWords))" );
         return FALSE;
      }
#endif
   }

   DebugMsg( "Stopping infinite loop in FindString()." );
   return FALSE;
}
