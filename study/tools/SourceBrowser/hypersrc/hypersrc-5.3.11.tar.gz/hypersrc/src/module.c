/******************************************************************************
 * $Id: module.c,v 1.43 2003/01/14 21:47:14 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Functions for managing source code modules (ie files).
 ******************************************************************************/

#include "common.h"
#include "module.h"

#include "file.h"
#include "tags.h"
#include "statusbar.h"

/******************************************************************************
 * Returns a buffer that holds a source code module.
 * Inserts (or updates) a module_t struct into a hash.
 *
 * The buffer has a null char appended that is NOT accounted in the module size.
 *
 * To free the buffer, call FreeModuleBuffer() !!!not g_free()!!!
 *
 * Returns : Pointer to memory buffer allocated by ** g_malloc() **
 *           -or- NULL upon failure.
 *
 * Parms   : pModuleName
 *           Name of module.
 *
 *           pModuleSize (OUT)
 *           Size of module (undefined if module could not be loaded).
 *           This does NOT account a null char that was appended to buffer.
 *
 *           pModuleLoaded (GLOBAL/OUT)
 *           Updated.
 *
 *           pHashModules (GLOBAL/OUT)
 *           Updated.
 *
 * Notes   : When a module is loaded, its buffer is defined by a hashed module_t struct.
 *           Prior to ever loading any module, the tags processing code has built
 *           a hash table of module_t structs (pHashModule) for every module.
 *           Among other things, a module_t holds the buffer's ptr/size.
 *           ## module_t structs are NEVER FREED!! ##
 *           ModuleBuffer() and FreeModuleBuffer() only modify ptr/size in module_t.
 ******************************************************************************/
char*
ModuleBuffer( gchar* pModuleName,
              guint* pModuleSize /* OUT */ )
{
   *pModuleSize = 0;

g_return_val_if_fail( IsStringValid( pModuleName, MAX_FILENAME_LEN ), NULL );

  /*
   * The corresponding module_t struct must be in the hash since
   * the tags processing code hashed a module_t for every module.
   */
   pModuleLoaded = (module_t*) g_hash_table_lookup( pHashModules, pModuleName );
g_return_val_if_fail( pModuleLoaded, NULL );

  /*
   * Is the sought module still in a memory buffer?
   * The buffer might have been freed by FreeModuleBuffer().
   * Check only the buffer ptr (size could be zero if a file was empty).
   */
   if ( pModuleLoaded->pModuleBuffer )
   {
     /*
      * Return pointer/size of buffer.
      */
      *pModuleSize = pModuleLoaded->moduleSize;
      return pModuleLoaded->pModuleBuffer;
   }

  /*
   * Load the module into a buffer
   * Note that LoadFile() will append an UNACCOUNTED null char
   * in case other code depends on a trailing null char.
   *
   * For the hashed module_t struct, only update the buffer ptr/size members,
   * leave the rest unchanged!
   */
   pModuleLoaded->pModuleBuffer = LoadFile( pModuleName, pModuleSize /*OUT*/ );
   pModuleLoaded->moduleSize    = *pModuleSize;

   if ( pModuleLoaded->pModuleBuffer == NULL )
   {
     /*
      * Oops, couldn't open the module.
      */
      PrintStatusbarThirds( "Could not open module '", pModuleName, "'." );
      if ( FileSize( pModuleName ) == 0 )
         Warning( "module %s is empty. ", pModuleName );
      else
         Warning( "couldn't open module %s ", pModuleName );
      return NULL;
   }

  /*
   * Does this appear to be a MSDOG file?
   */
   if ( memchr( pModuleLoaded->pModuleBuffer, CHAR_CR, MIN(MAX_LINE_LEN,*pModuleSize) ) )
   {
      char* pBufferNew;
      int   bufferNewSize;

     /*
      * Create a new buffer minus CR chars, then free old buffer.
      */
      if ( FilterMsdosCr( pModuleLoaded->pModuleBuffer,
                          *pModuleSize,
                          &pBufferNew,
                          &bufferNewSize ) == FUNC_OK )
      {
         g_free( pModuleLoaded->pModuleBuffer );
         pModuleLoaded->pModuleBuffer                = pBufferNew;
         pModuleLoaded->moduleSize    = *pModuleSize = bufferNewSize;
      }
      /*
       * Continue if FilterMsdosCr() failed.
       */
   }

#ifdef HYPERSRC_PEDANTIC
  /*
   * Check if a null char exists within the buffer,
   * because code which parses buffers would malfunction.
   * LoadFile() has appended the buffer with a null char.
   */
 {
   char* pNull = strchr( pModuleLoaded->pModuleBuffer, '\0' );
   if ( pNull < (char*)pModuleLoaded->pModuleBuffer + *pModuleSize )
   {
      Warning( "Found a null char in middle of file %s \n", pModuleName );
      return NULL;
   }
 }
#endif /* HYPERSRC_PEDANTIC */

  /*
   * Return a pointer to the buffer that holds the module.
   * Buffer size was returned-by-ref to *pModuleSize.
   */
   return pModuleLoaded->pModuleBuffer;
}

/******************************************************************************
 * Free a buffer that holds a module.
 * Updates (does NOT free) the corresponding hashed module_t struct.
 *
 * Parms   : pModuleName
 *           Name of module.
 *
 *           pModuleLoaded->pModuleBuffer (OUT/GLOBAL)
 *           pModuleLoaded->moduleSize    (OUT/GLOBAL)
 *           Nullified to indicate module was freed.
 ******************************************************************************/
void
FreeModuleBuffer( gchar* pModuleName )
{
   module_t*	pModule = NULL;

  /*
   * Skip if name indicates no module is shown in a text widget.
   */
   if ( IsStringEmpty( pModuleName ) )
      return;
g_return_if_fail( IsStringValid( pModuleName, MAX_FILENAME_LEN ) );

  /*
   * Every module should have a hashed module_t struct.
   */
   pModule = (module_t*) g_hash_table_lookup( pHashModules, pModuleName );
g_return_if_fail( pModule );

  /*
   * Free the buffer.
   * Update the hashed module_t to indicate the buffer was freed.
   * Keep the module_t in the hash and don't change the rest of it!
   */
   if ( pModule->pModuleBuffer ) g_free( pModule->pModuleBuffer );
   pModule->pModuleBuffer = NULL;
   pModule->moduleSize    = 0;

   return;
}

/*****************************************************************************
 * Insert a module_t struct into a hash table (pHashModules).
 * This is intended for when a module is first encountered (before it was loaded).
 *
 * Parms   : pModuleName
 *           Filename of module ## CALLER MUST PASS PERMANENT STRING!! ##
 *
 *           pHashModules (GLOBAL)
 *
 * Returns : Pointer to a module_t struct of the module.
 *           Returns NULL if there were too many modules.
 *****************************************************************************/
module_t*
HashDebutModule( char* pModuleName ) /* ## CALLER MUST PASS PERMANENT STRING!! ## */
{
   module_t*	pModule;

g_return_val_if_fail( IsStringValid( pModuleName, MAX_FILENAME_LEN ), NULL );

  /*
   * Too many modules?
   */
   if ( g_hash_table_size( pHashModules ) >= maxModules )
      return NULL;

  /*
   * Don't re-insert the same module, otherwise g_hash_table_insert()
   * will discard the previously inserted module_t and its state!
   * This check is necessary in case the same src file was passed on the cmd-line.
   */
   pModule = g_hash_table_lookup( pHashModules, pModuleName );

   if ( !pModule )
   {
     /*
      * For this newly-encountered module (referenced by a field in a ctags line),
      * create a module_t struct and insert it into a hash table.
      */
      pModule = (module_t*) g_malloc( sizeof(module_t) );

      pModule->pModuleName		= pModuleName;	/* caller is expected to pass permanent string!! */
      pModule->pModuleBuffer	= NULL;			/* was never loaded */
      pModule->moduleSize		= 0;			/* was never loaded */
      pModule->pGslistFuncDef	= NULL;			/* to assign after all tags are processed */
      pModule->pHashFuncTags	= g_hash_table_new( HashFuncTagsKey, HashFuncTagsCmp );

      g_hash_table_insert( pHashModules,
                           pModuleName, /* key */
                           pModule );   /* value */
   }

   return pModule;
}

/******************************************************************************
 * The "hash function" for the hash table of modules.
 ******************************************************************************/
guint
HashModuleKey( gconstpointer pModuleName )
{
   return g_str_hash( pModuleName );
}

/******************************************************************************
 * The comparison function for the hash table of modules.
 ******************************************************************************/
gint
HashModuleCmp( gconstpointer pModuleName1,
               gconstpointer pModuleName2 )
{
   return g_str_equal( pModuleName1,
                       pModuleName2 );
}

/*****************************************************************************
 * Create a sorted glist of module names from the module hash table.
 *
 * Parms:		pHashModules (GLOBAL)
 *
 *				pGlistModuleNames (OUT/GLOBAL)
 *****************************************************************************/
void
CreateModuleNameGlist( void )
{
   g_assert( pHashModules ); /* must be created first */

  /*
   * Erase previous module names glist.
   */
   if ( pGlistModuleNames )
   {
      g_list_free( pGlistModuleNames );

     /*
      * Reset to NULL to cause a new glist to be created.
      */
      pGlistModuleNames = NULL;
   }

  /*
   * The modules in the hash are unsorted, so create a glist of sorted module names.
   */
   g_hash_table_foreach( pHashModules,
                         AddSortedModuleGlist,
                         (gpointer)&pGlistModuleNames /* out */ );

  return;
}

/******************************************************************************
 * From an item in the module hash, add a module name to a sorted glist.
 *
 * Parms   : pModuleName (hash key)
 *           Pointer to the module name.
 *
 *         : pUnused (hash value)
 *
 *         : ppGlist (IN/OUT)
 *           Pointer^2 to the glist containing module names.
 ******************************************************************************/
void
AddSortedModuleGlist( gpointer pModuleName,
                      gpointer pUnused,
                      gpointer ppGlist )
{
   *(GList**)ppGlist = g_list_insert_sorted( *(GList**)ppGlist,
                                             pModuleName,
                                             HashStrcmp );
   return;
}
