/******************************************************************************
 * $Id: hilite_forth.c,v 1.10 2003/08/06 01:51:56 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Functions for hiliting FORTH code in a text widget.
 * Notes        :
 ******************************************************************************/

#include "common.h"
#include "hilite_forth.h"

#include "hilite.h"
#include "widgets.h"
#include "statusbar.h"
#include "text.h"

/*****************************************************************************
 * Return TRUE if start of a FORTH comment is pointed to.
 *****************************************************************************/
gboolean
IsStartOfForthComment( const char* pc,
                       const char* pBuffer )
{
  /*
   * ( comment ) ?
   */
   if ( pc[0] == '('  &&  IsWhitespace( pc[1] ) )
   {
     /*
      * ".( )" is a word to print a message, it isn't a comment.
      */
      if ( pc > pBuffer  &&  *(pc-1) == '.' )
         return FALSE;

      return TRUE;
   }
   else /* <backslash> comment ? */
      return pc[0] == '\\';
}

/*****************************************************************************
 * Load a text widget with hilited FORTH source code.
 *
 * Precond : The text widget must be empty and frozen.
 *
 * Returns : true if successful
 *
 * Parms   : pWidget
 *           Pointer to a text widget.
 *
 *           pBuffer
 *           Pointer to a buffer containing source code text.
 *           Buffer must have a trailing null char.
 *
 *           bufferSize
 *           Size of buffer (excluding trailing null char).
 *
 *           srcFileKind
 *           One of SRC_FILE_*
 *****************************************************************************/
gboolean
HiliteForth( GtkWidget* pWidget,
             char*      pBuffer,
             int        bufferSize,
             int        srcFileKind )
{
   const char*	pc;
   const char*	pcAfter;
   const char*	pcTmp1;
   const char*	pcPrevious;
   const char*	pcPrePastWhitespace;
   const char*	pCommentAfter;
   char*		pScratch;
   int			textWidgetSize;
   int          breakout = 0;

#define REMAINING_BUFFER_SIZE(p)	(bufferSize - (p - pBuffer))

  /*
   * Allocate mem for a temp string as large as module buffer.
   * Will be re-used many times by lower-level functions.
   */
   pScratch = g_malloc( bufferSize );

  /*
   * Parse buffer for strings to hilite.
   */
   pcPrevious = NULL;
   for ( pc = pBuffer; pc < &pBuffer[bufferSize]; )
   {
     /*
      * Break loop if pc is stuck (due to parser bug).
      */
      if ( pc == pcPrevious )
      {
         ++breakout;
         if ( breakout > 100 )
         {
            Warning( "Hilite code is stuck." );
            WarningMalfunction();
            break;
         }
      }
      pcPrevious = pc;

     /*
      * Note: Loop should be stopped using break, not return.
      */
g_return_val_if_fail( pc >= pBuffer  &&  pc < &pBuffer[bufferSize], FALSE );

     /*
      * Has end of buffer been reached?
      */
g_return_val_if_fail( pc != NULL, FALSE );	/* should not be NULL at this point */
      if ( pc >= &pc[bufferSize]  ||  *pc == '\0' )
         break;

     /*
      * Move past whitespace, but remember prior pointer.
      */
      pcPrePastWhitespace = pc;
      pc = (char*)PastWhitespace( pc, REMAINING_BUFFER_SIZE(pc) );

     /*
      * Does only whitespace remain?
      */
      if ( pc == NULL )
      {
         gtk_text_insert( GTK_TEXT(pWidget),
                          NULL,
                          NULL,
                          NULL,
                          pcPrePastWhitespace,
                          REMAINING_BUFFER_SIZE(pcPrePastWhitespace ) );
         break;
      }

     /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

     /*
      * Is the beginning of a comment being pointed to?
      */
      if ( IsStartOfForthComment( pc, pBuffer ) )
      {
         char* pCommentEndDef = ")";

        /*
         * Is this a one-line comment?
         */
         if ( pc[0] == '\\' )
            pCommentEndDef = "\n";

        /*
         * Parse/insert comment.
         */
         pCommentAfter = \
         HiliteComment( pWidget,
                        pcPrePastWhitespace,
                        pCommentEndDef,
                        REMAINING_BUFFER_SIZE(pcPrePastWhitespace) );

        /*
         * Was the end of the comment parsed?
         */
         if ( pCommentAfter )
         {
           /*
            * From after comment, iterate.
            */
            pc = pCommentAfter;
            continue;
         }
         else
         {
           /*
            * End of buffer must have been prematurely encountered.
            */
            break;
         }
      }
     /*
      * Is this the definition of a FORTH word?
      */
      else if ( pc[0] == ':' )
      {
        /*
         * Insert any preceding whitespace.
         */
         if ( pc > pcPrePastWhitespace )
            gtk_text_insert( GTK_TEXT(pWidget),
                             NULL,
                             NULL,
                             NULL,
                             pcPrePastWhitespace,
                             pc - pcPrePastWhitespace );

        /*
         * Look for the form ": x"
         */
         if ( IsWhitespace(pc[1])  &&  !IsWhitespace(pc[2]) )
         {
            int         sizeWord;
            const char* pWord;

           /*
            * Insert ": "
            */
            gtk_text_insert( GTK_TEXT(pWidget),
                             NULL,
                             NULL,
                             NULL,
                             pc,
                             2 );

           /*
            * Insert hilited FORTH word.
            * Move pc past it.
            */
            sizeWord = ParseWord( pc+2, &pWord, 30 );
g_return_val_if_fail( sizeWord > 0  &&  pWord, FALSE );
            gtk_text_insert( GTK_TEXT(pWidget),
                             pFontKeyword,
                             &colorKeyword,
                             NULL,
                             pc+2,
                             sizeWord );
            pc = pc + 2 + sizeWord;
            continue;
         }
         else
         {
           /*
            * Encountered a ":" which isn't part of a FORTH word definition.
            * Insert ":", then move past it.
            */
            gtk_text_insert( GTK_TEXT(pWidget),
                             NULL,
                             NULL,
                             NULL,
                             pc,
                             1 );
            ++pc;
            continue;
         }
      }

     /*
      * Is this is a FORTH keyword or alphabetic char(s)?
      */
      if ( isalpha(*pc) )
      {
         const char* pWord = NULL;
         int         sizeWord;

        /*
         * Insert any preceding whitespace.
         */
         if ( pc > pcPrePastWhitespace )
            gtk_text_insert( GTK_TEXT(pWidget),
                             NULL,
                             NULL,
                             NULL,
                             pcPrePastWhitespace,
                             pc - pcPrePastWhitespace );

        /*
         * Highlight FORTH control flow words.
         */
#define MATCH(upper,lower) ( (sizeWord==sizeof(upper)-1)  &&  (MEMEQ(pWord,upper,sizeof(upper)-1)||MEMEQ(pWord,lower,sizeof(lower)-1)) )
         sizeWord = ParseWord( pc, &pWord, 10 );
         if ( sizeWord > 1 /* ignore single char */
              && pWord     /* if non-null */
              && pWord+10 < &pBuffer[bufferSize] /* don't overshoot buffer while matching */
              && (   MATCH( "IF",      "if"      )
                  || MATCH( "ELSE",    "else"    )
                  || MATCH( "ENDIF",   "endif"   )
                  || MATCH( "THEN",    "then"    )
                  || MATCH( "BEGIN",   "begin"   )
                  || MATCH( "AGAIN",   "again"   )
                  || MATCH( "REPEAT",  "repeat"  )
                  || MATCH( "WHILE",   "while"   )
                  || MATCH( "UNTIL",   "until"   )
// won't ever be matched since this point is reached only if first char is alphabetic
//                || MATCH( "?DO",     "?do"     )
                  || MATCH( "DO",      "do"      )
//                || MATCH( "+LOOP",   "+loop"   ) /* match +LOOP before LOOP */
                  || MATCH( "LOOP",    "loop"    )
                  || MATCH( "UNLOOP",  "unloop"  )
                  || MATCH( "LEAVE",   "leave"   )
                  || MATCH( "CASE",    "case"    )
                  || MATCH( "ENDCASE", "endcase" )
                  || MATCH( "OF",      "of"      )
                  || MATCH( "ENDOF",   "endof"   ) ) )
         {
            gtk_text_insert( GTK_TEXT(pWidget),
                             pFontKeyword,
                             &colorType, /*&colorKeyword,*/
                             NULL,
                             pc,
                             sizeWord );
         }
         else
         {
            gtk_text_insert( GTK_TEXT(pWidget), /* insert with normal font/color */
                             NULL,
                             NULL,
                             NULL,
                             pc,
                             sizeWord );
         }
         pc = pc + sizeWord;
         continue;
      }

     /*
      * Scoop all text until:
      * start of comment, a colon ':", alphabetic char, or buffer end.
      */
      pcAfter = NULL;
      for ( pcTmp1 = pc; *pcTmp1; ++pcTmp1 )
      {
         if (    IsStartOfForthComment( pcTmp1, pBuffer )
              || *pcTmp1 == ':'
              || isalpha(*pcTmp1) )
         {
            pcAfter = pcTmp1;
            break;
         }
      }

      if ( pcAfter == NULL )				/* was both NULL (buffer end)? */
      {
        /*
         * Encountered buffer end.
         */
         pcAfter = &pBuffer[bufferSize];
      }

      gtk_text_insert( GTK_TEXT(pWidget),
                       NULL,
                       NULL,
                       NULL,
                       pcPrePastWhitespace,
                       pcAfter - pcPrePastWhitespace );

     /*
      * Move pointer, continue (stopping cases are checked above).
      */
      pc = pcAfter;
   }

  /*
   * There's a bug here if the size of the text widget
   * does not equal the size of the buffer.
   */
   textWidgetSize = gtk_text_get_length( GTK_TEXT(pWidgetTextActive) );
#ifdef HYPERSRC_DEBUG
   if ( textWidgetSize != bufferSize )
   {
      DebugMsg( __FUNCTION__ "(): gtk_text_get_length() != bufferSize in module %s", ActiveModuleName() );
      DebugMsg( __FUNCTION__ "(): gtk_text_get_length() = %d  bufferSize = %d", textWidgetSize, bufferSize );
   }
#endif

  /*
   * Dealloc, return.
   */
   g_free( pScratch );
   return TRUE;
}
