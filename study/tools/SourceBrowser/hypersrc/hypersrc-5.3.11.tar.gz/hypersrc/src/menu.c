/******************************************************************************
 * $Id: menu.c,v 1.127 2003/07/09 15:47:01 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Functions for menus.
 * Notes        : A performance trick is to create a widget only once and use hide/show
 *                instead of recreating it.  However, if the widget has been pushed
 *                behind another widget, then the show function won't bring to the top.
 ******************************************************************************/

#include "common.h"
#include "menu.h"

#include "sys.h"
#include "widgets.h"
#include "handlers.h"
#include "list.h"
#include "find.h"
#include "text.h"
#include "statusbar.h"
#include "popup.h"
#include "prefs.h"
#include "history.h"
#include "main.h"
#include "treefunc.h"

/*****************************************************************************
 * Set sensitivity of menubar.
 *****************************************************************************/
void
SetSensitivityMenubar( gboolean sensitive )
{
g_return_if_fail( pItemFactory );
#if 0
   /* --this won't work-- */
   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/Sort" ), sensitive );
#else
   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/File/Edit with emacs" ), sensitive );
   if ( vimExists )
   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/File/Edit with vim" ), sensitive );
   else
   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/File/Edit with vi" ), sensitive );

   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/Sort/Tags By Name" ), sensitive );
   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/Sort/Tags By Module" ), sensitive );
   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/Sort/Tags By Type" ), sensitive );

   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/Search/Find Text  F3" ), sensitive );
   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/Search/Find Tag   F4" ), sensitive );
   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/Search/Find Module" ), sensitive );

   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/Prefs/Edit Prefs" ), sensitive );
   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/Prefs/Save Prefs" ), sensitive );

   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/Help/Key Assignments" ), sensitive );
   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/Help/Release Notes" ), sensitive );
   gtk_widget_set_sensitive( gtk_item_factory_get_widget( pItemFactory, "/Help/About" ), sensitive );
#endif
}

/******************************************************************************
 * Create the menubar.
 *
 * Notes: "_Find" shouldn't be used because conventionally "F" is for "_File",
 *        and "Alt+F" is used by the text widget (when it has the focus).
 ******************************************************************************/
void
CreateMenubar( GtkWidget* pWidgetHbox )
{
   static GtkItemFactoryEntry menuItems[] =
   {
      { "/Fil_e",					NULL,	0,			0,			"<Branch>"						},
      { "/File/Edit with _emacs",	NULL,	MenuItemSelected,		MENU_ITEM_FILE_EMACS,		0  	},
#if 0
      { "/File/Edit with _xemacs",	NULL,	MenuItemSelected,		MENU_ITEM_FILE_XEMACS,		0  	},
#endif
      { "/File/Edit with _vi",		NULL,	MenuItemSelected,		MENU_ITEM_FILE_VI,			0  	},
      { "/File/E_xit",				NULL,	MenuItemSelected,		MENU_ITEM_FILE_EXIT,		0  	},

      { "/_Search",					NULL,	0,			0,			"<Branch>"						},
      { "/Search/Find Te_xt  F3",	NULL,	MenuItemSelected,		MENU_ITEM_FIND_TEXT,		0  	},
      { "/Search/Find Ta_g   F4",	NULL,	MenuItemSelected,		MENU_ITEM_FIND_TAG,			0  	},
      { "/Search/Find _Module",		NULL,	MenuItemSelected,		MENU_ITEM_FIND_MODULE,		0  	},

      { "/Sor_t",					NULL,	0,			0,			"<Branch>"						},
      { "/Sort/Tags By _Name",		NULL,	MenuItemSelected,		MENU_ITEM_SORT_TAG,			0   },
      { "/Sort/Tags By _Module",	NULL,	MenuItemSelected,		MENU_ITEM_SORT_MODULE,		0   },
      { "/Sort/Tags By _Type",		NULL,	MenuItemSelected,		MENU_ITEM_SORT_TYPE,		0   },

      { "/_Prefs",					NULL,	0,			0,			"<Branch>"						},
      { "/Prefs/_Edit Prefs",		NULL,	MenuItemSelected,		MENU_ITEM_PREFS_EDIT,		0  	},
      { "/Prefs/_Save Prefs",		NULL,	MenuItemSelected,		MENU_ITEM_PREFS_SAVE,		0  	},

      { "/_Help",					NULL,	0,			0,			"<Branch>"						},
      { "/Help/_Key Assignments",	NULL,	MenuItemSelected,		MENU_ITEM_HELP_KEYS,		0   },
      { "/Help/_Release Notes",		NULL,	MenuItemSelected,		MENU_ITEM_HELP_NOTES,		0   },
      { "/Help/_About",				NULL,	MenuItemSelected,		MENU_ITEM_HELP_ABOUT,		0   }

   };
   int i;

  /*
   * Change corresponding menu item if vim exists (preferred over vi).
   */
   if ( vimExists )
   {
      for ( i = 0; i < 7; i++ )
         if ( strstr( menuItems[i].path, "/File/Edit with _vi" ) )
            menuItems[i].path = "/File/Edit with _vim";
   }

  /*
   * Create a new accel group.
   */
   pAccelGroup = gtk_accel_group_new();

  /*
   * Create a new item factory.
   */
   pItemFactory = gtk_item_factory_new( GTK_TYPE_MENU_BAR,
                                        "<main>",
                                        pAccelGroup );

  /*
   * Create the items in the factory.
   */
   gtk_item_factory_create_items( pItemFactory,
                                  sizeof(menuItems) / sizeof(menuItems[0]),
                                  menuItems,
                                  NULL );
  /*
   * Attach the accel group to the main window.
   */
   gtk_accel_group_attach( pAccelGroup,
                           GTK_OBJECT(pWidgetMain) );

  /*
   * Put the menubar in the hbox.
   */
   gtk_box_pack_start( GTK_BOX( pWidgetHbox ),
                       gtk_item_factory_get_widget( pItemFactory,
                                                    "<main>" ),
                       FALSE, FALSE, 0 );

   return;
}

/******************************************************************************
 * Callback for when a menu item is selected.
 ******************************************************************************/
void
MenuItemSelected( gpointer   pData,
                  guint      menuItem,
                  GtkWidget* pWidget )
{
  /*
   * Prevent nesting major functions.
   */
   if ( IsAnyMajorFunctionBusy(TRUE) ) return;

  /*
   * Clear the statusbar before calling a menu item function.
   * Often, lingering statusbar messages are no longer relevant, and can cause confusion.
   */
   MostlyClearStatusbar();

  /*
   * Route the menu item to the appropriate function.
   */
   switch ( menuItem )
   {
      case MENU_ITEM_FILE_XEMACS:
         RunEditor( "xemacs" );
         break;

      case MENU_ITEM_FILE_EMACS:
         RunEditor( "emacs" );
         break;

      case MENU_ITEM_FILE_VI:
         RunEditor( vimExists ? "vim" : "vi" );
         break;

      case MENU_ITEM_FILE_EXIT:
         gtk_exit( 0 );

      case MENU_ITEM_FIND_TAG:
         CreateFindDialog( MENU_ITEM_FIND_TAG );
         break;

      case MENU_ITEM_FIND_TEXT:
         CreateFindDialog( MENU_ITEM_FIND_TEXT );
         break;

      case MENU_ITEM_FIND_MODULE:
         CreateFindDialog( MENU_ITEM_FIND_MODULE );
         break;

      case MENU_ITEM_SORT_TAG:
         SetSensitivityWhileBusy( FALSE );
         PopulateTagsClistWidget( SORT_TAG );
         SetSensitivityWhileBusy( TRUE );
         break;

      case MENU_ITEM_SORT_MODULE:
         SetSensitivityWhileBusy( FALSE );
         PopulateTagsClistWidget( SORT_MODULE );
         SetSensitivityWhileBusy( TRUE );
         break;

      case MENU_ITEM_SORT_TYPE:
         SetSensitivityWhileBusy( FALSE );
         PopulateTagsClistWidget( SORT_TYPE );
         SetSensitivityWhileBusy( TRUE );
         break;
 
      case MENU_ITEM_PREFS_EDIT:
         EditPrefs();
         break;

      case MENU_ITEM_PREFS_SAVE:
         SaveVars();
         PrintStatusbar( "Preferences saved as ~/.gnome/hypersrc" );
         break;

      case MENU_ITEM_HELP_KEYS:
         Popup( "   ---------------------------------------------------------- \n" \
                "   F3 or Ctrl+F       find text (opens dialog)                \n" \
                "   F4                 find tag  (opens dialog)                \n" \
                "   F5 or Ctrl+Enter   goto tag  (under cursor)                \n" \
                "   F6                 to earlier tag  (in history)            \n" \
                "   F7                 to later   tag  (in history)            \n" \
                "   F8                 find strings matching one under cursor  \n" \
                "   F9                 record cursor position in history       \n" \
                "   Ctrl+N or Ctrl+G   find next (text or tag)                 \n" \
                "   Ctrl+L             re-center text view                     \n" \
                "   Left-Shift         hyperjump using bottom text view        \n" \
                "   Left-Ctrl          disable updating tree                   \n" \
                "   ---------------------------------------------------------- \n" \
                "   In clist widget:                                           \n" \
                "                                                              \n" \
                "   Up/Down            move up/down a row                      \n" \
                "   Ctrl+Home[End]     move to top[bottom] row                 \n" \
                "   Space              select row (toggle)                     \n",
                "Default Key Assignments",
                FONT_MONOSPACED );
         break;

      case MENU_ITEM_HELP_ABOUT:
         Popup( "hypersrc "HYPERSRC_VERSION_STRING" by Jim Brooks\nhypersrc@jimbrooks.org\nwww.jimbrooks.org/hypersrc/\n(GPL no warranty)", "About hypersrc", FONT_PROPORTIONAL );
         break;

      case MENU_ITEM_HELP_NOTES:
#if defined(HYPERSRC_DEBUG)
 #ifdef HYPERSRC_PEDANTIC
 #define BINARY_BUILD	"DEBUG (pedantic)"
 #else
 #define BINARY_BUILD	"DEBUG"
 #endif
#elif defined(HYPERSRC_SPEED)
 #define BINARY_BUILD	"SPEED"
#else /* assume release */
 #ifndef G_DISABLE_ASSERT
 #define BINARY_BUILD	"RELEASE"
 #else
 #define BINARY_BUILD	"RELEASE (asserts disabled)"
 #endif
#endif

#ifdef HYPERSRC_PROFILE
#define BINARY_BUILD_PROFILE "PROFILE/"
#else
#define BINARY_BUILD_PROFILE ""
#endif
         Popup( "Version "HYPERSRC_VERSION_STRING"\n\nTested on:\nRed Hat 7/8, Mandrake 8.1, FreeBSD 4.6.2\nGTK+ 1.2.10\nXFree86 4.x.x\n\nThis is a " BINARY_BUILD_PROFILE BINARY_BUILD " build.      ", "Release notes", FONT_PROPORTIONAL );
         break;
   }

   return;
}

/*****************************************************************************
 * Run an editor (vi/emacs/xemacs).
 *****************************************************************************/
void
RunEditor( char* pEditor )
{
   char*	execArgs[10];
   int		line;
   char		arg[20];

   if ( IsTextWidgetEmpty()  ||  ! ActiveModule() )
   {
      PrintStatusbar( "Text widget is empty." );
      return;
   }
g_return_if_fail( ActiveModule()->pModuleName );

  /*
   * Compute the goto-line arg +nnn which is the same in vi/emacs/xemacs.
   */
   line = LineAtCursor() + 1;
   if ( line <= 2 ) line = 1;
   sprintf( arg, "+%d", line );

   if ( strstr( pEditor, "emacs" ) )
   {
     /*
      * emacs/xemacs
      */
      execArgs[0] = pEditor;
      execArgs[1] = arg;
      execArgs[2] = ActiveModule()->pModuleName;
      execArgs[3] = NULL;
   }
   else
   {
     /*
      * vi/vim
      * Run via a separate xterm.
      */
      execArgs[0] = "xterm";
      execArgs[1] = "-tn";			/* export TERM=xterm-color so that vim can show colors */
      execArgs[2] = "xterm-color";
      execArgs[3] = "-e";
      execArgs[4] = pEditor;
      execArgs[5] = arg;
      execArgs[6] = ActiveModule()->pModuleName;
      execArgs[7] = NULL;
   }

   SysExec( execArgs[0], execArgs );

   return;
}

/*****************************************************************************
 * Create/show the dialog widget for finding.
 *
 * The find dialog is used for finding either a tag or a text string.
 *
 * Parms   : menuItem (GLOBAL)
 *           Which menu item corresponds to the dialog widget.
 *           Can be one of MENU_ITEM_FIND_*.
 *
 *           pWidgetDialogFind (IO/GLOBAL)
 *           Pointer to the create (or recreated) dialog widget.
 *****************************************************************************/
void
CreateFindDialog( MENU_ITEM menuItem )
{
   GtkWidget*	pWidgetHbox             = NULL;		/* contains all boxes */
   GtkWidget*	pWidgetVboxButtons      = NULL;		/* contains rows of buttons */
   GtkWidget*	pWidgetVboxEntryWord    = NULL;		/* contains text entry and "Word At Cursor" button */
   GtkWidget*	pWidgetHboxEntry        = NULL;		/* contains text entry and its label */
   GtkWidget*	pWidgetLabel            = NULL;
   GtkWidget*   pWidgetButtonWord       = NULL;
   GtkWidget*   pWidgetButtonRestoreCursor = NULL;
   GtkWidget*	pWidgetButtonFind       = NULL;
   GtkWidget*	pWidgetButtonCancel     = NULL;
   GString**	ppSought                = NULL;

  /*
   * Record what kind of item is sought (ie a tag or text string)
   * for the next find.
   */
   soughtType = menuItem;

  /*
   * Save the cursor position in the text widget in case later
   * the user wants to restore the cursor position after doing searches.
   */
   SaveCursor( &cursorText );

  /*
   * Destroy the widget if it is already created.
   */
   if ( pWidgetDialogFind ) gtk_widget_destroy( pWidgetDialogFind );

  /*
   * Create (recreate) the dialog widget.
   */
   pWidgetDialogFind = gtk_dialog_new();

  /*
   * Install key event handlers (to close dialog if ESC is pressed).
   */
   gtk_signal_connect( GTK_OBJECT(pWidgetDialogFind),
                       "key-press-event",
                       (GtkSignalFunc)HandlerKeyPressDialogFind,
                       NULL );
   gtk_signal_connect( GTK_OBJECT(pWidgetDialogFind),
                       "key-release-event",
                       (GtkSignalFunc)HandlerKeyRelease,
                       NULL );
   gtk_widget_add_events( pWidgetDialogFind,
                          GDK_KEY_RELEASE_MASK );	/* to enable key release events */

  /*
   * Init appropriate vars.
   */
   if ( soughtType == MENU_ITEM_FIND_TAG )
      ppGlistFindStrings = &pGlistFindStringsTag;
   else
   if ( soughtType == MENU_ITEM_FIND_TEXT )
      ppGlistFindStrings = &pGlistFindStringsText;
   else
   if ( soughtType == MENU_ITEM_FIND_MODULE )
      ppGlistFindStrings = &pGlistFindStringsModule;
   else
      g_return_if_fail( 0 );

  /*
   * Title the dialog.
   */
   if ( soughtType == MENU_ITEM_FIND_TAG )
      gtk_window_set_title( GTK_WINDOW(pWidgetDialogFind),
                            "Find Tag" );
   else
   if ( soughtType == MENU_ITEM_FIND_TEXT )
      gtk_window_set_title( GTK_WINDOW(pWidgetDialogFind),
                            "Find Text" );
   else
   if ( soughtType == MENU_ITEM_FIND_MODULE )
      gtk_window_set_title( GTK_WINDOW(pWidgetDialogFind),
                            "Find Module" );
   else
      g_return_if_fail( 0 );

  /*
   * Widen the border of the dialog.
   */
   gtk_container_border_width( GTK_CONTAINER(pWidgetDialogFind),
                               16 );

  /*
   * Create/pack the various boxes.
   */
   pWidgetHbox          = gtk_hbox_new( FALSE, 4 );
   pWidgetHboxEntry     = gtk_hbox_new( FALSE, 4 );
   pWidgetVboxEntryWord = gtk_vbox_new( FALSE, 4 );
   pWidgetVboxButtons   = gtk_vbox_new( TRUE,  4 );
   gtk_box_pack_start( GTK_BOX(pWidgetHbox),			/* pack textEntry/word's vbox into main hbox */
                       pWidgetVboxEntryWord,
                       TRUE, TRUE, 4 );
   gtk_box_pack_start( GTK_BOX(pWidgetVboxEntryWord),	/* pack textEntry's hbox into textEntry/word vbox */
                       pWidgetHboxEntry,
                       TRUE, TRUE, 4 );
   gtk_box_pack_end( GTK_BOX(pWidgetHbox),				/* pack buttons's vbox into main hbox */
                     pWidgetVboxButtons,
                     TRUE, TRUE, 4 );

  /*
   * Create/pack a label for the dialog.
   */
   if ( soughtType == MENU_ITEM_FIND_TAG )
      pWidgetLabel = gtk_label_new( "Find (fuzzy): " );
   else
   if ( soughtType == MENU_ITEM_FIND_TEXT )
      pWidgetLabel = gtk_label_new( "Find: " );
   else
   if ( soughtType == MENU_ITEM_FIND_MODULE )
      pWidgetLabel = gtk_label_new( "Find (fuzzy): " );
   else
      g_return_if_fail( 0 );

   gtk_box_pack_start( GTK_BOX(pWidgetHboxEntry),
                       pWidgetLabel,
                       TRUE, TRUE, 4 );

  /*
   * Create/pack the combo (text entry field) of the dialog.
   * Do not add pop-down strings if no search has even been done before.
   * gtk_combo_disable_active() makes Enter key work as expected.
   */
   pWidgetComboFind = gtk_combo_new();
   gtk_combo_disable_activate( GTK_COMBO(pWidgetComboFind) );
   if ( *ppGlistFindStrings != NULL )
      gtk_combo_set_popdown_strings( GTK_COMBO(pWidgetComboFind),
                                     *ppGlistFindStrings );
   gtk_box_pack_start( GTK_BOX(pWidgetHboxEntry),
                       pWidgetComboFind,
                       TRUE, TRUE, 4 );

  /*
   * By default, a combo's entry widget will try to alter the case
   * of a newly entered string to match a previous string.
   * Such behavior is a hindrance in a find dialog, so disable it.
   */
   gtk_combo_set_value_in_list( GTK_COMBO(pWidgetComboFind),
                                FALSE,
                                FALSE );
   gtk_combo_set_case_sensitive( GTK_COMBO(pWidgetComboFind),
                                 TRUE );

  /*
   * Insert the previous appropriate sought item (if it exists)
   * into the text entry (to facilitate repeated searches for same item).
   */
   if ( soughtType == MENU_ITEM_FIND_TAG )
      ppSought = &pSoughtTag;
   else
   if ( soughtType == MENU_ITEM_FIND_TEXT )
      ppSought = &pSoughtText;
   else
   if ( soughtType == MENU_ITEM_FIND_MODULE )
      ppSought = &pSoughtModule;
   else
      g_return_if_fail( 0 );

   if ( *ppSought )
      gtk_entry_set_text( GTK_ENTRY( GTK_COMBO(pWidgetComboFind)->entry ),
                          (*ppSought)->str );

  /*
   * For text search, create/pack the "Word At Cursor" button (underneath the text entry).
   */
   if (     soughtType == MENU_ITEM_FIND_TEXT
        &&  ! IsTextWidgetEmpty()
        &&  IsCursorOverWord() )
   {
     /*
      * Create/pack "Word At Cursor" button.
      */
      pWidgetButtonWord = CreateButtonLabelUnderlined( "Choose Word at Cursor",
                                                       "       _             " );
      gtk_box_pack_start( GTK_BOX(pWidgetVboxEntryWord),
                        pWidgetButtonWord,
                        TRUE, FALSE, 4 );

     /*
      * Connect to signal when "Word At Cursor" is clicked.
      */
      gtk_signal_connect( GTK_OBJECT(pWidgetButtonWord),
                          "clicked",
                          GTK_SIGNAL_FUNC(WordAtCursorClicked),
                          NULL );

     /*
      * For key handler, remember that this button was created.
      */
      buttonWordAtCursorFlag = TRUE;
   }

  /*
   * Create a button to restore the cursor position.
   */
   if ( ! IsTextWidgetEmpty() )
   {
      pWidgetButtonRestoreCursor = \
      CreateButtonLabelUnderlined( "Restore Cursor Position",
                                   "               _       " );
      gtk_box_pack_start( GTK_BOX(pWidgetVboxEntryWord),
                          pWidgetButtonRestoreCursor,
                          TRUE, FALSE, 4 );
      gtk_signal_connect( GTK_OBJECT(pWidgetButtonRestoreCursor),
                          "clicked",
                          GTK_SIGNAL_FUNC(RestoreCursorClicked),
                          NULL );
     /*
      * For key handler, remember that this button was created.
      */
      buttonRestoreCursorFlag = TRUE;
   }

  /*
   * Create appropriate buttons and connect to appropriate signals.
   *
   * Create/pack the appropriate check buttons.
   */
   if ( soughtType == MENU_ITEM_FIND_TEXT )
   {
      pWidgetCheckButtonFindGlobal  = gtk_check_button_new_with_label( "global" );
      pWidgetCheckButtonFindExact   = NULL;
      pWidgetCheckButtonFindCase    = gtk_check_button_new_with_label( "case-sensitive" );
      pWidgetCheckButtonFindReverse = gtk_check_button_new_with_label( "reverse" );
      pWidgetCheckButtonFindRegex   = gtk_check_button_new_with_label( "regex" );
   }
   else /* find tag or module */
   {
      pWidgetCheckButtonFindGlobal  = NULL;
      pWidgetCheckButtonFindExact   = gtk_check_button_new_with_label( "exact match" );
      pWidgetCheckButtonFindCase    = gtk_check_button_new_with_label( "case-sensitive" );
      pWidgetCheckButtonFindReverse = NULL;
      pWidgetCheckButtonFindRegex   = NULL;
   }

   if ( pWidgetCheckButtonFindGlobal )
      gtk_box_pack_start( GTK_BOX(pWidgetVboxButtons),
                          pWidgetCheckButtonFindGlobal,
                          TRUE, TRUE, 0 );
   if ( pWidgetCheckButtonFindExact )
      gtk_box_pack_start( GTK_BOX(pWidgetVboxButtons),
                          pWidgetCheckButtonFindExact,
                          TRUE, TRUE, 0 );
   if ( pWidgetCheckButtonFindCase )
      gtk_box_pack_start( GTK_BOX(pWidgetVboxButtons),
                          pWidgetCheckButtonFindCase,
                          TRUE, TRUE, 0 );
   if ( pWidgetCheckButtonFindReverse )
      gtk_box_pack_start( GTK_BOX(pWidgetVboxButtons),
                          pWidgetCheckButtonFindReverse,
                          TRUE, TRUE, 0 );
   if ( pWidgetCheckButtonFindRegex )
      gtk_box_pack_start( GTK_BOX(pWidgetVboxButtons),
                          pWidgetCheckButtonFindRegex,
                          TRUE, TRUE, 0 );

  /*
   * Depress the check button if "exact match" was previously selected.
   */
   if (    (soughtType == MENU_ITEM_FIND_TAG     &&  findExactTag)
        || (soughtType == MENU_ITEM_FIND_MODULE  &&  findExactModule) )
      gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(pWidgetCheckButtonFindExact),
                                    TRUE );

  /*
   * Depress the check button if "case-sensitive" was previously selected.
   */
   if (    (soughtType == MENU_ITEM_FIND_TEXT    &&  findCaseSensText)
        || (soughtType == MENU_ITEM_FIND_TAG     &&  findCaseSensTag)
        || (soughtType == MENU_ITEM_FIND_MODULE  &&  findCaseSensModule) )
      gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(pWidgetCheckButtonFindCase),
                                    TRUE );

  /*
   * Depress the check button if "reverse".
   */
   if (    (soughtType == MENU_ITEM_FIND_TEXT    &&  findReverse) )
      gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(pWidgetCheckButtonFindReverse),
                                    TRUE );

  /*
   * Depress the check button if "regex".
   */
   if (    (soughtType == MENU_ITEM_FIND_TEXT    &&  regex) )
      gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(pWidgetCheckButtonFindRegex),
                                    TRUE );

  /*
   * Depress the check button if "global" was previously selected.
   */
   if ( soughtType == MENU_ITEM_FIND_TEXT  &&  findGlobal )
      gtk_toggle_button_set_active( GTK_TOGGLE_BUTTON(pWidgetCheckButtonFindGlobal),
                                    TRUE );

  /*
   * Connect to the "toggle" signal for check buttons.
   */
   if ( pWidgetCheckButtonFindExact )
      gtk_signal_connect( GTK_OBJECT(pWidgetCheckButtonFindExact),
                          "toggled",
                          GTK_SIGNAL_FUNC(CheckButtonFindToggledBool),
                          soughtType == MENU_ITEM_FIND_TAG ? &findExactTag : &findExactModule );
   if ( pWidgetCheckButtonFindCase )
      gtk_signal_connect( GTK_OBJECT(pWidgetCheckButtonFindCase),
                          "toggled",
                          GTK_SIGNAL_FUNC(CheckButtonFindToggledBool),
                          soughtType == MENU_ITEM_FIND_TEXT ? &findCaseSensText : soughtType == MENU_ITEM_FIND_TAG ? &findCaseSensTag : &findCaseSensModule );
   if ( pWidgetCheckButtonFindGlobal )
      gtk_signal_connect( GTK_OBJECT(pWidgetCheckButtonFindGlobal),
                          "toggled",
                          GTK_SIGNAL_FUNC(CheckButtonFindGlobalToggled),
                          NULL );
   if ( pWidgetCheckButtonFindReverse )
      gtk_signal_connect( GTK_OBJECT(pWidgetCheckButtonFindReverse),
                          "toggled",
                          GTK_SIGNAL_FUNC(CheckButtonFindReverseToggled),
                          NULL );
   if ( pWidgetCheckButtonFindRegex )
      gtk_signal_connect( GTK_OBJECT(pWidgetCheckButtonFindRegex),
                          "toggled",
                          GTK_SIGNAL_FUNC(CheckButtonFindRegexToggled),
                          NULL );

  /*
   * Create/pack the "Find" button.
   */
   pWidgetButtonFind = CreateButtonLabelUnderlined( "Find",
                                                    "_   " );
   gtk_box_pack_start( GTK_BOX(GTK_DIALOG(pWidgetDialogFind)->action_area),
                       pWidgetButtonFind,
                       TRUE, TRUE, 0 );

  /*
   * Make the Find button the default button.
   */
   GTK_WIDGET_SET_FLAGS( pWidgetButtonFind,
                         GTK_CAN_DEFAULT );
   gtk_widget_grab_default( pWidgetButtonFind );

  /*
   * Create/pack the "Cancel" button.
   */
   pWidgetButtonCancel = gtk_button_new_with_label( "Close" );
   gtk_box_pack_start( GTK_BOX(GTK_DIALOG(pWidgetDialogFind)->action_area),
                       pWidgetButtonCancel,
                       TRUE, TRUE, 0 );

  /*
   * The final pack is to pack the hbox into the dialog's vbox.
   */
   gtk_box_pack_start( GTK_BOX(GTK_DIALOG(pWidgetDialogFind)->vbox),
                       pWidgetHbox,
                       TRUE, TRUE, 0 );

  /*
   * Connect to signals.
   */
   gtk_signal_connect( GTK_OBJECT(pWidgetDialogFind),
                       "destroy",
                       GTK_SIGNAL_FUNC(FindDialogClose),
                       NULL );
   gtk_signal_connect( GTK_OBJECT(pWidgetButtonFind),
                       "clicked",
                       GTK_SIGNAL_FUNC(FindDialogClickedFind),
                       NULL );
   gtk_signal_connect( GTK_OBJECT(pWidgetButtonCancel),
                       "clicked",
                       GTK_SIGNAL_FUNC(FindDialogClose),
                       NULL );

  /*
   * Position/show the dialog (and its sub-widgets).
   */
   PositionShowFindDialog( pWidgetDialogFind );

  /*
   * Grab the focus for the entry widget.
   */
   gtk_widget_grab_focus( GTK_WIDGET(GTK_COMBO(pWidgetComboFind)->entry) );

   return;
}

/*****************************************************************************
 * Called when the find dialog is closed/canceled.
 *****************************************************************************/
void
FindDialogClose( void )
{
  /*
   * This will be called twice if user clicks close before search completes.
   */
   if ( pWidgetDialogFind == NULL ) return;

  /*
   * Record the geom of the find dialog, to be used next time.
   */
   if ( pWidgetDialogFind->window )
   {
      WidgetGeom( pWidgetDialogFind,
                  &findGeom[0],
                  &findGeom[1],
                  &findGeom[2],
                  &findGeom[3] );
   }

  /*
   * Destroy the dialog widget and NULLify its pointer.
   */
   gtk_widget_destroy( pWidgetDialogFind );
   pWidgetDialogFind = NULL;

  /*
   * Clear other find dialog state.
   */
   buttonWordAtCursorFlag  = FALSE;
   buttonRestoreCursorFlag = FALSE;

   return;
}

/*****************************************************************************
 * Called when the Find button of the Find dialog is clicked.
 * Either, a tag or module in a clist widget, or a string in the text widget,
 * is sought.
 * The purpose of this function is to record what is being sought,
 * and defer the actual search to an appropriate function.
 *****************************************************************************/
void
FindDialogClickedFind( void )
{
   void FindDialogClickedFind___( void );

  /*
   * Prevent nesting major functions.
   */
   if ( IsAnyMajorFunctionBusy(TRUE) ) return;

  /*
   * For stability, serialize this function.
   */
   if ( busy_FindDialogClickedFind ) { DebugMsg( "FindDialogClickedFind() is busy." ); return; }
   busy_FindDialogClickedFind = TRUE;
   FindDialogClickedFind___();
   busy_FindDialogClickedFind = FALSE;
}
void
FindDialogClickedFind___( void )
{
   GString**	ppSought = NULL;

  /*
   * Determine which pSoughtX to use.
   */
   if ( soughtType == MENU_ITEM_FIND_TAG )
      ppSought = &pSoughtTag;
   else
   if ( soughtType == MENU_ITEM_FIND_TEXT )
      ppSought = &pSoughtText;
   else
   if ( soughtType == MENU_ITEM_FIND_MODULE )
      ppSought = &pSoughtModule;
   else
      g_assert( 0 );

  /*
   * Record what to find (for when the user does a subsequent search, eg Find Again).
   * Extract the text from the entry widget.
   */
   *ppSought = \
   g_string_new( gtk_editable_get_chars( GTK_EDITABLE(GTK_ENTRY(GTK_COMBO(pWidgetComboFind)->entry)),
                                         0, -1 ) );

  /*
   * Is what to find empty?
   */
   if ( ((*ppSought)->str)[0] == '\0' ) return;

  /*
   * Record what to find for the next creation of the find combo widget.
   */
   PrependComboDropDown( (*ppSought)->str,
                         ppGlistFindStrings );


  /*
   * Update the drop-down of the find combo.
   * (Helps the user who is repeatedly entering typos and wants to refer
   *  previous attempts.)
   */
   gtk_combo_set_popdown_strings( GTK_COMBO(pWidgetComboFind),
                                  *ppGlistFindStrings );

  /*
   * Defer to the appropriate find tag/text function.
   */
   if ( soughtType == MENU_ITEM_FIND_TAG )
   {
      SetSensitivityWhileBusy( FALSE );
      RecordCursorInTagHistory( "(recorded position)" );
      FindTagCheckMultipleMatches( (*ppSought)->str,
                                   SEEKING_ANY_TAG,
                                   NULL,
                                   widgetTagsClistSelectedRow,
                                   findExactTag,
                                   findCaseSensTag,
                                   autoSelectNotebookPage,
                                   "Multiple tags match (press Enter or click Find for next one)." );
      ScheduleUpdateFuncTree();
      SetSensitivityWhileBusy( TRUE );
   }
   else
   if ( soughtType == MENU_ITEM_FIND_TEXT )
   {
      if ( ! findGlobal )
      {
         FindStringInTextWidget( (*ppSought)->str,
                                 TRUE,   /* wrap if necessary */
                                 FALSE,  /* loud */
                                 TRUE,   /* scroll/highlight match */
                                 NULL    /* don't care which line # */ );
      }
      else
      {
         SetSensitivityWhileBusy( FALSE );
         FindStringGlobal( (*ppSought)->str,
                           FALSE,	/* loud */
                           TRUE		/* stop search if find dialog is closed */  );
         SetSensitivityWhileBusy( TRUE );
      }
   }
   else
   if ( soughtType == MENU_ITEM_FIND_MODULE )
   {
      SetSensitivityWhileBusy( FALSE );
      SearchClistWidget( (*ppSought)->str,
                         SEEKING_ANY_TAG,
                         NULL,
                         pWidgetClistModules,
                         widgetModulesClistSelectedRow,
                         findExactModule,
                         findCaseSensModule,
                         FALSE, /* be loud */
                         autoSelectNotebookPage,
                         TRUE	/* do select row */ );
      SetSensitivityWhileBusy( TRUE );
   }
   else
      g_assert( 0 );

   return;
}

/*****************************************************************************
 * Called when the "case sensitive" or "exact match" check button
 * of a find dialog is toggled.
 *****************************************************************************/
void
CheckButtonFindToggledBool( GtkWidget* pWidget,
                            gpointer   pVarBool )
{
  /*
   * Invert one of the global bools that control searching.
   */
#ifdef HYPERSRC_PEDANTIC
g_return_if_fail(    (pVarBool == &findExactTag)
                  || (pVarBool == &findExactModule)
                  || (pVarBool == &findCaseSensText)
                  || (pVarBool == &findCaseSensTag)
                  || (pVarBool == &findCaseSensModule) );
#endif

   if ( GTK_TOGGLE_BUTTON(pWidget)->active )
      *(gboolean*)pVarBool = TRUE;
   else
      *(gboolean*)pVarBool = FALSE;
}

/*****************************************************************************
 * Called when the "global" check button of a find dialog is toggled.
 *
 * Toggle the global var "findGlobal".
 *****************************************************************************/
void
CheckButtonFindGlobalToggled( GtkWidget* pWidget,
                              gpointer   pData )
{
   if ( soughtType == MENU_ITEM_FIND_TEXT )
      findGlobal = !findGlobal;
}

/*****************************************************************************
 * Called when the "reverse" check button of a find dialog is toggled.
 *
 * Toggle the global var "findReverse".
 *****************************************************************************/
void
CheckButtonFindReverseToggled( GtkWidget* pWidget,
                               gpointer   pData )
{
   if ( soughtType == MENU_ITEM_FIND_TEXT )
      findReverse = !findReverse;
}

/*****************************************************************************
 * Called when the "regex" check button of a find dialog is toggled.
 *
 * Toggle the global var "regex".
 *****************************************************************************/
void
CheckButtonFindRegexToggled( GtkWidget* pWidget,
                             gpointer   pData )
{
   if ( soughtType == MENU_ITEM_FIND_TEXT )
      regex = !regex;
}
