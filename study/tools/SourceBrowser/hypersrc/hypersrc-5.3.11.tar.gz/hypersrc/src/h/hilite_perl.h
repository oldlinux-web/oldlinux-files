/******************************************************************************
 * $Id: hilite_perl.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef HILITE_PERL_H
#define HILITE_PERL_H

gboolean
HilitePerl( GtkWidget* pWidget,
            char*      pBuffer,
            int        bufferSize,
            int        srcFileKind );

gboolean
HilitePerlString( GtkWidget*  pWidget,
                  const char* pStr,
                  int         strSize,
                  char        precedingChar,
                  char*       pScratch,
                  int         srcFileKind );

int
ParsePerlArg( const char* pc,
              const char* pBufEnd );

int
IsPerlVarChar( char c );

int
IsPerlSymbolChar( char c );

const char*
FindPerlSymbolVarChar( const char* pStr,
                       int         len,
                       gboolean    includeVarChars );

#endif /* HILITE_PERL_H */
