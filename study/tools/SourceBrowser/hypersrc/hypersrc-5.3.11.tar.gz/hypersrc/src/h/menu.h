/******************************************************************************
 * $Id: menu.h,v 1.3 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef MENU_H
#define MENU_H

void
SetSensitivityMenubar( gboolean sensitive );

void
CreateMenubar( GtkWidget* pWidgetHbox );

void
MenuItemSelected( gpointer   pData,
                  guint      menuItem,
                  GtkWidget* pWidget );

void
RunEditor( char* pEditor );

void
MenuItemFindTag( void );

void
CreateFindDialog( MENU_ITEM menuItem );

void
FindDialogClose( void );

void
FindDialogClickedFind( void );

void
CheckButtonFindToggledBool( GtkWidget* pWidget,
                            gpointer   pVarBool );

void
CheckButtonFindGlobalToggled( GtkWidget* pWidget,
                              gpointer   pData );

void
CheckButtonFindReverseToggled( GtkWidget* pWidget,
                               gpointer   pData );

void
CheckButtonFindRegexToggled( GtkWidget* pWidget,
                             gpointer   pData );

#endif /* MENU_H */
