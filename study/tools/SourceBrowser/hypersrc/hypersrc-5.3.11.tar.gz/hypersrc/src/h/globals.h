/******************************************************************************
 * $Id: globals.h,v 1.8 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Global data.
 ******************************************************************************/

#ifndef GLOBALS_H
#define GLOBALS_H

#ifdef HYPERSRC_DEFINE_GLOBALS
#define GLOBAL
#define INIT(x) = x
#else
#define GLOBAL		extern
#define INIT(x) 
#endif

/*
 * Pointers to widgets.
 */
GLOBAL GtkWidget*      pWidgetMain;
GLOBAL GtkWidget*      pWidgetVboxMain;
GLOBAL GtkWidget*      pWidgetToolbar;
GLOBAL GtkWidget*      pWidgetToolbarButtonGotoLine;
GLOBAL GtkWidget*      pWidgetToolbarButtonGotoTag;
GLOBAL GtkWidget*      pWidgetToolbarButtonLaterTag;
GLOBAL GtkWidget*      pWidgetToolbarButtonEarlierTag;
GLOBAL GtkWidget*      pWidgetToolbarButtonFindMatches;
GLOBAL GtkWidget*      pWidgetToolbarButtonRecordCursor;
GLOBAL GtkWidget*      pWidgetNotebook;
GLOBAL GtkWidget*      pWidgetModuleTree;
GLOBAL GtkWidget*      pWidgetFuncTreeRoot;
GLOBAL GtkWidget*      pWidgetFrameFuncTree;
GLOBAL GtkWidget*      pWidgetClistTags;
GLOBAL GtkWidget*      pWidgetClistFound;
GLOBAL GtkWidget*      pWidgetClistModules;
GLOBAL GtkWidget*      pWidgetClistHistory;
GLOBAL GtkWidget*      pWidgetScrolledTags;
GLOBAL GtkWidget*      pWidgetScrolledFound;
GLOBAL GtkWidget*      pWidgetScrolledModules;
GLOBAL GtkWidget*      pWidgetScrolledHistory;
GLOBAL GtkWidget*      pWidgetScrolledModuleTree;
GLOBAL GtkWidget*      pWidgetScrolledFuncTree;
GLOBAL GtkWidget*      pWidgetTextMain;
GLOBAL GtkWidget*      pWidgetTextAux;
GLOBAL GtkWidget*      pWidgetTextActive;		/* points to either main/aux text widgets */

GLOBAL GtkWidget*      pWidgetVboxTextMain;
GLOBAL GtkWidget*      pWidgetTableTextMain;
GLOBAL GtkWidget*      pWidgetHscrollTextMain;
GLOBAL GtkWidget*      pWidgetVscrollTextMain;

GLOBAL GtkWidget*      pWidgetVboxTextAux;
GLOBAL GtkWidget*      pWidgetTableTextAux;
GLOBAL GtkWidget*      pWidgetHscrollTextAux;
GLOBAL GtkWidget*      pWidgetVscrollTextAux;

GLOBAL GtkWidget*      pWidgetPaned;
GLOBAL GtkWidget*      pWidgetPanedFuncTree;
GLOBAL GtkWidget*      pWidgetPanedText;
GLOBAL GtkWidget*      pWidgetStatusbar;
GLOBAL GtkWidget*      pWidgetDialogFind;
GLOBAL GtkWidget*      pWidgetDialogLine;
GLOBAL GtkWidget*      pWidgetComboFind;
GLOBAL GtkWidget*      pWidgetComboLine;
GLOBAL GtkWidget*      pWidgetCheckButtonFindExact;
GLOBAL GtkWidget*      pWidgetCheckButtonFindCase;
GLOBAL GtkWidget*      pWidgetCheckButtonFindGlobal;
GLOBAL GtkWidget*      pWidgetCheckButtonFindReverse;
GLOBAL GtkWidget*      pWidgetCheckButtonFindRegex;
GLOBAL GtkWidget*      pWidgetCheckButtonFunctree;
GLOBAL GtkWidget*      pWidgetFontSel;
GLOBAL GtkWidget*      pWidgetWithFocus;
GLOBAL GtkAccelGroup*  pAccelGroup;
GLOBAL GtkItemFactory* pItemFactory;

/*
 * Text widget state.
 */
GLOBAL cursor_t cursorText;
#if 0 /* old behavior: */
GLOBAL int textWidgetBehavior INIT(SWITCH_PER_AUX_TEXT_KEY);
#else /* new behavior (default): */
GLOBAL int textWidgetBehavior INIT(DONT_SWITCH_UNLESS_AUX_TEXT_KEY);
#endif
GLOBAL int scrolling  INIT(0); /* reported if SIGSEGV happens */
GLOBAL int scrollLine INIT(0); /* reported if SIGSEGV happens */

/*
 * Focusbars.
 */
GLOBAL focusbar_t* pFocusbarTextMain;
GLOBAL focusbar_t* pFocusbarTextAux;
GLOBAL focusbar_t* pFocusbarTextActive;
GLOBAL gboolean keepFocusbarLit INIT(TRUE); /* if TRUE, focusbars over text widgets tend to stay lit, even when other widgets have the focus */

/*
 * Tag and tag clist widget state.
 */
GLOBAL GList*	pGlistTags;								/* pointer to a glist of tag_t structs */
GLOBAL GHashTable* pHashTagsFabricated;					/* tags fabricated by hypersrc */
GLOBAL GHashTable* pHashFuncTagsAll;					/* all func/macro/method tags */
GLOBAL int		ctagsLines;								/* inc'd by ProcessCtagsBuf() */
GLOBAL int      tagsCnt;								/* same as g_list_length( pGlistTags ) */
GLOBAL GList*	pGlistFoundTags;						/* list of tagged lines resulting from Find/Global */
GLOBAL int		widgetTagsClistWidthCol[WIDGET_TAGS_CLIST_COLUMNS];
GLOBAL int		widgetFoundClistWidthCol[WIDGET_FOUND_CLIST_COLUMNS];
GLOBAL gint		widgetTagsClistSelectedRow INIT(ROW_NONE);
GLOBAL int		tagSortInitial INIT(SORT_UNSORTED);		/* how tags are initially sorted */
GLOBAL int		tagsSorted;								/* amount of sorted tags */
GLOBAL int		tagsSortedPercentShown;					/* {0,5,10,..95} percentage being shown by statusbar */
GLOBAL int		textLeft INIT(FALSE);
GLOBAL int		textLeftApplied;
GLOBAL int		tagsColumnsLayout INIT(TAG_COL_LAYOUT_TAG_MODULE_TYPE_LINE);
GLOBAL int		tagsLineColumn INIT(3);

/*
 * Modules clist widget state.
 */
GLOBAL int		widgetModulesClistWidthCol[WIDGET_MODULES_CLIST_COLUMNS];
GLOBAL gint		widgetModulesClistSelectedRow INIT(ROW_NONE);
GLOBAL int      returnEarlyModuleSelectCallback INIT(FALSE);

/*
 * History clist widget state.
 */
GLOBAL int		widgetHistoryClistWidthCol[WIDGET_HISTORY_CLIST_COLUMNS];
GLOBAL gint		widgetHistoryClistSelectedRow INIT(ROW_NONE);
GLOBAL gboolean prependingTagHistory INIT(FALSE);
GLOBAL gboolean activeHistoryRowSelect INIT(FALSE);
GLOBAL GSList*  pGslistHistoryCursor;					/* records cursor positions */

/*
 * State for all clists.
 */
GLOBAL gboolean rowSelectedByProgram INIT(0);

/*
 * Tree state.
 */
GLOBAL gboolean funcTreeVerbose INIT(TRUE);				/* also affects module tree */
GLOBAL gboolean disableFuncTreeUpdates INIT(FALSE);		/* corresponds to a check button */
GLOBAL gboolean fontifyFuncTrees INIT(TRUE);			/* whether to use different fonts in func trees */

/*
 * Notebook state.
 */
GLOBAL gint	    notebookPageWithSelectedRow;
GLOBAL gboolean notebookPageFound INIT(FALSE);
GLOBAL gboolean kludgeNotebookSwitchPage INIT(FALSE);
GLOBAL gboolean autoSelectNotebookPage INIT(TRUE);		/* auto-select will work regardless in some sensible cases */

/*
 * Paned widget state.
 */
GLOBAL gint	    panedSliderPercent			INIT(0);	/* ## set by config, thereafter, is stale ##  */
GLOBAL gint	    panedSliderFuncTreePercent	INIT(0);	/* ## set by config, thereafter, is stale ##  */
GLOBAL gint	    panedSliderTextPercent		INIT(0);	/* ## set by config, thereafter, is stale ##  */

/*
 * Statusbar state.
 */
GLOBAL guint	statusbarContextId;
GLOBAL guint	statusbarMsgs INIT(0);
GLOBAL gint		statusbarRow INIT(ROW_NONE);
GLOBAL gchar*	pStatusbarInitMsg;
GLOBAL GString* pGStringStatusbarMsg;			/* access this using Get[Record]StatusbarMsg() */
GLOBAL gint     timerStatusbar INIT(0);

/*
 * Misc. widget state.
 */
GLOBAL gboolean widgetsReady INIT(FALSE);
GLOBAL gint		widgetMainGeom[4];			/* x/y/w/h of main window */
GLOBAL gchar    mainWindowTitle[256];
GLOBAL gboolean toolbarPlacement INIT(TOOLBAR_PLACEMENT_BELOW);
GLOBAL gboolean kludgeWidgetGeomUseGetPosition INIT(TRUE);

/*
 * Keyboard state.
 */
GLOBAL gboolean auxKeyPressed INIT(FALSE);	/* if pressed, tagged line will be shown in aux. text widget */
GLOBAL int		auxKeyGdkKeyval INIT(GDK_Shift_L);
GLOBAL int		auxKeyGdkMask   INIT(GDK_SHIFT_MASK);
GLOBAL gboolean treeKeyPressed INIT(FALSE);	/* if pressed, disables tree updates */
GLOBAL int      treeKeyGdkKeyval INIT(GDK_Control_L);
GLOBAL int		treeKeyGdkMask   INIT(GDK_CONTROL_MASK);

/*
 * Find state.
 */
MENU_ITEM	soughtType;				/* either a tag or a text string */
GString*	pSoughtTag;
GString*	pSoughtText;
GString*	pSoughtModule;
gboolean	findCaseSensText   INIT(FALSE);		/* for string searches */
gboolean	findCaseSensTag    INIT(FALSE);		/* for tag    searches */
gboolean	findCaseSensModule INIT(FALSE);		/* for module searches */
gboolean	findExactTag	 INIT(FALSE);		/* for tag    searches */
gboolean	findExactModule  INIT(FALSE);		/* for module searches */
gboolean    findGlobal INIT(FALSE);				/* for string searches */
gboolean	findReverse;						/* for string searches */
gboolean	regex INIT(FALSE);
gboolean    searchMethodFoundPage;              /* results from normal or regex searching */
gint		searchDefault INIT(SEARCH_NORMAL);  /* default search method */
gint		regexScope INIT(REGEX_SCOPE_LINE);  /* scope of regex matching (one line or file) */
gint        findGeom[4];
GList**		ppGlistFindStrings;		/* ptr to pGlistFindStrings[Tag,Text,Module] */
GList*		pGlistFindStringsTag;
GList*		pGlistFindStringsText;
GList*		pGlistFindStringsModule;

/*
 * Goto line widget state.
 */
GList*		pGlistLineStrings;

/*
 * Dialog widget state.
 */
GLOBAL gboolean buttonWordAtCursorFlag INIT(FALSE);
GLOBAL gboolean buttonRestoreCursorFlag INIT(FALSE);
GLOBAL gboolean dialogPlacement INIT(DIALOG_PLACEMENT_DEFAULT_WM);

/*
 * Variables assigned via the command line (or GNOME config).
 */
GLOBAL gint     tabWidth INIT(0);
GLOBAL gboolean hilite INIT(TRUE);
GLOBAL gboolean skipFuncTree INIT(FALSE);	/* also affects module tree -- can't be changed if tree was built!!! */
GLOBAL gboolean skipFuncTree_pref;			/* pref code should affect this instead */
GLOBAL gboolean vimExists INIT(FALSE);
GLOBAL gboolean browsingCPlusPlus INIT(FALSE);
GLOBAL gboolean classQual INIT(FALSE);

/*
 * Colors of the clist widgets.
 */
GLOBAL GdkColor colorClistWidgetTextFg
#ifdef HYPERSRC_DEFINE_GLOBALS
= { 0,
    COLOR_CLIST_WIDGET_TEXT_FG_RED,
    COLOR_CLIST_WIDGET_TEXT_FG_GREEN,
    COLOR_CLIST_WIDGET_TEXT_FG_BLUE };
#else
;
#endif

GLOBAL GdkColor colorClistWidgetTextBg
#ifdef HYPERSRC_DEFINE_GLOBALS
= { 0,
    COLOR_CLIST_WIDGET_TEXT_BG_RED,
    COLOR_CLIST_WIDGET_TEXT_BG_GREEN,
    COLOR_CLIST_WIDGET_TEXT_BG_BLUE };
#else
;
#endif

GLOBAL GdkColor colorClistWidgetSelFg
#ifdef HYPERSRC_DEFINE_GLOBALS
= { 0,
    COLOR_CLIST_WIDGET_SEL_FG_RED,
    COLOR_CLIST_WIDGET_SEL_FG_GREEN,
    COLOR_CLIST_WIDGET_SEL_FG_BLUE };
#else
;
#endif

GLOBAL GdkColor colorClistWidgetSelBg
#ifdef HYPERSRC_DEFINE_GLOBALS
= { 0,
    COLOR_CLIST_WIDGET_SEL_BG_RED,
    COLOR_CLIST_WIDGET_SEL_BG_GREEN,
    COLOR_CLIST_WIDGET_SEL_BG_BLUE };
#else
;
#endif

/*
 * Colors of the text widget.
 */
GLOBAL GdkColor colorTextWidgetTextFg
#ifdef HYPERSRC_DEFINE_GLOBALS
= { 0,
    COLOR_TEXT_WIDGET_TEXT_FG_RED,
    COLOR_TEXT_WIDGET_TEXT_FG_GREEN,
    COLOR_TEXT_WIDGET_TEXT_FG_BLUE };
#else
;
#endif

GLOBAL GdkColor colorTextWidgetTextBg
#ifdef HYPERSRC_DEFINE_GLOBALS
= { 0,
    COLOR_TEXT_WIDGET_TEXT_BG_RED,
    COLOR_TEXT_WIDGET_TEXT_BG_GREEN,
    COLOR_TEXT_WIDGET_TEXT_BG_BLUE };
#else
;
#endif

GLOBAL GdkColor colorTextWidgetSelFg
#ifdef HYPERSRC_DEFINE_GLOBALS
= { 0,
    COLOR_TEXT_WIDGET_SEL_FG_RED,
    COLOR_TEXT_WIDGET_SEL_FG_GREEN,
    COLOR_TEXT_WIDGET_SEL_FG_BLUE };
#else
;
#endif
GLOBAL GdkColor colorTextWidgetSelBg
#ifdef HYPERSRC_DEFINE_GLOBALS
= { 0,
    COLOR_TEXT_WIDGET_SEL_BG_RED,
    COLOR_TEXT_WIDGET_SEL_BG_GREEN,
    COLOR_TEXT_WIDGET_SEL_BG_BLUE };
#else
;
#endif

/*
 * Hash table for modules.
 * For speed, a hash table, not a list, is used because module names are recorded
 * (in addition to other info) while processing all the ctags lines.
 */
GLOBAL GHashTable* pHashModules;

/*
 * Hash item of module recently loaded from a file
 * (NOT NECESSARILY THE ONE SHOWN IN TEXT WIDGET!!!)
 * Note when a module is freed, this will still point to its hash item (it won't be nullified).
 */
GLOBAL module_t* pModuleLoaded;

/*
 * Sorted list of module names (derived from pHashModules).
 * Used to build the modules clist widget (in notebook).
 */
GLOBAL GList* pGlistModuleNames;	/* created when tag clist is populated */

/*
 * Name of file which holds tags.
 */
GLOBAL char*	pTagsFilename;

/*
 * Maximum amount of tags that can be processed (affected by --max-tags arg).
 */
GLOBAL int	maxTags INIT(MAX_TAGS_DEFAULT);
GLOBAL gboolean tooManyTags INIT(FALSE);

/*
 * Misc flags.
 */
GLOBAL int	showLineColumn INIT(TRUE);
GLOBAL int	enableProcessPendingEvents INIT(TRUE);
GLOBAL int  argQuiet INIT(FALSE);		/* true if -q was passed */
GLOBAL int  argVerbose INIT(FALSE);		/* true if -v/-status was passed */

/*
 * Flags affecting memory/speed tradeoff.
 */
GLOBAL int	conserveMemory INIT(TRUE);  /* conserve memory at expense of speed (can change) */
GLOBAL int  speed          INIT(FALSE); /* inverse of conserveMemory (can change) */
GLOBAL int  argSpeed       INIT(FALSE); /* true if -speed was passed (stays true) */

/*
 * Tag sort levels.
 */
GLOBAL int	sort1;
GLOBAL int	sort2;
GLOBAL int	sort3;

/*
 * Font names.
 */
GLOBAL char	fontNameText[MAX_FONT_NAME_LEN];
GLOBAL char	fontNameList[MAX_FONT_NAME_LEN];
GLOBAL char	fontNameTree[MAX_FONT_NAME_LEN];
GLOBAL char	fontNameHiliteComment[MAX_FONT_NAME_LEN];
GLOBAL char	fontNameHiliteKeyword[MAX_FONT_NAME_LEN];
GLOBAL char	fontNameHiliteType[MAX_FONT_NAME_LEN];
GLOBAL char	fontNameHiliteSymbol[MAX_FONT_NAME_LEN];
/* -- copies -- */
GLOBAL char	fontNameTextCopy[MAX_FONT_NAME_LEN];
GLOBAL char	fontNameListCopy[MAX_FONT_NAME_LEN];
GLOBAL char	fontNameTreeCopy[MAX_FONT_NAME_LEN];
GLOBAL char	fontNameHiliteCommentCopy[MAX_FONT_NAME_LEN];
GLOBAL char	fontNameHiliteKeywordCopy[MAX_FONT_NAME_LEN];
GLOBAL char	fontNameHiliteTypeCopy[MAX_FONT_NAME_LEN];
GLOBAL char	fontNameHiliteSymbolCopy[MAX_FONT_NAME_LEN];
/* -- derived from fontNameTree -- */
GLOBAL char fontNameTreeModule[MAX_FONT_NAME_LEN];
GLOBAL char fontNameTreeFuncDef[MAX_FONT_NAME_LEN];
GLOBAL char fontNameTreeFuncCall[MAX_FONT_NAME_LEN];

/*
 * Busy state of major outer-level functions.
 * Interrupting a major function to run another one
 * might confuse GTK+ and this program itself.
 * This concern is a caveat of using ProcessPendingEvents()
 * which could otherwise lead to nesting of events.
 */
gboolean	busy_FindStringGlobal			INIT(FALSE);
gboolean	busy_FindDialogClickedFind		INIT(FALSE);
gboolean	busy_PopulateTagsClistWidget	INIT(FALSE);
gboolean	busy_GotoTagUnderCursor			INIT(FALSE);
gboolean	busy_FindMatchesUnderCursor		INIT(FALSE);
gboolean	busy_SearchClistWidget_tag		INIT(FALSE);
gboolean	busy_SearchClistWidget_module	INIT(FALSE);
gboolean	busy_StepHistoryList			INIT(FALSE);
gboolean	busy_PropertyPageApply			INIT(FALSE);
	/* -- don't forget to update IsAnyMajorFunctionBusy() -- */

/*
 * Busy state of other functions.
 */
gboolean	busy_UpdateFuncTree						INIT(FALSE);
gboolean	busy_HyperjumpViaTreeNodeOrItem_cb		INIT(FALSE);
gboolean	busy_HyperjumpToModuleViaModuleTree_cb	INIT(FALSE);
gboolean	busy_HandlerFuncDefTreeExpand_cb		INIT(FALSE);
gboolean	busy_HandlerModuleTreeExpand_cb			INIT(FALSE);
	/* -- don't forget to update IsAnyTreeFunctionBusy() -- */
gboolean	SetSensitivityWhileBusy_cnt				INIT(0);

/*
 * Misc.
 */
GLOBAL gboolean ctagsStdin INIT(FALSE);
GLOBAL gboolean acceptAllTags INIT(FALSE);
GLOBAL gboolean printStatusMsgs INIT(FALSE);	/* controls StatusMsg() */
GLOBAL gboolean tagProcessingComplete INIT(FALSE);
GLOBAL int      maxModules INIT(MAX_MODULES_DEFAULT);

/*
 * Vars for debugging/profiling.
 */
#ifdef HYPERSRC_DEBUG
GTimeVal timeval1;
GTimeVal timeval2;
#endif

#endif /* GLOBALS_H */
