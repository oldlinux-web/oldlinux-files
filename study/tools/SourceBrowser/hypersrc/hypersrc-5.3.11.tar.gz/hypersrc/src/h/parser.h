/*****************************************************************************
 * $Id: parser.h,v 1.5 2003/02/10 16:18:48 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: 
 *****************************************************************************/

#ifndef PARSER_H
#define PARSER_H

#if 0
#define DEBUG
#endif

#ifndef DEBUG
#define LEX_YACC_QUIET
#endif
#define MAX_ID_LEN		256

extern int
OccurrencesInString( const char* pc,
                     char        c );

#ifdef DEBUG

#ifndef DebugMsg
#define DebugMsg( format, args...) \
{\
   printf(format , ## args);\
   printf( "\n" );\
}
#endif

#else /* !DEBUG */

#ifndef DebugMsg
#define DebugMsg( format, args...)
#endif

#endif /* DEBUG */

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

enum
{
   PARSER_MODE_HYPERSRC,	/* for hypersrc */
   PARSER_MODE_PRINTF		/* output via printf() */
};

/*
 * Macros.
 */
#ifndef MAX
#define MAX(a,b) ((a > b) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a,b) ((a < b) ? (a) : (b))
#endif

/*
 * yacc (public)
 */
void
ParseFuncsInModule( char* pInput, unsigned int inputSize, char* pInputName, int debug );

/*
 * yacc (internal)
 */
#ifdef PARSER_Y

static void
ParserCreate( int mode, int strHeapSize );

static void
ParserDelete( void );

static void
ParserReset( int howMuchToReset );

static void
ParserErrorRecover( void );

#endif /* PARSER_Y */

/*
 * lex (public)
 */
void*
LexBufferUse( char* buf );

void
LexBufferDiscard( void* hnd );

/*
 * lex (internal)
 */
#ifdef PARSER_L

static int
LexToken( int token );

static void
LexReset( void );

static void
LexErrorRecover( void );

#endif /* PARSER_L */

#endif /* PARSER_H */
