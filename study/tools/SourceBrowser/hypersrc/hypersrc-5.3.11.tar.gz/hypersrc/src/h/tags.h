/******************************************************************************
 * $Id: tags.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef TAGS_H
#define TAGS_H

void
PrepareProcessCtags( void );

void
ProcessCtagsFromFile( char* pFilename );

char*
ReadCtagsFromFile( guint* pCtagsSize, /* OUT */
                   char*  pFilename );

void
ProcessCtagsFromStdin( void );

GList*
ProcessCtagsBuf( char* pCtags,
                 guint ctagsSize );

FUNC_X
ProcessCtagsLine( const char* pLine,
                  GList**     ppGlist, /*IN/OUT*/
                  tag_t**     ppTag ); /*OUT*/

void
MinimizeTagStruct( tag_t* pTag,
                   GList*      pGlist );

tag_t*
AllocTagStruct( void );

void
FreeTagStruct( tag_t* pTag );

void
FillTagStruct( tag_t*  pTag,
               gchar*  pName,
               gint    lineNum,
               gchar*  pType,
               gchar*  pModuleName );

gboolean
IsTagFabricated( tag_t* pTag );

tag_t*
FabricateFuncCallTag( char* pFuncCallId,
                      int   lenFuncCallId );

const char*
CheckTagType( const char* pTagType );

gboolean
IsFuncLikeTag( tag_t* pTag );

int
IsTagChar( gchar c );

tag_t*
FindTag( char* pTagName,
         char* pTagType );

tag_t*
FindFuncTag( char*     pName,
             module_t* pModule );

tag_t*
FindFuncTagAnyOtherModule( char*  pName,
                           GList* pLinkModuleCurrent );

guint
HashFuncTagsKey( gconstpointer pTagName );

gint
HashFuncTagsCmp( gconstpointer pTagName1,
                 gconstpointer pTagName2 );

void
GotoTagUnderCursor( void );

void
ResortTagsGlist( int sort );

gint
ResortTagsGlistCompare( gconstpointer pTag1,
                        gconstpointer pTag2 );

inline gint
CompareTags( const tag_t* pTag1,
             const tag_t* pTag2,
             int          member );

void
WarnTooManyTags( void );

#endif /* TAGS_H */
