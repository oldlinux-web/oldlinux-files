/******************************************************************************
 * $Id: toolbar.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef TOOLBAR_H
#define TOOLBAR_H

void
CreateToolbar( GtkWidget* pWidgetHbox );

#endif /* TOOLBAR_H */
