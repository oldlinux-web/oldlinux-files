/******************************************************************************
 * $Id: file.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef FILE_H
#define FILE_H

char*
LoadFile( gchar* pFileName,
          guint* pFileSize /* OUT */ );

GString*
LoadFileSpecial( gchar* pFileName );

long
FileSize( gchar* pFilename );

int
FileSuffixMatch( char* pFilename,
                 char* pSuffix );

int
WhichKindOfSrcFile( char* pFilename );

int
IsSrcFileCish( char* pFilename );

int
IsSrcFileC( char* pFilename );

int
IsSrcFileCPlusPlus( char* pFilename );

int
IsSrcFileJava( char* pFilename );

int
IsSrcFileAsm( char* pFilename );

int
IsSrcFilePerl( char* pFilename );

int
IsSrcFileForth( char* pFilename );

FUNC_X
FilterMsdosCr( char*  pBufOld,
               int    sizeOld,
               char** ppBufNew, /*OUT*/
               int*   pSizeNew  /*OUT*/ );
#endif /* FILE_H */
