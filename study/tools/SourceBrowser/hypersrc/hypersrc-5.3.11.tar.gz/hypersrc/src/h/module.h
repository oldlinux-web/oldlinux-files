/******************************************************************************
 * $Id: module.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef MODULE_H
#define MODULE_H

char*
ModuleBuffer( gchar* pModuleName,
              guint* pModuleSize /* OUT */ );

void
FreeModuleBuffer( gchar* pModuleName );

module_t*
HashDebutModule( char* pModuleName );/* ## CALLER MUST PASS PERMANENT STRING!! ## */

guint
HashModuleKey( gconstpointer pModuleName );

gint
HashModuleCmp( gconstpointer pModuleName1,
               gconstpointer pModuleName2 );

void
CreateModuleNameGlist( void );

void
AddSortedModuleGlist( gpointer pModuleName,
                      gpointer pUnused,
                      gpointer ppGlist );

#endif /* MODULE_H */
