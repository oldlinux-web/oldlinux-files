/******************************************************************************
 * $Id: prefs.h,v 1.3 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef PREFS_H
#define PREFS_H

void
EditPrefs( void );

GtkWidget*
CreatePropertyPageFont( void );

GtkWidget*
CreatePropertyPageLayout( void );

GtkWidget*
CreatePropertyPageNumbers( void );

GtkWidget*
CreatePropertyPageMisc( void );

GtkWidget*
CreatePropertyPageSearch( void );

GtkWidget*
CreatePropertyPageKeyboard( void );

void
HandlerPropertyPageFontButton( GtkWidget* pWidget,
                               gpointer   pStr );

void
HandlerFontSelOk( GtkWidget*              pWidget,
                  GtkFontSelectionDialog* pWidgetFsd );

void
HandlerFontSelCancel( GtkWidget*              pWidget,
                      GtkFontSelectionDialog* pWidgetFsd );

void
HandlerPropertyPageEntryModified( GtkWidget* pWidget,
                                 gpointer   pUnused );

void
HandlerPropertyPageToggle( GtkWidget* pWidget,
                           gpointer   pUnused );

void
HandlerPropertyPageApply( GtkWidget* pWidget,
                          gint       page,
                          gpointer   pUnused );

gint
HandlerPropertyPageClose( GnomeDialog* pGnomeDialog,
                          gpointer     pUnused );

void
SaveFontNames( void );

void
RestoreFontNames( void );

int
ApplyFonts( gboolean applyTreeFont );

#endif /* PREFS_H */
