/******************************************************************************
 * $Id: funcmisc.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef FUNCMISC_H
#define FUNCMISC_H

funcDef_t*
FindFuncDefByItsTag( tag_t* pTagFuncDefSought );

funcDef_t*
FindFuncDefByItsTagInOneModule( tag_t* pTagFuncDefSought,
                                gchar* pModuleName );
funcDef_t*
SearchFuncDefList( int line );

gboolean
IsModuleOfFuncKnown( tag_t* pTagFunc );

gboolean
FilterDuplicateFuncCalls( GSList*     pFuncCallList,
                          funcCall_t* pFuncCall );

#endif /* FUNCMISC_H */
