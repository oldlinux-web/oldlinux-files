/******************************************************************************
 * $Id: utils.h,v 1.4 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef UTILS_H
#define UTILS_H

#include <regex.h>

/* --- inline --- */

extern inline int
IsWhitespace( char c );

extern inline int
IsCSymbolChar( char c );

extern inline const char*
FindCSymbolChar( const char* pStr,
                 int         len );

extern inline int
IsEolUnix( const char* pc );

extern inline int
IsEolMsdos( const char* pc );

extern inline int
IsEol( const char* pc );

extern inline int
IsLineEmpty( const char* pLine );

extern inline void
CopyChars( char*       pDest,
           const char* pSrc,
           int         amount );

extern inline const char*
PastWord( const char* pWord,
          int         size );

extern inline const char*
PastWhitespace( const char* pc,
                int         max );

extern inline char*
CreateString( int size );

extern inline char*
CloneString( const char* src );

extern inline void
DeleteString( char* p );

extern inline int
CompareStrings( const char* s1,			/* -- Don't replace this with strcmp()!!! -- */
                const char* s2 );

extern inline int
CompareStringsNonCase( const char* s1,	/* -- Don't replace this with strcmp()!!! -- */
                       const char* s2 );

/* -------------- */

FUNC_X
ParseWord( const char*  pc,
           const char** ppWord,
           int          max );

FUNC_X
ParseWordAlphanum( const char*  pc,
                   const char** ppWord,
                   int          max );

const char*
NextLine( const char* pc,
          int         max );

const char*
ToLine( const char*	pc,
        int		line,
        int		maxLineSize );

char*
ToEol( const char* pLine,
       int         max );

gint
LineIdx2LineNum( gchar* pText,
                 gint   idx );

const char*
PastEol( const char* pc );

int
IsWordChar( gchar c );

char*
ExtractLine( const char* pLine,
             int         maxLineLen );

GString*
CreateGString( char* pInit,
               int   len );

#ifdef HYPERSRC_SPEED
#define StrLen strlen
#else
size_t
StrLen( const char* pStr );
#endif

#ifdef HYPERSRC_SPEED
#define FindSubstr strstr
#else
char*
FindSubstr( const char* pHaystack,
            const char* pNeedle );
#endif

char*
FindSubstrI( const char* pHaystack,
             const char* pNeedle );

char*
FindSubstrSegment( const char* pHaystack,
                   int         haystackLen,
                   const char* pNeedle,
                   gboolean    caseSens );


char*
FindSubstrReverse( const char* pHaystackTop,
                   const char* pHaystackBottom,
                   const char* pNeedle,
                   P_FUNC_STRCMPX pFuncCmp );

char*
FindRegexSegment( int*        pMatchLen,
                  const char* pHaystack,
                  int         haystackLen,
                  const char* pNeedle,
                  gboolean    caseSens,
                  gboolean    reverse,
                  int         cflags_newline );

int
OccurrencesInString( const char* pc,
                     char        c );

gboolean
IsStringValid( const char* str, int maxLen );

void
FreeGlistDynamic( GList* pGlist );

void
FreeGlistDynamicFreeElem( gpointer pData,
                          gpointer pUnused );

gint
HashStrcmp( gconstpointer pKey1,
            gconstpointer pKey2 );

guint32
ElfHash( const guchar* pKey,
         guint32       h );

GList*
fast_g_list_append( GList*   list,
                    gpointer data,
                    GList**  last /* IN/OUT */ );

void
ExtractDirFromPathname( const char* pPathname,
                        char**      ppDirBegin, /*OUT*/
                        char**      ppDirEnd    /*OUT*/ );

int
ExtractPathFromPathname( char* pPathname );

char*
ExtractFilenameFromPathname( char* pPathname );

#include "utils_inline.h"

#endif /* UTILS_H */
