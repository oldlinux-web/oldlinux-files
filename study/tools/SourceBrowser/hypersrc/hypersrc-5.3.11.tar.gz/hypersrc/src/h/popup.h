/******************************************************************************
 * $Id: popup.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef POPUP_H
#define POPUP_H

void
Popup( char*    pMsg,
       char*    pTitle,
       int      whichFont );

void
PopupClose( GtkWidget* pWidget,
            gpointer   pData );

void
PopupClosing( GtkWidget* pWidget,
              gpointer   pData );

#endif /* POPUP_H */
