/******************************************************************************
 * $Id: list.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef LIST_H
#define LIST_H

void
CreateTagsClistWidget( void );

void
CreateInvisibleTagsClistWidget( GtkWidget** ppWidgetScrolled,
                                GtkWidget** ppWidgetClist,
                                int         columnsLayout,
                                PFUNC       RowSelectCallback,
                                PFUNC       RowUnselectCallback );

void
CreateModulesClistWidget( void );

void
PopulateTagsClistWidget( int sort );

void
PopulateModulesClistWidget( void );

void
TagsClistWidgetRowSelectCallback( GtkWidget*      pWidget,
                                  gint            row,
                                  gint            col,
                                  GdkEventButton* pEvent,
                                  gpointer	      pData );

void
ModulesClistWidgetRowSelectCallback( GtkWidget*      pWidget,
                                     gint            row,
                                     gint            col,
                                     GdkEventButton* pEvent,
                                     gpointer        pData );

void
TagsClistWidgetRowUnselectCallback( GtkWidget*      pWidget,
                                    gint            row,
                                    gint            col,
                                    GdkEventButton* pEvent,
                                    gpointer	    pData );

void
ModulesClistWidgetRowUnselectCallback( GtkWidget*      pWidget,
                                       gint            row,
                                       gint            col,
                                       GdkEventButton* pEvent,
                                       gpointer	       pData );

void
SelectClistRow( GtkWidget* pWidgetClist,
                gint       row );

void
SelectClistRowAsThoughUserDid( GtkWidget* pWidgetClist,
                               gint       row );

void
UnselectClistRow( GtkWidget* pWidgetClist,
                  gint*      pSelectedRow );

void
AddSortedModuleGlist( gpointer pModuleName,
                      gpointer pUnused,
                      gpointer ppGlist );

void
AddRowToAnyTagsClistWidget( GtkWidget* pWidgetClist,
                            gpointer   pData,
                            gpointer   pUnused,
                            gboolean   prependOrAppend );

void
AddRowToTagsClistWidget( gpointer pData,
                         gpointer pUnused );

void
AddRowToModulesClistWidget( gpointer pModuleName,
                            gpointer pUnused );

gint
SearchClistWidget( gchar*     pSought,
                   gboolean   seekingFuncLikeTag,
                   gchar*     pModuleName,
                   GtkWidget* pWidgetClist,
                   int        selectedRow,
                   int        exact,
                   int        caseSens,
                   int        quiet,
                   gboolean   selectNotebookPage,
                   gboolean   doSelectRow );

int
ClistColumnWidth( GtkWidget* pWidgetClist,
                  int        col );

#endif /* LIST_H */
