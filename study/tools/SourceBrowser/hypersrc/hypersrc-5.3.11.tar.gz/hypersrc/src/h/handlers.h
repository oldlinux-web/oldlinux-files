/******************************************************************************
 * $Id: handlers.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef HANDLERS_H
#define HANDLERS_H

gboolean
HandlerKeyPressMain( GtkWidget*   pWidget,
                     GdkEventKey* pEvent,
                     gpointer     unused );

gboolean
HandlerKeyPressText( GtkWidget*   pWidget,
                     GdkEventKey* pEvent,
                     gpointer     unused );

gboolean
ComplainAboutEditing( GdkEventKey* pEvent );

void
RecordAuxTextKeyEvent( GdkEventKey* pEvent );

void
RecordTreeKeyEvent( GdkEventKey* pEvent );

gboolean
HandlerKeyPressClist( GtkWidget*   pWidget,
                      GdkEventKey* pEvent,
                      gpointer     unused );

gboolean
HandlerKeyRelease( GtkWidget*   pWidget,
                   GdkEventKey* pEvent,
                   gpointer     unused );

gboolean
HandlerKeyPressDialogFind( GtkWidget*   pWidget,
                           GdkEventKey* pEvent,
                           gpointer     unused );

gboolean
HandlerKeyPressDialogLine( GtkWidget*   pWidget,
                           GdkEventKey* pEvent,
                           gpointer     unused );

gboolean
HandlerActivateComboLine( GtkWidget*   pWidget,
                          GdkEventKey* pEvent,
                          gpointer     unused );

gboolean
HandlerLineNum( GtkWidget*      pWidget,
                GdkEventButton* pEvent,
                gpointer        ununsed );

void
HandlerToolbarButtonEarlierTag( GtkWidget* pWidgetUnused,
                                gpointer   unused );

void
HandlerToolbarButtonLaterTag( GtkWidget* pWidgetUnused,
                              gpointer   unused );

void
HandlerToolbarButtonGotoTag( GtkWidget* pWidgetUnused,
                             gpointer   unused );

void
HandlerToolbarButtonFindMatches( GtkWidget* pWidgetUnused,
                                 gpointer   unused );

void
HandlerToolbarButtonRecordCursor( GtkWidget* pWidgetUnused,
                                  gpointer   unused );

void
HandlerSwitchPageNotebook( GtkNotebook*     pNotebook,
                           GtkNotebookPage* pNotebookPage,
                           gint             page_num,
                           gpointer         unused );

void
HandlerDrawClistKludge( GtkWidget*    pWidget,
                        GdkRectangle* pRect,
                        gpointer      unused );

void
InstallFocusHandlers( GtkWidget* pWidget );

gboolean
HandlerFocusIn( GtkWidget*     pWidget,
                GdkEventFocus* pEvent,
                gpointer       unused );

gboolean
HandlerFocusOut( GtkWidget*     pWidget,
                 GdkEventFocus* pEvent,
                 gpointer       unused );

gboolean
HandlerFocusbarButtonEvent( GtkWidget*      pWidget,
                            GdkEventButton* pEvent,
                            gpointer        pFocusbar );

void
HandlerButtons( GtkWidget* pWidget,
                gpointer   pUnused );

gint
HandlerDeleteEvent( GtkWidget* pWidget,
                    GdkEvent*  pEvent,
                    gpointer   pUnused );

void
WordAtCursorClicked( void );

void
RestoreCursorClicked( void );

#endif /* HANDLERS_H */
