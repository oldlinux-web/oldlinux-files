/******************************************************************************
 * $Id: misc.h,v 1.3 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef MISC_H
#define MISC_H

gboolean
Lock( lock_t* pLock ); /* ### MUST BE A STATIC VAR ### */

void
Unlock( lock_t* pLock ); /* ### MUST BE A STATIC VAR ### */

void
ScheduleIdleCallback( guint*      pCbId,
                      GtkFunction func,
                      gpointer    pData );

void
UnscheduleIdleCallback( guint* pCbId );

#endif /* MISC_H */
