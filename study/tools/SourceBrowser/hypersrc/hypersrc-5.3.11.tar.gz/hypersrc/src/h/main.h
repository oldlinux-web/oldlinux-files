/******************************************************************************
 * $Id: main.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef MAIN_H
#define MAIN_H

int
MatchArg( const char* pArg,
          const char* pStr1Dash );

void
InitGlobals( void );

void
InitFontNames( void );

void
RestoreVars( void );

void
SaveVars( void );

void
ParseCommandLine( int argc, char* argv[] );

#endif /* MAIN_H */
