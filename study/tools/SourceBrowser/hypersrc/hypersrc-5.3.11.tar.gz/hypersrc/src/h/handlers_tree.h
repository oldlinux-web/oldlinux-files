/******************************************************************************
 * $Id: handlers_tree.h,v 1.3 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef HANDLERS_TREE_H
#define HANDLERS_TREE_H

typedef struct
{
   tag_t*     pTag;
   funcDef_t* pFuncDef;
} pTag_pFuncDef_t;

void
ResetTrees( void );

gboolean
LockTreeFunc( gboolean* pBusyFlag );/* ### MUST BE A STATIC VAR ### */

void
UnlockTreeFunc( gboolean* pBusyFlag );/* ### MUST BE A STATIC VAR ### */

void
HandlerTreeItemSelected( GtkTree*   pWidgetTree,
                         GtkWidget* pWidgetItem,
                         gpointer   unused );

void
HandlerSubtreeSelected( GtkTree*   pWidgetItem,	/* refers to a subtree (node), not a leaf (tree item) */
                        gpointer   unused );

gint
HyperjumpViaTreeNodeOrItem_cb( gpointer pTag_pFuncDef /* g_malloc-ed */ );

gint
HyperjumpToModuleViaModuleTree_cb( gpointer pModuleName_ );

void
HandlerFuncDefTreeExpand( GtkTreeItem* pWidgetTreeItem,
                          tag_t*       pTagFuncCall );

gint
HandlerFuncDefTreeExpand_cb( gpointer unused );

void
HandlerModuleTreeExpand( GtkTreeItem* pWidgetTreeItem,
                         module_t*    pModule );

gint
HandlerModuleTreeExpand_cb( gpointer unused );


#endif /* HANDLERS_TREE_H */
