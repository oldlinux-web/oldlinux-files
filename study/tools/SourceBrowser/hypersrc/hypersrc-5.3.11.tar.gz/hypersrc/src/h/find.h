/******************************************************************************
 * $Id: find.h,v 1.3 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef FIND_H
#define FIND_H

void
FindMatchesUnderCursor( void );

gchar*
FindStringInSegment( gint*  pMatchLen,
                     gchar* pSought,
                     gchar* pSegment,
                     int    segmentLen );

gboolean
FindNextStringInTextWidget( void );

int
FindTagCheckMultipleMatches( char*    pTagName,
                             gboolean seekingFuncLikeTag,
                             char*    pModuleName,
                             int      rowStarting,
                             gboolean exact,
                             gboolean caseSens,
                             gboolean selectNotebookPage,
                             char*    pMsgMultipleMatches );

void
FindNextTextOrTag( void );

gint
FindNextTag( void );

gboolean
FindStringInTextWidget( gchar*   pSought,
                        gboolean tryWrap,
                        gboolean quiet,
                        gboolean scroll,
                        gint*    pReturnLineNumFound );

gboolean
FindStringInTextWidget_( gchar*   pSought,
                         gboolean tryWrap,
                         gboolean quiet,
                         gboolean scroll,
                         gint*    pReturnLineNumFound,
                         gchar*   pText,
                         gint     textLen );

gboolean
FindStringGlobal( gchar*   pSought,
                  gboolean quiet,
                  gboolean stopIfFindDialogClosed );

gboolean
BuildListOfFoundStrings( gchar*   pSought,
                         gboolean quiet,
                         gboolean stopIfFindDialogClosed );

FUNC_X
AppendFoundTagsList( gchar* pTagName,
                     gchar* pModuleName,
                     gint   lineNum );

void
BuildNotebookPageWithFindResults( void );

void
AddRowToFoundClistWidget( gpointer pData,
                          gpointer pUnused );

void
FoundClistWidgetRowSelectCallback( GtkWidget*      pWidget,
                                   gint            row,
                                   gint            col,
                                   GdkEventButton* pEvent,
                                   gpointer	       pData );

void
FoundClistWidgetRowUnselectCallback( GtkWidget*      pWidget,
                                     gint            row,
                                     gint            col,
                                     GdkEventButton* pEvent,
                                     gpointer	     pData );

#endif /* FIND_H */
