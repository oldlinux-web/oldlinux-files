/******************************************************************************
 * $Id: notebook.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef NOTEBOOK_H
#define NOTEBOOK_H

void
CreateNotebook( void );

int
NotebookPageTags( void );

int
NotebookPageModules( void );

int
NotebookPageHistory( void );

int
NotebookPageFunctions( void );

int
NotebookPageFound( void );

#endif /* NOTEBOOK_H */
