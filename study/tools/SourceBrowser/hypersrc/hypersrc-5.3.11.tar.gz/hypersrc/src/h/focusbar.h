/******************************************************************************
 * $Id: focusbar.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef FOCUSBAR_H
#define FOCUSBAR_H

focusbar_t*
FocusbarCreate( char* pFontName );

void
FocusbarDestroy( focusbar_t* pFocusbar );

void
FocusbarLabelSet( focusbar_t* pFocusbar,
                  char*       pStr );

void
FocusbarFocusGain( focusbar_t* pFocusbar );

void
FocusbarFocusLose( focusbar_t* pFocusbar );

void
FocusbarPaint( focusbar_t* pFocusbar );

gboolean
HandlerFocusbarExpose( GtkWidget*      pWidget,
                       GdkEventExpose* pEvent,
                       gpointer        pFocusbar );

#endif /* FOCUSBAR_H */
