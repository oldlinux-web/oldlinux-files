/******************************************************************************
 * $Id: funcgraph.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	:
 ******************************************************************************/

void
BuildFuncGraph( void );

void
AddFuncCallToGraph( char* pFuncCallId,
                    int   lenFuncCallId,
                    int   line );

void
AddFuncDefToGraph( char* pFuncDefId,
                   int   lineLeftBrace,
                   int   lineRightBrace );

int
ShouldFuncIdBeGraphed( char* pFuncId );

int
IgnoreFuncName( char* pFuncName );

char*
PreprocessCPlusPlusJava( const char* pBufIn,
                         int         sizeIn );

#if defined(HYPERSRC_DEBUG)  &&  !defined(PARSER_L)  &&  !defined(PARSER_Y)
void
DumpFuncGraph( void );

void
CallbackDumpFuncGraph( gpointer key,
                       gpointer val,
                       gpointer unused );
#endif /* HYPERSRC_DEBUG */
