/******************************************************************************
 * $Id: font.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef FONT_H
#define FONT_H

gboolean
FindFontBold( char*       pFontNameBold, /*OUT*/
              const char* pFontNameBase );

gboolean
FindFontItalic( char*       pFontNameItalic, /*OUT*/
                const char* pFontNameBase );

gboolean
FindFontVariation( char*       pFontNameVar, /*OUT*/
                   const char* pFontNameBase,
                   const char* pPartVar,
                   const char* pPartBase );

#endif /* FONT_H */
