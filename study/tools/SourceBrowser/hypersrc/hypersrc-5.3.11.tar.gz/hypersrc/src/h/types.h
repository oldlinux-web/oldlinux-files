/******************************************************************************
 * $Id: types.h,v 1.3 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: structs and typedefs
 ******************************************************************************/

#ifndef TYPES_H
#define TYPES_H

/******************************************************************************
 * structs/typedefs
 ******************************************************************************/

/*-----------------------------------------------------------------------------
 * Function call graph (used to construct a tree view):
 *
 * module hash table --+
 *                     |
 *                     +--> GSList of funcDef_t --+
 *                                                |
 *                                                +--> GSList of funcCall_t
 *
 *-----------------------------------------------------------------------------*/

/*
 * ############################################################
 * #   Some members point to dynamically allocated strings.   #
 * #   Some members point to static strings.                  #
 * #   Deallocating a tag_t struct will be quite complicated. #
 * ############################################################
 */
typedef struct
{
   char*	pName;			/* name of the tag */
   char*	pType;			/* type of tag, eg "func", "define", etc */
   int		lineInt;		/* which line (in integer form) */
   char*	pModuleName;	/* name of module the tag is in */
} tag_t;

/*
 * Defines a module (src file).
 * This is stored in the module hash table.
 */
typedef struct
{
   gchar*		pModuleName;
   gchar*		pModuleBuffer;
   guint		moduleSize;
 /*gboolean		modified;*/				/* for later when/if editing is supported */
   GSList*		pGslistFuncDef;
   GHashTable*	pHashFuncTags;			/* hashed tag_t structs of funcs/macros/methods */
} module_t;

/*
 * Defines a function call that was parsed (within a function definition).
 * A Gslist of these structs is pointed to by funcDef_t.pGslistFuncCall.
 *
 * Notes: If a func def/call wasn't tagged by ctags (tag lookup fails),
 *        then pTag* will point to an _unlinked_ fabricated tag_t struct.
 */
typedef struct
{
   tag_t*		pTagFuncCall;		/* (see above note) points to tag of called function */
} funcCall_t;

/*
 * Defines a function definition that was parsed.
 * A Gslist of these structs is pointed to by module_t.pGslistFuncDef.
 */
typedef struct
{
   tag_t*		pTagFuncDef;		/* (see above note) points to function definition's tag */
   GSList*		pGslistFuncCall;
   int			lineStart;			/* line which func def begins */
   int			lineLast;			/* line which func def ends */
} funcDef_t;

typedef struct
{
   GtkWidget* pWidget;
   char       str[256];
   gboolean   focus;
   guint      fontHeight;
} focusbar_t;

typedef struct
{
   gboolean		valid;						/* true if members hold valid values */
   GtkWidget*	pWidgetText;				/* which text widget */
   gfloat		adjustmentValue;			/* value from text widget's GtkAdjustment widget */
   guint		idxCursor;					/* index of the cursor within the text */
   char			module[MAX_FILENAME_LEN];
} cursor_t;

/*
 * Type for locking arbitrary resources.
 */
typedef gboolean lock_t;

/******************************************************************************
 * typedefs
 ******************************************************************************/

/*
 * For ptrs to strcmp() or strcase().
 */
typedef int FUNC_STRCMPX( const char* s1, const char *s2, size_t n);
typedef FUNC_STRCMPX* P_FUNC_STRCMPX;

/*
 * Misc. typedefs.
 */
typedef void FUNC(void);
typedef FUNC* PFUNC;

#endif /* TYPES_H */
