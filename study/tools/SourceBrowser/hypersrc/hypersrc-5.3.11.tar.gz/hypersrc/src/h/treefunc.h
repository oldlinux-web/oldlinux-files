/******************************************************************************
 * $Id: treefunc.h,v 1.3 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef TREEFUNC_H
#define TREEFUNC_H


/*==============================================================================
 *==============================================================================
 *
 * Types/enums.
 *
 *==============================================================================
 *==============================================================================*/


enum { DONT_ANNOTATE_MODULE, DO_ANNOTATE_MODULE };


/*==============================================================================
 *==============================================================================
 *
 * Macros/inlines.
 *
 *==============================================================================
 *==============================================================================*/


/*****************************************************************************
 * Obtain the GtkTreeItem that owns a GtkTree (though it sounds reverse).
 *****************************************************************************/
static inline GtkTreeItem*
TreeOwnerItem( GtkTree* pTree )
{
   if ( !pTree ) WarningMalfunction();

   return GTK_TREE_ITEM(pTree->tree_owner);
}

/*****************************************************************************
 * Expand a GtkTree.
 *****************************************************************************/
static inline void
ExpandTree( GtkTree* pTree )
{
   if ( pTree) gtk_tree_item_expand( TreeOwnerItem(pTree) );
}

/*****************************************************************************
 * Return amount of children (leafs) a tree has.
 *****************************************************************************/
static inline guint
TreeChildrenCount( GtkTree* pTree )
{
   if ( pTree )
      return g_list_length( pTree->children );
   else
      return 0;
}


/*==============================================================================
 *==============================================================================
 *
 * Prototypes.
 *
 *==============================================================================
 *==============================================================================*/


void
RefreshFuncTree( void );

void
UpdateFuncTree( int      line,
                gboolean force );

void
ScheduleUpdateFuncTree( void );

void
UpdateFuncTreeWidget( funcDef_t* pFuncDef );

void
FillTreeWithFuncCalls( GtkTree*   pTree,
                       funcDef_t* pFuncDef );

void
FillTreeWithFuncCallers( GtkTree*   pTree,
                         funcDef_t* pFuncDef );

void
CreateFuncTreeAncillaryWidgets( void );

void
RefreshModuleTree( void );

void
CreateNotebookPageWithModuleTree( gboolean decorate );

void
ModuleTreeForEachModule( char*     pModulePathname,
                         module_t* pModule );

void
ModuleTreeDecorateSubtree( GtkTree*  pSubtree,
                           module_t* pModule );

void
FreeHashSubtreeItem( gpointer key,
                     gpointer value,
                     gpointer unused );

GtkTree*
DescendTreeNodesOnModulePath( char* pModulePathname );

GtkTree*
CreateTreeForFunc( GtkTree* pTreeParent,
                   char*    pTreeName,
                   guint    signalMask,
                   tag_t*   pTag );


void
CreateTreeNodeForFunc( GtkTree*   pTree,
                       tag_t*     pTag,
                       funcDef_t* pFuncDef,
                       int        annotateModule,
                       char*      pFontName );

GtkTreeItem*
CreateTreeItemForFunc( GtkTree*   pTree,
                       tag_t*     pTag,
                       funcDef_t* pFuncDef,
                       int        annotateModule,
                       char*      pFontName );

GtkTreeItem*
CreateTreeItem( GtkTree* pTree,
                char*    pItemName,
                char*    pFontName );

GtkTree*
CreateSubtree( GtkTreeItem* pTreeItem,
               guint        signalMask,
               char*        pKey,
               void*        pData );

void
ChangeStyleTree( GtkTree* pTree );

void
ChangeStyleTreeItem( GtkTreeItem* pTreeItem,
                     char*        pFontName );

gboolean
SelectDifferentFontsForFuncTrees( const char* pFontNameBase );

void
SelectSameFontForFuncTrees( const char* pFontNameBase );

void
SetSensitivityModuleFuncTrees( gboolean sensitive,
                               gboolean hideIfInsensitive );

#endif /* TREEFUNC_H */
