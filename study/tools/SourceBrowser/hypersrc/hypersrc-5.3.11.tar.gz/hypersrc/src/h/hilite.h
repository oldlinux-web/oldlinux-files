/******************************************************************************
 * $Id: hilite.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Hilite global vars.
 ******************************************************************************/

#ifndef HILITE_H
#define HILITE_H

/*
 * Define or declare globals.
 */
#ifdef DEFINE_HILITE_GLOBALS

GdkColor colorComment  = { 0, 0x0800, 0x7000, 0x0800 };
GdkColor colorKeyword  = { 0, 0x1000, 0x1000, 0xb000 };
GdkColor colorType     = { 0, 0xb000, 0x1000, 0xc000 };
GdkColor colorSymbol   = { 0, 0xb000, 0x1000, 0x1000 };
GdkColor colorLabel    = { 0, 0x3000, 0x8000, 0x8000 };
GdkColor colorGoto     = { 0, 0xf000, 0xf000, 0x5000 };
GdkColor colorString   = { 0, 0x8000, 0x8000, 0x8000 };

GdkFont* pFontComment	= NULL;
GdkFont* pFontKeyword	= NULL;
GdkFont* pFontType		= NULL;
GdkFont* pFontSymbol	= NULL;

#else /* !DEFINE_HILITE_GLOBALS */

extern GdkColor colorComment;
extern GdkColor colorKeyword;
extern GdkColor colorType;
extern GdkColor colorSymbol;
extern GdkColor colorLabel;
extern GdkColor colorGoto;
extern GdkColor colorString;

extern GdkFont*	pFontComment;
extern GdkFont*	pFontKeyword;
extern GdkFont*	pFontType;
extern GdkFont*	pFontSymbol;

#endif /* DEFINE_HILITE_GLOBALS */

void
HiliteLoadCode( GtkWidget* pWidget,
                char*      pBuffer,
                int        bufferSize,
                int        srcFileKind );

const char*
HiliteComment( GtkWidget*  pWidget,
               const char* pCommentStartApprox,
               const char* pCommentEndDef,
               int         bufferSize );

FUNC_X
HiliteQuotedString( GtkWidget*   pWidget,
                    GdkColor*    pColor,
                    GdkFont*     pFont,
                    const char*  pStart,
                    const char*  pDquote1,
                    const char*  pBufEnd,
                    const char** ppAfter /*OUT*/ );

int
FindWord( const char* pWords,
          char*       pSought,
          int         soughtLen );

#endif /* HILITE_H */
