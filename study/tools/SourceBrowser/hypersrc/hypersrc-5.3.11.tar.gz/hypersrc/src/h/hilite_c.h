/******************************************************************************
 * $Id: hilite_c.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef HILITE_C_H
#define HILITE_C_H

gboolean
HiliteC( GtkWidget* pWidget,
         char*      pBuffer,
         int        bufferSize,
         int        srcFileKind );

gboolean
HiliteCString( GtkWidget*  pWidget,
               const char* pStr,
               int         strSize,
               char        precedingChar,
               char*       pScratch,
               int         srcFileKind );

gboolean
ResemblesCUserType( const char* pWord,
                    int         wordLen );

#endif /* HILITE_C_H */
