/******************************************************************************
 * $Id: common.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Common header.
 ******************************************************************************/

#ifndef COMMON_H
#define COMMON_H

#if 0
#define G_DISABLE_ASSERT
#endif

#define malloc malloc_USE_GLIB_INSTEAD_DUMMY
#define free   free_USE_GLIB_INSTEAD_DUMMY

#include <stdlib.h>
#include <stdio.h>
#include <gtk/gtk.h>
#include <gnome.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>

#ifdef HYPERSRC_THREADS
#include <pthread.h>
#ifndef G_THREADS_IMPL_POSIX
#error "HYPERSRC_THREADS is defined, but this host appears to lack POSIX threads."
#endif
#endif

#include "defines.h"
#include "types.h"
#include "globals.h"
#include "utils.h"

#endif /* COMMON_H */
