/******************************************************************************
 * $Id: statusbar.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef STATUSBAR_H
#define STATUSBAR_H

void
RecordStatusbarMsg( gchar* pMsg );

gchar*
GetStatusbarMsg( void );

void
PrintStatusbarNoTimeout( gchar* pMsg );

void
PrintStatusbar( gchar* pMsg );

void
PrintStatusbarThirdsNoTimeout( gchar* pMsg1,
                               gchar* pMsg2,
                               gchar* pMsg3 );
void
PrintStatusbarThirds( gchar* pMsg1,
                      gchar* pMsg2,
                      gchar* pMsg3 );

void
StartupStatusMsg( gchar* pMsg1,
                  gchar* pMsg2,
                  gchar* pMsg3 );

void
PrintStatusbarForRow( gchar* pMsg,
                      gint   row );

gint
RowAssociatedWithStatusbar( void );

void
SetStatusbarInitialMsg( gchar* pMsg );

void
DiscardStatusbarMsg( void );

void
ClearStatusbar( void );

void
ClearStatusbar_( int limit );

void
MostlyClearStatusbar( void );

void
EnableStatusbarTimeout( void );

gint
StatusbarTimedOut( gpointer unused );

void
StatusbarShowPercentage( char* pMsg,
                         int   percent );

void
StatusbarBusy( void );

#endif /* STATUSBAR_H */
