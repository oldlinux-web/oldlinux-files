/******************************************************************************
 * $Id: str_heap.h,v 1.3 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: String heap.
 ******************************************************************************/

#ifndef STR_HEAP_H
#define STR_HEAP_H

typedef struct
{
   char* 	pBase;
   int		size;
   char*	pFree;
} STR_HEAP;

inline void
StrHeapCreate( STR_HEAP* pStrHeap, int size );

inline void
StrHeapDelete( STR_HEAP* pStrHeap );

inline char*
StrHeapAppendFast( STR_HEAP* pStrHeap, char* str, int strLen );

inline char*
StrHeapAppend( STR_HEAP* pStrHeap, char* str, int strLen );

#endif /* STR_HEAP_H */
