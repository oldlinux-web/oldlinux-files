/******************************************************************************
 * $Id: hilite_forth.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef HILITE_FORTH_H
#define HILITE_FORTH_H

gboolean
HiliteForth( GtkWidget* pWidget,
             char*      pBuffer,
             int        bufferSize,
             int        srcFileKind );

#endif /* HILITE_FORTH_H */
