/******************************************************************************
 * $Id: history.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef HISTORY_H
#define HISTORY_H

void
CreateHistoryClistWidget( void );

void
HistoryClistWidgetRowSelectCallback( GtkWidget*      pWidget,
                                     gint            row,
                                     gint            col,
                                     GdkEventButton* pEvent,
                                     gpointer	     pData );

void
HistoryClistWidgetRowUnselectCallback( GtkWidget*      pWidget,
                                       gint            row,
                                       gint            col,
                                       GdkEventButton* pEvent,
                                       gpointer        pData );

void
PrependTagHistory( tag_t* pTag );

void
UndoPrependTagHistory( void );

void
StepHistoryList( gboolean stepDown );

void
RecordCursorInTagHistory( char* pTagName );

void
UndoRecordCursorInTagHistory( void );

#endif /* HISTORY_H */
