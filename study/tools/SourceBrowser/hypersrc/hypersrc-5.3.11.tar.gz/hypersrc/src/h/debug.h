/******************************************************************************
 * $Id: debug.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef DEBUG_H
#define DEBUG_H

#ifdef HYPERSRC_DEBUG
void
PrintUsecElapsed( GTimeVal* pTimeval1,
                  GTimeVal* pTimeval2 );
#endif

#endif /* DEBUG_H */
