/******************************************************************************
 * $Id: text.h,v 1.3 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef TEXT_H
#define TEXT_H

void
CreateTextWidgetEtAl( GtkWidget**  ppWidgetText,	/*OUT*/
                      GtkWidget**  ppWidgetVbox,	/*OUT*/
                      GtkWidget**  ppWidgetTable,	/*OUT*/
                      GtkWidget**  ppWidgetVscroll,	/*OUT*/
                      GtkWidget**  ppWidgetHscroll,	/*OUT*/
                      focusbar_t** ppFocusbar		/*OUT*/ );

void
ConnectHandlersForTextWidget( GtkWidget* pWidget );

void
ApplyTabWidth( GtkWidget* pWidget,
               int        width );

FUNC_X
LoadTextWidgetWithModule( gchar*   pModuleName,
                          gint	   cursor,
                          gint     row,
                          gboolean reload );

void
LoadTextWidgetWithBuffer( gpointer pBuffer,
                          gint     bufferSize,
                          int      srcFileKind );

void
ClearTextWidget( void );

void
RedrawBothTextWidgets( void );

void
RedrawActiveTextWidget( void );

int
IsTextWidgetEmpty( void );

int
LineAtCursor( void );

void
ScrollTextWidgetToLine( gint   line,
                        gfloat vertFrac );

void
SetAdjustmentValue( GtkAdjustment* pAdj,
                    gfloat         adjust );

void
RecenterTextWidget( void );

void
RecordLocationAsPrevious( void );

void
GotoPrev( void );

void
GotoLine( void );

gboolean
HighlightLine( int line );

void
HighlightWordInCurrentLine( const char* pWord,
                            gboolean    caseSens,
                            int         searchMethod );

void
HighlightTextString( gchar* pText,
                     gint   idx,
                     gint   len );

void
HighlightTag( tag_t* pTag,
              guint  idxCursor );

void
HighlightChar( int line,
               int idxText );

int
PrintLineNum( void );

gint
IdleLineNum( gpointer dontCare );

void
SelectRegion( GtkText* pGtkText,
              int      idxStart,
              int      idxEnd );

gint
IdleSelectRegion( gpointer unused );

guint
TextCursorIdx( void );

gboolean
IsCursorOverWord( void );

GString*
ScoopWordAtCursor( int   maxWordLen,
                   char* pText,
                   int   textLen,
                   int   idxCursor );

void
SaveCursor( cursor_t* pCursor );

void
RestoreCursor( cursor_t* pCursor );

char*
ActiveTextWidgetContents( guint* pSizeOut );

guint
ActiveTextWidgetSize( void );

void
SetActiveTextWidget( GtkWidget* pWidget );

void
GiveFocusToTextWidget( GtkWidget* pWidget );

void
SwitchActiveTextWidget( gboolean whicheverHasFocus );

void
RecordActiveModuleName( char* pModuleName );

char*
ActiveModuleName( void );

void
RecordActiveModule( module_t* pModule );

module_t*
ActiveModule( void );

#endif /* TEXT_H */
