/******************************************************************************
 * $Id: widgets.h,v 1.2 2003/01/14 21:46:28 jimb Exp $
 * Author		: Jim Brooks <hypersrc@jimbrooks.org>
 * Description	: Function prototypes.
 ******************************************************************************/

#ifndef WIDGETS_H
#define WIDGETS_H

void
CreateWidgetsStep1( void );

void
CreateWidgetsStep2( void );

void
CreateMainWindow( void );

void
CreateMenubarToolbar( void );

void
ChangeStyleColorTextSel( GtkWidget* pWidget,
                         GdkColor*  pColorFgText,
                         GdkColor*  pColorBgText,
                         GdkColor*  pColorFgSel,
                         GdkColor*  pColorBgSel );

void
ChangeStyleColorText( GtkWidget* pWidget,
                      GdkColor*  pColorFg,
                      GdkColor*  pColorBg );

void
ChangeStyleColorSel( GtkWidget* pWidget,
                     GdkColor*  pColorFg,
                     GdkColor*  pColorBg );

gboolean
ChangeStyleFont( GtkWidget* pWidget,
                 char*      pFontName );

void
ApplyFontListWidgets( void );

gint
FontHeight( GdkFont* pFont );

void
PositionWidgetAtMiddle( GtkWidget* pWidget );

void
PositionWidgetAtTopMiddle( GtkWidget* pWidget );

void
PositionShowDialogAtMiddle( GtkWidget* pWidgetDialog );

void
PositionShowFindDialog( GtkWidget* pWidgetDialog );

void
WidgetWidthHeight( GtkWidget* pWidget,
                   gint*      pWidth,
                   gint*      pHeight );

void
KludgeForWidgetGeom( GtkWidget* pWidget,
                     int x,
                     int y );

void
WidgetGeom( GtkWidget* pWidget,
            gint*      pX,
            gint*      pY,
            gint*      pW,
            gint*      pH );

void
PrependComboDropDown( char*   pString,
                      GList** ppGList );

GtkWidget*
CreateButtonLabelUnderlined( const gchar* pLabelText,
                             const gchar* pLabelPattern );

void
ResetFunctions( void );

gboolean
IsAnyMajorFunctionBusy( gboolean showMsg );

gboolean
IsAnyTreeFunctionBusy( void );

void
SetSensitivityWhileBusy( gboolean sensitive );

void
SetPanedSlidersInitialPositions( void );

int
PanedSliderPercent( GtkWidget* pWidget );

void
ProcessPendingEvents( void );

void
PeriodicallyProcessPendingEvents( void );

#endif /* WIDGETS_H */
