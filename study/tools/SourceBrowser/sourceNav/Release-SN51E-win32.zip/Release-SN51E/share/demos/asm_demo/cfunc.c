/*
 * cfunc.c
 *
 * Copyright (C) 1998 Cygnus Solutions, Inc.
 *
 * Description:
 * A simple C source file that contains a C function which effectively does
 * nothing more than generate external linkage.
 */

extern int cfunc(int arg)
{
  /* do nothing */
}
