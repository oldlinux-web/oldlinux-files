#define GLISH_VERSION "2.5.0.4"
