// $Header: /cvsroot/sourcenav/src/snavigator/demo/c++_demo/glish/Queue.cc,v 1.1.1.1 2002/04/18 23:35:25 mdejong Exp $

#include "Queue.h"


BaseQueue::BaseQueue()
	{
	head = tail = 0;
	}

void BaseQueue::EnQueue( void* element )
	{
	QueueElement* qe = new QueueElement( element );

	if ( ! head )
		head = tail = qe;

	else
		{
		tail->next = qe;
		tail = qe;
		}
	}

void* BaseQueue::DeQueue()
	{
	if ( ! head )
		return 0;

	QueueElement* qe = head;
	head = head->next;

	if ( qe == tail )
		tail = 0;

	void* result = qe->elem;
	delete qe;

	return result;
	}
