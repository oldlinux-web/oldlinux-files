      COMMON/FLWORK/IWS(MXNAME)
*--- IWS    = working space
