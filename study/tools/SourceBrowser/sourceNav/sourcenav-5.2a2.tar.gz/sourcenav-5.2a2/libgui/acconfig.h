/* Name of package.  */
#undef PACKAGE

/* Version of package.  */
#undef VERSION

/* Set this if Tk's stdlib.h should be used.  */
#undef NO_STDLIB_H

/* Define this if <string.h> declares strncasecmp().  */
#undef HAVE_STRNCASECMP_DECL

/* Define this if the IDE is enabled.  */
#define IDE_ENABLED 0
