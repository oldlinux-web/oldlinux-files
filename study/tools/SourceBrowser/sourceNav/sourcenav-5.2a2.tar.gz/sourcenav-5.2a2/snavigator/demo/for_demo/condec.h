      LOGICAL SPECCH,NUMCH,ALPHCH,ANUMCH,STRGCH
      CHARACTER SBASE*92,SPCHAR*7,SPILL*2,SDUMMY*1
*-----------------------------------------------------------------------
*---  SBASE   = list of all characters recognized by FLOPPY.
*+++ warning +++ : '{', and '}' are forbidden for users.
*---  SPCHAR  = list of string replacement characters in flop.
*-----------------------------------------------------------------------
