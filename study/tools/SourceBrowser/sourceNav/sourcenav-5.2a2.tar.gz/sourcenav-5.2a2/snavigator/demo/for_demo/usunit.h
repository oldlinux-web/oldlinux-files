      PARAMETER (MZUNIT=99,MJUNIT=50,MSUNIT=55)
*-----------------------------------------------------------------------
*   MZUNIT  = logical unit of scratch file
*   MJUNIT  = logical unit for customized TREE output
*   MSUNIT  = logical unit for specification of rules
*-----------------------------------------------------------------------
