/* $Header: /cvsroot/sourcenav/src/snavigator/demo/c++_demo/glish/ports.h,v 1.1.1.1 2002/04/18 23:35:25 mdejong Exp $ */

/* Port numbers used by Glish. */


/* Default port used by Glish interpreter.  If it's in use, the interpreter
 * may switch to another port.*/

#define INTERPRETER_DEFAULT_PORT 2000

/* Port always used by Glish daemon; there's only ever one daemon
 * per host.
 */
#define DAEMON_PORT 9991
