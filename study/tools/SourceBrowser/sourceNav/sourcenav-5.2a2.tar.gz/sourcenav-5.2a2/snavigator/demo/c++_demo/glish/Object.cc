// $Header: /cvsroot/sourcenav/src/snavigator/demo/c++_demo/glish/Object.cc,v 1.1.1.1 2002/04/18 23:35:24 mdejong Exp $

#include <stream.h>
#include "Glish/Object.h"


int line_num;

void GlishObject::Describe( ostream& s ) const
	{
	DescribeSelf( s );
	}

void GlishObject::DescribeSelf( ostream& s ) const
	{
	s << description;
	}
