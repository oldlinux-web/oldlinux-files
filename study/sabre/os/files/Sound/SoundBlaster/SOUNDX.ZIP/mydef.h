#ifndef __MYDEF__

#define __MYDEF__

typedef unsigned char BYTE;
typedef unsigned int  WORD;
typedef unsigned long DWORD;

static const TRUE= -1,FALSE=0;

#endif
