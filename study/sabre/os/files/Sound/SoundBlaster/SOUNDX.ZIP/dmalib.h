
/* Copyright 1993 by Peter Sprenger   Pete@amber.dinoco.de
 *                   5014 Kerpen 3
 *                   Germany
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that the above copyright
 * notice appear in all copies.  The author Peter Sprenger
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */

#ifndef __DMA__

#define __DMA__

#define DMA_IN 4
#define DMA_OUT 8
#define DMA_SINGLE 0x40
#define DMA_AUTO 0x10
#define DMA_BLOCK 0x80
#define DMA_DEMAND 0
#define DMA_DECREMENT 0x20

WORD dma_set(DWORD adr,DWORD len,int channel,BYTE mode);
WORD dma_next(int channel);
DWORD far2long(char far *adr);
long dma_len(int channel);

#endif
