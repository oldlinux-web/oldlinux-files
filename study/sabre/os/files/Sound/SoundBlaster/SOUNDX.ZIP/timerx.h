
/* Copyright 1993 by Peter Sprenger   Pete@amber.dinoco.de
 *                   5014 Kerpen 3
 *                   Germany
 *
 * Permission to use, copy, modify, and distribute this
 * software and its documentation for any purpose and without
 * fee is hereby granted, provided that the above copyright
 * notice appear in all copies.  The author Peter Sprenger
 * makes no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without
 * express or implied warranty.
 */


/* timerx prototypes */

typedef unsigned int WORD;
typedef unsigned char BYTE;

extern WORD tax,tay,tbx,tby; /* values of potentiometer */
extern WORD ba1,ba2,bb1,bb2; /* button values; bit set = pressed */

void ReadTJoy(BYTE which);
void ReadTJoy2(BYTE which);
void ReadBJoy();

void InitT2();
void timer_on();
WORD timer_off();
WORD to_micro(WORD clk);
void clkdelay(WORD clicks);
void measure();
void mdelay(WORD delay);
WORD mcalc(WORD micro);
WORD vbl_measure();
void Install_Timer0(WORD period,void far (*func)());
void Remove_Timer0();

void Install_RTC(WORD hertz,void far (*func)());
void Remove_RTC();

BYTE int2vect(BYTE intnr);
void enable_int(BYTE nr);
void disable_int(BYTE nr);


