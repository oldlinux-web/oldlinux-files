main(int argc, char **argv)
{
  printf("%d", (argv[1][0] - 'a') * 6);
  return 0;
}
