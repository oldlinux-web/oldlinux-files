/****************************************************************************/
/* Test                                                                     */
/* Functions under DOS4Gw and PmodeW                                        */
/*--------------------------------------------------------------------------*/
/* Coded by Kodiak of The Apollo Project                                    */
/* AKA Charles Jones                                                        */
/*     1122 s 32nd St #2                                                    */
/*     Omaha, NE 68105                                                      */
/*     (402)-346-8974                                                       */
/*                                                                          */
/* Email: CAD@UnOmaha.edu                                                   */
/* IRC  : #Coders                                                           */
/*                                                                          */
/* Copyright 1995 All Rights Reservered                                     */
/* Released to public domain, but hey if you use it greet me.               */
/****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "kad.h"

char sentence[100];

char errors[8][35] = {
    "File not found",
    "Unable to open KAD file",
    "Internal directory to small",
    "Standard File not found",
    "Read error on file",
    "Unknown file type",
    "Compressed file = 0",
    "Read Error on Compressed File"
};


/****************************************************************************/
/* Function : error_handler                                                 */
/* IN : error number                                                        */
/* RETURNS:                                                                 */
/*          nothing                                                         */
/****************************************************************************/
/* Note :                                                                   */
/*      This routine will display an error if one occurred!                 */
/****************************************************************************/
void error_handler(int error_num)
{
    if (error_num != 0) {
        if (strcmp(altstr,"") == 0)
            printf("%s\n",errors[error_num-1]);
        else
            printf("%s : %s\n",errors[error_num-1],altstr);
        exit( EXIT_SUCCESS );
    }
}

void main()
{
    error_handler(openkadfile("dummy.kad","Kodiak"));

    error_handler(getfile("","dummy.ari",&sentence));
    printf("%s\n",sentence);

    closekadfile();
}

