#ifndef _LINUX_CONFIG_SITE_H
#define _LINUX_CONFIG_SITE_H

/*
	This configuration file contains site specific things, things 
	that you have added and config.dist will not know about.
*/

#endif
