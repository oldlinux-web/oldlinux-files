/* Updated automatically --- do not modify */
char version[] = "1.0";
