/* 
 * config.h for HP-UX 8.0
 */


/* 
 * Define this if your system has the tmpfile(3) function.
 */
#define HAVE_TMPFILE

/* 
 * Define this if your system has the mkstemp(3) function.  This is only
 * used if HAVE_TMPFILE is NOT defined.
 */
#undef HAVE_MKSTEMP

/* 
 * Define this is your system supports the [efg]cvt(3) functions.  This
 * is used in format.c.  Use a value above 1 iff they are defined in
 * stdlib.h.
 */
#define HAVE_EFGCVT	(2)

/* 
 * Define this if you have <stdlib.h>.
 */
#define STDC_HEADERS

/* 
 * Define this if <string.h> and <memory.h> conflicts.  This has been
 * observed on some systems.
 */
#undef NO_MEMORY_H
