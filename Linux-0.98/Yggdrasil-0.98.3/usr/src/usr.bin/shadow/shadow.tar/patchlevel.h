/*
 * Copyright 1991, John F. Haugh II
 * All rights reserved.
 *
 * Permission is granted to copy and create derivative works for any
 * non-commercial purpose, provided this copyright notice is preserved
 * in all copies of source code, or included in human readable form
 * and conspicuously displayed on all copies of object code or
 * distribution media.
 *
 * Revision History
 *	11/25/91	3.1.1	patchlevel 14
 *		Added "login.defs" to Makefile
 *	12/02/91	3.1.2	patchlevel 15
 *		Bugs found by users
 *	12/28/91	3.1.3	patchlevel 16
 *		Changes for SunOS 4.1.1
 */

#define	RELEASE		3
#define	PATCHLEVEL	16
#define	VERSION		"3.1.3"
