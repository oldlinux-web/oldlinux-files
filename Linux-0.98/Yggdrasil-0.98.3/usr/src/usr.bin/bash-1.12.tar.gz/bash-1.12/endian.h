/* endian.h - Define BIG or LITTLE endian. */

/* This file was automatically created by `endian.aux'.  You shouldn't
   edit this file, because your changes will be overwritten.  Instead,
   edit the source code file `endian.c'. */

#if !defined (LITTLE_ENDIAN)
#  define LITTLE_ENDIAN
#endif /* LITTLE_ENDIAN */
