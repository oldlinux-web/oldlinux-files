/* Version control for the shell.  This file gets changed when you say
   `make newversion' to the Makefile.  It is created by newversion.aux. */

/* The distribution version number of this shell. */
#define DISTVERSION "1.12"

/* The last built version of this shell. */
#define BUILDVERSION 1
