#include <stdio.h>

float a;

main()
{
   a=2.1;
   printf("Hello world %f\n",a*a);
}
