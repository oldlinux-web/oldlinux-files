#include <stdio.h>

main()
{
  long long long a=1;
  float a=2.3;
  float b=2.7;

  printf("%f\n",a+b);
  exit(0);
}
