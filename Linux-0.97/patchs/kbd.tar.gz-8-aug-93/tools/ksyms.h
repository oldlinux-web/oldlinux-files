typedef struct {
	char **table;
	int size;
} syms_entry;

extern syms_entry syms[];

extern const int syms_size;

