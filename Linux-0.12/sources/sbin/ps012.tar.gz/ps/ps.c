/*
 * ps.c		- show process status
 *
 * Copyright (c) 1992 Branko Lankester
 *
 */

#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <pwd.h>
#include <ctype.h>
#include <linux/sched.h>
#include <linux/tty.h>
#include "ps.h"

unsigned long main_mem;
unsigned long startup_time;

union task_union {
    struct task_struct task;
    reg_t stack[PAGE_SIZE/4];
};

/*#define	_SSIZE(task)	(LIBRARY_OFFSET - (task)->start_stack)*/
#define	_SSIZE(task)	(LIBRARY_OFFSET - KSTK_ESP(task))
#define	SSIZE(task)	((task)->pid == 0 ? 0 : _SSIZE(task))
#define	VSIZE(task)	(((task)->brk + 1023 + SSIZE(task)) / 1024)
#define	SIZE(task)	(((task)->brk - (task)->end_code + 1023 + \
			  SSIZE(task)) / 1024)

char *hdrs[] = {
"  PID TT STAT  TIME COMMAND",
" F   UID   PID  PPID PRI NI SIZE  RSS WCHAN      STAT TT   TIME COMMAND",
"USER       PID %CPU %MEM SIZE  RSS TT STAT START   TIME COMMAND",
" PPID   PID  PGID   SID TT TPGID  STAT   UID   TIME COMMAND",
"  UID   PID SIGNAL   BLOCKED  IGNORED  CATCHED  STAT TT   TIME COMMAND",
"  PID TT STAT  TIME  PAGEIN TSIZ DSIZ  RSS   LIM %MEM COMMAND",
"  PID TT MAJFLT MINFLT TSIZ  TRS SIZE SWAP  RSS SHARE  A  WP   D COMMAND",
"  PID     BASE    STACK      ESP      EIP STAT TT   TIME COMMAND"
};

extern (*fmt_fnc[])();

unsigned char *memmap;
unsigned pages;

/*
 * command line options
 */
int fmt;
int all;
int kern_comm;
int no_ctty;
int run_only;
char *ctty;
pid_t pid = -1;
int show_env;
int num_outp;		/* numeric fields for user or wchan */
int first_task = 1;	/* don't show task 0 */
int pg_shift = 2;	/* default: show k instead of pages */
int Sum;


main(argc, argv)
char **argv;
{
    char *p, *syspath=NULL;
    int no_header = 0;
    int fopt = 0;
    int width = 0;
    int Update = 0;

    if (argc > 3)
	usage();
    
    if (argc == 3)
	syspath = argv[2];

    if (argc > 1) {
	for (p = argv[1]; *p; ++p) {
	    switch (*p) {
		case 'l': fmt = PS_L; ++fopt; break;
		case 'u': fmt = PS_U; ++fopt; break;
		case 'j': fmt = PS_J; ++fopt; break;
		case 's': fmt = PS_S; ++fopt; break;
		case 'v': fmt = PS_V; ++fopt; break;
		case 'm': fmt = PS_M; ++fopt; break;
		case 'X': fmt = PS_X; ++fopt; break; /* regs */
		case 'a': all = 1; break;
		case 'c': kern_comm = 1; break;
		case '0': first_task = 0; /*falltrough*/
		case 'x': no_ctty = 1; break;
		case 't': ctty = p + 1; break;
		case 'r': run_only = 1; break;
		case 'e': show_env = 1; break;
		case 'w': ++width; break;
		case 'h': no_header = 1; break;
		case 'n': num_outp = 1; break;
		case 'S': Sum = 1; break;
		case 'p': pg_shift = 0; break;
		case 'U': Update = 1; break;
#ifdef DEBUG
		case 'd': ++Debug; break;
#endif
		case 'g':	/* old flag, ignore */
		case '-': break;
		default:
		    if (isdigit(*p)) {
			pid = atoi(p);
		    } else
			usage();
	    }
	    if (ctty || pid != -1)
		break;		/* pid and tty always last */
	}
	if (fopt > 1) {
	    fprintf(stderr, "ps: specify only one of j,l,s,u,v\n");
	    exit(1);
	}
    }

    if (open_sys(syspath, Update) == -1) {
	perror(syspath ? syspath : "cannot open psdatabase");
	exit(1);
    }

    set_maxcmd(width);
    read_globals();
    if (!no_header)
	puts(hdrs[fmt]);
    show_procs();
    exit(0);
}


usage()
{
    fprintf(stderr, "usage:  ps acehjlnrsSuUvwx{t<tty>,#} [system-path]\n");
    exit(1);
}


show_procs()
{
    struct task_struct *taskp;
    union task_union task_buf;
    int tty, i, uid;
    off_t _task = k_addr("_task");

    uid = getuid();

    if (ctty)
	tty = tty_to_dev(ctty);

    for (i = first_task; i < NR_TASKS; ++i) {
	kmemread(&taskp, _task + 4*i, 4);
	if (taskp) {
	    kmemread(&task_buf, taskp, sizeof(task_buf));
			/* check if valid, proc may have exited */
	    if ((unsigned) task_buf.task.state > 4 ||
		    task_buf.task.pid <= 0 && i != 0)
		continue;

	    if (pid >= 0) {
		if (task_buf.task.pid != pid)
		    continue;
	    } else if (ctty) {
		if (task_buf.task.tty != tty)
		    continue;
	    } else
		if (!all && task_buf.task.uid != uid ||
		    !no_ctty && task_buf.task.tty == -1 ||
		    run_only && task_buf.task.state != TASK_RUNNING &&
			    task_buf.task.state != TASK_UNINTERRUPTIBLE)
			continue;

	    (fmt_fnc[fmt])(&task_buf);
	    if (fmt != PS_V && fmt != PS_M)
		show_time(&task_buf);
	    printf("%s\n", cmd_args(&task_buf));
	}
    }
}



show_short(task)
struct task_struct *task;
{
    printf("%5d %s %s",
	task->pid,
	dev_to_tty(task->tty),
	status(task));
}

show_long(task)
struct task_struct *task;
{
    long ppid;

    kmemread(&ppid, &task->p_pptr->pid, 4);

    printf("%2x %5d %5d %5d %3d %2d %4d %4d %-10.10s %s %s ",
	task->flags | (task->used_math ? 4 : 0),
	task->euid,
	task->pid,
	ppid,
	2 * PZERO - task->counter,	/* sort of priority */
	PZERO - task->priority,		/* nice value */
	VSIZE(task),
	task->rss * 4,
	(task->state == TASK_INTERRUPTIBLE ||
	 task->state == TASK_UNINTERRUPTIBLE ? 
	    wchan(task->tss.ebp, task) : ""),
	status(task),
	dev_to_tty(task->tty));
}

show_jobs(task)
struct task_struct *task;
{
    long ppid, tpgid;
    struct tty_struct *tt;
    if (task->tty != -1) {
	tt = (struct tty_struct *) k_addr("_tty_table");
	kmemread(&tpgid, &tt[(task->tty & 0xff) - 1].pgrp, 4);
    } else
	tpgid = -1;

    kmemread(&ppid, &task->p_pptr->pid, 4);

    printf("%5d %5d %5d %5d %s %5d  %s %5d ",
	ppid,
	task->pid,
	task->pgrp,
	task->session,
	dev_to_tty(task->tty),
	tpgid,
	status(task),
	task->euid);
}

show_user(task)
struct task_struct *task;
{
    struct passwd *pw;
    time_t now, start;
    int pcpu, pmem;

    if (!num_outp && (pw = getpwuid(task->euid)) != NULL)
	printf("%-8s ", pw->pw_name);
    else
	printf("%5d    ", task->euid);

    now = time(0L);
    start = startup_time + task->start_time / HZ;
    if (now == start)
	pcpu = 0;
    else
	pcpu = (task->utime + task->stime) * (1000/HZ) / (now - start);
    pmem = task->rss * 1000 / (main_mem / 4096);

    printf("%5d %2d.%d %2d.%d %4d %4d %s %s%.6s ",
	task->pid,
	pcpu / 10, pcpu % 10,
	pmem / 10, pmem % 10,
	VSIZE(task),
	task->rss * 4,
	dev_to_tty(task->tty),
	status(task),
 	ctime(&start) + (now - start > 3600*24 ? 4 : 10));
}

show_sig(task)
struct task_struct *task;
{
    unsigned long sigignore=0, sigcatch=0, bit=1;
    int i;

    for (i=0; i<32; ++i) {
	switch((int) task->sigaction[i].sa_handler) {
	    case 1: sigignore |= bit; break;
	    case 0: break;
	    default: sigcatch |= bit;
	}
	bit <<= 1;
    }
    printf("%5d %5d %08x %08x %08x %08x %s %s ",
	task->euid,
	task->pid,
	task->signal,
	task->blocked,
	sigignore,
	sigcatch,
	status(task),
	dev_to_tty(task->tty));
}

show_vm(task)
struct task_struct *task;
{
    int pmem;

    printf("%5d %2s %s",
	task->pid,
	dev_to_tty(task->tty),
	status(task));
    show_time(task);
    printf(" %6d %4d %4d %4d ",
	task->maj_flt + (Sum ? task->cmaj_flt : 0),
	task->end_code / 1024,
	SIZE(task), task->rss*4);
    if (task->rlim[RLIMIT_RSS].rlim_cur == RLIM_INFINITY)
	printf("   xx ");
    else
	printf("%5d ", task->rlim[RLIMIT_RSS].rlim_cur / 1024);
    pmem = task->rss * 1000 / (main_mem / 4096);
    printf("%2d.%d ", pmem / 10, pmem % 10);
}


show_m(task)
struct task_struct *task;
{
    int i;
    unsigned long buf[PAGE_SIZE/4], *pte;
    unsigned long pdir, ptbl;
    int size=0, resident=0;
    int wp=0, dirty=0, acc=0, share=0, trs=0;
    int tpag = task->end_code / PAGE_SIZE;

    if (memmap == NULL)
	get_memmap();

    pdir = task->start_code >> 20;
    for (i = 0; i < 15; ++i, pdir += 4) {
	ptbl = get_kword(pdir);
	if (ptbl == 0) {
	    tpag -= 1024;
	    continue;
	}
	kmemread(buf, ptbl & 0xfffff000, sizeof buf);
	for (pte = buf; pte < &buf[1024]; ++pte) {
	    if (*pte != 0) {
		++size;
		if (tpag > 0)
		    ++trs;
		if (*pte & 1) {
		    ++resident;
		    if ((*pte & 2) == 0) {
			++wp;
		    }
		    if (memmap[MAP_NR(*pte)] > 1)
			++share;
		    if (*pte & 0x40) ++dirty;
		    if (*pte & 0x20) ++acc;
		}
	    }
	    --tpag;
	}
    }
    printf("%5d %2s %6d %6d %4d %4d %4d %4d %4d %4d %3d %3d %3d ", 
	task->pid,
	dev_to_tty(task->tty),
	task->maj_flt + (Sum ? task->cmaj_flt : 0),
	task->min_flt + (Sum ? task->cmin_flt : 0),
	task->end_code / 4096 << pg_shift,
	trs << pg_shift,
	size << pg_shift, 
	size - resident << pg_shift,
	task->rss << pg_shift,
	share << pg_shift, acc, wp, dirty
	);
}

show_regs(task)
struct task_struct *task;
{
    printf("%5d %8x %8x %8x %8x %s %2s ",
	task->pid,
	task->start_code,
	task->start_stack,
	KSTK_ESP(task),
	KSTK_EIP(task),
	status(task),
	dev_to_tty(task->tty));
}

int (*fmt_fnc[])() = {
    show_short,
    show_long,
    show_user,
    show_jobs,
    show_sig,
    show_vm,
    show_m,
    show_regs
};


show_time(task)
struct task_struct *task;
{
    unsigned t;

    t = (task->utime + task->stime) / HZ;
    if (Sum)
	t += (task->cutime + task->cstime) / HZ;

    printf("%3d:%02d ", t / 60, t % 60);
}

char *
status(task)
struct task_struct *task;
{
    static char buf[5] = "    ";

    buf[0] = "RSDZT" [task->state];
    buf[1] = (task->rss == 0 && task->state != TASK_ZOMBIE ? 'W' : ' ');
    if (task->priority > PZERO)
	buf[2] = '<';
    else if (task->priority < PZERO)
	buf[2] = 'N';
    else
	buf[2] = ' ';
    return(buf);
}


char *
wchan(ebp, stack)
reg_t ebp;
reg_t *stack;
{
    reg_t eip;
    int bp;
    static char buf[16], *p;

    bp = (ebp & PAGE_MASK) >> 2;
    eip = stack[bp + 1];
    p = find_func(eip);
    if (strcmp(p, "sleep_on") == 0 ||
		strcmp(p, "interruptible_sleep_on") == 0)
	return(wchan(stack[bp], stack));
    
    if (num_outp) {
	sprintf(buf, "%x", eip);
	return(buf);
    }
    if (strncmp(p, "sys_", 4) == 0)
	p += 4;
    return(p);
}

get_memmap()
{
    if (memmap == NULL) {
	pages = (get_kword(k_addr("_HIGH_MEMORY")) - LOW_MEM) >> 12;
	memmap = (unsigned char *) xmalloc(pages);
    }
    kmemread(memmap, k_addr("_mem_map"), pages);
}

read_globals()
{
    main_mem =  get_kword(k_addr("_memory_end")) -
		get_kword(k_addr("_main_memory_start"));
    startup_time = get_kword(k_addr("_startup_time"));
}


/*
 * ttynames:
 * 	ttya0 a1 a2...	virtual consoles
 *	ttyA0 A1 	serial lines
 *	ttyp0 p1 p2...	pty's
 */

static char *ttgrp = "abcdABCDpqrsPQRS";
static char *ttsub = "0123456789abcdef";

char *
dev_to_tty(int dev)
{
    static char tty[3];

    if (dev == -1)
	return "? ";
    if (dev == 0)
	return "co";

    tty[0] = ttgrp[(dev >> 4) & 017];
    tty[1] = ttsub[dev & 017];
    return(tty);
}

tty_to_dev(tty)
char *tty;
{
    char *p, *q;

    if (*tty == '\0') {		/* empty string: controlling tty */
	struct stat buf;
	if (fstat(0, &buf) != -1)
	    return(buf.st_rdev & 0xff);
	else
	    return -1;
    }
    if (tty[1] == '\0' && isdigit(*tty))
	return(*tty - '0');
    if (strcmp(tty, "co") == 0)
	return 0;
    if ((p = strchr(ttgrp, *tty)) != NULL &&
	(q = strchr(ttsub, tty[1])) != NULL)
	return(((p - ttgrp) << 4) | (q - ttsub));
    else
	return -1;
}
