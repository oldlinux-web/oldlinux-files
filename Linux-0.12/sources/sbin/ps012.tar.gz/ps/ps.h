/*
 * ps.h
 *
 * Copyright (c) 1992 Branko Lankester
 *
 */


#define	PS_D	0	/* default format (short) */
#define	PS_L	1
#define	PS_U	2
#define	PS_J	3
#define	PS_S	4	/* signal format */
#define	PS_V	5
#define	PS_M	6	/* mem. stuff */
#define	PS_X	7	/* regs etc., for testing */

extern int show_env;	/* -e flag */
extern int kern_comm;	/* -c flag */
extern int fmt;

extern char *hdrs[];


#define	PZERO	15	/* priority of init (in sched.h) */

#define	PAGE_MASK	0xfff

#define	KSTK_EIP(task)	(*((unsigned long *)(task)+1019))
#define	KSTK_ESP(task)	(*((unsigned long *)(task)+1022))

typedef unsigned reg_t;


char *find_func();
unsigned long k_addr();
unsigned long get_kword();
char *cmd_args();
char *dev_to_tty();
char *wchan();
char *status();
char *xmalloc();
