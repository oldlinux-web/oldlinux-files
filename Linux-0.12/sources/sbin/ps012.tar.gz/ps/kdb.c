/*
 * kdb.c	- a simple kernel debugger
 *
 * Displays kernel memory on address or symbol.
 * 
 * syntax:
 * [address]/[count][modifier]
 *
 * address: symbol or absolute value
 * count: decimal number of units to print
 * modifiers:
 *	D	dec. long word (signed)
 *	U	dec. long word (unsigned)
 *	X	hex. long word
 *	d,u,x	2 byte word
 *	B	hex. byte
 *
 * An empty line repeats last command
 */

 /*
  * works only on a little endian system
  */

#include <stdio.h>

extern int kmemfd;

main()
{
    char buf[1024];
    unsigned long cur_addr=0;
    int count=0, i, val, size=0, l;
    char *p, *pfmt="", *index();

    if (open_psdb()) {
	perror("");
	exit(1);
    }
    if ((kmemfd = open("/dev/mem", 2)) == -1) {
	perror("cannot open /dev/mem\n");
	exit(1);
    }
    while (fgets(buf, sizeof buf, stdin) != NULL) {
	if (strcmp(buf, "q\n") != 0) {
		if (*buf != '\n') {
		    if ((p = index(buf, '/')) == NULL) {
			if (( p = index(buf, '\n')) != NULL) 	
				*p = '\0';
			strcat(buf, "/1\n");
		    }
		    *p++ = '\0';
		    if (*buf) {
			if (*buf >= '0' && *buf <= '9') {
			    cur_addr = strtol(buf, 0, 0);
			} else
			    if ((cur_addr = k_addr(buf)) == -1) {
				fprintf(stderr,"symbol not found: '%s'\n", buf);
				continue;
			    }
		    }
		    if (*p >= '0' && *p <= '9') {
			count = strtol(p, &p, 10);
		    } else
			count = 1;

		    switch (*p) {
			case '\n': /* default */
			case 'X': size = 4; pfmt = "%08x  "; break;
			case 'D': size = 4; pfmt = "%11ld "; break;
			case 'U': size = 4; pfmt = "%10lu "; break;
			case 'x': size = 2; pfmt = "%04x "; break;
			case 'd': size = 2; pfmt = "%6d "; break;
			case 'u': size = 2; pfmt = "%5u "; break;
			case 'b': size = 1; pfmt = "%03o "; break;
			case 'B': size = 1; pfmt = "%02x "; break;
			case 'c': size = 1; pfmt = "%c"; break;
			case 'n': size = 0; pfmt = "\n"; break;
			case 't': size = 0; pfmt = "\t"; break;
			case 'r': size = 0; pfmt = " "; break;
			case 'W': do_write(cur_addr, p+1, 4); continue;
			case 'w': do_write(cur_addr, p+1, 2); continue;
			default: fprintf(stderr,"invalid modifier: '%c'\n", *p);
				 continue;
		    }
		}
		l = 16;
		printf("%8x:  ", cur_addr);
		i = count;
	  	while (--i >= 0) {
		    if ((l -= size) < 0) {
		        printf("\n%8x:  ", cur_addr);
		        l += 16;
		    }
	  	    val = 0;
		    kmemread(&val, cur_addr, size);
		    printf(pfmt, val);
		    cur_addr += size;
		}
		printf("\n");
	}
	else return 0;
    }
    exit(0);
}

do_write(addr, p, n)
unsigned long addr;
char *p;
{
    char *res;
    unsigned long w;
    
    w = strtol(p, &res, 0);
    if (res == NULL || *res != '\n') {
	fprintf(stderr, "invalid value: %s\n", p);
	return(-1);
    }
    if (lseek(kmemfd, addr, 0) == -1) {
	perror("lseek");
	return(-1);
    }
    if (write(kmemfd, &w, n) != n) {
	fprintf(stderr, "cannot write to address %lx\n", addr);
	return(-1);
    }
    return(0);
}
