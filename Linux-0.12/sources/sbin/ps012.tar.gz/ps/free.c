
#include <stdio.h>
#include <linux/fs.h>
#include <linux/mm.h>
#include <sys/stat.h>
#include "../kernel/blk_drv/blk.h"

#define SWAP_BITS (4096<<3)

#define bitop(name,op) \
static inline int name(char * addr,unsigned int nr) \
{ \
int __res; \
__asm__ __volatile__("bt" op " %1,%2; adcl $0,%0" \
:"=g" (__res) \
:"r" (nr),"m" (*(addr)),"0" (0)); \
return __res; \
}

bitop(bit,"")
bitop(setbit,"s")
bitop(clrbit,"r")

extern int optind;
extern char *optarg;
char *swapf = NULL;
unsigned long swap_bm;
int pg_shift = 2;

main(argc, argv)
char **argv;
{
    int i, opt, interv = 0;
    int req = 0, mem = 0, swap = 0, buf = 0, ino = 0;

    if (open_psdb()) {
	perror("cannot open psdatabase");
	exit(2);
    }
    while ((opt = getopt(argc, argv, "pkcrmsbiS:")) != -1) {
	switch (opt) {
	    case 'p': pg_shift = 0; break;
	    case 'k': pg_shift = 2; break;
	    case 'c': pg_shift = 12; break;
	    case 'r': req = 1; break;
	    case 'm': mem = 1; break;
	    case 's': swap = 1; break;
	    case 'b': buf = 1; break;
	    case 'i': ino = 1; break;
	    case 'S': interv = atoi(optarg); break;
	    default:
		fprintf(stderr, "usage: free [-msribpc] [-S interval] [swappath]\n");
	}
    }

    swap_bm = get_kword(k_addr("_swap_bitmap"));

    if (!mem && !req && !swap && !buf && !ino) {
	mem = 1;		/* default: mem and swap */
	swap = (swap_bm != 0);
    }

    if (argc > optind)
	swapf = argv[optind];

    if (mem || swap)
	printf("             total       used       free     shared\n");

    if (buf || ino)
	printf("             total       used      dirty     locked       free\n");

    while (1) {
	if (req)
	    show_req();

	if (buf)
	    show_buf();

	if (ino)
	    show_ino();

	if (mem)
	    show_memory();

	if (swap)
	    show_swap();

	if (interv)
	    sleep(interv);
	else
	    break;
    }

    exit(0);
}

show_memory()
{
    char memmap[PAGING_PAGES];
    unsigned used=0, freepg=0, shared=0;
    int i;

    kmemread(memmap, k_addr("_mem_map"), sizeof memmap);
    for (i = 0; i < PAGING_PAGES; ++i)
	switch (memmap[i]) {
	    case 0: ++freepg; break;
	    case USED: break;
	    default: shared += memmap[i] - 1;
	    case 1: ++used;
	}

    printf("memory: %10d %10d %10d %10d\n",
	freepg + used << pg_shift,
	used << pg_shift,
	freepg << pg_shift,
	shared << pg_shift);
}

show_swap()
{
    unsigned freepg=0;
    int i;
    char bitmap[4096];
    char swappath[64];

    printf("swap:   ");
    if (swap_bm == 0)
	printf("No swap device.\n");
    else {
	freepg = 0;
	kmemread(bitmap, swap_bm, 4096);
	for (i = 0; i < SWAP_BITS; ++i)
	    freepg += bit(bitmap, i);

	if (swapf == NULL) {
	    int swapdev;
	    if ((swapdev = get_kword(k_addr("_SWAP_DEV"))) != 0) {
		if (swapdev >> 8 != 3) {
		    fprintf(stderr, "bad device number\n");
		    exit(2);
		}
/* for 0.9x
		sprintf(swappath, "/dev/hd%c%d", (swapdev>>6) + 'a',
				swapdev & 0x3f);
*/
		sprintf(swappath, "/dev/hd%d", swapdev & 0x3f);
		swapf = swappath;
	    }
	}
	if (swapf != NULL) {
	    unsigned total = 0;
	    int fd;

	    if ((fd = open(swapf, 0)) == -1) {
		perror(swapf);
		exit(2);
	    }
	    read(fd, bitmap, sizeof bitmap);
	    for (i = 0; i < SWAP_BITS - 80; ++i)
		total += bit(bitmap, i);

	    printf("%10d %10d ", 
		total << pg_shift,
		total - freepg << pg_shift);
	} else
	    printf("                      ");
	printf("%10d\n", freepg << pg_shift);
    }
}

show_req()
{
    struct request request[NR_REQUEST];
    int i;
    int readreq = 0, writereq = 0;

    kmemread(request, k_addr("_request"), sizeof request);
    for (i=0; i<NR_REQUEST; ++i) {
	if (request[i].dev != -1) {
	    if (request[i].cmd)
		++writereq;
	    else
		++readreq;
	}
    }
    printf("blk requests:  read: %d  write: %d  free: %d\n",
	readreq, writereq, NR_REQUEST - readreq - writereq);
}


show_buf()
{
    int nr_buf;
    int i;
    struct buffer_head *buf;
    int in_use = 0, dirt = 0, locked = 0, unused = 0;

    nr_buf = get_kword(k_addr("_nr_buffers"));

    buf = (struct buffer_head *) xmalloc(nr_buf * sizeof(struct buffer_head));
    kmemread(buf, get_kword(k_addr("_start_buffer")), 
		nr_buf * sizeof(struct buffer_head));

    for (i = 0; i < nr_buf; ++i) {
	if (buf[i].b_count) ++in_use;
	if (buf[i].b_dirt) ++dirt;
	if (buf[i].b_lock) ++locked;
	if (buf[i].b_dev == 0) ++unused;
    }
#undef free
    free(buf);
    printf("buffers:%10d %10d %10d %10d %10d\n",
	nr_buf, in_use, dirt, locked, unused);
}

show_ino()
{
    struct m_inode ino[NR_INODE];
    int in_use = 0, dirt = 0, locked = 0;
    int i;

    kmemread(ino, k_addr("_inode_table"), sizeof ino);
    for (i = 0; i < NR_INODE; ++i) {
	if (ino[i].i_count) ++in_use;
	if (ino[i].i_dirt) ++dirt;
	if (ino[i].i_lock) ++locked;
    }
    printf("inodes: %10d %10d %10d %10d %10d\n",
	NR_INODE, in_use, dirt, locked, NR_INODE - in_use);
}
