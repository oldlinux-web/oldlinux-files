/*
 * dip		A program for handling dialup IP connecions.
 *		This module handles setting the interface and
 *		its routing table entry.
 *
 * Version:	@(#)attach.c	3.3.3	08/16/93
 *
 * Author:      Fred N. van Kempen, <waltje@uWalt.NL.Mugnet.ORG>
 *		Copyright 1988-1993 MicroWalt Corporation
 *
 *		This program is free software; you can redistribute it
 *		and/or  modify it under  the terms of  the GNU General
 *		Public  License as  published  by  the  Free  Software
 *		Foundation;  either  version 2 of the License, or  (at
 *		your option) any later version.
 */
#include "dip.h"


int
attach(char *name, struct dip *dip)
{
  char buff[1024];
  FILE *fp; /* lock file */

  /* Set up for "upping" the desired interface. */
  sprintf(buff, "%s %s %s pointopoint ", _PATH_BIN_IFCONFIG,
	name, inet_ntoa(dip->loc_ip));
  sprintf(&buff[strlen(buff)], "%s mtu %d netmask 255.255.255.0", 
	  inet_ntoa(dip->rmt_ip), dip->mtu);
#ifdef DEBUG
  syslog(LOG_ERR, ">>> ATTACH \"%s\"\n", buff);
#endif
  if (system(buff) != 0) return(-1);

  sprintf(buff, "%s add %s", _PATH_BIN_ROUTE, inet_ntoa(dip->rmt_ip));
#ifdef DEBUG
  syslog(LOG_ERR, ">>> ATTACH \"%s\"\n", buff);
#endif
  if (system(buff) != 0) return(-1);
  sprintf(buff, "%s add default", _PATH_BIN_ROUTE);
  sprintf(&buff[strlen(buff)], " gw %s metric 1", inet_ntoa(dip->rmt_ip));
#ifdef DEBUG
  syslog(LOG_ERR, ">>> ATTACH \"%s\"\n", buff);
#endif
  if (system(buff) != 0) return(-1);
 
  if ((fp = fopen("/usr/spool/uucp/LCK..cua1", "w")) == (FILE *)NULL)
	return(-1);
  fprintf(fp, "%1d", (int)getpid());
  fclose(fp); 
  if ((fp = fopen("/usr/spool/uucp/LCK..ttyS1", "w")) == (FILE *)NULL)
	return(-1);
  fprintf(fp, "%1d", (int)getpid());
  fclose(fp); 
  return(0);
}


void
detach(char *name)
{
  char buff[1024];

  /* Set up for "downing" the desired interface. */
  sprintf(buff, "%s %s down", _PATH_BIN_IFCONFIG, name);
  syslog(LOG_ERR, ">>> DETACH \"%s\"\n", buff);
  (void) system(buff);
  (void) unlink("/usr/spool/uucp/LCK..cua1");
  (void) unlink("/usr/spool/uucp/LCK..ttyS1");
}
