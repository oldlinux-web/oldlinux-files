/*
 * dip		A program for handling dialup IP connecions.
 *		This module handles setting the interface and
 *		its routing table entry.
 *
 * Author:      Fred N. van Kempen, <waltje@uWalt.NL.Mugnet.ORG>
 *		Copyright 1992-1993 MicroWalt Corporation
 *		This program is free software; you can redistribute it and/or
 *		modify it under the terms of the GNU General Public License
 *		as published by the Free Software Foundation; either version
 *		2 of the License, or (at your option) any later version.
 */
#include "dip.h"


int rt_add(name, dest)
char *name;
struct in_addr *dest;
{
  char myname[128];
  char buff[1024];

  /* Determine our own IP address. */
  if (gethostname(myname, 128) < 0) return(-1);

  /* Set up for "upping" the desired interface. */
  sprintf(buff, "/etc/ifconfig %s %s", name, myname);
  syslog(LOG_ERR, ">>> \"%s\"\n", buff);
  if (system(buff) != 0) return(-1);

  sprintf(buff, "/etc/route add %s %s", inet_ntoa(*dest), name);
  syslog(LOG_ERR, ">>> \"%s\"\n", buff);
  if (system(buff) != 0) return(-1);
  return(0);
}


void rt_del(name)
char *name;
{
  char buff[1024];

  /* Set up for "downing" the desired interface. */
  sprintf(buff, "/etc/ifconfig %s down", name);
  syslog(LOG_ERR, ">>> \"%s\"\n", buff);
  (void) system(buff);
}
