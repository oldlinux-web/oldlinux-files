#! /bin/sh
#
# NET-BASE	A collection of programs that form the base set of the
#		NET-2 Networking Distribution for the LINUX operating
#		system.
#
# Version:	@(#)Install.sh  1.00    07/05/93
#
# Author:	Fred N. van Kempen, <waltje@uwalt.nl.mugnet.org>
#		Copyright 1988-1993 MicroWalt Corporation
#
#		This program is free software; you can redistribute it
#		and/or  modify it under  the terms of  the GNU General
#		Public  License as  published  by  the  Free  Software
#		Foundation;  either  version 2 of the License, or  (at
#		your option) any later version.
#

#ROOT="/tmp"		# Set to "/tmp" for testing.
ETC="/etc"		# Usually "/etc" - "/etc/inet" for old SLS.
DEV="/dev/net"		# Set to "/dev" for SLS.
CONF="/conf/net"	# Set to "/etc" for SLS.

DIRS="/dev /dev/net /conf /conf/net /etc /bin /usr /usr/bin /usr/man"
BIN_PROGS="hostname netstat"
ETC_PROGS="arp ifsetup ifconfig kd route wdsetup/wdsetup"


  echo "Installing NET-2 BASE..."

  echo -n "Creating directories: "
  for i in ${DIRS}
  do
	if [ ! -d ${ROOT}$i ]
	then
		echo -n "$i "
		mkdir ${ROOT}$i
		chown bin.bin ${ROOT}$i
		chmod 755 ${ROOT}$i
	fi
  done
  for i in 1 5 8
  do
	if [ ! -d ${ROOT}/usr/man/man$i ]
	then
		echo -n "/usr/man/man$i "
		mkdir ${ROOT}/usr/man/man$i
		chown bin.bin ${ROOT}/usr/man/man$i
		chmod 755 ${ROOT}/usr/man/man$i
	fi
  done
  echo "...done"

  # Create the /dev entries.
  echo -n "Creating DEVICE (${DEV}) files..."
  rm -rf ${ROOT}${DEV}/*

  # Install the SOCKET layer entries.
  mknod ${ROOT}${DEV}/socket c 16 0
  chmod 666 ${ROOT}${DEV}/socket
  mknod ${ROOT}${DEV}/arp c 16 1
  chmod 600 ${ROOT}${DEV}/arp

  # Install the AF_UNIX layer entries.
  mknod ${ROOT}${DEV}/unix c 17 0
  chmod 666 ${ROOT}${DEV}/unix

  # Install the AF_INET layer entries.
  mknod ${ROOT}${DEV}/inet c 18 0
  chmod 600 ${ROOT}${DEV}/inet
  mknod ${ROOT}${DEV}/ip c 18 1
  chmod 666 ${ROOT}${DEV}/ip
  mknod ${ROOT}${DEV}/icmp c 18 2
  chmod 666 ${ROOT}${DEV}/icmp
  mknod ${ROOT}${DEV}/tcp c 18 3
  chmod 666 ${ROOT}${DEV}/tcp
  mknod ${ROOT}${DEV}/udp c 18 4
  chmod 666 ${ROOT}${DEV}/udp

  # Install the LOOPBACK device driver.
  mknod ${ROOT}${DEV}/lo c 19 0
  chmod 600 ${ROOT}${DEV}/lo

  # Install the DP8390 device driver.
  for i in 0 1 2 3
  do
	mknod ${ROOT}${DEV}/wd$i c 20 `expr $i + 8`
	chmod 600 ${ROOT}${DEV}/wd*
	mknod ${ROOT}${DEV}/el$i c 20 `expr $i + 16`
	chmod 600 ${ROOT}${DEV}/el*
	mknod ${ROOT}${DEV}/ne$i c 20 `expr $i + 24`
	chmod 600 ${ROOT}${DEV}/ne*
	mknod ${ROOT}${DEV}/hp$i c 20 `expr $i + 32`
	chmod 600 ${ROOT}${DEV}/hp*
  done

  # Install the SLIP device driver.
  mknod ${ROOT}${DEV}/slip c 21 0
  chmod 600 ${ROOT}${DEV}/slip

  # Install the PLIP device driver.
  for i in 0 1 2
  do
	mknod ${ROOT}${DEV}/plip$i c 22 $i
  done
  chmod 600 ${ROOT}${DEV}/plip*

  # Install the DLINK device driver.
  for i in 0 1 2
  do
	mknod ${ROOT}${DEV}/dl$i c 23 $i
  done
  chmod 600 ${ROOT}${DEV}/dl*

  chown bin.bin ${ROOT}${DEV}/*
  echo "done"

  # Install the CONFIG files.
  if [ "xx$1" != "xxupdate" ]
  then
	echo -n "Installing CONFIG (${ETC}) files..."
	cp -a samples/etc/* ${ROOT}${ETC}
	echo "done"
	echo -n "Installing CONFIG (${CONF}) files..."
	cp -a samples/conf/* ${ROOT}${CONF}
	echo "done"

	# Set up those damn symbolic links.
	echo -n "Setting up symbolic links..."
	links="`cd ${ROOT}${CONF}; echo *`"
	for i in ${links}
	do
		ln -sf ${ROOT}${CONF}/$i ${ROOT}${ETC}/$i
	done
	echo "done"
  fi

  # Install the primary user commands.
  echo -n "Installing USER (/bin) commands..."
  for i in ${BIN_PROGS}
  do
	path=${ROOT}/bin/`basename $i`
	cp $i ${path}
	chmod 555 ${path}
	chown bin.bin ${path}
  done
  echo "done"

  # Install the primary system administrator commands.
  echo -n "Installing SYSTEM (${ETC}) commands..."
  for i in ${ETC_PROGS}
  do
	path=${ROOT}${ETC}/`basename $i`
	cp $i ${path}
	chmod 555 ${path}
	chown bin.bin ${path}
  done
  echo "done"

  # Install the manual pages.
  echo -n "Installing manual pages..."
  for i in 1 5 8
  do
	chown bin.bin man/*.$i >/dev/null
	chmod 644 man/*.$i >/dev/null
	cp -a man/*.$i ${ROOT}/usr/man/man$i >/dev/null
  done
  echo "done"

  # Install the DIP program.
  echo -n "Installing DIP..."

  cp dip/dip ${ROOT}/usr/bin/dip
  chown root.dip ${ROOT}/usr/bin/dip
  chmod 6750 ${ROOT}/usr/bin/dip
  cp dip/sample.dip ${ROOT}${CONF}
  chown bin.bin ${ROOT}${CONF}/sample.dip
  chmod 600 ${ROOT}${CONF}/sample.dip
  cp dip/dip.8 ${ROOT}/usr/man/man8
  chown bin.bin ${ROOT}/usr/man/man8/dip.8
  chmod 644 ${ROOT}/usr/man/man8/dip.8
  echo "done"

  echo
  echo "Installation completed."
  echo "Do NOT forget to edit the files I installed for you;"
  echo "otherwise the NET-2 system will not operate correctly!"
  echo

  exit 0
