/*
 * dip		A program for handling dialup IP connecions.
 *		This module handles the PPP protocol.
 *
 * Version:	@(#)p_ppp.c	3.3.0	07/06/93
 *
 * Author:      Fred N. van Kempen, <waltje@uWalt.NL.Mugnet.ORG>
 *		Copyright 1988-1993 MicroWalt Corporation
 *
 *		This program is free software; you can redistribute it
 *		and/or  modify it under  the terms of  the GNU General
 *		Public  License as  published  by  the  Free  Software
 *		Foundation;  either  version 2 of the License, or  (at
 *		your option) any later version.
 */
#include "dip.h"


void
do_ppp(struct dip *dip)
{
  fprintf(stderr, "DIP: PPP protocol not available yet.\n");
}
