/*
 * dip		A program for handling dialup IP connecions.
 *		IP Datagram dumping routines.
 *
 * Version:	@(#)ipdump.c	3.3.0	07/06/93
 *
 * Author:      Fred N. van Kempen, <waltje@uWalt.NL.Mugnet.ORG>
 *		Copyright 1988-1993 MicroWalt Corporation
 *
 *		This program is free software; you can redistribute it
 *		and/or  modify it under  the terms of  the GNU General
 *		Public  License as  published  by  the  Free  Software
 *		Foundation;  either  version 2 of the License, or  (at
 *		your option) any later version.
 */
#include "dip.h"
#include <linux/ip.h>	/* --> should become <net/ip.h> */


/* Define some IP layer stuff.  Not all systems have it. */
#define	IP_VERSION	4		/* version# of our IP software	*/
#define	IPF_F_OFFSET	0x1fff		/* Offset field			*/
#define	IPF_DF		0x4000		/* Don't fragment flag		*/
#define	IPF_MF		0x2000		/* More Fragments flag		*/
#define	IP_OF_COPIED	0x80		/* Copied-on-fragmentation flag	*/
#define	IP_OF_CLASS	0x60		/* Option class			*/
#define	IP_OF_NUMBER	0x1f		/* Option number		*/


void
ip_dump(char *ptr, int len)
{
  struct iphdr *ip;
  int flags, dlen, doff;

  ip = (struct iphdr *) ptr;
  dlen = ntohs(ip->tot_len);
  flags = (ntohs(ip->offset) & ~IPF_F_OFFSET);
  doff = ((ntohs(ip->offset) & IPF_F_OFFSET) << 3);

  fprintf(stderr, "\r*****\n");
  fprintf(stderr, "IP: %s->", inet_ntoa(*(struct in_addr *) &ip->saddr));
  fprintf(stderr, "%s\n", inet_ntoa(*(struct in_addr *) &ip->daddr));
  fprintf(stderr, " len %u ihl %u ver %u ttl %u prot %u",
	dlen, ip->ihl, ip->version, ip->ttl, ip->protocol);

  if (ip->tos != 0) fprintf(stderr, " tos %u", ip->tos);
  if (doff != 0 || (flags & IPF_MF))
	fprintf(stderr, " id %u offs %u", ntohs(ip->id), doff);

  if (flags & IPF_DF) fprintf(stderr, " DF");
  if (flags & IPF_MF) fprintf(stderr, " MF");
  if (flags & IPF_CE) fprintf(stderr, " CE");
  fprintf(stderr, "\n*****\n");
  (void) fflush(stderr);
}
