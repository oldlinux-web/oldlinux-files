/*
 * ifconfig	This file contains an implementation of the command
 *		that either displays or sets the characteristics of
 *		one or more of the system's networking interfaces.
 *
 * Usage:	ifconfig [-a] [-i] [-v] interface [inet] [address | up |
 *			down | metric NN | mtu NN | arp | -arp |
 *			trailers | -trailers | broadcast aa.bb.cc.dd |
 *			dstaddr aa.bb.cc.dd | netmask aa.bb.cc.dd |
 *			pointopoint aa.bb.cc.dd .. ]
 *
 * Version:	@(#)ifconfig.c	1.31	07/11/93
 *
 * Author:	Fred N. van Kempen, <waltje@uwalt.nl.mugnet.org>
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <linux/ddi.h>
#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <netinet/in.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <linux/if_ether.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <resolv.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "pathnames.h"


struct interface {
  char			name[IFNAMSIZ];		/* interface name	*/
  short			flags;			/* various flags	*/
  int			metric;			/* routing metric	*/
  int			mtu;			/* MTU value		*/
  struct sockaddr	addr;			/* IP address		*/
  struct sockaddr	dstaddr;		/* P-P IP address	*/
  struct sockaddr	broadaddr;		/* IP broadcast address	*/
  struct sockaddr	netmask;		/* IP network mask	*/
  struct sockaddr	hwaddr;			/* HW address		*/
  struct dev_stats	stats;			/* statistics		*/
};

  
struct addrtyp {
  char		*name;			/* address family name		*/
  int		af;			/* address family ID		*/
  char		*(*ntoa)();		/* no specified args!!!!	*/
};


/* Forward declaration. */
static char *unspec_print(struct sockaddr *sap);
static char *ether_print(struct sockaddr *sap);
#ifdef AF_INET
static char *in_print(struct sockaddr *sap);
#endif


char *Version = "@(#) ifconfig 1.31 (07/11/93)";


int opt_a = 0;				/* show all interfaces		*/
int opt_i = 0;				/* show the statistics		*/
int opt_v = 0;				/* debugging output flag	*/
int sock = -1;				/* AF_INET raw socket desc.	*/
struct addrtyp af_types[] = {		/* the address families		*/
  { "UNSPEC",	AF_UNSPEC,	unspec_print	},
#ifdef AF_INET
  { "inet",	AF_INET,	in_print	},
#endif
  { NULL,	-1,		NULL		}
};
struct addrtyp hw_types[] = {		/* the hardware types		*/
  { "UNSPEC",		0,		unspec_print	},
  { "Ethernet",		ARPHRD_ETHER,	ether_print	},
  { "SLIP",		127,		NULL		},
  { "CSLIP",		126,		NULL		},
#if 0
  { "PPP",		125,		NULL		},
#endif
#if 0
  { "KISS AX.25",	124,		ax25_print	},
#endif
  { "LOOPBACK",		255,		NULL		},
  { NULL,		-1,		NULL		}
};
int addr_family = 0;			/* currently selected AF	*/


/* Display an UNSPEC address. */
static char *unspec_print(struct sockaddr *sap)
{
  static char buff[64];
  unsigned char *ptr;
  char *pos;
  int i;

  if (sap->sa_family == 0xFFFF || sap->sa_family == 0) return("[NONE SET]");
  ptr = (unsigned char *) sap;
  pos = buff;
  for(i = 0; i < sizeof(struct sockaddr); i++) {
	pos += sprintf(pos, "%02X-", (*ptr++ & 0377));
  }
  buff[strlen(buff) - 1] = '\0';
  return(buff);
}


/* Display an Ethernet address. */
static char *ether_print(struct sockaddr *sap)
{
  static char buff[64];
  unsigned char *ptr;

  ptr = (unsigned char *) sap->sa_data;
  sprintf(buff, "%02X:%02X:%02X:%02X:%02X:%02X",
	ptr[0] & 0377, ptr[1] & 0377, ptr[2] & 0377,
	ptr[3] & 0377, ptr[4] & 0377, ptr[5] & 0377);
  return(buff);
}


#ifdef AF_INET
/* Display a DARPA Internet ("IP") address. */
static char *in_print(struct sockaddr *sap)
{
  return(inet_ntoa(((struct sockaddr_in *)sap)->sin_addr));
}
#endif

/* Find the correct address family handler. */
static struct addrtyp *get_af(int af)
{
  register int i;

  i = 0;
  while (af_types[i].name != NULL) {
	if (af_types[i].af == af) return(&af_types[i]);
	i++;
  }
  return((struct addrtyp *)NULL);
}


/* Find the correct address family handler by name. */
static struct addrtyp *get_afname(char *name)
{
  register int i;

  i = 0;
  while (af_types[i].name != NULL) {
	if (!strcmp(af_types[i].name, name)) return(&af_types[i]);
	i++;
  }
  return((struct addrtyp *)NULL);
}


/* Find the correct hardware type handler. */
static struct addrtyp *get_hw(int hw)
{
  register int i;

  i = 0;
  while (hw_types[i].name != NULL) {
	if (hw_types[i].af == hw) return(&hw_types[i]);
	i++;
  }
  return((struct addrtyp *)NULL);
}


static int resolve(char *name, struct in_addr *in)
{
  struct hostent *hp;

  /* Hack- this address is refused by the resolver routines! */
  if (!strcmp(name, "255.255.255.255")) {
	in->s_addr = INADDR_BROADCAST;
	return(0);
  }
  if ((hp = gethostbyname(name)) == (struct hostent *)NULL) return(-1);
  memcpy((char *) in, (char *) hp->h_addr_list[0], hp->h_length);
  return(0);
}


static void ife_print(struct interface *ptr)
{
  struct addrtyp *ap;
  struct addrtyp *hw;

  ap = get_af(ptr->addr.sa_family);
  if (ap == NULL) ap = get_af(0);
  hw = get_hw(ptr->hwaddr.sa_family);
  if (hw == NULL) hw = get_hw(0);

  printf("%-8.8s  Link encap %s  ", ptr->name, hw->name);
  if (hw->ntoa != NULL) {
	printf("HWaddr %s", hw->ntoa(&ptr->hwaddr));
  }
  printf("\n          %s addr %s", ap->name, ap->ntoa(&ptr->addr));
  if (ptr->flags & IFF_POINTOPOINT) {
	printf("  P-t-P %s  ", ap->ntoa(&ptr->dstaddr));
  } else {
	printf("  Bcast %s  ", ap->ntoa(&ptr->broadaddr));
  }
  printf("Mask %s\n", ap->ntoa(&ptr->netmask));
  printf("          ");
  if (ptr->flags == 0) printf("[NO FLAGS] ");
  if (ptr->flags & IFF_UP) printf("UP ");
  if (ptr->flags & IFF_BROADCAST) printf("BROADCAST ");
  if (ptr->flags & IFF_DEBUG) printf("DEBUG ");
  if (ptr->flags & IFF_LOOPBACK) printf("LOOPBACK ");
  if (ptr->flags & IFF_POINTOPOINT) printf("POINTOPOINT ");
  if (ptr->flags & IFF_NOTRAILERS) printf("NOTRAILERS ");
  if (ptr->flags & IFF_RUNNING) printf("RUNNING ");
  if (ptr->flags & IFF_NOARP) printf("NOARP ");
  if (ptr->flags & IFF_PROMISC) printf("PROMISC ");
  if (ptr->flags & IFF_ALLMULTI) printf("ALLMULTI ");
  printf(" MTU %d  Metric %d\n", ptr->mtu, ptr->metric);

  /* If needed, display the interface statistics. */
  printf("          ");
  printf("RX packets %u errors %u dropped %u overrun %u\n",
		ptr->stats.rx_packets, ptr->stats.rx_errors,
		ptr->stats.rx_dropped, ptr->stats.rx_overruns);
  printf("          ");
  printf("TX packets %u errors %u dropped %u overrun %u\n",
		ptr->stats.tx_packets, ptr->stats.tx_errors,
		ptr->stats.tx_dropped, ptr->stats.tx_overruns);

  printf("\n");
}


/* Fetch the inteface configuration from the kernel. */
static int if_fetch(char *ifname, struct interface *ife)
{
  struct ifreq ifr;

  memset((char *) ife, 0, sizeof(struct interface));
  strcpy(ife->name, ifname);

  strcpy(ifr.ifr_name, ifname);
  if (ioctl(sock, SIOCGIFFLAGS, &ifr) < 0) {
	fprintf(stderr, "SIOCGIFFLAGS: %s\n", strerror(errno));
	return(-1);
  }
  ife->flags = ifr.ifr_flags;

  strcpy(ifr.ifr_name, ifname);
  if (ioctl(sock, SIOCGIFADDR, &ifr) < 0) {
	memset(&ife->addr, 0, sizeof(struct sockaddr));
  } else ife->addr = ifr.ifr_addr;

  strcpy(ifr.ifr_name, ifname);
  if (ioctl(sock, SIOCGIFHWADDR, &ifr) < 0) {
	memset(&ife->hwaddr, 0, sizeof(struct sockaddr));
  } else ife->hwaddr = ifr.ifr_addr;

  strcpy(ifr.ifr_name, ifname);
  if (ioctl(sock, SIOCGIFMETRIC, &ifr) < 0) {
	ife->metric = 0;
  } else ife->metric = ifr.ifr_metric;

#ifdef SIOCGIFMTU
  strcpy(ifr.ifr_name, ifname);
  if (ioctl(sock, SIOCGIFMTU, &ifr) < 0) {
	ife->mtu = 0;
  } else ife->mtu = ifr.ifr_mtu;
#endif

  strcpy(ifr.ifr_name, ifname);
  if (ioctl(sock, SIOCGIFDSTADDR, &ifr) < 0) {
	memset(&ife->dstaddr, 0, sizeof(struct sockaddr));
  } else ife->dstaddr = ifr.ifr_dstaddr;

  strcpy(ifr.ifr_name, ifname);
  if (ioctl(sock, SIOCGIFBRDADDR, &ifr) < 0) {
	memset(&ife->broadaddr, 0, sizeof(struct sockaddr));
  } else ife->broadaddr = ifr.ifr_broadaddr;

#ifdef SIOCGIFNETMASK
  strcpy(ifr.ifr_name, ifname);
  if (ioctl(sock, SIOCGIFNETMASK, &ifr) < 0) {
	memset(&ife->netmask, 0, sizeof(struct sockaddr));
  } else {
#ifdef LINUX
	ife->netmask = ifr.ifr_netmask;
#else
	memcpy(ife->netmask.sa_data, &ifr.ifr_data, sizeof(struct sockaddr));
#endif

#ifdef SIOCGIFSTATS
  strcpy(ifr.ifr_name, ifname);
  ifr.ifr_data = (caddr_t) &ife->stats;
  if (ioctl(sock, SIOCGIFSTATS, &ifr) < 0) {
	memset(&ife->stats, 0, sizeof(struct dev_stats));
  }
#endif

  }
#endif

  return(0);
}


static void if_print(char *ifname)
{
  char buff[1024];
  struct interface ife;
  struct ifconf ifc;
  struct ifreq *ifr;
  int i;

  if (ifname == (char *)NULL) {
	ifc.ifc_len = sizeof(buff);
	ifc.ifc_buf = buff;
	if (ioctl(sock, SIOCGIFCONF, &ifc) < 0) {
		fprintf(stderr, "SIOCGIFCONF: %s\n", strerror(errno));
		return;
	}

	ifr = ifc.ifc_req;
	for (i = ifc.ifc_len / sizeof(struct ifreq); --i >= 0; ifr++) {
		if (if_fetch(ifr->ifr_name, &ife) < 0) {
			fprintf(stderr, "%s: unknown interface.\n",
							ifr->ifr_name);
			continue;
		}

		if (((ife.flags & IFF_UP) == 0) && !opt_a) continue;
		ife_print(&ife);
	}
  } else {
	if (if_fetch(ifname, &ife) < 0)
		fprintf(stderr, "%s: unknown interface.\n", ifname);
	  else ife_print(&ife);
  }
}


/* Set a certain interface flag. */
static void set_flag(char *ifname, short flag)
{
  struct ifreq ifr;

  strcpy(ifr.ifr_name, ifname);
  if (ioctl(sock, SIOCGIFFLAGS, &ifr) < 0) {
	fprintf(stderr, "SIOCGIFFLAGS: %s\n", strerror(errno));
  }
  ifr.ifr_flags |= flag;
  if (ioctl(sock, SIOCSIFFLAGS, &ifr) < 0) {
	fprintf(stderr, "SIOCSIFFLAGS: %s\n", strerror(errno));
  }
}


/* Clear a certain interface flag. */
static void clr_flag(char *ifname, short flag)
{
  struct ifreq ifr;

  strcpy(ifr.ifr_name, ifname);
  if (ioctl(sock, SIOCGIFFLAGS, &ifr) < 0) {
	fprintf(stderr, "SIOCGIFFLAGS: %s\n", strerror(errno));
  }
  ifr.ifr_flags &= ~flag;
  if (ioctl(sock, SIOCSIFFLAGS, &ifr) < 0) {
	fprintf(stderr, "SIOCSIFFLAGS: %s\n", strerror(errno));
  }
}


static void usage()
{
  fprintf(stderr, "Usage: ");
  fprintf(stderr,
	"ifconfig [-aiv] interface [inet] [ address | metric NN | mtu NN |\n");
  fprintf(stderr, "       ");
  fprintf(stderr,
	"arp | -arp | trailers | -trailers | broadcast aa.bb.cc.dd |\n");
  fprintf(stderr, "       ");
  fprintf(stderr,
	"dstaddr aa.bb.cc.dd | netmask aa.bb.cc.dd |\n");
  fprintf(stderr, "       ");
  fprintf(stderr,
	"pointopoint aa.bb.cc.dd | up | down ... ] \n");
  exit(-1);
}


void main(argc, argv)
int argc;
char *argv[];
{
  struct addrtyp *ap;
  struct ifreq ifr;
  struct in_addr in;
  char **spp;
  char *sp;

  /* Create a channel to the NET kernel. */
  if ((sock = open(_PATH_DEV_SOCKET, O_RDWR)) < 0) {
	perror(_PATH_DEV_SOCKET);
	exit(-1);
  }

  /* Find any options. */
  argc--;
  argv++;
  while (*argv[0] == '-') {
	if (!strcmp(*argv, "-a")) opt_a = 1;
	if (!strcmp(*argv, "-v")) opt_v = 1;
	argv++;
	argc--;
  }

  /* Do we have to show the current setup? */
  if (argc == 0) {
	if_print((char *)NULL);
	(void) close(sock);
	exit(0);
  }

  /* No. Fetch the interface name. */
  spp = argv;
  strncpy(ifr.ifr_name, *spp++, IFNAMSIZ);
  if (*spp == (char *)NULL) {
	if_print(ifr.ifr_name);
	(void) close(sock);
	exit(0);
  }

  /* The next argument is either an address family name, or an option. */
  if ((ap = get_afname(*spp)) == NULL) {
	ap = get_afname("inet");
  } else spp++;
  addr_family = ap->af;

  /* Process the remaining arguments. */
  while (*spp != (char *)NULL) {
#ifdef SIOCSIFMETRIC
	if (!strcmp(*spp, "metric")) {
		sp = *++spp;
		if (sp == NULL) usage();
		spp++;
		ifr.ifr_metric = atoi(sp);
		if (ioctl(sock, SIOCSIFMETRIC, &ifr) < 0) {
			fprintf(stderr, "SIOCSIFMETRIC: %s\n", strerror(errno));
		}
		continue;
	}
#endif

#ifdef SIOCSIFMTU
	if (!strcmp(*spp, "mtu")) {
		sp = *++spp;
		if (sp == NULL) usage();
		spp++;
		ifr.ifr_mtu = atoi(sp);
		if (ioctl(sock, SIOCSIFMTU, &ifr) < 0) {
			fprintf(stderr, "SIOCSIFMTU: %s\n", strerror(errno));
		}
		continue;
	}
#endif

#ifdef SIOCSIFBRDADDR
	if (!strcmp(*spp, "broadcast")) {
		sp = *++spp;
		if (sp == NULL) usage();
		spp++;
		if (resolve(sp, &in) < 0) {
			herror(sp);
			continue;
		}
		ifr.ifr_broadaddr.sa_family = addr_family;
		(*(struct sockaddr_in *) &ifr.ifr_broadaddr).sin_addr = in;
		if (ioctl(sock, SIOCSIFBRDADDR, &ifr) < 0) {
			fprintf(stderr, "SIOCSIFBRDADDR: %s\n",
						strerror(errno));
		}
		set_flag(ifr.ifr_name, IFF_BROADCAST);
		continue;
	}
#endif

#ifdef SIOCSIFDSTADDR
	if (!strcmp(*spp, "dstaddr")) {
		sp = *++spp;
		if (sp == NULL) usage();
		spp++;
		if (resolve(sp, &in) < 0) {
			herror(sp);
			continue;
		}
		ifr.ifr_dstaddr.sa_family = addr_family;
		(*(struct sockaddr_in *) &ifr.ifr_dstaddr).sin_addr = in;
		if (ioctl(sock, SIOCSIFDSTADDR, &ifr) < 0) {
			fprintf(stderr, "SIOCSIFDSTADDR: %s\n",
							strerror(errno));
		}
		continue;
	}
#endif

#ifdef SIOCSIFNETMASK
	if (!strcmp(*spp, "netmask")) {
		sp = *++spp;
		if (sp == NULL) usage();
		spp++;
		if (resolve(sp, &in) < 0) {
			herror(sp);
			continue;
		}
		ifr.ifr_netmask.sa_family = addr_family;
		(*(struct sockaddr_in *) &ifr.ifr_netmask).sin_addr = in;
		if (ioctl(sock, SIOCSIFNETMASK, &ifr) < 0) {
			fprintf(stderr, "SIOCSIFNETMASK: %s\n",
						strerror(errno));
		}
		continue;
	}
#endif

#ifdef IFF_NOARP
	if (!strcmp(*spp, "arp")) {
		spp++;
		clr_flag(ifr.ifr_name, IFF_NOARP);
		continue;
	}
	if (!strcmp(*spp, "-arp")) {
		spp++;
		set_flag(ifr.ifr_name, IFF_NOARP);
		continue;
	}
#endif

#ifdef IFF_NOTRAILERS
	if (!strcmp(*spp, "trailers")) {
		spp++;
		clr_flag(ifr.ifr_name, IFF_NOTRAILERS);
		continue;
	}

	if (!strcmp(*spp, "-trailers")) {
		spp++;
		set_flag(ifr.ifr_name, IFF_NOTRAILERS);
		continue;
	}
#endif

#ifdef IFF_PROMISC
	if (!strcmp(*spp, "promisc")) {
		spp++;
		set_flag(ifr.ifr_name, IFF_PROMISC);
		continue;
	}

	if (!strcmp(*spp, "-promisc")) {
		spp++;
		clr_flag(ifr.ifr_name, IFF_PROMISC);
		continue;
	}
#endif

#ifdef IFF_ALLMULTI
	if (!strcmp(*spp, "allmulti")) {
		spp++;
		set_flag(ifr.ifr_name, IFF_ALLMULTI);
		continue;
	}

	if (!strcmp(*spp, "-allmulti")) {
		spp++;
		clr_flag(ifr.ifr_name, IFF_ALLMULTI);
		continue;
	}
#endif

#ifdef IFF_UP
	if (!strcmp(*spp, "up")) {
		spp++;
		set_flag(ifr.ifr_name, (IFF_UP | IFF_RUNNING));
		continue;
	}

	if (!strcmp(*spp, "down")) {
		spp++;
		clr_flag(ifr.ifr_name, IFF_UP);
		continue;
	}
#endif

#ifdef IFF_POINTOPOINT
	if (!strcmp(*spp, "pointopoint")) {
		spp++;
		if (resolve(*spp, &in)) {
			herror(*spp);
			spp--;
			continue;
		};

		ifr.ifr_dstaddr.sa_family = addr_family;
		(*(struct sockaddr_in *) &ifr.ifr_dstaddr).sin_addr = in;
		ifr.ifr_dstaddr.sa_family = AF_INET;
		if (ioctl(sock, SIOCSIFDSTADDR, &ifr) < 0) {
			fprintf(stderr, "SIOCSIFDSTADDR: %s\n",
							strerror(errno));
		}
		set_flag(ifr.ifr_name, IFF_POINTOPOINT);
		spp++;
		continue;
	};
#endif

	/* If the next argument is a valid hostname, assume OK. */
	if (resolve(*spp, &in) < 0) usage();
	spp++;

	(*(struct sockaddr_in *) &ifr.ifr_addr).sin_addr = in;
	ifr.ifr_addr.sa_family = addr_family;
	if (ioctl(sock, SIOCSIFADDR, &ifr) < 0) {
		fprintf(stderr, "SIOCSIFADDR: %s\n", strerror(errno));
	}
	set_flag(ifr.ifr_name, (IFF_UP | IFF_RUNNING));
	continue;
  }

  /* Close the socket. */
  (void) close(sock);

  exit(0);
}
