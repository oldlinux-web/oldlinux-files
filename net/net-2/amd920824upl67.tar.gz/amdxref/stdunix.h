#ifndef __STDUNIX_H__
#define __STDUNIX_H__
/*
This software is provided as-is, with no warranties for suitability of
use or support implied.  This package makes no guarantees that it will
perform in any manner.  The authors and Texas A&M University accept no
liability for any damages incurred while using this software.

This software may be copied, redistributed, and updated in any
fashion as long as this comment header is not removed or altered.

Douglas Lee Schales
Doug.Schales@sc.tamu.edu
Texas A&M University
Supercomputer Center

01/26/1993
*/
/*
extern int fprintf(FILE *, char *, ...);
extern void perror(char *);
extern int fputs(char *, FILE *);
extern int fputc(int, FILE *);
extern void fflush(FILE *);
extern void fclose(FILE *);
*/
#endif
