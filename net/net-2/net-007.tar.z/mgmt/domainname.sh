#! /bin/sh

#
# Set/Change the current domainname.
#

  if [ -f /etc/HOSTNAME ]
  then
	name="`cat /etc/HOSTNAME`"
  else
	name="none"
  fi

  echo -n "Enter new hostname [${name}]: "
  read ans
  if [ -n "${ans}" ]
  then
	name="${ans}"
	rm -f /etc/HOSTNAME
	echo ${name} >/etc/HOSTNAME
	chown bin.bin /etc/HOSTNAME
	chmod 644 /etc/HOSTNAME
	echo "Hostname changed to \"${name}\""
  else
	echo "Hostname not changed."
  fi
