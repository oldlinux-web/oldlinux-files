#! /bin/sh

BIN=/usr/bin

  echo "Welcome to the LINUX/Pro NET-2 Installation."
  echo
  echo "This procedure will try to help you install the NET-2 networking"
  echo "package on your system, and to configure it.  Not all of this work"
  echo "can be automated, but many of the dull things can be..."
  echo

  echo -n "Enter \"bin\" directory name [${BIN}]: "
  read ans
  if [ -n "${ans}" ]; then BIN="${ans}"; fi

  echo
  echo -n "Enter the name of this host (without domain): "
  read ans
  if [ ! -n "${ans}" ]
  then
	echo "You must supply a host name.  Aborting installation!"
	exit 1
  fi
  HOST="${ans}"

  echo
  echo -n "Enter the domainname of this host: "
  read ans
  if [ ! -n "${ans}" ]
  then
	echo "You must supply a domain name.  Aborting installation!"
	exit 1
  fi
  DOMAIN="${ans}"

  exit 0
