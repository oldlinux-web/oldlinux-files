int _check_rhosts_file;
