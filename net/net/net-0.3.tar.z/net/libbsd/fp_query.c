#include <stdio.h>

void fp_query(void)
{
	fprintf(stderr, "fp_query not implemented\n");
}

