#ifndef _BSD_UNISTD_H
#define _BSD_UNISTD_H

#include_next <unistd.h>
#include <sys/time.h>
#include <sys/file.h>

#undef setpgrp
#define setpgrp setpgid

#endif /* _BSD_UNISTD_H */
