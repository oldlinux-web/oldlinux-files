#ifndef _BSD_SYS_A_OUT_H
#define _BSD_SYS_A_OUT_H

#define __STRUCT_EXEC_OVERRIDE__

struct exec
{
  unsigned int a_magic;
  unsigned char a_machtype;
  unsigned char a_flags;
  unsigned a_text;
  unsigned a_data;
  unsigned a_bss;
  unsigned a_syms;
  unsigned a_entry;
  unsigned a_trsize;
  unsigned a_drsize;
};

#include_next <a.out.h>

#define A_MAGIC1 OMAGIC
#define A_MAGIC2 NMAGIC
#define A_MAGIC3 ZMAGIC
#define A_MAGIC4 CMAGIC

#include <ar.h>

#undef ARMAG
#define ARMAG 0177545

#endif /* _BSD_SYS_A_OUT_H */
