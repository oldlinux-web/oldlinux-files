#ifndef _BSD_SYS_DIR_H
#define _BSD_SYS_DIR_H

#include_next <sys/dir.h>

/* gloss over slight differences between BSD direct and Linux direct */
  
#define d_namlen	d_reclen

#endif /* _BSD_SYS_DIR_H */
