#ifndef _BSD_MSGBUF_H
#define _BSD_MSGBUF_H

#define MSG_BSIZE	1024

#endif /* _BSD_MSGBUF_H */
