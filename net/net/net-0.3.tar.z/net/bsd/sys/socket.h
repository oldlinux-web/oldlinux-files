#ifndef _BSD_SYS_SOCKET_H
#define _BSD_SYS_SOCKET_H

#include_next <sys/socket.h>

#define osockaddr	sockaddr

#define MSG_EOR		3

#endif /* _BSD_SYS_SOCKET_H */
