#ifndef _BSD_SYS_PARAM_H
#define _BSD_SYS_PARAM_H

#include_next <sys/param.h>
#include <sys/types.h>		/* does this go here or in sys/socket.h? */

/* some BSD progs expect MIN and MAX to be defined */

#define MIN(a, b)	((a) < (b) ? (a) : (b))
#define MAX(a, b)	((a) > (b) ? (a) : (b))

/* bits per byte */

#define NBBY		8

/* POSIX version of maximum number of characters in an argument list */

#define NCARGS		ARG_MAX

/* some BSD net code uses these definitions for byte-order dependencies */

#define BYTE_ORDER	1234
#define LITTLE_ENDIAN	1234

#endif /* _BSD_SYS_PARAM_H */
