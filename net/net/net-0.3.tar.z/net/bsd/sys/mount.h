#ifndef _BSD_SYS_MOUNT_H
#define _BSD_SYS_MOUNT_H

#include_next <sys/mount.h>
#include <sys/vfs.h>

#define f_fsize f_bsize

#endif /* _BSD_SYS_MOUNT_H */
