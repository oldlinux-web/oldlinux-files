#ifndef _BSD_FEATURES_H
#define _BSD_FEATURES_H

#ifndef _BSD_SOURCE
#define _BSD_SOURCE
#endif

#include_next <features.h>

#endif /* _BSD_FEATURES_H */
