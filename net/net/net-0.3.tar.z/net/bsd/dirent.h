#ifndef _BSD_DIRENT_H
#define _BSD_DIRENT_H

#include_next <dirent.h>

/* gloss over slight differences between BSD dirent and Linux dirent */
  
#define d_namlen	d_reclen

#endif /* _BSD_DIRENT_H */
