#ifndef _BSD_CURSES_H
#define _BSD_CURSES_H

#include_next <curses.h>

#include <sgtty.h>

#endif /* _BSD_CURSES_H */
