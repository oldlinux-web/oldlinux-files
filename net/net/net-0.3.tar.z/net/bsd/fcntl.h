#ifndef _BSD_FCNTL_H
#define _BSD_FCNTL_H

#include_next <fcntl.h>

/* BSD has slight non-POSIX names (and meanings :-) for some things */

#define FAPPEND		O_APPEND 

#endif /* _BSD_FCNTL_H */
