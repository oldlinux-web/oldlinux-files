#ifdef __linux__
#error "linux is defined"
#endif
