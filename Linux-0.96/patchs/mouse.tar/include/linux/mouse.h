/* kernel/include/linux/mouse.h */
/*	mouse.h:	header file for Logitech Bus Mouse driver	*/
 
#ifndef _MOUSE_H
#define _MOUSE_H
 
 
#define	MSE_DATA_PORT		0x23c	/*	1100		*/
#define	MSE_SIGNATURE_PORT	0x23d	/*	1101		*/
#define	MSE_CONTROL_PORT	0x23e	/*	1110		*/
#define MSE_INTERRUPT_PORT	0x23e
#define	MSE_CONFIG_PORT		0x23f	/*	1111		*/
 
#define	MSE_ENABLE_INTERRUPTS	0x01	/*	0000 0000	*/
#define	MSE_DISABLE_INTERRUPTS	0x10	/*	0001 0000	*/
 
#define	MSE_READ_X_LOW		0x80	/*	1000 0000	*/
#define	MSE_READ_X_HIGH		0xa0	/*	1010 0000	*/
#define	MSE_READ_Y_LOW		0xc0	/*	1100 0000	*/
#define	MSE_READ_Y_HIGH		0xe0	/*	1110 0000	*/
 
#define MSE_IRQ5		0x01
#define MSE_IRQ4		0x02
#define MSE_IRQ3		0x04
#define MSE_IRQ2		0x08
 
/* Magic number used to check if the mouse exists */
#define MSE_CONFIG_BYTE	0x91
 

extern void mouse_init();

#endif
