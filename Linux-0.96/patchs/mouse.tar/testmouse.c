#include <stdio.h>

void
main()
{
  FILE *mouse;
  short int a, b, c, d;
  int x, y;

  x = 0; y = 0;
  mouse = fopen("/dev/mouse", "r");
for(;;){
  a = (getc(mouse) % 8);
  b = getc(mouse);
  c = getc(mouse);
  d = getc(mouse);
  x += b > 127 ? b - 256 : b;
  y += c > 127 ? c - 256 : c;
  printf("Mouse buttons = %2hd dX = %4hd dY = %4hd X = %6d Y = %6d count = %4hd\r", a, b, c, x, y, d);
  a = getc(mouse);
}
}
