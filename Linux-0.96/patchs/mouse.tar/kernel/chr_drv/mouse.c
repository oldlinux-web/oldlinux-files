/* linux/kernel/chr_drv/mouse.c */
/*
 *	Linux logitech bus mouse driver 
 *      adapted from various sources by James Banks
 *
 *      modified by Peter Williams
 */
 
#include	<linux/kernel.h>
#include	<errno.h> 
#include	<asm/io.h>
#include	<asm/segment.h>
#include        <linux/fs.h>
#include	<linux/mouse.h>

#define FILLER 0x00
 
char mouse_present, mouse_active, mouse_count;
 
static int mouse_open(struct inode * inode, struct file * file)
{
	unsigned int minor = MINOR(inode->i_rdev);
 
	if ((minor != 0) || (mouse_present == 0))
		return -ENODEV;
	if (mouse_active = 0) {
		outb(MSE_ENABLE_INTERRUPTS, MSE_CONTROL_PORT);
		mouse_active = 1;
	};
        return 0;
}
 
static int mouse_read(struct inode * inode, struct file * file,char * buffer,int count)
{
	unsigned int minor = MINOR(inode->i_rdev);
	char deltax, deltay, buttons;
	unsigned int i;
 
	if ((minor != 0) || (mouse_present == 0))
		return -ENODEV;
	if (mouse_active = 0) {
		outb(MSE_ENABLE_INTERRUPTS, MSE_CONTROL_PORT);
		mouse_active = 1;
	}
	outb(MSE_DISABLE_INTERRUPTS, MSE_CONTROL_PORT);
 
	outb(MSE_READ_X_LOW, MSE_CONTROL_PORT);
	deltax = inb(MSE_DATA_PORT) & 0xf;
	outb(MSE_READ_X_HIGH, MSE_CONTROL_PORT);
	deltax |= (inb(MSE_DATA_PORT) & 0xf) << 4;
	outb(MSE_READ_Y_LOW, MSE_CONTROL_PORT );
	deltay = inb(MSE_DATA_PORT) & 0xf;
	outb(MSE_READ_Y_HIGH, MSE_CONTROL_PORT);
	i = inb(MSE_DATA_PORT);
	deltay |= (i & 0xf) << 4;
	deltay = -deltay;
	buttons = ((i >> 5) & 0x07) | 0x80;
 
	if (deltax == -128)  deltax = -127;
	if (deltay == -128)  deltay = -127;
 
	put_fs_byte(buttons, buffer);
	put_fs_byte(deltax, buffer + 1);
	put_fs_byte(deltay, buffer + 2);
	put_fs_byte(mouse_count, buffer + 3);
	put_fs_byte(FILLER, buffer + 4);
	
	outb(MSE_ENABLE_INTERRUPTS, MSE_CONTROL_PORT);
	return 5;
 
}

int mouse_write(struct inode * inode, struct file * file,char * buffer,unsigned int count)
{
  return -EINVAL;
}
 
static struct file_operations mouse_fops = {
        NULL, /* mouse_seek */
        mouse_read,
        NULL, /* mouse_write */
        NULL, /* mouse_readdir */
        NULL, /* mouse_select */
        NULL, /* mouse_ioctl */
        mouse_open,
        NULL /* mouse_release */
};
 
void mouse_init()
{	
	int i;

        chrdev_fops[10] = &mouse_fops;
 
/* Is mouse there? */
	outb(MSE_CONFIG_BYTE, MSE_CONFIG_PORT);
	outb(0xa5, MSE_SIGNATURE_PORT);
	for (i = 0; i < 100000; i++); /* busy loop */
	if (inb(MSE_SIGNATURE_PORT) != 0xa5) {
		printk("mouse_init: No Logitech Bus Mouse found  %x\n", inb(MSE_SIGNATURE_PORT));
		mouse_present = 0;
		return;
	}
/* Initailize registers	*/
	outb(MSE_DISABLE_INTERRUPTS, MSE_CONTROL_PORT); 
	mouse_present = 1;
	mouse_active = 0;
/* Say hello world */
	printk("Logitech Bus Mouse: %x-%x %x\n",
		MSE_DATA_PORT, MSE_CONTROL_PORT, inb(MSE_SIGNATURE_PORT));
}

