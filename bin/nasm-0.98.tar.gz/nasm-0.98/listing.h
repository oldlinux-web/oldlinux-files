/* listing.h   header file for listing.c
 *
 * The Netwide Assembler is copyright (C) 1996 Simon Tatham and
 * Julian Hall. All rights reserved. The software is
 * redistributable under the licence given in the file "Licence"
 * distributed in the NASM archive.
 */

#ifndef NASM_LISTING_H
#define NASM_LISTING_H

extern ListGen nasmlist;

#endif
