#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main(int argc, char *argv[])
{
	int i;

	if (! --argc) {
		printf("Randomize the arguments.\nUsage: %s args\n", argv[0]);
		return 1;
	}
	srand(time(NULL));
	while (argc) {
		i = 1 + random() % argc;
		printf("%s ", argv[i]);
		argv[i] = argv[argc--];
	}
	putchar('\n');
	return 0;
}
