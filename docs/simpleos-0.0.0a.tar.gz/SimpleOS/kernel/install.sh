#!/bin/sh

# Build and install script for the Kernel, now works with ELF binaries so we
# can split the source into multiple modes

# Clean Up
rm -f *.o
rm -f kernel.bin

# Assemble
nasm -f elf -o entry.o entry.asm
nasm -f elf -o int.o int.asm
nasm -f elf -o task.o task.asm
nasm -f elf -o speaker.o speaker.asm
nasm -f elf -o timer.o timer.asm

# Link
ld entry.o int.o task.o speaker.o timer.o  -o kernel.bin -oformat binary -Ttext 0x10000 -e _start32

# Install
dd if=./kernel.bin of=/dev/fd0 bs=512 count=15 seek=1


