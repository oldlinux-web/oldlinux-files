

The file ELF11G.ZIP decompresses into the ELF.HPS and README.TXT 

ELF.HPS is a postscript file which contains the Executable and Linkable
Format Specification, V1.1.

The ELF Specification is one chapter of the Portable Formats Specification
Version 1.1.

To print a copy of the ELF document, copy the file to your postscript 
printer.  This files has been formatted in Hewlett-Packard postscript 
format and has been tested on an HPIIISi postscript printer.  (If you have 
problems printing, the first line of the file can be altered/deleted for 
your specific printer.) 

The TIS Committe grants you a non-exclusive, worldwide, royalty-free
license to use the information disclosed in the Specification to make your 
software TIS-compliant; no other license, express or implied, is granted or
intended hereby.

The TIS Committee make no warranty for the use of this standard, and reserves
the right to make changes to this specification at any time without notice.

All brands and product names are trademarks or registered trademarks of their 
respective holders.
