#!/bin/bash

rm -f boot
nasm boot.asm
dd if=./boot of=/dev/fd0 bs=512 count=1