#include "tm-convex2.h"

#undef LINK_SPEC
#undef STARTFILE_SPEC
#undef CPP_SPEC
#undef LIB_SPEC
