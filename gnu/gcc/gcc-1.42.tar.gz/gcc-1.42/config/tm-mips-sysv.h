#define MIPS_SYSV

#include "tm-mips.h"

#define TARGET_MEM_FUNCTIONS
