/* Define target machine as an ISI 68000/68020 with no 68881.  */

#define TARGET_DEFAULT 5

#include "tm-isi68.h"
