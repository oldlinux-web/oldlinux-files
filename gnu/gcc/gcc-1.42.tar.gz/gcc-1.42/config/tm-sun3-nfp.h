/* Define target machine as a Sun 3 with no 68881.  */

#define TARGET_DEFAULT 5

#include "tm-sun3.h"
