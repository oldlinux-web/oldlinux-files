#define VERSION	"2.0.7"
#define DATE	"6 Sep 92"
