const char *major_version = "1";
const char *minor_version = "06";
