const char *version_string = "1.06";
