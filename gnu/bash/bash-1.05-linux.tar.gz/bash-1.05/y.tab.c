
/*  A Bison parser, made from parse.y  */

#define	IF	258
#define	THEN	259
#define	ELSE	260
#define	ELIF	261
#define	FI	262
#define	CASE	263
#define	ESAC	264
#define	FOR	265
#define	WHILE	266
#define	UNTIL	267
#define	DO	268
#define	DONE	269
#define	FUNCTION	270
#define	IN	271
#define	WORD	272
#define	NUMBER	273
#define	AND_AND	274
#define	OR_OR	275
#define	GREATER_GREATER	276
#define	LESS_LESS	277
#define	LESS_AND	278
#define	GREATER_AND	279
#define	SEMI_SEMI	280
#define	LESS_LESS_MINUS	281
#define	AND_GREATER	282
#define	DOUBLE_OPEN	283
#define	DOUBLE_CLOSE	284
#define	yacc_EOF	285

#line 21 "parse.y"

#include <stdio.h>
#include <signal.h>
#include "shell.h"
#include "flags.h"

#ifdef READLINE
#include <readline/readline.h>
#include <readline/history.h>
#endif

#define YYDEBUG 1
extern int eof_encountered;
extern int no_line_editing;
extern int interactive;

#line 38 "parse.y"
typedef union {
  WORD_DESC *word;		/* the word that we read. */
  int number;			/* the number that we read. */
  WORD_LIST *word_list;
  COMMAND *command;
  REDIRECT *redirect;
  ELEMENT element;
  PATTERN_LIST *pattern;
} YYSTYPE;

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#include <stdio.h>

#ifndef __STDC__
#define const
#endif



#define	YYFINAL		201
#define	YYFLAG		-32768
#define	YYNTBASE	42

#define YYTRANSLATE(x) ((unsigned)(x) <= 285 ? yytranslate[x] : 64)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,    32,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,    30,     2,    40,
    41,     2,     2,     2,    37,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,    31,    36,
     2,    35,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    38,    34,    39,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    33
};

static const short yyprhs[] = {     0,
     0,     3,     5,     8,    10,    11,    14,    17,    20,    24,
    28,    31,    35,    38,    42,    45,    49,    52,    56,    59,
    63,    66,    70,    73,    77,    80,    83,    85,    87,    89,
    92,    94,    97,    99,   101,   104,   111,   119,   127,   138,
   149,   156,   164,   171,   177,   185,   192,   198,   204,   208,
   210,   216,   223,   229,   233,   237,   242,   249,   255,   257,
   260,   265,   270,   272,   275,   281,   287,   289,   293,   296,
   298,   302,   306,   310,   315,   320,   325,   330,   335,   340,
   342,   344,   346,   348,   349,   352,   354,   357,   360,   365,
   370,   374,   378,   383
};

static const short yyrhs[] = {    62,
    32,     0,    32,     0,     1,    32,     0,    33,     0,     0,
    43,    17,     0,    35,    17,     0,    36,    17,     0,    18,
    35,    17,     0,    18,    36,    17,     0,    21,    17,     0,
    18,    21,    17,     0,    22,    17,     0,    18,    22,    17,
     0,    23,    18,     0,    18,    23,    18,     0,    24,    18,
     0,    18,    24,    18,     0,    26,    17,     0,    18,    26,
    17,     0,    24,    37,     0,    18,    24,    37,     0,    23,
    37,     0,    18,    23,    37,     0,    27,    17,     0,    24,
    17,     0,    17,     0,    44,     0,    44,     0,    46,    44,
     0,    45,     0,    47,    45,     0,    47,     0,    49,     0,
    49,    46,     0,    10,    17,    61,    13,    57,    14,     0,
    10,    17,    31,    61,    13,    57,    14,     0,    10,    17,
    31,    61,    38,    57,    39,     0,    10,    17,    61,    16,
    43,    60,    61,    13,    57,    14,     0,    10,    17,    61,
    16,    43,    60,    61,    38,    57,    39,     0,     8,    17,
    61,    16,    61,     9,     0,     8,    17,    61,    16,    54,
    61,     9,     0,     8,    17,    61,    16,    52,     9,     0,
     3,    57,     4,    57,     7,     0,     3,    57,     4,    57,
     5,    57,     7,     0,     3,    57,     4,    57,    51,     7,
     0,    11,    57,    13,    57,    14,     0,    12,    57,    13,
    57,    14,     0,    40,    57,    41,     0,    50,     0,    17,
    40,    41,    61,    50,     0,    15,    17,    40,    41,    61,
    50,     0,    15,    17,    32,    61,    50,     0,    15,    17,
    50,     0,    38,    57,    39,     0,     6,    57,     4,    57,
     0,     6,    57,     4,    57,     5,    57,     0,     6,    57,
     4,    57,    51,     0,    53,     0,    54,    53,     0,    61,
    56,    41,    57,     0,    61,    56,    41,    61,     0,    55,
     0,    54,    55,     0,    61,    56,    41,    57,    25,     0,
    61,    56,    41,    61,    25,     0,    17,     0,    56,    34,
    17,     0,    61,    58,     0,    59,     0,    59,    32,    61,
     0,    59,    30,    61,     0,    59,    31,    61,     0,    59,
    19,    61,    59,     0,    59,    20,    61,    59,     0,    59,
    30,    61,    59,     0,    59,    31,    61,    59,     0,    59,
    32,    61,    59,     0,    59,    34,    61,    59,     0,    48,
     0,    32,     0,    31,     0,    33,     0,     0,    61,    32,
     0,    63,     0,    63,    30,     0,    63,    31,     0,    63,
    19,    61,    63,     0,    63,    20,    61,    63,     0,    63,
    30,    63,     0,    63,    31,    63,     0,    63,    34,    61,
    63,     0,    48,     0
};

#if YYDEBUG != 0
static const short yyrline[] = { 0,
    77,    86,    93,   105,   116,   118,   122,   124,   126,   128,
   130,   132,   134,   136,   138,   140,   142,   144,   146,   148,
   150,   153,   155,   157,   159,   161,   165,   167,   171,   172,
   176,   178,   182,   184,   187,   191,   193,   195,   197,   199,
   202,   204,   206,   210,   212,   214,   217,   219,   222,   225,
   228,   231,   234,   237,   241,   245,   247,   249,   254,   255,
   259,   261,   265,   267,   271,   273,   277,   279,   288,   292,
   293,   294,   296,   300,   302,   304,   306,   308,   310,   312,
   316,   317,   318,   321,   322,   331,   332,   334,   337,   339,
   341,   343,   345,   347
};

static const char * const yytname[] = {   "$",
"error","$illegal.","IF","THEN","ELSE","ELIF","FI","CASE","ESAC","FOR",
"WHILE","UNTIL","DO","DONE","FUNCTION","IN","WORD","NUMBER","AND_AND","OR_OR",
"GREATER_GREATER","LESS_LESS","LESS_AND","GREATER_AND","SEMI_SEMI","LESS_LESS_MINUS","AND_GREATER","DOUBLE_OPEN","DOUBLE_CLOSE","'&'",
"';'","'\\n'","yacc_EOF","'|'","'>'","'<'","'-'","'{'","'}'","'('",
"')'","inputunit","words","redirection","simple_command_element","redirections","simple_command","command","shell_command","group_command",
"elif_clause","case_clause_1","pattern_list_1","case_clause_sequence","pattern_list","pattern","list","list0","list1","list_terminator",
"newlines","simple_list","simple_list1",""
};
#endif

static const short yyr1[] = {     0,
    42,    42,    42,    42,    43,    43,    44,    44,    44,    44,
    44,    44,    44,    44,    44,    44,    44,    44,    44,    44,
    44,    44,    44,    44,    44,    44,    45,    45,    46,    46,
    47,    47,    48,    48,    48,    49,    49,    49,    49,    49,
    49,    49,    49,    49,    49,    49,    49,    49,    49,    49,
    49,    49,    49,    49,    50,    51,    51,    51,    52,    52,
    53,    53,    54,    54,    55,    55,    56,    56,    57,    58,
    58,    58,    58,    59,    59,    59,    59,    59,    59,    59,
    60,    60,    60,    61,    61,    62,    62,    62,    63,    63,
    63,    63,    63,    63
};

static const short yyr2[] = {     0,
     2,     1,     2,     1,     0,     2,     2,     2,     3,     3,
     2,     3,     2,     3,     2,     3,     2,     3,     2,     3,
     2,     3,     2,     3,     2,     2,     1,     1,     1,     2,
     1,     2,     1,     1,     2,     6,     7,     7,    10,    10,
     6,     7,     6,     5,     7,     6,     5,     5,     3,     1,
     5,     6,     5,     3,     3,     4,     6,     5,     1,     2,
     4,     4,     1,     2,     5,     5,     1,     3,     2,     1,
     3,     3,     3,     4,     4,     4,     4,     4,     4,     1,
     1,     1,     1,     0,     2,     1,     2,     2,     4,     4,
     3,     3,     4,     1
};

static const short yydefact[] = {     0,
     0,    84,     0,     0,    84,    84,     0,    27,     0,     0,
     0,     0,     0,     0,     0,     2,     4,     0,     0,    84,
    84,    28,    31,    33,    94,    34,    50,     0,    86,     3,
     0,     0,    84,    84,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,    11,    13,    15,    23,    26,
    17,    21,    19,    25,     7,     8,     0,     0,    27,    32,
    29,    35,     1,    84,    84,    87,    88,    84,    84,    85,
    80,    69,    70,     0,    84,     0,    84,    84,    84,     0,
    54,    84,    12,    14,    16,    24,    18,    22,    20,     9,
    10,    55,    49,    30,     0,     0,    91,    92,     0,     0,
    84,    84,    84,    84,    84,    84,    84,     0,    84,     5,
     0,     0,     0,    84,     0,    89,    90,     0,     0,    93,
    84,    84,    44,     0,     0,     0,    72,    73,    71,     0,
     0,    59,    84,    63,     0,    84,    84,     0,     0,    47,
    48,    53,     0,    51,     0,     0,    46,    74,    75,    76,
    77,    78,    79,    43,    60,    64,     0,    41,    67,     0,
     0,     0,    36,     6,    82,    81,    83,    84,    52,    45,
    84,    84,    84,    84,    42,     0,    84,    37,    38,     0,
    56,     0,     0,     0,    68,    61,    62,    84,    84,    84,
    58,    65,    66,     0,     0,    57,    39,    40,     0,     0,
     0
};

static const short yydefgoto[] = {   199,
   139,    22,    23,    62,    24,    71,    26,    27,   124,   131,
   132,   133,   134,   160,    31,    72,    73,   168,    32,    28,
    97
};

static const short yypact[] = {   141,
   -14,-32768,    19,    33,-32768,-32768,    42,    20,   103,    76,
    85,     7,    14,    93,    95,-32768,-32768,    96,    97,-32768,
-32768,-32768,-32768,   265,-32768,   272,-32768,    56,    88,-32768,
    92,   210,-32768,    61,   102,   115,   -12,    89,   116,   117,
    16,    17,   118,   119,   120,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,   101,   107,-32768,-32768,
-32768,   272,-32768,-32768,-32768,   241,   241,-32768,-32768,-32768,
-32768,-32768,   283,    54,-32768,     1,-32768,-32768,-32768,   113,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,   210,   210,    71,    71,   210,    51,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,     8,-32768,-32768,
   129,   143,    -9,-32768,    -9,   121,   121,   241,   241,-32768,
-32768,-32768,-32768,   153,   210,   210,   210,   210,   210,   210,
   152,-32768,-32768,-32768,    10,-32768,-32768,   155,    30,-32768,
-32768,-32768,    -9,-32768,   163,   167,-32768,   144,   144,    75,
    75,    75,-32768,-32768,-32768,-32768,    13,-32768,-32768,    48,
   161,   147,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,   171,-32768,-32768,-32768,    11,
    79,   210,   210,   210,-32768,   168,   179,-32768,-32768,-32768,
-32768,-32768,-32768,   166,   156,-32768,-32768,-32768,   192,   198,
-32768
};

static const short yypgoto[] = {-32768,
-32768,   -23,   175,-32768,-32768,     2,-32768,   -32,    26,-32768,
    77,-32768,    83,-32768,    -5,-32768,  -117,-32768,   -27,-32768,
     4
};


#define	YYLAST		317


static const short yytable[] = {    35,
    36,    25,    61,    29,    81,    74,    76,   148,   149,   150,
   151,   152,   153,   109,    57,    58,   110,    30,   158,    79,
   136,   175,    70,   188,    48,    20,   159,    80,    20,   159,
    50,    51,    70,    85,    87,    33,    95,    96,    94,    70,
    99,    70,    70,    49,    70,   137,   164,   108,   189,    34,
    52,   113,    86,    88,   115,   121,   122,   123,    37,    38,
   165,   166,   167,   100,   150,   151,   152,    25,    25,   107,
    98,   111,   112,   125,   126,   127,   128,   129,   130,   135,
   142,   176,   144,   190,   122,    70,   143,    63,   177,    64,
    65,    75,    46,   101,   102,    69,    25,    25,   116,   117,
    25,    47,   120,   138,    68,   157,    64,    65,   106,    53,
   169,    54,    55,    56,    77,   145,   146,    66,    67,    25,
    25,    68,    98,    39,    40,    41,    42,    78,    43,    82,
   161,   162,    83,    84,    89,    90,    91,    44,    45,    92,
   180,     1,   140,     2,   182,   183,   184,    93,     3,   187,
     4,     5,     6,   114,    68,     7,   141,     8,     9,   147,
   154,    10,    11,    12,    13,   181,    14,    15,   163,   170,
   171,   186,    16,    17,   178,    18,    19,   106,    20,   197,
    21,     2,   194,   195,   196,   179,     3,   185,     4,     5,
     6,   200,   192,     7,   198,     8,     9,   201,    60,    10,
    11,    12,    13,   193,    14,    15,   191,     0,     0,   155,
    70,     0,     2,    18,    19,   156,    20,     3,    21,     4,
     5,     6,     0,     0,     7,     0,     8,     9,     0,     0,
    10,    11,    12,    13,     0,    14,    15,     0,     0,     0,
     0,    70,     0,     2,    18,    19,     0,    20,     3,    21,
     4,     5,     6,     0,     0,     7,     0,     8,     9,     0,
     0,    10,    11,    12,    13,     0,    14,    15,     0,     0,
     0,     0,     0,     0,     0,    18,    19,     0,    20,     0,
    21,    59,     9,     0,     0,    10,    11,    12,    13,     9,
    14,    15,    10,    11,    12,    13,     0,    14,    15,    18,
    19,   101,   102,     0,     0,     0,    18,    19,     0,     0,
     0,     0,   103,   104,   105,     0,   106
};

static const short yycheck[] = {     5,
     6,     0,    26,     0,    37,    33,    34,   125,   126,   127,
   128,   129,   130,    13,    20,    21,    16,    32,     9,    32,
    13,     9,    32,    13,    18,    38,    17,    40,    38,    17,
    17,    18,    32,    18,    18,    17,    64,    65,    62,    32,
    68,    32,    32,    37,    32,    38,    17,    75,    38,    17,
    37,    79,    37,    37,    82,     5,     6,     7,    17,    40,
    31,    32,    33,    69,   182,   183,   184,    66,    67,    16,
    67,    77,    78,   101,   102,   103,   104,   105,   106,   107,
   113,    34,   115,     5,     6,    32,   114,    32,    41,    19,
    20,    31,    17,    19,    20,     4,    95,    96,    95,    96,
    99,    17,    99,   109,    34,   133,    19,    20,    34,    17,
   143,    17,    17,    17,    13,   121,   122,    30,    31,   118,
   119,    34,   119,    21,    22,    23,    24,    13,    26,    41,
   136,   137,    17,    17,    17,    17,    17,    35,    36,    39,
   168,     1,    14,     3,   172,   173,   174,    41,     8,   177,
    10,    11,    12,    41,    34,    15,    14,    17,    18,     7,
     9,    21,    22,    23,    24,   171,    26,    27,    14,     7,
     4,   177,    32,    33,    14,    35,    36,    34,    38,    14,
    40,     3,   188,   189,   190,    39,     8,    17,    10,    11,
    12,     0,    25,    15,    39,    17,    18,     0,    24,    21,
    22,    23,    24,    25,    26,    27,   181,    -1,    -1,   133,
    32,    -1,     3,    35,    36,   133,    38,     8,    40,    10,
    11,    12,    -1,    -1,    15,    -1,    17,    18,    -1,    -1,
    21,    22,    23,    24,    -1,    26,    27,    -1,    -1,    -1,
    -1,    32,    -1,     3,    35,    36,    -1,    38,     8,    40,
    10,    11,    12,    -1,    -1,    15,    -1,    17,    18,    -1,
    -1,    21,    22,    23,    24,    -1,    26,    27,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    35,    36,    -1,    38,    -1,
    40,    17,    18,    -1,    -1,    21,    22,    23,    24,    18,
    26,    27,    21,    22,    23,    24,    -1,    26,    27,    35,
    36,    19,    20,    -1,    -1,    -1,    35,    36,    -1,    -1,
    -1,    -1,    30,    31,    32,    -1,    34
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/gnu/lib/bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* Not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__)
#include <alloca.h>
#else /* Not sparc */
#ifdef MSDOS
#include <malloc.h>
#endif /* MSDOS */
#endif /* Not sparc.  */
#endif /* Not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#define YYLEX		yylex(&yylval, &yylloc)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif

#line 160 "/usr/gnu/lib/bison.simple"
int
yyparse()
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/

#define YYPOPSTACK   (yyvsp--, yysp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yysp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
#ifdef YYLSP_NEEDED
		 &yyls1, size * sizeof (*yylsp),
#endif
		 &yystacksize);

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_bcopy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_bcopy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_bcopy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Next token is %d (%s)\n", yychar, yytname[yychar1]);
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

 /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symboles being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
#line 78 "parse.y"
{
			  /* Case of regular command.  Discard the error
			     safety net,and return the command just parsed. */
			  global_command = yyvsp[-1].command;
			  eof_encountered = 0;
			  discard_parser_constructs (0);
			  YYACCEPT;
			;
    break;}
case 2:
#line 87 "parse.y"
{
			  /* Case of regular command, but not a very
			     interesting one.  Return a NULL command. */
			  global_command = (COMMAND *)NULL;
			  YYACCEPT;
			;
    break;}
case 3:
#line 95 "parse.y"
{
			  /* Error during parsing.  Return NULL command. */
			  global_command = (COMMAND *)NULL;
			  eof_encountered = 0;
			  discard_parser_constructs (1);
			  if (interactive)
			    YYACCEPT;
			  else
			    YYABORT;
			;
    break;}
case 4:
#line 107 "parse.y"
{
			  /* Case of EOF seen by itself.  Do ignoreeof or 
			     not. */
			  global_command = (COMMAND *)NULL;
			  handle_eof_input_unit ();
			  YYACCEPT;
			;
    break;}
case 5:
#line 117 "parse.y"
{ yyval.word_list = NULL; ;
    break;}
case 6:
#line 119 "parse.y"
{ yyval.word_list = make_word_list (yyvsp[0].word, yyvsp[-1].word_list); ;
    break;}
case 7:
#line 123 "parse.y"
{ yyval.redirect = make_redirection ( 1, r_output_direction, yyvsp[0].word); ;
    break;}
case 8:
#line 125 "parse.y"
{ yyval.redirect = make_redirection ( 0, r_input_direction, yyvsp[0].word); ;
    break;}
case 9:
#line 127 "parse.y"
{ yyval.redirect = make_redirection (yyvsp[-2].number, r_output_direction, yyvsp[0].word); ;
    break;}
case 10:
#line 129 "parse.y"
{ yyval.redirect = make_redirection (yyvsp[-2].number, r_input_direction, yyvsp[0].word); ;
    break;}
case 11:
#line 131 "parse.y"
{ yyval.redirect = make_redirection ( 1, r_appending_to, yyvsp[0].word); ;
    break;}
case 12:
#line 133 "parse.y"
{ yyval.redirect = make_redirection (yyvsp[-2].number, r_appending_to, yyvsp[0].word); ;
    break;}
case 13:
#line 135 "parse.y"
{ yyval.redirect = make_redirection ( 0, r_reading_until, yyvsp[0].word); ;
    break;}
case 14:
#line 137 "parse.y"
{ yyval.redirect = make_redirection (yyvsp[-2].number, r_reading_until, yyvsp[0].word); ;
    break;}
case 15:
#line 139 "parse.y"
{ yyval.redirect = make_redirection ( 0, r_duplicating, yyvsp[0].number); ;
    break;}
case 16:
#line 141 "parse.y"
{ yyval.redirect = make_redirection (yyvsp[-2].number, r_duplicating, yyvsp[0].number); ;
    break;}
case 17:
#line 143 "parse.y"
{ yyval.redirect = make_redirection ( 1, r_duplicating, yyvsp[0].number); ;
    break;}
case 18:
#line 145 "parse.y"
{ yyval.redirect = make_redirection (yyvsp[-2].number, r_duplicating, yyvsp[0].number); ;
    break;}
case 19:
#line 147 "parse.y"
{ yyval.redirect = make_redirection ( 0, r_deblank_reading_until, yyvsp[0].word); ;
    break;}
case 20:
#line 149 "parse.y"
{ yyval.redirect = make_redirection (yyvsp[-2].number, r_deblank_reading_until, yyvsp[0].word); ;
    break;}
case 21:
#line 151 "parse.y"
{ yyval.redirect = make_redirection ( 1, r_close_this, 0); ;
    break;}
case 22:
#line 154 "parse.y"
{ yyval.redirect = make_redirection (yyvsp[-2].number, r_close_this, 0); ;
    break;}
case 23:
#line 156 "parse.y"
{ yyval.redirect = make_redirection ( 0, r_close_this, 0); ;
    break;}
case 24:
#line 158 "parse.y"
{ yyval.redirect = make_redirection (yyvsp[-2].number, r_close_this, 0); ;
    break;}
case 25:
#line 160 "parse.y"
{ yyval.redirect = make_redirection ( 1, r_err_and_out, yyvsp[0].word); ;
    break;}
case 26:
#line 162 "parse.y"
{ yyval.redirect = make_redirection ( 1, r_err_and_out, yyvsp[0].word); ;
    break;}
case 27:
#line 166 "parse.y"
{ yyval.element.word = yyvsp[0].word; yyval.element.redirect = 0; ;
    break;}
case 28:
#line 168 "parse.y"
{ yyval.element.redirect = yyvsp[0].redirect; yyval.element.word = 0; ;
    break;}
case 30:
#line 173 "parse.y"
{ yyvsp[-1].redirect->next = yyvsp[0].redirect; yyval.redirect = yyvsp[-1].redirect; ;
    break;}
case 31:
#line 177 "parse.y"
{ yyval.command = make_simple_command (yyvsp[0].element, NULL); ;
    break;}
case 32:
#line 179 "parse.y"
{ yyval.command = make_simple_command (yyvsp[0].element, yyvsp[-1].command); ;
    break;}
case 33:
#line 183 "parse.y"
{ yyval.command = clean_simple_command (yyvsp[0].command); ;
    break;}
case 34:
#line 185 "parse.y"
{ yyval.command = yyvsp[0].command; ;
    break;}
case 35:
#line 188 "parse.y"
{ yyval.command->redirects = yyvsp[0].redirect; yyval.command = yyvsp[-1].command; ;
    break;}
case 36:
#line 192 "parse.y"
{ yyval.command = make_for_command (yyvsp[-4].word, (WORD_LIST *)add_string_to_list ("$@", NULL), yyvsp[-1].command); ;
    break;}
case 37:
#line 194 "parse.y"
{ yyval.command = make_for_command (yyvsp[-5].word, (WORD_LIST *)add_string_to_list ("$@", NULL), yyvsp[-1].command); ;
    break;}
case 38:
#line 196 "parse.y"
{ yyval.command = make_for_command (yyvsp[-5].word, (WORD_LIST *)add_string_to_list ("$@", NULL), yyvsp[-1].command); ;
    break;}
case 39:
#line 198 "parse.y"
{ yyval.command = make_for_command (yyvsp[-8].word, (WORD_LIST *)reverse_list (yyvsp[-5].word_list), yyvsp[-1].command); ;
    break;}
case 40:
#line 200 "parse.y"
{ yyval.command = make_for_command (yyvsp[-8].word, (WORD_LIST *)reverse_list (yyvsp[-5].word_list), yyvsp[-1].command); ;
    break;}
case 41:
#line 203 "parse.y"
{ yyval.command = make_case_command (yyvsp[-4].word, NULL); ;
    break;}
case 42:
#line 205 "parse.y"
{ yyval.command = make_case_command (yyvsp[-5].word, yyvsp[-2].pattern); ;
    break;}
case 43:
#line 207 "parse.y"
{ report_syntax_error ("Inserted `;;'");
			  yyval.command = make_case_command (yyvsp[-4].word, yyvsp[-1].pattern); ;
    break;}
case 44:
#line 211 "parse.y"
{ yyval.command = make_if_command (yyvsp[-3].command, yyvsp[-1].command, NULL); ;
    break;}
case 45:
#line 213 "parse.y"
{ yyval.command = make_if_command (yyvsp[-5].command, yyvsp[-3].command, yyvsp[-1].command); ;
    break;}
case 46:
#line 215 "parse.y"
{ yyval.command = make_if_command (yyvsp[-4].command, yyvsp[-2].command, yyvsp[-1].command); ;
    break;}
case 47:
#line 218 "parse.y"
{ yyval.command = make_while_command (yyvsp[-3].command, yyvsp[-1].command); ;
    break;}
case 48:
#line 220 "parse.y"
{ yyval.command = make_until_command (yyvsp[-3].command, yyvsp[-1].command); ;
    break;}
case 49:
#line 223 "parse.y"
{ yyvsp[-1].command->subshell = 1; yyval.command = yyvsp[-1].command; ;
    break;}
case 50:
#line 226 "parse.y"
{ yyval.command = yyvsp[0].command; ;
    break;}
case 51:
#line 229 "parse.y"
{ yyval.command = make_function_def (yyvsp[-4].word, yyvsp[0].command); ;
    break;}
case 52:
#line 232 "parse.y"
{ yyval.command = make_function_def (yyvsp[-4].word, yyvsp[0].command); ;
    break;}
case 53:
#line 235 "parse.y"
{ yyval.command = make_function_def (yyvsp[-3].word, yyvsp[0].command); ;
    break;}
case 54:
#line 238 "parse.y"
{ yyval.command = make_function_def (yyvsp[-1].word, yyvsp[0].command); ;
    break;}
case 55:
#line 242 "parse.y"
{ yyval.command = make_group_command (yyvsp[-1].command); ;
    break;}
case 56:
#line 246 "parse.y"
{ yyval.command = make_if_command (yyvsp[-2].command, yyvsp[0].command, NULL); ;
    break;}
case 57:
#line 248 "parse.y"
{ yyval.command = make_if_command (yyvsp[-4].command, yyvsp[-2].command, yyvsp[0].command); ;
    break;}
case 58:
#line 250 "parse.y"
{ yyval.command = make_if_command (yyvsp[-3].command, yyvsp[-1].command, yyvsp[0].command); ;
    break;}
case 60:
#line 256 "parse.y"
{ yyvsp[0].pattern->next = yyvsp[-1].pattern; yyval.pattern = yyvsp[0].pattern; ;
    break;}
case 61:
#line 260 "parse.y"
{ yyval.pattern = make_pattern_list (yyvsp[-2].word_list, yyvsp[0].command); ;
    break;}
case 62:
#line 262 "parse.y"
{ yyval.pattern = make_pattern_list (yyvsp[-2].word_list, NULL); ;
    break;}
case 64:
#line 268 "parse.y"
{ yyvsp[0].pattern->next = yyvsp[-1].pattern; yyval.pattern = yyvsp[0].pattern; ;
    break;}
case 65:
#line 272 "parse.y"
{ yyval.pattern = make_pattern_list (yyvsp[-3].word_list, yyvsp[-1].command); ;
    break;}
case 66:
#line 274 "parse.y"
{ yyval.pattern = make_pattern_list (yyvsp[-3].word_list, NULL); ;
    break;}
case 67:
#line 278 "parse.y"
{ yyval.word_list = make_word_list (yyvsp[0].word, NULL); ;
    break;}
case 68:
#line 280 "parse.y"
{ yyval.word_list = make_word_list (yyvsp[0].word, yyvsp[-2].word_list); ;
    break;}
case 69:
#line 289 "parse.y"
{ yyval.command = yyvsp[0].command; ;
    break;}
case 72:
#line 295 "parse.y"
{ yyval.command = command_connect (yyvsp[-2].command, 0, '&'); ;
    break;}
case 74:
#line 301 "parse.y"
{ yyval.command = command_connect (yyvsp[-3].command, yyvsp[0].command, AND_AND); ;
    break;}
case 75:
#line 303 "parse.y"
{ yyval.command = command_connect (yyvsp[-3].command, yyvsp[0].command, OR_OR); ;
    break;}
case 76:
#line 305 "parse.y"
{ yyval.command = command_connect (yyvsp[-3].command, yyvsp[0].command, '&'); ;
    break;}
case 77:
#line 307 "parse.y"
{ yyval.command = command_connect (yyvsp[-3].command, yyvsp[0].command, ';'); ;
    break;}
case 78:
#line 309 "parse.y"
{ yyval.command = command_connect (yyvsp[-3].command, yyvsp[0].command, ';'); ;
    break;}
case 79:
#line 311 "parse.y"
{ yyval.command = command_connect (yyvsp[-3].command, yyvsp[0].command, '|'); ;
    break;}
case 87:
#line 333 "parse.y"
{ yyval.command = command_connect (yyvsp[-1].command, (COMMAND *)NULL, '&'); ;
    break;}
case 89:
#line 338 "parse.y"
{ yyval.command = command_connect (yyvsp[-3].command, yyvsp[0].command, AND_AND); ;
    break;}
case 90:
#line 340 "parse.y"
{ yyval.command = command_connect (yyvsp[-3].command, yyvsp[0].command, OR_OR); ;
    break;}
case 91:
#line 342 "parse.y"
{ yyval.command = command_connect (yyvsp[-2].command, yyvsp[0].command, '&'); ;
    break;}
case 92:
#line 344 "parse.y"
{ yyval.command = command_connect (yyvsp[-2].command, yyvsp[0].command, ';'); ;
    break;}
case 93:
#line 346 "parse.y"
{ yyval.command = command_connect (yyvsp[-3].command, yyvsp[0].command, '|'); ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 423 "/usr/gnu/lib/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  for (x = 0; x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) xmalloc(size + 15);
	  strcpy(msg, "parse error");

	  if (count < 5)
	    {
	      count = 0;
	      for (x = 0; x < (sizeof(yytname) / sizeof(char *)); x++)
		if (yycheck[x + yyn] == x)
		  {
		    strcat(msg, count == 0 ? ", expecting `" : " or `");
		    strcat(msg, yytname[x]);
		    strcat(msg, "'");
		    count++;
		  }
	    }
	  yyerror(msg);
	  free(msg);
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 349 "parse.y"


/* Initial size to allocate for tokens, and the
   amount to grow them by. */
#define TOKEN_DEFAULT_GROW_SIZE 512

/* The token currently being read. */
int current_token = 0;

/* The last read token, or NULL.  read_token () uses this for context
   checking. */
int last_read_token = 0;

/* The token read prior to last_read_token. */
int token_before_that = 0;

/* Global var is non-zero when end of file has been reached. */
int EOF_Reached = 0;

/* yy_getc () returns the next available character from input or EOF.
   yy_ungetc (c) makes `c' the next character to read.
   init_yy_io (get, unget), makes the function `get' the installed function
   for getting the next character, and makes `unget' the installed function
   for un-getting a character. */
return_EOF ()			/* does nothing good. */
{
  return (EOF);
}

/* Variables containing the current get and unget functions. */

/* Some stream `types'. */
#define st_stream 0
#define st_string 1

Function *get_yy_char = return_EOF;
Function *unget_yy_char = return_EOF;
int yy_input_type = st_stream;
FILE *yy_input_dev = (FILE *)NULL;

/* The current stream name.  In the case of a file, this is a filename. */
char *stream_name = (char *)NULL;

/* Function to set get_yy_char and unget_yy_char. */
init_yy_io (get_function, unget_function, type, location)
     Function *get_function, *unget_function;
     int type;
     FILE *location;
{
  get_yy_char = get_function;
  unget_yy_char = unget_function;
  yy_input_type = type;
  yy_input_dev = location;
}

/* Call this to get the next character of input. */
yy_getc ()
{
  return (*get_yy_char) ();
}

/* Call this to unget C.  That is, to make C the next character
   to be read. */
yy_ungetc (c)
{
  return (*unget_yy_char) (c);
}

/* **************************************************************** */
/*								    */
/*		  Let input be read from readline ().		    */
/*								    */
/* **************************************************************** */

#ifdef READLINE
char *current_readline_prompt = (char *)NULL;
char *current_readline_line = (char *)NULL;
int current_readline_line_index = 0;

static int readline_initialized_yet = 0;
yy_readline_get ()
{
  if (!current_readline_line)
    {
      char *readline ();
      SigHandler *old_sigint;
      extern sighandler throw_to_top_level ();
      
      if (!readline_initialized_yet)
	{
	  initialize_readline ();
	  readline_initialized_yet = 1;
	}

      old_sigint = (SigHandler *)signal (SIGINT, throw_to_top_level);
	  if (!current_readline_prompt)
	    current_readline_line = readline ("");
	  else
	    current_readline_line = readline (current_readline_prompt);
      signal (SIGINT, old_sigint);

      current_readline_line_index = 0;

      if (!current_readline_line)
	{
	  current_readline_line_index = 0;
	  return (EOF);
	}

      current_readline_line =
	(char *)xrealloc (current_readline_line,
			  2 + strlen (current_readline_line));
      strcat (current_readline_line, "\n");
    }

  if (!current_readline_line[current_readline_line_index])
    {
      free (current_readline_line);
      current_readline_line = (char *)NULL;
      return (yy_readline_get ());
    }
  else
    {
      int c = current_readline_line[current_readline_line_index++];
      return (c);
    }
}

yy_readline_unget (c)
{
  if (current_readline_line_index && current_readline_line)
    current_readline_line[--current_readline_line_index] = c;
}
  
with_input_from_stdin ()
{
  init_yy_io (yy_readline_get, yy_readline_unget,
	      st_string, current_readline_line);
  stream_name = savestring ("readline stdin");
}

#else  /* READLINE */

with_input_from_stdin ()
{
  with_input_from_stream (stdin, "stdin");
}
#endif  /* READLINE */

/* **************************************************************** */
/*								    */
/*   Let input come from STRING.  STRING is zero terminated.	    */
/*								    */
/* **************************************************************** */

yy_string_get ()
{
  /* If the string doesn't exist, or is empty, EOF found. */
  if (!(char *)yy_input_dev || !*(char *)yy_input_dev)
    return (EOF);
  else {
    register char *temp = (char *)yy_input_dev;
    int c = *temp++;
    yy_input_dev = (FILE *)temp;
    return (c);
  }
}

yy_string_unget (c)
     int c;
{
  register char *temp = (char *)yy_input_dev;
  *(--temp) = c;
  yy_input_dev = (FILE *)temp;
  return (c);
}

with_input_from_string (string, name)
     char *string;
     char *name;
{
  init_yy_io (yy_string_get, yy_string_unget, st_string, string);
  stream_name = savestring (name);
}

/* **************************************************************** */
/*								    */
/*		     Let input come from STREAM.		    */
/*								    */
/* **************************************************************** */

yy_stream_get ()
{
  if (yy_input_dev)
#ifdef SYSV
    return (sysv_getc (yy_input_dev));
#else
    return (getc (yy_input_dev));
#endif  /* SYSV */
  else return (EOF);
}

yy_stream_unget (c)
     int c;
{
  ungetc (c, yy_input_dev);
}

with_input_from_stream (stream, name)
     FILE *stream;
     char *name;
{
  init_yy_io (yy_stream_get, yy_stream_unget, st_stream, stream);
  stream_name = savestring (name);
}

typedef struct stream_saver {
  struct stream_saver *next;
  Function *getter, *putter;
  int type, line;
  char *location, *name;
} STREAM_SAVER;

/* The globally known line number. */
int line_number = 0;

STREAM_SAVER *stream_list = (STREAM_SAVER *)NULL;

push_stream ()
{
  STREAM_SAVER *temp = (STREAM_SAVER *)xmalloc (sizeof (STREAM_SAVER));
  temp->type = yy_input_type;
  temp->location = (char *)yy_input_dev;
  temp->getter = get_yy_char;
  temp->putter = unget_yy_char;
  temp->line = line_number;
  temp->name = stream_name; stream_name = (char *)NULL;
  temp->next = stream_list;
  stream_list = temp;
  EOF_Reached = line_number = 0;
}

pop_stream ()
{
  if (!stream_list)
    {
      EOF_Reached = 1;
    }
  else
    {
      STREAM_SAVER *temp = stream_list;
    
      EOF_Reached = 0;
      stream_list = stream_list->next;

      if (stream_name)
	free (stream_name);
      stream_name = temp->name;

      init_yy_io (temp->getter, temp->putter, temp->type, temp->location);
      line_number = temp->line;
      free (temp);
    }
}


/* Return a line of text, taken from wherever yylex () reads input.
   If there is no more input, then we return NULL. */
char *
read_a_line ()
{
  char *line_buffer = (char *)NULL;
  int index = 0, buffer_size = 0;
  int c;

  while (c = yy_getc ())
    {
      /* If there is no more input, then we return NULL. */
      if (c == EOF)
	{
	  c = '\n';
	  if (!line_buffer)
	    return ((char *)NULL);
	}

      if (index + 1 > buffer_size)
	if (!buffer_size)
	  line_buffer = (char *)xmalloc (buffer_size = 200);
	else
	  line_buffer = (char *)xrealloc (line_buffer, buffer_size += 200);

      line_buffer[index++] = c;
      if (c == '\n')
	{
	  line_buffer[index] = '\0';
	  return (line_buffer);
	}
    }
}


/* Return a line as in read_a_line (), but insure that the prompt is
   the secondary prompt. */
char *
read_secondary_line ()
{
  char *decode_prompt_string ();
  char *temp_prompt = get_string_value ("PS2");

#ifdef READLINE
  if (!no_line_editing)
    {
      extern char *current_readline_prompt;

      if (current_readline_prompt)
	{
	  free (current_readline_prompt);
	  current_readline_prompt = (char *)NULL;
	}

      if (temp_prompt)
	current_readline_prompt = decode_prompt_string (temp_prompt);
      else
	current_readline_prompt = (savestring (""));
    }
  else
#endif  /* READLINE */
    {
      printf ("%s", temp_prompt ? temp_prompt : "");
      fflush (stdout);
    }

  return (read_a_line ());
}

/* **************************************************************** */
/*								    */
/*				YYLEX ()			    */
/*								    */
/* **************************************************************** */

/* Reserved words.  These are only recognized as the first word of a
   command.  TOKEN_WORD_ALIST. */
struct {
  char *word;
  int token;
} token_word_alist[] = {
  {"if", IF},
  {"then", THEN},
  {"else", ELSE},
  {"elif", ELIF},
  {"fi", FI},
  {"case", CASE},
  {"esac", ESAC},
  {"for", FOR},
  {"while", WHILE},
  {"until", UNTIL},
  {"do", DO},
  {"done", DONE},
  {"in", IN},
  {"function", FUNCTION},
  {"{", '{'},
  {"}", '}'},
  {(char *)NULL, 0}
};

/* Where shell input comes from.  For each line that we read, alias
   and history expansion are done. */
char *shell_input_line = (char *)NULL;
int shell_input_line_index = 0;
int shell_input_line_size = 0;

/* Either zero, or EOF. */
int shell_input_line_terminator = 0;

/* Return the next shell input character.  This always reads characters
   from shell_input_line; when that line is exhausted, it is time to
   read the next line. */
int
shell_getc (remove_quoted_newline)
     int remove_quoted_newline;
{
  extern int login_shell;
  int c;

  if (!shell_input_line || !shell_input_line[shell_input_line_index])
    {
      register int i, l;
      char *pre_process_line (), *expansions;

      restart_read_next_line:

      line_number++;

    restart_read:

      i = 0;
      shell_input_line_terminator = 0;

#ifdef JOB_CONTROL
      notify_and_cleanup ();
#endif

      clearerr (stdin);
      while (c = yy_getc ())
	{
	  if (i + 2 > shell_input_line_size)
	    if (!shell_input_line)
	      shell_input_line = (char *)xmalloc (shell_input_line_size = 256);
	    else
	      shell_input_line =
		(char *)xrealloc (shell_input_line, shell_input_line_size += 256);

	  if (c == EOF)
	    {
	      clearerr (stdin);

	      if (!i)
		shell_input_line_terminator = EOF;

	      shell_input_line[i] = '\0';
	      break;
	    }

	  shell_input_line[i++] = c;

	  if (c == '\n')
	    {
	      shell_input_line[--i] = '\0';
	      break;
	    }
	}
      shell_input_line_index = 0;

      if (!shell_input_line[0] || shell_input_line[0] == '#')
	goto after_pre_process;

      expansions = pre_process_line (shell_input_line, 1, 1);

      free (shell_input_line);
      shell_input_line = expansions;

      if (shell_input_line)
	{
	  if (echo_input_at_read)
	    fprintf (stderr, "%s\n", shell_input_line);

	  shell_input_line_size = strlen (expansions);

	}
      else
	{
	  shell_input_line_size = 0;
	  prompt_again ();
	  goto restart_read;
	}

    after_pre_process:
      /* Add the newline to the end of this string, iff the string does
	 not already end in an EOF character.  */
      if (shell_input_line_terminator != EOF)
	{
	  l = strlen (shell_input_line);

	  if (l + 3 > shell_input_line_size)
	    shell_input_line =
	      (char *)xrealloc (shell_input_line,
				1 + (shell_input_line_size += 2));
	  strcpy (shell_input_line + l, "\n");
	}
    }
  
  c = shell_input_line[shell_input_line_index];

  if (c)
    shell_input_line_index++;

  if (c == '\\' && remove_quoted_newline &&
      shell_input_line[shell_input_line_index] == '\n')
    {
      prompt_again ();
      goto restart_read_next_line;
    }

  if (!c && shell_input_line_terminator == EOF)
    {
      if (shell_input_line_index != 0)
	return ('\n');
      else
	return (EOF);
    }

  return (c);
}

/* Put C back into the input for the shell. */
shell_ungetc (c)
     int c;
{
  if (shell_input_line && shell_input_line_index)
    shell_input_line[--shell_input_line_index] = c;
}

/* Discard input until CHARACTER is seen. */
discard_until (character)
     int character;
{
  int c;
  while ((c = shell_getc (0)) != EOF && c != character)
    ;
  if (c != EOF )
    shell_ungetc (c);
}

/* Tell readline () that we have some text for it to edit. */
re_edit (text)
     char *text;
{
#ifdef READLINE
  if (strcmp (stream_name, "readline stdin") == 0)
    bash_re_edit (text);
#endif
}

/* Non-zero means do no history expansion on this line, regardless
   of what history_expansion says. */
int history_expansion_inhibited = 0;

/* Do pre-processing on LINE.  If PRINT_CHANGES is non-zero, then
   print the results of expanding the line if there were any changes.
   If there is an error, return NULL, otherwise the expanded line is
   returned.  If ADDIT is non-zero the line is added to the history
   list after history expansion, but before alias expansion.  ADDIT
   is just a suggestion; REMEMBER_ON_HISTORY can veto, and does.
   Right now this does history and alias expansion. */
char *
pre_process_line (line, print_changes, addit)
     char *line;
     int print_changes, addit;
{
  extern int history_expansion;
  extern int remember_on_history;
  int history_expand ();
  char *history_value;
  char *return_value = line;
  int expanded = 0;

#ifdef ALIAS
  char *alias_expand (), *alias_value;
#endif

  /* History expand the line.  If this results in no errors, then
     add that line to the history if ADDIT is non-zero. */
  if (!history_expansion_inhibited && history_expansion)
    {
      expanded = history_expand (line, &history_value);

      if (expanded)
	{
	  if (print_changes)
	    fprintf (stderr, "%s\n", history_value);

	  /* If there was an error, return NULL. */
	  if (expanded < 0)
	    {
	      free (history_value);

	      /* New hack.  We can allow the user to edit the
		 failed history expansion. */
	      re_edit (line);

	      return ((char *)NULL);
	    }
	}

      /* Let other expansions know that return_value can be free'ed,
	 and that a line has been added to the history list. */
      expanded = 1;
      return_value = history_value;
    }

  if (addit && remember_on_history)
    {
      extern int history_control;

      switch (history_control)
	{
	case 0:
	  add_history (return_value);
	  break;
	case 1:
	  if (*return_value != ' ')
	    add_history (return_value);
	  break;
	case 2:
	  {
	    HIST_ENTRY *temp = previous_history ();
	    if (!temp || (strcmp (temp->line, return_value) != 0))
	      add_history (return_value);
	    using_history ();
	  }
	  break;
	}
    }

#ifdef ALIAS
  alias_value = alias_expand (return_value);

  if (expanded)
    {
      expanded = 0;
      free (return_value);
    }

  return_value = alias_value;

#else
  return_value = savestring (line);
#endif /* ALIAS */

#ifdef ALIAS
#ifdef NEVER  /* Expanding history-wise here is sematically incorrect
		 for this shell, and should never be done.  I figured
		 it out, so just trust me, okay? */
  /* History expand the alias.  This is a special hack.  Don't you
     just hate this? */

  if (!history_expansion_inhibited && history_expansion)
    {
      expanded = history_expand (return_value, &history_value);

      if (expanded < 0)
	{
	  free (history_value);
	  free (return_value);
	  return ((char *)NULL);
	}

      if (expanded)
	{
	  free (return_value);
	  return_value = history_value;
	}
    }
#endif  /* NEVER */
#endif  /* ALIAS */
  return (return_value);
}


/* Place to remember the token.  We try to keep the buffer
   at a reasonable size, but it can grow. */
char *token = NULL;

/* Current size of the token buffer. */
int token_buffer_size = 0;

/* Command to read_token () explaining what we want it to do. */
#define READ 0
#define RESET 1

/* prompt_string_pointer points to one of these,
   never to an actual string. */
char *ps1_prompt, *ps2_prompt;

/* Handle on the current prompt string.  Indirectly points through
   ps1_ or ps2_prompt. */
char **prompt_string_pointer;

/* Function for yyparse to call.  yylex keeps track of
   the last two tokens read, and calls read_token.  */
yylex ()
{
  if (interactive && (!current_token || current_token == '\n'))
    {
      /* Before we print a prompt, we might have to check mailboxes.
	 We do this only if it is time to do so. Notice that only here
	 is the mail alarm reset; nothing takes place in check_mail ()
	 except the checking of mail.  Please don't change this. */
      if (time_to_check_mail ())
	{
	  check_mail ();
	  reset_mail_timer ();
	}

      /* Allow the execution of a random command just before the printing
	 of each prompt.  If the shell variable PROMPT_COMMAND
	 is set then the value of it is the command to execute. */
      {
	char *command_to_execute = get_string_value ("PROMPT_COMMAND");

	if (command_to_execute)
	  {
	    extern Function *last_shell_builtin, *this_shell_builtin;
	    Function *temp_last, *temp_this;

	    temp_last = last_shell_builtin;
	    temp_this = this_shell_builtin;

	    parse_and_execute (savestring (command_to_execute),
			       "PROMPT_COMMAND");
	    last_shell_builtin = temp_last;
	    this_shell_builtin = temp_this;
	  }
      }

      prompt_again ();
      prompt_string_pointer = &ps2_prompt;
    }

  token_before_that = last_read_token;
  last_read_token = current_token;
  current_token = read_token (READ);
  return (current_token);
}

/* Called from shell.c when Control-C is typed at top level.  Or
   by the error rule at top level. */
reset_parser ()
{
  read_token (RESET);
}
  
/* When non-zero, we have read the required tokens
   which allow ESAC to be the next one read. */
static int allow_esac_as_next = 0;

/* When non-zero, accept single '{' as a token itself. */
static int allow_open_brace = 0;

/* DELIMITER is the value of the delimiter that is currently
   enclosing, or zero for none. */
static int delimiter = 0;

/* When non-zero, an open-brace used to create a group is awaiting a close
   brace partner. */
static int open_brace_awaiting_satisfaction = 0;

/* If non-zero, it is the token that we want read_token to return regardless
   of what text is (or isn't) present to be read.  read_token resets this. */
int token_to_read = 0;

/* Read the next token.  Command can be READ (normal operation) or 
   RESET (to normalize state. */
read_token (command)
     int command;
{
  int character;		/* Current character. */
  int peek_char;		/* Temporary look-ahead character. */
  int result;			/* The thing to return. */
  WORD_DESC *the_word;		/* The value for YYLVAL when a WORD is read. */

  if (token_buffer_size < TOKEN_DEFAULT_GROW_SIZE)
    {
      if (token)
	free (token);
      token = (char *)xmalloc (token_buffer_size = TOKEN_DEFAULT_GROW_SIZE);
    }

  if (command == RESET)
    {
      delimiter = 0;
      open_brace_awaiting_satisfaction = 0;
      if (shell_input_line)
	{
	  free (shell_input_line);
	  shell_input_line = (char *)NULL;
	  shell_input_line_size = 0;
	}
      last_read_token = '\n';
      token_to_read = '\n';
      return;
    }

  if (token_to_read)
    {
      int rt = token_to_read;
      token_to_read = 0;
      return (rt);
    }

  /* Read a single word from input.  Start by skipping blanks. */
  while ((character = shell_getc (1)) != EOF && whitespace (character));

  if (character == EOF)
    return (yacc_EOF);

  if (character == '#' && !interactive)
    {
      /* A comment.  Discard until EOL or EOF, and then return a newline. */
      discard_until ('\n');
      shell_getc (0);
      return ('\n');
    }

  if (character == '\n')
    return (character);

  if (member (character, "()<>;&|"))
    {
      /* Please note that the shell does not allow whitespace to
	 appear in between tokens which are character pairs, such as
	 "<<" or ">>".  I believe this is the correct behaviour. */

      if (character == (peek_char = shell_getc (1)))
	{
	  switch (character)
	    {
	      /* If '<' then we could be at "<<" or at "<<-".  We have to
		 look ahead one more character. */
	    case '<':
	      peek_char = shell_getc (1);
	      if (peek_char == '-')
		return (LESS_LESS_MINUS);
	      else
		{
		  shell_ungetc (peek_char);
		  return (LESS_LESS);
		}

	    case '(': return (DOUBLE_OPEN);
	    case ')': return (DOUBLE_CLOSE);
	    case '>': return (GREATER_GREATER);
	    case ';':	return (SEMI_SEMI);
	    case '&': return (AND_AND);
	    case '|': return (OR_OR);
	    }
	}
      else
	{
	  if (peek_char == '&')
	    {
	      switch (character)
		{
		case '<': return (LESS_AND);
		case '>': return (GREATER_AND);
		}
	    }
	  if (peek_char == '>' && character == '&')
	    return (AND_GREATER);
	}
      shell_ungetc (peek_char);

      /* If we look like we are reading the start of a function
	 definition, then let the reader know about it so that
	 we will do the right thing with `{'. */
      if (character == ')' &&
	  last_read_token == '(' && token_before_that == WORD)
	allow_open_brace = 1;

      return (character);
    }

  /* Hack <&- (close stdin) case. */
  if (character == '-')
    {
      switch (last_read_token)
	{
	case LESS_AND:
	case GREATER_AND:
	  return (character);
	}
    }
  
  /* Okay, if we got this far, we have to read a word.  Read one,
     and then check it against the known ones. */
  {
    /* Index into the token that we are building. */
    int token_index = 0;

    /* ALL_DIGITS becomes zero when we see a non-digit. */
    int all_digits = digit (character);

    /* DOLLAR_PRESENT becomes non-zero if we see a `$'. */
    int dollar_present = 0;

    /* QUOTED becomes non-zero if we see one of ("), ('), (`), or (\). */
    int quoted = 0;

    /* Non-zero means to ignore the value of the next character, and just
       to add it no matter what. */
    int pass_next_character = 0;

    /* Non-zero means parsing a dollar-paren construct.  It is the count of
       un-quoted closes we need to see. */
    int dollar_paren_level = 0;

    /* Another level variable.  This one is for dollar_parens inside of
       double-quotes. */
    int delimited_paren_level = 0;

    for (;;)
      {
	if (character == EOF)
	  goto got_token;

	if (pass_next_character)
	  {
	    pass_next_character = 0;
	    goto got_character;
	  }

	/* Handle double backslash.  These are always magic.  The
	   second backslash does not cause a trailing newline to be
	   eaten. */

	if (character == '\\')
	  {
	    peek_char = shell_getc (0);
	    if (peek_char != '\\')
	      shell_ungetc (peek_char);
	    else
	      {
		token[token_index++] = character;
		goto got_character;
	      }
	  }

	/* Handle backslashes.  Quote lots of things when not inside of
	   double-quotes, quote some things inside of double-quotes. */

	if (character == '\\' && delimiter != '\'')
	  {
	    peek_char = shell_getc (0);

	    /* Backslash-newline is ignored in all other cases. */
	    if (peek_char == '\n')
	      {
		character = '\n';
		goto next_character;
	      }
	    else
	      {
		shell_ungetc (peek_char);

		/* If the next character is to be quoted, do it now. */
		if (!delimiter || delimiter == '`' ||
		    ((delimiter == '"' ) &&
		     (member (peek_char, slashify_in_quotes))))
		  {
		    pass_next_character++;
		    quoted = 1;
		    goto got_character;
		  }
	      }
	  }

	if (delimiter)
	  {
	    if (character == delimiter)
	      {
		delimiter = 0;
		if (delimited_paren_level)
		  {
		    report_error ("Expected ')' before %c", character);
		    return ('\n');
		  }
		goto got_character;
	      }
	  }

	if (!delimiter || delimiter == '`' || delimiter == '"')
	  {
	    if (character == '$')
	      {
		peek_char = shell_getc (1);
		shell_ungetc (peek_char);
		if (peek_char == '(')
		  {
		    if (!delimiter)
		      dollar_paren_level++;
		    else
		      delimited_paren_level++;

		    pass_next_character++;
		    goto got_character;
		  }
	      }
		
	    if (character == ')')
	      {
		if (delimiter && delimited_paren_level)
		  delimited_paren_level--;

		if (!delimiter && dollar_paren_level)
		  {
		    dollar_paren_level--;
		    goto got_character;
		  }
	      }
	  }

	if (!dollar_paren_level && !delimiter &&
	    member (character, " \t\n;&()|<>"))
	  {
	    shell_ungetc (character);
	    goto got_token;
	  }
    
	if (!delimiter)
	  {
	    if (character == '"' || character == '`' || character == '\'')
	      {
		quoted = 1;
		delimiter = character;
		goto got_character;
	      }
	  }

	if (all_digits) all_digits = digit (character);
	if (character == '$') dollar_present = 1;

      got_character:

	token[token_index++] = character;

	if (token_index == (token_buffer_size - 1))
	  token = (char *)xrealloc (token, (token_buffer_size
					    += TOKEN_DEFAULT_GROW_SIZE));
	{
	  char *decode_prompt_string ();

	next_character:
	  if (character == '\n' && interactive)
	    prompt_again ();
	}
	character = shell_getc ((delimiter != '\''));
      }

got_token:

    token[token_index] = '\0';
	
    if ((delimiter || dollar_paren_level) && character == EOF)
      {
	if (dollar_paren_level && !delimiter)
	  delimiter = ')';

	report_error ("Unexpected EOF.  Looking for `%c'.", delimiter);
	return (-1);
      }

    if (all_digits)
      {
	/* Check to see what thing we should return.  If the last_read_token
	   is a `<', or a `&', or the character which ended this token is
	   a '>' or '<', then, and ONLY then, is this input token a NUMBER.
	   Otherwise, it is just a word, and should be returned as such. */

	if ((character == '<' || character == '>') ||
	    (last_read_token == LESS_AND ||
	     last_read_token == GREATER_AND))
	  {
	    sscanf (token, "%d", &(yylval.number));
	    return (NUMBER);
	  }
      }

    /* Handle special case.  IN is recognized if the last token
       was WORD and the token before that was FOR or CASE. */
    if ((strcmp (token, "in") == 0) &&
	(last_read_token == WORD) &&
	((token_before_that == FOR) ||
	 (token_before_that == CASE)))
      {
	if (token_before_that == CASE) allow_esac_as_next++;
	return (IN);
      }

    /* Ditto for DO in the FOR case. */
    if ((strcmp (token, "do") == 0) &&
	(last_read_token == WORD) &&
	(token_before_that == FOR))
      return (DO);

    /* Ditto for ESAC in the CASE case. 
       Specifically, this handles "case word in esac", which is a legal
       construct, certainly because someone will pass an empty arg to the
       case construct, and we don't want it to barf.  Of course, we should
       insist that the case construct has at least one pattern in it, but
       the designers disagree. */
    if (allow_esac_as_next)
      {
	allow_esac_as_next--;
	if (strcmp (token, "esac") == 0)
	  return (ESAC);
      }

    /* Ditto for `{' in the FUNCTION case. */
    if (allow_open_brace)
      {
	allow_open_brace = 0;
	if (strcmp (token, "{") == 0)
	  {
	    open_brace_awaiting_satisfaction++;
	    return ('{');
	  }
      }

    /* Check to see if it is a reserved word. */
    if (!dollar_present && !quoted &&
	reserved_word_acceptable (last_read_token))
      {
	int i;
	for (i = 0; token_word_alist[i].word != (char *)NULL; i++)
	  if (strcmp (token, token_word_alist[i].word) == 0)
	    {
	      if (token_word_alist[i].token == '{')
		open_brace_awaiting_satisfaction++;

	      return (token_word_alist[i].token);
	    }
      }

    /* What if we are attempting to satisfy an open-brace grouper? */
    if (open_brace_awaiting_satisfaction && strcmp (token, "}") == 0)
      {
	open_brace_awaiting_satisfaction--;
	return ('}');
      }
      
    the_word = (WORD_DESC *)xmalloc (sizeof (WORD_DESC));
    the_word->word = (char *)xmalloc (1 + strlen (token));
    strcpy (the_word->word, token);
    the_word->dollar_present = dollar_present;
    the_word->quoted = quoted;
    the_word->assignment = assignment (token);

    yylval.word = the_word;
    result = WORD;
    if (last_read_token == FUNCTION)
      allow_open_brace = 1;
  }
  return (result);
}

/* Return 1 if TOKEN is a token that after being read would allow
   a reserved word to be seen, else 0. */
reserved_word_acceptable (token)
     int token;
{
  if (member (token, "\n;()|&{") ||
      token == AND_AND ||
      token == OR_OR ||
      token == SEMI_SEMI ||
      token == DO ||
      token == IF ||
      token == THEN ||
      token == ELSE ||
      token == ELIF ||
      token == 0)
    return (1);
  else
    return (0);
}

/* Issue a prompt, or prepare to issue a prompt when the next character
   is read. */
prompt_again ()
{
  char *decode_prompt_string ();
  char *temp_prompt;

  ps1_prompt = get_string_value ("PS1");
  ps2_prompt = get_string_value ("PS2");

  if (!prompt_string_pointer)
    prompt_string_pointer = &ps1_prompt;

  if (*prompt_string_pointer)
    temp_prompt = decode_prompt_string (*prompt_string_pointer);
  else
    temp_prompt = savestring ("");

#ifdef READLINE
  if (!no_line_editing)
    {
      if (current_readline_prompt)
	free (current_readline_prompt);
      
      current_readline_prompt = temp_prompt;
    }
  else
#endif  /* READLINE */
    {
      if (interactive)
	{
	  fprintf (stderr, "%s", temp_prompt);
	  fflush (stderr);
	}
      free (temp_prompt);
    }
}

/* This sucks. but it is just a crock for SYSV.  The whole idea of MAXPATHLEN
   is a crock if you ask me.  Why can't we just have dynamically defined
   sizes?  (UCSB crashes every 20 minutes on me.) */
#ifndef MAXPATHLEN
#define MAXPATHLEN 1024
#endif  /* MAXPATHLEN */

/* Return a string which will be printed as a prompt.  The string
   may contain special characters which are decoded as follows:
   
	\t	the time
	\d	the date
	\n	CRLF
	\s	the name of the shell
	\w	the current working directory
	\W	the last element of PWD
	\u	your username
	\h	the hostname
	\#	the command number of this command
	\!	the history number of this command
	\$	a $ or a # if you are root
	\<octal> character code in octal
	\\	a backslash
*/
#include <sys/param.h>
#include <time.h>

#define PROMPT_GROWTH 50
char *
decode_prompt_string (string)
     char *string;
{
  int result_size = PROMPT_GROWTH;
  int result_index = 0;
  char *result = (char *)xmalloc (PROMPT_GROWTH);
  int c;
  char *temp = (char *)NULL;

  result[0] = 0;
  while (c = *string++)
    {
      if (c == '\\')
	{
	  c = *string;

	  switch (c)
	    {

	    case '0':
	    case '1':
	    case '2':
	    case '3':
	    case '4':
	    case '5':
	    case '6':
	    case '7':
	      {
		char octal_string[4];
		int n;

		strncpy (octal_string, string, 3);
		octal_string[3] = '\0';

		n = read_octal (octal_string);

		temp = savestring ("\\");
		if (n != -1)
		  {
		    string += 3;
		    temp[0] = n;
		  }

		c = 0;
		goto add_string;
	      }
	  
	    case 't':
	    case 'd':

	      /* Make the current time/date into a string. */
	      {
		long the_time = time (0);
		char *ttemp = ctime (&the_time);
		temp = savestring (ttemp);

		if (c == 't')
		  {
		    strcpy (temp, temp + 11);
		    temp[8] = '\0';
		  }
		else
		  temp[10] = '\0';

		goto add_string;
	      }

	    case 'n':
	      temp = savestring ("\r\n");
	      goto add_string;

	    case 's':
	      {
		extern char *shell_name;
		temp = savestring (shell_name);
		goto add_string;
	      }
	
	    case 'w':
	    case 'W':
	      {
		/* Use the value of PWD because it is much more effecient. */
#define EFFICIENT
#ifdef EFFICIENT
		char *polite_directory_format (), t_string[MAXPATHLEN];

		temp = get_string_value ("PWD");

		if (!temp)
		  getwd (t_string);
		else
		  strcpy (t_string, temp);
#else
		getwd (t_string);
#endif  /* EFFICIENT */

		if (c == 'W')
		  {
		    char *rindex (), *dir = rindex (t_string, '/');
		    if (dir)
		      strcpy (t_string, dir + 1);
		    temp = savestring (t_string);
		  }
		else
		  temp = savestring (polite_directory_format (t_string));
		goto add_string;
	      }
      
	    case 'u':
	      {
		extern char *current_user_name;
		temp = savestring (current_user_name);

		goto add_string;
	      }

	    case 'h':
	      {
		extern char *current_host_name;
		char *t_string, *index ();

		temp = savestring (current_host_name);
		if (t_string = index (temp, '.'))
		  *t_string = '\0';
		
		goto add_string;
	      }

	    case '#':
	      {
		extern int current_command_number;
		char number_buffer[20];
		sprintf (number_buffer, "%d", current_command_number);
		temp = savestring (number_buffer);
		goto add_string;
	      }

	    case '!':
	      {
		extern int history_base, where_history ();
		char number_buffer[20];

		using_history ();
		if (get_string_value ("HISTSIZE"))
		  sprintf (number_buffer, "%d",
			   history_base + where_history ());
		else
		  strcpy (number_buffer, "!");
		temp = savestring (number_buffer);
		goto add_string;
	      }

	    case '$':
	      temp = savestring (geteuid () == 0 ? "#" : "$");
	      goto add_string;

	    case '\\':
	      temp = savestring ("\\");
	      goto add_string;

	    default:
	      temp = savestring ("\\ ");
	      temp[1] = c;

	    add_string:
	      if (c)
		string++;
	      result =
		(char *)sub_append_string (temp, result,
					   &result_index, &result_size);
	      temp = (char *)NULL; /* Free ()'ed in sub_append_string (). */
	      result[result_index] = '\0';
	      break;
	    }
	}
      else
	{
	  while (3 + result_index > result_size)
	    result = (char *)xrealloc (result, result_size += PROMPT_GROWTH);

	  result[result_index++] = c;
	  result[result_index] = '\0';
	}
    }

  /* I don't really think that this is a good idea.  Do you? */
  if (!find_variable ("NO_PROMPT_VARS"))
    {
      WORD_LIST *expand_string (), *list;
      char *string_list ();

      list = expand_string (result, 1);
      free (result);
      result = string_list (list);
      dispose_words (list);
    }

  return (result);
}

/* Report a syntax error, and restart the parser.  Call here for fatal
   errors. */
yyerror ()
{
  report_syntax_error ((char *)NULL);
  reset_parser ();
}

/* Report a syntax error with line numbers, etc.
   Call here for recoverable errors.  If you have a message to print,
   then place it in MESSAGE, otherwise pass NULL and this will figure
   out an appropriate message for you. */
report_syntax_error (message)
     char *message;
{
  if (message)
    {
      if (!interactive)
	{
	  char *name = stream_name ? stream_name : "stdin";
	  report_error ("%s:%d: `%s'", name, line_number, message);
	}
      else
	report_error ("%s", message);

      return;
    }

  if (shell_input_line && *shell_input_line)
    {
      char *error_token, *t = shell_input_line;
      register int i = shell_input_line_index;
      int token_end = 0;

      if (!t[i] && i)
	i--;

      while (i && t[i] == ' ' || t[i] == '\t' || t[i] == '\n')
	i--;

      if (i)
	token_end = i + 1;

      while (i && !member (t[i], " \n\t;|&"))
	i--;

      while (i != token_end && member (t[i], " \n\t"))
	i++;

      if (token_end)
	{
	  error_token = (char *)alloca (1 + (token_end - i));
	  strncpy (error_token, t + i, token_end - i);
	  error_token[token_end - i] = '\0';

	  report_error ("syntax error near `%s'", error_token);
	}
      else if ((i == 0) && (token_end == 0))    /* a 1-character token */
	{
	  error_token = (char *) alloca (2);
	  strncpy(error_token, t + i, 1);
	  error_token[1] = '\0';

	  report_error ("syntax error near `%s'", error_token);
	}

      if (!interactive)
	{
	  char *temp = savestring (shell_input_line);
	  char *name = stream_name ? stream_name : "stdin";
	  int l = strlen (temp);

	  while (l && temp[l - 1] == '\n')
	    temp[--l] = '\0';

	  report_error ("%s:%d: `%s'", name, line_number, temp);
	  free (temp);
	}
    }
  else
    report_error ("Syntax error");
}

/* ??? Needed function. ??? We have to be able to discard the constructs
   created during parsing.  In the case of error, we want to return
   allocated objects to the memory pool.  In the case of no error, we want
   to throw away the information about where the allocated objects live.
   (dispose_command () will actually free the command. */
discard_parser_constructs (error_p)
     int error_p;
{
/*   if (error_p) {
     fprintf (stderr, "*");
  } */
}
   
/* Do that silly `type "bye" to exit' stuff.  You know, "ignoreeof". */

/* The number of times that we have encountered an EOF character without
   another character intervening.  When this gets above the limit, the
   shell terminates. */
int eof_encountered = 0;

/* The limit for eof_encountered. */
int eof_encountered_limit = 10;

/* If we have EOF as the only input unit, this user wants to leave
   the shell.  If the shell is not interactive, then just leave.
   Otherwise, if ignoreeof is set, and we haven't done this the
   required number of times in a row, print a message. */
handle_eof_input_unit ()
{
  extern int login_shell, EOF_Reached;

  if (interactive)
    {
      /* If the user wants to "ignore" eof, then let her do so, kind of. */
      if (find_variable ("ignoreeof") || find_variable ("IGNOREEOF"))
	{
	  if (eof_encountered < eof_encountered_limit)
	    {
	      fprintf (stderr, "Use \"%s\" to leave the shell.\n",
		       login_shell ? "logout" : "exit");
	      eof_encountered++;
	      return;
	    } 
	}

      /* In this case EOF should exit the shell.  Do it now. */
      reset_parser ();
      exit_builtin ((WORD_LIST *)NULL);
    }
  else
    {
      /* We don't write history files, etc., for non-interactive shells. */
      EOF_Reached = 1;
    }
}
