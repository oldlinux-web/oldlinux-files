typedef union {
  WORD_DESC *word;		/* the word that we read. */
  int number;			/* the number that we read. */
  WORD_LIST *word_list;
  COMMAND *command;
  REDIRECT *redirect;
  ELEMENT element;
  PATTERN_LIST *pattern;
} YYSTYPE;
#define	IF	258
#define	THEN	259
#define	ELSE	260
#define	ELIF	261
#define	FI	262
#define	CASE	263
#define	ESAC	264
#define	FOR	265
#define	WHILE	266
#define	UNTIL	267
#define	DO	268
#define	DONE	269
#define	FUNCTION	270
#define	IN	271
#define	WORD	272
#define	NUMBER	273
#define	AND_AND	274
#define	OR_OR	275
#define	GREATER_GREATER	276
#define	LESS_LESS	277
#define	LESS_AND	278
#define	GREATER_AND	279
#define	SEMI_SEMI	280
#define	LESS_LESS_MINUS	281
#define	AND_GREATER	282
#define	DOUBLE_OPEN	283
#define	DOUBLE_CLOSE	284
#define	yacc_EOF	285


extern YYSTYPE yylval;
