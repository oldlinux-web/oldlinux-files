/bin/cat "$*"
