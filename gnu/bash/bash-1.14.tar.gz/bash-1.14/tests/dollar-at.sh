/bin/cat "$@"
