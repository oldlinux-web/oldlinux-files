../bash redir-test-1.sh
