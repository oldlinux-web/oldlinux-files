/* dispose_cmd.h -- Functions appearing in dispose_cmd.c. */

#if !defined (_DISPOSE_CMD_H_)
#define _DISPOSE_CMD_H_

extern void dispose_command (), dispose_word (), dispose_words ();
extern void dispose_word_array (), dispose_redirects ();

#endif /* !_DISPOSE_CMD_H_ */
