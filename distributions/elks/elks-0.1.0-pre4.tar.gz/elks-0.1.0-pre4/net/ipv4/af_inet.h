#ifndef AF_INET_H
#define AF_INET_H

#include <linuxmt/in.h>

#endif
