#ifndef __LINUX_VFS_H__
#define __LINUX_VFS_H__

#include <arch/statfs.h>

#endif
