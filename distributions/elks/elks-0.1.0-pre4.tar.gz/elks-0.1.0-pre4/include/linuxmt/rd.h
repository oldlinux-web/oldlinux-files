#ifndef __LINUXMT_RD_H__
#define __LINUXMT_RD_H__

#define RDCREATE	0
#define RDDESTROY	1

#define RD_BUSY 	0x01

#endif
