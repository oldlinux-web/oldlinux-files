#ifndef __LINUX_IOCTL_H__
#define __LINUX_IOCTL_H__

#include <arch/ioctl.h>

#endif
