#ifndef __ROMFS_FS_SB_H__
#define __ROMFS_FS_SB_H__

/* romfs superblock in-core data */

struct romfs_sb_info {
	unsigned long s_maxsize;
};

#endif
