#ifndef __ARCH_8086_IOCTL_H__
#define __ARCH_8086_IOCTL_H__

/*
 *	Nothing here yet.
 */

#endif
