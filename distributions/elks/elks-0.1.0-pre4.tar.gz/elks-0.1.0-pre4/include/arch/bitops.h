#ifndef __ARCH_8086_BITOPS_H__
#define __ARCH_8086_BITOPS_H__

extern int clear_bit();
extern int set_bit();
extern int test_bit();

#endif
