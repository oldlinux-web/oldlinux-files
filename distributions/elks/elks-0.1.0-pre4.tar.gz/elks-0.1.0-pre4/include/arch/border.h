#ifndef __ARCH_BORDER_H__
#define __ARCH_BORDER_H__

extern unsigned long htonl();
extern unsigned long ntohl();

#endif
