#include <unistd.h>
#include <string.h>


void
main ()
{
	sync();
	exit(0);
}
