#include <unistd.h>
#include <string.h>


void
main ()
{
	exit(1);
}
