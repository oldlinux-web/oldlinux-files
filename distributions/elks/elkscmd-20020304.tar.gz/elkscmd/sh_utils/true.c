#include <unistd.h>
#include <string.h>


void
main (void)
{
	exit(0);
}
