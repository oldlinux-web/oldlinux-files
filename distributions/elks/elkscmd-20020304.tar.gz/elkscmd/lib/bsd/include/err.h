#ifndef _BSD_ERR_H
#define _BSD_ERR_H

void errx(int eval, const char * fmt, ...);

#endif /* _BSD_ERR_H */
