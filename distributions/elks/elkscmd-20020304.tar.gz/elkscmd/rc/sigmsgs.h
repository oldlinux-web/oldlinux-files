typedef struct {
	char *name, *msg;
} Sigmsgs;
extern Sigmsgs signals[];
#define NUMOFSIGNALS 29
