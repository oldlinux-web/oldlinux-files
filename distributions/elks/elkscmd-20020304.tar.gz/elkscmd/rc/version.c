char id[] = "@(#)rc version 1.5betadev-1, 1/9/94.";
