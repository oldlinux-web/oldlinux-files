/* config.h */
#define SMALL_BUF
#define BC_MATH_FILE "/usr/lib/libmath.b"
#define SHORTNAMES
