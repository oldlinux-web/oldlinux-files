#if !DEBUG

#define trputc(_a)

#define trace(_a, _b, _c, _d, _e, _f, _g, _h, _i)

#define trputs(_a)

#define trstring(_a)

#define trargs(_a)

#define opentrace(_a)

#endif
