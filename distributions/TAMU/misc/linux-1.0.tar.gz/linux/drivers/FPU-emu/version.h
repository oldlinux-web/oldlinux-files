/*---------------------------------------------------------------------------+
 |  version.h                                                                |
 |                                                                           |
 |                                                                           |
 | Copyright (C) 1992,1993,1994                                              |
 |                       W. Metzenthen, 22 Parker St, Ormond, Vic 3163,      |
 |                       Australia.  E-mail   billm@vaxc.cc.monash.edu.au    |
 |                                                                           |
 |                                                                           |
 +---------------------------------------------------------------------------*/

#define FPU_VERSION "wm-FPU-emu version Beta 1.10"

