/*
 * UMAIL	MINIX Remote Domain-addressing Mail Router
 *
 *		This file contains the code that takes care of the actual
 *		sending of the message.  This can be done through its own
 *		delivery routines (which is _fast_), but we can also call
 *		standard programs (portability!) to do the job. For some
 *		reasons, we can also call non-standard programs to do the
 *		delivery.
 *
 * Author:	Fred N. van Kempen, MicroWalt Corporation
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pwd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include "umail.h"


/* Write an U-MAIL Administration Record. */
static void uadmin(frm, hst, usr, data)
char *frm;
char *hst;
char *usr;
char *data;
{
  char buff[1024];
  struct stat stb;
  struct tm *tm;
  FILE *adm;
  time_t now;
  int i;

  /* Is the U-MAIL Traffic Administration enabled? */
  if (access(ADMIN, 0) != 0) return;

  /* Get the current date and time. */
  (void) time(&now); tm = xltime(&now);

  if (stat(data, &stb) < 0) {
	fprintf(stderr, "umail: admin: cannot stat %s\n", data);
	return;
  }

  sprintf(buff, "%02.2d/%02.2d/%02.2d\t%s\t%ld\t%s\t%s",
	tm->tm_year - 1900, tm->tm_mon + 1, tm->tm_mday,
	mailsender, (long) stb.st_size, hst, usr);

  i = 0;
  while(creat(ADMINLCK, 0600) < 0) {
	(void) sleep(5);
  	if (++i > 5) {
		fprintf(stderr, "umail: cannot lock %s\n", ADMIN);
		return;
	}
  }

  if ((adm = fopen(ADMIN, "a")) != (FILE *)NULL) {
	fprintf(adm, "%s\n", buff);
	fclose(adm);
  }
  (void) unlink(ADMINLCK);
}


/* Read and update the SPOOLSEQ. */
static off_t get_seq()
{
  char buff[10];
  off_t seq;
  FILE *fp;
  int i;

  if (access(SEQF, 0) != 0) {
	fprintf(stderr, "umail: SEQF does not exist!\n");
	return((off_t) 0);
  }

  i = 0;
  while(creat(SEQLCK, 0600) < 0) {
	(void) sleep(5);
  	if (++i > 5) {
		fprintf(stderr, "umail: cannot lock %s\n", SEQF);
		return((off_t)-1);
	}
  }

  if ((fp = fopen(SEQF, "r+")) != (FILE *)NULL) {
	fgets(buff, 10, fp);
	seq = (off_t) atol(buff);
	seq++;
	(void) fseek(fp, (off_t) 0, SEEK_SET);
	fprintf(fp, "%ld\n", (long) seq);
	fclose(fp);
  } else seq = (off_t) 0;
  (void) unlink(SEQLCK);

  return(seq);
}


/*
 * Create a "short" message-ID.
 * This has the form:
 *
 *	"AAseqno"
 *
 * and return the string.
 */
char *shortid()
{
  static char buff[16];
  off_t seq;

  /* Get the message-ID. */
  seq = get_seq();
  if (seq == (off_t) -1) seq == (off_t) 1;

  /* Create the string. */
  sprintf(buff, "AA%04.4ld", (long) seq);

  return(buff);
}


/*
 * Create a "Message-ID" field.
 * This has the form:
 *
 *	"yymmdd.AAseqno@myname"
 *
 * as in "891113.AA12345@uwalt.UUCP"
 */
char *mesgid(shortid)
char *shortid;
{
  static char buff[80];
  struct tm *tm;
  char *sp;
  time_t now;

  /* Get the current date and time. */
  time(&now); tm = xltime(&now);

  /* Create the string. */
  sprintf(buff, "%02.2d%02.2d%02.2d.%s@%s.%s", 
	tm->tm_year - 1900, tm->tm_mon + 1, tm->tm_mday, shortid,
						myname, mydomain);

  return(buff);
}


/* Call a mailer to perform the work. We should log here. */
static int callprog(args, data, errors)
char **args;
char *data;
char *errors;
{  
  int pid, status;
  int fd, efd;

  /* Open the input file. */
  if ((fd = open(data, O_RDONLY)) < 0) {
	fprintf(stderr, "umail: callprog: %s: %s\n", data, strerror(errno));
	return(-1);
  }

  /* We put all stdout/err in a file. */
  if ((efd = creat(errors, O_RDWR)) < 0) {
	fprintf(stderr, "umail: callprog: %s: %d\n", errors, strerror(errno));
	(void) close(fd);
	return(-1);
  }

  /* Fork off a child process. */
  if ((pid = fork()) == 0) {
	(void) close(0); (void) dup(fd);
	(void) close(1); (void) dup(efd);
	(void) close(2); (void) dup(efd);
	(void) close(fd);
	(void) close(efd);

	/* A slight change of personality. */
	(void) setgid(old_gid);
	(void) setuid(old_uid);

	/* Go home, so UUX won't barf on us (thanks, Will!). */
  	(void) chdir("/");

	/* Execute the desired program. */
	return(execv(args[0], args));
  } else {
	(void) close(fd);
	(void) close(efd);
	if (pid > 0) {
		while (wait(&status) != pid)
			    ;
	}
  }
 
  /* Check all resuls. */
  if (pid < 0) pid = errno;
    else pid = WEXITSTATUS(status);

  return(pid);
}


/*
 * Deliver this message to a local user.
 * We do this by calling "LMAIL" (which is actually
 * a link to "Mail"; the Local Mail Agent.
 */
static int send_local(usr, data)
char *usr;
char *data;
{
  char path[128];
  char buff[128];
  char *args[8];
  int st;

  /* Perform any UMAIL Administration necessary. */
  uadmin(mailsender, "local", usr, data);

  /* Set the correct protection mask. */
  (void) chown(data, old_uid, old_gid);

  st = 0;
  sprintf(path, "/tmp/umEXXXXXX");
  mktemp(path);
  args[st++] = LMAIL;
  args[st++] = usr;
  args[st] = (char *)NULL;

  st = callprog(args, data, path);

  if (st != 0) {
	sprintf(buff, "%s ... local delivery failed (status %d)", usr, st);
	errmail(buff, path, FALSE);
	st = FALSE;
  } else st = TRUE;

  (void) unlink(path);
  return(st);
}


/*
 * Deliver this message to a remote user.
 */
static int send_remote(rmtname, rmtuser, data)
char *rmtname;
char *rmtuser;
char *data;
{
  char path[128];
  char buff[128];
  char name[128];
  char *args[16];
  int st;

  /* Perform any UMAIL Administration necessary. */
  uadmin(mailsender, rmtname, rmtuser, data);

  sprintf(path, "/tmp/umEXXXXXX");
  mktemp(path);
  sprintf(buff, "%s!rmail", rmtname);
  sprintf(name, "(%s)", rmtuser);
  st = 0;
  args[st++] = UUX;
  args[st++] = "-gN";
  args[st++] = "-r";
  args[st++] = "-z";
  args[st++] = "-";
  args[st++] = buff;
  args[st++] = rmtuser;
  args[st] = (char *)NULL;

  st = callprog(args, data, path);

  if (st != 0) {
	sprintf(buff, "%s!rmail %s ... UUCP failed (status %d)",
						rmtname, rmtuser, st);
	errmail(buff, path, FALSE);
	st = FALSE;
  } else st = TRUE;

  (void) unlink(path);
  return(st);
}


/*
 * Perform the mail-transport.
 * We do this by calling the appropriate mailer.
 * If the name of the mailer is "$$" then we can use
 * this program to deliver. This saves a lot of memory.
 */
int sendit(who, shost, cmd, opts, data)
char *who;
char *shost;
char *cmd;
char *opts;
char *data;
{
  char cmdline[512];
  char tmpbuff[512];
  char addressee[1024];

  /* Run our own transport routines if possible. */
  if (!strcmp(cmd, "$$")) {
	if (*shost == '\0' && tolocal == FALSE) {
		strcpy(addressee, who);
		if (convert(addressee) == FALSE) return(FALSE);
		if (route() == FALSE) return(FALSE);
		if (mailhost[0] == '\0') send_local(mailaddr, data);
		  else send_remote(mailhost, mailaddr, data);
	} else {
		if (tolocal == TRUE) send_local(who, data);
		  else send_remote(shost, who, data);
	}
  } else {
	  sprintf(tmpbuff, "exec %s %s ", cmd, opts);
	  sprintf(cmdline, tmpbuff, data);
	  strcat(cmdline, who);
	  system(cmdline);
  }
  return(0);
}


/* Send mail to system manager ans sender upon errors. */
void errmail(str, errs, mgronly)
char *str;
char *errs;
int mgronly;
{
  struct passwd *pw;
  FILE *fp, *tp, *xp;
  time_t now;
  char fname[32];
  char tmp[1024];
  struct stat stb;

  time(&now);
  strcpy(fname, "/tmp/umeXXXXXX"); mktemp(fname);
  if ((tp = fopen(fname, "w")) == (FILE *)NULL) {
	if (logfp) fprintf(logfp, "Creation of return mail %s failed\n",
								fname);
	return;
  }

  if ((fp = fopen(dfile, "r")) == (FILE *)NULL ||
      stat(dfile, &stb) < 0) stb.st_size = 0L;

  /* Create header of the report-message. */
  fprintf(tp, "From %s %s\n", ERRUSER, xtime(&now));	
  fprintf(tp, "To: %s\n", mailsender);
  if (errcc == TRUE) fprintf(tp, "Cc: %s\n", ERRUSER);
  fprintf(tp, "Subject: Returned mail\n\n");

  /* Create an error transcript. */
  fprintf(tp, "Your message could not be delivered.  Please check\n");
  fprintf(tp, "all parameters and try again.  The message is below.\n\n");
  if ((xp = fopen(errs, "r")) != (FILE *)NULL) {
	fprintf(tp, "   ---- Standard Error of session follows ----\n\n");
	while(fgets(tmp, 1024, xp) != (char *)NULL)
		fprintf(tp, ">> %s", tmp);
	(void) fclose(xp);
	fprintf(tp, ">>\n");
  }
  fprintf(tp, "   ---- Transcript of session follows ----\n\n");
  fprintf(tp, "%s\n", str);
  if (stb.st_size >= noretsize) {
	fprintf(tp, "\n   ---- (return message suppressed) ----\n");
  } else {
	fprintf(tp, "\n   ---- Unsent message follows ----\n");

	/* Copy the message. */
	while (fgets(tmp, sizeof(tmp), fp) != (char *)NULL)
				fprintf(tp, "> %s", tmp);
  }
  fclose(tp); fclose(fp);

  /* Return mail to system manager (and sender if mgronly == FALSE). */
  if (mgronly == FALSE) sendit(mailsender, "", RMAIL, " <%s", fname);

  /* Send mail to UUCP administrator, if existing. */
  if ((pw = getpwnam(ERRUSER)) != (struct passwd *)NULL) {
	sendit(ERRUSER, "", "$$", "", fname);
  }

  (void) unlink(fname); (void) unlink(dfile);
  exit(1);
}
