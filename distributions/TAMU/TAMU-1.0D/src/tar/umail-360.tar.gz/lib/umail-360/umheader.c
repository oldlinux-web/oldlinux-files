/*
 * UMAIL	MINIX Remote Domain-addressing Mail Router
 *		This module reads the header part of a message into
 *		memory, and then rearranges it into RFC-822 order.
 *		At present, the header is defined in a structure in
 *		this file.  In the future, this definition should be
 *		placed in the U-MAIL Configuration file, to make it
 *		more portable.
 *
 * Author:	Fred N. van Kempen, MicroWalt Corporation
 */
#include <sys/types.h>
#include <pwd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdio.h>
#include "umail.h"


/* These RFC-822 message header fields are supported by U-MAIL. */
#define RF_NONE		"--RFC--"
#define RF_OFRM		"From "
#define RF_FROM		"From:"
#define RF_NAME		"Full-Name:"
#define RF_SENDER	"Sender:"
#define RF_REPLY	"Reply-To:"
#define RF_RETPAT	"Return-Path:"
#define RF_RECVD	"Received:"
#define RF_ORG		"Organization:"
#define RF_DEPT		"Department:"
#define RF_TO		"To:"
#define RF_CC		"Cc:"
#define RF_BCC		"Bcc:"
#define RF_SUBJ		"Subject:"
#define RF_KEYW		"Keywords:"
#define RF_SUMM		"Summary:"
#define RF_XMAIL	"X-Mailer:"
#define RF_XCOMM	"X-Comment:"
#define RF_MSGID	"Message-ID:"
#define RF_DATE		"Date:"


typedef struct _hdr_ {			/* the header field definition	*/
  char		*name;
  char		*field;
  struct _hdr_	*next;
} HDR;
#define HDRSIZE	(sizeof(HDR))
#define NILHDR	((HDR *)NULL)


static char olduser[1024];		/* who sent the message?	*/
static char oldhost[1024];		/* from which site?		*/
static char olddate[48];		/* and at what time?		*/
static HDR hdr[] = {			/* this is the in-core header	*/
  { RF_OFRM,	(char *)NULL,	NILHDR	},
  { RF_FROM,	(char *)NULL,	NILHDR	},
  { RF_NAME,	(char *)NULL,	NILHDR	},
  { RF_SENDER,	(char *)NULL,	NILHDR	},
  { RF_REPLY,	(char *)NULL,	NILHDR	},
  { RF_RETPAT,	(char *)NULL,	NILHDR	},
  { RF_RECVD,	(char *)NULL,	NILHDR	},
  { RF_ORG,	(char *)NULL,	NILHDR	},
  { RF_DEPT,	(char *)NULL,	NILHDR	},
  { RF_TO,	(char *)NULL,	NILHDR	},
  { RF_CC,	(char *)NULL,	NILHDR	},
  { RF_BCC,	(char *)NULL,	NILHDR	},
  { RF_SUBJ,	(char *)NULL,	NILHDR	},
  { RF_KEYW,	(char *)NULL,	NILHDR	},
  { RF_SUMM,	(char *)NULL,	NILHDR	},
  { RF_XMAIL,	(char *)NULL,	NILHDR	},
  { RF_XCOMM,	(char *)NULL,	NILHDR	},
  { RF_MSGID,	(char *)NULL,	NILHDR	},
  { RF_DATE,	(char *)NULL,	NILHDR	},
  { "",		(char *)NULL,	NILHDR	},
  { RF_NONE,	(char *)NULL,	NILHDR	}
};


/* Forward declarations. */
HDR *hdr_get(char *name);
int hdr_upd(char *text);
void hdr_new(void);
void hdr_end(void);
int hdr_chk(void);
int hdr_upd(char *text);


/* Fetch a certain field from the header. */
static HDR *hdr_get(name)
char *name;
{
  char name1[1024], name2[1024];
  register HDR *hp;

  strupr(name1, name);
  hp = hdr;
  while (*hp->name != '\0') {
	strupr(name2, hp->name);
	if (!strcmp(name2, name1)) return(hp);
	hp++;
  }
  return(NILHDR);
}


/*
 * Generate a local system header if needed.
 * Should we also create a "Sender:" field here if the
 * name of the sender != name of current user ??????
 */
static void hdr_new()
{
  char buff[1024];
  struct passwd *pw;
  register HDR *hp;
  char *un, *ur, *mydate;
  char *msg_id;
  time_t now;

  time(&now); mydate = maketime(&now);

  if ((pw = getpwnam(olduser)) == (struct passwd *)NULL) {
	un = "unknown";
	ur = "John Doe";
  } else {
	un = pw->pw_name;
	ur = pw->pw_gecos;
  }

  /* Clear out the old postmark and create a new one. */
  hp = hdr_get(RF_OFRM);
  free(hp->field);
  hp->field = (char *)NULL;
  sprintf(buff, "%s%s %s remote from %s.%s", RF_OFRM,
				un, olddate, myname, mydomain);
  (void) hdr_upd(buff);

  /* Generate an official From: line. */
  sprintf(buff, "%s \"%s\" <%s@%s.%s>", RF_FROM, ur, un, myname, mydomain);
  (void) hdr_upd(buff);

  /* Generate a Reply-To: line if needed. */
  hp = hdr_get(RF_REPLY);
  if (hp->field == (char *)NULL) {
	if ((pw = getpwnam(olduser)) != (struct passwd *)NULL) {
		sprintf(buff, "%s \"%s\" <%s@%s.%s>", hp->name,
			pw->pw_gecos, pw->pw_name, myname, mydomain);
		(void) hdr_upd(buff);
	}
  }

#if HAVE_SENDER
  /* Generate a Sender: line if needed. */
  if ((hp = hdr_get(RF_SENDER))->field == (char *)NULL) {
	if ((pw = getpwnam(olduser)) != (struct passwd *)NULL) {
		sprintf(buff, "%s %s <%s@%s.%s>", hp->name,
			pw->pw_gecos, pw->pw_name, myname, mydomain);
		(void) hdr_upd(buff);
	}
  }
#endif

  sprintf(buff, "%s by %s.%s (U-MAIL %s);\n%*.*s %s", RF_RECVD,
	myname, mydomain, Version, strlen(RF_RECVD), strlen(RF_RECVD),
					"                  ", mydate);
  (void) hdr_upd(buff);

  if (myorg != (char *)NULL) {
	sprintf(buff, "%s %s", RF_ORG, myorg);
	(void) hdr_upd(buff);
  }

  if (mydept != (char *)NULL) {
	sprintf(buff, "%s %s", RF_DEPT, mydept);
	(void) hdr_upd(buff);
  }

  msg_id = shortid();
  sprintf(buff, "%s <%s>", RF_MSGID, mesgid(msg_id));
  (void) hdr_upd(buff);

  sprintf(buff, "%s %s", RF_DATE, olddate);
  (void) hdr_upd(buff);
}


/* Patch the in-core header for various things. */
static void hdr_end()
{
  char buff[1024];		/* gathered From: line */
  char addr[512];
  char temp[512];
  char *rest;
  register char *sp, *bp;
  register HDR *hp, *xp, *yp;
  int local;
  time_t now;
  char *mydate;

  /* Get the current date and time. */
  (void) time(&now); mydate = maketime(&now);

  /* 1. Change the "From: " line if needed. */
  if (tolocal == FALSE) {
	strcpy(buff, "");
	xp = hp = hdr_get(RF_FROM);
	while (xp != NILHDR) {
		strcat(buff, xp->field);
		xp = xp->next;
	}

	if ((sp = strchr(buff, '<')) == (char *)NULL) {
		bp = buff;
		while (*bp && *bp != ' ' && *bp != '\t' && *bp != '(') bp++;
		if (*bp == ' ' || *bp == '\t' || *bp == '(') *bp++ = '\0';
		strcpy(addr, buff);
		if ((sp = strchr(bp, '(')) != (char *)NULL) *sp++ = '\0';
		  else sp = bp;
		rest = sp;
		if ((bp = strchr(sp, ')')) != (char *)NULL) *bp = '\0';
	} else {
		*sp++ = '\0';
		if ((bp = strchr(sp, '>')) != (char *)NULL) *bp = '\0';
		strcpy(addr, sp);
		sp -= 2;
		rest = buff;
		while (*sp == ' ' || *sp == '\t') *sp-- = '\0';
	}
	if ((sp = strchr(addr, ' ')) != (char *)NULL) *sp = '\0';
	if ((sp = strchr(addr, '@')) == (char *)NULL) {
		sprintf(temp, "%s!%s", myname, addr);
		strcpy(addr, temp);
	}
	if (rest == buff) sprintf(temp, "%s <%s>", rest, addr);
	  else sprintf(temp, "%s (%s)", addr, rest);

	/* Free all From: parts. */
	xp = hp->next;
	while(xp != NILHDR) {
		yp = xp->next;
		free(xp->field);
		free(xp);
		xp = yp;
	}
	hp->next = NILHDR;
	hp->field = (char *)malloc(strlen(temp) + 1);
	if (hp->field == (char *)NULL) {
		fprintf(stderr, "out of memory\n");
		return;
	} else strcpy(hp->field, temp);
  }

  /* 2. Rewrite the postmark. */
  hp = hdr_get(RF_OFRM);
  if (hp->field != (char *)NULL) free(hp->field);
  hp->field = (char *)NULL;
  if (tolocal == TRUE) {
	sprintf(buff, "%s%s %s remote from %s",
		RF_OFRM, olduser, olddate, oldhost);
  } else {
	sprintf(buff, "%s%s!%s %s remote from %s.%s",
		RF_OFRM, oldhost, olduser, olddate, myname, mydomain);
  }
  (void) hdr_upd(buff);

  /* 3. Patch in our Received: stamp. */
  hp = hdr_get(RF_RECVD);
  sprintf(buff, "by %s.%s (U-MAIL %s) with %s;\n%*.*s ", myname, mydomain,
	Version, protocol, strlen(hp->name), strlen(hp->name),
					"                        ");
  if (tolocal == FALSE) {
	sprintf(temp, "id %s; %s", shortid(), mydate);
  } else {
	sprintf(temp, "%s", mydate);
  }
  strcat(buff, temp);
  if (hp->field == (char *)NULL) {
	if ((hp->field = (char *)malloc(strlen(buff) + 1)) == (char *)NULL) {
		fprintf(stderr, "Out of memory\n");
		return;
	}
	strcpy(hp->field, buff);
	hp->next = NILHDR;
	return;
  } else {
	if ((xp = (HDR *)malloc(HDRSIZE)) == NILHDR) {
		fprintf(stderr, "Out of memory\n");
		return;
	} else {
		xp->next = hp->next;
		hp->next = xp;
		xp->name = hp->name;
		xp->field = hp->field;
		hp->field = (char *)malloc(strlen(buff) + 1);
		if (hp->field == (char *)NULL) {
			fprintf(stderr, "Out of memory\n");
			return;
		}
		strcpy(hp->field, buff);
	}
  }
}


/*
 * We need at least an old-style postmark, which has the form
 *
 *	From username date [remote from hostname]
 *
 * but we prefer to have the following fields:
 *
 *	From: username@hostname.domain (Real Name)
 *	To: username@hostname.domain (Real Name)
 *	Date: date
 *
 * Alternatively, we may have a From or To field with the newer
 * specification:
 *
 *	From: Real Name <username@hostname.domain>
 *
 * This routine checks out what kind of header we have, and it
 * then extracts the necessary info from the header.
 */
static int hdr_chk()
{
  char buff[1024];
  register HDR *hp;
  register char *bp, *sp, *cp;

  fromlocal = TRUE;
  hp = hdr_get(RF_FROM);
  if (hp->field != (char *)NULL) {
	fromlocal = FALSE;

	/* Remote mail.  Extract an 'olduser' and 'oldhost' value. */
	strcpy(buff, hp->field);

	/*
	 * Try 1: address (Real Name)
	 */
	if ((sp = strchr(buff, '(')) == (char *)NULL) {
		/*
		 * Try 2: Real Name <address>
		 */
		if ((sp = strchr(buff, '<')) != (char *)NULL) {
			*sp++ = '\0';
			if ((bp = strchr(sp, '>')) != (char *)NULL)
								*bp = '\0';
		} else {
			sp = buff;
#if 0
			sprintf(errmsg, "umail: illegal return address %s\n",
								hp->field);
			return(FALSE);
#endif
		}
	} else {
		*--sp = '\0';
		sp = buff;
	}

	/* SP now contains the sender's address. */
	while (*sp == ' ' || *sp == '\t') sp++;
	bp = strchr(sp, '@');		/* check for the @ char */
	if (bp != (char *)NULL)	{
		*bp++ = '\0';
		strcpy(oldhost, bp);
		strcpy(olduser, sp);
		sprintf(mailsender, "%s!%s", oldhost, olduser);
	} else {
		bp = strchr(sp, '!');		/* check for `!' */
		if (bp != (char *)NULL) {
			*bp++ = '\0';
			strcpy(oldhost, sp);	
			strcpy(olduser, bp);
			sprintf(mailsender, "%s!%s", oldhost, olduser);
		} else {
			strcpy(oldhost, "");
			strcpy(mailsender, olduser);
		}
	}

	/* Fetch the RFC-822 Date: field value. */
	hp = hdr_get(RF_DATE);
	if (hp->field == (char *)NULL) return(FALSE);
	  else strcpy(olddate, hp->field);

	hdr_end();
  } else {
	hp = hdr_get(RF_OFRM);
	if (hp->field == (char *)NULL) {
		sprintf(errmsg, "%s: no Postmark in header!", dfile);
       		return(FALSE);
	}

	/* We have a postmark.  Scan it for vital information. */
	sp = hp->field;
	bp = olduser;
	while (*sp && *sp != ' ' && *sp != '\t') *bp++ = *sp++;	/* uname */
	*bp = '\0';
	while (*sp == ' ' || *sp == '\t') sp++;

	/*
	 * CP points to the date.  SP points to date _and_ a possible
	 * "remote from" part. Parse line to seek out "remote from".
	 */
	cp = sp;
	while (TRUE) {
		bp = strchr(sp++, 'r');
		if (bp != (char *)NULL) {
			if (!strncmp(bp, "remote from ", 12)) break;
        	} else break;
	}

	/*
	 * If BP is non-NULL, we have a remote message.  Otherwise, it
	 * _may_ be one.  Some (ugly!) mailers do not use the "From_"
	 * line correct.  They omit the "remote from <host>" part, and
	 * just stuff an address of "user@host.domain" in this line !!!
	 */
	if (bp == (char *)NULL) {		/* possibly local mail */
		strcpy(buff, olduser);
		bp = strchr(buff, '@');		/* check for the @ char */
		if (bp != (char *)NULL)	{
			*bp++ = '\0';
			strcpy(olddate, cp);
			strcpy(oldhost, bp);
			strcpy(olduser, buff);
			sprintf(mailsender, "%s!%s", oldhost, olduser);
			fromlocal = FALSE;
		} else {
			bp = strchr(buff, '!');		/* check for `!' */
			if (bp != (char *)NULL) {
				*bp++ = '\0';
				strcpy(olddate, cp);
				strcpy(oldhost, buff);	
				strcpy(olduser, bp);
				sprintf(mailsender, "%s!%s",
						oldhost, olduser);
				fromlocal = FALSE;
			} else {
				strcpy(olddate, cp);
				strcpy(oldhost, "");
				strcpy(mailsender, olduser);
				fromlocal = TRUE;	
			}
		}
	} else {				/* old-style remote mail */
		sp = strrchr(bp, ' ');
		*(bp - 1) = '\0';
       		strcpy(olddate, cp);
		strcpy(oldhost, ++sp);
		fromlocal = FALSE;
	}
  }

  /* If this was local mail, complete the RFC-822 header. */
  if (fromlocal == TRUE) hdr_new();

  return(TRUE);
}


/* Update our in-core header information. */
static int hdr_upd(text)
char *text;
{
  char buff[1024];
  static HDR *op = NILHDR;
  register char *sp;
  register HDR *hp, *xp;
  char c;

  /* Is this the end-of-header marker? */
  if (*text == '\n') return(1);

  /* No.  Remove the trailing newline, if any. */
  sp = text + strlen(text) - 1;
  if (*sp == '\n') *sp = '\0';

  /* First, split up the "Field: " and "value" parts. */
  if (!strncmp(text, RF_OFRM, strlen(RF_OFRM))) {
	sp = text + strlen(RF_OFRM) - 1;
	*sp++ = '\0';
	while (*sp == ' ' || *sp == '\t') sp++;
	text = RF_OFRM;
  } else {
	if ((sp = strchr(text, ':')) == (char *)NULL) {
		if (op == NILHDR || (*text != ' ' && *text != '\t')) {
			fprintf(stderr, "bad header field: \"%s\"\n", text);
			return(0);
		}
		sp = text;
		text = op->name;
	} else {
		c = *++sp;
		*sp = '\0';
		if (hdr_get(text) == NILHDR) {
			*sp = c;
			if (op == NILHDR ||
			    (*text != ' ' && *text != '\t')) {
				fprintf(stderr, "bad header field: \"%s\"\n",
								text);
				return(0);
			}
			sp = text;
			text = op->name;
		} else {
			sp++;
			while (*sp == ' ' || *sp == '\t') sp++;
		}
	}
  }

  /* Then, add this header field to the in-core hdr. */
  if ((hp = hdr_get(text)) != NILHDR) {		/* standard field? */
	if (hp->next != NILHDR) {
		xp = hp->next;
		while (xp->next != NILHDR) xp = xp->next;
		hp = xp;
	}
	op = hp;
  } else {			/* no standard field, add "extra" field */
	hp = hdr_get(RF_NONE);
	if (hp->next != NILHDR) {
		xp = hp->next;
		while (xp->next != NILHDR) xp = xp->next;
		hp = xp;
	}
	op = hp;
  }

  /* If this is not a continuation line, add another frame. */
  if (hp->field != (char *)NULL && *sp != ' ' && *sp != '\t') {
	if ((xp = (HDR *)malloc(HDRSIZE)) == NILHDR) {
		fprintf(stderr, "out of memory\n");
		return(-1);
	}
	hp->next = xp;
	if ((xp->name = (char *)malloc(strlen(text) + 1)) == (char *)NULL) {
		fprintf(stderr, "out of memory\n");
		return(-1);
	} else strcpy(xp->name, text);
	xp->next = NILHDR;
	op = xp;
	hp = xp;
  }

  /* Now, see if we have to continue the previous line. */
  if (*sp == ' ' || *sp == '\t') {
	sprintf(buff, "%s\n%s", hp->field, sp);
	free(hp->field);
	sp = buff;
  }

  /* Finally, (re-)create the line. */
  if ((hp->field = (char *)malloc(strlen(sp) + 1)) == (char *)NULL) {
	fprintf(stderr, "out of memory\n");
	return(-1);
  } else strcpy(hp->field, sp);

  return(0);
}


/* Write out a complete message header. */
void hdr_out(fp)
register FILE *fp;
{
  register HDR *hp, *xp;

  /* First of, write all known RFC-fields. */
  hp = hdr;
  while (*hp->name != '\0') {
	if (hp->field == (char *)NULL) {
		hp++;
		continue;
	}
	if (!strcmp(hp->name, RF_OFRM)) {
		if (oldmailer == TRUE) {
			fprintf(fp, "%s%s\n", RF_OFRM, hp->field);
		}
	} else fprintf(fp, "%s %s\n", hp->name, hp->field);

	xp = hp->next;
	while (xp != NILHDR) {
		fprintf(fp, "%s %s\n", hp->name, xp->field);
		xp = xp->next;
	}
	hp++;
  }

  /* Then, dump all unknown fields. */
  hp++; hp = hp->next;
  while (hp != NILHDR) {
	if (hp->field == (char *)NULL) {
		hp = hp->next;
		continue;
	} else fprintf(fp, "%s %s\n", hp->name, hp->field);
	hp = hp->next;
  }

  /* Finish the header. */
  fprintf(fp, "\n");
}


/* Read and process the message header. Write a temporary message file. */
int hdr_inp(fp)
register FILE *fp;
{
  char buff[1024];
  int state;

  /* Now, go and fetch the incoming message header. */
  state = 0;
  while (state == 0) {
	(void) fgets(buff, 1024, fp);
	if (ferror(fp) || feof(fp)) state = 1;
	switch(state) {
		case 0:
			state = hdr_upd(buff);	/* add header line */
			break;
		case -1:
		case 1:
			break;
	}
  }
if (ferror(fp)) perror("INPUT DATA");
  if (state != 1) return(FALSE);

  /* Analyze the header. */
  state = hdr_chk();
  strcpy(mailuser, olduser);
  return(state);
}
