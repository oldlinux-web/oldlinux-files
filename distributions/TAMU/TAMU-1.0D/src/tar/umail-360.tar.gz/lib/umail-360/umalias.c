/*
 * UMAIL	MINIX Remote Domain-addressing Mail Router
 *		This file contains the routines to handle system-wide
 *		user aliasing.  The code was mostly taken from the
 *		W-MAIL package, by the same author.
 *
 * Author:	Fred N. van Kempen, MicroWalt Corporation
 */
#include <sys/types.h>
#include <string.h>
#include <stdio.h>
#include "umail.h"


char *exp_alias(name)
char *name;
{
#if HAVE_ALIASES
  static char buff[1024];
  register char *sp;
  register FILE *fp;

  if (aliases == (char *)NULL) return(name);
  if ((fp = fopen(aliases, "r")) == (FILE *)NULL) return(name);

  while (fgets(buff, 1024, fp) != (char *)NULL) {
	if ((sp = strrchr(buff, '\n')) != (char *)NULL) *sp = '\0';
	if ((sp = strchr(buff, '\t')) != (char *)NULL) *sp++ = '\0';
	if (!strcmp(buff, name)) {
		fclose(fp);
		return(sp);
	}
  }
  fclose(fp);
#endif
  return(name);
}
