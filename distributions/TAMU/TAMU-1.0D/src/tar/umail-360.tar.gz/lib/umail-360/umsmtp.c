/*
 * U-MAIL	MINIX Remote Domain-addressing Mail Router
 *		This file contains the implementation of the Simple Mail
 *		Transfer Protocol (SMTP) daemon for the MINIX AmoebaNET
 *		Network Software.
 *
 * Author:	Fred N. van Kempen, MicroWalt Corporation
 */
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pwd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdio.h>
#include "umail.h"

/* State machine constants. */
#define ST_STOPPED	0		/* we just quit the protocol	*/
#define ST_IDLE		1		/* waiting for HELO command	*/
#define ST_HELO		2		/* got HELO command		*/
#define ST_MAIL		3		/* got MAIL FROM: command	*/
#define ST_RCPT		4		/* got RCPT TO: command		*/
#define ST_DATA		5		/* got DATA command		*/


/* Forward declarations. */
void do_data(), do_expn(), do_helo(), do_help(), do_mail();
void do_noop(), do_quit(), do_rcpt(), do_rset(), do_send();
void do_soml(), do_saml(), do_turn(), do_vrfy();


static unsigned int mystate;		/* SMTP state machine		*/
static int nwfdin, nwfdout;		/* Network file descriptor(s)	*/
static FILE *nwfpin, *nwfpout;		/* Network file pointer(s)	*/
static struct cmdtable {
  char *name;
  void (*func)();
} cmdtable[] = {
  { "DATA",	do_data	}, { "EXPN",	do_expn	},
  { "HELO",	do_helo	}, { "HELP",	do_help	},
  { "MAIL",	do_mail	}, { "NOOP",	do_noop	},
  { "QUIT",	do_quit	}, { "RCPT",	do_rcpt	},
  { "RSET",	do_rset	}, { "SEND",	do_send	},
  { "SOML",	do_soml	}, { "SAML",	do_saml	},
  { "TURN",	do_turn	}, { "VRFY",	do_vrfy	},
  { (char *)NULL,	     do_quit		}
};


/*
 * Open a network connection to the machine with the name in the
 * argument (an ASCII string which holds the network name of the
 * machine we want to talk to).
 */
static int nopen(host, proto)
char *host;
char *proto;
{
#if 0
  HEADER head;
  int try, len;

  if (!netname(&head.h_port, host)) {
	fprintf(stderr, "connect: unknown host %s\n", host);
	return(-1);
  }
  head.h_command = NC_REQUEST;
  head.h_size = getservbyname(proto);
  try = 0;
  do {
	len = trans(&head, NILBUF, 0, &head, NILBUF, 0);
	if (len < 0) {
		sleep(1);
		try++;
	}
  } while (len < 0 && try < 5);
  if (try == 5) {
	fprintf(stderr, "connect: host is unreachable.\n");
	return(-2);
  }
  if (head.h_status != NE_OK) return(head.h_status);
  _An_Job = head.h_size;
  _An_Rpid = rx_tty(&head);
  _An_Spid = tx_tty(&head);
#else
  nwfdin = 0;
  nwfdout = 1;
#endif
  nwfpin = fdopen(nwfdin, "r");		/* streams are more efficient */
  nwfpout = fdopen(nwfdout, "w");
  return(TRUE);
}


/* Close a connection. */
static int nclose()
{
  fclose(nwfpout);
  fclose(nwfpin);
#if 0
  HEADER head;
  int try, len;

  head.h_command = NC_LOGOUT;
  head.h_size = job;
  try = 0;
  do {
	len = trans(&head, NILBUF, 0, &head, NILBUF, 0);
	if (len < 0) {
		sleep(1);
		try++;
	}
  } while (len < 0 && try < 5);
  if (try == 5) {
	fprintf(stderr, "netclose: host is unreachable.\n");
	return(-1);
  }
  if (pid > 0) kill(pid, SIGKILL);
#endif
  nwfdin = -1;
  nwfdout = -1;
  return(TRUE);
}


/* Perform a DATA operation. */
static void do_data(cmd)
char *cmd;
{
  char buff[MAXTEXT];
  FILE *fp;
  int st;
  time_t now;

  if (mystate != ST_RCPT) {
	fprintf(nwfpout,
		"%d You cannot give a DATA command right now.\n", RS_BAD_SEQ);
	return;
  }

  /* Create the temporary message file. */
  if ((fp = fopen(dfile, "w")) == (FILE *)NULL) {
	fprintf(nwfpout,
		"%d Error while creating file: %d\n", RS_ERR, errno);
	do_rset((char *)NULL);
	(void) unlink(dfile);
	return;
  }

  fprintf(nwfpout,
	"%d Enter text, enter with . on a blank line.\n", RS_DO_TEXT);
  mystate = ST_DATA;

  /* Parse incoming message header and create a new one. */
  if (hdr_inp(nwfpin) == TRUE) {

	/* Now create the new message. */
	hdr_out(fp);

	/* Read the rest of the message. */
	while (fgets(buff, MAXTEXT, nwfpin) != (char *)NULL) {
		if (strlen(buff) == 2 && buff[0] == '.') break;
		if (strncmp(buff, "From ", 5)) fprintf(fp, "%s", buff);
		  else fprintf(fp, "> %s", buff);
	};
	fprintf(fp, "\n");
	if (fclose(fp) != 0) {
		fprintf(nwfpout, "%d Error while closing temp file: %d\n",
							RS_ERR, errno);
		do_rset((char *)NULL);
		return;
	}

	/* Deliver the message. */
	st = sendit(mailaddr, mailhost, mailcmd, mailopts, dfile);
  }
  (void) unlink(dfile);

  if (st == 0) fprintf(nwfpout, "%d Sent.\n", RS_OK);
    else fprintf(nwfpout, "%d Delivery failed: %d\n", RS_ERR, st);

  mystate = ST_HELO;
}


/* Perform a EXPN operation. */
static void do_expn(cmd)
char *cmd;
{
  fprintf(nwfpout, "%d EXPN command not (yet) implemented.\n", RS_BAD_CMD);
}


/* Perform a HELO operation. */
static void do_helo(cmd)
char *cmd;
{
  if (mystate != ST_IDLE) {
	fprintf(nwfpout, "%d You already introduced yourself, <%s>!\n",
							RS_BAD_SEQ, sm_host);
	return;
  }

  (void) do_rset((char *)NULL);
  strncpy(sm_host, cmd, PATH_MAX -1);

  fprintf(nwfpout, "%d Hello <%s>, pleased to meet you.\n", RS_OK, sm_host);

  mystate = ST_HELO;
}


/* Perform a HELP operation. */
static void do_help(cmd)
char *cmd;
{
  fprintf(nwfpout,
	"%d-The following commands can be used:\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-DATA              - start DATA entry mode\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-EXPN              - expand a mailing list address\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-HELO myname       - tell me your name\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-HELP              - send this message\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-MAIL FROM: <user> - who is this from\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-NOOP              - no operation\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-QUIT              - close the connection\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-RCPT TO: <user>   - whom is it for\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-RSET              - reset the state machine\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-SAML              - send and mail a message\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-SAML              - send a message to a terminal\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-SOML              - send or mail a message\n", RS_UHELP);
  fprintf(nwfpout,
	"%d-TURN              - switch protocol roles\n", RS_UHELP);
  fprintf(nwfpout,
	"%d VRFY              - verify a mailbox or address\n", RS_UHELP);
}


/* Perform a MAIL operation. */
static void do_mail(cmd)
char *cmd;
{
  char buff[PATH_MAX];
  register char *sp, *bp;

  if (mystate != ST_HELO) {
	fprintf(nwfpout, "%d Please say HELO before sending mail.\n",
								RS_BAD_SEQ);
	return;
  }

  /* Check for the "MAIL From:" syntax. */
  bp = buff;
  sp = cmd;
  while (*sp && *sp != ' ' && *sp != '\t') {
	if (*sp >= 'a' && *sp <= 'z') *sp = *sp - 'a' + 'A';
	sp++;
  }
  if (*sp != '\0') *sp++ = '\0';
  if (strcmp(cmd, "FROM:")) {
	fprintf(nwfpout, "%d Missing FROM: - (partly) bad sender.\n", RS_SYN_PARM);
	return;
  }

  /* OK, now parse the address. */
  while (*sp == ' ' || *sp == '\t') sp++;
  if (*sp++ != '<') {
	fprintf(nwfpout, "%d Missing angle_bracket - (partly) bad sender.\n",
							RS_SYN_PARM);
	return;
  }

  /* Copy the address. */
  while (*sp && *sp != '>') *bp++ = *sp++;
  *bp++ = '\0';
  if (strchr(buff, '@') == (char *)NULL &&
      strchr(buff, '!') == (char *)NULL &&
      strchr(buff, '%') == (char *)NULL)
		sprintf(sm_from, "%s@%s", buff, sm_host);
    else strcpy(sm_from, buff);

  fprintf(nwfpout, "%d Sender <%s>: OK\n", RS_OK, sm_from);

  mystate = ST_MAIL;
}


/* Perform a NOOP operation. */
static void do_noop(cmd)
char *cmd;
{
  fprintf(nwfpout, "%d OK.\n", RS_OK);
}


/* Perform a QUIT operation. */
static void do_quit(cmd)
char *cmd;
{
  time_t now;

  (void) time(&now);
  fprintf(nwfpout, "%d Bye from %s.%s at %-24.24s\n",
		RS_BYE, myname, mydomain, ctime(&now));

  mystate = ST_STOPPED;
}


/* Perform an RCPT operation. */
static void do_rcpt(cmd)
char *cmd;
{
  char buff[PATH_MAX];
  char temp[PATH_MAX];
  register char *sp, *bp;
  register int i;

  if (mystate != ST_MAIL && mystate != ST_RCPT) {
	fprintf(nwfpout, "%d You cannot give a RCPT command right now.\n", RS_BAD_SEQ);
	return;
  }

  /* Check for the "RCPT To:" syntax. */
  bp = temp;
  sp = cmd;
  while (*sp && *sp != ' ' && *sp != '\t') {
	if (*sp >= 'a' && *sp <= 'z') *sp = *sp - 'a' + 'A';
	sp++;
  }
  if (*sp != '\0') *sp++ = '\0';
  if (strcmp(cmd, "TO:")) {
	fprintf(nwfpout,
		"%d Missing TO: - (partly) bad address.\n", RS_SYN_PARM);
	return;
  }

  /* OK, now parse the address. */
  while (*sp == ' ' || *sp == '\t') sp++;
  if (*sp++ != '<') {
	fprintf(nwfpout,
		"%d Missing angle_bracket - (partly) bad address.\n",
								RS_SYN_PARM);
	return;
  }

  /* Copy the address. */
  while (*sp && *sp != '>') *bp++ = *sp++;
  *bp++ = '\0';
  if (strchr(temp, '@') == (char *)NULL &&
      strchr(temp, '!') == (char *)NULL &&
      strchr(temp, '%') == (char *)NULL)
	sprintf(buff, "%s@%s.%s", temp, myname, mydomain);
    else strcpy(buff, temp);

  /* Try to convert the address. */
  if (convert(buff) == FALSE) {
	fprintf(nwfpout, "%d %s\n", RS_SYN_PARM, errmsg);
	return;
  } else if (route() == FALSE) {
	fprintf(nwfpout, "%d %s\n", RS_SYN_PARM, errmsg);
	return;
  }

  /* Add this recipient to the list. */
  if ((sp = (char *)malloc(strlen(buff) + 1)) == (char *)NULL) {
	fprintf(nwfpout, "%d Out of memory?\n", RS_TOO_LARGE);
	return;
  }
  i = 0;
  while (rcpt[i] != (char *)NULL) i++;
  rcpt[i] = sp;
  strcpy(rcpt[i], buff);
  
  fprintf(nwfpout, "%d Recipient <%s>: OK\n", RS_OK, rcpt[i]);

  mystate = ST_RCPT;
}


/* Perform an RSET operation. */
static void do_rset(cmd)
char *cmd;
{
  register int i;

  if (cmd != (char *)NULL) fprintf(nwfpout, "%d State Reset\n", RS_OK);

  /* Clear all buffers. */
  memset(sm_host, 0, PATH_MAX);
  memset(sm_from, 0, PATH_MAX);

  /* Clear the static recipientsstatic  list. */
  for (i = 0; i < MAXRCPT; i++) {
	if (rcpt[i] != (char *)NULL) free(rcpt[i]);
	rcpt[i] = (char *)NULL;
  }

  mystate = ST_IDLE;
}


/* Perform a SAML operation. */
static void do_saml(cmd)
char *cmd;
{
  fprintf(nwfpout, "%d SAML command not (yet) implemented.\n", RS_BAD_CMD);
}


/* Perform a SEND operation. */
static void do_send(cmd)
char *cmd;
{
  fprintf(nwfpout, "%d SEND command not (yet) implemented.\n", RS_BAD_CMD);
}


/* Perform a SOML operation. */
static void do_soml(cmd)
char *cmd;
{
  fprintf(nwfpout, "%d SOML command not (yet) implemented.\n", RS_BAD_CMD);
}


/* Perform a TURN operation. */
static void do_turn(cmd)
char *cmd;
{
  fprintf(nwfpout, "%d TURN command not (yet) implemented.\n", RS_BAD_CMD);
}


/* Perform a VRFY operation. */
static void do_vrfy(cmd)
char *cmd;
{
  char buff[MAXLINE];
  struct passwd *pw;
  register char *sp;

  sp = cmd;
  while (*sp == ' ' || *sp == '\t') sp++;
  if ((pw = getpwnam(sp)) == (struct passwd *)NULL) {
	fprintf(nwfpout, "%d Unknown user at %s\n", RS_NOACC, myname);
	return;
  }
  fprintf(nwfpout, "%d %s <%s@%s>\n",
		RS_OK, pw->pw_gecos, pw->pw_name, myname);
}


/* This is the main loop of the SMTP server. */
void smtpd()
{
  char buff[MAXLINE];
  time_t now;
  register struct cmdtable *cp;
  register char *sp, *bp;
  int st;

  mystate = ST_IDLE;
  protocol = "SMTP";
  if (nopen(myname, protocol) == FALSE) return;

  (void) time(&now);
  fprintf(nwfpout, "%d SMTP on %s.%s ready at %-24.24s\n",
			 RS_READY, myname, mydomain, ctime(&now));

  while(mystate != ST_STOPPED) {
	if (fgets(buff, MAXLINE, nwfpin) == (char *)NULL) {
		do_quit(buff);
		continue;
	}
	if ((sp = strchr(buff, '\n')) != (char *)NULL) *sp = '\0';
	sp = buff;
	while (*sp && *sp != ' ' && *sp != '\t') sp++;
	if (*sp != '\0') *sp++ = '\0';
	bp = buff;
	while (*bp != '\0') {
		if (*bp >= 'a' && *bp <= 'z') *bp = *bp - 'a' + 'A';
		bp++;
	}
	cp = &cmdtable[0];
	while (cp->name != (char *)NULL) {
		if (!strcmp(cp->name, buff)) break;
		cp++;
	}
	if (cp->name == (char *)NULL) {
		fprintf(nwfpout, "%d Unknown command: syntax error.\n",
								RS_SYNTAX);
		continue;
	}

	(*cp->func)(sp);
  }

  (void) nclose();
}


/************************************************************************
 *		    SMTP Client Processor Routines			*
 ************************************************************************/
/* This is the SMTP processor.  It calls another system. */
int smtp(host)
char *host;
{
  return(0);
}
