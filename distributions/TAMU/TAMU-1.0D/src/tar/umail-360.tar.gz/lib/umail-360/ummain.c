/*
 * UMAIL	MINIX Remote Domain-addressing Mail Router
 *		This version of RMAIL handles message-headers in a much
 *		more "standard" way. It can handle bang-addresses, plus
 *		the new-style Internet addressing (user@host.domain).
 *		It is called by programs as "Mail" and "uuxqt".
 *
 * Usage:	umail [-c <config>] [-d] [-i <infile>] [-n] [-v] addressee
 *
 * Version:	4.00(alpha)	03/29/91
 *
 * Author:	Fred N. van Kempen, MicroWalt Corporation
 */
#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#define EXTERN
#include "umail.h"


static NAME *namelist;			/* list of my network names	*/
static VAR *varlist;			/* list of config variables	*/
static HOST *hostlist;			/* list of reacheable hosts	*/
static ROUTE *routemap;			/* list of domain routes	*/


extern int getopt(), optind, opterr;	/* from standard library */
extern char *optarg;


/* Convert strings S to upper case. */
void strupr(to, from)
char *to;
char *from;
{
  register char *sp, *bp;

  sp = (from != (char *)NULL) ? from : to;
  bp = to;
  while (*sp) {
	if (islower(*sp)) *bp = *sp - 'a' + 'A';
	  else *bp = *sp;
  	sp++; bp++;
  }
  *bp = '\0';
}


/* Convert strings S to lower case. */
void strlwr(to, from)
char *to;
char *from;
{
  register char *sp, *bp;

  sp = (from != (char *)NULL) ? from : to;
  bp = to;
  while (*sp) {
	if (isupper(*sp)) *bp = *sp - 'A' + 'a';
	  else *bp = *sp;
  	sp++; bp++;
  }
  *bp = '\0';
}


/* Add 'name' to the list of our names. */
void add_name(name)
char *name;
{
  register NAME *np, *xp;

  np = (NAME *)malloc(sizeof(NAME));
  if (namelist != NILNAME) {
          xp = namelist;
          while (xp->next != NILNAME) xp = xp->next;
          xp->next = np;
  } else namelist = np;
  np->next = NILNAME;
  np->name = (char *)malloc(strlen(name) + 1);
  strcpy(np->name, name);
}


/* Add host 'name' to the list of hosts. */
void add_host(name, smart, cmd, opts)
char *name;
int smart;
char *cmd;
char *opts;
{
  register HOST *hp, *xp;

  hp = (HOST *)malloc(sizeof(HOST));
  if (hostlist != NILHOST) {
          xp = hostlist;
          while (xp->next != NILHOST) xp = xp->next;
          xp->next = hp;
  } else hostlist = hp;
  hp->next = NILHOST;
  hp->name = (char *)malloc(strlen(name) + 1);
  hp->command = (char *)malloc(strlen(cmd) + 1);
  hp->opts = (char *)malloc(strlen(opts) + 1);
  strcpy(hp->name, name);
  strcpy(hp->command, cmd);
  strcpy(hp->opts, opts);
  hp->smart = smart;
}


/* Add route 'domain' to the routing table. */
void add_route(dom, hst, newroute)
char *dom;
char *hst;
char *newroute;
{
  register ROUTE *rp, *xp;

  rp = (ROUTE *)malloc(sizeof(ROUTE));
  if (routemap != NILROUTE) {
          xp = routemap;
          while (xp->next != NILROUTE) xp = xp->next;
          xp->next = rp;
  } else routemap = rp;
  rp->next = NILROUTE;
  rp->domain = (char *)malloc(strlen(dom) + 1);
  rp->host = (char *)malloc(strlen(hst) + 1);
  rp->newroute = (char *)malloc(strlen(newroute) + 1);
  strcpy(rp->domain, dom);
  strcpy(rp->host, hst);
  strcpy(rp->newroute, newroute);
}


/* Add variable 'name' to the variable list. */
void add_var(name, val)
char *name;
char *val;
{
  register VAR *vp, *xp;

  strupr(name, (char *)NULL);
  vp = (VAR *)malloc(sizeof(VAR));
  if (varlist != NILVAR) {
          xp = varlist;
          while (xp->next != NILVAR) xp = xp->next;
          xp->next = vp;
  } else varlist = vp;
  vp->next = NILVAR;
  vp->name = (char *)malloc(strlen(name) + 1);
  vp->value = (char *)malloc(strlen(val) + 1);
  strcpy(vp->name, name);
  strcpy(vp->value, val);
}


/* Get a variable from the variable list. */
char *lookup(what)
char *what;
{
  register VAR *vp;

  vp = varlist;
  while (vp != NILVAR) {
    	if (!strcmp(vp->name, what)) return(vp->value);
    	vp = vp->next;
  }
  return((char *)NULL);
}


/* Get the value of a boolean variable. */
int boolean(ascii)
char *ascii;
{
  if (ascii == (char *)NULL) return(FALSE);

  strupr(ascii, (char *)NULL);
  if (!strcmp(ascii, "FALSE")) return(FALSE);
    else if (!strcmp(ascii, "TRUE")) return(TRUE);
           else fprintf(stderr, "Bad boolean value: \"%s\"\n", ascii);
  return(FALSE);
}


/* Lookup a host in our hosts-table. */
HOST *gethost(hst)
char *hst;
{
  register HOST *hp;

  hp = hostlist;
  while (hp != NILHOST) {
	if (!strcmp(hp->name, hst)) return(hp);
	hp = hp->next;
  }
  return(NILHOST);
}


/* Lookup a domain in our domain-table. */
ROUTE *getdomain(dom)
char *dom;
{
  char buff1[128], buff2[128];
  register ROUTE *rp;

  strupr(buff1, dom);
  rp = routemap;
  while (rp != NILROUTE) {
	strupr(buff2, rp->domain);
	if (!strcmp(buff1, buff2)) return(rp);
	rp = rp->next;
  }
  return(NILROUTE);
}


/* Check if this is one of our local names.  Return TRUE or FALSE. */
int islocal(name)
char *name;
{
  register NAME *np;

  np = namelist;
  while (np != NILNAME) {
	if (!strcmp(np->name, name)) return(TRUE);
	np = np->next;
  }
  return(FALSE);
}


/* Check if we may perform operation 'mode' on file 'name'. */
int allowed(name, mode)
char *name;
unsigned short mode;			/* mode to check (R=4, W=2, X=1) */
{
  char abuf[1024];
  struct stat stb;
  char *p;

  if (old_uid == 0) return(TRUE);

  if (stat(name, &stb) < 0) {
	if (errno == ENOENT) {
		strcpy(abuf, name);
		p = strrchr(abuf, '/');	
		if (p == (char *)NULL) getcwd(abuf, 1023);
		  else *p = '\0';
		if (stat(abuf, &stb) < 0) return(FALSE);
	} else return(FALSE);
  }

  /* We now have the status of the file or its parent dir. */
  if (stb.st_uid == old_uid) {
	if ((stb.st_mode >> 6) & mode) return(TRUE);
  	  else return(FALSE);
  } else if (stb.st_gid == old_gid) {
	if ((stb.st_mode >> 3) & mode) return(TRUE);
  	  else return(FALSE);
  } else if (stb.st_mode & mode) return(TRUE);
  return(FALSE);
}


/* Something went wrong.  Tell the caller how we should be called! */
static void usage()
{
  fprintf(stderr, "Usage: umail [-c <config>] [-d] [-i <infile>] [-n] ");
  fprintf(stderr, "[-v] addressee\n");
  exit(1);
}


int main(argc, argv)
int argc;
char *argv[];
{
  char buff[1024];
  FILE *infp, *ofp;
  register int st;
  char *cfgfile, *sp;

  namelist = NILNAME;
  varlist = NILVAR;
  hostlist = NILHOST;
  routemap = NILROUTE;
  strcpy(infile, "");
  cfgfile = CONFIG;
  opt_B = FALSE;

  old_uid = getuid();
  old_gid = getgid();

  opterr = 0;
  while ((st = getopt(argc, argv, "Bc:di:nv")) != EOF) switch(st) {
	case 'B':
		opt_B = TRUE;
		break;
	case 'c':
		cfgfile = optarg;
		break;
	case 'd':
	case 'v':
		debug = TRUE;
		break;
	case 'i':
		strncpy(infile, optarg, 128 - 1);
		if (allowed(infile, 04) == FALSE) {
			fprintf(stderr, "umail: no permission for \"%s\"\n", 
								infile);
			exit(1);
		}
		break;
	case 'n':
		immediate = TRUE;
		break;
	default:
		usage();
  }

  (void) umask(0117);			/* change umask to -rw-rw---- */

  setup(cfgfile);			/* read CONFIG and setup */

  strcpy(dfile, "/tmp/umXXXXXX"); mktemp(dfile);

  /* Setup a debug log file, if needed. */
  if (logfile != (char *)NULL) {
	logfp = fopen(logfile, "a");
	fprintf(logfp, "\n");
  } else logfp = (FILE *)NULL;

  /* If this is an SMTP session, things are different. */
  if (opt_B == TRUE) {	/* SMTP session */
	/* No more arguments allowed! */
	if (optind != argc) usage();
	smtpd();
	exit(0);
  }

  /* Look if this is an alias.  If so, expand it. */
  st = 0;
  while (optind < argc && st < MAXRCPT) {
	rcpt[st++] = exp_alias(argv[optind++]);
  }

  /* Convert addressee and route it to a host. */
  if ((st = convert(rcpt[0])) == TRUE) st = route();

  /* Set up an input file. */
  if (infile[0] != '\0') {
	if ((infp = fopen(infile, "r")) == (FILE *)NULL) {
		fprintf(stderr, "umail: cannot open input \"%s\"\n", infile);
		exit(1);
	}
  } else infp = stdin;

  /* Parse incoming message header and create a new one. */
  if (hdr_inp(infp) == TRUE) {
	if ((ofp = fopen(dfile, "w")) == (FILE *)NULL) {
		fprintf(stderr, "umail: cannot create(%s)\n", dfile);
		exit(1);
	}

	/* Now create the new message. */
	hdr_out(ofp);

	while (fgets(buff, sizeof(buff), infp) != (char *)NULL) {
		fwrite(buff, sizeof(char), strlen(buff), ofp);
	}
	if (infp != stdin) fclose(infp);
	fclose(ofp);
	if (st == FALSE) { 
		errmail(errmsg, "nix", FALSE);	/* address conversion error! */
		st = -1;
	} else st = sendit(mailaddr, mailhost, mailcmd, mailopts, dfile);
  }

  (void) unlink(dfile);
  exit(st);
}
