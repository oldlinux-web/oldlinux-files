/*
 * UMAIL	MINIX Remote Domain-addressing Mail Router
 *		This version of RMAIL handles message-headers in a much
 *		more "standard" way. It can handle bang-addresses, plus
 *		the new-style Internet addressing (user@host.domain).
 *		It is called by programs as "Mail" and "Uuxqt".
 *
 *		D E F I N I T I O N S
 *
 * Author:	Fred N. van Kempen, MicroWalt Corporation
 */

/* U-MAIL Feature Selection. */
#define HAVE_IMAIL	1	/* use "mail -i" (mailx) for local mail	*/
#define	HAVE_PATHALIAS	1	/* use the PathAlias database router	*/
#define HAVE_UUSERV	0	/* use the UUSERV Amoeba RPC server	*/
#define HAVE_ALIASES	1	/* use the ALIASES database support	*/
#define HAVE_SENDER	0	/* use the Sender: field code		*/

#define VERSION		"3.60-LUX"

/* Some RFC-821 defined constants. */
#define MAXRCPT		100		/* max. number of recipients	*/
#define MAXUSER		64		/* max. # of chr in username	*/
#define MAXDOMN		64		/* max. # of chr in domainname	*/
#define MAXPATH		256		/* max. # of chr in pathname	*/
#define MAXLINE		512		/* max. # of chr in line buffer	*/
#define MAXTEXT		1024		/* max. # of chr in DATA line	*/

/* SMTP protocol constants. */
#define RS_SHELP	211		/* system status		*/
#define RS_UHELP	214		/* user-aiding message		*/
#define RS_READY	220		/* service ready indicator	*/
#define RS_BYE		221		/* sevice closing indicator	*/
#define RS_OK		250		/* OK, complete, yes, etc	*/
#define RS_NTLOCL	251		/* user not local, will forward	*/
#define RS_DO_TEXT	354		/* "enter message" indicator	*/
#define RS_UNAVL	421		/* service not available:abort	*/
#define RS_NOMAIL	450		/* MAIL command failed,not found*/
#define RS_ERR		451		/* abort: error in processing	*/
#define RS_NOSPC	452		/* abort: out of system space	*/
#define RS_SYNTAX	500		/* syntax error, bad command	*/
#define RS_SYN_PARM	501		/* syntax error in parameters	*/
#define RS_BAD_CMD	502		/* command not implemented	*/
#define RS_BAD_SEQ	503		/* wrong command order		*/
#define RS_BAD_PARM	504		/* command parameter not impl.	*/
#define RS_NOACC	550		/* MAIL failed; no access	*/
#define RS_NOTRY	551		/* RCPT failed: try again	*/
#define RS_TOO_LARGE	552		/* storage allocation exceeded	*/
#define RS_NTALLWD	553		/* nameing error		*/
#define RS_FAIL		554		/* transaction failed		*/

#ifdef _MINIX
#	define CONFIG		"/usr/lib/umail/umail.cf"
#	define ADMIN		"/usr/lib/umail/umail.adm"
#	define ADMINLCK		"/usr/lib/umail/umail.alk"
#	define UUX		"/usr/bin/uux"
#	define LMAIL		"/usr/bin/lmail"
#	define RMAIL		"/usr/bin/rmail"
#	define SEQF		"/usr/lib/umail/MSEQ"
#	define SEQLCK		"/usr/lib/umail/LCK..MSEQ"
#	define UUCPUSER		"uucp"
#	define ERRUSER		"postmaster"
#endif

#ifdef _LINUX
#	define CONFIG		"/usr/lib/umail/umail.cf"
#	define ADMIN		"/usr/lib/umail/umail.adm"
#	define ADMINLCK		"/usr/lib/umail/umail.alk"
#	define UUX		"/usr/bin/uux"
#	define LMAIL		"/usr/bin/lmail"
#	define RMAIL		"/usr/bin/rmail"
#	define SEQF		"/usr/lib/umail/MSEQ"
#	define SEQLCK		"/usr/lib/umail/LCK..MSEQ"
#	define UUCPUSER		"uucp"
#	define ERRUSER		"postmaster"
#endif

#ifdef _UNIX
#	define CONFIG		"/usr/lib/smail/umail.cf"
#	define ADMIN		"/usr/lib/smail/umail.adm"
#	define ADMINLCK		"/usr/lib/smail/umail.alk"
#	define UUX		"/usr/bin/uux"
#	define LMAIL		"/usr/bin/lmail"
#	define RMAIL		"/usr/bin/rmail"
#	define SEQF		"/usr/lib/umail/MSEQ"
#	define SEQLCK		"/usr/lib/umail/LCK..MSEQ"
#	define UUCPUSER		"uucp"
#	define ERRUSER		"postmaster"
#endif

#define FALSE		0
#define TRUE		1

typedef struct __name {
  struct __name *next;
  char *name;
} NAME;
#define NILNAME      ((NAME *)NULL)

typedef struct __var {
  struct __var *next;
  char *name;
  char *value;
} VAR;
#define NILVAR        ((VAR *)NULL)

typedef struct __host {
  struct __host *next;
  char *name;
  int smart;
  char *command;
  char *opts;
} HOST;
#define NILHOST      ((HOST *)NULL)

typedef struct __routemap {
  struct __routemap *next;
  char *domain;
  char *host;
  char *newroute;
} ROUTE;
#define NILROUTE    ((ROUTE *)NULL)


#ifndef EXTERN
#	define	EXTERN	extern
#endif


/* Global variables. */
EXTERN char *Version;			/* UMAIL version ID		*/
EXTERN char *protocol;			/* transfer protocol used	*/
EXTERN int immediate, debug, opt_B;	/* commandline option flags	*/
EXTERN int old_uid, old_gid;		/* orig UID and GID of caller	*/
EXTERN FILE *logfp;			/* pointer to log file, if any	*/
EXTERN char errmsg[256];		/* global error message		*/

/* These should disappear from here. */
EXTERN char dfile[128], infile[128];	/* names of message temp-files	*/

/* These variables are used for address conversion. */
EXTERN int fromlocal, tolocal;		/* REMOTE/LOCAL flags		*/
EXTERN char mailuser[MAXUSER];		/* name of the (local) sender	*/
EXTERN char mailsender[MAXPATH];	/* who sent the message?	*/
EXTERN char mailaddr[1024];		/* final routed address to use. */
EXTERN char mailhost[MAXPATH];		/* which host to send to	*/
EXTERN char mailcmd[128];		/* cmd to use to send the mail	*/
EXTERN char mailopts[128];		/* which opts the mailer uses	*/
EXTERN char *rcpt[MAXRCPT];		/* list of recipients		*/
EXTERN char sm_host[MAXPATH];		/* SMTP remote host		*/
EXTERN char sm_from[MAXPATH];		/* SMTP remote from		*/

/* Configuration settings. */
EXTERN char *myname;			/* my UUCP site name		*/
EXTERN char *mydomain;			/* my UUCP domain name		*/
EXTERN char *myorg;			/* Name of my organization	*/
EXTERN char *mydept;			/* Name of my department	*/
EXTERN char *mytz;			/* my ARPANET Time Zone		*/
EXTERN char *logfile;			/* Path name of the log file	*/
EXTERN int oldmailer;			/* mailer uses old From-lines?	*/
EXTERN int sendfrom;			/* add "From user date"		*/
EXTERN int escape;			/* routing ESCAPE enable	*/
EXTERN int errcc;			/* send Postmaster a Cc: ???	*/
EXTERN int uudomain;			/* may we lookup domains in PA?	*/
EXTERN long noretsize;			/* size of max returned message	*/
#if HAVE_PATHALIAS
EXTERN char *netfile;			/* path name of umail.net	*/
#endif
#if HAVE_UUSERV
EXTERN char *uuserv;			/* port name of UUSERV server	*/
#endif
#if HAVE_ALIASES
EXTERN char *aliases;			/* path name of umail.alias	*/
#endif


/* Function Prototypes. */
#if _MINIX
#	include <ansi.h>
#else
#       define  _PROTOTYPE(function, params)    function params
#endif /* _MINIX */

_PROTOTYPE( void add_host, (char *name, int smart, char *cmd, char *opts) );
_PROTOTYPE( void add_name, (char *name) );
_PROTOTYPE( void add_route, (char *domain, char *host, char *route) );
_PROTOTYPE( void add_var, (char *name, char *val) );
_PROTOTYPE( char *ask_am_serv, (char *key, char *def) );
_PROTOTYPE( int boolean, (char *ascii) );
_PROTOTYPE( int convert, (char *adr) );
_PROTOTYPE( void errmail, (char *str, char *errs, int mgronly) );
_PROTOTYPE( char *exp_alias, (char *name) );
_PROTOTYPE( ROUTE *getdomain, (char *domain) );
_PROTOTYPE( HOST *gethost, (char *host) );
_PROTOTYPE( void hdr_out, (FILE *fp) );
_PROTOTYPE( int hdr_inp, (FILE *fp) );
_PROTOTYPE( int islocal, (char *name) );
_PROTOTYPE( char *lookup, (char *name) );
_PROTOTYPE( char *maketime, (time_t *salt) );
_PROTOTYPE( char *mesgid, (char *shortid) );
_PROTOTYPE( int route, (void) );
_PROTOTYPE( int scanner, (char *fname) );
_PROTOTYPE( int sendit, (char *who, char *host, char *cmd, char *opts, char *data) );
_PROTOTYPE( void setup, (char *cfgfile) );
_PROTOTYPE( char *shortid, (void) );
_PROTOTYPE( void strlwr, (char *to, char *from) );
_PROTOTYPE( void strupr, (char *to, char *from) );
_PROTOTYPE( struct tm *xltime, (time_t *pt) );
_PROTOTYPE( char *xtime, (time_t *salt) );
