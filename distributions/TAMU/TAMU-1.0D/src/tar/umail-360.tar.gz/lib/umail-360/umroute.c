/*
 * U-MAIL	MINIX Remote Domain-addressing Mail Router
 *
 *		This file handles all address conversions and message
 *		routing.  It can grow into a quite complex piece of
 *		software, if all is done well...
 *
 * Author:	Fred N. van Kempen, MicroWalt Corporation
 */
#include <sys/types.h>
#include <pwd.h>
#include <string.h>
#include <stdio.h>
#include "umail.h"


static char target[512];		/* what is the routing target?	*/
static char user[512], host[512];	/* what is the user/host name?	*/
static char domain[128];		/* what is the domain address?	*/
#if HAVE_PATHALIAS || HAVE_UUSERV
static ROUTE uu_route;			/* UUCP default route entry	*/
static char uu_buff[1024];		/* buffer for UUCP map entry	*/
#endif


/*
 * %-sign expansion.
 *
 * With this syntax, we can have the following situations:
 *
 *	user%anything
 *	host!user%anything
 *	anything%anything@domain
 *
 * We use the following rules when expanding:
 *
 *	(1) If any @ sign is present, do not expand.
 *	(2) If any host! prefix is present, do not expand.
 *	(3) If only one %, replace it with a @ sign.
 *	(4) If more than one % signs, only replace the rightmost one with @
 */
static void percent(name)
char *name;
{
  register char *sp, *bp;

  if (logfp) fprintf(logfp, "Percent: IN=%s ", name);
  if ((sp = strrchr(name, '%')) != (char *)NULL) {
	if (strchr(name, '@') == (char *)NULL) {
		if ((bp = strchr(name, '!')) != (char *)NULL) {
			if (sp < bp) *sp = '@';
		} else *sp = '@';
	}
  }
  if (logfp) fprintf(logfp, "OUT=%s\n", name);
}


/*
 * Create the target mail addresses.
 * This can be quite complicated, since many circumstances
 * do not allow the Internet (domain) addressing system.
 * Most notably, we have to use UUCP (bang) style if the
 * system is defined as "not smart", OR if we have a route
 * that contains a bang-notation....
 */
static void mk_addr(rp, hp)
register ROUTE *rp;
register HOST *hp;
{
  char buff[1024];
  char temp[512];

  if (logfp) fprintf(logfp, "SERVER=%s USER=%s HOST=%s DOM=%s ROUTE=%s ",
	hp->name, user, host, domain,
		(rp != NILROUTE) ? rp->newroute : "(NONE)");

  /* Do we have a domain or host name to work with? */
  if (domain[0] != '\0' || host[0] != '\0') {
	if (domain[0] != '\0' && host[0] != '\0') {
		sprintf(temp, "%s.%s", host, domain);
	} else {
		if (host[0] == '\0') strcpy(temp, domain);
		  else strcpy(temp, host);
	}
  } else {
	/* Nope.  Then check if we only have a user. */
	if (islocal(target)) strcpy(temp, user);
	  else strcpy(temp, target);
  }

  /* Do we have to make a bang address? */
  if ((rp != NILROUTE && strchr(rp->newroute, '!')) ||
      strchr(user, '!') || (hp->smart == FALSE)) {
	/* Yes, we need a full bang path... */
	if (rp != NILROUTE && *(rp->newroute) != '@') {
		sprintf(buff, rp->newroute, temp);
	} else strcpy(buff, temp);

	/* Now, add the user if not done before. */
	if (strcmp(temp, user)) sprintf(mailaddr, "%s!%s", buff, user);
	  else strcpy(mailaddr, buff);
  } else {
	/* No bang path required.  Use domain addressing! */
	if (rp != NILROUTE && *(rp->newroute) != '@') {
		sprintf(buff, temp, rp->newroute);
	} else strcpy(buff, temp);

	/* Now, add the user if not done before. */
	if (strcmp(temp, user)) sprintf(mailaddr, "%s@%s", user, buff);
	  else strcpy(mailaddr, buff);
  }
  if (logfp) fprintf(logfp, "ADDR=%s\n", mailaddr);
}


/*
 * Check if we can find `what' in the DOMAIN server table.
 * This is the fastest way of routing, since no other files
 * than the UMAIL config file need be searched...
 */
static ROUTE *chk_domain(what)
char *what;
{
  char buff[1024];
  register ROUTE *rp;
  register char *sp, *bp;

  /* Iterate on the target, and check the domain table. */
  strupr(buff, what);
  bp = buff;
  rp = NILROUTE;
  while (TRUE) {
	sp = bp;
	if ((rp = getdomain(bp)) != NILROUTE) break;
	if ((bp = strchr(sp, '.')) == (char *)NULL) break;
	  else bp++;
  }
  if (rp == NILROUTE) {
	if (logfp) fprintf(logfp, "No domain server for %s\n", what);
  } else {
	if (logfp) fprintf(logfp, "Domain server %s found for %s\n",
							rp->host, what);
  }
  return(rp);
}


/*
 * We now have checked the DOMAIN table for a matching domain, and failed
 * to find a matching domain entry.  We also were unable to find a matching
 * entry in the PATHALIAS database.  Finally, we were unable to find a local
 * UUCP connection for this target..  If the mailer was configured with the
 * ESCAPE parameter, we can try to route it to the default (".") domain.
 * Otherwise, we cannot deliver the message...
 */
static ROUTE *chk_default(what)
char *what;
{
  register ROUTE *rp;

  if (escape == FALSE) {
	sprintf(errmsg, "%s ... domain unknown", what);
	return(NILROUTE);
  }
  if ((rp = getdomain(".")) == NILROUTE) {
	sprintf(errmsg, "%s ... domain unreachable", what);
	return(NILROUTE);
  }
  return(rp);
}


/*
 * It is also possible to route messages to other systems using the UUCP
 * Maps.  To enable this, one must feed any maps of interest (preferrably
 * ALL maps) through the PathAlias program, which will create a file
 * containing (bang-style) addresses to all known UUCP systems "from here":
 *
 *	hostname <tab> foo!bar!bla!target!%s <newline>
 *
 * This routine scans the /usr/lib/uucp/umail.net file (which is a sorted
 * version of the PathAlias output) for an entry matching the argument. If
 * a match is found, it fakes a DOMAIN TABLE router for it, pointing to the
 * default host.
 */
static ROUTE *chk_dbase(what, uusys)
char *what;			/* what to search for */
int uusys;			/* are we looking for a system name? */
{
  char temp[128];
#if HAVE_PATHALIAS
  register FILE *fp;
#endif
  register char *sp;

  /* Create lookup key. */
  if (uusys == FALSE) {
	if (uudomain == FALSE) return(NILROUTE);
	sprintf(temp, ".%s", what);
  } else {
	if ((sp = strrchr(what, '.')) != (char *)NULL) {
		if (!strcmp(sp, ".UUCP") || !strcmp(sp, ".uucp")) *sp = '\0';
	}
	strcpy(temp, what);
  }

#if HAVE_UUSERV
  /* Ask the UUSERV NetFile server for this target. */
  sp = ask_am_serv(temp, uu_buff);
  if (sp == (char *)NULL) {
#endif
#if HAVE_PATHALIAS
	if (netfile == (char *)NULL) return(NILROUTE);  /* not enabled */
	if ((fp = fopen(netfile, "r")) == (FILE *)NULL) return(NILROUTE);
	while (fgets(uu_buff, 1024, fp) != (char *)NULL) {
		if ((sp = strrchr(uu_buff, '\n')) != (char *)NULL)
							*sp = '\0';
		if ((sp = strchr(uu_buff, '\t')) != (char *)NULL)
							*sp++ = '\0';
		if (!strcmp(uu_buff, temp)) break;
	}
	fclose(fp);
	if (strcmp(uu_buff, temp)) return(NILROUTE);
#endif
#if HAVE_UUSERV
  }
#endif
#if HAVE_PATHALIAS || HAVE_UUSERV
  /* We found a matching entry.  Fake a domain server. */
  uu_route.domain = uu_buff;		/* what were we looking for? */
  uu_route.host = sp;			/* what is the first hop? */
  if ((sp = strchr(uu_route.host, '!')) != (char *)NULL) *sp++ = '\0';
  uu_route.newroute = sp;		/* the bang-path */
  return(&uu_route);
#else
  return(NILROUTE);
#endif
}


/*
 * Convert address 'adr' into more manageable chunks.
 * Stuff the output into 'user', 'host', 'domain' and 'target'.
 * These variables are only used by the routing functions in this
 * file, so they are static to this file.
 * Return FALSE if an error ocurred.
 *
 * We understand the following notations:
 *
 *	1. user%host@somewhere	--> waltje%minixug@uunet.UU.NET
 *	2. user@host.domain	--> waltje@uwalt.nl.mugnet.org
 *	3. user@[host | domain]
 *	4. host!user		--> uwalt!waltje
 *	5. user			--> waltje
 */
int convert(name)
char *name;
{
  char temp[1024];
  register char *bp, *sp, *cp;
  register ROUTE *rp;
  register HOST *hp;

  /* Copy the addressee's name to 'mailaddr'. */
  strcpy(mailaddr, name);

  target[0] = '\0';
  domain[0] = '\0';
  host[0] = '\0';
  user[0] = '\0';
  temp[0] = '\0';

  /* Rule 1: Try to do %-sign expansion. */
  percent(mailaddr);

  /* Rule 2: Check for user@host.domain */
  if ((sp = strrchr(mailaddr, '@')) != (char *)NULL) {
	*sp++ = '\0';
	strcpy(user, mailaddr);
	strcpy(temp, sp);	
	if (logfp) fprintf(logfp, "Domain address found\n");

	/* Rule 3: Now check for "." in the domain part. */
	if ((sp = strchr(temp, '.')) == (char *)NULL) {
		strcpy(target, temp);
		domain[0] = '\0';
		host[0] = '\0';
		if (logfp) fprintf(logfp, "TARGET=%s\n", target);
		return(TRUE);
	} else {
		*sp++ = '\0';
		strcpy(host, temp);
		strcpy(domain, sp);
		strcpy(target, sp);
		if (logfp) fprintf(logfp, "TARGET=%s HOST=%s DOM=%s\n",
						target, host, domain);
		return(TRUE);
	}
  }

  /* Rule 4: Check for host!user */
  if ((sp = strchr(mailaddr, '!')) != (char *)NULL) {
	if (logfp) fprintf(logfp, "UUCP address found\n");
	*sp++ = '\0';
	strcpy(user, sp);
	strcpy(temp, mailaddr);	

	/* Now check for "." in the text. */
	if ((sp = strchr(temp, '.')) == (char *)NULL) {
		strcpy(target, temp);
		domain[0] = '\0';
		host[0] = '\0';
		if (logfp) fprintf(logfp, "TARGET=%s USER=%s\n",
							target, user);
		return(TRUE);
	} else {
		*sp++ = '\0';
		strcpy(host, temp);
		strcpy(domain, sp);
		strcpy(target, sp);
		if (logfp) fprintf(logfp,
			"TARGET=%s HOST=%s DOM=%s USER=%s\n",
					target, host, domain, user);
		return(TRUE);
	}

	/* No dot, so a simple UUCP address. */
	domain[0] = '\0';
	strcpy(host, temp);
	strcpy(target, temp);
	if (logfp) fprintf(logfp, "TARGET=%s HOST=%s USER=%s\n",
						target, host, user);
	return(TRUE);
  }

  /* Rule 5: Must be local user. */
  strlwr(user, mailaddr);
  strcpy(target, myname);
  host[0] = '\0';
  domain[0] = '\0';
  if (logfp) fprintf(logfp, "Local user %s found\n", user);
  return(TRUE);
}


/* Route the address in `target' into a ready-to-run UUCP address. */
int route()
{
  char buff[1024];
  char addr[1024];
  register ROUTE *rp;
  register HOST *hp;
  struct passwd *pw;
  int uusys = TRUE;

  if (logfp) fprintf(logfp, "Route(%s)\n", target);

  while (TRUE) {
	if (logfp) fprintf(logfp, "T=%s U=%s H=%s D=%s\n",
				target, user, host, domain);
	/*
	 * Rule 0: Clear out the pseudo-domain .UUCP
	 * We sometimes get addresses like user@host.UUCP , which are
	 * to be read as user@host or host!user .  So, we just simply
	 * get rid of this pseudo-domain here...
	 */
	if (!strcmp(domain, "uucp") || !strcmp(domain, "UUCP")) {
		domain[0] = '\0';
		strcpy(target, host);
		continue;
	}

	/*
	 * Rule 1: Check for local system names.
	 * We can also get addresses that match one of our own names.
	 * This can be the case in simple user names, or simple forms
	 * of our domain address.  Also, this can occur with incoming
	 * mail that specifies our system as part of the route.  In
	 * all cases, skip our local name and try to fetch the next
	 * target...
	 * First off, try to create a complete address.
	 */
	if (host[0] != '\0' && strcmp(target, host))
			sprintf(addr, "%s.%s", host, target);
	  else strcpy(addr, target);

	/*
	 * Now check to see if the current target matches one of our
	 * local names.  If so, take the next target and continue. If
	 * no next target exists (i.e. only a local user) then set up
	 * for local delivery.
	 */
  	if (islocal(addr)) {
		/* We have a local target.  Re-convert and continue. */
		if (logfp) fprintf(logfp, "Local name %s, continue for %s\n",
								addr, user);
		if (convert(user) == FALSE) return(FALSE);
		if (host[0] != '\0' && strcmp(target, host))
				sprintf(addr, "%s.%s", host, target);
		  else strcpy(addr, target);

		/* Is there any next target? */
		if (islocal(addr) &&
		    (strchr(user, '!') || strchr(user, '@') ||
						strchr(user, '%'))) {
			if (logfp) fprintf(logfp,
				"Local, continue for U=%s H=%s D=%s\n",
							user, host, domain);
			continue;
		} else {
			if (logfp) fprintf(logfp,
			    "Local, ADDR=%s next U=%s H=%s D=%s\n",
						addr, user, host, domain);
			if (islocal(addr)) {
				target[0] = '\0';
				host[0] = '\0';
				domain[0] = '\0';
			}
		}
  	}

  	/* Rule 2: Check for target validity. */
  	if (target[0] != '\0') {
		if (domain[0] != '\0' && !strcmp(target, domain))
							uusys = FALSE;

		/* Try to fit it into the domain server's table? */
		if ((rp = chk_domain(addr)) == NILROUTE) {
			/* Hmm.  A local UUCP system maybe? */
			if ((hp = gethost(addr)) == NILHOST) {
				if (logfp) fprintf(logfp,
					"No local host %s\n", addr);

				/* Nope. Check PathAlias netlist... */
				rp = chk_dbase(target, uusys);
				if (rp == NILROUTE) {
					if (logfp) fprintf(logfp,
						"No UUCP host %s(%d)\n",
							    target, uusys);
				} else {
					if (logfp) fprintf(logfp,
						"UUCP host %s found\n",
								addr);
				}
			} else {
				if (logfp) fprintf(logfp,
					"Local host %s found\n", addr);
			}
		} else hp = NILHOST;

		/* Try to get a host description for this. */
		if (rp != NILROUTE) {
			if ((hp = gethost(rp->host)) == NILHOST)
				if (logfp) fprintf(logfp,
					"Unreachable domain server %s\n",
								rp->host);
		} else {
			if (hp == NILHOST) hp = gethost(addr);
			if (hp == NILHOST)
				if (logfp) fprintf(logfp,
					"Unreachable host %s\n", addr);
		}

		/* Aiiii.... check for a nearby SmartHost! */
		if (hp == NILHOST) {
			if ((rp = chk_default(addr)) == NILROUTE) {
				if (logfp) fprintf(logfp, "No dflt host\n");
				sprintf(errmsg,
					"%s ... target unreachable", addr);
				return(FALSE);
			} else {
				if (logfp) fprintf(logfp,
					"Rerouted to dflt host %s\n",
								rp->host);
			}
			if ((hp = gethost(rp->host)) == NILHOST) {
				if (logfp) fprintf(logfp,
					"Dflt host %s for %s unreachable\n",
						rp->host, rp->domain);
				sprintf(errmsg,
					"%s ... default host unreachable",
								rp->host);
				return(FALSE);
			}
		}

		/*
	 	 * If *we* are the host, it must be the case of us acting as
		 * a domain server.  In this case, we may leave out the
		 * "domain" part of the address, and we can look at the
		 * address without the domain part attached.  Just reroute
		 * the message to the target system, as if it were being
		 * sent to that host directly.
	 	 */
		if (islocal(hp->name)) {
			if (logfp) fprintf(logfp,
				"I am domain server for .%s\n", domain);
			if ((hp = gethost(host)) == NILHOST) {
				if (logfp) fprintf(logfp,
					"Bad host %s in my domain\n", host);
				sprintf(errmsg,
					"%s ... host unknown in .%s\n",
							host, domain);
				return(FALSE);
			}
			strcpy(target, host);
			domain[0] = '\0';
			host[0] = '\0';
			addr[0] = '\0';
			if (logfp) fprintf(logfp,
				"Continue for target %s, U=%s\n",
							target, user);
			continue;
		}

		/* At this point we have all the information we need. */
		mk_addr(rp, hp);
		strcpy(host, hp->name);
		strcpy(mailcmd, hp->command);
		strcpy(mailopts, hp->opts);
		strcpy(mailhost, hp->name);
		tolocal = FALSE;
		if (logfp) fprintf(logfp, "HOST=%s CMD=%s OPTS=%s\n",
						mailhost, mailcmd, mailopts);
		return(TRUE);
  	}

  	/* Rule 4: Check for local users. */
  	if ((pw = getpwnam(user)) == (struct passwd *)NULL) {
		if (logfp) fprintf(logfp, "Unknown local user %s\n", user);
		sprintf(errmsg, "%s ... user unknown at %s.%s",
						user, myname, mydomain);
		return(FALSE);
  	}

	if ((hp = gethost(myname)) != NILHOST) {
		strcpy(mailaddr, user);
		host[0] = '\0';
		mailhost[0] = '\0';
		strcpy(mailcmd, hp->command);
		strcpy(mailopts, hp->opts);
		tolocal = TRUE;
		if (logfp) fprintf(logfp,
			"Set for local delivery to %s with %s (%s)\n",
						mailaddr, mailcmd, mailopts);
		return(TRUE);
	} else {
		sprintf(errmsg, "Cannot find my own name!");
		if (logfp) fprintf(logfp, "%s\n", errmsg);
		return(FALSE);
	}
  }
}
