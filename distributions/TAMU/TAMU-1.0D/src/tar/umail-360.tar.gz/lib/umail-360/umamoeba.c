/*
 * U-MAIL	MINIX Remote Domain-addressing Mail Router
 *		This file contains all the Amoeba RPC interfacing stuff.
 *		We need this for calling the Amoeba-based UUSERV UUCP
 *		name server.  Also, we might add hooks here to interface
 *		to SMTP-style network mail services...
 *
 * Author:	Fred N. van Kempen, MicroWalt Corporation
 */
#include <sys/types.h>
#include <pwd.h>
#include <string.h>
#include <stdio.h>
#include "umail.h"
#if HAVE_UUSERV
#include <amoeba.h>
#endif


/*
 * Since scanning the NETFILE each time takes lots of time, we can also use
 * the UUSERV UUCP MAP SERVER, which is a server based on the Amoeba RPC
 * Transaction system available in MINIX. This server is a highly optimized,
 * caching name server that is automatically maintained and updated by the
 * network. It may be trained for fast response to often-used system names.
 */
char *ask_am_serv(key, def)
char *key;			/* what to ask for */
char *def;			/* buff to use for definition */
{
#if HAVE_UUSERV
  header msg;
  register char *sp;
  int st;

  sp = (char *)NULL;

  /* Ask the UUSERV NetFile server for this target. */
  if (uuserv == (char *)NULL) return(sp);

  strncpy(&msg.h_port, uuserv, PORTSIZE);
  msg.h_command = 1;	/* == LOOKUP */
  msg.h_size = strlen(key);
  timeout(10);
  st = trans(&msg, key, strlen(key), &msg, def, 1024);
  if (st <= 0) return(sp);
  if (msg.h_status <= 0) return(sp);
  def[msg.h_size] = '\0';

  return(def);
#else
  return((char *)NULL);
#endif
}
