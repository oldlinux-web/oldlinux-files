#!/bin/sh

umask 022

if [ -e $BINROOTDIR/etc/ld.so.cache ] ; then
	echo Deleting old $BINROOTDIR/etc/ld.so.cache
	rm -f $BINROOTDIR/etc/ld.so.cache
fi

if [ ! -e $BINROOTDIR/etc/ld.so.conf ] ; then
	for dir in /usr/local/lib /usr/openwin/lib /usr/X386/lib ; do
		if [ -d $dir ] ; then
			echo Adding $dir to $BINROOTDIR/etc/ld.so.conf
			echo $dir >> $BINROOTDIR/etc/ld.so.conf
		fi
	done
fi

echo Installing ldd in $BINROOTDIR/usr/bin
install -c ldd $BINROOTDIR/usr/bin

if [ -e $BINROOTDIR/lib/ld.so ] ; then
	echo Backing up existing ld.so
	ln -f $BINROOTDIR/lib/ld.so $BINROOTDIR/lib/ld.so.old
fi
echo Installing ld.so in $BINROOTDIR/lib
install -c ld.so $BINROOTDIR/lib/ld.so.new
ln -f $BINROOTDIR/lib/ld.so.new $BINROOTDIR/lib/ld.so
rm $BINROOTDIR/lib/ld.so.new

if [ -d $BINROOTDIR/sbin ] ; then
	echo Installing ldconfig in $BINROOTDIR/sbin
	install -c ldconfig $BINROOTDIR/sbin
#	/sbin/ldconfig
else
	echo Installing ldconfig in /etc
	install -c ldconfig /etc
	/etc/ldconfig
fi

echo Installing libldso.a in $BINROOTDIR/usr/lib
install -c -m 644 libldso.a $BINROOTDIR/usr/lib

echo Installing manual pages in $BINROOTDIR/usr/man
install -c -m 644 ldd.1 $BINROOTDIR/usr/man/man1
install -c -m 644 ldconfig.8 ld.so.8 $BINROOTDIR/usr/man/man8

echo Installation complete
