#if 0
char dummy[1088*1024+ 64*1024]; /* make sure that the lower 1MB+64K is unused */
#else
char dummy[1088*1024+ 64*1024]; /* make sure that the lower 1MB+64K is unused */
#endif
#include <unistd.h>

int main(int argc, char **argv)
{

       int i;
       char *p;
	void (*dosemu)();

	if (uselib("/usr/X386/lib/X11/xdos/libxdosemu") != 0) {
		printf("cannot load shared lib\n");
		exit(1);
	}
	dosemu = (void *) LIBSTART;
	dosemu(argc, argv);
}
