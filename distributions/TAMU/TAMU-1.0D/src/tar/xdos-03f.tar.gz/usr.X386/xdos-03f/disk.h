#define FIVE_INCH_FLOPPY	2	/* 5.25 in, 1.2 MB floppy */
#define THREE_INCH_FLOPPY	4	/* 3.5 in, 1.44 MB floppy */

struct disk {
	char *dev_name;
	int rdonly;
	int sectors, heads, tracks;
	int default_cmos;
	int fdesc;
	int removeable;
	};

extern struct disk hdisktab[];
