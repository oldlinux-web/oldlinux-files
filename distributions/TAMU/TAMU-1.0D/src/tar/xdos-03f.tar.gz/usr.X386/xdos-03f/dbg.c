void d_printf()
{
}
void s_printf()
{
}
void R_printf()
{
}

extern int debug_out;

void dump_int_vect()
{ unsigned short *p;
  int i=0;

  p=0; 
    if(debug_out)
	for(i=0; i<0x40; i++) {
		printf("%4x:%4x|", *(p+1), *p);
		p+=2;
		if ((i%8)==7) puts("");
	}
}
