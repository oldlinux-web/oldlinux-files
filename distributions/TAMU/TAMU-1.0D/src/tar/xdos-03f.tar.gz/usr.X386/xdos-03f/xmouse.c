#include <linux/vm86.h>
#include <stdio.h>
#include "emu.h"
#include "xmouse.h"

us me_cs=0, me_ip=0;
us me_mask=0;
us mlx=0, mly=0;
int ret_imm=0, by_int16;
int mminx=0, mmaxx=0xffff, mminy=0, mmaxy=0xffff, mwidth, mheight;
extern int m_last_x, m_last_y; 
extern int press_count, button_state;
int po_last_call_x=0, po_last_call_y=0;
extern int po_x, po_y;
extern int mouse_x, mouse_y;
extern int scrollbar_width;
extern int enable_mouse_drv;
extern int dos_window_width, dos_window_height;

#define XM_SEN_X	4/5
#define XM_SEN_Y	2/5

#define M_X 640
#define M_Y 200

void x_mouse()
{  
	if (!enable_mouse_drv) return;

switch (_regs.eax & 0xffff) {
	case 0:
	case 0x21:
#if	1
		e_printf("mouse status %x %x\n", (int)_regs.cs, (int)_regs.eip);
/*		printf("%04x %04x %04x %04x\n",
			 _regs.eax,_regs.ebx, _regs.ecx,_regs.edx); */
/*		show_regs(); */
		_regs.eax=0xffff;  /* installed */
		_regs.ebx=3; /* 3 buttton */
		me_mask=0;
		return;
#endif
	case 1:
#if	0
		printf("mouse enable cursor display\n");
#endif	0
		return;
	case 2:
#if	0
		printf("mouse disable cursor display\n");
		return;
#endif	0
	case 3:
/* X11/X.h */
#define Button1Mask             (1<<8)
#define Button2Mask             (1<<9)
#define Button3Mask             (1<<10)

		if (button_state & Button1Mask ) _regs.eax=1;	/* l */
		else _regs.eax=0;
		if (button_state & Button3Mask ) _regs.eax|=2;  /* r */
		if (button_state & Button2Mask ) _regs.eax|=4;	/* m */
		_regs.ebx=press_count; press_count=0;
  _regs.ecx= ((mouse_x - scrollbar_width) * M_X / dos_window_width) ;
  if (_regs.ecx < mminx ) _regs.ecx=mminx;
  if (_regs.ecx > mmaxx ) _regs.ecx=mmaxx;
  _regs.edx= (mouse_y * M_Y / dos_window_height) ;
  if (_regs.edx < mminy ) _regs.edx=mminy;
  if (_regs.edx > mmaxy ) _regs.edx=mmaxy;
/*		printf("--- mouse 3\n"); */
		return;
	case 4:
		e_printf("mouse Set cursor location %x %x\n", _regs.ecx,_regs.edx);
		return;
	case 7:
		mminx=_regs.ecx;
		mmaxx=_regs.edx;
		mwidth=mmaxx;
		e_printf("mouse define x range %x %x\n",mminx,mmaxx);
		return;
	case 8:
		mminy=_regs.ecx;
		mmaxy=_regs.edx;
		mheight=mmaxy;
		e_printf("mouse define y range %x %x\n",mminy,mmaxy);
		return;
	case 9:
		e_printf("define graphic cursor\n");
		return;
	case 10:
		e_printf("define text cursor\n");
		return;
	case 11:
  _regs.ecx= ((mouse_x - scrollbar_width) * M_X / dos_window_width) ;
  if (_regs.ecx < mminx ) _regs.ecx=mminx;
  if (_regs.ecx > mmaxx ) _regs.ecx=mmaxx;
  _regs.edx= (mouse_y * M_Y / dos_window_height) ;
  if (_regs.edx < mminy ) _regs.edx=mminy;
  if (_regs.edx > mmaxy ) _regs.edx=mmaxy;
		e_printf("m 11  %d %d\n", _regs.ecx, _regs.edx);
		po_last_call_x = po_x;
		po_last_call_y = po_y;
		return;
	case 12:	/* set mouse event handler */
		if(debug_out)puts("set mouse event handler ---\n");
		e_printf("mouse mask: %x\n", _regs.ecx);
		show_regs();
		me_mask=_regs.ecx;
		me_ip=_regs.edx;
		me_cs=_regs.es;
		_regs.ecx=3;
		_regs.edx=0x247;
		return;
	case 15:
		e_printf("mouse define sensitivity\n");
		return;
	case 20:
		e_printf("Swap Event Handler Entry Location\n");
		return;
	case 21:
		e_printf("Get mouse state storage\n");
		return;
	case 22:
		e_printf("Save mouse state storage\n");
		return;
	case 23:
		e_printf("Restore mouse state storage\n");
		return;
	case 29:
		e_printf("set crt page\n");
		return;
	case 30:
		e_printf("set crt page\n");
		return;
	case 36: /* version num */
#if	1
		_regs.ebx=0x906;
		_regs.ecx=0x204;
#endif
		return;
	case 0x36:
		_regs.ebx=0;
		_regs.ecx=M_X;
		_regs.edx=M_Y;
	default:
		e_printf("---------- undefined mouse ax:%x bx:%x, cx:%x\n",
			_regs.eax, _regs.ebx, _regs.ecx);
		return;
}

	if (_regs.cs==0xe000) {
		us *ssp;

		ssp = SP_ADR;
		_regs.eip = *(ssp++);
		_regs.cs = *(ssp++);
		_regs.eflags = (_regs.eflags & 0xffff0000) | *(ssp++);
		_regs.esp += 6;
	}
}

char mouse_ver[256]={2,3,4,5,0x14,0x7,0x38,0x39,0x3a,0x3b,0x3c,0x3d,0x3e,0x3f};
void xmouse_int10()
{
  char *p=(char *)0xefe00;
  int i;
  FILE *fp;

  int fun=HI(ax);
  switch (fun) {
	case 0xfa:
		puts("int 10h: get mouse version");
		_regs.es=0xe000;
		_regs.ebx=XMOUSE_VER_ADDR;
#if	0
		if ((fp=fopen("amo.dat", "r"))==NULL) {
			puts("Unable to open amo.dat");
			return;
		}
		fread(p,1,256, fp);
		fclose(fp);
#else
		for (i=0; i<sizeof(mouse_ver); i++)
			*(p++)=mouse_ver[i];
#endif
		return;
	default:
		e_printf("undef mouse int10 %x", fun);
  }
}

void run_mouse_event(event)
int event;
{
  us *ssp;

  ssp =SEG_ADR((us *), ss, sp);

  *(--ssp) = _regs.cs;
  if (by_int16)
  *(--ssp) = _regs.eip-2;   /* so that it will run int 16 again */
  else
  *(--ssp) = _regs.eip;
  *(--ssp) = _regs.eflags;  /* don't use iret */
			    /* well, I forgot to save bp */
  *(--ssp) = _regs.eax;
  *(--ssp) = _regs.ebx;
  *(--ssp) = _regs.ecx;
  *(--ssp) = _regs.edx;
  *(--ssp) = _regs.esi;
  *(--ssp) = _regs.edi;
  *(--ssp) = _regs.ds;
  *(--ssp) = _regs.es;     
  *(--ssp) = 0xe000;
  *(--ssp) = XMOUSE_HANDLER1;
  
  _regs.eax=event;
  if (button_state & Button1Mask) _regs.ebx=1;
  else _regs.ebx=0;
  if (button_state & Button2Mask) _regs.ebx|=4;
  if (button_state & Button3Mask) _regs.ebx|=2;
  _regs.ecx= ((mouse_x - scrollbar_width) * M_X / dos_window_width) ;
  if (_regs.ecx < mminx ) _regs.ecx=mminx;
  if (_regs.ecx > mmaxx ) _regs.ecx=mmaxx;
  _regs.edx= (mouse_y * M_Y / dos_window_height) ;
  if (_regs.edx < mminy ) _regs.edx=mminy;
  if (_regs.edx > mmaxy ) _regs.edx=mmaxy;
  _regs.esi=(mouse_x - m_last_x) * M_X / dos_window_width;
  _regs.edi=(mouse_y - m_last_y) * M_Y / dos_window_height;
  _regs.esp -= 2*13;
  _regs.cs = me_cs;
  _regs.eip = me_ip;
#if	0
  printf("r m ev %d %d\n", _regs.ecx, _regs.edx);
#endif
  _regs.eflags &= 0xfffffcff;
  ret_imm=1;
}
