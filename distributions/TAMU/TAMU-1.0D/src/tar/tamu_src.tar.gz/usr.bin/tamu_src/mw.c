/* mw -  write multiple diskettes from stdin data
      - mw [-f] device size(in 1K blocks) "label"
          (-f forces a format for all diskettes, rather
          than the autodetect formatting)

   mw writes a 92 byte ascii label at the start of each diskette
   to help mr control/verify the reading process.

   This label consists of:
	char set_name[80];	 name of diskette set (null terminated)
	char disk_num[3];	 number of this diskette (%2d\0)
	char data_length[8];     length of data on this diskette (%7d\0)
	char more_disks[1];	 more disks? ('y'/'n')
 */

#include <stdio.h>
#include <string.h>
#ifdef SUN
#include <unistd.h>
#include <sys/fdio.h>
#endif

main(int argc, char **argv)
{
	FILE *fp,*tp;
	int i,n,fd,size,disk=1,doformat=0,done=0;
	char c,*buf,buf2[512],cmd[128];

	if ((argc !=5) && (argc !=4)) {
		fprintf(stderr,"usage: mr [-f] device size name\n");
		exit(1);
	}
	if (argc == 5) {
		if((argv[1][0] != '-')||(argv[1][1] != 'f')) {
			fprintf(stderr,"usage: mr [-f] device size name\n");
			exit(1);
		}
		else
			doformat = 1;
	}
	size = atoi(argv[2+doformat]);

	/* have to buffer up to a whole disk, so we can count
           the data bytes and write the number in the label */
	if ((buf  = (char *)malloc(size*1024)) == NULL) {
		fprintf(stderr,"not enough memory\n");
		exit(1);
	}

	if ((tp = fopen("/dev/tty","r")) == NULL) {
		fprintf(stderr,"can't open tty\n");
		exit(1);
	}
	sprintf(cmd,"fdformat %s",argv[1+doformat]);

	while(!done) {
		/* put label and data into buf */
		memset(buf,0,size*1024); 
		strncpy(buf,argv[3+doformat],80);
		sprintf(buf+80,"%2d",disk);
		if((n=fread(buf+92,1,((size*1024)-92),stdin))<((size*1024)-92)){
			done=1;
			buf[91] = 'n';
		}
		else
			buf[91] = 'y';
		sprintf(buf+83,"%7d",n);
#ifdef DEBUG
		fprintf(stderr,"name %s disk %d length %d more %c\n",
			buf, disk, n, buf[91]);
#endif
		n=(n+92+1023)/1024;

		for(;;) {
		    fprintf(stderr,"\007Insert disk %d and press enter: ",disk);
		    fflush(stderr);
		    c = getc(tp);
		    if(doformat) 
			system(cmd);
		    if((fp = fopen(argv[1+doformat],"r")) == NULL) {
			fprintf(stderr,"bad device 1 %s\n",argv[1+doformat]);
			continue;
		    }
		    if((i = fread(buf2,512,1,fp)) == 1) 
			fclose(fp);
		    else{
			fprintf(stderr,"hmm... trying a format\n",n);
			fclose(fp);
			system(cmd);
		    }
		    if((fp = fopen(argv[1+doformat],"w")) == NULL) {
			fprintf(stderr,"bad device 2 %s\n",argv[1+doformat]);
			continue;
		    }
		    if((i = fwrite(buf,1024,n,fp)) != n) {
			fprintf(stderr,"bad floppy on write %d %d\n",n,i);
#ifdef SUN
		        fd = fileno(fp);
	                ioctl(fd,FDEJECT);
#endif	
  		        continue;
		    }
#ifdef SUN
		    fd = fileno(fp);
	            ioctl(fd,FDEJECT);
#endif
		    fclose(fp);
		    break;
		}
		disk++;
	}
}
