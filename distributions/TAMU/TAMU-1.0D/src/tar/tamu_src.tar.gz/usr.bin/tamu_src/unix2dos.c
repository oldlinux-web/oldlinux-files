#include <stdio.h>
main()
{
	char c;
	while((c=getchar())!=EOF)
		if (c==10) {
			putchar(13);
			putchar(10);
		}
		else
			putchar(c);
}
