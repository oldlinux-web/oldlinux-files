/* label or unlabel -  write or read multiple diskettes or files  
                       to/from stdin data

   Revision history:
	version 1.0	- base release
	version 1.1	- added checking of header on unlabel
	version 2.0	- added checksums to header
	version 2.1	- used getopt for cleaner syntax, new options

   TAMU.99p14 is distributed in "labeled" diskette image format.
   The label is used to control the reassembly of the split
   data back into a stream for further uncompression and untarring,
   in a reliable, length controlled manner.  This program provides
   a method for manipulating labeled data in all of the six
   possible ways:
	
	unlabeled stdin   -> labeled stdout     ()
	unlabeled stdin   -> labeled diskettes  (-o /dev/rdiskette)
	unlabeled stdin   -> labeled files      (-o basename)
	labeled stdin     -> unlabeled stdout	(-u)
	labeled diskettes -> unlabeled stdout   (-u -i /dev/rdiskette)
	labeled files     -> unlabeled stdout   (-u -i basename)

   label uses a 98 byte ascii label at the start of each diskette/file
   to help control/verify the reading process.

   This label consists of:
	char set_name[80];	 name of diskette set (null terminated)
	char disk_num[3];	 number of this diskette (%2d\0)
	char data_length[8];     length of data on this diskette (%7d\0)
	char more_disks[1];	 more disks? ('y'/'n')
	char checksum[6];	 sysV checksum (%05d\0) of label + data with 
				 cksum field initialized to zeros

   Synopsis:
	label [-f] [-o name] [-s skip] [-c count] [-b blocks] [-l label]

	label  -u  [-i name] [-s skip] [-c count]

		(name is either a base filename or device (default "base"))
		(skip is the offset in bytes to start (default 0))
		(count is the length in bytes to read or write (unlimited))
		(blocks are integer number of 1K byte blocks (1440))

   Examples:
	label
		(read stdin, and output to labeled stdout)

	label -o source
		(read stdin, and output to labeled files source.01 ...)

	label -o /dev/rdiskette -f -l "Test Diskettes 01/01/94"
		(read stdin, and output to labeled diskettes, force format)

	label -u
		(read from labeled stdin, and output to unlabeled stdout)

	label -u -i /dev/rdiskette 
		(read labeled diskettes, and output unlabeled to stdout)

	label -u -i base
		(read files base.01 ..., and output unlabeled to stdout)

 */

/* options:
 * #define SUN   -> gives eject for floppy 
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifdef SUN
#include <unistd.h>
#include <sys/fdio.h>
#endif

main(int argc, char **argv)
{
	int skip=0,count=0,blocks=1440;
	int uflag=0,fflag=0,iflag=0,oflag=0,lflag=0,errflag=0;
	int sflag=0, cflag=0, bflag=0;
	char *fname = "base", *label = "NONAME";
	int c, isdevice=0;
	extern char *optarg;

	while((c = getopt(argc,argv,"ufi:o:s:c:b:l:")) != EOF) {
		switch(c) {
			case 'u':  	/* unlabel -> no fobl */
				if (fflag|oflag|bflag|lflag)
					usage();
				else
					uflag++;
				break;

			case 'f':	/* force format -> no ui */
				if(uflag|iflag)
					usage();
				else
					fflag++;
				break;

			case 'i': 	/* input file -> need u, no o */
				if(oflag)
					usage();
				else
					iflag++;
				fname = (char *)malloc(strlen(optarg));
				strcpy(fname,optarg);
				break;

			case 'o':	/* output file -> no ui*/
				if(uflag|iflag)
					usage();
				else
					oflag++;
				fname = (char *)malloc(strlen(optarg));
				strcpy(fname,optarg);
				break;

			case 's':	/* skip bytes */
				sflag++;
				skip = atoi(optarg);
				break;

			case 'c':	/* count bytes */
				cflag++;
				count = atoi(optarg);
				break;

			case 'b':	/* blocking factor -> no ui */
				if(uflag|iflag)
					usage();
				else
					bflag++;
				blocks = atoi(optarg);
				break;

			case 'l':	/* label -> no ui */
				if(uflag|iflag)
					usage();
				else
					lflag++;
				label = (char *)malloc(strlen(optarg));
				strcpy(label,optarg);
				break;

			case '?':
				errflag++;
		}

	}

	/* sanity check options -- label only from stdin */
	if (errflag || (iflag && !uflag))
		usage();

	/* if filename specified with -i or -o, is it a device? */
	if (iflag || oflag) {
		if (strncmp(fname,"/dev",4) == 0)
			isdevice = 1;
	} 

	/* payoff - check options, and call respective handler */	
	if (!uflag && !oflag) {
		/* unlabeled stdin -> labeled stdout */
		return(label_to_stdout(skip,count,blocks,label));
	}
	if (!uflag && oflag && isdevice) {
		/* unlabeled stdin -> labeled diskette */
		return(label_to_diskette(fflag,fname,skip,count,blocks,label));
	}
	if (!uflag && oflag && !isdevice) {
		/* unlabeled stdin -> labeled files */
		return(label_to_file(fname,skip,count,blocks,label));
	}
	if (uflag && !iflag) {
		/* read lableled stdin -> unlabeled stdout */
		return(unlable_from_stdin(skip,count));
	}
	if (uflag && iflag && isdevice) {
		/* read labeled diskettes -> unlabeled stdout */
		return(unlable_from_diskette(fname,skip,count));
	}
	if (uflag && iflag &&!isdevice) {
		/* read labeled files -> unlabeled stdout */
		return(unlabel_from_files(fname,skip,count));
	}

	/* oops should'nt get here */
	usage();
}

usage()
{
	printf("Usage:\n\t");
	printf("label [-f][-o name][-s skip][-c count][-b blocks][-l label]\n");
	printf("\tlabel -u  [-i name][-s skip][-c count]\n");
	exit(1);
}

unlable_from_stdin(int skip, int count)
{
	char buf[18*1024], label[98], set[80];
	int i, disk=1, ldisk, llength, tsum, sum = 0;

	if (skip || count) {
		printf("skip and count not implemented yet in this mode\n");
		exit(1);
	}

	for(;;) {
		fread(label,98,1,stdin);
		tsum = atoi(&label[92]);  /* get correct cksum */
		memset(&label[92],0,6);   /* zero it out */
		sum += cksum(label,98);   /* cksum label */
		ldisk=atoi(&label[80]);
		llength=atoi(&label[83]);
		if(disk!=ldisk) {
			fprintf(stderr,"Image %d out of order\n",ldisk);
			fflush(stderr);
			exit(1);
		}
		if (disk==1) {
			strncpy(set,label,80);
			fprintf(stderr,"Reading set %.50s\n",set);
			fflush(stderr);
		}
		else {
			if(strncmp(label,set,80)) {
				fprintf(stderr,"Wrong set %.50s\n",label);
				fflush(stderr);
				exit(1);
			}
	        }
		disk++;
	    	while(llength>0) {
		    i=fread(buf,1,(llength<18*1024?llength:18*1024),stdin);
		    llength -= i;
	            fwrite(buf,1,i,stdout);
		    sum += cksum(buf,i);
	    	}

	    	fflush(stdout);
		sum &= 0xffff;
		if (sum != tsum) {
			fprintf(stderr,"Bad checksum on image %d\n",disk-1);
			exit(1);
		}
		sum = 0;	
	    	if(label[91] == 'n')
			break;
	}
}

unlable_from_diskette(char *device, int skip, int count)
{
	FILE *fp;
	int fd, i, disk=1, ldisk, llength, sum = 0, tsum;
	char c, *buf, label[98], set[80];

	if (skip || count) {
		printf("skip and count not implemented yet in this mode\n");
		exit(1);
	}

	/* setup one track buffer */
	if ((buf  = (char *)malloc(18*1024)) == NULL) {
		fprintf(stderr,"not enough memory\n");
		exit(1);
	}
	for(;;) {
	    for(;;) {
		fflush(stdin);
		fprintf(stderr,"\007Insert disk %d and press enter: ",disk);
		fflush(stderr);
		c = getchar();

		if (c == 'q')
			exit(0);

		if((fp = fopen(device,"r")) == NULL) {
			fprintf(stderr,"error opening device, try again.\n");
			fflush(stderr);
			continue;
		}
		fd = fileno(fp);

		i = fread(label,98,1,fp);

		tsum = atoi(&label[92]);  /* get correct cksum */
		memset(&label[92],0,6);   /* zero it out */
		ldisk=atoi(&label[80]);
		llength=atoi(&label[83]);
		if((i != 1) || (disk!=ldisk)) {
			fprintf(stderr,"Wrong/bad disk (%d) inserted\n",ldisk);
			fflush(stderr);
#ifdef SUN
	    		ioctl(fd,FDEJECT);
#endif
			continue;
		}
		if (disk==1) {
			strncpy(set,label,80);
			fprintf(stderr,"Reading set %.50s\n",set);
			fflush(stderr);
		}
		else {
			if(strncmp(label,set,80)) {
				fprintf(stderr,"Wrong set %.50s\n",label);
				fflush(stderr);
#ifdef SUN
	    			ioctl(fd,FDEJECT);
#endif
				continue;
			}
	        }
		sum += cksum(label,98);   /* cksum label */
		disk++;
		break;
	    }
	    while(llength>0) {
		    i=fread(buf,1,(llength<18*1024?llength:18*1024),fp);
		    if (i != (llength<18*1024?llength:18*1024) ) {
			fprintf(stderr,"Bad read\n");
			exit(1);
		    }

		    llength -= i;
		    sum += cksum(buf,i);
	            fwrite(buf,1,i,stdout);
	    }
#ifdef SUN
	    ioctl(fd,FDEJECT);
#endif
	    fclose(fp);
	    fflush(stdout);
	    sum &= 0xffff;
	    if (sum != tsum) {
		fprintf(stderr,"Bad checksum on image %d\n",disk-1);
		exit(1);
	    }
	    if(label[91] == 'n')
		break;
	    sum = 0;
	}
}


label_to_file(char *base_name, int skip, int count, int size, char *label)
{
	FILE *fp;
	int i,n,disk=1,done=0;
	char *buf;

	if (skip || count) {
		printf("skip and count not implemented yet in this mode\n");
		exit(1);
	}

	/* have to buffer up to a whole disk, so we can count
           the data bytes and write the number in the label */
	if ((buf  = (char *)malloc(size*1024)) == NULL) {
		fprintf(stderr,"not enough memory\n");
		exit(1);
	}

	while(!done) {
		/* put label and data into buf */
		memset(buf,0,size*1024); 
		strncpy(buf,label,80);
		sprintf(buf+80,"%2d",disk);
		if((n=fread(buf+98,1,((size*1024)-98),stdin))<((size*1024)-98)){
			done=1;
			buf[91] = 'n';
		}
		else
			buf[91] = 'y';
		sprintf(buf+83,"%7d",n);
		sprintf(buf+92,"%5d",cksum(buf,n+98)&0xffff);
		n=(n+98+1023)/1024;

		{
		    char fn[100];
		    sprintf(fn,"%s.%02d",base_name,disk);	
		    if((fp = fopen(fn,"w")) == NULL) {
			fprintf(stderr,"bad open\n");
		    }
		    if((i = fwrite(buf,1024,n,fp)) != n) {
			fprintf(stderr,"bad write\n");
		    }
		    fclose(fp);
		}
		disk++;
	}
}


label_to_diskette(int doformat, char *device, int skip, int count, 
		  int size, char *label)
{

	FILE *fp,*tp;
	int i,n,fd,disk=1,done=0;
	char c,*buf,buf2[512],cmd[128],ecmd[128];

	if (skip || count) {
		printf("skip and count not implemented yet in this mode\n");
		exit(1);
	}

	/* have to buffer up to a whole disk, so we can count
           the data bytes and write the number in the label */
	if ((buf  = (char *)malloc(size*1024)) == NULL) {
		fprintf(stderr,"not enough memory\n");
		exit(1);
	}

	if ((tp = fopen("/dev/tty","r")) == NULL) {
		fprintf(stderr,"can't open tty\n");
		exit(1);
	}
#ifndef SUN
	sprintf(cmd,"fdformat %s",device);
#else
	sprintf(ecmd,"eject %s",device);
	sprintf(cmd,"fdformat -f %s",device);
#endif

	while(!done) {
		/* put label and data into buf */
		memset(buf,0,size*1024); 
		strncpy(buf,label,80);
		sprintf(buf+80,"%2d",disk);
		if((n=fread(buf+98,1,((size*1024)-98),stdin))<((size*1024)-98)){
			done=1;
			buf[91] = 'n';
		}
		else
			buf[91] = 'y';
		sprintf(buf+83,"%7d",n);
		sprintf(buf+92,"%5d",cksum(buf,n+98)&0xffff);
		n=(n+98+1023)/1024;

		for(;;) {
		    fflush(tp);
		    fprintf(stderr,"\007Insert disk %d and press enter: ",disk);
		    fflush(stderr);
		    c = getc(tp);
		    if(doformat) 
			system(cmd);
		    if((fp = fopen(device,"r")) == NULL) {
			fprintf(stderr,"bad device 1 %s\n",device);
#ifdef SUN
			system(ecmd);
#endif
			continue;
		    }
		    if((i = fread(buf2,512,1,fp)) == 1) 
			fclose(fp);
		    else{
			fprintf(stderr,"hmm... trying a format\n");
			fclose(fp);
			system(cmd);
		    }
		    if((fp = fopen(device,"w")) == NULL) {
			fprintf(stderr,"bad device 2 %s\n",device);
#ifdef SUN
			system(ecmd);
#endif
			continue;
		    }
		    if((i = fwrite(buf,1024,n,fp)) != n) {
			fprintf(stderr,"bad floppy on write %d %d\n",n,i);
#ifdef SUN
		        fd = fileno(fp);
	                ioctl(fd,FDEJECT);
#endif	
			fclose(fp);
  		        continue;
		    }

		    /* !!!! add read verify !!!!! */

#ifdef SUN
		    fd = fileno(fp);
	            ioctl(fd,FDEJECT);
#endif
		    fclose(fp);
		    break;
		}
		disk++;
	}
}

label_to_stdout(int skip, int count, int blocks, char *label)
{
	fprintf(stderr,"label_to_stdout not implemented yet\n");
}

unlabel_from_files(char *fname, int skip, int count)
{
	fprintf(stderr,"unlabel_from_files not implemented yet\n");
}

int cksum(char *buf, int length)
{
	int sum=0,i;

	for (i=0;i<length;i++)
		sum += buf[i];
	return (sum);
}
