/* mr - read multiple diskettes and cat to stdout
      - mr device 

mr uses a 92 byte ascii label at the start of each diskette
to control/verify the reading process.

This label consists of:
	char set_name[80];	 name of diskette set (null terminated)
	char disk_num[3];	 number of this diskette (%2d\0)
	char data_length[8];     length of data on this diskette (%7d\0)
	char more_disks[1];	 more disks? ('y'/'n')

 */

#include <stdio.h>
#include <string.h>
#ifdef SUN
#include <unistd.h>
#include <sys/fdio.h>
#endif

main(int argc, char **argv)
{
	FILE *fp;
	int fd, i, disk=1, ldisk, llength;
	char c, *buf, label[90], set[80];

	if (argc !=2) {
		fprintf(stderr,"usage: mr device\n");
		exit(1);
	}
	/* setup one track buffer */
	if ((buf  = (char *)malloc(18*1024)) == NULL) {
		fprintf(stderr,"not enough memory\n");
		exit(1);
	}
	for(;;) {
	    for(;;) {
		fflush(stdin);
		fprintf(stderr,"\007Insert disk %d and press enter: ",disk);
		fflush(stderr);
		c = getchar();
		if((fp = fopen(argv[1],"r")) == NULL) {
			fprintf(stderr,"error opening device, try again.\n");
			fflush(stderr);
			continue;
		}
		fd = fileno(fp);
		fread(label,92,1,fp);
		ldisk=atoi(&label[80]);
		llength=atoi(&label[83]);
		if(disk!=ldisk) {
			fprintf(stderr,"Wrong disk (%d) inserted\n",ldisk);
			fflush(stderr);
#ifdef SUN
	    		ioctl(fd,FDEJECT);
#endif
			continue;
		}
		if (disk==1) {
			strncpy(set,label,80);
			fprintf(stderr,"Reading set %.40s\n",set);
			fflush(stderr);
		}
		else {
			if(strncmp(label,set,80)) {
				fprintf(stderr,"Wrong set %.40s\n",label);
				fflush(stderr);
#ifdef SUN
	    			ioctl(fd,FDEJECT);
#endif
				continue;
			}
	        }
#ifdef DEBUG
		fprintf(stderr,"disk %d length %d more %c\n",
			ldisk, llength, label[91]);
		fflush(stderr);
#endif
		disk++;
		break;
	    }
	    while(llength>0) {
		    i=fread(buf,1,(llength<18*1024?llength:18*1024),fp);
#ifdef DEBUG
		    fprintf(stderr,"llength %d read %d\n",llength,i);
#endif
		    llength -= i;
	            fwrite(buf,1,i,stdout);
	    }
#ifdef SUN
	    ioctl(fd,FDEJECT);
#endif
	    fclose(fp);
	    fflush(stdout);
	    if(label[91] == 'n')
		break;
	}
}
