#! /bin/sh
# mkpdir dir ... - make directory and parents

status=0
for dir
do
	mkdir "$dir" 2>/dev/null
	if test ! -d "$dir"; then
		mkpdir.sh "`echo $dir | sed 's/\/[^\/]*$//'`"
		mkdir "$dir"
		if test ! -d "$dir"; then
			status=1
		fi
	fi
done
exit $status
