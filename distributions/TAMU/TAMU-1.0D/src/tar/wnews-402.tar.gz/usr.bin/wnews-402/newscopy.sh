cp checknews /usr/lib/news
cp control /usr/lib/news
cp expire /usr/lib/news
cp inews /usr/lib/news
cp pnews /usr/lib/news
cp rnews /usr/lib/news
cp sendbatch /usr/lib/news
cp unbatch /usr/lib/news
cp wnbill /usr/lib/news
cp newspace /usr/lib/news
exit 0
