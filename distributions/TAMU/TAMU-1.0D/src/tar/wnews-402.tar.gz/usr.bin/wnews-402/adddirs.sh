#! /bin/sh
# adddirs - add any directories needed for newsgroups in active file

for dir in `awk '$4 !~ /^[x=]/ { print $1 }' ./active | tr . /`
do
	if test ! -d /usr/spool/news/$dir
	then
		echo "making $dir (and parents if needed...)"
		mkpdir.sh /usr/spool/news/$dir
	fi
done
