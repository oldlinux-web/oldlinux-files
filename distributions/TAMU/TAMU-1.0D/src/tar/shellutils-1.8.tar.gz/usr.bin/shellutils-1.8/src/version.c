/* Make the binaries identifiable with the RCS ident command.  */
char *version_string = "\n$Version: GNU shellutils 1.8 $\n";
