#ifndef _ASM_IOW_H
#define _ASM_IOW_H

/* no longer used */

#endif
