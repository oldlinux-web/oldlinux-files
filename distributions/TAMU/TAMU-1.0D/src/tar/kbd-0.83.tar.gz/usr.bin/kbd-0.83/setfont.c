/*
 * setfont.c - Eugene Crosser & aeb
 *
 */
#include <stdio.h>
#include <memory.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/kd.h>

char *progname;

void usage(void)
{
        fprintf(stderr, "\
usage:  %s newfont [-o oldfont]
or:     %s -o oldfont [newfont]
", progname, progname);
	exit(1);
}

int main(int argc, char *argv[])
{
	FILE *fpi, *fpo;
	struct stat stbuf;
	char buf[8192];
	char *ifil, *ofil;
	int i, unit, hdr, size;

	progname = argv[0];

	ifil = ofil = 0;

	for (i = 1; i < argc; i++) {
	    if (!strcmp(argv[i], "-o")) {
		if (++i == argc || ofil)
		  usage();
		ofil = argv[i];
	    } else {
		if (ifil)
		  usage();
		ifil = argv[i];
	    }
	}

	if (!ifil && !ofil) /* maybe reset to some default? */
	    usage();

	if (ofil) {
	        if((fpo = fopen(ofil, "w")) == NULL) {
		    perror(ofil);
		    exit(1);
		}
		i = ioctl(0,GIO_FONT,buf);
		if (i) {
		    perror("GIO_FONT ioctl error");
		    return(i);
		}

		/* save as efficiently as possible */
		for (unit = 32; unit > 0; unit--)
		    for (i = 0; i < 256; i++)
		      if (buf[32*i+unit-1])
			goto nonzero;
	      nonzero:
		if (unit == 0)
		    fprintf(stderr, "Found nothing to save\n");
		else {
		    for (i = 0; i < 256; i++)
		      if (fwrite(buf+(32*i), unit, 1, fpo) != 1) {
			  perror("Cannot write font file");
			  exit(1);
		      }
		    printf("Saved 8x%d font file on %s\n", unit, ofil);
		}
		fclose(fpo);
	}

	if (ifil) {
		if (stat(ifil, &stbuf)) {
		    perror("Cannot stat input font file");
		    exit(1);
		}
		if ((fpi = fopen(ifil,"r")) == NULL) {
		    perror("Cannot open input font file");
		    exit(1);
		}
		size = stbuf.st_size;
		hdr = (size & 0377);
		unit = (size - hdr)/256;

		if (hdr == 4) {
		    char psfhdr[4];
		    if (fread(psfhdr, 4, 1, fpi) != 1) {
			perror("Error reading header input font");
			exit(1);
		    }
		    /* note: this depends on endianness */
		    if (psfhdr[1] != 0x04 || psfhdr[0] != 0x36) {
			fprintf(stderr, "Unrecognized font format\n");
			exit(1);
		    }
		    if (psfhdr[2] != 0) {
			fprintf(stderr, "Unsupported psf file mode\n");
			exit(1);
		    }
		    if(size != hdr + 256*psfhdr[3]) {
			fprintf(stderr, "Input file: bad length\n");
			exit(1);
		    }
		}

		if ((hdr != 0 && hdr != 4) || unit < 1 || unit > 32) {
		    fprintf(stderr, "Bad input file size\n");
		    exit(1);
		}

		memset(buf,0,sizeof(buf));

		for (i = 0; i < 256; i++)
		  if (fread(buf+(32*i), unit, 1, fpi) != 1) {
		      perror("Cannot read font from file");
		      exit(1);
		  }
		fclose(fpi);

		printf("Loading 8x%d font from file %s\n", unit, ifil);

		i = ioctl(0,PIO_FONT,buf);
		if (i) {
		    perror("PIO_FONT ioctl error");
		    exit(i);
		}
	}

	return(0);
}
