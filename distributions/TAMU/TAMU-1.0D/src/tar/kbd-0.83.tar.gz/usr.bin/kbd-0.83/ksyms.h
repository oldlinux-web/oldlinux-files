typedef struct {
	char **table;
	int size;
} syms_entry;

extern syms_entry syms[];

extern const int syms_size;

extern int syms_iso8859(int i);

/* this is a temporary ugly kludge */

extern char *latin2_syms[];
extern char *latin3_syms[];
extern char *latin4_syms[];

