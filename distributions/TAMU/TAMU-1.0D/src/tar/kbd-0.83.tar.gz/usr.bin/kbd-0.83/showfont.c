/* showfont.c - aeb, 940131 */
#include <stdio.h>

main ()
{
  unsigned char i, j, k;

  /* first select null translation */
  printf("\033(U");

  /* show font */
  printf("\n");
  for (i = 0; i < 16; i++) {
      for (j = 0; j < 16; j++) {
	  k = 16*j + i;
	  if (k == 010 || k == 012 || k == 014 || k == 015 ||
	      k == 016 || k == 017 || k == 033 || k == 0)
	    k = ' ';
	  printf ("%c  ", k);
      }
      printf ("\n");
  }
  printf ("\n");

  /* and return to usual translation */
  printf("\033(B");
}
