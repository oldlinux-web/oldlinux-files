#include <stdio.h>
#include <memory.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/kd.h>

static int parsemap (FILE *, char*);
static int ctoi (char *);

int main(argc,argv)
int argc;
char *argv[];
{
	FILE *fp;
	struct stat stbuf;
	char buf[256];
	int i;

	if (argc < 2)
	{
		fprintf(stderr,"usage: %s map-file\n",argv[0]);
		exit(1);
	}
	if (stat(argv[1],&stbuf))
	{
		perror("Cannot stat map file");
		exit(1);
	}
	if ((fp=fopen(argv[1],"r")) == NULL)
	{
		perror("Cannot open map file");
		exit(1);
	}
	if (stbuf.st_size != E_TABSZ)
	{
		printf("Loading symbolic screen map from file %s\n",argv[1]);

		for (i=0;i<156;i++) buf[i]=i;
		if (parsemap(fp,buf))
		{
			fprintf(stderr,"Error parsing symbolic map\n");
			exit(1);
		}
	}
	else
	{
		printf("Loading binary screen map from file %s\n",argv[1]);

		if (fread(buf,E_TABSZ,1,fp) != 1)
		{
			perror("Cannot read map from file");
			exit(1);
		}
	}
	fclose(fp);

	memset(buf,0,32); /* don't redefine control characters */

	i=ioctl(0,PIO_SCRNMAP,buf);

	if (i) perror("PIO_SCRNMAP ioctl error");
	else printf("\033(K"); /* switch G0 to new map */

	return(i);
}

static int parsemap(fp,buf)
FILE *fp;
char buf[];
{
  char buffer[256];
  int in,on;
  char *p,*q;

  for (in=0;in<256;in++) buf[in]=in;

  while (fgets(buffer,sizeof(buffer)-1,fp))
    {
      p=strtok(buffer," \t\n#");
      q=strtok(NULL," \t\n#");
      if (p && q)
	{
	  in=ctoi(p);
	  on=ctoi(q);
	  if (in && on) buf[in]=on;
	}
    }
  return(0);
}

int ctoi(s)
char *s;
{
  int i;

  if ((strncmp(s,"0x",2) == 0) && 
      (strspn(s+2,"0123456789abcdefABCDEF") == strlen(s+2)))
    sscanf(s+2,"%x",&i);

  else if ((*s == '0') &&
	   (strspn(s,"01234567") == strlen(s)))
    sscanf(s,"%o",&i);

  else if (strspn(s,"0123456789") == strlen(s)) 
    sscanf(s,"%d",&i);

  else if ((strlen(s) == 3) && (s[0] == '\'') && (s[2] == '\''))
    i=s[1];

  else i=0;

  return(i);
}
