/* vgaset.c: set VGA registers for X server.
 * Greg Lehey, 9 October 1992 */
/* Copyright 1992 LEMIS, Schellnhausen 2, W-6324 Feldatal, Germany
 * Telephone +49-6637-1488, fax +49-6637-1489
 * This software may be used for noncommercial purposes provided that this copyright notice
 * is not removed. Contact lemis (lemis%lemis@@germany.eu.net or lemis@@lemis.de) for
 * permission to distribute or use for commercial purposes.
 */
/* Modified 26 March 93, by Bill C. Riemers to print correct vertical values for ATI */
/* Modified 03 April 93, by Bill C. Riemers to make less dangerous. */
#include <ctype.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/errno.h>
#include <termios.h>
#include "svga.h"
#define INLINE inline

float dotclock = 0, hmin = -1, hmax = -1, vmin = -1, vmax = -1, horfreq = 0, verfreq = 0;
char *crtc_reg_name [] =
{
  "HT", "HDE", "SHB", "EHB", "SHR", "EHR", "VT", "OVERFLOW", "PRS",
  "MSL", "CS", "CE", "SAH", "SAL", "CLH", "CLL", "VRS", "EVR", "VDE",
  "OFF", "UL", "VBS", "VBE", "Mode Control", "LC"
};

/* These are the ``real'' values of the registers. They need to be collected from the
 * VGA registers or scattered to them */
struct crtc_regs
{
  short int hde,					/* horizontal display end */
  shr,					    /* start of horizontal retrace */
  ehr,					    /* end of horizontal retrace */
  ht,						    /* horizontal total */
  vde,					    /* vertical display end */
  vbs,					    /* vertical blanking start */
  vbe,					    /* vertical blanking end */
  vrs,					    /* vertical retrace start */
  evr,					    /* end of vertical retrace */
  vt,						    /* vertical total */
  overflow,					    /* overflow register */
  msl;					    /* and maximum scan line reg */
}
current_regs,
saved_regs,
actual_regs;

int verbose = 0;					 /* set to show more info */
int restore = 0;                     /* flag when restoring saved values */
short int active_hde = 0,            /* reset active horizontal resolution */
active_vde = 0,                 /* reset active vertical resolution */
virtual_hde = 0,                /* reset virtual horizontal resolution */
virtual_vde = 0,                /* reset virtual vertical resolution */
vertical_shift = 1;             /* shift from virtual to actual */

static INLINE void
outb (short port, char val)
{
  ioperm(port, 1, 1);
  __asm__ volatile ("out%B0 %0,%1" : :"a" (val), "d" (port));
}

static INLINE unsigned char
inb (short port)
{
  unsigned int ret;
  ioperm(port, 1, 1);  
  __asm__ volatile ("in%B0 %1,%0" : "=a" (ret) : "d" (port));
  return ret;
}

short int getreg (int address, int index)
{
  int val;
  outb (address, index);				    /* set the register number */
  val = inb (address + 1);
  return val;
}

void get_freq () /* here is where horizontal and vertical frequencies are computed */
{
  if (dotclock)
    horfreq = dotclock / actual_regs.ht;
  else	 /* If don't know the dotclock, I'll assume 20 MHz for the calculations  */
    horfreq = 20000000.0 / actual_regs.ht;
  verfreq = horfreq / actual_regs.vt;
}


void get_actual ()  /* here is where a correct bit shifts in vertical values */
{
  memcpy (&actual_regs, &current_regs, sizeof (struct crtc_regs));
  vertical_shift = 1;
  while (actual_regs.hde > (actual_regs.vde << 1))
    {
      actual_regs.vde *= 2;
      actual_regs.vrs *= 2;
      actual_regs.evr *= 2;
      actual_regs.vt  *= 2;
      vertical_shift  *= 2;
    } 
}

void restore_saved ();

void setreg (int address, int index, short int value)
{ 
  if ((! restore) && (active_hde != actual_regs.hde || active_vde != actual_regs.vde)) 
    {
      printf ("Can't handle changes in video mode \n", strerror (errno));
      exit (1);
    }
  get_actual ();
  get_freq ();
  /* Hopefully, this error message is impossable. */
  if ((! restore) && (verfreq < vmin || verfreq > vmax || horfreq < hmin || horfreq > hmax))
    {
      printf ("ERROR: Attempt to use illegal frequencies \n");
      restore_saved ();
      exit (1);
    }
  outb (address, index);				    /* set the register number */
  outb (address + 1, value);
}

void get_crtc_regs ()
{
  current_regs.hde = (getreg (CRTCL_INDEX, HDE) + 1) << 3;
  current_regs.shr = getreg (CRTCL_INDEX, SHR) << 3;
  current_regs.ehr = (getreg (CRTCL_INDEX, EHR) & 0x1f) << 3;
  if (current_regs.ehr <= (current_regs.shr & 0xff))	    /* wraparound, */
    current_regs.ehr += 0x100;				    /* adjust */
  current_regs.ehr += (current_regs.shr & ~0xff);	    /* this is relative to shr */
  current_regs.ht = (getreg (CRTCL_INDEX, HT) + 5) << 3;
  current_regs.overflow = getreg (CRTCL_INDEX, OVERFLOW);
  switch (current_regs.overflow & 0x21)			    /* get the high-order VT stuff */
    {
    case 0:
      current_regs.vt = 0; break;
    case 1:
      current_regs.vt = 256; break;
    case 0x20:
      current_regs.vt = 512; break;
    case 0x21:
      current_regs.vt = 768;
    }
  current_regs.vt += getreg (CRTCL_INDEX, VT) + 2;
  switch (current_regs.overflow & 0x84)			    /* get the high-order VRS stuff */
    {
    case 0:
      current_regs.vrs = 0; break;
    case 4:
      current_regs.vrs = 256; break;
    case 0x80:
      current_regs.vrs = 512; break;
    case 0x84:
      current_regs.vrs = 768;
    }
  current_regs.vrs += getreg (CRTCL_INDEX, VRS);
  if ((current_regs.evr = getreg (CRTCL_INDEX, EVR) & 0xf) <= (current_regs.vrs & 0xf)) /* wraparound */
    current_regs.evr += 0x10;
  current_regs.evr += (current_regs.vrs & ~0xf);	    /* get base */
  switch (current_regs.overflow & 0x42)			    /* get the high-order VDE stuff */
    {
    case 0:
      current_regs.vde = 0; break;
    case 2:
      current_regs.vde = 256; break;
    case 0x40:
      current_regs.vde = 512; break;
    case 0x42:
      current_regs.vde = 768;
    }
  current_regs.vde += getreg (CRTCL_INDEX, VDE) + 1;
  current_regs.vbs = getreg (CRTCL_INDEX, VBS);		    /* start of blanking register */
  if (current_regs.overflow & 8)			    /* bit 8 of VBS reg */
    current_regs.vbs += 256;				    /* add in */
  if (getreg (CRTCL_INDEX, MSL) & 0x20)			    /* bit 9 of VBS reg */
    current_regs.vbs += 512;				    /* add in */
  current_regs.vbe = getreg (CRTCL_INDEX, VBE) & 0x7f;	    /* end of blanking register */
  if (current_regs.vbe < (current_regs.vbs & 0x7f))	    /* wraparound */
    current_regs.vbe += 128;
  current_regs.vbe += current_regs.vbs & ~0x7f;		    /* high-order comes from vbs */
  get_actual ();
  if (! active_vde) active_vde = actual_regs.vde;
  if (! active_hde) active_hde = actual_regs.hde;
  if (! virtual_vde) virtual_vde = active_vde;
  if (! virtual_hde) virtual_hde = active_hde;
  get_freq ();
  }

/* set vertical resolution */
void setvde ()
{ 
  short int myvde = -1;
  get_actual ();
  if ( actual_regs.vde > virtual_vde ) 
    {
      restore_saved ();
      get_actual ();
      active_vde = actual_regs.vde;
    }
  else
    {
      active_vde = actual_regs.vde;
      myvde += current_regs.vde;			            /* adjust for VGA format */
      current_regs.overflow = getreg (CRTCL_INDEX, OVERFLOW) & ~ 0x42;
      current_regs.overflow |= ((short int []) {0, 2, 0x40, 0x42}) [myvde >> 8]; /* put in high order bits */
      setreg (CRTCL_INDEX, OVERFLOW, current_regs.overflow);
      setreg (CRTCL_INDEX, VDE, myvde & 0xff);		    /* and low-order 8 bits */
    }
}

/* set vertical blanking start */
void setvrs ()
{
  current_regs.overflow = getreg (CRTCL_INDEX, OVERFLOW) & ~8;
  if (current_regs.vrs & 0x100)
    current_regs.overflow |= 8;
  setreg (CRTCL_INDEX, OVERFLOW, current_regs.overflow);    /* take care of bit 
                                                               8 */
  current_regs.msl = getreg (CRTCL_INDEX, MSL) & ~0x20;
  if (current_regs.vrs & 0x200)
    current_regs.msl |= 0x20;
  setreg (CRTCL_INDEX, MSL, current_regs.msl);              /* take care of bit 
                                                               9 */
  setreg (CRTCL_INDEX, VRS, current_regs.vrs & 0xff);       /* and the first 8 b
                                                               its */
}

void setevr ()
{
  setreg (CRTCL_INDEX, EVR, (current_regs.evr & 0xf) | (getreg (CRTCL_INDEX, EVR) & ~0xf));
}

void setvt ()
{
  short int myvt = current_regs.vt - 2;			    /* adjust for VGA format */
  current_regs.overflow = getreg (CRTCL_INDEX, OVERFLOW) & ~ 0x21;
  current_regs.overflow |= ((short int []) {0, 1, 0x20, 0x21}) [myvt >> 8]; /* put in high order bits */
  setreg (CRTCL_INDEX, OVERFLOW, current_regs.overflow);
  setreg (CRTCL_INDEX, VT, myvt & 0xff);		    /* and low-order 8 bits */
}

void sethde ()
{
  get_actual ();
  if ( actual_regs.hde > virtual_hde ) 
    {restore_saved;get_actual ();active_hde = actual_regs.hde;}
  else
    {
      active_hde = actual_regs.hde;
      setreg (CRTCL_INDEX, HDE, ( current_regs.hde >> 3 ) - 1);
    }
}

void setshr ()
{
  setreg (CRTCL_INDEX, SHR, current_regs.shr >> 3);
}

void setehr ()
{
  setreg (CRTCL_INDEX, EHR, (getreg (CRTCL_INDEX, EHR) & 0xe0) | ((current_regs.ehr >> 3) & 0x1f));
}

void setht ()
{
  setreg (CRTCL_INDEX, HT, (current_regs.ht >> 3) - 5);
}

void restore_saved () /* This restores the saved X windows settings */
{
  memcpy (&current_regs, &saved_regs, sizeof (struct crtc_regs));
  restore = 1;
  setvde ();
  setvrs ();
  setevr ();
  setvt ();
  sethde ();
  setshr ();
  setehr ();
  setht ();
  restore = 0;
}

void decrease_left_margin ()
{
  if (current_regs.ht > current_regs.ehr)
    {
      current_regs.ht -= 8;
      get_actual ();
      get_freq ();
      if (horfreq > hmax || verfreq > vmax)
        {
          printf ("Can't reduce left margin further\n\007");
          current_regs.ht += 8;
        }
      else
        setht ();
    }
  else
    printf ("Can't reduce left margin further\n\007");
}

void increase_left_margin ()
{
  if (current_regs.ht < 2040 )
    {
      current_regs.ht += 8;
      get_actual ();
      get_freq ();
      if (horfreq < hmin || verfreq < vmin)
        {
          printf ("Can't increase Left margin further\n\007");
          current_regs.ht -= 8;
        }
      else
        setht ();
    }
  else
    printf ("Can't increase Left margin further\n\007");
}


void decrease_horizontal_sync ()
{
  if (current_regs.ehr > (current_regs.shr + 8))	    /* can decrease */
	{
      current_regs.ehr -= 8;
      setehr ();
	}
  else
	printf ("Can't decrease horizontal sync further\007\n");
}

void increase_horizontal_sync ()
{
  if (current_regs.ehr < current_regs.ht)		    /* space to increase */
	{
      current_regs.ehr += 8;
      setehr ();
	}
  else
	printf ("Can't increase horizontal sync further\007\n");
}

void decrease_right_margin ()
{
  if (current_regs.shr > current_regs.hde)		    /* can decrease */
	{
      current_regs.shr -= 8;
      setshr ();
      decrease_horizontal_sync ();
      decrease_left_margin ();
	}
  else
	printf ("Can't decrease right margin further\007\n");
}

void increase_right_margin ()
{
  increase_left_margin ();
  if (current_regs.ehr < current_regs.ht)		    /* space to increase */
	{
      current_regs.shr += 8;
      setshr ();
      increase_horizontal_sync ();
	}
  else
	printf ("Can't increase right margin further\007\n");
}

void decrease_x_resolution ()
{
  if ((current_regs.hde - 8) > actual_regs.vde)
    {
      current_regs.hde -= 8;
      sethde ();
      decrease_right_margin ();
    }
  else
    printf ("Can't decrease horizontal resolution further\007\n");
}

void increase_x_resolution ()
{
  get_actual ();
  if (actual_regs.hde < virtual_hde &&
      (actual_regs.hde + 8) < (actual_regs.vde << 1))
    {
      current_regs.hde += 8;
      sethde ();
      increase_right_margin ();
    }
  else
    printf ("Can't increase horizontal resolution further\007\n");
}

void increase_top_margin ()
{
  if (current_regs.vt < 1024 )
    {
      current_regs.vt++;
      get_actual ();
      get_freq ();
      if (verfreq < vmin)
        {
      printf ("Can't increase top margin further\n\007");
      current_regs.vt--;
    }
      else
        setvt ();
    }
  else
    printf ("Can't increase top margin further\n\007");
}


void decrease_top_margin ()
{
  if (current_regs.vt > current_regs.evr)
    {
      current_regs.vt--;
      get_actual ();
      get_freq ();
      if (verfreq > vmax)
        {
          printf ("Can't reduce top margin further\n\007");
          current_regs.vt++;
        }
      else
        setvt ();
    }
  else
    printf ("Can't reduce top margin further\n\007");
}

void decrease_vertical_sync ()
{
  if (current_regs.evr > current_regs.vrs)		    /* can decrease */
	{
      current_regs.evr--;
      setevr ();
	}
  else
	printf ("Can't decrease vertical sync further\007\n");
}

void increase_vertical_sync ()
{
  if (current_regs.evr < current_regs.vt)		    /* space to increase */
	{
      current_regs.evr++;
      setevr ();
	}
  else
	printf ("Can't increase vertical sync further\007\n");
}

void decrease_bottom_margin ()
{
  if (current_regs.vrs > current_regs.vde)		    /* can decrease */
	{
      current_regs.vrs--;
      setvrs ();
      decrease_vertical_sync ();
      decrease_top_margin ();
	}
  else
	printf ("Can't decrease bottom margin further\007\n");
}

void increase_bottom_margin ()
{
  increase_top_margin ();
  if (current_regs.evr < current_regs.vt)		    /* space to increase */
	{
      current_regs.vrs++;
      setvrs ();
      increase_vertical_sync ();
	}
  else
	printf ("Can't increase bottom margin further\007\n");
}

void decrease_y_resolution ()
{
  if (((actual_regs.vde - vertical_shift) << 1) > current_regs.hde)
    {
      current_regs.vde--;
      setvde ();
      decrease_bottom_margin ();
    }
  else
    printf ("Can't decrease vertical resolution further\007\n");
}

void increase_y_resolution ()
{
  get_actual ();
  if ((actual_regs.vde < virtual_vde) &&
      ((actual_regs.hde) > (actual_regs.vde + vertical_shift)))
    {
      current_regs.vde++;
      setvde ();
      increase_bottom_margin ();
    }
  else
    printf ("Can't increase vertical resolution further\007\n");
}

void show_crtc_regs ()
{
  int reg;						    /* register number */
  short int val;					    /* value stored in register */
  
  get_crtc_regs ();
  
  if (active_hde != actual_regs.hde || active_vde != actual_regs.vde) 
    {
      printf ("It is unsafe to change video modes while running vgaset \n");
      printf ("Can't restore saved values.  EXIT XWINDOWS NOW. \n",strerror (errno));
      exit (1);
    }
  if (dotclock)						    /* show frequencies */
    {
      printf ("%3.0f\t%d %d %d %d\t%d %d %d %d\n",
              dotclock / 1000000.0,
              actual_regs.hde,
              actual_regs.shr,
              actual_regs.ehr,
              actual_regs.ht,
              actual_regs.vde,
              actual_regs.vrs,
              actual_regs.evr,
              actual_regs.vt);						    /* print clocks line */
      get_freq ();
    printf ("Horizontal frequency: %3.1f kHz, vertical frequency: %3.1f Hz\n",
            horfreq/1000.0,
            verfreq );
      printf ("Horizontal sync %5.2f us, vertical sync %5.2f us\n",
              (actual_regs.ehr - actual_regs.shr) / dotclock * 1000000.0,
              (actual_regs.evr - actual_regs.vrs) / horfreq * 1000000.0 );
      printf ("Horizontal retrace %5.2f us, vertical retrace %5.2f us\n",
              (actual_regs.ht - actual_regs.hde) / dotclock * 1000000.0,
              (actual_regs.vt - actual_regs.vde) / horfreq * 1000000.0 );
    }
  else
    {
      printf ("%d %d %d %d\t%d %d %d %d\n",
              actual_regs.hde,
              actual_regs.shr,
	  actual_regs.ehr,
              actual_regs.ht,
              actual_regs.vde,
              actual_regs.vrs,
              actual_regs.evr,
              actual_regs.vt);
    }	  						    /* print clocks line */
  
  if (verbose)
    {
      for (reg = 0; reg < CRTC_REG_COUNT; reg++)
        {
          outb (CRTCL_INDEX, reg);				    /* set the register number */
          val = inb (CRTCL_DATA);
          if (! (reg & 3))
            printf ("\n");					    /* 4 to a line */
          printf ("%s\t%x\t", crtc_reg_name [reg], val);
      }
      printf ("\n");
    }
}

void main (int argc, char *argv [])
{
  int i;
  struct termios term_status;
  
  if (argc > 1)
    printf ("WARNING: Improper use of this program may destroy your monitor \n");
  if (tcgetattr (0, &term_status))
    {
      printf ("Can't get terminal attributes for stdin: %s\n", strerror (errno));
      exit (1);
    }
  term_status.c_lflag &= ~ICANON;
  if (tcsetattr (0, TCSAFLUSH, &term_status))
    {
      printf ("Can't set terminal attributes for stdin: %s\n", strerror (errno));
      exit (1);
    }
  get_crtc_regs ();					    /* save current values */
  memcpy (&saved_regs, &current_regs, sizeof (struct crtc_regs));
  for (i = 1; i < argc; i++)
    {
      if (*argv [i] == '-')				    /* flag */
        {
          switch (argv [i] [1])
            {
            case 'x':
              if ((hmin = atof (&argv [i] [2])) < 1000 )
                hmin *= 1000;  				   /* convert to kHz */
              break;
            case 'y':
              vmin = atof (&argv [i] [2]);
              break;
            case 'X':
              if ((hmax = atof (&argv [i] [2])) < 1000 )
                hmax *= 1000;					   /* convert to kHz */
              break;
            case 'Y':
              vmax = atof (&argv [i] [2]);
              break;
            case 'd':
              if ((dotclock = atof (&argv [i] [2])) < 1000)	    /* get it */
                if ((dotclock *= 1000) < 1000000)                 /* convert from kHz */
                  dotclock *= 1000;				    /* convert from MHz */
              get_freq ();
              break;
            case 's':						    /* set the registers first */
              if (argc < (i + 7))				    /* not enough args */
                {
                  puts ("Not enough arguments to -s option");
                  exit (1);
                };
              current_regs.shr = atoi (argv [++i]);		    /* get the values to set the regs to */
              current_regs.ehr = atoi (argv [++i]);
              current_regs.ht = atoi (argv [++i]);
              current_regs.vrs = atoi (argv [++i]);
              current_regs.evr = atoi (argv [++i]);
              current_regs.vt = atoi (argv [++i]);
              break;
            case 'v':                         /* get virtual screen size */
              if (argc < (i + 3))				    /* not enough args */
                {
                  puts ("Not enough arguments to -v option");
                  exit (1);
                };
              virtual_hde = atoi (argv [++i]);		    /* get the virtual resolution */
              virtual_vde = atoi (argv [++i]);
              break;
            case 'V':
              verbose = 1;
              break;
            }
        }
      else
        {
          printf ("Usage:\n%s [-ddot_clock [-xfrequency_min] [-yfrequency_min] \n
       [-Xfrequency_max] [-Yfrequency_max]]  [-s shr ehr ht vrs evr vt] \n
       [-v x_virtual y_virtual] [-V] \n", argv [0]);
        }
    }
  if ( ! dotclock ) 					    /* We need a clock value true frequency ranges */
    {
      if (vmin != 0 ) vmin = verfreq;
      if (vmax != 0 ) vmax = verfreq;
      hmin = horfreq;
      hmax = horfreq;
    }
  else
    {
      if ( vmin > verfreq || vmin < 0 ) vmin = verfreq; 	   /* Assume the current mode is valid */
      if ( vmax < verfreq ) vmax = verfreq;
      if ( hmin > horfreq || hmin < 0 ) hmin = horfreq;
      if ( hmax < horfreq ) hmax = horfreq;
    }
  setshr ();
  setehr ();
  setht ();
  setvrs ();
  setevr ();
  setvt ();
  show_crtc_regs ();					    /* first time round */
  while (1)
    {
      char c = getchar ();
      switch (c)
        {
        case 'l':						    /* decrease left */
          puts ("eft margin decrease");
          decrease_left_margin ();
          break;
        case 'L':						    /* increase left */
          puts ("eft margin increase");
          increase_left_margin ();
          break;
        case 'r':						    /* decrease right */
          puts ("ight margin decrease");
          decrease_right_margin ();
          break;
        case 'R':						    /* increase right */
          puts ("ight margin increase");
          increase_right_margin ();
          break;
        case 'h':						    /* decrease horizontal sync */
          puts ("orizontal sync decrease");
          decrease_horizontal_sync ();
          break;
        case 'H':						    /* increase horizontal sync */
          puts ("orizontal sync increase");
          increase_horizontal_sync ();
          break;
          /* Vertical operations */
        case 't':						    /* decrease top */
          puts ("op margin decrease");
          decrease_top_margin ();
          break;
        case 'T':						    /* increase top */
          puts ("op margin increase");
          increase_top_margin ();
          break;
        case 'b':						    /* decrease bottom */
          puts ("ottom margin decrease");
          decrease_bottom_margin ();
          break;
        case 'B':						    /* increase bottom */
          puts ("ottom margin increase");
          increase_bottom_margin ();
          break;
        case 'v':						    /* decrease vertical sync */
          puts ("ertical sync decrease");
          decrease_vertical_sync ();
          break;
        case 'V':						    /* increase vertical sync */
          puts ("ertical sync increase");
          increase_vertical_sync ();
          break;
        case 'x':                           /* decrease horizontal resolution */
          puts ("-resolution decrease");
          decrease_x_resolution ();
          break;
        case 'X':                           /* increase horizontal resolution */
          puts ("-resolution increase");
          increase_x_resolution ();
          break;
        case 'y':						    /* decrease vertical resolution */
          puts ("-resolution decrease");
          decrease_y_resolution ();
          break;
        case 'Y':						    /* increase vertical resolution */
          puts ("-resolution increase");
          increase_y_resolution ();
          break;
        case '\n':						    /* do nothing */
          break;
        case '?':						    /* reset saved values */
          puts ("\bReset to standard values");
          restore_saved ();
          break;
        case 'q':
          puts ("uit");
          /* FALLTHROUGH */
        case '\004':
          restore_saved ();
          exit (0);
        default:
          printf ("Invalid command\007\n");
        }
      show_crtc_regs ();
    }
}
