char *version_string = "3.70";

/*
  Local variables:
  version-control: never
  End:
 */
