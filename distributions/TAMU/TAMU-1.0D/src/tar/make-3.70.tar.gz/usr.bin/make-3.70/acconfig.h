/* Define to the name of the SCCS `get' command.  */
#undef SCCS_GET

/* Define this if the SCCS `get' command understands the `-G<file>' option.  */
#undef SCCS_GET_MINUS_G
