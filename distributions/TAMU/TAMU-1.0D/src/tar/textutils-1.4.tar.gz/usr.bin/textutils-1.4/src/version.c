/* Make the binaries identifiable with the RCS ident command.  */
char *version_string = "\n$Version: GNU textutils 1.4 $\n";
