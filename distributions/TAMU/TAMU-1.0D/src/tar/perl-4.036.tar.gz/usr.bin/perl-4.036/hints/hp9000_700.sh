libswanted='ndbm m'
ccflags="$ccflags -DJMPCLOBBER"
optimize='+O1'
d_mymalloc=define
alignbytes=8
