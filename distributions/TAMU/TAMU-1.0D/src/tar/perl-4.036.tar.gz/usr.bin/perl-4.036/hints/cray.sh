case `uname -r` in
6.1*) shellflags="-m+65536" ;;
esac
