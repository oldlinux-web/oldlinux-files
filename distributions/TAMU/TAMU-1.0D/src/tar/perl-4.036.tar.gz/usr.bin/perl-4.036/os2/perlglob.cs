os2\glob.c

setargv.obj

os2\perl.def
os2\perl.bad
perlglob.exe

-AS -LB -S0x1000
