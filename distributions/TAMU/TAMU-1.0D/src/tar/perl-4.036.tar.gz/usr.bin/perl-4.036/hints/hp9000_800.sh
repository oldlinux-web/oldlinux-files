libswanted=`echo $libswanted | sed -e 's/malloc //' -e 's/BSD //`
eval_cflags='optimize=+O1'
teval_cflags=$eval_cflags
