ccflags="$ccflags -DFPUTS_BOTCH"
