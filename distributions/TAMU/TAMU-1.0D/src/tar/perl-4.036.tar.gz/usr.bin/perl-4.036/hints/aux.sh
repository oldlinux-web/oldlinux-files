optimize='-O'
ccflags="$ccflags -B/usr/lib/big/ -DPARAM_NEEDS_TYPES"
