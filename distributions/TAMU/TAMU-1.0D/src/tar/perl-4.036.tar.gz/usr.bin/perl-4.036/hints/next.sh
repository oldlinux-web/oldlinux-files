: Just disable defaulting to -fpcc-struct-return, since gcc is native compiler.
nativegcc='define'
groupstype="int"
usemymalloc="n"
libswanted='dbm sys_s'
