#define SIGALRM SIGUSR1
unsigned alarm(unsigned);
