# defaults for the masscomp (concurrent) 6000 series running RTU 5.0
cppstdin=/lib/cpp
cmd_cflags='optimize=""'
tcmd_cflags='optimize=""'
d_mymalloc=define
