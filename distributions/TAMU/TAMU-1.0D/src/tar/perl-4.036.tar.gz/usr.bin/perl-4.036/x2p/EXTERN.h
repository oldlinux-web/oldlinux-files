/* $RCSfile: EXTERN.h,v $$Revision: 4.0.1.1 $$Date: 91/06/07 12:11:15 $
 *
 *    Copyright (c) 1991, Larry Wall
 *
 *    You may distribute under the terms of either the GNU General Public
 *    License or the Artistic License, as specified in the README file.
 *
 * $Log:	EXTERN.h,v $
 * Revision 4.0.1.1  91/06/07  12:11:15  lwall
 * patch4: new copyright notice
 * 
 * Revision 4.0  91/03/20  01:56:53  lwall
 * 4.0 baseline.
 * 
 */

#undef EXT
#define EXT extern

#undef INIT
#define INIT(x)

#undef DOINIT
