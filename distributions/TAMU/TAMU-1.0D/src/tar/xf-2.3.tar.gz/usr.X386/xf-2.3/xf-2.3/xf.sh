%%%!/bin/sh
%%% This is the safest way ... (I guess :-)
%%%
if [ "$HOME" = "" ]; then
	HOME=`pwd`
fi

%%% configure here please!!!
%%%
%%% where can I find wish (the ultimate tool :-)
if test "$WISH_CMD" = ""; then
  WISH_CMD=CPP_WISH_CMD
fi

%%% configure here please!!!
%%%
%%% where can I find wish (the ultimate tool :-)
if test "$WISH_TEST_CMD" = ""; then
  WISH_TEST_CMD=CPP_WISH_CMD
fi

%%%
%%% where can I find my files
if test "$XF_DIR" = ""; then
  XF_DIR=CPP_XF_DIR
fi
XF_DIR_CPP=CPP_XF_DIR

%%%
%%% where can I find my lib files
if test "$XF_LIB_DIR" = ""; then
  XF_LIB_DIR=CPP_XF_LIB_DIR
fi
XF_LIB_DIR_CPP=CPP_XF_LIB_DIR

%%%
%%% where can I find my src files
if test "$XF_SRC_DIR" = ""; then
  XF_SRC_DIR=CPP_XF_SRC_DIR
fi
XF_SRC_DIR_CPP=CPP_XF_SRC_DIR

%%%
%%% where are the additional widgets (if any)
if test "$XF_ADD_DIR" = ""; then
  XF_ADD_DIR=CPP_XF_ADD_DIR
fi
XF_ADD_DIR_CPP=CPP_XF_ADD_DIR

%%%
%%% where are the standard widgets
if test "$XF_ELEM_DIR" = ""; then
  XF_ELEM_DIR=CPP_XF_ELEM_DIR
fi
XF_ELEM_DIR_CPP=CPP_XF_ELEM_DIR

%%%
%%% where are the help pages (if any)
if test "$XF_HELP_DIR" = ""; then
  XF_HELP_DIR=CPP_XF_HELP_DIR
  export XF_HELP_DIR
fi
XF_HELP_DIR_CPP=CPP_XF_HELP_DIR

%%%
%%% where are the icons
if test "$XF_ICONS_DIR" = ""; then
  XF_ICONS_DIR=CPP_XF_ICONS_DIR
fi
XF_ICONS_DIR_CPP=CPP_XF_ICONS_DIR

%%%
%%% where are the procedures (if any)
if test "$XF_PROC_DIR" = ""; then
  XF_PROC_DIR=CPP_XF_PROC_DIR
fi
XF_PROC_DIR_CPP=CPP_XF_PROC_DIR

%%%
%%% where are the tmp files (if created)
if test "$XF_TMP_DIR" = ""; then
  XF_TMP_DIR=CPP_XF_TMP_DIR
fi
XF_TMP_DIR_CPP=CPP_XF_TMP_DIR

%%%
%%% where are the templates (if any)
if test "$XF_TMPLT_DIR" = ""; then
  XF_TMPLT_DIR=CPP_XF_TMPLT_DIR
fi
XF_TMPLT_DIR_CPP=CPP_XF_TMPLT_DIR

%%%
%%% what name has the default binding file
if test "$XF_BIND_FILE" = ""; then
  XF_BIND_FILE=CPP_XF_BIND_FILE
  export XF_BIND_FILE
fi
XF_BIND_FILE_CPP=CPP_XF_BIND_FILE

%%%
%%% what name has the color file
if test "$XF_COLOR_FILE" = ""; then
  XF_COLOR_FILE=CPP_XF_COLOR_FILE
  export XF_COLOR_FILE
fi
XF_COLOR_FILE_CPP=CPP_XF_COLOR_FILE

%%%
%%% what name has the config file
if test "$XF_CONFIG_FILE" = ""; then
  XF_CONFIG_FILE=CPP_XF_CONFIG_FILE
fi
XF_CONFIG_FILE_CPP=CPP_XF_CONFIG_FILE

%%%
%%% what name has the cursor file
if test "$XF_CURSOR_FILE" = ""; then
  XF_CURSOR_FILE=CPP_XF_CURSOR_FILE
  export XF_CURSOR_FILE
fi
XF_CURSOR_FILE_CPP=CPP_XF_CURSOR_FILE

%%%
%%% what name has the font file
if test "$XF_FONT_FILE" = ""; then
  XF_FONT_FILE=CPP_XF_FONT_FILE
  export XF_FONT_FILE
fi
XF_FONT_FILE_CPP=CPP_XF_FONT_FILE

%%%
%%% what name has the iconbar file
if test "$XF_ICONBAR_FILE" = ""; then
  XF_ICONBAR_FILE=CPP_XF_ICONBAR_FILE
fi
XF_ICONBAR_FILE_CPP=CPP_XF_ICONBAR_FILE

%%%
%%% what name has the keysym file
if test "$XF_KEYSYM_FILE" = ""; then
  XF_KEYSYM_FILE=CPP_XF_KEYSYM_FILE
  export XF_KEYSYM_FILE
fi
XF_KEYSYM_FILE_CPP=CPP_XF_KEYSYM_FILE

%%%
%%% what name has the menubar definition file
if test "$XF_MENUBAR_FILE" = ""; then
  XF_MENUBAR_FILE=CPP_XF_MENUBAR_FILE
fi
XF_MENUBAR_FILE_CPP=CPP_XF_MENUBAR_FILE

%%%
%%% what name has the window positions file
if test "$XF_POS_FILE" = ""; then
  XF_POS_FILE=CPP_XF_POS_FILE
fi
XF_POS_FILE_CPP=CPP_XF_POS_FILE

%%%
%%% initialize
XF_WISH_CMD=""

%%%
%%% initialize
XF_WISH_TEST_CMD=""

%%%
%%% look if we have a local config file
if [ -r $HOME/.xf-config ]; then
	XF_CONFIG_FILE=$HOME/.xf-config
fi
if [ -r .xf-config ]; then
	XF_CONFIG_FILE=.xf-config
fi

%%%
%%% CAUTION ! do not cross this line !!!!
%%%
ARGC=$%%%
COMMANDLINE=
while [ $ARGC -gt 0 ]; do
        C=$1
        shift
        ARGC=`expr $ARGC - 1`
        case $C in
        -cmd)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                WISH_CMD=$C
		        XF_WISH_CMD="-cmd $WISH_CMD"
		else
			echo "XF error: expected program name for -cmd"
			exit 2
                fi;;
        -testcmd)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                WISH_TEST_CMD=$C
		        XF_WISH_TEST_CMD="-testcmd $WISH_TEST_CMD"
		else
			echo "XF error: expected program name for -testcmd"
			exit 2
                fi;;
        -xf)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_DIR=$C
		else
			echo "XF error: expected pathname for -xf"
			exit 2
                fi;;
        -xfadd | -xfadditionals)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_ADD_DIR=$C
		else
			echo "XF error: expected pathname for -xfadditionals"
			exit 2
                fi;;
        -xfbind)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_BIND_FILE=$C
		else
			echo "XF error: expected filename for -xfbind"
			exit 2
                fi;;
        -xfcol | -xfcolors)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_COLOR_FILE=$C
		else
			echo "XF error: expected filename for -xfcolors"
			exit 2
                fi;;
        -xfconf | -xfconfig)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_CONFIG_FILE=$C
		else
			echo "XF error: expected filename for -xfconfig"
			exit 2
                fi;;
        -xfcursors)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_CURSOR_FILE=$C
		else
			echo "XF error: expected filename for -xfcursors"
			exit 2
                fi;;
        -xfelem | -xfelements)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_ELEM_DIR=$C
		else
			echo "XF error: expected pathname for -xfelements"
			exit 2
                fi;;
        -xffonts)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_FONT_FILE=$C
		else
			echo "XF error: expected filename for -xffonts"
			exit 2
                fi;;
        -xfhelp)
		echo "XF:"
		echo `cat $XF_DIR/Version`
		echo "usage:"
		echo -n "xf "
		echo -n "[-cmd <arg>] "
		echo -n "[-testcmd <arg>] "
		echo -n "[-xf <arg>] "
		echo -n "[-xfadditionals <arg>] "
		echo    "[-xfbind <arg>] "
		echo -n "   "
		echo -n "[-xfcolors <arg>] "
		echo -n "[-xfconfig <arg>] "
		echo -n "[-xfcursors <arg>] "
		echo    "[-xfelements <arg>] "
		echo -n "   "
		echo -n "[-xffonts <arg>] "
		echo -n "[-xfhelp] "
		echo -n "[-xfhelps <arg>] "
		echo    "[-xficonbar <arg>] "
		echo -n "   "
		echo -n "[-xficons <arg>] "
		echo -n "[-xfkeysyms <arg>] "
		echo -n "[-xflib <arg>] "
		echo    "[-xfmenubar <arg>] "
		echo -n "   "
		echo -n "[-xfmodelcolor] "
		echo -n "[-xfmodelmono] "
		echo -n "[-xfpos <arg>] "
		echo    "[-xfprocedures <arg>] "
		echo -n "   "
		echo -n "[-xftmp <arg>] "
		echo -n "[-xftmplt <arg>] "
		echo -n "[-xfsrc <arg>] "
		echo -n "[-xfstartup <arg>] "
		echo    "[-xfversion] "
		exit 0;;
        -xfhelps)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_HELP_DIR=$C
		else
			echo "XF error: expected pathname for -xfhelps"
			exit 2
                fi;;
        -xficonbar)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_ICONBAR_FILE=$C
		else
			echo "XF error: expected filename for -xficonbar"
			exit 2
                fi;;
        -xficons)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_ICONS_DIR=$C
		else
			echo "XF error: expected pathname for -xficons"
			exit 2
                fi;;
        -xfkeysyms)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_KEYSYM_FILE=$C
		else
			echo "XF error: expected filename for -xfkeysyms"
			exit 2
                fi;;
        -xflib)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_LIB_DIR=$C
		else
			echo "XF error: expected pathname for -xflib"
			exit 2
                fi;;
        -xfmenubar)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_MENUBAR_FILE=$C
		else
			echo "XF error: expected pathname for -xfmenubar"
			exit 2
                fi;;
        -xfpos)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_POS_FILE=$C
		else
			echo "XF error: expected pathname for -xfpos"
			exit 2
                fi;;
        -xfprocs | -xfprocedures)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_PROC_DIR=$C
		else
			echo "XF error: expected pathname for -xfprocedures"
			exit 2
                fi;;
        -xfsrc)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_SRC_DIR=$C
		else
			echo "XF error: expected pathname for -xfsrc"
			exit 2
                fi;;
        -xftmp)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_TMP_DIR=$C
		else
			echo "XF error: expected pathname for -xftmp"
			exit 2
                fi;;
        -xftmplt | -xftemplates)
                if [ $ARGC -gt 0 ]; then
		        C=$1
                        shift
                        ARGC=`expr $ARGC - 1`
	                XF_TMPLT_DIR=$C
		else
			echo "XF error: expected pathname for -xftemplates"
			exit 2
                fi;;
        -xfversion)
		%%% here we must guarantee that both files have the same
		%%% version number
		echo "XF:"
		echo `cat $XF_DIR/Version`
		exit 0;;
        *)
		COMMANDLINE=$COMMANDLINE" "$C;;
        esac
done

if [ "$WISH_CMD" != "" ]; then
	WISH_CMD_CMD=$WISH_CMD
else
	WISH_CMD_CMD="wish"
fi
if [ "$WISH_TEST_CMD" != "" ]; then
	WISH_TEST_CMD_CMD=$WISH_TEST_CMD
else
	WISH_TEST_CMD_CMD="wish"
fi

if [ "$XF_DIR" != "" ]; then
	XF_DIR_CMD="-xf $XF_DIR"
else
	XF_DIR=.
	XF_DIR_CMD=
fi

if [ "$XF_LIB_DIR" != "" ]; then
	XF_LIB_DIR_CMD="-xflib $XF_LIB_DIR"
else
	XF_LIB_DIR=.
	XF_LIB_DIR_CMD=
fi

if [ "$XF_ADD_DIR" != "" ]; then
	XF_ADD_DIR_CMD="-xfadditionals $XF_ADD_DIR"
else
	XF_ADD_DIR_CMD=
fi

if [ "$XF_BIND_FILE" != "" ]; then
	XF_BIND_FILE_CMD="-xfbind $XF_BIND_FILE"
else
	XF_BIND_FILE_CMD=
fi

if [ "$XF_COLOR_FILE" != "" ]; then
	XF_COLOR_FILE_CMD="-xfcolors $XF_COLOR_FILE"
else
	XF_COLOR_FILE_CMD=
fi

if [ "$XF_CURSOR_FILE" != "" ]; then
	XF_CURSOR_FILE_CMD="-xfcursors $XF_CURSOR_FILE"
else
	XF_CURSOR_FILE_CMD=
fi

if [ "$XF_ELEM_DIR" != "" ]; then
	XF_ELEM_DIR_CMD="-xfelements $XF_ELEM_DIR"
else
	XF_ELEM_DIR_CMD=
fi

if [ "$XF_FONT_FILE" != "" ]; then
	XF_FONT_FILE_CMD="-xffonts $XF_FONT_FILE"
else
	XF_FONT_FILE_CMD=
fi

if [ "$XF_HELP_DIR" != "" ]; then
	XF_HELP_DIR_CMD="-xfhelps $XF_HELP_DIR"
else
	XF_HELP_DIR_CMD=
fi

if [ "$XF_ICONBAR_FILE" != "" ]; then
	XF_ICONBAR_FILE_CMD="-xficonbar $XF_ICONBAR_FILE"
else
	XF_ICONBAR_FILE_CMD=
fi

if [ "$XF_ICONS_DIR" != "" ]; then
	XF_ICONS_DIR_CMD="-xficons $XF_ICONS_DIR"
else
	XF_ICONS_DIR_CMD=
fi

if [ "$XF_KEYSYM_FILE" != "" ]; then
	XF_KEYSYM_FILE_CMD="-xfkeysyms $XF_KEYSYM_FILE"
else
	XF_KEYSYM_FILE_CMD=
fi

if [ "$XF_MENUBAR_FILE" != "" ]; then
	XF_MENUBAR_FILE_CMD="-xfmenubar $XF_MENUBAR_FILE"
else
	XF_MENUBAR_FILE_CMD=
fi

if [ "$XF_POS_FILE" != "" ]; then
	XF_POS_FILE_CMD="-xfpos $XF_POS_FILE"
else
	XF_POS_FILE_CMD=
fi

if [ "$XF_PROC_DIR" != "" ]; then
	XF_PROC_DIR_CMD="-xfprocedures $XF_PROC_DIR"
else
	XF_PROC_DIR_CMD=
fi

if [ "$XF_SRC_DIR" != "" ]; then
	XF_SRC_DIR_CMD="-xfsrc $XF_SRC_DIR"
else
	XF_SRC_DIR=.
	XF_SRC_DIR_CMD=
fi

if [ "$XF_TMP_DIR" != "" ]; then
	XF_TMP_DIR_CMD="-xftmp $XF_TMP_DIR"
else
	XF_TMP_DIR_CMD=
fi

if [ "$XF_TMPLT_DIR" != "" ]; then
	XF_TMPLT_DIR_CMD="-xftemplates $XF_TMPLT_DIR"
else
	XF_TMPLT_DIR_CMD=
fi

%%%
%%% if there is no config file, pass the default wish
%%% as interpreter.
if test -f $XF_CONFIG_FILE; then
	:
else
	if [ "$XF_WISH_CMD" = "" ]; then
		XF_WISH_CMD="-cmd $WISH_CMD_CMD"
	fi
	if [ "$XF_WISH_TEST_CMD" = "" ]; then
		XF_WISH_TEST_CMD="-testcmd $WISH_TEST_CMD_CMD"
	fi
fi

%%%
%%% if a config file is specified, and this file exists we
%%% only pass the config file name (the rest is specified in the
%%% config file (makes the commandline short again :-)
if [ "$XF_CONFIG_FILE" != "" ]; then
	XF_CONFIG_FILE_CMD="-xfconfig $XF_CONFIG_FILE"
        if test -f $XF_CONFIG_FILE; then
		if [ "$XF_DIR" = "$XF_DIR_CPP" ]; then
			XF_DIR_CMD=
		fi
		if [ "$XF_LIB_DIR" = "$XF_LIB_DIR_CPP" ]; then
			XF_LIB_DIR_CMD=
		fi
		if [ "$XF_ADD_DIR" = "$XF_ADD_DIR_CPP" ]; then
			XF_ADD_DIR_CMD=
		fi
		if [ "$XF_BIND_FILE" = "$XF_BIND_FILE_CPP" ]; then
			XF_BIND_FILE_CMD=
		fi
		if [ "$XF_COLOR_FILE" = "$XF_COLOR_FILE_CPP" ]; then
			XF_COLOR_FILE_CMD=
		fi
		if [ "$XF_CURSOR_FILE" = "$XF_CURSOR_FILE_CPP" ]; then
			XF_CURSOR_FILE_CMD=
		fi
		if [ "$XF_ELEM_DIR" = "$XF_ELEM_DIR_CPP" ]; then
			XF_ELEM_DIR_CMD=
		fi
		if [ "$XF_FONT_FILE" = "$XF_FONT_FILE_CPP" ]; then
			XF_FONT_FILE_CMD=
		fi
		if [ "$XF_HELP_DIR" = "$XF_HELP_DIR_CPP" ]; then
			XF_HELP_DIR_CMD=
		fi
		if [ "$XF_ICONBAR_FILE" = "$XF_ICONBAR_FILE_CPP" ]; then
			XF_ICONBAR_FILE_CMD=
		fi
		if [ "$XF_ICONS_DIR" = "$XF_ICONS_DIR_CPP" ]; then
			XF_ICONS_DIR_CMD=
		fi
		if [ "$XF_KEYSYM_FILE" = "$XF_KEYSYM_FILE_CPP" ]; then
			XF_KEYSYM_FILE_CMD=
		fi
		if [ "$XF_MENUBAR_FILE" = "$XF_MENUBAR_FILE_CPP" ]; then
			XF_MENUBAR_FILE_CMD=
		fi
		if [ "$XF_POS_FILE" = "$XF_POS_FILE_CPP" ]; then
			XF_POS_FILE_CMD=
		fi
		if [ "$XF_PROC_DIR" = "$XF_PROC_DIR_CPP" ]; then
			XF_PROC_DIR_CMD=
		fi
		if [ "$XF_SRC_DIR" = "$XF_SRC_DIR_CPP" ]; then
			XF_SRC_DIR_CMD=
		fi 
		if [ "$XF_TMP_DIR" = "$XF_TMP_DIR_CPP" ]; then
			XF_TMP_DIR_CMD=
		fi
		if [ "$XF_TMPLT_DIR" = "$XF_TMPLT_DIR_CPP" ]; then
			XF_TMPLT_DIR_CMD=
		fi
        fi
else
	XF_CONFIG_FILE_CMD=
fi

%%%
%%% and finally get it running
rm -f $XF_TMP_DIR/xferrors

PATH=$PATH:CPP_INSTALLBINPATH
export PATH

exec $WISH_CMD_CMD \
       	$XF_WISH_CMD \
       	$XF_WISH_TEST_CMD \
	$XF_ADD_DIR_CMD \
	$XF_BIND_FILE_CMD \
	$XF_COLOR_FILE_CMD \
	$XF_CONFIG_FILE_CMD \
	$XF_CURSOR_FILE_CMD \
	$XF_DIR_CMD \
	$XF_ELEM_DIR_CMD \
	$XF_FONT_FILE_CMD \
	$XF_HELP_DIR_CMD \
	$XF_ICONBAR_FILE_CMD \
	$XF_ICONS_DIR_CMD \
	$XF_KEYSYM_FILE_CMD \
	$XF_LIB_DIR_CMD \
	$XF_MENUBAR_FILE_CMD \
	$XF_POS_FILE_CMD \
	$XF_PROC_DIR_CMD \
	$XF_SRC_DIR_CMD \
	$XF_TMP_DIR_CMD \
	$XF_TMPLT_DIR_CMD \
	$COMMANDLINE \
	-name xf \
	-file $XF_SRC_DIR/xfmain.tcl

%%% eof

