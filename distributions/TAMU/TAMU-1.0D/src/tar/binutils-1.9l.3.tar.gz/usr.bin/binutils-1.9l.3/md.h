struct md_symdef
{
  long stringoffset;
  long offset;
};

struct md_reloc_info
{
  int r_address;
  unsigned int r_symbolnum:24;
  unsigned int r_pcrel:1;
  unsigned int r_length:2;
  unsigned int r_extern:1;
  unsigned int r_pad:4;
};

extern long md_chars_to_number (unsigned char *p, int nbytes);
extern void md_number_to_chars (long value, int nbytes, unsigned char *p);
extern void md_chars_to_hdr (unsigned char *p, struct exec *hdr);
extern void md_hdr_to_chars (struct exec *hdr, unsigned char *p);
extern void md_chars_to_nlist (unsigned char *p, struct nlist *nlist,
			       int nitems);
extern void md_nlist_to_chars (struct nlist *nlist, int nitems,
			       unsigned char *p);
extern void md_chars_to_symdefs (unsigned char *p, struct md_symdef *symdefs,
				 int nitems);
extern void md_symdefs_to_chars (struct md_symdef *symdefs, int nitems,
				 unsigned char *p);
extern void md_chars_to_relocs (unsigned char *p,
				struct md_reloc_info *relocs, int nitems);
extern void md_relocs_to_chars (struct md_reloc_info *relocs, int nitems,
				unsigned char *p);
extern void md_vector_to_chars (unsigned long *vector, int nitems,
				unsigned char *p);
