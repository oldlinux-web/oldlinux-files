/* This stdlib.h is null, just so the #includes of it won't fail.
 * Normally you should use your system's stdlib.h; this is for 
 * venerable antique compilers/systems that don't provide one.
 * $Id: stdlib.h,v 1.1 92/09/09 16:21:25 ian Exp $
 */
