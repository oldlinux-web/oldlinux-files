#include <stdio.h>

main()
{
int i;

#if 0
	printf("\033(B\033)U\016");
#else
	printf("\033)U\016");
#endif
	for ( i = 1; i < 255; i++) {
		if (i == 033 || i == 012 || i == 014 || i == 015)
			continue;
		else
			printf("%-3o = %c     ", i, i);
	}
#if 0
	printf("\033(B\033)0\017\n");
#else
	printf("\033)0\017\n");
#endif
}

