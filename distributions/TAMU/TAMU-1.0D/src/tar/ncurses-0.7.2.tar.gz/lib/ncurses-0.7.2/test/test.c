#include <ncurses.h>

main()
{
int i;

	initscr();
	clear();
	refresh();
	addch((unsigned char)'\374');
	addch('\n');
	addstr("a \374 b");
	refresh();
	getch();
	endwin();

}
