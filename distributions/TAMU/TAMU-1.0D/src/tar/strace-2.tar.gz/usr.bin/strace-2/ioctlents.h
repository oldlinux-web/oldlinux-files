{"linux/sockios.h", "IP_SET_DEV", 0x2401},
{"linux/kd.h", "SWAPMONO", 0x4B00},	/* use mca as output device */
{"linux/kd.h", "SWAPCGA", 0x4B01},	/* use cga as output device */
{"linux/kd.h", "SWAPEGA", 0x4B02},	/* use ega as output device */
{"linux/kd.h", "SWAPVGA", 0x4B03},	/* use vga as output device */
{"linux/kd.h", "CONS_CURRENT", 0x4B04},	/* return current output device */
{"linux/kd.h", "SW_B40x25", 0x4B05},	/* 40x25 mono text (cga/ega) */
{"linux/kd.h", "SW_C40x25", 0x4B06},	/* 40x24 color text (cga/ega) */
{"linux/kd.h", "SW_B80x25", 0x4B07},	/* 80x25 mono text (cga/ega) */
{"linux/kd.h", "SW_C80x25", 0x4B08},	/* 80x25 color text (cga/ega) */
{"linux/kd.h", "SW_BG320", 0x4B09},	/* 320x200 mono graphics (cga/ega) */
{"linux/kd.h", "SW_CG320", 0x4B0A},	/* 320x200 color graphics (cga/ega) */
{"linux/kd.h", "SW_BG640", 0x4B0B},	/* 640x200 mono graphics (cga/ega) */
{"linux/kd.h", "SW_CG320_D", 0x4B0C},	/* 320x200 graphics (ega mode d) */
{"linux/kd.h", "SW_CG640_E", 0x4B0D},	/* 640x200 graphics (ega mode e) */
{"linux/kd.h", "SW_EGAMONOAPA", 0x4B0E},	/* 640x350 graphics (ega mode f) */
{"linux/kd.h", "SW_ENH_MONOAPA2", 0x4B0F},	/* 640x350 graphics extd mem (ega mode f*) */
{"linux/kd.h", "SW_CG640x350", 0x4B10},	/* 640x350 graphics (ega mode 10) */
{"linux/kd.h", "SW_ENH_CG640", 0x4B11},	/* 640x350 graphics extd mem (ega mode 10*) */
{"linux/kd.h", "SW_EGAMONO80x25", 0x4B12},	/* 80x25 mono text (ega mode 7) */
{"linux/kd.h", "SW_ENHB40x25", 0x4B13},	/* enhanced 40x25 mono text (ega) */
{"linux/kd.h", "SW_ENHC40x25", 0x4B14},	/* enhanced 40x25 color text (ega) */
{"linux/kd.h", "SW_ENHB80x25", 0x4B15},	/* enhanced 80x25 mono text (ega) */
{"linux/kd.h", "SW_ENHC80x25", 0x4B16},	/* enhanced 80x25 color text (ega) */
{"linux/kd.h", "SW_ENHB80x43", 0x4B17},	/* enhanced 80x43 mono text (ega) */
{"linux/kd.h", "SW_ENHC80x43", 0x4B18},	/* enhanced 80x43 color text (ega) */
{"linux/kd.h", "SW_MCAMODE", 0x4B19},	/* reinit mca */
{"linux/kd.h", "SW_ATT640", 0x4B1A},	/* 640x400 16color */
{"linux/kd.h", "CONS_GET", 0x4B1B},	/* get current display mode */
{"linux/kd.h", "MCA_GET", 0x4B1C},	/* get mca display mode */
{"linux/kd.h", "CGA_GET", 0x4B1D},	/* get cga display mode */
{"linux/kd.h", "EGA_GET", 0x4B1E},	/* get ega display mode */
{"linux/kd.h", "MAPCONS", 0x4B1F},	/* map current video mem into address space */
{"linux/kd.h", "MAPMONO", 0x4B20},	/* map mca video mem into address space */
{"linux/kd.h", "MAPCGA", 0x4B21},	/* map cga video mem into address space */
{"linux/kd.h", "MAPEGA", 0x4B22},	/* map ega video mem into address space */
{"linux/kd.h", "MAPVGA", 0x4B23},	/* map vga video mem into address space */
{"linux/kd.h", "MCAIO", 0x4B24},	/* i/o to mca video board */
{"linux/kd.h", "CGAIO", 0x4B25},	/* i/o to cga video board */
{"linux/kd.h", "EGAIO", 0x4B26},	/* i/o to ega video board */
{"linux/kd.h", "VGAIO", 0x4B27},	/* i/o to vga video board */
{"linux/kd.h", "GIO_FONT8x8", 0x4B28},	/* gets current 8x8 font used */
{"linux/kd.h", "PIO_FONT8x8", 0x4B29},	/* use supplied 8x8 font */
{"linux/kd.h", "GIO_FONT8x14", 0x4B2A},	/* gets current 8x14 font used */
{"linux/kd.h", "PIO_FONT8x14", 0x4B2B},	/* use supplied 8x14 font */
{"linux/kd.h", "GIO_FONT8x16", 0x4B2C},	/* gets current 8x16 font used */
{"linux/kd.h", "PIO_FONT8x16", 0x4B2D},	/* use supplied 8x16 font */
{"linux/kd.h", "KDDISPTYPE", 0x4B2E},	/* gets display info */
{"linux/kd.h", "KIOCSOUND", 0x4B2F},	/* start sound generation (0 for off) */
{"linux/kd.h", "KDMKTONE", 0x4B30},	/* generate tone */
{"linux/kd.h", "KDGETLED", 0x4B31},	/* return current led flags */
{"linux/kd.h", "KDSETLED", 0x4B32},	/* set current led flags */
{"linux/kd.h", "KDGKBTYPE", 0x4B33},	/* get keyboard type */
{"linux/kd.h", "KDADDIO", 0x4B34},	/* add i/o port as valid */
{"linux/kd.h", "KDDELIO", 0x4B35},	/* del i/o port as valid */
{"linux/kd.h", "KDENABIO", 0x4B36},	/* enable i/o to video board */
{"linux/kd.h", "KDDISABIO", 0x4B37},	/* disable i/o to video board */
{"linux/kd.h", "KDQUEMODE", 0x4B38},	/* enable/disable special queue mode */
{"linux/kd.h", "KDSBORDER", 0x4B39},	/* set screen boarder in ega text mode */
{"linux/kd.h", "KDSETMODE", 0x4B3A},	/* set text/grahics mode */
{"linux/kd.h", "KDGETMODE", 0x4B3B},	/* get current mode */
{"linux/kd.h", "KDMAPDISP", 0x4B3C},	/* map display into address space */
{"linux/kd.h", "KDUNMAPDISP", 0x4B3D},	/* unmap display from address space */
{"linux/kd.h", "KDVDCTYPE", 0x4B3E},	/* return vdc controller/display info */
{"linux/kd.h", "KIOCINFO", 0x4B3F},	/* tell what the device is */
{"linux/kd.h", "GIO_SCRNMAP", 0x4B40},	/* get screen mapping from kernel */
{"linux/kd.h", "PIO_SCRNMAP", 0x4B41},	/* put screen mapping table in kernel */
{"linux/kd.h", "GIO_ATTR", 0x4B42},	/* get screen attributes */
{"linux/kd.h", "GIO_COLOR", 0x4B43},	/* return nonzero if display is color */
{"linux/kd.h", "KDGKBMODE", 0x4B44},	/* gets current keyboard mode */
{"linux/kd.h", "KDSKBMODE", 0x4B45},	/* sets current keyboard mode */
{"linux/kd.h", "KDGKBENT", 0x4B46},	/* gets one entry in translation table */
{"linux/kd.h", "KDSKBENT", 0x4B47},	/* sets one entry in translation table */
{"linux/cdrom.h", "CDROMPAUSE", 0x5301},		/* pause			*/
{"linux/cdrom.h", "CDROMRESUME", 0x5302},		/* resume			*/
{"linux/cdrom.h", "CDROMPLAYMSF", 0x5303},		/* (stuct cdrom_msf)		*/
{"linux/cdrom.h", "CDROMPLAYTRKIND", 0x5304},		/* (struct cdrom_ti)		*/
{"linux/cdrom.h", "CDROMREADTOCHDR", 0x5305},		/* (struct cdrom_tochdr)	*/
{"linux/cdrom.h", "CDROMREADTOCENTRY", 0x5306},		/* (struct cdrom_tocentry)	*/
{"linux/cdrom.h", "CDROMSTOP", 0x5307},		/* stop the drive motor		*/
{"linux/cdrom.h", "CDROMSTART", 0x5308},		/* turn the motor on 		*/
{"linux/cdrom.h", "CDROMEJECT", 0x5309},		/* eject CD-ROM media		*/
{"linux/cdrom.h", "CDROMVOLCTRL", 0x530a},		/* (struct cdrom_volctrl)	*/
{"linux/cdrom.h", "CDROMSUBCHNL", 0x530b},		/* (struct cdrom_subchnl)	*/
{"linux/cdrom.h", "CDROMREADMODE2", 0x530c},		/* (struct cdrom_read)		*/
{"linux/cdrom.h", "CDROMREADMODE1", 0x530d},		/* (struct cdrom_read)		*/
{"linux/termios.h", "TCGETS", 0x5401},
{"linux/termios.h", "TCSETS", 0x5402},
{"linux/termios.h", "TCSETSW", 0x5403},
{"linux/termios.h", "TCSETSF", 0x5404},
{"linux/termios.h", "TCGETA", 0x5405},
{"linux/termios.h", "TCSETA", 0x5406},
{"linux/termios.h", "TCSETAW", 0x5407},
{"linux/termios.h", "TCSETAF", 0x5408},
{"linux/termios.h", "TCSBRK", 0x5409},
{"linux/termios.h", "TCXONC", 0x540A},
{"linux/termios.h", "TCFLSH", 0x540B},
{"linux/termios.h", "TIOCEXCL", 0x540C},
{"linux/termios.h", "TIOCNXCL", 0x540D},
{"linux/termios.h", "TIOCSCTTY", 0x540E},
{"linux/termios.h", "TIOCGPGRP", 0x540F},
{"linux/termios.h", "TIOCSPGRP", 0x5410},
{"linux/termios.h", "TIOCOUTQ", 0x5411},
{"linux/termios.h", "TIOCSTI", 0x5412},
{"linux/termios.h", "TIOCGWINSZ", 0x5413},
{"linux/termios.h", "TIOCSWINSZ", 0x5414},
{"linux/termios.h", "TIOCMGET", 0x5415},
{"linux/termios.h", "TIOCMBIS", 0x5416},
{"linux/termios.h", "TIOCMBIC", 0x5417},
{"linux/termios.h", "TIOCMSET", 0x5418},
{"linux/termios.h", "TIOCGSOFTCAR", 0x5419},
{"linux/termios.h", "TIOCSSOFTCAR", 0x541A},
{"linux/termios.h", "FIONREAD", 0x541B},
{"linux/termios.h", "TIOCLINUX", 0x541C},
{"linux/termios.h", "TIOCCONS", 0x541D},
{"linux/termios.h", "TIOCGSERIAL", 0x541E},
{"linux/termios.h", "TIOCSSERIAL", 0x541F},
{"linux/termios.h", "TIOCPKT", 0x5420},
{"linux/termios.h", "FIONBIO", 0x5421},
{"linux/termios.h", "TIOCNOTTY", 0x5422},
{"linux/termios.h", "TIOCSETD", 0x5423},
{"linux/termios.h", "TIOCGETD", 0x5424},
{"linux/termios.h", "TCSBRKP", 0x5425},	/* Needed for POSIX tcsendbreak() */
{"linux/termios.h", "FIONCLEX", 0x5450},  /* these numbers need to be adjusted. */
{"linux/termios.h", "FIOCLEX", 0x5451},
{"linux/termios.h", "FIOASYNC", 0x5452},
{"linux/termios.h", "TIOCSERCONFIG", 0x5453},
{"linux/termios.h", "TIOCSERGWILD", 0x5454},
{"linux/termios.h", "TIOCSERSWILD", 0x5455},
{"linux/vt.h", "VT_OPENQRY", 0x5600},	/* find available vt */
{"linux/vt.h", "VT_GETMODE", 0x5601},	/* get mode of active vt */
{"linux/vt.h", "VT_SETMODE", 0x5602},	/* set mode of active vt */
{"linux/vt.h", "VT_GETSTATE", 0x5603},	/* get global vt state info */
{"linux/vt.h", "VT_SENDSIG", 0x5604},	/* signal to send to bitmask of vts */
{"linux/vt.h", "VT_RELDISP", 0x5605},	/* release display */
{"linux/vt.h", "VT_ACTIVATE", 0x5606},	/* make vt active */
{"linux/vt.h", "VT_WAITACTIVE", 0x5607},	/* wait for vt active */
{"linux/sockios.h", "FIOSETOWN", 0x8901},
{"linux/sockios.h", "SIOCSPGRP", 0x8902},
{"linux/sockios.h", "FIOGETOWN", 0x8903},
{"linux/sockios.h", "SIOCGPGRP", 0x8904},
{"linux/sockios.h", "SIOCATMARK", 0x8905},
{"linux/sockios.h", "SIOCGIFNAME", 0x8910},		/* get iface name		*/
{"linux/sockios.h", "SIOCSIFLINK", 0x8911},		/* set iface channel		*/
{"linux/sockios.h", "SIOCGIFCONF", 0x8912},		/* get iface list		*/
{"linux/sockios.h", "SIOCGIFFLAGS", 0x8913},		/* get flags			*/
{"linux/sockios.h", "SIOCSIFFLAGS", 0x8914},		/* set flags			*/
{"linux/sockios.h", "SIOCGIFADDR", 0x8915},		/* get PA address		*/
{"linux/sockios.h", "SIOCSIFADDR", 0x8916},		/* set PA address		*/
{"linux/sockios.h", "SIOCGIFDSTADDR", 0x8917},		/* get remote PA address	*/
{"linux/sockios.h", "SIOCSIFDSTADDR", 0x8918},		/* set remote PA address	*/
{"linux/sockios.h", "SIOCGIFBRDADDR", 0x8919},		/* get broadcast PA address	*/
{"linux/sockios.h", "SIOCSIFBRDADDR", 0x891a},		/* set broadcast PA address	*/
{"linux/sockios.h", "SIOCGIFNETMASK", 0x891b},		/* get network PA mask		*/
{"linux/sockios.h", "SIOCSIFNETMASK", 0x891c},		/* set network PA mask		*/
{"linux/sockios.h", "SIOCGIFMETRIC", 0x891d},		/* get metric			*/
{"linux/sockios.h", "SIOCSIFMETRIC", 0x891e},		/* set metric			*/
{"linux/sockios.h", "SIOCGIFMEM", 0x891f},		/* get memory address (BSD)	*/
{"linux/sockios.h", "SIOCSIFMEM", 0x8920},		/* set memory address (BSD)	*/
{"linux/sockios.h", "SIOCGIFMTU", 0x8921},		/* get MTU size			*/
{"linux/sockios.h", "SIOCSIFMTU", 0x8922},		/* set MTU size			*/
{"linux/sockios.h", "SIOCADDRT", 0x8940},		/* add routing table entry	*/
{"linux/sockios.h", "SIOCDELRT", 0x8941},		/* delete routing table entry	*/
{"linux/sockios.h", "SIOCDARP", 0x8950},		/* delete ARP table entry	*/
{"linux/sockios.h", "SIOCGARP", 0x8951},		/* get ARP table entry		*/
{"linux/sockios.h", "SIOCSARP", 0x8952},		/* set ARP table entry		*/
{"linux/ddi.h", "DDIOCSDBG", 0x9000},		/* set DDI debug level		*/
{"linux/ddi.h", "DDIOCGNAME", 0x9001},		/* get DDI ID name		*/
{"linux/ddi.h", "DDIOCGCONF", 0x9002},		/* get DDI HW config		*/
{"linux/ddi.h", "DDIOCSCONF", 0x9003},		/* set DDI HW config		*/
