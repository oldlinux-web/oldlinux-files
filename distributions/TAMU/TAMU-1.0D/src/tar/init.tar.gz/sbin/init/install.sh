#!/bin/sh
# #(@) Install.sh 1.0 MvS
#
# Installation script for the new init.
# This script installs init inittab reboot halt shutdown wall & man pages

#
# The system installs the binaries into these places:
#
Reboot=${BINROOTDIR}/sbin/reboot
Halt=${BINROOTDIR}/sbin/halt
Init=${BINROOTDIR}/sbin/init

#
# These binaries are installed into the place they already were
# (the install script tries to find out)
#
Shutdown=${BINROOTDIR}/sbin/shutdown
Telinit=${BINROOTDIR}/sbin/telinit
#
# Some flags
#
ConvertInittab=n

umask 022
PATH=/bin:/usr/bin:/etc:/sbin

echo "SystemV init installation script".
echo
echo "One moment, checking out your system..."
#
# See what kind of inittab this system has...
#
if [ ! -f $BINROOTDIR/etc/inittab ]
then
  echo "Well, I'm sorry. Your system is ancient: you don't have an /etc/inittab"
  echo "at all. Configure the new one, place it in /etc/and try again."
else
  if grep ^tty1 $BINROOTDIR/etc/inittab > /dev/null
  then
	ConvertInittab=y
  fi
fi
#
# Find the place of the binaries...
#
[ -x ${BINROOTDIR}/sbin/shutdown ] && Shutdown=${BINROOTDIR}/sbin/shutdown
[ -x ${BINROOTDIR}/sbin/wall ] && Wall=${BINROOTDIR}/sbin/wall
[ -x ${BINROOTDIR}/sbin/telinit ] && Telinit=${BINROOTDIR}/sbin/telinit
#
# Tell the user what we're gonna do.
#
echo
if [ $ConvertInittab = y ]
then
  echo "I'm going to convert your old inittab into the new format."
  echo "Your old inittab will be renamed to \"${BINROOTDIR}/etc/inittab.old\"."
  sleep 3
  grep -v '#' ${BINROOTDIR}/etc/inittab | (
    echo "#"
    echo "# System generated inittab"
    echo "#"
    echo "id:4:initdefault"
    echo "rc::bootwait:/etc/rc"
    echo "#"
    IFS=:
    while read line term command
    do
	echo "${line##tty}:1234:respawn:$command"
    done
    echo "#"
    echo "pf::powerwait:/etc/shutdown -rf now"
    # Be sure /etc/rc is executable
    chmod 755 ${BINROOTDIR}/etc/rc 1>&2
  ) | tee inittab.new
  echo
else
  echo "Oh! You already have a new style inittab.. I won't touch it."
fi

echo
echo "These files are going to be installed:"
echo
echo "reboot   as $Reboot"
echo "halt     as $Halt"
echo "init     as $Init"
echo "telinit  as $Telinit"
echo "shutdown as $Shutdown"
echo
echo "And the appropriate man pages in ${BINROOTDIR}/usr/man/man1 and ${BINROOTDIR}/usr/man/man8"
echo

echo "Installing."
#
# Dispose of old files.
#
rm -f $Reboot $Halt ${BINROOTDIR}/etc/shutdown ${BINROOTDIR}/bin/shutdown ${BINROOTDIR}/sbin/shutdown
rm -f $Telinit
mv ${BINROOTDIR}/sbin/init ${BINROOTDIR}/sbin/init.old
if [ $ConvertInittab = y ]
then
  mv ${BINROOTDIR}/etc/inittab ${BINROOTDIR}/etc/inittab.old
  cp inittab.new ${BINROOTDIR}/etc/inittab
  cp brc ${BINROOTDIR}/etc/brc ; chmod 755 ${BINROOTDIR}/etc/brc
fi
#
# Install new files
#
cp init $Init;	chmod 755 $Init ; ln -s /sbin/init $Telinit
cp halt $Halt;	chmod 755 $Halt
ln -s /sbin/halt $Reboot
cp shutdown $Shutdown; chmod 755 $Shutdown
ln -s /sbin/shutdown ${BINROOTDIR}/sbin/halt > /dev/null 2>&1
cp brc $BINROOTDIR/etc/brc

#
# And install the man pages.
#
if [ -d ${BINROOTDIR}/usr/man ]
then
  echo "Installing man pages..."
  for i in 1 5 8
  do
	[ ! -d ${BINROOTDIR}/usr/man/man$i ] && mkdir ${BINROOTDIR}/usr/man/man$i
	[ ! -d ${BINROOTDIR}/usr/man/cat$i ] && mkdir ${BINROOTDIR}/usr/man/cat$i
	chown man ${BINROOTDIR}/usr/man/man$i ${BINROOTDIR}/usr/man/cat$i > /dev/null 2>&1
	cp *.$i ${BINROOTDIR}/usr/man/man$i
	chmod 755 ${BINROOTDIR}/usr/man/man$i
  done
fi

echo "Installation complete. Please check everything carefully, and"
echo "then reboot. Succes!"
