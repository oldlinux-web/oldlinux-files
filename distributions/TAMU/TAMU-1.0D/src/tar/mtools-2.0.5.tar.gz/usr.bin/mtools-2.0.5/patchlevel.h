#define VERSION	"2.0.5+"
#define DATE	"5 Aug 92"

/*
 * Version 1.0		13 Oct 86
 * Version 1.1		11 Jan 87
 * Version 1.2		11 Jun 87
 * Version 1.3		15 Jun 88
 * Version 1.4		28 Sep 88
 * Version 1.5		 9 Oct 88
 * Version 1.6		 3 May 89
 * Version 2.0		 8 Sep 90
 *  patch #1		12 Oct 90
 *  patch #2		21 Nov 90
 *  patch #3		28 Nov 90
 *  patch #4		11 Apr 91
 *  patch #5		25 Aug 91
 *  Minor improvements   5 Aug 92 (WA)
 */
