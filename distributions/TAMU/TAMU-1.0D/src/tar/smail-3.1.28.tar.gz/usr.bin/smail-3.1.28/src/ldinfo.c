/*
 * This file defines the number of compiles since the first time this
 * file was created when compiling smail.  This information is used in
 * expand.c to define the values for $compile_num and $compile_date.
 * To reset the compilation count, simply remove ldinfo.c.
 */
int compile_num = 21;
char *compile_date = "21-may-94";
