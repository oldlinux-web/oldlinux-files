:
# @(#)conf/lib/xexec.sh	1.3 9/6/92 04:39:25

echo "	"$*
$*
