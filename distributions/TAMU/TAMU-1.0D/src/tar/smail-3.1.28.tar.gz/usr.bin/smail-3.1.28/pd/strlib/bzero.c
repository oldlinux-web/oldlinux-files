/* @(#)pd/strlib/bzero.c	1.2 10/24/90 05:19:25 */

/*
 * bzero(b, n)  -  zero out n bytes at b
 */
bzero(b, n)
    char *b;
    unsigned n;
{
    while (n > 0) {
	*b++ = '\0';
	--n;
    }
}
