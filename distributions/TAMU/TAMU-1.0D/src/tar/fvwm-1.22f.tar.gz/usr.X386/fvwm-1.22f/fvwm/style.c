/****************************************************************************
 * This module is all original code 
 * by Rob Nation (nation@rocket.sanders.lockheed.com 
 * Copyright 1993, Robert Nation
 *     You may use this code for any purpose, as long as the original
 *     copyright remains in the source code and all documentation
 ****************************************************************************/

/***********************************************************************
 *
 * code for parsing the fvwm style command
 *
 ***********************************************************************/
#include "../configure.h"

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <unistd.h>

#include "fvwm.h"
#include "menus.h"
#include "misc.h"
#include "parse.h"
#include "screen.h"
#include "../version.h"

void ParseStyle(char *text, FILE *fd, char **list, int *junk)
{
  extern char *orig_tline;
  char *name, *line;
  char *restofline,*tmp;
  char *icon_name = NULL;
  char *forecolor = NULL;
  char *backcolor = NULL;

  int len,desknumber = 0,bw=0, nobw = 0;
  unsigned long off_flags = 0;
  unsigned long on_flags = 0;
  
  name = stripcpy2(text,FALSE,TRUE);
  /* in case there was no argument! */
  if(name == NULL)
    return;

  restofline = stripcpy3(text,FALSE);
  line = restofline;

  if(restofline == NULL)return;
  while((*restofline != 0)&&(*restofline != '\n'))
    {
      while(isspace(*restofline))restofline++;
      if(strncasecmp(restofline,"ICON",4)==0)
	{
	  restofline +=4;
	  while(isspace(*restofline))restofline++;
	  tmp = restofline;
	  len = 0;
	  while((tmp != NULL)&&(*tmp != 0)&&(*tmp != ',')&&(*tmp != '\n'))
	    {
	      tmp++;
	      len++;
	    }
	  if(len > 0)
	    {
	      icon_name = safemalloc(len+1);
	      strncpy(icon_name,restofline,len);
	      icon_name[len] = 0;
	      off_flags |= ICON_FLAG;
	      on_flags |= SUPPRESSICON_FLAG;
	    }
	  else
	    on_flags |= SUPPRESSICON_FLAG;	    
	  restofline = tmp;
	}
      if(strncasecmp(restofline,"COLOR",5)==0)
	{
	  restofline +=5;
	  while(isspace(*restofline))restofline++;
	  tmp = restofline;
	  len = 0;
	  while((tmp != NULL)&&(*tmp != 0)&&(*tmp != ',')&&
		(*tmp != '\n')&&(*tmp != '/')&&(!isspace(*tmp)))
	    {
	      tmp++;
	      len++;
	    }
	  if(len > 0)
	    {
	      forecolor = safemalloc(len+1);
	      strncpy(forecolor,restofline,len);
	      forecolor[len] = 0;
	      off_flags |= FORE_COLOR_FLAG;
	    }

	  while(isspace(*tmp))tmp++;
	  if(*tmp == '/')
	    {
	      tmp++;
	      while(isspace(*tmp))tmp++;
	      restofline = tmp;
	      len = 0;
	      while((tmp != NULL)&&(*tmp != 0)&&(*tmp != ',')&&
		    (*tmp != '\n')&&(*tmp != '/')&&(!isspace(*tmp)))
		{
		  tmp++;
		  len++;
		}
	      if(len > 0)
		{
		  backcolor = safemalloc(len+1);
		  strncpy(backcolor,restofline,len);
		  backcolor[len] = 0;
		  off_flags |= BACK_COLOR_FLAG;
		}
	    }
	  restofline = tmp;
	}

      else if(strncasecmp(restofline,"NOICON",6)==0)
	{
	  restofline +=6;
	  off_flags |= SUPPRESSICON_FLAG;
	}
      else if(strncasecmp(restofline,"NOTITLE",7)==0)
	{
	  restofline +=7;
	  off_flags |= NOTITLE_FLAG;
	}
      else if(strncasecmp(restofline,"TITLE",5)==0)
	{
	  restofline +=5;
	  on_flags |= NOTITLE_FLAG;
	}
      else if(strncasecmp(restofline,"NOHANDLES",9)==0)
	{
	  restofline +=9;
	  off_flags |= NOBORDER_FLAG;
	}	
      else if(strncasecmp(restofline,"HANDLES",7)==0)
	{
	  restofline +=7;
	  on_flags |= NOBORDER_FLAG;
	}	
      else if(strncasecmp(restofline,"WindowListSkip",14)==0)
	{
	  restofline +=14;
	  off_flags |= LISTSKIP_FLAG;
	}	
      else if(strncasecmp(restofline,"WindowListHit",13)==0)
	{
	  restofline +=13;
	  on_flags |= LISTSKIP_FLAG;
	}	
      else if(strncasecmp(restofline,"CirculateSkip",13)==0)
	{
	  restofline +=13;
	  off_flags |= CIRCULATESKIP_FLAG;
	}	
      else if(strncasecmp(restofline,"CirculateHit",12)==0)
	{
	  restofline +=12;
	  on_flags |= CIRCULATESKIP_FLAG;
	}	
      else if(strncasecmp(restofline,"StartIconic",11)==0)
	{
	  restofline +=11;
	  off_flags |= START_ICONIC_FLAG;
	}	
      else if(strncasecmp(restofline,"StartNormal",11)==0)
	{
	  restofline +=11;
	  on_flags |= START_ICONIC_FLAG;
	}	
      else if(strncasecmp(restofline,"StaysOnTop",10)==0)
	{
	  restofline +=10;
	  off_flags |= STAYSONTOP_FLAG;	  
	}	
      else if(strncasecmp(restofline,"StaysPut",8)==0)
	{
	  restofline +=8;
	  on_flags |= STAYSONTOP_FLAG;	  
	}	
      else if(strncasecmp(restofline,"Sticky",6)==0)
	{
	  off_flags |= STICKY_FLAG;	  
	  restofline +=6;
	}	
      else if(strncasecmp(restofline,"Slippery",8)==0)
	{
	  on_flags |= STICKY_FLAG;	  
	  restofline +=8;
	}	
      else if(strncasecmp(restofline,"BorderWidth",11)==0)
	{
	  restofline +=11;
	  off_flags |= BW_FLAG;
	  sscanf(restofline,"%d",&bw);
	  while(isspace(*restofline))restofline++;
	  while((!isspace(*restofline))&&(*restofline!= 0)&&
		 (*restofline != ',')&&(*restofline != '\n'))
	    restofline++;
	  while(isspace(*restofline))restofline++;
	}
      else if(strncasecmp(restofline,"HandleWidth",11)==0)
	{
	  restofline +=11;
	  off_flags |= NOBW_FLAG;
	  sscanf(restofline,"%d",&nobw);
	  while(isspace(*restofline))restofline++;
	  while((!isspace(*restofline))&&(*restofline!= 0)&&
		 (*restofline != ',')&&(*restofline != '\n'))
	    restofline++;
	  while(isspace(*restofline))restofline++;
	}
      else if(strncasecmp(restofline,"STARTSONDESK",12)==0)
	{
	  restofline +=12;
	  off_flags |= STAYSONDESK_FLAG;
	  sscanf(restofline,"%d",&desknumber);
	  while(isspace(*restofline))restofline++;
	  while((!isspace(*restofline))&&(*restofline!= 0)&&
		 (*restofline != ',')&&(*restofline != '\n'))
	    restofline++;
	  while(isspace(*restofline))restofline++;
	}
      else if(strncasecmp(restofline,"STARTSANYWHERE",14)==0)
	{
	  restofline +=14;
	  on_flags |= STAYSONDESK_FLAG;
	}
      while(isspace(*restofline))restofline++;
      if(*restofline == ',')
	restofline++;
      else if((*restofline != 0)&&(*restofline != '\n'))
	{
	  fvwm_err("bad style command in line %s at %s",
		   orig_tline,restofline,NULL);
	  return;
	}
    }
  /* capture default icons */
  if(strcmp(name,"*") == 0)
    {
      if(off_flags & ICON_FLAG)
	Scr.DefaultIcon = icon_name;
      off_flags &= ~ICON_FLAG;
      icon_name = NULL;
    }

  /* capture default colors */
  if(strcmp(name,"*") == 0)
    {
      extern char *Stdfore, *Stdback;

      if(off_flags & FORE_COLOR_FLAG)
	Stdfore = forecolor;
      off_flags &= ~FORE_COLOR_FLAG;
      forecolor = NULL;
      if(off_flags & BACK_COLOR_FLAG)
	Stdback = backcolor;
      off_flags &= ~BACK_COLOR_FLAG;
      backcolor = NULL;
    }
  free(line);
  AddToList(name,icon_name,off_flags,on_flags,desknumber,bw,nobw,
	    forecolor,backcolor);
}


void AddToList(char *name, char *icon_name, unsigned long off_flags, 
	       unsigned long on_flags, int desk, int bw, int nobw,
	       char *forecolor, char *backcolor)
{
  name_list *nptr,*lastptr = NULL;

  if((name == NULL)||((off_flags == 0)&&(on_flags == 0)))
    {
      if(name)
	free(name);
      if(icon_name)
	free(icon_name);
      return;
    }

  /* used to merge duplicate entries, but that is no longer
   * appropriate since conficting styles are possible, and the
   * last match should win! */
  for (nptr = Scr.TheList; nptr != NULL; nptr = nptr->next)
    {
      lastptr=nptr;
    }

  nptr = (name_list *)safemalloc(sizeof(name_list));
  nptr->next = NULL;
  nptr->name = name;
  nptr->on_flags = on_flags;
  nptr->off_flags = off_flags;
  nptr->value = icon_name;
  nptr->Desk = desk;
  nptr->border_width = bw;
  nptr->resize_width = nobw;
  nptr->ForeColor = forecolor;
  nptr->BackColor = backcolor;
  if(lastptr != NULL)
    lastptr->next = nptr;
  else
    Scr.TheList = nptr;
}    

