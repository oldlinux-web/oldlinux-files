/* ckcfil.h -- File-related symbols and structures for C-Kermit */

/*
 As of edit 166, there is no ckcfil.h.  This material has been moved
 to ckcker.h.
*/

