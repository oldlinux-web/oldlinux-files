#!/site/bin/perl

open(TCPDUMP, "tcpdump -e ip |") || die "Can't open tcpdump pipe: $!\n";
while (<TCPDUMP>) {
	$|=1;
	@line=split;
	shift(@line);
	if ( $line[0] =~ /:/ && (! $uniq{$line[0]}) ) {
		$uniq{$line[0]}=1;
		print "$line[0]		$line[4]\n";
	}
	if ( $line[1] =~ /:/ && (! $uniq{$line[1]}) ) {
		$uniq{$line[1]}=1;
		print "$line[1]		$line[6]\n";
	}
}
