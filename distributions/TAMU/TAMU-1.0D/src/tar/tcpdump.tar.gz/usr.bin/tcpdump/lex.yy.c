# include "stdio.h"
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX BUFSIZ
# define output(c) putc(c,yyout)
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;
/*
 * Copyright (c) 1988-1990 The Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that: (1) source code distributions
 * retain the above copyright notice and this paragraph in its entirety, (2)
 * distributions including binary code include the above copyright notice and
 * this paragraph in its entirety in the documentation or other materials
 * provided with the distribution, and (3) all advertising materials mentioning
 * features or use of this software display the following acknowledgement:
 * ``This product includes software developed by the University of California,
 * Lawrence Berkeley Laboratory and its contributors.'' Neither the name of
 * the University nor the names of its contributors may be used to endorse
 * or promote products derived from this software without specific prior
 * written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */

#ifndef lint
static char rcsid[] =
    "@(#) $Header: tcplex.l,v 1.19 90/10/25 13:15:01 mccanne Exp $ (LBL)";
#endif

#include <sys/types.h>
#include <ctype.h>
#include "interface.h"
#include "nametoaddr.h"

#include <sys/time.h>
#include <net/bpf.h>
#include "tokdefs.h"

#ifdef FLEX_SCANNER
#undef YY_INPUT
#define YY_INPUT(buf, result, max)\
 {\
	char *src = in_buffer;\
	int i;\
\
	if (*src == 0)\
		result = YY_NULL;\
	else {\
		for (i = 0; *src && i < max; ++i)\
			buf[i] = *src++;\
		in_buffer += i;\
		result = i;\
	}\
 }
#else
#undef getc
#define getc(fp)  (*in_buffer == 0 ? EOF : *in_buffer++)
#endif

extern YYSTYPE yylval;
static char *in_buffer;

# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:
	return DST;
break;
case 2:
	return SRC;
break;
case 3:
	return ETHER;
break;
case 4:
	return ARP;
break;
case 5:
	return RARP;
break;
case 6:
	return IP;
break;
case 7:
	return TCP;
break;
case 8:
	return UDP;
break;
case 9:
	return HOST;
break;
case 10:
	return NET;
break;
case 11:
	return PORT;
break;
case 12:
	return PROTO;
break;
case 13:
	return GATEWAY;
break;
case 14:
	return LESS;
break;
case 15:
	return GREATER;
break;
case 16:
	return BYTE;
break;
case 17:
return BROADCAST;
break;
case 18:
	return AND;
break;
case 19:
	return OR;
break;
case 20:
	return '!';
break;
case 21:
	return LEN;
break;
case 22:
		;
break;
case 23:
return yytext[0];
break;
case 24:
		return GEQ;
break;
case 25:
		return LEQ;
break;
case 26:
		return NEQ;
break;
case 27:
		return LSH;
break;
case 28:
		return RSH;
break;
case 29:
		{ yylval.i = stoi(yytext); return NUM; }
break;
case 30:
{ 
			yylval.h = atoin(yytext); return HID;
}
break;
case 31:
{ yylval.e = ETHER_aton(yytext); return EID; }
break;
case 32:
	{ error("bogus ethernet address %s", yytext); }
break;
case 33:
{ yylval.s = yytext; return ID; }
break;
case 34:
{ yylval.s = yytext + 1; return ID; }
break;
case 35:
   { error("illegal token: %s\n", yytext); }
break;
case 36:
		{ error("illegal char '%c'", *yytext); }
break;
case -1:
break;
default:
fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */
void
lex_init(buf)
	char *buf;
{
	in_buffer = buf;;
}
#ifndef FLEX_SCANNER
int 
yywrap()
/* so we don't need -ll */
{
	return 1;
}				
#endif
int yyvstop[] = {
0,

35,
36,
0,

22,
36,
0,

22,
0,

23,
36,
0,

23,
36,
0,

23,
35,
36,
0,

36,
0,

29,
36,
0,

29,
36,
0,

23,
36,
0,

23,
36,
0,

33,
36,
0,

33,
36,
0,

35,
36,
0,

33,
36,
0,

33,
36,
0,

33,
36,
0,

33,
36,
0,

33,
36,
0,

33,
36,
0,

33,
36,
0,

33,
36,
0,

33,
36,
0,

33,
36,
0,

33,
36,
0,

33,
36,
0,

33,
36,
0,

33,
36,
0,

33,
36,
0,

35,
0,

26,
0,

29,
0,

27,
0,

25,
0,

24,
0,

28,
0,

33,
0,

33,
0,

34,
35,
0,

34,
0,

33,
0,

33,
0,

33,
0,

33,
0,

33,
0,

33,
0,

33,
0,

33,
0,

33,
0,

6,
33,
0,

33,
0,

33,
0,

33,
0,

19,
33,
0,

33,
0,

33,
0,

33,
0,

33,
0,

33,
0,

33,
0,

30,
0,

30,
0,

29,
0,

29,
0,

18,
33,
0,

4,
33,
0,

33,
0,

33,
0,

1,
33,
0,

33,
0,

33,
0,

33,
0,

33,
0,

21,
33,
0,

33,
0,

10,
33,
0,

20,
33,
0,

33,
0,

33,
0,

33,
0,

2,
33,
0,

7,
33,
0,

8,
33,
0,

32,
0,

33,
0,

16,
33,
0,

33,
0,

33,
0,

33,
0,

9,
33,
0,

14,
33,
0,

11,
33,
0,

33,
0,

5,
33,
0,

30,
0,

30,
0,

30,
0,

32,
0,

33,
0,

3,
33,
0,

33,
0,

33,
0,

12,
33,
0,

32,
0,

33,
0,

33,
0,

33,
0,

30,
0,

30,
0,

30,
0,

33,
0,

13,
33,
0,

15,
33,
0,

32,
0,

33,
0,

30,
0,

17,
33,
0,

32,
0,

31,
0,

31,
0,
0};
# define YYTYPE int
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	1,3,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,4,	1,5,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	1,6,	0,0,	
0,0,	0,0,	0,0,	1,7,	
0,0,	1,7,	1,7,	1,8,	
0,0,	0,0,	1,7,	1,9,	
0,0,	1,10,	1,11,	1,11,	
1,11,	1,11,	1,11,	1,11,	
1,11,	1,11,	1,11,	0,0,	
0,0,	1,12,	0,0,	1,13,	
6,33,	0,0,	1,14,	2,7,	
2,7,	12,39,	12,40,	0,0,	
1,15,	13,41,	13,42,	0,0,	
2,11,	2,11,	2,11,	2,11,	
2,11,	2,11,	2,11,	2,11,	
2,11,	0,0,	0,0,	2,12,	
0,0,	2,13,	0,0,	0,0,	
0,0,	1,16,	0,0,	0,0,	
0,0,	0,0,	1,17,	1,18,	
0,0,	1,19,	1,20,	21,53,	
1,21,	1,22,	1,23,	0,0,	
0,0,	1,24,	0,0,	1,25,	
1,26,	1,27,	24,57,	1,28,	
1,29,	1,30,	1,31,	2,16,	
21,54,	19,51,	17,47,	20,52,	
2,17,	2,18,	17,48,	2,19,	
2,20,	18,49,	2,21,	2,22,	
2,23,	22,55,	23,56,	2,24,	
18,50,	2,25,	2,26,	2,27,	
26,60,	2,28,	2,29,	2,30,	
2,31,	3,32,	3,32,	3,32,	
3,32,	3,32,	3,32,	3,32,	
3,32,	28,63,	29,64,	3,32,	
3,32,	3,32,	3,32,	3,32,	
3,32,	3,32,	3,32,	3,32,	
3,32,	3,32,	3,32,	3,32,	
3,32,	3,32,	3,32,	3,32,	
3,32,	3,32,	3,32,	3,32,	
30,65,	31,66,	3,32,	3,32,	
3,32,	3,32,	25,58,	3,32,	
37,36,	44,36,	3,32,	3,32,	
3,32,	47,73,	27,61,	3,32,	
25,59,	27,62,	48,74,	49,75,	
50,76,	51,77,	52,78,	53,79,	
54,80,	55,81,	3,32,	3,32,	
58,84,	57,82,	59,85,	3,32,	
3,32,	10,34,	57,83,	10,35,	
10,35,	10,35,	10,35,	10,35,	
10,35,	10,35,	10,35,	10,35,	
10,35,	10,36,	61,86,	62,87,	
63,88,	64,89,	65,90,	66,91,	
10,37,	10,37,	10,37,	10,37,	
10,37,	10,37,	72,34,	75,97,	
3,32,	67,92,	3,32,	67,68,	
3,32,	34,67,	34,68,	34,68,	
34,68,	34,68,	34,68,	34,68,	
34,68,	34,68,	34,68,	10,38,	
68,92,	76,98,	68,68,	78,99,	
79,100,	80,101,	81,102,	83,103,	
10,37,	10,37,	10,37,	10,37,	
10,37,	10,37,	86,104,	3,32,	
87,105,	3,32,	3,32,	3,32,	
88,106,	94,95,	97,113,	99,114,	
45,0,	45,0,	100,115,	67,93,	
101,116,	105,117,	11,34,	10,38,	
11,35,	11,35,	11,35,	11,35,	
11,35,	11,35,	11,35,	11,35,	
11,35,	11,35,	11,36,	108,118,	
109,92,	108,108,	112,111,	45,0,	
45,0,	11,37,	11,37,	11,37,	
11,37,	11,37,	11,37,	45,0,	
45,0,	113,122,	115,123,	67,93,	
116,124,	120,121,	122,129,	123,130,	
124,131,	126,126,	127,118,	14,43,	
14,43,	129,135,	14,44,	14,44,	
14,44,	14,44,	14,44,	14,44,	
14,44,	14,44,	14,44,	14,44,	
14,36,	11,37,	11,37,	11,37,	
11,37,	11,37,	11,37,	14,44,	
14,44,	14,44,	14,44,	14,44,	
14,44,	14,43,	14,43,	14,43,	
14,43,	14,43,	14,43,	14,43,	
14,43,	14,43,	14,43,	14,43,	
14,43,	14,43,	14,43,	14,43,	
14,43,	14,43,	14,43,	14,43,	
14,43,	133,134,	135,138,	139,140,	
0,0,	14,43,	0,0,	14,44,	
14,44,	14,44,	14,44,	14,44,	
14,44,	14,43,	14,43,	14,43,	
14,43,	14,43,	14,43,	14,43,	
14,43,	14,43,	14,43,	14,43,	
14,43,	14,43,	14,43,	14,43,	
14,43,	14,43,	14,43,	14,43,	
14,43,	15,43,	15,43,	0,0,	
15,43,	15,43,	15,43,	15,43,	
15,43,	15,43,	15,43,	15,43,	
15,43,	15,43,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	15,43,	15,43,	15,43,	
15,43,	15,43,	15,43,	15,43,	
15,43,	15,43,	15,43,	15,43,	
15,43,	15,43,	15,43,	15,43,	
15,43,	15,43,	15,43,	15,43,	
15,43,	15,43,	15,43,	15,43,	
15,43,	15,43,	15,43,	0,0,	
107,118,	0,0,	107,108,	15,43,	
0,0,	15,43,	15,43,	15,43,	
15,43,	15,43,	15,43,	15,43,	
15,43,	15,43,	15,43,	15,43,	
15,43,	15,43,	15,43,	15,43,	
15,43,	15,43,	15,43,	15,43,	
15,43,	15,43,	15,43,	15,43,	
15,43,	15,43,	15,43,	16,45,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	16,0,	
16,0,	35,34,	107,119,	35,69,	
35,69,	35,69,	35,69,	35,69,	
35,69,	35,69,	35,69,	35,69,	
35,69,	35,36,	0,0,	0,0,	
0,0,	46,46,	0,0,	0,0,	
0,0,	0,0,	16,0,	16,0,	
0,0,	46,0,	46,0,	0,0,	
16,46,	0,0,	16,0,	16,0,	
16,45,	0,0,	107,119,	16,46,	
16,46,	125,126,	16,46,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
46,0,	46,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	16,46,	
46,0,	46,0,	46,46,	0,0,	
0,0,	16,46,	36,70,	36,70,	
36,70,	36,70,	36,70,	36,70,	
36,70,	36,70,	36,70,	36,70,	
36,71,	0,0,	0,0,	0,0,	
0,0,	125,132,	0,0,	36,70,	
36,70,	36,70,	36,70,	36,70,	
36,70,	38,72,	38,72,	38,72,	
38,72,	38,72,	38,72,	38,72,	
38,72,	38,72,	38,72,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	38,72,	38,72,	
38,72,	38,72,	38,72,	38,72,	
0,0,	125,132,	0,0,	36,70,	
36,70,	36,70,	36,70,	36,70,	
36,70,	69,34,	0,0,	69,69,	
69,69,	69,69,	69,69,	69,69,	
69,69,	69,69,	69,69,	69,69,	
69,69,	0,0,	0,0,	0,0,	
0,0,	0,0,	38,72,	38,72,	
38,72,	38,72,	38,72,	38,72,	
70,94,	70,94,	70,94,	70,94,	
70,94,	70,94,	70,94,	70,94,	
70,94,	70,94,	70,95,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	70,94,	70,94,	70,94,	
70,94,	70,94,	70,94,	71,96,	
71,96,	71,96,	71,96,	71,96,	
71,96,	71,96,	71,96,	71,96,	
71,96,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
71,96,	71,96,	71,96,	71,96,	
71,96,	71,96,	0,0,	0,0,	
0,0,	70,94,	70,94,	70,94,	
70,94,	70,94,	70,94,	92,107,	
92,108,	92,108,	92,108,	92,108,	
92,108,	92,108,	92,108,	92,108,	
92,108,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
71,96,	71,96,	71,96,	71,96,	
71,96,	71,96,	93,109,	93,109,	
93,109,	93,109,	93,109,	93,109,	
93,109,	93,109,	93,109,	93,109,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	93,109,	
93,109,	93,109,	93,109,	93,109,	
93,109,	95,110,	95,110,	95,110,	
95,110,	95,110,	95,110,	95,110,	
95,110,	95,110,	95,110,	95,111,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	95,110,	95,110,	
95,110,	95,110,	95,110,	95,110,	
0,0,	0,0,	0,0,	93,109,	
93,109,	93,109,	93,109,	93,109,	
93,109,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	96,112,	
96,112,	96,112,	96,112,	96,112,	
96,112,	96,112,	96,112,	96,112,	
96,112,	0,0,	95,110,	95,110,	
95,110,	95,110,	95,110,	95,110,	
96,112,	96,112,	96,112,	96,112,	
96,112,	96,112,	110,120,	110,120,	
110,120,	110,120,	110,120,	110,120,	
110,120,	110,120,	110,120,	110,120,	
110,121,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	110,120,	
110,120,	110,120,	110,120,	110,120,	
110,120,	0,0,	0,0,	0,0,	
96,112,	96,112,	96,112,	96,112,	
96,112,	96,112,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
111,96,	111,96,	111,96,	111,96,	
111,96,	111,96,	111,96,	111,96,	
111,96,	111,96,	0,0,	110,120,	
110,120,	110,120,	110,120,	110,120,	
110,120,	111,96,	111,96,	111,96,	
111,96,	111,96,	111,96,	118,125,	
118,126,	118,126,	118,126,	118,126,	
118,126,	118,126,	118,126,	118,126,	
118,126,	0,0,	0,0,	0,0,	
0,0,	0,0,	119,127,	119,127,	
119,127,	119,127,	119,127,	119,127,	
119,127,	119,127,	119,127,	119,127,	
0,0,	111,96,	111,96,	111,96,	
111,96,	111,96,	111,96,	119,127,	
119,127,	119,127,	119,127,	119,127,	
119,127,	121,128,	121,128,	121,128,	
121,128,	121,128,	121,128,	121,128,	
121,128,	121,128,	121,128,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	121,128,	121,128,	
121,128,	121,128,	121,128,	121,128,	
0,0,	0,0,	0,0,	119,127,	
119,127,	119,127,	119,127,	119,127,	
119,127,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	128,133,	
128,133,	128,133,	128,133,	128,133,	
128,133,	128,133,	128,133,	128,133,	
128,133,	128,134,	121,128,	121,128,	
121,128,	121,128,	121,128,	121,128,	
128,133,	128,133,	128,133,	128,133,	
128,133,	128,133,	132,136,	132,136,	
132,136,	132,136,	132,136,	132,136,	
132,136,	132,136,	132,136,	132,136,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	132,136,	
132,136,	132,136,	132,136,	132,136,	
132,136,	0,0,	0,0,	0,0,	
128,133,	128,133,	128,133,	128,133,	
128,133,	128,133,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
134,137,	134,137,	134,137,	134,137,	
134,137,	134,137,	134,137,	134,137,	
134,137,	134,137,	0,0,	132,136,	
132,136,	132,136,	132,136,	132,136,	
132,136,	134,137,	134,137,	134,137,	
134,137,	134,137,	134,137,	137,139,	
137,139,	137,139,	137,139,	137,139,	
137,139,	137,139,	137,139,	137,139,	
137,139,	137,140,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
137,139,	137,139,	137,139,	137,139,	
137,139,	137,139,	0,0,	0,0,	
0,0,	134,137,	134,137,	134,137,	
134,137,	134,137,	134,137,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	140,141,	140,141,	140,141,	
140,141,	140,141,	140,141,	140,141,	
140,141,	140,141,	140,141,	0,0,	
137,139,	137,139,	137,139,	137,139,	
137,139,	137,139,	140,141,	140,141,	
140,141,	140,141,	140,141,	140,141,	
141,142,	141,142,	141,142,	141,142,	
141,142,	141,142,	141,142,	141,142,	
141,142,	141,142,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	141,142,	141,142,	141,142,	
141,142,	141,142,	141,142,	0,0,	
0,0,	0,0,	140,141,	140,141,	
140,141,	140,141,	140,141,	140,141,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	0,0,	0,0,	0,0,	
0,0,	141,142,	141,142,	141,142,	
141,142,	141,142,	141,142,	0,0,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+-1,	0,		0,	
yycrank+-27,	yysvec+1,	0,	
yycrank+144,	0,		yyvstop+1,
yycrank+0,	0,		yyvstop+4,
yycrank+0,	0,		yyvstop+7,
yycrank+3,	0,		yyvstop+9,
yycrank+0,	0,		yyvstop+12,
yycrank+0,	yysvec+3,	yyvstop+15,
yycrank+0,	0,		yyvstop+19,
yycrank+163,	0,		yyvstop+21,
yycrank+236,	0,		yyvstop+24,
yycrank+9,	0,		yyvstop+27,
yycrank+12,	0,		yyvstop+30,
yycrank+274,	0,		yyvstop+33,
yycrank+352,	0,		yyvstop+36,
yycrank+-474,	0,		yyvstop+39,
yycrank+12,	yysvec+14,	yyvstop+42,
yycrank+15,	yysvec+14,	yyvstop+45,
yycrank+6,	yysvec+14,	yyvstop+48,
yycrank+7,	yysvec+14,	yyvstop+51,
yycrank+6,	yysvec+15,	yyvstop+54,
yycrank+22,	yysvec+15,	yyvstop+57,
yycrank+22,	yysvec+15,	yyvstop+60,
yycrank+13,	yysvec+15,	yyvstop+63,
yycrank+81,	yysvec+15,	yyvstop+66,
yycrank+26,	yysvec+15,	yyvstop+69,
yycrank+79,	yysvec+15,	yyvstop+72,
yycrank+56,	yysvec+15,	yyvstop+75,
yycrank+40,	yysvec+15,	yyvstop+78,
yycrank+77,	yysvec+15,	yyvstop+81,
yycrank+77,	yysvec+15,	yyvstop+84,
yycrank+0,	yysvec+3,	yyvstop+87,
yycrank+0,	0,		yyvstop+89,
yycrank+193,	0,		0,	
yycrank+439,	0,		yyvstop+91,
yycrank+498,	0,		0,	
yycrank+126,	0,		0,	
yycrank+521,	0,		0,	
yycrank+0,	0,		yyvstop+93,
yycrank+0,	0,		yyvstop+95,
yycrank+0,	0,		yyvstop+97,
yycrank+0,	0,		yyvstop+99,
yycrank+0,	yysvec+15,	yyvstop+101,
yycrank+127,	yysvec+15,	yyvstop+103,
yycrank+-267,	yysvec+16,	yyvstop+105,
yycrank+-500,	yysvec+16,	yyvstop+108,
yycrank+89,	yysvec+15,	yyvstop+110,
yycrank+82,	yysvec+15,	yyvstop+112,
yycrank+84,	yysvec+15,	yyvstop+114,
yycrank+80,	yysvec+15,	yyvstop+116,
yycrank+81,	yysvec+15,	yyvstop+118,
yycrank+94,	yysvec+15,	yyvstop+120,
yycrank+83,	yysvec+15,	yyvstop+122,
yycrank+99,	yysvec+15,	yyvstop+124,
yycrank+86,	yysvec+15,	yyvstop+126,
yycrank+0,	yysvec+15,	yyvstop+128,
yycrank+95,	yysvec+15,	yyvstop+131,
yycrank+88,	yysvec+15,	yyvstop+133,
yycrank+90,	yysvec+15,	yyvstop+135,
yycrank+0,	yysvec+15,	yyvstop+137,
yycrank+108,	yysvec+15,	yyvstop+140,
yycrank+112,	yysvec+15,	yyvstop+142,
yycrank+110,	yysvec+15,	yyvstop+144,
yycrank+126,	yysvec+15,	yyvstop+146,
yycrank+114,	yysvec+15,	yyvstop+148,
yycrank+115,	yysvec+15,	yyvstop+150,
yycrank+191,	yysvec+34,	yyvstop+152,
yycrank+206,	yysvec+34,	yyvstop+154,
yycrank+555,	0,		yyvstop+156,
yycrank+576,	0,		0,	
yycrank+599,	yysvec+36,	0,	
yycrank+188,	yysvec+38,	yyvstop+158,
yycrank+0,	yysvec+15,	yyvstop+160,
yycrank+0,	yysvec+15,	yyvstop+163,
yycrank+138,	yysvec+15,	yyvstop+166,
yycrank+152,	yysvec+15,	yyvstop+168,
yycrank+0,	yysvec+15,	yyvstop+170,
yycrank+154,	yysvec+15,	yyvstop+173,
yycrank+155,	yysvec+15,	yyvstop+175,
yycrank+160,	yysvec+15,	yyvstop+177,
yycrank+142,	yysvec+15,	yyvstop+179,
yycrank+0,	yysvec+15,	yyvstop+181,
yycrank+144,	yysvec+15,	yyvstop+184,
yycrank+0,	yysvec+15,	yyvstop+186,
yycrank+0,	yysvec+15,	yyvstop+189,
yycrank+150,	yysvec+15,	yyvstop+192,
yycrank+152,	yysvec+15,	yyvstop+194,
yycrank+160,	yysvec+15,	yyvstop+196,
yycrank+0,	yysvec+15,	yyvstop+198,
yycrank+0,	yysvec+15,	yyvstop+201,
yycrank+0,	yysvec+15,	yyvstop+204,
yycrank+631,	0,		0,	
yycrank+654,	0,		0,	
yycrank+215,	0,		0,	
yycrank+677,	0,		yyvstop+207,
yycrank+715,	yysvec+95,	0,	
yycrank+174,	yysvec+15,	yyvstop+209,
yycrank+0,	yysvec+15,	yyvstop+211,
yycrank+161,	yysvec+15,	yyvstop+214,
yycrank+159,	yysvec+15,	yyvstop+216,
yycrank+164,	yysvec+15,	yyvstop+218,
yycrank+0,	yysvec+15,	yyvstop+220,
yycrank+0,	yysvec+15,	yyvstop+223,
yycrank+0,	yysvec+15,	yyvstop+226,
yycrank+170,	yysvec+15,	yyvstop+229,
yycrank+0,	yysvec+15,	yyvstop+231,
yycrank+398,	yysvec+92,	yyvstop+234,
yycrank+249,	yysvec+92,	yyvstop+236,
yycrank+250,	yysvec+93,	yyvstop+238,
yycrank+738,	0,		0,	
yycrank+776,	yysvec+95,	yyvstop+240,
yycrank+240,	0,		0,	
yycrank+210,	yysvec+15,	yyvstop+242,
yycrank+0,	yysvec+15,	yyvstop+244,
yycrank+213,	yysvec+15,	yyvstop+247,
yycrank+211,	yysvec+15,	yyvstop+249,
yycrank+0,	yysvec+15,	yyvstop+251,
yycrank+799,	0,		0,	
yycrank+814,	0,		0,	
yycrank+255,	0,		0,	
yycrank+837,	yysvec+95,	yyvstop+254,
yycrank+217,	yysvec+15,	yyvstop+256,
yycrank+194,	yysvec+15,	yyvstop+258,
yycrank+202,	yysvec+15,	yyvstop+260,
yycrank+473,	yysvec+118,	yyvstop+262,
yycrank+269,	yysvec+118,	yyvstop+264,
yycrank+272,	yysvec+119,	yyvstop+266,
yycrank+875,	0,		0,	
yycrank+206,	yysvec+15,	yyvstop+268,
yycrank+0,	yysvec+15,	yyvstop+270,
yycrank+0,	yysvec+15,	yyvstop+273,
yycrank+898,	0,		0,	
yycrank+307,	0,		0,	
yycrank+936,	yysvec+95,	yyvstop+276,
yycrank+250,	yysvec+15,	yyvstop+278,
yycrank+0,	yysvec+132,	yyvstop+280,
yycrank+959,	0,		0,	
yycrank+0,	yysvec+15,	yyvstop+282,
yycrank+309,	0,		0,	
yycrank+997,	yysvec+95,	yyvstop+285,
yycrank+1020,	yysvec+95,	yyvstop+287,
yycrank+0,	yysvec+112,	yyvstop+289,
0,	0,	0};
struct yywork *yytop = yycrank+1122;
struct yysvf *yybgin = yysvec+1;
char yymatch[] = {
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,012 ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
011 ,'!' ,01  ,01  ,01  ,01  ,'&' ,01  ,
'!' ,'!' ,'*' ,'*' ,01  ,'-' ,'.' ,'*' ,
'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,'0' ,
'0' ,'0' ,'*' ,01  ,'&' ,'&' ,'&' ,01  ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'G' ,
'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,
'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,
'G' ,'G' ,'G' ,'&' ,01  ,'&' ,01  ,'.' ,
01  ,'A' ,'A' ,'A' ,'A' ,'A' ,'A' ,'G' ,
'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,
'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,'G' ,
'G' ,'G' ,'G' ,01  ,'&' ,01  ,01  ,01  ,
0};
char yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
#ifndef lint
static	char ncform_sccsid[] = "@(#)ncform 1.6 88/02/08 SMI"; /* from S5R2 1.2 */
#endif

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
yyback(p, m)
	int *p;
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
yyinput(){
	return(input());
	}
yyoutput(c)
  int c; {
	output(c);
	}
yyunput(c)
   int c; {
	unput(c);
	}
