/*-----------------------------------------------------------------------------
  xfmc.h

  (c) Simon Marlow 1992
-----------------------------------------------------------------------------*/

#ifndef XFMC_H
#define XFMC_H

#define XFM_OPEN_WINDOW   "XFM_OPEN_WINDOW"
#define XFM_UPDATE_WINDOW "XFM_UPDATE_WINDOW"

#endif
