#ifndef lint
static char patchlevel[] = "@(#) patchlevel 5.0";
#endif
