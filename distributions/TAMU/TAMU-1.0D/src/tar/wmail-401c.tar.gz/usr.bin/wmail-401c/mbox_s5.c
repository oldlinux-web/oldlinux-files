/*
 * WMAIL        MicroWalt Extended Mail Agent.
 *              Local message delivery, SystemV-style, which uses
 *              "binary" mailboxes in the user's home directory.
 *              Forwarding goes like V7.
 *
 * Author:      Fred N. van Kempen, <waltje@uwalt.nl.mugnet.org>
 *		Copyright 1988-1992 MicroWalt Corporation
 */
#include "wmail.h"
#if (BOX_TYPE == BOX_SYSV)
#include <sys/stat.h>
#include <sys/wait.h>


#endif  /* BOX_TYPE */
