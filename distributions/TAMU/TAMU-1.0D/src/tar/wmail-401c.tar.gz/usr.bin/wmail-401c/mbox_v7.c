/*
 * WMAIL        MicroWalt Extended Mail Agent.
 *              Local message delivery, V7-style, which is similar to
 *              V6-style, except that forwarding is now done by putting
 *              a file ".forward" in the user's home directory, which
 *              contains the forwarding address.
 *
 * Author:      Fred N. van Kempen, <waltje@uwalt.nl.mugnet.org>
 *		Copyright 1988-1992 MicroWalt Corporation
 */
#include "wmail.h"
#include <sys/stat.h>


