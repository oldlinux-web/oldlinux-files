/*
 * gopher.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 * This handles talking to the gopher server (a nightmare).  They should
 * cut their losses with Gopher+ and make a Gopher++ which sticks
 * a MIME header on the top of documents which are sent to gopher++ clients
 * like HTTP.  Heck, gopher should be thrown away and everyone should
 * use HTTP.
 *
 */
#include <stdio.h>
#include <ctype.h>

#ifndef NOSTDHDRS
#include <stdlib.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>

#include <fcntl.h>

#include "document.h"
#include "access.h"
#include "net.h"
#include "util.h"
#include "url.h"
#include "conf.h"

#if NeedFunctionPrototypes
static char *gopher_to_html(char *, int, char *, char *, char *);
extern int DisplayTransferStatus(char *);
#else
static char *gopher_to_html();
extern int DisplayTransferStatus();
#endif

/*
 * gopher_read
 *
 * Read data from a gopher server.  This needs to learn how to hack
 * the '.' off the end.  Actually there are several ways for the
 * server to terminate the data.  Swell.
 */
static char *
gopher_read(s, len)
int s;
int *len;
{
  char buffer[BUFSIZ];
  char stats[256];
  char *t;
  int tlen, btlen;
  int blen;

  /*
   * Read info from the FTP host
   */
  t = NULL;
  tlen = 0;
  btlen = 0;
  while ((blen = net_read(s, buffer, sizeof(buffer))) > 0)
  {
    tlen += blen;

    if (t)
    {
      t = (char *)realloc(t, tlen + 1);
    }
    else
    {
      t = (char *)malloc(tlen + 1);
    }
    if (t == NULL)
    {
      break;
    }

    memcpy(t + btlen, buffer, blen);
    btlen = tlen;

    sprintf (stats, LOAD_MESSAGE, tlen);
    if (DisplayTransferStatus(stats) == 1)
    {
      free(t);
      t = NULL;

      return(NULL);
    }
  }

  *len = tlen;

  return(t);
}

/*
 * gopher_main
 *
 * Request a document from a gopher/gopher+ server.  Converts directories
 * into HTML files so that subdirectories can be accessed.
 *
 * This code needs a rewrite.  I figured out basically how gopher
 * works and then figured the rest out by telnet'ing to a gopher
 * port and trying stuff out.  This is not good.  Also, gopher/gopher+
 * URLs are not handled very well.  I added my own bogus gopher+
 * access method.
 *
 */
static void
gopher_main(d, hostname, portno, filename, ext, plus)
Document *d;
char *hostname;
int portno;
char *filename;
char *ext;
int plus;
{
  char *searchstr = NULL;
  char *t = NULL;
  char *plainfilename = NULL;
  char buffer[256];
  int s;
  int tlen;

  d->type = DocUnknown;
  d->text = NULL;

  /*
   * The gopher server WANTS spaces.
   */ 
  filename = UnescapeURL(filename);
  if (filename == NULL)
  {
    return;
  }

  /*
   * Check to see if there is a search string.
   */
  if (ext[0] == '?')
  {
    searchstr = ext;
  }

  if (filename[1] == '\0')
  {
    free(filename);
    filename = alloc_string("/11/");
    if (filename == NULL)
    {
      return;
    }
  }
  else if (filename[2] == '/' || filename[2] == '\0')
  {
    char *tfilename;

    tfilename = alloc_string_mem(strlen(filename) + 2);
    if (tfilename == NULL)
    {
      return;
    }
    sprintf (tfilename, "/%c%s", filename[1], filename + 1);
    free(filename);
    filename = tfilename;
  }

  plainfilename = alloc_string(filename);
  if (plainfilename == NULL)
  {
    free(filename);

    return;
  }

  /*
   * If the type is index then check to see if the user has entered
   * a search string.  If not then return and ask for a query string
   * using the <isindex> command.
   */
  switch (filename[1])
  {
    case '7':
      if (searchstr == NULL)
      {
	d->text = alloc_string("<h1>Search</h1>\nEnter a search specification. <isindex>");
	d->type = DocInternal;
	d->content = alloc_string("text/html");
	free(filename);
	free(plainfilename);
	return;
      }
      else
      {
	filename = recomb_string(filename, "\t");
	filename = recomb_string(filename, searchstr + 1);
      }
      break;

    default: ;
  }

  if (portno == -1)
  {
    portno = DEFAULT_GOPHER_PORT;
  }

  s = net_open(hostname, portno);
  if (s < 0)
  {
    free(filename);
    free(plainfilename);
    return;
  }

  filename = recomb_string(filename, "\n");
  net_write(s, filename + 2, strlen(filename + 2));

  /*
   * Read info from the Gopher host
   */
  t = gopher_read(s, &tlen);

  net_close(s);

  if (t == NULL)
  {
    free(plainfilename);
    free(filename);
    return;
  }

  /*
   * Now reconnect and grab the gopher+ information.  This is really
   * kind of hokey, but then, so is gopher+.
   */
  if (plus &&
      filename[1] != '1' &&
      filename[1] != '8' &&
      filename[1] != '7')
  {
    s = net_open(hostname, portno);
    if (s >= 0)
    {
      char *vt;
      char *g;
      int vlen;
      
      /*
       * First strip the \n and tack on "\t!\n"
       */
      filename[strlen(filename) - 1] = '\0';
      filename = recomb_string(filename, "\t!\n");

      /*
       * Send request
       */
      net_write(s, filename + 2, strlen(filename + 2));

      /*
       * Grab up information.
       */
      vt = gopher_read(s, &vlen);
      net_close(s);

      if (vt == NULL)
      {
	free(filename);
	free(plainfilename);
	return;
      }

      /*
       * Now grab the view information.
       */
      g = vt;
      while ((g = get_line(g, buffer, sizeof(buffer))) != NULL)
      {
	if (strncmp("+VIEWS:", buffer, 7) == 0)
	{
	  g = get_line(g, buffer, sizeof(buffer));
	  if (g != NULL)
	  {
	    /*
	     * info->content will be a little oversized but who cares.
	     */
	    d->content = alloc_string(buffer);
	    sscanf (buffer, "%s", d->content);
	  }
	}
      }

      free(vt);
      vt = NULL;

      net_close(s);
    }
  }

  /*
   * Do some processing on the information.  If it a directory do some
   * really special stuff.  If it is a file then do other stuff.  See
   * file.c for file processing.
   */
  if (t)
  {
    if (t[tlen - 3] == '.' && t[tlen - 2] == '\r' && t[tlen - 1] == '\n')
    {
      tlen -= 3;
      t[tlen] = '\0';
    }
    else
    {
      t[tlen] = '\0';
    }

    if (t[0] == '\0')
    {
      d->text = alloc_string("<h1>Info</h1>No data is available.");
      d->type = DocInternal;

      free(filename);
      free(plainfilename);
      return;
    }

    switch (filename[1])
    {
      case '8': /* telnet.  this is scary */
        fprintf (stderr, "Gopher telnet bug.\n");
	break;

      /*
       * Convert these guys to HTML.
       */
      case '\0': /* directories */
      case '1': /* directories */
      case '7': /* indexes */
        d->text = gopher_to_html(hostname, portno, plainfilename + 2, ext, t);
	if (d->text != NULL)
	{
	  d->type = DocInternal;
	  d->content = alloc_string("text/html");
	  d->len = strlen(d->text);
	}
	break;

      /*
       * Everything else
       */
      default:
	/*
	 * Check for an error.  Don't mess with it further.
	 */
	if (plus && t[0] == '-')
	{
	  d->text = NULL;
	  free(t);
	  t = NULL;
	}
	else
	{
	  d->type = DocUnknown;
	  d->text = t;
	  d->len = tlen;
	}
	break;
    }
  }

  free(filename);
  free(plainfilename);

  return;
}

/*
 * gopherplus
 *
 * This is the gopher+ frontend to gopher_man
 */
void
gopherplus(d, hostname, portno, filename, ext)
Document *d;
char *hostname;
int portno;
char *filename;
char *ext;
{
  gopher_main(d, hostname, portno, filename, ext, 1);

  return;
}

/*
 * gopherplain
 *
 * The plain gopher frontend to gopher_main
 */
void
gopherplain(d, hostname, portno, filename, ext)
Document *d;
char *hostname;
int portno;
char *filename;
char *ext;
{
  gopher_main(d, hostname, portno, filename, ext, 0);

  return;
}

#define GOPHER_DISPLAY 0
#define GOPHER_SELECTOR 1
#define GOPHER_HOST 2
#define GOPHER_PORT 3
#define GOPHER_EXTRA 4
#define GOPHER_FIELD_COUNT 5

/*
 * gopher_to_html
 *
 * Converts gopher directory information into HTML.
 *
 * John thinks gopher sucks.
 */
static char *
gopher_to_html(hostname, portno, filename, ext, t)
char *hostname;
int portno;
char *filename;
char *ext;
char *t;
{
  /*
   * What's with the big strings?!?
   */
  char gf[GOPHER_FIELD_COUNT][256]; /* fields in gopher line */
  char buffer[256];
  char *p;
  char *f = NULL;
  char *form;
  char *junk = NULL;
  char *stuff;
  char *cp;
  char gtype;
  int i;
  int gfno;
  int flen;
  static char *header = "<title>Gopher directory %s on %s</title>\n<ul>\n";
  static char *header2 = "<title>Gopher search for %s</title>\n<ul>\n";
  static char *format  = "<li> <a href=gopher://%s:%s/%c%s> %s </a>\n";
  static char *eformat = "<li> <a href=gopherp://%s:%s/%c%s> %s </a>\n";
  static char *trailer = "</ul>";
  /*
   * The telform definition had to be changed to provide the information to 
   * html needed to prompt the user for the login name.  RSE@GMI
   */
  static char *telform = "<li> <a href=telnet://%s@%s:%s/> Telnet to %s </a>\n";

  switch (filename[0])
  {
    case '7':
      f = alloc_string_mem(strlen(header2) + strlen(ext) + 1);
      if (f == NULL)
      {
	return(NULL);
      }
      sprintf (f, header2, ext + 1);
      break;
    case '1':
    case '\0':
      f = alloc_string_mem(strlen(header) +
			   strlen(filename) +
			   strlen(hostname) + 1);
      if (f == NULL)
      {
	return(NULL);
      }
      sprintf (f, header, filename, hostname);
      break;
    default:
      f = alloc_string_mem(1);
      if (f == NULL)
      {
	return(NULL);
      }
      f[0] = '\0';
  }
  flen = strlen(f);

  /*
   * Now grab up each gopher line and convert it to an HTML menu item.
   */
  p = t;
  while ((p = get_line(p, buffer, sizeof(buffer))) != NULL)
  {
    /*
     * Make sure that the fields are blank in case someone leaves a
     * field out.
     */
    for (gfno = 0; gfno < GOPHER_FIELD_COUNT; gfno++)
    {
      gf[gfno][0] = '\0';
    }

    /*
     * Separate the TAB separated fields.
     */
    gtype = buffer[0];
    for (i = 0, cp = buffer + 1, gfno = 0;
	 *cp && gfno < GOPHER_FIELD_COUNT;
	 cp++)
    {
      if (*cp == '\t')
      {
	gf[gfno][i] = '\0';
	i = 0;
	gfno++;
      }
      else
      {
	gf[gfno][i++] = *cp;
      }
    }
    gf[gfno][i] = '\0';

    /*
     * Check for empty fields.
     */
    if (gf[GOPHER_HOST][0] == '\0')
    {
      strcpy(gf[GOPHER_HOST], hostname);
    }

    if (gf[GOPHER_HOST][0] == '\0')
    {
      strcpy(gf[GOPHER_HOST], hostname);
    }

    /*
     * Select the proper form.
     */
    switch (gtype)
    {
      case '8':
        form = telform;
	stuff = gf[GOPHER_SELECTOR];
        break;

      default:
	if (gf[GOPHER_EXTRA][0] == '+' && gf[GOPHER_SELECTOR][0] != '1')
	{
	  form = eformat;
	}
	else
	{
	  form = format;
	}
	/*
	 * Make sure the weird characters are escaped.
	 */
	junk = EscapeURL(gf[GOPHER_SELECTOR]);
	if (junk != NULL)
	{
	  stuff = junk;
	}
	else
	{
	  stuff = gf[GOPHER_SELECTOR];
	}
    }
    
    /*
     * Now make a bit of HTML for the gopher line.
     */
    flen += strlen(form) + strlen(gf[GOPHER_HOST]) + strlen(stuff) +
	strlen(gf[GOPHER_DISPLAY]) + strlen(gf[GOPHER_PORT]) + 2;
    
    f = (char *)realloc(f, flen);
    if (f == NULL)
    {
      free(t);
      
      if (junk)
      {
	free(junk);
      }
      
      return(NULL);
    }
    
    if (gtype != '8')
    {
      sprintf(f + strlen(f), form,
	      gf[GOPHER_HOST],
	      gf[GOPHER_PORT],
	      buffer[0],
	      stuff,
	      gf[GOPHER_DISPLAY]);
    }
    /*
     * presumably the next case consists entirely of type 8,
     * therefore the login 
     * name for gopher accounts normally carried in the Path field is
     * necessary.
     * It doesn't appear to be available as a named variable, so I am
     * referring 
     * to it as gf[1].  RSE@GMI
     */
    else
    {
      sprintf(f + strlen(f), form,
              stuff,
	      gf[GOPHER_HOST],
	      gf[GOPHER_PORT],
	      gf[GOPHER_DISPLAY]);
    }
    
    if (junk)
    {
      free(junk);
      junk = NULL;
    }
  }

  /*
   * Put a trailer on the HTML document.
   */ 
  flen += strlen(trailer) + 1;
  f = (char *)realloc(f, flen);
  if (f == NULL)
  {
    free(t);

    if (junk)
    {
      free(junk);
    }

    return(NULL);
  }
  strcpy(f + strlen(f), trailer);

  free(t);

  return(f);
}


