/*
 * widget.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * Note that this code was actually written by Jim.Rees@umich.edu.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 * Patches for box configuration written by Jim.Rees@umich.edu (pretty
 * much this entire file).
 *
 */ 
#include <stdio.h>

#ifndef NOSTDHDRS
#include <stdlib.h>
#endif

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>

#include <X11/Xaw/Form.h>
#include <X11/Xaw/Paned.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Viewport.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/Scrollbar.h>

#include <X11/Xaw/Cardinals.h>

#include "ScrollText.h"

#define _NO_PROTO

#include "HTML.h"

#include "document.h"
#include "bookmark.h"
#include "content.h"
#include "requester.h"
#include "lister.h"
#include "widget.h"
#include "conf.h"
#include "util.h"

static struct ButtonTable {
  char *name;
  Widget w;
  void (*cb)();
} ButtonTable[] = {
  {"quit",      NULL, Quit},
  {"open",	NULL, DoRequester},
  {"home",	NULL, Home},
  {"back",	NULL, Back},
  {"source",	NULL, Source},
  {"reload",	NULL, Reload},
  {"save",      NULL, DoRequester},
  {"help",	NULL, Help},
  {"cancel",    NULL, Cancel},
  {"bookmark",	NULL, DoLister},
  {"print",     NULL, DoRequester},
  {"search",    NULL, DoRequester},
  {NULL,        NULL, NULL},
};

static void
AddButtons(r, box, list)
HTMLRoot *r;
Widget box;
char *list;
{
  char name[256];
  struct ButtonTable *btp;

  list = alloc_string(list);

  while (sscanf(list, " %[^,]", name) == 1)
  {
    /*
     * Find the listed button and create its widget
     */
    for (btp = &ButtonTable[0]; btp->name != NULL; btp++)
    {
      if (!mystrcmp(btp->name, name))
      {
	btp->w = XtCreateManagedWidget(btp->name,
				       commandWidgetClass,
				       box,
				       NULL, ZERO);
	XtAddCallback(btp->w, XtNcallback, btp->cb, r);
	break;
      }
    }

    /*
     * Fill in the entry in HTMLRoot for the widget.
     */
    if (!mystrcmp(name, "open"))
      r->load = btp->w;
    else if (!mystrcmp(name, "home"))
      r->home = btp->w;
    else if (!mystrcmp(name, "back"))
      r->back = btp->w;
    else if (!mystrcmp(name, "source"))
      r->source = btp->w;
    else if (!mystrcmp(name, "reload"))
      r->reload = btp->w;
    else if (!mystrcmp(name, "save"))
      r->save = btp->w;
    else if (!mystrcmp(name, "help"))
      r->help = btp->w;
    else if (!mystrcmp(name, "bookmark"))
      r->bookmark = btp->w;
    else if (!mystrcmp(name, "cancel"))
      r->cancel = btp->w;
    else if (!mystrcmp(name, "print"))
      r->print = btp->w;
    else if (!mystrcmp(name, "search"))
      r->search = btp->w;
    else if (!mystrcmp(name, "quit"))
      r->quit = btp->w;

    /*
     * Skip to the next comma-delimited item in the list
     */
    while (*list && *list != ',')
      list++;
    if (*list == ',')
      list++;
  }

  return;
}

/*
 * CreateWidgets
 *
 * Create the command and box widgets.
 */
void
CreateWidgets(r)
HTMLRoot *r;
{
  Widget paned, box, form;
  Arg args[3];
  XtCallbackRec cbrec[2];

  /*
   * Main window pane
   */
  paned = XtCreateManagedWidget("paned",
                                panedWidgetClass, r->toplevel, 
                                NULL, ZERO);


  /*
   * Button pane(s)
   */
  if (r->button1Box && *r->button1Box)
  {
    box = XtCreateManagedWidget("box1", boxWidgetClass, paned, NULL, ZERO);
    AddButtons(r, box, r->button1Box);
  }

  if (r->button2Box && *r->button2Box)
  {
    box = XtCreateManagedWidget("box3", boxWidgetClass, paned, NULL, ZERO);
    AddButtons(r, box, r->button2Box);
  }


  /*
   * Third pane. Title display.
   */
  if (r->showTitle)
  {
    form = XtCreateManagedWidget("box5",
				formWidgetClass, paned,
				NULL, ZERO);
    
    XtCreateManagedWidget("titlelabel",
			  labelWidgetClass, form,
			  NULL, ZERO);
    
    r->titledisplay = XtCreateManagedWidget("titledisplay",
					      scrollingTextWidgetClass, form,
					      NULL, ZERO);
    r->titledisplay = XtNameToWidget(r->titledisplay, "text");
  }

  /*
   * Fourth pane.  URL display.
   */
  if (r->showURL)
  {
    form = XtCreateManagedWidget("box4",
				formWidgetClass, paned,
				NULL, ZERO);
    
    XtCreateManagedWidget("urllabel",
			  labelWidgetClass, form,
			  NULL, ZERO);
    
    r->urldisplay = XtCreateManagedWidget("urldisplay",
					    scrollingTextWidgetClass, form,
					    NULL, ZERO);
    r->urldisplay = XtNameToWidget(r->urldisplay, "text");
  }

  /*
   * Fifth pane, the HTML viewing area
   */
  r->w = XtCreateManagedWidget("html",
                              htmlWidgetClass, paned,
                              NULL, ZERO);
  XtAddCallback(r->w, WbNanchorCallback, Anchor, r);

  /*
   * Mmmmmm descriptive.
   */
  XtSetArg(args[0], WbNresolveImageFunction, ImageResolve);
  XtSetArg(args[1], WbNpreviouslyVisitedTestFunction, VisitTest);

  cbrec[0].callback = SubmitForm;
  cbrec[0].closure = (XtPointer)r;
  cbrec[1].callback = 0;
  cbrec[1].closure = 0;
  XtSetArg(args[2], WbNsubmitFormCallback, cbrec);

  XtSetValues(r->w, args, 3);

  return;
}




