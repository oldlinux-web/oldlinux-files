/*
 * url.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 */
#include <stdio.h>
#include <ctype.h>

#ifndef NOSTDHDRS
#include <stdlib.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>

#include <fcntl.h>

#include "url.h"
#include "util.h"
#include "conf.h"

/*
 * StripSearchURL
 *
 * Takes the ?mumble off the end.
 */
void
StripSearchURL(url)
char *url;
{
  char *cp;

  for (cp = url; *cp; cp++)
  {
    if (*cp == '?')
    {
      *cp = '\0';
      break;
    }
  }

  return;
}

/*
 * FixURL
 *
 * Fixes URLs for searches.  May do more fixing later.
 *
 * Thanks Jim.Rees@umich.edu
 */
char *
FixURL(url)
char *url;
{
  char *s, *cp;

  s = alloc_string(url);
  for (cp = s; *cp; cp++)
  {
    if (*cp == ' ')
    {
      *cp = '+';
    }
  }
  return(s);
}

/*
 * EscapeURL
 *
 * Puts escape codes in URLs.  NOT complete.
 */
char *
EscapeURL(url)
char *url;
{
  char *cp;
  char *n, *s;
  static char *hex = "0123456789ABCDEF"; /* back to my C64 days... */

  /*
   * use a bit of memory so i don't have to mess around here
   */
  s = n = alloc_string_mem(strlen(url) * 3 + 1);
  if (s == NULL)
  {
    return(NULL);
  }

  for (cp = url; *cp; cp++, n++)
  {
    if (*cp <= ' ' || *cp == '%' || *cp == '&' || *cp == '=')
    {
      *n = '%';
      n++;
      *n = hex[*cp / 16];
      n++;
      *n = hex[*cp % 16];
    }
    else
    {
      *n = *cp;
    }
  }

  *n = '\0';

  return(s);
}

/*
 * UnescapeURL
 *
 * Converts the escape codes (%xx) into actual characters.  NOT complete.
 * Could do everthing in place I guess.
 */
char *
UnescapeURL(url)
char *url;
{
  char *cp, *n, *s;
  char hex[3];

  s = n = alloc_string_mem(strlen(url) + 1);
  if (n == NULL)
  {
    return(NULL);
  }

  for (cp = url; *cp; cp++, n++)
  {
    if (*cp == '%')
    {
      cp++;
      if (*cp == '%')
      {
	*n = *cp;
      }
      else
      {
	hex[0] = *cp;
	cp++;
	hex[1] = *cp;
	hex[2] = '\0';
	*n = (char)strtol(hex, NULL, 16);
      }
    }
    else
    {
      *n = *cp;
    }
  }

  *n = '\0';

  return(s);
}

/*
 * MakeURL
 *
 * Takes two URLs and uses one to use as context for the other
 * possibly incomplete URL.  If this guy gets a memory allocation
 * error then he just bails and returns NULL and lets someone
 * else handle it.
 */
char *
MakeURL(url, context, link, linklen)
char *url;
char *context;
char *link; /* ugly */
int linklen;
{
  char *u = NULL;
  char access[256], access2[256];
  char hostname[256], hostname2[256];
  char filename[256], filename2[256];
  char ext[256], ext2[256];
  int portno, portno2;
  long flags, flags2;
  int len;

  if (url == NULL)
  {
    return(NULL);
  }

  portno = -1;
  access[0] = '\0';
  hostname[0] = '\0';
  filename[0] = '\0';
  ext[0] = '\0';
  flags = ParseURL(url,
		   access, sizeof(access),
		   hostname, sizeof(hostname),
		   &portno,
		   filename, sizeof(filename),
		   ext, sizeof(ext));
  if (flags == 0)
  {
    return(NULL);
  }

  if (ext[0] == '#' && link != NULL && linklen > 0)
  {
    len = strlen(ext);
    len = (len > linklen - 1 ? linklen - 1:len);
    strncpy(link, ext, len);
    link[len] = '\0';
  }

  /*
   * The access and hostname has been supplied or there is no context.
   */
  if (((flags & URL_ACCESS) && (flags & URL_HOSTNAME)) || context == NULL)
  {
    if (!(flags & URL_ACCESS))
    {
      u = alloc_string_mem(strlen(url) + strlen(ext) + 6);
      if (u != NULL)
      {
	strcpy(u, "file:");
	strcat(u, url);
	strcat(u, ext);
      }
    }
    else
    {
      u = alloc_string(url);
    }

    return(u);
  }

  /*
   * This could cause problems but will probably be OK and it removes
   * a lot of garbage later on.  The extra memory is made up by
   * the speedup and code clean up and the fact that this amount of
   * memory is negligible compared to what the rest of the program
   * uses.  Why I am trying to justify this?
   */
  len = strlen(url) * 3;
  if (context != NULL)
  {
    len += strlen(context) * 3;
  }

  u = alloc_string_mem(len);
  if (u == NULL)
  {
    return(NULL);
  }
  strcpy(u, url); /* so we can return at any time */

  portno2 = -1;
  access2[0] = '\0';
  hostname2[0] = '\0';
  filename2[0] = '\0';
  ext2[0] = '\0';
  flags2 = ParseURL(context,
		    access2, sizeof(access2),
		    hostname2, sizeof(hostname2),
		    &portno2,
		    filename2, sizeof(filename2),
		    ext2, sizeof(ext2));
  
  /*
   * Eliminate the cases where the context can't be used.
   */
  if ((flags & URL_ACCESS) && (flags2 & URL_ACCESS))
  {
    if (strcmp(access, access2) != 0)
    {
      return(u);
    }
  }
  
  /*
   * Use the url and the supplied context to construct a new url.
   * Jim Rees to the rescue!
   */
  if ((flags | flags2) & URL_ACCESS)
  {
    strcpy(u, (flags & URL_ACCESS) ? access : access2);
    strcat(u, ":");

    if ((flags | flags2) & URL_HOSTNAME)
    {
      strcat(u, "//");
      strcat(u, (flags & URL_HOSTNAME) ? hostname : hostname2);

      if ((flags | flags2) & URL_PORTNO)
      {
	sprintf (u + strlen(u), ":%d",
		 (flags & URL_PORTNO) ? portno : portno2);
      }
    }
  }
  else
  {
    strcpy(u, "file:");
  }

  if (filename[0] == '/' || filename[0] == '~')
  {
    /*
     * I love this kind of stuff.  Right.
     */
    if (filename[0] == '~' && u[strlen(u) - 1] != '/')
    {
      strcat(u, "/");
    }
    strcat(u, filename);
  }
  else
  {
    /*
     * This includes an attempt to deal with '..' and '.'
     */
    int i;
    int len;
    int start;
    int backcount = 0;

    backcount = 0;
    start = 0;
    len = strlen(filename);
    for (i = 0; i < len; i++)
    {
      if (strncmp(filename + i, "../", 3) == 0)
      {
	start = i + 3;
	i += 2;
	backcount++;
      }
      else if (strncmp(filename + i, "./", 2) == 0)
      {
	start = i + 2;
	i += 1;
      }
    }

    for (i = strlen(filename2) - 1; i >= 0; i--)
    {
      if (filename2[i] == '/')
      {
	if (backcount-- == 0)
	{
	  filename2[i + 1] = '\0';
	  break;
	}
      }
    }

    if (i == -1)
    {
      strcat(u, filename + start);
    }
    else
    {
      strcat(u, filename2);
      strcat(u, filename + start);
    }
  }

  strcat(u, ext);

  return(u);
}

/*
 * ParseURL
 *
 * Parses a URL and picks out the parts.  It returns
 * a long with bits sets indicating which parts were in the
 * URL.
 *
 * This could probably be rewritten.
 *
 */
long
ParseURL(url, a, alen, h, hlen, portno, f, flen, e, elen)
char *url;
char *a;
int alen;
char *h;
int hlen;
int *portno;
char *f;
int flen;
char *e;
int elen;
{
  int p;
  int i, lasti;
  int digit_count;
  unsigned long flags = 0;

  /*
   * Look for an access method.
   */
  for (i = 0; *(url + i); i++)
  {
    if (*(url + i) == '/')
    {
      break;
    }
    else if (*(url + i) == ':')
    {
      if (i < alen)
      {
	if (a)
	{
	  strncpy(a, url, i);
	  a[i] = '\0';
	  flags |= URL_ACCESS;
	}
	break;
      }
      else
      {
	return(0);
      }
    }
  }

  /*
   * There was no colon then start at the beginning otherwise jump past
   * the colon.
   */
  if (url[i] == ':')
  {
    i++;
  }
  else
  {
    i = 0;
  }

  /*
   * Look for the hostname.  If the // isn't there then the rest
   * must be a filename.  If the // is there then look for a
   * portno or for the start of the filename.
   */
  if (url[i] == '/' && url[i + 1] == '/')
  {
    i += 2; /* get past the // */
    lasti = i;

    /*
     * Look for 'host:portno' or 'host' ended by '/' or NULL
     */
    for (; ; i++)
    {
      /*
       * If not special character add to hostname else terminate hostname
       * and hunt for port number
       */
      if (url[i] == ':' || url[i] == '/' || url[i] == '\0')
      {
	if (i - lasti < hlen)
	{
	  if (h)
	  {
	    strncpy(h, url + lasti, i - lasti);
	    h[i - lasti] = '\0';
	    flags |= URL_HOSTNAME;
	  }
	}
	else
	{
	  return(0);
	}

	/*
	 * Did we happen upon a port number?
	 */
	if (url[i] == ':')
	{
	  int isign = 1;

	  i++;

	  if (url[i] == '-')
	  {
	    isign = -1;
	    i++;
	  }

	  for (digit_count = 0, p = 0;
	       isdigit(url[i]);
	       i++)
	  {
	    p = p * 10 + (url[i] - '0');
	    digit_count++;
	  }
	  p *= isign;

	  if (url[i] != '/' && url[i] != '\0')
	  {
	    return(-1);
	  }
	  else
	  {
	    if (portno)
	    {
	      if (digit_count == 0 || p < 0)
	      {
		*portno = -1;
	      }
	      else
	      {
		*portno = p;
		flags |= URL_PORTNO;
	      }
	    }
	  }
	}
	break;
      }
    }
  }

  /*
   * The rest must be a filename.  If the rest is NULL then give a
   * slash.
   */
  lasti = i;

  if (url[i] == '\0')
  {
    if (f)
    {
      strcpy(f, "/"); /* i hope they provided at least two chars */
      flags |= URL_FILENAME;
    }
  }
  else
  {
    for (; url[i] != '\0'; i++)
    {
      if (url[i] == '#' || url[i] == '?' || url[i] == '$')
      {
	int j;

	if (e)
	{
	  for (j = i; url[j] != '\0' && j - i < elen - 1; j++)
	  {
	    e[j - i] = url[j];
	  }
	  e[j - i] = '\0';

	  flags |= URL_EXTENSION;
	}

	break;
      }
    }
    if (i - lasti < flen)
    {
      if (f)
      {
	strncpy(f, url + lasti, i - lasti);
	f[i - lasti] = '\0';
	flags |= URL_FILENAME;
      }
    }
    else
    {
      return(0);
    }
  }

  return(flags);
}

