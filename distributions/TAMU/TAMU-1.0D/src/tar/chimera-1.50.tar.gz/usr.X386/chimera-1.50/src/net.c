/*
 * net.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 */
#include <stdio.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/param.h>
#include <netinet/in.h>
#include <netdb.h>

#include "net.h"
#include "util.h"

#ifdef SYSV
# define bzero(dst,len) memset(dst,0,len)
# define bcopy(src,dst,len) memmove(dst,src,len)
#endif /*SYSV*/

#ifdef TERM
#include <client.h>
#endif

/*
 * There is a now a regular net_open and a term net_open.  The combination
 * was getting hairy. john.
 */

#ifdef TERM
/*
 * net_open
 *
 * open network connection to a host
 *
 */
int
net_open(hostname, portno)
char *hostname;
int portno;
{
  static char hostlast[161];
  static int lastlocal = 0;
  int s;
#ifndef NONETWORK
  struct sockaddr_in addr;
  struct hostent *hp;
  
  if ((!strcmp(hostname, "noterm")) ||
      (lastlocal && (!strcmp(hostname, ""))))
  {
    lastlocal = 1;
    hostname = "localhost";

    bzero(&addr, sizeof(addr));
    
    /* fix by Jim Rees so that numeric addresses are dealt with */
    if ((addr.sin_addr.s_addr = inet_addr(hostname)) == -1)
    {
      if ((hp = gethostbyname(hostname)) == NULL)
      {
	return(-1);
      }
      bcopy(hp->h_addr, &(addr.sin_addr), hp->h_length);
    }
    
    addr.sin_family = AF_INET;
    addr.sin_port = htons(portno);
    
    s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (s < 0)
    {
      return(-1);
    }
    
    if (connect(s, &addr, sizeof(addr)) < 0)
    {
      return(-1);
    }
  }
  else
#endif
  {
    lastlocal = 0;
    /* Patched in by Tom Boutell; swiped from whoever ported termirc! */
    if (hostname[0] != '\0')
    {
      strcpy(hostlast, hostname);
    }
    else
    {
      hostname = hostlast;
    }
    
    if ((s = connect_server(0)) < 0)
    {
      perror("chimera+term: connect to term server");
      return(-3);
    }
    
    send_command(s, C_PORT, 0, "%s:%d", hostname, portno);
    send_command(s, C_DUMB, 1, 0);
  }

  return (s);
}

#else /* TERM */

/*
 * net_open
 *
 * open network connection to a host.  the regular version.
 *
 */
int
net_open(hostname, portno)
char *hostname;
int portno;
{
  int s;
  struct sockaddr_in addr;
  struct hostent *hp;

  bzero(&addr, sizeof(addr));

  /* fix by Jim Rees so that numeric addresses are dealt with */
  if ((addr.sin_addr.s_addr = inet_addr(hostname)) == -1)
  {
    if ((hp = gethostbyname(hostname)) == NULL)
    {
      return(-1);
    }
    bcopy(hp->h_addr, &(addr.sin_addr), hp->h_length);
  }

  addr.sin_family = AF_INET;
  addr.sin_port = htons(portno);

  s = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (s < 0)
  {
    return(-1);
  }
 
#ifndef SOCKS 
  if (connect(s, &addr, sizeof(addr)) < 0)
#else
  if (Rconnect(s, &addr, sizeof(addr)) <0)
#endif
  {
    return(-1);
  }
  
  return(s);
}
#endif /* TERM */

/*
 * net_write
 *
 * write data on a network connection
 *
 */
int
net_write(s, data, datalen)
int s;
char *data;
int datalen;
{
  if (write(s, data, datalen) <= 0)
  {
    return(-1);
  }

  return(0);
}

/*
 * net_read
 *
 * read data from a network connection
 *
 */
int
net_read(s, data, datalen)
int s;
char *data;
int datalen;
{
  int rv;

  rv = read(s, data, datalen);

#ifdef TERM
  if (rv == 4 && strcmp(data, "@>2") == 0)
  {
    return(-1);
  }
#endif

  return(rv);
}

/*
 * net_close
 *
 * close a network connection
 *
 */
void
net_close(s)
int s;
{
  close(s);

  return;
}

/*
 * net_islocal
 *
 * Determines if a hostname is the local host.  This will probably screw
 * up if a host is on two networks and stuff like that.
 *
 */
int
net_islocal(hostname)
char *hostname;
{
  return(0);
}

/*
 * net_gethostname
 *
 * Returns the full domain name of the local host.  Thanks Jim.
 */
char *
net_gethostname()
{
  static char *domain = NULL;

  if (domain == NULL)
  {
    char myname[100];
    struct hostent *hp;

    if (gethostname(myname, sizeof(myname)) < 0)
    {
      fprintf (stderr, "can't gethostname\n");

      return(NULL);
    }

    if ((hp = gethostbyname(myname)) == NULL)
    {
      fprintf(stderr, "can't gethostbyname\n");

      return(NULL);
    }

    domain = alloc_string(hp->h_name);
  }

  return(domain);
}



