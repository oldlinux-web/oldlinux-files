/*
 *
 * requester.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 */ 
#include <stdio.h>

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>

#include <X11/cursorfont.h>

#include <ScrollText.h>

#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Paned.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Form.h>

#include <X11/Xaw/Cardinals.h>

#include "requester.h"

static Widget requester = 0;
static void (*returnfunc)();
static XtPointer cldata;
static Widget okw;

/*
 * OKFunc
 *
 * Called when the user presses return.
 */
static void
OKFunc()
{
  (*returnfunc)(okw, cldata, NULL);
  
  return;
}

/*
 * CreateRequester
 *
 */
void
CreateRequester(parent, flist, clist, callback_data)
Widget parent;
Field *flist;
RequesterCommand *clist;
XtPointer callback_data;
{
  Widget paned, box;
  Arg args[4];
  Dimension width, height;
  Widget label;
  int i;
  Display *dpy;
  Window rw, cw;
  int rx, ry, wx, wy;
  unsigned int mask;
  int dwidth, dheight;
  XtActionsRec action_rec[1];
  static RequesterCallbackData d;

  if (requester)
  {
    fprintf (stderr, "WARNING: nested requesters\n");
  }

  requester = XtCreatePopupShell("Requester",
				 transientShellWidgetClass, parent,
				 NULL, 0);
  
  paned = XtCreateManagedWidget("requesterpaned",
                                panedWidgetClass, requester,
                                NULL, 0);
  
  for (i = 0; flist[i].name; i++)
  {
    box = XtCreateManagedWidget("requestertextbox",
                                formWidgetClass, paned,
                                NULL, 0);
    
    label = XtCreateManagedWidget(flist[i].prompt,
			  labelWidgetClass, box,
			  NULL, 0);

    flist[i].w = XtCreateManagedWidget(flist[i].name,
				       scrollingTextWidgetClass, box,
				       NULL, 0);
    XtSetArg(args[0], XtNwidth, flist[i].width);
    XtSetArg(args[1], XtNheight, flist[i].height);
    XtSetArg(args[2], XtNfromVert, label);
    XtSetValues(flist[i].w, args, 3);

    flist[i].w = XtNameToWidget(flist[i].w, "text");

    if (flist[i].fdef == NULL)
    {
      XtSetArg(args[0], XtNstring, "");
    }
    else
    {
      XtSetArg(args[0], XtNstring, flist[i].fdef);
    }
    XtSetArg(args[1], XtNeditType, XawtextEdit);
    XtSetValues(flist[i].w, args, 2);

    action_rec[0].proc = (XtActionProc)OKFunc;
    action_rec[0].string = "ok-func";
    XtAppAddActions(XtWidgetToApplicationContext(flist[i].w),
                    action_rec, 1);

    XtOverrideTranslations(flist[i].w,
                            XtParseTranslationTable(
                            "Ctrl<Key>M:    ok-func()\n\
                            Ctrl<Key>J:    ok-func()\n\
                            <Key>Linefeed: ok-func()\n\
                            <Key>Return:   ok-func()"));
  }
  
  box = XtCreateManagedWidget("requesterbox",
			      boxWidgetClass, paned,
			      NULL, 0);

  d.cbdata = callback_data;
  d.flist = flist;
  d.clist = clist;
  cldata = (XtPointer)&d;

  for (i = 0; clist[i].name != NULL; i++)
  {
    clist[i].w = XtCreateManagedWidget(clist[i].name,
				       commandWidgetClass, box,
				       NULL, 0);
    XtAddCallback(clist[i].w, XtNcallback, clist[i].func, (XtPointer)&d);
  }
  okw = clist[0].w;
  returnfunc = clist[0].func;

  /*
   * not centered but close enough
   */
  XtRealizeWidget(requester);

  dpy = XtDisplay(parent);
  XQueryPointer(dpy, XtWindow(requester),
		&rw, &cw,
		&rx, &ry,
		&wx, &wy,
		&mask);

  XtSetArg(args[0], XtNwidth, &width);
  XtSetArg(args[1], XtNheight, &height);
  XtGetValues(requester, args, 2);
  
  dwidth = DisplayWidth(dpy, DefaultScreen(dpy));
  dheight = DisplayHeight(dpy, DefaultScreen(dpy));

  if (rx + width > dwidth)
  {
    rx -= rx + width - dwidth;
  }
  if (ry + height > dheight)
  {
    ry -= ry + height - dheight;
  }

  XtSetArg(args[0], XtNx, rx);
  XtSetArg(args[1], XtNy, ry);
  XtSetValues(requester, args, 2);

  XtPopup(requester, XtGrabNone);

  return;
}

/*
 * DestroyRequester
 *
 */
void
DestroyRequester()
{
  XtPopdown(requester);

  XtDestroyWidget(requester);
  requester = 0;
  return;
}

/*
 * RaiseRequester
 */
void
RaiseRequester()
{
  XRaiseWindow(XtDisplay(requester), XtWindow(requester));

  return;
}
