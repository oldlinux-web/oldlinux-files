/*
 * document.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 * Handles document caching.
 *
 */
#include <stdio.h>
#include <ctype.h>

#ifndef NOSTDHDRS
#include <stdlib.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>

#include <fcntl.h>

#include "access.h"
#include "document.h"
#include "url.h"
#include "local.h"
#include "util.h"
#include "net.h"
#include "conf.h"

#define FIRST_ID 1

/*
 * CreateDocument
 *
 * Allocates the structure used for documents.  Could do other
 * init stuff, too.  This function should always be called to create
 * a new document.  It provides initialization for the document which
 * is good if an old part of the program doesn't know about new
 * document attributes.
 */
static Document *
CreateDocument()
{
  Document *d;

  d = (Document *)malloc(sizeof(Document));
  if (d)
  {
    d->url = NULL;
    d->text = NULL;
    d->otext = NULL;
    d->ext = NULL;
    d->type = DocUnknown;
    d->otype = DocUnknown;
    d->content = NULL;
    d->ref_count = 0;
    d->last_access = 0;
    d->cnext = NULL;
  }

  return(d);
}

/*
 * TransferDocument
 *
 * Kludge for http.c
 */
void
TransferDocument(dest, src)
Document *dest, *src;
{
  if (dest->url) free(dest->url);
  if (dest->text) free(dest->text);
  if (dest->content) free(dest->content);
  if (dest->ext) free(dest->ext);
  if (dest->otext) free(dest->otext);

  dest->ext = src->ext;
  dest->text = src->text;
  dest->otext = src->otext;
  dest->len = src->len;
  dest->type = src->type;
  dest->url = src->url;
  dest->content = src->content;

  free(src);

  return;
}

/*
 * DestroyDocument
 *
 * Deallocates a document.  DON'T USE IT AGAIN.
 */
static void
DestroyDocument(d)
Document *d;
{
  if (d->text) free(d->text);
  if (d->content) free(d->content);
  if (d->url) free(d->url);
  if (d->ext) free(d->ext);
  if (d->otext) free(d->otext);

  free(d);

  return;
}

/*
 * MakeDocument
 *
 * Creates a document using supplied HTML.
 */
Document *
MakeDocument(html)
char *html;
{
  Document *d;

  d = CreateDocument();
  if (d == NULL)
  {
    return(NULL);
  }

  d->url = NULL;
  d->text = alloc_string(html);
  if (d->text == NULL)
  {
    DestroyDocument(d);
    d = NULL;
  }
  else
  {
    d->len = strlen(d->text);
    d->type = DocInternal;
  }

  return(d);
}

/*
 * Tells which functions to call for each access.
 */
struct name
{
  char *name;
  void (*func)();
  char *command;
};

static struct name methods[] = 
{
  { "ftp", ftp, NULL },
  { "http", http, NULL },
  { "gopher", gopherplain, NULL },
  { "gopherp", gopherplus, NULL },
  { "file", file, NULL },
  { "telnet", telnet, NULL },
  { "tn3270", telnet, NULL },
  { NULL, NULL, NULL },
};

/*
 * DownloadDocument
 *
 * This is a frontend to the document network grab code.
 */
static Document *
DownloadDocument(url)
char *url;
{
  int i;
  Document *d;
  char hostname[256];
  char filename[256];
  char access[256];
  char ext[256];
  int portno;
  unsigned long flags;

  portno = -1;
  access[0] = '\0';
  hostname[0] = '\0';
  filename[0] = '\0';
  ext[0] = '\0';
  flags = ParseURL(url,
                   access, sizeof(access),
                   hostname, sizeof(hostname),
                   &portno,
                   filename, sizeof(filename),
                   ext, sizeof(ext));
  if (flags == 0)
  {
    return(NULL);
  }

  if (!(flags & URL_ACCESS)) access[0] = '\0';
  if (!(flags & URL_HOSTNAME)) hostname[0] = '\0';
  if (!(flags & URL_FILENAME)) filename[0] = '\0';
  if (!(flags & URL_PORTNO)) portno = -1;

  d = CreateDocument();
  if (d == NULL)
  {
    return(NULL);
  }

  d->url = alloc_string(url);
  if (d->url == NULL)
  {
    DestroyDocument(d);
    return(NULL);
  }

  /*
   * Now we have the URL business figured out so pick the function which
   * handles the transfer mechanism indicated.  Returns results in d.
   */
  for (i = 0; methods[i].name != NULL; i++)
  {
    if (strcmp(access, methods[i].name) == 0)
    {
      (methods[i].func)(d, hostname, portno, filename, ext);
      break;
    }
  }

  if (d->text == NULL)
  {
    DestroyDocument(d);
    d = NULL;
  }

  return(d);
}

/*
 * The document cache list.
 */
static Document *dcache = NULL;

/*
 * IsCached
 *
 * Returns 1 if the specified URL is in the cache, otherwise returns 0.
 */
int
IsCached(url)
char *url;
{
  int i, len;
  Document *c;
  
  len = strlen(url);
  for (i = 0; i < len; i++)
  {
    if (url[i] == '#')
    {
      break;
    }
  }
  
  c = dcache;
  if (i == len)
  {
    while (c)
    {
      if (strcmp(c->url, url) == 0)
      {
	return(1);
      }
      c = c->cnext;
    }
  }
  else
  {
    while (c)
    {
      if (strncmp(c->url, url, i) == 0 &&
	  c->url[i + 1] == '#' && url[i + 1] == '#')
      {
	return(1);
      }
      c = c->cnext;
    }
  }
  
  return(0);
}

/*
 * CleanCache
 *
 * Cleans the cache of dead documents.  Dead documents have a
 * reference count of 0 and TTL has passed since the last reference.
 */
static void
CleanCache()
{
  Document *t, *c, *o;
  long now;

  now = (long)time((long *)0);

  t = NULL;
  c = dcache;
  while (c)
  {
    /*
     * Check to see if anyone has a hold of the document.
     */
    if (c->ref_count == 0 && now - c->last_access > DOC_TTL)
    {
      if (t == NULL)
      {
	dcache = c->cnext;
      }
      else
      {
	t->cnext = c->cnext;
      }
      o = c;
      c = c->cnext;
      DestroyDocument(o);
    }
    else
    {
      c = c->cnext;
    }
  }

  return;
}

/*
 * ReleaseDocument
 *
 * Tells the cache system that the document is no longer being
 * referenced.  If it is no longer being referenced then the time to
 * live stuff decides when the document is deallocated
 */
void
ReleaseDocument(d)
Document *d;
{
  if (d->url == NULL)
  {
    DestroyDocument(d);
  }
  else
  {
    if (d->type == DocExternal)
    {
      d->type = DocUnknown;
    }

    if (d->ref_count)
    {
      d->ref_count--;
    }
    if (d->ref_count == 0)
    {
      d->last_access = (long)time((long *)0);
    }
  }

  CleanCache();

  return;
}

/*
 * LoadDocumentMain
 *
 * Grabs a document from the cache if it exists or grabs the document from
 * the net.
 */
static Document *
LoadDocumentMain(url, reload)
char *url;
int reload;
{
  Document *c = NULL;

  /*
   * Check to see if the thing is in the cache.  If it is then return
   * it immediately.
   */
  if (!reload)
  {
    int i, len;

    len = strlen(url);
    for (i = 0; i < len; i++)
    {
      if (url[i] == '#')
      {
	break;
      }
    }

    c = dcache;
    if (i == len)
    {
      while (c)
      {
	if (strcmp(c->url, url) == 0)
	{
	  break;
	}
	c = c->cnext;
      }
    }
    else
    {
      while (c)
      {
	if (strncmp(c->url, url, i) == 0 &&
	    c->url[i + 1] == '#' && url[i + 1] == '#')
	{
	  break;
	}
	c = c->cnext;
      }
    }
  }

  /*
   * If the document is in the cache then increment the reference count
   * and return else
   * try to download the document.
   */
  if (c != NULL)
  {
    c->ref_count++;
  }
  else
  {
    c = DownloadDocument(url);
    if (c != NULL)
    {
      if (!reload)
      {
	c->ref_count = 1;
	c->cnext = dcache;
	c->last_access = (long)time((long *)0);
	dcache = c;
      }
    }
    else
    {
      char *t;

      /*
       * The document could not be found so whip up an error message.
       */
      t = alloc_string("<h1>Error</h1>Couldn't load document<p>");
      if (t != NULL)
      {
	t = recomb_string(t, url);
	if (t != NULL)
	{
	  c = MakeDocument(t);
	  free(t);
	}
      }
    }
  }

  if (!reload)
  {
    CleanCache();
  }

  return(c);
}

/*
 * ReloadDocument
 *
 * Forces the next grab of the document to come from its source and not
 * the cache.
 */
void
ReloadDocument(d)
Document *d;
{
  Document *t;

  t = LoadDocumentMain(d->url, 1);
  if (t != NULL)
  {
    TransferDocument(d, t);
  }

  return;
}

/*
 * LoadDocument
 *
 * Frontend for LoadDocumentMain
 */
Document *
LoadDocument(url)
char *url;
{
  return(LoadDocumentMain(url, 0));
}
