/*
 *
 * lister.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 */ 
#include <stdio.h>

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>

#include <X11/cursorfont.h>

#include <X11/Xaw/List.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Paned.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Viewport.h>

#include <X11/Xaw/Cardinals.h>

#include "lister.h"

static Widget lister = 0;

/*
 * ListerSelect
 *
 * Called when the user clicks on an item in the list.
 */
static void
ListerSelect(w, d, cbdata)
Widget w;
ListerCallbackData *d;
XtPointer cbdata;
{
  XawListReturnStruct *lr;
  static int last_selected = -1;

  lr = XawListShowCurrent(w);
  if (lr != NULL)
  {
    if (lr->list_index == last_selected)
    {
      (d->clist[0].func)(d->clist[0].w, d, NULL);
      last_selected = -1;
    }
    else
    {
      last_selected = lr->list_index;
    }
  }

  return;
}

/*
 * CreateLister
 *
 * The first command in clist is assumed to be the "OK" button and its
 * callback function is used for the callback when the user double
 * clicks on an item.
 */
void
CreateLister(title, parent, clist, itemlist, callback_data)
char *title;
Widget parent;
ListCommand *clist;
char **itemlist;
XtPointer callback_data;
{
  Widget paned, box, box2, box3, view, list;
  Arg args[4];
  Dimension width, height;
  Display *dpy;
  Window rw, cw;
  int rx, ry, wx, wy;
  int i;
  unsigned int mask;
  int dwidth, dheight;
  static ListerCallbackData d;

  if (lister)
  {
    fprintf (stderr, "WARNING: nested listers\n");
  }
  
  lister = XtCreatePopupShell("Lister",
				 transientShellWidgetClass, parent,
				 NULL, 0);
  
  paned = XtCreateManagedWidget("listerpaned",
                                panedWidgetClass, lister,
                                NULL, 0);
  
  box = XtCreateManagedWidget("listerbox",
			      boxWidgetClass, paned,
			      NULL, 0);

  box2 = XtCreateManagedWidget("listerbox2",
			      formWidgetClass, paned,
			      NULL, 0);

  box3 = XtCreateManagedWidget("listerbox3",
			       boxWidgetClass, paned,
			       NULL, 0);

  view = XtCreateManagedWidget ("listerview",
                                viewportWidgetClass,
                                box2,
                                NULL, 0);
  
  list = XtCreateManagedWidget ("listerlist",
                                listWidgetClass,
                                view,
                                NULL, 0);
  
  XawListChange(list, itemlist, 0, 0, True);

  d.cbdata = callback_data;
  d.itemlist = itemlist;
  d.listw = list;
  d.clist = clist;
  XtAddCallback(list, XtNcallback,
		(XtCallbackProc)ListerSelect, (XtPointer)&d);
 
  XtCreateManagedWidget(title,
			labelWidgetClass, box,
			NULL, 0);

  for (i = 0; clist[i].name != NULL; i++)
  {
    clist[i].w = XtCreateManagedWidget(clist[i].name,
			      commandWidgetClass, box3,
			      NULL, 0);
    XtAddCallback(clist[i].w, XtNcallback, clist[i].func, (XtPointer)&d);
  }
    
  /*
   * not centered but close enough
   */
  XtRealizeWidget(lister);

  dpy = XtDisplay(parent);
  XQueryPointer(dpy, XtWindow(lister),
		&rw, &cw,
		&rx, &ry,
		&wx, &wy,
		&mask);

  XtSetArg(args[0], XtNwidth, &width);
  XtSetArg(args[1], XtNheight, &height);
  XtGetValues(lister, args, 2);
  
  dwidth = DisplayWidth(dpy, DefaultScreen(dpy));
  dheight = DisplayHeight(dpy, DefaultScreen(dpy));

  if (rx + width > dwidth)
  {
    rx -= rx + width - dwidth;
  }
  if (ry + height > dheight)
  {
    ry -= ry + height - dheight;
  }

  XtSetArg(args[0], XtNx, rx);
  XtSetArg(args[1], XtNy, ry);
  XtSetValues(lister, args, 2);

  XtPopup(lister, XtGrabNone);

  return;
}

/*
 * DestroyLister
 */
void
DestroyLister()
{
  XtPopdown(lister);
  XtDestroyWidget(lister);
  lister = 0;
  return;
}

/*
 * RaiseLister
 */
void
RaiseLister()
{
  XRaiseWindow(XtDisplay(lister), XtWindow(lister));

  return;
}
