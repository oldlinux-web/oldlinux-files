/*
 * util.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 * contains misc. useful(?) stuff 
 */
#include <stdio.h>
#include <pwd.h>

#ifndef NOSTDHDRS
#include <stdlib.h>
#endif

#include <ctype.h>

#include "util.h"

/*
 * realloc_string
 *
 * Reallocs space for a string.
 */
char *
realloc_string(s, str)
char *s;
char *str;
{
  s = (char *)realloc(s, sizeof(char) * (strlen(str) + 1));
  if (s != NULL)
  {
    strcpy(s, str);
  }

  return(s);
}

/*
 * alloc_string_mem
 *
 * Is this silliness or what?
 */
char *
alloc_string_mem(len)
int len;
{
  return((char *)malloc(sizeof(char) * (len + 1)));
}

/*
 * realloc_string_mem
 *
 */
char *
realloc_string_mem(s, len)
char *s;
int len;
{
  return((char *)realloc(s, len));
}
 
/*
 * recomb_string
 *
 * Combines two strings from a realloc of the address indicated by
 * s1.  The first string must be malloc'd memory.  The second string
 * can be any type of memory since it is
 * not touched.
 */
char *
recomb_string(s1, s2)
char *s1, *s2;
{
  int len;

  len = strlen(s1) + strlen(s2) + 1;
  s1 = (char *)realloc(s1, len);
  if (s1 != NULL)
  {
    strcat(s1, s2);
  }

  return(s1);
}

/*
 * alloc_string
 *
 * Allocates space for a string and copies the string to the space
 */
char *
alloc_string(str)
char *str;
{
  char *s;

  s = (char *)malloc(sizeof(char) * (strlen(str) + 1));
  if (s != NULL)
  {
    strcpy(s, str);
  }
  return(s);
}

/*
 * get_line
 *
 * Returns the next line from a text buffer.  A NULL is placed in
 * len - 1 in the return string.
 */
char *
get_line(t, buffer, len)
char *t;
char *buffer;
int len;
{
  char *j;
  int i;

  if (t == NULL)
  {
    return(NULL);
  }

  if (*t == '\0')
  {
    return(NULL);
  }

  for (j = t, i = 0; *j; j++, i++)
  {
    if (*j == '\r') /* nobody ever puts this without \n ? */
    {
      j += 2;
      break;
    }
    if (*j == '\n')
    {
      j++;
      break;
    }
    else if (*j == '\0')
    {
      break;
    }

    if (i < len)
    {
      buffer[i] = *j;
    }
  }
  buffer[(i < len - 1 ? i:len - 1)] = '\0';

  return(j);
}

/*
 * mystrncmp
 */
int
mystrncmp(s1, s2, len)
char *s1, *s2;
int len;
{
  int i;
  char c1 = 0, c2 = 0;

  for (i = 0; i < len && *(s1 + i) && *(s2 + i); i++)
  {
    c1 = *(s1 + i);
    c2 = *(s2 + i);
    c1 = (isupper(c1) ? tolower(c1):c1);
    c2 = (isupper(c2) ? tolower(c2):c2);
    if (c1 != c2)
    {
      return(c1 - c2);
    }
  }

  if (i == len)
  {
    c1 = 0;
    c2 = 0;
  }
  else
  {
    c1 = *(s1 + i);
    c2 = *(s2 + i);
    c1 = (isupper(c1) ? tolower(c1):c1);
    c2 = (isupper(c2) ? tolower(c2):c2);
  }

  return(c1 - c2);
}

/*
 * mystrcmp
 */
int
mystrcmp(s1, s2)
char *s1, *s2;
{
  int i;
  char c1 = 0, c2 = 0;

  for (i = 0; *(s1 + i) && *(s2 + i); i++)
  {
    c1 = *(s1 + i);
    c2 = *(s2 + i);
    c1 = (isupper(c1) ? tolower(c1):c1);
    c2 = (isupper(c2) ? tolower(c2):c2);
    if (c1 != c2)
    {
      return(c1 - c2);
    }
  }

  c1 = *(s1 + i);
  c2 = *(s2 + i);
  c1 = (isupper(c1) ? tolower(c1):c1);
  c2 = (isupper(c2) ? tolower(c2):c2);

  return(c1 - c2);
}

/*
 * FixFilename
 *
 * The only thing this does right now is to handle the '~' stuff.
 */
char *
FixFilename(filename)
char *filename;
{
  struct passwd *p;
  char *s, *cp, *cp2;
  char username[BUFSIZ];

  if (filename[0] == '~')
  {
    if (filename[1] == '/')
    {
      p = getpwuid(getuid());
      cp = filename + 1;
    }
    else
    {
      for (cp = filename + 1, cp2 = username; *cp && *cp != '/'; cp++, cp2++)
      {
	*cp2 = *cp;
      }
      *cp2 = '\0';

      p = getpwnam(username);
    }

    if (p == NULL)
    {
      return(NULL);
    }

    s = alloc_string_mem(strlen(p->pw_dir) + strlen(cp) + 1);
    if (s == NULL)
    {
      return(NULL);
    }

    strcpy(s, p->pw_dir);
    strcat(s, cp);
  }
  else
  {
    s = alloc_string(filename);
  }

  return(s);
}
