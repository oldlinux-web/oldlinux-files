/*
 * local.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 */
#include <stdio.h>

#ifndef NOSTDHDRS
#include <stdlib.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>

#include <fcntl.h>

#ifdef SYSV
#include <dirent.h>
#else
#include <sys/dir.h>
#endif

/* Jim Rees fix */
#ifndef S_ISDIR
#define S_ISDIR(mode) (((mode) & S_IFMT) == S_IFDIR)
#endif

#include "document.h"
#include "access.h"
#include "util.h"
#include "net.h"
#include "conf.h"

/*
 * Local functions.
 */
#if NeedFunctionPrototypes
static void LoadFile(Document *, char *);
#else
static void LoadFile();
#endif

/*
 * LoadFile
 *
 * Load the contents of a file into memory.
 *
 */

static void
LoadFile(d, filename, size)
Document *d;
char *filename;
int size;
{
  int fd;
  int i, v;
  char *b;

  d->text = NULL;
  d->type = DocUnknown;

  fd = open(filename, O_RDONLY, 0);
  if (fd < 0)
  {
    return;
  }

  b = alloc_string_mem(size + 1);
  if (b == NULL)
  {
    return;
  }

  for (i = 0; i < size; i += v)
  {
    if ((v = read(fd, b + i, BUFSIZ)) <= 0)
    {
      break;
    }
  }

  close(fd);

  b[(i <= size ? i:size)] = 0;

  d->text = b;
  d->len = i;

  return;
}

/*
 * LoadDir
 *
 * Reads a local directory and converts it into HTML so the user can
 * navigate the local filesystem.
 */
static void
LoadDir(d, filename)
Document *d;
char *filename;
{
  DIR *dp;
#ifdef SYSV
  struct dirent *de;
#else
  struct direct *de;
#endif
  int flen;
  int filelen;
  int formlen;
  char *f;
  static char *format = "<li> <a href=file:%s/%s> %s </a>\n";
  static char *rformat = "<li> <a href=file:%s%s> %s </a>\n";
  static char *header = "<title>Local Directory %s</title>\n<h1>Local Directory %s</h1>\n<ul>\n";

  d->text = NULL;
  d->type = DocInternal;

  filelen = strlen(filename);
  formlen = strlen(format);

  flen = strlen(header) + filelen * 2 + 1;
  f = (char *)malloc(flen);
  if (f == NULL)
  {
    return;
  }
  sprintf (f, header, filename, filename);

  dp = opendir(filename);
  if (dp == NULL)
  {
    return;
  }

  while ((de = readdir(dp)) != NULL)
  {
    if (de->d_name[0] != '.')
    {
      flen += formlen + strlen(de->d_name) * 2 + filelen + 1;
      
      f = (char *)realloc(f, flen);
      if (f == NULL)
      {
	return;
      }

      if (filename[strlen(filename) - 1] == '/')
      {
	sprintf(f + strlen(f), rformat, filename, de->d_name, de->d_name);
      }
      else
      {
	sprintf(f + strlen(f), format, filename, de->d_name, de->d_name);
      }
    }
  }

  closedir(dp);

  d->text = f;

  return;
}

/*
 * file
 *
 * First tries to load a local function and then tries for ftp.
 *
 */
void
file(d, hostname, portno, filename, ext)
Document *d;
char *hostname;
int portno;
char *filename;
char *ext;
{
  char *domain;
  struct stat s;
  char *nf;

  if (hostname[0] != '\0' && mystrcmp(hostname, "localhost") != 0)
  {
    domain = net_gethostname(); /* gets the full domain name */
    if (domain == NULL)
    {
      return;
    }

    if (mystrcmp(domain, hostname) != 0)
    {
      char myhostname[256];

      gethostname(myhostname, sizeof(myhostname)); /* gets only hostname ? */
      if (mystrcmp(hostname, myhostname) != 0)
      {
	ftp(d, hostname, portno, filename);
	return;
      }
    }
  }

  nf = FixFilename(filename);
  if (nf == NULL)
  {
    d->text = alloc_string("<h1>Error</h1>Invalid filename.");
    d->type = DocInternal;

    return;
  }

  if (stat(nf, &s) < 0)
  {
    d->text = alloc_string("<h1>Error</h1>Could not access local file.  Either the file does not exist or you do not have permission to access it");
    d->type = DocInternal;

    free(nf);

    return;
  }

  if (S_ISDIR(s.st_mode))
  {
    LoadDir(d, nf);
  }
  else /* lazy */
  {
    LoadFile(d, nf, s.st_size);
  }

  free(nf);

  return;
}

/*
 * telnet
 *
 * Do telnet stuff
 *
 */
void
telnet(d, hostname, portno, filename, ext)
Document *d;
char *hostname;
int portno;
char *filename;
char *ext;
{
  char *username = NULL;
  int i;
  int len;
  static char *format = "%s\n%s\n%d\n";

  len = strlen(hostname);
  for (i = 0; i < len; i++)
  {
    if (hostname[i] == '@')
    {
      username = alloc_string_mem(i + 1);
      strncpy(username, hostname, i);
      username[i] = '\0';
      i++;
      break;
    }
    else if (hostname[i] == ':')
    {
      i = 0;
      break;
    }
  }

  if (username == NULL || i == len)
  {
    char *s = getenv("USER");

    i = 0;

    if (s)
    {
      username = alloc_string(s);
    }
    else
    {
      username = alloc_string("nobody");
    }
  }

  if (portno == -1 || portno == 0)
  {
    portno = DEFAULT_TELNET_PORT;
  }

  d->len = strlen(format) + strlen(username) + strlen(hostname + i) + 12;
  d->text = alloc_string_mem(d->len);
  if (d->text)
  {
    sprintf (d->text, format, username, hostname + i, portno);
  }
  d->type = DocUnknown;
  
  free(username);

  return;
}
