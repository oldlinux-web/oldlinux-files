/*
 * main.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 * Graphics...mmmmmmmmmm...pretty.
 *
 */ 
#include <stdio.h>

#ifndef NOSTDHDRS
#include <stdlib.h>
#endif

#include <sys/signal.h>

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>

#include <X11/Xaw/Form.h>
#include <X11/Xaw/Paned.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Viewport.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/Scrollbar.h>

#include <X11/Xaw/Cardinals.h>

#include <X11/cursorfont.h>

#define _NO_PROTO

#include "HTML.h"

#include "document.h"
#include "bookmark.h"
#include "content.h"
#include "file.h"
#include "url.h"
#include "access.h"
#include "requester.h"
#include "lister.h"
#include "widget.h"
#include "image.h"
#include "util.h"
#include "conf.h"

/*
 * convenience routines.  the ifdef is bogus.
 */
#if NeedFunctionPrototypes
static void AddDocNode(HTMLRoot *, char *, unsigned long);
static void DisplayCurrent(HTMLRoot *);
static void SetTitle(HTMLRoot *, char *);
static void SetURL(HTMLRoot *, char *);
static void NukeRequester(HTMLRoot *);
static void NukeLister(HTMLRoot *);
static void SetSensitive(HTMLRoot *, int);
static void MyXtSetSensitive(Widget, int);
int DisplayTransferStatus(char *);
static void MakeRequester(HTMLRoot *, int, XtPointer);
static void ListBookmark();
static void AddBookmark();
static void AddBookmarkCommand();
static void DeleteBookmark();
static void CancelLister();
#else
static void AddDocNode();
static void DisplayCurrent();
static void SetTitle();
static void SetURL();
static void NukeRequester();
static void NukeLister();
static void SetSensitive();
static void MyXtSetSensitive();
int DisplayTransferStatus();
static void MakeRequester();
static void ListBookmark();
static void AddBookmark();
static void AddBookmarkCommand();
static void DeleteBookmark();
static void CancelLister();
#endif

static void           HomeAction();
static void           BackAction();
static void           ReloadAction();
static void           HelpAction();
static void           QuitAction();
static void           SourceAction();
static void           OpenAction();
static void           SaveAction();
static void           SearchAction();
static void           PrintAction();
static void           BookmarkAction();

/*
 * DocNode flags
 */
#define DN_ISHTML   0x00000001 /* if the passed text is HTML and not a URL */
#define DN_DOWNLOAD 0x00000002 /* download only, don't display */

/*
 * The big guy.  It is unfortunate that I was forced by ImageResolve
 * to make this global.
 */
static HTMLRoot root;

static char defaultTranslations[] =
"\
<Key>h: home()\n\
<Key>u: back()\n\
<Key>l: reload()\n\
<Key>?: help()\n\
<Key>q: quit()\n\
<Key>d: source()\n\
<Key>o: open()\n\
<Key>w: save()\n\
<Key>s: search()\n\
<Key>p: print()\n\
<Key>m: bookmark()\n\
";

/*
 * X stuff
 */
#define offset(field) XtOffset(HTMLRoot *, field)
static XtResource       resource_list[] =
{
  { "actionVerify", "ActionVerify", XtRBoolean, sizeof(Boolean),
	offset(actionVerify), XtRString, "False" },
  { "contentFile", "ContentFile", XtRString, sizeof(char *),
	offset(contentFile), XtRImmediate, CONTENT_FILE },
  { "homePage", "HomePage", XtRString, sizeof(char *),
	offset(homePage), XtRImmediate, HOME_PAGE },
  { "helpDocument", "HelpDocument", XtRString, sizeof(char *),
	offset(helpDocument), XtRImmediate, HELP_DOCUMENT },
  { "contentPath", "ContentPath", XtRString, sizeof(char *),
	offset(contentPath), XtRImmediate, NULL },
  { "showURL", "ShowURL", XtRBoolean, sizeof(Boolean),
	offset(showURL), XtRString, "True" },
  { "showTitle", "ShowTitle", XtRBoolean, sizeof(Boolean),
	offset(showTitle), XtRString, "True" },
  { "button1Box", "Button1Box", XtRString, sizeof(char *),
	offset(button1Box), XtRImmediate, "quit, open, home, back, source, reload, save, help, bookmark, print, search" },
  { "button2Box", "Button2Box", XtRString, sizeof(char *),
	offset(button2Box), XtRImmediate, NULL },
  { "printerName", "PrinterName", XtRString, sizeof(char *),
	offset(printerName), XtRImmediate, PRINTER_NAME },
  { "keyTrans", "KeyTrans", XtRString, sizeof(char *),
        offset(keyTrans), XtRImmediate, defaultTranslations }
};

static String fallback_resources[] =
{
  /* Resources for everything */
  "*background:                moccasin",
  "*showGrip:                  false",

  /* resources for general widget types */
  "*Scrollbar.background:      burlywood2",
  "*Command.background:        burlywood2",
  "*Box.orientation:           horizonal",
  "*Label.borderWidth:         0",

  /* Labels for main window commands */
  "*save.label:                Save",
  "*open.label:                Open",
  "*bookmark.label:            Bookmark",
  "*quit.label:                Quit",
  "*reload.label:              Reload",
  "*help.label:                Help",
  "*source.label:              Source",
  "*home.label:                Home",
  "*back.label:                Back",
  "*search.label:              Search",
  "*print.label:               Print",

  /* resources for specific widgets */
  "*html.height:               600",
  "*html.width:                600",
  "*html.horizontalScrollOnTop: True",
  "*html.activeAnchorBG:       moccasin",
  "*html.anchorUnderlines:     1",
  "*html.visitedAnchorUnderlines: 1",
  "*html.dashedVisitedAnchorUnderlines: true",
  "*html.autoSize:             true",

  /* resources for the requester popup */
  "*Requester*reqok.label:     OK",
  "*Requester*reqcancel.label: Dismiss",
  "*Requester*reqclear.label:  Clear",
  "*Requester*reqtext1.left:   ChainLeft",
  "*Requester*reqtext1.right:  ChainRight",
  "*Requester*prnraw:          Print Text",
  "*Requester*prnpretty:       Print Pretty Text",
  "*Requester*prnps:           Print Postscript",
  "*Requester*savraw:          Save Text",
  "*Requester*savepretty:      Save Pretty Text",
  "*Requester*savps:           Save Postscript",
  "*Requester*savhtml:         Save HTML",

  /* resoruces for the lister popup */
  "*Lister*listercancel.label: Dismiss",
  "*Lister*defaultColumns:     1",
  "*Lister*forceColumns:       true",
  "*Lister*listerview.borderWidth: 0",
  "*Lister*listerbox2.borderWidth: 0",
  "*Lister*listerlist.borderWidth: 0",
  "*Lister*listok.label:       Open",
  "*Lister*listcancel.label:   Dismiss",
  "*Lister*listdelete.label:   Delete",
  "*Lister*listadd.label:      Add",
  "*Lister*listerview.width:   500",
  "*Lister*listerview.height:  200",
  "*Lister*listerview.allowVert: True",
  "*Lister*listerview.allowHoriz: True",
  "*Lister*listerbox2.defaultDistance: 0",

  /* other crap */

  "*urllabel.label:            URL   :",
  "*urllabel.left:             ChainLeft",
  "*urllabel.right:            ChainLeft",
  "*urldisplay.left:           ChainLeft",
  "*urldisplay.right:          ChainRight",
  "*urldisplay.fromHoriz:      urllabel",
  "*urldisplay*sensitive:      true",
  "*urldisplay.width:          500",
  "*urldisplay.displayCaret:   False",
  "*urldisplay.editType:       read",

  "*titlelabel.label:          Title :",
  "*titlelabel.left:           ChainLeft",
  "*titlelabel.right:          ChainLeft",
  "*titledisplay.left:         ChainLeft",
  "*titledisplay.right:        ChainRight",
  "*titledisplay.fromHoriz:    titlelabel",
  "*titledisplay*sensitive:    true",
  "*titledisplay.width:        500",
  "*titledisplay.displayCaret: False",
  "*titledisplay.editType:     read",

  NULL
};

static XtActionsRec actionsList[] =
{
  { "home",     (XtActionProc) HomeAction },
  { "back",     (XtActionProc) BackAction },
  { "reload",   (XtActionProc) ReloadAction },
  { "help",     (XtActionProc) HelpAction },
  { "quit",     (XtActionProc) QuitAction },
  { "source",   (XtActionProc) SourceAction },
  { "open",     (XtActionProc) OpenAction },
  { "save",     (XtActionProc) SaveAction },
  { "search",   (XtActionProc) SearchAction },
  { "print",    (XtActionProc) PrintAction },
  { "bookmark", (XtActionProc) BookmarkAction },
};

/*
 * main
 *
 * this is where the whole thing kicks off.
 */
void
main(argc, argv)
int argc;
char **argv;
{
  char *first;

  /*
   * Support for firewalls.  You'll need to grab the SOCKS package
   * package from someplace else.
   */
#ifdef SOCKS
  SOCKSinit(argv[0]);
#endif

  /*
   * Init the toolkit and setup the main window.  Should set this up
   * to grab the command line arguments...too lazy.
   */
  root.toplevel = XtAppInitialize(&(root.appcon), "Chimera", NULL, 0,
			     &argc, argv, fallback_resources, NULL, 0);
  if (root.toplevel == 0)
  {
    fprintf (stderr, "Can't init X toolkit\n");
    exit(1);
  }

  /*
   * Grab up the resources.
   */
  XtGetApplicationResources(root.toplevel, &root, resource_list,
			    XtNumber(resource_list), NULL, 0);

  /*
   * Init the root information.
   */
  if ((first = getenv("WWW_HOME")) == NULL)
  {
    first = root.homePage;
  }
  if (argc > 1)
  {
    first = argv[1];
  }
  root.blist = ReadBookmarkFile();
  root.clist = ReadContentDB(root.contentFile);
  root.dlist = NULL;
  root.requesterup = False;
  root.listerup = False;
  root.special = NULL;
  root.cancelop = False;
  root.watch = XCreateFontCursor(XtDisplay(root.toplevel), XC_watch);
  root.left_ptr = XCreateFontCursor(XtDisplay(root.toplevel), XC_left_ptr);
  root.searchstr = NULL;
  root.loadstr = NULL;
  root.savestr = NULL;
  root.printerstr = NULL;
  root.bookmarkstr = NULL;
  root.savedoc = NULL;

  /*
   * Setup the translations stuff for the keyboard shortcuts.
   */
  XtAppAddActions(root.appcon,
		  actionsList, XtNumber(actionsList));
  root.trans = XtParseTranslationTable(root.keyTrans);

  /*
   * this is hiding in widget.c.  it creates the command widgets and stuff.
   * it is hidden away just to make main() smaller not because it is
   * a logical break or anything.  main was just too damn big.
   */
  CreateWidgets(&root);

  XtRealizeWidget(root.toplevel);

  StartReaper();

  AddDocNode(&root, first, 0);

  XtAppMainLoop(root.appcon);
}

/*
 * SetTitle
 *
 * Sets the string in the title widget.  Passing a NULL as a string
 * makes the title of the current document the title.
 */
static void
SetTitle(r, title)
HTMLRoot *r;
char *title;
{
  Arg args[1];
  String t;

  if (r->showTitle)
  {
    if (title == NULL)
    {
      XtSetArg(args[0], WbNtitleText, &t);
      XtGetValues(r->w, args, 1);
      
      if (t == NULL)
      {
	t = "";
      }
      
      XtSetArg(args[0], XtNstring, t);
    }
    else
    {
      XtSetArg(args[0], XtNstring, title);
    }
    XtSetValues(r->titledisplay, args, 1);
  }

  return;
}

/*
 * SetURL
 *
 * Change the URL display
 */
static void
SetURL(r, url)
HTMLRoot *r;
char *url;
{
  Arg args[1];

  if (r->showURL)
  {
    if (url != NULL)
    {
      XtSetArg(args[0], XtNstring, url);
    }
    else
    {
      XtSetArg(args[0], XtNstring, "");
    }
    XtSetValues(r->urldisplay, args, 1);
  }

  return;
}

/*
 * DisplayCurrent
 *
 * Displays the current HTML screen.  It also changes the title display
 * and the URL display.
 */
static void
DisplayCurrent(r)
HTMLRoot *r;
{
  Document *d;
  Arg args[2];
  Widget view;

  /*
   * Give the new scrollbar position.
   */
  XtSetArg(args[0], WbNverticalScrollPos, r->dlist->vpos);
  XtSetArg(args[1], WbNhorizontalScrollPos, r->dlist->hpos);
  XtSetValues(r->w, args, 2);
  
  d = r->dlist->doc;
  HTMLSetText(r->w, d->text, NULL, NULL, 0, NULL, NULL);

  if (d->ext != NULL && d->ext[0] == '#')
  {
    int id;

    id = HTMLAnchorToId(r->w, d->ext + 1);
    if (id > 0)
    {
      HTMLGotoId(r->w, id);
    }
  }

  SetSensitive(r, True);
  SetTitle(r, NULL);
  SetURL(r, r->dlist->doc->url);

  /*
   * This has to be done everytime due to HTML widget bogusness.
   */
  XtSetArg(args[0], WbNview, &view);
  XtGetValues(r->w, args, 1);
  if (view == 0)
  {
    fprintf (stderr, "DisplayCurrent bug\n");
  }
  else
  {
    XtOverrideTranslations(view, r->trans);
  }

  return;
}

/*
 * HandleDocument
 *
 * Do whatever needs to be done with a newly retrieved document.
 */
static void
HandleDocument(r, d)
HTMLRoot *r;
Document *d;
{
  DocNode *dn = NULL;
  Arg args[2];

  SetTitle(r, "Displaying document...");
  XFlush(XtDisplay(r->w));
  
  if (d->type == DocUnknown)
  {
    ProcessDocument(d, r->clist, NULL, r->contentPath);
  }
  
  switch (d->type)
  {
    case DocExternal:
    case DocImage:
      ReleaseDocument(d);
      break;
      
    case DocInternal:
      dn = (DocNode *)malloc(sizeof(DocNode));
      if (dn == NULL)
      {
	ReleaseDocument(d);
      }
      else
      {
	/*
	 * Save the old scrollbar position.
	 */
	if (r->dlist)
	{
	  XtSetArg(args[0], WbNverticalScrollPos, &(r->dlist->vpos));
	  XtSetArg(args[1], WbNhorizontalScrollPos, &(r->dlist->hpos));
	  XtGetValues(r->w, args, 2);
	}

	dn->doc = d;
	dn->vpos = 0;
	dn->hpos = 0;
	dn->next = r->dlist;
	r->dlist = dn;

        DisplayCurrent(r);
      }
      break;
      
    case DocUnknown:
      MakeRequester(r, 4, r);
      r->savedoc = d;
      break;
  }

  /*
   * in case the command line argument is a GIF or something.
   */
  if (r->dlist == NULL)
  {
    AddDocNode(r, r->homePage, 0);

    return;
  }

  SetTitle(r, NULL);
  SetURL(r, r->dlist->doc->url);

  return;
}

/*
 * LoadURL
 *
 * Returns a Document for a URL.
 */
static Document *
LoadURL(r, url)
HTMLRoot *r;
char *url;
{
  Document *d = NULL;
  char *t = NULL;
  char *nurl = NULL;
  char link[256];

  link[0] = '\0';
  
  /*
   * Handle the #identifier guys without the nonsense.
   */
  if (url[0] == '#')
  {
    int id;

    id = HTMLAnchorToId(r->w, url + 1);
    if (id > 0)
    {
      HTMLGotoId(r->w, id);
    }

    return(NULL);
  }
  
  if (r->dlist != NULL && r->dlist->doc->url != NULL)
  {
    t = nurl = alloc_string(r->dlist->doc->url);
    if (nurl == NULL)
    {
      return(NULL);
    }
  }
  else
  {
    nurl = NULL;
  }
  nurl = MakeURL(url, nurl, link, sizeof(link));
  if (t != NULL)
  {
    free(t);
  }
  
  if (nurl == NULL)
  {
    static char *message = "<h1>Error</h1>\nMalformed URL<p>\n";
    
    t = alloc_string_mem(strlen(message) + strlen(url) + 1);
    if (t != NULL)
    { 
      strcpy(t, message);
      strcat(t, url);
      d = MakeDocument(t);
      free(t);
    }
  }
  else
  {
    SetTitle(r, "Downloading document...");
    SetURL(r, nurl);
    XFlush(XtDisplay(r->w));
    
    d = LoadDocument(nurl);

    if (d)
    {
      d->ext = alloc_string(link);
    }

    free(nurl);
  }

  return(d);
}

/*
 * AddDocNode
 *
 * Ya.
 */
static void
AddDocNode(r, text, flags)
HTMLRoot *r;
char *text;
unsigned long flags;
{
  Document *d;

  XDefineCursor(XtDisplay(r->toplevel), XtWindow(r->toplevel), r->watch);
  
  if (flags & DN_ISHTML)
  {
    d = MakeDocument(text);
  }
  else
  {
    d = LoadURL(r, text);
  }

  if (d != NULL)
  {
    if (flags & DN_DOWNLOAD)
    {
      DisplayCurrent(r);
      r->savedoc = d;
      MakeRequester(r, 4, r);
    }
    else
    {
      HandleDocument(r, d);
    }
  }

  XDefineCursor(XtDisplay(r->toplevel), XtWindow(r->toplevel), r->left_ptr);

  return;
}

/*
 * Anchor
 *
 * Called when the user clicks on an anchor
 */
void
Anchor(w, r, c)
Widget w;
HTMLRoot *r;
WbAnchorCallbackData *c;
{
  if (c == NULL || c->href == NULL)
  {
    return;
  }

  if (c->event)
  {
    switch (c->event->xbutton.button)
    {
      case 2:
        AddDocNode(r, c->href, DN_DOWNLOAD);
        break;
	  
      default:
	AddDocNode(r, c->href, 0);
    }
  }

  return;
}

/*
 * OpenDocument
 *
 * Called when the user clicks on the open button.
 *
 * This function grabs the text in the text widget which it assumes to
 * be a URL and tries to access the document.  It will not handle local
 * files.
 */
void
OpenDocument(w, cldata, cbdata)
Widget w;
RequesterCallbackData *cldata;
XtPointer cbdata;
{
  Arg args[1];
  String s;
  HTMLRoot *r;
  Field *f;

  r = (HTMLRoot *)(cldata->cbdata);
  f = cldata->flist;

  XtSetArg(args[0], XtNstring, &s);
  XtGetValues(f[0].w, args, 1);

  /*
   * Make sure that the user has entered something in the text widget
   */
  if (s == NULL || s[0] == '\0')
  {
    AddDocNode(r, "<h1>Error</h1>Empty URL.  Document not loaded.",
	       DN_ISHTML);
  }
  else
  {
    if (r->loadstr)
    {
      free(r->loadstr);
    }
    r->loadstr = alloc_string(s);

    AddDocNode(r, s, 0);
  }

  NukeRequester(r);

  return;
}

static void
OpenAction()
{
  DoRequester(root.load, &root, NULL);
  return;
}

/*
 * Home
 *
 * Called when the user clicks on the home button.
 *
 * The equivalent of clicking on "Back" until the first document is
 * visible.
 */
void
Home(w, r, cbdata)
Widget w;
HTMLRoot *r;
XtPointer cbdata;
{
  DocNode *c, *t;

  c = r->dlist;
  if (c)
  {
    while (c->next)
    {
      t = c;
      c = c->next;
      ReleaseDocument(t->doc);
      free(t);
    }
    r->dlist = c;
    DisplayCurrent(r);
  }
  else
  {
    fprintf (stderr, "Home bug check\n");
  }

  return;
}

static void
HomeAction()
{
  Arg args[1];
  Boolean sensitive;

  XtSetArg(args[0], XtNsensitive, &sensitive);
  XtGetValues(root.home, args, 1);
  if (sensitive)
  {
    Home(root.home, &root, NULL);
  }

  return;
}

/*
 * Save
 *
 * Called when the user clicks on the save button.
 *
 * Saves the currently displayed document to a file.
 */
void
Save(w, cldata, cbdata)
Widget w;
RequesterCallbackData *cldata;
XtPointer cbdata;
{
  String s;
  Arg args[1];
  char *text = NULL, *data;
  FILE *fp;
  int len, i, e, c;
  HTMLRoot *r;
  Field *f;

  r = (HTMLRoot *)(cldata->cbdata);
  f = cldata->flist;

  XtSetArg(args[0], XtNstring, &s);
  XtGetValues(f[0].w, args, 1);

  /*
   * Make sure that the user has entered something in the text widget
   */
  if (s == NULL || s[0] == '\0')
  {
    AddDocNode(r, "<h1>Error</h1>\nEmpty filename.  Document not saved.",
		DN_ISHTML);

  }
  else
  {
    if (r->savestr)
    {
      free(r->savestr);
    }
    r->savestr = alloc_string(s);

    /*
     * This depends on clist3 in MakeRequester.  Probably a bad move.
     */
    for (i = 0; cldata->clist[i].name != NULL; i++)
    {
      if (w == cldata->clist[i].w)
      {
	break;
      }
    }
    
    if (cldata->clist[i].name == NULL)
    {
      fprintf (stderr, "Print weirdness\n");

      NukeRequester(r);

      return;
    }

    if (r->savedoc != NULL)
    {
      data = r->savedoc->text;
      len = r->savedoc->len;
    }
    else if (i == 3)
    {
      data = r->dlist->doc->text;
      len = r->dlist->doc->len;
    }
    else
    {
      data = text = HTMLGetText(r->w, i);
      if (text == NULL)
      {
	NukeRequester(r);
	return;
      }
      len = strlen(data);
    }
  
    s = FixFilename(s); 
    if (s == NULL)
    {
      AddDocNode(r, "<h1>Error</h1>\nInvalid filename.  Document not saved.",
		DN_ISHTML);

      NukeRequester(r);
      return;
    }

    fp = fopen(s, "w");
    if (fp == NULL)
    {
      if (text != NULL)
      {
	free(text);
      }

      NukeRequester(r);
      free(s);

      return;
    }
    
    for (i = 0; i < len; i += e)
    {
      c = len - i;
      c = (BUFSIZ > c ? c : BUFSIZ);
      if ((e = fwrite(data + i, 1, c, fp)) == 0)
      {
	break;
      }
    }
    
    fclose(fp);
    
    if (text != NULL)
    {
      free(text);
    }
  }

  NukeRequester(r);

  free(s);

  return;
}

static void
SaveAction()
{
  DoRequester(root.save, &root, NULL);
  return;
}

/*
 * Back
 *
 * Called when the user clicks on the back button.  It moves back one
 * HTML frame.
 */
void
Back(w, r, cbdata)
Widget w;
HTMLRoot *r;
XtPointer cbdata;
{
  DocNode *t;

  t = r->dlist;
  r->dlist = r->dlist->next;
  ReleaseDocument(t->doc);
  free(t);

  if (r->dlist)
  {
    XDefineCursor(XtDisplay(r->toplevel),
		  XtWindow(r->toplevel),
		  r->watch);
    
    XFlush(XtDisplay(r->w));

    DisplayCurrent(r);
    
    XDefineCursor(XtDisplay(r->toplevel),
		  XtWindow(r->toplevel),
		  r->left_ptr);
  }

  return;
}

static void
BackAction()
{
  Arg args[1];
  Boolean sensitive;

  XtSetArg(args[0], XtNsensitive, &sensitive);
  XtGetValues(root.back, args, 1);
  if (sensitive)
  {
    Back(root.back, &root, NULL);
  }

  return;
}

/*
 * Reload
 *
 * Reloads the current document.  Note that this doesn't reload inline
 * images for the document.  Reload'ing can cause serious trouble.
 * For example, if the document changes from an HTML document to a
 * GIF or something there will be trouble.  Tough shit for now.
 */
void
Reload(w, r, cbdata)
Widget w;
HTMLRoot *r;
XtPointer cbdata;
{
  ReloadDocument(r->dlist->doc);
  DisplayCurrent(r);

  return;
}

static void
ReloadAction()
{
  Reload(root.reload, &root, NULL);
  return;
}

/*
 * Cancel
 *
 * Sets a flag for any other bits of code that care.
 */
void
Cancel(w, r, cbdata)
Widget w;
HTMLRoot *r;
XtPointer cbdata;
{
  r->cancelop = True;

  return;
}

/*
 * Help
 *
 * Shows the help file.
 */
void
Help(w, r, cbdata)
Widget w;
HTMLRoot *r;
XtPointer cbdata;
{
  AddDocNode(r, r->helpDocument, 0);

  return;
}

static void
HelpAction()
{
  Help(root.help, &root, NULL);
  return;
}

/*
 * Search
 *
 * Called when the user clicks on the Search button
 */
void
Search(w, cldata, cbdata)
Widget w;
RequesterCallbackData *cldata;
XtPointer cbdata;
{
  Arg args[1];
  String s;
  HTMLRoot *r;
  Field *f;
  static ElementRef start, end;
  Boolean wrap;

  r = (HTMLRoot *)(cldata->cbdata);
  f = cldata->flist;

  XtSetArg(args[0], XtNstring, &s);
  XtGetValues(f[0].w, args, 1);

  /*
   * Make sure that the user has entered something in the text widget
   */
  if (s == NULL || s[0] == '\0')
  {
    AddDocNode(r, "<h1>Error</h1>\nEmpty search string.  Search aborted.",
		DN_ISHTML);
  }
  else
  {
    if (r->searchstr != NULL)
    {
      if (mystrcmp(r->searchstr, s) != 0)
      {
	start.id = 0;
	free(r->searchstr);
	r->searchstr = alloc_string(s);
	if (r->searchstr == NULL)
	{
	  return;
	}
      }
      else
      {
	start.pos = end.pos;
      }
    }
    else
    {
      r->searchstr = alloc_string(s);
      start.id = 0;
      start.pos = 0;
    }

    do
    {
      wrap = False;
      if (HTMLSearchText(r->w, s, &start, &end, 0, 1) == 1)
      {
	HTMLSetSelection(r->w, &start, &end);
	HTMLGotoId(r->w, start.id);
      }
      else
      {
	if (start.pos == 0)
	{
	  AddDocNode(r, "<h1>Info</h1>\nSearch failed.", DN_ISHTML);
	}
	else
	{
	  start.id = 0;
	  start.pos = 0;
	  wrap = True;
	}
      }
    } while (wrap);
  }

  return;
}

static void
SearchAction()
{
  DoRequester(root.search, &root, NULL);
  return;
}

#ifdef SIGPIPE
/*
 * sigpipehandler
 *
 * right
 */
static void
sigpipehandler()
{
  signal(SIGPIPE, sigpipehandler);

  return;
}
#endif

/*
 * Print
 *
 * Called when the user clicks on the print button.
 */
static void
Print(w, cldata, cbdata)
Widget w;
RequesterCallbackData *cldata;
XtPointer cbdata;
{
  String s;
  Arg args[1];
  char buffer[256];
  char *text;
  FILE *pp;
  int len, i, e, c;
  HTMLRoot *r;
  Field *f;

  r = (HTMLRoot *)(cldata->cbdata);
  f = cldata->flist;

  XtSetArg(args[0], XtNstring, &s);
  XtGetValues(f[0].w, args, 1);

  /*
   * Make sure that the user has entered something in the text widget
   */
  if (s == NULL || s[0] == '\0')
  {
    AddDocNode(r, "<h1>Error</h1>\nEmpty printer name.  Document not printed.",
		DN_ISHTML);

  }
  else
  {
    if (r->printerstr)
    {
      free(r->printerstr);
    }
    r->printerstr = alloc_string(s);

    sprintf (buffer, PRINT_COMMAND, s);

    /*
     * This depends on clist2 in MakeRequester.  Probably a bad move.
     */
    for (i = 0; cldata->clist[i].name != NULL; i++)
    {
      if (w == cldata->clist[i].w)
      {
	break;
      }
    }
    
    if (cldata->clist[i].name == NULL)
    {
      fprintf (stderr, "Print weirdness\n");

      NukeRequester(r);

      return;
    }

    text = HTMLGetText(r->w, i);
    if (text == NULL)
    {
      NukeRequester(r);
      return;
    }
    
#ifdef SIGPIPE
    signal(SIGPIPE, sigpipehandler);
#endif
    
    pp = popen(buffer, "w");
    if (pp == NULL)
    {
      AddDocNode(r, "<h1>Error</h1>\nA pipe to the print command (probably lpr) could not be opened.  Make sure that you have the print command in your path.\n", DN_ISHTML);
      
      free(text);
      
      NukeRequester(r);

      return;
    }
    
    len = strlen(text);
    for (i = 0; i < len; i += e)
    {
      c = len - i;
      c = (BUFSIZ > c ? c : BUFSIZ);
      if ((e = fwrite(text + i, 1, c, pp)) == 0)
      {
	break;
      }
    }
    
    pclose(pp);
    
    free(text);
  }

  NukeRequester(r);

  return;
}

static void
PrintAction()
{
  DoRequester(root.print, &root, NULL);
  return;
}

/*
 * Quit
 *
 * Called when the user clicks on the quit button
 */
void
Quit(w, r, cbdata)
Widget w;
HTMLRoot *r;
XtPointer cbdata;
{
  exit(0);
}

static void
QuitAction()
{
  Quit(root.quit, &root, NULL);
  return;
}

/*
 * Source
 *
 * Called when the user clicks on the source button.  Allocates yet more
 * memory to put the current HTML in a document with <plaintext> at the
 * top.
 */
void
Source(w, r, cbdata)
Widget w;
HTMLRoot *r;
XtPointer cbdata;
{
  char *t;
  int len;
  static char *message = "<title>HTML Source</title>\n<plaintext>\n";

  /*
   * Build HTML source to view HTML source if there is text available.
   */
  if (r->dlist->doc->text != NULL)
  {
    len = strlen(message) + strlen(r->dlist->doc->text);
    t = alloc_string_mem(len + 1);
    if (t != NULL)
    {
      strcpy(t, message);
      strcat(t, r->dlist->doc->text);

      AddDocNode(r, t, DN_ISHTML);
      free(t);
    }
  }

  return;
}

static void
SourceAction()
{
  Source(root.source, &root, NULL);
  return;
}

/*
 * CancelRequester
 *
 * Guess
 */
static void
CancelRequester(w, cldata, cbdata)
Widget w;
RequesterCallbackData *cldata;
XtPointer cbdata;
{
  HTMLRoot *r;

  r = (HTMLRoot *)(cldata->cbdata);
  r->special = NULL;

  NukeRequester(r);

  return;
}

/*
 * CancelLister
 */
static void
CancelLister(w, cldata, cbdata)
Widget w;
ListerCallbackData *cldata;
XtPointer cbdata;
{
  HTMLRoot *r;

  if (cldata->itemlist)
  {
    free(cldata->itemlist);
    cldata->itemlist = NULL;
  }

  r = (HTMLRoot *)(cldata->cbdata);

  if (r->requesterup && r->special)
  {
    NukeRequester(r);
  }

  r->special = NULL;

  NukeLister(r);

  return;
}

/*
 * ClearRequester
 *
 * Clears the text widget in the requester.
 */
static void
ClearRequester(w, cldata, cbdata)
Widget w;
RequesterCallbackData *cldata;
XtPointer cbdata;
{
  Arg args[1];
  Field *f;

  f = cldata->flist;

  XtSetArg(args[0], XtNstring, "");
  XtSetValues(f[0].w, args, 1);

  return;
}

/*
 * MakeRequester
 *
 * Creates a requester.  Welcome to hell.
 */
static void
MakeRequester(r, funcno, cbdata)
HTMLRoot *r;
int funcno;
XtPointer cbdata;
{
  Arg args[1];
  String s;
  char *pname;
  RequesterCommand *clist;
  static int last = -1;

  static Field flist[] =
  {
    { NULL, "reqtext1", 300, 25, True, "" },
    { NULL, NULL, 0, 0, False, "" }
  };
  static RequesterCommand clist1[] =
  {
    { "reqok", NULL },
    { "reqclear", ClearRequester },
    { "reqcancel", CancelRequester },
    { NULL, NULL }
  };
  static RequesterCommand clist2[] =
  {
    { "prnraw", Print },
    { "prnpretty", Print },
    { "prnps", Print },
    { "reqclear", ClearRequester },
    { "reqcancel", CancelRequester },
    { NULL, NULL }
  };
  static RequesterCommand clist3[] = 
  {
    { "savraw", Save },
    { "savpretty", Save },
    { "savps", Save },
    { "savhtml", Save },
    { "reqclear", ClearRequester },
    { "reqcancel", CancelRequester },
    { NULL, NULL },
  };

  if (r->requesterup)
  {
    if (last == funcno)
    {
      RaiseRequester();
      return;
    }
    else
    {
      NukeRequester(r);
    }
  }

  switch (funcno)
  {
    case 0: /* Save Document Requester */
      clist = clist3;
      flist[0].prompt = "Enter a filename for the document";
      flist[0].fdef = r->savestr;
      break;

    case 1: /* Open Document Requester */
      clist = clist1;
      clist[0].func = OpenDocument;
      flist[0].prompt = "Enter document URL";
      flist[0].fdef = r->loadstr;
      break;

    case 2: /* Search requester */
      clist = clist1;
      clist[0].func = Search;
      flist[0].prompt = "Enter search string";
      flist[0].fdef = r->searchstr;
      break;

    case 4: /* Unknown Document Save Requester */
      clist = clist1;
      clist[0].func = Save;
      flist[0].fdef = r->savestr;
      flist[0].width = 500;
      flist[0].prompt = "Downloading document...enter a filename";
      break;

    case 5: /* Print requester */
      clist = clist2;
      if ((pname = getenv("PRINTER")) == NULL)
      {
	pname = r->printerName;
      }
      
      if (pname == NULL)
      {
	AddDocNode(r, "<h1>Error</h1>\nChimera does not know the name of the printer to use.  Set the PRINTER environment variable or the printerName X resource\n.", DN_ISHTML);
	
	return;
      }

      if (r->printerstr == NULL)
      {
	flist[0].fdef = pname;
      }
      else
      {
	flist[0].fdef = r->printerstr;
      }
      flist[0].prompt = "Enter printer name";
      break;

    case 6: /* Add bookmark */
      clist = clist1;
      clist[0].func = AddBookmark;
      flist[0].prompt = "Enter bookmark name";

      /*
       * This will leave allocated memory laying around but only once.
       */
      if (r->bookmarkstr)
      {
	free(r->bookmarkstr);
	r->bookmarkstr = NULL;
      }

      XtSetArg(args[0], WbNtitleText, &s);
      XtGetValues(r->w, args, 1);
      if (s == NULL || s[0] == '\0')
      {
	s = r->dlist->doc->url;
	if (s == NULL)
	{
	  return;
	}
      }
      r->bookmarkstr = alloc_string(s);
      
      flist[0].fdef = r->bookmarkstr;
      break;

    default: /* Invalid */
      fprintf (stderr, "MakeRequester Error 2\n");
      return;
  }

  last = funcno;
  r->requesterup = True;
  SetSensitive(r, True);
  CreateRequester(r->toplevel, flist, clist, cbdata);

  return;
}

/*
 * DoRequester
 *
 * Cranks up a requester and sets up the callback.
 */
void
DoRequester(w, r, cbdata)
Widget w;
HTMLRoot *r;
XtPointer cbdata;
{
  if (w == r->save) MakeRequester(r, 0, r);
  else if (w == r->load) MakeRequester(r, 1, r);
  else if (w == r->search) MakeRequester(r, 2, r);
  else if (w == r->print) MakeRequester(r, 5, r);
  else
  {
    fprintf (stderr, "DoRequester Error\n");
    return;
  }

  return;
}

/*
 * MakeBookList
 *
 * Makes an array of char pointers to the list of bookmarks.
 */
static char **
MakeBookList(blist)
Bookmark *blist;
{
  int i, count;
  Bookmark *b;
  char **list;

  b = blist;
  count = 0;
  while (b)
  {
    count++;
    b = b->next;
  }

  if (count == 0)
  {
    return(NULL);
  }

  count++;

  list = (char **)malloc(sizeof(char *) * count);
  if (list)
  {
    b = blist;
    i = 0;
    while (b)
    {
      list[i++] = b->display;
      b = b->next;
    }
    list[i] = '\0';
  }

  return(list);
}

/*
 * DoLister
 *
 * Cranks up a lister and sets up the callback.
 */
void
DoLister(w, r, cbdata)
Widget w;
HTMLRoot *r;
XtPointer cbdata;
{
  char **itemlist;
  static ListCommand clist[] =
  {
    { "listok", ListBookmark },
    { "listcancel", CancelLister },
    { "listadd", AddBookmarkCommand },
    { "listdelete", DeleteBookmark },
    { NULL, NULL },
  };

  if (r->listerup == True)
  {
    RaiseLister();
    return;
  }

  itemlist = MakeBookList(r->blist);
  if (itemlist == NULL)
  {
    itemlist = (char **)malloc(sizeof(char **));
    if (itemlist == NULL)
    {
      return;
    }
    itemlist[0] = NULL;
  }

  r->listerup = True;
  SetSensitive(r, True);

  CreateLister("Bookmarks" , w, clist, itemlist, (XtPointer)r);

  return;
}

/*
 * NukeRequester
 *
 * Guess
 */
static void
NukeRequester(r)
HTMLRoot *r;
{
  if (r->savedoc != NULL)
  {
    ReleaseDocument(r->savedoc);
    r->savedoc = NULL;
  }

  DestroyRequester();
  r->requesterup = False;
  SetSensitive(r, True);

  return;
}

/*
 * NukeLister
 *
 * Stuff
 */
static void
NukeLister(r)
HTMLRoot *r;
{
  DestroyLister();
  r->listerup = False;
  SetSensitive(r, True);

  return;
}

/*
 * ImageResolve
 *
 * Called by the HTML widget to turn an image into something the widget
 * understands.  This treats images like documents.
 */
ImageInfo *
ImageResolve(w, url)
Widget w;
char *url;
{
  Document *d;
  ImageInfo *i = NULL;
  Display *dpy;
  int screen;
  Visual *v;
  char *img;
  int depth;
  Arg args[1];
  char *nurl;

  /*
   * Watch out for weirdness.
   */
  if (url == NULL)
  {
    return(NULL);
  }

  SetTitle(&root, "Downloading inline image...");
  XFlush(XtDisplay(root.w));

  /*
   * Fix up the URL.  This is code from AddNode.  This code should
   * be in one spot only.
   */
  if (root.dlist != NULL && root.dlist->doc->url != NULL)
  {
    nurl = MakeURL(url, root.dlist->doc->url, NULL, 0);
  }
  else
  {
    nurl = alloc_string(url);
  }

  /*
   * Get the document.
   */
  d = LoadDocument(nurl);
  if (d == NULL)
  {
    return(NULL);
  }
  free(nurl);

  /*
   * If the document is already an image then just return it.  If the
   * type is unknown then see if it can be converted to an image.
   */
  if (d->otype == DocImage)
  {
    i = (ImageInfo *)d->otext;
    i->image = 0; /* this may be very evil.  this could cause the X server
		     to suck up all of the memory on the machine if left
		     to run long enough.  yikes! */
  }
  else if (d->type == DocUnknown)
  {
    /*
     * Figure out if the screen is color, grayscale, or monochrome.
     */
    XtSetArg(args[0], XtNdepth, &depth);
    XtGetValues(root.toplevel, args, 1);

    if (depth > 1)
    {
      dpy = XtDisplay(root.toplevel);
      screen = DefaultScreen(dpy);
      v = DefaultVisual(dpy, screen);
      switch(v->class)
      {
	case StaticColor:
	case DirectColor:
	case TrueColor:
	case PseudoColor:
	  img = "cimg";
	  break;
	case StaticGray:
	case GrayScale:
	  img = "gimg";
	  break;
	default:
	  img = "mimg";
	break;
      }
    }
    else
    {
      img = "mimg";
    }
    
    /*
     * Convert the document.
     */
    ProcessDocument(d, root.clist, img, root.contentPath);
    if (d->text == NULL)
    {
      ReleaseDocument(d);

      return(NULL);
    }
    
    /*
     * Convert the PxM to an ImageInfo data structure.
     */
    i = MakeImageInfo(d);
    if (i == NULL)
    {
      ReleaseDocument(d);

      return(NULL);
    }

    free(d->otext);
    d->otext = (char *)i;
    d->otype = DocImage;
  }

  SetTitle(&root, NULL);
  XFlush(XtDisplay(root.w));

  return(i);
}

/*
 * ListRedo
 *
 * Refreshes the bookmark list after it has been changed.
 */
static void
ListRedo(lcb)
ListerCallbackData *lcb;
{
  char **olditemlist;

  olditemlist = lcb->itemlist;

  lcb->itemlist = MakeBookList(((HTMLRoot *)(lcb->cbdata))->blist);
  /*
   * At least this will save us from disaster.
   */
  if (lcb->itemlist == NULL)
  {
    lcb->itemlist = olditemlist;
    return;
  }
  
  XawListChange(lcb->listw, lcb->itemlist, 0, 0, True);
  
  free(olditemlist);
  
  return;
}

/*
 * AddBookmarkCommand
 *
 */
static void
AddBookmarkCommand(w, cldata, cbdata)
Widget w;
ListerCallbackData *cldata;
XtPointer cbdata;
{
  HTMLRoot *r;

  r = (HTMLRoot *)(cldata->cbdata);

  r->special = cldata;

  MakeRequester(r, 6, r);

  return;
}

static void
BookmarkAction()
{
  DoLister(root.bookmark, &root, NULL);

  return;
}

/*
 * AddBookmark
 *
 * Adds the current document to the bookmark list.  This is a callback
 * for a command widget.  Be careful.
 */
static void
AddBookmark(w, cldata, cbdata)
Widget w;
RequesterCallbackData *cldata;
XtPointer cbdata;
{
  Bookmark *b;
  char *s;
  Arg args[1];
  HTMLRoot *r;
  Field *f;

  r = (HTMLRoot *)(cldata->cbdata);
  f = cldata->flist;

  XtSetArg(args[0], XtNstring, &s);
  XtGetValues(f[0].w, args, 1);

  if (s == NULL || s[0] == '\0')
  {
    AddDocNode(r, "<h1>Info</h1>Empty bookmark name.  Bookmark not added.",
	       DN_ISHTML);
    NukeRequester(r);
    r->special = NULL;
    return;
  }

  b = CreateBookmark(r->dlist->doc->url, s);
  if (b == NULL)
  {
    NukeRequester(r);
    r->special = NULL;
    return;
  }
  
  b->next = r->blist;
  r->blist = b;
  
  if (r->actionVerify)
  {
    char *t;
    static char *message = "<h1>Info</h1>Added bookmark ";
    
    t = alloc_string_mem(strlen(message) + strlen(s) + 1);
    if (t != NULL)
    {
      strcpy(t, message);
      strcat(t, s);
      AddDocNode(r, t, DN_ISHTML);
      free(t);
    }
  }

  ListRedo(r->special);

  r->special = NULL;

  NukeRequester(r);

  WriteBookmarkFile(r->blist);

  return;
}

/*
 * ListBoomark
 *
 * Goes to the bookmark selected by the user.  This is actually a
 * callback for a command widget.  See lister.c.
 */
static void
ListBookmark(w, cldata, cbdata)
Widget w;
ListerCallbackData *cldata;
XtPointer cbdata;
{
  int i;
  Bookmark *b;
  XawListReturnStruct *lr;

  lr = XawListShowCurrent(cldata->listw);
  if (lr != NULL)
  {
    b = ((HTMLRoot *)(cldata->cbdata))->blist;
    for (i = 0; b; i++)
    {
      if (i == lr->list_index)
      {
	AddDocNode((HTMLRoot *)(cldata->cbdata), b->url, 0);
	break;
      }
      b = b->next;
    }
  }

  return;
}

/*
 * DeleteBookmark
 *
 * Deletes the bookmark selected by the user.  This is actually the
 * callback for a command widget.  Look at lister.c.  Be careful.
 */
static void
DeleteBookmark(w, cldata, cbdata)
Widget w;
ListerCallbackData *cldata;
XtPointer cbdata;
{
  int i;
  Bookmark *b, *tb;
  XawListReturnStruct *lr;
  HTMLRoot *r;

  lr = XawListShowCurrent(cldata->listw);
  if (lr == NULL)
  {
    return;
  }

  r = (HTMLRoot *)(cldata->cbdata);

  b = r->blist;
  tb = NULL;
  for (i = 0; b; i++)
  {
    if (i == lr->list_index)
    {
      if (tb == NULL)
      {
	r->blist = b->next;
      }
      else
      {
	tb->next = b->next;
      }
      break;
    }
    tb = b;
    b = b->next;
  }
  
  if (b)
  {
    if (r->actionVerify)
    {
      char *t;
      static char *message = "<h1>Info</h1>Deleted bookmark ";

      t = alloc_string_mem(strlen(message) + strlen(b->display) + 1);
      if (t != NULL)
      {
	strcpy(t, message);
	strcat(t, b->display);

	AddDocNode(r, t, DN_ISHTML);
	free(t);
      }
    }

    DestroyBookmark(b);

    ListRedo(cldata);
  }

  WriteBookmarkFile(r->blist);

  return;
}

/*
 * Prevents trouble.
 */
static void
MyXtSetSensitive(w, sensitive)
Widget w;
int sensitive;
{
  if (w)
  {
    XtSetSensitive(w, (Boolean)sensitive);
  }
  return;
}

/*
 * SetSensitive
 *
 * Figures out which buttons to make sensitive or insensitive.
 * Sensitive is a guideline which may be ignored.  Could probably
 * eliminate all of the if's here but it wouldn't look as cool.
 */
static void
SetSensitive(r, sensitive)
HTMLRoot *r;
int sensitive;
{
  MyXtSetSensitive(r->load, sensitive);
  MyXtSetSensitive(r->search, sensitive);
  MyXtSetSensitive(r->save, sensitive);
  MyXtSetSensitive(r->bookmark, sensitive);
  MyXtSetSensitive(r->print, sensitive);
  MyXtSetSensitive(r->help, sensitive);
  MyXtSetSensitive(r->cancel, sensitive);
  MyXtSetSensitive(r->source, sensitive);

  MyXtSetSensitive(r->reload, (r->dlist->doc->url != NULL ? True:False));

  if (r->dlist->next == NULL)
  {
    MyXtSetSensitive(r->back, False);
    MyXtSetSensitive(r->home, False);
  }
  else
  {
    MyXtSetSensitive(r->back, sensitive);
    MyXtSetSensitive(r->home, sensitive);
  }

  return;
}

/*
 * VisitTest
 *
 * Called by the HTML widget functions to determine if a link has been
 * visited.
 */
int
VisitTest(w, url)
Widget w;
char *url;
{
  char *nurl, *context;

  if (root.dlist == NULL)
  {
    fprintf (stderr, "VisitTest bug check.\n");
    return(0);
  }

  if (root.dlist->doc->url != NULL)
  {
    context = root.dlist->doc->url;
  }
  else
  {
    context = NULL;
  }

  nurl = MakeURL(url, context, NULL, 0);
  if (nurl == NULL)
  {
    return(0);
  }

  if (IsCached(nurl))
  {
    free(nurl);

    return(1);
  }

  free(nurl);

  return(0);
}

/*
 * DisplayTransferStatus
 *
 * This is called by the data transfer functions to display the status of
 * a transfer.  They should pass a simple, short string.  If a 1 is
 * returned then the transfer should be aborted.  The abort stuff
 * doesn't work yet.
 */
int
DisplayTransferStatus(s)
char *s;
{
  if (root.titledisplay != 0)
  {
    SetTitle(&root, s);
    XFlush(XtDisplay(root.w));
  }

  if (root.cancelop == True)
  {
    return(1);
  }

  return(0);
}

/*
 * SubmitForm
 *
 * Form callback for the HTML widget.
 */
void
SubmitForm(w, r, formdata)
Widget w;
HTMLRoot *r;
WbFormCallbackData *formdata;
{
  int i;
  char *n, *v, *t;
  char *url;
  char *href;
  char **nlist, **vlist;
  char sep = '?';
  int url_len;
  int ourl_len;
  extern MethodName methodname;

  if (formdata == NULL)
  {
    return;
  }

  nlist = formdata->attribute_names;
  vlist = formdata->attribute_values;

  if (vlist == NULL || vlist[0] == '\0')
  {
    return;
  }

  if (nlist == NULL || nlist[0] == '\0')
  {
    return;
  }

  if (formdata->method == NULL || strcmp(formdata->method, "GET") == 0)
  {
    methodname = MethodGET;
  }
  else if (strcmp(formdata->method, "POST") == 0)
  {
    methodname = MethodPOST;
  }
  else
  {
    fprintf (stderr, "Unknown method %s\n", formdata->method);
    return;
  }

  if (formdata->href == NULL || formdata->href[0] == '\0')
  {
    href = alloc_string(r->dlist->doc->url);
  }
  else
  {
    href = alloc_string(formdata->href);
  }

  if (href == NULL)
  {
    return;
  }

  StripSearchURL(href);

  /*
   * If there is only one attribute and it is named isindex then
   * treat this like a regular searchable index.  Otherwise
   * do form stuff.
   */
  if (formdata->attribute_count == 1 && mystrcmp("isindex", nlist[0]) == 0)
  {
    url = alloc_string_mem(strlen(href) +
			   strlen(vlist[0]) + 2);
    if (url == NULL)
    {
      free(href);
      return;
    }

    sprintf (url, "%s?%s", href, vlist[0]);

    t = FixURL(url);
    if (t != NULL)
    {
      free(url);
      url = t;
    }

    free(href);
  }
  else
  {
    url_len = strlen(href);
    url = alloc_string_mem(url_len + 1);
    if (url == NULL)
    {
      free(href);
      return;
    }
    strcpy(url, href);
    free(href);

    for (i = 0; i < formdata->attribute_count; i++)
    {
      if (nlist[i] == NULL) continue;

      n = EscapeURL(nlist[i]);
      if (n == NULL)
      {
	free(url);
	return;
      }

      if (vlist[i] != NULL)
      {
	v = EscapeURL(vlist[i]);
	if (v == NULL)
	{
	  free(n);
	  free(url);
	  return;
	}
      }
      else
      {
	v = "";
      }
      
      /*
       * length of URL + length of attribute name + length of
       * attribute value + ampersand/question mark + equal sign + NULL
       */
      ourl_len = url_len;
      url_len = url_len + strlen(n) + strlen(v) + 1 + 1;
      url = realloc_string_mem(url, url_len + 1);
      if (url == NULL)
      {
	free(n);
	free(v);
	
	return;
      }
      
      sprintf (url + ourl_len, "%c%s=%s", sep, n, v); 
      sep = '&';
    }
  }

  AddDocNode(r, url, 0);

  methodname = MethodGET;

  return;
}
