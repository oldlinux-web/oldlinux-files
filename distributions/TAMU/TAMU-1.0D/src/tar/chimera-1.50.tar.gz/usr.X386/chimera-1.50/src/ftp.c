/*
 * ftp.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 * Handles FTP transfers.
 *
 */
#include <stdio.h>

#ifndef NOSTDHDRS
#include <stdlib.h>
#endif

#include "document.h"
#include "access.h"
#include "net.h"
#include "util.h"
#include "url.h"
#include "conf.h"

#if NeedFunctionPrototypes
static char *ftp_dir(char *, int, char *, char *);
static int soak(int);
extern int DisplayTransferStatus(char *);
#else
static char *ftp_dir();
static int soak();
extern int DisplayTransferStatus();
#endif

/*
 * soak
 * 
 * This function is used to "soak up" the multiline BS that some
 * ftp servers spew (not that it is bad to have nice long
 * informational messages its just that I hate them from my
 * programmer's point of view).
 */
static int
soak(s)
int s;
{
  char buffer[BUFSIZ];
  char ftpcode[5];
  int blen;
  int i;
  int firstline;
  int pastgarbage;
  int endgarbage;
  int lastline;
  int code;

  /*
   * Deal with the greeting.
   *
   * This stuff is kind of hairy since the read won't necessarily break
   * off at the end of line.  The end of greeting line starts with
   * 'XXX ' (X is a digit) which might be located in the middle of the
   * read buffer.  Neat.
   */
  firstline = 1;
  lastline = 0;
  pastgarbage = 0;
  endgarbage = 0;
  code = 200;
  for(;;)
  {
    blen = net_read(s, buffer, sizeof(buffer));
    if (blen < 0)
    {
      return(9999);
    }

    for (i = 0; i < blen; i++)
    {
      if (lastline)
      {
	if (buffer[i] == '\n')
	{
	  break;
	}
      }
      else if (endgarbage || firstline)
      {
	ftpcode[pastgarbage++] = buffer[i];
	if (pastgarbage == 4)
	{
	  ftpcode[pastgarbage - 1] = '\0';
	  pastgarbage = 0;
	  code = atoi(ftpcode);

	  if (buffer[i] == ' ' && code > 0)
	  {
	    lastline = 1;
	  }
	  else
	  {
	    endgarbage = 0;
	  }
	}
      }
      else if (buffer[i] == '\n')
      {
	endgarbage = 1;
	pastgarbage = 0;
      }
    }

    firstline = 0;

    if (i < blen)
    {
      break;
    }
  }

  return(code);
}

/*
 * ftp
 *
 * Anonymous FTP interface
 *
 * This is getting to be quite large and that is without all of the
 * necessary error checking being done.
 *
 */
void
ftp(info, hostname, portno, filename, ext)
Document *info;
char *hostname;
int portno;
char *filename;
char *ext;
{
  char *query;
  char buffer[BUFSIZ];
  char data_hostname[48];
  char stats[256];
  char *t;
  char *domain;
  char *uname;
  int blen;
  int s, d;
  int isdir;
  int h0, h1, h2, h3, p0, p1, reply, n;
  int data_port;
  int tlen = 0;
  int btlen = 0;
  static char *format = "PASS -%s@%s\r\n"; 
  static char *format2 = "RETR %s\r\n";
  static char *format3 = "CWD %s\r\n";

  info->text = NULL;
  info->type = DocUnknown;

  if (portno == -1)
  {
    portno = DEFAULT_FTP_PORT;
  }

  filename = EscapeURL(filename);
  if (filename == NULL)
  {
    return;
  }

  /*
   * Contact the ftp server on the usualy port.  Hardcoding ports is bad.
   */
  s = net_open(hostname, portno);
  if (s < 0)
  {
    info->type = DocInternal;
    info->text = alloc_string("<h1>Error</h1>Could not make connection.  Either the host does not exist or is not available.");

    free(filename);
    return;
  }

  /*
   * Take care of the greeting.
   */
  if (soak(s) >= 400) 
  {
    net_close(s);
    free(filename);
    return;
  }

  /*
   * Send the user name
   */
  strcpy(buffer, "USER anonymous\r\n");
  net_write(s, buffer, strlen(buffer));

  if (soak(s) >= 400)
  {
    net_close(s);
    free(filename);
    return;
  }

  domain = net_gethostname();
  if (domain == NULL)
  {
    net_close(s);
    free(filename);
    return;
  }

  /*
   * Send the password
   */
  if ((uname = getenv("USER")) == NULL)
  {
    uname = "nobody";
  }

  query = alloc_string_mem(strlen(uname) + 
			   strlen(domain) + strlen(format) + 1);
  sprintf(query, format, uname, domain);

  net_write(s, query, strlen(query));

  free(query);

  if (soak(s) >= 400)
  {
    net_close(s);
    free(filename);
    return;
  }

  /*
   * Set binary transfers
   */
  strcpy(buffer, "TYPE I\r\n");
  net_write(s, buffer, strlen(buffer));

  if (soak(s) >= 400)
  {
    net_close(s);
    free(filename);
    return;
  }

  /*
   * Set passive mode and grab the port information
   */
  strcpy(buffer, "PASV\r\n");
  net_write(s, buffer, strlen(buffer));

  blen = net_read(s, buffer, sizeof(buffer));
  if (blen <= 0)
  {
    net_close(s);
    free(filename);
    return;
  }
  
  n = sscanf(buffer, "%d %*[^(] (%d,%d,%d,%d,%d,%d)", &reply, &h0, &h1, &h2, &h3, &p0, &p1);
  if (n != 7 || reply != 227)
  {
    net_close(s);

    free(filename);

    return;
  }

  sprintf (data_hostname, "%d.%d.%d.%d", h0, h1, h2, h3);

  /*
   * Open a data connection
   */
  data_port = (p0 << 8) + p1;
  d = net_open(data_hostname, data_port);
  if (d < 0)
  {
    net_close(s);

    free(filename);

    return;
  }

  /*
   * Try to retrieve the file
   */
  query = alloc_string_mem(strlen(filename) + strlen(format2) + 1);
  sprintf(query, format2, filename);
  if (net_write(s, query, strlen(query)) < 0)
  {
    net_close(s);
    net_close(d);

    free(query);

    free(filename);

    return;
  }
  free(query);

  reply = soak(s);
  if (reply == 9999)
  {    
    net_close(s);
    net_close(d);
    free(filename);
    return;
  }

  /*
   * If the retrieve fails try to treat the file as a directory.
   * If the file is a directory then ask for a listing.
   */
  if (reply >= 400)
  {
    /*
     * Try to read the file as a directory.
     */
    query = alloc_string_mem(strlen(filename) + strlen(format3) + 1);
    sprintf (query, format3, filename);
    net_write(s, query, strlen(query));
    free(query);

    if (soak(s) >= 400)
    {
      net_close(d);
      net_close(s);
      free(filename);
      return;
    }

    strcpy (buffer, "NLST\r\n");
    net_write(s, buffer, strlen(buffer));

    if (soak(s) >= 400)
    {
      net_close(s);
      net_close(d);
      free(filename);
      return;
    }

    isdir = 1;
  }
  else
  {
    isdir = 0;
  }

  /*
   * Read info from the FTP host
   */
  t = NULL;
  tlen = 0;
  btlen = 0;
  while ((blen = net_read(d, buffer, sizeof(buffer))) > 0)
  {
    tlen += blen;

    if (t)
    {
      t = (char *)realloc(t, tlen + 1);
    }
    else
    {
      t = (char *)malloc(tlen + 1);
    }
    if (t == NULL)
    {
      break;
    }

    memcpy(t + btlen, buffer, blen);
    btlen = tlen;

    sprintf (stats, LOAD_MESSAGE, tlen);
    if (DisplayTransferStatus(stats) == 1)
    {
      free(t);

      info->text = alloc_string("<h1>Info</h1>Transfer cancelled.");
      info->type = DocInternal;

      net_close(s);

      return;
    }
  }

  net_close(s);
  net_close(d);

  /*
   * Do some processing on the information.  If it a directory do some
   * really special stuff.  If it is a file then do other stuff.  See
   * file.c for file processing.
   */
  if (t)
  {
    info->text = t;
    info->len = tlen;

    t[tlen] = '\0';

    if (isdir)
    {
      char *otext = info->text;

      info->text = ftp_dir(hostname, portno, filename, otext);
      if (info->text != NULL)
      {
        info->type = DocInternal;
      }

      free(otext);
    }
    else
    {
      info->type = DocUnknown;
    }
  }

  free(filename);

  return;
}

/*
 * ftp_dir
 *
 * Process data from an ftp directory listing.  This converts the listing
 * to HTML with the proper anchors so that the user can click on each
 * entry and access that entry.
 *
 */
static char *
ftp_dir(hostname, portno, filename, t)
char *hostname;
int portno;
char *filename;
char *t;
{
  char *temp;
  char *fptr;
  char *p, *f = NULL;
  char buffer[256];
  char file[256];
  int flen = 0, lastflen = 0;
  static char *head = "<title>FTP directory %s on %s</title>\n<h1> FTP directory %s </h1>\n<ul>\n";
  static char *entry = "<li> <a href=ftp://%s:%d%s/%s> %s </a>\n";
  static char *trail = "</ul>";

  p = t;

  /*
   * First make a title line with the hostname and file name and all that
   * jazz.
   */
  temp = alloc_string_mem(strlen(filename) * 2 + strlen(hostname) +
			   strlen(head) + 1 + 10);
  sprintf (temp, head, filename, hostname, filename);
  flen = strlen(temp);
  f = (char *)malloc(sizeof(char) * (flen + 1));
  if (f == NULL)
  {
    return(NULL);
  }
  strcpy(f, temp);
  free(temp);

  if (filename[0] == '/' && filename[1] == '\0')
  {
    fptr = "";
  }
  else
  {
    fptr = filename;
  }

  /*
   * The following lines should be directory entries.  If there are no
   * directory entries then this loop will just poop out.  There will
   * always be one iteration since we need a link back to the parent
   * directory.
   */
  while ((p = get_line(p, buffer, sizeof(buffer))) != NULL)
  {
    /*
     * First get the filename
     */
    sscanf(buffer, "%s", file);

    /*
     * Now craft a bit of HTML with an anchor for the directory entry
     * and add it to the end of the HTML buffer.  Use realloc to extend
     * the buffer and sprintf to put the formatted HTML in the newly
     * allocated space.
     */
    lastflen = flen;
    temp = alloc_string_mem(strlen(file) * 2 + strlen(hostname) +
			     strlen(fptr) + strlen(entry) + 10 + 1);
    sprintf (temp, entry, hostname, portno, fptr, file, file);
    flen += strlen(temp);
    f = (char *)realloc(f, sizeof(char) * (flen + 1));
    if (f == NULL)
    {
      return(NULL);
    }
    strcpy(f + lastflen, temp);
    free(temp);
  }

  /*
   * Put the trailer on the end for completeness.  Heck, might as well
   * be a nice guy about it.
   */
  lastflen = flen;
  flen += strlen(trail);
  f = (char *)realloc(f, sizeof(char) * (flen + 1));
  if (f == NULL)
  {
    return(NULL);
  }
  strcpy(f + lastflen, trail);

  return(f);
}






