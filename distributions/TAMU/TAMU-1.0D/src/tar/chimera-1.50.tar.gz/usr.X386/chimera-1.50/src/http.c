/*
 * http.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 * Handles HTTP 'GET'.  Use this to grab a document from an HTTP server.
 * Handles HTTP/1.0.
 *
 */
#include <stdio.h>
#include <ctype.h>

#ifndef NOSTDHDRS
#include <stdlib.h>
#endif

#include "document.h"
#include "access.h"
#include "net.h"
#include "util.h"
#include "conf.h"

#if NeedFunctionPrototypes
static void standard_http(Document *);
extern int DisplayTransferStatus(char *);
#else
static void standard_http();
extern int DisplayTransferStatus();
#endif

/*
 * Notice evil global variable.  Keep your eye on this guy.
 */
MethodName methodname = MethodGET;

/*
 * http
 *
 * This is the HTTP interface.  The only command it knows is 'GET'.
 * It uses "Accept: *.*".  Problem is that
 * you have to know ahead of time what class(?) (image,
 * audio, text,...) the data is in order to tell which contents you'll
 * accept.  I could connect and when I get the generic server error
 * I can try every content known but that wouldn't be such a great
 * idea now would it?
 *
 * I am going apeshit here.
 *
 * The funny part about all of this is that there probably is a way
 * to deal with this problem but I just haven't been able to figure
 * it out.
 *
 */
void
http(d, hostname, portno, filename, ext)
Document *d;
char *hostname;
int portno;
char *filename;
char *ext;
{
  char *query;
  char buffer[BUFSIZ];
  char stats[256];
  int blen;
  int s;
  char *t = NULL;
  int tlen = 0;
  int btlen = 0;
  static char *format_get = "GET %s%s HTTP/1.0\r\nAccept: */*\r\n\r\n";
  static char *format_post = "POST %s HTTP/1.0\r\nContent-length: %d\r\nContent-type: application/x-www-form-urlencoded\r\n\r\n%s\r\n";

  if (portno == -1)
  {
    portno = DEFAULT_HTTP_PORT;
  }

  d->type = DocUnknown;
  d->text = NULL;

  /*
   * Start chitchatting with the HTTP server.
   */
  s = net_open(hostname, portno);
  if (s < 0)
  {
    return;
  }

  /*
   * Send request
   */
  if (methodname == MethodGET) /* GET */
  {
    query = alloc_string_mem(strlen(filename) + strlen(format_get) +
			     strlen(ext) + 1);
    if (query == NULL)
    {
      net_close(s);
      
      return;
    }

    if (ext[0] == '?')
    {
      sprintf (query, format_get, filename, ext);
    }
    else
    {
      sprintf (query, format_get, filename, "");
    }
    if (net_write(s, query, strlen(query)) < 0)
    {
      net_close(s);
      
      return;
    }
  }
  else /* POST ! */
  {
    query = alloc_string_mem(strlen(filename) + strlen(format_post) +
			     strlen(ext + 1) + 1);
    if (query == NULL)
    {
      net_close(s);

      return;
    }

    sprintf (query, format_post, filename, strlen(ext + 1), ext + 1);
    if (net_write(s, query, strlen(query)) < 0)
    {
      net_close(s);
      free(query);

      return;
    }
  }
  free(query);

  /*
   * Read info from the HTTP host
   */
  while ((blen = net_read(s, buffer, sizeof(buffer))) > 0)
  {
    tlen += blen;
    if (t)
    {
      t = (char *)realloc(t, tlen + 1);
    }
    else
    {
      t = (char *)malloc(tlen + 1);
    }
    
    if (t == NULL)
    {
      net_close(s);
      
      return;
    }

    memcpy(t + btlen, buffer, blen);
    btlen = tlen;

    sprintf (stats, LOAD_MESSAGE, tlen);
    if (DisplayTransferStatus(stats) == 1)
    {
      free(t);

      d->text = NULL;
      d->text = alloc_string("<h1>Info</h1>Transfer cancelled.");
      d->type = DocInternal;

      net_close(s);

      return;
    }
  }

  net_close(s);

  if (tlen == 0)
  {
    return;
  }

  /*
   * Terminate the data, fill in the Document.
   */
  t[tlen] = '\0';
  d->text = t;
  d->len = tlen;

  /*
   * Check for the proper header information.  Notice the evil 5.
   * Everyone should be using HTTP/1.0 by now.
   */
  if (mystrncmp("HTTP/", d->text, 5) == 0)
  {
    standard_http(d);
  } 
  else
  {
    if (filename[strlen(filename) - 1] == '/')
    {
      d->content = alloc_string("text/html");
    }
    else
    {
      char *cp;

      for (cp = filename; *cp; cp++)
      {
	if (*cp == '?')
	{
	  d->content = alloc_string("text/html");
	  break;
	}
      }
    }
  }

  return;
}

/*
 * standard_http
 *
 * This function sorts out the standard HTTP header (which looks like
 * a MIME header and sorts out the error code and all that jazz.
 * This is a whole bunch of hard-coded MIME string fields and stuff
 * in here.
 */
static void
standard_http(d)
Document *d;
{
  char buffer[256];
  char junk[256];
  char field[256];
  char data[256];
  char *t;
  int error_code;
  int i, j;

  /*
   * The first line should be a status line:
   *
   * HTTP/x.x error_code swell message with spaces
   *
   * In fact, we shouldn't even get here if the line didn't start "HTTP"...
   */
  t = get_line(d->text, buffer, sizeof(buffer));
  if (t == NULL)
  {
    /*
     * Unlikely to happen but you never know...
     */
    return;
  }

  sscanf (buffer, "%s %d %s", junk, &error_code, junk);

  /*
   * Read the MIME fields and figure out what is going on.
   */
  while ((t = get_line(t, buffer, sizeof(buffer))) != NULL)
  {
    /*
     * Check for end of MIME header (that's a blank line to you and me).
     */
    if (buffer[0] == '\0')
    {
      break;
    }

    /*
     * Oversimplified MIME field parser.  But heck we are only looking
     * for MIME fields with simple data.
     */
    sscanf(buffer, "%[^:] %[:] %[^\n]", field, junk, data);

    /*
     * Pick out the MIME fields that we understand and do stuff with
     * the data.  Only understands Content-type and Location.  It may
     * not handle them correctly since I didn't look at the RFC.
     */
    if (mystrncmp("Content-type", field, 12) == 0)
    {
      /*
       * Ho boy!  This is good.  Now we know how to deal with the document.
       * If the string allocate fails then it will look at the filename
       * so it isn't a complete disaster.  Of course if this puny
       * allocate fails then something else is bound to fail.
       */
      d->content = alloc_string(data);
    }
    else if (mystrncmp("Location", field, 8) == 0)
    {
      /*
       * Handle 3xx guys.  Try to deal with looping.  Of course a document
       * could go to
       * another document which loops back to the current document.
       * I don't care to be that clever.  I figure this will fool the
       * BSDI test case.
       */
      if (error_code >= 300 && error_code <= 399)
      {
	if (mystrcmp(d->url, data))
	{
	  char *u = alloc_string(data);
	  if (u)
	  {
	    free(d->url);
	    d->url = u;
	    ReloadDocument(d);
	  }
	  return;
	}
      }
    }
  }

  /*
   * It is possible that the info is screwed up.  Just return and let
   * the user see the server's screwup (it might be the client's fault).
   */
  if (t == NULL)
  {
    return;
  }

  /*
   * Since the amount of actual data is smaller we can reuse the
   * space.  Have to do a copy anyways.
   */
  for (j = 0, i = t - d->text; i < d->len; i++, j++)
  {
    d->text[j] = d->text[i]; 
  }
  d->text[j] = '\0';

  if (error_code >= 400)
  {
    d->content = alloc_string("text/html");
  }

  return;
}



