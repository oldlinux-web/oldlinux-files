/*
 * file.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 * Screws around with the data and either sends it back as an HTML file
 * or executes another program to display the data.
 *
 */
#include <stdio.h>
#include <fcntl.h>
#include <ctype.h>

#ifndef NOSTDHDRS
#include <stdlib.h>
#endif

#include <errno.h>
#include <sys/signal.h>
#include <sys/wait.h>

extern int errno;

#include "content.h"
#include "document.h"
#include "file.h"
#include "url.h"
#include "util.h"
#include "conf.h"

/*
 * Just in case.
 */
#ifndef L_tmpnam
#define L_tmpnam 1024
#endif

/*
 * SaveData
 *
 * Save the data from a download to a file.
 *
 */
int
SaveData(data, filename)
Document *data;
char *filename;
{
  int i, c;
  int fd;
  int e = 0;

  fd = open(filename, O_WRONLY | O_CREAT, 0600);
  if (fd < 0)
  {
    return(-1);
  }

  for (i = 0; i < data->len; i += e)
  {
    c = data->len - i;
    c = (BUFSIZ > c ? c : BUFSIZ);
    if ((e = write(fd, data->text + i, c)) <= 0)
    {
      break;
    }
  }

  close(fd);

  if (e <= 0)
  {
    return(-1);
  }

  return(0);
}

/*
 * text
 *
 * deal with text files
 */
static void
text(d, command)
Document *d;
char *command;
{
  char *t;

  t = alloc_string("<plaintext>");
  if (t != NULL)
  {
    t = recomb_string(t, d->text);
    if (t != NULL)
    {
      free(d->text);
      d->text = t;
      d->type = DocInternal;
    }
  }

  return;
}

/*
 * ReapChild
 *
 * This code grabs the status from an exiting child process.  We really
 * don't care about the status, we just want to keep zombie's from
 * cropping up.
 */
static void
ReapChild()
{
  int pid;
  int old_errno = errno;
 /*
  * It would probably be better to use the POSIX mechanism here,but I have not 
  * checked into it.  This gets us off the ground with SYSV.  RSE@GMI
  */
#if defined(WNOHANG) && !defined(SYSV)
  union wait st;

  do 
  {
    errno = 0;
    pid = wait3(&st, WNOHANG, 0);
  }
  while (pid <= 0 && errno == EINTR);
#else
  int st;

  wait(&st);
#endif
  StartReaper();
  errno = old_errno;

  return;
}

/*
 * StartReaper
 *
 * This code inits the code which reaps child processes that where
 * fork'd off for external viewers.
 */
void
StartReaper()
{
#ifdef SIGCHLD
  signal(SIGCHLD, ReapChild);
#else
  signal(SIGCLD, ReapChild);
#endif

  return;
}

/*
 * process
 *
 * Deal with data files with external commands.
 *
 */
static void
process(d, command, path)
Document *d;
char *command;
char *path;
{
  char *cmdline;
  char *filename;
  char tmpnam_buffer[L_tmpnam];

  if (d->len == 0)
  {
    return;
  }

  if (SaveData(d, (filename = tmpnam(tmpnam_buffer))) == -1)
  {
    d->text = alloc_string("<h1>Error</h1>Could not store document data.");
  }
  else
  {
    cmdline = alloc_string_mem(strlen(command) + strlen(filename) + 1);
    sprintf (cmdline, command, filename);

    if (path != NULL)
    {
      char *t;

      t = alloc_string_mem(strlen(path) + strlen(cmdline) + 7);
      sprintf(t, "PATH=%s;%s", path, cmdline);
      free(cmdline);
      cmdline = t;      
    }
    
    if (fork() == 0)
    {
      system(cmdline);
      unlink(filename);
      exit(0);
    }

    free(cmdline);

    d->type = DocExternal;
  }

  return;
}

#ifdef SIGPIPE
/*
 * sigpipehandler
 *
 * right
 */
static void
sigpipehandler()
{
  signal(SIGPIPE, sigpipehandler);

  return;
}
#endif

/*
 * pipe
 *
 * Pipe a command through an external command and stick the data back
 * in the document.  Nifty.
 *
 */
static void
processpipe(d, command, path)
Document *d;
char *command;
char *path;
{
  FILE *p;
  char *t;
  char *filename;
  char *cmdline;
  char tmpnam_buffer[L_tmpnam];
  char buffer[256];
  int len, olen;
  int count;

  if (d->len == 0)
  {
    return;
  }

  if (SaveData(d, (filename = tmpnam(tmpnam_buffer))) == -1)
  {
    d->text = alloc_string("<h1>Error</h1>Ran out of temporary disk space?");
  }
  else
  {
    cmdline = alloc_string_mem(strlen(command) + strlen(filename) + 1);
    sprintf (cmdline, command, filename);

    if (path != NULL)
    {
      t = alloc_string_mem(strlen(path) + strlen(cmdline) + 7);
      sprintf(t, "PATH=%s;%s", path, cmdline);
      free(cmdline);
      cmdline = t;
    }

#ifdef SIGPIPE
    signal(SIGPIPE, sigpipehandler);
#endif

    p = popen(cmdline, "r");
    if (p == NULL)
    {
      d->text = alloc_string("<h1>Error</h1>Could not open pipe to ");
      d->text = recomb_string(d->text, cmdline);

      return;
    }

    t = NULL;
    len = 0;
    while ((count = fread(buffer, 1, sizeof(buffer), p)))
    {
      olen = len;
      len += count;
      if (t)
      {
	t = realloc(t, len);
      }
      else
      {
	t = malloc(len);
      }

      if (t != NULL)
      {
	memcpy(t + olen, buffer, count);
      }
    }

    pclose(p);

    free(cmdline);

    unlink(filename);

    d->otext = t;
    d->olen = len;
  }

  return;
}

/*
 * ProcessFile
 *
 * Processes the data from a file by looking at the extension and then
 * doing the right thing.  Adding a carat (^) to the front of a name
 * makes the name compare start at the front.
 *
 * The contrived third argument is used to specify an alternate
 * access method.
 */
void
ProcessDocument(d, clist, altaccess, path)
Document *d;
Content *clist;
char *altaccess;
char *path;
{
  Content *c;
  int portno;
  char *s;
  char access[256];
  char hostname[256];
  char filename[256];

  /*
   * Has the document already been processed?
   */
  if (d->type != DocUnknown)
  {
    return;
  }

  /*
   * Figure out what string to use to ID the contents of the file.
   */
  ParseURL(d->url,
	   access, sizeof(access),
	   hostname, sizeof(hostname),
	   &portno,
	   filename, sizeof(filename),
	   NULL, 0);

  if (d->content)
  {
    s = d->content;
  }
  else
  {
    s = filename;
  }

  if (altaccess)
  {
    c = GetContent(clist, altaccess, s);
  }
  else
  {
    c = GetContent(clist, access, s);
  }
  if (c != NULL)
  {
    switch (c->method[0])
    {
      case '!':
        process(d, (c->method) + 1, path);
	break;
      case '|':
	processpipe(d, (c->method) + 1, path);
        break;
      default:
        if (mystrcmp(c->method, "text") == 0)
	{
	  text(d);
	}
	else if (mystrcmp(c->method, "html") == 0)
	{
	  d->type = DocInternal;
	}
	else
	{
	  d->type = DocUnknown;
	}
	break;
    }
    return;
  }

  text(d);

  return;
}
