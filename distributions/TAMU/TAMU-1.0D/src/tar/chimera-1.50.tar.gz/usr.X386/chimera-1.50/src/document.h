/*
 *
 * document.h
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 */

typedef enum
{
  DocInternal, /* HTML for now */
  DocImage,    /* Inline Image */
  DocExternal, /* anything not internal: GIF, AU, PS, DVI, MPEG, ... */
  DocUnknown   /* not a clue */
} DocType;

typedef struct _document
{
  char *text;           /* the stuff in the document */
  char *otext;          /* data processed by a pipe goes here */
  char *url;            /* the address of the document */
  char *content;        /* content-type might be NULL */
  char *ext;            /* extra garbage like '#' or '?' */
  int len;              /* the len of the data */
  int olen;             /* length of piped data */
  long last_access;     /* last time this document was grabbed */
  int ref_count;        /* reference count */
  DocType type;         /* type of document */
  DocType otype;        /* type of piped info */
  struct _document *cnext; /* next cached document */
} Document;

#if NeedFunctionPrototypes
Document *LoadDocument(char *);
void ReloadDocument(Document *);
void ReleaseDocument(Document *);
Document *MakeDocument(char *);
void TransferDocument(Document *, Document *);
void FlushDocument(Document *);
int IsCached(char *);
#else
Document *LoadDocument();
void ReloadDocument();
void ReleaseDocument();
Document *MakeDocument();
void TransferDocument();
void FlushDocument();
int IsCached();
#endif



