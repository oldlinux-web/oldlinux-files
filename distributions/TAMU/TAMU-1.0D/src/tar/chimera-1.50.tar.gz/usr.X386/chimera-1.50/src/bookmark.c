/*
 * bookmark.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 * Deals with the bookmark file
 *
 */
#include <stdio.h>

#ifndef NOSTDHDRS
#include <stdlib.h>
#endif

#include "bookmark.h"
#include "util.h"
#include "conf.h"

/*
 * get_bookmark_file
 *
 * returns a filename in filename to be used for the bookmark file.
 */
static void
get_bookmark_file(filename, len)
char *filename;
int len;
{
  char *dir;

  if ((dir = getenv("HOME")) == NULL)
  {
    dir = "/tmp";
  }

  if (len > strlen(dir) + strlen(BOOKMARK_FILE))
  {
    sprintf (filename, "%s/%s", dir, BOOKMARK_FILE);
  }
  else
  {
    fprintf (stderr, "Bookmark filename problem!  Adjust the size of BOOKMARK_FILE!\n");
    exit(1);
  }

  return;
}

/*
 * DestroyBookmark
 *
 * Deallocate a bookmark
 */
void
DestroyBookmark(b)
Bookmark *b;
{
  if (b->url)
  {
    free(b->url);
  }
  if (b->display)
  {
    free(b->display);
  }
  free(b);

  return;
}

/*
 * CreateBookmark
 *
 * Allocate the space for a bookmark.
 */
Bookmark *
CreateBookmark(url, display)
char *url;
char *display;
{
  Bookmark *b;

  b = (Bookmark *)malloc(sizeof(Bookmark));
  if (b == NULL)
  {
    return(NULL);
  }
  
  b->url = alloc_string(url);
  if (b->url == NULL)
  {
    free(b);

    return(NULL);
  }
  
  b->display = alloc_string(display);
  if (b->display == NULL)
  {
    free(b->url);
    free(b);

    return(NULL);
  }

  b->next = NULL;

  return(b);
}

/*
 * ReadBookmarkFile
 *
 * Guess
 */
Bookmark *
ReadBookmarkFile()
{
  FILE *fp;
  Bookmark *blist, *b, *t;
  char buffer[256];
  char url[256];
  char display[256];

  get_bookmark_file(buffer, sizeof(buffer));

  fp = fopen(buffer, "r");
  if (fp == NULL)
  {
    return(NULL);
  }

  blist = NULL;
  t = NULL;
  while (fgets(buffer, sizeof(buffer), fp))
  {
    if (sscanf(buffer, "%s %[^\n]", url, display) == 2)
    {
      b = CreateBookmark(url, display);
      if (b == NULL)
      {
	fclose(fp);

	return(NULL);
      }

      if (blist)
      {
	t->next = b;
      }
      else
      {
	blist = b;
      }
      t = b;
    }
  }

  fclose(fp);

  return(blist);
}

/*
 * WriteBookmarkFile
 *
 * Guess
 */
void
WriteBookmarkFile(b)
Bookmark *b;
{
  FILE *fp;
  char filename[256];

  get_bookmark_file(filename, sizeof(filename));

  fp = fopen(filename, "w");
  if (fp == NULL)
  {
    return;
  }

  while (b)
  {
    fprintf (fp, "%s\t%s\n", b->url, b->display);

    b = b->next;
  }

  fclose(fp);

  return;
}


