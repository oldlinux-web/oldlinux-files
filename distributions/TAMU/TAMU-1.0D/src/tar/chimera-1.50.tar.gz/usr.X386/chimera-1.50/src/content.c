/*
 * content.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 */
#include <stdio.h>

#ifndef NOSTDHDRS
#include <stdlib.h>
#endif

#include "content.h"
#include "util.h"

/*
 * ReadContentDB
 *
 * Reads the content database.
 */
Content *
ReadContentDB(filename)
char *filename;
{
  FILE *fp;
  Content *t, *c, *clist = NULL;
  char buffer[256];
  char access[256];
  char accessid[256];
  char method[256];

  fp = fopen(filename, "r");
  if (fp == NULL)
  {
    return(NULL);
  }

  t = NULL;
  while (fgets(buffer, sizeof(buffer), fp))
  {
    if (buffer[0] != '#')
    {
      if (sscanf(buffer, "%s %s %[^\n]",
		 access,
		 accessid,
		 method) == 3)
      {
	c = (Content *)malloc(sizeof(Content));
	if (c == NULL)
	{
	  fclose(fp);

	  return(NULL);
	}
	c->access = alloc_string(access);
	c->accessid = alloc_string(accessid);
	c->method = alloc_string(method);
	if (c->access == NULL || c->accessid == NULL || c->method == NULL)
	{
	  fclose(fp);

	  return(NULL);
	}

	if (clist)
	{
	  t->next = c;
	}
	else
	{
	  clist = c;
	}
	t = c;
      }
    }
  }

  fclose(fp);

  return(clist);
}

/*
 * GetContent
 *
 * Returns the content type for a filename.
 */
Content *
GetContent(clist, access, filename)
Content *clist;
char *access;
char *filename;
{
  Content *c;
  int flen, elen;

  /*
   * Compare bits of the filename to try to determine file type.
   */
  flen = strlen(filename);
  c = clist;
  while (c)
  {
    if (c->access[0] == '*' || mystrcmp(access, c->access) == 0)
    {
      elen = strlen(c->accessid);
      switch (c->accessid[0])
      {
	case '*':
	  return(c);
	  break;

	case '^':
	  if (elen - 1 <= flen &&
              mystrncmp(filename, (c->accessid) + 1, elen - 1) == 0)
	  {
	    return(c);
	  }
	  break;

	default:
	  if (elen <= flen &&
              mystrncmp(filename + flen - elen, c->accessid, elen) == 0)
	  {
	    return(c);
	  }
      }
    }
    c = c->next;
  }

  return(NULL);
}
