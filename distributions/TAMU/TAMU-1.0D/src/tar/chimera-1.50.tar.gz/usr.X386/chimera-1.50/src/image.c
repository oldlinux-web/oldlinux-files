/*
 * image.c
 *
 * Copyright (C) 1993, John Kilburg.
 *
 * You may distribute this code freely as long as it is used only
 * for academic, research, and internal business uses only, without
 * a fee.  You may distribute the binary and source code to third
 * parties provided that the copyright notice and this statement
 * appears on all copies and that no charge is associated with such
 * copies.
 *
 * If you make and distribute modified versions of the source or
 * binaries then you must inform me (John Kilburg) of the distribution.
 * You must also give me credit for the original in the source and
 * documentation but you must indicate that modifications were made.
 *
 * If you wish to make commercial use of the source or binaries you should    
 * contact me, to negotiate an appropriate license for such
 * commercial use.  Commercial use includes (1) integration of all or    
 * part of the source code into a product for sale or license by or on   
 * behalf of Licensee to third parties, or (2) distribution of the binary
 * code or source code to third parties that need it to utilize a          
 * commercial product sold or licensed by you or on your behalf.        
 * 
 * This software is provided "as is" without expressed or
 * implied warranty.  It is not intended to be used for any particular
 * purpose.  I shall not be liable for any damages suffered by users
 * of this software.  USE AT YOUR OWN RISK.
 *
 */
#include <stdio.h>

#ifndef NOSTDHDRS
#include <stdlib.h>
#endif

#include <ctype.h>

#include <X11/Intrinsic.h>

#define _NO_PROTO

#include "HTML.h"

#include "document.h"
#include "util.h"
#include "image.h"
#include "conf.h"

#define MAXCOLORS 256

/*
 * This stuff really doesn't handle PBM, PGM, or PPM files too well.
 * This code assumes that each field is on a separate line...most of
 * the time it is.  BUT a perfectly good file may fail.
 */

/*
 * PPM2Image
 *
 * Converts PPM data to a ImageInfo structure.
 */
static ImageInfo *
PPM2ImageInfo(t, format)
char *t;
char format;
{
  ImageInfo *img;
  char *p, *n;
  char buffer[256];
  char num[11];
  int r[MAXCOLORS], g[MAXCOLORS], b[MAXCOLORS];
  int hv[MAXCOLORS];
  int c[3];
  int colorcount = 0;
  int i, j, k, l, m, v;
  int maxcolorval;

  img = (ImageInfo *)malloc(sizeof(ImageInfo));
  if (img == NULL)
  {
    return(NULL);
  }

  /* get dimensions */
  while ((t = get_line(t, buffer, sizeof(buffer))) != NULL)
  {
    if (buffer[0] != '#')
    {
      break;
    }
  }
  sscanf(buffer, "%d %d", &(img->width), &(img->height));

  /* get max color */
  while ((t = get_line(t, buffer, sizeof(buffer))) != NULL)
  {
    if (buffer[0] != '#')
    {
      break;
    }
  }
  sscanf(buffer, "%d", &maxcolorval);

  img->image_data = (unsigned char *)malloc(sizeof(unsigned char)
					    * img->width * img->height);
  if (img->image_data == NULL)
  {
    free(img);
    return(NULL);
  }

  img->image = 0;
  img->ismap = 0;

  for (i = 0; i < MAXCOLORS; i++)
  {
    hv[i] = -1;
  }

  p = (char *)img->image_data;

  for (i = 0; i < img->height; i++)
  {
    for (j = 0; j < img->width; j++)
    {
      for (k = 0; k < 3; k++)
      {
	if (format == '3')
	{
	  while (isspace(*t))
	  {
	    t++;
	  }
	  
	  for (n = num; isdigit(*t); t++, n++)
	  {
	    *n = *t;
	  }
	  *n = '\0';
	  c[k] = atoi(num);
	}
	else
	{
	  c[k] = (unsigned char)*t;
	  t++;
	}
      }

      /*
       * Lame hash.  Don't know if it is faster than a linear search.
       * Seems like it would be.
       */
      for (l = (c[0] + c[1] + c[2]) % MAXCOLORS, m = 0;
	   m < MAXCOLORS;
	   m++, l = (l + 1) % MAXCOLORS)
      {
	v = hv[l];
	if (v == -1)
	{
	  hv[l] = colorcount;
	  r[colorcount] = c[0];
	  g[colorcount] = c[1];
	  b[colorcount] = c[2];
	  *p = colorcount++;
	  p++;
	  break;
	}
	else if (c[0] == r[v] && c[1] == g[v] && c[2] == b[v])
	{
	  *p = v;
	  p++;
	  break;
	}
      }

      if (m == MAXCOLORS)
      {
	*p = 0;
	p++;
      }
    }
  }

  img->reds = (int *)malloc(sizeof(int) * colorcount);
  img->greens = (int *)malloc(sizeof(int) * colorcount);
  img->blues = (int *)malloc(sizeof(int) * colorcount);
  img->num_colors = colorcount;

  for (i = 0; i < colorcount; i++)
  {
    img->reds[i] = (r[i] * 65535) / maxcolorval;
    img->blues[i] = (b[i] * 65535) / maxcolorval;
    img->greens[i] = (g[i] * 65535) / maxcolorval;
  }

  return(img);
}

/*
 * PGM2Image
 *
 *
 */
static ImageInfo *
PGM2ImageInfo(t, format)
char *t;
char format;
{
  ImageInfo *img;
  unsigned char *p;
  char *n;
  char buffer[256];
  char num[11];
  int g[MAXCOLORS];
  int hv[MAXCOLORS];
  int c;
  int colorcount = 0;
  int i, j, l, m, v;
  int maxcolorval;

  img = (ImageInfo *)malloc(sizeof(ImageInfo));
  if (img == NULL)
  {
    return(NULL);
  }

  /* get dimension data */
  while ((t = get_line(t, buffer, sizeof(buffer))) != NULL)
  {
    if (buffer[0] != '#')
    {
      break;
    }
  }
  sscanf(buffer, "%d %d", &(img->width), &(img->height));

  /* get max color value */
  while ((t = get_line(t, buffer, sizeof(buffer))) != NULL)
  {
    if (buffer[0] != '#')
    {
      break;
    }
  }
  sscanf(buffer, "%d", &maxcolorval);

  img->image_data = (unsigned char *)malloc(sizeof(unsigned char)
					    * img->width * img->height);
  if (img->image_data == NULL)
  {
    free(img);
    return(NULL);
  }

  img->image = 0;
  img->ismap = 0;

  for (i = 0; i < MAXCOLORS; i++)
  {
    hv[i] = -1;
  }

  p = img->image_data;

  for (i = 0; i < img->height; i++)
  {
    for (j = 0; j < img->width; j++)
    {
      if (format == '2')
      {
	while (isspace(*t))
	{
	  t++;
	}
	
	n = num;
	for (; isdigit(*t); t++, n++)
	{
	  *n = *t;
	}
	*n = '\0';
	c = atoi(num);
      }
      else
      {
	c = (unsigned char)*t;
	t++;
      }

      for (l = c % MAXCOLORS, m = 0;
	   m < MAXCOLORS;
	   m++, l = (l + 1) % MAXCOLORS)
      {
	v = hv[l];
	if (v == -1)
	{
	  hv[l] = colorcount;
	  g[colorcount] = c;
	  *p = colorcount++;
	  p++;
	  break;
	}
	else if (c == g[v])
	{
	  *p = v;
	  p++;
	  break;
	}
      }

      if (m == MAXCOLORS)
      {
	*p = 0;
	p++;
      }
    }
  }

  img->reds = (int *)malloc(sizeof(int) * colorcount);
  img->greens = (int *)malloc(sizeof(int) * colorcount);
  img->blues = (int *)malloc(sizeof(int) * colorcount);
  img->num_colors = colorcount;

  for (i = 0; i < colorcount; i++)
  {
    img->reds[i] = (g[i]  * 65535) / maxcolorval;
    img->blues[i] = (g[i]  * 65535) / maxcolorval;
    img->greens[i] = (g[i]  * 65535) / maxcolorval;
  }

  return(img);
}

/*
 * PBM2Image
 *
 *
 */
static ImageInfo *
PBM2ImageInfo(t, format)
char *t;
char format;
{
  ImageInfo *img;
  int i, j, bit;
  int len;
  unsigned char *p;
  char buffer[256];

  img = (ImageInfo *)malloc(sizeof(ImageInfo));
  if (img == NULL)
  {
    return(NULL);
  }

  while ((t = get_line(t, buffer, sizeof(buffer))) != NULL)
  {
    if (buffer[0] != '#')
    {
      break;
    }
  }
  sscanf(buffer, "%d %d", &(img->width), &(img->height));

  img->image_data = (unsigned char *)malloc(sizeof(unsigned char) *
					    img->width * img->height);
  if (img->image_data == NULL)
  {
    free(img);
    return(NULL);
  }

  img->image = 0;
  img->ismap = 0;
  img->reds = (int *)malloc(sizeof(int) * 2);
  img->greens = (int *)malloc(sizeof(int) * 2);
  img->blues = (int *)malloc(sizeof(int) * 2);
  img->num_colors = 2;

  img->reds[1] = 0;
  img->reds[0] = 65535;
  img->greens[1] = 0;
  img->greens[0] = 65535;
  img->blues[1] = 0;
  img->blues[0] = 65535;

  p = img->image_data;
  if (format == '4')
  {
    --t;
    for (i = 0; i < img->height; i++)
    {
      for (j = 0, bit = -1; j < img->width; j++, p++)
      {
	if (bit == -1)
	{
	  t++;
	  bit = 7;
	}
	*p = ((unsigned char)*t >> bit) & 1;
	--bit;
      }
    }
  }
  else if (format == '1')
  {
    while ((t = get_line(t, buffer, sizeof(buffer))) != NULL)
    {
      len = strlen(buffer);
      for (i = 0; i < len; i++)
      {
	if (buffer[i] == '0' || buffer[i] == '1')
	{
	  *p = buffer[i] - '0';
	  p++;
	}
      }
    }
  }

  return(img);
}

/*
 * MakeImageInfo
 *
 * Creates an ImageInfo structure from a PBM.
 */
ImageInfo *
MakeImageInfo(d)
Document *d;
{
  ImageInfo *img = NULL;
  char *t;
  char buffer[256];

  t = get_line(d->otext, buffer, sizeof(buffer));

  if (buffer[1] == '4' || buffer[1] == '1')
  {
    img = PBM2ImageInfo(t, buffer[1]);
  }
  else if (buffer[1] == '3' || buffer[1] == '6')
  {
    img = PPM2ImageInfo(t, buffer[1]);
  }
  else if (buffer[1] == '2' || buffer[1] == '5')
  {
    img = PGM2ImageInfo(t, buffer[1]);
  }

  if (img != NULL)
  {
    img->image = 0;
  }

  return(img);
}

