/* @(#) $Header: timer.h,v 1.2 90/12/12 00:52:56 sob Exp $ */

struct timer {
	void (*subr)();		/* routine to invoke at timeout */
	int resetoninput;	/* if true, reset timer on input */
	long seconds;		/* seconds until a timeout */
	long left;		/* seconds left until next timeout */
};

void timer_init();
int timer_sleep();
