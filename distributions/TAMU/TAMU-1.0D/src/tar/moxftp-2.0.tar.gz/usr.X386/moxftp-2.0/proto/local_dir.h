static char * getgroup P_((int));
static char * getowner P_((int));
static void ls P_(());
static int set_unix_mode P_((int, char*));
