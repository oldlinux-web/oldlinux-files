static void finish_get P_((struct _output*, int, DATA));
static void finish_view P_((struct _output*, DATA, CB*));
static void percent P_((caddr_t, XtIntervalId*));
static void status P_((char*, int));
