/*
** SCCS_data:   @(#) patchlevel.h 1.7 92/11/16 08:12:08
*/
#define Wcl_MajorRelease 2
#define Wcl_MinorRelease 4
