#!/bin/sh
tput clear
tput rmacs
tput rmm
tput rmso
tput rmul
tput rs1
tput rs2
tput rs3
