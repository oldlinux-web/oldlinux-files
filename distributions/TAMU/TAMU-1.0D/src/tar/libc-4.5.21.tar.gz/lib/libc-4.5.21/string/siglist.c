#include <gnu-stabs.h>

#undef  sys_siglist

symbol_alias (_sys_siglist, sys_siglist);
