
void lose_ctty(void);
void terminal_save(int);
void terminal_raw(int);
void terminal_restore(int);
