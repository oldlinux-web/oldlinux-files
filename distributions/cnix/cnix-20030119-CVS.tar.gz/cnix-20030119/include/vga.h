#ifndef VGA_H
#define VGA_H

void vga_init(void);

#endif
