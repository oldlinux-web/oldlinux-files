#ifndef CONST_H
#define CONST_H

#define PAGE_SIZE	4096
#define PAGE_SHIFT	12

#define NR_TASKS	64

#ifndef NULL
#define NULL (void *)0
#endif

#endif
