#include <stdio.h>

int main(int argc, char * argv[])
{
	int fd;

	if(argc != 2){
		printf("%s file\n", argv[0]);
		exit(0);
	}

	fd = open(argv[1], RDONLY);
	if(fd < 0){
		fd = open(argv[1], CREATE);
		if(fd < 0){
			printf("Please try again later\n");

			exit(0);
		}
	}

	close(fd);

	exit(0);
}
