#ifndef STDIO_H
#define STDIO_H

#define printf MP

extern int MP(const char *, ...);
extern unsigned char getchar(void);
extern int open(char *, int);
extern int read(int, char *, int);
extern int seek(int, int, int);
extern int close(int);
extern int fork(void);
extern int execve(char *, char **, char **);
extern int wait(int *);
extern int exit(int);
extern int unlink(char *);

#define NULL	((char *)0)

#define RDONLY	1
#define WRONLY	2
#define RDWR	(RDONLY | WRONLY)
#define CREATE	4

#define SEEK_SET	0
#define SEEK_CUR	1
#define SEEK_END	2

#endif
