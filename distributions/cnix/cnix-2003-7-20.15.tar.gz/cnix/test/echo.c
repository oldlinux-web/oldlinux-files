#include <stdio.h>

int main(int argc, char * argv[])
{
	if(argc != 2){
		printf("%s string\n", argv[0]);
		exit(0);
	}

	printf("%s\n", argv[1]);

	exit(0);

	return  0;
}
