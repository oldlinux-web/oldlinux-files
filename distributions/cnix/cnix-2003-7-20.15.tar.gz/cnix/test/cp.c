#include <stdio.h>

int main(int argc, char ** argv)
{
	int fd_in, fd_out, readbytes;
	char buffer[1024];

	if(argc != 3){
		printf("%s srcfile dstfile\n", argv[0]);
		exit(0);
	}

	fd_in = open(argv[1], RDONLY);
	fd_out = open(argv[2], CREATE);

	while((readbytes = read(fd_in, buffer, 1024)) > 0)
		write(fd_out, buffer, readbytes);
	
	close(fd_in);
	close(fd_out);

	exit(0);
}
