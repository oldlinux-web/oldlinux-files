#include <stdio.h>

int main(int argc, char * argv[])
{
	int fd, readbytes, i;
	char buffer[1024];

	if(argc != 2){
		printf("%s file\n", argv[0]);
		exit(0);
	}
	
	fd = open(argv[1], 0);
	if(fd < 0){
		printf("open file error!\n");
		exit(0);
	}

	while((readbytes = read(fd, buffer, 1024)) > 0){
		for(i = 0; i < readbytes; i++)
			printf("%c", buffer[i]);
	}
	close(fd);

	exit(0);

	return 0;
}
