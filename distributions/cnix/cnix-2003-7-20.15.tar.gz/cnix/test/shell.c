#include <stdio.h>

char arg_buff[1024], * arg_ptr[1024];
int arg_num, arg_index;

char * mystrtok(char *, char *);
int mystrcmp(char *, char *);
void do_cat(char *);
void do_reboot(void);
void do_execve(char *, char *, char *);

int main(int argc, char * argv[])
{
	int i;
	unsigned char c;
	unsigned char buff[1024];
	char * arg0, * arg1, * arg2;
	
	for(;;){
		printf("[xiexiecn@cnix /]#");
		
		i = 0;
		c = getchar();
		while(c != '\n' && i < 1024){
			if(c == 0x7f){
				if(i > 0){
					printf("\b");
					i--;
				}
			}else{
				printf("%c", c);
				buff[i++] = c;
			}

			c = getchar();
		}

		buff[i] = '\0';
		printf("\n");

		/* to explain > | */
		if(i != 0 && c == '\n'){
			arg0 = mystrtok(buff, " \n\t");
			arg1 = mystrtok(NULL, " \n\t");
			arg2 = mystrtok(NULL, " \n\t");

			if(arg0){
				if(!mystrcmp(arg0, "exit"))
					exit(0);
				do_execve(arg0, arg1, arg2);
			}else
				printf("\n");
		}
	}

	return 0;
}

char * mystrtok(char * string, char * delim)
{
	int i, j;

	if(string != NULL){
		for(i = 0; i < 1024; i++){
			arg_buff[i] = string[i];
			if(string[i] == '\0')
				break;
		}

		arg_num = 0;
		arg_index = 0;
		arg_ptr[arg_num++] = &arg_buff[0];
		for(i = 0; i < 1024; i++){
			if(arg_buff[i] == '\0')
				break;

			for(j = 0; delim[j]; j++){
				if(arg_buff[i] == delim[j]){
					arg_buff[i] = '\0';
					arg_ptr[arg_num++] = &arg_buff[i + 1];
					break;
				}
			}
		}

		return arg_ptr[arg_index++];
	}else{
		if(arg_index < arg_num)
			return arg_ptr[arg_index++];
		else	
			return NULL;
	}
}

int mystrcmp(char * s1, char * s2)
{
	int i, ret;
	
	ret = 0;
	for(i = 0; s1[i] != '\0' && s2[i] != '\0'; i++)
		if(s1[i] != s2[i]){
			ret = s1[i] > s2[i] ? 1 : -1;
			break;
		}
	if(s1[i] != '\0')
		ret = 1;
	else if(s2[i] != '\0')
		ret = -1;
	
	return ret;
}

void do_execve(char * filename, char * arg1, char * arg2)
{
	int pid, status, ret;
	char * argvptr[4];

	argvptr[0] = filename;
	argvptr[1] = arg1;
	argvptr[2] = arg2;
	argvptr[3] = NULL;
	if(!(pid = fork())){		
		execve(filename, argvptr, (char **)NULL);

		printf("Command not found!\n");

		exit(0);
	}
	
	wait(&status);
}
