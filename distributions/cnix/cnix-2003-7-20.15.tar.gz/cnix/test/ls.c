#include <stdio.h>
#include <dirent.h>

int main(void)
{
	int fd;
	struct dirent dir;

	fd = open("/", RDONLY);
	while(read(fd, (char *)&dir, 1)){
		printf("%s\n", dir.d_name);
	}

	exit(0);

	return 0;
}
