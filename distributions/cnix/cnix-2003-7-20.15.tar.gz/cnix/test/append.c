#include <stdio.h>
#include <string.h>

int main(int argc, char * argv[])
{
	int fd;

	if(argc != 3){
		printf("%s file\n", argv[0]);
		exit(0);
	}

	fd = open(argv[1], RDWR);
	if(fd < 0){
		printf("%s not exist\n", argv[1]);
		exit(0);
	}
	
	seek(fd, 0, SEEK_END);
	write(fd, argv[2], strlen(argv[2]));
	write(fd, "\n", 1);
	
	close(fd);

	exit(0);
}
