#ifndef TYPES_H
#define TYPES_H

#define NULL	((void *)0)

typedef void	(*fn_t)(void);

#endif
