#ifndef SUPER_H
#define SUPER_H

#define DEFAULT_PART	0

#define BOOTBLOCK	0
#define BBSIZE		1
#define RESERVED	(BOOTBLOCK + BBSIZE)
#define RVSIZE		2	
#define SUPERBLOCK	(RESERVED + RVSIZE)
#define SBSIZE		1
#define ROOTBLOCK	(SUPERBLOCK + SBSIZE)
#define RBSIZE		1
#define BITBLOCK	(ROOTBLOCK + RBSIZE)
#define BITSIZE		1
#define INODEBLOCK	(BITBLOCK + BITSIZE)
#define IBSIZE		2	
#define DATABLOCK	(INODEBLOCK + IBSIZE)

struct superblock{
	char version[32];
	int di_used;
	int low_fb, high_fb;
};

#endif
