#ifndef DIRENT_H
#define DIRENT_H

/* in simple.c */
#define NAME_MAX	28

/* ... typedef */
struct dirent{
	int	d_ino;
	int	d_off;
	int	d_reclen;
	char	d_name[NAME_MAX + 1];
};

#endif
