#ifndef TIME_H
#define TIME_H

struct m_state{
	unsigned int prev;
	unsigned int now;
};

#endif
