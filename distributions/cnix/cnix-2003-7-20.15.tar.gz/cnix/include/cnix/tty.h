#ifndef TTY_H
#define TTY_H

#include <cnix/vga.h>
#include <cnix/wait.h>

#define TTY_NUM	6

#define SIZE 64 /*  the power of 2 ,so mod is replaced by head &(SIZE - 1) */

struct tty_queue{
	  long head;
	  long tail;
	  char buf[SIZE];
};

struct tty_struct{
	struct tty_queue tq;
	struct vga_struct * vp;
	struct wait_queue * wait;
};

#endif
