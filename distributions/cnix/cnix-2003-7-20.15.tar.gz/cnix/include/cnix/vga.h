#ifndef VGA_H
#define VGA_H

#include <cnix/tty.h>

#define VGA_NUM	2

struct vga_struct{
	struct tty_struct * tp;
	int cur_row, cur_col;
	unsigned long start, limit, org, cur_pos;
};

#endif
