#ifndef MM_H
#define MM_H

#include <const.h>
#include <cnix/head.h>
#include <cnix/page.h>

extern int KP_DIR_SIZE;
extern unsigned long start_mem;
extern unsigned long end_mem;
extern mem_map_t *mem_map;

extern unsigned long get_one_page(void);
extern unsigned long get_free_pages(unsigned long, int);
extern void free_one_page(unsigned long);
extern int copy_page_tables(unsigned long, unsigned long, int);
extern int free_page_tables(unsigned long, int, int);
extern void __free_pages(unsigned long, int);

#endif
