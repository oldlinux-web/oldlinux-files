#ifndef WAIT_H
#define WAIT_H

struct wait_queue{
	struct task_struct *task;
	struct wait_queue *next;
};

#endif
