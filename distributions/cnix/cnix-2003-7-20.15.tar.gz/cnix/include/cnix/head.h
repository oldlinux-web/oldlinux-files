#ifndef HEAD_H
#define HEAD_H

typedef struct desc_struct{
	unsigned long a, b;
}desc_table[256];

extern unsigned long kp_dir[];
extern desc_table gdt, idt;

extern unsigned long end;
extern unsigned long edata;
extern unsigned long etext;

#endif
