#define printf MP

int strcmp(char * s1, char * s2)
{
	int i, ret;
	
	ret = 0;
	for(i = 0; s1[i] != '\0' && s2[i] != '\0'; i++)
		if(s1[i] != s2[i]){
			ret = s1[i] > s2[i] ? 1 : -1;
			break;
		}
	if(s1[i] != '\0')
		ret = 1;
	else if(s2[i] != '\0')
		ret = -1;
	
	return ret;
}

void main(void)
{
	int i;
	unsigned char c;
	unsigned char buff[20];
	
	for(;;){
		printf("\ncnix>");
		
		i = 0;
		c = getchar();
		while(c != '\n' && i < 20){
			printf("%c", c);
			buff[i++] = c;
			c = getchar();
		}

		buff[i] = '\0';
		printf("\n");
		if(i != 0 && c == '\n'){
			if(!strcmp(buff, "help")){
				printf("cnix\n");
				/*printf("reboot\n");*/
			}else if(!strcmp(buff, "cnix"))
				printf("Welcome!");
			/*else if(!strcmp(buff, "reboot"))
				reboot();*/
			continue;
		}

		printf("%s", buff);
	}
}
