#ifndef CONST_H
#define CONST_H

#define  PAGE_SHIFT 12
#define  PAGE_SIZE  (1UL<<PAGE_SHIFT)

#define NR_TASKS	64

#endif
