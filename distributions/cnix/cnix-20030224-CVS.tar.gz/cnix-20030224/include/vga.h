#ifndef VGA_H
#define VGA_H

extern void vga_init(void);
extern void puts(char *s);

#endif
