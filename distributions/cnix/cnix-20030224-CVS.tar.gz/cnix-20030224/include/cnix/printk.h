#ifndef __PRINTK_H__
#define __PRINTK_H__

extern int printk(const char * fmt, ...);
extern int panic(const char * fmt, ...);

#endif
