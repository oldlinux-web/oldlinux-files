#ifndef TIME_H
#define TIME_H

struct m_state{
	unsigned int prev;
	unsigned int now;
};

extern void m_start(struct m_state * ms);
extern unsigned int m_elapsed(struct m_state * ms);
extern void m_delay(unsigned int msec);
#endif
