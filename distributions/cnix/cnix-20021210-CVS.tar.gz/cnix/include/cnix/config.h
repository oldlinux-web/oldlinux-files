#ifndef CONFIG_H
#define CONFIG_H

#define HIGH_MEM	0x4000000
#define LOW_MEM		0x100000
#define DMA_HIGH_MEM	0x1000000

#endif
