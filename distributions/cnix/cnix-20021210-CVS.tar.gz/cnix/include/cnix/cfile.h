#ifndef __CFILE_H__
#define __CFILE_H__
struct cfile{
	int size;
	unsigned char *file_buf;

};



#endif /*__CFILE_H__*/
