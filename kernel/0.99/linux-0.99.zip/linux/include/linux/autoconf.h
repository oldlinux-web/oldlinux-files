/*
 * Automatically generated C config: don't edit
 */

/*
 * General setup
 */
#define CONFIG_BLK_DEV_HD 1
#define CONFIG_TCPIP 1
#define CONFIG_PROFILE 1
#define CONFIG_MAX_16M 1

/*
 * SCSI support
 */

/*
 * SCSI support type (disk, tape, CDrom)
 */

/*
 * SCSI low-level drivers
 */

/*
 * Filesystems
 */
#define CONFIG_MINIX_FS 1
#define CONFIG_PROC_FS 1

/*
 * Various character device drivers..
 */
