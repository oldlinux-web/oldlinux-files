#include <linux/fs.h>

struct file file_table[NR_FILE];
