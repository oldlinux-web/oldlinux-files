/*---------------------------------------------------------------------------+
 |  version.h                                                                |
 |                                                                           |
 |                                                                           |
 | Copyright (C) 1992,1993                                                   |
 |                       W. Metzenthen, 22 Parker St, Ormond, Vic 3163,      |
 |                       Australia.  E-mail apm233m@vaxc.cc.monash.edu.au    |
 |                                                                           |
 |                                                                           |
 +---------------------------------------------------------------------------*/

#define FPU_VERSION "wm-FPU-emu version BETA 1.6"

