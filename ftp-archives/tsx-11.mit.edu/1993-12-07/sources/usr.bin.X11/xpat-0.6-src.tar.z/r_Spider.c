/*****************************************************************************/
/*									     */
/*									     */
/*	X patience - r_Spider.c						     */
/*									     */
/*	written by Heiko Eissfeldt and Michael Bischoff			     */
/*									     */
/*	24-Feb-1993: First release (0.1)				     */
/*									     */
/*									     */
/*****************************************************************************/
#include "gpat.h"

/************************************************************************/
/*									*/
/*	Spider routines:						*/
/*									*/
/************************************************************************/

static int Spider_new_cards(void)
{   int i;
    if (!CARDS_ON_PILE(IDECK))
	return 0;	/* no more cards */
    for (i = FIRST_SLOT; i <= LAST_SLOT; ++i)
	if (EMPTY(i))
	    return 0;
    return 1;
}

static int Spider_stackable(int src)	/* src is index of a slot */
{   int srcindex;
    if (EMPTY(src))
	return -1;
    srcindex = select_max(src, 0);
    if (srcindex + rules.cards_per_color == INDEX_OF_LAST_CARD(src) + 1) {
	int i;			/* must check, if jokers inside */
	for (i = INDEX_OF_LAST_CARD(src); i >= srcindex; --i)
	    if (IS_JOKER(game.cards[i]))
		return -1;
	return srcindex;	/* only full stack movable */
    }
    return -1;
}

static int Spider_alternate(int h, int l)
{   if (IS_JOKER(h) || IS_JOKER(l))
	return 1;
    return RANK(h) == 1 + RANK(l) && SUIT(h) == SUIT(l);
}

static int Spider_relaxed_alternate(int h, int l)
{   if (IS_JOKER(h) || IS_JOKER(l))
	return 1;
    return RANK(h) == 1 + RANK(l);
}


static int Spider_good_hint(int srcindex, int dstpile)
{
   if (IS_STACK(dstpile))   /* strongly encourage dropping the whole suit */
       return 10000;
   if (SUIT(game.cards[srcindex]) == SUIT(game.cards[INDEX_OF_LAST_CARD(dstpile)]))
       return 30;
   if (game.ind[getpile(srcindex)] != srcindex && 
       game.visible[srcindex-1] &&
       RANK(game.cards[srcindex]) == RANK(game.cards[srcindex-1]) - 1)
       return 1; /* hint doesn't make anything better */
   else
       return 15 + RANK(game.cards[srcindex]);	/* upper ones first */
}


struct rules Spider_rules = {
    "Spider", "Spider",
    NULL,       /* description of this game variant */
    0, /* (EXACT_MATCH << MOVE_SHIFT) | (ALL_VALID << PLACE_SHIFT), */
    104,	/* two full decks of 52 cards */
    8,		/* eight stacks */
    10,		/* eight slots */
    0,		/* no Tmps */
    2,		/* two decks */
    13,		/* thirteen ranks, no jokers */
    0,		/* jokers */
    0, 0,	/* no flips, no turns */
    NULL,
    Spider_relaxed_alternate,
    Spider_alternate,
    Spider_new_cards,
    Spider_stackable,
    Spider_good_hint,
    4, 1,
    NULL, 0,	/* score */
    generic_automove,
    NULL,
    generic_minwindow
};
