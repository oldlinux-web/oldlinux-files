/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/************
** B--DASH **
****************************************************************
	   ** (C) Copyright 1992,1993 by:         ------      **
           **                                     \    /      **
           **                                      \  /       **
           **                                       \/        **
           ** N-A-B-L-A->Productions, K. Ballue�der           **
           *****************************************************
           ** email: kballued@jupiter.rz.uni-osnabrueck.de    **
           *****************************************************

           All rights reserved, see BDASH.DOC for details.

***********************************************************************

bdash.h:  Allgemeine Definitionen

*****************************************************end of header*****/

#ifdef __unix__
#	define OS_UNIX
#endif
#ifdef __linux__
#	define OS_LINUX
#	define CC_GNUC
#endif
#ifdef __TURBOC__
#	define OS_DOS
#	define CC_TURBOC
#endif
#ifdef OS_DOS
#	define BDASH_OS	"Dos"
#	include <alloc.h>  /* fuer k_alloc() */
#	define MAX_SPEED	(75L)
#	define DEFAULT_SPEED	(68L)
#	define BASE_SPEED	(0L)
#endif
#ifdef OS_UNIX
#	define MAX_SPEED	(5000L)
#	define DEFAULT_SPEED	(3000L)
#	define BASE_SPEED	(3000L)
#	define getch()	getchar()
#endif
#ifdef OS_LINUX
#	define BDASH_OS "Linux"
#endif

#define BDASH_RELEASE "0.21b"
#define BDASH_VERSION BDASH_RELEASE " for " BDASH_OS

#define FILELEVEL 	"bdash%03u.lvl"
#define FILECOLOR 	"bdashcol.cmp"
#define FILECOLORBW     "bdash_sw.cmp"
#define FILESCORE	"bdash.hsc"
#define FILEDATA	"bdash.dta"
#ifdef OS_DOS
#	define FILECONFIG	"bdash.cfg"
#	define BGIPATH		"c:\\anw\\tc\\bgi"
#endif
#ifdef OS_UNIX
#	define FILECONFIG	".bdash"
#endif
/* BGIPATH can be overwritten by environment variable BGI
 * just type:  SET BGI=new_path
 */

#define NUM_OF_FIGURS 41
        /* Anzahl der definierten Bildelemente */
enum{	FELD_LEER,
	FELD_SPIELER_1,
	FELD_SPIELER_2,
	FELD_ERDE,
	FELD_DIAMANT_1,
	FELD_DIAMANT_2,
	FELD_DIAMANT_3,
	FELD_DIAMANT_4,
	FELD_STEIN,
	FELD_STEIN_2,
	FELD_BOMBE,
	FELD_BOMBE_2,
	FELD_EXPLODE,
	FELD_MAUER,
	FELD_KAEFER_1,
	FELD_KAEFER_1a,
	FELD_KAEFER_1b,
	FELD_KAEFER_1c,
	FELD_KAEFER_2,
	FELD_KAEFER_2a,
	FELD_KAEFER_2b,
	FELD_KAEFER_2c,
	FELD_KAEFER_3,
	FELD_KAEFER_3a,
	FELD_KAEFER_3b,
	FELD_KAEFER_3c,
	FELD_KAEFER_4,
	FELD_KAEFER_4a,
	FELD_KAEFER_5,
	FELD_KAEFER_5a,
	FELD_KEY_1,
	FELD_KEY_2,
	FELD_KEY_3,
	FELD_KEY_4,
	FELD_TOR_1,
	FELD_TOR_2,
	FELD_TOR_3,
	FELD_TOR_4,
	FELD_CHEESE_1,
	FELD_CHEESE_2,
	FELD_SCROLL
};


#define CAN_FALL(object) (((object) >FELD_ERDE && (object) < FELD_EXPLODE)||((object)==FELD_CHEESE_2))
#ifdef __TURBOC__
int bioskey(int);

#define CLEAR_KEY_BUF while(bioskey(1)) bioskey(0);
#else
#	define CLEAR_KEY_BUF
#endif
extern unsigned char **level_table;
extern void *figur[NUM_OF_FIGURS];


extern
struct flagstype { int monochrome;
		   int twoplayer;
		   int slavemode;
		   int comport;
		   int soundport;
		   char *snd_dev;
		   int son_pid;
   		   int dead;
                 }
                 globale_flags;

extern void fatal_error(char *err);

extern long bdash_speed;
extern unsigned char player_x[2], player_y[2];
extern unsigned level_x_size, level_y_size;
extern char level_name[21];
extern unsigned act_level;
extern unsigned long points_required;
extern unsigned char keys[2][4];

  struct memlist_node
  { void *address;
    struct memlist_node *next;
  };

#define __malloc(size) malloc(size)

#ifdef K_ALLOC
  extern struct memlist_node *mem_first_block;

  extern void *k_alloc(size_t n, size_t size);

  #define malloc(size) k_alloc(1,size)
  #define calloc(n,size) k_alloc(n,size)
#endif

