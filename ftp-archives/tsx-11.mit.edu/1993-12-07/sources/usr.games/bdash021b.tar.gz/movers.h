/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/******
      MOVERS.C : moving animals

******/
/*
 * available objects:
 */
enum {STD_BEETLE,STRAIGHT_BEETLE,RANDOM_BEETLE,UPDOWN_BEETLE,LR_BEETLE,CHEESE1,CHEESE2};

struct objects_node
{ unsigned x,y;       /* coordinates */
  unsigned type;      /* type of object */
  unsigned direction; /* 0: north, 1:east... */
  struct
  objects_node *next; /* pointer to next object */
};

/*** activate object at x,y ***/
extern void add_object(unsigned x, unsigned y, unsigned type, unsigned dir);

/*** remove object at x,y ***/
extern void kill_object(unsigned x, unsigned y);

/*** move all objects */
extern void move_objects(void);

extern void kill_all_objects(void);