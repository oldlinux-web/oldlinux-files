/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/*****

      GAME.C: Routinen zur Punkteverwaltung etc

*****/
#include "sound.h"
#include "bdash.h"

#ifdef OS_DOS
#	include <conio.h>
#else
#	include <stdio.h>
#endif

static int lives = 4;

void tod(void)  /* Tod von Spieler 1! */
{
	soundeffect(SND_TOD);
	getch();
	if(-- lives == 0)	/* still one life remaining */
		globale_flags.dead = 1;
}
