/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/*
 * Graphic.h : Definition der Grafikfunktionen zu Boulder-Dash
 *
 */


void display(int dx, int dy); /* das Spielfeld (mit Offset) darstellen */

void scroll_up(int py); /* Spielfeld um eine Zeile hochscrollen */

void scroll_down(int py); /* Spielfeld um eine Zeile herunterrollen */

void scroll_left(int px); /* Spielfeld um eine Spalte nach links scrollen */

void scroll_right(int px); /* Spielfeld um eine Spalte nach rechts scrollen */

void draw_image(int x, int y, unsigned char object); /* Feld malen */

void draw_spieler(int x, int y, int player); /* Die Spielfiguren darstellen, bei x,y */

void draw_leer(int x, int y); /* bei x,y ein leeres Feld darstellen */

void display_message(char *l1, char *l2, char *l3);


/* ein Objekt verschieben */

void move_object(int alt_x, int alt_y, int neu_x, int neu_y, unsigned obj_num);

extern int gr_maxx, gr_maxy;
