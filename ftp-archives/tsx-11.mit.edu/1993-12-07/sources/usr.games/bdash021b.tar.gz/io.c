/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/************
** B--DASH **
****************************************************************
           ** (C) Copyright 1992 by:              ------      **
           **                                     \    /      **
           **                                      \  /       **
           **                                       \/        **
           ** N-A-B-L-A->Productions, K. Ball�der             **
           *****************************************************
           ** email: kballued@charon.physik.uni-osnabrueck.de **
           *****************************************************

           All rights reserved, see BDASH.DOC for details.

***********************************************************************

io.c	: loads graphic data, level definitions and highscores
	  initializes graphics
	  saves highscores

*****************************************************end of header*****/

#include "io.h"


#ifdef __TURBOC__
#	include <graphics.h>
#	include <svga256.h>
#	include <alloc.h>
#else
#	include "vga.h"
	typedef unsigned  char DacPalette256[256][3];
#endif 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bdash.h"
#include "react.h"
#include "movers.h"
#include "scores.h"
#include "graphic.h"


int load_level(unsigned level_no)/* Level laden und in level_table ablegen */
{
	int help;

	FILE *leveldatei;
	int y,x, diamant_count=0,  /* 4 diamonds, 4 doors, 4 keys */
		 door_count = 0,
		 key_count = 0;
	unsigned real_x_size, real_y_size;
	unsigned long pr;
	char dateiname[13];
	char inputbuffer[100];

	sprintf(dateiname,FILELEVEL,level_no);
	if(NULL ==(leveldatei = fopen(dateiname,"rt")))
	{ 	perror("load_level");
		return -1; /* Fehler beim Dateioeffnen */
	}
	fgets(inputbuffer,101,leveldatei); /* 1. Zeile der Datei lesen */
	sscanf(inputbuffer,"%u %u %lu %20s\n", /* Ma�e lesen */\
			&real_y_size, &real_x_size, &pr, level_name);
	points_required += pr;
	level_x_size = real_x_size <  8 ?  8: real_x_size;
	level_y_size = real_y_size < 10 ? 10: real_y_size;

	/* Platz f�r Tabelle von Zeigern auf die Zeilen einrichten */
	if((level_table = calloc(level_y_size,sizeof(char *)))==NULL)
		fatal_error("load_level out of mem");

	for(y=0;y<level_y_size;y++) /* Level zeilenweise einlesen */
	{ 	/* Platz fuer Zeile y allozieren */
		/* calloc(): falls Feld zu klein, mit 0 initialisieren! */
		if((level_table[y] = calloc(level_x_size+1,sizeof(unsigned char)))==NULL)
			fatal_error("load_level out of mem");
		fgets((char *)level_table[y],real_x_size+1,leveldatei);

		for(help=0, x=0;x<level_x_size;x++)
			if(level_table[y][x] == '\n')
				level_table[y][x] = '\0', help = 1;
		if(! help)
			fgets(inputbuffer,101,leveldatei);	/* read \n */

		for(x=0;x<level_x_size;x++) /* Umwandeln in Indices */
		{ 	switch(level_table[y][x])
			{ 	case ' ': 	level_table[y][x] = FELD_LEER;
						break;
				case '1': 	level_table[y][x] = FELD_SPIELER_1;
						player_x[0] = x; player_y[0] = y;
						break;
				case '2': 	level_table[y][x] = (globale_flags.twoplayer)?FELD_SPIELER_2:FELD_ERDE;
						player_x[1] = x; player_y[1] = y;
						break;
				case '.': 	level_table[y][x] = FELD_ERDE;
						break;
				case 'B': 	level_table[y][x] = FELD_BOMBE;
						break;
				case 'S': 	level_table[y][x] = FELD_STEIN;
						break;
				case 'M': 	level_table[y][x] = FELD_MAUER;
						break;
				case 'D': 	level_table[y][x] = (diamant_count+++FELD_DIAMANT_1);
						diamant_count%=4;
						break;
				case '(': 	level_table[y][x] = FELD_KAEFER_2;
						add_object(x,y,STRAIGHT_BEETLE,0);
						break;
				case '%': 	level_table[y][x] = FELD_KAEFER_1;
						add_object(x,y,STD_BEETLE,0);
						break;
				case '&': 	level_table[y][x] = FELD_KAEFER_3;
						add_object(x,y,RANDOM_BEETLE,0);
						break;
				case '$': 	level_table[y][x] = FELD_KAEFER_4;
						add_object(x,y,UPDOWN_BEETLE,0);
						break;
				case '-':	level_table[y][x] = FELD_KAEFER_5;
						add_object(x,y,LR_BEETLE,0);
						break;
				case 'C':	level_table[y][x] = FELD_CHEESE_1;
						add_object(x,y,CHEESE1,0);
						break;
				case 'K': 	level_table[y][x] = (key_count+++FELD_KEY_1);
						key_count%=4;
						break;
				case 'T':	level_table[y][x] = (door_count+++FELD_TOR_1);
						door_count%=4;
						break;
				case '/':	level_table[y][x] = FELD_SCROLL;
						break;
				default: 	level_table[y][x] = FELD_LEER;
			}
		}
	}
	fclose(leveldatei);
	/* Achtung, bei 2 Spieler Modus bei Slave  Figuren vertauschen! */
	if(globale_flags.twoplayer && globale_flags.slavemode)
	{ 	level_table[player_y[0]][player_x[0]] = FELD_SPIELER_2;
		level_table[player_y[1]][player_x[1]] = FELD_SPIELER_1;
		help = player_x[0]; player_x[0] = player_x[1]; player_x[1] = help;
		help = player_y[0]; player_y[0] = player_y[1]; player_y[1] = help;
	}
	for(y=0;y<level_y_size;y++)
	{ 	for(x=0;x<level_x_size;x++)
		switch(level_table[y][x])
		{	case FELD_BOMBE: case FELD_BOMBE_2:
			case FELD_STEIN: case FELD_STEIN_2:
			case FELD_DIAMANT_1:case FELD_DIAMANT_2:
			case FELD_DIAMANT_3:case FELD_DIAMANT_4:
			bearbeite_feld(x,y);
		}
		react();
	}
	for(y = 0; y < 4; y ++)	/* Schluessel auf 0 setzen */
		keys[0][y] = keys[1][y] = (unsigned char)'\0';
	return 0;
#pragma warn -aus
}

void free_level(void)	/* free memory allocated */
{
	int y;

	for(y=0;y<level_y_size;y++) /* Level zeilenweise einlesen */
	{	free(level_table[y]);
		level_table[y] = NULL;
	}

	free(level_table);
}

#ifndef DUMMY_VERSION
#ifdef __TURBOC__
	int huge DetectSVGA(void) {return SVGA320x200x256;}
#endif
int load_graphics(void) /* Laden der Bildchen und der Palette */
                        /* Initialisieren der Grafik */
{
#ifdef __TURBOC__
	int gd = DETECT, gm;
#endif
	FILE *datafile;
	int i,dummy,r,g,b;
	size_t lng;

	extern void *figur[NUM_OF_FIGURS];


	DacPalette256 palette;

#ifdef __TURBOC__
	detectgraph(&gd,&gm);
	if(gd != VGA && gd != IBM8514)
		fatal_error("VGA-Card required");
	gd = DETECT;
	installuserdriver("svga256",DetectSVGA);
	initgraph(&gd,&gm,getenv("BGI")?getenv("BGI"):BGIPATH);
	gr_maxx = getmaxx(), gr_maxy = getmaxy();
#else
	vga_setmode(G320x200x256), vga_clear();
	gr_maxx = vga_getxdim()-1, gr_maxy = vga_getydim()-1;
#endif
	datafile = fopen(globale_flags.monochrome?FILECOLORBW:FILECOLOR,"rt"); /* Palete lesen ColorMaP */
	if(datafile == NULL)
	{	
#ifdef __TURBOC__
		closegraph();
#else
		vga_setmode(TEXT);
#endif
		perror("no graphics palette");
		return -1;
	}

	for(i=0;i<256;i++)
	{ 	fscanf(datafile,"%d %d %d %d",&dummy,&r,&g,&b);
		palette[i][0] = r>>2; palette[i][1] = g>>2; palette[i][2] = b>>2;
	}
	fclose(datafile);
#ifdef __TURBOC__
	setvgapalette(&palette);
#else
	for(i=0;i<256;i++)
		vga_setpalette(i,palette[i][0],palette[i][1],palette[i][2]);
#endif
	datafile = fopen(FILEDATA,"rb");
	if(datafile == NULL)
	{      
#ifdef __TURBOC__
		 closegraph();
#else
		vga_setmode(TEXT);
#endif
		perror("no graphic definitions");
		return -2;
	}

	for(i=0;i<NUM_OF_FIGURS;i++)
	{ 	if(NULL == (figur[i] = malloc((lng = 32*25+6))))
		{ 	perror("load_graphics");
			return -1;
		}
		fread(figur[i],lng,1,datafile);
	}
	fclose(datafile);
	return 0;
}
#else
int load_graphics(void)
{	return 0; }

#endif


int load_scores(void)	/* nomen est omen */
{
	FILE *input;

	if((input = fopen(FILESCORE,"rb")) == NULL)
		return -1;
	if(fread(highscore_table,sizeof(highscore_table),1,input)
		< 1)
		{
			fclose(input);
			return -2;
		}
	fclose(input);
	return 0;
}

int save_scores(void)
{
	FILE *output;

	if((output = fopen(FILESCORE,"wb")) == NULL)
		return -1;
	if(fwrite(highscore_table,sizeof(highscore_table),1,output)
		< 1)
		{	fclose(output);
			return -2;
		}
	fclose(output);
	return 0;
}


void fatal_error(char *err)
{
	fprintf(stderr,"Boulder-Dash: fatal error occured: %s\n\rDOS Error code: %s\n\r",err,strerror(errno));
#ifndef NDEBUG
	abort();
#else
	exit(EXIT_FAILURE);
#endif
}

