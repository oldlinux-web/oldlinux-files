/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/



/******************************************************************************
**                                                                           **
** Boulder-Dash: Hauptprogramm                                               **
**                                                                           **
******************************************************************************/
#include "bdash.h"

#ifdef CC_TURBOC
#	include <graphics.h>
#else
#	include <unistd.h>
#	include "vga.h"
#	include <sys/types.h>
#	include <signal.h>
#	include <fcntl.h>
#endif
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "graphic.h"
#include "react.h"
#include "communic.h"
#include "io.h"
#include "sound.h"
#include "scores.h"
#include "movers.h"



#define COPYRIGHT_MESSAGE \
	"*************\n"\
	"** B--DASH **\n"\
	"****************************************************************\n"\
	"           ** (C) Copyright 1992,1993 by:         ------      **\n"\
	"           **                                     \\    /      **\n"\
	"           **                                      \\  /       **\n"\
	"           **                                       \\/        **\n"\
	"           ** N-A-B-L-A-->Productions                         **\n"\
	"           *****************************************************\n"\
	"           ** email:  kballued@jupiter.rz.uni-osnabrueck.de   **\n"\
	"           *****************************************************\n"\
	"\nCurrent Release: "BDASH_VERSION"     Date: "__DATE__"     Time: "__TIME__"\n"

#ifdef OS_DOS
#	define HELPTEXT \
	"\tAvailable options:\n"\
	"-lxxx : level xxx           -m  : monochrome\n"\
	"-2    : two player option   -s  : set speed (0-%ld, default: %ld)\n"\
	"-cx   : use COMx            -px : x = s,1,2,q play sounds on speaker or LPTx\n"\
	"                                  x = q quiet mode, no sounds at all\n"
#endif
#ifdef OS_LINUX
#	define HELPTEXT \
	"\tAvailable options:\n"\
	"-lxxx  : level xxx                  -m  : monochrome\n"\
	"-p dev : play sound on device dev   -s  : set speed (0-%ld, default: %ld)\n"\
	"         (/dev/dsp or /dev/pcsp)\n"
#	define OPTS "h?l:ms:p:"
#endif

extern int controlling(void);  /* controlling.c */
#ifdef __TURBOC__
extern int getch(void);
#endif

long bdash_speed = MAX_SPEED-DEFAULT_SPEED;    /* Delay in msecs */
unsigned char player_x[2],player_y[2];
unsigned char **level_table;
unsigned level_x_size, level_y_size;
char level_name[21];
unsigned long points_required = 0ul;

void 		*figur[NUM_OF_FIGURS]; /* Bildchen */

unsigned 	act_level 	= 1;
struct flagstype globale_flags 	= {0,0,0,0x2f8,SPEAKER};

unsigned char 	keys[2][4];	/* Schluessel */


struct memlist_node *mem_first_block = NULL;

void *k_alloc(size_t n, size_t size)
{
  struct memlist_node *mln = __malloc(sizeof(struct memlist_node));
  void *ptr = calloc(n, size);

  if((!mln) || (!ptr))
    return NULL;
  mln->address = ptr;
  mln->next = mem_first_block;
  return ptr;
}

static void _parse_it(char *arg)
{
	if(*arg == '-' || *arg == '/')
	switch(arg[1])
	{ 	case 'l': case 'L':
			printf("\tstarting on level %d\n",act_level = atoi(arg+2));
			break;
		case 'm': case 'M':
			globale_flags.monochrome = 1;
			puts("\tmonochrome activated");	break;
		case '2':
			globale_flags.twoplayer = 1;
			puts("\ttwo player mode enabled");break;
		case 'c': case 'C':
			globale_flags.comport = atoi(arg+2)==1?0x3f8:0x2f8;
			if(globale_flags.twoplayer)
				printf("\tusing communication port at %0x\n",
					 globale_flags.comport);
			break;
		case 's': case 'S':
			bdash_speed = atol(arg+2);
			bdash_speed = bdash_speed > MAX_SPEED?0:MAX_SPEED-bdash_speed;
			printf("\tspeed set to %ld\n",bdash_speed);break;
		case 'p': case 'P':
			if(arg[2]=='q' || arg[2] == 'Q')
				globale_flags.soundport = NOSOUND;
			else
			{ 	if(arg[2]=='s' || arg[2]=='S')
					globale_flags.soundport = SPEAKER;
				else
					globale_flags.soundport = (unsigned) (atoi(arg+2)-1);
				printf("\tusing digitized sound via ");
				switch(globale_flags.soundport)
				{ 	case LPT1: printf("LPT1\n");break;
					case LPT2: printf("LPT2\n");break;
					default:   globale_flags.soundport = SPEAKER;
					printf("internal speaker\n");break;
				}
			}
			break;
		case '?': case 'h': case 'H':
			printf(HELPTEXT,MAX_SPEED,DEFAULT_SPEED);
		exit(EXIT_SUCCESS);
			break;
		default:
		printf("\tunknown command switch: %s\a\n", arg);
	}
}
void new_parse(char c, char *optarg)
{
	switch (c)
	{	case 'm':	globale_flags.monochrome = 1;
				puts("\tmonochrome activated");
				break;
		case 'l':	act_level = atoi(optarg);
				printf("\tstarting on level %d\n",act_level);
				break;
		case 's':	bdash_speed = atol(optarg);
				bdash_speed = bdash_speed > MAX_SPEED?0:MAX_SPEED-bdash_speed;
				printf("\tspeed set to %ld\n",bdash_speed);
				break;
		case 'p':	globale_flags.snd_dev = malloc(strlen(optarg)+1);
				if(globale_flags.snd_dev == NULL)
					puts("No mem.\a"), exit(1);
				strcpy(globale_flags.snd_dev,optarg);
				printf("writing sound data to: %s\n", optarg);
				break;
		case '?':
		case 'h':	puts(HELPTEXT);
				exit(EXIT_SUCCESS);
	}
}

static void parse_arg(int argc, char **argv)
{
	FILE 	*configfile;
	const MAXARGS = 11;
	char 	args[MAXARGS][81], *argsv[MAXARGS];
	int 	count = 1;
	char 	c;

	strcpy(args[0],argv[0]);
	argsv[0] = args[0];
	if((configfile = fopen(FILECONFIG,"rt"))!=NULL)
	{ 	puts("parsing configuration file "FILECONFIG"...");
		do
		{	if((! fscanf(configfile,"%80s", args[count]))|| feof(configfile))
				break;
			argsv[count]=args[count];
#ifdef OS_DOS
				_parse_it(args[count]);
#endif
		}while(count++ < MAXARGS);
		fclose(configfile);
#ifdef TEST
#ifdef OS_LINUX
	while ((c = getopt(count, argsv, OPTS)) != EOF)
		new_parse(c, optarg);
#endif
#endif		
	}
	else
		puts("no configuration file "FILECONFIG);
	if(argc > 1)
		puts("parsing command line parameters...");
#ifdef OS_LINUX
	while ((c = getopt(argc, argv, OPTS)) != EOF)
		new_parse(c, optarg);
#else
	for(i=1;i<argc;i++)
	_parse_it(argv[i]);
#endif
}

void cleanup(void)
{
#ifdef OS_LINUX
	/* make sure son is dead */
	if(globale_flags.son_pid)
		kill(globale_flags.son_pid, SIGTERM);
#endif
#ifdef  CC_TURBOC
	closegraph();
#else
	vga_setmode(TEXT);
#endif

#ifdef K_ALLOC
	while(mem_first_block) /* Speicher freigeben */
	{ free(mem_first_block->address);
	  mem_first_block = mem_first_block->next;
	}
#endif

	CLEAR_KEY_BUF
	puts("cleanup complete");
}

void main(int argc, char **argv)
{
	int cont;	/* boolean */


	globale_flags.snd_dev = "/dev/dsp";
	
	puts(COPYRIGHT_MESSAGE);
	#ifdef DUMMY_VERSION
		puts("\n\t\tDUMMY_VERSION  --- no graphics\a!!!");
	#endif

	parse_arg(argc, argv);

	atexit(cleanup);
	puts("\nType BDASH -h for help\n\nPress return key to proceed.");
	getch();

#ifdef 	OS_LINUX 
	close(0);				/* close stdin */
	open("/dev/tty",O_RDONLY|O_NDELAY);	/* reopen stdin */
#endif

	if(globale_flags.twoplayer)
	{ 	InitComm();   /* COM2 initialisieren */
		globale_flags.slavemode = detect_mode(); /* Slavemode? */
	}

	if(globale_flags.soundport != NOSOUND)
		load_sounds();
	if(load_graphics()<0)
		return;

	(void) load_scores();


	/************* MAIN LOOP ***************/
	do
	{       init_react_stack();
		if(load_level(act_level) >= 0)
		{	display(player_x[0],player_y[0]);
			display_message("Next Level:","",level_name);
			act_level += cont = controlling();
			free_level();
			free_react_stack();
			kill_all_objects();
		}
		else
			cont = 0;

	}while(cont);
	/***************************************/

	display_scoretable();
#ifdef  CC_TURBOC
	closegraph();
#else
	vga_setmode(TEXT);
#endif

	if(save_scores())
	      puts("cannot save scores\a");

	/* cleanup() is called via atexit() */
}
