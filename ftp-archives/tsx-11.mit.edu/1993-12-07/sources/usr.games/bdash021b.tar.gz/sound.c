/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/******

  SOUND.c  : Soundroutinen fuer BDASH

******/
#ifdef OS_DOS
#	include <dos.h>
#	include <alloc.h>
#else
#	include <malloc.h>
#endif

#include <stdio.h>
#include "bdash.h"
#include "sound.h"
#include "io.h"

static FILE *stream;

int sounds_ready = 0;   /* Alles klar zum Abspielen? */

struct sound sounds[NUM_OF_SOUNDFX]; 

/*
 * Laden der benoetigten Sounddateien
 */

void load_sounds(void)
{
	int init_snd_dev(void);

#ifdef OS_DOS
	union REGS registers;
	void far *address;
#else
	void *address;
#endif

  	FILE *description, *sndfile;
  	char inputbuffer[256];
  	int i, nread;
	int rate, len;
	
		
	if((description = fopen(SND_DESCR_FILE,"rt"))==NULL)
  	{ 	puts("Sound descriptions not found"); 
  		return;
  	}
  	puts("loading sounds...");
  	for(i=0;i<NUM_OF_SOUNDFX;i++)
  	{ 	if(fscanf(description,"%s %d %d",inputbuffer,&len,&rate) < 3) /* Fehler */
  	    		fatal_error("Unable to load specified sound");  /* Abbruch */
    		if((address = malloc(len))==NULL)
      			fatal_error("Unable to load specified sound");
#ifdef OS_DOS
    		sounds[i].seg = FP_SEG(address); sounds[i].off = FP_OFF(address);
    		sounds[i].len_lsw = len-(sounds[i].len_msw = len>>16);
#else
		sounds[i].bufstart = address;
		sounds[i].len = len;
#endif
		sounds[i].rate = rate;

		if((sndfile=fopen(inputbuffer,"rb"))==NULL)
			fatal_error("Unable to load specified sound");
		nread = fread(address,1,len,sndfile);
		printf("read sound #%d\trate=%d\tlen=%d\tbytes read=%d\n", i,
			sounds[i].rate, sounds[i].len, nread);
		fclose(sndfile);
	}
	fclose(description);
	
	if(init_snd_dev() == 0)	/* cannot initialize snd device */
		return;
		
	sounds_ready = 1;
}

void soundeffect(enum soundfx  nr)
{
	if(! sounds_ready)
		return;
	SND_CALL(nr);
}
