/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/



/************
** B--DASH **
****************************************************************
           ** (C) Copyright 1992 by:              ------      **
           **                                     \    /      **
           **                                      \  /       **
           **                                       \/        **
           ** N-A-B-L-A->Productions, K. Ball�der              **
           *****************************************************
           ** email: kballued@jupiter.rz.uni-osnabrueck.de    **
           *****************************************************

           All rights reserved, see BDASH.DOC for details.

***********************************************************************

movers.c:  Moving and "Living" of all non-static objects/fields

*****************************************************end of header*****/
#include "bdash.h"

#ifdef OS_DOS
#	include <alloc.h>
#	include <bios.h>  /* biostime() */
#endif
#include <stdlib.h>

#include "graphic.h"
#include "movers.h"
#include "react.h"
#include "game.h"

/*
 * all objects which have to be moved are save in a linear list,
 * beginning with  *first_object
 */
struct objects_node *first_object = NULL;

/* add new object to list: */
void add_object(unsigned x, unsigned y, unsigned type, unsigned dir)
{
	  struct objects_node * new_object = malloc(sizeof(struct objects_node));
	  if(! new_object)
		    return; /* malloc failed */
	  new_object->x = x; new_object->y = y;
	  new_object->type = type; new_object->direction = dir;
	  new_object->next = first_object;
	  first_object = new_object;  /* first in list */
}

/* remove object from list: */
void kill_object(unsigned x, unsigned y)
{
  struct objects_node *obj = first_object, *last_obj=NULL;

  while(obj) /* not NULL */
  { if(obj->x == x && obj->y == y)
    { if(last_obj)
        last_obj->next = obj->next;
      else /* obj is first object */
        first_object = obj->next;
      free(obj);
      return;
    }
    last_obj = obj;
    obj = obj->next;
  }
}

void kill_all_objects(void)
{
	struct objects_node *ptr = first_object;

	while(ptr) /* not NULL */
	{ 	first_object = ptr->next;
		free(ptr);
		ptr = first_object;
	}

}


/*
 * available types of movement:
 */
typedef void (move_func_type)(struct objects_node *btl);

static move_func_type
	move_beetle_torque,
	move_beetle_straight,
	move_beetle_random,
	move_beetle_updown,
	move_beetle_lr,
	split_cheese;

static move_func_type *move_functs [] =
{	move_beetle_torque,
	move_beetle_straight,
	move_beetle_random,
	move_beetle_updown,
	move_beetle_lr,
	split_cheese,
};

static int delay_movers(void)
{
#ifdef OS_DOS
	static long lasttime = 0L;	/* time of last movement */
	if(biostime(0,0)-lasttime < bdash_speed)
		return 1;
	lasttime = biostime(0,0);
#else
	static long count = 0L;
	if(count ++ < bdash_speed)
		return 1;
	count = 0L;
#endif
	return 0;
}



/*
 * each time this routine is called, it moves every object one step further
 */
void move_objects(void)
{
	int x,y;

	struct objects_node *obj = first_object;

	if(delay_movers())
		return;

	while(obj) /* not NULL */
	{	x = obj->x, y = obj->y;
		bearbeite_feld(x,y);
		if(x)	bearbeite_feld(x-1,y);
		if(y)	bearbeite_feld(x,y-1);
		if(x < level_x_size-1)	bearbeite_feld(x+1,y);
		if(y < level_y_size-1)	bearbeite_feld(x,y+1);
		(*move_functs[obj->type])(obj);
		obj = obj->next;
	}
}



static void move_beetle_straight(struct objects_node *btl)
{
	int moved = '\0', tested = '\0';

	while(! moved)
	switch(btl->direction)
	{ 	case 0:
		if(btl->x > 0 && level_table[btl->y][btl->x-1] < FELD_ERDE)
/**/		{ 	if(level_table[btl->y][btl->x-1] == FELD_SPIELER_1)
				tod();
			move_object(btl->x,btl->y,btl->x-1,btl->y,FELD_KAEFER_2+3);
			level_table[btl->y][btl->x-1]=FELD_KAEFER_2;
			btl->x--; moved = '\1';
                }
                else
		     btl->direction++;
                break;

		case 1:
		if(btl->y > 0 && level_table[btl->y-1][btl->x] < FELD_ERDE)
		{ 	if(level_table[btl->y-1][btl->x]==FELD_SPIELER_1)
				tod();
			move_object(btl->x,btl->y,btl->x,btl->y-1,FELD_KAEFER_2+0);
			level_table[btl->y-1][btl->x]=FELD_KAEFER_2;
			 btl->y--; moved = '\1';
                }
                else
			 btl->direction++;
                break;
		case 2:
		if(btl->x < level_x_size-1 &&
			level_table[btl->y][btl->x+1] < FELD_ERDE)
		{ 	if(level_table[btl->y][btl->x+1]==FELD_SPIELER_1)
				tod();
			  move_object(btl->x,btl->y,btl->x+1,btl->y,FELD_KAEFER_2+1);
			  level_table[btl->y][btl->x+1]=FELD_KAEFER_2;
			  btl->x++; moved = '\1';
                }
                else
			 btl->direction++;
                break;
		case 3:
		if(btl->y < level_y_size-1 &&
			 level_table[btl->y+1][btl->x] < FELD_ERDE)
/**/		{ 	if(level_table[btl->y+1][btl->x]==FELD_SPIELER_1)
			    tod();
			  move_object(btl->x,btl->y,btl->x,btl->y+1,FELD_KAEFER_2+2);
			  level_table[btl->y+1][btl->x]=FELD_KAEFER_2;
			  btl->y++; moved = '\1';
                }
                else
		{	 btl->direction = 0;
			  moved = tested;      /* falls eingesperrt, nach 2. Durchlauf */
			  tested = '\1';       /* abbrechen */
                }
                break;
      }/* switch & while */
}

static void move_beetle_random(struct objects_node *btl)
{
	int moved = '\0', tested = '\0';

	while(! moved)
	{	btl->direction %= 4;
		switch(btl->direction)
		{ 	case 0:
			if(btl->x > 0 && level_table[btl->y][btl->x-1] < FELD_ERDE)
			{ 	if(level_table[btl->y][btl->x-1] == FELD_SPIELER_1)
					tod();
				move_object(btl->x,btl->y,btl->x-1,btl->y,FELD_KAEFER_3+3);
				level_table[btl->y][btl->x-1]=FELD_KAEFER_3;
				btl->x--; moved = '\1';
			}
			else
				if(rand()%2)
					btl->direction++;
				else
					btl->direction--;

			break;

			case 1:
			if(btl->y > 0 && level_table[btl->y-1][btl->x] < FELD_ERDE)
			{ 	if(level_table[btl->y-1][btl->x]==FELD_SPIELER_1)
					tod();
				move_object(btl->x,btl->y,btl->x,btl->y-1,FELD_KAEFER_3+0);
				level_table[btl->y-1][btl->x]=FELD_KAEFER_3;
				 btl->y--; moved = '\1';
			}
			else
				if(rand()%2)
					btl->direction++;
				else
					btl->direction--;

			break;
			case 2:
			if(btl->x < level_x_size-1 &&
				level_table[btl->y][btl->x+1] < FELD_ERDE)
			{ 	if(level_table[btl->y][btl->x+1]==FELD_SPIELER_1)
					tod();
				  move_object(btl->x,btl->y,btl->x+1,btl->y,FELD_KAEFER_3+1);
				  level_table[btl->y][btl->x+1]=FELD_KAEFER_3;
				  btl->x++; moved = '\1';
			}
			else
				if(rand()%2)
					btl->direction++;
				else
					btl->direction--;

			break;
			case 3:
			if(btl->y < level_y_size-1 &&
				 level_table[btl->y+1][btl->x] < FELD_ERDE)
			{ 	if(level_table[btl->y+1][btl->x]==FELD_SPIELER_1)
				    tod();
				  move_object(btl->x,btl->y,btl->x,btl->y+1,FELD_KAEFER_3+2);
				  level_table[btl->y+1][btl->x]=FELD_KAEFER_3;
				  btl->y++; moved = '\1';
			}
			else
			{	if(rand()%2)
					btl->direction++;
				else
					btl->direction--;
				  moved = tested;      /* falls eingesperrt, nach 2. Durchlauf */
				  tested = '\1';       /* abbrechen */
			}
			break;
		}
      }/* switch & while */
}


static void move_beetle_torque(struct objects_node *btl)
{
	int moved = '\0', tested = '\0';

	while(! moved)
	switch(btl->direction)
	{ 	case 0:
		if(btl->x > 0 && level_table[btl->y][btl->x-1] < FELD_ERDE)
		{ 	if(level_table[btl->y][btl->x-1] == FELD_SPIELER_1)
				tod();
			move_object(btl->x,btl->y,btl->x-1,btl->y,FELD_KAEFER_1+(btl->direction=3));
			level_table[btl->y][btl->x-1]=FELD_KAEFER_1;
			btl->x--; moved = '\1';
                }
                else
		     btl->direction++;
                break;

		case 1:
		if(btl->y > 0 && level_table[btl->y-1][btl->x] < FELD_ERDE)
		{ 	if(level_table[btl->y-1][btl->x]==FELD_SPIELER_1)
				tod();
			move_object(btl->x,btl->y,btl->x,btl->y-1,FELD_KAEFER_1+(btl->direction=0));
			level_table[btl->y-1][btl->x]=FELD_KAEFER_1;
			 btl->y--; moved = '\1';
                }
                else
			 btl->direction++;
                break;
		case 2:
		if(btl->x < level_y_size-1 &&
			level_table[btl->y][btl->x+1] < FELD_ERDE)
		{ 	if(level_table[btl->y][btl->x+1]==FELD_SPIELER_1)
				tod();
			  move_object(btl->x,btl->y,btl->x+1,btl->y,FELD_KAEFER_1+(btl->direction=1));
			  level_table[btl->y][btl->x+1]=FELD_KAEFER_1;
			  btl->x++; moved = '\1';
                }
                else
			 btl->direction++;
                break;
		case 3:
		if(btl->y < level_y_size-1 &&
			 level_table[btl->y+1][btl->x] < FELD_ERDE)
		{ 	if(level_table[btl->y+1][btl->x]==FELD_SPIELER_1)
			    tod();
			  move_object(btl->x,btl->y,btl->x,btl->y+1,FELD_KAEFER_1+(btl->direction=2));
			  level_table[btl->y+1][btl->x]=FELD_KAEFER_1;
			  btl->y++; moved = '\1';
                }
                else
		{	 btl->direction = 0;
			  moved = tested;      /* falls eingesperrt, nach 2. Durchlauf */
			  tested = '\1';       /* abbrechen */
                }
                break;
      }/* switch & while */
}

static void move_beetle_updown(struct objects_node *obj)
{
	int moved = '\0', tested = '\0';

	while(! moved)
	switch(obj->direction)
	{	case 0: /* up */
		if(obj->y > 0 && level_table[obj->y-1][obj->x] < FELD_ERDE)
		{       if(level_table[obj->y-1][obj->x] == FELD_SPIELER_1)
				tod();
			move_object(obj->x,obj->y,obj->x,obj->y-1,FELD_KAEFER_4);
			level_table[--obj->y][obj->x] = FELD_KAEFER_4;
			moved = '\1';
		}
		else
			obj->direction = 1, tested = 1;
		break;

		case 1: /* down */
		if(obj->y < level_y_size && level_table[obj->y+1][obj->x] < FELD_ERDE)
		{	if(level_table[obj->y+1][obj->x] == FELD_SPIELER_1)
				tod();
			move_object(obj->x,obj->y,obj->x,obj->y+1,FELD_KAEFER_4a);
			level_table[++obj->y][obj->x] = FELD_KAEFER_4a;
			moved = '\1';
		}
		else
			obj->direction = 0, moved = tested, tested = 1;
	}
}

static void move_beetle_lr(struct objects_node *obj)
{
	int moved = '\0', tested = '\0';

	while(! moved)
	switch(obj->direction)
	{	case 1: /* left */
		if(obj->x > 0 && level_table[obj->y][obj->x-1] < FELD_ERDE)
		{	if(level_table[obj->y][obj->x-1] == FELD_SPIELER_1)
				tod();
			move_object(obj->x,obj->y,obj->x-1,obj->y,FELD_KAEFER_5a);
			level_table[obj->y][--obj->x] = FELD_KAEFER_5a;
			moved = '\1';
		}
		else
			obj->direction = 0, tested = 1;
		break;

		case 0: /* right */
		if(obj->x < level_x_size && level_table[obj->y][obj->x+1] < FELD_ERDE)
		{	if(level_table[obj->y][obj->x+1] == FELD_SPIELER_1)
				tod();
			move_object(obj->x,obj->y,obj->x+1,obj->y,FELD_KAEFER_5);
			level_table[obj->y][++obj->x] = FELD_KAEFER_5;
			moved = '\1';
		}
		else
			obj->direction = 1, moved = tested, tested = 1;
	}
}


static void split_cheese(struct objects_node *obj)
{
	unsigned zu = 0;
	int feld;

	if(obj->x < level_x_size)
	{	if((feld = level_table[obj->y][obj->x+1]) == FELD_LEER)
		{	level_table[obj->y][obj->x+1] = FELD_CHEESE_1;
			draw_image(obj->x+1,obj->y,FELD_CHEESE_1);
			add_object(obj->x+1,obj->y,CHEESE1,0);
		}
		else if(feld == FELD_CHEESE_1 || feld == FELD_MAUER)
			zu++;
	}
	else
		zu++;
	if(obj->x > 0)
	{	if((feld = level_table[obj->y][obj->x-1]) == FELD_LEER)
		{	level_table[obj->y][obj->x-1] = FELD_CHEESE_1;
			draw_image(obj->x-1,obj->y,FELD_CHEESE_1);
			add_object(obj->x-1,obj->y,CHEESE1,0);
		}
		else if(feld == FELD_CHEESE_1 || feld == FELD_MAUER)
			zu++;
	}
	else
		zu++;
	if(obj->y > 0)
	{	if((feld = level_table[obj->y-1][obj->x]) == FELD_LEER)
		{	level_table[obj->y-1][obj->x] = FELD_CHEESE_1;
			draw_image(obj->x,obj->y-1,FELD_CHEESE_1);
			add_object(obj->x,obj->y-1,CHEESE1,0);
		}
		else if(feld == FELD_CHEESE_1 || feld == FELD_MAUER)
			zu++;
	}
	else
		zu++;
	if(obj->y < level_y_size)
	{	if((feld = level_table[obj->y+1][obj->x]) == FELD_LEER)
		{	level_table[obj->y+1][obj->x] = FELD_CHEESE_2;
			draw_image(obj->x,obj->y+1,FELD_CHEESE_2);
		}
		else if(feld == FELD_CHEESE_1 || feld == FELD_MAUER)
			zu++;
	}
	else
		zu++;
	if(zu == 4)
		kill_object(obj->x,obj->y);
}

