/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/************
** B--DASH **
****************************************************************
	   ** (C) Copyright 1992,1993 by:         ------      **
           **                                     \    /      **
           **                                      \  /       **
           **                                       \/        **
           ** N-A-B-L-A->Productions, K. Ball�der             **
           *****************************************************
           ** email: kballued@charon.physik.uni-osnabrueck.de **
           *****************************************************

           All rights reserved, see BDASH.DOC for details.

***********************************************************************

scores.c: Keeping track of scores and management of high-score-list

*****************************************************end of header*****/

#include "scores.h"
#include "bdash.h"

#include <ctype.h>
#ifdef __TURBOC__
#	include <graphics.h>
#	include <conio.h>
#endif
#include <stdio.h>

#include "graphic.h"

static unsigned long _score = 0;

struct highscore_entry highscore_table[10] = {
{"",0ul,0u},{"",0ul,0u},{"",0ul,0u},{"",0ul,0u},{"",0ul,0u},
{"",0ul,0u},{"",0ul,0u},{"",0ul,0u},{"",0ul,0u},{"",0ul,0u}};

void display_score(void)
{
#ifdef __TURBOC__
	void _display_score(unsigned long score);	/* from graphic.c */
	_display_score(_score);
#endif
}

#define STD_SCORE	5

unsigned long get_score(void)
{
	return _score;
}

void increment_score(int factor)
{
	_score += factor * STD_SCORE;
	display_score();
}

#ifndef DUMMY_VERSION
static void edit_line(int x, int y, char *line)
{
#ifdef __TURBOC__
	char input, buf[2]="X";
	int pos = 0;

	do
	{       outtextxy(x,y,"_");
		input = getch();
		bar(x,y,x+7,y+7);
		if(pos < 19 && isprint(input))
		{	*buf = line[pos++] = input;
			outtextxy(x,y,buf);
			bar(x+=8,y,x+7,y+7);
		}
		else if(input == 8) /* Backspace */
		{	pos--;
			bar(x-=8,y,x+7,y+7);
		}
	}while(input != '\r');
	line[pos] = '\0';
#endif
}

void display_scoretable(void)
{
#ifdef __TURBOC__
	int i,j,x = gr_maxx>>1,y,y2;
	char linebuffer[41];

	CLEAR_KEY_BUF

	setfillstyle(SOLID_FILL,BLUE);
	setcolor(YELLOW);
	fillellipse(x,gr_maxy>>1,158,90);
	settextjustify(CENTER_TEXT,TOP_TEXT);

	outtextxy(x,24,"Famous Diggers");

	for(y = 64, i = 0; i < 10; y+=8,i++)
	{	sprintf(linebuffer,"%3u:%-20s : %7lu",
			highscore_table[i].level,
			highscore_table[i].name,
			highscore_table[i].score);
		outtextxy(x,y,linebuffer);
	}
	for(y = 64, i = 0; i < 10; y+=8, i++)
		if(_score > highscore_table[i].score)
		{       for(y2=136, j=9;j>i;y2-=8,j--)
			{	highscore_table[j] = highscore_table[j-1];
				bar(24,y2,gr_maxx-24,y2+7);
				sprintf(linebuffer,"%3u:%-20s : %7lu",
					highscore_table[j].level,
					highscore_table[j].name,
					highscore_table[j].score);
					outtextxy(x,y2,linebuffer);
		}

			bar(24,y,gr_maxx-24,y+7);
			sprintf(linebuffer,"%3u:%-20s : %7lu",
				act_level,
				"",
				_score);
			outtextxy(x,y,linebuffer);
			settextjustify(LEFT_TEXT,TOP_TEXT);
			edit_line(56,y,highscore_table[i].name);
			highscore_table[i].score = _score;
			highscore_table[i].level = act_level;
			break;
		}
	getch();
#endif
}
#else
void display_scoretable(void)
{}
#endif


