/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/*
 * React: andere Objekte reagieren lassen
 *
 */

extern void bearbeite_feld(int x, int y); /* zu bearbeitendes Feld merken! */
extern void react(void); /* gemerkte Felder bearbeiten */
extern void init_react_stack(void); /* unbedingt zuerst aufrufen! */
extern void free_react_stack(void);