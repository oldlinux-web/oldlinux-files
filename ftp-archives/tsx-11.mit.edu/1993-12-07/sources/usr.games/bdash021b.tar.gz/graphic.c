/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/************
** B--DASH **
****************************************************************
           ** (C) Copyright 1992 by:              ------      **
           **                                     \    /      **
           **                                      \  /       **
           **                                       \/        **
           ** N-A-B-L-A->Productions, K. Ball�der             **
           *****************************************************
           ** email: kballued@charon.physik.uni-osnabrueck.de **
           *****************************************************

           All rights reserved, see BDASH.DOC for details.

***********************************************************************

graphic.c:	Graphic routines (wat sonst?)

*****************************************************end of header*****/
#include "bdash.h"

#include "graphic.h"

#ifdef CC_TURBOC
#	include <graphics.h>
#	include <alloc.h>
#	include <mem.h>
#	include <dos.h>
#else
#	include "vga.h"
#	include "vgax.h"
#	include "string.h"	/* fuer memmove */
#endif

#include <stdlib.h>

#include "scores.h"

static int dx = 0, dy = 0;

int gr_maxx, gr_maxy;


#define ONSCREEN(x,y) ((dx <= x)&&(x < dx+10)&&(dy <= y)&&(y <dy+8))

void erase_score(void);

#ifndef DUMMY_VERSION


void display(int px, int py)
{
  register int x,y;

  dx = 0; dy = 0;

  while(px-dx >= 6)
	dx++;
  while(py-dy >= 4)
	dy++;

  for(x=0;x<10;x++)
    for(y=0;y<8;y++)
       putimage(x<<5,y*25,figur[level_table[y+dy][x+dx]],COPY_PUT);
  display_score();
}



void scroll_up(int py)
{
  int x;

  if(dy > level_y_size-9 || (py-dy < 4))
    return;

  erase_score();
  dy++;
#ifdef CC_TURBOC
  movedata(0xa000,8000,0xa000,0,(size_t)56000L);
#else
	memmove(graph_mem,graph_mem+8000,(size_t)56000);
#endif
  for(x = 0; x < 10; x++)
    putimage(x<<5,175,figur[level_table[7+dy][x+dx]],COPY_PUT);
  display_score();
}

void scroll_down(int py)
{
  int x;

  if(dy == 0 || py-dy > 4)
    return;
  dy--;

#ifdef CC_TURBOC
  memmove(MK_FP(0xa000,8000),MK_FP(0xa000,0),(size_t)56000L);
#else
  memmove(graph_mem+8000,graph_mem,(size_t)56000);
#endif
  for(x = 0; x < 10; x++)
    putimage(x<<5,0,figur[level_table[dy][x+dx]],COPY_PUT);
  display_score();
}

void scroll_left(int px)
{
  register int y;

  if(dx > level_x_size-11 || px-dx < 5)
    return;

  erase_score();
  dx++;
  for(y = 0; y < 200; y++)
#ifdef CC_TURBOC
    movedata(0xa000,y*320+32,0xa000,y*320,288);
#else
	memmove(graph_mem+y*320,graph_mem+y*320+32,288);
#endif

  for(y = 0; y < 8; y++)
    putimage(288,y*25,figur[level_table[y+dy][9+dx]],COPY_PUT);
  display_score();
}

void scroll_right(int px)
{
  register int y;


  if(dx == 0 || px-dx > 5)
    return;

  erase_score();
  dx--;
  for(y = 0; y < 200; y++)
#ifdef CC_TURBOC
    memmove(MK_FP(0xa000,y*320+32),MK_FP(0xa000,y*320),288);
#else
	memmove(graph_mem+y*320+32,graph_mem+y*320,288);
#endif
  for(y = 0; y < 8; y++)
    putimage(0,y*25,figur[level_table[y+dy][dx]],COPY_PUT);
  display_score();
}

void draw_image(int x, int y, unsigned char object)
{
  if(ONSCREEN(x,y))
    putimage((x-dx)<<5,(y-dy)*25,figur[object],COPY_PUT);
}
void draw_spieler(int x, int y, int player)
{
  if(ONSCREEN(x,y))
    putimage((x-dx)<<5,(y-dy)*25,figur[player == 0 ? FELD_SPIELER_1:FELD_SPIELER_2],COPY_PUT);
}

void draw_leer(int x, int y)
{
  if(ONSCREEN(x,y))
    putimage((x-dx)<<5,(y-dy)*25,figur[FELD_LEER],COPY_PUT);
}

void move_object(int alt_x, int alt_y, int neu_x, int neu_y, unsigned obj_num)
{
  if(obj_num == FELD_STEIN) obj_num = FELD_STEIN_2;
  if(obj_num == FELD_BOMBE) obj_num = FELD_BOMBE_2;
  if(ONSCREEN(alt_x,alt_y))
    putimage((alt_x-dx)<<5,(alt_y-dy)*25,figur[FELD_LEER],COPY_PUT);
  level_table[alt_y][alt_x] = FELD_LEER;
  if(ONSCREEN(neu_x,neu_y))
    putimage((neu_x-dx)<<5,(neu_y-dy)*25,figur[obj_num],COPY_PUT);
  level_table[neu_y][neu_x] = obj_num;
}


void display_message(char *l1, char *l2, char *l3)
{
#ifdef CC_TURBOC
	int getch(void);

	int width;

	width = textwidth(l1);
	width = textwidth(l2) > width ? textwidth(l2) : width;
	width = textwidth(l3) > width ? textwidth(l3) : width;

	settextjustify(CENTER_TEXT,TOP_TEXT);
	setcolor(YELLOW);
	setfillstyle(SOLID_FILL,BLUE);

	bar((gr_maxx-width-8)>>1,(gr_maxy-30)>>1,(gr_maxx+width+8)>>1,(gr_maxy+34)>>1);
	rectangle((gr_maxx-width-10)>>1,(gr_maxy-32)>>1,(gr_maxx+width+10)>>1,(gr_maxy+36)>>1);


	outtextxy(gr_maxx>>1,(gr_maxy>>1)-12,l1);
	outtextxy(gr_maxx>>1,(gr_maxy>>1)-2,l2);
	outtextxy(gr_maxx>>1,(gr_maxy>>1)+8,l3);

	CLEAR_KEY_BUF

	if(! getch()) getch();
	display(player_x[0],player_y[0]);
#endif
}




void _display_score(unsigned long score)	/* called by display_score() */
{
#ifdef CC_TURBOC
	static char buf[10]; /* should be enough */

	ultoa(score,buf,10);
	settextjustify(RIGHT_TEXT,BOTTOM_TEXT);
	setcolor(YELLOW);
	outtextxy(gr_maxx,gr_maxy,buf);
#endif
}

void erase_score(void)	/* remove score from screen */
{
#ifdef CC_TURBOC
	putimage(9<<5,7*25,figur[level_table[7+dy][9+dx]],COPY_PUT);
	putimage(8<<5,7*25,figur[level_table[7+dy][8+dx]],COPY_PUT);
#endif
}
#else

#pragma warn -par
#pragma warn -use
#include <stdio.h>

void display(int dx, int dy)
{
}

void scroll_up(int py) /* Spielfeld um eine Zeile hochscrollen */
{
	puts("scroll_up()");
}
void scroll_down(int py) /* Spielfeld um eine Zeile herunterrollen */
{
	puts("scroll_down()");
}
void scroll_left(int px) /* Spielfeld um eine Spalte nach links scrollen */
{
	puts("scroll_left()");
}
void scroll_right(int px) /* Spielfeld um eine Spalte nach rechts scrollen */
{
	puts("scroll_right()");
}
void draw_image(int x, int y, unsigned char object) /* Feld malen */
{}
void draw_spieler(int x, int y, int player) /* Die Spielfiguren darstellen, bei x,y */
{}
void draw_leer(int x, int y) /* bei x,y ein leeres Feld darstellen */
{}
void display_message(char *l1, char *l2, char *l3)
{
	puts("display_message():");
	puts("{"); puts(l1); puts(l2); puts(l3); puts("}");
}

/* ein Objekt verschieben */

void move_object(int alt_x, int alt_y, int neu_x, int neu_y, unsigned obj_num)
{}

void _display_score(void)
{}

#endif
