#! /bin/sh
#
# NET-BASE	A collection of programs that form the base set of the
#		NET-2 Networking Distribution for the LINUX operating
#		system.
#
# Usage:	Install.sh [firsttime]
#
# Version:	@(#)Install.sh  1.30	08/26/93
#
# Authors:	Fred N. van Kempen, <waltje@uwalt.nl.mugnet.org>
#		Johannes Grosen, <grosen@argv.cs.ndsu.nodak.edu>
#		Copyright 1988-1993 MicroWalt Corporation
#
#		This program is free software; you can redistribute it
#		and/or  modify it under  the terms of  the GNU General
#		Public  License as  published  by  the  Free  Software
#		Foundation;  either  version 2 of the License, or  (at
#		your option) any later version.
#
PATH=/bin:/usr/bin:/etc:/usr/etc
export PATH
NROFF="groff -Tascii"	# how to format man pages for catman

DIRS="/dev /dev/net /conf /conf/net /etc /bin /usr /usr/bin /usr/man"
BIN_PROGS="hostname netstat"
ETC_PROGS="arp ifsetup ifconfig kd route wdsetup/wdsetup"
DEVICES="socket arp route unix inet ip icmp tcp udp lo wd[0-3] el[0-3] ne[0-3] hp[0-3] sl[0-7] plip[0-2] dl[0-2]"
DEV_OWNER="bin.bin"

  echo "Installing NET-2 BASE..."

  # Check if this is either SLS, Pro or something unknown.
  if test -d /conf/net
  then	# Linux/PRO
	ETC="/etc"
	CONF="/conf/net"
	DOLINK=1
	DIRS="/dev /dev/net /conf /conf/net /etc /bin /usr /usr/bin /usr/man"
  else	# SLS or vanilla
	ETC="/etc"
	CONF="/etc"
	DOLINK=0
	DIRS="/dev /etc /bin /usr /usr/bin /usr/man"
  fi

  if test -d /dev/net
  then
	DEV="/dev/net"
  else
	DEV="/dev"
  fi

  # Are we expected to install preformatted manual pages?
  if test -d /usr/man/cat1
  then
	CATMAN=1
  else
	CATMAN=0
  fi

  # Create the /dev entries.
  echo "Creating device special files:"

  for device in $DEVICES
  do
	rm -f ${DEV}/${device}
  done

  # Install the SOCKET layer entries.
  echo -n "socket "
  mknod -m 666 ${DEV}/socket c 16 0
  chown ${DEV_OWNER} ${DEV}/socket
  echo -n "arp "
  mknod -m 600 ${DEV}/arp c 16 1
  chown ${DEV_OWNER} ${DEV}/arp
  echo -n "route "
  mknod -m 600 ${DEV}/route c 16 2
  chown ${DEV_OWNER} ${DEV}/route

  # Install the AF_UNIX layer entries.
  echo -n "unix "
  mknod -m 666 ${DEV}/unix c 17 0
  chown ${DEV_OWNER} ${DEV}/unix

  # Install the AF_INET layer entries.
  echo -n "inet "
  mknod -m 600 ${DEV}/inet c 18 0
  chown ${DEV_OWNER} ${DEV}/inet
  echo -n "ip "
  mknod -m 666 ${DEV}/ip c 18 1
  chown ${DEV_OWNER} ${DEV}/ip
  echo -n "icmp "
  mknod -m 666 ${DEV}/icmp c 18 2
  chown ${DEV_OWNER} ${DEV}/icmp
  echo -n "tcp "
  mknod -m 666 ${DEV}/tcp c 18 3
  chown ${DEV_OWNER} ${DEV}/tcp
  echo -n "udp "
  mknod -m 666 ${DEV}/udp c 18 4
  chown ${DEV_OWNER} ${DEV}/udp

  # Install the LOOPBACK device driver.
  echo "lo"
  mknod -m 600 ${DEV}/lo c 19 0
  chown ${DEV_OWNER} ${DEV}/lo

  # Install the DP8390 device driver.
  echo -n "wd[0-3] el[0-3] ne[0-3] hp[0-3] "
  for i in 0 1 2 3
  do
	mknod -m 600 ${DEV}/wd$i c 20 `expr $i + 8`
	chown ${DEV_OWNER} ${DEV}/wd$i
	mknod -m 600 ${DEV}/el$i c 20 `expr $i + 16`
	chown ${DEV_OWNER} ${DEV}/el$i
	mknod -m 600 ${DEV}/ne$i c 20 `expr $i + 24`
	chown ${DEV_OWNER} ${DEV}/ne$i
	mknod -m 600 ${DEV}/hp$i c 20 `expr $i + 32`
	chown ${DEV_OWNER} ${DEV}/hp$i
  done

  # Install the SLIP device driver.
  echo -n "sl[0-7] "
  for i in 0 1 2 3 4 5 6 7
  do
	mknod -m 600 ${DEV}/sl$i c 21 $i
	chown ${DEV_OWNER} ${DEV}/sl$i
  done

  # Install the PLIP device driver.
  echo -n "plip[0-2] "
  for i in 0 1 2
  do
	mknod -m 600 ${DEV}/plip$i c 22 $i
	chown ${DEV_OWNER} ${DEV}/plip$i
  done

  # Install the DLINK device driver.
  echo -n "dl[0-2]"
  for i in 0 1 2
  do
	mknod -m 600 ${DEV}/dl$i c 23 $i
	chown ${DEV_OWNER} ${DEV}/dl$i
  done

  echo ; echo

  # Install the CONFIG files.
  if [ "xx$1" = "xxfirsttime" ]
  then
	echo -n "Installing CONFIG files..."
	cp -a samples/etc/* ${ETC}
	echo "done"
	echo -n "Installing CONFIG (${CONF}) files..."
	cp -a samples/conf/* ${CONF}
	echo "done"
	CONFIG=1

	# Set up those damn symbolic links.
	if [ $DOLINK -eq 1 ]
	then
		echo -n "Setting up symbolic links..."
		links="`cd ${CONF}; echo *`"
		for i in ${links}
		do
			ln -sf ${CONF}/$i ${ETC}/$i
		done
		echo "done"
	fi
  else
	CONFIG=0
  fi

  # Install the primary user commands.
  echo "Installing USER commands:"
  for i in ${BIN_PROGS}
  do
	path=/bin/`basename $i`
	echo -n "${path} "
	mv ${path} ${path}.old	# backup old version
	cp $i ${path}
	chmod 555 ${path}
	chown bin.bin ${path}
  done
  (echo -n "/bin/domainname"; cd /bin; ln -sf hostname domainname)
  echo ; echo

  # Install the primary system administrator commands.
  echo "Installing SYSTEM administrator commands:"
  for i in ${ETC_PROGS}
  do
	path=${ETC}/`basename $i`
	echo -n "${path} "
	mv -f ${path} ${path}.old	# backup old version
	cp $i ${path}
	chmod 555 ${path}
	chown bin.bin ${path}
  done
  echo ; echo

  # Install the manual pages.
  echo -n "Installing manual pages..."
  for i in 1 5 8
  do
	# Install manual sources.
	chmod 644 man/*.$i
	chown bin.bin man/*.$i
	cp -af man/*.$i /usr/man/man$i >/dev/null

	# Do we need to pre-format them as well?
	if [ ${CATMAN} -eq 1 ]
	then
		for manpage in man/*.$i
		do
			page=`basename ${manpage}`
			rm -f /usr/man/cat${i}/${page}
			${NROFF} -man $manpage > /usr/man/cat${i}/${page}
			chmod 644 /usr/man/cat${i}/${page}
			chown bin.bin /usr/man/cat${i}/${page}
		done
	fi
  done
  (cd /usr/man/man1; ln -sf hostname.1 domainname.1)
  echo "done" ; echo

  # Install the DIP program.
  echo -n "Installing DIP..."
  cp -f dip/dip /usr/bin/dip
  chmod 6750 /usr/bin/dip
  chown root.dip /usr/bin/dip
  cp -f dip/sample.dip ${CONF}
  chmod 600 ${CONF}/sample.dip
  chown bin.dip ${CONF}/sample.dip
  if test $CATMAN -eq 1
  then
	rm -f /usr/man/cat8/dip.8
	${NROFF} -man dip/dip.8 > /usr/man/cat8/dip.8
	chmod 644 /usr/man/cat8/dip.8
	chown bin.bin /usr/man/cat8/dip.8
  else
	cp -f dip/dip.8 /usr/man/man8
	chmod 644 /usr/man/man8/dip.8
	chown bin.bin /usr/man/man8/dip.8
  fi
  echo "done" ; echo

  echo
  echo "Installation completed."
  if [ ${CONFIG} -eq 1 ]
  then
	echo "Do NOT forget to edit the files in ${CONF} just installed."
	echo "or the NET-2 system will not operate correctly!"
  fi
  echo "Your old binaries (if they existed) were backed up to <name>.old."
  echo "You may safely delete them once you are satisfied that the new"
  echo "setup is working correctly."
  echo

  exit 0
