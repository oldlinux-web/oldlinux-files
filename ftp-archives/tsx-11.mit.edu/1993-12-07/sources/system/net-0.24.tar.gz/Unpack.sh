#! /bin/sh
#
# NET-BASE	A collection of programs that form the base set of the
#		NET-2 Networking Distribution for the LINUX operating
#		system.
#
# Usage:	Unpack.sh
#
# Version:	@(#)Unpack.sh	1.00	08/26/93
#
# Author:	Fred N. van Kempen, <waltje@uwalt.nl.mugnet.org>
#		Copyright 1988-1993 MicroWalt Corporation
#
#		This program is free software; you can redistribute it
#		and/or  modify it under  the terms of  the GNU General
#		Public  License as  published  by  the  Free  Software
#		Foundation;  either  version 2 of the License, or  (at
#		your option) any later version.
#
PATH=/bin:/usr/bin:/etc:/usr/etc
export PATH

  echo "Unpacking NET-2 prerequisite files..."

  if [ ! -f /usr/include/netinet/in_systm.h ]
  then
	echo -n "Unpacking new INCLUDE files..."
	(p=`pwd`; cd /usr/include; umask 0; tar xfmp ${p}/includes.tar)
	echo "done"
  fi

  exit 0
