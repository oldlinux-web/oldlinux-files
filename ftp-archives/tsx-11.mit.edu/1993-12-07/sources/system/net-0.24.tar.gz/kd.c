/*
 * kd		A simple program to manipulate the Linux NET-2 kernel debug
 *		modules.  Basically, this program can be used to enable and/
 *		or disable various debug flags of the NET-2 kernel code.
 *
 * Usage:	kd keyword|value [device]
 *
 * Version:	@(#)kd.c	2.21	07/18/93
 *
 * Author:	Fred N. van Kempen, <waltje@uwalt.nl.mugnet.org>
 */
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/ddi.h>
#include <ctype.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include "pathnames.h"


char *Version = "@(#) kd 2.21 (07/18/93)";


static struct _words_ {
  char	*name;
  char	*dev;
  int	level;
} words[] = {
  { "off",	NULL,			0	},	/* general */
  { "on",	NULL,			1	},

  { "socket",	"/dev/net/socket",	1	},	/* NET itself */
  { "net",	"/dev/net/socket",	1	},
  { "dev",	"/dev/net/socket",	2	},
  { "ioctl",	"/dev/net/socket",	3	},
  { "pkt",	"/dev/net/socket",	4	},
  { "proto",	"/dev/net/socket",	5	},
  { "eth",	"/dev/net/socket",	6	},
  { "lo",	"/dev/net/socket",	7	},

  { "arp",	"/dev/net/arp",		1	},	/* ARP */
  { "route",	"/dev/net/route",	1	},	/* ROUTE */

  { "unix",	"/dev/net/unix",	1	},	/* AF_UNIX */

  { "inet",	"/dev/net/inet",	1	},	/* AF_INET */
  { "iroute",	"/dev/net/inet",	2	},
  { "iproto",	"/dev/net/inet",	3	},
  { "itmr",	"/dev/net/inet",	4	},
  { "ipck",	"/dev/net/inet",	5	},
  { "raw",	"/dev/net/inet",	6	},
  { "ip",	"/dev/net/inet",	7	},
  { "icmp",	"/dev/net/inet",	8	},
  { "tcp",	"/dev/net/inet",	9	},
  { "udp",	"/dev/net/inet",	10	},

  { NULL,	NULL,			-1	}
};


static void
usage(void)
{
  struct _words_ *wp;
  int field;

  fprintf(stderr, "Usage: kd keyword|value [device]\n");
  fprintf(stderr, "\nPossible keywords are:\n");
  wp = words;
  field = 0;
  while (wp->name != NULL) {
	if (field == 0) fprintf(stderr, "\n\t");
	fprintf(stderr, "%-16s", wp->name);
	field++;
	if (field == 4) field = 0;
	wp++;
  }
  if (field != 0) fprintf(stderr, "\n");
  exit(1);
}


int
main(int argc, char **argv)
{
  struct _words_ *wp;
  char *name;
  char *opt;
  int fd, val;
  int off = 0;

  if (argc < 2 || argc > 3) usage();
  opt = argv[1];

  fd = 0;
  val = -1;
  if (*opt == '-') {
	opt++;
	off = 128;
  }

  name = NULL;
  wp = words;
  while (wp->name != NULL) {
	if (!strcmp(opt, wp->name)) {
		val = wp->level;
		name = wp->dev;
		break;
	} else wp++;
  }
  if (val == -1) {
	if (!isdigit(*opt)) usage();
	val = atoi(opt);
  }

  if (argc == 3 || name == NULL) {
	if (argc != 3) usage();
	name = argv[2];
  }

  if ((fd = open(name, O_RDWR)) < 0) {
	fprintf(stderr, "%s: %s\n", name, strerror(errno));
	exit(1);
  }

  val += off;
  if (ioctl(fd, DDIOCSDBG, &val) < 0) {
	fprintf(stderr, "%s: DDIOCSDBG(%d): %s\n", name, val, strerror(errno));
  }

  (void) close(fd);

  return(0);
}
