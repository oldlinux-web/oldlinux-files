#!/bin/sh
### netf.sh
### $Id: netf.sh,v 1.1 1993/05/29 18:39:46 mdw Exp $
### Matt Welsh <mdw@tc.cornell.edu>

# Some security
PATH=/bin:/usr/bin:/etc:$NET_DIR
IFS="	 "

#Generic filenames
CONF_FILE=$NET_DIR/net.conf

### Prompt for a response and return the default if none.
Prompt () {
  case $2 in
    "") echo -n "$1: " > /dev/tty
    ;;
    *) echo -n "$1 [$2]: " > /dev/tty
    ;;
  esac
  read ans
  case $ans in
	"") echo $2
	;;
	*) echo $ans
	;;
  esac
}
