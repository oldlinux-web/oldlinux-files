/*
 * version.h - version information for the Linux file system degragmenter.
 * version.h,v 1.5 1993/04/06 13:31:37 linux Exp
 *
 * Copyright (C) 1992, 1993 Stephen Tweedie (sct@dcs.ed.ac.uk)
 * 
 * This file may be redistributed under the terms of the GNU General
 * Public License.
 *
 */

char *version = "0.4";
char *CVSID = "version.h,v 1.5 1993/04/06 13:31:37 linux Exp";
