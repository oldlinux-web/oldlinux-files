/* $Id: dumputmp.c,v 4.1 1993/03/23 16:17:06 mike Exp $ */


#include <stdio.h>
#include <utmp.h>


main(int argc, char *argv[])
{
	struct utmp	*ut;

	utmpname(argv[1]);
	while ((ut = getutent()) != NULL) {
		printf("ID: %s\n", ut->ut_id);
		printf("\tType: %d\n", ut->ut_type);
		printf("\tPid:  %d\n", ut->ut_pid);
		printf("\tLine: %s\n", ut->ut_line);
		printf("\tTime: %d\n", ut->ut_time);
		printf("\tUser: %s\n", ut->ut_user);
		printf("\tHost: %s\n", ut->ut_host);
		printf("\tAddr: %d\n", ut->ut_addr);
	}
	endutent();
}
