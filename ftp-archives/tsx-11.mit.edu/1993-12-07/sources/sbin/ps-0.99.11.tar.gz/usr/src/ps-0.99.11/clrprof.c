

#include <stdio.h>
#include <stdlib.h>


unsigned long prof_len = 0;
unsigned long prof_buffer = 0;
unsigned long jiffies = 0;

unsigned long * buffer;

extern int optind;
extern char *optarg;

main(argc, argv)
char **argv;
{
    int fd;

    if (open_psdb()) {
	perror("cannot open psdatabase");
	exit(2);
    }
    prof_len = get_kword(k_addr("_prof_len"));
    prof_buffer = get_kword(k_addr("_prof_buffer"));
    buffer = malloc(prof_len * sizeof(unsigned long));
    if (!buffer) {
    	fprintf(stderr,"out of memory\n");
    	exit(1);
    }
    memset(buffer, 0, 4*prof_len);
    if ((fd = open("/dev/kmem", 1)) == -1) {
	perror("/dev/kmem");
	exit(1);
    }
    if (lseek(fd, prof_buffer, 0) == -1) {
	perror("lseek");
	exit(1);
    }
    write(fd, buffer, 4*prof_len);
    exit(0);
}
