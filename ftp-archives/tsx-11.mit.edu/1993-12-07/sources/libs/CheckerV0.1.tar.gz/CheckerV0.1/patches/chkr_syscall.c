/* chkr_syscall.c from unistd.h
   Changes by Tristan Gingold */
/* Copyright (C) 1991, 1992 Free Software Foundation, Inc.
This file is part of the GNU C Library.

The GNU C Library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public License as
published by the Free Software Foundation; either version 2 of the
License, or (at your option) any later version.

The GNU C Library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with the GNU C Library; see the file COPYING.LIB.  If
not, write to the Free Software Foundation, Inc., 675 Mass Ave,
Cambridge, MA 02139, USA.  */

/*
 *	POSIX Standard: 2.10 Symbolic Constants		<unistd.h>
 */

#include "checker.h"
#include <features.h>
#include <unistd.h>
#include <grp.h>
#include <sys/stat.h>
#include <sys/vfs.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/signal.h>
#include <sys/times.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/mount.h>
#include <sys/mman.h>
#include <sys/vm86.h>
#include <utime.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <stdarg.h>
#include <termios.h>
#include <linux/fs.h>
#include <linux/tty.h>

/* All functions that are not declared anywhere else.  */

#include <gnu/types.h>
#include <gnu-stabs.h>

#if !defined(ssize_t) && !defined(_SSIZE_T)
#define _SSIZE_T
#define	ssize_t	__ssize_t
#endif

#define	__need_size_t
#include <stddef.h>

/* Test for access to NAME.  */
extern int _chkr___access (__const char *__name, int __type);
int __access (__const char *__name, int __type)
{
  chkr_check_str(__name, CHKR_RO);
  return _chkr___access(__name, __type);
}  

/* Move FD's file position to OFFSET bytes from the
   beginning of the file (if WHENCE is SEEK_SET),
   the current position (if WHENCE is SEEK_CUR),
   or the end of the file (if WHENCE is SEEK_END).
   Return the new file position.  */
function_alias(__lseek, _chkr___lseek, __off_t, (__fd, __offset, __whence),
		DEFUN(__lseek, (__fd, __offset, __whence),
			int __fd AND __off_t __offset AND int __whence));
/* __off_t __lseek(int __fd, __off_t __offset, int __whence) */

/* Close the file descriptor FD.  */
function_alias(__close, _chkr___close, int , (__fd),
		DEFUN(__close, (__fd),
			int __fd));
/*extern int __close __P ((int __fd)); */

/* Read NBYTES into BUF from FD.  Return the
   number read, -1 for errors or 0 for EOF.  */
extern ssize_t _chkr___read (int __fd, __ptr_t __buf, size_t __nbytes);
ssize_t __read (int __fd, __ptr_t __buf, size_t __nbytes)
{
  ssize_t res;
  chkr_check_addr(__buf, __nbytes, CHKR_TW);
  res = _chkr___read(__fd, __buf, __nbytes);
  if (res > 0)
    chkr_set_right(__buf, res, CHKR_RW);
  return res;
}

/* Write N bytes of BUF to FD.  Return the number written, or -1.  */
extern ssize_t _chkr___write (int __fd, __const __ptr_t __buf, size_t __n);
ssize_t __write (int __fd, __const __ptr_t __buf, size_t __n)
{
  chkr_check_addr(__buf, __n, CHKR_RO);
  return _chkr___write(__fd, __buf, __n);
}

/* Create a one-way communication channel (pipe).
   If successul, two file descriptors are stored in PIPEDES;
   bytes written on PIPEDES[1] can be read from PIPEDES[0].
   Returns 0 if successful, -1 if not.  */
extern int _chkr___pipe (int __pipedes[2]);
int __pipe (int __pipedes[2])
{
  chkr_check_addr(__pipedes, 2*sizeof(int), CHKR_WO);
  return _chkr___pipe(__pipedes);
}  
/* extern int pipe __P ((int __pipedes[2])); */

/* Schedule an alarm.  In SECONDS seconds, the process will get a SIGALRM.
   If SECONDS is zero, any currently scheduled alarm will be cancelled.
   The function returns the number of seconds remaining until the last
   alarm scheduled would have signaled, or zero if there wasn't one.
   There is no return value to indicate an error, but you can set `errno'
   to 0 and check its value after calling `alarm', and this might tell you.
   The signal may come late due to processor scheduling.  */
function_alias(alarm , _chkr_alarm, int , (__seconds),
		DEFUN(alarm, (__seconds),
			unsigned int __seconds));   
/* extern unsigned int alarm __P ((unsigned int __seconds)); */

/* Suspend the process until a signal arrives.
   This always returns -1 and sets `errno' to EINTR.  */
function_alias(pause, _chkr_pause, int, (),
		DEFUN(pause, (),
			));   
/* extern int pause __P ((void)); */


/* Change the owner and group of FILE.  */
extern int _chkr___chown (__const char *__file, __uid_t __owner, __gid_t __group);
int __chown (__const char *__file, __uid_t __owner, __gid_t __group)
{
  chkr_check_str(__file, CHKR_RO);
  return _chkr___chown(__file, __owner, __group);
}
  			 
#ifdef	__USE_BSD
/* Change the owner and group of the file that FD is open on.  */
function_alias(__fchown, _chkr___fchown, int, (__fd, __owner, __group),
		DEFUN(__fchown, (__fd, __owner, __group),
			int __fd AND __uid_t __owner AND __gid_t __group));
/* extern int fchown __P ((int __fd,
			__uid_t __owner, __gid_t __group)); */
#endif /* Use BSD.  */

/* Change the process's working directory to PATH.  */
extern int _chkr___chdir (__const char *__path);
int __chdir (__const char *__path)
{
  chkr_check_str(__path, CHKR_RO);
  return _chkr___chdir(__path);
}

/* Duplicate FD, returning a new file descriptor on the same file.  */
function_alias(__dup, _chkr___dup, int , (__fd),
		DEFUN(__dup, (__fd),
			int __fd));
/* extern int dup __P ((int __fd)); */

/* Duplicate FD to FD2, closing FD2 and making it open on the same file.  */
function_alias(__dup2, _chkr___dup2, int , (__fd, __fd2),
		DEFUN(__dup, (__fd, __fd2),
			int __fd AND int __fd2));
/* extern int dup2 __P ((int __fd, int __fd2)); */


/* Replace the current process, executing PATH with arguments ARGV and
   environment ENVP.  ARGV and ENVP are terminated by NULL pointers.  */
extern int _chkr___execve (__const char *__path, char *__const __argv[],   
			  char *__const __envp[]);
int __execve (__const char *__path, char *__const __argv[],
			  char *__const __envp[])
{
  char *ptr;
  
  /* check path */
  chkr_check_str(__path, CHKR_RO);
  
  /* check arguments */
  chkr_check_addr(__argv, sizeof(char *), CHKR_RO);
  ptr = __argv[0];
  while ( ptr != (char*)0)
  {
    chkr_check_addr(&ptr, sizeof(char *), CHKR_RO);
    chkr_check_str(ptr, CHKR_RO);
    ptr++;
  }
  
  /* check environnement */
  chkr_check_addr(__envp, sizeof(char *), CHKR_RO);
  ptr = __envp[0];
  while ( ptr != (char*)0)
  {
    chkr_check_addr(&ptr, sizeof(char *), CHKR_RO);
    chkr_check_str(ptr, CHKR_RO);
    ptr++;
  }
  return _chkr___execve(__path, __argv, __envp);
}
/* extern int execve __P ((__const char *__path, char *__const __argv[],
			char *__const __envp[])); */

#ifndef	__NORETURN
#ifdef	__GNUC__
/* The `volatile' keyword tells GCC that a function never returns.  */
#define	__NORETURN	__volatile
#else /* Not GCC.  */
#define	__NORETURN
#endif /* GCC.  */
#endif /* __NORETURN not defined.  */

/* Get the process ID of the calling process.  */
function_alias(__getpid, _chkr___getpid, int , (),
		DEFUN(__getpid, (),
			));
/*extern __pid_t __getpid __P ((void)); */

/* Get the process ID of the calling process's parent.  */
function_alias(__getppid, _chkr___getppid, int , (),
		DEFUN(__getppid, (),
			));
/* extern __pid_t __getppid __P ((void)); */

#ifdef __linux__

/* Get the process group ID of the calling process.  */
function_alias(getpgrp, _chkr_getpgrp, int , (),
		DEFUN(getpgrp, (),
			));
/* extern __pid_t getpgrp __P ((void)); */

/* Set the process group ID of the process matching PID to PGID.
   If PID is zero, the current process's process group ID is set.
   If PGID is zero, the process ID of the process is used.  */
function_alias(setpgid, _chkr_setpgid, int , (__pid, __pgid),
		DEFUN(setpgid, (__pid, __pgid),
			__pid_t __pid AND __pid_t __pgid));   
/* extern int setpgid __P ((__pid_t __pid, __pid_t __pgid)); */

#else

/* Get the process group ID of process PID.  */
function_alias(getpgid, _chkr_getpgid, int , (__pid),
		DEFUN(getpgrp, (__pid),
			__pid_t __pid));
/* extern __pid_t __getpgrp __P ((__pid_t __pid)); */

#ifndef	__FAVOR_BSD
/* Get the process group ID of the calling process.  */
function_alias(getpgid, _chkr_getpgid, int , (),
		DEFUN(getpgid, (),
			));
/* extern __pid_t getpgrp __P ((void)); */
#else /* Favor BSD.  */
#define	getpgrp(pid)	__getpgrp(pid)
#endif

#ifdef	__USE_BSD
/* Set the process group of PID to PGRP.  */
function_alias(setpgrp, _chkr_setpgrp, int , (__pid, __pgid),
		DEFUN(setpgrp, (__pid, __pgid),
			__pid_t __pid AND __pid_t __pgid));   
/* extern int setpgrp __P ((__pid_t __pid, __pid_t __pgrp)); */

#endif /* Use BSD.  */

#endif /* __linux__ */

/* Create a new session with the calling process as its leader.
   The process group IDs of the session and the calling process
   are set to the process ID of the calling process, which is returned.  */
function_alias(__setsid, _chkr___setsid, __pid_t , (),
		DEFUN(__setsid, (),
			));   
/* extern __pid_t __setsid __P ((void)); */

/* Get the real user ID of the calling process.  */
function_alias(__getuid, _chkr___getuid, __pid_t , (),
		DEFUN(__getuid, (),
			));
/* extern __uid_t __getuid __P ((void)); */

/* Get the effective user ID of the calling process.  */
function_alias(__geteuid, _chkr___geteuid, __pid_t , (),
		DEFUN(__geteuid, (),
			));
/* extern __uid_t __geteuid __P ((void)); */

/* Get the real group ID of the calling process.  */
function_alias(__getgid, _chkr___getgid, __pid_t , (),
		DEFUN(__getgid, (),
			));
/* extern __gid_t __getgid __P ((void)); */

/* Get the effective group ID of the calling process.  */
function_alias(__getegid, _chkr___getegid, __pid_t , (),
		DEFUN(__getegid, (),
			));
/* extern __gid_t __getegid __P ((void)); */

/* If SIZE is zero, return the number of supplementary groups
   the calling process is in.  Otherwise, fill in the group IDs
   of its supplementary groups in LIST and return the number written.  */
extern int _chkr___getgroups (int __size, __gid_t __list[]);
int __getgroups (int __size, __gid_t __list[])
{
  int res;
  chkr_check_addr(__list, __size * sizeof(__gid_t), CHKR_TW);
  res = _chkr___getgroups(__size, __list);
  chkr_set_right(__list, res * sizeof(__gid_t), CHKR_WO);
  return res;
}
/* extern int getgroups __P ((int __size, __gid_t __list[])); */

/* Set the group set for the current user to GROUPS (N of them).  */
extern int _chkr_setgroups (size_t __n, __const __gid_t * __groups);
int setgroups (size_t __n, __const __gid_t * __groups)
{
  chkr_check_addr(__groups, __n * sizeof(__gid_t), CHKR_RO);
  return _chkr_setgroups(__n, __groups);
}

/* Set the user ID of the calling process to UID.
   If the calling process is the super-user, set the real
   and effective user IDs, and the saved set-user-ID to UID;
   if not, the effective user ID is set to UID.  */
function_alias(__setuid, _chkr___setuid, __pid_t , (__uid),
		DEFUN(__setuid, (__uid),
			__uid_t __uid));   
/* extern int __setuid __P ((__uid_t __uid)); */

#ifdef	__USE_BSD
/* Set the real user ID of the calling process to RUID,
   and the effective user ID of the calling process to EUID.  */
function_alias(__setreuid, _chkr___setreuid, __pid_t , (__uid, __euid),
		DEFUN(__setreuid, (__uid, __euid),
			__uid_t __uid AND __uid_t __euid));
/* extern int __setreuid __P ((__uid_t __ruid, __uid_t __euid)); */

#endif /* Use BSD.  */

/* Set the group ID of the calling process to GID.
   If the calling process is the super-user, set the real
   and effective group IDs, and the saved set-group-ID to GID;
   if not, the effective group ID is set to GID.  */
function_alias(__setgid, _chkr___setgid, int, (__gid),
		DEFUN(__setgid, (__gid),
			__gid_t __gid));   
/* extern int __setgid __P ((__gid_t __gid)); */

#ifdef	__USE_BSD
/* Set the real group ID of the calling process to RGID,
   and the effective group ID of the calling process to EGID.  */
function_alias(__setregid, _chkr___setregid, int, (__gid, __egid),
		DEFUN(__setregid, (__gid, __egid),
			__gid_t __gid AND __gid_t __egid));   
/* extern int __setregid __P ((__gid_t __rgid, __gid_t __egid)); */

#endif /* Use BSD.  */


/* Clone the calling process, creating an exact copy.
   Return -1 for errors, 0 to the new process,
   and the process ID of the new process to the old process.  */
function_alias(__fork, _chkr___fork, __pid_t, (),
		DEFUN(__fork, (),
			));
/* extern __pid_t fork __P ((void)); */

/* Make a link to FROM named TO.  */
extern int _chkr___link (__const char *__from, __const char *__to);
int __link (__const char *__from, __const char *__to)
{
  chkr_check_str(__from, CHKR_RO);
  chkr_check_str(__to, CHKR_RO);  
  return _chkr___link(__from, __to);
}
/* extern int link __P ((__const char *__from, __const char *__to)); */

#ifdef	__USE_BSD
/* Make a symbolic link to FROM named TO.  */
extern int _chkr___symlink (__const char *__from, __const char *__to);
int __symlink (__const char *__from, __const char *__to)
{
  chkr_check_str(__from, CHKR_RO);
  chkr_check_str(__to, CHKR_RO);  
  return _chkr___symlink(__from, __to);
}
/* extern int symlink __P ((__const char *__from, __const char *__to)); */

/* Read the contents of the symbolic link PATH into no more than
   LEN bytes of BUF.  The contents are not null-terminated.
   Returns the number of characters read, or -1 for errors.  */
extern int _chkr___readlink (__const char *__path, char *__buf, size_t __len);
int __readlink (__const char *__path, char *__buf, size_t __len)
{
  int res;
  chkr_check_str(__path, CHKR_RO);
  chkr_check_addr(__buf, __len, CHKR_TW);
  res = _chkr___readlink(__path, __buf, __len);
  chkr_set_right(__buf, __len, CHKR_WO);
  return res;
}    
/* extern int readlink __P ((__const char *__path, char *__buf, size_t __len)); */

#endif /* Use BSD.  */

/* Remove the link NAME.  */
extern int _chkr___unlink (__const char *__name);
int __unlink (__const char *__name)
{
  chkr_check_str(__name, CHKR_RO);
  return _chkr___unlink(__name);
}
/* extern int unlink __P ((__const char *__name)); */

/* Remove the directory PATH.  */
extern int _chkr___rmdir (__const char *__path);
int __rmdir (__const char *__path)
{
  chkr_check_str(__path, CHKR_RO);
  return _chkr___rmdir(__path);
}
/* extern int rmdir __P ((__const char *__path)); */

#ifdef	__USE_BSD
/* Set the name of the current host to NAME, which is LEN bytes long.
   This call is restricted to the super-user.  */
extern int _chkr_sethostname (__const char *__name, size_t __len);
int sethostname (__const char *__name, size_t __len)
{
  chkr_check_addr(__name, __len, CHKR_RO);
  return _chkr_sethostname(__name, __len);
}

/* Make all changes done to FD actually appear on disk.  */
function_alias(fsync , _chkr_fsync, int , (__fd),
		DEFUN(fsync, (__fd),
			int __fd));
/* extern int fsync __P ((int __fd)); */

/* Make all changes done to all files actually appear on disk.  */
function_alias(sync , _chkr_sync, int , (),
		DEFUN(sync, (),
			));
/* extern int sync __P ((void)); */

/* Revoke access permissions to all processes currently communicating
   with the control terminal, and then send a SIGHUP signal to the process
   group of the control terminal.  */
function_alias(vhangup , _chkr_vhangup, int , (),
		DEFUN(changup, (),
			));   
/* extern int vhangup __P ((void)); */

/* Turn accounting on if NAME is an existing file.  The system will then write
   a record for each process as it terminates, to this file.  If NAME is NULL,
   turn accounting off.  This call is restricted to the super-user.  */
extern int _chkr_acct (__const char *__name);
int acct (__const char *__name)
{
  chkr_check_str(__name, CHKR_RO);
  return _chkr_acct(__name);
}

/* Make PATH be the root directory (the starting point for absolute paths).
   This call is restricted to the super-user.  */
extern int _chkr_chroot (__const char *__path);
int chroot (__const char *__path)
{
  chkr_check_str(__path, CHKR_RO);
  return _chkr_chroot(__path);
}

/* Make the block special device PATH available to the system for swapping.
   This call is restricted to the super-user.  */
extern int _chkr_swapon (__const char *__path);
int swapon (__const char *__path)
{
  chkr_check_str(__path, CHKR_RO);
  return _chkr_swapon(__path);
}

#endif /* Use BSD.  */

/* Theses are kind of Linux specific. */

#include <sys/types.h>

function_alias(ftruncate, _chkr_ftruncate, int , (__fildes, __length),
		DEFUN(ftruncat, (__fildes, __length),
			 int __fildes AND size_t __length));
/*extern int	ftruncate __P ((int __fildes, size_t __length)); */

extern int _chkr_truncate (__const char *__path, size_t __length);
int truncate (__const char *__path, size_t __length)
{
  chkr_check_str(__path, CHKR_RO);
  return _chkr_truncate(__path, __length);
}  

function_alias(ioperm, _chkr_ioperm, int , (__from, __num, __turn_on),
		DEFUN(ioperm, (__form, __num, __turn_on),
			unsigned long __from AND unsigned long __num AND int __turn_on));
/*extern int	ioperm  __P ((unsigned long __from,
			unsigned long __num, int __turn_on));*/
			
function_alias(iopl, _chkr_iopl, int , (__level),
		DEFUN(iopl, (__level),
			int __level));			
/* extern int	iopl __P((int __level)); */

function_alias(nice, _chkr_nice, int , (__val),
		DEFUN(nice, (__val),
			int __val));
/* extern int	nice __P ((int __val)); */

int profil (char *__buf, int __bufsiz, int __offset, int __scale)
{
  chkr_errno = 12;
  chkr_perror();
  chkr_abort();
  return -1;
}

extern int _chkr_ustat (dev_t __dev, struct ustat* __ubuf);
int ustat (dev_t __dev, struct ustat* __ubuf)
{
  chkr_check_addr(__ubuf, sizeof(struct ustat), CHKR_WO);
  return _chkr_ustat(__dev, __ubuf);
}  

function_alias(idle, _chkr_idle, int , (),
		DEFUN(idle, (),
			));
/* extern int	idle __P ((void));*/

function_alias(reboot, _chkr_reboot, int, (__magic, __magic_too, __flag),
		DEFUN(reboot, (__magic, __magic_too),
			int __magic AND int __magic_too AND int __flag));
/* extern int	reboot __P ((int __magic, int __magic_too, int __flag)); */

extern int _chkr_swapoff (__const char * __specialfile);
int swapoff (__const char * __specialfile)
{
  chkr_check_str(__specialfile, CHKR_RO);
  return _chkr_swapoff(__specialfile);
}

function_alias(uselib, _chkr_uselib, int, (__filename),
		DEFUN(uselib, (__filename),
			CONST chqr *__filename));
/* extern int uselib __P ((__const char *__filename)); */

extern int _chkr_setdomainname (__const char *__name, size_t __len);
int setdomainname (__const char *__name, size_t __len)
{
  chkr_check_addr(__name, __len, CHKR_RO);
  return _chkr_setdomainname(__name, __len);
}

extern int _chkr___chmod (__const char *__path, mode_t __mode);
int __chmod (__const char *__path, mode_t __mode)
{
  chkr_check_str(__path, CHKR_RO);
  return _chkr___chmod(__path, __mode);
}

function_alias(__fchmod, _chkr___fchmod, int, (__fildes, __mode),
		DEFUN(__fchmod, (__filedes, __mode),
			int __fildes AND mode_t __mode));
/* extern int	fchmod __P ((int __fildes, mode_t __mode)); */

extern int _chkr___fstat (int __fildes, struct stat *__stat_buf);
int __fstat (int __fildes, struct stat *__stat_buf)
{
  chkr_check_addr(__stat_buf, sizeof(struct stat), CHKR_WO);
  return _chkr___fstat(__fildes, __stat_buf);
}
/* extern int	fstat __P ((int __fildes, struct stat *__stat_buf)); */

extern int _chkr___mkdir (__const char *__path, mode_t __mode);
int __mkdir (__const char *__path, mode_t __mode)
{
  chkr_check_str(__path, CHKR_RO);
  return _chkr___mkdir(__path, __mode);
}
/* extern int	mkdir __P ((__const char *__path, mode_t __mode)); */

extern int _chkr___mknod (__const char *__path, mode_t __mode, dev_t __dev);
int __mknod (__const char *__path, mode_t __mode, dev_t __dev)
{
  chkr_check_str(__path, CHKR_RO);
  return _chkr___mknod(__path, __mode, __dev);
}			
/* extern int	mknod __P ((__const char *__path, mode_t __mode,
			dev_t __dev)); */

extern int _chkr___stat (__const char *__filename, struct stat *__stat_buf);
int __stat (__const char *__filename, struct stat *__stat_buf)
{
  chkr_check_str(__filename, CHKR_RO);
  chkr_check_addr(__stat_buf, sizeof(struct stat), CHKR_WO);
  return _chkr___stat(__filename, __stat_buf);
}			
/* extern int	stat __P ((__const char *__filename,
			struct stat *__stat_buf)); */

extern int _chkr___lstat (__const char *__filename, struct stat *__stat_buf);
int __lstat (__const char *__filename, struct stat *__stat_buf)
{
  chkr_check_str(__filename, CHKR_RO);
  chkr_check_addr(__stat_buf, sizeof(struct stat), CHKR_WO);
  return _chkr___lstat(__filename, __stat_buf);
}
/*extern int	lstat __P ((__const char *__filename,
			struct stat *__stat_buf)); */
			
function_alias(__umask, _chkr___umask, mode_t, (__mask),
		DEFUN(__umask, (__mask),
			mode_t __mask));
/* extern mode_t	__umask __P ((mode_t __mask)); */

extern int _chkr___statfs(__const char *__path, struct statfs *__buf);
int __statfs(__const char *__path, struct statfs *__buf)
{
  chkr_check_str(__path, CHKR_RO);
  chkr_check_addr(__buf, sizeof(struct statfs), CHKR_WO);
  return _chkr___statfs(__path, __buf);
}
/* extern int statfs __P ((__const char *__path, struct statfs *__buf)); */

extern int _chkr___fstatfs(int __fildes, struct statfs *__buf);
int __fstatfs(int __fildes, struct statfs *__buf)
{
  chkr_check_addr(__buf, sizeof(struct statfs), CHKR_WO);
  return _chkr___fstatfs(__fildes, __buf);
}
/* extern int fstatfs __P ((int __fildes, struct statfs *__buf)); */

extern int _chkr___gettimeofday (struct timeval * __tp, struct timezone * __tz);
int __gettimeofday (struct timeval * __tp, struct timezone * __tz)
{
  chkr_check_addr(__tp, sizeof(struct timeval), CHKR_WO);
  chkr_check_addr(__tz, sizeof(struct timezone), CHKR_WO);
  return _chkr___gettimeofday(__tp,__tz);
}
/* extern int	gettimeofday __P ((struct timeval * __tp,
			struct timezone * __tz)); */
extern int _chkr___settimeofday (__const struct timeval *__tv, __const struct timezone *__tz);
int __settimeofday (__const struct timeval *__tv, __const struct timezone *__tz)
{
  chkr_check_addr(__tv, sizeof(struct timeval), CHKR_RO);
  chkr_check_addr(__tz, sizeof(struct timezone), CHKR_RO);
  return _chkr___settimeofday(__tv, __tz);
}			
/* extern int	settimeofday __P ((__const struct timeval *__tv,
			__const struct timezone *__tz)); */

extern int _chkr___getitimer(int __which, struct itimerval *__value);
int __getitimer(int __which, struct itimerval *__value)
{
  chkr_check_addr(__value, sizeof(struct itimerval), CHKR_WO);
  return _chkr___getitimer(__which, __value);
}  
/* extern int	getitimer __P ((int __which,
			struct itimerval *__value)); */
			
extern int _chkr___setitimer (int __which, __const struct itimerval *__value, 
		struct itimerval *__ovalue);
int __setitimer (int __which, __const struct itimerval *__value, 
		struct itimerval *__ovalue)
{
  chkr_check_addr(__value, sizeof(struct itimerval), CHKR_RO);
  if (__ovalue)
    chkr_check_addr(__ovalue, sizeof(struct itimerval), CHKR_WO);
  return _chkr___setitimer(__which, __value, __ovalue);
}
/* extern int	setitimer __P ((int __which,
			__const struct itimerval *__value,
			struct itimerval *__ovalue)); */

extern int _chkr_getrlimit (int __resource, struct rlimit *__rlp);
int getrlimit (int __resource, struct rlimit *__rlp)
{
  chkr_check_addr(__rlp, sizeof(struct rlimit), CHKR_WO);
  return _chkr_getrlimit(__resource, __rlp);
}

extern int _chkr_setrlimit (int __resource, __const struct rlimit *__rlp);
int setrlimit (int __resource, __const struct rlimit *__rlp)
{
  chkr_check_addr(__rlp, sizeof(struct rlimit), CHKR_RO);
  return _chkr_setrlimit(__resource, __rlp);
}

extern int _chkr___getrusage (int __who, struct rusage *__rusage);
int __getrusage (int __who, struct rusage *__rusage)
{
  chkr_check_addr(__rusage, sizeof(struct rusage), CHKR_WO);
  return _chkr___getrusage(__who, __rusage);
}
/* extern int	getrusage __P ((int __who, struct rusage *__rusage)); */


function_alias(__kill, _chkr___kill, __off_t, (__pid, __sig),
		DEFUN(__kill, (__pid, __sig),
			pid_t __pid AND int __sig));		
/* extern int	__kill __P ((pid_t __pid, int __sig)); */

extern int _chkr_sigpending (sigset_t *__set);
int sigpending (sigset_t *__set)
{
  chkr_check_addr(__set, sizeof(sigset_t), CHKR_WO);
  return _chkr_sigpending(__set);
}  

extern clock_t _chkr___times (struct tms * __tp);
clock_t __times (struct tms * __tp)
{
 chkr_check_addr(__tp, sizeof(struct tms), CHKR_WO);
 return _chkr___times(__tp);
}
/* extern clock_t __times __P ((struct tms * __tp)); */

extern int _chkr___uname (struct utsname * __utsbuf);
int __uname (struct utsname * __utsbuf)
{
  chkr_check_addr(__utsbuf, sizeof(__utsbuf), CHKR_WO);
  return _chkr___uname(__utsbuf);
}
/* extern int __uname __P ((struct utsname * __utsbuf)); */

/* PID is like waitpid.  Other args are like wait3.  */
extern __pid_t _chkr___wait4 (__pid_t __pid, union __wait * __stat_loc,
			     int __options, struct rusage * __usage);
__pid_t __wait4 (__pid_t __pid, union __wait * __stat_loc,
			     int __options, struct rusage * __usage)
{			     
  if (__stat_loc)
    chkr_check_addr(__stat_loc, sizeof(union __wait), CHKR_WO);  
  if (__usage)
    chkr_check_addr(__usage, sizeof(struct rusage), CHKR_RO);
  return _chkr___wait4(__pid, __stat_loc, __options, __usage);
}

extern int _chkr_mount (__const char* __specialfile,
		__const char* __dir,__const char* __filesystemype,
			unsigned long __rwflag,__const void *__data);
int mount (__const char* __specialfile,
		__const char* __dir,__const char* __filesystemype,
			unsigned long __rwflag,__const void *__data)
{
  chkr_check_str(__specialfile, CHKR_RO);
  chkr_check_str(__dir, CHKR_RO);
  chkr_check_str(__filesystemype, CHKR_RO);
  return _chkr_mount(__specialfile, __dir, __filesystemype, __rwflag, __data);
}  
   
extern int _chkr_umount (__const char* __specialfile);
int umount (__const char* __specialfile)
{
  chkr_check_str(__specialfile, CHKR_RO);
  return _chkr_umount(__specialfile);
}

/* this is not really correct */

caddr_t mmap(caddr_t __addr, size_t __len,
		int __prot, int __flags, int __fd, off_t __off)
{
  chkr_errno = 12;
  chkr_perror();
  chkr_abort();
  return (caddr_t)-1;
}
  		
int munmap (caddr_t __addr, size_t __len)
{
  chkr_errno =12;
  chkr_perror();
  chkr_abort();
  return -1;
}

extern int _chkr_rename (__const char *__old, __const char *__new);
int rename (__const char *__old, __const char *__new)
{
  chkr_check_str(__old, CHKR_RO);
  chkr_check_str(__new, CHKR_RO);
  return _chkr_rename(__old, __new);
}

extern int _chkr_stime (time_t* __tptr);
int stime (time_t* __tptr)
{
  chkr_check_addr(__tptr, sizeof(time_t), CHKR_RO);
  return stime(__tptr);
}

extern time_t _chkr_time (time_t * __tp);
time_t time (time_t * __tp)
{
  chkr_check_addr(__tp, sizeof(time_t), CHKR_WO);
  return _chkr_time(__tp);
}  

extern int _chkr_utime (__const char *__filename, struct utimbuf *__times);
int utime (__const char *__filename, struct utimbuf *__times)
{
  chkr_check_addr(__times, sizeof(struct utimbuf), CHKR_RW);
  chkr_check_str(__filename, CHKR_RO);
  return _chkr_utime(__filename, __times);
}

extern int _chkr_vm86(struct vm86_struct * __info);
int vm86(struct vm86_struct * __info)
{
  chkr_check_addr(__info, sizeof(struct vm86_struct), CHKR_RW);
  return _chkr_vm86(__info);
}

extern int _chkr___fcntl(int fildes, int cmd, ...);
int __fcntl(int fildes, int cmd, ...)
{
	int arg1;
	va_list arg;

	va_start(arg,cmd);
	arg1 = va_arg(arg,int);
	switch(cmd)
	{
	 case F_DUPFD:
	 	break;
	 case F_GETFD:
	 case F_GETFL:
	 	chkr_check_addr((__ptr_t)arg1, sizeof(int), CHKR_WO);
	 	break;
	 case F_SETFD:
	 case F_SETFL:
	 	chkr_check_addr((__ptr_t)arg1, sizeof(int), CHKR_RO);
	 	break;
	 case F_GETLK:
	 	chkr_check_addr((__ptr_t)arg1, sizeof(struct flock), CHKR_WO);
	 	break;
	 case F_SETLK:
	 case F_SETLKW:	/* TG: what is the difference ? */
	 	chkr_check_addr((__ptr_t)arg1, sizeof(struct flock), CHKR_RO);
	 	break;
	 default:
	 	chkr_errno=12;
	 	chkr_perror();
	 	chkr_abort();
	}
	va_end(arg);
	return _chkr___fcntl(fildes, cmd, arg1);
}	
	
extern int _chkr___ioctl(int fildes, int cmd, ...);
int __ioctl(int fildes, int cmd, ...)
{
  register int res, arg1;
  va_list arg;
  switch(cmd)
  {
    case TCGETS:
      chkr_check_addr((__ptr_t)arg1, sizeof(struct termios), CHKR_WO);
      break;
    case TCSETSW:
	  case TCSETSF:	    
	  case TCSETS:
	    chkr_check_addr((__ptr_t)arg1, sizeof(struct termios), CHKR_RO);
	    break;
	  case TCGETA:
	    chkr_check_addr((__ptr_t)arg1, sizeof(struct termio), CHKR_WO);
	    break;
	  case TCSETAW:
	  case TCSETAF:	    	  
	  case TCSETA:
	    chkr_check_addr((__ptr_t)arg1, sizeof(struct termios), CHKR_RO);
	    break;
	  case TCSBRK:
	  case TCSBRKP:	  
	    chkr_check_addr((__ptr_t)arg1, sizeof(long), CHKR_RO);
	    break;	  
	  case TCFLSH:	  
	  case TCXONC:
	  case TIOCSCTTY:	  
	    chkr_check_addr((__ptr_t)arg1, sizeof(int), CHKR_RO);
	    break;
	  case TIOCEXCL:
	  case TIOCNXCL:
	  	break;
	  case TIOCGPGRP:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(pid_t), CHKR_WO);
	  	break;
	  case TIOCSPGRP:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(pid_t), CHKR_RO);
	  	break;
	  case TIOCOUTQ:
	  	chkr_check_addr((__ptr_t)arg1, 4, CHKR_WO);
	  	break;	  	
	  case TIOCSTI:
	  	break;
	  case TIOCGWINSZ:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(struct winsize), CHKR_WO);
	  	break;
	  case TIOCSWINSZ:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(struct winsize), CHKR_RO);
	  	break;
	  case TIOCMGET:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(long), CHKR_WO);
	  	break;	  
	  case TIOCMBIS:
	  case TIOCMBIC:
	  case TIOCMSET:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(long), CHKR_RO);
	  	break;	  
	  case TIOCGSOFTCAR:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(long), CHKR_WO);
	  	break;	  
	  case TIOCSSOFTCAR:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(long), CHKR_WO);
	  	break;	  
	  case FIONREAD:
	  	break;
	  case TIOCCONS:
	  	break;
	  case TIOCGSERIAL:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(struct serial_struct), CHKR_WO);
	  	break;	  
	  case TIOCSSERIAL:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(struct serial_struct), CHKR_RO);
	  	break;	  
	  case TIOCPKT:
	  case FIONBIO:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(long), CHKR_RO);
	  	break;	  		  
	  case TIOCNOTTY:
	  	break;
	  case TIOCSETD:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(long), CHKR_RO);
	  	break;	  		  
	  case TIOCGETD:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(long), CHKR_WO);
	  	break;
	  case TIOCSERCONFIG:
	  	break;
	  case TIOCSERGWILD:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(long), CHKR_WO);
	  	break;	  
	  case TIOCSERSWILD:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(long), CHKR_RO);
	  	break;	  
	  case TIOCGLCKTRMIOS:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(__ptr_t), CHKR_RO);
	  	chkr_check_addr(*((__ptr_t*)arg1), sizeof(struct termios), CHKR_RO);
	  	break;
	  case TIOCSLCKTRMIOS:
	  	chkr_check_addr((__ptr_t)arg1, sizeof(__ptr_t), CHKR_RO);
	  	chkr_check_addr(*((__ptr_t*)arg1), sizeof(struct termios), CHKR_WO);
	  	break;	  
	  case TIOCLINUX:	/* I don't really know */	  	
	  case FIONCLEX:
	  case FIOCLEX:
	  case FIOASYNC:
	  default:	/* some other ioctl are not here */
	  	chkr_errno = 12;
	  	chkr_perror();
	  	chkr_abort();	  	
  }
  va_start(arg,cmd);
  arg1 = va_arg(arg,int);
  va_end(arg);
  return _chkr___ioctl(fildes, cmd, arg1);
}

extern int _chkr___open(const char * filename, int flag, ...);
int __open(const char * filename, int flag, ...)
{
  int opt;
  va_list arg;

  chkr_check_str(filename, CHKR_RO);
  va_start(arg,flag);	
  opt = va_arg(arg,int);
  va_end(arg);	
  return _chkr___open(filename, flag, opt);
}

function_alias(setpriority, _chkr_setpriority, int, (__which, __who, __prio),
		DEFUN(setpriority, (__which, __who, __prio),
			int __which AND int __who AND int __prio));
/* extern int setpriority __P((int __which, int __who, int __prio)); */