#include <unistd.h>
#include <sys/syscall.h>

void chkr_remove_symtabfile(void);

volatile void
_exit(int exit_code)
{
/* really bad, but really useful */
  chkr_remove_symtabfile();
  __asm__ volatile ("int $0x80"::"a" (SYS_exit),"b" (exit_code):"bx");
}
