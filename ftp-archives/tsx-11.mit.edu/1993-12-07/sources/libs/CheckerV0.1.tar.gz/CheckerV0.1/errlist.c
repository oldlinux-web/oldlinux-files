/* error list of Checker.
   Copyright 1993 Tristan Gingold
		  Written August 1993 Tristan Gingold

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public License as
published by the Free Software Foundation; either version 2 of the
License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with this library; see the file COPYING.LIB.  If
not, write to the Free Software Foundation, Inc., 675 Mass Ave,
Cambridge, MA 02139, USA.

   The author may be reached (Email) at the address marc@david.saclay.cea.fr,
   or (US/French mail) as Tristan Gingold 
   			  8 rue Parmentier
   			  F91120 PALAISEAU
   			  FRANCE */

#ifndef	_MALLOC_INTERNAL
#define _MALLOC_INTERNAL
#include "malloc.h"
#endif

#include <signal.h>

void chkr_show_frames();

int chkr_errno;

int chkr_show_err_flag = 1;

const char * const chkr_errlist[]=
{
	/*  0 */	"Unknown error",
	/*  1 */	"Try to free a free block",
	/*  2 */	"Try to free a free fragment",
	/*  3 */	"This address hadn't been returned by malloc",
	/*  4 */	"Free a block which null size",
	/*  5 */	"free is called before malloc",
	/*  6 */	"Length of a red zone is bad",
	/*  7 */	"brk() was directly called",
	/*  8 */	"'bytes_per_state' is 0. Use default value",
	/*  9 */	"Memory access error",
	/* 10 */	"Internal error: bad right while checking",
	/* 11 */	"Internal error: instruction unknown",
	/* 12 */	"Internal error: can't check this syscall"
};
	
void chkr_perror()
{
 if( chkr_show_err_flag)
   (*__chkr_trap)(1,chkr_errlist[chkr_errno]);
#ifdef CHKR_SAVESTACK
 chkr_show_frames();
#endif  /* CHKR_SAVESTACK */
}

void chkr_remove_symtabfile(void);

void chkr_abort()
{
 /* bad bad */
  chkr_remove_symtabfile();
  kill(getpid(),SIGIOT);
}
