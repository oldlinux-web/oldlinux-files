/* revision.h -- define the version number
 * Copyright (C) 1992-1993 Jean-loup Gailly.
 * This is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License, see the file COPYING.
 */

#define VERSION "1.0.2"
#define PATCHLEVEL 0
#define REVDATE "10 Feb 93"

/* This version supports only decompression of old compress format: */
#ifdef LZW
#  undef LZW
#endif

/* $Id: revision.h,v 0.10 1993/01/26 19:12:42 jloup Exp $ */
