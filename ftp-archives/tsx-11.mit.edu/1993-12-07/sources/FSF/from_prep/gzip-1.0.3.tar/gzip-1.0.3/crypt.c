/* crypt.c (dummy version) -- do not perform encrytion
 * Hardly worth copyrighting :-)
 */
#ifndef lint
static char rcsid[] = "$Id: crypt.c,v 0.5 1992/12/21 18:56:56 jloup Exp $";
#endif
