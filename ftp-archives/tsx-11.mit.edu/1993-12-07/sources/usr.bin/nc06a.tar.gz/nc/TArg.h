/* TArg.h --- The argument input window class  

    Copyright (C) 1993  A.Matthias

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef _TArg_h
#define _TArg_h

#ifdef NCURSES
  #include <ncurses.hpp>
#else
  #include <curses.h>
#endif
#include "globals.h"
#include "config.h"

class TArg
  {
  private:
    WINDOW *wptr;
    char PS1 [PATH_MAX], DEFAULT [PATH_MAX];


  public:
    TArg( char* ps1, char* defaults )
      {
	wptr = newwin( 1, SCR_X, SCR_Y-6, 0 );
	setPS1( ps1, defaults );
//        raw();
	cbreak();
	echo();
	werase( wptr );
	waddstr( wptr, PS1 );
      }
    
    ~TArg()
      {
      delwin( wptr );
      }

    void show( void )
      { touchwin( wptr ); wrefresh( wptr ); }

    void prompt( void )
      { mvwaddstr( wptr, 0, 0, PS1 ); wclrtoeol( wptr ); show(); }

    // setPS1() adds a trailing separator and default info
    void setPS1( char *ps1, char* defaults )
      {
	strcpy( DEFAULT, defaults );
	sprintf( PS1, "%s [%s]%s", ps1, DEFAULT, ARG_SEPARATOR );
      }

    char* input( char* buf )
      {
      wgetstr( wptr, buf );

      // wgetstr() does *not* process backspace. It just leaves
      // control characters in buf, although you don't see them
      // on screen at first, because the tty driver interprets
      // them. But the filesystem doesn't ;-) and you get a
      // bad file name. So we must postprocess buf and interpret
      // the backspaces manually.
      
      for ( char* p=buf; *p!='\0'; p++ )
	if ( (*p==BACKSPACE_CHAR) || (*p==BACKSPACE_CHAR2) )
	  {
	  strcpy( (p-1), (p+1) );
          p = buf;
	  }
      
      if ( strcmp( buf, "" ) == 0 ) strcpy( buf, DEFAULT );
      return( buf );
      }

    WINDOW* getwptr( void )
      { return( wptr ); }

  };


#endif


