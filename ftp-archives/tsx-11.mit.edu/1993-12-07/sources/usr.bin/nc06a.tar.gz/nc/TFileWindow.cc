/* TFileWindow.cc  ---  The file window class implementation

    Copyright (C) 1993  A.Matthias

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <iostream.h>
#include <fstream.h>
#ifdef NCURSES
  #include <ncurses.hpp>
#else
  #include <curses.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>

#include "globals.h"  // Global definitions
#include "config.h"   // Site-dependent setup options
#include "TDir.h"     // Directory manager class
#include "TList.h"    // Linked list class
#include "TElem.h"    // Directory entry definition 
#include "TInfo.h"    // The "long filename"-line
#include "TFileWindow.h" // Header for file windows

  void TFileWindow::fillbuffer( void )  // fills Fname with the directory listing
    {
      char dummy[PATH_MAX];
      TElem Elem;            // One directory element
      bool isok;             // Should the processed element be shown?
      
      ifstream dirfile( dirfilename );

      if ( !dirfile )
	{ 
	  endwin(); 
	  system( "clear" );
	  cout << "Dirfile: " << dirfilename << " not accessible\n"; 
	  exit(1); 
	}

      List.wipe();   // clear list
      maxnum = 0;
      totalbytes=0;
      werase( wptr );

      dirfile >> dummy;  // "Total"-line
      dirfile >> dummy;

      while ( dirfile  )
	{
	  dirfile >> Elem.fmode;
	  dirfile >> dummy;
	  dirfile >> Elem.uname;
	  dirfile >> Elem.gname;
	  dirfile >> Elem.fsize;
	  dirfile >> dummy;
	  dirfile >> dummy;
	  dirfile >> dummy;
	  dirfile >> Elem.fname;
	  // Handle links correctly
	  if ( Elem.fmode[0] == 'l' )
	    {
	      dirfile >> dummy;    // throw "->" away
	      dirfile >> Elem.truename;    // target of link
	    }

          isok = TRUE;
          if ( (execonly == TRUE) && (strchr( Elem.fmode, 'x')==NULL ) )
            isok = FALSE;
          if ( Elem.fmode[0]=='d' ) 
            isok = TRUE; 
          // don't show "."-entry
	  if ( (strcmp( Elem.fname, "." )==0) || 
               (strcmp( Elem.fname, ""  )==0) ) 
            isok = FALSE;

	  if ( isok==TRUE ) 
            {
	    maxnum++;
            totalbytes += Elem.fsize;
            List.add( &Elem );
            }
	}      
      // We must add an empty element at the end of list
      strcpy( Elem.fname, "" );
      strcpy( Elem.fmode, "" );
      strcpy( Elem.uname, "" );
      strcpy( Elem.gname, "" );
      strcpy( Elem.truename, "" );
      Elem.fsize = 0;
      List.add( &Elem );
      maxnum-=1;
      dirfile.close();
    }

// insert() returns TRUE if the window is already filled and no more names
// are needed. It returns FALSE if there are still names needed.

  bool TFileWindow::insert( TElem *Elem, int num )
    {
      char s[PATH_MAX], tmp[PATH_MAX];

      if ( num < firstshown )
	return FALSE;
      if ( num >= firstshown+(y2-y1) )
	return TRUE;

      // fname could be longer than we can display, so we truncate
      // after the first FNAME_LEN characters
      strcpy( tmp, Elem->fname  );
      tmp[FNAME_LEN]='\0';
      if ( strcmp( tmp, Elem->fname ) != 0 ) 
	strcat( tmp, "+" );

      if ( Elem->status==NONE )
        sprintf( s, " %-15s%s %9d", tmp, Elem->fmode, Elem->fsize );
      else
        sprintf( s, "*%-15s%s %9d", tmp, Elem->fmode, Elem->fsize );
      
      strcpy( onscreen[num-firstshown], s );

      if ( num==hilight && active ) wstandout( wptr );
      mvwaddstr( wptr, num-firstshown, 0, s );
      wclrtoeol( wptr );
      if ( num==hilight && active ) wstandend( wptr );

      return FALSE;
    }

  void TFileWindow::changehilight( int oldhi, int newhi )
    {
    wstandend( wptr );
    mvwaddstr( wptr, oldhi-firstshown, 0, onscreen[oldhi-firstshown] );
    wclrtoeol( wptr );
    wstandout( wptr );
    mvwaddstr( wptr, newhi-firstshown, 0, onscreen[newhi-firstshown] );
    wclrtoeol( wptr );
    wstandend( wptr );
    wrefresh( wptr );
    }

  TFileWindow::TFileWindow( WINDOW *scr, WHICH which ) : Dir( NULL )
    { 
      std=scr;
      scrx=1; scry=1;
      scrw=SCR_X; scrh=SCR_Y;
      TFileWindow::which=which;  // Is this one correct ?
      hilight=0;
      maxnum = 0;
      firstshown = 0;
      totalbytes=0;
      execonly = FALSE;
      for ( int i=0; i<255; i++ )
	onscreen[i][0] = '\0';

      if ( which==LEFT ) 
	{
	  Dir.setdirfile( DIRFILE_L );
	  sprintf( dirfilename, "%s%s", homedir, DIRFILE_L );
	  x1=1; x2=scrw/2;
	  y1=1; y2=scrh/2+scrh/4;
	  active=TRUE;
        }
      else 
	{
	  Dir.setdirfile( DIRFILE_R );
	  sprintf( dirfilename, "%s%s", homedir, DIRFILE_R );
	  x1=(scrw/2)+1; x2=scrw;
	  y1=1; y2=scrh/2+scrh/4;
	  active=FALSE;
	}
      frameptr=newwin( y2-y1, x2-x1, y1, x1 );
      box( frameptr, FRAME_CHAR_V, FRAME_CHAR_H );
      y1++; x1++; y2--; x2--;
      wptr=newwin( y2-y1, x2-x1, y1, x1 );
      leaveok( wptr, TRUE );
      show();
    } /* end of constructor */


  // trim() truncates a pathname (oldstr) to "size" characters
  // and returns it in newstr
  char* TFileWindow::trim( char* oldstr, char* newstr, int size )
    {
    char *ptr;
    if ( strlen( oldstr ) > (unsigned)size )
      {
      ptr = &oldstr[strlen( oldstr )-size+3];
      strcpy( &newstr[3], ptr );
      for ( ptr=newstr; ptr!=&newstr[3]; ptr++ )
        *ptr = '.';
      }
    else
      {
      ptr = oldstr;
      strcpy( newstr, ptr );
      }
    return newstr;
    }


  void TFileWindow::header( void )
    { 
      char tmp[2048];

      box( frameptr, FRAME_CHAR_V, FRAME_CHAR_H );
      if ( active ) wstandout( frameptr );
      mvwaddstr( frameptr, 0, 0, trim(Dir.telldir( cwd ), tmp, 37) ); 
      if ( active ) wstandend( frameptr );
    }

  void TFileWindow::summary( void )
    { 
      char line[1024];

      if ( execonly == TRUE )
        sprintf( line, "%ld bytes in %d files (E)", totalbytes, maxnum+1 );
      else
        sprintf( line, "%ld bytes in %d files", totalbytes, maxnum+1 );

      if ( active ) wstandout( frameptr );
      mvwaddstr( frameptr, y2-1, 0, line ); 
      if ( active ) wstandend( frameptr );
    }
 
  void TFileWindow::show( void )
    { 
      header(); 
      summary();
      wrefresh( frameptr ); wrefresh( wptr ); 
    }

  void TFileWindow::showinside( void )
    {
      wrefresh( wptr );
    }


  void TFileWindow::repaint( void )
    {
      touchwin( frameptr );
      touchwin( wptr );
      show();
    }


  void TFileWindow::chdir( char *newdir )
    {
      Dir.changedir( newdir );
      Dir.telldir( cwd );
      firstshown = 0;
//      sethilight( 0 );
      totalbytes=0;
    }


  char* TFileWindow::telldir( char *dir )
    {
      return( Dir.telldir( dir ) );
    }

  void TFileWindow::fill( bool readdir )
    { 
      TElem *Elem;

      for ( int i=0; i<255; i++ )
	onscreen[i][0] = '\0';

      if ( readdir == TRUE )
	{
        Dir.writedir();  // Generate a directory listing file
	sethilight(0);   
        fillbuffer();    // and read it into the list Fname
	touchwin( frameptr );
	}

      List.rewind();

      bool full;               // Is window already full ?
      do
	{
	  Elem = List.getelem();   // Get the filenames from list
	  // and print them
	  if ( Elem != NULL ) full=insert( Elem, List.getnum() ); 

	  List.next();
	} while ( (Elem != NULL) && ( full != TRUE ) );
      
      if ( readdir == TRUE )
	show();
      else
	showinside();
    }

  char* TFileWindow::gethilightedfname( void )
    {
      return( List.getfname( hilight ) );
    }

// The difference between the following two functions is that
// gethilightedfmode(), if applied to a link, returns the modes
// of the link; gethilightedtruemode() returns the modes of the
// file or directory the link points to. If gethilightedtruemode()
// is applied to a non-link, it returns the file modes as usual.
// NOTE: 
// get...fmode() returns a string representation of permission
// flags, as they appear in an "ls -la" listing !!! 
// get...truemode() returns the st_mode field of a stat structure,
// as defined in sys/stat.h !!!

  char* TFileWindow::gethilightedfmode( void )
    {
      return( List.getfmode( hilight ) );
    }

  int TFileWindow::gethilightedtruemode( void )
    {
      struct stat sbuf;

      stat( List.getfname( hilight ), &sbuf );
      return (sbuf.st_mode);
    }


  int TFileWindow::gethilight( void )
    { return( hilight ); }

  void TFileWindow::sethilight( int value )
    { 
      int oldfirstshown, oldhilight;

      oldfirstshown = firstshown;
      oldhilight = hilight;

      if ( value >= 0 && value <= getmaxnum() ) hilight = value; 
      if ( hilight >= firstshown+(y2-y1) ) 
	{
	  if ( firstshown+((y2-y1)/2) <= getmaxnum() )
	    firstshown+=(y2-y1)/2;
	}
      if ( hilight < firstshown ) 
	{
	  if ( firstshown-((y2-y1)/2) >= 0 )
	    firstshown-=(y2-y1)/2;
	  else
	    firstshown = 0;
	}
      if ( hilight==0 ) 
	firstshown=0;
      if ( hilight==getmaxnum() )
	firstshown=getmaxnum()-((y2-y1)/2);
      if ( firstshown < 0 ) 
	firstshown=0;

      if ( oldfirstshown!=firstshown ) 
	{
	werase( wptr );
	fill( FALSE );
        }
      else
	{
	if ( oldhilight != hilight )
	  changehilight( oldhilight, hilight );

	}
    if ( LONGNAMES == 1 )
      Info.show( gethilightedfname() );
    }

  WINDOW* TFileWindow::getwptr( void )
    {
      return( wptr );
    }

  int TFileWindow::getmaxnum( void )
    { return ( maxnum ); }

  bool TFileWindow::isactive( void )
    {
      if ( active )
	return ( TRUE );
      else
	return ( FALSE );
    }

  void TFileWindow::activate( void )
    { active = TRUE; Dir.activate(); sethilight(0); fill( TRUE ); }

  void TFileWindow::inactivate( void )
    { active = FALSE; fill( TRUE ); }

  void TFileWindow::toggleentry( void )
    {
    if ( *gethilightedfmode() != 'd' )  // don't mark directories
      if ( List.getstatus( hilight ) != MARK )
        List.mark( hilight );
      else
        List.unmark( hilight );
    sethilight( hilight+1 );
    fill( FALSE );
    }  

  void TFileWindow::postprocess( void )
  // This function sets the cwd and the environment of the current shell
  // to the values generated by the subshell which executed the last
  // user command
    {
    // First we evaluate the cwd
    char line[PATH_MAX], cwdfilename[PATH_MAX];
    sprintf( cwdfilename, "%s%s", homedir, CWDFILE );
    ifstream f( cwdfilename );
    if ( !f )
      return;
    f >> line;
    f.close();
    this->chdir( line );
    }

void TFileWindow::makepfile( char *what, char *param )
  {
  char pfilename[PATH_MAX];
  TElem *Elem;  

  sprintf( pfilename, "%s%s", homedir, PARAMFILE );
  ofstream pfile( pfilename );
  if ( !pfile )
    return;
  switch( what[0] )
    {
    case 'h':
      pfile << gethilightedfname();
      break;
    case 'p':
      pfile << param;
      break;
    case 'm':
    case 'u':
      bool marked_exist = FALSE;
      List.rewind();
      do
        {
        Elem = List.getelem();
        if ( ( (Elem->status==MARK) && (what[0]=='m') ) ||
             ( (Elem->status==NONE) && (what[0]=='u') ) )
          {
          pfile << Elem->fname << ' ';
          marked_exist = TRUE;
          }
        List.next();
        }
      while ( Elem != NULL );

      // If nothing is marked, return the hilighted filename
      if ( ( marked_exist == FALSE ) && ( what[0]=='m' ) )
        pfile << gethilightedfname();

      break;
    }

  pfile.close();
  }

void TFileWindow::setexeconly( bool value )
  {
  execonly = value;
  }

bool TFileWindow::getexeconly( void )
  {
  return( execonly );
  }












