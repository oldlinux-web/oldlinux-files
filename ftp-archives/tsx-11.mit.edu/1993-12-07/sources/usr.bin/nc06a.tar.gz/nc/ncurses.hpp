
extern "C" {
#include <ncurses.h>   
}
