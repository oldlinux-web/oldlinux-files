/* TDir.h  ---  Definition and declaration of class TDir for directory
   manipulation 

    Copyright (C) 1993  A.Matthias

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/


/* ! All TDir routines are implemeted here, there is *no* TDir.cc ! */

#ifndef _TDir_h
#define _TDir_h

#include <string.h>
#include <unistd.h>

#include "globals.h" 

class TDir 
{
 private:
    char  cwd[PATH_MAX];
    char  cl[PATH_MAX];  // Command line temporary storage
    char  dirfile[PATH_MAX];

 public:
    TDir( char *dfile ) 
      { 
	strcpy( dirfile, dfile ); 
	getwd( cwd );
      }

    void setdirfile( char *dfile )
      { strcpy( dirfile, dfile ); getwd( cwd ); }

    char *telldir( char *wd ) 
      { strcpy( wd, cwd ); return( wd ); }

    bool changedir( char *dir )
      { int ret = chdir( dir ); getwd( cwd ); writedir(); return( ret ); }

    void activate( void )
      { chdir( cwd ); getwd( cwd ); writedir(); }

    void writedir()
      { 
	sprintf( cl, "ls -la > %s%s", homedir, dirfile );
	system( cl );
      }
};

#endif

