/* nc.cc  ---  Main file

    Copyright (C) 1993  Andreas Matthias
    Contact andreas_matthias@rollo.central.de
            matthias@namu01.gwdg.de
            2:241/3410.43 fidonet "classic"

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#ifdef NCURSES
  #include <ncurses.hpp>
#else
  #include <curses.h>
#endif
#include <term.h>

#include "globals.h"     // Global definitions
#include "config.h"      // Site-dependent setup options
#include "TDir.h"        // Directory manager class
#include "TList.h"       // Linked list class
#include "softlabel.h"   // Bottom line key labels 
#include "TElem.h"       // Directory entry definition 
#include "TPrompt.h"     // Command line emulation
#include "welcome.h"     // Copyright message 
#include "TFileWindow.h" // File window class
#include "THistory.h"    // History list class
#include "THistElem.h"   // One history list element
#include "readkeys.h"    // Softlabel assignment
#include "TArg.h"        // Class that prompts user for command args

// wputline() puts userline to window wptr and creates a
// softcursor at position ulpos
void wputline( WINDOW* wptr, char* userline, int ulpos )
  {
  char tmp[PATH_MAX];
  strncpy( tmp, userline, ulpos );
  tmp[ulpos]='\0';
  wprintw( wptr, "%s", tmp );
  wstandout( wptr );
  wprintw( wptr, "%c", userline[ulpos] );
  wstandend( wptr );
  if ( userline[ulpos]!='\0' )
    wprintw( wptr, "%s", &userline[ulpos+1] );
  
  }

// strinsch() inserts the character ch into string str at position pos
// str must be a valid, null-terminated string. No checking is made
// on pos, the caller has to keep it within range
void strinsch( char *str, char ch, int pos )
  {
  int len=strlen( str );
  for ( char* p=&str[len]; p!=&str[pos]; p-- )
    *p=*(p-1);
  str[pos]=(char)ch;
  str[len+1]='\0';
  }

void testterm( void )
  {
  if ( strcmp( getenv( "TERM" ), "vt100" ) != 0 )
    {
    fprintf( stderr, "Sorry, only vt100 terminals supported\n" );
    exit( 1 );
    }
  } 



int main( int argc, char *argv[] )
{
  WINDOW *std;          // The whole screen
  char *items[11];
  char *ctrl_items[] = { "Ctrl-X:", "1 ExecOnly", "2 BuildTree", "3 HexView", 
			   "4  ", 
			   "5  ", "6  ", "7  ", "8  ", "0 Tree", "" };
  char cwd[PATH_MAX];
  bool wait;            // Wait for key before return ?
  bool ul_dirty;        // userline has changed and must be repainted
  bool abortcmd;        // Don't execute the prepared command line
  int ulpos = 0;        // Position of softcursor in userline
  testterm();
  welcome();
  inithome();
  if ( readkeys() )     // Fills the global ;-) structure "action"
    {
    fprintf( stderr, "Fatal: File %s%s not found\n", homedir, KEYFILE );
    exit( 1 );
    }
  std=initscr();
  // Copy labels to expected Softlabel format
  for ( char c='1'; c<='8'; c++ ) 
    {
    items[c-'0']=new( char[11] );
    if ( action[c].defined==TRUE )
      strcpy( items[c-'0'], action[c].label );
    else 
      strcpy( items[c-'0'], " " );
    }
  items[0] =new( char[11] );
  items[9] =new( char[11] );
  items[10]=new( char[11] );  
  strcpy( items[0],  "ESC:"   );
  strcpy( items[9], "0 Quit" );
  strcpy( items[10], ""       );
  
  Softlabel Footer( items );
  TFileWindow Right( std, RIGHT ), Left( std, LEFT );  
  TFileWindow *Active, *Nonactive;
  TPrompt Prompt;
  THistory History;
  THistElem HistElem;

  leaveok( std, TRUE );

  Active = &Left;
  Nonactive = &Right;
  Left.fill( TRUE );
  Right.fill( TRUE );
  Footer.show();
  Prompt.setPS1( Active->telldir( cwd ) );
  Prompt.newprompt();

  /*** Here is the main event loop ***/
  char userline[256];
  int ch;

  do
    {
    cbreak();
    userline[0]='\0';
    strcpy( HistElem.cmd, "" );
    History.eol();             // Go to end of history list
    ulpos = 0;
    wait=TRUE;
    ul_dirty=TRUE;
    abortcmd=FALSE;

    do
      {
      if ( Left.isactive() ) 
	{
	Active=&Left;
	Nonactive=&Right;
        }
      else 
	{
	Active=&Right;
	Nonactive=&Left;
        }

      if ( ul_dirty == TRUE )
	{
        werase( Prompt.getwptr() );
#ifdef BUILTIN_PROMPT
        Prompt.setPS1( Active->telldir( cwd ) );
#endif
        Prompt.prompt();
	wputline( Prompt.getwptr(), userline, ulpos );
        Prompt.show();
	ul_dirty=FALSE;
        }
      noecho();
      ch = wgetch( Active->getwptr() );
      echo();
      
      if ( ch == TAB_CHAR )
	{
	  ul_dirty=FALSE;
	  if ( Active == &Right )
	    { 
	      Active=&Left; 
	      Nonactive=&Right; 
	      Right.inactivate(); 
	      Left.activate(); 
	    }
	  else
	    { 
	      Active=&Right; 
	      Nonactive=&Left; 
	      Left.inactivate(); 
	      Right.activate(); 
	    }
	  continue;
	}


      if ( ch == ESCAPE_CHAR )
	{
	  if ( strcmp( getenv( "TERM" ), "vt100" ) != 0 )
	    {
	      endwin();
	      fprintf( stderr, "Sorry, only vt100 terminals supported\n" );
	      exit( 1 );
	    }

	  noecho();

	  char escaped[3];
	  escaped[0] = wgetch( Active->getwptr() );

	  if (escaped[0]=='[')   // Cursor key ?
	    escaped[1] = wgetch( Active->getwptr() );
	  else                   // No, some other key
	    escaped[1] = '\0';

	  escaped[2] = '\0';
          if ( escaped[0] == '[' )  // Cursor key
	    {
	    if ( strcmp( escaped, CRSR_UP ) == 0 )
	      Active->sethilight( Active->gethilight() - 1 );
	    if ( strcmp( escaped, CRSR_DN ) == 0 )
	      Active->sethilight( Active->gethilight() + 1 );

	    ul_dirty=FALSE;

	    // If command line is empty, cursor keys are for TFileWindow,
	    // else they are for command line editing

	    if ( strcmp( escaped, CRSR_LF ) == 0 )
	      if ( strlen( userline ) == 0 )
		{
		Active->sethilight( 0 );
		ul_dirty=FALSE;
	        }
	      else   // cursor one character to the left
		{
		if (ulpos>0) ulpos--;
		ul_dirty=TRUE;
	        }

	    if ( strcmp( escaped, CRSR_RT ) == 0 )
	      if ( strlen( userline ) == 0 )
		{
		Active->sethilight( Active->getmaxnum() );
		ul_dirty=FALSE;
	        }
	      else   // cursor one character to the right
		{
		if (ulpos<(int)strlen(userline)) ulpos++;
		ul_dirty=TRUE;
	        }

	    echo();
	    } // end: Cursor key
	  else                      // A menu selection
	    {
	      bool doit = FALSE;   // doit==TRUE: Execute this line immediately
	      switch( escaped[0] )
		{
                default:
                  abortcmd=FALSE;
                  if ( action[escaped[0]].defined==TRUE )
                    {
		    doit=action[escaped[0]].doit;
		    wait=action[escaped[0]].wait;
		    if (doit==FALSE) ul_dirty=TRUE;
		    if (action[escaped[0]].needarg==TRUE) 
		      {
		      char defaults[PATH_MAX];
		      if ( action[escaped[0]].defaults == TRUE )
		        Nonactive->telldir( defaults );
		      else
		        strcpy( defaults, "" );
		      TArg Arg( action[escaped[0]].prompt, defaults );
		      Arg.show();
		      Arg.input( action[escaped[0]].arg );
		      for ( int i=0; i<(int)strlen( action[escaped[0]].arg);
			    i++ )  // User wishes to abort
		        if ( action[escaped[0]].arg[i]==ESCAPE_CHAR )
                          {
			  abortcmd=TRUE;
			  ul_dirty=TRUE;
			  doit=FALSE;
			  wait=TRUE;
			  }
                      wclear( Arg.getwptr() );
                      wrefresh( Arg.getwptr() );
		      }
		    if ( abortcmd == FALSE )
                      {
                      // Build a temporary parameter file in $HOME
                      Active->makepfile( action[escaped[0]].params,
                                         action[escaped[0]].arg );
                      switch ( action[escaped[0]].params[1] )
                        {
                        case '0':
		          sprintf( userline, "%s %s%s", 
                                   action[escaped[0]].script,
                                   homedir, PARAMFILE );
                          break;
                        case '2':
		          sprintf( userline, "%s %s%s %s", 
                                   action[escaped[0]].script,
                                   homedir, PARAMFILE,
                                   action[escaped[0]].arg );
                          break;
                        case '1':
		          sprintf( userline, "%s %s %s%s", 
                                   action[escaped[0]].script,
                                   action[escaped[0]].arg,
                                   homedir, PARAMFILE );

                          break;
                        }
                      }
                    }
		  break;

		case '0':
		  sprintf( userline, "quit" );
		  doit=TRUE;
		  wait=FALSE;
		  break;
		case 10:
		  strinsch( userline, ' ', ulpos );
		  ulpos++;
		  for ( int i=0; i<(int)strlen( Active->gethilightedfname() );
		        i++ )
		    strinsch( userline, 
			     *(Active->gethilightedfname()+i), ulpos++);
		  ul_dirty=TRUE;
		  doit=FALSE;
		  break;
		case ' ':
		  strcat( userline, " " );
		  ulpos++;
		  ul_dirty=TRUE;
		  doit=FALSE;
		  break;
		}
	      if ( doit==TRUE ) ch=10;      // Simulated return key
	      else ch=' ';
	  
	    } // end: A menu selection
	  
	  continue;
	}

      if ( ch == META_CHAR ) // Ctrl-X was pressed for other builtins
	{
	Footer.change( ctrl_items );
	ul_dirty=TRUE;
	noecho();
	ch = wgetch( Active->getwptr() );  
	echo();
	Footer.change( items );
	switch( ch )
	  {
	  case READTREE_CHAR:
	      // Some magic necessary in order to start the tree
	      // read-in in the background
	      char tmp[PATH_MAX];
	      sprintf( tmp, "%s 2>/dev/null | grep -v \"/proc/\" >%s%s &", 
                       TREECMD, homedir, TREEFILE );
	      sprintf( userline, "echo \"%s\" > %s%s", tmp, homedir, CMDFILE );
	      system( userline );
	      sprintf( userline, "chmod u+x %s%s", homedir, CMDFILE );
	      system( userline );
	      sprintf( userline, "%s%s", homedir, CMDFILE );
	      wait=FALSE;
	      ul_dirty=TRUE;
	      ch=10;
	      break;
          case HEXVIEW_CHAR:
              sprintf( userline, "%s %s | %s", HEXVIEW_CMD, 
                       Active->gethilightedfname(), PAGER );
              wait = TRUE;
              ul_dirty = TRUE;
              ch=10;
              break;
          case EXECONLY_CHAR:
              Active->setexeconly( !Active->getexeconly() );
              wait=FALSE;
              ul_dirty = TRUE;
              Active->fill(TRUE);
              break;
	  }

	continue;
	}

      if ( ch == HIST_PREV )
	{
	History.prev();
	History.getcmd( userline );
	ulpos = strlen( userline );
	ul_dirty=TRUE;
	continue;
	}

      if ( ch == HIST_NEXT )
	{
	if ( History.next() != NULL )
	  {
	  History.getcmd( userline );
	  ulpos = strlen( userline );
	  }
	else
	  {
	  strcpy( userline, "" );
	  ulpos = 0;
	  }
	ul_dirty=TRUE;
	continue;
	}

      if ( ( ch == MARK_CHAR ) && ( strlen(userline)==0 ) )
	{
	Active->toggleentry();
	continue;
	}

      if ( ch == 10 ) continue;  /* don't append CR to line */

      if ( ( (ch == BACKSPACE_CHAR) || (ch == BACKSPACE_CHAR2) )
	    && (ulpos>0) )
	{
	ul_dirty=TRUE;
	strcpy( &userline[ulpos-1], &userline[ulpos] );
	ulpos--;
	continue;
	}
      else
	if ( (ch != BACKSPACE_CHAR) && (ch != BACKSPACE_CHAR2) )
	  {
	    ul_dirty=TRUE;
	    strinsch( userline, ch, ulpos );
	    ulpos++;
	    continue;
	  }
      }
    while ( ch != 10 );

    if ( strlen( userline ) == 0 )  /* Return is for TFileWindow */
      {
 	  ul_dirty=TRUE;
	  if ( (*(Active->gethilightedfmode()) == 'd') ||
	      ( (Active->gethilightedtruemode() & S_IFDIR) == S_IFDIR ) )
	    {
	    sprintf( userline, "cd %s", Active->gethilightedfname() );
	    wait=FALSE;
	    }
	  else
	    sprintf( userline, Active->gethilightedfname() );
      }

    if ( strcmp(userline,"quit") != 0 )
      {
	Footer.hide();
	system( "clear" );
	{
	  char tmp[PATH_MAX];
	  // Save userline in history list
	  if ( ulpos!=0 )
	    {
	    strcpy( HistElem.cmd, userline );
	    History.add( &HistElem );
	    }

	  // Add cwd change checking to userline
          if ( strncmp( userline, "ncd ", 4 ) != 0 )
	    sprintf( tmp, "{ %s } ; pwd > $HOME/%s", userline, CWDFILE );
	  else
            {
            sprintf( tmp, "%s", userline );
	    wait = 0;
	    }
	  // EXECUTE THE USER COMMAND LINE
	  nocbreak();
	  system( tmp );
	  cbreak();
	}
	if (wait==TRUE)
	  {
	  cout << "\nPress a key to continue\n";
	  getch();
	  }
        Prompt.newprompt();
	Active->postprocess();
	// Now repaint everything
	system( "clear" );
	wclear( std );
	wrefresh( std );
	Active->fill( TRUE );
	Nonactive->repaint();
	Footer.show();
      }
    }
  while ( strcmp( userline, "quit" ) != 0 );

  endwin();

  // Clean up the user directory
  sprintf( userline, "rm %s%s %s%s %s%s %s%s %s%s %s%s &>/dev/null", 
	  homedir, DIRFILE_L, homedir, DIRFILE_R, 
	  homedir, CWDFILE, homedir, PS1FILE, 
	  homedir, CMDFILE, homedir, PARAMFILE );
  system( userline );

  system( "clear" );
  return 0;
}







