/* inithome.cc  ---  Attempts to find the home directory of user

    Copyright (C) 1993  A.Matthias

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 1, or (at your option)
    any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* ! Probably non-portable ! (This one is for Linux 0.99) */

#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include "globals.h"

void inithome( void )  // This one is GLOBAL !!!
  {
  strcpy( homedir, getenv( "HOME" ) );
  strcat( homedir, "/" );
  }










