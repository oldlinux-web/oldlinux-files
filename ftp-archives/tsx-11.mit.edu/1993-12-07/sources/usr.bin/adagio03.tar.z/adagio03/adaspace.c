/* adaspace.c -- free space initialization module for adagio program */

/* this file defines the maximum allowable number of notes for phase1 */
/* the number must be determined emperically because it depends upon  */
/* the amount of storage that must be left around for phase2 */

/* this should leave about 2KB free */
/**-gl #define MAXSPACE 48000**/
#define MAXSPACE 200000

/* export the free space counter */
long space = MAXSPACE;
