/* set 128 SoundBlaster voices from patches in a Glib library;
   e.g.:
	setsb default.sb
				--gl
*/
#include <stdio.h>
#include <linux/soundcard.h>
#include <fcntl.h>
#include "adagio.h"
#include "sblast.h"

int drum16[16] = {
	128, 134, 142, 131, 132, 153, 133, 144,
	136, 157, 146, 169, 174, 163, 146, 159 };

main(int argc, char *argv[])
{	int sb, f, c, n, v, bank_size;
	int first_voice = 0, num_progs = 128, num_drums = 0;
	struct sbi_instrument instr;
	struct synth_info fm_info;
	char *libname;
	char defname[80];
	char buf[52];

	strcpy(defname, SBDIR);
	strcat(defname, "/std.sb");
	if (argc < 2) libname = defname;
	else libname = argv[1];

	if ((f = open(libname, O_RDONLY, 0)) == -1) {
		fprintf(stderr,"can't find library file %s\n", libname);
		exit(1);
	}
	if ((sb=open("/dev/sequencer", O_WRONLY, 0)) == -1) {
		fprintf(stderr,"can't open sequencer device\n");
		exit(1);
	}
	if (ioctl(sb, SNDCTL_SYNTH_INFO, &fm_info) == -1) {
		fprintf(stderr,"can't get synth info\n");
		exit(1);
	}
	bank_size = fm_info.instr_bank_size;
	if (bank_size >= 128+47) {
		num_drums = 47;
	}
	else if (bank_size >= 128+16) {
		num_drums = 16;
	}

	for (v = 0; v < num_progs; v++) {
		if (read(f, buf, SBVOICESIZE) != SBVOICESIZE) {
			fprintf(stderr,"short library file\n");
			exit(1);
		}
		instr.channel = v + first_voice;
		for (n = SBOFFSET; n < SBVOICESIZE; n++)
			instr.operators[n - SBOFFSET] = buf[n];
		if (ioctl(sb, SNDCTL_FM_LOAD_INSTR, &instr) == -1) {
			fprintf(stderr,"can't load instrument %d\n", v);
			exit(1);
		}
	}


	strcpy(defname, SBDIR);
	strcat(defname, "/drums.sb");
	if (argc < 3) libname = defname;
	else libname = argv[2];

	if ((f = open(libname, O_RDONLY, 0)) == -1) {
		fprintf(stderr,"can't find library file %s\n", libname);
		exit(1);
	}
	first_voice = 128;
	num_progs = 47;

	for (v = 0; v < num_progs; v++) {
		if (read(f, buf, SBVOICESIZE) != SBVOICESIZE) {
			fprintf(stderr,"short library file\n");
			exit(1);
		}
		if (num_drums == 47) instr.channel = v + first_voice;
		else {
			for (n = 0; n < 16 && v + first_voice != drum16[n]; n++) ;
			if (n == 16) continue;
			instr.channel = n + first_voice;
		}
		for (n = SBOFFSET; n < SBVOICESIZE; n++)
			instr.operators[n - SBOFFSET] = buf[n];
		if (ioctl(sb, SNDCTL_FM_LOAD_INSTR, &instr) == -1) {
			fprintf(stderr,"can't load instrument %d\n", v);
			exit(1);
		}
	}
}

