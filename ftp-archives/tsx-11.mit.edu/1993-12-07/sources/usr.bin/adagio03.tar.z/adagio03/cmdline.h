boolean cl_init();
char *cl_option();
char *cl_noption();
boolean cl_switch();
char *cl_nswitch();
char *cl_arg();
