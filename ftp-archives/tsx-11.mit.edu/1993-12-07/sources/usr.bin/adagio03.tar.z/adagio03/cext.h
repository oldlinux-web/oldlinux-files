/* cext.h -- extensions to c */

#define true 1
#define false 0
#define private static
#define boolean int
#define byte unsigned char
