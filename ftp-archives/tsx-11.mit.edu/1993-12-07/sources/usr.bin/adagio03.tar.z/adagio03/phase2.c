/* phase2.c -- this module plays notes compiled and sorted in phase1 or phasem */

#include <stdio.h>
#include <ctype.h>
#include <malloc.h>
#include "cext.h"
#include "adagio.h"
#include "userio.h"
#include "cmdline.h"
#include "pitch.h"
#include "midicode.h"
#include "midi.h"
#include "midifile.h"
#include "sblast.h"
#include "drum.h"
#include <linux/soundcard.h>
#include <fcntl.h>

#define MAXTIME 10000000

extern boolean verbose;

#define n_t_sw 2
private char *t_switches[n_t_sw] = { "-t", "-trace" };
#define n_m_sw 2
private char *m_switches[n_m_sw] = { "-m", "-midi" };
#define n_e_sw 2
private char *e_switches[n_e_sw] = { "-e", "-external" };
#define nmsw 2
private char *msw[nmsw] = { "-i", "-init" };
private boolean initflag = false;
private boolean extflag = false;
extern int percsel;
extern boolean drum_mode;
private boolean v_drum = true;
private boolean use_damper = false;
extern boolean recording_track;
private int recording_channel = 1;
private int recording_program = 0;

private unsigned long time = 0;	/* time clock */
private unsigned long sb_time = 0; /* time clock */
private unsigned long lasttime = 0;	/* time clock */
private boolean readable = false;

private int stat_cell_on = 0;
private int stat_cell_off = 0;
private int stat_imp_cell_off = 0;
private int stat_not_cell_off = 0;

private int user_scale = false; /* true if user-defined scale */
private int bend[num_voices];	/* current pitch bend on channel */
private pitch_table pit_tab[128];	/* scale definition */

private char sblast = true;
/****************************************************************************
* Routines local to this module
****************************************************************************/
private	void	off_init();
private void	tuninginit();
private void	read_tuning();
private	boolean	note_offs();
private long	next_off();
private	void	off_schedule();
private void	f_note();
private void	f_touch();
private void	f_program();
private void	f_ctrl();
private void	f_bend();


static int sb;
static unsigned char sbbuf[408];
static int sbptr = 0;
static int num_cells, perc_mode, bank_size;
struct synth_info fm_info;
static int d_dur[256];
static int dnote[256];
#ifdef XVOICE
static int xvoice[256];
#endif

private void midisync(void);
private void fm_program(int,int,int);
private void fm_noteon(int,int,int,int,int,unsigned long);
private void fm_noteoff(int,int,int,int,unsigned long);
private int new_cell(unsigned long, int, int);
#ifdef MIDIIN
private void	listen();
private int	midigetc(void);
private int	midipending(void);
private void	midimessage();
#endif

#define SBMONWAIT 20
#define SBOUTCHUNK 64

void sbflush(void)
{	int room, lastroom;
	int count = SBMONWAIT;

	if (!sbptr) return;
	while ( (room=ioctl(sb,SNDCTL_SEQ_GETOUTCOUNT,0)) - (sbptr/4) < 240) {
		if (count == SBMONWAIT) lastroom = room;
		usleep(100000);
		if (count-- == 0) {
			/*printf("waited 4s, room=%d, sbptr=%d, time=0x%08x\n", room, sbptr, time);*/
			if (room > lastroom) count = SBMONWAIT;
			else if (room < sbptr/4) {
				printf("potential overflow - exiting (sorry)\n");
				(void)ioctl(sb, SNDCTL_SEQ_RESET, 0);
				exit(1);
			}
			else  break;
		}
#ifdef MIDIIN
		listen();
#endif
	}

	if (write(sb, sbbuf, sbptr) == -1) {
		perror("write sb");
		exit(-1);
	}
	sbptr=0;
}

void sbwrite(char *msg)
{
	if (sbptr>=SBOUTCHUNK) sbflush();

	memcpy(&sbbuf[sbptr], msg, 4);
	sbptr +=4;
}

void sb_resync()
{	char buf[4];
	buf[0] = SEQ_SYNCTIMER;
	sbwrite(buf);
	sbflush();
	sb_time = 0;
}

void midich(char c)
{
	char buf[4];

	buf[0] = 5;
	buf[1] = c;
	sbwrite(buf);
}

#ifdef MIDIIN
int inonenb()
{
	/*usleep(10000);*/
	if (!midipending()) {
		usleep(100000);
		if (!midipending()) {
			usleep(1000000);
			if (!midipending()) return(-1);
		}
	}
	return((midigetc()&0xff));
}
#endif

extern struct sub_type{
	char *vname;
	char solo;
	char newv;
	char transpose;
} sub_voice[];

extern char *sysex[];

extern int ext_program[];
extern int ext_chan[];
extern int ext_pan[];
private int main_volume[num_voices] =
	{ 90, 90, 90, 90, 90, 90, 90, 90,
	  90, 90, 90, 90, 90, 90, 90, 90 };
private int expression[16] =
	{ -1, -1, -1, -1, -1, -1, -1, -1,
	  -1, -1, -1, -1, -1, -1, -1, -1 };

#ifdef K1
/* form of a multi patch on the Kawai K1 */
struct patch_multi {
	char name[10];
	char volume;
	char single[8];
	char zonelow[8];
	char zonehigh[8];
	char poly[8];
	char rcvchan[8];
	char transpose[8];
	char tune[8];
	char level[8];
	char checksum;
} patch = {
	'M','i','s','c',' ',' ',' ',' ',' ',' ',
	99,
	0,1,2,3,4,5,6,7,
	0,0,0,0,0,0,0,0,
	127,127,127,127,127,127,127,127,
	0x10, 0x50, 0x50, 0x50, 0x50, 0x50, 0x50, 0x50,
	0x40, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
	24,24,24,24,24,24,24,24,
	50,50,50,50,50,50,50,50,
	100,100,100,100,100,100,100,100,
	0x74
};

/* send intro to K1 sysex command */
void
k1send1(function, voice)
{
	midich(0xf0);
	midich(0x40);		/* Kawai id */
	midich(0x00);		/* channel = 0 to 15 */
	midich(function);	/* function */
	midich(0x00);		/* group */
	midich(0x03);		/* machine id number of K1 */
	midich(0x00);		/* subcommand 1 = internal */
	midich(voice);	/* subcommand 2 = voice/program */
}

/* byte to K1 and update checksum */
void
mchk(c)
int c;
{
	midich(c);
	patch.checksum += c & 0x7f;
}

/* k1msone - send a single voice to the K1 */
void
k1msone(iv)
int iv;
{
	int n;

	k1send1(0x20, iv);
	patch.checksum = 0xa5;

	for (n = 0; n < 10; n++) mchk(patch.name[n]);
	mchk(patch.volume);
	for (n = 0; n < 8; n++) mchk(patch.single[n]);
	for (n = 0; n < 8; n++) mchk(patch.zonelow[n]);
	for (n = 0; n < 8; n++) mchk(patch.zonehigh[n]);
	for (n = 0; n < 8; n++) mchk(patch.poly[n]);
	for (n = 0; n < 8; n++) mchk(patch.rcvchan[n]);
	for (n = 0; n < 8; n++) mchk(patch.transpose[n]);
	for (n = 0; n < 8; n++) mchk(patch.tune[n]);
	for (n = 0; n < 8; n++) mchk(patch.level[n]);
	midich(patch.checksum & 0x7f);
	midich(MIDI_EOX);

}
#endif

private void card_init();
private void lib_init();
private void voices_init();
private void channel_init();
private void play_score();

private event_type the_score;

FILE *fp;
myputc(c) { return(putc(c,fp));}

int mywritetrack(track)
int track;
{
	play_score();
	return(1);
}

/****************************************************************************
*				    phase2
* Inputs:
*	event_type root: Root of play list
* Effect: 
*	Plays the music
****************************************************************************/

void phase2(score)
	event_type score;
{	char *recording_parms = cl_option("-r");

	readable = (cl_nswitch(t_switches, n_t_sw) != NULL);
	sblast = (cl_nswitch(m_switches, n_m_sw) == NULL);
	if (!sblast) extflag = false;
	else extflag = (cl_nswitch(e_switches, n_e_sw) == NULL);
	if (extflag) sblast = true;
	if (readable) sblast = false;
	initflag = (cl_nswitch(msw, nmsw) == NULL);
	if (cl_switch("-s")) use_damper = true;
	if (recording_track) {
		int i;
		recording_channel = atoi(recording_parms);
		for (i = 0; recording_parms[i] != '\0' && recording_parms[i] != ','; i++) ;
		if (recording_parms[i] == ',') recording_program =
			atoi(recording_parms + i + 1);
		if (verbose) printf("recording program %d!\n", recording_program);
		if (recording_channel < 1 || recording_channel > 16)
			recording_channel = 1;
		if (recording_program < 0 || recording_program > 127)
			recording_program = 0;
		if (verbose) printf("recording program is #%d\n", recording_program);
	}

	off_init();
	tuninginit();  
	if (sblast) card_init();
	if (sblast) lib_init();
	voices_init();
	sb_resync();
	channel_init();
	the_score = score;

	if (recording_track) {
		Mf_putc = myputc;
		Mf_writetrack = mywritetrack;
		if((fp = fopen("mpout.mid","w")) == 0L)
			exit(1);
		mfwrite(0, 1, Mf_division, fp);
	}
	else play_score();

	if (verbose) {
/*
		printf("\t%d cells allocated\n", stat_cell_on);
		printf("\t%d cells deallocated\n", stat_cell_off);
		printf("\t%d cells implicitly deallocated\n", stat_imp_cell_off);
		printf("\t%d cells not turned off\n", stat_not_cell_off);
*/
		printf("\n%d SB notes terminated due to conflicts.\n", stat_imp_cell_off);
	}
}


void card_init()
{
	char buf[4];
#ifdef MIDIIN
	if ((sb=open("/dev/sequencer", O_RDWR, 0))==-1) {
#else
	if ((sb=open("/dev/sequencer", O_WRONLY, 0))==-1) {
#endif
		perror("/dev/sequencer");
		exit(-1);
	}
	(void)ioctl(sb, SNDCTL_SEQ_RESET, 0);

	if (drum_mode)
	if (ioctl(sb, SNDCTL_SEQ_PERCMODE, 1) == -1) {
		perror("/dev/sequencer");
		exit(-1);
	}

	if (ioctl(sb, SNDCTL_SYNTH_INFO, &fm_info) == -1) {
		perror("/dev/sequencer");
		exit(-1);
	}

	num_cells = fm_info.nr_voices;
	perc_mode = fm_info.perc_mode;
	bank_size = fm_info.instr_bank_size;
/*TEST how it works with small instrument bank*/
/*bank_size = 128+16;*/
	/* and if card does not support drum mode, make sure not
	 * to use any percussion channels
	 */
	if (!drum_mode) perc_mode = 0;
	else if (!perc_mode) percsel = 0;

	if (verbose) printf("%d SB voices, %d instruments, %susing percussion mode.\n",
		num_cells, bank_size, perc_mode? "" : "not ");
}

private int subdrum16[16] = {
	128, 134, 142, 131, 132, 153, 133, 144,
	136, 157, 146, 169, 174, 163, 146, 159 };

void lib_init()
{	char libname[80];
	int n, v, f, num_drums;
	int first_voice = 128;
	struct sbi_instrument instr;
	char buf[SBVOICESIZE];

	strcpy(libname, SBDIR);
	strcat(libname, "/drums.sb");
	if (bank_size >= 128+47)  num_drums = 47;
	else if (bank_size >= 128+16) num_drums = 16;
	else {
		fprintf(stderr,"not enough instruments in banksize of %d\n", bank_size);
		v_drum = false;
		num_drums = 0;
		return;
	}
	if ((f = open(libname, O_RDONLY, 0)) == -1) {
		if (verbose) fprintf(stderr,"can't find %s library file\n", libname);
		return;
	}
	for (v = 0; v < 47; v++) {
		if (read(f, buf, SBVOICESIZE) != SBVOICESIZE) {
			if (verbose) fprintf(stderr,"%s is a short library file\n", libname);
			close(f);
			return;
		}
		if (num_drums == 47) instr.channel = v + first_voice;
		else {
			for (n = 0; n < 16 && v + first_voice != subdrum16[n]; n++) ;
			if (n == 16) continue;
			instr.channel = n + first_voice;
		}
		for (n = SBOFFSET; n < SBVOICESIZE; n++)
			instr.operators[n - SBOFFSET] = buf[n];
		if (ioctl(sb, SNDCTL_FM_LOAD_INSTR, &instr) == -1) {
			if (verbose) fprintf(stderr,"can't load instrument %d\n", v);
			close(f);
			return;
		}
		if (num_drums == 47) {
			d_dur[instr.channel] = buf[33];
#ifdef XVOICE
			xvoice[instr.channel] = buf[34];
#endif
			dnote[instr.channel] = buf[35];
		}
	}
	close(f);
	strcpy(libname, SBDIR);
	strcat(libname, "/std.sb");
	if ((f = open(libname, O_RDONLY, 0)) == -1) {
		if (verbose) fprintf(stderr,"can't find %s library file\n", libname);
		return;
	}
	for (v = 0; v < 128; v++) {
		if (read(f, buf, SBVOICESIZE) != SBVOICESIZE) {
			if (verbose) fprintf(stderr,"%s is a short library file\n", libname);
			close(f);
			return;
		}
		d_dur[v] = buf[33];
#ifdef XVOICE
		xvoice[v] = buf[34];
#endif
		dnote[v] = buf[35];
	}
	close(f);
}

void voices_init()
{   int n;

    for (n = 0; n < num_voices; n++) {
	int v;
	if (!extflag) ext_chan[n] = 0;
	/* "ext_program" has the first program requested for each
	 * channel, or else -1 or 0 if there was no program request
	 * (0 if notes were played on the channel)
	 */
	v = program[n] - 1;
	/* if notes were played but there was no program request, use
	 * program 0, Ac. Gr. Piano, as default
	 */
	if (program[n] == 0) v = 0;
	if (PERCCHAN(n) && v >= 0) {
		if (verbose) {
		    printf("  channel %2d: SB percussion", n+1);
		    if (program[n] > 0) printf(" (%s[%d] request ignored)",
			sub_voice[program[n]-1].vname, program[n]-1);
		    printf(".\n");
		}
	}
	else if (sysex[n] != NULL) {
		int i;
		struct sbi_instrument instr;

		program[n] = 240+n+1;
		instr.channel = 240+n;
		for (i = SBOFFSET; i < SBVOICESIZE; i++)
			instr.operators[i - SBOFFSET] = sysex[n][i+8];
		if (ioctl(sb, SNDCTL_FM_LOAD_INSTR, &instr) == -1) {
			fprintf(stderr,"can't load instrument\n");
			exit(1);
		}
		if (verbose) printf("  channel %2d: sysex %s\n", n+1, sysex[n]+4+8);
	}
#ifdef K1
	/* which channels shall we send out to the K1? none if the -e flag
	 * was given (extflag is 0), no more than the max (etot keeps track),
	 * and not for a timbre the K1 doesn't have (marked -1 in the array in
	 * vname.h)
	 */
	else if (ext_chan[n]) {
		static char *pan[3] = { "right", "center", "left" };
		int etot = ext_chan[n] - 1;
		int leftright = 1;
		int solo = 0;
		int kbmode = etot? 1 : 2;
		if (ext_pan[n] != -1) {
			if (ext_pan[n] < 64) leftright = 2;
			else if (ext_pan[n] > 64) leftright = 0;

		}
		v = ext_program[etot] - 1;
		/*if (sub_voice[v].solo) solo = 2;*/
		patch.poly[etot] = solo | ((kbmode&1) << 6) | (leftright << 4);
		/*patch.rcvchan[etot] = (0x3f&patch.rcvchan[etot]) | ((kbmode&2) << 5);*/
		/* use transposition marked in vname.h */
		patch.transpose[etot] = sub_voice[v].transpose + 24;
		/* finally, the voice/timbre for the section */
		patch.single[etot] = sub_voice[v].newv;
		if (verbose) {
			printf("  channel %2d: %s[%d] %sto K1 channel %d at %s.\n", n+1,
				sub_voice[v].vname, v, sub_voice[v].solo? "":"(poly) ",
				etot+1, pan[leftright]);
			if (program[n]>0 && v != program[n]-1)
				printf("   (also %s[%d], etc. to SB)\n",
					sub_voice[program[n]-1].vname, program[n]-1);
		}
	}
#else
	else if (ext_chan[n] && v >= 0) {
		if (verbose) printf("  channel %2d: %s[%d] external.\n", n+1,
			sub_voice[v].vname, v);
	}
#endif
	else if (program[n] > 0) {
		if (verbose) {
		    printf("  channel %2d: is %s[%d] etc. on SB.\n", n+1,
			sub_voice[program[n]-1].vname, program[n]-1);
		}
	}
    }

    if (recording_track) {
#ifdef K1
/* The first channel has been reserved for the player; initialize
 * it now to respond to the keyboard and use the program specified
 * on the command line, if any.  Tone down the volume a little.
 */
	int kbmode = 0;
	int prog = sub_voice[recording_program].newv;
	if (prog < 0) prog = 0;
	patch.single[0] = prog;
	patch.rcvchan[0] = (0x3f&patch.rcvchan[0]) | ((kbmode&2) << 5);
	patch.poly[0] = 0 | ((kbmode&1) << 6) | (1 << 4);
	patch.transpose[0] = sub_voice[recording_program].transpose + 24;
	patch.level[0] = 90;
#else
	f_program(recording_channel, 1, recording_program);
#endif
    }

#ifdef K1
    if (extflag) {
    /* I have had a hell of a time getting the K1 to accept and use a patch;
     * the following uses up so much time waiting that the SB sequencer has
     * to be reset -- and it works only 9 times out of 10
     */
#ifdef MIDIIN
	unsigned char k1ack[7] = { 0xf0, 0x40, 0x00, 0x40, 0x00, 0x03, 0xf7 };
	int n = 0, tries = 5;

    while (tries--) {
#endif
	k1msone(64);
	sbflush();
	usleep(100000);
#ifdef MIDIIN
	if (readable) printf("  (k1 answering: ");
	for (n = 0; n < 7; n++) {
		int c = inonenb();
		if (c == MIDI_CTRL) {
			(void)inonenb(); (void)inonenb();
			c = inonenb();
		}
		if (c == -1) {
			if (verbose)
			printf("timed out waiting for k1 to acknowledge patch\n");
			break;
		}
		if (readable) printf(" 0x%02x", c);
		if (c != k1ack[n]) {
			if (verbose)
			printf("k1 did not correctly acknowledge my patch on try %d\n", 5-tries);
			/*(void)ioctl(sb, SNDCTL_SEQ_RESET, 0);*/
			break;
		}
	}
	if (readable) printf(")\n");
	if (n == 7) break;
	if (!tries) {
		printf("cannot send patch to k1\n");
		/*(void)ioctl(sb, SNDCTL_SEQ_RESET, 0);*/
		exit(1);
	}
	else {
		usleep(100000);
		while (midipending()) (void)midigetc();
	}
    }
#endif
	midich(PROGRAM + 0);
	midich(64);
	sbflush();
	usleep(200000);
#ifdef MIDIIN
	while(midipending()) {
		int c = midigetc();
		if (verbose) printf(" k1 says 0x%02x for some reason\n", c);
	}
#endif
    }
#endif
}


void channel_init()
{   int i;

    /* Initialize all midi channels with reasonable start values: */
    for (i = 1; i <= num_voices; i++) {
	int d = ext_chan[i-1];
	program[i-1] = ext_program[i-1];
	if (program[i-1] <= 0) ext_program[i-1] = program[i-1] = 1;
	bend[i-1] = 1 << 13;
	if (!initflag) continue;
	f_program(d, i, program[i-1]);
	f_bend(d, i, 1 << 13);
	f_touch(d, i, 0);
	f_ctrl(d, i, PORTARATE, 99);
	f_ctrl(d, i, PORTASWITCH, 0);
	f_ctrl(d, i, MODWHEEL, 0);
	f_ctrl(d, i, FOOT, 99);
	f_ctrl(d, i, VOLUME, 116);
	if (d) continue;
	f_program(0, i, program[i-1]);
	f_bend(0, i, 1 << 13);
	f_touch(0, i, 0);
	f_ctrl(0, i, PORTARATE, 99);
	f_ctrl(0, i, PORTASWITCH, 0);
	f_ctrl(0, i, MODWHEEL, 0);
	f_ctrl(0, i, FOOT, 99);
	f_ctrl(0, i, VOLUME, 116);
    }
}

#ifdef MIDIIN

unsigned long getdelta()
{	static double last_ticks = 0;
	double ticks = ((double)sb_time * 10000 * (double)Mf_division) / (double)Mf_currtempo;
	unsigned long delta_ticks = (unsigned long)(ticks - last_ticks);
	last_ticks = ticks;
	return(delta_ticks);
}

void listen()
{
    while (midipending()) {
	if (recording_track) midimessage();
	else (void)midigetc();
    }
}
#endif

void play_score()
{   event_type event;

    event = the_score;

#ifdef MIDIIN
    if (recording_track) {
	unsigned char data[4];
	(void)mf_write_tempo(0, Mf_currtempo);
	data[0] = recording_program;
	(void)mf_write_midi_event(getdelta(),program_chng,recording_channel-1,data,1);
    }
#endif

    while (event != NULL) { /* play it, Sam */
	int d = event->ndest;
	int chan = event->nvoice;
	if (!ext_chan[chan]) d = 0;
	time = event->ntime;
	note_offs(time);
#ifdef MIDIIN
	listen();
#endif

	if (is_note(event)) { /* play a note */
		int prog = event->u.note.nprogram;
		int pitch = event->u.note.npitch;
		int vel = event->u.note.nloud;
		int dur = event->u.note.ndur;

		if (!d && !perc_mode && d_dur[prog-1]) dur = d_dur[prog-1];
		if (!d && !PERCCHAN(chan) && dnote[prog-1]) pitch = dnote[prog-1];

		/* check for correct program (preset) */
		if (prog != program[chan]) {
			f_program(d, chan+1, prog);
			 program[chan] = prog;
		}
		/* if it is a note (not a rest) play it */
		if (pitch != NO_PITCH) {
			int cell = 0;
			if (!d) cell = new_cell(time, chan, pitch);
			if (cell == -1) {
				event = event->next;
				continue;
			}
			f_note(d, chan+1, cell, pitch, vel, time);
			off_schedule(d, time + dur, chan, cell, pitch, time);
#ifdef XVOICE
			if (!d) {
			  int xprogram = xvoice[prog-1];
			  if (xprogram) {
			    cell = new_cell(time, chan, pitch);
			    if (cell == -1) {
				event = event->next;
				continue;
			    }
			    f_program(d, chan+1, xprogram);
			    f_note(d, chan+1, cell, pitch, vel, time);
			    off_schedule(d, time + dur, chan, cell, pitch, time);
			    f_program(d, chan+1, prog);
			  }
			}
#endif
		}
	} else {	/* send control info */
		switch (vc_ctrl(chan)) {
			case 1: f_ctrl(d, vc_voice(chan) + 1,
					     PORTARATE,
					     event->u.ctrl.value);
				break;
			case 2: f_ctrl(d, vc_voice(chan) + 1,
					     PORTASWITCH,
					     event->u.ctrl.value);
				break;
			case 3: f_ctrl(d, vc_voice(chan) + 1,
					     MODWHEEL,
					     event->u.ctrl.value);
				break;
			case 4: f_touch(d, vc_voice(chan) + 1,
					   event->u.ctrl.value);
				break;
			case 5: if (use_damper) f_ctrl(d, vc_voice(chan) + 1,
					     FOOT,
					     event->u.ctrl.value);
				break;
			case 6: f_bend(d, vc_voice(chan) + 1,
					  event->u.ctrl.value << 6);
				break;
			/* when d=0 should I also set volume external channel? */
			case 7: f_ctrl(d, vc_voice(chan) + 1,
					     VOLUME,
					     event->u.ctrl.value);
				main_volume[vc_voice(chan)] =
					     event->u.ctrl.value;
				break;
			case 8: f_ctrl(d, vc_voice(chan) + 1,
					     PAN,
					     event->u.ctrl.value);
				break;
			case 9: f_ctrl(d, vc_voice(chan) + 1,
					     EXPRESSION,
					     event->u.ctrl.value);
				expression[vc_voice(chan)] =
					     event->u.ctrl.value;
				break;
			/* pass through any other controls */
			case 15: f_ctrl(d, vc_voice(chan) + 1,
					     event->u.ctrl.control,
					     event->u.ctrl.value);
				break;
			default: break;
		}
	}

	event = event->next;
    } /* play it, Sam */

    note_offs(MAXTIME);
    if (sblast) {
	sbflush();
#ifdef MIDIIN
	listen();
	if (recording_track) {
		int room;
		while ( (room=ioctl(sb,SNDCTL_SEQ_GETOUTCOUNT,0))  < 512) {
			usleep(100000);
			listen();
		}
		(void)mf_write_meta_event(getdelta(),end_of_track,NULL,0);
	}
#endif
	/*sb_resync();*/
    }
}


/* noteoff.c -- this module keeps track of pending note offs for adagio */

/*****************************************************************************
*	    Change Log
*  Date	    | Change
*-----------+-----------------------------------------------------------------
* 31-Dec-85 | Created changelog
* 31-Dec-85 | Add c:\ to include directives
*  1-Jan-86 | Declare malloc char * for lint consistency
* 21-Jan-86 | note_offs can now turn off more than one note per call
*****************************************************************************/


/* off_type is a structure containing note-off information */

typedef struct off_struct {
    unsigned long when;
    int voice;
    int pitch;
    int dest;
    int cell;
    unsigned long stime;
    struct off_struct *next;
} *off_type;

private off_type free_off;		/* free list of off_type structures */
private off_type off_events = NULL;	/* active list */

/****************************************************************************
*	Routines declared in this module
****************************************************************************/

private off_type	off_alloc();
private void		off_free();

/****************************************************************************
*				note_offs
* Inputs:
*	long time: the current time
* Outputs:
*	return true if off list has more notes 
* Effect: turn off notes if it is time 
* Assumes:
* Implementation:
*	Find scheduled note off events in off_events, compare with time
****************************************************************************/

private boolean note_offs(mtime)
unsigned long mtime;
{
    off_type temp;
    while (off_events != NULL && (time=off_events->when) <= mtime) {
	f_note(off_events->dest, (off_events->voice) + 1,
		off_events->cell, off_events->pitch, 0, off_events->stime);
	temp = off_events;
	off_events = off_events->next;
	off_free(temp);
    }
    if (mtime < MAXTIME) time = mtime;
    return (off_events != NULL);
}

/****************************************************************************
*				off_alloc
* Outputs:
*	returns off_type: an allocated note off structure
* Effect:
*	allocates a structure using malloc
****************************************************************************/

private off_type off_alloc()
{
    return (off_type) malloc(sizeof(struct off_struct));
}

/****************************************************************************
*				off_free
* Inputs:
*	off_type off: a structure to deallocate
* Effect: 
*	returns off to freelist
****************************************************************************/

private void off_free(off)
    off_type off;
{
    off->next = free_off;
    free_off = off;
}

/****************************************************************************
*				off_init
* Effect: initialize this module
* Assumes:
*	only called once, otherwise storage is leaked
****************************************************************************/

private void off_init()
{
    int i;
    for (i = 0; i < 50; i++) off_free(off_alloc());
}

/****************************************************************************
*				off_schedule
* Inputs:
*	long offtime: time to turn note off
*	int voice: the midi channel
*	int pitch: the pitch
* Effect: 
*	schedules a note to be turned off
* Assumes:
*	note_offs will be called frequently to actually turn off notes
****************************************************************************/

private void off_schedule(dest, offtime, voice, cell, pitch, stime)
    unsigned long offtime;
    int dest, voice, cell, pitch;
    unsigned long stime;
{
    off_type off, ptr, prv;
    /* allocate off */
    if ((off = free_off) == NULL) {
	off = off_alloc();
    } else free_off = off->next;

    if (off == NULL) {
	fprintf(stderr, "out of space for note off events");
	exit(1);
    }

    off->when = offtime;
    off->voice = voice;
    off->pitch = pitch;
    off->dest = dest;
    off->cell = cell;
    off->stime = stime;
    /* insert into list of off events */
    ptr = off_events;
    if (ptr == NULL || offtime <= ptr->when) {
	off->next = ptr;
	off_events = off;
    } else {
	while (ptr != NULL && offtime > ptr->when) {
	    prv = ptr;
	    ptr = ptr->next;
	}
	prv->next = off;
	off->next = ptr;
    }
/*
 *    printf("off_schedule(%ld, %d, %d): \n", offtime, voice, pitch);
 *    for (ptr = off_events; ptr != NULL; ptr = ptr->next) {
 *	printf("    %ld: %d, %d\n", ptr->when, ptr->voice, ptr->pitch);
 *    }
 */
}

AWriteVarLen (value)
register long value;
{
	register long buffer;

	buffer = value & 0x7f;
	while ((value >>= 7) > 0)
	{
		buffer <<= 8;
		buffer |= 0x80;
		buffer += (value & 0x7f);
	}

	while (true)
	{
		putchar(buffer);
		if (buffer & 0x80)
			buffer >>= 8;
		else
			break;
	} 
}

deltatime()
{
	float csecs = (float)(time - lasttime);

	AWriteVarLen( (long)(((csecs * 10.0) / 4.0 * 96) / 120) );
	lasttime = time;
}

/****************************************************************************
*				   f_note
* Inputs:
*	int channel: midi channel on which to send data
*	int pitch: midi pitch code
*	int velocity: velocity with which to sound it (0=> release)
* Effect: 
*	Prints a midi note-play request out
****************************************************************************/

private void f_note(d, channel, cell, pitch, velocity, stime)
    int d, channel, cell, pitch, velocity;
    unsigned long stime;
{
    if (readable)
    printf("Time=%d  Note %s, chan=%d pitch=%d vol=%d\n",
	    time, velocity? "on":"off", channel, pitch, velocity);
    else if (sblast) fm_noteon(d, channel-1, cell, pitch, velocity, stime);
    else {
	deltatime();
	putchar(NOTEON + channel - 1);
	putchar(pitch);
	putchar(velocity);
    }

    if (user_scale) {
	/* check for correct pitch bend */
	if ((pit_tab[pitch].pbend != bend[MIDI_CHANNEL(channel)]) &&
	    (velocity != 0)) {
	    f_bend(d, channel, pit_tab[pitch].pbend);
	    bend[channel] = pit_tab[pitch].pbend;
	}
	pitch = pit_tab[pitch].ppitch;
    }
}

/****************************************************************************
*				   f_bend
* Inputs:
*	int channel: midi channel on which to send data
*	int value: pitch bend value
* Effect: 
*	Prints a midi pitch bend message
****************************************************************************/

private void f_bend(d, channel, value)
    int d, channel, value;
{
    if (readable)
	printf("Time=%d  Pitchbend, chan=%d value=%d\n",
		time, channel, value);
    else if (sblast) {
	if (d) {
		midisync();
		midich(PITCHBEND + d - 1);
		midich(value & 0x7f);
		midich((value>>7) & 0x7f);
	}
    }
    else {
	deltatime();
	putchar(PITCHBEND + channel - 1);
/* are these bytes in right order? */
	putchar(value & 0x7f);
	putchar((value>>7) & 0x7f);
    }

	bend[MIDI_CHANNEL(channel)] = value;
}

/****************************************************************************
*				   f_ctrl
* Inputs:
*	int channel: midi channel on which to send data
*	int control: control number
*	int value: control value
* Effect: 
*	Prints a midi control change message
****************************************************************************/

private void f_ctrl(d, channel, control, value)
    int d, channel, control, value;
{
    if (readable)
	printf("Time=%d  Parameter, chan=%d ctrl=%d value=%d\n", 
		time, channel, control, value);
    else if (sblast) {
	if (d) {
#ifdef K1
/* no expression controller for K1, so use volume */
		if (control == EXPRESSION) {
			control = VOLUME;
			value = (main_volume[channel-1] * value)/128;
		}
#endif
		midisync();
		midich(CONTROLLER + d - 1);
		midich(control);
		midich(value);
	}
    }
    else {
	deltatime();
	putchar(CONTROLLER + channel - 1);
	putchar(control);
	putchar(value);
    }
}

/****************************************************************************
*				 f_program
* Inputs:
*	int channel: Channel on which to send midi program change request
*	int program: Program number to send (decremented by 1 before
*			being sent as midi data)
* Effect: 
*	Prints a program change request out the channel
****************************************************************************/

private void f_program(d, channel, program)
    int d;		/* destination */
    int channel;	/* midi channel */
    int program;	/* the program number */
{
    if (readable)
	printf("Time=%d  Program, chan=%d program=%d\n",
		time, channel, program);
    else if (sblast) fm_program(d, channel-1, program-1);
    else {
	deltatime();
	putchar(PROGRAM + channel - 1);
	putchar(program - 1);
    }
}

/****************************************************************************
*				   f_touch
* Inputs:
*	int channel: midi channel on which to send data
*	int value: control value
* Effect: 
*	Prints a midi after touch message
****************************************************************************/

private void f_touch(d, channel, value)
    int d, channel, value;
{
    if (readable)
	printf("Time=%d  Channel pressure, chan=%d value=%d\n",
		time, channel, value);
    else if (sblast) {
	if (d) {
		midisync();
		midich(CHANPRESSURE + d - 1);
		midich(value);
	}
    }
    else {
	deltatime();
	putchar(CHANPRESSURE + channel - 1);
	putchar(value);
    }
}

/*****************************************************************
*			set_pitch_default
*****************************************************************/
private void set_pitch_default()
{
    int i;

    for (i = 0; i < 128; i++) {
	pit_tab[i].pbend = 8192;
	pit_tab[i].ppitch = i;
    }
}

/*****************************************************************
*			read_tuning
*****************************************************************/

private void read_tuning(filename)
    char *filename;
{
    int index, pit, lineno = 0;
    float bend;
    FILE *fpp;

    user_scale = true;
    set_pitch_default();
    fpp = fileopen(filename, "tun", "r", "Tuning definition file");
    while ((fscanf(fpp, "%d %d %f\n", &index, &pit, &bend) > 2) &&
	   (lineno < 128)) {
	lineno++;
	if (index >= -12 && index <= 115) {
	    pit_tab[index+12].pbend = (int)(8192 * bend/100 + 8192);
	    pit_tab[index+12].ppitch = pit;
	}
    }
}


/****************************************************************************
*				   tunginginit
* Effect: 
* Read tuning file
****************************************************************************/

private void tuninginit()
{
    int i;
    char *filename;

    filename = cl_option("-tune");
    if (filename != NULL) {
	    read_tuning(filename);
    }
/*
    if (user_scale) {
	for (i = 0; i < num_voices; i++) {
	    f_bend(0, i+1, 8192);
	    bend[i] = 8192;
	}
    }
*/

}

/*
 * some of following code was adapted from:
 * 
 * fmplay by Hannu Savolainen (hsavolai@cs.helsinki.fi)
 * Modifications, bugfixes, and ANSIfied by Rob Hooft (hooft@chem.ruu.nl)
 *
 */
static int chn_pgm[16] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
#define N_CELL		(20)
static long cell_alloc[N_CELL] =
	{ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
	  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
static int cell_chan[N_CELL] =
	{ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
	  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
static int cell_pitch[N_CELL] =
	{ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
	  -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };

int new_cell(unsigned long stime, int chan, int pitch)
{	int i, best = 0, bperc = 0, perc = 0;

	/* cells not used up in perc mode */
	if (perc_mode && PERCCHAN(chan)) return(0);

	for (i = 0; i < num_cells; i++) {
		if (cell_alloc[i] < cell_alloc[best]) best = i;
		if (cell_chan[i] >= 0 && PERCCHAN(cell_chan[i])) {
			if (perc && cell_alloc[i] < cell_alloc[bperc]) bperc = i;
			else {
				perc = 1;
				bperc = i;
			}
		}
	}
	if (cell_alloc[best] >= 0) {
		if (perc) best = bperc;
		stat_imp_cell_off++;

		fm_noteon(0, cell_chan[best], best, cell_pitch[best], 0,
			(unsigned long)cell_alloc[best]);

	}
	cell_alloc[best] = (long)stime;
	if (cell_alloc[best] < 0) fprintf(stderr, "internal error in new_cell()\n");
	cell_chan[best] = chan;
	cell_pitch[best] = pitch;
	stat_cell_on++;
	return(best);
}

void fm_drumon(int drum, int vol)
{
	char buf[4];

	buf[0] = SEQ_DRUMON;
	buf[1] = 0;
	buf[2] = drum;
	buf[3] = vol;
	sbwrite(buf);
}

void fm_drumoff(int drum, int vol)
{
	char buf[4];

	buf[0] = SEQ_DRUMOFF;
	buf[1] = 0;
	buf[2] = drum;
	buf[3] = vol;
	sbwrite(buf);
}

void fm_noteon(int d, int chan, int cell, int pitch, int vol, unsigned long stime)
{
	char buf[4];
	int dv, nominal_pitch;

	midisync();

	if (d) {
		midich(NOTEON + d - 1);
		midich(pitch);
		midich(vol);
		return;
	}

	if (vol && main_volume[chan] >= 0) {
		float vol_factor = (float)main_volume[chan];
		if (expression[chan] >= 0) vol_factor *=
			((float)expression[chan]/128.0);
		vol = vol * (vol_factor/128.0);
	}

	nominal_pitch = pitch;

	if (PERCCHAN(chan)) {
		if (perc_mode) {
			if (!vol) fm_drumoff(pitch, vol);
			else fm_drumon(pitch, vol);
			return;
		}
		else if (v_drum) {
			if (pitch >= 35 && pitch <= 81) {
				if (bank_size <= 128 + 81 - 35) {
					dv = d_voice[pitch - 35].dv;
					pitch = d_voice[pitch - 35].dnote;
				} else {
					dv = 128 + pitch - 35;
					pitch = dnote[128 + pitch - 35];
				}
			}
			else {
			/* should not happen */
				dv = 130;
				pitch = 50;
			}
		}
	}

	if (!vol) {
		if (cell_alloc[cell] != (long)stime
		    || cell_chan[cell] != chan
		    || cell_pitch[cell] != nominal_pitch) {
			stat_not_cell_off++;
			return;
		}
		fm_noteoff(chan,cell,pitch,vol,stime);
		return;
	}
	if (1) /*if (cell_chan[cell] != chn_pgm[chan])*/ {
		buf[0] = SEQ_FMPGMCHANGE;
		buf[1] = cell;
		if (v_drum && PERCCHAN(chan)) buf[2] = dv;
		else buf[2] = chn_pgm[chan];
		sbwrite(buf);
	}
	buf[0] = SEQ_FMNOTEON;
	buf[1] = cell;
	buf[2] = pitch;
	buf[3] = vol;
	sbwrite(buf);	
}

void fm_noteoff(int chan, int cell, int pitch, int vol, unsigned long stime)
{
	char buf[4];


	midisync();
	buf[0] = SEQ_FMNOTEOFF;
	buf[1] = cell;
	buf[2] = pitch;
	buf[3] = vol;
	sbwrite(buf);
	cell_alloc[cell] = cell_chan[cell] = cell_pitch[cell] = -1;
	stat_cell_off++;
}


void fm_program(int d, int chan, int program)
{
	chn_pgm[chan] = program;
#ifndef K1
/* K1 can't remember channel programs */
	if (d) {
		midich(PROGRAM + d);
		midich(program);
		return;
	}
#endif
}

void midisync(void)
{
	unsigned long jiffies;

	static unsigned long prevtime = 0;
	int i;

	jiffies = time;
	if (jiffies&0xff000000) {
		printf("time is forever\n");
		exit(1);
	}
	if (jiffies > prevtime)
	{
/*if (jiffies - prevtime > 200) printf("(%dcsec time delta)\n", jiffies-prevtime);*/
		prevtime = jiffies; 
		jiffies = (jiffies << 8) | SEQ_WAIT;
		sbwrite((char*)&jiffies);
	}
else if (jiffies < prevtime) printf("(%dcsec negative time)\n", prevtime - jiffies);
}

#ifdef MIDIIN

int midipending(void)
{
	return(ioctl(sb, SNDCTL_SEQ_GETINCOUNT, 0));
}

int midigetc(void)
{	int l, havemidi;
	unsigned char buf[4];
	int attempts;

attempts = 0;
	havemidi = 0;
	while (!havemidi) {
attempts++;
if (attempts > 2) printf("%d attempts\n", attempts);
		if ((l=read(sb, buf, 4))==-1) {
			perror("/dev/sequencer");
			exit(-1);
		}
		if (l != 4) {
			fprintf(stderr,"could only read %d bytes\n", l);
			exit(-1);
		}
		if (buf[0] == SEQ_WAIT) {
			sb_time = buf[1] + (buf[2] << 8) + (buf[3] << 16);
#ifdef DEBUG
			printf("sb_time %x (%x %x %x %x)\n",
				sb_time, buf[0],buf[1],buf[2],buf[3]);
#endif
		}
		else if (buf[0] == SEQ_MIDIPUTC) havemidi = 1;
	}
	return(buf[1]);
}

int midigetnb()
{
	if (midipending()) return(midigetc());
	return(-1);
}
/* following 2 routines adapted from midifile.c,
 * by Tim Thompson and M. Czeisperger
 */
static
chanmessage(status,c1,c2)
int status;
int c1, c2;
{
    /*int chan = status & 0xf;*/
    int chan = recording_channel - 1;
    unsigned char data[2];

    data[0] = c1;
    data[1] = c2;

    switch ( status & 0xf0 ) {
    case 0x80:
	mf_write_midi_event(getdelta(),note_off,chan,data,2);
	break;
    case 0x90:
	mf_write_midi_event(getdelta(),note_on,chan,data,2);
	break;
    case 0xa0:
	mf_write_midi_event(getdelta(),poly_aftertouch,chan,data,2);
	break;
    case 0xb0:
	if (c1 != 123)
	mf_write_midi_event(getdelta(),control_change,chan,data,2);
	break;
    case 0xc0:
	mf_write_midi_event(getdelta(),program_chng,chan,data,1);
	break;
    case 0xd0:
	mf_write_midi_event(getdelta(),channel_aftertouch,chan,data,1);
	break;
    case 0xe0:
	mf_write_midi_event(getdelta(),pitch_wheel,chan,data,2);
	break;
    }
}

static
void midimessage()
{
	/* This array is indexed by the high half of a status byte.  It's */
	/* value is either the number of bytes needed (1 or 2) for a channel */
	/* message, or 0 (meaning it's not  a channel message). */
	static int chantype[] = {
		0, 0, 0, 0, 0, 0, 0, 0,		/* 0x00 through 0x70 */
		2, 2, 2, 2, 1, 1, 2, 0		/* 0x80 through 0xf0 */
	};
	static int c = -1, c1 = -1, c2 = -1;
	static int running = 0;	/* 1 when running status used */
	static int status = 0;		/* status value (e.g. 0x90==note-on) */
	int needed;


	if (c == -1) {
		c = midigetnb();
		if (c == -1) return;
	}
	if ( (c & 0x80) == 0 ) {	 /* running status? */
		if ( status == 0 )
			mferror("unexpected running status");
		running = 1;
	}
	else {
		status = c;
		running = 0;
	}

	needed = chantype[ (status>>4) & 0xf ];

	if ( needed ) {		/* ie. is it a channel message? */

		if ( running ) c1 = c;
		else if (c1 = -1) {
			c1 = midigetnb();
			if (c1 == -1) return;
		}
		if (needed>1) {
			if (c2 == -1) c2 = midigetnb();
			if (c2 == -1) return;
		}
		else c2 = 0;

		chanmessage( status, c1, c2 );
		c = c1 = c2 = -1;
	}
	else mferror("apparent non-channel message");
}
#endif

