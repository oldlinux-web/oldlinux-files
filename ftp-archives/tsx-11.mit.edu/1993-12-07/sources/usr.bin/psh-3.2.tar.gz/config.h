/*
 * Configuration header file
 * Pink House Systems, October 1993
 */

#ifndef __CONFIG_H
#define __CONFIG_H


#define MAXLINE		1024
#define NO_SEEK		0

#define STATUS_BAD	0
#define STATUS_OK	1


class configuration
{
    FILE *file;
    int status;
    char line[MAXLINE];
    void (*panic)(char *);

    getline(void);

   public:
    configuration(char *filename, void (*_panic)(char *));
    ~configuration(void);
    int getsectionptr(char *section_name);
    int getstatus(void) { return status; }
    void getfielddata(int sectionptr, char *field_name,
    		      char **dest, int fields, int seek = 1);
};

#endif
