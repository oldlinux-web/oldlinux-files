#!/bin/sh
#
# This produces a plain text of the nroff/troff file tech-notes.me
# If you've got real troff or ptroff, use that: troff -me tech-notes.me
#
nroff -Tcrt -me tech-notes.me | sed -e 's/.//g'  -e 's/^ *- Pine Tech/&/'\
            | awk ' BEGIN {output = 0}
                    /^ *- [0-9]* - *$/ {output = 0; print; print "" }
                    /^/ {output = 1}
                    /Pine Tech/ {output = 1;}
                          {if(output == 1) print}
                  ' > tech-notes


