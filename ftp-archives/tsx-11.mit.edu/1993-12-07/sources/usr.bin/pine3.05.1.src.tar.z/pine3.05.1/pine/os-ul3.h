/*----------------------------------------------------------------------

            T H E    P I N E    M A I L   S Y S T E M

   Laurence Lundblade and Mike Seibel
   Networks and Distributed Computing
   Computing and Communications
   University of Washington
   Administration Building, AG-44
   Seattle, Washington, 98195, USA
   Internet: lgl@CAC.Washington.EDU
             mikes@CAC.Washington.EDU

   Please address all bugs and comments to "pine-bugs@cac.washington.edu"

   Date:
   Last Edited:
      
   Copyright 1989, 1990, 1991, 1992  University of Washington

    Permission to use, copy, modify, and distribute this software and its
   documentation for any purpose and without fee to the University of
   Washington is hereby granted, provided that the above copyright notice
   appears in all copies and that both the above copyright notice and this
   permission notice appear in supporting documentation, and that the name
   of the University of Washington not be used in advertising or publicity
   pertaining to distribution of the software without specific, written
   prior permission.  This software is made available "as is", and
   THE UNIVERSITY OF WASHINGTON DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED,
   WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT LIMITATION ALL IMPLIED
   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, AND IN
   NO EVENT SHALL THE UNIVERSITY OF WASHINGTON BE LIABLE FOR ANY SPECIAL,
   INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
   LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, TORT
   (INCLUDING NEGLIGENCE) OR STRICT LIABILITY, ARISING OUT OF OR IN CONNECTION
   WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
  

   Pine is in part based on The Elm Mail System:
    ***********************************************************************
    *  The Elm Mail System  -  $Revision: 2.13 $   $State: Exp $          *
    *                                                                     *
    * 			Copyright (c) 1986, 1987 Dave Taylor              *
    * 			Copyright (c) 1988, 1989 USENET Community Trust   *
    ***********************************************************************
 

  ----------------------------------------------------------------------*/

#ifndef _OS_INCLUDED
#define _OS_INCLUDED


#define void char


/*------- Include standard/strings library -------*/
#include <string.h>

#ifdef      MEMLOG
#undef      malloc
#endif     /*  MEMLOG */



/*----------------- time.h -----------------------*/
#include <time.h>



/*--------------- signals.h ----------------------*/
#include <signal.h>

#define SigType int



/*-------------- qsort arguments type ------------*/
#define QSType int



/*---------- What exit return -------------------*/
int    exit();


#define RESIZING



/*----------------------------------------------------------------------
    Turn on if you want the disk item on the "other" menu to check and
 report disk quotas. This will only work if the system actually supports
 quotas and the config.h file mentions it.
 ----*/
#define USE_QUOTAS


#define ANSI_PRINTER "attached-to-ansi"


/*----------------------------------------------------------------------
 *  The default printer when pine starts up for the first time with no printer
 */
#define DF_DEFAULT_PRINTER ANSI_PRINTER



/*----------------------------------------------------------------------
 *  Standard printer 
 */
#define DF_STANDARD_PRINTER "lpr"



/*----------------------------------------------------------------------
 *   If turned on the News features will show on the main menu, so the
 * user may read news about the latest versions of Pine or other notes
 */
#define SHOW_NEWS 


/*----------------------------------------------------------------------
 *
 */
#define WHO_FILE1 "/usr/lib/pine.info"
#define WHO_FILE2 "/usr/local/lib/pine.info"
#define SYSTEM_PINERC "/usr/local/lib/pine.conf"



/*----------------------------------------------------------------------
  Where to put the output of the pine in debug mode. Files are created
 in users home directory and have a number appended to them when there 
 are more than one.
 ----*/
#define DEBUGFILE	".pine-debug"



/*----------------------------------------------------------------------
   The number of .debug files to save in the users home diretory. The files
 are useful for figuring out what a user did when he complains that something
 went wrong. It's important to keep a bunch around, usually 4, so that the
 debug file in questions will still be around when the problem gets 
 invesitagated. Users tend to go in and out of Pine a few times and there
 is one file for each pine invocation
 ----*/
#define NUMDEBUGFILES 4


/*----------------------------------------------------------------------
   The default debug level to set:
       1 logs only highest level events and errors
       2 logs events like file writes
       3
       4 logs each command
       5
       6 
       7 logs details of command execution (7 is highest to run any production)
       8
       9 logs gross details of command execution
  ----*/
#define DEFAULT_DEBUG 2



/*----------------------------------------------------------------------
    The usual sendmail configuration for sending mail
 ----*/
#define SENDMAIL	"/usr/lib/sendmail"
#define SENDMAILFLAGS	"-oi -oem -t"	/* ignore dots and mail back errors
					   and read message for recpeients.*/


/*----------------------------------------------------------------------
    Various maximum string sizes 
 ------*/
#define MAXPATH        (512)    /* Longest pathname we ever expect */
#define MAXFOLDER      (64)     /* Longest foldername we ever expect */  

/* Note to reduce stack consumption, one can reduce the size of MAXPATH,
  the current system permitting. Currently the larges functions use
  about 2 * MAXPATH + 200 bytes. Reducing MAX_SCREEN_COLS is a can
  help reduce stack consumption too. Ofcourse this is only of concern for
  things like PC's.
*/
/*
  Maximum lengths of the fields. In practice the address field is limited
  by the screen width when used on an 80 column screen. These are usually
  entered with the optionally_enter() function which must fit the prompt
  and the field in the number of columns on the screen. If the length
  given it is wider than the screen is just stops at the screen width
 */
#define MAX_FULLNAME  (50) 
#define MAX_NICKNAME  (20)
#define MAX_ADDRESS   (100)
#define MAX_NEW_LIST  (100)  /* Max addresses to be added when creating list */
#define MAX_SEARCH    (100)  /* Long possible string to search for */
#define MAX_ADDR_EXPN (1000)  /* Longest single expanded address to expect */
#define MAX_ADDR_FIELD (10000) /* Longest address fully expanded field */



/*==========  Time outs, check pointing  ==========*/
#define NEW_MAIL_TIME  (10) /* How often to check for new mail. There's 
                               some expense in doing this so it shouldn't
                               be done too frequently 
                             */
#define CHECK_POINT_TIME (5*60)  /* Minimum time to wait before forcing
                                      a check point if there has been at 
                                      least one change, but not
                                      CHECK_POINT_FREQ changes.
                                    */
                                     
#define CHECK_POINT_FREQ (10) /* Do a check point if there have been this
                                 many (status) changes to the current mail
                                 file.
                               */



/*----------------------------------------------------------------------
   The largest screen pine will display on. Used to define some array sizes
 so increases here will make Pine larger and use more stack space.
 ---*/
#define MAX_SCREEN_COLS  (170) 
#define MAX_SCREEN_ROWS  (200) 


/*----------------------------------------------------------------------
   When no screen size can be discovered this is the size used
 ----*/
#define DEFAULT_LINES_ON_TERMINAL	(24)
#define DEFAULT_COLUMNS_ON_TERMINAL	(80)


/*----------------------------------------------------------------------
 In scrolling through text, the number of lines from the previous
 screen to overlap when showing the next screen
 ----*/
#define	OVERLAP		(2) 



/*----------------------------------------------------------------------
   The default folder names and folder directories
 ----*/
#define DF_DEFAULT_FCC    "sent-mail"
#define DEFAULT_SAVE      "saved-messages"
#define POSTPONED_MAIL    "postponed-mail"
#define INTERRUPTED_MAIL  "interrupted-mail"
#define DF_MAIL_DIRECTORY "mail"
#define INBOX_NAME        "inbox"
#define DF_SIGNATURE_FILE ".signature"
#define DF_ELM_STYLE_SAVE         "no"
#define DF_HEADER_IN_REPLY        "no"
#define DF_OLD_STYLE_REPLY        "no"
#define DF_USE_ONLY_DOMAIN_NAME   "no"
#define DF_FEATURE_LEVEL          "sapling"


#endif /* _OS_INCLUDED */
