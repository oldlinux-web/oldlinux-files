/* rewind-stdin.c B.A.McCauley@bham.ac.uk 21 May 1993 */
/* 
   This command is used by the magic-filter script to rewind
   its standard input or to work out it standard input is
   rewindable.
*/
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
main () { return lseek(0,0,SEEK_SET) == EOF ? errno : 0; }
