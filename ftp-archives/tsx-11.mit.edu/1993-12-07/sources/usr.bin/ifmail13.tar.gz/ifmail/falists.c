#include <stdlib.h>
#include <string.h>
#include "xutil.h"
#include "lutil.h"
#include "ftn.h"
#include "falists.h"

#ifndef __compar_fn_t
#define __compar_fn_t int
#endif

int in_list(addr,fap)
faddr *addr;
fa_list **fap;
{
	fa_list *tmp;

	debug(6,"Seeking seen-by match for %s",ascinode(addr,0x06));
	for (tmp=*fap;tmp;tmp=tmp->next)
		if ((tmp->addr->net == addr->net) &&
		    (tmp->addr->node == addr->node))
		{
			debug(6,"Match found");
			return 1;
		}
	debug(6,"Match not found");
	return 0;
}

void tidy_list(fap)
fa_list **fap;
{
	fa_list *tmp,*old;

	for (tmp=*fap;tmp;tmp=old)
	{
		old=tmp->next;
		tidy_faddr(tmp->addr);
		free(tmp);
	}
	*fap=NULL;
}

void fill_list(fap,str)
fa_list **fap;
char *str;
{
	fa_list *tmp;
	faddr *ta;
	static unsigned int oldnet;
	char *buf,*p;

	if (str == NULL) return;

	buf=xstrcpy(str);
	p=strtok(buf," \t\n");
	while (p)
	{
		if ((ta=parsefnode(p)))
		{
			if (ta->net == 0) ta->net=oldnet;
			else oldnet=ta->net;
			tmp=(fa_list *)xmalloc(sizeof(fa_list));
			tmp->next=*fap;
			tmp->addr=ta;
			*fap=tmp;
		}
		p=strtok(NULL," \t\n");
	}
	free(buf);
	return;
}

int compaddr(fa_list **,fa_list **);

void sort_list(fap)
fa_list **fap;
{
	fa_list *ta,**vector;
	size_t n=0,i;

	for (ta=*fap;ta;ta=ta->next) n++;
	vector=(fa_list **)xmalloc(n * sizeof(fa_list *));
	debug(3,"Sorting %d seen-by entries",n);
	i=0;
	for (ta=*fap;ta;ta=ta->next)
	{
		vector[i++]=ta;
		debug(7,"seen-by addr before sort: %s",
			ascfnode(ta->addr,0x06));
	}
	qsort(vector,n,sizeof(faddr*),compaddr);
	for (i=0;i<n;i++)
		debug(7,"seen-by addr after sort: %s",
			ascfnode(vector[i]->addr,0x06));
	(*fap)=vector[0];
	i=1;
	for (ta=*fap;ta;ta=ta->next)
	{
		while ((i < n) && (compaddr(&ta,&(vector[i])) == 0)) i++;
		if (i < n) ta->next=vector[i];
		else ta->next=NULL;
		debug(7,"seen-by addr after unique: %s",
			ascfnode(ta->addr,0x06));
	}
	free(vector);
	return;
}

int compaddr(fap1,fap2)
fa_list **fap1,**fap2;
{
	if ((*fap1)->addr->net != (*fap2)->addr->net)
		return ((*fap1)->addr->net - (*fap2)->addr->net);
	else
		return ((*fap1)->addr->node - (*fap2)->addr->node);
}
