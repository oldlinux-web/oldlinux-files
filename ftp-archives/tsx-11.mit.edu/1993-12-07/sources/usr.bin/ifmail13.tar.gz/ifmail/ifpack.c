#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include "getopt.h"
#include "lutil.h"
#include "config.h"
#include "version.h"

#ifndef PATH_MAX
#define PATH_MAX 512
#endif

extern int verbose;
extern char *logname;
extern char *configname;

int pack(char *,int);
void check_old(char *);
extern int f_lock(char *);
extern void funlock(int);
extern int execute(char *,char *,char *,char *,char *,char *);
extern long sequencer(void);

static char *dow[] = {"su","mo","tu","we","th","fr","sa"};
static char *ext;

void usage(name)
char *name;
{
	fprintf(stderr,"%s\tVersion %s of %s\n\t\tCopyright (c) %s\n",
		name,version,reldate,copyright);
	fprintf(stderr,"This is free software. You can do what you wish \
with it\nas long as this copyright notice is preserved.\n\n");
	fprintf(stderr,"usage: %s -h -x<N> -I<file>\n",name);
	fprintf(stderr,"-h		get this help\n");
	fprintf(stderr,"-x<N>		set debug level to <N>	[%d]\n",
		verbose);
	fprintf(stderr,"-I<file> 	use config file	<file>	[%s]\n",
		configname);
}

int main(argc,argv)
int argc;
char *argv[];
{
	int c;
	int rc=0,maxrc=0;
	int packets=0,packets_ok=0;
	DIR *dp,*dpp;
	struct dirent *de,*dpe;
	time_t tt;
	struct tm *ptm;

	logname=LOGFILE;
	configname=CONFIGFILE;

	while ((c=getopt(argc,argv,"hx:I:")) != -1)
	switch (c)
	{
		case 'x':	verbose=atoi(optarg); break;
		case 'I':	configname=optarg; break;
		case 'h':
		default:	usage(argv[0]); exit(1);
	}

#ifdef DEBUGFILE
	freopen(DEBUGFILE,"a",stderr);
#endif

	log("start %s verbose=%d",argv[0],
		verbose);

	if (readconfig())
	{
		log("Error getting configuration, aborting");
		exit(1);
	}

	time(&tt);
	ptm=localtime(&tt);
	ext=dow[ptm->tm_wday];

	if (chdir(outbound) != 0)
	{
		log("$Error changing to directory %s",outbound);
		exit(1);
	}

	if ((dp=opendir(".")) == NULL)
	{
		log("$Error opening directory %s",outbound);
		exit(1);
	}

	umask(066);

	while((de=readdir(dp)))
	if ((strlen(de->d_name) == 12) &&
	    (*(de->d_name+8) == '.') &&
	    (strspn(de->d_name,"0123456789abcdefABCDEF") == 8))
	{
		check_old(de->d_name);
		if ((strcasecmp(de->d_name+10,"ut") == 0) &&
		    ((toupper(*(de->d_name+9)) == 'O') ||
		     (toupper(*(de->d_name+9)) == 'C') ||
		     (toupper(*(de->d_name+9)) == 'H')))
		{
			/* This is a packet */
			packets++;
			if ((rc=pack(de->d_name,0)) == 0) packets_ok++;
			else log("Error packing %s",de->d_name);
			if (rc > maxrc) maxrc=rc;
		}
		else if (strcasecmp(de->d_name+8,".pnt") == 0)
		{
			/* This is a point directory */
			dpp=NULL;
			if (chdir(de->d_name) != 0)
				log("$Error changing to directory %s",de->d_name);
			else if ((dpp=opendir(".")) == NULL)
				log("$Error opening directory %s",de->d_name);
			else
			while((dpe=readdir(dpp)))
			if ((strlen(dpe->d_name) == 12) &&
			    (*(dpe->d_name+8) == '.') &&
			    (strspn(dpe->d_name,"0123456789abcdefABCDEF") == 8))
			{
				check_old(dpe->d_name);
				if ((strcasecmp(dpe->d_name+10,"ut") == 0) &&
				    ((toupper(*(dpe->d_name+9)) == 'O') ||
				     (toupper(*(dpe->d_name+9)) == 'C') ||
				     (toupper(*(dpe->d_name+9)) == 'H')))
				{
					packets++;
					if ((rc=pack(dpe->d_name,1)) == 0) packets_ok++;
					else log("Error packing %s",dpe->d_name);
					if (rc > maxrc) maxrc=rc;
				}
			}
			if (dpp) closedir(dpp);
			if (chdir("..") != 0)
				log("$Error changing to directory %s",outbound);
		}
	}
	closedir(dp);

	log("end %s, %d of %d packets",
		argv[0],packets_ok,packets);

	return maxrc;
}

int pack(pn,ispoint)
char *pn;
int ispoint;
{
	int rc;
	int pl;
	char fn[14],flo[14],pkt[14],spl[14];
	char *p,c;
	int absent,needadd;
	unsigned int rnet,rnode;
	char flavor;
	struct stat stbuf;
	FILE *fp;
	char buf[PATH_MAX],name[PATH_MAX];
	struct flock fl;

	sscanf(pn,"%04x%04x.%cut",&rnet,&rnode,&flavor);
	flavor=tolower(flavor);
	if (flavor == 'o') flavor='f';
	if (isupper(pn[9])) flavor=toupper(flavor);
	if (ispoint)
	{
		sprintf(fn,"%04x%04x.%s0",rnet&0xffff,rnode&0xffff,ext);
	}
	else
	{
		sprintf(fn,"%04x%04x.%s0", (whoami->addr->net-rnet)&0xffff,
			(whoami->addr->node-rnode+whoami->addr->point)&0xffff,
			ext);
	}
	if (islower(flavor))
		sprintf(flo,"%04x%04x.%clo",rnet,rnode,flavor);
	else
		sprintf(flo,"%04X%04X.%cLO",rnet,rnode,flavor);
	sprintf(spl,"%04x%04x.spl",rnet,rnode);

	if ((pl=f_lock(pn)) == -1) return 1;

	if ((fp=fopen(flo,"r+")) == NULL)
	if ((fp=fopen(flo,"w")) == NULL)
	{
		log("$Error opening \"%s\" for update",flo);
		funlock(pl);
		return 1;
	}
	fl.l_type=F_WRLCK;
	fl.l_whence=0;
	fl.l_start=0L;
	fl.l_len=0L;
	if (fcntl(fileno(fp),F_SETLK,&fl) < 0)
	{
		if (errno != EAGAIN)
			log("$Unable to lock flo file %s",flo);
		fclose(fp);
		funlock(pl);
		return 1;
	}

	name[0]='#';
	getcwd(name+1,sizeof(name)-15);
	p=name+strlen(name);
	absent=1;
	while (fgets(buf,sizeof(buf)-1,fp))
	{
		sprintf(p,"/%s",fn);
		if (strncasecmp(buf,name,strlen(name)-1) == 0)
		{
			absent=0;
			c=buf[strlen(name)-1];
			if (fn[11] < c) fn[11]=c;
		}
	}

	needadd=0;
	if (absent)
	{
		debug(2,"no arcmail file mentioned in flo file, create new");
		needadd=1;
		while (stat(fn,&stbuf) == 0)
			if (fn[11] == '9') fn[11]='a'; else fn[11]++;
	}
	else if (((stat(fn,&stbuf) == 0) && (((stbuf.st_size == 0L) ||
	    ((maxfsize > 0) && (stbuf.st_size > maxfsize))))) ||
	    (stat(spl,&stbuf) != -1))
	{
		debug(2,"arcmail file mentioned in flo file, but new requested");
		needadd=1;
		unlink(spl);
		do
		{
			if (fn[11] == '9') fn[11]='a';
			else fn[11]++;
		}
		while (stat(fn,&stbuf) == 0);
	}

	sprintf(pkt,"%08x.pkt",sequencer());

	rename(pn,pkt);

	debug(2,"using .flo file \"%s\", arc file \"%s\", packet \"%s\" -> \"%s\"",
		flo,fn,pkt,pn);
	rc=execute(packer,fn,pkt,"/dev/null",logname,logname);
	if (rc == 0)
	{
		unlink(pkt);
		if (needadd)
		{
			sprintf(p,"/%s\n",fn);
			fputs(name,fp);
		}
	}
	else rename(pkt,pn);

	fclose(fp);
	funlock(pl);
	return rc;
}

void check_old(fn)
char *fn;
{
	int i;
	struct stat stbuf;

	debug(4,"Check file %s for being old truncated arcmail",fn);
	for (i=0;i<7;i++) 
	if ((strcmp(dow[i],ext) != 0) && 
	    (strncasecmp(fn+9,dow[i],2) == 0) &&
	    (stat(fn,&stbuf) != -1) && 
	    (stbuf.st_size == 0L))
	{
		debug(3,"Unlink old truncated file %s",fn);
		unlink(fn);
	}
}
