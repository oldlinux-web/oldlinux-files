#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include "getopt.h"
#include "lutil.h"
#include "config.h"
#include "version.h"
#include "ftn.h"
#include "getheader.h"

extern int verbose;
extern char *logname;
extern char *configname;

extern int getmessage(FILE *,FILE*,faddr *,faddr *);
extern void readareas(char *);
extern void readalias(char *);

extern int num_echo,num_mail;

int usetmp=1; /* to tell bgets that we do not use batch mode */

void usage(name)
char *name;
{
	fprintf(stderr,"%s\tVersion %s of %s\n\t\tCopyright (c) %s\n",
		name,version,reldate,copyright);
	fprintf(stderr,"This is free software. You can do what you wish \
with it\nas long as this copyright notice is preserved.\n\n");
	fprintf(stderr,"usage: %s -h -x<N> -I<file>\n",name);
	fprintf(stderr,"-h		get this help\n");
	fprintf(stderr,"-x<N>		set debug level to <N>	[%d]\n",
		verbose);
	fprintf(stderr,"-I<file> 	use config file	<file>	[%s]\n",
		configname);
}

FILE *nb = NULL;

int main(argc,argv)
int argc;
char *argv[];
{
	int c;
	int rc;
	FILE *fp;
	faddr from,to;

	logname=LOGFILE;
	configname=CONFIGFILE;

	while ((c=getopt(argc,argv,"hx:I:")) != -1)
	switch (c)
	{
		case 'x':	verbose=atoi(optarg); break;
		case 'I':	configname=optarg; break;
		case 'h':
		default:	usage(argv[0]); exit(1);
	}

#ifdef DEBUGFILE
	freopen(DEBUGFILE,"a",stderr);
#endif

	log("start %s verbose=%d",argv[0],
		verbose);

	if (verbose)
	{
		mkdir("/tmp/ifmail",0777);
		log("in debug mode resultant messages will go to /tmp/ifmail");
	}

	if (readconfig())
	{
		log("Error getting configuration, aborting");
		exit(1);
	}
	readareas(areafile);
	readalias(aliasfile);

	if (((rc=getheader(&from,&to,stdin)) != 0) && (rc != 4))
	{
		log("%s, aborting",(rc==3)?"packet not to this node":
			"bad packet");
		exit(rc);
	}

	if ((fp=tmpfile()) == NULL)
	{
		log("$Cannot open temporary file");
		exit(2);
	}
	while ((rc=getmessage(stdin,fp,&from,&to)) == 1);

	fclose(fp);
	if (nb) fclose(nb);

	log("end %s, %d echomail, %d netmail messages processed, rc=%d",
		argv[0],num_echo,num_mail,rc);

	return rc;
}
