#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "getopt.h"
#include "lutil.h"
#include "xutil.h"
#include "ftn.h"
#include "falists.h"
#include "rfcmsg.h"
#include "ftnmsg.h"
#include "areas.h"
#include "config.h"
#include "version.h"

extern int verbose;
extern int newsmode;
extern char *logname;
extern char *configname;
extern char passwd[];

extern FILE *openpkt(faddr *,char);
extern int putmessage(rfcmsg *,ftnmsg *,FILE *,FILE *,fa_list **);
extern void closepkt(FILE *);
extern char *bgets(char *,int,FILE *);
extern void readareas(char *);
extern void try_attach(char *,int,faddr *,char);

int usetmp=0;

void usage(name)
char *name;
{
	fprintf(stderr,"%s\tVersion %s of %s\n\t\tCopyright (c) %s\n",
		name,version,reldate,copyright);
	fprintf(stderr,"This is free software. You can do what you wish \
with it\nas long as this copyright notice is preserved.\n\n");
	fprintf(stderr,"usage: %s -h -n -x<N> -I<file> -r<addr> <recip> ...\n",name);
	fprintf(stderr,"-h		get this help\n");
	fprintf(stderr,"-n		set news mode\n");
	fprintf(stderr,"-x<N>		set debug level to <N>	[%d]\n",
		verbose);
	fprintf(stderr,"-I<file> 	use config file	<file>	[%s]\n",
		configname);
	fprintf(stderr,"-r<addr>	address to route packet\n");
	fprintf(stderr,"-g<grade>	[ n | c | h ] \"flavor\" of packet\n");
	fprintf(stderr,"<recip>		list of receipient addresses\n");
}

int main(argc,argv)
int argc;
char *argv[];
{
	int c;
	char *p;
	char buf[BUFSIZ];
	FILE *fp,*pkt = NULL;
	faddr *route = NULL;
	fa_list *envrecip = NULL, *envrecip_start = NULL;
	int envrecip_count=0;
	area_list *area = NULL, *area_start = NULL;
	int area_count=0;
	int msg_in=0,msg_out=0;
	rfcmsg *msg=NULL,*tmsg;
	ftnmsg *fmsg=NULL;
	faddr *taddr;
	char flavor='n';
	fa_list *sbl = NULL;

	logname=LOGFILE;
	configname=CONFIGFILE;

	while ((c=getopt(argc,argv,"g:r:x:I:nh")) != -1)
	switch (c)
	{
		case 'g':	if (optarg && ((*optarg == 'n') || 
				   (*optarg == 'c') || (*optarg == 'h')))
					flavor=*optarg;
				else 
				{
					usage(argv[0]); 
					exit(1);
				}
				break;
		case 'r':	if ((route=parsefaddr(optarg)) == NULL)
				log("unparsable route address \"%s\"",optarg);
				break;
		case 'x':	verbose=atoi(optarg); break;
		case 'I':	configname=optarg; break;
		case 'n':	newsmode=1; break;
		case 'h':
		default:	usage(argv[0]); exit(1);
	}

#ifdef DEBUGFILE
	freopen(DEBUGFILE,"a",stderr);
#endif

	if ((p=strrchr(argv[0],'/'))) p++;
	else p=argv[0];
	if (!strcmp(p,"ifnews")) newsmode=1;

	while (argv[optind])
	{
		if ((taddr=parsefaddr(argv[optind]))) 
		{
			if (envrecip)
			{
				envrecip->next = (fa_list *)
					xmalloc(sizeof(fa_list));
				envrecip=envrecip->next;
			}
			else
			{
				envrecip_start = (fa_list *)
					xmalloc(sizeof(fa_list));
				envrecip=envrecip_start;
			}
			envrecip->next=NULL;
			envrecip->addr=taddr;
			envrecip_count++;
		}
		else log("unparsable recipient \"%s\", ignored",argv[optind]);
		optind++;
	}

	if ((!newsmode) && (!envrecip_count))
	{
		log("No valid receipients specified, aborting");
		exit(1);
	}

	if (!route && newsmode && envrecip_count)
		route=envrecip_start->addr;

	if (!route) route=parsefaddr(getenv("NEWSSITE"));

	if (!route)
	{
		log("Routing address not specified, aborting");
		exit(1);
	}

	log("start %s in %s mode, route=%s verbose=%d",argv[0],
		newsmode?"news":"mail",ascinode(route,0x3f),verbose);

	for(envrecip=envrecip_start;envrecip;envrecip=envrecip->next)
	if (envrecip->addr)
		log("envrecip: %s",ascinode(envrecip->addr,0x7f));

	if (readconfig())
	{
		log("Error getting configuration, aborting");
		exit(1);
	}
	if (newsmode) readareas(areafile);

	umask(066); /* packets may contain confidential information */

	while (!feof(stdin))
	{
		usetmp=0;
		tidyrfc(msg);
		msg=parsrfc(stdin);

		if (verbose >= 9) dumpmsg(msg,stderr);

		if (pkt == NULL)
		{
			if (flavor == 'n') flavor='o';
			if ((p=hdr("X-FTN-FLAGS",msg)))
			{
				if (strstr(p,"CRS")) flavor='c';
				else if (strstr(p,"HLD")) flavor='h';
				if (strstr(p,"ATT"))
					try_attach(hdr("Subject",msg),0,route,flavor);
				if (strstr(p,"TFS"))
					try_attach(hdr("Subject",msg),1,route,flavor);
				if (strstr(p,"KFS"))
					try_attach(hdr("Subject",msg),2,route,flavor);
			}
			else if ((p=hdr("Priority",msg)) ||
			         (p=hdr("X-Class",msg)))
			{
				while (isspace(*p)) p++;
				if ((strncasecmp(p,"fast",4) == 0) ||
				    (strncasecmp(p,"high",4) == 0) ||
				    (strncasecmp(p,"crash",5) == 0))
					flavor='c';
				else if ((strncasecmp(p,"slow",4) == 0) ||
				         (strncasecmp(p,"low",3) == 0) ||
				         (strncasecmp(p,"hold",4) == 0))
					flavor='h';
			}
			if ((pkt=openpkt(route,flavor)) == NULL)
			{
				log("Unable to open packet for node %s, aborting",
					ascinode(route,0x1f));
				exit(2);
			}
		}

		if (newsmode)
		{
			tidy_arealist(area_start);
			area_start=areas(hdr("Newsgroups",msg));
			area_count=0;
			for(area=area_start;area;area=area->next)
			{
				area_count++;
				debug(2,"area: %s",area->name);
			}
			tidy_list(&sbl);
			for (tmsg=msg;tmsg;tmsg=tmsg->next)
				if (strcasecmp(tmsg->key,"X-FTN-SEEN-BY") == 0)
					fill_list(&sbl,tmsg->val);
		}

		if (((!newsmode) && (envrecip_count > 1)) ||
		    ((newsmode) && (area_count > 1)))
		{
			if ((fp=tmpfile()) == NULL)
			{
				log("$Cannot open temporary file");
				exit(2);
			}
			while(bgets(buf,sizeof(buf)-1,stdin))
				fputs(buf,fp);
			rewind(fp);
			usetmp=1;
		}
		else
		{
			fp=stdin;
			usetmp=0;
		}

		if (newsmode && ((area_count < 1) || hdr("Control",msg) ||
		     (in_list(route,&sbl))))
		{
			debug(1,"skipping news message w/o valid newsgroups or Control header or seen by this node");
			while(bgets(buf,sizeof(buf)-1,fp));
		}
		else
		{
			tidy_ftnmsg(fmsg);
			if ((fmsg=mkftnhdr(msg)) == NULL)
			{
				log("Unable to create FTN headers from RFC ones, aborting");
				exit(2);
			}

			if (newsmode)
			{
				fmsg->to->zone=route->zone;
				fmsg->to->net=route->net;
				fmsg->to->node=route->node;
				fmsg->to->point=route->point;
			}

			if (!newsmode)
			for(envrecip=envrecip_start;envrecip;envrecip=envrecip->next)
			{
				fmsg->to=envrecip->addr;
				if (putmessage(msg,fmsg,fp,pkt,&sbl))
				{
					log("Unable to put netmail message into the packet, aborting");
					exit(2);
				}
				if (usetmp) rewind(fp);
				fmsg->to=NULL;
				msg_out++;
			}
			else
			for(area=area_start;area;area=area->next)
			{
				fmsg->area=area->name;
				if (putmessage(msg,fmsg,fp,pkt,&sbl))
				{
					log("Unable to put echo message into the packet, aborting");
					exit(2);
				}
				if (usetmp) rewind(fp);
				fmsg->area=NULL;
				msg_out++;
			}
			msg_in++;
		}
		if (usetmp) fclose(fp);
	}

	closepkt(pkt);

	log("end %s input %d, output %d messages",argv[0],msg_in,msg_out);

	return 0;
}
