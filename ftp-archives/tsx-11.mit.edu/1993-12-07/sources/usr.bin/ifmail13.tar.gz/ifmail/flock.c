#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include "lutil.h"

int f_lock(fn)
char *fn;
{
	int lfd=-1;
	struct flock fl = {
		F_WRLCK,
		0,
		0L,
		0L,
		0
	};

	if (fn)
	{
		if ((lfd=open(fn,O_RDWR | O_CREAT)) < 0)
		{
			log("$Error opening file %s",fn);
			return -1;
		}
		fl.l_pid=getpid();
		if (fcntl(lfd,F_SETLK,&fl) != 0)
		{
			if (errno != EAGAIN)
				log("$Error locking file %s",fn);
			close(lfd);
			return -1;
		}
	}
	return lfd;
}

void funlock(fd)
int fd;
{
/*
	struct flock fl = {
		F_UNLCK,
		0,
		0L,
		0L,
		0
	};
	fl.l_pid=getpid();
	if (fcntl(fd,F_SETLK,&fl) != 0)
	{
		log("$Error ulocking fd %d",fd);
	}
*/
	close(fd);
	return;
}
