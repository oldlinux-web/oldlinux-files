int debug(int,char*,...);
int log(char *,...);
char *date(long);
char *printable(char*,int);
