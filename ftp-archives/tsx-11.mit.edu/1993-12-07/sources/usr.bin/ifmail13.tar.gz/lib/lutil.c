#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <varargs.h>
#include <errno.h>
#include <time.h>
#include <sys/types.h>

FILE *logfile=NULL;
int verbose=0;
char *logname="/tmp/tmplog";

char *strerror(errno)
int errno;
{
	extern char *sys_errlist[];
	extern int sys_nerr;
	if ((errno >= 0) && (errno <= sys_nerr))
		return(sys_errlist[errno]);
	else
		return("unknown error");
}

char *date(t)
time_t t;
{
	struct tm ptm;
	time_t now;
	static char buf[20];

	if (t) now=t; 
	else time(&now);
	ptm=*localtime(&now);
	sprintf(buf,"%02d/%02d/%02d %02d:%02d:%02d",
		ptm.tm_year%100,ptm.tm_mon+1,ptm.tm_mday,
		ptm.tm_hour,ptm.tm_min,ptm.tm_sec);
	return(buf);
}

static char *pbuff = NULL;

char *printable(s,l)
unsigned char *s;
int l;
{
	int len;
	char *p;

	if (pbuff) free(pbuff);
	pbuff=NULL;

	if (s == NULL) return "(null)";

	if (l > 0) len=l;
	else if (l == 0) len=strlen(s);
	else
	{
		len=strlen(s);
		if (len > -l) len=-l;
	}
	pbuff=(char*)malloc(len*4+1);
	p=pbuff;
	while (len--)
	{
		if ((*s) >= ' ') *p++=*s;
		else switch (*s)
		{
		case '\r': *p++='\\'; *p++='r'; break;
		case '\n': *p++='\\'; *p++='n'; break;
		case '\t': *p++='\\'; *p++='t'; break;
		case '\b': *p++='\\'; *p++='b'; break;
		case '\e': *p++='\\'; *p++='e'; break;
		default:   sprintf(p,"\\%03o",*s); p+=4; break;
		}
		s++;
	}
	*p='\0';
	return pbuff;
}

void log(va_alist)
va_dcl
{
	va_list	args;
	char	*fmt;

	va_start(args);
	fmt=va_arg(args, char*);

	if (verbose)
	{
		vfprintf(stderr,*fmt == '$' ? fmt+1 : fmt,args);
		if (*fmt == '$') 
			fprintf(stderr,"\n\terrno=%d : %s\n",
				errno,strerror(errno));
		else
			fprintf(stderr,"\n");
	}

	if (!logfile)
	if ((logfile=fopen(logname,"a")) == NULL)
	{
		perror("Cannot open log file");
		return;
	}
	fprintf(logfile,"%s %05d ",date(0L),getpid());
	vfprintf(logfile,*fmt == '$' ? fmt+1 : fmt,args);
	if (*fmt == '$') 
		fprintf(logfile,"\n\terrno=%d : %s\n",
			errno,strerror(errno));
	else
		fprintf(logfile,"\n");
	fflush(logfile);

	va_end(args);
	return;
}

void debug(va_alist)
va_dcl
{
	va_list	args;
	int	level;
	char	*fmt;

	va_start(args);
	level=va_arg(args, int);
	fmt=va_arg(args, char*);

	if (level <= verbose)
	{
		vfprintf(stderr,*fmt == '$' ? fmt+1 : fmt,args);
		if (*fmt == '$') 
			fprintf(stderr,"\n\terrno=%d : %s\n",
				errno,strerror(errno));
		else
			fprintf(stderr,"\n");
	}
	fflush(stderr);
	va_end(args);
	return;
}
