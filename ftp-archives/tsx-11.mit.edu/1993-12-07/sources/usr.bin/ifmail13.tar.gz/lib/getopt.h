#ifdef DONT_HAVE_GETOPT

extern int getopt();
extern char *optarg;
extern int optind;

#endif
