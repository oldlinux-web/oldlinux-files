#include <stdio.h>

int iread(FILE *);
long lread(FILE *);
char *aread(char *,int,FILE *);
