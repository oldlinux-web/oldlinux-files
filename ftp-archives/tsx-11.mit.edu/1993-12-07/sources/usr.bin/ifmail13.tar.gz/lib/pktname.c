/* This module hopefully implements BinkleyTerm packet naming conventions */

#include <stdio.h>
#include <string.h>
#include <limits.h>
#include "lutil.h"
#include "xutil.h"
#include "ftn.h"
#include "config.h"

#ifndef PATH_MAX
#define PATH_MAX 256
#endif
#define ptyp "ut"
#define ftyp "lo"
#define rtyp "req"

static char buf[PATH_MAX];

static char *prepbuf(faddr*);
static char *prepbuf(addr)
faddr *addr;
{
	char *p;
	char zpref[8];
	fa_list *tmpl;

	strcpy(buf,outbound);

	if ((addr->domain != NULL) && (whoami->addr->domain != NULL) &&
	    (strcasecmp(addr->domain,whoami->addr->domain) != 0))
	{
		if ((p=strrchr(buf,'/'))) p++;
		else p=buf;
		strcpy(p,addr->domain);
		for (tmpl=nllist;tmpl;tmpl=tmpl->next)
			if (strcasecmp(tmpl->addr->domain,addr->domain) == 0)
				break;
		if (tmpl && (tmpl->addr->zone == addr->zone))
			zpref[0]='\0';
		else sprintf(zpref,".%03x",addr->zone);
	}
	else /* this is our primary domain */
	{
		if ((addr->zone == 0) || (addr->zone == whoami->addr->zone))
			zpref[0]='\0';
		else sprintf(zpref,".%03x",addr->zone);
	}

	p=buf+strlen(buf);

	if (addr->point)
		sprintf(p,"%s/%04x%04x.pnt/%08x.",
			zpref,addr->net,addr->node,addr->point);
	else
		sprintf(p,"%s/%04x%04x.",zpref,addr->net,addr->node);

	p=buf+strlen(buf);
	return p;
}

char *pktname(addr,flavor)
faddr *addr;
char flavor;
{
	char *p;

	p=prepbuf(addr);
	if (flavor == 'f') flavor='o';
	sprintf(p,"%c%s",flavor,ptyp);
	debug(3,"packet name is \"%s\"",buf);
	return buf;
}

char *floname(addr,flavor)
faddr *addr;
char flavor;
{
	char *p;

	p=prepbuf(addr);
	if (flavor == 'o') flavor='f';
	sprintf(p,"%c%s",flavor,ftyp);
	debug(3,"flo file name is \"%s\"",buf);
	return buf;
}

char *reqname(addr,flavor)
faddr *addr;
char flavor;
{
	char *p;

	p=prepbuf(addr);
	if (flavor == 'o') flavor='f'; /* in fact this is ignored for reqs */
	sprintf(p,"%s",rtyp);
	debug(3,"req file name is \"%s\"",buf);
	return buf;
}
