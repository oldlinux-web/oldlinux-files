#ifndef _FTN_H
#define _FTN_H

#define MAXNAME 35
#define MAXSUBJ 71
#define MAXORIGIN 45

typedef struct _faddr {
	char *name;
	unsigned int point;
	unsigned int node;
	unsigned int net;
	unsigned int zone;
	char *domain;
} faddr;

typedef struct _fa_list {
		struct _fa_list *next;
		faddr *addr;
} fa_list;

faddr *parsefaddr(char *);
faddr *parsefnode(char *);
char *ascinode(faddr *,int);
char *ascfnode(faddr *,int);
void tidy_faddr(faddr *);
#endif
