#include <stdio.h>
#include "ftn.h"

extern int getheader(faddr *,faddr*,FILE *);
