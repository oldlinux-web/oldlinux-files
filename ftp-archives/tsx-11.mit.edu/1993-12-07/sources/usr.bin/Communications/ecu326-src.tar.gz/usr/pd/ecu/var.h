/*+-------------------------------------------------------------------------
	var.h - ecu user variable declarations
	wht@n4hgf.Mt-Park.GA.US
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:09-10-1992-14:00-wht@n4hgf-ECU release 3.20 */
/*:08-22-1992-15:39-wht@n4hgf-ECU release 3.20 BETA */
/*:03-27-1992-16:21-wht@n4hgf-re-include protection for all .h files */
/*:07-25-1991-12:59-wht@n4hgf-ECU release 3.10 */
/*:08-14-1990-20:40-wht@n4hgf-ecu3.00-flush old edit history */

#ifndef _var_h
#define _var_h

#if !defined(VDECL)
#define VDECL extern
#endif

#define SVLEN	256
#define SVQUAN	50
#define IVQUAN	50

VDECL ESD *sv[SVQUAN];
VDECL long iv[SVQUAN];

#endif /* _var_h */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of var.h */
