/*+-------------------------------------------------------------------------
	bperr.c - build proc_error .c from ecuerror.h
	wht@n4hgf.Mt-Park.GA.US
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:09-10-1992-13:58-wht@n4hgf-ECU release 3.20 */
/*:08-22-1992-15:38-wht@n4hgf-ECU release 3.20 BETA */
/*:07-25-1991-12:55-wht@n4hgf-ECU release 3.10 */
/*:08-14-1990-20:39-wht@n4hgf-ecu3.00-flush old edit history */

#include <stdio.h>
#include <time.h>

#define MAXLINE 256
#define MAXFLDS 50

char *strchr();

char line[MAXLINE];
char copy[MAXLINE];
char *fields[MAXFLDS + 1];

char *bc = 
"/*+-------------------------------------------------------------------------";
char *ec = 
"--------------------------------------------------------------------------*/";
/*+-------------------------------------------------------------------------
	splitter(sep)
--------------------------------------------------------------------------*/
splitter(sep)
char *sep;
{
char *tmp = copy;
register int fld;

	for (fld = 1; fld <= MAXFLDS; fld++)
		fields[fld] = NULL;
	if (!strlen(sep) || !strlen(line))
		return(0);
	fld = 1;
	sprintf(copy, "%s", line);
	while (fld < MAXFLDS)
	{
		while (strchr(sep, *tmp))
			if (!*++tmp) return fld;
		fields[fld++] = tmp++;
		while (!strchr(sep, *tmp))
			if (!*++tmp) return fld;
		*tmp++ = '\0';
	}
	return(fld);
}	/* end of splitter */

/*+-------------------------------------------------------------------------
	main(argc,argv)
--------------------------------------------------------------------------*/
main(argc,argv)
int argc;
char **argv;
{
register field_count;
register itmp;
long time();
struct tm *localtime();
long cur_time;
struct tm *ltime;
FILE *fp;
char cmd[256];

	freopen("proc_error.c","w",stdout);

	puts(bc);
	puts("\tproc_error.c - print ecu procedure error");
	puts(ec);
	puts("/*+:EDITS:*/");

	cur_time = time((long *)0);
	ltime = localtime(&cur_time);
	printf(
	"/*:%02d-%02d-%04d-%02d:%02d-build_err-creation from ecuerror.h */\n",
	    ltime->tm_mon+1,ltime->tm_mday,ltime->tm_year + 1900,
	    ltime->tm_hour,ltime->tm_min);
	puts("");
	puts("#include \"ecu.h\"");
	puts("#include \"ecuerror.h\"");
	puts("");
	puts(bc);
	puts("\tproc_error(erc) - print error message");
	puts(ec);
	puts("void");
	puts("proc_error(erc)");
	puts("int erc;");
	puts("{");
	puts("\tswitch(erc)");
	puts("\t{");

	for(itmp = 0; itmp <= MAXFLDS; itmp++)
		fields[itmp] = NULL;

	fp = fopen("ecuerror.h","r");

	while(fgets(line,sizeof(line),fp))
	{
		line[strlen(line) - 1] = 0;
		fields[0] = line;
		field_count = splitter(" \t");
		if(!field_count || (strcmp(fields[1],"#define")))
			continue;
		if((!strcmp(fields[2],"eFATAL_ALREADY")) ||
			(!strcmp(fields[2],"eWARNING_ALREADY")) ||
			(!strncmp(fields[2],"_e",2)) ||
			(!strncmp(fields[2],"e_",2)))
			continue;
		printf("\t\tcase %s:\n",fields[2]);
		fputs("\t\t\tpputs(\"",stdout);

		for(itmp = 1; itmp < field_count - 1; itmp++)
			if(!strcmp(fields[itmp],"/*"))
				break;
		itmp++;

		for(; itmp < field_count - 1; itmp++)
		{
			fputs(fields[itmp],stdout);
			if(itmp != field_count - 2)
				fputc(' ',stdout);
		}
		fputs("\\n\");\n",stdout);
		puts("\t\t\tbreak;");
	}
	puts("\t\tcase eFATAL_ALREADY:");
	puts("\t\tcase eWARNING_ALREADY:");
	puts("\t\t\tbreak;");
	puts("\t\tdefault:");
	puts("\t\t\tpprintf(\"unknown error %x\\n\",erc);");
	puts("\t\t\tbreak;");

	puts("\t}");
	puts("} /* end of proc_error */\n");
	puts("/* vi: set tabstop=4 shiftwidth=4: */");
	puts("/* end of proc_error.c */");
	freopen("/dev/tty","a",stdout);
	sprintf(cmd,"fcrc -u proc_error.c");
	system(cmd);
	exit(0);
}	/* end of main */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of bperr.c */
