/*+-------------------------------------------------------------------------
	ecuvmin.h  --  set line default VMIN
	wht@n4hgf.Mt-Park.GA.US
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:09-10-1992-13:59-wht@n4hgf-ECU release 3.20 */
/*:08-22-1992-15:38-wht@n4hgf-ECU release 3.20 BETA */
/*:03-27-1992-16:21-wht@n4hgf-re-include protection for all .h files */
/*:07-25-1991-12:57-wht@n4hgf-ECU release 3.10 */
/*:08-14-1990-20:40-wht@n4hgf-ecu3.00-flush old edit history */

#ifndef _ecuvmin_h
#define _ecuvmin_h

#if defined(BUILDING_PROTOTYPES)	/* if building protos.h ... */
									/* ... pick up extra functions */
#define XENIX_VMIN		2	/* ... include vmin handling routines */
#else
#define XENIX_VMIN		1	/* this is the real value for vmin */
#endif

#endif /* _ecuvmin_h */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of ecuvmin.h */
