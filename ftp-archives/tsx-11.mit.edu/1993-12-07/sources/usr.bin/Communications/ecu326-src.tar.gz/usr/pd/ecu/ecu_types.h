/*+-------------------------------------------------------------------------
	ecu_types.h
	wht@n4hgf.Mt-Park.GA.US

We cannot always guarantee against multiple inclusion because
some old development environments don't protect against it.
We try and do it here ..... 1/2 of my incoming long distance 
support calls are because old XENIX systems don't do this.
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:09-10-1992-13:58-wht@n4hgf-ECU release 3.20 */
/*:08-22-1992-15:38-wht@n4hgf-ECU release 3.20 BETA */
/*:03-27-1992-16:21-wht@n4hgf-re-include protection for all .h files */
/*:01-29-1992-16:49-wht@n4hgf-creation */

#ifndef ___ECU_TYPES_H___
#define ___ECU_TYPES_H___
#ifndef NBBY	/* some types.h included by stdio.h and cannot be reincluded
				 * this is just an attempt ... you may have to hack */
#include <sys/types.h>
#endif
#endif

/* vi: set tabstop=4 shiftwidth=4: */
/* end of ecu_types.h */
