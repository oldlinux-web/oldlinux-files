/*+-------------------------------------------------------------------------
	ecufork.h 
	wht@n4hgf.Mt-Park.GA.US

for now just vehicle for deciding whether or not to debug fork/waits
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:09-10-1992-13:58-wht@n4hgf-ECU release 3.20 */
/*:08-22-1992-15:38-wht@n4hgf-ECU release 3.20 BETA */
/*:03-27-1992-16:21-wht@n4hgf-re-include protection for all .h files */
/*:07-25-1991-12:55-wht@n4hgf-ECU release 3.10 */
/*:08-14-1990-20:40-wht@n4hgf-ecu3.00-flush old edit history */

#ifndef _ecufork_h
#define _ecufork_h

/* #define FORK_DEBUG */

#endif /* _ecufork_h */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of ecufork.h */
