/* CHK=0xF551 */
/*+-------------------------------------------------------------------------
	testsel.c - test timeout interval of select()
	wht@n4hgf.Mt-Park.GA.US
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:09-10-1992-14:00-wht@n4hgf-ECU release 3.20 */
/*:08-22-1992-15:39-wht@n4hgf-ECU release 3.20 BETA */
/*:09-03-1991-19:57-wht@n4hgf-creation */

#include <stdio.h>
#ifdef M_SYSV /* SCO */
#include <sys/select.h>
#else
#include <sys/time.h>
#endif

/*+-------------------------------------------------------------------------
	main(argc,argv)
--------------------------------------------------------------------------*/
main(argc,argv)
int argc;
char **argv;
{
struct timeval tv;

	setbuf(stdout,NULL);

	while(1)
	{
		tv.tv_sec = 0;
		tv.tv_usec = 100*1000L;
		select(0,0,0,0,&tv);
		fputs("100 msec?\n",stdout);
	}

	exit(0);
}	/* end of main */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of testsel.c */
