/*+-------------------------------------------------------------------------
	ecucurses.h - bypass SCO <curses.h> problems
	wht@n4hgf.Mt-Park.GA.US

It is impossible to avoid warnings with various SCO curses installation
options, so we do it here
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:09-10-1992-13:58-wht@n4hgf-ECU release 3.20 */
/*:08-22-1992-15:38-wht@n4hgf-ECU release 3.20 BETA */
/*:03-27-1992-16:21-wht@n4hgf-re-include protection for all .h files */
/*:07-25-1991-12:55-wht@n4hgf-ECU release 3.10 */
/*:05-02-1991-02:35-wht@n4hgf-creation */

#ifndef _ecucurses_h
#define _ecucurses_h

/*
 * remove any pre-conceived notion of TERMINFO vs. TERMCAP curses (SCO)
 */
#if defined(M_TERMINFO)
#undef M_TERMINFO
#endif /* M_TERMINFO */

#if defined(M_TERMCAP)
#undef M_TERMCAP
#endif /* M_TERMCAP */


#if defined(M_SYSV) && !defined(LINUX)		/* any SCO */
/*
 * SCO uses TERMCAP curses at this time
 */
#define M_TERMCAP
#if defined(M_TERMCAP)
# include <tcap.h>
#else /* !M_TERMCAP */
# include <tinfo.h>
#endif /* M_TERMCAP */
#else /* !M_SYSV */
#if defined(sun)
# include <curses.h>
#else
/*
 * other uses TERMINFO curses at this time
 */
#define M_TERMINFO		/* some ecu code requires this despite non-SCO */
# include <ncurses.h>
#endif /* sun */
#endif /* M_SYSV */

#endif /* _ecucurses_h */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of ecucurses.h */
