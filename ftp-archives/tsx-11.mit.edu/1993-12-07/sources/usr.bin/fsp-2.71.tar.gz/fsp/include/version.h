#ifndef _FSP_VERSION_H_
#define _FSP_VERSION_H_

#ifdef VMS
#define VERSION_STR "VMS Version 2.7.1, May 21st, 1993"
#else
#define VERSION_STR "Version 2.7.1, May 21st, 1993"
#endif

#endif /* _FSP_VERSION_H_ */
