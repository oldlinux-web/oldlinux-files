#define USEDCHAR 97
#define FREECHAR ':'
#define GRAFIXON "\x1b(0"
#define GRAFIXOFF "\x1b(B"
#define TOPBAR		" lqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq" \
			"qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqk\n x"
#define CELLARBAR	"x\n mqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq" \
			"qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqj\n"
