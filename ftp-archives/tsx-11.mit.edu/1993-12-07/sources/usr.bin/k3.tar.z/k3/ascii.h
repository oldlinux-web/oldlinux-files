#define USEDCHAR '#'
#define FREECHAR ':'
#define GRAFIXON ""
#define GRAFIXOFF ""
#define TOPBAR		" +-------------------------------------" \
			"---------------------------------------+\n |"
#define CELLARBAR	"|\n +-------------------------------------" \
			"---------------------------------------+\n"
