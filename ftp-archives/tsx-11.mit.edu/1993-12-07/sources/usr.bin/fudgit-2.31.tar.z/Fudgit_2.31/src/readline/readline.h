/* Readline.h -- the names of functions callable from within readline. */

#ifndef _READLINE_H_
#define _READLINE_H_

#include "keymaps.h"

#ifndef __FUNCTION_DEF
typedef int Function ();
typedef int KFunction (int, int);
typedef void VFunction (char *);
typedef char *CFunction (char *, int);
typedef void CCFunction (char **);
#define __FUNCTION_DEF
#endif
typedef char *UFunction(char *, int, int);


/* The functions for manipulating the text of the line within readline.
Most of these functions are bound to keys by default. */
extern void rl_beg_of_line (int dum1, int dum2),
  rl_backward (int count, int dum2),
  rl_delete (int count, int invoking_key),
  rl_end_of_line (int dum1, int dum2),
  rl_forward (int count, int dum2),
  rl_backward (int count, int dum2),
  rl_newline (int count, int key),
  rl_kill_line (int direction, int dum2),
  rl_clear_screen (int dum1, int dum2),
  rl_get_next_history (int count, int dum2),
  rl_get_previous_history (int count, int dum2),
  rl_reverse_search_history (int sign, int key),
  rl_transpose_chars (int count, int dum2),
  rl_unix_word_rubout (int dum1, int dum2),
  rl_yank (int dum1, int dum2),
  rl_backward_word (int count, int dum2),
  rl_kill_word (int count, int dum2),
  rl_forward_word (int count, int dum2),
  rl_tab_insert (int count, int dum2),
  rl_yank_pop (int dum1, int dum2),
  rl_yank_nth_arg (int count, int ignore),
  rl_backward_kill_word (int count, int dum2),
  rl_backward_kill_line (int direction, int dum2),
  rl_transpose_words (int count, int dum2),
  rl_complete (int ignore, int invoking_key), 
  rl_possible_completions (int dum1, int dum2), 
  rl_do_lowercase_version (int ignore1, int ignore2), 
  rl_undo_command (int count, int dum2),
  rl_revert_line (int dum1, int dum2),
  rl_beginning_of_history (int dum1, int dum2),
  rl_end_of_history (int dum1, int dum2), 
  rl_forward_search_history (int sign, int key), 
  rl_insert (int count, int c),
  rl_upcase_word (int count, int dum2), 
  rl_downcase_word (int count, int dum2),
  rl_capitalize_word (int count, int dum2),
  rl_restart_output (int count, int key), 
  rl_re_read_init_file (int count, int ignore),
  rl_digit_argument (int ignore, int key), 
  rl_universal_argument (int dum1, int dum2),
  rl_abort (int dum1, int dum2),
  rl_unix_line_discard (int dummy1, int dummy2),
  rl_quoted_insert (int count, int dum2),
  rl_rubout (int count, int dummy);

extern int ding (void);

/* These are *both* defined even when VI_MODE is not. */
extern void rl_vi_editing_mode (int dum1, int dum2),
  rl_emacs_editing_mode (int dum1, int dum2);

#ifdef VI_MODE
/* Things for vi mode. */
extern int rl_vi_movement_mode (), rl_vi_insertion_mode (), rl_vi_arg_digit (),
rl_vi_prev_word (), rl_vi_next_word (), rl_vi_char_search (),
rl_vi_eof_maybe (), rl_vi_append_mode (), rl_vi_put (),
rl_vi_append_eol (), rl_vi_insert_beg (), rl_vi_delete (), rl_vi_comment (),
rl_vi_first_print (), rl_vi_fword (), rl_vi_fWord (), rl_vi_bword (),
rl_vi_bWord (), rl_vi_eword (), rl_vi_eWord (), rl_vi_end_word (),
rl_vi_change_case (), rl_vi_match (), rl_vi_bracktype (), rl_vi_change_char (),
rl_vi_yank_arg (), rl_vi_search (), rl_vi_search_again (),
rl_vi_dosearch (), rl_vi_subst (), rl_vi_overstrike (),
rl_vi_overstrike_delete (), rl_vi_replace(), rl_vi_column (),
rl_vi_delete_to (), rl_vi_change_to (), rl_vi_yank_to (), rl_vi_complete ();
#endif /* VI_MODE */

/* Keyboard macro commands. */
extern void rl_start_kbd_macro (int ignore1, int ignore2), 
  rl_end_kbd_macro (int count, int ignore), 
  rl_call_last_kbd_macro (int count, int ignore);

extern void rl_arrow_keys(int count, int c),
  rl_refresh_line (int dum1, int dum2);

/* Maintaining the state of undo.  We remember individual deletes and inserts
   on a chain of things to do. */

/* The actions that undo knows how to undo.  Notice that UNDO_DELETE means
   to insert some text, and UNDO_INSERT means to delete some text.   I.e.,
   the code tells undo what to undo, not how to undo it. */
enum undo_code { UNDO_DELETE, UNDO_INSERT, UNDO_BEGIN, UNDO_END };

/* What an element of THE_UNDO_LIST looks like. */
typedef struct undo_list {
  struct undo_list *next;
  int start, end;		/* Where the change took place. */
  char *text;			/* The text to insert, if undoing a delete. */
  enum undo_code what;		/* Delete, Insert, Begin, End. */
} UNDO_LIST;

/* The current undo list for RL_LINE_BUFFER. */
extern UNDO_LIST *rl_undo_list;

/* The data structure for mapping textual names to code addresses. */
typedef struct {
  char *name;
  KFunction *function;
} FUNMAP;

extern FUNMAP **funmap;

/* **************************************************************** */
/*								    */
/*			Well Published Variables		    */
/*								    */
/* **************************************************************** */

/* The name of the calling program.  You should initialize this to
   whatever was in argv[0].  It is used when parsing conditionals. */
extern char *rl_readline_name;

/* The line buffer that is in use. */
extern char *rl_line_buffer;

/* The location of point, and end. */
extern int rl_point, rl_end;

/* The name of the terminal to use. */
extern char *rl_terminal_name;

/* The input and output streams. */
extern FILE *rl_instream, *rl_outstream;

/* The basic list of characters that signal a break between words for the
   completer routine.  The initial contents of this variable is what
   breaks words in the shell, i.e. "n\"\\'`@$>". */
extern char *rl_basic_word_break_characters;

/* The list of characters that signal a break between words for
   rl_complete_internal.  The default list is the contents of
   rl_basic_word_break_characters.  */
extern char *rl_completer_word_break_characters;

/* List of characters that are word break characters, but should be left
   in TEXT when it is passed to the completion function.  The shell uses
   this to help determine what kind of completing to do. */
extern char *rl_special_prefixes;

/* Pointer to the generator function for completion_matches ().
   NULL means to use filename_entry_function (), the default filename
   completer. */
extern CFunction *rl_completion_entry_function;

/* If rl_ignore_some_completions_function is non-NULL it is the address
   of a function to call after all of the possible matches have been
   generated, but before the actual completion is done to the input line.
   The function is called with one argument; a NULL terminated array
   of (char *).  If your function removes any of the elements, they
   must be free()'ed. */
extern CCFunction *rl_ignore_some_completions_function;

/* Pointer to alternative function to create matches.
   Function is called with TEXT, START, and END.
   START and END are indices in RL_LINE_BUFFER saying what the boundaries
   of TEXT are.
   If this function exists and returns NULL then call the value of
   rl_completion_entry_function to try to match, otherwise use the
   array of strings returned. */
extern UFunction *rl_attempted_completion_function;

/* If non-null, this contains the address of a function to call if the
   standard meaning for expanding a tilde fails.  The function is called
   with the text (sans tilde, as in "foo"), and returns a malloc()'ed string
   which is the expansion, or a NULL pointer if there is no expansion. */
extern char *(*rl_tilde_expander)(char *);

/* If non-zero, then this is the address of a function to call just
   before readline_internal () prints the first prompt. */
extern VFunction *rl_startup_hook;

/* If non-zero, then this is the address of a function to call when
   completing on a directory name.  The function is called with
   the address of a string (the current directory name) as an arg. */
extern CCFunction *rl_symbolic_link_hook;

/* Non-zero means that modified history lines are preceded
   with an asterisk. */
extern int rl_show_star;

/* **************************************************************** */
/*								    */
/*			Well Published Functions		    */
/*								    */
/* **************************************************************** */

/* Read a line of input.  Prompt with PROMPT.  A NULL PROMPT means none. */
extern char *rl_readline (char *prompt);

/* Return an array of strings which are the result of repeatadly calling
   FUNC with TEXT. */
extern char **completion_matches (char *text, CFunction *entry_function);

/* rl_add_defun (char *name, Function *function, int key)
   Add NAME to the list of named functions.  Make FUNCTION
   be the function that gets called.
   If KEY is not -1, then bind it. */
extern void rl_add_defun (char *name, KFunction (*function), int key);

#endif /* _READLINE_H_ */
