
static int do_install(int argc, char **argv, char *l, Command *cmd)
{
	fprintf(stderr, "%s: Not supported on this machine.\n", cmd->fname);
	return(ERRR);
}

int Ft_initdl(void)
{
	return(0);
}
