#define AMACRO   1
#define ANALIAS  2
#define AFILE    3

typedef struct Macro {
		char *name;
		char *fname;
		char *line;
		int nargs;
		short type;
		struct Macro *next;
} Macro;

extern Macro *Ft_maclook(char *m, int type);
extern Macro *Ft_macinstall(char *name, char *line, int type);
extern char *Ft_readmacro(char *prompt);
extern char *Ft_nextline(char *prompt, int *eof);
extern char *Ft_expandedline(char *prompt, int type, int *eof);
extern Macro *Ft_mplisp(void);

