
typedef struct Meth {
	char *cname;
	char *name;
} Meth;

#define NONE     0
#define LS_REG   1
#define LA_REG   2
#define LS_FIT   3
#define SVD_FIT  4
#define ML_FIT   5
#define METHNUM  6

typedef struct Func {
	char *cname;
	char *name;
} Func;

#define STRL    1
#define POLY    2
#define LEG     3
#define SINE    4
#define COSINE  5
#define EXPO    6
#define GAUSS   7
#define USER    8
#define FUNCNUM 9
