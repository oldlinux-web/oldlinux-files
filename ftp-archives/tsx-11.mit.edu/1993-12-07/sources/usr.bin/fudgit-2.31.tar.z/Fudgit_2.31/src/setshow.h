extern double Ft_Q;
extern double **Ft_M1parxpar, **Ft_M2parxpar, *Ft_Mfparx1;
extern double **Ft_Mparxsamp;
extern int Ft_Mlist, *Ft_Miparx1;
extern double *Ft_A, *Ft_DA; 
extern double Ft_Cortest[];
extern double *Ft_Param, *Ft_Data, *Ft_X2;
extern int Ft_Samples;
extern int Ft_Debug;
extern int Ft_Check;
extern int Ft_Iter;
extern int Ft_Mode;
extern int Ft_Expandhist;
extern char *Ft_Tmp;
extern char *Ft_File;
extern char Ft_Shell[];
extern char Ft_Pager[];
extern char Ft_ReadFile[];
extern char Ft_Prompt_pm[];
extern char Ft_Prompt_fm[];
extern char Ft_Prompt_cm[];
extern char Ft_Home[];
extern char Ft_Vformat[];
extern char Ft_Format[];
extern char Ft_TFormat[];
extern char Ft_UFunction[];
extern char Ft_Pname[];
extern int Ft_Methi;
extern int Ft_Funci;
extern char *Ft_Plotting[];
extern char Ft_Comchar;
extern FILE *Ft_Outprint;
extern FILE *Ft_Inread;
extern char Ft_Outname[];
extern char Ft_Inname[];

#include "functions.h"

extern Meth Ft_Method[];
extern Func Ft_Function[];

