/*
 *  For systems not having this function.
 */

#include <string.h>

#ifndef NULL
#define NULL 0
#endif

char *strstr(s1, s2)
register char *s1;
register char *s2;
{
  register int i;
  register int len1 = strlen (s1);
  register int len2 = strlen (s2);

  for (i = 0; (len1 - i) >= len2; i++)
      if (strncmp(&s1[i], s2, len2) == 0)
          return (s1 + i);
  return ((char *)NULL);
}

