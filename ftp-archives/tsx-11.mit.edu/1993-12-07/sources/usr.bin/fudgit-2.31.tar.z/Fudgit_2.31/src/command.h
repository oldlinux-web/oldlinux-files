
struct Comm {
	char	 *name;
	int      (*func)(int, char **, char *, struct Comm *);
	char	 *fname;
	char     *usage;
	char     *help;
};
/*
I tried to solve a problem with HPUX that way: it seems to be a compiler bug...
typedef struct Comm Command;
*/
#define Command struct Comm
typedef int Do (int, char **, char *, Command *);
