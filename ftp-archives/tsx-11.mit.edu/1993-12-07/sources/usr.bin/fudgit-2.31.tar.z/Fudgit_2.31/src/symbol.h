#ifndef CODETYPE
typedef void Code;
#define CODETYPE
#endif

typedef struct AutoSymbol {
	char *name;
	short type;
	short level;
	short argno;
	struct AutoSymbol *next;
}  AutoSymbol;

typedef struct Symbol {
	char *name;
	short type;
	union {
		int val;
		char *vals;
	} size;
	union {
		double val;
		double *vec;
		char *str;
		double (*ptr)();
		Code (**defn)();
	} u;
	struct Symbol *next;
}  Symbol;

extern Symbol *Ft_install(char *s, int t, int size), *Ft_lookup(char *s), *Ft_geninstall(char *s, int t, int size);
extern int Ft_autolookup(char *s, int level), Ft_autoinstall(char *s, int type, int level);
extern Symbol *Ft_install(char *, int, int);
extern Symbol *Ft_lookup(char *s), *Ft_install(char *s, int t, int size);

extern int Ft_readvar (char **argp, Symbol **sym, int *loc, int (*irange)[32], double (*range)[32], int *lines, int num, int exec, char *comname);

