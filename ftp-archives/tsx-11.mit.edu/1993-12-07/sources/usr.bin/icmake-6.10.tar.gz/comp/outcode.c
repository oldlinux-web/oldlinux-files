/*
                        O U T C O D E . C
*/

#include "iccomp.h"

void outcode(ESTRUC_ *ep, int value, register unsigned size)
{
    register unsigned
        codelen;
    char
        buffer[2];

    codelen = ep->code ?
                ep->codelen
            :
                0;

    if (size == sizeof(char))
        buffer[0] = (char)value;
    else
        *(INT16 *)buffer = (INT16)value;

    memcpy(                                 /* append new code */
        (ep->code = xrealloc(ep->code, (codelen + size) * sizeof(char)))
                                                                   + codelen,
        buffer,
        size);


    ep->codelen = codelen + size;
}