/*
                              P A T C H U P . C
*/

#include "iccomp.h"

void patchup(code, len, list, listlen, pos)
    INT8
        *code;
    unsigned
        listlen,
        len,
        *list;
    int
        pos;
{
    register unsigned
        index,
        beyond_jump;

    if (!listlen)
        return;

    if (pos)
        pos = len;

    for (index = 0; index < listlen; index++)
    {
        beyond_jump = list[index];
#ifndef SPARC      				/* 'ordinary' code */
        *((INT16 *)&code[beyond_jump - 2 * sizeof(INT8)]) = pos - beyond_jump;
#else						/* SPARC patch code */
	{
	    int
	    	byte_index;
	    	
	    byte_index = beyond_jump - 2 * sizeof(INT8);
	    code[byte_index++] = (INT8) ((pos - beyond_jump) / 256);
            code[byte_index] = (INT8)((pos-beyond_jump) % 256);
        }
#endif        
    }
    
    free(list);
}
