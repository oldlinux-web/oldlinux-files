#ifndef MSDOS

#include <stdio.h>
#include "icrss.h"

unsigned redirect_start (unsigned x, unsigned y)
{
    return (1);
}

#endif

