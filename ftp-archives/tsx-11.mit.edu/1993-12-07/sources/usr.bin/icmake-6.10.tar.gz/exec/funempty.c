void fun_empty ()
{
}