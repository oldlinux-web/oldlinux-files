#include "icmun.h"

void fun_pop_reg ()
{
    puts ("        pop reg");
}
