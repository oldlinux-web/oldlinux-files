#include "icmun.h"

void fun_xor ()
{
    puts ("        xor");
}
