
/*
                                            V E R S I O N . C
*/

#include "icmun.h"

char
    version [] = "6.02",
    release[] = "1992, 1993";
