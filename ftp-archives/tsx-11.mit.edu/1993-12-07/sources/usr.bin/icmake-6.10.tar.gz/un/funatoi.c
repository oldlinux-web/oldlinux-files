#include "icmun.h"

void fun_atoi ()
{
    puts ("        atoi");
}
