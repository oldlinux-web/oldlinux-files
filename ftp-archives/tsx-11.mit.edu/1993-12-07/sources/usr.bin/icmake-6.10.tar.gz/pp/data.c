#include "icm-pp.h"

char
    *imdir,
    lexbuf [3000];

DEFINED_
    *defined;

FILE
    *outfile;

FILESTACK_
    *filestack;

int
    filesp = -1,
    ndefined;
