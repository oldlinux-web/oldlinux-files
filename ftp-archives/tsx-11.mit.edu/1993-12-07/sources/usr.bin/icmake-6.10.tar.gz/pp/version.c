/*
                                V E R S I O N . C
*/
char
    version[] = "6.00",
    release[] = "1992, 1993";
