/*
 * The Xenix filesystem constants/structures
 */

#ifndef _LINUX_XENIX_FS_H
#define _LINUX_XENIX_FS_H

#include <linux/types.h>
typedef unsigned short short_ino_t;
typedef unsigned int block_nr_t;

#define XENIX_NAME_LEN 14
#define XENIX_ROOT_INO 2

#define	XENIX_SB_NICINOD 100	/* number of superblock inodes */
#define	XENIX_SB_NICFREE 100	/* number of superblock free blocks */
#define	XENIX_SB_FILL	371	/* aligns s_magic at end of super block */
#define	XENIX_SB_CLEAN	0106	/* s_clean, arbitrary magic value  */
#define	XENIX_SB_MAGIC 0x2b5544	/* s_magic, system 3 arbitrary magic value */
#define	XENIX_SB_B512	1	/* s_type, 512 byte block */
#define	XENIX_SB_B1024	2	/* s_type, 1024 byte block */

#define XENIX_LINK_MAX	126	/* max number of hard links to an inode */

/*
 * A kludgey implementation of symbolic links using a hopefully unused
 * value for the mode bits: sticky bit only.  We try to avoid the case where
 * the user tries to set this (and collide with our usage), by turning such
 * chmod's into XENIX_KLUDGE_AVOID (not implemented yet).
 */

#define XENIX_KLUDGE_SYMLINKS		/* FIXME: should be in config file */

#define XENIX_KLUDGE_SYMLINK_MODE	(S_IFREG + S_ISVTX)
#define XENIX_KLUDGE_AVOID		(S_IFREG + S_ISVTX + S_IRUSR)

#define XENIX_INODES_PER_BLOCK		((BLOCK_SIZE) / (sizeof (struct xenix_inode)))
#define XENIX_DIR_ENTRY_SIZE		(sizeof (struct xenix_dir_entry))
#define XENIX_DIR_ENTRIES_PER_BLOCK	((BLOCK_SIZE) / XENIX_DIR_ENTRY_SIZE)

struct xenix_inode {
	umode_t i_mode;		/* mode and type of file */
	nlink_t i_nlink;    	/* number of links to file */
	uid_t i_uid;      	/* owner's user id */
	gid_t i_gid;      	/* owner's group id */
	off_t i_size;     	/* number of bytes in file */
	char i_addr[40];	/* disk block addresses */
	time_t i_atime;   	/* time last accessed */
	time_t i_mtime;   	/* time last modified */
	time_t i_ctime;   	/* time created */
};

/*
 * the 40 address bytes: 39 used; 13 addresses of 3 bytes each.
 */

/*#pragma pack(2)*/		/* FIXME: what is gcc's version of this? */

struct xenix_super_block {
	unsigned short xs_isize;/* size in blocks of i-list */
#ifdef XENIX_GOT_PACK_2
	block_nr_t xs_fsize;	/* size in blocks of entire volume */
#else
	char xs_fsize[sizeof(block_nr_t)];
#endif
	unsigned short xs_nfree; /* number of addresses in xs_free */
#ifdef XENIX_GOT_PACK_2
	block_nr_t xs_free[XENIX_SB_NICFREE]; /* free block list */
#else
	char xs_free[XENIX_SB_NICFREE * sizeof(block_nr_t)];
#endif
	short_ino_t xs_ninode;	/* number of i-nodes in xs_inode */
	short_ino_t xs_inode[XENIX_SB_NICINOD]; /* free i-node list */
	char xs_flock;		/* lock during free list manipulation */
	char xs_ilock;		/* lock during i-list manipulation */
	char xs_fmod;		/* super block modified flag */
	char xs_ronly;		/* mounted read-only flag */
#ifdef XENIX_GOT_PACK_2
	time_t xs_time;		/* last super block update */
	block_nr_t xs_tfree;	/* total free blocks */
#else
	char xs_time[sizeof(time_t)];
	char xs_tfree[sizeof(block_nr_t)];
#endif
	short_ino_t xs_tinode;	/* total free inodes */
	short xs_dinfo[4];	/* device information */
	char xs_fname[6];	/* file system name */
	char xs_fpack[6];	/* file system pack name */
	/* remainder is maintained for xenix */
	char xs_clean;		/* S_CLEAN if structure is properly closed */
	char xs_fill[XENIX_SB_FILL];/* space to make sizeof filsys be BSIZE */
	long xs_magic;		/* indicates version of filsys */
	long xs_type;		/* type of new file system */
};

/*#pragma pack()*/

struct xenix_dir_entry {
	short_ino_t inode;
	char name[XENIX_NAME_LEN];
};

struct xenix_free_block {
	unsigned short xfb_nfree;
#ifdef XENIX_GOT_PACK_2
	block_nr_t xfb_free[XENIX_SB_NICFREE];
#else
	char xfb_free[XENIX_SB_NICFREE * sizeof(block_nr_t)];
#endif
};

/*
 * Simplifies porting ...
 */

#define s_xenix_bh	u.xenix_sb.s_bh
#define s_xenix_xsb	u.xenix_sb.s_xsb
#define s_xenix_isize	u.xenix_sb.s_isize
#define s_xenix_fsize	u.xenix_sb.s_fsize
#define s_xenix_nfree	u.xenix_sb.s_xsb->xs_nfree
#define s_xenix_free	u.xenix_sb.s_xsb->xs_free	/* MISALIGNED! */
#define s_xenix_ninode	u.xenix_sb.s_xsb->xs_ninode
#define s_xenix_inode	u.xenix_sb.s_xsb->xs_inode
#define s_xenix_tfree	u.xenix_sb.s_xsb->xs_tfree	/* MISALIGNED! */
#define s_xenix_tinode	u.xenix_sb.s_xsb->xs_tinode

/*
 * Debugging stuff ...
 */

extern char xenix_inodes;
extern char xenix_blocks;

/*
 * Function prototypes ...
 */

extern int xenix_lookup(struct inode * dir,const char * name, int len,
	struct inode ** result);
extern int xenix_create(struct inode * dir,const char * name, int len, int mode,
	struct inode ** result);
extern int xenix_mkdir(struct inode * dir, const char * name, int len, int mode);
extern int xenix_rmdir(struct inode * dir, const char * name, int len);
extern int xenix_unlink(struct inode * dir, const char * name, int len);
extern int xenix_symlink(struct inode * inode, const char * name, int len,
	const char * symname);
extern int xenix_link(struct inode * oldinode, struct inode * dir, const char * name, int len);
extern int xenix_mknod(struct inode * dir, const char * name, int len, int mode, int rdev);
extern int xenix_rename(struct inode * old_dir, const char * old_name, int old_len,
	struct inode * new_dir, const char * new_name, int new_len);
extern struct inode * xenix_new_inode(const struct inode * dir);
extern void xenix_free_inode(struct inode * inode);
extern unsigned long xenix_count_free_inodes(struct super_block * sb);
extern unsigned long xenix_count_total_inodes(struct super_block * sb);
extern int xenix_new_block(struct super_block * sb);
extern void xenix_free_block(struct super_block * sb, int block);
extern unsigned long xenix_count_free_blocks(struct super_block * sb);
extern unsigned long xenix_count_total_blocks(struct super_block * sb);

extern int xenix_bmap(struct inode *,int);

extern struct buffer_head * xenix_getblk(struct inode *, int, int);
extern struct buffer_head * xenix_bread(struct inode *, int, int);

extern void xenix_truncate(struct inode *);
extern void xenix_put_super(struct super_block *);
extern struct super_block *xenix_read_super(struct super_block *,void *, int);
extern void xenix_read_inode(struct inode *);
extern void xenix_write_inode(struct inode *);
extern void xenix_put_inode(struct inode *);
extern void xenix_statfs(struct super_block *, struct statfs *);

extern struct inode_operations xenix_file_inode_operations;
extern struct inode_operations xenix_dir_inode_operations;
extern struct inode_operations xenix_symlink_inode_operations;

extern struct file_operations xenix_file_operations;
extern struct file_operations xenix_dir_operations;

#endif
