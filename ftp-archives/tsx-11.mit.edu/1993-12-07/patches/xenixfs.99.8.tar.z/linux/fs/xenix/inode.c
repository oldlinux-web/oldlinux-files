/*
 * linux/fs/xenix/inode.c
 *
 * (C) 1991  Linus Torvalds
 *
 * Taken from minix/inode.c, modified by Doug Evans, dje@sspiff.uucp, 92Jun04.
 *
 * This file contains code for allocating/freeing inodes and for read/writing
 * the superblock.
 */

#include <linux/sched.h>
#include <linux/fs.h>
#include <linux/xenix_fs.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/string.h>
#include <linux/stat.h>
#include <linux/locks.h>

#include <asm/system.h>
#include <asm/segment.h>

/* sizeof() cast to int: see truncate.c */
#define BLOCKS_PER_BLOCK	(BLOCK_SIZE / (int) sizeof(daddr_t))

char xenix_inodes = 0;	/* for debugging */
char xenix_blocks = 0;

inline static int
read3byte(unsigned char *p, int index)
{
	return p[index * 3] + (p[index * 3 + 1] << 8) + (p[index * 3 + 2] << 16);
}

inline static void
write3byte(unsigned char *p, int index, int val)
{
	p[index * 3] = (unsigned char) val;
	p[index * 3 + 1] = (unsigned char) (val >> 8);
	p[index * 3 + 2] = (unsigned char) (val >> 16);
}

static struct super_operations xenix_sops = { 
	xenix_read_inode,
	NULL,
	xenix_write_inode,
	xenix_put_inode,
	xenix_put_super,
	NULL,
	xenix_statfs
};

void
xenix_put_inode(struct inode *inode)
{
	if (inode->i_nlink)
		return;
	inode->i_size = 0;
	xenix_truncate(inode);
	xenix_free_inode(inode);
}

void
xenix_put_super(struct super_block *sb)
{
	struct buffer_head * bh;
	struct xenix_super_block * xsb;

	lock_super(sb);
	bh = sb->s_xenix_bh;
	xsb = sb->s_xenix_xsb;
#ifdef XENIX_GOT_PACK_2
	xsb->xs_time = CURRENT_TIME;
#else
	*(time_t *) xsb->xs_time = CURRENT_TIME;
#endif
	xsb->xs_clean = XENIX_SB_CLEAN;
	bh->b_dirt = 1;
	brelse(bh);
	sb->s_dev = 0;
	unlock_super(sb);
}

struct super_block *
xenix_read_super(struct super_block * s, void * data, int silent)
{
	struct buffer_head * bh;
	struct xenix_super_block * xsb;
	int dev = s->s_dev;

	lock_super(s);
	if (!(bh = bread(dev, 1, BLOCK_SIZE))) {
		s->s_dev = 0;
		unlock_super(s);
		printk("XENIX-fs: unable to read superblock\n");
		return NULL;
	}
	s->s_blocksize = 1024;
	s->s_xenix_bh = bh;
	s->s_xenix_xsb = xsb = (struct xenix_super_block *) bh->b_data;
#if 0
	hex_dump(xsb, 1024);
	printk("xsb: 0x%x, &xs_magic: 0x%x\n", xsb, &xsb->xs_magic);
#endif
	if (xsb->xs_magic != XENIX_SB_MAGIC) {
		s->s_dev = 0;
		brelse(bh);
		unlock_super(s);
		if (!silent)
			printk("VFS: Can't find a xenix filesystem on dev 0x%04x\n",
				dev);
		return NULL;
	}
	s->s_magic = xsb->xs_magic;
	/*
	 * <s_xenix_isize, s_xenix_fsize> are kept in the main super_block
	 * struct because they are constant, and <s_xenix_fsize> suffers from
	 * being wrongly aligned.
	 */
	s->s_xenix_isize = xsb->xs_isize;
#ifdef XENIX_GOT_PACK_2
	s->s_xenix_fsize = xsb->xs_fsize;
#else
	s->s_xenix_fsize = *(daddr_t *) xsb->xs_fsize;
#endif
	/* set up enough so that it can read an inode */
	s->s_dev = dev;
	s->s_op = &xenix_sops;
	s->s_mounted = iget(s, XENIX_ROOT_INO);
	unlock_super(s);
	if (!s->s_mounted) {
		s->s_dev = 0;
		brelse(bh);
		printk("XENIX-fs: get root inode failed\n");
		return NULL;
	}
	/* <bh> is freed when the disk is unmounted */
	return s;
}

void
xenix_statfs(struct super_block * sb, struct statfs * buf)
{
	unsigned long tmp;

	put_fs_long(XENIX_SB_MAGIC, &buf->f_type);
	put_fs_long(1024, &buf->f_bsize);
	put_fs_long(xenix_count_total_blocks(sb), &buf->f_blocks);
	tmp = xenix_count_free_blocks(sb);
	put_fs_long(tmp, &buf->f_bfree);
	put_fs_long(tmp, &buf->f_bavail);
	put_fs_long(xenix_count_total_inodes(sb), &buf->f_files);
	put_fs_long(xenix_count_free_inodes(sb), &buf->f_ffree);
	put_fs_long(XENIX_NAME_LEN, &buf->f_namelen);
	/* Don't know what value to put in buf->f_fsid */
}

#define inode_bmap(inode, nr)	((inode)->u.xenix_i.i_data[(nr)])

static block_nr_t
block_bmap(struct buffer_head * bh, int nr)
{
	block_nr_t tmp;

	if (!bh)
		return 0;
	tmp = ((block_nr_t *) bh->b_data)[nr];
	brelse(bh);
	return tmp;
}

int
xenix_bmap(struct inode * inode, int block)
{
	block_nr_t i;

	if (block < 0) {
		printk("xenix_bmap: block<0\n");
		return 0;
	}
	if (block >= 10 + BLOCKS_PER_BLOCK + BLOCKS_PER_BLOCK * BLOCKS_PER_BLOCK) {
		printk("xenix_bmap: block>big\n");
		return 0;
	}
	if (block < 10)
		return inode_bmap(inode, block);
	block -= 10;
	if (block < BLOCKS_PER_BLOCK) {
		i = inode_bmap(inode, 10);
		if (!i)
			return 0;
		return block_bmap(bread(inode->i_dev, i, BLOCK_SIZE), block);
	}
	block -= BLOCKS_PER_BLOCK;
	i = inode_bmap(inode, 11);
	if (!i)
		return 0;
	i = block_bmap(bread(inode->i_dev, i, BLOCK_SIZE), block >> 8);
		/* 8: log2(BLOCKS_PER_BLOCK) */
	if (!i)
		return 0;
	return block_bmap(bread(inode->i_dev, i, BLOCK_SIZE), block & 255);
}

static struct buffer_head *
inode_getblk(struct inode * inode, block_nr_t nr, int create)
{
	block_nr_t tmp,*p;
	struct buffer_head * result;

	p = inode->u.xenix_i.i_data + nr;
repeat:
	tmp = *p;
	if (tmp) {
		result = getblk(inode->i_dev, tmp, BLOCK_SIZE);
		if (tmp == *p)
			return result;
		brelse(result);
		goto repeat;
	}
	if (!create)
		return NULL;
	tmp = xenix_new_block(inode->i_sb);
	if (!tmp)
		return NULL;
	result = getblk(inode->i_dev, tmp, BLOCK_SIZE);
	if (*p) {
		xenix_free_block(inode->i_sb, tmp);
		brelse(result);
		goto repeat;
	}
	*p = tmp;
	inode->i_ctime = CURRENT_TIME;
	inode->i_dirt = 1;
	return result;
}

static struct buffer_head *
block_getblk(struct inode * inode, struct buffer_head * bh, block_nr_t nr, int create)
{
	block_nr_t tmp,*p;
	struct buffer_head * result;

	if (!bh)
		return NULL;
	if (!bh->b_uptodate) {
		ll_rw_block(READ, 1, &bh);
		wait_on_buffer(bh);
		if (!bh->b_uptodate) {
			brelse(bh);
			return NULL;
		}
	}
	p = nr + (block_nr_t *) bh->b_data;
repeat:
	tmp = *p;
	if (tmp) {
		result = getblk(bh->b_dev, tmp, BLOCK_SIZE);
		if (tmp == *p) {
			brelse(bh);
			return result;
		}
		brelse(result);
		goto repeat;
	}
	if (!create) {
		brelse(bh);
		return NULL;
	}
	tmp = xenix_new_block(inode->i_sb);
	if (!tmp) {
		brelse(bh);
		return NULL;
	}
	result = getblk(bh->b_dev, tmp, BLOCK_SIZE);
	if (*p) {
		xenix_free_block(inode->i_sb, tmp);
		brelse(result);
		goto repeat;
	}
	*p = tmp;
	bh->b_dirt = 1;
	brelse(bh);
	return result;
}

struct buffer_head *
xenix_getblk(struct inode * inode, int block, int create)
{
	struct buffer_head * bh;

	if (block < 0) {
		printk("xenix_getblk: block<0");
		return NULL;
	}
	if (block >= 10 + BLOCKS_PER_BLOCK + BLOCKS_PER_BLOCK * BLOCKS_PER_BLOCK) {
		printk("xenix_getblk: block>big");
		return NULL;
	}
	if (block < 10)
		return inode_getblk(inode, block, create);
	block -= 10;
	if (block < BLOCKS_PER_BLOCK) {
		bh = inode_getblk(inode, 10, create);
		return block_getblk(inode, bh, block, create);
	}
	block -= BLOCKS_PER_BLOCK;
	bh = inode_getblk(inode, 11, create);
	bh = block_getblk(inode, bh, block >> 8, create);
		/* 8: log2(BLOCKS_PER_BLOCK) */
	return block_getblk(inode, bh, block & 255, create);
}

struct buffer_head *
xenix_bread(struct inode * inode, int block, int create)
{
	struct buffer_head * bh;

	bh = xenix_getblk(inode, block, create);
	if (!bh || bh->b_uptodate)
		return bh;
	ll_rw_block(READ, 1, &bh);
	wait_on_buffer(bh);
	if (bh->b_uptodate)
		return bh;
	brelse(bh);
	return NULL;
}

void
xenix_read_inode(struct inode * inode)
{
	struct buffer_head * bh;
	struct xenix_inode * raw_inode;
	int block, ino;

	DEBUGPK(xenix_inodes, ("xenix_read_inode: dev 0x%x, inode %d\n",
		inode->i_dev, inode->i_ino));

	ino = inode->i_ino;
	inode->i_op = NULL;
	inode->i_mode = 0;
	if (!ino || ino >= inode->i_sb->s_xenix_isize * XENIX_INODES_PER_BLOCK) {
		printk("Bad inode number on dev 0x%04x: %d is out of range\n",
			inode->i_dev, ino);
		return;
	}

	block = 2 + (inode->i_ino - 1) / XENIX_INODES_PER_BLOCK;
	if (!(bh = bread(inode->i_dev, block, BLOCK_SIZE))) {
		printk("Major problem: unable to read inode from dev 0x%04x\n",
			inode->i_dev);
		return;
	}

	raw_inode = ((struct xenix_inode *) bh->b_data) +
		(ino - 1) % XENIX_INODES_PER_BLOCK;
	inode->i_mode = raw_inode->i_mode;
	inode->i_uid = raw_inode->i_uid;
	inode->i_gid = raw_inode->i_gid;
	inode->i_nlink = raw_inode->i_nlink;
	inode->i_size = raw_inode->i_size;
	inode->i_ctime = raw_inode->i_ctime;
	inode->i_mtime = raw_inode->i_mtime;
	inode->i_atime = raw_inode->i_atime;
	inode->i_blocks = inode->i_blksize = 0;
#ifdef XENIX_KLUDGE_SYMLINKS
	if (inode->i_mode == XENIX_KLUDGE_SYMLINK_MODE) {
		inode->i_mode = S_IFLNK | 0777;
		if (inode->i_size > 1023) {
			printk("xenix_read_inode: symlink has size %d\n",
				inode->i_size);
			inode->i_size = 1023;
		}
	}
#endif
	if (S_ISCHR(inode->i_mode) || S_ISBLK(inode->i_mode))
		inode->i_rdev = read3byte(raw_inode->i_addr, 0);
	else for (block = 0; block < 13; block++)
		inode->u.xenix_i.i_data[block] = read3byte(raw_inode->i_addr, block);
	brelse(bh);
	if (S_ISREG(inode->i_mode))
		inode->i_op = &xenix_file_inode_operations;
	else if (S_ISDIR(inode->i_mode))
		inode->i_op = &xenix_dir_inode_operations;
	else if (S_ISLNK(inode->i_mode))
		inode->i_op = &xenix_symlink_inode_operations;
	else if (S_ISCHR(inode->i_mode))
		inode->i_op = &chrdev_inode_operations;
	else if (S_ISBLK(inode->i_mode))
		inode->i_op = &blkdev_inode_operations;
	else if (S_ISFIFO(inode->i_mode))
		init_fifo(inode);
}

void
xenix_write_inode(struct inode * inode)
{
	struct buffer_head * bh;
	struct xenix_inode * raw_inode;
	int ino, block;

	DEBUGPK(xenix_inodes, ("xenix_write_inode: dev 0x%x, inode %d\n",
		inode->i_dev, inode->i_ino));

	ino = inode->i_ino;
	if (!ino || ino >= inode->i_sb->s_xenix_isize * XENIX_INODES_PER_BLOCK) {
		printk("Bad inode number on dev 0x%04x: %d is out of range\n",
			inode->i_dev, ino);
		inode->i_dirt = 0;
		return;
	}

	block = 2 + (ino - 1) / XENIX_INODES_PER_BLOCK;
	if (!(bh = bread(inode->i_dev, block, BLOCK_SIZE))) {
		printk("xenix_write_inode: unable to read i-node block (dev %d, block %d)\n",
			inode->i_dev, block);
		inode->i_dirt = 0;
		return;
	}
	raw_inode = ((struct xenix_inode *) bh->b_data) +
		(ino - 1) % XENIX_INODES_PER_BLOCK;
	raw_inode->i_mode = inode->i_mode;
	raw_inode->i_uid = inode->i_uid;
	raw_inode->i_gid = inode->i_gid;
	raw_inode->i_nlink = inode->i_nlink;
	raw_inode->i_size = inode->i_size;
	raw_inode->i_ctime = inode->i_ctime;
	raw_inode->i_mtime = inode->i_mtime;
	raw_inode->i_atime = inode->i_atime;
#ifdef XENIX_KLUDGE_SYMLINKS
	if (S_ISLNK(raw_inode->i_mode)) {
		raw_inode->i_mode = XENIX_KLUDGE_SYMLINK_MODE;
		if (raw_inode->i_size > 1023)
			printk("xenix_write_inode: symlink has size %d\n",
				raw_inode->i_size);
	}
#endif
	if (S_ISCHR(inode->i_mode) || S_ISBLK(inode->i_mode))
		write3byte(raw_inode->i_addr, 0, inode->i_rdev);
	else for (block = 0; block < 13; block++)
		write3byte(raw_inode->i_addr, block, inode->u.xenix_i.i_data[block]);
	inode->i_dirt = 0;
	bh->b_dirt = 1;
	brelse(bh);
}
