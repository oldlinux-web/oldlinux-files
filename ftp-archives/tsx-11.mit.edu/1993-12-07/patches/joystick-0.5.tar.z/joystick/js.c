#include <fcntl.h>
#include <stdio.h>
#include <linux/joystick.h>

extern int errno;

main(argc,argv)
int argc;
char *argv[];
{
int fd;
char fnme[40];
struct JS_DATA_TYPE js;
if (argc == 2) {
sprintf(fnme,"/dev/js%d",atoi(argv[1]));
if ((fd=open(fnme,O_RDONLY)) <1) die("open");
while (1) {
if (read(fd,&js,JS_RETURN) != JS_RETURN) die("read");
fprintf(stdout,"%x %04x %04x\r",js.buttons,js.x,js.y);
fflush(stdout);
}
close(fd);
}
else fprintf(stderr,"Usage: js <0|1>\n");
}

die(str)
char *str;
{
	printf("%s failed %d\n",str,errno);
	exit(-1);
}
