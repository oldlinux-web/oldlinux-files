#include <stdio.h>
#include <fcntl.h>
#include <linux/joystick.h>

extern int errno;

main(argc,argv)
int argc;
char *argv[];
{
int fd,js,ln,tmp;
long tmpl;
struct JS_DATA_TYPE js_data;
char file[20];
if (argc != 2) usage();
if ((js=atoi(argv[1])) != 0 && js != 1) usage();
sprintf(file,"/dev/js%d",js);
printf("Trying %s\n",file);
if ((fd=open(file,O_RDONLY)) < 0) die("Error opening",file);
if (ioctl(fd,JS_GET_TIMEOUT,&tmp) == -1) die("Joystick ioctl failed","");
printf("Timeout value=%d\n",tmp);
if (ioctl(fd,JS_GET_TIMELIMIT,&tmpl) == -1) die("Joystick ioctl failed","");
printf("Timelimit value=%ld ms\nSetting Timelimit= 100 ms\n",tmpl);
tmpl=100;
if (ioctl(fd,JS_SET_TIMELIMIT,&tmpl) == -1) die("Joystick ioctl failed","");
if (ioctl(fd,JS_GET_CAL,&js_data) == -1) die("Joystick ioctl failed","");
printf("Current correction:%d,%d\n",js_data.x,js_data.y);
printf("Move joystick to lower right and press either button\n");
while ((read(fd,&js_data,JS_RETURN) > 0) && js_data.buttons == 0x00)
	printf("Got x=%04x, y=%04x\r",js_data.x,js_data.y);
for(tmp=0;js_data.x > 0xff;tmp++,js_data.x=js_data.x >> 1);
js_data.x=tmp;
for(tmp=0;js_data.y > 0xff;tmp++,js_data.y=js_data.y >> 1);
js_data.y=tmp;
printf("Setting correction:%d,%d\n",js_data.x,js_data.y);
if (ioctl(fd,JS_SET_CAL,&js_data) == -1) die("Joystick ioctl failed","");
if (ioctl(fd,JS_GET_CAL,&js_data) == -1) die("Joystick ioctl failed","");
printf("Verify Correction:%d,%d\n",js_data.x,js_data.y);
while (1)
if (read(fd,&js_data,JS_RETURN) != JS_RETURN) printf("read failed %d\n",errno);
else {
fprintf(stdout,"%x %x %x        \r",js_data.buttons,js_data.x,js_data.y);
fflush(stdout);
}
(void) close(fd);
}

int usage()
{
die("Usage: jscal <0|1>\n","");
}

die(s1,s2)
char *s1,s2;
{
printf("%s %s %d\n",s1,s2,errno);
exit(-1);
}
