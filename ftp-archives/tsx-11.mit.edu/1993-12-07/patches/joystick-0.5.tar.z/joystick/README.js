This describes how to install the joystick device driver V0.5 in the Linux
0.99pl9 kernel. The driver was written and tested on a 486DX2-50 computer with
GCC2.3.3/libc4.2. Unpacking the js05.tar.z file (at the top of your source tree,
usually /usr/src) should create six new files:
	./linux/include/linux/joystick.h
	./linux/kernel/chr_drv/joystick.c
	./js.pat999
	./joystick/js.c
	./joystick/jscal.c
	./joystick/README.js (this file).
If you have a different kernel level you may have to apply the patches by hand.
If you are UPGRADING from a previous release of the joystick drivers you will
need to uninstall the previous version and then apply js.pat999 with
patch -p0 < js.pat999.
After this cd to ./linux and make config answering 'y' to the joystick question.
SAVE A BACKUP OF YOUR CURRENT KERNEL, remake the kernel, and reboot the new
kernel.  To use the joystick driver two files should be made in /dev. To do
this:
	mknod /dev/js0 c 15 0 and
	mknod /dev/js1 c 15 1.
To test the driver cd ./joystick and compile js.c and jscal.c.
Js prints out the buttons and joystick values continuously.
Jscal allows the joysticks to be calibrated to return values between 0 and 0xff
(or as close as can be done with shifting). The driver has been modified to not
use floating point. This should prevent kernel panics... For more details read
the version section of joystick.c. If you have any questions of problems
please let me (asmith@cbnewsd.att.com) know.
	Thanks,
	Art
