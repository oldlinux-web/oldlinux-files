__divsf3()
{return 0;}

__cmpsf2()
{return 0;}

__mulsf3 ()
{return 0;}

__addsf3 ()
{return 0;}

fabs ()
{return 0;}

ecvt ()
{return 0;}
