/*
**	$Id: release.h,v 2.0 90/09/19 20:16:46 paul Rel $
**
**	Getty release/date
*/


/* these are used by the man pages, too
 */
#define	RELEASE		"2.0.7"		/* release number */
#define	DATE		"04-04-93"	/* release date */


/* end of release.h */
