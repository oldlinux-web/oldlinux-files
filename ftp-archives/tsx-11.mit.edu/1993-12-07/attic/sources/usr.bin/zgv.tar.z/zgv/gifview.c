/* GIFVIEW - shows gif via vgalib in Linux, sort of scrolly, zoom, etc.
 * (c) 1993 Russell Marks for improbabledesigns.
 */

/* s'funny, y'know, I tried buffering the input, because it gets
 * it byte by byte (!) - but it actually *slowed down*!
 * Weird. So Mr. BFI here stays happy. :)
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>
#include <stdlib.h>
#include <vga.h>

typedef unsigned char byte;

/* default mode; you may want to change to, say, G320x240x256 */
/* and also change 'virtual=1' to 'virtual=0' */
int curvgamode=G360x480x256;
int zoom=0,virtual=1;
int vkludge=0;
struct {
  int rgb;
  byte col;
  } vkcache[65536];

#define MOVSTP 10    /* for q,a,o,p panning */
#define BIGSTP 100   /* for Q,A,O,P panning (i.e. with shift) */

byte *theimage;

float contrast=1;
int brightness=0;
int pixgo=0,pixstart,pixnum,rcol=4;
int bound;
int width2;
int scrnwide,scrnhigh,realscrnwide;

struct {
  char sig[6];           /* should be GIF87a */
  byte wide_lo,wide_hi;  /* NUXI Problem Avoidance System (tm) */
  byte high_lo,high_hi;  /* these are 'screen size', BTW */
  byte misc;             /* misc, and bpp */
  byte back;             /* background index */
  byte zero;             /* if this ain't zero, problem */
  } gifhed;
struct {
  byte left_lo,left_hi;  /* usually zero - ignore */
  byte top_lo,top_hi;
  byte wide_lo,wide_hi;  /* this is 'image size', often the same as screen */
  byte high_lo,high_hi;
  byte misc;
  } imagehed;

int dc_cc,dc_eoi;
int width,height,bpp,numcols;
int imagex=0,imagey=0,stoprightnow=0;
int palr[256],palg[256],palb[256];
int palrorg[256],palgorg[256],palborg[256];
int palr64[256],palg64[256],palb64[256];
int palrgb[768];

int pwr2[16]={1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,
                  16384,32768};

/* now this is for the string table.
 * the st_ptr array stores which pos to back reference to,
 *  each string is [...]+ end char, [...] is traced back through
 *  the 'pointer' (index really), then back through the next, etc.
 *  a 'null pointer' is = to UNUSED.
 * the st_chr array gives the end char for each.
 *  an unoccupied slot is = to UNUSED.
 */
#define UNUSED 32767
#define MAXSTR 4096
int st_ptr[MAXSTR],st_chr[MAXSTR],st_last;
int st_ptr1st[MAXSTR];

/* this is for the byte -> bits mangler */
int dc_bitbox=0,dc_bitsleft=0,blocksize=0;



main(argc,argv)
int argc;
char **argv;
{
FILE *in;
char giffn[1024];

vga_setflipchar('#');
if((argc<2)||(argc>4))
  printf("Usage: gifview <GIF filename>\n");
else
  {
  strcpy(giffn,argv[1]);
  if(!strcmp(strrchr(giffn,'.'),".jpg"))
    {
    printf("Using djpeg to expand to gif...\n");
    sprintf(giffn,"djpeg -gif %s >/tmp/~temp.gif",argv[1]);
    system(giffn);
    strcpy(giffn,"/tmp/~temp.gif");
    }
  if((in=fopen(giffn,"rb"))==NULL)
    printf("File not found or open error.\n");
  else
    {
    readgifhed(in);
    readcolmap(in);
    readimagehed(in);
    theimage=(byte *)malloc(height*width);
    if(theimage==NULL)
      {
      printf("Bletcherousity! Malloc failed! Get some more memory!\n");
      exit(0);
      }
    decompress(in);
    showgif();
    free(theimage);
    fclose(in);
    if(!strcmp(strrchr(argv[1],'.'),".jpg"))
      remove("/tmp/~temp.gif");
    printf("\n");
    }
  }
}

makerealpal()
{
int f;

for(f=0;f<256;f++)
  {
  palrgb[f*3  ]=palr64[f]=palr[f]>>2;
  palrgb[f*3+1]=palg64[f]=palg[f]>>2;
  palrgb[f*3+2]=palb64[f]=palb[f]>>2;
  }
}


readgifhed(in)
FILE *in;
{
int f;

fread(&gifhed,sizeof(gifhed),1,in);
if(strncmp(gifhed.sig,"GIF",3))
  {
  printf("Not a GIF file.\n");
  fclose(in); exit(0);
  }
if((gifhed.misc&128)==0)
  {
  printf("No global colour map.\n");
  fclose(in); exit(0);
  }
bpp=(gifhed.misc&7)+1;
numcols=twopower(bpp);
if(numcols<=16)
  {
  curvgamode=4;
  virtual=0;
  }
printf("Screen size: %d by %d : %d bpp, %d cols : background col. %d\n",
                   gifhed.wide_lo+256*gifhed.wide_hi,
                   gifhed.high_lo+256*gifhed.high_hi,
                   bpp,numcols,gifhed.back);
}

/* only works for b<=15 */
int twopower(b)
int b;
{
return(pwr2[b]);
}

readcolmap(in)
FILE *in;
{
int f;

for(f=0;f<numcols;f++)
  {
  palrorg[f]=fgetc(in);
  palgorg[f]=fgetc(in);
  palborg[f]=fgetc(in);  
  }
filterpal();
}

filterpal()
{
int f;

for(f=0;f<numcols;f++)
  {
  palr[f]=dimmer(contrastup(palrorg[f]));
  palg[f]=dimmer(contrastup(palgorg[f]));
  palb[f]=dimmer(contrastup(palborg[f]));
  }
makerealpal();
}

int dimmer(a)
int a;
{
a+=brightness;
if(a<0) a=0;
if(a>255) a=255;
return(a);
}

int contrastup(cp)
int cp;
{
float g;

g=(float)(cp);
g=128+(g-128)*contrast;
if(g<0)g=0;
if(g>255)g=255;
return((int)g);
}

readimagehed(in)
FILE *in;
{
int c,f;

c=fgetc(in);
while(c=='!')      /* oh damn it, they've put an ext. block in, ditch it */
  {
  fgetc(in);       /* function code, means nothing to me */
  c=fgetc(in);
  while(c!=0)
    {    /* well then, c = number of bytes, so ignore that many */
    printf("Extension block skipped - %d bytes.\n",c);
    for(f=1;f<=c;f++) fgetc(in);
    c=fgetc(in);
    }
  c=fgetc(in);     /* test for image again */
  }
if(c!=',')
  {
  printf("Can't find image in file : unknown block starts with %d.\n",c);
  fclose(in); exit(0);
  }
fread(&imagehed,sizeof(imagehed),1,in);

if((imagehed.misc&128)!=0)
  {
  printf("Can't handle local colour maps.\n");
  fclose(in); exit(0);
  }
if((imagehed.misc&64)!=0)
  {
  printf("Can't handle interlaced images.\n");
  fclose(in); exit(0);
  }
printf("Image size: %d by %d\n",
                   width=(imagehed.wide_lo+256*imagehed.wide_hi),
                  height=(imagehed.high_lo+256*imagehed.high_hi));
if((width==320)&&(height==200))
  {
  curvgamode=5;
  virtual=0;
  }
}


/* DEEP MAGIC STARTS HERE - NO USER SERVICEABLE PARTS INSIDE :) */

decompress(in)
FILE *in;
{
int csize,orgcsize,numbytes,c;
int newcode,oldcode,k;

csize=fgetc(in)+1;
orgcsize=csize;
inittable();

do
  {
  readcode(&newcode,csize,in);
  oldcode=newcode;
  }
while(newcode==dc_cc);
outputstring(newcode);

while((newcode!=dc_eoi)&&(!stoprightnow))
  {
  readcode(&newcode,csize,in);
  if(newcode!=dc_eoi)
    {
    if(newcode==dc_cc)
      {
      inittable();
      csize=orgcsize;
      readcode(&newcode,csize,in);
      oldcode=newcode;
      outputstring(newcode);
      }
    else
      {
      if(st_chr[newcode]!=UNUSED)
        {
        outputstring(newcode);
        k=findfirstchr(newcode);
        }
      else
        {
        k=findfirstchr(oldcode);
        outputstring(oldcode);
        outputchr(k);
        }
      addstring(oldcode,k);
      if(st_last==(twopower(csize)-1))
        {
        csize++;
        if(csize==13) csize=12;
        }
      oldcode=newcode;
      }
    }
  }
}

inittable()
{
int f;

for(f=0;f<MAXSTR;f++)
  st_chr[f]=UNUSED;
for(f=0;f<numcols+2;f++)
  {
  st_ptr[f]=UNUSED;     /* these are root values... no back pointer */
  st_chr[f]=f;          /* for numcols and numcols+1, doesn't matter */
  }
st_last=numcols+1;      /* last occupied slot */
dc_cc=numcols;
dc_eoi=numcols+1;
if(numcols==2)
  {
  st_chr[2]=st_chr[3]=UNUSED;
  dc_cc=4;
  dc_eoi=5;
  st_chr[dc_cc]=dc_cc; st_chr[dc_eoi]=dc_eoi;
  st_last=5;
  }
}

/* add a string specified by oldstring + chr to string table */
addstring(oldcode,chr)
int oldcode,chr;
{
st_last++;
while(st_chr[st_last]!=UNUSED)
  st_last++;
st_chr[st_last]=chr;
st_ptr[st_last]=oldcode;
if(st_ptr[oldcode]==UNUSED)          /* if we're pointing to a root... */
  st_ptr1st[st_last]=oldcode;        /* then that holds the first char */
else                                 /* otherwise... */
  st_ptr1st[st_last]=st_ptr1st[oldcode]; /* use their pointer to first */
}

/* read a code of bitlength numbits from in file */
readcode(newcode,numbits,in)
int *newcode,numbits;
FILE *in;
{
int bitsfilled,got;

bitsfilled=got=0;
(*newcode)=0;

while(bitsfilled<numbits)
  {
  if(dc_bitsleft==0)        /* have we run out of bits? */
    {
    if(blocksize==0)        /* end of block? */
      {
      blocksize=fgetc(in);  /* start new block, blocksize = num of bytes */
      if(blocksize==0) abort();  /* if =0, gif file is too short/damaged */
      }
    blocksize--;
    dc_bitbox=fgetc(in);    /* read eight more bits */
    dc_bitsleft=8;
    }
  if(dc_bitsleft<(numbits-bitsfilled))
    got=dc_bitsleft;
  else
    got=numbits-bitsfilled;
  (*newcode)|=((dc_bitbox&(twopower(got)-1))<<bitsfilled);
  dc_bitbox>>=got;
  dc_bitsleft-=got;
  bitsfilled+=got;
  }
}

outputstring(code)
register int code;
{
if(st_ptr[code]!=UNUSED)
  outputstring(st_ptr[code]);
outputchr(st_chr[code]);
}

int findfirstchr(code)
int code;
{
if(st_ptr[code]!=UNUSED)       /* not first? then use st_ptr1st */
  code=st_ptr1st[code];
return(st_chr[code]);
}

graphicson()
{
vga_setmode(curvgamode);
scrnwide=realscrnwide=vga_getxdim();
scrnhigh=vga_getydim();
if(virtual)
  scrnwide*=2;
vga_setpalvec(0,256,palrgb);
}

graphicsoff()
{
vga_setmode(TEXT);
}

outputchr(col)
int col;
{
int a,c,d,colfix,x;
long place;

if(!stoprightnow)
  {
  *(theimage+imagey*width+imagex)=col;
  imagex++;
  if(imagex>=width)
    {
    imagex=0;
    if(imagey%50==0) fprintf(stderr,"\rLine %d",imagey);
    imagey++;
    if(imagey==height) stoprightnow=1;
    }
  }
}

showgif()
{
int opx,opy,px,py,quitshow,key;

px=py=quitshow=0;
graphicson();
redrawgif(px,py);

while(!quitshow)
  {
  key=vga_getch();
  opx=px; opy=py;
  if((key>='0')&&(key<='9'))
    {
    if(key=='0')
      virtual=(virtual==1)?0:1;
    else
      {
      curvgamode=key-48;
      if((curvgamode==7)||(curvgamode==8)) virtual=1; else virtual=0;
      }
    opx=-1; /* redraw screen */
    graphicson();
    }
  else
    switch(key)
      {
      case 'v': vkludge=((vkludge==1)?0:1); opx=-1; break;
      case ',': contrast-=0.05; filterpal(); opx=-1; graphicson(); break;
      case '.': contrast+=0.05; filterpal(); opx=-1; graphicson(); break;
      case 'k': brightness-=10; filterpal(); opx=-1; graphicson(); break;
      case 'l': brightness+=10; filterpal(); opx=-1; graphicson(); break;
      case '*': contrast=1.0; brightness=0;
                filterpal(); opx=-1; graphicson(); break;
      case 'q': py-=MOVSTP; break;
      case 'a': py+=MOVSTP; break;
      case 'o': px-=MOVSTP; break;
      case 'p': px+=MOVSTP; break;
      case 'Q': py-=BIGSTP; break;
      case 'A': py+=BIGSTP; break;
      case 'O': px-=BIGSTP; break;
      case 'P': px+=BIGSTP; break;
      case 'm': fx_mirror(); px=py=0; opx=-1; break;
      case 'f': fx_flip();   px=py=0; opx=-1; break;
      case 'r': fx_rot();    px=py=0; opx=-1; break;
      case 'z':
        zoom=(!zoom); opx=-1; px=py=0; graphicson(); break;
      case 'h':
        showhelp();  /* falls through to 'refresh screen' */
      case 12: case 18:     /* 12,18 = Ctrl-L, Ctrl-R */
        opx=-1; graphicson(); break;
      case 'x': case 27:
        quitshow=1;
      }
  if(!zoom)
    {
    if(height<=scrnhigh)
      py=0;
    else
      if(height-py<scrnhigh) py=height-scrnhigh;
    if(width<=scrnwide)
      px=0;
    else
      if(width-px<scrnwide) px=width-scrnwide;
    if(px<0) px=0;
    if(py<0) py=0;
    }
  else
    px=py=0;
  if((opx!=px)||(opy!=py)) redrawgif(px,py);
  }

graphicsoff();
}

redrawgif(px,py)
int px,py;
{
int x,y,xdim;
byte *realline;
long place;

if(zoom)
  drawzoomedgif();
else
  {
  if(width-px<scrnwide) xdim=width-px; else xdim=scrnwide;
  if((py>=height)||(px>=width)) return(0);
  /* hopefully the following is fairly quick as fewer ifs... ? */
  if(virtual)
    {
    if((realline=malloc(scrnwide))==NULL) return(0);
    for(x=0;x<65536;x++) vkcache[x].rgb=-1;
    if(xdim==scrnwide)
      {for(y=0;(y<height-py)&&(y<scrnhigh);y++)
        {for(x=0;(x<width-px)&&(x<scrnwide);x++)
          *(realline+(x>>1))=getvpix(px,py,x,y);
        vga_drawscanline(y,realline);}}
    else
      {for(y=0;(y<height-py)&&(y<scrnhigh);y++)
        {for(x=0;x<xdim;x++)
          *(realline+(x>>1))=getvpix(px,py,x,y);
        vga_drawscansegment(realline,0,y,xdim>>1);}}
    free(realline);
    }
  else
    {
    if(xdim==scrnwide)
      {for(y=0;(y<height-py)&&(y<scrnhigh);y++)
        vga_drawscanline(y,theimage+(py+y)*width+px);}
    else
      {for(y=0;(y<height-py)&&(y<scrnhigh);y++)
        vga_drawscansegment(theimage+(py+y)*width+px,0,y,xdim);}
    }
  }
}

int getvpix(px,py,x,y)
int px,py,x,y;
{
int p1,p2,r,g,b;

if(vkludge)
  {
  p1=*(theimage+(py+y)*width+px+x);
  if(px+x+1>=width) return(p1);
  p2=*(theimage+(py+y)*width+px+x+1);
  r=(palr64[p1]+palr64[p2])>>1;
  g=(palg64[p1]+palg64[p2])>>1;
  b=(palb64[p1]+palb64[p2])>>1;
  return(closest(r,g,b));
  }
else
  return(*(theimage+(py+y)*width+px+x));
}

/* this routine is nasty writ big, but about as quick as I can manage */
drawzoomedgif()
{
register int a,b,x,yp,yw;
long y,sw,sh,lastyp;
int xoff,yoff;
int c,pixwide,pixhigh,pr,pg,pb;
long place;
int bigimage;
byte *rline;

if((rline=malloc(scrnwide))==NULL) return(0);
for(x=0;x<scrnwide;x++)
  rline[x]=0;

/* try landscapey */
sw=scrnwide; sh=(int)((scrnwide*((long)height))/((long)width));
if(sh>scrnhigh)
  /* no, oh well portraity then */
  { sh=scrnhigh; sw=(int)((scrnhigh*((long)width))/((long)height)); }

/* so now our zoomed image will be sw x sh */
bigimage=(width>sw)?1:0;   /* 1 if image has been reduced, 0 if made bigger */
if(bigimage)
  /* it's been reduced - easy, just make 'em fit in less space */
  {
  if(virtual) sw>>=1;
  lastyp=-1;
  for(y=0;y<height;y++)
    {
    yp=(y*sh)/height;
    if(yp!=lastyp)
      {
      yw=y*width;
      for(x=0;x<width;x++,yw++)
        rline[(x*sw)/width]=*(theimage+yw);
      vga_drawscanline(yp,rline);  
      lastyp=yp;
      }
    }
  free(rline);
  }
else
  /* well, we need to fill in the gaps because it's been made bigger. */
  {
  free(rline);  /* get rid of that... */
    /* and get a screen's worth... hahahahahahahahaha er, sorry. */
  if((rline=malloc(scrnwide*scrnhigh))==NULL) return(0);
  for(x=0;x<scrnwide*scrnhigh;x++) rline[x]=0;
  
  /* a pixel from the original is now pixwide x pixhigh */
  pixwide=(int) ( (((float)sw)/((float)width )) +1.0 );
  pixhigh=(int) ( (((float)sh)/((float)height)) +1.0 );
  if(virtual)
    sw>>=1;   /* leave pixwide though as it *might* miss with >> */
  for(y=0;y<height;y++)
    {
    yoff=(y*sh)/height;
    yw=y*width;
    for(x=0;x<width;x++,yw++)
      {
      c=*(theimage+yw);
      xoff=(x*sw)/width;
      for(b=0;b<pixhigh;b++)
        for(a=0;a<pixwide;a++)
          *(rline+(yoff+b)*scrnwide+xoff+a)=c;
      }
    vga_drawscanline(y,rline+y*scrnwide); /* really pessimistic */
    }
  for(;y<scrnhigh;y++)          /* and do the rest */
    vga_drawscanline(y,rline+y*scrnwide);
  free(rline);
  }
}

showhelp()
{
char nothingtoworryyourlittleheadabout[80];
int f;

graphicsoff();
for(f=0;f<100;f++) printf("\n"); /* hi-tech clear screen algorithm :) */
printf("GIFVIEW v1.0 - GIF viewer with zoom and pan - supports both GIF87a and 89a\n");
printf("(only exception being that currently interlaced images are not supported.)\n");
printf("  (c) 1993 Russell Marks for improbabledesigns");
printf("\n\n");
printf("Keys available and function:\n\n");
printf("h - this help page.\n");
printf("1 to 9 - mode change    0 - toggle 'virtual' mode\n");
printf("q - scroll up picture   a - scroll down picture\n");
printf("o - scroll left along picture\n");
printf("p - scroll right along picture  (Q,A,O,P (with shift) give larger steps)\n\n");
printf("v - toggle smoothing in 'virtual' modes (default - off)\n");
printf("[,] [.] - contrast down/up  [k] [l] - brightness down/up  [*] - reset both\n");
printf("z - toggle zoomed mode (default - zoom mode off)\n");
printf("  Zoom mode fits the picture to the screen:\n");
printf("  So as you might expect, panning controls are not available in zoomed mode.\n\n");
printf("^L or ^R are available to redraw the screen.\n\n");
printf("r - rotate clockwise 90 degs, m - mirror, f - flip\n");
printf("x or Esc - exit the viewer.\n");
printf("\nPress Enter to return...\n");

gets(nothingtoworryyourlittleheadabout);
graphicson();
}


putrgbpixel(x,y,c)
int x,y,c;
{
vga_setcolor(c);
vga_drawpixel(x,y);
}

fx_mirror()
{
byte *tmp;
int x,y;

tmp=malloc(width*height);
if(tmp==NULL) return(0);
for(y=0;y<height;y++)
  for(x=0;x<width;x++)
    *(tmp+y*width+(width-x-1))=*(theimage+y*width+x);

free(theimage);
theimage=tmp;
}

fx_flip()
{
byte *tmp;
int x,y;

tmp=malloc(width*height);
if(tmp==NULL) return(0);
for(y=0;y<height;y++)
  for(x=0;x<width;x++)
    *(tmp+(height-y-1)*width+x)=*(theimage+y*width+x);

free(theimage);
theimage=tmp;
}

fx_rot()
{
byte *tmp;
int x,y;

tmp=malloc(width*height);
if(tmp==NULL) return(0);
for(y=0;y<height;y++)
  for(x=0;x<width;x++)
    *(tmp+(height-y-1)+x*height)=*(theimage+y*width+x);
x=height;y=width;
width=x; height=y;
free(theimage);
theimage=tmp;
graphicson(); /* clear screen 'cos image diff. size */
}

/* rgb values must be 0..63 */
/* because of course, only 6 bits of the rgb values actually count on VGA */
int closest(r,g,b)
int r,g,b;
{
int idx,rgb,*pr,*pg,*pb;
register int f,xr,xg,xb,dist,distnum,distquan;   /* optimistic :) */

rgb=((b<<12)|(g<<6)|r);
idx=rgb&0xffff;
if(vkcache[idx].rgb==rgb)
  return(vkcache[idx].col);
distnum=0;
distquan=16000000; /* standard arbitrary bignum */
for(pr=palr64,pg=palg64,pb=palb64,f=0;f<256;f++,pr++,pg++,pb++)
  {
  xr=(r-*pr);
  xg=(g-*pg);
  xb=(b-*pb);
  if((dist=xr*xr+xg*xg+xb*xb)<distquan)
    {
    distnum=f;
    distquan=dist;
    if(dist==0) f=999;  /* premature exit if it can't get any better */
    }
  }
vkcache[idx].rgb=rgb;
return(vkcache[idx].col=distnum);
}
