#include <stdio.h>
#include <dirent.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <curses.h>


#define PROGTTL "[ ZGV - select a file and press enter to view ]"
#define MDIRSIZ 1000
#define YSIZ ((LINES-6)-6)

int gcompare(void *,void *);


WINDOW *filewin;
struct GDIR {
  char name[80];
  char isdir;            /* 0=file, 1=dir. */
  } gifdir[MDIRSIZ];
int gifdirsiz;


main()
{
initscr();
noecho(); cbreak();
initwins();

mainloop();

echo(); nocbreak();
endwin();
}

initwins()
{
filewin=newwin(LINES-6,COLS,6,0);
wrefresh(filewin);
}

mainloop()
{
int quit,key,curent; /* quit, key pressed, current entry */
int oldent,startfrom,oldstart;
char cline[100];

quit=0; curent=1; oldent=1;
startfrom=1;

readgifdir();
showgifdir(filewin,startfrom);
showbar(filewin,curent,1,startfrom);
wrefresh(filewin);
while(!quit)
  {
  oldent=curent;
  key=getch();
  switch(key)
    {
    case 'q':
      if(curent>1) curent--; break;
    case 'a':
      if(curent<gifdirsiz) curent++; break;
    case 'o':
      curent-=YSIZ;
      if(curent<1) curent=1;
      break;
    case 'p':
      curent+=YSIZ;
      if(curent>gifdirsiz) curent=gifdirsiz;
      break;
    case 13: case 10:
      if(gifdir[curent].isdir)
        {
        chdir(gifdir[curent].name);
        readgifdir();
        showgifdir(filewin,1); curent=oldent=1;
        showbar(filewin,curent,1,startfrom);
        }
      else
        {
        sprintf(cline,"clear ; gifview %s",gifdir[curent].name);
        system(cline);
        werase(filewin); wrefresh(filewin);
        showgifdir(filewin,startfrom); showbar(filewin,curent,1,startfrom);
        wrefresh(filewin);
        }
      break;
    case 'x': case 27:
      quit=1;
    }
  oldstart=startfrom;
  while(curent<startfrom)
    startfrom-=YSIZ;
  while(fwinxpos(curent-startfrom+1)+17>COLS)
    startfrom+=YSIZ;
  if(startfrom!=oldstart)
    {
    showgifdir(filewin,startfrom);
    showbar(filewin,curent,1,startfrom);
    }
  else  
    if(curent!=oldent)
      {
      showbar(filewin,oldent,0,startfrom);
      showbar(filewin,curent,1,startfrom);
      }
  wrefresh(filewin);
  }
werase(filewin);
wrefresh(filewin);
refresh();
system("clear");
}

showbar(fwin,entnum,selected,startfrom)
WINDOW *fwin;
int entnum,selected;
int startfrom;
{
char ctmp[100];
int xpos,ypos;

xpos=fwinxpos(entnum-startfrom+1);
if((xpos<1)||(xpos+17>COLS)) return(0);
ypos=fwinypos(entnum-startfrom+1);
prettyfile(&ctmp,&(gifdir[entnum]));

if(selected)
  {
  mvwaddstr(fwin,ypos,xpos-1,">");
  mvwaddstr(fwin,ypos,xpos+strlen(ctmp),"<");
  }
else
  {
  mvwaddstr(fwin,ypos,xpos-1," ");
  mvwaddstr(fwin,ypos,xpos+strlen(ctmp)," ");
  }
}

showgifdir(fwin,startfrom)
WINDOW *fwin;
int startfrom;
{
char cdir[MAXPATHLEN+1];
char ctmp[MAXPATHLEN+100];
int f,ypos,xpos;

werase(fwin);
box(fwin,':','-');
getcwd(cdir,MAXPATHLEN);
mvwaddstr(fwin,2,2,"Directory of ");
mvwaddstr(fwin,2,15,cdir);

for(f=startfrom;f<=gifdirsiz;f++)
  {
  xpos=fwinxpos(f-startfrom+1);
  if(xpos+17>COLS) break;
  ypos=fwinypos(f-startfrom+1);
  prettyfile(&ctmp,&(gifdir[f]));
  mvwaddstr(fwin,ypos,xpos,ctmp);
  }
mvwaddstr(filewin,0,(COLS-strlen(PROGTTL))>>1,PROGTTL);
wrefresh(filewin);
}

readgifdir()
{
DIR *dirfile;
struct dirent *anentry;
struct stat buf;
char cdir[MAXPATHLEN+1];
int entnum;

getcwd(cdir,MAXPATHLEN);
dirfile=opendir(".");
entnum=0;
while((anentry=readdir(dirfile))!=NULL)
  {
  if((strcmp(anentry->d_name,".")!=0)&&
     (!((strcmp(cdir,"/")==0)&&(strcmp(anentry->d_name,"..")==0))))
    {
    entnum++;
    if((stat(anentry->d_name,&buf))==-1)
      buf.st_mode=0;
    if((buf.st_mode&0x7000)==0x4000)
      gifdir[entnum].isdir=1; else gifdir[entnum].isdir=0;
    strcpy(gifdir[entnum].name,anentry->d_name);
    }
  }
closedir(dirfile);
gifdirsiz=entnum;
qsort(&(gifdir[1]),gifdirsiz,sizeof(struct GDIR),(void *)gcompare);
}

int gcompare(gn1,gn2)
void *gn1,*gn2;
{
struct GDIR *g1,*g2;
char buf1[80],buf2[80];

g1=(struct GDIR *)gn1; g2=(struct GDIR *)gn2;
prettyfile(buf1,g1); prettyfile(buf2,g2);
return(strcmp(buf1,buf2));
}

int fwinxpos(f)
int f;
{return(3+((f-1)/YSIZ)*15);}

int fwinypos(f)
int f;
{return(4+((f-1)%YSIZ));}

prettyfile(buf,gifdptr)
char *buf;
struct GDIR *gifdptr;
{
if(gifdptr->isdir)
  {
  strcpy(buf,"(");
  strcat(buf,gifdptr->name);
  strcat(buf,")");
  }
else
  strcpy(buf,gifdptr->name);
}