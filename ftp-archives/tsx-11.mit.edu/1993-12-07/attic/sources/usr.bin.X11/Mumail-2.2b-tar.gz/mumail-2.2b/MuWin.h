/*---------------------------------------------------------------------------+
| This file is part of Mumail, Copyright (c) 1992-1993 by
| Muhammad M. Saggaf. All rights reserved.
|
| See the file COPYING (1-COPYING) or the manual page mumail(1)
| for a full statement of rights and permissions.
+---------------------------------------------------------------------------*/

extern int

                IconifyShell();


extern void

                DoNothingCallback(),

                DestroyShell(),
                DestroyShellCallBack(),
                CenterShell(),

                MuXFlush(),

                SeSetViewportDimFromMultiList();
extern Widget
                AddButton(),
                AddLabel(),

                AddMenuButton(),
                AddSimpleMenu(),
                AddMenuEntry(),
                AddMenuLine(),
                AddAsciiText(),
                 
                AddBox(),
                AddPaned(),

                AddSimplePopup(),
                GetShell();

#define PopupCentered(popup,parent) \
  {CenterShell(popup,parent); XtPopupSpringLoaded(popup);}
#define PopupCenteredOnRoot(popup) \
  {CenterShellOnRoot(popup);  XtPopupSpringLoaded(popup);}
