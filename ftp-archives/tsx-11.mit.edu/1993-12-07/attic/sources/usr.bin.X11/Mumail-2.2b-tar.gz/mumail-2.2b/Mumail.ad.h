"*.title: Mumail",
"*.iconName: Mumail",
"*cursor: hand2",
"*alert*font: -adobe-times-bold-i-normal--24-240-*-*-p-128-iso8859-1",
"*Label*shadowWidth: 2",
"*Text.cursor: xterm",
"*FileComplete.acceptableFilenameProc: regexfiles",
"*FileComplete.filenameProcData: [^.#].*[^~]",
"*FileComplete.cursor: hand2",
"*XfwfMultiList.shadeSurplus: off",
"*XfwfFrame.frameWidth: 5",
"*XfwfFrame.frameOffset: 0",
"*XfwfFrame.frameType: ledged",
"*mainPaned.internalBorderWidth: 0",
"*MenuButton.Translations: #override\\n\
	<Btn1Up>: reset()\\n\
	<Btn1Down>: reset() set() PopupMenu()",
"*mainMenuFrame.showGrip: off",
"*mainMenu.showGrip: off",
"*menuButtonFrame.frameWidth: 4",
"*menuButtonFrame.frameOffset: 2",
"*menuButtonFrame.frameType: sunken",
"*windowButton.menuName: windowMenu",
"*windowButton.label: Window",
"*windowMenu.new.label:					New",
"*windowMenu.close.label: 				Close",
"*windowMenu.iconify.label: 				Iconify      C-z",
"*windowMenu.exit.label: 				Exit Program   q",
"*windowMenu.quickExit.label: 			Quick Exit     Q",
"*folderButton.menuName: folderMenu",
"*folderButton.label: Folder",
"*folderMenu.checkMailbox.label: 		Check Mailbox",
"*folderMenu.getNew.label: 				Read New Mail",
"*folderMenu.open.label: 				Open...                      o",
"*folderMenu.reopen.label: 				ReOpen",
"*folderMenu.openInNextScn.label: 		Open in Next Window...",
"*folderMenu.new.label: 					New...",
"*folderMenu.save.label: 				Save                       C-s",
"*folderMenu.saveAs.label: 				Save As...",
"*folderMenu.saveCompressed.label: 		Save Compressed",
"*folderMenu.saveGZipped.label: 			Save GZipped",
"*folderMenu.saveUnpacked.label: 		Save Unpacked (Normal)",
"*folderMenu.edit.label: 				Edit...",
"*folderMenu.delete.label: 				Delete...",
"*folderMenu.commit.label: 				Commit Changes             C-c",
"*folderMenu.sort.label: 				Sort",
"*folderMenu.search.label: 				Search (Current->Last)...",
"*folderMenu.remake.label: 				Reconstruct TOC",
"*folderMenu.redraw.label: 				Redraw TOC                 C-l",
"*folderMenu.info.label: 				Info                       C-i",
"*letterButton1.menuName: letterMenu1",
"*letterButton1.label: Letter-1",
"*letterMenu1.displayPartial.label: 		View                     Space",
"*letterMenu1.displayWhole.label: 		View Whole                   v",
"*letterMenu1.displayPartialInNextScn.label: View in Next Window",
"*letterMenu1.pipeToMime.label: 			MIME View",
"*letterMenu1.compose.label: 			Compose                      c",
"*letterMenu1.reply.label: 				Reply                        r",
"*letterMenu1.forward.label: 			Forward                      f",
"*letterMenu1.followup.label: 			Follow-up                    ",
"*letterMenu1.quoteScFmtReply.label: 	Quote/Reply (SC Fmt.)...   M-1",
"*letterMenu1.quoteScUnfmtReply.label: 	Quote/Reply (SC Unfmt.)... M-2",
"*letterMenu1.quoteRnReply.label: 		Quot/Reply (RN)            M-3",
"*letterMenu1.composeExt.label: 			External Compose",
"*letterMenu1.replyExt.label: 			External Reply",
"*letterMenu1.info.label: 				Info                         i",
"*letterButton2.menuName: letterMenu2",
"*letterButton2.label: Letter-2",
"*letterMenu2.tag.label: 				Tag/Untag                t",
"*letterMenu2.tagAll.label: 				Tag All",
"*letterMenu2.tagRange.label: 			Tag Range...",
"*letterMenu2.untagAll.label: 			Untag All",
"*letterMenu2.retag.label: 				Retag                    T",
"*letterMenu2.delete.label: 				Delete                   d",
"*letterMenu2.undelete.label: 			Undelete                 u",
"*letterMenu2.copy.label: 				Copy...                C/w",
"*letterMenu2.refile.label: 				Refile...                F",
"*letterMenu2.pipe.label: 				Pipe to Command...",
"*letterMenu2.print.label: 				Print",
"*letterMenu2.digestDefacto.label: 		Explode Digest",
"*letterMenu2.digestGrotty.label: 		Explode Grotty Digest",
"*letterMenu2.search.label: 				Search...              C-s",
"*draftButton.menuName: draftMenu",
"*draftButton.label: Draft",
"*draftMenu.send.label: 					Send (+Expand+Save)      M-S",
"*draftMenu.expandAliases.label: 		Expand Aliases",
"*draftMenu.expMimeInc.label: 			Expand MIME Inclusions",
"*draftMenu.quoteScFmt.label: 			Quote (SC Style Fmt.)    M-1",
"*draftMenu.quoteScUnfmt.label: 			Quote (SC Style Unfmt.)  M-2",
"*draftMenu.quoteRn.label: 				Quote (RN Style)         M-3",
"*draftMenu.quoteRnE.label: 				Quote (RN Style Ext.)    M-4",
"*draftMenu.signature.label: 			Insert Signature         M-s",
"*draftMenu.body.label: 					Insert Body",
"*draftMenu.partial.label: 				Insert Parial",
"*draftMenu.whole.label: 				Insert Whole",
"*draftMenu.cancel.label: 				Cancel                   M-C",
"*editButton.menuName: editMenu",
"*editButton.label: Edit",
"*editMenu.goto.label: 					Goto",
"*editMenu.save.label: 					Save",
"*editMenu.cancel.label: 				End",
"*editMenu.cut.label: 					Cut                C-w",
"*editMenu.cutEol.label: 				Cut to EOL         C-k",
"*editMenu.paste.label: 					Paste              C-y",
"*editMenu.search.label: 				Search/Replace...  C-s",
"*editMenu.insert.label: 				Insert File...     M-i",
"*editMenu.format.label: 				Format Paraghraph  M-q",
"*editMenu.redraw.label: 				Redraw Display     C-l",
"*editMenu.editExt.label: 				External Edit",
"*miscButton.menuName: miscMenu",
"*miscButton.label: Misc",
"*miscMenu.editHeaders.label: 			Edit Custom Headers",
"*miscMenu.editAliases.label: 			Edit Aliases",
"*miscMenu.viewFile.label: 				View File...",
"*miscMenu.editFile.label: 				Edit File...",
"*helpButton.menuName: helpMenu",
"*helpButton.label: Help",
"*helpMenu.about.label: 					About",
"*helpMenu.all.label: 					General",
"*helpMenu.overview.label: 				Overview",
"*helpMenu.options.label: 				Options",
"*helpMenu.resources.label: 				Resources",
"*helpMenu.mailAgents.label: 			Mail Agents",
"*helpMenu.aliases.label: 				Aliases",
"*helpMenu.mime.label: 					MIME Support",
"*helpMenu.menus.label: 					Menus",
"*helpMenu.bindings.label: 				Bindings",
"*helpMenu.files.label: 					Files",
"*helpMenu.bugs.label: 					Bugs",
"*helpMenu.copyright.label: 				Copyright",
"*helpMenu.author.label: 				Author",
"*helpMenu.ack.label: 					Acknowledgement",
"*helpMenu.news.label: 					News/Changes",
"*chooserPopup.title: File Chooser",
"*FileComplete*home.label: >>Home",
"*FileComplete*mail.label: >>Mail",
"*FileComplete*delete.label: Delete",
"*tocFrame.preferredPaneSize: 150",
"*tocW.preferredPaneSize: 150",
"*bodyFrame.preferredPaneSize: 350",
"*bodyW.preferredPaneSize: 350",
"*tocW*borderWidth: 0",
"*tocW.cursor: hand2",
"*tocW.displayCaret: off",
"*tocW*editType: edit",
"*tocW.rightMargin: 0",
"*tocW.leftMargin: 0",
"*tocW.scrollHorizontal: never",
"*tocW.scrollVertical: always",
"*dialogFrame.showGrip: off",
"*dialogFrame.skipAdjust: on",
"*dialogW.BorderWidth: 0",
"*dialogW.showGrip: off",
"*dialogW.skipAdjust: on",
"*dialogW.orientation: horizontal",
"*dialogW.Command.showGrip: off",
"*bodyW*borderWidth: 0",
"*bodyW.autoFill: on",
"*bodyW.displayCaret: off",
"*bodyW*editType: read",
"*bodyW.rightMargin: 40",
"*bodyW.scrollHorizontal: whenNeeded",
"*bodyW.scrollVertical: always",
"*labelFrame.skipAdjust: on",
"*labelFrame.showGrip: off",
"*labelFrame.justify: center",
"*labelFrame.label: ",
"*labelW*shadowWidth: 0",
"*labelW.borderWidth: 0",
"*labelW.skipAdjust: on",
"*labelW.showGrip: off",
"*labelW.justify: center",
"*labelW.label: ",
"*valueW.displayCaret: off",
"*valueW*editType: read",
"*valueW.leftMargin: 10",
"*valueW.scrollHorizontal: whenNeeded",
"*valueW.scrollVertical: whenNeeded",
"*valueW.type: string",
"*yesW.label: Cancel",
"*noW.label: Cancel",
"*cancelW.label: Cancel",
"*dialogW.valueW.Translations: #override\\n\
	<Key>Return: insert-string(\"\200\")",
"*tocW.Translations: #replace\\n\
	<Btn1Down>: select-start()\\n\
	Button1 <Btn1Motion>: select-adjust()\\n\
	<Btn1Up>: select-end() SetCurLetterNumber()\\n\
		\
	<Btn2Down>: select-start()\\n\
	Button2 <Btn2Motion>: select-adjust()\\n\
	<Btn2Up>: select-end() SetCurLetterNumber()\
		RedisplayCurLetterPartial()\\n\
		\
	<Btn3Down>: select-start()\\n\
	Button3 <Btn3Motion>: select-adjust()\\n\
	<Btn3Up>: select-end() SetCurLetterNumber() TagUntagLetter()\\n\
		\
	<Key>Down: next-line() HighlightCurrentLine() SetCurLetterNumber()\\n\
	<Key>Up: previous-line() HighlightCurrentLine() SetCurLetterNumber()\\n\
	!:<Key>n: next-line() HighlightCurrentLine() SetCurLetterNumber()\
 		RedisplayCurLetterPartial()\\n\
	!:<Key>p: previous-line() HighlightCurrentLine() SetCurLetterNumber()\
		RedisplayCurLetterPartial()\\n\
		\
	!:<Key>0x20: DisplayLetterGeneral()\\n\
	!:<Key>.: RedisplayCurLetterPartial()\\n\
	!:<Key>v: RedisplayCurLetterWhole()\\n\
		\
	<Key>Prior: previous-page()\\n\
	<Key>Next: next-page()\\n\
	m<Key><: beginning-of-file()\\n\
	m<Key>>: end-of-file()\\n\
		\
	!:<Key>BackSpace: BodyBoxPrevPage()\\n\
	!:<Key>Delete: BodyBoxPrevPage()\\n\
	!:<Key>b: BodyBoxPrevPage()\\n\
	!:<Key>Return: BodyBoxEndOfPage() BodyBoxNextLine()\\n\
		\
	!:c<Key>z: IconifyWindow()\\n\
	!:<Key>q: Exit()\\n\
	!:<Key>Q: QuickExit()\\n\
		\
	!:<Key>o: OpenFolder()\\n\
	!:c<Key>s: SaveFolder()\\n\
	!:c<Key>c: CommitChanges()\\n\
	!:c<Key>i: FolderInfo()\\n\
	!:c<Key>l: redraw-display()\\n\
		\
	!:<Key>t: TagUntagLetter() next-line() HighlightCurrentLine()\
		 SetCurLetterNumber()\\n\
	!:<Key>T: RetagLetters()\\n\
	!:<Key>d: DeleteLetter()\\n\
	!:<Key>u: UndeleteLetter()\\n\
	!:<Key>c: ComposeLetter()\\n\
	!:Meta<Key>r: ReplyToLetter() QuoteScStyleFmt()\\n\
	!:Meta<Key>1: ReplyToLetter() QuoteScStyleFmt()\\n\
	!:Ctrl<Key>r: ReplyToLetter() QuoteScStyleUnfmt()\\n\
	!:Meta<Key>2: ReplyToLetter() QuoteScStyleUnfmt()\\n\
	!:<Key>R: ReplyToLetter() QuoteRnStyle()\\n\
	!:Meta<Key>3: ReplyToLetter() QuoteRnStyle()\\n\
	!:<Key>r: ReplyToLetter()\\n\
	!:<Key>f: ForwardLetter()\\n\
	!:<Key>e: ExternalComposeLetter()\\n\
	!:<Key>C: CopyLetter()\\n\
	!:<Key>w: CopyLetter()\\n\
	!:<Key>F: RefileLetter()\\n\
	!:<Key>i: LetterInfo()",
"*bodyW.Translations: #override\\n\
	<Key>Prior: previous-page()\\n\
	<Key>Next: next-page()\\n\
		\
	!:Meta<Key>S: SendDraft()\\n\
	!:Meta<Key>C: CancelDraft()\\n\
	Meta<Key>1: QuoteScStyleFmt()\\n\
	Meta<Key>2: QuoteScStyleUnfmt()\\n\
	Meta<Key>3: QuoteRnStyle()\\n\
	Meta<Key>S: InsertSignature()",
"*freqFolders: MUINBOX mutmp sent put_your_other FreqFolders_here \
				via_the_resources",
