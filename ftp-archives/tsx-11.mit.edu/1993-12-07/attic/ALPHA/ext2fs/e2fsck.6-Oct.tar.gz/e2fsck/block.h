/*
 * block.h
 */

/*
 * Return flags for the block iterator functions
 */
#define BLOCK_CHANGED	1
#define BLOCK_ABORT	2

/*
 * Block interate flags
 */
#define BLOCK_FLAG_APPEND	1

