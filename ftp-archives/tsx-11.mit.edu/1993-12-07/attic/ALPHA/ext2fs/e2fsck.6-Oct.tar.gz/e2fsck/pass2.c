/*
 * pass2.c --- check directory structure
 *
 * Pass 2 of e2fsck iterates through all active directory inodes, and
 * applies to following tests to each directory entry:
 *
 *	- The length of the directory entry (rec_len) should be at
 * 		least 8 bytes, and no more than the remaining space
 * 		left in the directory block.
 * 	- The length of the name in the directory entry (name_len)
 * 		should be less than (rec_len - 8).  
 *	- The inode number in the directory entry should be within
 * 		legal bounds.
 * 	- The inode number should refer to a in-use inode.
 *	- The first entry should be '.', and its inode should be
 * 		the inode of the directory.
 * 	- The second entry should be '..'.
 *
 * Pass 2 also collects the following information:
 * 	- The inode numbers of the subdirectories for each directory.
 *
 * Pass 2 relies on the following information from previous passes:
 * 	- The data blocks of the directory inodes in the dir_map
 * 		structure from pass 1.
 * 	- The inode state information from pass 1 which indicates:
 * 		- whether an inode is used
 * 		- whether an inode is a directory
 * 		- whether an inode contains bad blocks
 * 		- whether an inode contains duplicate blocks
 * 
 */

#include "et/com_err.h"

#include "e2fsck.h"

/*
 * Keeps track of how many times an inode is referenced.
 */
unsigned short * inode_count;

static int process_dir_block(ext2_filsys fs, blk_t *block_nr,
			     int blockcnt, void *private);
struct process_dir_struct {
	ext2_filsys	fs;
	struct	dir_map	*dirmap;
	int		num_entry;
};

void pass2(ext2_filsys fs)
{
	int	i;
	struct	dir_map	*dir, **dir_map_sort;
	int	dirmap_count;
	char	*block_buf;
	struct process_dir_struct pd;
	errcode_t	retval;
	struct resource_track	rtrack;
	
	init_resource_track(&rtrack);

	if (!preen)
		printf("Pass 2: Checking directory structure\n");
	inode_count = allocate_memory((fs->super->s_inodes_count + 1) *
				      sizeof (*inode_count),
				      "buffer for inode count");
		
	block_buf = allocate_memory(fs->blocksize * 3, "block iterate buffer");

	retval = get_sorted_dirmap(&dir_map_sort, &dirmap_count);
	if (retval) {
		com_err("get_sorted_dirmap", retval, "");
		fatal_error(0);
	}

	use_dirmap_info(fs);

	for (i=0; i < dirmap_count; i++) {
		pd.fs = fs;
		pd.dirmap = dir = dir_map_sort[i];
		pd.num_entry = 0;

		retval = ext2fs_block_iterate(fs, dir->ino, 0, block_buf,
					      process_dir_block, &pd);
		if (retval) {
			com_err("e2fsck", retval, "while scanning dir %d",
				dir->ino);
			fatal_error(0);
		}
	}
	free(block_buf);
	if (tflag > 1) {
		printf("Pass 2: ");
		print_resource_track(&rtrack);
	}
}

/*
 * Make sure the first entry in the directory is '.', and that the
 * directory entry is sane.
 */
static int check_dot(ext2_filsys fs,
		     struct ext2_dir_entry *dirent,
		     struct process_dir_struct *pd)
{
	struct ext2_dir_entry *nextdir;
	int	ino = pd->dirmap->ino;
	int	status = 0;
	int	created = 0;
	int	new_len;
	char	name[BLOCK_SIZE];
	
	if (!dirent->inode) {
		printf("Missing '.' in directory inode %d.\n", ino);
		if (dirent->rec_len < 12)
			fatal_error("Cannot fix, insufficient space to add '.'");
		preenhalt();
		if (ask("Fix", 1)) {
			dirent->inode = ino;
			dirent->name_len = 1;
			dirent->name[0] = '.';
			status = 1;
			created = 1;
		} else {
			ext2fs_unmark_valid(fs);
			return 0;
		}
	}
	if ((dirent->name_len != 1) ||
	    strncmp(dirent->name, ".", dirent->name_len)) {
		strncpy(name, dirent->name, dirent->name_len);
		name[dirent->name_len] = '\0';
		printf("Missing '.' in directory inode %d.\n", ino);
		printf("Cannot fix, first entry in directory contains '%s'\n",
		       name);
		exit(FSCK_ERROR);
	}
	if (dirent->inode != ino) {
		printf("Bad inode number for '.' in directory inode %d.\n",
		       ino);
		preenhalt();
		if (ask("Fix", 1)) {
			dirent->inode = ino;
			status = 1;
		} else
			ext2fs_unmark_valid(fs);
	}
	if (dirent->rec_len > 12) {
		new_len = dirent->rec_len - 12;
		if (new_len > 12) {
			preenhalt();
			if (created ||
			    ask("Directory entry for '.' is big.  Split", 1)) {
				nextdir = (struct ext2_dir_entry *)
					((char *) dirent + 12);
				dirent->rec_len = 12;
				nextdir->rec_len = new_len;
				nextdir->inode = 0;
				nextdir->name_len = 0;
				status = 1;
			}
		}
	}
	return status;
}

/*
 * Make sure the second entry in the directory is '..', and that the
 * directory entry is sane.  We do not check the inode number of '..'
 * here; this gets done in pass 3.
 */
static int check_dotdot(ext2_filsys fs,
			struct ext2_dir_entry *dirent,
			struct process_dir_struct *pd)
{
	char	name[BLOCK_SIZE];
	int	ino = pd->dirmap->ino;
	
	if (!dirent->inode) {
		printf("Missing '..' in directory inode %d.\n", ino);
		if (dirent->rec_len < 12)
			fatal_error("Cannot fix, insufficient space to add '..'");
		preenhalt();
		if (ask("Fix", 1)) {
			/*
			 * Note: we don't have the parent inode just
			 * yet, so we will it in with the root
			 * inode.  This will get fixed in pass 3.
			 */
			dirent->inode = EXT2_ROOT_INO;
			dirent->name_len = 2;
			dirent->name[0] = '.';
			dirent->name[1] = '.';
			return 1;
		} else
			ext2fs_unmark_valid(fs);
		return 0;
	}
	if ((dirent->name_len != 2) ||
	    strncmp(dirent->name, "..", dirent->name_len)) {
		strncpy(name, dirent->name, dirent->name_len);
		name[dirent->name_len] = '\0';
		printf("Missing '..' in directory inode %d.\n", ino);
		printf("Cannot fix, first entry in directory contains %s\n",
		       name);
		exit(FSCK_ERROR);
	}
	pd->dirmap->parent = dirent->inode;
	return 0;
}

/*
 * Check to make sure a directory entry doesn't contain any illegal
 * characters.
 */
static int check_name(ext2_filsys fs,
		      struct ext2_dir_entry *dirent,
		      struct process_dir_struct *pd,
		      char *name)
{
	int	i;
	int	fixup = -1;
	char	*pathname;
	int	ret = 0;
	errcode_t	retval;
	
	for ( i = 0; i < dirent->name_len; i++) {
		if (dirent->name[i] == '/' || dirent->name[i] == '\0') {
			if (fixup < 0) {
				retval = ext2fs_get_pathname(pd->fs,
							     pd->dirmap->ino,
							     0,
							     &pathname);
				if (retval) {
					com_err(program_name, retval, "while getting pathname in check_name");
					fatal_error(0);
				}
				printf ("Bad file name '%s' (contains '/' or "
					" null) in directory '%s'",
					pathname, name);
				free(pathname);
				preenhalt();
				fixup = ask("Replace '/' or null by '.'", 1);
			}
			if (fixup) {
				dirent->name[i] = '.';
				ret = 1;
			} else
				ext2fs_unmark_valid(fs);
		}
	}
	return ret;
}

static int process_dir_block(ext2_filsys fs,
			     blk_t *block_nr,
			     int blockcnt,
			     void *private)
{
	struct process_dir_struct	*pd;
	struct subdir_map		*sd;
	struct dir_map			*dir;
	struct ext2_dir_entry 		*dirent;
	char				buf[BLOCK_SIZE];
	char				name[BLOCK_SIZE];
	int				offset = 0;
	int				dir_modified = 0;
	errcode_t			retval;
	
	if (blockcnt < 0)
		return 0;

	pd = (struct process_dir_struct *) private;
	dir = pd->dirmap;
	
#if 0
	printf("In process_dir_block block %d, #%d, inode %d\n", *block_nr,
	       blockcnt, dir->ino);
#endif
	
	retval = io_channel_read_blk(pd->fs->io, *block_nr, 1, buf);
	if (retval) {
		com_err(program_name, retval,
			"while reading directory block %d", *block_nr);
	}

	do {
		pd->num_entry++;
		dirent = (struct ext2_dir_entry *) (buf + offset);
		if (((offset + dirent->rec_len) > fs->blocksize) ||
		    (dirent->rec_len < 8) ||
		    ((dirent->name_len+8) > dirent->rec_len)) {
			printf("Directory inode %d, block %d, offset %d: directory corrupted\n",
			       dir->ino, blockcnt, offset);
			preenhalt();
			if (ask("Salvage", 1)) {
				dirent->rec_len = fs->blocksize - offset;
				dirent->name_len = 0;
				dirent->inode = 0;
				dir_modified++;
			} else {
				ext2fs_unmark_valid(fs);
				return DIRENT_ABORT;
			}
		}
		strncpy(name, dirent->name, dirent->name_len);
		name[dirent->name_len] = '\0';
		if (pd->num_entry == 1) {
			if (check_dot(fs, dirent, pd))
				dir_modified++;
		} else if (pd->num_entry == 2) {
			if (check_dotdot(fs, dirent, pd))
				dir_modified++;
		} else if (dirent->inode == dir->ino) {
			printf("Entry '%s' in directory inode %d is a symlink to '.'  ",
			       name, dir->ino);
			preenhalt();
			if (ask("Clear", 1)) {
				dirent->inode = 0;
				dir_modified++;
			}
		}
		if (!dirent->inode) 
			goto next;
		
#if 0
		printf("Entry '%s', name_len %d, rec_len %d, inode %d... ",
		       name, dirent->name_len, dirent->rec_len, dirent->inode);
#endif
		if (check_name(fs, dirent, pd, name))
			dir_modified++;
		if (((dirent->inode != EXT2_ROOT_INO) &&
		     (dirent->inode < EXT2_FIRST_INO)) ||
		    (dirent->inode > fs->super->s_inodes_count)) {
			printf("Entry %s has bad inode number %d.  ",
			       name, dirent->inode);
			preenhalt();
			if (ask("Clear", 1)) {
				dirent->inode = 0;
				dir_modified++;
				goto next;
			} else
				ext2fs_unmark_valid(fs);
		}
		if (!(ext2fs_test_inode_bitmap(fs, inode_used_map,
					       dirent->inode))) {
			printf("Entry %s points to deleted/unused inode %d.  ",
			       name, dirent->inode);
			preenhalt();
			if (ask("Clear", 1)) {
				dirent->inode = 0;
				dir_modified++;
				goto next;
			} else
				ext2fs_unmark_valid(fs);
		}
		if ((pd->num_entry > 2) &&
		    (ext2fs_test_inode_bitmap(fs, inode_dir_map,
					      dirent->inode))) {
			/*
			 * Stash away the subdirectories for pass 3.
			 */
			sd = allocate_memory(sizeof(struct subdir_map),
					     "subdir struct");
			sd->ino = dirent->inode;
			sd->next = dir->subdir;
			dir->subdir = sd;
		}
		if (inode_count[dirent->inode]++ > 0)
			fs_links_count++;
		fs_total_count++;
	next:
		offset += dirent->rec_len;
	} while (offset < fs->blocksize);
#if 0
	printf("\n");
#endif
	if (offset != fs->blocksize) {
		printf("Final rec_len is %d, should be %d\n",
		       dirent->rec_len,
		       dirent->rec_len - fs->blocksize + offset);
	}
	if (dir_modified) {
		retval = io_channel_write_blk(pd->fs->io, *block_nr, 1, buf);
		if (retval) {
			com_err(program_name, retval,
				"while writing directory block %d", *block_nr);
		}
		ext2fs_mark_changed(pd->fs);
	}
	return 0;
}

