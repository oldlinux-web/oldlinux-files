/*
 * super.h --- ext2fs superblock abstractions
 */

stuct ext2_filsys {
	struct ext2_super_block * 	super;
	int				blocksize;
	unsigned long			group_desc_count;
	unsigned long			group_desc_size;
	unsigned long			desc_blocks;
	struct ext2_group_desc *	group_desc;
};


	
	
	
