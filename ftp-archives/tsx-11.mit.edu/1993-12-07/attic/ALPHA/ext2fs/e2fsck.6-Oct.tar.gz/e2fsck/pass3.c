/*
 * pass3.c -- pass #3 of e2fsck: Check for directory connectivity
 */

#include "et/com_err.h"

#include "e2fsck.h"

static void check_root(ext2_filsys fs, ino_t root_ino);
static void traverse_tree(ext2_filsys fs, ino_t inode, ino_t parent);
static ino_t get_lost_and_found(ext2_filsys fs);
static void fix_parent(ext2_filsys fs, ino_t inode, ino_t parent);
static int adjust_inode_count(ext2_filsys fs, ino_t ino, int adj);

static ino_t lost_and_found = 0;
static int bad_lost_and_found = 0;

static char *inode_found_map;

void pass3(ext2_filsys fs)
{
	int		i;
	char		*pathname;
	errcode_t	retval;
	struct resource_track	rtrack;
	
	init_resource_track(&rtrack);

	if (!preen)
		printf("Pass 3: Checking directory connectivity\n");

	retval = ext2fs_allocate_inode_bitmap(fs, &inode_found_map);
	if (retval) {
		com_err("ext2fs_allocate_inode_bitmap", retval,
			"while allocating inode_found_map");
		fatal_error(0);
	}
	
	check_root(fs, EXT2_ROOT_INO);
	traverse_tree(fs, EXT2_ROOT_INO, EXT2_ROOT_INO);
	
	for (i=1; i <= fs->super->s_inodes_count; i++) {
		if (!(ext2fs_test_inode_bitmap(fs, inode_dir_map, i)))
			continue;
		if (ext2fs_test_inode_bitmap(fs, inode_found_map, i))
			continue;
		retval = ext2fs_get_pathname(fs, i, 0, &pathname);
		if (retval) {
			com_err(program_name, retval,
				"while getting pathname during pass3");
			fatal_error(0);
		}
		printf("Unconnected directory inode %i (%s)\n", i,
		       pathname);
		preenhalt();
		if (ask("Connect to /lost+found", 1)) {
			if (reconnect_file(fs, i))
				ext2fs_unmark_valid(fs);
			else {
				fix_parent(fs, i, lost_and_found);
				traverse_tree(fs, i, lost_and_found);
			}
		} else
				ext2fs_unmark_valid(fs);
		free(pathname);
	}
	free_dirmap(fs);
	free(inode_found_map);
	if (tflag > 1) {
		printf("Pass 3: ");
		print_resource_track(&rtrack);
	}
}

/*
 * This makes sure the root inode is present.
 *
 * XXX This routine should be expanded to try to correct for a
 * non-existent or non-directory root inode.
 */
void check_root(ext2_filsys fs, ino_t root_ino)
{
	blk_t			blk;
	errcode_t		retval;
	struct ext2_inode	inode;
	char *			block;
	
	if (ext2fs_test_inode_bitmap(fs, inode_used_map, root_ino)) {
		/*
		 * If the root inode is a directory, die here.  The
		 * user must have answered 'no' in pass1 when we
		 * offered to clear it.
		 */
		if (!(ext2fs_test_inode_bitmap(fs, inode_dir_map, root_ino)))
			fatal_error("Root inode not directory");
		return;
	}

	printf("Root inode not allocated.  ");
	preenhalt();
	if (!ask("Rellocate", 1)) {
		ext2fs_unmark_valid(fs);
		fatal_error("Cannot proceed without a root inode.");
	}

	read_bitmaps(fs);
	
	/*
	 * First, find a free block
	 */
	retval = ext2fs_new_block(fs, 0, block_found_map, &blk);
	if (retval) {
		com_err("ext2fs_new_block", retval,
			"while trying to create /lost+found directory");
		fatal_error(0);
	}
	ext2fs_mark_block_bitmap(fs, block_found_map, blk);
	ext2fs_mark_block_bitmap(fs, fs->block_map, blk);
	ext2fs_mark_bb_dirty(fs);

	/*
	 * Now let's create the actual data block for the inode
	 */
	retval = ext2fs_new_dir_block(fs, EXT2_ROOT_INO, EXT2_ROOT_INO,
				      &block);
	if (retval) {
		com_err("ext2fs_new_dir_block", retval,
			"while creating new root directory");
		fatal_error(0);
	}

	retval = io_channel_write_blk(fs->io, blk, 1, block);
	if (retval) {
		com_err("io_channel_write_blk", retval,
			"while writing the root directory block");
		fatal_error(0);
	}
	free(block);

	/*
	 * Set up the inode structure
	 */
	memset(&inode, 0, sizeof(inode));
	inode.i_mode = 040755;
	inode.i_size = fs->blocksize;
	inode.i_atime = inode.i_ctime = inode.i_mtime = time(0);
	inode.i_links_count = 2;
	inode.i_blocks = fs->blocksize / 512;
	inode.i_block[0] = blk;

	/*
	 * Write out the inode.
	 */
	retval = ext2fs_write_inode(fs, EXT2_ROOT_INO, &inode);
	if (retval) {
		com_err("ext2fs_write_inode", retval,
			"While trying to create /lost+found");
		fatal_error(0);
	}
	
	/*
	 * Miscellaneous bookkeeping...
	 */
	add_dirmap(fs, EXT2_ROOT_INO, EXT2_ROOT_INO, &inode);
	inode_count[EXT2_ROOT_INO] = 3;

	ext2fs_mark_inode_bitmap(fs, inode_used_map, EXT2_ROOT_INO);
	ext2fs_mark_inode_bitmap(fs, inode_dir_map, EXT2_ROOT_INO);
	ext2fs_mark_inode_bitmap(fs, fs->inode_map, EXT2_ROOT_INO);
	ext2fs_mark_ib_dirty(fs);
}

/*
 * This routine gets the lost_and_found inode, making it a directory
 * if necessary
 */
ino_t get_lost_and_found(ext2_filsys fs)
{
	ino_t			ino;
	blk_t			blk;
	errcode_t		retval;
	struct ext2_inode	inode;
	char *			block;
	char *			name = "lost+found";

	retval = ext2fs_lookup(fs, EXT2_ROOT_INO, name, strlen(name), 0, &ino);
	if (!retval)
		return ino;
	if (retval != ENOENT)
		printf("Error while trying to find /lost+found: %s",
		       error_message(retval));
	else
		printf("/lost+found not found.  ");
	preenhalt();
	if (!ask("Create", 1)) {
		ext2fs_unmark_valid(fs);
		return 0;
	}

	/*
	 * Read the inode and block bitmaps in; we'll be messing with
	 * them.
	 */
	read_bitmaps(fs);
	
	/*
	 * First, find a free block
	 */
	retval = ext2fs_new_block(fs, 0, block_found_map, &blk);
	if (retval) {
		com_err("ext2fs_new_block", retval,
			"while trying to create /lost+found directory");
		return 0;
	}
	ext2fs_mark_block_bitmap(fs, block_found_map, blk);
	ext2fs_mark_block_bitmap(fs, fs->block_map, blk);
	ext2fs_mark_bb_dirty(fs);

	/*
	 * Next find a free inode.
	 */
	retval = ext2fs_new_inode(fs, EXT2_ROOT_INO, 040755, inode_used_map,
				  &ino);
	if (retval) {
		com_err("ext2fs_new_inode", retval,
			"while trying to create /lost+found directory");
		return 0;
	}
	ext2fs_mark_inode_bitmap(fs, inode_used_map, ino);
	ext2fs_mark_inode_bitmap(fs, inode_dir_map, ino);
	ext2fs_mark_inode_bitmap(fs, fs->inode_map, ino);
	ext2fs_mark_ib_dirty(fs);

	/*
	 * Now let's create the actual data block for the inode
	 */
	retval = ext2fs_new_dir_block(fs, ino, EXT2_ROOT_INO, &block);
	if (retval) {
		com_err("ext2fs_new_dir_block", retval,
			"while creating new directory block");
		return 0;
	}

	retval = io_channel_write_blk(fs->io, blk, 1, block);
	if (retval) {
		com_err("io_channel_write_blk", retval,
			"while writing the directory block for /lost+found");
		return 0;
	}
	free(block);

	/*
	 * Set up the inode structure
	 */
	memset(&inode, 0, sizeof(inode));
	inode.i_mode = 040755;
	inode.i_size = fs->blocksize;
	inode.i_atime = inode.i_ctime = inode.i_mtime = time(0);
	inode.i_links_count = 2;
	inode.i_blocks = fs->blocksize / 512;
	inode.i_block[0] = blk;

	/*
	 * Next, write out the inode.
	 */
	retval = ext2fs_write_inode(fs, ino, &inode);
	if (retval) {
		com_err("ext2fs_write_inode", retval,
			"While trying to create /lost+found");
		return 0;
	}
	/*
	 * Finally, create the directory link
	 */
	retval = ext2fs_link(fs, EXT2_ROOT_INO, name, ino, 0);
	if (retval) {
		com_err("ext2fs_link", retval, "While creating /lost+found");
		return 0;
	}

	/*
	 * Miscellaneous bookkeeping that needs to be kept straight.
	 */
	add_dirmap(fs, ino, EXT2_ROOT_INO, &inode);
	adjust_inode_count(fs, EXT2_ROOT_INO, +1);
	inode_count[ino] = 2;
	ext2fs_mark_inode_bitmap(fs, inode_found_map, ino);
#if 0
	printf("/lost+found created; inode #%d\n", ino);
#endif
	return ino;
}

void traverse_tree(ext2_filsys fs, ino_t inode, ino_t parent)
{
	struct dir_map *dir;
	char *			path1;
	char *			path2;
	struct subdir_map	*subdir;
	errcode_t		retval;

#if 0
	printf("In traverse_tree, inode %d, parent %d\n", inode, parent);
#endif
	dir = get_dirmap(inode);
	if (!dir) {
		printf("Internal error: dirmap not found for inode %d.\n",
			inode);
		fatal_error(0);
	}
	/*
	 * See if we've seen this directory already; if we have, offer
	 * to clear the hard link.
	 */
	if (ext2fs_test_inode_bitmap(fs, inode_found_map, inode)) {
		retval = ext2fs_get_pathname(fs, inode, parent, &path1);
		if (retval) {
			com_err(program_name, retval,
				"while getting pathname in traverse tree");
			fatal_error(0);
		}
		printf("Hard link to directory inode %d (%s) found.\n",
		       inode, path1);
		free(path1);
		preenhalt();
		if (ask("Clear", 1)) {
			retval = ext2fs_unlink(fs, parent, 0, inode, 0);
			if (retval) {
				com_err("ext2fs_unlink", retval, "");
				ext2fs_unmark_valid(fs);
			}
		} else
			ext2fs_unmark_valid(fs);
		/*
		 * This part of the directory tree has been validated
		 * already; we don't want to do it again.  We could
		 * end up in an infinite loop otherwise.
		 */
		return;
	}
	if (dir->parent != parent) {
		retval = ext2fs_get_pathname(fs, dir->parent, 0, &path1);
		if (!retval)
			retval = ext2fs_get_pathname(fs, parent, 0, &path2);
		if (retval) {
			com_err(program_name, retval,
				"while getting pathname in traverse tree");
			fatal_error(0);
		}
		printf("Parent directory of inode %d was %d (%s), expecting %d (%s).\n",
		       inode, dir->parent, path1, parent, path2);
		preenhalt();
		if (ask("Fix", 1)) {
			fix_parent(fs, inode, parent);
			dir->parent = parent;
		} else
			ext2fs_unmark_valid(fs);
		free(path1);
		free(path2);
	}
	ext2fs_mark_inode_bitmap(fs, inode_found_map, inode);
	subdir = dir->subdir;
	while (subdir) {
		traverse_tree(fs, subdir->ino, inode);
		subdir = subdir->next;
	}
}

/*
 * This routine will connect a file to lost+found
 */
int reconnect_file(ext2_filsys fs, ino_t inode)
{
	errcode_t	retval;
	char		name[80];
	
	if (bad_lost_and_found) {
		printf("Bad or nonexistent /lost+found.  Cannot reconnect.\n");
		return 1;
	}
	if (!lost_and_found) {
		lost_and_found = get_lost_and_found(fs);
		if (!lost_and_found) {
			printf("Bad or nonexistent /lost+found.  Cannot reconnect.\n");
			bad_lost_and_found++;
			return 1;
		}
	}

	sprintf(name, "#%d", inode);
	retval = ext2fs_link(fs, lost_and_found, name, inode, 0);
	if (retval) {
		printf("Could not reconnect %d: %s\n", inode,
		       error_message(retval));
		return 1;
	}

	adjust_inode_count(fs, inode, +1);

	return 0;
}

/*
 * Utility routine to adjust the inode counts on an inode.
 */
static int adjust_inode_count(ext2_filsys fs, ino_t ino, int adj)
{
	errcode_t		retval;
	struct ext2_inode 	inode;
	
	if (!ino)
		return 0;

	retval = ext2fs_read_inode(fs, ino, &inode);
	if (retval)
		return retval;

#if 0
	printf("Adjusting link count for inode %d by %d (from %d)\n", ino, adj,
	       inode.i_links_count);
#endif

	inode.i_links_count += adj;
	inode_count[ino] += adj;
	inode_link_info[ino] += adj;

	retval = ext2fs_write_inode(fs, ino, &inode);
	if (retval)
		return retval;

	return 0;
}

/*
 * Fix parent --- this routine fixes up the parent of a directory.
 */
struct fix_parent_struct {
	ext2_filsys	fs;
	ino_t		parent;
	int		done;
};

static int fix_parent_proc(struct ext2_dir_entry *dirent,
			   int	offset,
			   int	blocksize,
			   char	*buf,
			   void	*private)
{
	struct fix_parent_struct *fp = (struct fix_parent_struct *) private;
	errcode_t	retval;

	if (dirent->name_len != 2)
		return 0;
	if (strncmp(dirent->name, "..", 2))
		return 0;
	
	retval = adjust_inode_count(fp->fs, dirent->inode, -1);
	if (retval)
		printf("Error while adjusting inode count on inode %d\n",
		       dirent->inode);
	retval = adjust_inode_count(fp->fs, fp->parent, 1);
	if (retval)
		printf("Error while adjusting inode count on inode %d\n",
		       fp->parent);

	dirent->inode = fp->parent;

	fp->done++;
	return DIRENT_ABORT | DIRENT_CHANGED;
}

static void fix_parent(ext2_filsys fs, ino_t inode, ino_t parent)
{
	errcode_t	retval;
	struct fix_parent_struct fp;
	struct dir_map *dir;

	fp.fs = fs;
	fp.parent = parent;
	fp.done = 0;

#if 0
	printf("Fixing parent of inode %d to be %d...\n", inode, parent);
#endif
	
	retval = ext2fs_dir_iterate(fs, inode, DIRENT_FLAG_INCLUDE_EMPTY,
				    0, fix_parent_proc, &fp);
	if (retval || !fp.done) {
		printf("Couldn't fix parent of inode %d: %s\n\n",
		       inode, retval ? error_message(retval) :
		       "Couldn't find parent direntory entry");
		ext2fs_unmark_valid(fs);
	}
	dir = get_dirmap(inode);
	if (dir)
		dir->parent = parent;
	
	return;
}


		
