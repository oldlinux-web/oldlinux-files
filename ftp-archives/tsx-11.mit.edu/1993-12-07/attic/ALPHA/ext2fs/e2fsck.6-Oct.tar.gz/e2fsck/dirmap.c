/*
 * dirmap.c
 */

#include <et/com_err.h>
#include "e2fsck.h"

static errcode_t dirmap_check_directory(ext2_filsys fs, ino_t ino);
static errcode_t dirmap_get_blocks(ext2_filsys fs, ino_t ino, blk_t *blocks);
static int dircmp(const void *a, const void *b);

static int		dir_map_count = 0;
static int		dir_map_size = 0;
static struct dir_map	**dir_map = 0;
static struct	dir_map	**dir_map_sorted = 0;

/*
 * This subroutine creates a dirmap entry for a directory inode.
 * The dirmap entry is used to stash away information which we will
 * need later.  The idea is to avoid reading directory inodes twice.
 */
void add_dirmap(ext2_filsys fs, ino_t ino, ino_t parent,
		struct ext2_inode *inode)
{
	struct dir_map *dir;
	int	i;

#if 0
	printf("add_dirmap for inode %d...\n", ino);
#endif
	if (!dir_map) {
		dir_map_count = 0;
		dir_map_size = 0;
		for (i = 0; i < fs->group_desc_count; i++)
			dir_map_size += fs->group_desc[i].bg_used_dirs_count;
		dir_map_size += 10;

		dir_map  = allocate_memory(dir_map_size *
					   sizeof (struct dir_map *),
					   "directory map");
	}
	
	dir = allocate_memory(sizeof(struct dir_map), "directory map entry");
	dir->ino = ino;
	dir->parent = parent;
	for (i=0; i < EXT2_N_BLOCKS; i++)
		dir->block[i] = inode->i_block[i];

	if (dir_map_count >= dir_map_size) {
		dir_map_size += 10;
		dir_map = realloc(dir_map,
				  dir_map_size * sizeof(struct dir_map *));
	}
	dir_map[dir_map_count++] = dir;
}

/*
 * get_dirmap() --- given an inode number, try to find the dirmap entry
 * for it.
 */
struct dir_map *get_dirmap(ino_t ino)
{
	int	low, high, mid;

	low = 0;
	high = dir_map_count-1;
	if (ino == dir_map[low]->ino)
		return dir_map[low];
	if  (ino == dir_map[high]->ino)
		return dir_map[high];

	while (low < high) {
		mid = (low+high)/2;
		if (mid == low || mid == high)
			break;
		if (ino == dir_map[mid]->ino)
			return dir_map[mid];
		if (ino < dir_map[mid]->ino)
			high = mid;
		else
			low = mid;
	}
	return 0;
}

errcode_t get_sorted_dirmap(struct dir_map ***ret_map, int *ret_count)
{
	int	i;
	
	if (!dir_map_sorted) {
		dir_map_sorted = malloc(dir_map_count *
					sizeof(struct dir_map *));
		if (!dir_map_sorted)
			return ENOMEM;
		for (i=0; i < dir_map_count; i++)
			dir_map_sorted[i] = dir_map[i];
		qsort(dir_map_sorted, dir_map_count,
		      sizeof(struct dir_map *), dircmp);
	}
	*ret_map = dir_map_sorted;
	*ret_count = dir_map_count;
	return 0;
}

static int dircmp(const void *a, const void *b)
{
	const struct dir_map **dir_a = (const struct dir_map **) a;
	const struct dir_map **dir_b = (const struct dir_map **) b;
	
	return ((*dir_a)->block[0] - (*dir_b)->block[0]);
}

void use_dirmap_info(ext2_filsys fs)
{
	fs->get_blocks = dirmap_get_blocks;
	fs->check_directory = dirmap_check_directory;
}

/*
 * These subroutines short circuits ext2fs_get_blocks and
 * ext2fs_check_directory; we use them since we already have the
 * directory inode information already stashed away.
 */
static errcode_t dirmap_get_blocks(ext2_filsys fs, ino_t ino, blk_t *blocks)
{
	struct dir_map *dir;
	int	i;

	dir = get_dirmap(ino);

	if (dir) {
		for (i=0; i < EXT2_N_BLOCKS; i++)
			blocks[i] = dir->block[i];
		return 0;
	}
	return ENOTDIR;
}

static errcode_t dirmap_check_directory(ext2_filsys fs, ino_t ino)
{
	if (ext2fs_test_inode_bitmap(fs, inode_dir_map, ino))
		return 0;
	return ENOTDIR;
}


/*
 * Free the dirmap structure when it isn't needed any more.
 */
void free_dirmap(ext2_filsys fs)
{
	int	i;

	if (dir_map) {
		for (i=0; i < dir_map_count; i++)
			free(dir_map[i]);
		free(dir_map);
		dir_map = 0;
	}
	dir_map_size = 0;
	dir_map_count = 0;
	if (dir_map_sorted) {
		free(dir_map_sorted);
		dir_map_sorted = 0;
	}
	if (fs->get_blocks == dirmap_get_blocks)
		fs->get_blocks = 0;
	if (fs->check_directory == dirmap_check_directory)
		fs->check_directory = 0;
	
}
