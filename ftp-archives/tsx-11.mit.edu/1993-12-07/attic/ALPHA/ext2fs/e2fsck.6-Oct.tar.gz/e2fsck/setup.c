/*
 * setup.c --- sets up e2fsck's data structures
 */

#include "e2fsck.h"

void e2fsck_setup(ext2_filsys fs)
{
}

