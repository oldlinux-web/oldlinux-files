/*
 *	OS Specific settings for Linux
 */

#define ALLOW_SELECT

#include <linux/param.h>
#include <linux/types.h>
#include <linux/errno.h>
#include <linux/signal.h>
#include <linux/fcntl.h>
#include <linux/sched.h>
#include <linux/timer.h>
#include <linux/tty.h>
#include <linux/ctype.h>
#include <asm/io.h>
#include <asm/segment.h>
#include <asm/system.h>
#include <sys/kd.h>
#include <asm/dma.h>
#include <linux/wait.h>
#include <linux/soundcard.h>

typedef char snd_rw_buf;

#define FALSE	0
#define TRUE	1

#define COPY_FROM_USER(d, s, o, c)	memcpy_fromfs((d), &((s)[o]), (c))
#define COPY_TO_USER(d, o, s, c)	memcpy_tofs(&((d)[o]), (s), (c))
#define IOCTL_FROM_USER(d, s, o, c)	memcpy_fromfs((d), &((s)[o]), (c))
#define IOCTL_TO_USER(d, o, s, c)	memcpy_tofs(&((d)[o]), (s), (c))

#define GET_BYTE_FROM_USER(target, addr, offs)	target = get_fs_byte(&((addr)[offs]))
#define GET_SHORT_FROM_USER(target, addr, offs)	target = get_fs_word(&((addr)[offs]))
#define GET_WORD_FROM_USER(target, addr, offs)	target = get_fs_long((long*)&((addr)[offs]))
#define PUT_WORD_TO_USER(addr, offs, data)	put_fs_long(data, (long*)&((addr)[offs]))
#define IOCTL_IN(arg)			get_fs_long((long *)(arg))
#define IOCTL_OUT(arg, ret)		snd_ioctl_return((int *)arg, ret)

#define PROCESS_ABORTING		(current->signal & ~current->blocked)
#define INTERRUPTIBLE_SLEEP_ON(q)	interruptible_sleep_on(&q)
#define WAKE_UP(q)			wake_up(&q)

#define ALLOC_DMA_CHN(chn)		request_dma(chn)
#define RELEASE_DMA_CHN(chn)		free_dma(chn)

#define GET_TIME()			jiffies
#define RELEASE_IRQ			free_irq
#define RET_ERROR(err)			-err
#define DEFINE_WAIT_QUEUE(name, flag) static struct wait_queue *name = NULL; static int flag = 0
#define DEFINE_WAIT_QUEUES(name, flag) static struct wait_queue *name = {NULL}; static int flag = {0}

/* DISABLE_INTR and ENABLE_INTR are used to disable or enable interrupts.
   These macros store the current flags to the (unsigned long) variable given
   as a parameter. RESTORE_INTR returns the interrupt ebable bit to state
   before DISABLE_INTR or ENABLE_INTR */

#define DISABLE_INTR(flags)	__asm__ __volatile__("pushfl ; popl %0 ; cli":"=r" (flags));
#define ENABLE_INTR(flags)	__asm__ __volatile__("pushfl ; popl %0 ; sti":"=r" (flags));
#define RESTORE_INTR(flags)	__asm__ __volatile__("pushl %0 ; popfl": \
							:"r" (flags));

#define INB	inb
#define OUTB	outb
