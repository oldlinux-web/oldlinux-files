/*
 * NOTE! 	You propably have to change the GUS_DEV before compiling. Use
 * -lm option while compiling.
 */

/*
 * gustest.c	- A sample program to demonstrate programming of the Gravis
 * Ultrasound
 * 
 * Sorry!	No documents yet.
 * 
 * Please read ultradox 2.0 by Joshua Jensen. It contains usefull information.
 * 
 * The macro interface (sys/ultrasound.h) is similar to GUSUNIT (TP7 unit for
 * GUS) by Oliver Fromme. (gusunit.doc included in this directory). There is
 * a macro for most of the procedures in the GUSUNIT. The only difference is
 * (I believe) one extra parameter. The first parameter is the device number
 * of your GUS.
 */

#include <stdio.h>
#include <sys/ultrasound.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <math.h>

/*
 * The first parameter of the GUS_ macros is the device number of the GUS
 * wave table synthesizer. The Linux Sound driver supports (soon) more than
 * one synthesizer devices. Each synth has an unique device number. These
 * numbers are assigned in the initialization order. The first one gets
 * number 0 etc.
 * 
 * If you don't have other soundcards than GUS, use value 0. If you have AdLib,
 * SB or PAS also, use 1.
 */
#define GUS_DEV 	gus_dev

SEQ_DEFINEBUF (2048);

int             seqfd;

int             gus_dev = -1;

struct patch_info *patch;

/*
 * The function seqbuf_dump() must always be provided
 */

void
seqbuf_dump ()
{
  if (_seqbufptr)
    if (write (seqfd, _seqbuf, _seqbufptr) == -1)
      {
	perror ("write /dev/sequencer");
	exit (-1);
      }
  _seqbufptr = 0;
}

#define PAT_LEN	18

int
main (int argc, char *argv[])
{
  int             note, i, n, first_note = 60, last_note = 60;
  struct synth_info info;

  if ((seqfd = open ("/dev/sequencer", O_WRONLY, 0)) == -1)
    {
      perror ("/dev/sequencer");
      exit (-1);
    }

  SEQ_SET_PATCH(0, 0, 0);
  SEQ_SET_PATCH(1, 0, 0);

  if (argc == 3) 
  {
     first_note = atoi(argv[1]);
     last_note = atoi(argv[2]);
  }

  while(1)
  for (note=first_note;note <=last_note;note++)
  {
  	printf("Tuning note #%d\n", note);
  for (i=0;i<4;i++)
  {
  	SEQ_START_TIMER();

  	SEQ_START_NOTE(0, 0, note, 64);
  	SEQ_WAIT_TIME(100);
  	SEQ_STOP_NOTE(0, 0, note, 64);
  	SEQ_START_NOTE(1, 0, note, 64);
  	SEQ_WAIT_TIME(200);
  	SEQ_STOP_NOTE(1, 0, note, 64);
  }
  SEQ_DUMPBUF ();
  	ioctl(seqfd, SNDCTL_SEQ_SYNC, 0);
  }

  exit (0);
}
