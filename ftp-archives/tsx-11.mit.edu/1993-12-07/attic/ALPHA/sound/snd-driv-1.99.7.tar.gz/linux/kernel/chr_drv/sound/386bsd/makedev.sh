#!/bin/sh
MAJOR=14
# Create the devices
#
#	Mixer 		($MAJOR, 0)
#
rm -f /dev/mixer
mknod /dev/mixer c $MAJOR 0
chmod 666 /dev/mixer
#
#	Sequencer	($MAJOR, 1)
#
rm -f /dev/sequencer
mknod /dev/sequencer c $MAJOR 1
chmod 666 /dev/sequencer
#
#	DSP		($MAJOR, 3)
#
rm -f /dev/dsp
mknod /dev/dsp c $MAJOR 3
chmod 666 /dev/dsp
#
#	SPARC audio	($MAJOR, 4)	[ Not fully implemented ]
#
rm -f /dev/audio
mknod /dev/audio c $MAJOR 4
chmod 666 /dev/audio
#
exit 0
