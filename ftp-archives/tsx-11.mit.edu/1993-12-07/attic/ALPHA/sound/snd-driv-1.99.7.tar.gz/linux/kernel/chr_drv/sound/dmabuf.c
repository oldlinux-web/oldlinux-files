/*
 * linux/kernel/chr_drv/sound/dmabuf.c
 * 
 * The DMA buffer manager for digitized voice applications
 * 
 * (C) 1992  Hannu Savolainen (hsavolai@cs.helsinki.fi)
 */

#include "sound_config.h"

#ifdef CONFIGURE_SOUNDCARD

#include "sound_calls.h"

#if !defined(EXCLUDE_AUDIO) || !defined(EXCLUDE_GUS)

#define MAX_SUB_BUFFERS		16

/*
 * The DSP channel can be used either for input or output. Variable
 * 'dma_mode' will be set when the program calls read or write first time
 * after open. Current version doesn't support mode changes without closing
 * and reopening the device. Support for this feature may be implemented in a
 * future version of this driver.
 */

#define DMODE_NONE		0
#define DMODE_OUTPUT		1
#define DMODE_INPUT		2
#define DMODE_INIT		3

DEFINE_WAIT_QUEUES (dev_sleeper[MAX_DSP_DEV], dev_sleep_flag[MAX_DSP_DEV]);

static int      dma_mode[MAX_DSP_DEV] =
{0};				/* DMODE_INPUT, DMODE_OUTPUT or DMODE_NONE */

/*
 * Pointers to raw buffers
 */

char           *snd_raw_buf[MAX_DSP_DEV][DSP_BUFFCOUNT];
unsigned long   snd_raw_buf_phys[MAX_DSP_DEV][DSP_BUFFCOUNT];
int             snd_raw_count[MAX_DSP_DEV];

/*
 * Device state tables
 */

static int      dev_busy[MAX_DSP_DEV];
static int      dev_active[MAX_DSP_DEV];
static int      dev_qlen[MAX_DSP_DEV];
static int      dev_qhead[MAX_DSP_DEV];
static int      dev_qtail[MAX_DSP_DEV];
static int      dev_underrun[MAX_DSP_DEV];
static int      bufferalloc_done[MAX_DSP_DEV];

/*
 * Logical buffers for each devices
 */

static int      dev_nbufs[MAX_DSP_DEV];	/* # of logical buffers ( >=
					 * sound_buffcounts[dev] */
static int      dev_counts[MAX_DSP_DEV][MAX_SUB_BUFFERS];
static unsigned long dev_buf_phys[MAX_DSP_DEV][MAX_SUB_BUFFERS];
static char    *dev_buf[MAX_DSP_DEV][MAX_SUB_BUFFERS];
static int      dev_buffsize[MAX_DSP_DEV];

static void
reorganize_buffers (int dev)
{
  /*
   * This routine breaks the physical device buffers to logical ones.
   */

  unsigned long   i, p, n;
  unsigned long   sr, nc, sz, bsz;

  sr = dsp_devs[dev]->ioctl (dev, SOUND_PCM_READ_RATE, 0, 1);
  nc = dsp_devs[dev]->ioctl (dev, SOUND_PCM_READ_CHANNELS, 0, 1);
  sz = dsp_devs[dev]->ioctl (dev, SOUND_PCM_READ_BITS, 0, 1);

  if (sr < 1 || nc < 1 || sz < 1)
    {
      printk ("SOUND: Invalid PCM parameters[%d] sr=%d, nc=%d, sz=%d\n", dev, sr, nc, sz);
      sr = DSP_DEFAULT_SPEED;
      nc = 1;
      sz = 8;
    }

  sz /= 8;			/* Convert # of bits -> # of bytes */

  sz = sr * nc * sz;

  /*
   * Compute a buffer size not exeeding 1 second.
   */

  bsz = sound_buffsizes[dev];

  while (bsz > sz)
    bsz >>= 1;			/* Divide by 2 */

  if (sound_buffcounts[dev] == 1 && bsz == sound_buffsizes[dev])
    bsz >>= 1;			/* Need at least 2 buffers */

  dev_buffsize[dev] = bsz;
  n = 0;

  /*
   * Now computing addresses for the logical buffers
   */

  for (i = 0; i < snd_raw_count[dev]; i++)
    {
      p = 0;

      while ((p + bsz) <= sound_buffsizes[dev])
	{
	  dev_buf[dev][n] = snd_raw_buf[dev][i] + p;
	  dev_buf_phys[dev][n] = snd_raw_buf_phys[dev][i] + p;
	  p += bsz;
	  n++;
	}
    }

  dev_nbufs[dev] = n;

  for (i = 0; i < dev_nbufs[dev]; i++)
    {
      dev_counts[dev][i] = 0;
    }

  bufferalloc_done[dev] = 1;
}

int
DMAbuf_open (int dev, int mode)
{
  int             retval;

  if (dev >= num_dspdevs)
    {
      printk ("PCM device %d not installed.\n", dev);
      return RET_ERROR (ENODEV);
    }

  if (dev_busy[dev])
    return RET_ERROR (EBUSY);

  if (!dsp_devs[dev])
    {
      printk ("DSP device %d not initialized\n", dev);
      return RET_ERROR (ENODEV);
    }

  if (sound_buffcounts[dev] <= 0)
    return RET_ERROR (ENOSPC);	/* Memory allocation failed during boot */

  if ((retval = dsp_devs[dev]->open (dev, mode)) < 0)
    return retval;

  dev_underrun[dev] = 0;

  dev_busy[dev] = 1;

  reorganize_buffers (dev);
  bufferalloc_done[dev] = 0;

  dev_qlen[dev] = dev_qtail[dev] = dev_qhead[dev] = 0;

  return 0;
}

static void
dma_reset (int dev)
{
  dsp_devs[dev]->reset (dev);

  dev_qlen[dev] = 0;
  dev_qhead[dev] = 0;
  dev_qtail[dev] = 0;
  dev_active[dev] = 0;
}

static int
dma_sync (int dev)
{
  if (dma_mode[dev] == DMODE_OUTPUT)
    {
      while (!PROCESS_ABORTING
	     && dev_qlen[dev])
	{
	  dev_sleep_flag[dev] = 1;
	  INTERRUPTIBLE_SLEEP_ON (dev_sleeper[dev]);	/* Wait until a complete
							 * block is ready */
	}

      /*
       * Some devices such as GUS have huge amount of on board RAM for the
       * audio data. We have to wait util the device has finished playing.
       */

      if (dsp_devs[dev]->has_output_drained)	/* Device has hidden buffers */
	{
	  while (!PROCESS_ABORTING
		 && !dsp_devs[dev]->has_output_drained (dev))
	    {
	      current->timeout = jiffies + (HZ / 4);
	      INTERRUPTIBLE_SLEEP_ON (dev_sleeper[dev]);
	    }
	}
    }
  return dev_qlen[dev];
}

int
DMAbuf_release (int dev, int mode)
{

  if (!PROCESS_ABORTING && (dma_mode[dev] == DMODE_OUTPUT))
    {
      dma_sync (dev);
    }

  dma_reset (dev);

  if (!dev_active[dev])
    dsp_devs[dev]->close (dev);

  dma_mode[dev] = DMODE_NONE;
  dev_busy[dev] = 0;

  return 0;
}

int
DMAbuf_getrdbuffer (int dev, char **buf, int *len)
{
  if (!bufferalloc_done[dev])
    reorganize_buffers (dev);

  if (!dma_mode[dev])
    {
      int             err;

      if ((err = dsp_devs[dev]->prepare_for_input (dev,
				    dev_buffsize[dev], dev_nbufs[dev])) < 0)
	return err;
      dma_mode[dev] = DMODE_INPUT;
    }

  if (dma_mode[dev] != DMODE_INPUT)
    return RET_ERROR (EBUSY);	/* Can't change mode on fly */

  if (!dev_qlen[dev])
    {
      if (!dev_active[dev])
	{
	  dsp_devs[dev]->start_input (dev, dev_buf_phys[dev][dev_qtail[dev]], dev_buffsize[dev], 0);
	  dev_active[dev] = 1;
	}

      dev_sleep_flag[dev] = 1;
      INTERRUPTIBLE_SLEEP_ON (dev_sleeper[dev]);	/* Wait until a complete
							 * block is ready */
    }

  if (!dev_qlen[dev])
    return RET_ERROR (EINTR);

  *buf = &dev_buf[dev][dev_qhead[dev]][dev_counts[dev][dev_qhead[dev]]];
  *len = dev_buffsize[dev] - dev_counts[dev][dev_qhead[dev]];

  return dev_qhead[dev];
}

int
DMAbuf_rmchars (int dev, int buff_no, int c)
{
  int             p = dev_counts[dev][dev_qhead[dev]] + c;

  if (buff_no != dev_qhead[dev])
    printk ("Soundcard warning: DMA Buffers out of sync\n");

  if (p >= dev_buffsize[dev])
    {				/* This buffer is now empty */
      dev_counts[dev][dev_qhead[dev]] = 0;
      dev_qlen[dev]--;
      dev_qhead[dev] = (dev_qhead[dev] + 1) % dev_nbufs[dev];
    }
  else
    dev_counts[dev][dev_qhead[dev]] = p;

  return 0;
}

int
DMAbuf_read (int dev, snd_rw_buf * user_buf, int count)
{
  char           *dmabuf;
  int             buff_no, c, err;

  /*
   * This routine returns at most 'count' bytes from the dsp input buffers.
   * Returns negative value if there is an error.
   */

  if ((buff_no = DMAbuf_getrdbuffer (dev, &dmabuf, &c)) < 0)
    return buff_no;

  if (c > count)
    c = count;

  COPY_TO_USER (user_buf, 0, dmabuf, c);

  if ((err = DMAbuf_rmchars (dev, buff_no, c)) < 0)
    return err;
  return c;

}

int
DMAbuf_ioctl (int dev, unsigned int cmd, unsigned int arg, int local)
{
  switch (cmd)
    {
    case SNDCTL_DSP_RESET:
      dma_reset (dev);
      return 0;
      break;

    case SNDCTL_DSP_SYNC:
      dma_sync (dev);
      return 0;
      break;

    case SNDCTL_DSP_GETBLKSIZE:
      if (!bufferalloc_done[dev])
	reorganize_buffers (dev);

      return IOCTL_OUT (arg, dev_buffsize[dev]);
      break;

    default:
      return dsp_devs[dev]->ioctl (dev, cmd, arg, local);
    }

  return RET_ERROR (EIO);
}

int
DMAbuf_getwrbuffer (int dev, char **buf, int *size)
{
  if (!bufferalloc_done[dev])
    reorganize_buffers (dev);

  if (!dma_mode[dev])
    {
      int             err;

      dma_mode[dev] = DMODE_OUTPUT;
      if ((err = dsp_devs[dev]->prepare_for_output (dev,
				    dev_buffsize[dev], dev_nbufs[dev])) < 0)
	return err;
    }

  if (dma_mode[dev] != DMODE_OUTPUT)
    return RET_ERROR (EBUSY);	/* Can't change mode on fly */


  if (dev_qlen[dev] == dev_nbufs[dev])
    {
      if (!dev_active[dev])
	{
	  printk ("Soundcard warning: DMA not activated %d/%d\n",
		  dev_qlen[dev], dev_nbufs[dev]);
	  return RET_ERROR (EIO);
	}

      dev_sleep_flag[dev] = 1;
      INTERRUPTIBLE_SLEEP_ON (dev_sleeper[dev]);	/* Wait for space */
    }

  if (dev_qlen[dev] == dev_nbufs[dev])
    return RET_ERROR (EIO);	/* We have got signal (?) */

  *buf = dev_buf[dev][dev_qtail[dev]];
  *size = dev_buffsize[dev];
  dev_counts[dev][dev_qtail[dev]] = 0;

  return dev_qtail[dev];
}

int
DMAbuf_start_output (int dev, int buff_no, int l)
{
  if (buff_no != dev_qtail[dev])
    printk ("Soundcard warning: DMA buffers out of sync %d != %d\n", buff_no, dev_qtail[dev]);

  dev_qlen[dev]++;

  dev_counts[dev][dev_qtail[dev]] = l;

  dev_qtail[dev] = (dev_qtail[dev] + 1) % dev_nbufs[dev];

  if (!dev_active[dev])
    {
      dev_active[dev] = 1;
      dsp_devs[dev]->output_block (dev, dev_buf_phys[dev][dev_qhead[dev]], dev_counts[dev][dev_qhead[dev]], 0);
    }

  return 0;
}

int
DMAbuf_start_dma (int dev, unsigned long physaddr, int count, int dma_mode)
{
  int             chan = sound_dsp_dmachan[dev];
  unsigned long   flags;

  /*
   * The count must be one less than the actual size. This is handled by
   * set_dma_addr()
   */

  if (sound_dma_automode[dev])
    {				/* Auto restart mode. Transfer the whole
				 * buffer */
#ifdef linux
      DISABLE_INTR (flags);
      disable_dma (chan);
      clear_dma_ff (chan);
      set_dma_mode (chan, dma_mode | DMA_AUTOINIT);
      set_dma_addr (chan, snd_raw_buf_phys[dev][0]);
      set_dma_count (chan, sound_buffsizes[dev]);
      enable_dma (chan);
      RESTORE_INTR (flags);
#else

#ifdef __386BSD__
      printk ("sound: Invalid DMA mode for device %d\n", dev);

      isa_dmastart ((dma_mode == DMA_MODE_READ) ? B_READ : B_WRITE,
		    snd_raw_buf_phys[dev][0],
		    sound_buffsizes[dev],
		    chan);
#else
#  error This routine is not valid for this OS.
#endif

#endif
    }
  else
    {
#ifdef linux
      DISABLE_INTR (flags);
      disable_dma (chan);
      clear_dma_ff (chan);
      set_dma_mode (chan, dma_mode);
      set_dma_addr (chan, physaddr);
      set_dma_count (chan, count);
      enable_dma (chan);
      RESTORE_INTR (flags);
#else
#ifdef __386BSD__
      isa_dmastart ((dma_mode == DMA_MODE_READ) ? B_READ : B_WRITE,
		    physaddr,
		    count,
		    chan);
#else
#  error This routine is not valid for this OS.
#endif

#endif
    }

  return count;
}

long
DMAbuf_init (long mem_start)
{
  int             i;

  /*
   * In this version the DMA buffer allocation is done by sound_mem_init()
   * which is called by init/main.c
   */

  for (i = 0; i < MAX_DSP_DEV; i++)
    {
      dev_qlen[i] = 0;
      dev_qhead[i] = 0;
      dev_qtail[i] = 0;
      dev_active[i] = 0;
      dev_busy[i] = 0;
      bufferalloc_done[i] = 0;
    }

  return mem_start;
}

void
DMAbuf_outputintr (int dev)
{
  dev_active[dev] = 0;
  dev_qlen[dev]--;
  dev_qhead[dev] = (dev_qhead[dev] + 1) % dev_nbufs[dev];

  if (dev_qlen[dev])
    {
      dsp_devs[dev]->output_block (dev, dev_buf_phys[dev][dev_qhead[dev]], dev_counts[dev][dev_qhead[dev]], 1);
      dev_active[dev] = 1;
    }
  else
    {
      if (dev_busy[dev])
	{
	  dev_underrun[dev]++;
	  dsp_devs[dev]->halt_xfer (dev);
	}
      else
	{			/* Device has been closed */
	  dsp_devs[dev]->close (dev);
	}
    }

  if (dev_sleep_flag[dev])
    {
      dev_sleep_flag[dev] = 0;
      WAKE_UP (dev_sleeper[dev]);
    }
}

void
DMAbuf_inputintr (int dev)
{

  dev_active[dev] = 0;
  if (!dev_busy[dev])
    {
      dsp_devs[dev]->close (dev);
    }
  else if (dev_qlen[dev] == (dev_nbufs[dev] - 1))
    {
      dev_underrun[dev]++;
      dsp_devs[dev]->halt_xfer (dev);
    }
  else
    {
      dev_qlen[dev]++;
      dev_qtail[dev] = (dev_qtail[dev] + 1) % dev_nbufs[dev];

      dsp_devs[dev]->start_input (dev, dev_buf_phys[dev][dev_qtail[dev]], dev_buffsize[dev], 1);
      dev_active[dev] = 1;
    }

  if (dev_sleep_flag[dev])
    {
      dev_sleep_flag[dev] = 0;
      WAKE_UP (dev_sleeper[dev]);
    }
}

int
DMAbuf_open_dma (int dev)
{
  unsigned long   flags;
  int             chan = sound_dsp_dmachan[dev];

  if (ALLOC_DMA_CHN (chan))
    {
      printk ("Unable to grab DMA%d for the audio driver\n", chan);
      return 0;
    }

  DISABLE_INTR (flags);
#ifdef linux
  disable_dma (chan);
  clear_dma_ff (chan);
#endif
  RESTORE_INTR (flags);

  return 1;
}

void
DMAbuf_close_dma (int dev)
{
  int             chan = sound_dsp_dmachan[dev];

  DMAbuf_reset_dma (chan);
  RELEASE_DMA_CHN (chan);
}

void
DMAbuf_reset_dma (int chan)
{
}

/*
 * The sound_mem_init() is called by mem_init() immediately after mem_map is
 * initialized and before free_page_list is created.
 * 
 * This routine allocates DMA buffers at the end of available physical memory (
 * <16M) and marks pages reserved at mem_map.
 */

#else
/* Stub versions if audio services not included	 */

int
DMAbuf_open (int dev, int mode)
{
  return RET_ERROR (ENODEV);
}

int
DMAbuf_release (int dev, int mode)
{
  return 0;
}

int
DMAbuf_read (int dev, snd_rw_buf * user_buf, int count)
{
  return RET_ERROR (EIO);
}

int
DMAbuf_getwrbuffer (int dev, char **buf, int *size)
{
  return RET_ERROR (EIO);
}

int
DMAbuf_getrdbuffer (int dev, char **buf, int *len)
{
  return RET_ERROR (EIO);
}

int
DMAbuf_rmchars (int dev, int buff_no, int c)
{
  return RET_ERROR (EIO);
}

int
DMAbuf_start_output (int dev, int buff_no, int l)
{
  return RET_ERROR (EIO);
}

int
DMAbuf_ioctl (int dev, unsigned int cmd, unsigned int arg, int local)
{
  return RET_ERROR (EIO);
}

long
DMAbuf_init (long mem_start)
{
  return mem_start;
}

int
DMAbuf_start_dma (int dev, unsigned long physaddr, int count, int dma_mode)
{
  return RET_ERROR (EIO);
}

int
DMAbuf_open_dma (int chan)
{
  return RET_ERROR (ENODEV);
}

void
DMAbuf_close_dma (int chan)
{
  return;
}

void
DMAbuf_reset_dma (int chan)
{
  return;
}

void
DMAbuf_inputintr (int dev)
{
  return;
}

void
DMAbuf_outputintr (int dev)
{
  return;
}

#endif

#endif
