/*
	linux/kernel/chr_drv/sound/dev_table.h

	Global definitions for device call tables

	(C) Hannu Savolainen 1992

*/

#ifndef _DEV_TABLE_H_
#define _DEV_TABLE_H_

/*
 *	NOTE! 	NOTE!	NOTE!	NOTE!
 *
 *	If you modify this file, please check the dev_table.c also.
 *
 *	NOTE! 	NOTE!	NOTE!	NOTE!
 */

struct card_info {
	int card_type;	/*	From soundcard.c	*/
	char *name;
	long (*attach) (long mem_start, struct address_info *hw_config);
	int (*probe) (struct address_info *hw_config);
	struct address_info config;
};

struct audio_operations {
        char name[32];
	int (*open) (int dev, int mode);
	void (*close) (int dev);
	void (*output_block) (int dev, unsigned long buf, int count, int intrflag);
	void (*start_input) (int dev, unsigned long buf, int count, int intrflag);
	int (*ioctl) (int dev, unsigned int cmd, unsigned int arg, int local);
	int (*prepare_for_input) (int dev, int bufsize, int nbufs);
	int (*prepare_for_output) (int dev, int bufsize, int nbufs);
	void (*reset) (int dev);
	void (*halt_xfer) (int dev);
	int (*has_output_drained)(int dev);
        void (*copy_from_user)(int dev, char *localbuf, int localoffs,
                               char *userbuf, int useroffs, int len);
};

struct mixer_operations {
	int (*ioctl) (int dev, unsigned int cmd, unsigned int arg);
};

struct synth_operations {
	struct synth_info *info;
	int synth_type;
	int synth_subtype;

	int (*open) (int dev, int mode);
	void (*close) (int dev);
	int (*ioctl) (int dev, unsigned int cmd, unsigned int arg);
	int (*kill_note) (int dev, int voice, int velocity);
	int (*start_note) (int dev, int voice, int note, int velocity);
	int (*set_instr) (int dev, int voice, int instr);
	void (*reset) (int dev);
	void (*hw_control) (int dev, unsigned char *event);
	int (*load_patch) (int dev, int format, snd_rw_buf *addr, int offs, int count);
	void (*aftertouch) (int dev, int voice, int pressure);
	void (*controller) (int dev, int voice, int ctrl_num, int value);
	void (*panning) (int dev, int voice, int value);
};

struct midi_operations {
	struct midi_info info;
	int (*open) (int dev, int mode);
	void (*close) (int dev);
	int (*ioctl) (int dev, unsigned int cmd, unsigned int arg);
	int (*putc) (int dev, unsigned char data);
	int (*start_read) (int dev);
	int (*end_read) (int dev);
	void (*kick)(int dev);
	int (*command) (int dev, unsigned char data);
	int (*buffer_status) (int dev);
};

#ifdef _DEV_TABLE_C_
	struct audio_operations * dsp_devs[MAX_DSP_DEV] = {NULL}; int num_dspdevs = 0;
	struct mixer_operations * mixer_devs[MAX_MIXER_DEV] = {NULL}; int num_mixers = 0;
	struct synth_operations * synth_devs[MAX_SYNTH_DEV] = {NULL}; int num_synths = 0;
	struct midi_operations * midi_devs[MAX_MIDI_DEV] = {NULL}; int num_midis = 0;
#   ifndef EXCLUDE_MPU401
        int mpu401_dev = 0;
#   endif

/*
 *	Note! The detection order is significant. Don't change it.
 */

	struct card_info supported_drivers[] = {
#ifndef EXCLUDE_MPU401
		{SNDCARD_MPU401,"Roland MPU-401",	attach_mpu401, probe_mpu401,
			{MPU_BASE, MPU_IRQ, 0}},
#endif

#ifndef EXCLUDE_GUS
		{SNDCARD_GUS,	"Gravis Ultrasound",	attach_gus_card, probe_gus,
			{GUS_BASE, GUS_IRQ, GUS_DMA}},
#endif

#ifndef EXCLUDE_PAS
		{SNDCARD_PAS,	"ProAudioSpectrum",	attach_pas_card, probe_pas,
			{PAS_BASE, PAS_IRQ, PAS_DMA}},
#endif

#ifndef EXCLUDE_SB
		{SNDCARD_SB,	"SoundBlaster",		attach_sb_card, probe_sb,
			{SBC_BASE, SBC_IRQ, SBC_DMA}},
#endif

#ifndef EXCLUDE_YM3812
		{SNDCARD_ADLIB,	"AdLib",		attach_adlib_card, probe_adlib,
			{FM_MONO, 0, 0}},
#endif
		{0,			"*?*",			NULL}
	};

	int num_sound_drivers =
	    sizeof(supported_drivers) / sizeof (struct card_info);

# ifndef EXCLUDE_AUDIO
	int sound_buffcounts[MAX_DSP_DEV] = {0};
	long sound_buffsizes[MAX_DSP_DEV] = {0};
	int sound_dsp_dmachan[MAX_DSP_DEV] = {0};
	int sound_dma_automode[MAX_DSP_DEV] = {0};
# endif
#else
	extern struct audio_operations * dsp_devs[MAX_DSP_DEV]; int num_dspdevs;
	extern struct mixer_operations * mixer_devs[MAX_MIXER_DEV]; extern int num_mixers;
	extern struct synth_operations * synth_devs[MAX_SYNTH_DEV]; extern int num_synths;
	extern struct midi_operations * midi_devs[MAX_MIDI_DEV]; extern int num_midis;
#   ifndef EXCLUDE_MPU401
        extern int mpu401_dev;
#   endif

	extern struct card_info supported_drivers[];
	extern int num_sound_drivers;

# ifndef EXCLUDE_AUDIO
	extern int sound_buffcounts[MAX_DSP_DEV];
	extern long sound_buffsizes[MAX_DSP_DEV];
	extern int sound_dsp_dmachan[MAX_DSP_DEV];
	extern int sound_dma_automode[MAX_DSP_DEV];
# endif

#endif

long sndtable_init(long mem_start);
int sndtable_get_cardcount (void);

#endif
