/*
 * OS specific settings for 386BSD
 */
#ifndef _OS_H_
#define _OS_H_

#include "param.h"
#include "systm.h"
#include "ioctl.h"
#include "tty.h"
#include "proc.h"
#include "user.h"
#include "conf.h"
#include "file.h"
#include "uio.h"
/* #include "kernel.h" */
#include "syslog.h"
#include "errno.h"
#include "malloc.h"
#include "buf.h"
#include "i386/isa/isa_device.h"

#include "local.h"

#if NSND > 0
#define KERNEL_SOUNDCARD
#else
#undef KERNEL_SOUNDCARD
#endif

#ifdef CONFIGURE_SOUNDCARD

#undef ALLOW_SELECT
#define SHORT_BANNERS

#include "soundcard.h"

typedef struct uio snd_rw_buf;

extern time_t lbolt;

#define COPY_FROM_USER(target, source, offs, count) \
	if (uiomove(target, count, source)) { \
		printf ("sb: Bad copyin()!\n"); \
		return RET_ERROR(EIO); \
	}
#define COPY_TO_USER(target, offs, source, count) \
	if (uiomove(source, count, target)) { \
		printf ("sb: Bad copyout()!\n"); \
		return RET_ERROR(EIO); \
	}
#define IOCTL_FROM_USER(target, source, offs, count) {memcpy(target, &((source)[offs]), count);}
#define IOCTL_TO_USER(target, offs, source, count) {memcpy(&((target)[offs]), source, count);}

#define GET_BYTE_FROM_USER(target, addr, offs)	{uiomove((char*)&(target), 1, addr);}
#define GET_SHORT_FROM_USER(target, addr, offs)	{uiomove((char*)&(target), 2, addr);}
#define GET_WORD_FROM_USER(target, addr, offs)	{uiomove((char*)&(target), 4, addr);}
#define PUT_WORD_TO_USER(addr, offs, data)	{uiomove((char*)&(data), 4, addr);}
#define IOCTL_IN(arg)			(*(int*)arg)
#define IOCTL_OUT(arg, ret)		*(int*)arg = ret

#define printk 		printf
#define PROCESS_ABORTING (curproc->p_sig)	/* Returns 1, if process has received 
						   a signal which terminates it */
#define INTERRUPTIBLE_SLEEP_ON(on_what) 	sleep(&(on_what), PZERO+3)
#define WAKE_UP(who)				wakeup(&(who))

#define ALLOC_DMA_CHN(chn) (0)
#define RELEASE_DMA_CHN(chn) (0)

#define GET_TIME()	(lbolt)	/* Returns current time (1/HZ secs since boot) */

#define RELEASE_IRQ(irq_no)
#define DEFINE_WAIT_QUEUE(name, flag) static int *name = NULL; static int flag = 0
#define DEFINE_WAIT_QUEUES(name, flag) static int *name = {NULL}; static int flag = {0}

#define DMA_MODE_READ		0
#define DMA_MODE_WRITE		1

#ifndef HZ
extern int hz;
#define HZ	hz
#endif

#define DISABLE_INTR(flags)	flags = splhigh()
#define RESTORE_INTR(flags)	splx(flags)

#define RET_ERROR(err)		-(err)

#define INB			inb
#define OUTB(addr, data)	outb(data, addr)
#define memcpy(d, s, c)		bcopy(s, d, c)

#endif
#endif
