/* mbc code */
typedef struct pitch_struct {
    int ppitch;
    int pbend;
    } pitch_table;
/* end */
