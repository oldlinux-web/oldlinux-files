/* #define USE_OWN_GUS_VOL */
/*
 * xmp -- play midi files
 *	Greg Lee, June, 1993
 *	file menu code adapted from "menu_dir2.c", Dan Heller,
 *		XView Programming Manual, appendix F.
 */

/*
 * (some configuration options)
 */
/* comment out the following for true file names in file menu */
/*#define TRY_REAL_FILENAME*/

#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/icon.h>
#include <xview/notice.h>
#include <xview/notify.h>
#include <xview/cms.h>
#include <sspkg/canshell.h>
#include <sspkg/drawobj.h>
#include <sspkg/disp_list.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/dir.h>
#ifdef USE_SHM
#include <sys/ipc.h>	/* ftok */
#include <sys/shm.h>	/* shmget .. */
#endif
#include <X11/Xos.h>
#ifndef MAXPATHLEN
#include <sys/param.h>
#endif

#include <ctype.h>
#define NO_LC_DEFINES
#include "midifile.h"
#include "adagio.h"
#include "allphase.h"
#include "xmp.bits"
#include "dot.bits"
#include "stipple.bits"

#define MAIN_COLOR_GREEN (CMS_CONTROL_COLORS+0)
#define MAIN_COLOR_RED (CMS_CONTROL_COLORS+1)
#define MAIN_COLOR_BLACK (CMS_CONTROL_COLORS+2)

void phase2();
int gusvoice(int);

static Frame frame, settings_frame;
static Panel main_panel, settings_panel;
static Frame meter_frame;
static Canvas_shell meter_shell;
static Drawarea meter_area;
#ifndef USE_SHM
static int mplay_pipe[2];
#endif
static Cms meter_cms;
static int meter_visible = FALSE;
static Notify_client mplayer = (Notify_client)10;
static Frame carousel_frame;
static Panel carousel_panel;
static Panel_item carousel_list;
static int carousel_visible = FALSE;
static int carousel_auto = TRUE;
static int recycle_carousel = FALSE;
static Menu file_menu;
static Panel_item midi_file_item;
static Panel_item dot_play_button;
static Panel_item file_menu_button;
static char midi_file_selected = FALSE;
static char midi_file_playing = FALSE;
static char midi_file_path[MAXPATHLEN];
static Xv_notice misc_notice;
static Rect *working_rect;

#ifdef USE_SHM
int *shm_setting_pstereo;
int *shm_setting_gus_tuning;
int *shm_setting_gus_volume;
int *shm_setting_meter_color;
int *shm_setting_reverb;
int *shm_setting_chorus_spread;
int *shm_setting_vibrato_depth;
#endif

static unsigned xmp_time = 0;
static int xmp_epoch = -1;

static struct itimerval timer;
static Notify_value
timer_service()
{
	int last = xv_get(carousel_list, PANEL_LIST_NROWS);
	static void play_midi_file();
	static void update_meter();

	update_meter();

	xmp_time++;
	if ((xmp_time % 6) == 0 && midi_file_playing == TRUE)
		xv_set(dot_play_button, PANEL_ITEM_COLOR, MAIN_COLOR_BLACK, NULL);
	if ((xmp_time % 6) == 3 && midi_file_playing == TRUE)
		xv_set(dot_play_button, PANEL_ITEM_COLOR, MAIN_COLOR_RED, NULL);

	if (!midi_file_playing && !midi_file_selected && last > 0 && carousel_auto)
		play_midi_file((Panel_item)0, 0, (Event *)0);
	return(NOTIFY_DONE);
}
static void
start_timer()
{
	timer.it_value.tv_usec = 100000;
	timer.it_interval.tv_usec = 100000;
	notify_set_itimer_func(frame, timer_service,
		ITIMER_REAL, &timer, NULL);
}
static void
message(char *prompt)
{
	xv_set(misc_notice,
		NOTICE_MESSAGE_STRING, prompt,
		XV_SHOW, TRUE, NULL);
}

static int child_pid = -1;
#ifndef USE_SHM
static int total_packets = 0;
#endif

static void finish_up_playing()
{
	child_pid = -1;
	xv_set(midi_file_item, PANEL_BUSY, FALSE, NULL);
	xv_set(dot_play_button, PANEL_ITEM_COLOR, MAIN_COLOR_GREEN, NULL);
	xv_set(dot_play_button, PANEL_BUSY, FALSE, NULL);
	midi_file_playing = FALSE;
	if (carousel_visible && carousel_auto && xv_get(carousel_list, PANEL_LIST_NROWS))
		midi_file_selected = FALSE;
#ifndef USE_SHM
	total_packets = 0;
	notify_set_input_func(mplayer, NOTIFY_FUNC_NULL,
		mplay_pipe[0]);
#endif
	xmp_epoch = -1;
}

static void
quit_xmp()
{
	if (child_pid >= 0) {
		kill(child_pid, SIGKILL);
		finish_up_playing();
		return;
	}
	exit(0);
}

static Notify_value
wait3_handle(Notify_client me, int pid, int *status, struct rusage *rusage)
{
	if (WIFEXITED(*status)) {
		finish_up_playing();
		return(NOTIFY_DONE);
	}
	return(NOTIFY_IGNORED);
}

static int
crsltoplay(char *fname, char *path)
{
	int f, prob = 0;
	static char ybuff[80];

	midi_file_selected = TRUE;
	if ((f = open(path, O_RDONLY, 0)) == -1) {
		prob = 1;
		midi_file_selected = FALSE;
	}
	if (midi_file_selected && read(f, ybuff, 4) != 4) {
		prob = 2;
		midi_file_selected = FALSE;
	}
	ybuff[4] = '\0';
	if (midi_file_selected && strcmp(ybuff, "MThd")) {
		prob = 3;
		midi_file_selected = FALSE;
	}
	if (f != -1) close(f);
	strcpy(ybuff, "play: ");
	if (midi_file_selected) strcat(ybuff, fname);
	xv_set(midi_file_item, PANEL_LABEL_STRING, ybuff, NULL);

	if (midi_file_selected) {
		xv_set(dot_play_button, PANEL_ITEM_COLOR, MAIN_COLOR_GREEN, NULL);
		strcpy(midi_file_path, path);
		return(TRUE);
	}
	midi_file_path[0] = '\0';
/* playing from carousel, pass over bad files silently (??) */
	if (!carousel_visible)
	switch (prob) {
		case 1:
			message("can't open file");
			break;
		case 2:
		case 3: message("not a midi file");
			break;
	}
	return(FALSE);
}

static void
play_midi_file(Panel_item it, int value, Event *ev)
{
	static int do_midi();
#ifndef USE_SHM
	static Notify_value read_mplayer();
#endif
	if (midi_file_playing) return;
	if (!midi_file_selected && carousel_visible && carousel_auto) {
		int last = xv_get(carousel_list, PANEL_LIST_NROWS);
		if (last) {
			int ret;
			char *path = (char *)xv_get(carousel_list, 
				PANEL_LIST_CLIENT_DATA, 0, NULL);
			if (path == NULL) {
				xv_set(carousel_list, PANEL_LIST_DELETE, 0, NULL);
				return;
			}
			ret = crsltoplay((char *)xv_get(carousel_list, PANEL_LIST_STRING, 0),
				path);
			if (recycle_carousel && ret) {
				if (last > 1) {
					char buf[MAXPATHLEN];
					strcpy(buf, (char *)xv_get(carousel_list,
						PANEL_LIST_STRING, 0));
					xv_set(carousel_list,
						PANEL_LIST_DELETE, 0,
						PANEL_LIST_INSERT, last - 1,
						PANEL_LIST_STRING, last - 1, buf,
						PANEL_LIST_CLIENT_DATA, last - 1, path,
						NULL);
				}
			}
			else {
				free(path);
				xv_set(carousel_list, PANEL_LIST_DELETE, 0, NULL);
			}
			if (ret == FALSE) return;
		}
		else
		{
			message("use the midi file button to select a file");
			return;
		}
	}
	if (!midi_file_selected) return;

	xmp_epoch = -1;
	midi_file_playing = TRUE;

#ifndef USE_SHM
	pipe(mplay_pipe);
#endif
	switch (child_pid = fork()) {
		case -1: perror("fork"); exit(1);
		case  0:
#ifndef USE_SHM
			 dup2(mplay_pipe[1], 1);
			 close(mplay_pipe[0]);
#endif
			 (void)do_midi(midi_file_path);
			 _exit(0);
		default:
#ifndef USE_SHM
			 close(mplay_pipe[1]);
			 (void)notify_set_input_func(mplayer, read_mplayer, mplay_pipe[0]);
#endif
			 (void)notify_set_wait3_func(mplayer, wait3_handle, child_pid);
	}
}

static void
toggle_options(Panel_item item, unsigned int value, Event *ev)
{
	static int settings_visible = FALSE;
	Rect r;
	int opt = 1;

	frame_get_rect(frame, &r);

	if (value & opt) {
		if (!carousel_visible) {
			xv_set(carousel_frame, XV_X, r.r_left,
				XV_Y, r.r_top+r.r_height, NULL);
		}
		carousel_visible = TRUE;
	}
	else if (carousel_visible) {
		carousel_visible = FALSE;
	}
	xv_set(carousel_frame, XV_SHOW, (value & opt)? TRUE:FALSE, NULL);
	opt <<= 1;
	if (value & opt) {
		if (!meter_visible) {
			xv_set(meter_frame, XV_X, r.r_left+180,
				XV_Y, r.r_top+r.r_height, NULL);
		}
		meter_visible = TRUE;
	}
	else meter_visible = FALSE;
	xv_set(meter_frame, XV_SHOW, (value & opt)? TRUE:FALSE, NULL);
	opt <<= 1;
	if (value & opt) {
		if (!settings_visible) {
			xv_set(settings_frame, XV_X, r.r_left+r.r_width,
				XV_Y, r.r_top, NULL);
		}
		settings_visible = TRUE;
	}
	else settings_visible = FALSE;
	xv_set(settings_frame, XV_SHOW, (value & opt)? TRUE:FALSE, NULL);

}
static int req_no_solo = FALSE, req_piano_only = FALSE;
static void
choose_synth_opt(Panel_item item, unsigned int value, Event *ev)
{
	exclude_fm = ((value & 1) == 0);
	exclude_gus = ((value & 2) == 0);
	extflag = ((value & 4) != 0);
	setting_chorus = ((value & 8) != 0);
	setting_pstereo = ((value & 16) != 0);
	setting_4op_mode = ((value & 32) != 0);
	req_no_solo = ((value & 64) != 0);
	req_piano_only = ((value & 128) != 0);
#ifdef USE_SHM
	*shm_setting_pstereo = setting_pstereo;
#endif
}

static void
reverb_proc(Panel_item item, int value, Event *ev)
{
	setting_reverb = value;
#ifdef USE_SHM
	*shm_setting_reverb = setting_reverb;
#endif
}
static void
chorus_spread_proc(Panel_item item, int value, Event *ev)
{
	setting_chorus_spread = value;
#ifdef USE_SHM
	*shm_setting_chorus_spread = setting_chorus_spread;
#endif
}
static void
vibrato_depth_proc(Panel_item item, int value, Event *ev)
{
	setting_vibrato_depth = value;
#ifdef USE_SHM
	*shm_setting_vibrato_depth = setting_vibrato_depth;
#endif
}
static void
gus_voices_proc(Panel_item item, int value, Event *ev)
{
	setting_gus_voices = value;
}
static void
gus_tuning_proc(Panel_item item, int value, Event *ev)
{
	setting_gus_tuning= value;
#ifdef USE_SHM
	*shm_setting_gus_tuning = setting_gus_tuning;
#endif
}
#ifdef USE_OWN_GUS_VOL
static void
gus_volume_proc(Panel_item item, int value, Event *ev)
{
	setting_gus_volume= value;
#ifdef USE_SHM
	*shm_setting_gus_volume = setting_gus_volume;
#endif
}
#endif
static void
meter_color_proc(Panel_item item, int value, Event *ev)
{
	setting_meter_color = value;
#ifdef USE_SHM
	*shm_setting_meter_color = setting_meter_color;
#endif
}
static void
meter_column_proc(Panel_item item, int value, Event *ev)
{
	setting_meter_column = value;
}
static int setting_meter_sync = 0;
static void
meter_sync_proc(Panel_item item, int value, Event *ev)
{
	setting_meter_sync = value;
}

int
main(int argc, char *argv[])
{
	DIR *dirp;
	char *top_dir;
	Menu_item mi;
	static Menu_item add_path_to_menu();
	Icon icon;
	Rect icon_rect;
	Server_image closed_image, dot_image;
	Cms panel_cms;
	static void setup_settings();
	static void setup_meter();
	static void setup_carousel();

	xv_init(XV_INIT_ARGC_PTR_ARGV, &argc, argv, NULL);

	frame = (Frame)xv_create(
		XV_NULL,
		FRAME,
		XV_X,		50,
		XV_Y,		40,
		XV_WIDTH,	400,
		FRAME_LABEL,	argv[0],
		NULL);

	closed_image = xv_create(XV_NULL, SERVER_IMAGE,
		XV_WIDTH, xmp_width,
		XV_HEIGHT, xmp_height,
		SERVER_IMAGE_X_BITS, xmp_bits,
		NULL);
	icon = (Icon)xv_create(frame, ICON,
		ICON_IMAGE,	closed_image,
		ICON_TRANSPARENT, TRUE,
		NULL);
	icon_rect.r_top = 10;
	icon_rect.r_left = 118;
	icon_rect.r_width = xmp_width;
	icon_rect.r_height = xmp_height;
	xv_set(frame,
		FRAME_ICON, icon,
		FRAME_CLOSED_RECT, &icon_rect,
		NULL);
	panel_cms = (Cms)xv_create(XV_NULL, CMS,
		CMS_SIZE,		CMS_CONTROL_COLORS + 3,
		CMS_CONTROL_CMS,	TRUE,
		CMS_NAMED_COLORS,	"green", "red", "black", NULL,
		NULL);

	main_panel = (Panel)xv_create(frame, PANEL,
		WIN_CMS,	panel_cms,
		XV_X,		0,
		XV_Y,		0,
		NULL);
/*
 * first row
 */
	(void)xv_create(main_panel, PANEL_BUTTON,
		PANEL_LABEL_STRING,	"quit",
		PANEL_NOTIFY_PROC,	quit_xmp,
		NULL);

	if (argc > 1) top_dir = argv[1];
	else {
		top_dir = MIDIDIR;
		if (!(dirp = opendir(top_dir))) top_dir = ".";
		else closedir(dirp);
	}
	if ( (mi = add_path_to_menu(top_dir)) == XV_NULL ) {
		fprintf(stderr, "can't open directory %s\n", top_dir);
		exit(1);
	}
	file_menu = (Menu)xv_get(mi, MENU_PULLRIGHT);
	free((char *)xv_get(mi, MENU_CLIENT_DATA));
	xv_destroy(mi);

	file_menu_button = xv_create(main_panel, PANEL_BUTTON,
		PANEL_LABEL_STRING,	"midi file",
		PANEL_ITEM_MENU,	file_menu,
		NULL);

	setup_settings();
	setup_meter();
	setup_carousel();

	(void)xv_create(main_panel, PANEL_TOGGLE,
		PANEL_CHOICE_STRINGS,	"carousel", "meter", "settings", NULL,
		PANEL_NOTIFY_PROC,	toggle_options,
		PANEL_VALUE,		0,
		NULL);
/*
 * second row
 */

	dot_image = xv_create(XV_NULL, SERVER_IMAGE,
		XV_WIDTH, dot_width,
		XV_HEIGHT, dot_height,
		SERVER_IMAGE_X_BITS, dot_bits,
		NULL);
	dot_play_button = (Panel_item)xv_create(main_panel, PANEL_BUTTON,
		PANEL_NEXT_ROW,		-1,
		PANEL_LABEL_IMAGE,	dot_image,
		PANEL_NOTIFY_PROC,	play_midi_file,
		NULL);
	xv_set(dot_play_button, PANEL_ITEM_COLOR, MAIN_COLOR_RED, NULL);

	midi_file_item = (Panel_item)xv_create(main_panel, PANEL_MESSAGE,
		PANEL_LABEL_STRING,	"play:             ",
		PANEL_NOTIFY_PROC,	play_midi_file,
		NULL);
/*
 * end of rows
 */

	misc_notice = (Xv_notice)xv_create(main_panel, NOTICE,
		NOTICE_LOCK_SCREEN,	TRUE,
		NOTICE_NO_BEEPING,	TRUE,
		XV_SHOW,		FALSE,
		NULL);

	window_fit(main_panel);
	window_fit(frame);

	start_timer();

	window_main_loop(frame);
	return(0);
}

static void
setup_settings()
{
	Panel_item settings_item;
	unsigned int def_value;
	void card_init();
	Panel_item meter_color_choice;

	settings_frame = (Frame) xv_create(frame, FRAME,
		XV_X,		420,
		XV_Y,		50,
		XV_WIDTH,	300,
		WIN_TOP_LEVEL_NO_DECOR,	TRUE,
		FRAME_LABEL,		"settings",
		NULL);

	settings_panel = (Panel)xv_create(settings_frame, PANEL,
		PANEL_ITEM_Y_GAP,	8,
		PANEL_LAYOUT,	PANEL_VERTICAL,
		NULL);

	card_init();
	close(seq_fd);
	exclude_fm = (sb_dev < 0);
	exclude_gus = (gus_dev < 0);
	extflag = (ext_dev >= 0);

	def_value = 0;
	if (!exclude_fm) def_value |= 1;
	if (!exclude_gus) def_value |= 2;
	if (extflag) def_value |= 4;
	if (setting_chorus) def_value |= 8;
	if (setting_pstereo) def_value |= 16;
	if (setting_4op_mode) def_value |= 32;
	if (no_solo) def_value |= 64;
	if (piano_only) def_value |= 128;

	settings_item = (Panel_item)xv_create(settings_panel, PANEL_CHECK_BOX,
		PANEL_LAYOUT,		PANEL_VERTICAL,
		PANEL_CHOICE_NCOLS,	2,
		PANEL_CHOICE_STRINGS,
			"fm card",
			"gus card",
			"external synth",
			"(unused)",
			"pseudo stereo",
			"4op fm",
			"all polyphonic",
			"piano only",
			NULL,
		PANEL_NOTIFY_PROC,	choose_synth_opt,
		PANEL_VALUE,		def_value,
		NULL);
	xv_set(settings_item, PANEL_ITEM_Y_GAP, 8, NULL);

	(void)xv_create(settings_panel, PANEL_SLIDER,
		PANEL_LABEL_STRING,	"reverb delay",
		PANEL_VALUE,		setting_reverb,
		PANEL_MIN_VALUE,	0,
		PANEL_MAX_VALUE,	100,
		PANEL_SLIDER_WIDTH,	90,
		PANEL_TICKS,		10,
		PANEL_NOTIFY_PROC,	reverb_proc,
		NULL);
	(void)xv_create(settings_panel, PANEL_SLIDER,
		PANEL_LABEL_STRING,	"chorus spread",
		PANEL_VALUE,		setting_chorus_spread,
		PANEL_MIN_VALUE,	0,
		PANEL_MAX_VALUE,	100,
		PANEL_SLIDER_WIDTH,	90,
		PANEL_TICKS,		10,
		PANEL_NOTIFY_PROC,	chorus_spread_proc,
		NULL);
	(void)xv_create(settings_panel, PANEL_SLIDER,
		PANEL_LABEL_STRING,	"vibrato depth",
		PANEL_VALUE,		setting_vibrato_depth,
		PANEL_MIN_VALUE,	0,
		PANEL_MAX_VALUE,	100,
		PANEL_SLIDER_WIDTH,	90,
		PANEL_TICKS,		10,
		PANEL_NOTIFY_PROC,	vibrato_depth_proc,
		NULL);
	if (gus_dev >= 0)
	(void)xv_create(settings_panel, PANEL_SLIDER,
		PANEL_LABEL_STRING,	"gus voices",
		PANEL_VALUE,		setting_gus_voices,
		PANEL_MIN_VALUE,	14,
		PANEL_MAX_VALUE,	32,
		PANEL_SLIDER_WIDTH,	90,
		PANEL_TICKS,		18,
		PANEL_NOTIFY_PROC,	gus_voices_proc,
		NULL);
#ifdef USE_OWN_GUS_VOL
	if (gus_dev >= 0)
	(void)xv_create(settings_panel, PANEL_SLIDER,
		PANEL_LABEL_STRING,	"gus volume",
		PANEL_VALUE,		setting_gus_volume,
		PANEL_MIN_VALUE,	0,
		PANEL_MAX_VALUE,	100,
		PANEL_SLIDER_WIDTH,	90,
		PANEL_TICKS,		10,
		PANEL_NOTIFY_PROC,	gus_volume_proc,
		NULL);
#endif
	if (gus_dev >= 0)
	(void)xv_create(settings_panel, PANEL_SLIDER,
		PANEL_LABEL_STRING,	"gus tuning",
		PANEL_VALUE,		setting_gus_tuning,
		PANEL_MIN_VALUE,	-1000,
		PANEL_MAX_VALUE,	1000,
		PANEL_SLIDER_WIDTH,	90,
		PANEL_TICKS,		10,
		PANEL_NOTIFY_PROC,	gus_tuning_proc,
		NULL);
	meter_color_choice = (Panel_item)xv_create(settings_panel, PANEL_CHOICE_STACK,
		PANEL_LABEL_STRING,	"meter color",
		PANEL_CHOICE_STRINGS,
			"expression",
			"main volume",
			"chorus depth",
			"reverberation",
			"stereo pan",
			NULL,
		PANEL_VALUE,		setting_meter_color,
		PANEL_NOTIFY_PROC,	meter_color_proc,
		NULL);
	working_rect = (Rect *)xv_get(meter_color_choice, XV_RECT);
	(void)xv_create(settings_panel, PANEL_CHOICE_STACK,
		PANEL_LABEL_STRING,	"bar",
		PANEL_CHOICE_STRINGS,
			"channel",
			"pitch",
			"instrument",
			NULL,
		PANEL_VALUE,		0,
		XV_X,			rect_right(working_rect),
		XV_Y,			working_rect->r_top,
		PANEL_NOTIFY_PROC,	meter_column_proc,
		NULL);
	(void)xv_create(settings_panel, PANEL_SLIDER,
		PANEL_LABEL_STRING,	"meter sync",
		PANEL_VALUE,		0,
		PANEL_MIN_VALUE,	-50,
		PANEL_MAX_VALUE,	+50,
		PANEL_SLIDER_WIDTH,	90,
		PANEL_TICKS,		20,
		PANEL_NOTIFY_PROC,	meter_sync_proc,
		NULL);

	window_fit(settings_panel);
	window_fit(settings_frame);
}


static void
carousel_options_proc(Panel_item item, unsigned int value, Event *ev)
{
	recycle_carousel = value & 1;
	if (!carousel_auto && (value & 2)) {
		if (!midi_file_playing) midi_file_selected = FALSE;
	}
	carousel_auto = value & 2;
}

void
carousel_action(Menu menu, Menu_item item)
{	int r, last;
	char *path;
	char buf[MAXPATHLEN];
	char *choice = (char *)xv_get(item, MENU_STRING);

	if (!strcmp(choice, "sort")) {
		xv_set(carousel_list, PANEL_LIST_SORT, PANEL_FORWARD, NULL);
		return;
	}
	r = (int)xv_get(carousel_list, PANEL_LIST_FIRST_SELECTED);
	if (r<0) {
		message("please select a file");
		return;
	}
	if (!strcmp(choice, "delete")) {
		xv_set(carousel_list, PANEL_LIST_DELETE, r, NULL);
		return;
	}
	last = xv_get(carousel_list, PANEL_LIST_NROWS);
	if (!last) return;
	path = (char *)xv_get(carousel_list, 
		PANEL_LIST_CLIENT_DATA, r, NULL);
	if (path == NULL) {
		xv_set(carousel_list, PANEL_LIST_DELETE, 0, NULL);
		return;
	}
	strcpy(buf, (char *)xv_get(carousel_list,
		PANEL_LIST_STRING, r));
	if (!strcmp(choice, "bottom")) {
		if (last < 2) return;
		if (r == last - 1) return;
		xv_set(carousel_list,
			PANEL_LIST_DELETE, r,
			PANEL_LIST_INSERT, last - 1,
			PANEL_LIST_STRING, last - 1, buf,
			PANEL_LIST_CLIENT_DATA, last - 1, path,
			NULL);
		return;
	}
	if (!strcmp(choice, "top")) {
		if (last < 2) return;
		if (r == 0) return;
		xv_set(carousel_list,
			PANEL_LIST_DELETE, r,
			PANEL_LIST_INSERT, 0,
			PANEL_LIST_STRING, 0, buf,
			PANEL_LIST_CLIENT_DATA, 0, path,
			NULL);
		return;
	}
	if (!strcmp(choice, "add *")) {
		int i = 0;
		DIR *dirp;
		struct direct *dp;
		struct stat s_buf;
		char n_buf[MAXPATHLEN];
		char *dir_n = strcpy(malloc(strlen(path)+1), path);
		for (i = strlen(dir_n)-1; i > 0 && dir_n[i] != '/'; i--)
			dir_n[i] = '\0';
		if (dir_n[i] != '/') return;
		dir_n[i] = '\0';
		if (!(dirp = opendir(dir_n))) return;
		while ((dp = readdir(dirp))) {

			if (!strcmp(dp->d_name, ".")) continue;
			if (!strcmp(dp->d_name, "..")) continue;
			if (!strcmp(dp->d_name, buf)) continue;

			(void)sprintf(n_buf, "%s/%s", dir_n, dp->d_name);
			if (stat(n_buf, &s_buf) == -1 ||
				!(s_buf.st_mode & S_IREAD) ||
				(s_buf.st_mode & S_IFDIR))
				continue;

			xv_set(carousel_list,
				PANEL_LIST_INSERT, last - 1,
				PANEL_LIST_STRING, last - 1, dp->d_name,
				PANEL_LIST_CLIENT_DATA, last - 1,
					strcpy(malloc(strlen(n_buf)+1), n_buf),
				NULL);
			last++;
		}
		closedir(dirp);
		free(dir_n);
		return;
	}
}

static void
setup_carousel()
{
	Menu carousel_menu;

	carousel_frame = (Frame)xv_create(frame, FRAME,
		XV_WIDTH,	160,
		XV_HEIGHT,	280,
		FRAME_LABEL,	"carousel",
		NULL);
	carousel_panel = (Panel)xv_create(carousel_frame, PANEL,
		PANEL_LAYOUT,	PANEL_VERTICAL,
		NULL);

	carousel_list = (Panel_item)xv_create(carousel_panel, PANEL_LIST,
		PANEL_LIST_DISPLAY_ROWS,	6,
		PANEL_LIST_WIDTH,	-1,
		NULL);
	(void)xv_create(carousel_panel, PANEL_TOGGLE,
		PANEL_CHOICE_STRINGS,	"recycle", "auto", NULL,
		PANEL_NOTIFY_PROC,	carousel_options_proc,
		PANEL_VALUE,		2,
		NULL);
	carousel_menu = (Menu)xv_create(XV_NULL, MENU_CHOICE_MENU,
		MENU_STRINGS, "top", "bottom", "delete", "add *", "sort", NULL,
		MENU_NOTIFY_PROC,	carousel_action,
		NULL);
	xv_set(carousel_list, PANEL_ITEM_MENU, carousel_menu, NULL);
	window_fit(carousel_panel);
	window_fit(carousel_frame);
}

static void
meter_resize(Canvas_shell shell, int width, int height)
{
	xv_set(meter_area,
		XV_WIDTH, width,
		XV_HEIGHT, height,
		NULL);
}

static int time_expired = 0;
struct timeval tv;
struct timezone tz;
static void
time_sync()
{
	unsigned jiffies;

	gettimeofday (&tv, &tz);
	jiffies = tv.tv_sec*100 + tv.tv_usec/10000;
	if (xmp_epoch < 0) xmp_epoch = jiffies;
	time_expired = jiffies - xmp_epoch;
}

#define RINGSIZE 64
int *talk_in, *talk_out;

struct mp_talk {
	unsigned mptime;
	unsigned char count[NUM_CHANS];
	unsigned short vel[NUM_CHANS];
	int expr[NUM_CHANS];
};

struct mp_talk **mpd;


#ifdef USE_SHM

static void
setup_shm()
{
	char *shmaddr;
	key_t key;
	int shmid, i;

	key = ftok ("xmp", 1);

	/* need 2*4 +7*4 + 65*4 + 65*116 = 8 + 28 + 260 + 7520 = 7840 */
	if ((shmid = shmget (key, 8192, IPC_EXCL | 01600 )) < 0) {
		perror ("shmget ");
		exit (1);
	}
	if ((shmaddr = shmat (shmid, (char *)0, SHM_RND)) == (char *) -1) {
		perror ("shmat ");
		if (shmctl (shmid, IPC_RMID, NULL))
			perror ("shmctl ");
		exit (1);
	}

	if (shmctl (shmid, IPC_RMID, NULL)) {
		perror ("shmctl ... ");
		exit (1);
	}

	talk_in = (int *)shmaddr;
	shmaddr += sizeof(int);
	talk_out = (int *)shmaddr;
	shmaddr += sizeof(int);

	shm_setting_pstereo = (int *)shmaddr;
	shmaddr += sizeof(int);
	shm_setting_gus_tuning = (int *)shmaddr;
	shmaddr += sizeof(int);
	shm_setting_gus_volume = (int *)shmaddr;
	shmaddr += sizeof(int);
	shm_setting_meter_color = (int *)shmaddr;
	shmaddr += sizeof(int);
	shm_setting_reverb = (int *)shmaddr;
	shmaddr += sizeof(int);
	shm_setting_chorus_spread = (int *)shmaddr;
	shmaddr += sizeof(int);
	shm_setting_vibrato_depth = (int *)shmaddr;
	shmaddr += sizeof(int);

	*shm_setting_pstereo = setting_pstereo;
	*shm_setting_gus_tuning = setting_gus_tuning;
	*shm_setting_gus_volume = setting_gus_volume;
	*shm_setting_meter_color = setting_meter_color;
	*shm_setting_reverb = setting_reverb;
	*shm_setting_chorus_spread = setting_chorus_spread;
	*shm_setting_vibrato_depth = setting_vibrato_depth;

	mpd = (struct mp_talk **)shmaddr;
	shmaddr += (RINGSIZE+1)*sizeof(struct mp_talk *);
	for (i = 0; i < RINGSIZE+1; i++)
		mpd[i] = (struct mp_talk *)(shmaddr + i*sizeof(struct mp_talk));

}
#endif

static int last_meter_reading[NUM_CHANS];
static int disp_meter_reading[NUM_CHANS];

#ifdef USE_SHM
#define FUTURE_METER 5
#else
#define FUTURE_METER 62
#endif

static void
update_meter()
{
	int chan, vol, r;
	int x1, y1, h, w, cnt = 0;
	int fill_style = 2, exp_color;
	int expired;
	static void read_one_packet();

	read_one_packet();

	if (xmp_epoch < 0) r = RINGSIZE;
	else {
		time_sync();
		expired = FUTURE_METER + time_expired - setting_meter_sync;
		if (expired < 0) return;
		while (*talk_out < *talk_in) {
			if (mpd[*talk_out % RINGSIZE]->mptime > expired + 5) break;
			(*talk_out)++;
		}
		(*talk_out)--;
		if (*talk_out < 0) {
			*talk_out = 0;
			return;
		}
		r = *talk_out % RINGSIZE;
/** (debug)
if (mpd[r]->mptime > expired)
printf("mptime %d > expired %d at *talk_out %d, *talk_in %d\n", mpd[r]->mptime, expired, 
*talk_out, *talk_in);
**/
		if (mpd[r]->mptime > expired + 5) return;
	}

	for (chan = 0; chan < NUM_CHANS; chan++) {
		if (!mpd[r]->count[chan]) vol = 0;
		else vol = mpd[r]->vel[chan] / mpd[r]->count[chan];
		if (vol < disp_meter_reading[chan])
			vol = (vol + disp_meter_reading[chan]) / 2;
		disp_meter_reading[chan] = vol;
		if (vol == last_meter_reading[chan]) continue;
		last_meter_reading[chan] = vol;
		cnt++;
	}
	if (!cnt) return;

	xv_set(meter_shell, CANVAS_SHELL_DELAY_REPAINT, TRUE, NULL);
	VClear(meter_area);
	VSetFillStyle(meter_area, (fill_style = 0));
	for (chan = 0; chan < NUM_CHANS; chan++) {
		vol = disp_meter_reading[chan];
		if (!vol) continue;
		if (PERCCHAN(chan) && !setting_meter_column) {
			if (fill_style != 2) VSetFillStyle(meter_area, (fill_style = 2));
		}
		else {
			if (fill_style != 0) VSetFillStyle(meter_area, (fill_style = 0));
		}
		exp_color = (mpd[r]->expr[chan] >> 3) + 1;
		if (setting_meter_color == 3) exp_color = 17 - exp_color;
		VSetColor(meter_area, exp_color);
		w = mpd[r]->count[chan] * 125;
		if (w < 125) w = 125;
		else if (w > 500) w = 500;
		x1 = 80 + (500 - w)/2 + chan * (10000/NUM_CHANS);
		y1 = 10000 - vol * (10000/128);
		h = 10000 - y1;
		VFillRectangle(meter_area, x1, y1, w, h);
	}
	xv_set(meter_shell, CANVAS_SHELL_DELAY_REPAINT, FALSE, NULL);
}

#define TUNE_UP_COLORS

#ifdef TUNE_UP_COLORS
static void
show_meter_bars()
{
	int chan, w, x1, y1, h;

	for (chan = 0; chan < NUM_CHANS; chan++) {
		VSetColor(meter_area, chan+1);
		w = 500;
		x1 = 80 + (500 - w)/2 + chan * (10000/NUM_CHANS);
		y1 = 0;
		h = 10000 - y1;
		VFillRectangle(meter_area, x1, y1, w, h);
	}
}
#endif

static void
setup_meter()
{
	Server_image stipple_image;

#ifdef USE_SHM
	setup_shm();
#else
	int i;
	talk_in = (int *)malloc(sizeof(int));
	talk_out = (int *)malloc(sizeof(int));
	mpd = (struct mp_talk **)malloc( (RINGSIZE+1)*sizeof(struct mp_talk *) );
	for (i = 0; i < RINGSIZE+1; i++)
		mpd[i] = (struct mp_talk *)malloc( sizeof(struct mp_talk) );
#endif

	stipple_image = (Server_image) xv_create(XV_NULL, SERVER_IMAGE,
		XV_WIDTH, stipple_width,
		XV_HEIGHT, stipple_height,
		SERVER_IMAGE_X_BITS, stipple_bits,
		NULL);

	meter_cms = (Cms) xv_create(XV_NULL, CMS,
		CMS_SIZE, 17,
		CMS_NAMED_COLORS, "black",
			"cyan2",
			"turquoise2",
			"aquamarine2",
			"spring green",
			"green",
			"chartreuse",
			"green yellow",
			"DarkOliveGreen1",
			"yellow",
			"LightGoldenrod1",
			"gold",
			"DarkGoldenrod1",
			"orange",
			"dark orange",
			"DarkOrange1",
			"red",
			NULL,
		NULL);
	meter_area = (Drawarea)xv_create(XV_NULL, DRAWAREA, NULL);
	meter_frame = (Frame)xv_create(frame, FRAME,
		XV_X,		420-150-30,
		XV_Y,		50+80,
		XV_WIDTH,	180,
		XV_HEIGHT,	100,
		FRAME_LABEL,	"meter",
		NULL);
	meter_shell = (Canvas_shell)xv_create(meter_frame, CANVAS_SHELL,
		WIN_CMS, meter_cms,
		CANVAS_RESIZE_PROC, meter_resize,
		NULL);
	xv_set(meter_shell, CANVAS_SHELL_BATCH_REPAINT, TRUE, NULL);
	xv_set(meter_area,
		XV_OWNER, meter_shell,
		XV_WIDTH, xv_get(meter_shell, XV_WIDTH),
		XV_HEIGHT, xv_get(meter_shell, XV_HEIGHT),
		NULL);
        VSetStipple(meter_area, stipple_image);
#ifdef TUNE_UP_COLORS
	show_meter_bars();
#endif
}

#ifndef USE_SHM
static int pipe_fd;
#endif

static void read_one_packet()
{
#ifdef USE_SHM
	if (!midi_file_playing)
		*talk_in = *talk_out = 0;
	if (*talk_in < 1) return;
	if (xmp_epoch < 0) {
		time_sync();
		xmp_epoch += mpd[0]->mptime;
		time_expired += mpd[0]->mptime;
	}
	if ((xmp_time % 6) < 3 && midi_file_playing == TRUE) {
		xv_set(dot_play_button, PANEL_ITEM_COLOR, MAIN_COLOR_RED, NULL);
	}
	midi_file_playing = 2;
#else
	int i, r, n;

	if (total_packets < sizeof(struct mp_talk)) return;

	if (xmp_epoch < 0) {
		*talk_in = *talk_out = 0;
	}

	r = *talk_in % RINGSIZE;

	if ((i = read(pipe_fd, mpd[r]->count, sizeof(mpd[r]->count))) > 0) {
		total_packets -= i;
	}
	if ((i = read(pipe_fd, mpd[r]->vel, sizeof(mpd[r]->vel))) > 0) {
		total_packets -= i;
	}
	if ((i = read(pipe_fd, &mpd[r]->mptime, sizeof(mpd[r]->mptime))) > 0) {
		total_packets -= i;
	}
	if ((i = read(pipe_fd, mpd[r]->expr, sizeof(mpd[r]->expr))) > 0) {
		total_packets -= i;
	}
	for (n = 0; n < NUM_CHANS; n++) if (mpd[r]->expr[n] < 0) {
		mpd[r]->expr[n] = (setting_meter_color == 3)? 0 : 64;
	}
	if (*talk_in - *talk_out < RINGSIZE - 2) (*talk_in)++;
	if (xmp_epoch < 0) {
		time_sync();
		xmp_epoch += mpd[r]->mptime;
		time_expired += mpd[r]->mptime;
	}
#endif
}

#ifndef USE_SHM
static Notify_value read_mplayer(Notify_client me, int fd)
{
	int bytes;

	pipe_fd = fd;

	if (ioctl(fd, FIONREAD, &bytes) == 0) {
		total_packets = bytes;
	}
	read_one_packet();
	if ((xmp_time % 6) < 3 && midi_file_playing == TRUE) {
		xv_set(dot_play_button, PANEL_ITEM_COLOR, MAIN_COLOR_RED, NULL);
	}
	midi_file_playing = 2;
	return(NOTIFY_DONE);
}
#endif

static void
file_action_proc(Menu menu, Menu_item mi)
{
	char *fname, *path;

	fname = (char *)xv_get(mi, MENU_STRING);
	path = (char *)xv_get(mi, MENU_CLIENT_DATA);

	if (carousel_visible) {
		int last = xv_get(carousel_list, PANEL_LIST_NROWS);
		xv_set(carousel_list,
			PANEL_LIST_INSERT, last,
			PANEL_LIST_STRING, last, fname,
			PANEL_LIST_CLIENT_DATA, last, strcpy(malloc(strlen(path)+1), path),
			NULL);
		if (!midi_file_playing && carousel_auto) midi_file_selected = FALSE;
		return;
	}
	if (midi_file_playing) return;

	(void)crsltoplay(fname, path);
}

char *
getfilename(char *path)
{
	char *p;
#ifndef TRY_REAL_FILENAME
	char *q;
	int i, len, spccount = 0;
#endif
	if ((p = rindex(path, '/'))) p++;
	else p = path;
#ifdef TRY_REAL_FILENAME
	return(strcpy(malloc(strlen(p)+1), p));
#else
	len = strlen(p);
	for (i = 1; i < len; i++)
		if (isupper(p[i])) spccount++;
	len += spccount;
	q = strcpy(malloc(len+1), p);
	while (spccount && len > 1) {
		q[len] = q[len-spccount];
		if (isupper(q[len])) {
			q[len-spccount] = ' ';
			spccount--;
		}
		len--;
	}
	return(q);
#endif
}

Menu
gen_pullright(Menu_item mi, Menu_generate op)
{
	Menu menu;
	Menu_item new;
	char buf[MAXPATHLEN];
	static Menu_item add_path_to_menu();

	if (op == MENU_DISPLAY) {
		menu = (Menu)xv_get(mi, XV_OWNER);
		sprintf(buf, "%s/%s",
			(char *)xv_get(menu, MENU_CLIENT_DATA),
			(char *)xv_get(mi, MENU_CLIENT_DATA));
		if ((menu = (Menu)xv_get(mi, MENU_PULLRIGHT))) {
			free((char *)xv_get(menu, MENU_CLIENT_DATA));
			xv_destroy(menu);
		}
		if ((new = add_path_to_menu(buf)) != XV_NULL) {
			menu = (Menu)xv_get(new, MENU_PULLRIGHT);
			free((char *)xv_get(new, MENU_CLIENT_DATA));
			xv_destroy(new);
			return(menu);
		}
	}
	if (!(menu = (Menu)xv_get(mi, MENU_PULLRIGHT)))
		menu = (Menu)xv_create(
			XV_NULL,
			MENU,
			MENU_COLOR,	MAIN_COLOR_RED,
			MENU_STRINGS, "Couldn't build a menu.", NULL,
			NULL);
	return(menu);
}

static
Menu_item
add_path_to_menu(char *path)
{
	DIR *dirp;
	struct direct *dp;
	struct stat s_buf;
	Menu_item mi;
	Menu next_menu;
	char buf[MAXPATHLEN];
	char *pathname;
	static int recursion = 0;

	if (stat(path, &s_buf) == -1 || !(s_buf.st_mode & S_IREAD)) return(XV_NULL);

	if (s_buf.st_mode & S_IFDIR) {
		int cnt = 0;
		if (!((dirp = opendir(path)))) return(XV_NULL);
		if (recursion) {
			closedir(dirp);
			return((Menu_item)-1);
		}
		recursion++;
		next_menu = (Menu)xv_create(XV_NULL, MENU, NULL);
		while ((dp = readdir(dirp)))
			if (strcmp(dp->d_name, ".") && strcmp(dp->d_name, "..")) {
				(void)sprintf(buf, "%s/%s", path, dp->d_name);
				mi = add_path_to_menu(buf);
				if (mi == XV_NULL || mi == (Menu_item)-1) {
					int do_gen_pullright =
						(mi == (Menu_item)-1);
					pathname = strcpy(malloc(
						strlen(dp->d_name)+1), dp->d_name);
					mi = (Menu_item)xv_create(next_menu,
						MENUITEM,
						MENU_STRING, getfilename(dp->d_name),
						MENU_CLIENT_DATA, pathname,
						MENU_RELEASE,
						MENU_RELEASE_IMAGE,
						NULL);
					if (do_gen_pullright) xv_set(mi,
						MENU_GEN_PULLRIGHT, gen_pullright,
						NULL);
					else xv_set(mi, MENU_INACTIVE, TRUE, NULL);
				}
				xv_set(next_menu, MENU_APPEND_ITEM, mi, NULL);
				cnt++;
			}
		closedir(dirp);
		pathname = strcpy(malloc(strlen(path)+1), path);
		mi = (Menu_item)xv_create(
			XV_NULL,
			MENUITEM,
			MENU_STRING, getfilename(path),
			MENU_CLIENT_DATA, pathname,
			MENU_RELEASE,
			MENU_RELEASE_IMAGE,
			MENU_NOTIFY_PROC, file_action_proc,
			NULL);
		if (!cnt) {
			xv_destroy(next_menu);
			xv_set(mi, MENU_INACTIVE, TRUE, NULL);
		}
		else {
			xv_set(next_menu,
				MENU_TITLE_ITEM, strcpy(malloc(strlen(path)+1), path),
				MENU_CLIENT_DATA, strcpy(malloc(strlen(path)+1), path),
				NULL);
			xv_set(mi, MENU_PULLRIGHT, next_menu, NULL);
		}
		recursion--;
		return(mi);
	}
	pathname = strcpy(malloc(strlen(path)+1), path);
	return((Menu_item)xv_create(
		XV_NULL,
		MENUITEM,
		MENU_STRING, getfilename(path),
		MENU_CLIENT_DATA, pathname,
		MENU_RELEASE,
		MENU_RELEASE_IMAGE,
		MENU_NOTIFY_PROC, file_action_proc,
		NULL)
	);
}



/****************************************************************************
* Variables set by command line switches
****************************************************************************/

int ad_print = false;		/* adagio output */
int vverbose = false;		/* tracing output */


/****************************************************************************
*	Routines in phasem.c
****************************************************************************/
void var_init();
void initfuncs();
void rec_init();
void card_init();
event_type rec_final();
/*************************/

#define READ_WHOLE

/* part of interface to midifile functions */
#ifdef READ_WHOLE
static unsigned char *midi_file_contents;
static int midi_file_size;

static int filegetc()
{
    if (midi_file_size-- > 0) return (*midi_file_contents++);
    return(EOF);
}
#else
static FILE *F;
static int filegetc()
{
    return (getc(F));
}
#endif

void txt_error(char *s)
{
    fprintf(stderr, "midifile error: %s\n", s);
    _exit(0);
}

static
int do_midi(char *midi_name)
{
#ifdef READ_WHOLE
    struct stat statbuf;
    int fd;

    if (stat(midi_name, &statbuf)) {
	perror(midi_name);
	_exit(0);
    }
    midi_file_size = statbuf.st_size;
    if ( (fd = open(midi_name, O_RDONLY, 0)) == -1 ) {
	perror(midi_name);
	_exit(0);
    }
    if ( (midi_file_contents = (char *)malloc(midi_file_size)) == NULL) {
	perror("malloc");
	_exit(0);
    }
    if (read(fd, midi_file_contents, midi_file_size) != midi_file_size) {
	perror("read");
	_exit(0);
    }
    close(fd);
#endif

    var_init();
    no_solo = req_no_solo;
    piano_only = req_piano_only;
#ifndef READ_WHOLE
    F = fopen(midi_name, "r");
#endif
    card_init();		/* open /dev/sequencer and get info on devices */
    rec_init();
    initfuncs();		/* set calls to us from midifile functions */
    Mf_getc = filegetc;		/* tell midifile how to get bytes to process */
    mfread();			/* call midifile */
#ifdef READ_WHOLE
    free(midi_file_contents);
#else
    fclose(F);
#endif
    phase2((rec_final(true)));
    return(0);
}
