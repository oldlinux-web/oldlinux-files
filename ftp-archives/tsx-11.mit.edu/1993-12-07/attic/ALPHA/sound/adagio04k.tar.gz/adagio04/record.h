boolean rec_init();
boolean rec_poll();
void rec_final();
