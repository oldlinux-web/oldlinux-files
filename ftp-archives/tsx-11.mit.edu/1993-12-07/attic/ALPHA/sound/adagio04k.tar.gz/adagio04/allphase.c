#include <stdio.h>
#include "adagio.h"
#include "allphase.h"

/* Change default settings here: */
int piano_only = false;		/* change all instruments to piano ? */
int exclude_fm = false;		/* don't use fm card? */
int exclude_gus = false;	/* don't use GUS? */
int extflag = true;		/* use external synth? */
int percsel = PSELECT;		/* which channels are for percussion? */
int no_solo = false;		/* treal all instruments as polyphonic? */
int setting_chorus = true;	/* use midi chorus depth controller? */
int setting_pstereo = true;	/* add pseudo-stereo effect? */
int setting_4op_mode = true;	/* use 4 operator fm in preference to 2 operator? */
int setting_gus_tuning = -500;	/* -1000 to +1000 */
int setting_gus_volume = 60;	/* 0 to 100 */
int setting_gus_voices = 32;	/* 14 to 32 */
int setting_meter_color = 0;	/* 0=expression, 1=volume, 2=chorus depth,
				   3=reverberation, 4=stereo pan */
int setting_meter_column = 0;	/* 0=channel, 1=pitch, 2=instrument (GM group) */
int setting_reverb = 25;	/* 0=none, 0 to 100 */
int setting_chorus_spread = 25;	/* 0 to 100 */
int setting_vibrato_depth = 50;	/* 0 to 100 */

/* set by command line flags */
int verbose = false;
int recording_track = false;

/* for xmp meter: */
unsigned char curr_note_count[NUM_CHANS];
unsigned short curr_note_velocity[NUM_CHANS];

int program[NUM_CHANS] =
{NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI,
 NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI};
int ext_program[NUM_CHANS] =
{NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI,
 NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI, NO_VOI};
int ext_chan[NUM_CHANS] =
{0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0};
int ext_poly[NUM_CHANS] =
{0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0};
int ext_pan[NUM_CHANS] =
{-1, -1, -1, -1, -1, -1, -1, -1,
 -1, -1, -1, -1, -1, -1, -1, -1};
int chorus_depth[NUM_CHANS] =
{0, 0, 0, 0, 0, 0, 0, 0,
 0, 0, 0, 0, 0, 0, 0, 0};
unsigned char *sysex[NUM_CHANS] =
{NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
 NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL};

int ext_polyphony = 0;
int seq_fd = -1;
struct synth_info card_info[MAXCARDS];
int gus_dev = -1, sb_dev = -1, ext_dev = -1, ext_index = -1;
int nrsynths = 0;
int nrmidis = 0;


/* current values of some midi channel controllers */
int main_volume[NUM_CHANS] =
{NORMAL_VOLUME, NORMAL_VOLUME, NORMAL_VOLUME, NORMAL_VOLUME,
 NORMAL_VOLUME, NORMAL_VOLUME, NORMAL_VOLUME, NORMAL_VOLUME,
 NORMAL_VOLUME, NORMAL_VOLUME, NORMAL_VOLUME, NORMAL_VOLUME,
 NORMAL_VOLUME, NORMAL_VOLUME, NORMAL_VOLUME, NORMAL_VOLUME};

int expression[NUM_CHANS] =
{NORMAL_EXPR, NORMAL_EXPR, NORMAL_EXPR, NORMAL_EXPR,
 NORMAL_EXPR, NORMAL_EXPR, NORMAL_EXPR, NORMAL_EXPR,
 NORMAL_EXPR, NORMAL_EXPR, NORMAL_EXPR, NORMAL_EXPR,
 NORMAL_EXPR, NORMAL_EXPR, NORMAL_EXPR, NORMAL_EXPR};

int reverberation[NUM_CHANS] =
{-1, -1, -1, -1, -1, -1, -1, -1,
 -1, -1, -1, -1, -1, -1, -1, -1};

