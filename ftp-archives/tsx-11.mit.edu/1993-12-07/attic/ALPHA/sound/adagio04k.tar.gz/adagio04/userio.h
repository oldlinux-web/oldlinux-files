int askbool();
FILE *fileopen();
void readln();
