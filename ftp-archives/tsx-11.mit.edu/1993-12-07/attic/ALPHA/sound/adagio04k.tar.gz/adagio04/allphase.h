
#include <sys/soundcard.h>

/* MAXCARDS must be at least one greater than nrsynths as returned by driver */
#define MAXCARDS 3
/* MAXCELLS is the maximum note polyphony available on any synth */
#define MAXCELLS 32

extern int seq_fd, nrsynths, nrmidis, gus_dev, sb_dev, ext_dev, ext_index;
extern struct synth_info card_info[MAXCARDS];
extern int ext_polyphony;
extern int extflag;
extern int piano_only; /* ignore voice requests */
extern int exclude_fm;
extern int exclude_gus;
extern int verbose;
extern int recording_track;
extern int percsel;
extern int no_solo;
extern int setting_chorus;
extern int setting_pstereo;
extern int setting_4op_mode;
extern int setting_gus_tuning;
extern int setting_gus_volume;
extern int setting_gus_voices;
extern int setting_reverb;
extern int setting_chorus_spread;
extern int setting_vibrato_depth;

/* for xmp meter: */
extern int setting_meter_color;
extern int setting_meter_column;
extern unsigned char curr_note_count[NUM_CHANS];
extern unsigned short curr_note_velocity[NUM_CHANS];

extern int program[NUM_CHANS];
extern int ext_program[NUM_CHANS];
extern int ext_chan[NUM_CHANS];
extern int ext_poly[NUM_CHANS];
extern int chorus_depth[NUM_CHANS];
extern int ext_pan[NUM_CHANS];
extern unsigned char *sysex[NUM_CHANS];

#ifndef XMAXCHAN
#define XMAXCHAN 16
#endif

#define NO_VOI -1

extern struct gus_type {
	char *vname;
	int mem_req;
	unsigned char lowest;
	unsigned char highest;
	unsigned char sustain;
	unsigned char loaded;
	unsigned char rscale, rrate, rtop, rbot, rampmode;
	unsigned char volume;
} gus_voice[];

/* default values for main volume and expression controllers for the sake of
 * midi files which do not have those controls (90 is supposed to be normal
 * main volume, but this just seems too low to me): */
#define NORMAL_VOLUME 120
#define NORMAL_EXPR 120

extern int main_volume[NUM_CHANS];
extern int expression[NUM_CHANS];
extern int reverberation[NUM_CHANS];

