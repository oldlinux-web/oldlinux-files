/* phase2.c -- this module plays notes compiled and sorted in phase1 or phasem */

/* There are 3 layers of routines here: (1) phase1 with various initialization
 * functions and the play_score routine that it calls, (2) f_note and other "f_"
 * functions called by play_score, which direct the information flow either to
 * stdout, to the external port, or to (3) fm_note and other "fm_" functions which
 * play the sound cards (including the gus, though it is not an fm device).
 */
/* (following for testing gus volume calculation) */
/* #define USE_OWN_GUS_VOL */

/* The following defines are configurable options.  Probably, they don't need to
 * be changed.
 */

/* don't use running status for external midi out: */
#define NO_RUNNING_STATUS

/* restart midi output when this number events in queue (I have problems
 * keeping output going to the external port -- I'm not sure this low
 * value of 32 (max 512) really helps, but sometimes it has seemed to): */
#define WAKETHRESH 32

/* double notes with pitch bend for chorus depth: */
#define TRY_CHORUS

/* insert echo notes for non-percussion fm voices according to value of
 * controller #91: */
#define TRY_ECHO_REVERB

/* always reload fm voices to the driver from std and drums libraries: */
#define RELOAD_FM

/* use cute stereo effects: */
#define PSEUDO_STEREO

/* display info about noteon/off and records of dynamic voice allocation: */
/* #define END_DIAGNOSTICS */

/* pitch vibrato for selected voices (see vibrato.h) */
#define TRY_VIBRATO


#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>
#include <malloc.h>
#include <fcntl.h>
#include <string.h>
#include "adagio.h"
#ifndef XMP
#include "userio.h"
#include "cmdline.h"
#endif
#include "pitch.h"
#include "allphase.h"
#include "midicode.h"
#include "midi.h"
#define NO_LC_DEFINES
#include "midifile.h"
#include "sblast.h"
#include "drum.h"

#ifdef XMP
#define STOPNOW _exit(0)
#else
#define STOPNOW exit(-1)
#endif

/* nominal very long ending time for songs, in centiseconds */
#define MAXTIME 10000000

#ifndef XMP
/* business for using functions in cmdline.c */
#define n_t_sw 2
static char *t_switches[n_t_sw] =
{"-t", "-trace"};
#define n_m_sw 2
static char *m_switches[n_m_sw] =
{"-m", "-midi"};
#define nmsw 2
static char *msw[nmsw] =
{"-i", "-init"};
#endif

#ifdef USE_SHM
extern int *shm_setting_pstereo;
extern int *shm_setting_gus_tuning;
extern int *shm_setting_gus_volume;
extern int *shm_setting_meter_color;
extern int *shm_setting_reverb;
extern int *shm_setting_chorus_spread;
extern int *shm_setting_vibrato_depth;
#endif

/* variables set by command line options */
static int initflag = false;
static int v_drum = true;	/* currently always true */
static int use_damper = false;	/* currently always false */
static int recording_channel = 1;
static int recording_program = 0;
static int readable = false;	/* tracing output */
static int local_extflag;

/* keeping time (in centiseconds) */
static unsigned long time = 0;		/* playing time clock */
static unsigned long sb_time = 0;	/* recording time clock */
static unsigned long lasttime = 0;	/* recording time */

/* this is updated by low-level routines and consulted by
 * play_score to see if it is currently feasible to play extra
 * notes for reverberation or chorusing effects
 */
static int spare_cells[MAXCARDS];

/* records for optional diagnostic display at end of playing */
static int stat_imp_cell_off[MAXCARDS];
static int stat_note_on[MAXCARDS];
static int stat_note_off[MAXCARDS];
#ifdef USE_OWN_GUS_VOL
static int gus_clip_statistic = 0;
#endif

unsigned char inst_note_count[NUM_CHANS];
unsigned short inst_note_velocity[NUM_CHANS];

static int user_scale = false;	/* true if user-defined scale */
static int bend[NUM_CHANS];	/* current pitch bend on channel */
static pitch_table pit_tab[128];/* scale definition */

static char playing_music = true;


/****************************************************************************
* Routines local to this module
****************************************************************************/
/* (this list is only high-level routines) */
static void off_init();
#ifndef XMP
static void tuninginit();
static void read_tuning();
#endif
static int note_offs();
static void off_schedule();
static void f_note();
static void f_touch();
static void f_program();
static void f_ctrl();
static void f_bend();



/* Records resulting from reading the fm patch libraries during
 * initialization.
 */

/* do fm patch libraries have any 4op patches which require us
 * to ask driver for 4op mode? (reduces polyphony from 18 to 6!)
 */
static int need_4op_mode = false;
/* which individual fm patches are 2op, and which are 4op? */
static int instr_key[256];
/* transposition requests in fm patches */
static int sb_trnsps[256];
/* durations for percussion notes in fm patches */
static int d_dur[256];
/* which note to actually play for fm percussion? */
static int dnote[256];
#ifdef XVOICE
/* voices to use for doubling notes requested in fm patches */
static int xvoice[256];
#endif

/* miscelleneous low-level forward declarations */
static void midisync(void);
static void fm_program(int, int, int, int);
static void fm_ctrl(int, int, int, int, int);
static void fm_bend(int, int, int);
static void card_touch_all(int, int, int);
static void fm_noteon(int, int, int, int, int, int, unsigned long);
static void fm_noteoff(int, int, int, int, int, int, int, unsigned long);
static int new_cell(int, unsigned long, int, int, int, int, int, int);
#ifdef TRY_VIBRATO
static void fm_vibrate(int, unsigned long);
#endif
#ifdef MIDIIN
static void listen();
static int midigetc(void);
static int midipending(void);
static void midimessage();
static int midi_is_open_for_input = false;
#endif

/* buffered output to /dev/sequencer */
#define SBOUTCHUNK 128
static unsigned char sbbuf[SBOUTCHUNK + 8];
static char buf[8];
static int sbptr = 0;

/*
 * Flush output to /dev/sequencer.  This is rather complicated, considering
 * how poorly it works.  The idea is to monitor the output queue to avoid
 * filling it completely and, if it doesn't seem to be emptying properly,
 * to take some corrective action.  However, there is not necessarily anything
 * wrong with filling up the output queue (there was, at one point in the
 * development of the driver), and if in fact it is not emptying, there
 * really isn't anything constructive to do about it, that I know of.  You
 * see how confused I am?
 * Anyhow, the next two defines are for how many times when the queue is
 * checked it may remain unchanged before we decide that it is just stuck
 * and is never going to empty, then how much free room we maintain in
 * the queue.
 */
#define SBMONWAIT 20
#define OUTQSP 128

void sbflush(void)
{
    int room, lastroom = 0;
    int count = SBMONWAIT;

    /* nothing in the buffer? */
    if (!sbptr) return;

    /* Temporize, so long as writing the buffer to /dev/sequencer would result in less than
     * OUTQSP 4-byte events free room in the queue. (Unless we get desperate.)
     */
    while ((ioctl(seq_fd, SNDCTL_SEQ_GETOUTCOUNT, &room) != -1) && (room - (sbptr / 4) < OUTQSP)) {
	/* just starting the count? if so, note how much room there is */
	if (count == SBMONWAIT) lastroom = room;

	usleep(100000);

	/* timeout?  if so, maybe there is a problem */
	if (count-- == 0) {

	    /* it's ok when progress has been made, so restart the count */
	    if (room > lastroom) count = SBMONWAIT;

	    /* if we cannot write without overrunning the queue, give up */
	    else if (room < sbptr / 4) {
		fprintf(stderr,"problem with output queue ... only %d room at t=%d\n", room, time);
		(void) ioctl(seq_fd, SNDCTL_SEQ_RESET, 0);
		STOPNOW;
		time = sb_time = 0;
		break;
	    /* here, we are not able to maintain the free space in the queue
	     * that we wanted to, but at least there is room to hold what we
	     * want to output, so we'll write it out anyway
	     */
	    } else
		break;
	}
#ifdef MIDIIN
	/* while waiting for output, get any stuff pending from the midi
	 * input port
	 */
	listen();
#endif
    }

    /* now flush the buffer */
    if (write(seq_fd, sbbuf, sbptr) == -1) {
	perror("write /dev/sequencer");
	STOPNOW;
    }
    sbptr = 0;
}

/* write an 8-byte event to the output buffer */
void sqwrite(char *msg)
{
    if (sbptr + 8 >= SBOUTCHUNK)
	sbflush();
    memcpy(&sbbuf[sbptr], msg, 8);
    sbptr += 8;
}
/* write a 4-byte event to the output buffer */
void sbwrite(char *msg)
{
    if (sbptr + 4 >= SBOUTCHUNK)
	sbflush();

    memcpy(&sbbuf[sbptr], msg, 4);
    sbptr += 4;
}
/* reset driver's idea of now to now (do this just
 * before starting to play)
 */
void sb_resync()
{
    buf[0] = SEQ_SYNCTIMER;
    sbwrite(buf);
    sbflush();
    time = sb_time = lasttime = 0;
    midisync();
}
/* one 7-bit byte to the external midi port */
void midich(char c)
{
    /* if the 8th bit is set, there is an error somewhere */
    if (c < 0) fprintf(stderr, "error in midich: 0x%02x??\n", c);

    buf[0] = SEQ_MIDIPUTC;
    buf[1] = c;
    buf[2] = ext_dev;
    buf[3] = 0;
    sbwrite(buf);
}
/* one 8-bit byte to the external midi port */
void midicmdch(char c)
{
#ifndef NO_RUNNING_STATUS
    static char lastcmd = 0;
    if (c == lastcmd)
	return;
    lastcmd = c;
#endif
    /* if the 8th bit is not set, that's a problem */
    if (c > 0) fprintf(stderr, "error in midicmdch: 0x%02x??\n", c);
    buf[0] = SEQ_MIDIPUTC;
    buf[1] = c;
    buf[2] = ext_dev;
    buf[3] = 0;
    sbwrite(buf);
}

#ifdef MIDIIN
/* non-blocking input of one byte from the external midi port */
int inonenb()
{
    if (!midipending()) {
	usleep(100000);
	if (!midipending()) {
	    usleep(1000000);
	    if (!midipending()) {
		usleep(1000000);
		if (!midipending())
		    return (-1);
	    }
	}
    }
    return ((midigetc() & 0xff));
}
#endif

/* reference to array in vname.h containing GM names of
 * instruments and various other info about them
 */
extern struct sub_type {
    char *vname;
    char solo;
    char newv;
    char transpose;
}
sub_voice[];


#ifdef K1
/* form of a multi patch on the Kawai K1 */
  struct patch_multi {
      char name[10];
      char volume;
      char single[8];
      char zonelow[8];
      char zonehigh[8];
      char poly[8];
      char rcvchan[8];
      char transpose[8];
      char tune[8];
      char level[8];
      char checksum;
  }
kmpatch = {
    {
	'M', 'i', 's', 'c', ' ', ' ', ' ', ' ', ' ', ' '
    }
    ,
    99,
    {
	0, 1, 2, 3, 4, 5, 6, 7
    }
    ,
    {
	0, 0, 0, 0, 0, 0, 0, 0
    }
    ,
    {
	127, 127, 127, 127, 127, 127, 127, 127
    }
    ,
    {
	0x10, 0x50, 0x50, 0x50, 0x50, 0x50, 0x50, 0x50
    }
    ,
    {
	0x40, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07
    }
    ,
    {
	24, 24, 24, 24, 24, 24, 24, 24
    }
    ,
    {
	50, 50, 50, 50, 50, 50, 50, 50
    }
    ,
    {
	100, 100, 100, 100, 100, 100, 100, 100
    }
    ,
    0x74
};

/* send intro to K1 sysex command */
void k1send1(int function, int voice)
{
    midicmdch(0xf0);
    midich(0x40);		/* Kawai id */
    midich(0x00);		/* channel = 0 to 15 */
    midich(function);		/* function */
    midich(0x00);		/* group */
    midich(0x03);		/* machine id number of K1 */
    midich(0x00);		/* subcommand 1 = internal */
    midich(voice);		/* subcommand 2 = voice/program */
}

/* byte to K1 and update checksum */
void mchk(int c)
{
    midich(c);
    kmpatch.checksum += c & 0x7f;
}

/* k1msone - send a single voice to the K1 */
void k1msone(iv)
int iv;
{
    int n;

    k1send1(0x20, iv);
    kmpatch.checksum = 0xa5;

    for (n = 0; n < 10; n++)
	mchk(kmpatch.name[n]);
    mchk(kmpatch.volume);
    for (n = 0; n < 8; n++)
	mchk(kmpatch.single[n]);
    for (n = 0; n < 8; n++)
	mchk(kmpatch.zonelow[n]);
    for (n = 0; n < 8; n++)
	mchk(kmpatch.zonehigh[n]);
    for (n = 0; n < 8; n++)
	mchk(kmpatch.poly[n]);
    for (n = 0; n < 8; n++)
	mchk(kmpatch.rcvchan[n]);
    for (n = 0; n < 8; n++)
	mchk(kmpatch.transpose[n]);
    for (n = 0; n < 8; n++)
	mchk(kmpatch.tune[n]);
    for (n = 0; n < 8; n++)
	mchk(kmpatch.level[n]);
    midich(kmpatch.checksum & 0x7f);
    if (readable)
	printf("checksum = 0x%02x\n", kmpatch.checksum & 0x7f);
    midicmdch(MIDI_EOX);

}

/* dk1msone - show what is sent to the K1, for debugging */
void dk1msone(int iv)
{
    int n;

    printf("kmpatch%d [] = {\n\t", iv);
    for (n = 0; n < 10; n++)
	printf("'%c'[%d],", kmpatch.name[n], kmpatch.name[n]);
    printf("\n\t%d,\n\t", kmpatch.volume);
    for (n = 0; n < 8; n++)
	printf("%d,", kmpatch.single[n]);
    printf("\n\t");
    for (n = 0; n < 8; n++)
	printf("%d,", kmpatch.zonelow[n]);
    printf("\n\t");
    for (n = 0; n < 8; n++)
	printf("%d,", kmpatch.zonehigh[n]);
    printf("\n\t");
    for (n = 0; n < 8; n++)
	printf("0x%02x,", kmpatch.poly[n]);
    printf("\n\t");
    for (n = 0; n < 8; n++)
	printf("0x%02x,", kmpatch.rcvchan[n]);
    printf("\n\t");
    for (n = 0; n < 8; n++)
	printf("%d,", kmpatch.transpose[n]);
    printf("\n\t");
    for (n = 0; n < 8; n++)
	printf("%d,", kmpatch.tune[n]);
    printf("\n\t");
    for (n = 0; n < 8; n++)
	printf("%d,", kmpatch.level[n]);
    printf("\n}\n");

}
#endif

/* routines called by phase2 */
static void crd_init();
static void cells_init();
static void lib_init();
static void voices_init();
static void channel_init();
static void play_score();

/* The pointer to the note list has to be passed indirectly from
 * phase1 to play_score, because the latter is called from inside
 * the midifile library when recording a track.
 */
static event_type the_score;
/* next two routines are called from inside midifile library */
FILE *fp;
int myputc(int c)
{
    return (putc(c, fp));
}

int mywritetrack(int track)
{
    play_score();
    return (1);
}



/****************************************************************************
*				    phase2
* Inputs:
*	event_type root: Root of play list
* Effect:
*	Plays the music
****************************************************************************/

void phase2(score)
event_type score;
{
#ifdef XMP
    char *recording_parms = "";
#else
    char *recording_parms = cl_option("-r");

    readable = (cl_nswitch(t_switches, n_t_sw) != NULL);
    playing_music = (cl_nswitch(m_switches, n_m_sw) == NULL);
    initflag = (cl_nswitch(msw, nmsw) == NULL);
#endif
    local_extflag = extflag;
    if (ext_dev < 0 || !playing_music) local_extflag = false;
    if (local_extflag) playing_music = true;
    if (readable) playing_music = false;

    if (recording_track) {
	int i;
	recording_channel = atoi(recording_parms);
	for (i = 0; recording_parms[i] != '\0' && recording_parms[i] != ','; i++);
	if (recording_parms[i] == ',')
	    recording_program =
		atoi(recording_parms + i + 1);
	if (verbose)
	    printf("recording program %d!\n", recording_program);
	if (recording_channel < 1 || recording_channel > 16)
	    recording_channel = 1;
	if (recording_program < 0 || recording_program > 127)
	    recording_program = 0;
	if (verbose)
	    printf("recording program is #%d\n", recording_program);
    }

    off_init();				/* allocate some off-event structures */
#ifndef XMP
    tuninginit();			/* process any user tuning file */
#endif
    if (playing_music) cells_init();	/* mark up dynamically allocated voices */
    if (playing_music) lib_init();	/* consult std.* and drums.* fm patch libraries */
    voices_init();			/* K1 initialization and verbose display of
					 *  what voices are on what channels
					 */
    if (playing_music) crd_init();	/* init gus and fm cards */

    channel_init();			/* initialize midi controllers and pitch bend */
    the_score = score;			/* pass note list to play_score */

    /* To start playing, either pass call-backs to midifile library,
     * or if not recording a track, call play_score directly.
     */
    if (recording_track) {
	Mf_putc = myputc;
	Mf_writetrack = mywritetrack;
	if ((fp = fopen("mpout.mid", "w")) == 0L) STOPNOW;
	mfwrite(0, 1, Mf_division, fp);
    } else
	play_score();

    /* display final diagnostic report */
    if (verbose) {
#ifdef END_DIAGNOSTICS
	void hist_report();
#endif
	printf("\n");
	if (sb_dev >= 0)
	    printf("%d sb notes terminated due to conflicts.\n", stat_imp_cell_off[sb_dev]);
	if (gus_dev >= 0)
	    printf("%d gus notes terminated due to conflicts.\n", stat_imp_cell_off[gus_dev]);
#ifdef XPOLYPHONY
	if (ext_dev >= 0)
	    printf("%d ext notes terminated due to conflicts.\n", stat_imp_cell_off[ext_index]);
#endif
#ifdef END_DIAGNOSTICS
	printf("Notes on:  gus %d  sb %d  ext %d\n", stat_note_on[0],
	       stat_note_on[1], stat_note_on[2]);
	printf("Notes off: gus %d  sb %d  ext %d\n", stat_note_off[0],
	       stat_note_off[1], stat_note_off[2]);
	hist_report();
#endif
#ifdef USE_OWN_GUS_VOL
	printf("gus clips: %d\n", gus_clip_statistic);
#endif
    }
    (void) ioctl(seq_fd, SNDCTL_SEQ_RESET, 0);
    close(seq_fd);
}


/*
 * Initialize gus and fm cards and note info about
 * cells (i.e, dynamically allocated voices).
 */
void crd_init()
{
    int n;
    void gus_max_voices(int);

    /* 24 max voices is the default, but current 1.99.3 driver does not
     * report it correctly.  We have to set the number here, instead of
     * earlier in cardinit() called from admp.c, since /dev/sequencer
     * may have been closed and reopened since then.
     */
    if (gus_dev >= 0) {
	gus_max_voices(setting_gus_voices);
	card_info[gus_dev].nr_voices = setting_gus_voices;
	spare_cells[gus_dev] = card_info[gus_dev].nr_voices;
    }

    if (sb_dev >= 0) {
	spare_cells[sb_dev] = card_info[sb_dev].nr_voices;
    }

    if (ext_dev >= 0) {
	card_info[ext_index].nr_voices =
	spare_cells[ext_index] =
#ifdef XPOLYPHONY
		XPOLYPHONY;
#else
		0;
#endif
    }

    /* If any 4op patch was loaded to the driver from one of the fm
     * patch libraries, we must ask for 4op mode.
     */
    if ((n = sb_dev) >= 0 && need_4op_mode) {
	ioctl(seq_fd, SNDCTL_FM_4OP_ENABLE, &n);
	if (ioctl(seq_fd, SNDCTL_SYNTH_INFO, &card_info[sb_dev]) == -1) {
	    fprintf(stderr, "cannot get info on soundcard\n");
	    perror("/dev/sequencer");
	    STOPNOW;
	}
	card_info[sb_dev].device = sb_dev;
	/* We have 12 voices, despite what the driver reports. */
	if (card_info[sb_dev].nr_voices == 6) {
	    card_info[sb_dev].nr_voices = 6 /*12*/;
	    spare_cells[sb_dev] = 6;
	}
	else spare_cells[sb_dev] = card_info[sb_dev].nr_voices;
    }

    if (verbose && sb_dev >= 0)
	printf("%d sb voices, %d instruments.\n",
	       card_info[sb_dev].nr_voices,
	       card_info[sb_dev].instr_bank_size);
    if (verbose && gus_dev >= 0)
	printf("%d gus voices, %d instruments.\n",
	       card_info[gus_dev].nr_voices,
	       card_info[gus_dev].instr_bank_size);
#ifdef XPOLYPHONY
    if (verbose && ext_dev >= 0)
	printf("%d ext voices.\n",
	       card_info[ext_index].nr_voices);
#endif
}



/*
 * Read fm patch libraries.
 */
#define SBDIRO3DRUMS SBDIR##"/drums.o3"
#define SBDIRO3STD SBDIR##"/std.o3"
#define SBDIRSBDRUMS SBDIR##"/drums.sb"
#define SBDIRSBSTD SBDIR##"/std.sb"

#define OWN_FM_VOL
#ifdef OWN_FM_VOL
static char            fm_volume_table[128] =
{-63, -48, -40, -35, -32, -29, -27, -26,	/* 0 -   7 */
 -24, -23, -21, -20, -19, -18, -18, -17,	/* 8 -  15 */
 -16, -15, -15, -14, -13, -13, -12, -12,	/* 16 -  23 */
 -11, -11, -10, -10, -10, -9, -9, -8,	/* 24 -  31 */
 -8, -8, -7, -7, -7, -6, -6, -6,/* 32 -  39 */
 -5, -5, -5, -5, -4, -4, -4, -4,/* 40 -  47 */
 -3, -3, -3, -3, -2, -2, -2, -2,/* 48 -  55 */
 -2, -1, -1, -1, -1, 0, 0, 0,	/* 56 -  63 */
 0, 0, 0, 1, 1, 1, 1, 1,	/* 64 -  71 */
 1, 2, 2, 2, 2, 2, 2, 2,	/* 72 -  79 */
 3, 3, 3, 3, 3, 3, 3, 4,	/* 80 -  87 */
 4, 4, 4, 4, 4, 4, 4, 5,	/* 88 -  95 */
 5, 5, 5, 5, 5, 5, 5, 5,	/* 96 - 103 */
 6, 6, 6, 6, 6, 6, 6, 6,	/* 104 - 111 */
 6, 7, 7, 7, 7, 7, 7, 7,	/* 112 - 119 */
 7, 7, 7, 8, 8, 8, 8, 8};	/* 120 - 127 */

static int new_fm_vol(int volbyte, int chan, int voice)
{
    int oldvol, newvol, mainvol, n = 16;

    if (chan == 9) mainvol = main_volume[9];
    else {
	for (n = 0; n < NUM_CHANS; n++)
	    if (n != 9 && n != 15 && program[n]-1 == voice) break;
	if (n < NUM_CHANS) mainvol = main_volume[n];
	else mainvol = 120;
    }
    oldvol = 0x3f - (volbyte & 0x3f);
    newvol = fm_volume_table[mainvol] + oldvol;
/**
if (n < NUM_CHANS)
printf("chan %d, voice %d, volbyte %02x, oldvol %d, newvol %d, mainvol %d\n",
n, voice, volbyte, oldvol, newvol, mainvol);
**/
    if (newvol > 0x3f) newvol = 0x3f;
    else if (newvol < 0) newvol = 0;
    n = 0x3f - (newvol & 0x3f);
    return( (volbyte & 0xc0) | (n & 0x3f) );
}

static int fm_side(int chan)
{
    int leftright = 0x30;

    if (ext_pan[chan] != -1) {
	if (ext_pan[chan] < 54)
	    leftright = 0x10;
	else if (ext_pan[chan] > 74)
	    leftright = 0x20;
    }
    return(leftright);
}
#endif

void lib_init()
{
    char libname[80];
    int n, v, f, num_drums, voice_size, data_size, want_4op_mode;
    int first_voice = 128;
    struct sbi_instrument instr;
    char vbuf[O3VOICESIZE];


    if (sb_dev < 0) return;

    /* first, the drums */

    strcpy(libname, SBDIRO3DRUMS);
    /* assume a 4op patch */
    voice_size = O3VOICESIZE;

    /* global variable set true when any 4op patch is encountered,
     * so later we know whether to ask the driver for 4op mode
     */
    need_4op_mode = false;
    /* There might be circumstances in which 2op patches
     * are preferable, even though 4op mode is available.
     */
    if (card_info[sb_dev].nr_voices != 18) setting_4op_mode = false;
    want_4op_mode = setting_4op_mode;

    /* Drum patches are loaded as programs 128+; make sure there
     * is room for them.
     */
    if (card_info[sb_dev].instr_bank_size >= 128 + 47)
	num_drums = 47;
    else {
	fprintf(stderr, "not enough instruments in banksize of %d\n", card_info[sb_dev].instr_bank_size);
	v_drum = false;
	return;
    }
    if (!want_4op_mode || (f = open(libname, O_RDONLY, 0)) == -1) {
	/* There is no 4op drum library, so look for 2op library. */
	want_4op_mode = false;
	strcpy(libname, SBDIRSBDRUMS);
	voice_size = SBVOICESIZE;
	if ((f = open(libname, O_RDONLY, 0)) == -1) {
	    if (verbose)
		fprintf(stderr, "can't find %s or %s/drums.o3 library file\n",
			libname, SBDIR);
	    v_drum = false;
	    return;
	}
    }

    /* Now read the drum library. */

    instr.device = sb_dev;

    for (v = 0; v < 47; v++) {
	if (read(f, vbuf, voice_size) != voice_size) {
	    if (verbose)
		fprintf(stderr, "%s is a short library file\n", libname);
	    close(f);
	    return;
	}
	instr.channel = v + first_voice;

	if (voice_size == SBVOICESIZE || !want_4op_mode) {
	    instr.key = FM_PATCH;
	    data_size = 11;
	} else if ((vbuf[49] & 0x3f) == 0x3f && (vbuf[50] & 0x3f) == 0x3f) {
	    instr.key = FM_PATCH;
	    data_size = 11;
	} else {
	    need_4op_mode = true;
	    instr.key = OPL3_PATCH;
	    data_size = 22;
	}

	/* Dynamic voice allocation routine new_cell() needs to
	 * which voices are 4op, because they can only use the first
	 * 6 cells, so save this information.
	 */
	instr_key[128 + v + 35] = instr.key;

#ifdef RELOAD_FM

#ifdef OWN_FM_VOL
	if (instr.key == FM_PATCH) {
	    vbuf[39] = new_fm_vol(vbuf[39], 9, 0);
	    if (vbuf[46] & 1) vbuf[38] = new_fm_vol(vbuf[38], 9, 0);
	    vbuf[46] = (vbuf[46] & 0xcf) | fm_side(9);
	}
	else {
	    vbuf[50] = new_fm_vol(vbuf[50], 9, 0);
	    vbuf[46] = (vbuf[46] & 0xcf) | fm_side(9);
	    vbuf[57] = (vbuf[57] & 0xcf) | fm_side(9);
	}
#endif

	/* Load the drum patches down to the driver. */
	for (n = 0; n < 32; n++)
	    instr.operators[n] = (n < data_size) ? vbuf[SBOFFSET + n] : 0;

	if (write(seq_fd, (char *) &instr, sizeof(instr)) == -1) {
	    if (verbose)
		fprintf(stderr, "can't load instrument %d\n", v);
	    close(f);
	    return;
	}
#endif
	/* Save "meta" information about the patch. */
	sb_trnsps[instr.channel] = vbuf[32];
	d_dur[instr.channel] = vbuf[33];
#ifdef XVOICE
	xvoice[instr.channel] = vbuf[34];
#endif
	dnote[instr.channel] = vbuf[35];
    }
    close(f);

    /* Done with the drums.  Now do the same for the library of
     * melodic voices.
     */

    strcpy(libname, SBDIRO3STD);
    voice_size = O3VOICESIZE;
    want_4op_mode = setting_4op_mode;
    if (!want_4op_mode || (f = open(libname, O_RDONLY, 0)) == -1) {
	want_4op_mode = false;
	strcpy(libname, SBDIRSBSTD);
	voice_size = SBVOICESIZE;
	if ((f = open(libname, O_RDONLY, 0)) == -1) {
	    if (verbose)
		fprintf(stderr, "can't find %s or %s/std.o3 library file\n",
			libname, SBDIR);
	    return;
	}
    }
    for (v = 0; v < 128; v++) {
	if (read(f, vbuf, voice_size) != voice_size) {
	    if (verbose)
		fprintf(stderr, "%s is a short library file\n", libname);
	    close(f);
	    return;
	}
	if (voice_size == SBVOICESIZE || !want_4op_mode)
	    instr_key[v] = FM_PATCH;
	else if ((vbuf[49] & 0x3f) == 0x3f && (vbuf[50] & 0x3f) == 0x3f)
	    instr_key[v] = FM_PATCH;
	else {
	    need_4op_mode = true;
	    instr_key[v] = OPL3_PATCH;
	}

	sb_trnsps[v] = vbuf[32];
	d_dur[v] = vbuf[33];
#ifdef XVOICE
	xvoice[v] = vbuf[34];
#endif
	dnote[v] = vbuf[35];

#ifdef RELOAD_FM

#ifdef OWN_FM_VOL
	if (instr_key[v] == FM_PATCH) {
	    vbuf[39] = new_fm_vol(vbuf[39], 0, v);
	    if (vbuf[46] & 1) vbuf[38] = new_fm_vol(vbuf[38], 0, v);
	    vbuf[46] = (vbuf[46] & 0xcf) | fm_side(v);
	}
	else {
	    int mode;
	    if (buf[46]&1) mode = 2; else mode = 0;
	    if (buf[57]&1) mode++;
	    vbuf[50] = new_fm_vol(vbuf[50], 0, v);
	    if (mode == 3) vbuf[49] = new_fm_vol(vbuf[49], 0, v);
	    if (mode == 1) vbuf[39] = new_fm_vol(vbuf[39], 0, v);
	    if (mode == 2 || mode == 3) vbuf[38] = new_fm_vol(vbuf[38], 0, v);
	    vbuf[46] = (vbuf[46] & 0xcf) | fm_side(v);
	    vbuf[57] = (vbuf[57] & 0xcf) | fm_side(v);

	}
#endif

	if ((instr.key = instr_key[v]) == OPL3_PATCH)
	    data_size = 22;
	else
	    data_size = 11;

	instr.channel = v;

	for (n = 0; n < 32; n++)
	    instr.operators[n] = (n < data_size) ? vbuf[SBOFFSET + n] : 0;

	if (write(seq_fd, (char *) &instr, sizeof(instr)) == -1) {
	    if (verbose)
		fprintf(stderr, "can't load instrument %d\n", v);
	    close(f);
	    return;
	}
#endif
    }
    close(f);

}

/*
 * Display voices and channels if -v flag was given, and
 * set up Kawaii K1.
 */
void voices_init()
{
    int n;

#ifdef PSEUDO_STEREO
#ifdef USE_SHM
    setting_pstereo = *shm_setting_pstereo;
#endif
    if (setting_pstereo) {
	int scount = 0;
	for (n = 0; n < NUM_CHANS; n++) {
	    if (ext_pan[n] >= 0) break;
	    if (program[n] > 0) scount++;
	    if (ext_chan[n] > 0) scount++;
	}
	if (n == NUM_CHANS && scount > 3) for (n = 0; n < NUM_CHANS; n++) {
	    if (n % 2) scount = 224 - 16*(n-1);
	    else scount = 16*n;
	    if (scount > 128) scount -= 128;
	    if (scount == 128) scount = 127;
	    ext_pan[n] = scount;
	}
    }
#endif

#ifdef MIDIIN
    /* At the time /dev/sequencer was opened as write-only, it was not
     * known whether we needed midi input.  Now we know, so reopen it
     * as read-write, if need be.
     */
    if (ext_dev >= 0) {
	close(seq_fd);
	/* It has to be non-blocking, to keep enough events in the driver's
	 * queue to make sure gus volume is set _immediately_ after a note
	 * has started.  Otherwise, can hear the volume the driver sets,
	 * which is too loud.
	 */
	if ((seq_fd = open("/dev/sequencer", O_NONBLOCK|O_RDWR, 0)) == -1) {
	    fprintf(stderr, "couldn't reopen /dev/sequencer for input\n");
	    STOPNOW;
	}
	midi_is_open_for_input = true;
    }
    /* A small threshold minimizes problem of lost note-off events to
     * the midi output port.
     */
    n = WAKETHRESH;
    ioctl(seq_fd, SNDCTL_SEQ_TRESHOLD, &n);
#endif

    /* Display each channel and set up K1 patch. */

    for (n = 0; n < NUM_CHANS; n++) {
	int v;
	char *polynote;
	static char *pan[3] = {"right", "center", "left"};
	int leftright = 1;

	if (ext_pan[n] != -1) {
	    if (ext_pan[n] < 54) leftright = 2;
	    else if (ext_pan[n] > 74) leftright = 0;
	}

	if (!local_extflag)
	    ext_chan[n] = 0;
	/* "ext_program" has the first program requested for each
	 * channel, or else -1 or 0 if there was no program request
	 * (0 if notes were played on the channel)
	 */
	v = program[n] - 1;
	/* if notes were played but there was no program request, use
	 * program 0, Ac. Gr. Piano, as default (actually, I think this
	 * was already done -- but better safe than sorry)
	 */
	if (program[n] == 0)
	    v = 0;
	if (sub_voice[v].solo && !no_solo) polynote = "";
	else polynote =  "(poly) ";

	if ((sb_dev >= 0 || gus_dev >= 0) && PERCCHAN(n) && v >= 0) {
	    if (verbose) {
		printf("  channel %2d: %s percussion at %s", n + 1,
		       (sb_dev >= 0) ? "sb" : "gus", pan[leftright]);
		printf(".\n");
	    }
	/* Following is just an experiment and not useful, currently. */
	} else if (sb_dev >= 0 && sysex[n] != NULL) {
	    int i;
	    struct sbi_instrument instr;

	    program[n] = 240 + n + 1;
	    instr.channel = 240 + n;
	    instr.device = sb_dev;
	    instr.key = FM_PATCH;
	    for (i = SBOFFSET; i < SBVOICESIZE; i++)
		instr.operators[i - SBOFFSET] = sysex[n][i + 8];
	    if (write(seq_fd, (char *) &instr, sizeof(instr)) == -1) {
		fprintf(stderr, "can't load instrument\n");
		STOPNOW;
	    }
	    if (verbose)
		printf("  channel %2d: sysex %s\n", n + 1, sysex[n] + 4 + 8);
	}
#ifdef K1
	/* which channels shall we send out to the K1? none if the -e flag
	 * was given (local_extflag is 0), no more than the max (etot keeps track),
	 * and not for a timbre the K1 doesn't have (marked -1 in the array in
	 * vname.h)
	 */
	else if (ext_chan[n]) {
	    int etot = ext_chan[n] - 1;
	    int solo = 0;
	    int kbmode = etot ? 1 : 2;
	    v = ext_program[etot] - 1;
	    kmpatch.poly[etot] = solo | ((kbmode & 1) << 6) | (leftright << 4);
	    /* use transposition marked in vname.h */
	    kmpatch.transpose[etot] = sub_voice[v].transpose + 24;
	    /* finally, the voice/timbre for the section */
	    kmpatch.single[etot] = sub_voice[v].newv;
	    if (verbose) {
		printf("  channel %2d: %s[%d] %sto K1 channel %d at %s.\n", n + 1,
		sub_voice[v].vname, v, polynote, etot + 1, pan[leftright]);
		if (program[n] > 0 && v != program[n] - 1 && sb_dev >= 0)
		    printf("   (also %s[%d], etc. to %s)\n",
			 sub_voice[program[n] - 1].vname, program[n] - 1,
			gus_voice[program[n] - 1].loaded ? "gus" : "sb");
	    }
	}
#else
	else if (ext_chan[n] && v >= 0) {
	    if (verbose)
		printf("  channel %2d: %s[%d] %sexternal.\n", n + 1,
		       sub_voice[v].vname, v, polynote);
	}
#endif
	else if (program[n] > 0) {
	    if (verbose) {
		printf("  channel %2d: is %s[%d] %son %s at %s.\n", n + 1,
		       sub_voice[program[n] - 1].vname, program[n] - 1, polynote,
		       (gus_dev >= 0 && gus_voice[program[n] - 1].loaded) ?  "gus" :
		       ((sb_dev >= 0) ? "sb" : "nothing"), pan[leftright]);
	    }
	}
    }

    if (recording_track) {
#ifdef K1
/* The first channel has been reserved for the player; initialize
 * it now to respond to the keyboard and use the program specified
 * on the command line, if any.  Tone down the volume a little.
 */
	int kbmode = 0;
	int prog = sub_voice[recording_program].newv;
	if (prog < 0)
	    prog = 0;
	kmpatch.single[0] = prog;
	kmpatch.rcvchan[0] = (0x3f & kmpatch.rcvchan[0]) | ((kbmode & 2) << 5);
	kmpatch.poly[0] = 0 | ((kbmode & 1) << 6) | (1 << 4);
	kmpatch.transpose[0] = sub_voice[recording_program].transpose + 24;
	kmpatch.level[0] = 90;
#else
	f_program(ext_index, recording_channel, 1, recording_program);
#endif
    }
#ifdef K1
    if (local_extflag) {
#ifdef MIDIIN
	unsigned char k1ack[7] =
	{0xf0, 0x40, 0x00, 0x40, 0x00, 0x03, 0xf7};
	int n = 0, tries = 5;

#ifdef DEBUGK1INIT
fprintf(stderr,"K1 init");
#endif
	while (tries--) {
#endif
#ifdef DEBUGK1INIT
fprintf(stderr," (try)");
#endif
	    if (readable)
		dk1msone(64);
	    k1msone(64);
	    sbflush();
	    usleep(100000);
#ifdef MIDIIN
	    if (readable)
		printf("  (k1 answering: ");
	    for (n = 0; n < 7; n++) {
		int c = inonenb();
		if (c == MIDI_CTRL) {
		    (void) inonenb();
		    (void) inonenb();
		    c = inonenb();
		}
		if (c == -1) {
		    int n;
#ifdef DEBUGK1INIT
fprintf(stderr," (time out)");
#endif
		    if (verbose)
			printf("timed out waiting for k1 to acknowledge patch\n");
	    	    (void) ioctl(seq_fd, SNDCTL_SEQ_RESET, 0);
		    close(seq_fd);
		    if ((seq_fd = open("/dev/sequencer", O_NONBLOCK|O_RDWR, 0)) == -1) {
			perror("reopen /dev/sequencer");
			STOPNOW;
		    }
		    midi_is_open_for_input = true;
		    n = WAKETHRESH;
		    ioctl(seq_fd, SNDCTL_SEQ_TRESHOLD, &n);
		    break;
		}
		if (readable)
		    printf(" 0x%02x", c);
		if (c != k1ack[n]) {
		    while (midipending()) {
			c = inonenb();
			if (readable)
			    printf(" 0x%02x", c);
		    }
		    if (verbose && !readable)
			printf("k1 did not correctly acknowledge my patch on try %d\n", 5 - tries);
		    break;
		}
	    }
	    if (readable)
		printf(")\n");
	    if (n == 7)
		break;
	    if (!tries) {
		fprintf(stderr, "cannot send patch to k1\n");
		STOPNOW;
	    } else {
		usleep(100000);
		while (midipending())
		    (void) midigetc();
	    }
	}
#endif
#ifdef DEBUGK1INIT
fprintf(stderr," (prog)");
#endif
	midicmdch(MIDI_CH_PROGRAM + 0);
	midich(64);
	sbflush();
	usleep(200000);
#ifdef DEBUGK1INIT
fprintf(stderr," (prog fl)");
#endif
#ifdef MIDIIN
	while (midipending()) {
	    int c = 0xff & midigetc();
	    if (verbose)
		printf(" k1 says 0x%02x for some reason\n", c);
	}
#ifdef DEBUGK1INIT
fprintf(stderr," (input fl)");
#endif

	/* Read-write mode seems to exacerbate midi output problems,
	 * so if it's not required, go back to write-only.
	 */
	if (!recording_track) {
	    int n;
	    (void) ioctl(seq_fd, SNDCTL_SEQ_RESET, 0);
	    close(seq_fd);
	    if ((seq_fd = open("/dev/sequencer", O_NONBLOCK|O_WRONLY, 0)) == -1) {
		perror("reopen /dev/sequencer to write");
		STOPNOW;
	    }
	    midi_is_open_for_input = false;
#ifdef DEBUGK1INIT
fprintf(stderr," (reopened)");
#endif
	    n = WAKETHRESH;
	    ioctl(seq_fd, SNDCTL_SEQ_TRESHOLD, &n);
#ifdef DEBUGK1INIT
fprintf(stderr," (thresh)");
#endif
	}
#endif

#ifdef DEBUGK1INIT
fprintf(stderr, " done\n");
#endif

    }
#endif
}


/*
 * Send default values to all synths.
 */
void channel_init()
{
    int i;

    /* Initialize all midi channels with reasonable start values: */
    for (i = 1; i <= NUM_CHANS; i++) {
	int card;
	int d = ext_chan[i - 1];
	if (d)
	    card = ext_index;
	else if (sb_dev >= 0)
	    card = sb_dev;
	else if (gus_dev >= 0)
	    card = gus_dev;
	else
	    card = -1;
	program[i - 1] = ext_program[i - 1];
	if (program[i - 1] <= 0)
	    ext_program[i - 1] = program[i - 1] = 1;
	bend[i - 1] = 1 << 13;
	main_volume[i-1] = NORMAL_VOLUME;
	expression[i-1] = NORMAL_EXPR;
	reverberation[i-1] = -1;
	if (!initflag) continue;

	f_program(card, 0, i, program[i - 1]);
	f_bend(card, 0, i, 1 << 13);
	f_touch(card, 0, i, 0);
	f_ctrl(card, 0, i, PORTARATE, 99);
	f_ctrl(card, 0, i, PORTASWITCH, 0);
	f_ctrl(card, 0, i, MODWHEEL, 0);
	f_ctrl(card, 0, i, FOOT, 99);
	f_ctrl(card, 0, i, VOLUME, NORMAL_VOLUME);
	if (!d || ext_dev < 0)
	    continue;
	f_program(card, d, i, program[i - 1]);
	f_bend(card, d, i, 1 << 13);
	f_touch(card, d, i, 0);
	f_ctrl(card, d, i, PORTARATE, 99);
	f_ctrl(card, d, i, PORTASWITCH, 0);
	f_ctrl(card, d, i, MODWHEEL, 0);
	f_ctrl(card, d, i, FOOT, 99);
	f_ctrl(card, d, i, VOLUME, NORMAL_VOLUME);
    }
}

#ifdef MIDIIN
/*
 * During recording, calculate the midi delta time.  Use the total
 * time, sb_time, instead of just time since last delta, to maintain
 * accuracy.
 */
unsigned long getdelta()
{
    static double last_ticks = 0;
    double ticks = ((double) sb_time * 10000 * (double) Mf_division) / (double) Mf_currtempo;
    unsigned long delta_ticks = (unsigned long) (ticks - last_ticks);
    last_ticks = ticks;
    return (delta_ticks);
}

/*
 * Get anything that has arrived at the midi input port and write it
 * out to the track file if we are recording, else discard it.
 */
void listen()
{
    if (!midi_is_open_for_input) return;
    while (midipending()) {
	if (recording_track)
	    midimessage();
	else
	    (void) midigetc();
    }
}
#endif


#ifdef XMP

#ifdef USE_SHM
#define RINGSIZE 64
extern int *talk_in, *talk_out;

struct mp_talk {
	unsigned mptime;
	unsigned char count[NUM_CHANS];
	unsigned short vel[NUM_CHANS];
	int expr[NUM_CHANS];
};

extern struct mp_talk **mpd;
#endif

/*
 * Send packet of information to mother xmp process for meter display.
 */
static void
send_meter_packet(int always)
{   static int last_write_time = -1;
    int i;
#ifdef USE_SHM
    int r;
#endif

    if ( (time/10) != last_write_time || always ) {

#ifdef USE_SHM
	if (last_write_time < 0) {
		*talk_in = 0;
	}

	r = *talk_in % RINGSIZE;

	for (i = 0; i < NUM_CHANS; i++) {
	    int val;
	    mpd[r]->count[i] = curr_note_count[i];
	    mpd[r]->vel[i] = curr_note_velocity[i];
	    val = -1;
	    switch (*shm_setting_meter_color) {
		case 0: val = expression[i]; break;
		case 1: val = main_volume[i]; break;
		case 2: val = chorus_depth[i]; break;
		case 3: val = reverberation[i]; break;
		case 4: val = ext_pan[i]; break;
	    }
	    if (val < 0) {
		if (*shm_setting_meter_color == 3) val = 0;
		else val = 64; /* panning at center default */
	    }
	    mpd[r]->expr[i] = val;
	}
	mpd[r]->mptime = time;

	if (*talk_in - *talk_out < RINGSIZE - 2) (*talk_in)++;

#else
	write(1, curr_note_count, sizeof(curr_note_count));
	write(1, curr_note_velocity, sizeof(curr_note_velocity));
	write(1, &time, sizeof(time));
	switch (setting_meter_color) {
	    case 0: write(1, expression, sizeof(expression)); break;
	    case 1: write(1, main_volume, sizeof(main_volume)); break;
	    case 2: write(1, chorus_depth, sizeof(chorus_depth)); break;
	    case 3: write(1, reverberation, sizeof(reverberation)); break;
	    case 4: write(1, ext_pan, sizeof(ext_pan)); break;
	}
	fflush(stdout);
#endif
	last_write_time = (time/10);
	for (i = 0; i < NUM_CHANS; i++) {
	    curr_note_count[i] = inst_note_count[i];
	    curr_note_velocity[i] = inst_note_velocity[i];
	    if (curr_note_count[i] && curr_note_velocity[i]/curr_note_count[i] > 50) {
		curr_note_count[i] = (3*curr_note_count[i]) / 2;
		curr_note_velocity[i] = (3*curr_note_velocity[i]) / 2;
	    }
	}
    }
}
#endif

/*
 * This loop plays the music.
 */
void play_score()
{
    event_type event;
    /* Go to the next event indirectly using the_next_event variable,
     * so that some notes can be played twice, for reverberation
     * effect, without allocating a whole new note structure.
     */
    event_type the_next_event, the_last_event;

    /* Argument was passed indirectly from phase1(). */
    event = the_score;
    the_last_event = (event_type)NULL;

#ifdef MIDIIN
    /* Write track initialization info. */
    if (recording_track) {
	unsigned char data[4];
	(void) mf_write_tempo(0, Mf_currtempo);
	data[0] = recording_program;
	(void) mf_write_midi_event(getdelta(), MIDI_CH_PROGRAM, recording_channel - 1, data, 1);
    }
#endif

    /* Unless we resynchronize /dev/sequencer just before starting to
     * play, the first few notes sound hurried.
     */
    if (playing_music) sb_resync();

    /* The playing loop starts here. */
    while (event != NULL) {	/* play it, Sam */
	/* d is the channel, 1-16, to use for the external synth, or
	 * else 0 if the event is for a sound card.
	 */
	int d = event->ndest;
	/* card is either sb_dev or gus_dev, or -1 if event is not for
	 * either card.
	 */
	int card = event->ncard;
	/* the local midi channel, from 0-15 */
	int chan = vc_voice(event->nvoice);
#ifdef TRY_VIBRATO
	unsigned long new_time = event->ntime;
#else
	time = event->ntime;
#endif

	/* where to go next: This may be changed in case of an echo note. */
	the_next_event = event->next;
	if (the_last_event != (event_type)NULL) free(the_last_event);
	the_last_event = event;

	/* If this channel is not marked as in use for the external synth,
	 * make sure the event can't be sent out the midi port.
	 */
	if (!ext_chan[chan] || ext_dev < 0) d = 0;

	/* When the event is for the external synth, point card to one past
	 * the index of the last real sound card, pro forma, for the sake
	 * of indexing some arrays.
	 */
	if (d) card = ext_index;

	/* Discard any event which has no destination at all. */
	if (card < 0) {
	    event = the_next_event;
	    continue;
	}

#ifdef XMP
/* note that if TRY_VIBRATO is not defined, this has to be changed to generate
 * a write packet at time=0
 */
	send_meter_packet(false);
#endif

#ifdef TRY_VIBRATO
	while (time < new_time) {
	    time++;
	    note_offs(time);
	    if (time&1) continue;
	    if (gus_dev >= 0) fm_vibrate(gus_dev, time);
	    if (sb_dev >= 0) fm_vibrate(sb_dev, time);
	}
#else
	/* Terminate all notes in the off events list whose ending
	 * times are at or before now.
	 */
	note_offs(time);
#endif

#ifdef MIDIIN
	/* Record or purge midi input. */
	listen();
#endif

	if (is_note(event)) {	/* play a note */
	    int prog = event->u.note.nprogram;
	    int pitch = event->u.note.npitch;
	    int vel = event->u.note.nloud;
	    int dur = event->u.note.ndur;
	    int effect = event->u.note.neffect;

	    /* We cannot send to the external synth the second note generated
	     * when there is chorus depth, because it's simultaneous with and
	     * at the same pitch as the first note, so discard it.
	     */
	    if (d && (effect & CHORUS2_EFFECT)) {
		event = the_next_event;
		continue;
	    }

#ifdef TRY_CHORUS
	    /* Also discard the second chorus note when we don't have enough cells. */
#ifdef USE_SHM
	    if (!d && (spare_cells[card] < 1 || !*shm_setting_chorus_spread))
#else
	    if (!d && (spare_cells[card] < 1 || !setting_chorus_spread))
#endif
#else
	    /* ... or always discard it */
	    if (!d)
#endif
	    {
		if (effect & CHORUS2_EFFECT) {
		    event = the_next_event;
		    continue;
	        }
		/* Don't bend pitch of first chorus note when the first one
		 * had to be discarded.
		 */
		effect &= ~CHORUS1_EFFECT; 
	    }

#ifdef TRY_ECHO_REVERB
#ifdef USE_SHM
	    setting_reverb = *shm_setting_reverb;
#endif
	    /* Generate an extra note for reverberation effect. */
	    if (!d				/* when not ext. synth note */
	      && setting_reverb			/* when xmp setting requests it */
	      && spare_cells[card] > 2		/* But not when short on cells */
	      && reverberation[chan] > 20	/* or when there is little reverb */
	      && (!PERCCHAN(chan)||card!=sb_dev)/* or for fm percussion (it works out
						 * badly for fm, but this is a
						 * shame). */
	      && pitch > 48			/* Reverb is relatively inaudible
						 * at low pitches, so why waste
						 * the polyphony? */
	      && pitch != NO_PITCH		/* Don't echo rests. */
	      && vel > 127/3) {			/* Not only is reverb less audible
						 * for soft notes, but we have
						 * to prevent generating echoes
						 * of echoes of echoes ...
						 */
		event_type lag, lead;
		int reverb_adjust = 1 + (reverberation[chan]*setting_reverb)/1000;
		/* Values for current note are already in temporary
		 * variables, so we are free to modify the event without
		 * affecting anything this time around the play loop.
		 */
		event->u.note.nloud = vel / 3;
		/* Echo is softer, later, and longer.  Adjust amounts
		 * to taste.
		 */
		event->ntime += reverb_adjust;
		event->u.note.ndur += 4 * reverb_adjust;
		/* Flag it as an echo so it will be panned from a
		 * slightly different direction.
		 */
		event->u.note.neffect |= ECHO_EFFECT;
		/* Link the echo note back in further down the note list,
		 * so it will be played in the future.
		 */
		lag = event;
		lead = event->next;
		while (lead) {
		    if (event->ntime <= lead->ntime)
			break;
		    lag = lead;
		    lead = lead->next;
		}
		/* If it wasn't put after any future events, then it is
		 * the very next event.
		 */
		if (lag == event) {
		    the_next_event = event;
		} else {
		    event->next = lag->next;
		    lag->next = event;
		}
		/* don't free the memory */
		the_last_event = (event_type)NULL;
	    }
#endif


	    /* Change the pitch or duration, as specified in the fm patch. */
	    if (card == sb_dev && pitch != NO_PITCH) {
		if (PERCCHAN(chan)) {
		    if (d_dur[128 + pitch - 35])
			dur = d_dur[128 + pitch - 35];
		}
		else {
		    if (d_dur[prog - 1])
			dur = d_dur[prog - 1];
		    if (dnote[prog - 1])
			pitch = dnote[prog - 1];
		    if (sb_trnsps[prog - 1])
			pitch += sb_trnsps[prog - 1] - 64;
		}
	    }
	    /* If values are out of bounds, skip this note. */
	    if (pitch < 0 || pitch > 127 || dur < 1) {
		event = the_next_event;
		continue;
	    }
	    /* check for correct program (preset) */
	    if ((d || !PERCCHAN(chan)) && prog != program[chan]) {
		f_program(card, d, chan + 1, prog);
		program[chan] = prog;
	    }
	    /* if it is a note (not a rest) play it */
	    if (pitch != NO_PITCH) {
		int cell = 0;
		/* Request a voice ("cell") to be allocated, even for notes
		 * that go to the external synth, if we are doing voice
		 * allocation for it, too.
		 */
		cell = new_cell(card, time, d, chan, prog - 1, pitch, vel, effect);
		/* Currently, we always get a cell from new_cell(), but this might
		 * change, in which case we will want to skip the note.
		 */
		if (cell == -1) {
		    event = the_next_event;
		    continue;
		}

		/* Start the note up. */
		f_note(card, d, chan + 1, cell, pitch, vel, time);
		/* Put it on the list to be turned off later. */
		off_schedule(card, d, time + dur, chan, cell, pitch, time);
#ifdef XVOICE
		/* If doubling the note is requested in the fm patch, do
		 * that now, polyphony permitting.
		 */
		if (/*!effect &&*/ card == sb_dev && spare_cells[sb_dev] > 1) {
		    int xprogram = xvoice[prog - 1];
		    if (xprogram) {
			cell = new_cell(card, time, d, chan, prog - 1, pitch, vel, effect);
			if (cell == -1) {
			    event = the_next_event;
			    continue;
			}
			f_program(card, d, chan + 1, xprogram);
			f_note(card, d, chan + 1, cell, pitch, vel, time);
			off_schedule(card, d, time + dur, chan, cell, pitch, time);
			f_program(card, d, chan + 1, prog);
		    }
		}
#endif
	    }

	/* here, the event was not a note */
	} else {		/* send control info */
	    int val = event->u.ctrl.value;
	    switch (vc_ctrl(event->nvoice)) {
	    case 1:
		f_ctrl(card, d, chan + 1, PORTARATE, val);
		break;
	    case 2:
		f_ctrl(card, d, chan + 1, PORTASWITCH, val);
		break;
	    case 3:
		f_ctrl(card, d, chan + 1, MODWHEEL, val);
		break;
	    case 4:
		f_touch(card, d, chan + 1, val);
		break;
	    case 5:
		if (use_damper)
		    f_ctrl(card, d, chan + 1,
			   FOOT, val);
		break;
	    case 6:
		f_bend(card, d, chan + 1, val);
		break;
	    case 7:
		f_ctrl(card, d, chan + 1, VOLUME, val);
		main_volume[chan] = val;
		break;
	    case 8:
		f_ctrl(card, d, chan + 1, PAN, val);
		ext_pan[chan] = val;
		break;
	    case 9:
		expression[chan] = val;
		f_ctrl(card, d, chan + 1, EXPRESSION, val);
		break;
	    case 15:
	    /* for all controller events other than the above */
		if (event->u.ctrl.control == REVERBERATION)
		    reverberation[chan] = val;
		else if (event->u.ctrl.control == CHORUS_DEPTH)
		    chorus_depth[chan] = val;
		f_ctrl(card, d, chan + 1, event->u.ctrl.control, val);
		break;
	    default:
		break;
	    }
	}

	event = the_next_event;
    }				/* play it, Sam */

    /* At end of the song, all notes off. */
    note_offs(MAXTIME);
    if (the_last_event != (event_type)NULL) free(the_last_event);

#ifdef XMP
    send_meter_packet(true);
#endif

    /* Finish up by flushing the output buffer, getting any last
     * midi input, waiting for all events in driver queue to be
     * processed, write end of track info to track file, and
     * finally allowing a little extra time for the last notes
     * played on the gus to fade away.
     */
    if (playing_music) {
	int room;
	sbflush();
#ifdef MIDIIN
	listen();
#endif
	while ((ioctl(seq_fd, SNDCTL_SEQ_GETOUTCOUNT, &room) != -1) && (room < 512)) {
	    usleep(100000);
#ifdef MIDIIN
	    listen();
	}
	if (recording_track)
	    (void) mf_write_meta_event(getdelta(), 0x2f/*end_of_track*/, NULL, 0);
#else
	}
#endif
#ifdef K1
	/* kill any hanging notes (K1 does not understand all-notes-off) */
	if (ext_dev >= 0) {
	    midicmdch(MIDI_CH_PROGRAM + 0);
	    midich(0);
	    sbflush();
	}
#endif
	if (gus_dev >= 0)
	    sleep(1);
    }
}


/* noteoff.c -- this module keeps track of pending note offs for adagio */

/*****************************************************************************
*	    Change Log
*  Date	    | Change
*-----------+-----------------------------------------------------------------
* 31-Dec-85 | Created changelog
* 31-Dec-85 | Add c:\ to include directives
*  1-Jan-86 | Declare malloc char * for lint consistency
* 21-Jan-86 | note_offs can now turn off more than one note per call
*****************************************************************************/


/* off_type is a structure containing note-off information */

typedef struct off_struct {
    unsigned long when;
    int voice;
    int pitch;
    char dest;
    char card;
    int cell;
    unsigned long stime;
    struct off_struct *next;
} *off_type;

static off_type free_off = NULL;	/* free list of off_type structures */
static off_type off_events = NULL;	/* active list */

/****************************************************************************
*	Routines declared in this module
****************************************************************************/

static off_type off_alloc();
static void off_free();

/****************************************************************************
*				note_offs
* Inputs:
*	long time: the current time
* Outputs:
*	return true if off list has more notes
* Effect: turn off notes if it is time
* Assumes:
* Implementation:
*	Find scheduled note off events in off_events, compare with time
****************************************************************************/

static int note_offs(mtime)
unsigned long mtime;
{
    off_type temp;
    while (off_events != NULL && (time = off_events->when) <= mtime) {
	f_note(off_events->card, off_events->dest, (off_events->voice) + 1,
	       off_events->cell, off_events->pitch, 0, off_events->stime);
	temp = off_events;
	off_events = off_events->next;
	off_free(temp);
    }
    if (mtime < MAXTIME)
	time = mtime;
    return (off_events != NULL);
}

/****************************************************************************
*				off_alloc
* Outputs:
*	returns off_type: an allocated note off structure
* Effect:
*	allocates a structure using malloc
****************************************************************************/

static off_type off_alloc()
{
    return (off_type) malloc(sizeof(struct off_struct));
}

/****************************************************************************
*				off_free
* Inputs:
*	off_type off: a structure to deallocate
* Effect:
*	returns off to freelist
****************************************************************************/

static void off_free(off)
off_type off;
{
    off->next = free_off;
    free_off = off;
}

/****************************************************************************
*				off_init
* Effect: initialize this module
* Assumes:
*	only called once, otherwise storage is leaked
****************************************************************************/

static void off_init()
{
    int i;

    if (free_off != (off_type)NULL) return;

    for (i = 0; i < 50; i++)
	off_free(off_alloc());
}

/****************************************************************************
*				off_schedule
* Inputs:
*	long offtime: time to turn note off
*	int voice: the midi channel
*	int pitch: the pitch
* Effect:
*	schedules a note to be turned off
* Assumes:
*	note_offs will be called frequently to actually turn off notes
****************************************************************************/

static void off_schedule(card, dest, offtime, voice, cell, pitch, stime)
unsigned long offtime;
int card, dest, voice, cell, pitch;
unsigned long stime;
{
    off_type off, ptr, prv;
    /* allocate off */
    if ((off = free_off) == NULL) {
	off = off_alloc();
    } else
	free_off = off->next;

    if (off == NULL) {
	fprintf(stderr, "out of space for note off events");
	STOPNOW;
    }
    off->when = offtime;
    off->voice = voice;
    off->pitch = pitch;
    off->dest = dest;
    off->card = card;
    off->cell = cell;
    off->stime = stime;
    /* insert into list of off events */
    ptr = off_events;
    if (ptr == NULL || offtime <= ptr->when) {
	off->next = ptr;
	off_events = off;
    } else {
	while (ptr != NULL && offtime > ptr->when) {
	    prv = ptr;
	    ptr = ptr->next;
	}
	prv->next = off;
	off->next = ptr;
    }
/*
 *    printf("off_schedule(%ld, %d, %d): \n", offtime, voice, pitch);
 *    for (ptr = off_events; ptr != NULL; ptr = ptr->next) {
 *	printf("    %ld: %d, %d\n", ptr->when, ptr->voice, ptr->pitch);
 *    }
 */
}

/*
 * This is the same as a routine in the midifile library.  I don't
 * think it's necessary to duplicate it here any more.
 */
void AWriteVarLen(value)
register long value;
{
    register long buffer;

    buffer = value & 0x7f;
    while ((value >>= 7) > 0) {
	buffer <<= 8;
	buffer |= 0x80;
	buffer += (value & 0x7f);
    }

    while (true) {
	putchar(buffer);
	if (buffer & 0x80)
	    buffer >>= 8;
	else
	    break;
    }
}

/* Calculate time delta for -m option output. */
void deltatime()
{
    float csecs = (float) (time - lasttime);

    AWriteVarLen((long) (((csecs * 10.0) / 4.0 * 96) / 120));
    lasttime = time;
}


/****************************************************************************
*				   f_note
* Inputs:
*	int channel: midi channel on which to send data
*	int pitch: midi pitch code
*	int velocity: velocity with which to sound it (0=> release)
* Effect:
*	Prints a midi note-play request out
****************************************************************************/
/* (arguments have been added to Dannenburg's version) */
static void f_note(card, d, channel, cell, pitch, velocity, stime)
int card, d, channel, cell, pitch, velocity;
unsigned long stime;
{
    if (readable)
	printf("Time=%d  Note %s, chan=%d pitch=%d vol=%d\n",
	       time, velocity ? "on" : "off", channel, pitch, velocity);
    else if (playing_music)
	fm_noteon(card, d, channel - 1, cell, pitch, velocity, stime);
    else {
	deltatime();
	putchar(NOTEON + channel - 1);
	putchar(pitch);
	putchar(velocity);
    }

    if (user_scale) {
	/* check for correct pitch bend */
	if ((pit_tab[pitch].pbend != bend[MIDI_CHANNEL(channel)]) &&
	    (velocity != 0)) {
	    f_bend(card, d, channel, pit_tab[pitch].pbend);
	    bend[channel] = pit_tab[pitch].pbend;
	}
	pitch = pit_tab[pitch].ppitch;
    }
}

/****************************************************************************
*				   f_bend
* Inputs:
*	int channel: midi channel on which to send data
*	int value: pitch bend value
* Effect:
*	Prints a midi pitch bend message
****************************************************************************/

static void f_bend(card, d, channel, value)
int card, d, channel, value;
{

    if (readable)
	printf("Time=%d  Pitchbend, chan=%d value=%d\n",
	       time, channel, value);
    else if (playing_music) {
	if (d) {
	    midisync();
	    midicmdch(PITCHBEND + d - 1);
	    midich(value & 0x7f);
	    midich((value >> 7) & 0x7f);
	}
	fm_bend(card, channel - 1, value - 8192);
    } else {
	deltatime();
	putchar(PITCHBEND + channel - 1);
	putchar(value & 0x7f);
	putchar((value >> 7) & 0x7f);
    }

    bend[MIDI_CHANNEL(channel)] = value;
}

/****************************************************************************
*				   f_ctrl
* Inputs:
*	int channel: midi channel on which to send data
*	int control: control number
*	int value: control value
* Effect:
*	Prints a midi control change message
****************************************************************************/

static void f_ctrl(card, d, channel, control, value)
int card, d, channel, control, value;
{
    if (readable)
	printf("Time=%d  Parameter, chan=%d ctrl=%d value=%d\n",
	       time, channel, control, value);
    else if (playing_music)
	fm_ctrl(card, d, channel - 1, control, value);
    else {
	deltatime();
	putchar(CONTROLLER + channel - 1);
	putchar(control);
	putchar(value);
    }
}

/****************************************************************************
*				 f_program
* Inputs:
*	int channel: Channel on which to send midi program change request
*	int program: Program number to send (decremented by 1 before
*			being sent as midi data)
* Effect:
*	Prints a program change request out the channel
****************************************************************************/

static void f_program(card, d, channel, program)
int card, d;			/* destination */
int channel;			/* midi channel */
int program;			/* the program number */
{
    if (readable)
	printf("Time=%d  Program, chan=%d program=%d\n",
	       time, channel, program);
    else if (playing_music) {
	fm_program(card, d, channel - 1, program - 1);
    }
    else {
	deltatime();
	putchar(PROGRAM + channel - 1);
	putchar(program - 1);
    }
}

/****************************************************************************
*				   f_touch
* Inputs:
*	int channel: midi channel on which to send data
*	int value: control value
* Effect:
*	Prints a midi after touch message
****************************************************************************/

static void f_touch(card, d, channel, value)
int card, d, channel, value;
{
    if (readable)
	printf("Time=%d  Channel pressure, chan=%d value=%d\n",
	       time, channel, value);
    else if (playing_music) {
	if (d) {
	    midisync();
	    midicmdch(CHANPRESSURE + d - 1);
	    midich(value);
if (value > 127) fprintf(stderr, "neg. pressure %d\n", value);
	} else
	    card_touch_all(card, channel - 1, value);
    } else {
	deltatime();
	putchar(CHANPRESSURE + channel - 1);
	putchar(value);
    }
}

#ifndef XMP
/*****************************************************************
*			set_pitch_default
*****************************************************************/
static void set_pitch_default()
{
    int i;

    for (i = 0; i < 128; i++) {
	pit_tab[i].pbend = 8192;
	pit_tab[i].ppitch = i;
    }
}

/*****************************************************************
*			read_tuning
*****************************************************************/

static void read_tuning(filename)
char *filename;
{
    int index, pit, lineno = 0;
    float bend;
    FILE *fpp;

    user_scale = true;
    set_pitch_default();
    fpp = fileopen(filename, "tun", "r", "Tuning definition file");
    while ((fscanf(fpp, "%d %d %f\n", &index, &pit, &bend) > 2) &&
	   (lineno < 128)) {
	lineno++;
	if (index >= -12 && index <= 115) {
	    pit_tab[index + 12].pbend = (int) (8192 * bend / 100 + 8192);
	    pit_tab[index + 12].ppitch = pit;
	}
    }
}
#endif

#ifndef XMP
/****************************************************************************
*				   tuninginit
* Effect:
* Read tuning file
****************************************************************************/

static void tuninginit()
{
    char *filename;

    filename = cl_option("-tune");
    if (filename != NULL) {
	read_tuning(filename);
    }
/*
    if (user_scale) {
        int i;
	for (i = 0; i < NUM_CHANS; i++) {
	    f_bend(0, i+1, 8192);
	    bend[i] = 8192;
	}
    }
*/
}
#endif




/* Here are the routines for low level output to the soundcards. */


/*
 * Some of following code was originally adapted from:
 * fmplay by Hannu Savolainen (hsavolai@cs.helsinki.fi)
 *
 */

#include <sys/ultrasound.h>

/* gus mode bits */
#define Bit8 0
#define Bit16 4
#define LoopOff 0
#define LoopOn 8
#define UniDir 0
#define BiDir 16
#define Forw 0
#define Backw 64
#define Up 0
#define Down 64

/* Current midi program, pitch bend, and channel pressure. */
static int chn_bend[MAXCARDS][16];
static int chn_press[MAXCARDS][16];

/* records used in cell allocation (except the "cell_has" arrays
 * remember info already sent to the cards, to avoid duplication)
 */
static int cell_alloc[MAXCARDS][MAXCELLS];
static long cell_time[MAXCARDS][MAXCELLS];
static long cell_endtime[MAXCARDS][MAXCELLS];
static int cell_chan[MAXCARDS][MAXCELLS];
static int cell_prog[MAXCARDS][MAXCELLS];
static int cell_dest[MAXCARDS][MAXCELLS];
static int cell_has_vel[MAXCARDS][MAXCELLS];
static int cell_has_prog[MAXCARDS][MAXCELLS];
static int cell_has_bend[MAXCARDS][MAXCELLS];
static int cell_has_touch[MAXCARDS][MAXCELLS];
static int cell_pitch[MAXCARDS][MAXCELLS];
static int cell_vel[MAXCARDS][MAXCELLS];
static int cell_hist[MAXCARDS][MAXCELLS];
static int cell_pan[MAXCARDS][MAXCELLS];
static int cell_has_pan[MAXCARDS][MAXCELLS];
static int cell_effect[MAXCARDS][MAXCELLS];
static int cell_has_main_volume[MAXCARDS][MAXCELLS];
static int cell_has_expression[MAXCARDS][MAXCELLS];
#ifdef TRY_VIBRATO
static int cell_vibrato[MAXCARDS][MAXCELLS];
#endif

#ifdef END_DIAGNOSTICS
void hist_report()
{
    int i;

    if (sb_dev >= 0) {
	printf("fm cells: |");
	for (i = 0; i < card_info[sb_dev].nr_voices; i++)
	    printf("%4d |", cell_hist[sb_dev][i]);
	printf("\n          |");
	for (i = 0; i < card_info[sb_dev].nr_voices; i++)
	    printf("[%3d]|", i);
	printf("\n");
    }
    if (gus_dev >= 0) {
	printf("\nwv cells: |");
	for (i = 0; i < card_info[gus_dev].nr_voices / 2; i++)
	    printf("%4d |", cell_hist[gus_dev][i]);
	printf("\n          |");
	for (i = 0; i < card_info[gus_dev].nr_voices / 2; i++)
	    printf("[%3d]|", i);
	printf("\n           -----------------------------------------------");
	printf("\n          |");
	for (i = card_info[gus_dev].nr_voices / 2; i < card_info[gus_dev].nr_voices; i++)
	    printf("%4d |", cell_hist[gus_dev][i]);
	printf("\n          |");
	for (i = card_info[gus_dev].nr_voices / 2; i < card_info[gus_dev].nr_voices; i++)
	    printf("[%3d]|", i);
	printf("\n");
    }
#ifdef XPOLYPHONY
    if (ext_dev >= 0) {
	printf("xm cells: |");
	for (i = 0; i < card_info[ext_index].nr_voices; i++)
	    printf("%4d |", cell_hist[ext_index][i]);
	printf("\n          |");
	for (i = 0; i < card_info[ext_index].nr_voices; i++)
	    printf("[%3d]|", i);
	printf("\n");
    }
#endif
}
#endif

/*
 * Mark cells as not yet in use.
 */
void cells_init()
{
    int i, j;

    for (i = 0; i < MAXCARDS; i++)
	for (j = 0; j < MAXCELLS; j++) {
	    cell_alloc[i][j] = false;
	    cell_prog[i][j] = cell_has_prog[i][j] = cell_endtime[i][j] =
		cell_has_bend[i][j] = cell_has_pan[i][j] =
		cell_time[i][j] = cell_chan[i][j] = cell_pitch[i][j] = -1;
	    cell_has_touch[i][j] = 0;
	}
}

/*
 * Allocate a cell to play a note on.
 */
int new_cell(int card, unsigned long stime, int dest, int chan, int prog,
		int pitch, int vel, int effect)
{
    int i, best = 0, bperc = 0, perc = 0, oldest = 0, same = -1, oldecho = -1;
    int o3_mode = 0;

    /* If it's a 4op fm voice, note this so we know to allocate one of the first
     * six cells.
     */
    if (card == sb_dev && instr_key[(PERCCHAN(chan)) ? pitch + 128 : prog] == OPL3_PATCH)
	o3_mode = 1;

    /* Look through all the cells for the most suitable. */
    for (i = 0; i < card_info[card].nr_voices; i++) {

	/* Stop here if past the last cell eligible for 4op patch. */
	if (o3_mode && i > 5) break;

	/* A cell that is playing the same non-polyphonic voice is good,
	 * because we will cut off the release of the last note when we
	 * play this next one.  (But an echo or chorus note should not cut
	 * off the note it is paired with, so the pitch should differ.  Also,
	 * if the instrument is moving horizontally, we'll consider it to
	 * be a different instrument, so pan position should be the same.)
	 */
	if (cell_chan[card][i] == chan && cell_prog[card][i] == prog &&
	    sub_voice[cell_prog[card][i]].solo && !no_solo &&
	    cell_pitch[card][i] != pitch &&
	    !(cell_effect[card][i] & ECHO_EFFECT) &&
	    cell_pan[card][i] == ext_pan[chan])
	    same = i;

	/* In case a live note must be cut off, good candidates are
	 * a note that has been playing a long time or a drum note
	 * (and preferably an old drum note).
	 */
	if (cell_alloc[card][i]) {
	    if (cell_time[card][i] < cell_time[card][oldest]) {
		oldest = i;
		if (cell_effect[card][oldest] & ECHO_EFFECT) oldecho = i;
	    }
	    if (PERCCHAN(cell_chan[card][i])) {
		if (perc && cell_time[card][i] < cell_time[card][bperc]) bperc = i;
		else bperc = i;
		perc = 1;
	    }
	/* Of the dead notes, best is one that expired a long time ago,
	 * so that we get a better chance to hear the note releases.
	 */
	} else if (cell_endtime[card][i] < cell_endtime[card][best])
	    best = i;
    }

    /* When all cells are in use, the longest playing one is good ... */
    if (cell_alloc[card][best]) {
	best = oldest;
	/* and better is an old echo note. */
	if (oldecho >= 0) best = oldecho;
    }
    /* but since we have to cut off a note, a drum is still better (well,
     * this isn't obvious, but I think missing drum beats are easy to
     * overlook).
     */
    if (cell_alloc[card][best] && perc) best = bperc;

    /* But a note on the same non-polyphonic instrument ought to be cut
     * off (if it is no longer playing, its release ought to be cut off),
     * so this is a still better choice.
     */
    if (same >= 0) {
	/* (Make an exception and let the release sound when maximum
	 * reverberation was requested.)
	 */
	if ((reverberation[chan] < 127 && card == gus_dev)
	    /* For fm, I can't hear any difference here. */
	    /*||(reverberation[chan] < 10 && card == sb_dev)*/ )
	    best = same;
	else if (card == ext_index) best = same;
    }

    /* If the cell we are going to use is still playing a note,
     * turn it off now.
     */
    if (cell_alloc[card][best]) {
	stat_imp_cell_off[card]++;
#ifndef XPOLYPHONY
	if (card != ext_index)
#endif
	fm_noteon(card, cell_dest[card][best], cell_chan[card][best], best,
		cell_pitch[card][best], 0,
		(unsigned long) cell_time[card][best]);
	/* if we just cut off a chorus note, cut off its twin also */
	if ( cell_effect[card][best] & (CHORUS1_EFFECT | CHORUS2_EFFECT) )
	    for (i = 0; i < card_info[card].nr_voices; i++)
	    if (i != best &&
		cell_alloc[card][i] &&
		(cell_effect[card][i] & (CHORUS1_EFFECT | CHORUS2_EFFECT)) &&
		cell_chan[card][i] == cell_chan[card][best] &&
		cell_pitch[card][i] == cell_pitch[card][best])
	    fm_noteon(card, cell_dest[card][i], cell_chan[card][i], i,
		cell_pitch[card][i], 0,
		(unsigned long) cell_time[card][i]);
    }

    /* Do the bookkeeping for the cell that has been allocated. */
    cell_time[card][best] = (long) stime;
    cell_endtime[card][best] = MAXTIME;
    cell_chan[card][best] = chan;
    cell_dest[card][best] = dest;
    if (PERCCHAN(chan)) {
	if (card == sb_dev)
	    cell_prog[card][best] = pitch + 128 - 35;
	else
	    cell_prog[card][best] = pitch + 128;
    } else
	cell_prog[card][best] = prog;
    cell_pitch[card][best] = pitch;
    cell_vel[card][best] = vel;
    cell_pan[card][best] = ext_pan[chan];
    cell_effect[card][best] = effect;
    cell_alloc[card][best] = true;
    spare_cells[card]--;
#ifdef TRY_VIBRATO
    cell_vibrato[card][best] = 0;
#endif
    cell_hist[card][best]++;

    return (best);
}

/*
 * Ask for 14-32 gus voices.
 */
void gus_max_voices(int num)
{
    buf[0] = SEQ_PRIVATE;
    buf[1] = gus_dev;
    buf[2] = _GUS_NUMVOICES;
    buf[3] = 0;
    *(unsigned short *) &buf[4] = num;
    buf[6] = buf[7] = 0;
    sqwrite(buf);
}

/*
 * Send pitch bend request to card.
 */
void card_bend(int card, int chan, int cell)
{
#ifdef TRY_VIBRATO
    int amount = chn_bend[card][chan] + cell_vibrato[card][cell];
#else
    int amount = chn_bend[card][chan];
#endif
/**
    int cents = setting_chorus_spread*(1 + chorus_depth[chan]/16);
**/
#ifdef USE_SHM
    int cents = (*shm_setting_chorus_spread * chorus_depth[chan]) / 16;
#else
    int cents = (setting_chorus_spread * chorus_depth[chan]) / 16;
#endif

    if (cell_effect[card][cell] & CHORUS1_EFFECT)
	amount += cents;
    else if (cell_effect[card][cell] & CHORUS2_EFFECT)
	amount -= cents;

    if (cell_has_bend[card][cell] == amount) return;
    cell_has_bend[card][cell] = amount;

    midisync();

    buf[0] = SEQ_EXTENDED;
    buf[1] = SEQ_CONTROLLER;
    buf[2] = card;
    buf[3] = cell;
    buf[4] = CTRL_PITCH_BENDER;
    *(short *) &buf[5] = amount;
    buf[7] = 0;
    sqwrite(buf);
}

/*
 * Send expression request to card.
 */
void card_expression(int card, int chan, int cell)
{
    int amount = expression[chan];

    if (cell_has_expression[card][cell] == amount) return;
    cell_has_expression[card][cell] = amount;

    midisync();

    buf[0] = SEQ_EXTENDED;
    buf[1] = SEQ_CONTROLLER;
    buf[2] = card;
    buf[3] = cell;
    buf[4] = CTRL_EXPRESSION;
    *(short *) &buf[5] = amount;
    buf[7] = 0;
    sqwrite(buf);
}
/*
 * Send main volume request to card.
 */
void card_main_volume(int card, int chan, int cell)
{
    int amount = main_volume[chan];

    if (cell_has_main_volume[card][cell] == amount) return;
    cell_has_main_volume[card][cell] = amount;

    midisync();

    buf[0] = SEQ_EXTENDED;
    buf[1] = SEQ_CONTROLLER;
    buf[2] = card;
    buf[3] = cell;
    buf[4] = CTRL_MAIN_VOLUME;
    *(short *) &buf[5] = amount;
    buf[7] = 0;
    sqwrite(buf);
}

#ifdef TRY_VIBRATO
#include "vibrato.h"
/*
 * Bend pitch for pitch vibrato.
 */
void fm_vibrate(int card, unsigned long ctime)
{
    int prog, chan, i, vs, period, depth;

#ifdef USE_SHM
    setting_vibrato_depth = *shm_setting_vibrato_depth;
#endif

    /* Check each cell to see if it's playing a note ... */
    for (i = 0; i < card_info[card].nr_voices; i++)
	if (cell_alloc[card][i]) {

	    /* No vibrato on echoes. */
	    if (cell_effect[card][i]&ECHO_EFFECT) continue;
	    chan = cell_chan[card][i];

	    /* No vibrato drums (vibraslap?). */
	    if (PERCCHAN(chan)) continue;

	    /* Set period and depth ad hoc for each instrument. */
	    prog = cell_prog[card][i];
	    if (prog > 127) continue;
	    period = vibrato[prog].period;

	    if (!period) continue;

	    /* How far into this note are we? */
	    vs = ctime - cell_time[card][i];

	    /* Introduce a little variation into starting time of
	     * vibrato for choral effect.
	     */
	    vs -= (chan%8) + (cell_pitch[card][i]%6) + vibrato[prog].delay;

	    /* Time to start the vibrato? */
	    if (vs < 1) continue;

	    /* How far into current period? */
	    vs = (vs % period);

	    /* Change slope of triangle wave modulation at 90 and 270 degrees. */
	    if (vs > period / 4) {
	        if (vs < (3 * period) / 4)
	    	vs = period / 2 - vs;
	        else
	    	vs = period - vs;
	    }

	    depth = (setting_vibrato_depth * vibrato[prog].depth) / 50;

	    /* Height of triangle. */
	    vs = (vs * depth) / (period / 4);

	    /* Make record for offsetting other bend events. */
	    cell_vibrato[card][i] = vs;

	    /* Do it. */
	    card_bend(card, chan, i);
    }
}
#endif

/*
 * Dynamic change of pitch bend.  Bend all card cells playing notes.
 */
void fm_bend(int card, int chan, int value)
{
    int i;

    if (sb_dev >= 0) {
	chn_bend[sb_dev][chan] = value;
	for (i = 0; i < card_info[sb_dev].nr_voices; i++)
	    if (cell_alloc[sb_dev][i] && cell_chan[sb_dev][i] == chan)
		card_bend(sb_dev, chan, i);
    }
    if (gus_dev >= 0) {
#ifdef USE_SHM
	chn_bend[gus_dev][chan] = value + *shm_setting_gus_tuning;
#else
	chn_bend[gus_dev][chan] = value + setting_gus_tuning;
#endif
	for (i = 0; i < card_info[gus_dev].nr_voices; i++)
	    if (cell_alloc[gus_dev][i] && cell_chan[gus_dev][i] == chan)
		card_bend(gus_dev, chan, i);
    }
}

/*
 * Send channel aftertouch to card.
 */
void card_touch(int card, int chan, int cell)
{
    int touch = (0xe0&chn_press[card][chan]);

    if (cell_has_touch[card][cell] == touch) return;
    cell_has_touch[card][cell] = touch;

    buf[0] = SEQ_EXTENDED;
    buf[1] = SEQ_AFTERTOUCH;
    buf[2] = card;
    buf[3] = cell;
    buf[4] = chn_press[card][chan];
    buf[5] = buf[6] = buf[7] = 0;
    sqwrite(buf);
}

/*
 * Dynamic change of aftertouch.  Touch all card cells playing notes.
 */
void card_touch_all(int card, int chan, int value)
{
    int i;

    midisync();
    if (sb_dev >= 0) {
	chn_press[sb_dev][chan] = value;
	for (i = 0; i < card_info[sb_dev].nr_voices; i++)
	    if (cell_alloc[sb_dev][i] && cell_chan[sb_dev][i] == chan)
		card_touch(sb_dev, chan, i);
    }
    if (gus_dev >= 0) {
	chn_press[gus_dev][chan] = value;
	for (i = 0; i < card_info[gus_dev].nr_voices; i++)
	    if (cell_alloc[gus_dev][i] && cell_chan[gus_dev][i] == chan)
		card_touch(gus_dev, chan, i);
    }
}

/*
 * Dynamic volume change to fm card.  (Needs work -- too loud.)
 */
void sb_vol(int chan, int prog, int cell, int vol)
{
    /* vol = (main_volume[chan] * expression[chan] * vol) >> 14; */
    if (vol > 127) vol = 127;
    /* if (vol == cell_has_vel[sb_dev][cell]) return; */
    cell_has_vel[sb_dev][cell] = vol;
/**
    buf[0] = SEQ_EXTENDED;
    buf[1] = SEQ_NOTEON;
    buf[2] = sb_dev;
    buf[3] = cell;
    buf[4] = 255;
    buf[5] = vol;
    buf[6] = buf[7] = 0;
    sqwrite(buf);
**/
}

#ifdef USE_OWN_GUS_VOL

/*
 * Calculate gus volume from note velocity, main volume, expression,
 * and intrinsic patch volume given in patch library.  Expression is
 * multiplied in, so it emphasizes differences in note velocity,
 * while main volume is added in -- I don't know whether this is right,
 * but it seems reasonable to me.  (In the previous stage, main volume
 * controller messages were changed to expression controller messages,
 * if they were found to be used for dynamic volume adjustments, so here,
 * main volume can be assumed to be constant throughout a song.)
 *
 * Intrinsic patch volume is added in, but if over 64 is also multiplied
 * in, so we can give a big boost to very weak voices like nylon
 * guitar and the basses.
 */
unsigned short
gvol(int vel, int mainv, int xpn, int voicev)
{
	int i, m, n, x;

	if (xpn <= 0 || vel == 0) return(11 << 8);
	xpn += 8;

	/* A voice volume of 64 is considered neutral, so adjust
	 * the main volume if something other than this neutral
	 * value was assigned in the patch library.
	 */
	x = mainv + 6*(voicev - 64);
	if (x < 0) x = 0;

	/* Boost expression by voice volume above neutral. */
	/* if (voicev > 65) xpn += (voicev-64)/2; */
	if (voicev > 65) xpn += voicev-64;
	xpn += (voicev-64)/2;

	/* Combine multiplicative and level components. */
	x = vel*xpn*2 + (voicev/4)*x;

	/* Further adjustment by installation-specific master
	 * volume control (default 100).
	 */
#ifdef USE_SHM
	setting_gus_volume = *shm_setting_gus_volume;
#endif
	x = (x*setting_gus_volume*setting_gus_volume)/10000;

	if (x < 1) return(0);
	else if (x > 65535) {
		x = 65535;
		gus_clip_statistic++;
	}

	/* Convert to gus's logarithmic form with 4 bit exponent i
	 * and 8 bit mantissa m.
	 */
	n = x;
	i = 7;
	if (n < 128) {
		while (i > 0 && n < (1<<i)) i--;
	}
	else while (n > 255) {
		n >>= 1;
		i++;
	}
	/* Mantissa is part of linear volume not expressed in
	 * exponent.  (This is not quite like real logs -- I wonder
	 * if it's right.)
	 */
	m = x - (1<<i);

	/* Adjust mantissa to 8 bits. */
	if (m > 0) {
		if (i > 8) m >>= i-8;
		else if (i < 8) m <<= 8-i;
	}

	if (i < 11) return(11 << 8);
	return((i << 8) + m);
}


/*
 * Send volume to gus.
 */
void gus_vol(int chan, int prog, int cell, int vol, int flag)
{
    int top_vol = gvol(vol, main_volume[chan],
	expression[chan], gus_voice[prog].volume);
    if (top_vol > 4095) {
	gus_clip_statistic++;
    }
    buf[0] = SEQ_PRIVATE;
    buf[1] = gus_dev;
    buf[2] = _GUS_VOICEVOL2;
    buf[3] = cell;
    *(unsigned short *) &buf[4] = top_vol;
    buf[6] = buf[7] = 0;
    sqwrite(buf);

    if (!flag) return;
    buf[0] = SEQ_PRIVATE;
    buf[1] = gus_dev;
    buf[2] = _GUS_VOICEVOL;
    buf[3] = cell;
    *(unsigned short *) &buf[4] = top_vol;
    buf[6] = buf[7] = 0;
    sqwrite(buf);
}

#endif

/*
 * Calculate and send pan to gus.  Reduce pan controller range 0-127
 * to gus range 0-15.  Add pseudo-stereo effects.
 */
void gus_pan(int cell, int pan)
{
    int disturb = 0;

    /* Remember requested value (not what is actually sent to gus,
     * so new_cell() can permit note releases to sound when instrument
     * is changing locations.
     */
    cell_pan[gus_dev][cell] = pan;
    /* Reduce range: 64, center, must come out to 7, center. */
    pan = ((pan + 1) >> 3) - 1;
    if (pan < 0)
	pan = 0;
    if (pan > 15) {
	fprintf(stderr,"warning: pan out of range\n");
	return;
    }

#ifdef PSEUDO_STEREO
    if (cell_effect[gus_dev][cell] & CHORUS1_EFFECT) {
	pan -= 4;
	if (pan < 0) pan = 0;
    }
    else if (cell_effect[gus_dev][cell] & CHORUS2_EFFECT) {
	pan += 4;
	if (pan > 15) pan = 15;
    }
#ifdef USE_SHM
    setting_pstereo = *shm_setting_pstereo;
#endif

    /* Echoes come from a different direction. */
    if (cell_effect[gus_dev][cell] & ECHO_EFFECT) disturb = 3;
    /* If they're close up (no reverb) and you are behind the pianist,
     * high notes come from the right, so we'll spread piano etc. notes
     * out horizontally according to their pitches.
     */
    else if (cell_prog[gus_dev][cell] < 21 &&
	reverberation[ cell_chan[gus_dev][cell] ] < 20) {
	    int n = (cell_pitch[gus_dev][cell] - 32)/8;
	    if (n < 0) n = 0;
	    if (n > 8) n = 8;
	    if (setting_pstereo) pan = pan/2 + n;
	}
    /* For other types of instruments, the music sounds more alive if
     * notes come from slightly different directions.  However, instruments
     * do drift around in a sometimes disconcerting way, so the following
     * might not be such a good idea.
     */
    else if (setting_pstereo) disturb = (cell_vel[gus_dev][cell]/32 % 2) +
	(cell_pitch[gus_dev][cell] % 2); /* /16? */

    if (pan < 7) pan += disturb;
    else pan -= disturb;
#endif

    /* Don't send redundant pans. */
    if (cell_has_pan[gus_dev][cell] == pan) return;
    cell_has_pan[gus_dev][cell] = pan;

    buf[0] = SEQ_PRIVATE;
    buf[1] = gus_dev;
    buf[2] = _GUS_VOICEBALA;
    buf[3] = cell;
    *(unsigned short *) &buf[4] = pan;
    *(unsigned short *) &buf[6] = 0;
    sqwrite(buf);
}

/*
 * Start or stop a note -- all devices. (vol=0 stops the note.)
 */
void fm_noteon(int card, int d, int chan, int cell, int pitch, int vol, unsigned long stime)
{
    int nominal_pitch;

    /* In case the program is not changed, it will be the one requested. */
    int prog = cell_prog[card][cell];

#ifdef XMP
    int col = chan;
    if (setting_meter_column == 1) {
	if (PERCCHAN(chan)) col = 12 + (pitch % 4);
	else col = pitch % 12;
    }
    else if (setting_meter_column == 2) {
	if (PERCCHAN(chan)) col = 14;
	else col = (prog%128) / 8;
    }
#endif

    /* time delta to /dev/sequencer */
    if (vol) midisync();

#ifdef XMP
    /* for xmp meter */
    if (vol) {
	curr_note_count[col]++;
	curr_note_velocity[col] += vol;
	inst_note_count[col]++;
	inst_note_velocity[col] += vol;
    }
#endif
    /* note goes to external synth? */
    if (d && vol) {
	/* bookkeeping */
	stat_note_on[ext_index]++;
	spare_cells[ext_index]--;
	midicmdch(NOTEON + d - 1);
	midich(pitch);
	midich(vol);
if (pitch > 127) fprintf(stderr, "neg. pitch %d\n", pitch);
if (vol > 127) fprintf(stderr, "neg. vol %d\n", vol);
	return;
    }

    /* Adjust velocity of an fm note according to current main volume
     * and expression. (Dynamic volume change doesn't seem to be working.)
     */

    if (card == sb_dev && vol) {
	vol += (expression[chan] - 64) / 16;
	if (vol < 8) vol = 8;
	else if (vol > 127) vol = 127;
    }


    /* We are about to adjust the pitch and program, but for bookkeeping purposes,
     * remember the requested pitch.
     */
    nominal_pitch = pitch;

    /* Special treatment of percussion notes for fm: */
    if (card == sb_dev && PERCCHAN(chan)) {
	/* Requested pitch is really program, and pitch for device is whatever
	 * was specified in the patch library.
	 */
	if (v_drum) pitch = dnote[prog];

    /* Special treatment of percussion notes for gus: */
    } else if (card == gus_dev && PERCCHAN(chan)) {
	/* as for fm, except for details */
	if (gus_voice[prog].loaded) {
	    pitch = gus_voice[prog].lowest - 12;
	} else
	    return;
    }

    /* Stop the note? */
    if (!vol) {
	/* Try to detect case in which note was prematurely terminated
	 * by a call from new_cell(), since we don't want to turn it
	 * off twice (the cell will be in use for playing some other
	 * note, so this would be very undesirable).
	 */
#ifndef XPOLYPHONY
	if (card != ext_index)
#endif
	if (!cell_alloc[card][cell]
	    || cell_time[card][cell] != (long) stime
	    || cell_chan[card][cell] != chan
	    || cell_pitch[card][cell] != nominal_pitch) {
	    return;
	}

#ifdef XMP
	if (inst_note_count[col]) {
	    inst_note_count[col]--;
	    if (inst_note_velocity[col] > cell_vel[card][cell])
		inst_note_velocity[col] -= cell_vel[card][cell];
	    else inst_note_velocity[col] = 0;
	}
#endif

	fm_noteoff(card, d, chan, prog, cell, pitch, 0, stime);
	return;
    }

    /* The remainder of this routine deals with the cells on the cards,
     * which we can actually control.  If this is a note for the
     * external synth, all we can to is turn it on or off, so we're done.
     */
    if (card == ext_index) return;

    /* Set the program, if different from the one requested. */
    if (cell_has_prog[card][cell] != prog) {
	cell_has_prog[card][cell] = prog;
	buf[0] = SEQ_EXTENDED;
	buf[1] = SEQ_PGMCHANGE;
	buf[2] = card;
	buf[3] = cell;
	buf[4] = prog;
	buf[5] = buf[6] = buf[7] = 0;
	sqwrite(buf);
    }

    /* Do any pitch bending. */
    if (chn_bend[card][chan]) card_bend(card, chan, cell);

    /* Do any aftertouch. */
    card_touch(card, chan, cell);

    /* bookkeeping */
    stat_note_on[card]++;

    if (card == gus_dev) {
#ifdef USE_OWN_GUS_VOL
	gus_vol(chan, prog, cell, vol, 0);
#else
	card_expression(card, chan, cell);
	card_main_volume(card, chan, cell);
#endif
    }
    else if (card == sb_dev)
	sb_vol(chan, prog, cell, (expression[chan]*vol)/128);

    /* request note on to driver */
    buf[0] = SEQ_EXTENDED;
    buf[1] = SEQ_NOTEON;
    buf[2] = card;
    buf[3] = cell;
    buf[4] = pitch;
#ifdef USE_OWN_GUS_VOL
    if (card == gus_dev)
	buf[5] = 255;
    else
/* next line ought not to be there */
    /*buf[5] = 255;*/
#else
    buf[5] = vol;
#endif
    buf[6] = buf[7] = 0;
    sqwrite(buf);
    cell_has_vel[card][cell] = vol;

    /* Set direction: 64 for center, if there were no pan controller
     * messages.
     */
    if (ext_pan[chan] >= 0) gus_pan(cell, ext_pan[chan]);
    else gus_pan(cell, 64);
}

/*
 * Turn off a note -- all devices.  (Actually, for the external synth it's already
 * been turned off, and we're just doing bookkeeping here.)
 */
void fm_noteoff(int card, int d, int chan, int prog, int cell, int pitch,
		int vol, unsigned long stime)
{
    midisync();
    stat_note_off[card]++;
    cell_has_vel[card][cell] = vol;

    if (card == sb_dev || card == gus_dev) {
	buf[0] = SEQ_EXTENDED;
	buf[1] = SEQ_NOTEOFF;
	buf[2] = card;
	buf[3] = cell;
	buf[4] = pitch;
	buf[5] = vol;
	buf[6] = buf[7] = 0;
	sqwrite(buf);
    }
    else if (card == ext_index) {
	midicmdch(NOTEON + d - 1);
	midich(pitch);
	midich(0);
    }
    cell_alloc[card][cell] = false;
    spare_cells[card]++;
    cell_endtime[card][cell] = (long) stime;
}

/*
 * Send a controller message -- all devices.
 */
void fm_ctrl(int card, int d, int chan, int control, int value)
{
    int i;

    midisync();

    if (d) {
#ifdef K1
/* no expression controller for K1, so use volume */
	if (control == EXPRESSION) {
	    control = VOLUME;
	    /* much below 64 is inaudible */
	    value = 64 + value/2;
	}
#endif
	midicmdch(CONTROLLER + d - 1);
	midich(control);
	midich(value);
if (control > 127) fprintf(stderr, "neg. controller %d\n", control);
if (value > 127) fprintf(stderr, "neg. controller value %d\n", value);
	return;
    }
    if (control == EXPRESSION)
	for (i = 0; i < card_info[card].nr_voices; i++)
	    if (cell_alloc[card][i] && cell_chan[card][i] == chan) {
		if (card == sb_dev)
		    sb_vol(chan, cell_prog[card][i], i, cell_vel[card][i]);
		else if (card == gus_dev)
#ifdef USE_OWN_GUS_VOL
		    gus_vol(chan, cell_prog[card][i], i, cell_vel[card][i], 1);
#else
		    card_expression(card, chan, i);
#endif
	    }

    if (card != gus_dev) return;

    if (control == PAN)
	for (i = 0; i < card_info[card].nr_voices; i++)
	    if (cell_alloc[card][i] && cell_chan[card][i] == chan)
		gus_pan(i, value);
}

/*
 * Send change program to (non-K1) external synth.
 */
void fm_program(int card, int d, int chan, int program)
{
#ifndef K1
/* K1 can't remember channel programs */
    if (d) {
	midicmdch(PROGRAM + d);
	midich(program);
	return;
    }
#endif
}

/*
 * Send sync time to /dev/sequencer -- centiseconds
 * since last time sync.
 */
void midisync(void)
{
    unsigned long jiffies;

    static unsigned long prevtime = 0;

    if (time == 0) prevtime = 0;
    jiffies = time;
    if (jiffies & 0xff000000) {
	fprintf(stderr, "error: excessively long sync time\n");
	STOPNOW;
    }
    if (jiffies > prevtime) {
	prevtime = jiffies;
	jiffies = (jiffies << 8) | SEQ_WAIT;
	sbwrite((char *) &jiffies);
    } else if (jiffies < prevtime) {
	fprintf(stderr, "(warning: %dcsec negative sync time)\n", prevtime - jiffies);
	prevtime = jiffies;
    }
}

#ifdef MIDIIN

/*
 * Ask driver if there is midi input pending.
 */
int midipending(void)
{
    int tmp;
    if (ext_dev < 0)
	return (0);
    ioctl(seq_fd, SNDCTL_SEQ_GETINCOUNT, &tmp);
    return(tmp);
}

/*
 * Get one byte from midi input port.
 */
int midigetc(void)
{
    int l, havemidi;
    int attempts;

    attempts = 0;
    havemidi = 0;
    while (!havemidi) {
	attempts++;
	if (attempts > 2)
	    fprintf(stderr, "problem reading midi input after %d attempts\n", attempts);
	if ((l = read(seq_fd, buf, 4)) == -1) {
	    perror("midi get /dev/sequencer");
	    STOPNOW;
	}
	if (l != 4) {
	    fprintf(stderr, "error: could only read %d of 4 bytes seq. input\n", l);
	    STOPNOW;
	}
	if (buf[0] == SEQ_WAIT) {
	    sb_time = buf[1] + (buf[2] << 8) + (buf[3] << 16);
	} else if (buf[0] == SEQ_MIDIPUTC)
	    havemidi = 1;
    }
    return (buf[1]);
}

/*
 * Non-blocking input of one byte from midi input port.
 */
int midigetnb()
{
    if (midipending())
	return (midigetc());
    return (-1);
}

/* following 2 routines adapted from midifile.c,
 * by Tim Thompson and M. Czeisperger
 */
/*
 * Call a midifile library routine to write a midi message to
 * the recording file.
 */
static void chanmessage(status, c1, c2)
int status;
int c1, c2;
{
    int chan = recording_channel - 1;
    unsigned char data[2];

    data[0] = c1;
    data[1] = c2;

    switch (status & 0xf0) {
    case 0x80:
	mf_write_midi_event(getdelta(), MIDI_OFF_NOTE, chan, data, 2);
	break;
    case 0x90:
	mf_write_midi_event(getdelta(), MIDI_ON_NOTE, chan, data, 2);
	break;
    case 0xa0:
	mf_write_midi_event(getdelta(), MIDI_POLY_TOUCH, chan, data, 2);
	break;
    case 0xb0:
	if (c1 != 123)
	    mf_write_midi_event(getdelta(), MIDI_CTRL, chan, data, 2);
	break;
    case 0xc0:
	mf_write_midi_event(getdelta(), MIDI_CH_PROGRAM, chan, data, 1);
	break;
    case 0xd0:
	mf_write_midi_event(getdelta(), MIDI_TOUCH, chan, data, 1);
	break;
    case 0xe0:
	mf_write_midi_event(getdelta(), MIDI_BEND, chan, data, 2);
	break;
    }
}

/*
 * Get bytes from midi input port, so long as any are available,
 * and build up a midi message from them.  When message is complete,
 * call chanmessage() to write it out to the recording file.
 */
static void midimessage()
{
    /* This array is indexed by the high half of a status byte.  It's */
    /* value is either the number of bytes needed (1 or 2) for a channel */
    /* message, or 0 (meaning it's not  a channel message). */
    static int chantype[] =
    {
	0, 0, 0, 0, 0, 0, 0, 0,	/* 0x00 through 0x70 */
	2, 2, 2, 2, 1, 1, 2, 0	/* 0x80 through 0xf0 */
    };
    static int c = -1, c1 = -1, c2 = -1;
    static int running = 0;	/* 1 when running status used */
    static int status = 0;	/* status value (e.g. 0x90==note-on) */
    int needed;


    if (c == -1) {
	c = midigetnb();
	if (c == -1)
	    return;
    }
    if ((c & 0x80) == 0) {	/* running status? */
	if (status == 0) {
	    mferror("warning: unexpected midi input running status");
	    c = c1 = c2 = -1;
	    return;
	}
	running = 1;
    } else {
	status = c;
	running = 0;
    }

    needed = chantype[(status >> 4) & 0xf];

    if (needed) {		/* ie. is it a channel message? */

	if (running)
	    c1 = c;
	else if (c1 == -1) {
	    c1 = midigetnb();
	    if (c1 == -1)
		return;
	}
	if (c1 & 0x80) {
	    c = c1;
	    c1 = c2 = -1;
	    return;
	}
	if (needed > 1) {
	    if (c2 == -1)
		c2 = midigetnb();
	    if (c2 == -1)
		return;
	} else
	    c2 = 0;

	if (c2 & 0x80) {
	    c = c2;
	    c1 = c2 = -1;
	    return;
	}
	chanmessage(status, c1, c2);
	c = c1 = c2 = -1;
    } else
	mferror("apparent non-channel message");
}
#endif
