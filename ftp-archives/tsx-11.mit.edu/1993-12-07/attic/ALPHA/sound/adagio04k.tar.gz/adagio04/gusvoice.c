/* gusvoice.c, adapted (slightly) from gusload.c by H. Savolainen, --gl */

#include <stdio.h>
#include <sys/ultrasound.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <strings.h>
#include <unistd.h>
#include <fcntl.h>
#include "adagio.h"
#include "allphase.h"
#include "gusvoice.h"

  struct pat_header {
      char magic[12];
      char version[10];
      char copyright[60];
      char fill[3];
      char nr_samples;
/** new:
    char            magic[12];
    char            version[10];
    char            description[60];
    unsigned char   instruments;
    char            voices;
    char	    channels;
    unsigned short  nr_waveforms;
    unsigned short  master_volume;
    unsigned long   data_size;
**/
  };

  struct sample_header {
    char            name[7];
    unsigned char   fractions;
    long            len;
    long            loop_start;
    long            loop_end;
    unsigned short  base_freq;
    long            low_note;
    long            high_note;
    long            base_note;
    short           detune;
    unsigned char   panning;

    unsigned char   envelope_rate[6];
    unsigned char   envelope_offset[6];

    unsigned char   tremolo_sweep;
    unsigned char   tremolo_rate;
    unsigned char   tremolo_depth;

    unsigned char   vibrato_sweep;
    unsigned char   vibrato_rate;
    unsigned char   vibrato_depth;

    char	    modes;

    int		scale_frequency;
    unsigned int	scale_factor;		/* from 0 to 2048 or 0 to 2 */
	
    int		volume;
    int		spare[4];
    char data[0];	/* The waveform data starts here */
  };


struct patch_info *patch;

static int patch_mem_used = 0;
static int patch_mem_avail = 0;
static int total_patch_mem_avail = 0;

static char *vdata = NULL;

#ifndef SBDIR
#define SBDIR "/etc"
#endif

#ifndef GUSPATDIR
#define GUSPATDIR "/dos/ultrasnd/midi"
#endif

#define GUSPATSLDIR GUSPATDIR##"/"
#define SBSTDLIB SBDIR##"/"##"std.gus"
#define SBDRUMLIB SBDIR##"/"##"drums.gus"

#define OLDGUSVOICESIZE 646
#define NEWERGUSVOICESIZE 450
#define GUSVOICESIZE 112

int gusvoice(int pgm, int reverb)
{
    static int std_fd = -1;
    static int drum_fd = -1;
    int lib_fd;
    char *libname;

    int i, patfd, tmp;
    struct pat_header *header;
    struct sample_header sample;
    char buf[256];
    long offset;
    char *fname;
    char patfname[80];


    if (gus_dev < 0) return(0);

    if (pgm == -1) {
	for (i = 0; i <= 128+81; i++) gus_voice[i].loaded = 0;
	patch_mem_used = 0;
	patch_mem_avail = -1;
	return(0);
    }
    if (pgm < 0 || (pgm > 127 && pgm < 128 + 35) || pgm > 128 + 81)
	return (0);
    if (gus_voice[pgm].loaded)
	return (1);

    tmp = gus_dev;
    ioctl(seq_fd, SNDCTL_SYNTH_MEMAVL, &tmp);
    if (patch_mem_avail < 0) total_patch_mem_avail = tmp;
    patch_mem_avail = tmp;
    if (total_patch_mem_avail <= 0) {
	fprintf(stderr, "warning: no memory found on gus\n");
	return(0);
    }
    patch_mem_used = total_patch_mem_avail - patch_mem_avail;

    if (gus_voice[pgm].mem_req > patch_mem_avail) {
	return (0);
    }
    if (pgm <= 127) {
	libname = SBSTDLIB;
	if (std_fd < 0 && (std_fd = open(libname, O_RDONLY, 0)) == -1) {
	    perror(libname);
	    exit(1);
	}
	lib_fd = std_fd;
	offset = pgm * GUSVOICESIZE;
    } else {
	libname = SBDRUMLIB;
	if (drum_fd < 0 && (drum_fd = open(libname, O_RDONLY, 0)) == -1) {
	    perror(libname);
	    exit(1);
	}
	lib_fd = drum_fd;
	offset = (pgm - 128 - 27) * GUSVOICESIZE;
    }
    if (lseek(lib_fd, offset, 0) == -1) {
	perror(libname);
	exit(1);
    }
    if (vdata == NULL)
	vdata = (char *) malloc(GUSVOICESIZE);
    if (vdata == NULL) {
	fprintf(stderr, "out of memory\n");
    }
    if (read(lib_fd, vdata, GUSVOICESIZE) != GUSVOICESIZE) {
	fprintf(stderr, "%s: Short .pat file\n", libname);
	exit(1);
    }
    header = (struct pat_header *) vdata;

    fname = header->copyright;
    if (fname == NULL || !*fname) {
	fprintf(stderr, "%s: defective lib\n", libname);
	exit(1);
    }
    strcpy(patfname, GUSPATSLDIR);
    fname += strlen(fname) - 1;
    while (fname > header->copyright && *fname != '/')
	fname--;
    strcat(patfname, fname + 1);

    gus_voice[pgm].rscale = header->version[0];
    gus_voice[pgm].rrate = header->version[1];
    gus_voice[pgm].rtop = header->version[2];
    gus_voice[pgm].rbot = header->version[3];
    gus_voice[pgm].rampmode = header->version[4];
    gus_voice[pgm].sustain = header->version[5];
    gus_voice[pgm].volume = header->version[6];
    if (header->version[7])
	gus_voice[pgm].lowest = gus_voice[pgm].highest = header->version[7] + 12;

    if (gus_voice[pgm].rscale > 3 || gus_voice[pgm].rrate > 63)
	gus_voice[pgm].rrate = 0;
    if (gus_voice[pgm].sustain > 118)
	gus_voice[pgm].sustain = 118;

/**
printf("gus_voice: pgm %d, rscale %d, rrate %d, rtop %d, rbot %d, rampmode %d\n", pgm,
gus_voice[pgm].rscale,
gus_voice[pgm].rrate,
gus_voice[pgm].rtop,
gus_voice[pgm].rbot,
gus_voice[pgm].rampmode);
**/

    if ((patfd = open(patfname, O_RDONLY, 0)) == -1) {
	perror(patfname);
	exit(-1);
    }
    offset = 0xef;


    for (i = 0; i < header->nr_samples; i++) {

    if (lseek (patfd, offset, 0) == -1) {
	perror(patfname);
	exit (-1);
    }

    if (read (patfd, &buf, sizeof (sample)) != sizeof (sample)) {
	fprintf (stderr, "%s: Short file\n", patfname);
	exit (-1);
    }

    memcpy ((char *) &sample, buf, sizeof (sample));

    /*
     * Since some fields of the patch record are not 32bit aligned, we must
     * handle them specially.
     */
    sample.low_note = *(long *) &buf[22];
    sample.high_note = *(long *) &buf[26];
    sample.base_note = *(long *) &buf[30];
    sample.detune = *(short *)&buf[34];
    sample.panning = (unsigned char)buf[36];

    memcpy(sample.envelope_rate, &buf[37], 6);
    memcpy(sample.envelope_offset, &buf[43], 6);

    sample.tremolo_sweep = (unsigned char) buf[49];
    sample.tremolo_rate = (unsigned char) buf[50];
    sample.tremolo_depth = (unsigned char) buf[51];

    sample.vibrato_sweep = (unsigned char) buf[52];
    sample.vibrato_rate = (unsigned char) buf[53];
    sample.vibrato_depth = (unsigned char) buf[54];
    sample.modes = (unsigned char) buf[55];
    sample.scale_frequency = *(short *)&buf[56];
    sample.scale_factor = *(unsigned short *)&buf[58];

    offset = offset + 96;

    patch = (struct patch_info *) malloc(sizeof(*patch) + sample.len);

    patch->key = GUS_PATCH;
    patch->device_no = gus_dev;
    patch->instr_no = pgm;
    patch->mode = sample.modes | WAVE_TREMOLO |
                                 WAVE_VIBRATO | WAVE_SCALE;
    patch->len = sample.len;
    patch->loop_start = sample.loop_start;
    patch->loop_end = sample.loop_end;
    patch->base_note = sample.base_note;
    patch->high_note = sample.high_note;
    patch->low_note = sample.low_note;
    patch->base_freq = sample.base_freq;
    patch->detuning = sample.detune;
    patch->panning = (sample.panning - 7) * 16;

    memcpy(patch->env_rate, sample.envelope_rate, 6);
    memcpy(patch->env_offset, sample.envelope_offset, 6);

	if (reverb > 0 && setting_reverb && pgm < 120)
		patch->env_rate[3] = (2<<6) | (8 - (reverb>>3));

    patch->tremolo_sweep = sample.tremolo_sweep;
    patch->tremolo_rate = sample.tremolo_rate;
    patch->tremolo_depth = sample.tremolo_depth;

    patch->vibrato_sweep = sample.vibrato_sweep;
    patch->vibrato_rate = sample.vibrato_rate;
    patch->vibrato_depth = sample.vibrato_depth;

    patch->scale_frequency = sample.scale_frequency;
    patch->scale_factor = sample.scale_factor;

/*      patch->volume = header.master_volume; */
      patch->volume = header->version[6];

	if (lseek(patfd, offset, 0) == -1) {
	    perror(patfname);
	    exit(-1);
	}
	if (read(patfd, patch->data, sample.len) != sample.len) {
	    fprintf(stderr, "%s: Short file\n", patfname);
	    exit(-1);
	}
	if (write(seq_fd, (char *) patch, sizeof(*patch) + sample.len) == -1) {
	    /*patch_mem_used = patch_mem_avail;*/
	    close(patfd);
	    free(patch);
	    return (0);
	}
	offset += sample.len;
	patch_mem_used += sample.len;
	free(patch);
    }


    close(patfd);
    gus_voice[pgm].loaded = 1;

    if (verbose)
	printf("%s, %d mem used of %d, %d still free\n", fname+1/*gus_voice[pgm].vname*/,
	       patch_mem_used, total_patch_mem_avail, total_patch_mem_avail - patch_mem_used);
    return (1);
}
