/*
 *      Copyright (C) 1993 Bas Laarhoven.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 $Source: /usr/src/distr/driver/RCS/ftape-io.c,v $
 $Author: bas $
 *
 $Revision: 1.1 $
 $Date: 1993/06/30 22:41:48 $
 $Locker:  $
 $State: Alpha $
 *
 *      This file contains some general functions
 *      for the QIC-40/80 floppy-tape driver for Linux.
 *
 $Log: ftape-io.c,v $
 * Revision 1.1  1993/06/30  22:41:48  bas
 * Initial revision
 *
 */

static char RCSid[] = "$Id: ftape-io.c,v 1.1 1993/06/30 22:41:48 bas Alpha $";


#include <linux/errno.h>
#include <linux/sched.h>
#include <asm/segment.h>
#include <asm/system.h>

#include "qic117.h"
#include "fdc-io.h"
#include "ftape-io.h"
#include "ftape-rw.h"
#include "ftape-ioctl.h"
#include "kernel-interface.h"

extern void (*do_floppy)(void); /* declared in ../../blk_drv/blk.h */

/*      Global vars.
 */
/* NOTE: sectors start numbering at 1, all others at 0 ! */
int segments_per_track = 102;
int segments_per_head = 1020;
int segments_per_cylinder = 4;
int sectors_per_segment = 32;
int tracks_per_tape = 20;
int ftape_track = -1;
int ftape_failure = 1;
int ftape_chr_pos = 0;
int ftape_seg_pos = 0;
int bad_sector_table_full = 0;

/*      Local vars.
 */
static int drive_type = DRIVE_IS_UNKNOWN;
static void (*oldvect)();
static int check_restrictions = 1;
/*      command-restrictions is a table according
 *      to the QIC-117 specs specifying the state
 *      the drive status should be in at command execution.
 */
struct qic117_command_restriction restrictions[] = QIC117_RESTRICTIONS;
static ftape_error ftape_errors[] = QIC117_ERRORS;
static char* ftape_cmds[] = QIC117_COMMANDS;


/*****************************************************************
 *      Stolen next part from Hennus' QIC-02 code
 *      TIMING IS STILL INCORRECT, BUT ALSO NOT THAT CRITICAL ANYMORE.
 *      THIS STILL NEEDS TO BE IMPLEMENTED PROPERLY (28-06-93 SJL)
 */

# define SUB_PER_CYCLE	32		/* More than 0, less than, say 100. */
# define DELAY_LOOP(count,steps)	DELAY_LOOP2(count, steps)
# define DELAY_LOOP2(count,steps)	\
	__asm__ __volatile__("\n1:\tsubl $" #steps ",%0;jns 1b" \
			     :"=r" (count):"0" (count));

static unsigned int usec_loop_iter_count = 200;

/* This should provide a portable accurate delay
 * measured in microseconds. The multiplication factor
 * is determined during booting. You should not use this
 * for delays larger than a few milliseconds.
 *
 * The delay is expected to be accurate to 1%, but will be
 * a bit less for short delays.
 *
 * Note that the setup time is not accounted for.
 */
static __inline__ void udelay(int usecs)
{
	usecs *= usec_loop_iter_count;	/* Beware of overflows here */
	DELAY_LOOP(usecs, SUB_PER_CYCLE);
}

/*      End of theft
 ****************************************************************/


/*      Delay (msec) routine.
 */
void
ftape_sleep( unsigned int time) {

  unsigned long flags;
  int ticks = 1 + (time + MSPT - 1) / MSPT;
  /*    minimum error: + 0   MSPT
   *    average error: + 0.5 MSPT
   *    maximum error: + 1.0 MSPT
   */
  if (time < MSPT) {
    /*  Time too small for scheduler, do a busy wait ! */
    udelay( 1000 * time);
  } else {

    TRACEi( 2, "ftape_sleep", "milliseconds:", time);
    TRACEi( 2, "ftape_sleep", "       ticks:", ticks);

    current->timeout = jiffies + ticks;
    current->state = TASK_INTERRUPTIBLE;
    save_flags(flags);
    sti();
    
    do {
      schedule();
    } while (current->timeout > 0);
    
    restore_flags(flags);
  }
}

/* forward */ int ftape_report_raw_drive_status( int *status);

/*      Issue a tape command:
 *      Generate command # of step pulses.
 */
int
ftape_command( int command)
{
  int result;
  int track;

  TRACEi( 1, "ftape_command", "called with command =", command);
  if (check_restrictions) {
    /* this code interferes with the arguments passes after a command !!! FIX THIS !!! */
    ftape_sleep( MILLISECOND);
    if (restrictions[ command].mask & QIC_STATUS_READY & restrictions[ command].state) {
      int status;
      result = ftape_report_raw_drive_status( &status);
      if ((status & QIC_STATUS_READY) == 0) {
        TRACEi( -1, "ftape_command", "drive should be ready and isn't for command:", command);
      }
    }
  }
  check_restrictions = 1;       /* always turned on for next command */
  /*
   *    Keep cylinder nr within range, step towards home if possible.
   */
  if (current_cylinder >= command) {
    track = current_cylinder - command;
  } else {
    track = current_cylinder + command;
  }

  result = fdc_seek( track);

  /*    Verify whether we issued the right tape command.
   */
  if (result < 0) {
    TRACE( 0, "ftape_command", "fdc_seek failed");
    return -EIO;
  }
  return 0;
}

/*      Send a tape command parameter:
 *      Generates command # of step pulses.
 *      Skips tape-status call !
 */
int
ftape_parameter( int command)
{
  check_restrictions = 0;
  return ftape_command( command);
}

/*      Wait for the drive to get ready.
 *      timeout time in seconds
 */
int
ftape_ready_wait( int timeout, int* status)
{
  int result;

  timeout *= 10;                /* 0.1 secs */
  for (;;) {
    result = ftape_report_raw_drive_status( status);
    if (result < 0) {
      TRACE( 0, "ftape_ready_wait", "ftape_report_raw_drive_status failed");
      return -EIO;
    }
    if (*status & QIC_STATUS_READY) {
      return 0;
    }
    if (--timeout < 0) {
      TRACE( 0, "ftape_ready_wait", "timeout");
      return -ETIME;
    }
    ftape_sleep( HZ / 10);      /* 0.1 second */
  }
}

/*      Issue command and wait up to timeout seconds for drive ready
 */
int
ftape_command_wait( int command, int timeout, int* status)
{
  int result;

  /* Drive should be ready, issue command
   */
  result = ftape_command( command);
  if (result < 0) {
    TRACE( 0, "ftape_command_wait", "command failed");
    return result;
  }
  /* Now wait for drive ready or timeout
   */
  result = ftape_ready_wait( timeout, status);
  if (result < 0) {
    TRACE( 0, "ftape_command_wait", "ready wait failed");
    return result;
  }
  return 0;
}

int
ftape_parameter_wait( int command, int timeout, int* status)
{
  check_restrictions = 0;
  return ftape_command_wait( command, timeout, status);
}

/*--------------------------------------------------------------------------
 *      Report operations
 */

/* Query the drive about its status.  The command is sent and
   result_length bits of status are returned (2 extra bits are read
   for start and stop). */

static int
ftape_report_operation( int *status, int command, int result_length)
{
  int i, st3;
  int result;

  result = ftape_command( command);
  if (result < 0) {
    TRACE( 0, "ftape_report_operation", "ftape_command failed");
    return result;
  }

  ftape_sleep( 8 * MILLISECOND); /* Ttimeout + Tack */
  result = fdc_sense_drive_status( &st3);
  if (result < 0) {
    TRACE( 0, "ftape_report_operation", "fdc_sense_drive_status failed");
    return result;
  }
  if ((st3 & ST3_TRACK_0) == 0) {
    TRACE( 0, "ftape_report_operation", "timeout on Acknowledge");
    return -EIO;
  }

  *status = 0;
  for (i = 0; i < result_length + 1; i++) {
    result = ftape_command( QIC_REPORT_NEXT_BIT);
    if (result < 0) {
      TRACE( 0, "ftape_report_operation", "report next bit failed");
      return result;
    }
    ftape_sleep( 10 * MILLISECOND);
    result = fdc_sense_drive_status( &st3);
    if (result < 0) {
      TRACE( 0, "ftape_report_operation", "fdc_sense_drive_status (2) failed");
      return result;
    }
    if (i < result_length) {
      *status |= ((st3 & ST3_TRACK_0) ? 1 : 0) << i;
    } else {
      if ((st3 & ST3_TRACK_0) == 0) {
        TRACE( 0, "ftape_report_operation", "missing status stop bit");
        return -EIO;
      }
    }
  }
  ftape_command( QIC_REPORT_NEXT_BIT); /* ???? CHECK THIS !!! */
  return 0;
}

/* Report the current drive status. */

int
ftape_report_raw_drive_status( int *status)
{
  int result;
  int count = 0;

  do {
    result = ftape_report_operation( status, QIC_REPORT_DRIVE_STATUS, 8);
    if (++count > 3) {
      TRACE( 0, "ftape_report_raw_drive_status", "ftape_report_operation failed");
      return -EIO;
    }
  } while (result < 0);

  return result;
}

int
ftape_report_drive_status( int *status)
{
  int result;

  result = ftape_report_raw_drive_status( status);
  if (result < 0) {
    TRACE( 0, "ftape_report_drive_status", "ftape_report_raw_drive_status failed");
    return result;
  }

  if (*status & QIC_STATUS_NEW_CARTRIDGE ||
      !(*status & QIC_STATUS_CARTRIDGE_PRESENT)) {
    ftape_failure = 1;          /* will inhibit further operations */
    return -EIO;
  }
  if (*status & QIC_STATUS_READY && *status & QIC_STATUS_ERROR) {
    /*  Let caller handle all other errors
     */
    result = 1 * 0;             /* WHAT'S THIS ???? FIX IT */
  }
   
  return result;
}

int
ftape_report_error( struct fdt_error* error)
{
  int code;
  int result;

  result = ftape_report_operation( &code, QIC_REPORT_ERROR_CODE, 16);
  if (result < 0) {
    return -EIO;
  }
  error->error = code & 0xff;
  error->command = (code >> 8) & 0xff;

  TRACEi( 0, "ftape_report_error", "errorcode:", error->error);
  if (tracing > 0) {
    if (error->error >= 0 && error->error < NR_ITEMS( ftape_errors)) {
      printk( "%sFatal ERROR: %s,\n",
             (ftape_errors[ error->error].fatal ? "" : "Non-"),
             ftape_errors[ error->error].message);
    } else {
      printk( "Unknown ERROR !\n");
    }
    if (error->command >= 0 && error->command < NR_ITEMS( ftape_cmds) &&
        ftape_cmds[ error->command] != NULL) {
      printk( "  caused by command \'%s\'\n", ftape_cmds[ error->command]);
    } else {
      printk( "  caused by unknown command: %d.\n", error->command);
    }
  }
  return 0;
}

int
ftape_report_configuration( int* config)
{
  int result;
  result = ftape_report_operation( config, QIC_REPORT_DRIVE_CONFIGURATION, 8);
  return (result == 0) ? 0 : -EIO;
}

int
ftape_report_rom_version( int* version)
{
  int result;
  result = ftape_report_operation( version, QIC_REPORT_ROM_VERSION, 8);
  return (result == 0) ? 0 : -EIO;
}

int
ftape_report_vendor_id( int* id)
{
  int result;
  result = ftape_report_operation( id, QIC_REPORT_VENDOR_ID, 16);
  return (result == 0) ? 0 : -EIO;
}

int
ftape_report_tape_status( int* status)
{
  int result;
  result = ftape_report_operation( status, QIC_REPORT_TAPE_STATUS, 8);
  return (result == 0) ? 0 : -EIO;
}

/*      Seek the head to the specified track.
 */
int
ftape_seek_head_to_track( int track)
{
  int status;
  int result;

  ftape_track = -1;             /* remains set in case of error */

  if (track < 0 || track > tracks_per_tape) {
    TRACE( 0, "ftape_seek_head_to_track", "track out of bounds");
    return -EINVAL;
  }
  result = ftape_command( QIC_SEEK_HEAD_TO_TRACK);
  if (result < 0) {
    TRACE( 0, "ftape_seek_head_to_track", "ftape_command failed");
    return result;
  }
  result = ftape_command_wait( track + 2, 5, &status);
  if (result < 0) {
    TRACE( 0, "ftape_seek_head_to_track", "ftape_command_wait failed");
    return result;
  }
  ftape_track = track;
  return 0;
}

int
ftape_not_operational( int status)
{
  /* return true if status indicates tape can not be used.
   */
  return (status ^ QIC_STATUS_CARTRIDGE_PRESENT) & (QIC_STATUS_ERROR |
                                                    QIC_STATUS_CARTRIDGE_PRESENT |
                                                    QIC_STATUS_NEW_CARTRIDGE);
}

int
ftape_seek_to_eot( void)
{
  int result;
  int status;

  result = ftape_ready_wait( 5, &status);
  while ((status & QIC_STATUS_AT_EOT) == 0) {
    if (result < 0) {
      TRACE( 0, "ftape_seek_to_eot", "failed");
      return result;
    }
    if (ftape_not_operational( status)) {
      return -EIO;
    }
    result = ftape_command_wait( QIC_PHYSICAL_FORWARD, 85, &status);
  }
  return 0;
}

int
ftape_seek_to_bot( void)
{
  int result;
  int status;

  result = ftape_ready_wait( 5, &status);
  while ((status & QIC_STATUS_AT_BOT) == 0) {
    if (result < 0) {
      TRACE( 0, "ftape_seek_to_bot", "failed");
      return result;
    }
    if (ftape_not_operational( status)) {
      return -EIO;
    }
    result = ftape_command_wait( QIC_PHYSICAL_REVERSE, 85, &status);
  }
  return 0;
}

inline void
reset_tape_position( void)
{
  ftape_chr_pos = 0;
  ftape_seg_pos = 2;            /* should depend on position header segments */
}

int
ftape_new_cartridge( void)
{
  int i;

  for (i = 0; i < NR_ITEMS( buffer); ++i) {
    buffer[ i].status = empty;
    buffer[ i].address = ((char*)tape_buffer)+ i* BUFF_SIZE;
    buffer[ i].bytes = 0;
  }
  bad_sector_table_full = 0;    /* reset flag */
  ftape_track = -1;             /* force seek on first access */
  reset_tape_position();

  return 0;
}

/*      Extract tape parameters from drive configuration
 */
int
ftape_get_tape_parameters( void)
{
  int result;
  int drive_configuration;
  int tape_status;

  result = ftape_report_configuration( &drive_configuration);
  if (result < 0) {
    TRACE( 0, "ftape_get_tape_parameters", "ftape_report_configuration failed");
    return result;
  }
  /* Report-tape-status command seems to be
   * not implemented on the colorado drive,
   * find out about others !!!
   */
  if (drive_type != DRIVE_IS_COLORADO) {
    result = ftape_report_tape_status( &tape_status);
    if (result < 0) {
      TRACE( 0, "ftape_get_tape_parameters", "ftape_report_tape_status failed");
      return result;
    }
    /* consistency check tape and drive configuration
     */
    if ( ((drive_configuration & QIC_CONFIG_80) &&
          (tape_status & QIC_TAPE_STD_MASK) != QIC_TAPE_QIC80) ||
        (!(drive_configuration & QIC_CONFIG_80) &&
         (tape_status & QIC_TAPE_STD_MASK) != QIC_TAPE_QIC40) ) {
      TRACE( 0, "ftape_get_tape_parameters", "tape format does not match drive configuration");
      ftape_failure = 1;
      return -EIO;
    }
  }
  segments_per_cylinder = 4;
  sectors_per_segment = 32;
  if ((drive_configuration & QIC_CONFIG_80) != 0) {
    if ((drive_configuration & QIC_CONFIG_LONG) != 0) {
      segments_per_track = 150;
    } else {
      segments_per_track = 100;
    }
    segments_per_head = 600;
    tracks_per_tape = 28;
  } else {
    if ((drive_configuration & QIC_CONFIG_LONG) != 0) {
      segments_per_track = 102;
      segments_per_head = 1020;
    } else {
      segments_per_track = 68;
      segments_per_head = 680;
    }
    tracks_per_tape = 20;
  }
  TRACEi( 0, "ftape_tape_parameters", "segments_per_cylinder", segments_per_cylinder);
  TRACEi( 0, "ftape_tape_parameters", "segments_per_track", segments_per_track);
  TRACEi( 0, "ftape_tape_parameters", "segments_per_head", segments_per_head);
  TRACEi( 0, "ftape_tape_parameters", "sectors_per_segment", sectors_per_segment);
  TRACEi( 0, "ftape_tape_parameters", "track_per_tape", tracks_per_tape);
  return 0;
}

int
ftape_abort_operation( void)
{
  int result;
  int i;

  TRACE( 0, "ftape_abort_operation", "called");
  if (runner_status == running) {
    runner_status = do_abort;
    fdc_interrupt_wait( 10 * SECOND);
  }
  runner_status = idle;
  result = ftape_command( QIC_STOP_TAPE);
  for (i = 0; i < NR_ITEMS( buffer); ++i) {
    buffer[ i].status = empty;
  }
  head = tail = 0;
  return result;
}
  
int
ftape_wakeup_drive( int drive_type)
{
  int result = -ENODEV;
  int status;

  switch (drive_type) {
  case DRIVE_IS_COLORADO:
    result = ftape_command( QIC_COLORADO_ENABLE1);    
    if (result == 0) {
      result = ftape_parameter( 2); /* for unit nr 0 */
    }
    break;
  case DRIVE_IS_MOUNTAIN:
    result = ftape_command( QIC_MOUNTAIN_ENABLE1);
    if (result == 0) {
      ftape_sleep( MILLISECOND);  /* NEEDED */
      result = ftape_command( QIC_MOUNTAIN_ENABLE2);
    }
    break;
  }
  if (result < 0) {
    TRACE( 0, "ftape_wakeup_drive", "ftape_command failed");
    return -ENODEV;
  }
  /* If wakeup succeeded we'll get no error here.. */
  result = ftape_report_raw_drive_status( &status);
  return result;
}

/*      OPEN routine called by kernel-interface code
 */
int
_ftape_open( int unit)
{
  int result = 0;
  int value;
  struct fdt_error error;
  int status;
  static int new_tape = 1;

  cli();
  oldvect = *do_floppy;         /* Wedge in interrupt. */
  do_floppy = fdc_interrupt;
  sti();

  ftape_unit = unit;

  fdc_reset( 0);
  if (fdc_recalibrate() != 0) {
    TRACE( 0, "_ftape_open", "recalibrate failed");
    result = -EIO;
    goto error_exit;
  }

  /* If we already know the drive type, wake it up.
   * Else try to find out what kind of drive is attached.
   */
  switch (drive_type) {
  case DRIVE_IS_COLORADO:
  case DRIVE_IS_MOUNTAIN:
    result = ftape_wakeup_drive( drive_type);
    break;
  default:
    result = ftape_report_raw_drive_status( &status);
    if (result < 0) {
      /* Drive doesn't respond. Try and wake it up using the known
       * methods of drive wakeup.
       */
      TRACE( 0, "_ftape_open", "using known wakeup methods");
      /* Try colorado. */
      result = ftape_wakeup_drive( DRIVE_IS_COLORADO);
      if (result == 0) {
        TRACE( 0, "_ftape_open", "drive is Colorado");
        drive_type = DRIVE_IS_COLORADO;
        break;
      }
      /* Try mountain. */
      result = ftape_wakeup_drive( DRIVE_IS_MOUNTAIN);
      if (result == 0) {
        TRACE( 0, "_ftape_open", "drive is Mountain");
        drive_type = DRIVE_IS_MOUNTAIN;
        break;
      }
      /* no response at all, cannot open this drive */
      TRACE( -1, "_ftape_open", "unknown drive type");
      drive_type = DRIVE_IS_UNKNOWN;
      result = -ENODEV;
      goto error_exit;
    } else {
      /* we do not know the drive type, but it is responding.
       * let's hope it will co-operate with our software !
       */
      drive_type = DRIVE_IS_UNKNOWN;
    }
    break;
  }
  /*    Tape drive is activated now.
   *    First clear error status if present.
   */
  for (;;) {

    ftape_ready_wait( 105, &status);

    /*  Exit if no tape inserted
     */
    if ((status & QIC_STATUS_CARTRIDGE_PRESENT) == 0) {
      TRACE( 0, "_ftape_open", "no cartridge present");
      return -EIO;
    }
    /*  Clear error condition (drive is ready !)
     */
    if (status & QIC_STATUS_NEW_CARTRIDGE) {
      TRACE( -1, "_ftape_open", "status: new cartridge");
      value = ftape_report_error( &error);
      if (value < 0) {
        TRACE( 0, "_ftape_open", "report_error_code failed");
        return result;
      }
      TRACEi( 0, "_ftape_open", "error code   :", error.error);
      TRACEi( 0, "_ftape_open", "error command:", error.command);
      new_tape = 1;
    }
    if (status & QIC_STATUS_ERROR) {
      TRACE( 0, "_ftape_open", "status: error bit set");
      value = ftape_report_error( &error);
      if (value < 0) {
        TRACE( 0, "_ftape_open", "report_error_code failed");
        return result;
      }
      TRACEi( 0, "_ftape_open", "error code   :", error.error);
      TRACEi( 0, "_ftape_open", "error command:", error.command);
    } else {
      break;                    /* done ! */
    }
  }
  if (new_tape) {
    /* tape should be at bot if new cartridge ! */
    ftape_new_cartridge();
    ftape_get_tape_parameters();
    new_tape = 0;
  }

  return 0;

 error_exit:
  cli();
  do_floppy = oldvect;
  sti();
  return result;
}

/*      RELEASE routine called by kernel-interface code
 */
int
_ftape_close( int unit)
{
  int result;

  if (unit != ftape_unit) {
    TRACE( 0, "_ftape_close", "wrong unit nr");
    result = -EIO;
    goto exit;
  }

  _ftape_write( unit, NULL, -1); /* flush write buffer */

  for (;;) {
    int i;
    /* Find out if all buffers are written.
     */
    for (i = 0; i < NR_BUFFERS; ++i) {
      if (buffer[ i].status != empty) {
        break;
      }
    }
    if (i == NR_BUFFERS) {
      break;                    /* exit if all buffers written */
    }
    if (fdc_interrupt_wait( 5 * SECOND) == -ETIME) {
      TRACE( 0, "_ftape_close", "timeout waiting for done");
      break;                    /* something wrong */
    }
  }

  ftape_abort_operation();

  switch (drive_type) {
  case DRIVE_IS_COLORADO:
    ftape_command( QIC_COLORADO_DISABLE);
    break;
  case DRIVE_IS_MOUNTAIN:
    ftape_command( QIC_MOUNTAIN_DISABLE);
    break;
  default:
    break;
  }
  result = 0;

 exit:

  expect_stray_interrupt = 1;   /* one always comes */

  fdc_disable();

  cli();
  do_floppy = oldvect;
  sti();

  expect_stray_interrupt = 0;

  return result;
}

/*      IOCTL routine called by kernel-interface code
 */
int
_ftape_ioctl( int unit, unsigned int command, void * arg)
{
  int result = EINVAL;
  union {
    int word;
    struct fdt_error error;
    struct _fdt_find_me find;
    struct tape_read read;
    struct mtop _mtop;
  } krnl_arg;
  int arg_size = (command & IOCSIZE_MASK) >> IOCSIZE_SHIFT;

  if (unit != ftape_unit) {
    TRACE( 0, "_ftape_ioctl", "wrong unit nr");
    return -EIO;
  }

  /*    Filter commands depending on runner status and command type
   */
  if (command != FT_READ && runner_status != idle && command != FT_STOP_TAPE) {
    return -EBUSY;
  }

  /* This check will only catch arguments that are too large !
   */
  if (arg_size > sizeof( krnl_arg)) {
    TRACEi( -1, "ftape_ioctl", "bad argument size:", arg_size);
    return -EINVAL;
  }

  if (command & IOC_IN) {
    int error = verify_area( VERIFY_READ, arg, arg_size);
    if (error) {
      return error;
    }
    memcpy_fromfs( &krnl_arg, arg, arg_size);
  }

  TRACElx( 1, "_ftape_ioctl", "called with command:", command);

  switch (command) {
/* cpio compatibility
 */
  case MTIOCTOP:
    TRACE( 0, "_ftape_ioctl", "Mag tape ioctl command: MTIOCTOP");
    switch (krnl_arg._mtop.mt_op) {
    case MTREW:
      result = ftape_seek_to_bot();
      reset_tape_position();
      break;
    default:
      break;
    }
    break;
  case MTIOCGET:
    TRACE( 0, "_ftape_ioctl", "Mag tape ioctl command: MTIOCGET");
    break;
  case MTIOCPOS:
    TRACE( 0, "_ftape_ioctl", "Mag tape ioctl command: MTIOCPOS");
    break;

/* userft compatibility
 */
  case FT_REPORT_STATUS:
    result = ftape_report_drive_status( &krnl_arg.word);
    break;
  case FT_REPORT_ERROR_CODE:
    result = ftape_report_error( &krnl_arg.error);
    break;
  case FT_REPORT_CONFIGURATION:
    result = ftape_report_configuration( &krnl_arg.word);
    break;
  case FT_REPORT_ROM_VERSION:
    result = ftape_report_rom_version( &krnl_arg.word);
    break;
  case FT_REPORT_VENDOR_ID:
    result = ftape_report_vendor_id( &krnl_arg.word);
    break;
  case FT_SEEK_TO_TRACK:
    result = ftape_seek_head_to_track( krnl_arg.word);
    break;
  case FT_STOP_TAPE:
    result = ftape_abort_operation();
    break;
  case FT_SEEK_TO_END:
    result = ftape_seek_to_eot();
    break;
  case FT_SEEK_TO_BEGINNING:
    result = ftape_seek_to_bot();
    break;
  default:
    result = EINVAL;
    break;
  }

  if (command & IOC_OUT) {
    int error = verify_area( VERIFY_WRITE, arg, arg_size);
    if (error) {
      return error;
    }
    memcpy_tofs( arg, &krnl_arg, arg_size);
  }
  return result;
}
