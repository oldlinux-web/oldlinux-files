/*
 * Use the "hello, world" system call.
 */

#include "modules.h"

main() {
      int rc;
      extern int errno;

      rc = syscall( SYS_FREE_ENTRY);
      printf("syscall returned %d, errno = %d\n", rc, errno);
      return 0;
}
