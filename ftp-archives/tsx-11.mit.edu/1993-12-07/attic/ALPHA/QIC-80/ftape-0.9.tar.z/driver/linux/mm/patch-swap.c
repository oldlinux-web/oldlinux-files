--- 1.3	1993/05/01 22:15:28
+++ swap.c	1993/06/17 20:55:04
@@ -732,4 +730,69 @@
 	val->freeswap <<= PAGE_SHIFT;
 	val->totalswap <<= PAGE_SHIFT;
 	return;
+}
+
+
+extern unsigned long *dload_pages;	/* set up in memory.c */
+
+/*
+ * Allocate a block of pages at contiguous virtual memory addresses.
+ * Used for dynamic loading of kernel modules.
+ */
+unsigned long ld_alloc_mem(int npages)
+{
+	int i;
+	int freecount;
+	int freeloc;
+	unsigned long page;
+
+	freecount = 0;
+	for (i = 0 ; i < 1024 ; i++) {
+		if (dload_pages[i] != 0) {
+			freecount = 0;
+		} else if (++freecount >= npages) {
+			break;
+		}
+	}
+	if (freecount < npages)
+		return 0;
+	freeloc = i + 1 - npages;
+	do {
+		dload_pages[i] = 2;  /* mark page as taken */
+	} while (--i >= freeloc);
+	i += npages;
+	for (i = 0 ; i < npages ; i++) {
+		page = get_free_page(GFP_KERNEL);
+		if (page == 0)
+			goto bad;
+		dload_pages[freeloc + i] = page | 7;
+	}
+	invalidate();
+	return (unsigned long)(freeloc + 32 * 1024) * 4096;
+
+bad:
+	for (i = 0 ; i < npages ; i++) {
+		page = dload_pages[freeloc + i];
+		if (page != 2)
+			free_page(page);
+		dload_pages[freeloc + i] = 0;
+	}
+	return 0;
+}
+
+/*
+ * Free memory obtained from ld_alloc_mem.
+ */
+void ld_free_mem(unsigned long addr, int npages)
+{
+	int i;
+	int page;
+	int freeloc = (addr >> 12) - 32 * 1024;
+
+	for (i = 0 ; i < npages ; i++) {
+		page = dload_pages[freeloc + i];
+		free_page(page);
+		dload_pages[freeloc + i] = 0;
+	}
+
 }
