--- 1.3	1993/05/01 22:12:10
+++ mem.c	1993/06/17 21:15:33
@@ -357,6 +361,8 @@
 	NULL		/* release */
 };
 
+char* ftape_big_buffer;
+
 long chr_dev_init(long mem_start, long mem_end)
 {
 	if (register_chrdev(1,"mem",&memory_fops))
@@ -365,5 +371,18 @@
 	mem_start = lp_init(mem_start);
 	mem_start = mouse_init(mem_start);
 	mem_start = soundcard_init(mem_start);
+#if CONFIG_TAPE_QIC02
+	mem_start = tape_qic02_init(mem_start);
+#endif
+/*
+ *      Rude way to allocate kernel memory buffer for tape device
+ */
+        printk( "--- Tape buffer allocated at: %p ---\n", mem_start);
+        ftape_big_buffer= (char*) mem_start;
+        mem_start+= 3* 0x8000+ 0x7fff; /* 'n' 32Kb buffers+ allignment space */
+        printk( "--- Incremented mem_start to: %p ---\n", mem_start);
+/*
+ *      end of rude way
+ */
 	return mem_start;
 }
