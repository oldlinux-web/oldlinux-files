#ifndef _ECC_H
#define _ECC_H

/*
 *      Copyright (C) 1993 Bas Laarhoven.
 *      Original:
 *      Copyright (C) 1992 David L. Brown, Jr.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 *
 $Source: /usr/src/distr/driver/RCS/ecc.h,v $
 $Author: bas $
 *
 $Revision: 1.1 $
 $Date: 1993/06/30 22:41:48 $
 $State: Alpha $
 *
 *      This file contains the definitions for the
 *      Reed-Solomon error correction code 
 *      for the QIC-40/80 tape streamer device driver.
 *
 $Log: ecc.h,v $
 * Revision 1.1  1993/06/30  22:41:48  bas
 * Initial revision
 *
 */


#ifndef BIG_ENDIAN
typedef unsigned long BAD_SECTOR;
# define BAD_CLEAR(entry) ((entry)=0)
# define BAD_SET(entry,sector) ((entry)|=(1<<(sector)))
# define BAD_CHECK(entry,sector) ((entry)&(1<<(sector)))
#else
# error not yet written.
#endif

/* Return values for ecc_correct_data. */

enum {
  ECC_CORRECT,			/* Data was correct. */
  ECC_CORRECTED,		/* Correctable error in data. */
  ECC_FAILED			/* Could not correct data. */
};

struct ecc_inverse_matrix {
  unsigned char log_denom;      /* The $\log_z$ of the denominator. */
  unsigned char zs[3][3];       /* The coefficients for the adjustment
                                   matrix. */
};

/* Representation of an in memory segment.  marked_bad lists the
   sectors that were marked bad during format.  This is absolute
   sector.   The sectors should be read in from the disk and packed,
   as if the bad sectors were not there, and the segment just
   contained fewer sectors.  read_sectors is a bitmap of errors
   encountered while reading the data.  These offsets are relative to
   the packed data.  blocks is a count of the sectors not marked bad.
   This is just to prevent having to count the clear bits in
   marked_bad each time this is used.  data is the actual sector
   packed data from (or to) the tape. */

struct memory_segment {
  BAD_SECTOR marked_bad;
  BAD_SECTOR read_bad;
  int blocks;
  char *data;
};


/*      ecc.c defined global vars.
 */

/*      ecc.c defined global functions.
 */
extern int ecc_correct_data (struct memory_segment *data);
extern void ecc_set_segment_parity( struct memory_segment *data);

#endif



