--- root.c~	Tue Apr 27 20:28:26 1993
+++ root.c	Thu Jun 17 21:59:59 1993
@@ -59,7 +59,8 @@
 	{ 5,4,"kmsg" },
 	{ 6,7,"version" },
 	{ 7,4,"self" },	/* will change inode # */
-	{ 8,3,"net" }
+	{ 8,3,"net" },
+ 	{ 16,7,"modules" }
 };
 
 #define NR_ROOT_DIRENTRY ((sizeof (root_dir))/(sizeof (root_dir[0])))
