#ifndef _FTAPE_RW_H
#define _FTAPE_RW_H

/*
 * Copyright (C) 1993 Bas Laarhoven.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 *
 $Source: /usr/src/distr/driver/RCS/ftape-rw.h,v $
 $Author: bas $
 *
 $Revision: 1.1 $
 $Date: 1993/06/30 22:41:48 $
 $State: Alpha $
 *
 *      This file contains the non-read/write related functions
 *      for the QIC-40/80 floppy-tape driver for Linux.
 *
 $Log: ftape-rw.h,v $
 * Revision 1.1  1993/06/30  22:41:48  bas
 * Initial revision
 *
 */

#include "fdc-io.h"
#include "kernel-interface.h"

/*      ftape-rw.c defined global vars.
 */
extern buffer_struct buffer[ NR_BUFFERS];

/*      ftape-rw.c defined global functions.
 */
extern int setup_new_segment( unsigned int head, unsigned int segment_id);
extern int calc_next_cluster( void);
extern int setup_fdc_and_dma( unsigned char operation);
extern void next_buffer( volatile int* x);
extern int _ftape_read( int unit, char* buff, int req_len);
extern int _ftape_write( int unit, char* buff, int req_len);
extern int read_id( int unit, struct _fdt_id *location);
extern void ftape_tape_parameters( unsigned char drive_configuration);
extern int wait_segment( buffer_state_enum state);

#endif /* _FTAPE_RW_H */

