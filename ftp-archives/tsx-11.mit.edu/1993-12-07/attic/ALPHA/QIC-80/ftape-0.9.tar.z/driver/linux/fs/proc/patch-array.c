--- array.c~	Sat Jun  5 01:31:59 1993
+++ array.c	Thu Jun 17 22:01:24 1993
@@ -298,6 +298,8 @@
 		       size, resident, share, trs, lrs, drs, dt);
 }
 
+extern int get_module_list(char *);
+
 static int array_read(struct inode * inode, struct file * file,char * buf, int count)
 {
 	char * page;
@@ -337,6 +339,9 @@
 			break;
 		case 12:
 			length = get_statm(pid, page);
+			break;
+		case 16:
+			length = get_module_list(page);
 			break;
 		default:
 			free_page((unsigned long) page);
