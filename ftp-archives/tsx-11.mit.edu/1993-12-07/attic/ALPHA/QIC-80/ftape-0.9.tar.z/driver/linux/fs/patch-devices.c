--- devices.c~	Wed Feb 17 19:20:50 1993
+++ devices.c	Thu Jun 17 21:19:30 1993
@@ -44,6 +44,20 @@
 }
 
 /*
+ *  begin changes on 0.99pl10 by SJL
+ */
+int unregister_chrdev( unsigned int major, const char * name)
+{
+	if (major >= MAX_CHRDEV || chrdev_fops[ major] == NULL)
+		return -EINVAL;
+	chrdev_fops[ major] = NULL;
+	return 0;
+}
+/*
+ *  end changes on 0.99pl10 by SJL
+ */
+
+/*
  * Called every time a block special file is opened
  */
 int blkdev_open(struct inode * inode, struct file * filp)
