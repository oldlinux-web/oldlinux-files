--- 1.3	1993/06/12 15:05:58
+++ sys.c	1993/06/19 19:47:23
@@ -699,15 +740,25 @@
 #define LATCH ((1193180 + HZ/2)/HZ)
 
 /*
  * This version of gettimeofday has near microsecond resolution.
  * It was inspired by Steve McCanne's microtime-i386 for BSD.  -- jrs
  */
+#if 0
 static inline void do_gettimeofday(struct timeval *tv)
+#else
+void do_gettimeofday(struct timeval *tv)
+#endif
 {
 	unsigned long nowtime;
 	long count;
+#if 1
+        long flags;
+#endif
 
 #ifdef __i386__
+#if 1
+        save_flags( flags);
+#endif
 	cli();
 	/* timer count may underflow right here */
 	outb_p(0x00, 0x43);	/* latch the count ASAP */
@@ -716,17 +767,25 @@
 	count |= inb_p(0x40) << 8;
 	/* we know probability of underflow is always MUCH less than 1% */
 	if (count < (LATCH - LATCH/100))
+#if 0
 		sti();
+#else
+                restore_flags( flags);
+#endif
 	else {
 		/* check for pending timer interrupt */
 		outb_p(0x0a, 0x20);
 		if (inb(0x20) & 1)
 			nowtime++;
+#if 0
 		sti();
+#else
+                restore_flags( flags);
+#endif
 	}
 	nowtime += jiffies_offset;
 	tv->tv_sec = startup_time + CT_TO_SECS(nowtime);





