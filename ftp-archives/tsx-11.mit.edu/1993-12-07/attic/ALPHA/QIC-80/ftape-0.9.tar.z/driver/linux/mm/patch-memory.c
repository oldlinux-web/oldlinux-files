--- 1.3	1993/05/01 22:15:28
+++ memory.c	1993/06/17 21:33:05
@@ -58,6 +59,8 @@
 
 unsigned short * mem_map = NULL;
 
+unsigned long *dload_pages;	/* for dynamic loading - KA */
+
 #define CODE_SPACE(addr,p) ((addr) < (p)->end_code)
 
 /*
@@ -971,6 +1055,15 @@
 			address += 4096;
 		}
 	}
+	/*
+	 * Set up 4 MB of virtual address space for dynamicly loaded
+	 * kernel code.
+	 */
+	dload_pages = (unsigned long *) start_mem;
+	start_mem += 4096;
+	memset(dload_pages, 0, 4096);
+	swapper_pg_dir[800] = (unsigned long) dload_pages | 7;
+
 	invalidate();
 	return start_mem;
 }









