#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <linux/module.h>

#include "modules.h"

main(int argc, char **argv) {
	if (delete_module(argv[1]) < 0) {
		perror("delete_module");
		exit(2);
	}
	exit(0);
}


int delete_module(const char *name) {
	return syscall( SYS_DELETE_MODULE, name);
}
