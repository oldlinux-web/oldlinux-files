/*
 * Implement the hello, world system call.
 */

#include "modules.h"

typedef int (*fn_ptr)();

extern fn_ptr sys_call_table[];
extern int NR_syscalls;
extern int no_sys();

int sys_hello(void);

int
init_module() {
	printk("installing system call\n");
	printk( "NR_syscalls = %d\n", NR_syscalls);
	printk( "SYS_FREE_ENTRY = %d\n", SYS_FREE_ENTRY);
	if (NR_syscalls <= SYS_FREE_ENTRY) {
		printk("No space in system call table\n");
		return -1;
	}
	printk( "sys_call_table[ SYS_FREE_ENTRY] = %p\n", sys_call_table[ SYS_FREE_ENTRY]);
	printk( "no_sys = %p\n", no_sys);
	if (sys_call_table[SYS_FREE_ENTRY] != no_sys) {
		printk("System call number %d is already in use\n", SYS_FREE_ENTRY);
		return -1;
	}
	sys_call_table[SYS_FREE_ENTRY] = sys_hello;
	printk("Hello world system call loaded\n");
	return 0;
}

void
cleanup_module() {
	printk("hello.c:  cleanup called\n");
	sys_call_table[SYS_FREE_ENTRY] = no_sys;
}

int
sys_hello() {
	printk("Hello, world!\n");
	return 0;
}
