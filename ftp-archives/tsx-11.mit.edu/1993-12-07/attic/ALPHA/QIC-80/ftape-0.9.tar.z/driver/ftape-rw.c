/*
 *      Copyright (C) 1993 Bas Laarhoven.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 $Source: /usr/src/distr/driver/RCS/ftape-rw.c,v $
 $Author: bas $
 *
 $Revision: 1.1 $
 $Date: 1993/06/30 22:41:48 $
 $Locker:  $
 $State: Alpha $
 *
 *      This file contains the reading and writing code
 *      for the QIC-40/80 floppy-tape driver for Linux.
 *
 $Log: ftape-rw.c,v $
 * Revision 1.1  1993/06/30  22:41:48  bas
 * Initial revision
 *
 */

static char RCSid[] = "$Id: ftape-rw.c,v 1.1 1993/06/30 22:41:48 bas Alpha $";


#include <string.h>
#include <linux/errno.h>
#include <linux/sched.h>
#include <asm/dma.h>
#include <asm/segment.h>
#include <asm/system.h>

#include "kernel-interface.h"
#include "qic117.h"
#include "fdc-io.h"
#include "ftape-io.h"
#include "ftape-rw.h"
#include "ecc.h"

#define KERNEL_BUFFER           /* determines memcpy mode */

int tracing = 0;                /* for debugging: higher -> more verbose */
fdc_mode_enum fdc_mode = fdc_idle;
volatile enum runner_status_enum runner_status = idle;

unsigned int bad_sector_table[ 4200]; /* max size for QIC-80, 307.5 ft tape */
volatile int head;
volatile int tail;              /* not volatile but need same type as head */
int fdc_setup_error;
buffer_struct buffer[ NR_BUFFERS];
volatile unsigned char fdc_head; /* FDC head */
volatile unsigned char fdc_cyl; /* FDC track */
volatile unsigned char fdc_sect; /* FDC sector */
volatile unsigned int bad_sector_map; /* bad sector map for one segment */
volatile unsigned int next_segment; /* next segment for read ahead */
volatile unsigned int sector_count; /* nr of sectors to read from segment */
volatile unsigned int remaining; /* nr of sector remaining in segment */
volatile unsigned long int buffer_ptr; /* where to put next sector(s) */
volatile unsigned char sector_offset; /* offset for first sector to read */

struct wait_queue *wait_intr = NULL;
unsigned char global_in[ 7];
unsigned char deblock_buffer[ 29 * SECTOR_SIZE];

static int start_tape( int segment_id, int start_margin);

/*      Increment cyclic buffer nr.
 */
void
next_buffer( volatile int* x)
{
  if (++*x >= NR_ITEMS( buffer)) {
    *x = 0;
  }
}

/*      Calculate Floppy Disk Controller and DMA parameters for a new segment.
 */
int
setup_new_segment( unsigned int head, unsigned int segment_id)
{
  buffer[ head].segment_id = segment_id;
  buffer[ head].crc_error_map = 0; /* well, just for now ! */
  next_segment= segment_id + 1; /* for read ahead */
  buffer_ptr = (long) buffer[ head].address;
  bad_sector_map = bad_sector_table[ segment_id];
  remaining = sectors_per_segment;
  sector_offset = 0;

  fdc_head = segment_id / segments_per_head;
  fdc_cyl = (segment_id % segments_per_head) / segments_per_cylinder;
  fdc_sect = (segment_id % segments_per_cylinder) * sectors_per_segment + 1;

  fdc_setup_error = 0;
  TRACElx( 1, "setup_new_segment", "bad_sector_map =", bad_sector_map);
  return 0;
}

/*      Determine size of next cluster of good sectors.
 */
int
calc_next_cluster( void)
{
  /* Skip bad sectors.
   */
  while (remaining > 0 && (bad_sector_map & 1) != 0) {
    bad_sector_map >>= 1;
    ++sector_offset;
    --remaining;
  }
  
  /* Find next cluster of good sectors
   */
  if (bad_sector_map == 0) {  /* speed up */
    sector_count = remaining;
  } else {
    sector_count = 0;
    while (sector_count < remaining && (bad_sector_map & 1) == 0) {
      ++sector_count;
      bad_sector_map >>= 1;
    }
  }
  return sector_count;
}

/*      Setup Floppy Disk Controller and DMA to read or write the next cluster
 *      of good sectors from or to the current segment.
 */
int
setup_fdc_and_dma( unsigned char operation)
{
  unsigned long flags;
  unsigned char out[ 9];
  int result;

  TRACE( 1, "setup_fdc_and_dma", "Status:");
  if (tracing > 1) {  
    printk( "-- remaining: %d\n", remaining);
    printk( "-- transfer count = %d sectors\n", sector_count);
    printk( "-- destination address = 0x%p\n", buffer_ptr);
  }
  
  /* Program the DMA controller.
   */
  save_flags( flags);
  cli();                      /* could be called from ISR ! */
  disable_dma( FLOPPY_DMA);
  clear_dma_ff( FLOPPY_DMA);
  set_dma_mode( FLOPPY_DMA, (operation == FDC_WRITE) ? DMA_MODE_WRITE : DMA_MODE_READ);
  set_dma_addr( FLOPPY_DMA, buffer_ptr);
  set_dma_count( FLOPPY_DMA, SECTOR_SIZE * sector_count);
  enable_dma( FLOPPY_DMA);
  
  /* Issue FDC command to start reading.
   */
  out[0] = (operation == FDC_WRITE) ? FDC_WRITE : FDC_READ;
  out[1] = ftape_unit;
  out[2] = fdc_cyl;
  out[3] = fdc_head;
  out[4] = fdc_sect + sector_offset;
  out[5] = 3;                   /* Sector size of 1K. */
  out[6] = fdc_sect + sector_offset + sector_count - 1; /* last sector */
  out[7] = 116;                 /* Gap length. */
  out[8] = 0xff;		/* No limit to transfer size. */
  restore_flags( flags);

  TRACE( 1, "setup_fdc_and_dma", "FDC progamming info:");
  if (tracing > 1) {
    printk( "-- cyl.=%d, head=%d, sect.=%d, count=%d\n",
           out[ 2], out[ 3], out[ 4], out[ 6]- out[ 4]+ 1);
  }

  /* After all sectors are done an interrupt will follow.
   */
  result = fdc_command( out, 9);
  if (result != 0) {
    fdc_mode = fdc_idle;
    TRACE( -1, "setup_fdc_and_dma", "command issue error");
  }
  fdc_setup_error = result;
  return result;
}

/*      Read Id of first sector passing tape head.
 */
int
read_id( int unit, struct _fdt_id *location)
{
  int result;
  unsigned char out[2];
  int retry = 1;

try_again:                      /* FIX THIS !!! */
  
  out[ 0] = FDC_READID;
  out[ 1] = unit;
  result = fdc_command( out, 2);
  if (result != 0) {
    TRACE( -1, "read_id", "error issueing command");
    return result;
  }
  
  result = fdc_interrupt_wait( 5 * SECOND);
  if (result != 0) {
    TRACE( 0, "read_id", "timeout on result phase");
    return result;
  }

  /*    result in global_in. NEEDS REWORK !
   */
  /* Check return for normal. */
  if ((global_in[0] & ST0_INT_MASK) == FDC_INT_NORMAL) {
    location->cylinder = global_in[ 3];
    location->head = global_in[ 4];
    location->sector = global_in[ 5];
  } else {
    if (global_in[ 0] == 0x40 && global_in[ 1] == 0x01 && retry-- > 0) {
      goto try_again;
    }
    TRACE( 0, "read_id", "Error status:");
    printk( "   st0=0x%02x, st1=0x%02x, st2=0x%02x\n",
            global_in[ 0], global_in[ 1], global_in[ 2]);
    return -EIO;
  }
  
  return 0;
}

/*      Wait until runner has finished tail buffer.
 */
int
wait_segment( buffer_state_enum state)
{
  if (buffer[ tail].status == empty) {
    TRACE( 0, "wait_segment", "called on empty buffer");
    return -1;                  /* IS THIS RIGHT ?? */
  }
  while (buffer[ tail].status == state) {
    /*  First buffer still being done, wait...
     */
    if (fdc_interrupt_wait( 5 * SECOND) == -ETIME) {
      TRACE( 0, "wait_segment", "timeout");
      /* recover ... */
      return -ETIME;
    }
    if (fdc_setup_error) {
      TRACE( 0, "wait_segment", "setup error");
      /* recover... */
      return -EIO;
    }
  }
  return 0;
}


int
correct_and_copy( unsigned int tail, unsigned char* destination)
{
  struct memory_segment mseg;
  int result;

  mseg.read_bad = buffer[ tail].crc_error_map;
  mseg.marked_bad = 0;          /* not used... */
  mseg.blocks = buffer[ tail].bytes / SECTOR_SIZE;
  mseg.data = buffer[ tail].address;

  result = ecc_correct_data( &mseg);

  if (result == ECC_CORRECTED || result == ECC_CORRECT) {
    if (result == ECC_CORRECTED) {
      TRACEi( 0, "correct_and_copy", "corrected segment", buffer[ tail].segment_id);
    }
#ifdef KERNEL_BUFFER
    memcpy( destination, mseg.data, (mseg.blocks - 3) * SECTOR_SIZE);
#else
    memcpy_tofs( destination, mseg.data, (mseg.blocks - 3) * SECTOR_SIZE);
#endif
    return (mseg.blocks - 3) * SECTOR_SIZE;
  } else {
    TRACEi( 0, "correct_and_copy", "ecc failure on segment", buffer[ tail].segment_id);
    return -EIO;
  }
}

/* forward */ int
read_segment( unsigned int segment_id, unsigned char* address);

int
read_header_segment( unsigned char* address)
{
  /* Should be made according to QIC-40/80 spec.
   * For now, this will suffice for tapes with
   * the first two segments free of defects.
   */
  TRACE( 0, "read_header_segment", "reading...");
  bad_sector_table[ 0] = 0x00000000;
  return read_segment( 0, address);
}

int
read_bad_sector_table( unsigned char* address)
{
  int i;
  bad_sector_table_full = 1;  /* recursion ! */
  /* read bad sector info into caller's read buffer */
  if (read_header_segment( address) < 0) {
    bad_sector_table_full = 0; /* failed ! */
    return -EIO;
  }
  /* move from caller's read buffer into bad sector table */
#ifdef KERNEL_BUFFER
  memcpy( bad_sector_table, address + 2 * SECTOR_SIZE, sizeof( bad_sector_table));
#else
  memcpy_fromfs( bad_sector_table, address + 2 * SECTOR_SIZE, sizeof( bad_sector_table));
#endif
  if (tracing > 0) {
    for (i = 0; i < segments_per_track * tracks_per_tape; ++i) {
      if (bad_sector_table[ i] != 0x00000000) {
        printk( "Bad sector(s) in segment %d, map = 0x%08x\n", i, bad_sector_table[ i]);
      }
    }
  }
  return 0;
}

/*      Read given segment into buffer at address.
 */
int
read_segment( unsigned int segment_id, unsigned char* address)
{
  int read_done= 0;
  int result;
  int bytes_read = 0;
  
  TRACEi( 0, "read_segment", "entered, segment_id =", segment_id);

  if (runner_status == running && buffer[ head].status == writing) {
    ftape_abort_operation();
  }
  /*    Search all full buffers for the first matching the wanted segment.
   *    Clear other buffers on the fly.
   */
  while (!read_done && buffer[ tail].status == full) {
    if (buffer[ tail].segment_id == segment_id) {
      /*        If out buffer is yet full, return its contents.
       */
      bytes_read = correct_and_copy( tail, address);
      if (bytes_read < 0) {
        TRACE( -1, "read_segment", "should retry");
        /* IMPLEMENT RETRY HERE ! */
      }
      read_done = 1;
      TRACE( 0, "read_segment", "found segment in cache");
    } else {
      TRACEi( 0, "read_segment", "zapping segment buffer",
             buffer[ tail].segment_id);
    }
    buffer[ tail].status = empty;
    next_buffer( &tail);
  }
  if (!read_done) {
    cli();
    if (buffer[ tail].status == reading) {
      if (buffer[ tail].segment_id != segment_id) {
        /*        We're reading the wrong segment, stop runner.
         *        (We could wait for the right segment to pass by !)
         */
        runner_status = do_abort;
        sti();
        TRACE( 0, "read_segment", "aborting runner");
        do {
          if (fdc_interrupt_wait( 5 * SECOND) == -ETIME) {
            TRACE( 0, "read_segment", "timeout while aborting");
            /* should we abort the DMA transfer ??? */
            runner_status = aborting;
            break;
          }
        } while (runner_status != aborting);
      } else {
        sti();
        if (wait_segment( reading) != 0) {
          TRACE( 0, "read_segment", "wait_segment failed while reading");
          return -EIO;
        }
      }
    } else {
      sti();
    }
  }
  /*    just passed last segment on tape: wait for BOT or EOT mark.
   */
  if (runner_status == logical_eot) {
    int status;
    result = ftape_ready_wait( 10 * SECOND, &status);
    if (result < 0) {
      TRACE( 0, "read_segment", "ftape_ready_wait waiting for eot/bot failed");
    }
    if (status & (QIC_STATUS_AT_BOT | QIC_STATUS_AT_EOT) == 0) {
      TRACE( 0, "read_segment", "eot/bot not reached");
    }
    runner_status = end_of_tape;
  }
  /*    should runner stop ?
   */
  if (runner_status == aborting || runner_status == buffer_overrun ||
      runner_status == end_of_tape) {
    ftape_command( QIC_STOP_TAPE);
    if (runner_status == aborting) {
      expect_stray_interrupt = 0;
      if (buffer[ head].status == reading) {
        buffer[ head].status = empty;
      }
    }
    runner_status = idle;       /* aborted ? */
  }
  /*    Now at least one buffer is empty !
   *    Restart runner & tape if needed.
   */
  TRACE( 1, "read_segment", "State:");
  if (tracing > 1) {
    printk( "-- head = %d, tail = %d\n", head, tail);
    printk( "-- runner_status = %d\n", runner_status);
    printk( "-- buffer[tail].status = %d\n", buffer[ tail].status);
  }
  if (runner_status == idle && buffer[ tail].status != full) {
    int track = segment_id / segments_per_track;
    TRACEi( 1, "read_segment", "starting runner for segment", segment_id);
    if (ftape_track != track) {
      int status;
      TRACEi( 1, "read_segment", "seeking head to track", track);
      ftape_ready_wait( 5, &status);
      ftape_seek_head_to_track( track);
    }
    result= start_tape( segment_id, 10);
    TRACEi( 1,"read_segment", "runner starting status", result);
    if (result) {
      TRACEi( 0, "read_segment", "Error - couldn't reach segment", segment_id);
      return -EIO;
    }
    runner_status = running;

    /*  Start runner reading.
     */
    setup_new_segment( head, segment_id);
    buffer[ head].status = reading;
    if (calc_next_cluster() == 0) {
      TRACE( 0, "read_segment", "empty segment");
      return -EIO;
    }
    if (setup_fdc_and_dma( FDC_READ)) {
      buffer[ head].status = error;
      TRACE( 0, "read_segment", "setup error while starting");
      /* recover ... */
      return -EIO;
    }
  }
  /*    If we already copied a segment quit.
   */
  if (read_done) {
    return bytes_read;
  }
  /*    wait for our segment to become available.
   */
  if (wait_segment( reading) != 0) {
    TRACE( -1, "read_segment", "wait_segment failed after start_tape");
    return -EIO;
  }
  if (buffer[ tail].status != full) {
    TRACE( -1, "read_segment", "Error - no filled tape buffer");
    return -EIO;
  }

  bytes_read = correct_and_copy( tail, address);
  if (bytes_read < 0) {
    /* IMPLEMENT RETRY HERE ! */
    TRACE( -1, "read_segment", "should retry");
  }
  buffer[ tail].status = empty;
  next_buffer( &tail);

  return bytes_read;
}

int
seek_reverse( int count)
{
  int result;
  int status;

  result = ftape_ready_wait( 5, &status);  /* timeout for stop-tape command */
  if (result != 0) {
    TRACE( -1, "seek_reverse", "drive not ready");
    return -EIO;
  }

  /* Issue this tape command first. */
  result = ftape_command( QIC_SKIP_REVERSE);
  if (result == 0) {
    /* Issue the low nibble of the command. */
    result = ftape_parameter( 2 + (count & 0x0f));
    if (result == 0) {
      /* Issue the high nibble and wait for the command to complete. */
      result = ftape_parameter( 2 + ((count >> 4) & 0x0f));
      if (result == 0) {
        result = ftape_ready_wait( 85, &status);
      }
    }
  }
  return result;
}

/*      Start the tape moving and get our position.
 *      If wanted segment is no more than margin ahead return the
 *      moment the segment preceding our target passes the head.
 *      If we must change from one tape track to another an error
 *      is returned.
 *      Presume ftape_track is correct !
 */

static int
start_tape( int segment_id, int start_margin)
{
  int result;
  int status;
  struct _fdt_id location;
  int actual_segment;
  int last_segment = -1;

  TRACEi( 0, "start_tape", "seek segment", segment_id);

  do {

    result = ftape_ready_wait( 15, &status);
    if (result < 0) {
      TRACEi( 0, "start_tape", "wait for ready failed with code", result);
      return result;
    }
    result = ftape_report_drive_status( &status);
    if (result < 0) {
      TRACEi( 0, "start_tape", "ftape_report_drive_status failed with code", result);
    }
    result = ftape_command( QIC_LOGICAL_FORWARD);
    if (result) {
      TRACEi( 0, "start_tape", "logical forward failed with code", result);
      return result;
    }
    if (status & (QIC_STATUS_AT_BOT | QIC_STATUS_AT_EOT)) {

      TRACE( 0, "start_tape", "tape at bot or eot");
      /*          At BOT or EOT !
       */
      if (((status & QIC_STATUS_AT_BOT) && (ftape_track & 1)) ||
          ((status & QIC_STATUS_AT_EOT) && !(ftape_track & 1))) {
        
        /*        Wrong track nr., tape probably not running !
         */
        TRACE( 0, "start_tape", "wrong track selected");
        return -EIO;
      }
      if (segment_id % segments_per_track >= start_margin ||
          segment_id / segments_per_track != ftape_track) {
        
        /*        not within start margin, or at wrong track !
         */
        TRACE( 0, "start_tape", "bot or eot but too far away");
        return -EIO;
      }
      if (segment_id % segments_per_track == 0) {
        
        /*        next segment should be ours, no time for read id's !
         */
        return 0;
      }
    }
    /*    We're in the middle of somewhere, only thing that can
     *    go wrong is a tape track boundary crossing...
     */
    do {
      result = read_id( ftape_unit, &location);
      if (result) {
        location.head = 0;
        location.cylinder = 0;
        location.sector = 0;
        actual_segment = -1;
      } else {
        actual_segment = (segments_per_head * location.head
                          + segments_per_cylinder * location.cylinder
                          + (location.sector - 1) / sectors_per_segment);
      }
      if (actual_segment != last_segment) {
        TRACEi( 0, "start_tape", "just passed segment", actual_segment);
        if (tracing > 0) {
          printk( "-- head: %d, cyl.: %d, sect.: %d\n",
                 location.head, location.cylinder, location.sector);
        }
        last_segment = actual_segment;
      }
      if (result) {
        TRACEi( 0, "start_tape", "read_id failed with code", result);
        /* A read id error usually means the tape has run off of the end,
         * wait here to avoid trouble.
         */
        ftape_sleep( 1 * SECOND);
        /* Even wait for it to become ready. This even causes a lot of
         * problems if the drive isn't given a chance to calm down.
         */
        ftape_ready_wait( 15, &status);
        fdc_mode = fdc_idle;
        return result;
      }
      /*  Exit if segment not within margin or on different tracks.
       *  May rewind if past target.
       */
      if (segment_id / segments_per_track != ftape_track) {
        TRACE( 0, "start_tape", "seek segment: wrong track");
        fdc_mode = fdc_idle;
        return -EINVAL;
      }
      if (actual_segment < segment_id - start_margin ||
          actual_segment > segment_id + start_margin) {
        if (actual_segment < segment_id) {
          TRACE( 0, "start_tape", "seek segment: too far behind");
        } else {
          TRACE( 0, "start_tape", "seek segment: too far ahead");
        }
        ftape_command( QIC_STOP_TAPE);
        fdc_mode = fdc_idle;
        return -EINVAL;
      }
      if (actual_segment >= segment_id) {
        TRACE( 0, "start_tape", "repositioning");
        ftape_command( QIC_STOP_TAPE);
        TRACE( 0,"start_tape", "tape stopped");
        seek_reverse( 2 + actual_segment - segment_id);
        TRACE( 0, "start_tape", "tape reversed");
        break;                  /* start all over again (outer loop) */
      }
      /*    Now we're on the right track, wanted segment is within start margin
       *    and tape is spinning.
       *    Just have to wait for the correct segment to pass by.
       */
    } while (actual_segment != segment_id - 1);

    /* If got here and actual_segment != segment_id - 1
     * then restart tape and check for eot or bot.
     */
  } while (actual_segment != segment_id - 1);

  return 0;
}

int
_ftape_read( int unit, char* buff, int req_len)
{
  int result;
  int cnt;
  static int buf_len = 0;
  static int buf_pos;

  if (!bad_sector_table_full) {
    result = read_bad_sector_table( deblock_buffer);
    if (result < 0) {
      return result;
    }
  }

  if (buf_len == 0) {
    result = read_segment( ftape_seg_pos, deblock_buffer);
    if (result < 0) {
      printk( "ftape read error, result = %d (0x%08x)\n", result, result);
      return -EIO;
    }
    buf_pos = 0;
    buf_len = result;
    ++ftape_seg_pos;
  }
  if (req_len > buf_len) {
    cnt = buf_len;
  } else {
    cnt = req_len;
  }

  TRACEi( 0, "_ftape_read", "just read bytes:", cnt);

  result = verify_area( VERIFY_WRITE, buff, cnt);
  if (result) {
    TRACE( 0, "_ftape_read", "verify_area failed");
    return result;
  }
  memcpy_tofs( buff, deblock_buffer + buf_pos, cnt);
  
  buf_pos += cnt;               /* index in buffer */
  buf_len -= cnt;               /* remaining bytes in buffer */
  ftape_chr_pos += cnt;         /* tape position */

  return cnt;                   /* bytes read */
}

int
copy_and_gen_ecc( unsigned int tail, unsigned char* source)
{
  struct memory_segment mseg;
  int bads = 0;
  unsigned int mask;

  for (mask = buffer[ tail].crc_error_map; mask != 0; mask >>= 1) {
    if (mask & 1) {
      ++bads;
    }
  }

  mseg.data = buffer[ tail].address;
  mseg.blocks = 32 - bads;
  if (mseg.blocks <= 3) {
    TRACE( 0, "copy_and_gen_ecc", "empty segment");
    return -EIO;
  }

#ifdef KERNEL_BUFFER
  memcpy( mseg.data, source, (mseg.blocks - 3) * SECTOR_SIZE);
#else
  memcpy_fromfs( mseg.data, source, (mseg.blocks - 3) * SECTOR_SIZE);
#endif

  ecc_set_segment_parity( &mseg);

  return (mseg.blocks - 3) * SECTOR_SIZE;
}

/*      Write given segment from buffer at address onto tape.
 */
int
write_segment( unsigned int segment_id, unsigned char* address, int flushing)
{
  int result;
  int bytes_written = 0;
  
  TRACEi( 0, "write_segment", "entered, segment_id =", segment_id);

  if (runner_status == running && buffer[ head].status == reading) {
    ftape_abort_operation();
  }
 
  /*    If just passed last segment on tape: wait for BOT or EOT mark.
   */
  if (runner_status == logical_eot) {
    int status;
    result = ftape_ready_wait( 10 * SECOND, &status);
    if (result < 0) {
      TRACE( 0,"write_segment", "ftape_ready_wait waiting for eot/bot failed");
    }
    if (status & (QIC_STATUS_AT_BOT | QIC_STATUS_AT_EOT) == 0) {
      TRACE( 0, "write_segment", "eot/bot not reached");
    }
    runner_status = end_of_tape;
  }
  /*    should runner stop ?
   */
  if (runner_status == aborting || runner_status == buffer_underrun ||
      runner_status == end_of_tape) {
    ftape_command( QIC_STOP_TAPE);
    if (runner_status == aborting) {
      expect_stray_interrupt = 0;
      if (buffer[ head].status == writing) {
        buffer[ head].status = empty; /* ????? */
      }
    }
    runner_status = idle;       /* aborted ? */
  }
  /*    if all buffers full we'll have to wait...
   */
  if (buffer[ tail].status != empty) {
    wait_segment( writing);
  }
  if (buffer[ tail].status != empty) {
    TRACE( 0, "write_segment", "wait for empty segment failed");
    return -EIO;
  }
  /*    now at least one buffer is empty, fill it with our data.
   *    skip bad sectors and generate ecc.
   */
  result = copy_and_gen_ecc( tail, address);
  if (result < 0) {
    TRACE( -1, "write_segment", "copy_and_gen_ecc failed");
    return result;
  }
  bytes_written = result;
  buffer[ tail].status = full;
  buffer[ tail].segment_id = segment_id;
  next_buffer( &tail);

  if (runner_status == running) {
    /* isr will keep things running */
    return bytes_written;
  }
  /*    Start tape only if all buffers full or flush mode.
   *    This will give higher probability of streaming.
   */
  if (buffer[ tail].status == full || flushing) {

    int segment_id = buffer[ head].segment_id;

    if (!flushing && head != tail) {
      TRACE( -1, "write_segment", "head != tail");
      return -EIO;
    }
    setup_new_segment( head, segment_id);
    if (buffer[ head].status != full) {
      TRACE( -1, "write_segment", "unexpected head status");
      return -EIO;
    }
    buffer[ head].status = writing;

    if (runner_status == idle) {
      int track = segment_id / segments_per_track;
      TRACEi( 0, "write_segment", "starting runner for segment", segment_id);
      if (ftape_track != track) {
        int status;
        TRACEi( 0, "write_segment", "seeking head to track", track);
        ftape_ready_wait( 5, &status);
        ftape_seek_head_to_track( track);
      }
      result= start_tape( segment_id, 10);
      TRACEi( 0, "write_segment", "runner starting status", result);
      if (result) {
        TRACEi( 0, "write_segment", "Error - couldn't reach segment", segment_id);
        return -EIO;
      }
      runner_status = running;
    }
    /*  Start runner writing.
     */
    if (calc_next_cluster() == 0) {
      TRACE( 0, "write_segment", "empty segment");
      return -EIO;
    }
    if (setup_fdc_and_dma( FDC_WRITE)) {
      buffer[ head].status = error;
      TRACE( 0, "write_segment", "setup error while starting");
      /* recover ... */
      return -EIO;
    }
  }

  return bytes_written;
}

int
_ftape_write( int unit, char* buff, int req_len)
{
  int result;
  int cnt;
  int written = 0;
  static int buf_pos = 0;
  int do_flush = (req_len <= 0 && buf_pos > 0);

  if (!bad_sector_table_full && (req_len > 0 || do_flush)) {
    result = read_bad_sector_table( deblock_buffer);
    if (result < 0) {
      return result;
    }
  }

  if (do_flush) {
    /* Flush write buffer(s)
     */
    int buf_data_len = buf_pos;
    TRACEi( 0, "_ftape_write", "flush, remainder in buffer:", buf_pos);
    while (buf_data_len > 0) {

      cnt = sizeof( deblock_buffer) - buf_pos; /* remaining */
      TRACEi( 0, "_ftape_write", "flush, padding count:", cnt);
      /* pad buffer with 0's */
      memset( deblock_buffer + buf_pos, 0, cnt);
      result = write_segment( ftape_seg_pos, deblock_buffer, do_flush);
      if (result < 0) {
        TRACEi( -1, "_ftape_write", "write_segment failed, error:", -result);
        return -EIO;
      }
      TRACEi( 1, "_ftape_write", "flush, moved out buffer:", result);
      if (result < buf_data_len) {
        /* We'll need another segment */
        buf_pos = sizeof( deblock_buffer) - result;
        memmove( deblock_buffer, deblock_buffer + result, buf_pos);
      } else {
        buf_pos = 0;
      }
      buf_data_len -= result;
      ++ftape_seg_pos;
    }
    TRACEi( 0, "_ftape_write", "flush buffer netto pad-count:", -buf_data_len);
    return 0;
  }

  if (runner_status == running && buffer[ head].status == reading) {
    ftape_abort_operation();
  }
 
  while (req_len > 0) {
    int space_left = sizeof( deblock_buffer) - buf_pos;

    TRACEi( 1, "_ftape_write", "remaining req_len:", req_len);
    TRACEi( 1, "_ftape_write", "          buf_pos:", buf_pos);

    cnt = (req_len < space_left) ? req_len : space_left;
    result = verify_area( VERIFY_READ, buff, cnt);
    if (result) {
      TRACE( -1, "_ftape_write", "verify_area failed");
      return result;
    }
    memcpy_fromfs( deblock_buffer + buf_pos, buff, cnt);
    buff += cnt;
    req_len -= cnt;
    buf_pos += cnt;
    TRACEi( 0, "_ftape_write", "moved into blocking buffer:", cnt);

    if (buf_pos >= sizeof( deblock_buffer)) {
      /* Got one full buffer, write it to disk
       */
      result = write_segment( ftape_seg_pos, deblock_buffer, do_flush);
      if (result < 0) {
        TRACEi( -1, "_ftape_write", "write_segment failed, error:", -result);
        return -EIO;
      }
      ++ftape_seg_pos;
      if (result < buf_pos) {
        /* partial write: move remainder in lower part of buffer */
        memmove( deblock_buffer, deblock_buffer + result, buf_pos - result);
      }
      buf_pos -= result;        /* remainder */
      TRACEi( 1, "_ftape_write", "moved out of blocking buffer:", result);
    }

    ftape_chr_pos += cnt;       /* tape position */
    written += cnt;
  }
  TRACEi( 1, "_ftape_write", "remaining in blocking buffer:", buf_pos);
  TRACEi( 1, "_ftape_write", "just written bytes:", written);

  return written;               /* bytes written */
}
