/*
 *      Copyright (C) 1993 Bas Laarhoven.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 $Source: /usr/src/distr/driver/RCS/kernel-interface.c,v $
 $Author: bas $
 *
 $Revision: 1.1 $
 $Date: 1993/06/30 22:41:48 $
 $State: Alpha $
 *
 *      This file contains the code that interfaces the kernel
 *      for the QIC-40/80 floppy-tape driver for Linux.
 *
 $Log: kernel-interface.c,v $
 * Revision 1.1  1993/06/30  22:41:48  bas
 * Initial revision
 *
 */

static char RCSid[] = "$Id: kernel-interface.c,v 1.1 1993/06/30 22:41:48 bas Alpha $";


#include <errno.h>
#include <linux/fs.h>
#include <asm/segment.h>
#include <linux/kernel.h>

#include "ftape-ioctl.h"
#include "ftape-rw.h"
#include "ftape-io.h"
#include "kernel-interface.h"


/*      Global vars.
 */
char *tape_buffer = NULL;

/*      Local vars.
 */
static int busy_flag = 0;
static struct file_operations ftape_cdev; /* forward decl. */


/*      Called by modules package when installing the driver
 */
int
init_module( void) {

  TRACE( -1, "init_module", "installing QIC-117 ftape driver...");
  if (register_chrdev( TAPE_QIC_117_MAJOR, "mt", &ftape_cdev)) {
    TRACE( -1, "init_module", "register_chrdev failed");
    return -EIO;
  }
  /*    Allign buffer in kernel space at 32Kb boundary (what a waste!).
   */
  tape_buffer = (char*) (( (long) ftape_big_buffer + 0x7fffl) & ~0x7fffl);
  TRACElx( 0, "init_module", "ftape_big_buffer     @", ftape_big_buffer);
  TRACElx( 0, "init_module", "alligned tape_buffer @", tape_buffer);

  busy_flag = 0;
  ftape_unit = -1;
  ftape_failure = 1;            /* inhibit any operation but open */

  ftape_new_cartridge();        /* init some tape related variables */

  return 0;
}

/*      Called by modules package when removing the driver
 */
void
cleanup_module( void) {

  if (unregister_chrdev( TAPE_QIC_117_MAJOR, "mt") != 0) {
    TRACE( -1, "cleanup_module", "failed");
  } else {
    TRACE( -1, "cleanup_module", "succeeded");
  }
}

/*      Open ftape device
 */
static int
ftape_open( struct inode * inode, struct file * filep)
{
  int result;

  TRACE( 0, "ftape_open", "called");

  if (busy_flag) {
    TRACE( -1, "ftape_open", "failed because busy");
    return -EBUSY;
  }
  ftape_failure = 0;            /* allow tape operations */

  result = _ftape_open( MINOR( inode->i_rdev));
  if (result < 0) {
    TRACE( 0, "ftape_open", "_ftape_open failed");
    return result;
  } else {
    busy_flag = 1;
    return 0;
  }
}

/*      Close ftape device
 */
static void
ftape_close( struct inode * inode, struct file * filep)
{
  int result;

  TRACE( 0, "ftape_close", "called");
  if (!busy_flag) {
    TRACE( -1, "ftape_close", "failed because of not busy");
    return;
  }
  /*    put cease read or write runner here
   */

  result = _ftape_close( MINOR( inode->i_rdev));
  if (result < 0) {
    TRACE( -1, "ftape_close", "_ftape_close failed");
  }
  busy_flag = 0;
}

/*      Ioctl for ftape device
 */
static int
ftape_ioctl( struct inode * inode, struct file * filep, 
            unsigned int command, unsigned long arg)
{
  int result = -EIO;

  TRACElx( 0, "ftape_ioctl", "called with code:", command);
  if (!ftape_failure) {
    /* This will work as long as sizeof( void*) == sizeof( long)
     */
    result = _ftape_ioctl( MINOR( inode->i_rdev), command, (void*) arg);
  } else {
    TRACE( -1, "ftape_ioctl", "ftape_failure");
  }
  return result;
}

/*      Read from tape device
 */
static int
ftape_read( struct inode* ino, struct file * fp, char* buff, int req_len)
{
  int result = -EIO;

  TRACEi( 0, "ftape_read", "called with count:", req_len);
  if (!ftape_failure) {
    result = _ftape_read( MINOR( ino->i_rdev), buff, req_len);
  }
  if (req_len != result) {
    TRACEi( 0, "ftape_read", "partial read count:", result);
  }
  return result;
}

/*      Write to tape device
 */
static int
ftape_write( struct inode* ino, struct file * fp, char* buff, int req_len)
{
  int result = -EIO;

  TRACEi( 0, "ftape_write", "called with count:", req_len);
  if (!ftape_failure) {
    result = _ftape_write( MINOR( ino->i_rdev), buff, req_len);
  }
  if (req_len != result) {
    TRACEi( 0, "ftape_write", "partial write count:", result);
  }
  return result;
}

#if 0
static int ftape_select( void);
static int ftape_mmap( int dev, unsigned off, int prot);
#else
# define ftape_select NULL
# define ftape_mmap NULL
#endif


static struct file_operations ftape_cdev = {
  NULL,				/* lseek */
  ftape_read, 			/* read */
  ftape_write,			/* write */
  NULL,				/* readdir */
  ftape_select, 		/* select */
  ftape_ioctl,			/* ioctl */
  ftape_mmap, 		        /* mmap */
  ftape_open,			/* open */
  ftape_close,			/* release */
  NULL,                         /* fsync */
};

