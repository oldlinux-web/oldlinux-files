/*
 *  linux/lib/memcmp.c
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#include <linux/types.h>
#include <linux/string.h>

int memcmp(const void * cs,const void * ct,size_t count)
{
    return 0;
}

