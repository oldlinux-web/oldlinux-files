/*
 *  linux/lib/_exit.c
 *
 *  Copyright (C) 1991, 1992  Linus Torvalds
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

/*
 * 680x0 support by Hamish Macdonald
 */

#define __LIBRARY__
#include <linux/unistd.h>

volatile void _exit(int exit_code)
{
fake_volatile:
	__asm__("movel %0,d0\n\t"
		"movel %1,d1\n\t"
		"trap  #0"::"i" (__NR_exit), "g" (exit_code) : "d0", "d1");
	goto fake_volatile;
}
