/*
** chipregs.c -- This file defines pointers to the Amiga custom chip
**		 registers.  Naming conventions conform to the Amiga
**		 Hardware Reference Manual, 3rd Edition
**
** Copyright 1992 by Greg Harp
**
** This file is subject to the terms and conditions of the GNU General Public
** License.  See the file README.legal in the main directory of this archive
** for more details.
**
** Created: 9/24/92 by Greg Harp
** Last Modified 10/19/92 by Greg Harp
** Last Modified 02/11/93 by Hamish Macdonald
*/

#include <machine/chipregs.h>

volatile unsigned short
	*adkcon = (unsigned short *)ADKCON,
	*intena = (unsigned short *)INTENA,
	*intenar = (unsigned short *)INTENAR,
	*intreq = (unsigned short *)INTREQ,
	*intreqr = (unsigned short *)INTREQR,
	*serper = (unsigned short *)SERPER,
	*serdat = (unsigned short *)SERDAT,
	*serdatr = (unsigned short *)SERDATR;

volatile unsigned char
	*ciaa_pra  = (unsigned char *)CIAA_PRA,
	*ciaa_prb  = (unsigned char *)CIAA_PRB,
	*ciab_pra  = (unsigned char *)CIAB_PRA,
	*ciab_prb  = (unsigned char *)CIAB_PRB,

	*ciaa_talo = (unsigned char *)CIAA_TALO,
	*ciaa_tahi = (unsigned char *)CIAA_TAHI,
	*ciaa_tblo = (unsigned char *)CIAA_TBLO,
	*ciaa_tbhi = (unsigned char *)CIAA_TBHI,

	*ciab_talo = (unsigned char *)CIAB_TALO,
	*ciab_tahi = (unsigned char *)CIAB_TAHI,
	*ciab_tblo = (unsigned char *)CIAB_TBLO,
	*ciab_tbhi = (unsigned char *)CIAB_TBHI,

	*ciaa_icr  = (unsigned char *)CIAA_ICR,
	*ciab_icr  = (unsigned char *)CIAB_ICR,

	*ciaa_cra  = (unsigned char *)CIAA_CRA,
	*ciaa_crb  = (unsigned char *)CIAA_CRB,
	*ciab_cra  = (unsigned char *)CIAB_CRA,
	*ciab_crb  = (unsigned char *)CIAB_CRB,

	*ciaa_sdr  = (unsigned char *)CIAA_SDR;
