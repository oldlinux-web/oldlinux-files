#! /bin/sh

if [ ! -f .version ]
then
	echo 0 > .version
fi
typeset -i cycle
cycle=`/c/type .version`
let cycle=$cycle+1
if [ $cycle -gt 99 ]
then
	cycle=0
fi
echo $cycle > .version
