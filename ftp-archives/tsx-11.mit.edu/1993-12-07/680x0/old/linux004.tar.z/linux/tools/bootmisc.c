/*
** bootmisc.c -- Miscellaneous non-portable functions for the Amiga Linux
**		 boostrap.
**
** Copyright 1993 by Hamish Macdonald
**
** This file is subject to the terms and conditions of the GNU General Public
** License.  See the file README.legal in the main directory of this archive
** for more details.
**
*/

#include <sys/types.h>
#include <machine/ktypes.h>

#ifdef __GNUC__

void change_stack (u_long *stackp)
{
    __asm__ volatile ("movel %0,a0\n\t"
		      "lea   %0,a1\n\t"
		      "movel a1@(-4),a1\n\t"
		      "movel a0,sp\n\t"
		      "jmp a1@" :: "m" (stackp) : "sp");
    /* NOTREACHED */
}

void disable_cache (void)
{
    __asm__ volatile ("movec %0,cacr" :: "d" (0));
}

void disable_mmu (void)
{
    __asm__ volatile ("subl  #4,sp;"
		      "pmove tc,sp@;"
		      "bclr  #7,sp@;"
		      "pmove sp@,tc;"
		      "addl  #4,sp");
}

void jump_to (void* addr)
{
    __asm__ volatile ("jmp %0@" :: "a" (addr));
    /* NOTREACHED */
}

#else /* not GCC */

void change_stack (u_long *stackp)
{
#error
    /* NOTREACHED */
}

void disable_cache (void)
{
#error
}

void disable_mmu (void)
{
#error
}

void jump_to (void* addr)
{
#error
}

#endif /* GCC? */
