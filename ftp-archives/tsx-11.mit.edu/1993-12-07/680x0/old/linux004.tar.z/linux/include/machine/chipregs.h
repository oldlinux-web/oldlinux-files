/*
** chipregs.h -- This header defines some macros and pointers for the various
**		 Amiga custom hardware registers.  The naming conventions
**		 used here conform to those used in the Amiga Hardware
**		 Reference Manual, 3rd Edition
**
** Copyright 1992 by Greg Harp
**
** This file is subject to the terms and conditions of the GNU General Public
** License.  See the file README.legal in the main directory of this archive
** for more details.
**
** Created: 9/24/92 by Greg Harp
*/

#ifndef CHIPREGS_H
#define CHIPREGS_H

#define ADKCON	  0xdff09e	/* Audio, disk, control write */
#define ADKCONR   0xdff010	/* Audio, disk, control read */

#define INTENA	  0xdff09a	/* Interrupt enable write */
#define INTENAR   0xdff01c		/* Interrupt enable read */
#define INTREQ	  0xdff09c	/* Interrupt request write */
#define INTREQR   0xdff01e	/* Interrupt request read */

#define CIAA_PRA  0xbfe001	/* CIAA peripheral data register A */
#define CIAA_PRB  0xbfe101	/* CIAA peripheral data register B */
#define CIAB_PRA  0xbfd000	/* CIAB peripheral data register A */
#define CIAB_PRB  0xbfd100	/* CIAB peripheral data register B */

#define CIAA_TALO 0xbfe401	/* CIAA Timer A low byte */
#define CIAA_TAHI 0xbfe501	/* CIAA Timer A high byte */
#define CIAA_TBLO 0xbfe601	/* CIAA Timer B low byte */
#define CIAA_TBHI 0xbfe701	/* CIAA Timer B high byte */
#define CIAB_TALO 0xbfd400	/* CIAB Timer A low byte */
#define CIAB_TAHI 0xbfd500	/* CIAB Timer A high byte */
#define CIAB_TBLO 0xbfd600	/* CIAB Timer B low byte */
#define CIAB_TBHI 0xbfd700	/* CIAB Timer B high byte */

#define CIAA_ICR  0xbfed01	/* CIAA interrupt control register */
#define CIAB_ICR  0xbfdd00	/* CIAB interrupt control register */

#define CIAA_CRA  0xbfee01	/* CIAA control register A */
#define CIAA_CRB  0xbfef01	/* CIAA control register B */
#define CIAB_CRA  0xbfde00	/* CIAB control register A */
#define CIAB_CRB  0xbfdf00	/* CIAB control register B */

#define CIAA_SDR  0xbfec01	/* CIAA serial data register (keyboard) */

#define SERPER	  0xdff032	/* Serial port period and control */
#define SERDAT	  0xdff030	/* Serial port data write */
#define SERDATR   0xdff018	/* Serial port data read */

extern volatile unsigned short
	*adkcon,
	*adkconr,
	*intena,
	*intenar,
	*intreq,
	*intreqr,
	*serper,
	*serdat,
	*serdatr;

extern volatile unsigned char
	*ciaa_pra,
	*ciaa_prb,
	*ciab_pra,
	*ciab_prb,
	*ciaa_talo,
	*ciaa_tahi,
	*ciaa_tblo,
	*ciaa_tbhi,
	*ciab_talo,
	*ciab_tahi,
	*ciab_tblo,
	*ciab_tbhi,
	*ciaa_icr,
	*ciab_icr,
	*ciaa_cra,
	*ciaa_crb,
	*ciab_cra,
	*ciab_crb,
	*ciaa_sdr;

#endif /* CHIPREGS_H */
