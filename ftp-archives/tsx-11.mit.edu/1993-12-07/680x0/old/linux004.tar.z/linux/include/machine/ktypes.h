/*
** ktypes.h -- Types used in Amiga Linux kernel source
**
** Copyright 1992 by Greg Harp
**
** This file is subject to the terms and conditions of the GNU General Public
** License.  See the file README.legal in the main directory of this archive
** for more details.
**
** Created 09/29/92 by Greg Harp
*/

#ifndef KTYPES_H
#define KTYPES_H

struct Node {
    struct  Node *ln_Succ;	/* Pointer to next (successor) */
    struct  Node *ln_Pred;	/* Pointer to previous (predecessor) */
    u_char   ln_Type;
    char    ln_Pri;		/* Priority, for sorting */
    char    *ln_Name;		/* ID string, null terminated */
};

struct List {
    struct Node *l_head;
    struct Node *l_tail;
    struct Node *l_tailpred;
    u_char  l_type;
    u_char  l_pad;
};

struct MemChunk {
    struct  MemChunk *mc_Next;	/* pointer to next chunk */
    u_long   mc_Bytes;		/* chunk byte size	*/
};

#define MEMF_FAST  (1<<2)
#define MEMF_CHIP  (1<<1)
#define MEMF_CLEAR (1<<16)

struct MemHeader {
    struct  Node mh_Node;
    u_short   mh_Attributes;	/* characteristics of this region */
    struct  MemChunk *mh_First; /* first free region		*/
    void    *mh_Lower;		/* lower memory bound		*/
    void    *mh_Upper;		/* upper memory bound+1 */
    u_long   mh_Free;		/* total number of free bytes	*/
};

struct ExecBase {
    u_char	fill1[296];
    u_short	AttnFlags;
    u_char	fill2[24];
    struct List MemList;
    u_char	fill3[194];
    u_char	VBlankFrequency;
    u_char	PowerSupplyFrequency;
    u_char	fill4[36];
    u_long	EClockFrequency;
};

struct ExpansionRom {
    /* -First 16 bytes of the expansion ROM */
    u_char	er_Type;	/* Board type, size and flags */
    u_char	er_Product;	/* Product number, assigned by manufacturer */
    u_char	er_Flags;	/* Flags */
    u_char	er_Reserved03;	/* Must be zero ($ff inverted) */
    u_short	er_Manufacturer; /* Unique ID,ASSIGNED BY COMMODORE-AMIGA! */
    u_long	er_SerialNumber; /* Available for use by manufacturer */
    u_short	er_InitDiagVec; /* Offset to optional "DiagArea" structure */
    u_char	er_Reserved0c;
    u_char	er_Reserved0d;
    u_char	er_Reserved0e;
    u_char	er_Reserved0f;
};

struct ConfigDev {
    struct Node 	cd_Node;
    u_char		cd_Flags;	/* (read/write) */
    u_char		cd_Pad; 	/* reserved */
    struct ExpansionRom cd_Rom; 	/* copy of board's expansion ROM */
    void		*cd_BoardAddr;	/* where in memory the board was placed */
    u_long		cd_BoardSize;	/* size of board in bytes */
    u_short		cd_SlotAddr;	/* which slot number (PRIVATE) */
    u_short		cd_SlotSize;	/* number of slots (PRIVATE) */
    void		*cd_Driver;	/* pointer to node of driver */
    struct ConfigDev	*cd_NextCD;	/* linked list of drivers to config */
    u_long		cd_Unused[4];	/* for whatever the driver wants */
};

#ifndef AFF_68020
#define AFB_68020 1
#define AFF_68020 (1<<AFB_68020)
#endif

#ifndef AFF_68881
#define AFB_68881 4
#define AFF_68881 (1<<AFB_68881)
#endif

#ifndef AFF_68030
#define AFB_68030 2
#define AFF_68030 (1<<AFB_68030)
#endif

#ifndef AFF_68040
#define AFB_68040 3
#define AFF_68040 (1<<AFB_68040)
#endif

#ifndef AFF_68882
#define AFB_68882 5
#define AFF_68882 (1<<AFB_68882)
#endif

#ifndef MEMF_CHIP
#define MEMF_CHIP  (1<<1)
#endif

#ifndef MEMF_LOCAL
#define MEMF_LOCAL (1<<8)
#endif

#ifndef MEMF_24BITDMA
#define MEMF_24BITDMA (1<<9)
#endif

#define NTSC_JIFFY_TICKS   (7159)
#define PAL_JIFFY_TICKS    (7094)

#include <sys/cdefs.h>

struct Library;

__BEGIN_DECLS

#ifndef BASE_EXT_DECL
#define BASE_EXT_DECL extern struct ExecBase * SysBase;
#endif
#ifndef BASE_PAR_DECL
#define BASE_PAR_DECL
#define BASE_PAR_DECL0 void
#endif
#ifndef BASE_NAME
#define BASE_NAME SysBase
#endif

static __inline void *
AllocMem (BASE_PAR_DECL unsigned long byteSize,unsigned long requirements)
{
  BASE_EXT_DECL
  register void  *_res	__asm("d0");
  register struct ExecBase *a6 __asm("a6") = BASE_NAME;
  register unsigned long d0 __asm("d0") = byteSize;
  register unsigned long d1 __asm("d1") = requirements;
  __asm __volatile ("jsr a6@(-0xc6)"
  : "=r" (_res)
  : "r" (a6), "r" (d0), "r" (d1)
  : "a0","a1","d0","d1", "memory");
  return _res;
}
static __inline void
CloseLibrary (BASE_PAR_DECL struct Library *library)
{
  BASE_EXT_DECL
  register struct ExecBase *a6 __asm("a6") = BASE_NAME;
  register struct Library *a1 __asm("a1") = library;
  __asm __volatile ("jsr a6@(-0x19e)"
  : /* no output */
  : "r" (a6), "r" (a1)
  : "a0","a1","d0","d1", "memory");
}
static __inline void
Disable (BASE_PAR_DECL0)
{
  BASE_EXT_DECL
  register struct ExecBase *a6 __asm("a6") = BASE_NAME;
  __asm __volatile ("jsr a6@(-0x78)"
  : /* no output */
  : "r" (a6)
  : "a0","a1","d0","d1", "memory");
}
static __inline void
Enable (BASE_PAR_DECL0)
{
  BASE_EXT_DECL
  register struct ExecBase *a6 __asm("a6") = BASE_NAME;
  __asm __volatile ("jsr a6@(-0x7e)"
  : /* no output */
  : "r" (a6)
  : "a0","a1","d0","d1", "memory");
}
static __inline void
FreeMem (BASE_PAR_DECL void * memoryBlock,unsigned long byteSize)
{
  BASE_EXT_DECL
  register struct ExecBase *a6 __asm("a6") = BASE_NAME;
  register void *a1 __asm("a1") = memoryBlock;
  register unsigned long d0 __asm("d0") = byteSize;
  __asm __volatile ("jsr a6@(-0xd2)"
  : /* no output */
  : "r" (a6), "r" (a1), "r" (d0)
  : "a0","a1","d0","d1", "memory");
}
static __inline struct Library *
OpenLibrary (BASE_PAR_DECL u_char *libName,unsigned long version)
{
  BASE_EXT_DECL
  register struct Library * _res  __asm("d0");
  register struct ExecBase *a6 __asm("a6") = BASE_NAME;
  register u_char *a1 __asm("a1") = libName;
  register unsigned long d0 __asm("d0") = version;
  __asm __volatile ("jsr a6@(-0x228)"
  : "=r" (_res)
  : "r" (a6), "r" (a1), "r" (d0)
  : "a0","a1","d0","d1", "memory");
  return _res;
}
static __inline void *
SuperState (BASE_PAR_DECL0)
{
  BASE_EXT_DECL
  register void  *_res	__asm("d0");
  register struct ExecBase *a6 __asm("a6") = BASE_NAME;
  __asm __volatile ("jsr a6@(-0x96)"
  : "=r" (_res)
  : "r" (a6)
  : "a0","a1","d0","d1", "memory");
  return _res;
}
#undef BASE_EXT_DECL
#undef BASE_PAR_DECL
#undef BASE_PAR_DECL0
#undef BASE_NAME

__END_DECLS

__BEGIN_DECLS

#ifndef BASE_PAR_DECL
#define BASE_PAR_DECL
#define BASE_PAR_DECL0 void
#endif
#ifndef BASE_NAME
#define BASE_NAME ExpansionBase
#endif

struct ExpansionBase;

static __inline struct ConfigDev *
FindConfigDev (BASE_PAR_DECL struct ConfigDev *oldConfigDev,long manufacturer,long product)
{
  extern struct ExpansionBase *BASE_NAME;
  register struct ConfigDev * _res  __asm("d0");
  register struct ExpansionBase* a6 __asm("a6") = BASE_NAME;
  register struct ConfigDev *a0 __asm("a0") = oldConfigDev;
  register long d0 __asm("d0") = manufacturer;
  register long d1 __asm("d1") = product;
  __asm __volatile ("jsr a6@(-0x48)"
  : "=r" (_res)
  : "r" (a6), "r" (a0), "r" (d0), "r" (d1)
  : "a0","a1","d0","d1", "memory");
  return _res;
}
#undef BASE_EXT_DECL
#undef BASE_PAR_DECL
#undef BASE_PAR_DECL0
#undef BASE_NAME

__END_DECLS

#endif /* KTYPES_H */
