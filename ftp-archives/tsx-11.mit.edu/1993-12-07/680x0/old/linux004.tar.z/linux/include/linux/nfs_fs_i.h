#ifndef _NFS_FS_I
#define _NFS_FS_I

#include <linux/nfs.h>

/*
 * nfs fs inode data in memory
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */
struct nfs_inode_info {
	struct nfs_fh fhandle;
};

#endif
