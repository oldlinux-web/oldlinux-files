/*
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#ifndef _LINUX_UTIME_H
#define _LINUX_UTIME_H

struct utimbuf {
	time_t actime;
	time_t modtime;
};

#endif
