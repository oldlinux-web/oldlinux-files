/*
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#ifndef _LINUX_PTRACE_H
#define _LINUX_PTRACE_H
/* ptrace.h */
/* structs and defines to help the user use the ptrace system call. */

/*
 * 680x0 support by Hamish Macdonald
 */

/* has the defines to get at the registers. */

#define PTRACE_TRACEME		   0
#define PTRACE_PEEKTEXT 	   1
#define PTRACE_PEEKDATA 	   2
#define PTRACE_PEEKUSR		   3
#define PTRACE_POKETEXT 	   4
#define PTRACE_POKEDATA 	   5
#define PTRACE_POKEUSR		   6
#define PTRACE_CONT		   7
#define PTRACE_KILL		   8
#define PTRACE_SINGLESTEP	   9

#define PTRACE_ATTACH		0x10
#define PTRACE_DETACH		0x11

#define PTRACE_SYSCALL		  24

/* use ptrace (3 or 6, pid, PT_EXCL, data); to read or write
   the processes registers. */

#define PT_D1	   0
#define PT_D2	   1
#define PT_D3	   2
#define PT_D4	   3
#define PT_D5	   4
#define PT_D6	   5
#define PT_D7	   6
#define PT_A0	   7
#define PT_A1	   8
#define PT_A2	   9
#define PT_A3	   10
#define PT_A4	   11
#define PT_A5	   12
#define PT_A6	   12
#define PT_D0	   13
#define PT_USP	   14
#define PT_ORIG_D0 15
#define PT_SR	   16
#define PT_PC	   17


/* this struct defines the way the registers are stored on the
   stack during a system call. */

struct pt_regs {
  long	d1;
  long	d2;
  long	d3;
  long	d4;
  long	d5;
  long	d6;
  long	d7;
  long	a0;
  long	a1;
  long	a2;
  long	a3;
  long	a4;
  long	a5;
  long	a6;
  long	d0;
  long	usp;
  long	orig_d0;
  short sr;
  long	pc;
};

#endif
