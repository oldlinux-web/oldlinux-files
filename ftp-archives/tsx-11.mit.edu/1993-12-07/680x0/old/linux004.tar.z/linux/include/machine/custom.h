/*
 *  linux/include/machine/custom.h
 *
 *  Copyright (C) 1993        Hamish Macdonald
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#ifndef _MACH_CUSTOM_H_
#define _MACH_CUSTOM_H_ 1

#include <linux/types.h>


struct Custom {
    u_short bltddat;
    u_short dmaconr;
    short   vposr;
    u_short vhposr;
    u_short dskdatr;
    u_short joy0dat;
    u_short joy1dat;
    u_short clxdat;
    u_short adkconr;
    u_short pot0dat;
    u_short pot1dat;
    u_short potgor;
    u_short serdatr;
    u_short dskbytr;
    u_short intenar;
    u_short intreqr;
    u_char  *dskpt;
    u_short dsklen;
    u_short dskdat;
    u_short refptr;
    u_short vpsow;
    u_short vhposw;
    u_short copcon;
    u_short serdat;
    u_short serper;
    u_short potgo;
    u_short joytest;
    u_short strequ;
    u_short strvbl;
    u_short strhor;
    u_short strlong;
    u_short bltcon0;
    u_short bltcon1;
    u_short bltafwm;
    u_short bltalwm;
    u_char  *bltcpt;
    u_char  *bltbpt;
    u_char  *bltapt;
    u_char  *bltdpt;
    u_short bltsize;
    u_short spare1[3];
    u_short bltcmod;
    u_short bltbmod;
    u_short bltamod;
    u_short bltdmod;
    u_short spare2[4];
    u_short bltcdat;
    u_short bltbdat;
    u_short bltadat;
    u_short spare3[4];;
    u_short dsksync;
    u_short *cop1lc;
    u_short *cop2lc;
    u_short copjmp1;
    u_short copjmp2;
    u_short copins;
    u_short diwstrt;
    u_short diwstop;
    u_short ddfstrt;
    u_short ddfstop;
    u_short dmacon;
    u_short clxcon;
    u_short intena;
    u_short intreq;
    u_short adkcon;
    u_char  *aud0lc;
    u_short aud0len;
    u_short aud0per;
    u_short aud0vol;
    u_short aud0dat;
    u_short aud0spare[2];
    u_char  *aud1lc;
    u_short aud1len;
    u_short aud1per;
    u_short aud1vol;
    u_short aud1dat;
    u_short aud1spare[2];
    u_char  *aud2lc;
    u_short aud2len;
    u_short aud2per;
    u_short aud2vol;
    u_short aud2dat;
    u_short aud2spare[2];
    u_char  *aud3lc;
    u_short aud3len;
    u_short aud3per;
    u_short aud3vol;
    u_short aud3dat;
    u_short aud3spare[2];
    u_char  *bplpt[6];
    u_short spare5[4];
    u_short bplcon0;
    u_short bplcon1;
    u_short bplcon2;
    u_short spare6;
    u_short bpl1mod;
    u_short bpl2mod;
    u_short spare7[2];
    u_short bpldat[6];
    u_short spare8[2];
    u_char  *sprpt[8];
    struct {
	u_short pos;
	u_short ctl;
	u_short dataa;
	u_short datab;
    } spr[8];
    u_short color[32];
};

#endif /* machine/custom.h */
