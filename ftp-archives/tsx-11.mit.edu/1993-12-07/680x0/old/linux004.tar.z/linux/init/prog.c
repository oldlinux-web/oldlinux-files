#include <stdarg.h>
#include <sys/types.h>
#include <wait.h>
#include <linux/fcntl.h>
#include <linux/signal.h>
#include <linux/unistd.h>

static inline _syscall3(int,write,int,fd,const char *,buf,off_t,count)

int errno;
int cons;

int printf (const char *fmt, ...)
{
    extern int vsprintf(char * buf, const char * fmt, va_list args);
    static char buf[256];
    va_list args;
    int i;

    va_start (args, fmt);
    i = vsprintf (buf, fmt, args);
    va_end (args);

    write (cons, buf, i);

    return i;
}

int main(void)
{
    int i;

    cons = open ("/dev/console", O_RDWR);

    printf ("Hello World (from exec)!\n");

    return 0;
}

void __main(void) {}
