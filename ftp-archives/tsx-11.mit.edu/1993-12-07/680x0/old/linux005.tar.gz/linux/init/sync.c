#include <linux/unistd.h>

static inline _syscall0(int,sync)

int main(void)
{
    sync();
}
