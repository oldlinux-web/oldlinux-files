/*
 * Copyright 1993 Hamish Macdonald
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#include <stdarg.h>
#include <linux/types.h>
#include <linux/fcntl.h>
#include <linux/unistd.h>
#include <linux/stat.h>
#include <linux/time.h>

#include <wait.h>

static inline _syscall3(int,write,int,fd,const char *,buf,off_t,count)
static inline _syscall3(int,read,int,fd,char *,buf,off_t,count)
static inline _syscall1(int,close,int,fd)
static inline _syscall2(int,fchmod,int,fd,int,mode)
static inline _syscall0(int,fork)
static inline _syscall0(int,sync)
static inline _syscall3(int,lseek,int,fd,long,offset,int,whence)
static inline _syscall3(int,execve,const char *,file,char **,argv,
			char **,envp)
static inline _syscall1(int,unlink,const char *,file)
static inline _syscall2(int,mkdir,const char *,path,int,mode)
static inline _syscall3(int,mknod,const char *,file,int,mode,dev_t,dev)

int errno;
extern int printf (const char *, ...);
extern void subproc(void);
extern void showstat (int pid, union wait status);
char str[] = "syscallret = %d\n";

void init(void)
{
    int pid;
    union wait status;

#if 1
    mkdir ( "/bin", S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH);
    mkdir ( "/dev", S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH);
    mknod ( "/dev/console", S_IFCHR | S_IWUSR | S_IRUSR, 0x0400);
#endif

    open ("/dev/console", O_RDWR); /* -> fd 0 */

    if (fork() == 0)
	subproc();

    while (1) {
	pid = wait4(-1,&status.w_status,WUNTRACED,NULL);
	if (pid != -1)
	    showstat (pid, status);
    }
}

void showstat (int pid, union wait status)
{
    if (WIFSTOPPED(status))
	printf ("pid %d stopped with signal %d\n", pid, WSTOPSIG(status));
    else if (WIFSIGNALED(status))
	printf ("pid %d terminated with signal %d\n", pid, WTERMSIG(status));
    else if (WIFEXITED(status))
	printf ("pid %d exited with code %d\n", pid, WEXITSTATUS(status));
}

int printf (const char *fmt, ...)
{
    extern int vsprintf(char * buf, const char * fmt, va_list args);
    static char buf[256];
    va_list args;
    int i;

    va_start (args, fmt);
    i = vsprintf (buf, fmt, args);
    va_end (args);

    write (0, buf, i);

    return i;
}

#define STRING(id)      #id

void subproc(void)
{
    int fd, nr;
    char buffer[80];
    unsigned long sum;
    extern char progdata[];
    extern int progsize;
    char *filetodel, *filetowrite;
    char *argv[2], *envp[2];

#ifdef PROGTOWRITE
    filetowrite=PROGTOWRITE;

    fd = open (filetowrite, O_CREAT | O_WRONLY | O_TRUNC);

    if (fd == -1) {
	printf ("open (write) of %s failed.  errno=%d\n", filetowrite, errno);
	_exit(1);
    }

    if (write (fd, progdata, progsize) != progsize) {
	printf ("write of %s failed.  errno=%d\n", filetowrite, errno);
	_exit(1);
    }

    if (fchmod (fd, S_IRWXU) == -1) {
	printf ("fchmod of %s failed.  errno=%d\n", filetowrite, errno);
	_exit(1);
    }

    close (fd);

    sync ();

    printf ("wrote to %s\n", filetowrite);
#endif

    argv[0] = "/bin/notsh";
    argv[1] = NULL;
    envp[0] = "HOME=/";
    envp[1] = NULL;

    if (execve ("/bin/notsh", argv, envp) == -1) {
	printf ("execve of %s failed.  errno=%d\n", filetowrite, errno);
	_exit(1);
    }

    _exit(0);
}
