/*
 *  linux/init/config.c
 *
 *  Copyright (C) 1993, Hamish Macdonald
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#include <linux/config.h>
#include <linux/types.h>
#include <linux/sys_info.h>
#include <linux/fs.h>
#include <linux/tty.h>
#include <linux/console.h>

#include <amiga/config.h>
#include <atari/config.h>
#include <mac/config.h>


void (*mach_sched_init) (isrfunc);
unsigned long (*mach_keyb_init) (unsigned long);
void (*mach_init_INTS) (void);
int (*mach_add_isr) (unsigned long, isrfunc, int, void *);
void (*mach_gettime_usecs) (struct timeval *);

void config_init(void)
{
    switch (sys_info.machtype) {
      case MACH_AMIGA:
	config_amiga();
      case MACH_ATARI:
	config_atari();
      case MACH_MAC:
	config_mac();
    }
}
