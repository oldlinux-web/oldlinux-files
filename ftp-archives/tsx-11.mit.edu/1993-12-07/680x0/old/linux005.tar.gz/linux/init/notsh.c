#include <stdarg.h>
#include <linux/types.h>
#include <linux/fcntl.h>
#include <linux/unistd.h>
#include <linux/stat.h>

#include <wait.h>

#define BUF_SIZ   256

int cd_cmd (int ac, char **av);
int echo_cmd (int ac, char **av);
int sync_cmd (int ac, char **av);
int exit_cmd (int ac, char **av);

struct {
    char *name;
    int (*routine)(int, char **);
} cmds[] = { { "cd", cd_cmd },
	     { "echo", echo_cmd },
	     { "sync", sync_cmd },
	     { "exit", exit_cmd },
	     {NULL, NULL}};

int printf (const char *, ...);
char *getline(void);
int execute (const char *, char **);
extern int enargv(const char *buf, char **av, int avsiz,
		  char *tobuf, int biz);
extern char **environ;
static inline _syscall0(int,sync);
static inline _syscall0(int,fork);
static inline _syscall2(int,dup2,int,oldfd,int,newfd);
static inline _syscall3(int,execve,char *,prog,char **,av,char **,ev);
static inline _syscall3(int,write,int,fd,void *,buf,int,count);
static inline _syscall3(int,read,int,fd,void *,buf,int,count);
static inline _syscall1(int,chdir,char *,dir);
char *argv0;

int main(int argc, char *argv[])
{
    int fd;
    char *p;

    argv0 = argv[0];
    p = argv0 + strlen(argv0) - 1;
    while (p > argv0 && *p != '/')
	p--;
    if (p > argv0)
	argv0 = p+1;

    fd = open ("/dev/console", O_RDONLY);
    dup2 (fd, 0);
    fd = open ("/dev/console", O_WRONLY);
    dup2 (fd, 1);
    dup2 (fd, 2);

    while (1) {
	char *line, *ecmd;
	static char obuf[1024];
	char *av[10];
	int i, retval, ac;

	printf ("%s $ ", argv0);
	line = getline();

	if (!line) {
	    printf ("%s exiting on EOF\n", argv0);
	    _exit(0);
	}

	if (!*line)
	    continue;

	ac = enargv(line, av, 10, obuf, 1024);

	for (i = 0; cmds[i].name; i++) {
	    if (strcmp (cmds[i].name, av[0]) == 0) {
		retval = cmds[i].routine (ac, av);
		break;
	    }
	}

	if (!cmds[i].name)
	   execute (av[0], av);
    }
}

int cd_cmd (int ac, char **av)
{
    int retval;

    if (ac > 1)
	retval = chdir (av[1]);
    else
	retval = chdir ("/");

    if (retval != 0) {
	printf ("%s: cd failed (errno=%d)\n", argv0, errno);
	return -1;
    } else
	return 0;
}

int echo_cmd (int ac, char **av)
{
    while (ac--)
	printf ("%s ", *av++);
    printf ("\n");
}

int sync_cmd (int ac, char **av)
{
   sync();
}

int exit_cmd (int ac, char **av)
{
    int exitcode;

    if (ac > 1)
	exitcode = *av[1] - '0';
    else
	exitcode = 0;

    printf ("%s: exiting by command\n", argv0);
    exitcode = _exit(exitcode);

    printf ("%s: _exit failed (errno=%d)\n", argv0, errno);

    return -1;
}

int printf (const char *fmt, ...)
{
    extern int vsprintf(char * buf, const char * fmt, va_list args);
    static char buf[BUF_SIZ];
    va_list args;
    int i;

    va_start (args, fmt);
    i = vsprintf (buf, fmt, args);
    va_end (args);

    write (1, buf, i);

    return i;
}

char *getline(void)
{
    static char buffer[BUF_SIZ];
    int nread;

    nread = read (0, buffer, BUF_SIZ-1);

    switch (nread) {
      case 0:
	return NULL;
	break;
      case -1:
	printf ("%s: read failed (errno=%d)\n", argv0, errno);
	return NULL;
	break;
      default:
	if (buffer[nread-1] == '\n')
	    buffer[nread-1] = '\0';
	else
	    buffer[nread] = '\0';
	return buffer;
    }
}

void showstat (union wait status)
{
    if (WIFSTOPPED(status))
	printf ("stopped with signal %d\n", WSTOPSIG(status));
    else if (WIFSIGNALED(status))
	printf ("terminated with signal %d\n", WTERMSIG(status));
    else if (WIFEXITED(status) && WEXITSTATUS(status))
	printf ("exited with code %d\n", WEXITSTATUS(status));
}

int execute (const char *file, char **av)
{
    union wait status;
    static char buf[256];

    if (fork () == 0) {
	if (*file == '/')
	    strcpy (buf, file);
	else {
	    strcpy (buf, "/bin/");
	    strcat (buf, file);
	}
	if (execve (buf, av, environ) == -1) {
	    printf ("%s: failed to execute '%s' (errno=%d)\n",
		    argv0, file, errno);
	    _exit (1);
	}
    } else
	wait(&status);
    showstat (status);
}

#if 0
#include	<ctype.h>
#else
#define isspace(c) ((c) == ' ' || (c) == '\n' || (c) == '\t')
#define isprint(c) ((c) >= 32 && (c) < 127)
#endif

/*
main()
{
	char	buf[1024];
	char	obuf[1024];
	char	*av[100];
	int	ax;
	int	y;

	while(gets(buf)) {
		ax = enargv(buf,av,100,obuf,1024);
		for(y = 0; y < ax; y++)
			printf("av[%d] = \"%s\"\n",y,av[y]);
	}
	exit(0);
}
*/


/* enargv(). Marcus J. Ranum, 1993. Placed into the public domain. */
enargv(buf,av,avsiz,tobuf,bsiz)
const char    *buf;
char	**av;
int	avsiz;
char	*tobuf;
int	bsiz;
{
	register  const char	*ip = buf;
	register	char	*op = tobuf;
	register	char	*sp = 0;
	int		u_ac = 0;
	int		quot = 0;


	while(isspace(*ip) || !isprint(*ip) || *ip == ',')
		ip++;

	while(*ip) {
		if(!isprint(*ip)) {
			ip++;
			continue;
		}

		if(!quot && (*ip == '\"' || *ip == '\'')) {
			quot = *ip++;
			continue;
		}
		if(isspace(*ip) && !quot) {
			if(--bsiz < 0)
				return(0);
			*op++ = '\0';

			if(u_ac  + 1 >= avsiz)
				return(u_ac);

			av[u_ac++] = sp;
			sp = av[u_ac] = (char *)0;

			while(isspace(*ip))
				ip++;

			if(*ip == '\0')
				break;
			continue;
		}

		if(quot && *ip == quot) {
			quot = 0;
			ip++;
			continue;
		}

		if(*ip == '\\') {
			if(--bsiz < 0)
				return(0);
			switch(*++ip) {
			case	't':
				*op++ = '\t';
				break;

			case	'n':
				*op++ = '\n';
				break;

			default:
				*op++ = *ip;
			}
			ip++;
			continue;
		}

		if(sp == (char *)0)
			sp = op;
		if(--bsiz < 0)
			return(0);
		*op++ = *ip++;
	}

	if(sp != 0) {
		*op = '\0';

		if(u_ac  + 1 >= avsiz)
			return(u_ac);
		av[u_ac++] = sp;
		av[u_ac] = (char *)0;
	}
	return(u_ac);
}
