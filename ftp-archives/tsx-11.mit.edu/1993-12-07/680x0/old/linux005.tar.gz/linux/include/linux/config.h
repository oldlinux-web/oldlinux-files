/*
 *  linux/include/linux/config.h
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#ifndef _LINUX_CONFIG_H
#define _LINUX_CONFIG_H

#include <linux/autoconf.h>
#include <linux/traps.h>
#include <linux/time.h>

/*
 * Defines for what uname() should return
 */
#ifndef UTS_SYSNAME
#define UTS_SYSNAME "Linux"
#endif
#ifndef UTS_NODENAME
#define UTS_NODENAME "(none)"   /* set by sethostname() */
#endif
#define UTS_MACHINE "amiga"     /* hardware type */
/*
 * The definitions for UTS_RELEASE and UTS_VERSION are now defined
 * in linux/version.h, and should only be used by linux/version.c
 */

/* interrupt service routine function ptr type */
typedef void (*isrfunc) (struct frame *fp, void *data);

extern void (*mach_sched_init) (isrfunc);
extern unsigned long (*mach_keyb_init) (unsigned long);
extern void (*mach_init_INTS) (void);
extern int (*mach_add_isr) (unsigned long source, isrfunc isr,
			    int pri, void *data);
extern void (*mach_gettime_usecs)(struct timeval *tv);

#endif /* linux/config.h */
