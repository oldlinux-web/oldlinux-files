/*
 *  linux/include/linux/console.h
 *
 *  Copyright (C) 1993        Hamish Macdonald
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#ifndef _LINUX_CONSOLE_H_
#define _LINUX_CONSOLE_H_ 1

struct consw {
    int    (*con_init)();
    int    (*con_deinit)();
    int    (*con_clear)();
    int    (*con_putc)();
    int    (*con_cursor)();
    int    (*con_scroll)();
    int    (*con_switch)();
};

extern struct consw *conswitchp;

struct condata {
    int          flags;
    struct consw *sw;
    short        curx, cury;
    short        cursorx, cursory;
    short        rows, cols;
    short        attribute;
};

extern struct condata vc_cons[NR_CONSOLES];

/* flag bits */
#define CON_INITED  (1)

/* definitions for draw mode */
#define DM_CLEAR    (1)
#define DM_COPY     (2)
#define DM_XOR      (3)
#define DM_INVERSE  (4)

/* scroll */
#define SM_UP       (1)
#define SM_DOWN     (2)
#define SM_LEFT     (3)
#define SM_RIGHT    (4)

/* cursor */
#define CM_DRAW     (1)
#define CM_ERASE    (2)
#define CM_MOVE     (3)

#endif /* linux/console.h */
