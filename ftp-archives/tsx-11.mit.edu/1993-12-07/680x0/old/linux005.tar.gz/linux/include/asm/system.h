/*
 *  linux/include/asm/system.h
 *
 *  Copyright (C) 1991, 1992  Linus Torvalds
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

/*
 * 680x0 support added by Hamish Macdonald
 */

#ifndef _ASM_SYSTEM_H
#define _ASM_SYSTEM_H

#define sti() __asm__ __volatile__ ("andiw #0xf8ff,sr"::: "sr")
#define cli() __asm__ __volatile__ ("oriw  #0x0700,sr"::: "sr")
#define nop() __asm__ __volatile__ ("nop"::)

#define save_flags(x) \
__asm__ __volatile__("movew sr,%0":"=d" (x))

#define restore_flags(x) \
__asm__ __volatile__("movew %0,sr"::"d" (x))

#define iret() __asm__ __volatile__ ("rte"::)

#define move_to_user_mode() \
    __asm__ __volatile__ ("movec %0,usp\n\t"     /* setup user sp       */ \
			  "movel %1,sp\n\t"      /* setup kernel sp     */ \
			  "movew %2,sp@\n\t"     /* user mode sr        */ \
			  "movel %3,sp@(2)\n\t"  /* user pc             */ \
			  "movew %4,sp@(6)\n\t"  /* format word         */ \
			  "rte"                  /* return to user mode */ \
			  :: "d" (current->start_stack),                   \
			  "d" (KSTACK_ADDR + PAGE_SIZE - 8),               \
			  "d" (0x1000), "d" (0), "d" (0))

#endif /* _ASM_SYSTEM_H */
