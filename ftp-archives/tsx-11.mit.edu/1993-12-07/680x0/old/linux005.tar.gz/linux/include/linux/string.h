/*
 *  linux/include/linux/string.h
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#ifndef _LINUX_STRING_H_
#define _LINUX_STRING_H_

#include <linux/types.h>	/* for size_t */

char * strcpy(char * dest,const char *src);
char * strncpy(char * s1,const char *s2,size_t n);
char * strcat(char * dest,const char * src);
char * strncat(char * s1,const char * s2,size_t n);
int    strcmp(const char * p1,const char * p2);
int    strncmp(const char * s1,const char * s2,size_t n);
char * strchr(const char * s,char ci);
char * strrchr(const char * s,char c);
size_t strspn(const char * s, const char * accept);
size_t strcspn(const char * s, const char * reject);
char * strpbrk(const char * s,const char * accept);
char * strstr(const char * haystack,const char * needle);
size_t strlen(const char * str);
char * strtok(char * s,const char * ct);
void * memcpy(void * to, const void * from, size_t len);
void * bcopy(const void * from, void * to, size_t len);
void * memmove(void * dest,const void * src, size_t len);
int    memcmp(const void * cs,const void * ct,size_t count);
void * memchr(const void * cs,char c,size_t count);
void * memset(void * dstpp, int c, size_t len);

#endif /* _LINUX_STRING_H_ */
