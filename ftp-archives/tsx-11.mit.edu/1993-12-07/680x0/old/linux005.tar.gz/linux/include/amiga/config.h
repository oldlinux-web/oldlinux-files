/*
 *  linux/include/amiga/config.h
 *
 *  Copyright (C) 1993        Hamish Macdonald
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#ifndef _AMIGA_CONFIG_H_
#define _AMIGA_CONFIG_H_ 1

#ifdef CONFIG_AMIGA

#include <amiga/chipregs.h>

extern void amiga_sched_init(isrfunc);
extern unsigned long amiga_keyb_init(unsigned long);
extern void amiga_init_INTS (void);
extern int amiga_add_isr (unsigned long, isrfunc, int, void *);
extern void amiga_gettime_usecs (struct timeval *);
extern struct consw ami_con;

static __inline void config_amiga(void)
{
    mach_sched_init    = amiga_sched_init;
    mach_keyb_init     = amiga_keyb_init;
    mach_init_INTS     = amiga_init_INTS;
    mach_add_isr       = amiga_add_isr;
    mach_gettime_usecs = amiga_gettime_usecs;
    conswitchp	       = &ami_con;

    /* set up hardware bases */
    CustomBase = (caddr_t)CUSTOM_PHYSADDR;
    CiaABase   = (caddr_t)CIAA_PHYSADDR;
    CiaBBase   = (caddr_t)CIAB_PHYSADDR;
}

#else  /* !CONFIG_AMIGA */

static __inline void config_amiga(void) {}

#endif /* CONFIG_AMIGA */

#endif /* amiga/config.h */
