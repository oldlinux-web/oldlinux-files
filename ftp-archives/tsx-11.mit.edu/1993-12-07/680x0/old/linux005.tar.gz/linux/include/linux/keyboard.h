/*
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#ifndef __LINUX_KEYBOARD_H
#define __LINUX_KEYBOARD_H

#define set_leds() mark_bh(KEYBOARD_BH)

/*
 * Global flags: things that don't change between virtual consoles.
 * This includes things like "key-down" flags - if the shift key is
 * down when you change a console, it's down in both.
 *
 * Note that the KG_CAPSLOCK flags is NOT the flag that decides if
 * capslock is on or not: it's just a flag about the key being
 * physically down. The actual capslock status is in the local flags.
 */
extern unsigned long kbd_flags;

/*
 * These are the hardcoded global flags - use the numbers beyond 16
 * for non-standard or keyboard-dependent flags
 */
#define KG_LSHIFT	0
#define KG_RSHIFT	1
#define KG_LCTRL	2
#define KG_RCTRL	3
#define KG_ALT		4
#define KG_ALTGR	5
#define KG_CAPSLOCK	6

/*
 * machine specific modifiers.
 * e.g. Lamiga and Ramiga on the Amiga.
 *      Loption and Roption on the Mac
 */
#define KG_LMACH       17
#define KG_RMACH       18

/*
 * "dead" keys - prefix key values that are valid only for the next
 * character code (sticky shift, E0/E1 special scancodes, diacriticals)
 */
extern unsigned long kbd_dead_keys;
extern unsigned long kbd_prev_dead_keys;

/*
 * these are the hardcoded dead key flags
 */
#define KGD_E0		0
#define KGD_E1		1

/*
 * kbd->xxx contains the VC-local things (flag settings etc..)
 * The low 3 local flags are hardcoded to be the led setting..
 */
struct kbd_struct {
	unsigned long flags;
	unsigned long default_flags;
	unsigned char kbd_flags;
};

extern struct kbd_struct kbd_table[];
extern struct kbd_struct *kbd;
extern struct tty_struct *kb_tty;

/*
 * These are the local "softflags", giving actual keyboard modes. The
 * three first flags are coded to the led settings.
 */
#define VC_SCROLLOCK	0	/* scroll-lock mode */
#define VC_NUMLOCK	1	/* numeric lock mode */
#define VC_CAPSLOCK	2	/* capslock mode */
#define VC_APPLIC	3	/* application key mode */
#define VC_CKMODE	5	/* cursor key mode */
#define VC_REPEAT	6	/* keyboard repeat */
#define VC_RAW		7	/* raw (scancode) mode */
#define VC_CRLF 	8	/* 0 - enter sends CR, 1 - enter sends CRLF */
#define VC_META 	9	/* 0 - meta, 1 - meta=prefix with ESC */
#define VC_PAUSE	10	/* pause key pressed */

#define LED_MASK	7

extern unsigned long kbd_init(unsigned long);

extern inline int kbd_flag(int flag)
{
	return kbd_flags & (1 << flag);
}

extern inline void set_kbd_flag(int flag)
{
	kbd_flags |= 1 << flag;
}

extern inline void clr_kbd_flag(int flag)
{
	kbd_flags &= ~(1 << flag);
}

extern inline void chg_kbd_flag(int flag)
{
	kbd_flags ^= 1 << flag;
}

extern inline int kbd_dead(int flag)
{
	return kbd_prev_dead_keys & (1 << flag);
}

extern inline void set_kbd_dead(int flag)
{
	kbd_dead_keys |= 1 << flag;
}

extern inline void clr_kbd_dead(int flag)
{
	kbd_dead_keys &= ~(1 << flag);
}

extern inline void chg_kbd_dead(int flag)
{
	kbd_dead_keys ^= 1 << flag;
}

extern inline int vc_kbd_flag(struct kbd_struct * kbd, int flag)
{
	return ((kbd->flags >> flag) & 1);
}

extern inline void set_vc_kbd_flag(struct kbd_struct * kbd, int flag)
{
	kbd->flags |= 1 << flag;
}

extern inline void clr_vc_kbd_flag(struct kbd_struct * kbd, int flag)
{
	kbd->flags &= ~(1 << flag);
}

extern inline void chg_vc_kbd_flag(struct kbd_struct * kbd, int flag)
{
	kbd->flags ^= 1 << flag;
}

/*
 * Definitions for virtual keyboard action table
 */
extern struct tty_struct *kb_tty;

typedef void (*fptr)(int);
extern fptr key_table[];
extern void kb_put_queue(int);

/*
 * Define the "virtual" keyboard keys.
 *
 * The platform dependent keycodes are mapped
 * to these values.
 */

#define KB_A			(0)
#define KB_B			(1)
#define KB_C			(2)
#define KB_D			(3)
#define KB_E			(4)
#define KB_F			(5)
#define KB_G			(6)
#define KB_H			(7)
#define KB_I			(8)
#define KB_J			(9)
#define KB_K			(10)
#define KB_L			(11)
#define KB_M			(12)
#define KB_N			(13)
#define KB_O			(14)
#define KB_P			(15)
#define KB_Q			(16)
#define KB_R			(17)
#define KB_S			(18)
#define KB_T			(19)
#define KB_U			(20)
#define KB_V			(21)
#define KB_W			(22)
#define KB_X			(23)
#define KB_Y			(24)
#define KB_Z			(25)
#define KB_0			(26)
#define KB_1			(27)
#define KB_2			(28)
#define KB_3			(29)
#define KB_4			(30)
#define KB_5			(31)
#define KB_6			(32)
#define KB_7			(33)
#define KB_8			(34)
#define KB_9			(35)
#define KB_ESCAPE		(36)
#define KB_BACKSPACE		(37)
#define KB_DELETE		(38)
#define KB_TAB			(39)
#define KB_SPACE		(40)
#define KB_DASH			(41)
#define KB_EQUAL		(42)
#define KB_SLASH		(43)
#define KB_BACKSLASH		(44)
#define KB_LSQUARE		(45)
#define KB_RSQUARE		(46)
#define KB_BACKQUOTE		(47)
#define KB_SEMICOLON		(48)
#define KB_COMMA		(49)
#define KB_PERIOD		(50)
#define KB_APOSTROPHE		(51)

#define KB_F1			(52)
#define KB_F2			(53)
#define KB_F3			(54)
#define KB_F4			(55)
#define KB_F5			(56)
#define KB_F6			(57)
#define KB_F7			(58)
#define KB_F8			(59)
#define KB_F9			(60)
#define KB_F10			(61)
#define KB_F11			(62)
#define KB_F12			(63)

#define KB_KP0			(64)
#define KB_KP1			(65)
#define KB_KP2			(66)
#define KB_KP3			(67)
#define KB_KP4			(68)
#define KB_KP5			(69)
#define KB_KP6			(70)
#define KB_KP7			(71)
#define KB_KP8			(72)
#define KB_KP9			(73)

#define KB_ENTER		(74)
#define KB_HELP			(75)

#define KB_UP			(76)
#define KB_DOWN			(77)
#define KB_LEFT			(78)
#define KB_RIGHT		(79)

#define KB_NUMLOCK		(80)
#define KB_SCROLLLOCK		(81)
#define KB_KPSLASH		(82)
#define KB_KPSTAR		(83)
#define KB_KPPLUS		(84)
#define KB_KPMINUS		(85)
#define KB_KPENTER		(86)
#define KB_KPDECIMAL		(87)

#define KB_LSHIFT		(88)
#define KB_RSHIFT		(89)
#define KB_LCTRL		(90)
#define KB_RCTRL		(91)
#define KB_LALT			(92)
#define KB_RALT			(93)
#define KB_CAPS			(94)
#define KB_LMACH		(95) /* e.g. LAmiga, Loption */
#define KB_RMACH		(96) /* e.g. Ramiga, Roption */

#define KB_UNLSHIFT		(97)
#define KB_UNRSHIFT		(98)
#define KB_UNLCTRL		(99)
#define KB_UNRCTRL		(100)
#define KB_UNLALT		(101)
#define KB_UNRALT		(102)
#define KB_UNCAPS		(103)
#define KB_UNLMACH		(104)
#define KB_UNRMACH		(105)

/* signifies a nil (do nothing) key */
#define KB_NONE                 (108)

#endif
