/*
 *  linux/include/linux/traps.h
 *
 *  Copyright (C) 1993        Hamish Macdonald
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#ifndef _LINUX_TRAPS_H
#define _LINUX_TRAPS_H

typedef void (*vector)(void);

extern vector vectors[];

#define VEC_BUSERR  (2)
#define VEC_ADDRERR (3)
#define VEC_SPUR    (24)
#define VEC_INT1    (25)
#define VEC_INT2    (26)
#define VEC_INT3    (27)
#define VEC_INT4    (28)
#define VEC_INT5    (29)
#define VEC_INT6    (30)
#define VEC_INT7    (31)
#define VEC_SYS     (32)

#define VECOFF(vec) ((vec)<<2)

/* Status register bits */
#define PS_S  (0x2000)

/* bits for special status word */

#define FC    (0x8000)
#define FB    (0x4000)
#define RC    (0x2000)
#define RB    (0x1000)
#define DF    (0x0100)
#define RM    (0x0080)
#define RW    (0x0040)
#define SZ    (0x0030)
#define DFC   (0x0007)

/* Address spaces (FC0-FC2) */
#define USER_DATA     (1)
#define USER_PROGRAM  (2)
#define SUPER_DATA    (5)
#define SUPER_PROGRAM (6)
#define CPU_SPACE     (7)

/* structure for stack frames */

struct frame {
    unsigned long  regs[14];	/* d1-a6 */
    unsigned long  d0;		/* d0 */
    unsigned long  usp; 	/* user stack pointer */
    unsigned long  orig_d0;	/* orig_d0 */
    unsigned short sr;		/* status register */
    unsigned long  pc;		/* program counter */
    unsigned	   format : 4;	/* frame format specifier */
    unsigned	   vector :12;	/* vector offset */
    union {
	struct {
	    unsigned long iaddr;    /* instruction address */
	} fmt2;
	struct {
	    unsigned long iaddr;    /* instruction address */
	    unsigned short int1[4]; /* internal registers */
	} fmt9;
	struct {
	    unsigned short int1;
	    unsigned short ssw;     /* special status word */
	    unsigned short isc;     /* instruction stage c */
	    unsigned short isb;     /* instruction stage b */
	    unsigned long  daddr;   /* data cycle fault address */
	    unsigned short int2[2];
	    unsigned long  dobuf;   /* data cycle output buffer */
	    unsigned short int3[2];
	} fmta;
	struct {
	    unsigned short int1;
	    unsigned short ssw;     /* special status word */
	    unsigned short isc;     /* instruction stage c */
	    unsigned short isb;     /* instruction stage b */
	    unsigned long  daddr;   /* data cycle fault address */
	    unsigned short int2[2];
	    unsigned long  dobuf;   /* data cycle output buffer */
	    unsigned short int3[4];
	    unsigned long  baddr;   /* stage B address */
	    unsigned short int4[2];
	    unsigned long  dibuf;   /* data cycle input buffer */
	    unsigned short int5[3];
	    unsigned	   ver : 4; /* stack frame version # */
	    unsigned	   int6:12;
	    unsigned short int7[18];
	} fmtb;
    } un;
};


#endif /* _LINUX_TRAPS_H */
