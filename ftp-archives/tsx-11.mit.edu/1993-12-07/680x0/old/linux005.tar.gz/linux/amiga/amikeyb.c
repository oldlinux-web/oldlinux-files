/*
 * linux/kernel/amiga/amikeyb.c
 *
 * Amiga Keyboard driver for 680x0 Linux
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

/*
 * Amiga support by Hamish Macdonald
 */

#include <linux/config.h>

#ifdef CONFIG_AMIGA

#include <linux/sched.h>
#include <linux/ctype.h>
#include <linux/tty.h>
#include <linux/keyboard.h>
#include <linux/interrupt.h>

#include <amiga/types.h>
#include <amiga/interrupt.h>
#include <amiga/chipregs.h>

/* the number of CIA EClock ticks required to handshake a character */
#define ECLOCK_HANDSHAKE   (64)

extern void do_keyboard_interrupt (void);
extern void do_gettimeofday (struct timeval *);

extern unsigned char ami_kmap[];

static void keyboard_interrupt(struct frame *fp, void *data)
{
    static unsigned char rep = 0xff;
    unsigned char scancode, keycode;
    struct timeval endtime, curtime;

    /* get and invert scancode (keyboard is active low) */
    scancode = ~ciaa.sdr;

    /* switch SP pin to output and record time for start of handshake */
    ciaa.cra |= 0x40;
    do_gettimeofday (&endtime);
    endtime.tv_usec += 85;
    if (endtime.tv_usec > 1000000) {
	endtime.tv_sec++;
	endtime.tv_usec -= 1000000;
    }

    /* rotate scan code to get up/down bit in proper position */
    __asm__ __volatile__ ("rorb #1,%0" : "=g" (scancode) : "0" (scancode));

    kb_tty = TTY_TABLE(0);
    kbd = kbd_table + fg_console;
    if (vc_kbd_flag(kbd,VC_RAW)) {
	kbd_flags = 0;
	kb_put_queue(scancode);
	goto end_of_int;
    }

    /*
     *	Repeat a key only if the input buffers are empty or the
     *	characters get echoed locally. This makes key repeat usable
     *	with slow applications and unders heavy loads.
     */
    if (scancode == rep) {
	if (!(vc_kbd_flag(kbd,VC_REPEAT) && kb_tty &&
	      (L_ECHO(kb_tty) ||
	       (EMPTY(&kb_tty->secondary) &&
		EMPTY(&kb_tty->read_q)))))
	    goto end_of_int;
    }
    rep = scancode;
    keycode = ami_kmap[scancode];
    if (scancode < 0x80 && keycode == KB_NONE)
	printk ("\ncode is %#x\n", scancode);

    key_table[keycode](keycode);

end_of_int:
    do_keyboard_interrupt();

    /* wait until 85 us have expired */
    do {
	do_gettimeofday (&curtime);
    } while (curtime.tv_sec <= endtime.tv_sec &&
	     curtime.tv_usec <= endtime.tv_usec);

    /* switch CIA serial port to input mode */
    ciaa.cra &= ~0x40;
    return;
}

unsigned long amiga_keyb_init (unsigned long mem_start)
{
    /*
     * Initialize serial data direction.
     */
    ciaa.cra &= ~0x41;	     /* serial data in, turn off TA */

    /*
     * arrange for processing of keyboard interrupt
     */
    add_isr (IRQ_AMIGA_CIAA_SP, keyboard_interrupt, 0, NULL);

    return mem_start;
}

static unsigned char ami_kmap[256] =
{
/* 00-03 */    KB_BACKQUOTE,  KB_1,	    KB_2,	  KB_3,
/* 04-07 */    KB_4,	      KB_5,	    KB_6,	  KB_7,
/* 08-0B */    KB_8,	      KB_9,	    KB_0,	  KB_DASH,
/* 0C-0F */    KB_EQUAL,      KB_BACKSLASH, KB_NONE,	  KB_KP0,
/* 10-13 */    KB_Q,	      KB_W,	    KB_E,	  KB_R,
/* 14-17 */    KB_T,	      KB_Y,	    KB_U,	  KB_I,
/* 18-1B */    KB_O,	      KB_P,	    KB_LSQUARE,   KB_RSQUARE,
/* 1C-1F */    KB_NONE,       KB_KP1,	    KB_KP2,	  KB_KP3,
/* 20-23 */    KB_A,	      KB_S,	    KB_D,	  KB_F,
/* 24-27 */    KB_G,	      KB_H,	    KB_J,	  KB_K,
/* 28-2B */    KB_L,	      KB_SEMICOLON, KB_APOSTROPHE,KB_NONE,
/* 2C-2F */    KB_NONE,       KB_KP4,	    KB_KP5,	  KB_KP6,
/* 30-33 */    KB_NONE,       KB_Z,	    KB_X,	  KB_C,
/* 34-37 */    KB_V,	      KB_B,	    KB_N,	  KB_M,
/* 38-3B */    KB_COMMA,      KB_PERIOD,    KB_SLASH,	  KB_NONE,
/* 3C-3F */    KB_KPDECIMAL,  KB_KP7,	    KB_KP8,	  KB_KP9,
/* 40-43 */    KB_SPACE,      KB_BACKSPACE, KB_TAB,	  KB_KPENTER,
/* 44-47 */    KB_ENTER,      KB_ESCAPE,    KB_DELETE,	  KB_NONE,
/* 48-4B */    KB_NONE,       KB_NONE,	    KB_KPMINUS,   KB_NONE,
/* 4C-4F */    KB_UP,	      KB_DOWN,	    KB_RIGHT,	  KB_LEFT,
/* 50-53 */    KB_F1,	      KB_F2,	    KB_F3,	  KB_F4,
/* 54-57 */    KB_F5,	      KB_F6,	    KB_F7,	  KB_F8,
/* 58-5B */    KB_F9,	      KB_F10,	    KB_NUMLOCK,   KB_SCROLLLOCK,
/* 5B-5F */    KB_KPSLASH,    KB_KPSTAR,    KB_KPPLUS,	  KB_HELP,
/* 60-63 */    KB_LSHIFT,     KB_RSHIFT,    KB_CAPS,	  KB_LCTRL,
/* 64-67 */    KB_LALT,       KB_RALT,	    KB_LMACH,	  KB_RMACH,
/* 68-6B */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 6C-6F */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 70-73 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 74-77 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 78-7B */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 7C-7F */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,

/* 80-83 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 84-87 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 88-8B */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 8C-8F */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 90-93 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 94-97 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 98-9B */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 9C-9F */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* A0-A3 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* A4-A7 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* A8-AB */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* AC-AF */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* B0-B3 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* B4-B7 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* B8-BB */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* BC-BF */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* C0-C3 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* C4-C7 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* C8-CB */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* CC-CF */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* D0-D3 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* D4-D7 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* D8-DB */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* DC-DF */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* E0-E3 */    KB_UNLSHIFT,   KB_UNRSHIFT,  KB_UNCAPS,	  KB_UNLCTRL,
/* E4-E7 */    KB_UNLALT,     KB_UNRALT,    KB_UNLMACH,   KB_UNRMACH,
/* E8-EB */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* EC-EF */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* F0-F3 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* F4-F7 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* F8-FB */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* FC-FF */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE
};

#endif /* CONFIG_AMIGA */
