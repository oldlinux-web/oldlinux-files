/*
**  linux/amiga/amicon.c
**
**  Copyright (C) 1993 Hamish Macdonald and Greg Harp
**
**  Last Modified 2/22/93 by Greg Harp
**
** This file is subject to the terms and conditions of the GNU General Public
** License.  See the file README.legal in the main directory of this archive
** for more details.
*/

#include <linux/types.h>
#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/tty.h>
#include <linux/console.h>
#include <linux/string.h>

#include <amiga/chipregs.h>
#include <amiga/interrupt.h>

/*
** Macros
*/

#define COP_LIST_BASE	0x0400
#define BITPL_BASE	0x1000
#define CURSOR_BASE	0xc000

#define HIRES		0x8000
#define ONE_BIT_PLANE	0x1000
#define COMPOSITE	0x0200
#define LACE		0x0004

#define DEFAULT_MODE	(HIRES | ONE_BIT_PLANE | COMPOSITE | LACE)

#define SCR_MAX_WIDTH	704
#define SCR_MAX_HEIGHT	480
#define SCR_WIDTH	640
#define SCR_HEIGHT	400

#define CUSTOM_OFS(fld) ((long)&((struct CUSTOM*)0)->fld)
#define COP_LIST_ENTS	30

#define MEM_REQ 	((SCR_WIDTH/8) * SCR_HEIGHT)
#define COP_MEM_REQ	(COPENTS*4*2)

#define DIWSTRT_V	(0x18 + (SCR_MAX_HEIGHT - SCR_HEIGHT)/4)
#define DIWSTRT_H	(0x71 + (SCR_MAX_WIDTH - SCR_WIDTH)/4)
#define DIWSTOP_V	((0x108 - (SCR_MAX_HEIGHT - SCR_HEIGHT)/4) & 0xff)
#define DIWSTOP_H	(0xd5 - (SCR_MAX_WIDTH - SCR_WIDTH)/4)

#define DIWSTRT 	((DIWSTRT_V << 8) + DIWSTRT_H)
#define DIWSTOP 	((DIWSTOP_V << 8) + DIWSTOP_H)

#define DDFSTRT 	(((ushort)DIWSTRT_H >> 1) - 4)
#define DDFSTOP 	((ushort)DDFSTRT + (4 * (SCR_WIDTH/16 - 2)))

#define FG_COLOR	0x000 /* black */
#define BG_COLOR	0xaaa /* lt. grey */
#define CURSOR_COLOR	0x00a /* med. blue */

/*
** Externals
*/

extern unsigned char
    fontdata[];

extern int
    fontheight,
    fontwidth;

extern char
    fontname[];

/*
** Local Variables
*/

static struct
{
    ushort scr_height;		/* screen dimensions */
    ushort scr_width;

    ushort diwstrt;		/* display window control */
    ushort diwstop;

    ushort ddfstrt;		/* data fetch control */
    ushort ddfstop;

    ushort mode;		/* display mode */

    ushort fgcol;		/* text colors */
    ushort bgcol;
    ushort crsrcol;

    u_char *bitplane;		/* pointer to display bitplane */

    ushort *coplist1;		/* copper list pointers */
    ushort *coplist2;
} disp[NR_CONSOLES];

static ushort *cursor, *dummy;

static ushort cursor_data[] =
{
    0x2c81,0x2d00,
    0xf000,0x0000,
    0x0000,0x0000
};

/*
** Prototypes
*/

static int amicon_init();
static int amicon_deinit();
static int amicon_clear();
static int amicon_putc();
static int amicon_cursor();
static int amicon_scroll();
static int amicon_switch();

/*
** Global Variables
*/

struct consw ami_con =
{
    amicon_init, amicon_deinit, amicon_clear, amicon_putc,
    amicon_cursor, amicon_scroll, amicon_switch
};

/*
** Functions
*/

static void initcop(int unit, ushort *cop, ushort *othercop, int shf)
{
    int i;

    long scrmem = (long)disp[unit].bitplane;

    if (shf)
	scrmem += vc_cons[unit].cols;

    /* 1-2: Store bitplane address in BPL0PTx */
    *cop++ = CUSTOM_OFS(bplpt[0]);
    *cop++ = (long)scrmem >> 16;
    *cop++ = CUSTOM_OFS(bplpt[0]) + 2;
    *cop++ = (long)scrmem;

    /* 3-4: Modify Copper list pointer to use other list next time */
    *cop++ = CUSTOM_OFS(cop1lc);
    *cop++ = (long)othercop >> 16;
    *cop++ = CUSTOM_OFS(cop1lc) + 2;
    *cop++ = (long)othercop;

    /* 5-6: Point Sprite 0 at cursor sprite */
    *cop++ = CUSTOM_OFS(sprpt[0]);
    *cop++ = (ushort)((long)cursor >> 16);
    *cop++ = CUSTOM_OFS(sprpt[0]) + 2;
    *cop++ = (ushort)((long)cursor & 0x0000ffff);

    /* 7-20: Point Sprites 1-7 at dummy sprite */
    for (i=1; i<8; i++) {
	*cop++ = CUSTOM_OFS(sprpt[i]);
	*cop++ = (ushort)((long)dummy >> 16);
	*cop++ = CUSTOM_OFS(sprpt[i]) + 2;
	*cop++ = (ushort)((long)dummy & 0x0000ffff);
    }

    /* 21: End of Copper list */
    *(int*)cop = 0xfffffffe;
}

static int amicon_init(struct condata *conp)
{
    int i;
    int unit = conp - vc_cons;

    /* set up the display defaults */
    disp[unit].scr_height = SCR_HEIGHT;
    disp[unit].scr_width = SCR_WIDTH;

    disp[unit].diwstrt = DIWSTRT;
    disp[unit].diwstop = DIWSTOP;

    disp[unit].ddfstrt = DDFSTRT;
    disp[unit].ddfstop = DDFSTOP;

    disp[unit].mode = DEFAULT_MODE;

    disp[unit].fgcol = FG_COLOR;
    disp[unit].bgcol = BG_COLOR;
    disp[unit].crsrcol = CURSOR_COLOR;

    conp->cols = SCR_WIDTH / fontwidth;
    conp->rows = SCR_HEIGHT / fontheight;

    /* locate the copper list */
    disp[unit].coplist1 = (ushort *)COP_LIST_BASE;
    disp[unit].coplist2 = (ushort *)(COP_LIST_BASE + COP_LIST_ENTS * 4);

    /* locate the bitplane */
    disp[unit].bitplane = (u_char *)BITPL_BASE;

    /* locate the sprite data */
    cursor = (ushort *)CURSOR_BASE; /* bitplane may be up to 704x480 */
    dummy = (short *)(CURSOR_BASE + 12);

    /* copy the sprite data into Chip mem */
    for (i=0; i<6; i++)
	cursor[i] = cursor_data[i];

    /* set dummy sprite data to a blank sprite */
    for (i=0; i<6; i++)
	dummy[i] = 0x0000;

    /* set the modulo */
    custom.bpl1mod = conp->cols;

    /* set the display mode */
    custom.bplcon0 = disp[unit].mode;

    /* set DIWSTRT */
    custom.diwstrt = disp[unit].diwstrt;

    /* set DIWSTOP */
    custom.diwstop = disp[unit].diwstop;

    /* set DDFSTRT */
    custom.ddfstrt = disp[unit].ddfstrt;

    /* set DDFSTOP */
    custom.ddfstop = disp[unit].ddfstop;

    /* set background color */
    custom.color[0] = disp[unit].bgcol;

    /* set foreground color */
    custom.color[1] = disp[unit].fgcol;

    /* set sprite 0 color */
    custom.color[17] = disp[unit].crsrcol;

    /* clear display memory */
    memset (disp[unit].bitplane, 0, MEM_REQ);

    /* initialize LOF Copper List */
    initcop(unit, disp[unit].coplist1, disp[unit].coplist2, 0);

    /* initialize SHF Copper List */
    initcop(unit, disp[unit].coplist2, disp[unit].coplist1, 1);

    /* turn on DMA for bitplane and sprites */
    custom.dmacon = 0x83a0;

    /* set up copper */
    custom.cop1lc = disp[unit].coplist1;
    custom.copjmp1 = 0;

    /* reset vertical blank interrupt */
    custom.intreq = IF_VERTB;

    /* wait for vertical blank interrupt */
    while ((custom.intreqr & IF_VERTB) != IF_VERTB)
	;

    /* set bitplane pointers based on LOF/SHF bit */
    if (custom.vposr & 0x8000) {
	custom.cop1lc = disp[unit].coplist1;
	custom.copjmp1 = 0;
    } else {
	custom.cop1lc = disp[unit].coplist2;
	custom.copjmp1 = 0;
    }

    return 0;
}

static int amicon_deinit (struct condata *conp)
{
    return 0;
}

static void amicon_movedata (u_char *src,
			     ushort srcx, ushort srcy, ushort srcmod,
			     u_char *dst,
			     ushort dstx, ushort dsty, ushort dstmod,
			     ushort height, ushort width, ushort dmode)
{
    int i;

    src += srcmod * srcy + (srcx >> 3);
    dst += dstmod * dsty + (dstx >> 3);

    if ((srcx & 7) || (dstx & 7) || (width & 7))
	panic ("amicon: bad offset");

    width >>= 3;
    while (height--) {
	if (src > dst)
	    for (i = 0; i < width; i++)
		switch (dmode) {
		  case DM_COPY:
		    dst[i] = src[i];
		    break;
		  case DM_CLEAR:
		    dst[i] = 0;
		    break;
		  case DM_XOR:
		    dst[i] ^= src[i];
		    break;
		  case DM_INVERSE:
		    dst[i] = ~src[i];
		    break;
		}
	else
	    for (i = width - 1; i >= 0; i--)
		switch (dmode) {
		  case DM_COPY:
		    dst[i] = src[i];
		    break;
		  case DM_CLEAR:
		    dst[i] = 0;
		    break;
		  case DM_XOR:
		    dst[i] ^= src[i];
		    break;
		  case DM_INVERSE:
		    dst[i] = ~src[i];
		    break;
		}

	src += srcmod;
	dst += dstmod;
    }
}

static void amicon_bmove (struct condata *conp,
			 int sy, int sx, int dy, int dx,
			 int height, int width)
{
    int unit = conp - vc_cons;

    amicon_movedata (disp[unit].bitplane, sx * fontwidth,
		     sy * fontheight, disp[unit].scr_width >> 3,
		     disp[unit].bitplane, dx * fontwidth,
		     dy * fontheight, disp[unit].scr_width >> 3,
		     height * fontheight, width * fontwidth, DM_COPY);
}

static int amicon_clear (struct condata *conp,
		  int sy, int sx, int height, int width)
{
    int unit = conp - vc_cons;

    amicon_movedata (0, 0, 0, 0,
		     disp[unit].bitplane, sx * fontwidth, sy * fontheight,
		     disp[unit].scr_width >> 3,
		     height * fontheight, width * fontwidth, DM_CLEAR);

    return 0;
}

static int amicon_putc (struct condata *conp,
		 int c, int y, int x, int mode)
{
    int unit = conp - vc_cons;

    if ((c >= 32) && (c < 127))
	/* lower half of charset -- normal ASCII */
	c -=  32;
    else if ((c >= 160) && (c < 255))
	/* upper half of charset -- special characters */
	c -= 64;
    else
	/* not defined in charset -- non-printable character */
	return 0;

    amicon_movedata (fontdata, 0, c * fontheight, 1,
		     disp[unit].bitplane, x * fontwidth,
		     y * fontheight, disp[unit].scr_width >> 3,
		     fontheight, fontwidth, DM_COPY);

    return 0;
}

static int amicon_cursor (struct condata *conp,
			  int mode)
{
    int unit = conp - vc_cons;
    int vs, hs;

    if (mode == CM_ERASE) {
/*	*(long *)cursor = 0;*/
    } else {
	vs = (disp[unit].diwstrt >> 8) +
	    ((conp->cury + 1) * fontheight) / 2 - 1;
	hs = (disp[unit].diwstrt & 0x00ff) +
	    (conp->curx * fontwidth) / 2 - 1;
	*(long *)cursor = (vs << 24) + ((hs & 0x000001fe) << 15) +
	    (((vs+1) & 0x000000ff) << 8) + (vs & 0x00000100) +
		(((vs+1) & 0x00000100) >> 1) + (hs & 0x00000001);

	conp->cursorx = conp->curx;
	conp->cursory = conp->cury;
    }

    return 0;
}

static int amicon_scroll (struct condata *conp,
		   int sy, int sx, int count, int dir)
{
    int height, dy, i;

    amicon_cursor (conp, CM_ERASE);

    if (dir == SM_UP) {
	dy = sy - count;
	height = conp->rows - sy;
	for (i = 0; i < height; i++)
	    amicon_bmove (conp, sy + i, 0, dy + i, 0, 1, conp->cols);
    }

    return 0;
}

static int amicon_switch (struct condata *conp)
{
    return 0;
}
