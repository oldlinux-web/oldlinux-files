/*
 * amiints.c -- Amiga Linux interrupt handling code
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 *
 */

#include <linux/types.h>
#include <linux/config.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>

#include <asm/system.h>

#include <amiga/chipregs.h>
#include <amiga/interrupt.h>

/* isrfunc variables for amiga interrupt sources */
static isr_node_t *ami_lists[NUM_AMIGA_SOURCES];

static const ushort ami_intena_vals[NUM_AMIGA_SOURCES] = {
    IF_VERTB, IF_COPER, IF_AUD0, IF_AUD1, IF_AUD2, IF_AUD3, IF_BLIT,
    IF_DSKSYN, IF_DSKBLK, IF_RBF, IF_TBE, IF_PORTS, IF_PORTS, IF_PORTS,
    IF_PORTS, IF_PORTS, IF_EXTER, IF_EXTER, IF_EXTER, IF_EXTER, IF_EXTER,
    IF_SOFT, IF_PORTS, IF_EXTER
    };

struct ciadata
{
    volatile struct CIA *ciaptr;
    unsigned long	baseirq;
} ciadata[2];

/*
 * index into ami_lists for IRQs.  CIA IRQs are special, because
 * the same cia interrupt handler is used for both CIAs.
 */
#define IRQ_IDX(source) (source & ~IRQ_MACHSPEC)
#define CIA_IRQ_IDX(source) (IRQ_IDX(datap->baseirq) \
			     +(source-IRQ_AMIGA_CIAA_TA))

/*
 * void amiga_init_INTS (void)
 *
 * Parameters:	None
 *
 * Returns:	Nothing
 *
 * This function should be called during kernel startup to initialize
 * the amiga IRQ handling routines.
 */

static void
    ami_int1(struct frame *, void *), ami_int2(struct frame *, void *),
    ami_int3(struct frame *, void *), ami_int4(struct frame *, void *),
    ami_int5(struct frame *, void *), ami_int6(struct frame *, void *),
    ami_int7(struct frame *, void *), ami_intcia(struct frame *, void *);

void amiga_init_INTS (void)
{
    int i;

    /* initialize handlers */
    for (i = 0; i < NUM_AMIGA_SOURCES; i++)
	ami_lists[i] = NULL;

    add_isr (IRQ1, ami_int1, 0, NULL);
    add_isr (IRQ2, ami_int2, 0, NULL);
    add_isr (IRQ3, ami_int3, 0, NULL);
    add_isr (IRQ4, ami_int4, 0, NULL);
    add_isr (IRQ5, ami_int5, 0, NULL);
    add_isr (IRQ6, ami_int6, 0, NULL);
    add_isr (IRQ7, ami_int7, 0, NULL);

    /* hook in the CIA interrupts */
    ciadata[0].ciaptr = &ciaa;
    ciadata[0].baseirq = IRQ_AMIGA_CIAA_TA;
    add_isr (IRQ_AMIGA_PORTS, ami_intcia, 0, &ciadata[0]);
    ciadata[1].ciaptr = &ciab;
    ciadata[1].baseirq = IRQ_AMIGA_CIAB_TA;
    add_isr (IRQ_AMIGA_EXTER, ami_intcia, 0, &ciadata[1]);

    /* turn off all interrupts and enable the master interrupt bit */
    custom.intena = 0x7fff;
    custom.intreqr = 0x7fff;
    custom.intena = 0xc000;

    /* turn off all CIA interrupts */
    ciaa.icr = 0x7f;
    ciab.icr = 0x7f;

    /* clear any pending CIA interrupts */
    i = ciaa.icr;
    i = ciab.icr;
}


/*
 * The builtin Amiga hardware interrupt handlers.
 */

static void ami_int1 (struct frame *fp, void *data)
{
    ushort ints = custom.intreqr & custom.intenar;

    /* if serial transmit buffer empty, interrupt */
    if (ints & IF_TBE) {
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_TBE)], fp);

	/* acknowledge */
	custom.intreq = IF_TBE;
    }

    /* if floppy disk transfer complete, interrupt */
    if (ints & IF_DSKBLK) {
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_DSKBLK)], fp);

	/* acknowledge */
	custom.intreq = IF_DSKBLK;
    }

    /* if software interrupt set, interrupt */
    if (ints & IF_SOFT) {
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_SOFT)], fp);

	/* acknowledge */
	custom.intreq = IF_SOFT;
    }
}

static void ami_int2 (struct frame *fp, void *data)
{
    ushort ints = custom.intreqr & custom.intenar;

    if (ints & IF_PORTS) {
	/* call routines which have hooked into the PORTS interrupt */
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_PORTS)], fp);

	/* acknowledge */
	custom.intreq = IF_PORTS;
    }
}

static void ami_int3 (struct frame *fp, void *data)
{
    ushort ints = custom.intreqr & custom.intenar;

    /* if a copper interrupt */
    if (ints & IF_COPER) {
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_COPPER)], fp);

	/* acknowledge */
	custom.intreq = IF_COPER;
    }

    /* if a vertical blank interrupt */
    if (ints & IF_VERTB) {
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_VERTB)], fp);

	/* acknowledge */
	custom.intreq = IF_VERTB;
    }

    /* if a blitter interrupt */
    if (ints & IF_BLIT) {
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_BLIT)], fp);

	/* acknowledge */
	custom.intreq = IF_BLIT;
    }
}

static void ami_int4 (struct frame *fp, void *data)
{
    ushort ints = custom.intreqr & custom.intenar;

    /* if audio 0 interrupt */
    if (ints & IF_AUD0) {
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_AUD0)], fp);

	/* acknowledge */
	custom.intreq = IF_AUD0;
    }

    /* if audio 1 interrupt */
    if (ints & IF_AUD1) {
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_AUD1)], fp);

	/* acknowledge */
	custom.intreq = IF_AUD1;
    }

    /* if audio 2 interrupt */
    if (ints & IF_AUD2) {
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_AUD2)], fp);

	/* acknowledge */
	custom.intreq = IF_AUD2;
    }

    /* if audio 3 interrupt */
    if (ints & IF_AUD3) {
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_AUD3)], fp);

	/* acknowledge */
	custom.intreq = IF_AUD3;
    }
}

static void ami_int5 (struct frame *fp, void *data)
{
    ushort ints = custom.intreqr & custom.intenar;

    /* if serial receive buffer full interrupt */
    if (ints & IF_RBF) {
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_RBF)], fp);

	/* acknowledge */
	custom.intreq = IF_RBF;
    }

    /* if a disk sync interrupt */
    if (ints & IF_DSKSYN) {
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_DSKSYN)], fp);

	/* acknowledge */
	custom.intreq = IF_DSKSYN;
    }
}

static void ami_int6 (struct frame *fp, void *data)
{
    ushort ints = custom.intreqr & custom.intenar;

    if (ints & IF_EXTER) {
	/* call routines which have hooked into the EXTER interrupt */
	call_isr_list (ami_lists[IRQ_IDX(IRQ_AMIGA_EXTER)], fp);

	/* acknowledge */
	custom.intreq = IF_EXTER;
    }
}

static void ami_int7 (struct frame *fp, void *data)
{
    panic ("level 7 interrupt received\n");
}

static void ami_intcia (struct frame *fp, void *data)
{
    /* check CIA interrupts */
    struct ciadata *datap = (struct ciadata *)data;
    u_char cia_ints = datap->ciaptr->icr;

    /* if timer A interrupt */
    if (cia_ints & CIA_ICR_TA)
	call_isr_list (ami_lists[CIA_IRQ_IDX(IRQ_AMIGA_CIAA_TA)], fp);

    /* if timer B interrupt */
    if (cia_ints & CIA_ICR_TB)
	call_isr_list (ami_lists[CIA_IRQ_IDX(IRQ_AMIGA_CIAA_TB)], fp);

    /* if the alarm interrupt */
    if (cia_ints & CIA_ICR_ALRM)
	call_isr_list (ami_lists[CIA_IRQ_IDX(IRQ_AMIGA_CIAA_ALRM)], fp);

    /* if serial port interrupt (keyboard) */
    if (cia_ints & CIA_ICR_SP)
	call_isr_list (ami_lists[CIA_IRQ_IDX(IRQ_AMIGA_CIAA_SP)], fp);

    /* if flag interrupt (parallel port) */
    if (cia_ints & CIA_ICR_FLG)
	call_isr_list (ami_lists[CIA_IRQ_IDX(IRQ_AMIGA_CIAA_FLG)], fp);
}

/*
 * amiga_add_isr : add an interrupt service routine for a particular
 *		   machine specific interrupt source.
 *		   If the addition was successful, it returns 1, otherwise
 *		   it returns 0.  It will fail if another routine is already
 *		   bound into the specified source.
 *   Note that the "pri" argument is currently unused.
 */

int amiga_add_isr (unsigned long source, isrfunc isr, int pri, void *data)
{
    unsigned long amiga_source = source & ~IRQ_MACHSPEC;
    isr_node_t *p;

    if (amiga_source > NUM_AMIGA_SOURCES) {
	printk ("amiga_add_isr: Unknown interrupt source %ld\n", source);
	return 0;
    }

    p = new_isr_node();
    p->isr = isr;
    p->pri = pri;
    p->data = data;
    p->next = NULL;
    insert_isr (&ami_lists[amiga_source], p);

    /* enable the interrupt */
    custom.intena = IF_SETCLR | ami_intena_vals[amiga_source];

    /* if a CIAA interrupt, enable the appropriate CIA ICR bit */
    if (source >= IRQ_AMIGA_CIAA_TA && source <= IRQ_AMIGA_CIAA_FLG)
	ciaa.icr = 0x80 | (1 << (source - IRQ_AMIGA_CIAA_TA));

    /* if a CIAB interrupt, enable the appropriate CIA ICR bit */
    if (source >= IRQ_AMIGA_CIAB_TA && source <= IRQ_AMIGA_CIAB_FLG)
	ciab.icr = 0x80 | (1 << (source - IRQ_AMIGA_CIAB_TA));

    return 1;
}
