/*
 * linux/kernel/chr_drv/keyboard.c
 *
 * Keyboard driver for Linux v0.96 using Latin-1.
 *
 * Written for linux by Johan Myreen as a translation from
 * the assembly version by Linus (with diacriticals added)
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

/*
 * general 680x0 support by Hamish Macdonald
 */

#include <linux/sched.h>
#include <linux/ctype.h>
#include <linux/tty.h>
#include <linux/mm.h>
#include <linux/keyboard.h>
#include <linux/config.h>
#include <linux/signal.h>

#ifndef KBD_DEFFLAGS
#ifdef CONFIG_KBD_META
#define KBD_DEFFLAGS ((1 << VC_NUMLOCK) | (1 << VC_REPEAT) | (1 << VC_META))
#else
#define KBD_DEFFLAGS ((1 << VC_NUMLOCK) | (1 << VC_REPEAT))
#endif
#endif

extern void change_console(unsigned int new_console);

unsigned long kbd_flags = 0;
unsigned long kbd_dead_keys = 0;
unsigned long kbd_prev_dead_keys = 0;

static int last_console = 0; /* last used VC */
struct kbd_struct kbd_table[NR_CONSOLES];
struct kbd_struct *kbd = kbd_table;
struct tty_struct *kb_tty = NULL;

static int diacr = -1;
static int npadch = 0;
fptr key_table[];

static void applkey(int);
static void cur(int);
static unsigned int handle_diacr(unsigned int);

void kb_put_queue(int ch)
{
    struct tty_queue *qp;
    unsigned long new_head;

#ifdef DEBUG
    printk ("&keypress_wait is %#lx\n", &keypress_wait);
    printk ("keypress_wait is %#lx\n", keypress_wait);
    if (keypress_wait) {
	printk ("keypress_wait points to:\n");
	printk ("   task:    %#lx\n", keypress_wait->task);
	printk ("   next:    %#lx\n", keypress_wait->next);
    }
#endif
    wake_up(&keypress_wait);
    if (!kb_tty)
	return;
    qp = &kb_tty->read_q;

    qp->buf[qp->head]=ch;
    if ((new_head=(qp->head+1)&(TTY_BUF_SIZE-1)) != qp->tail)
	qp->head=new_head;
    wake_up_interruptible(&qp->proc_list);
}

static void puts_queue(char *cp)
{
    struct tty_queue *qp;
    unsigned long new_head;
    char ch;

#ifdef DEBUG
    printk ("&keypress_wait is %#lx\n", &keypress_wait);
    printk ("keypress_wait is %#lx\n", keypress_wait);
    if (keypress_wait) {
	printk ("keypress_wait points to:\n");
	printk ("   task:    %#lx\n", keypress_wait->task);
	printk ("   next:    %#lx\n", keypress_wait->next);
    }
#endif
    wake_up(&keypress_wait);
    if (!kb_tty)
	return;
    qp = &kb_tty->read_q;

    while ((ch = *(cp++)) != 0) {
	qp->buf[qp->head]=ch;
	if ((new_head=(qp->head+1)&(TTY_BUF_SIZE-1))
	    != qp->tail)
	    qp->head=new_head;
    }
    wake_up_interruptible(&qp->proc_list);
}

static void ctrl(int sc)
{
    if (kbd_dead(KGD_E0))
	    set_kbd_flag(KG_RCTRL);
    else
	set_kbd_flag(KG_LCTRL);
}

static void alt(int sc)
{
    if (kbd_dead(KGD_E0))
	set_kbd_flag(KG_ALTGR);
    else
	set_kbd_flag(KG_ALT);
}

static void unctrl(int sc)
{
    if (kbd_dead(KGD_E0))
	clr_kbd_flag(KG_RCTRL);
    else
	clr_kbd_flag(KG_LCTRL);
}

static void unalt(int sc)
{
    if (kbd_dead(KGD_E0))
	clr_kbd_flag(KG_ALTGR);
    else {
	clr_kbd_flag(KG_ALT);
	if (npadch != 0) {
	    kb_put_queue(npadch);
	    npadch=0;
	}
    }
}

static void lshift(int sc)
{
    set_kbd_flag(KG_LSHIFT);
}

static void unlshift(int sc)
{
    clr_kbd_flag(KG_LSHIFT);
}

static void rshift(int sc)
{
    set_kbd_flag(KG_RSHIFT);
}

static void unrshift(int sc)
{
    clr_kbd_flag(KG_RSHIFT);
}

static void caps(int sc)
{
    if (kbd_flag(KG_CAPSLOCK))
	return; 	/* key already pressed: defeat repeat */
    set_kbd_flag(KG_CAPSLOCK);
    chg_vc_kbd_flag(kbd,VC_CAPSLOCK);
}

static void uncaps(int sc)
{
    clr_kbd_flag(KG_CAPSLOCK);
    chg_vc_kbd_flag(kbd,VC_CAPSLOCK);
}

static void lmach(int sc)
{
    set_kbd_flag(KG_LMACH);
}

static void unlmach(int sc)
{
    clr_kbd_flag(KG_LMACH);
}

static void rmach(int sc)
{
    set_kbd_flag(KG_RMACH);
}

static void unrmach(int sc)
{
    clr_kbd_flag(KG_RMACH);
}

static void scroll(int sc)
{
    if (kbd_dead(KGD_E0))
	kb_put_queue(INTR_CHAR(kb_tty));
    else if (kbd_flag(KG_LSHIFT) || kbd_flag(KG_RSHIFT))
	show_mem();
    else if (kbd_flag(KG_LCTRL) || kbd_flag(KG_RCTRL))
	show_state();
    else {
	if (vc_kbd_flag(kbd, VC_SCROLLOCK))
	     /* pressing srcoll lock 2nd time sends ^Q, ChN */
	    kb_put_queue(START_CHAR(kb_tty));
	else
	    /* pressing srcoll lock 1st time sends ^S, ChN */
	    kb_put_queue(STOP_CHAR(kb_tty));
	    chg_vc_kbd_flag(kbd,VC_SCROLLOCK);
    }
}

static void num(int sc)
{
    if (kbd_flag(KG_LCTRL))
	/* pause key pressed, sends E1 1D 45, ChN */
	chg_vc_kbd_flag(kbd,VC_PAUSE);
    else if (vc_kbd_flag(kbd,VC_APPLIC))
	applkey(0x50);
    else
	chg_vc_kbd_flag(kbd,VC_NUMLOCK);
}

static void applkey(int key)
{
    char buf[] = { 0x1b, 0x4f, 0x00, 0x00 };

    buf[2] = key;
    puts_queue(buf);
}

static void sysreq(int sc)
{
#if 0
	/* pressing alt-printscreen switches to the last used console, ChN */
	if ( sc != rep)
		want_console = last_console;
#endif
}

#if defined KBD_FINNISH

static unsigned char key_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0',  '+', '\'',  127,    9,
	'q',  'w',  'e',  'r',  't',  'y',  'u',  'i',
	'o',  'p',  '}',    0,   13,    0,  'a',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',  '|',
	'{',    0,    0, '\'',  'z',  'x',  'c',  'v',
	'b',  'n',  'm',  ',',  '.',  '-',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char shift_map[] = {
	  0,   27,  '!', '\"',  '#',  '$',  '%',  '&',
	'/',  '(',  ')',  '=',  '?',  '`',  127,    9,
	'Q',  'W',  'E',  'R',  'T',  'Y',  'U',  'I',
	'O',  'P',  ']',  '^',   13,    0,  'A',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L', '\\',
	'[',    0,    0,  '*',  'Z',  'X',  'C',  'V',
	'B',  'N',  'M',  ';',  ':',  '_',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '>',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char alt_map[] = {
	  0,	0,    0,  '@',  163,  '$',    0,    0,
	'{',   '[',  ']', '}', '\\',    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,  '~',   13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,  '|',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_FINNISH_LATIN1

static unsigned char key_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0',  '+',  180,  127,    9,
	'q',  'w',  'e',  'r',  't',  'y',  'u',  'i',
	'o',  'p',  229,  168,   13,    0,  'a',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',  246,
	228,  167,    0, '\'',  'z',  'x',  'c',  'v',
	'b',  'n',  'm',  ',',  '.',  '-',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char shift_map[] = {
	  0,   27,  '!',  '"',  '#',  '$',  '%',  '&',
	'/',  '(',  ')',  '=',  '?',  '`',  127,    9,
	'Q',  'W',  'E',  'R',  'T',  'Y',  'U',  'I',
	'O',  'P',  197,  '^',   13,    0,  'A',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L',  214,
	196,  189,    0,  '*',  'Z',  'X',  'C',  'V',
	'B',  'N',  'M',  ';',  ':',  '_',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '>',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char alt_map[] = {
	  0,	0,    0,  '@',  163,  '$',    0,    0,
	'{',  '[',  ']',  '}', '\\',    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,  '~',   13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,  '|',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_US

static unsigned char key_map[] = {
	'a',  'b',  'c',  'd',  'e',  'f',  'g',  'h',
	'i',  'j',  'k',  'l',  'm',  'n',  'o',  'p',
	'q',  'r',  's',  't',  'u',  'v',  'w',  'x',
	'y',  'z',  '0',  '1',  '2',  '3',  '4',  '5',
	'6',  '7',  '8',  '9',   27, '\b',  127, '\t',
	' ',  '-',  '=',  '/', '\\',  '[',  ']',  '`',
	';',  ',',  '.', '\''};

static unsigned char shift_map[] = {
	'A',  'B',  'C',  'D',  'E',  'F',  'G',  'H',
	'I',  'J',  'K',  'L',  'M',  'N',  'O',  'P',
	'Q',  'R',  'S',  'T',  'U',  'V',  'W',  'X',
	'Y',  'Z',  ')',  '!',  '@',  '#',  '$',  '%',
	'^',  '&',  '*',  '(',   27, '\b',  127, '\t',
	' ',  '_',  '+',  '?',  '|',  '{',  '}',  '~',
	':',  '<',  '>',  '"'};

static unsigned char alt_map[] = {
	'a',  'b',  'c',  'd',  'e',  'f',  'g',  'h',
	'i',  'j',  'k',  'l',  'm',  'n',  'o',  'p',
	'q',  'r',  's',  't',  'u',  'v',  'w',  'x',
	'y',  'z',  '0',  '1',  '2',  '3',  '4',  '5',
	'6',  '7',  '8',  '9',   27, '\b',  127, '\t',
	' ',  '-',  '=',  '/', '\\',  '[',  ']',  '`',
	';',  ',',  '.', '\''};

#elif defined KBD_UK

static unsigned char key_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0',  '-',  '=',  127,    9,
	'q',  'w',  'e',  'r',  't',  'y',  'u',  'i',
	'o',  'p',  '[',  ']',   13,    0,  'a',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',  ';',
	'\'', '`',    0,  '#',  'z',  'x',  'c',  'v',
	'b',  'n',  'm',  ',',  '.',  '/',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0, '\\',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char shift_map[] = {
	  0,   27,  '!',  '"',  163,  '$',  '%',  '^',
	'&',  '*',  '(',  ')',  '_',  '+',  127,    9,
	'Q',  'W',  'E',  'R',  'T',  'Y',  'U',  'I',
	'O',  'P',  '{',  '}',   13,    0,  'A',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L',  ':',
	'@',  '~',  '0',  '~',  'Z',  'X',  'C',  'V',
	'B',  'N',  'M',  '<',  '>',  '?',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '|',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char alt_map[] = {
	  0,	0,    0,  '@',    0,  '$',    0,    0,
	'{',   '[',  ']', '}', '\\',    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,  '~',   13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,  '|',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_GR

static unsigned char key_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0', '\\', '\'',  127,    9,
	'q',  'w',  'e',  'r',  't',  'z',  'u',  'i',
	'o',  'p',  '@',  '+',   13,    0,  'a',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',  '[',
	']',  '^',    0,  '#',  'y',  'x',  'c',  'v',
	'b',  'n',  'm',  ',',  '.',  '-',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char shift_map[] = {
	  0,   27,  '!',  '"',  '#',  '$',  '%',  '&',
	'/',  '(',  ')',  '=',  '?',  '`',  127,    9,
	'Q',  'W',  'E',  'R',  'T',  'Z',  'U',  'I',
	'O',  'P', '\\',  '*',   13,    0,  'A',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L',  '{',
	'}',  '~',    0, '\'',  'Y',  'X',  'C',  'V',
	'B',  'N',  'M',  ';',  ':',  '_',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '>',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char alt_map[] = {
	  0,	0,    0,  '@',    0,  '$',    0,    0,
	'{',   '[',  ']', '}', '\\',    0,    0,    0,
	'@',    0,    0,    0,    0,    0,    0,    0,
	  0,	0,    0,  '~',   13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,  '|',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_GR_LATIN1

static unsigned char key_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0', 223,  180,  127,    9,
	'q',  'w',  'e',  'r',  't',  'z',  'u',  'i',
	'o',  'p',  252,  '+',   13,    0,  'a',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l', 246,
	228,   94,    0,  '#',  'y',  'x',  'c',  'v',
	'b',  'n',  'm',  ',',  '.',  '-',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char shift_map[] = {
	  0,   27,  '!',  '"',  167,  '$',  '%',  '&',
	'/',  '(',  ')',  '=',  '?',  '`',  127,    9,
	'Q',  'W',  'E',  'R',  'T',  'Z',  'U',  'I',
	'O',  'P',  220,  '*',   13,    0,  'A',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L',  214,
	196,  176,    0, '\'',  'Y',  'X',  'C',  'V',
	'B',  'N',  'M',  ';',  ':',  '_',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '>',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char alt_map[] = {
	  0,	0,    0,  178,	179,  '$',    0,    0,
	'{',   '[',  ']', '}', '\\',    0,    0,    0,
	'@',    0,    0,    0,    0,    0,    0,    0,
	  0,	0,    0,  '~',   13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  181,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,  '|',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_FR

static unsigned char key_map[] = {
	  0,   27,  '&',  '{',  '"', '\'',  '(',  '-',
	'}',  '_',  '/',  '@',  ')',  '=',  127,    9,
	'a',  'z',  'e',  'r',  't',  'y',  'u',  'i',
	'o',  'p',  '^',  '$',   13,    0,  'q',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',  'm',
	'|',  '`',    0,   42,  'w',  'x',  'c',  'v',
	'b',  'n',  ',',  ';',  ':',  '!',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char shift_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0',  ']',  '+',  127,    9,
	'A',  'Z',  'E',  'R',  'T',  'Y',  'U',  'I',
	'O',  'P',  '<',  '>',   13,    0,  'Q',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L',  'M',
	'%',  '~',    0,  '#',  'W',  'X',  'C',  'V',
	'B',  'N',  '?',  '.',  '/', '\\',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '>',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char alt_map[] = {
	  0,	0,    0,  '~',  '#',  '{',  '[',  '|',
	'`', '\\',   '^',  '@', ']',  '}',    0,    0,
	'@',    0,    0,    0,    0,    0,    0,    0,
	  0,	0,    0,  '~',   13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,  '|',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_FR_LATIN1

static unsigned char key_map[] = {
	  0,   27,  '&',  233,  '"', '\'',  '(',  '-',
	232,  '_',  231,  224,  ')',  '=',  127,    9,
	'a',  'z',  'e',  'r',  't',  'y',  'u',  'i',
	'o',  'p',  '^',  '$',   13,    0,  'q',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',  'm',
	249,  178,    0,   42,	'w',  'x',  'c',  'v',
	'b',  'n',  ',',  ';',  ':',  '!',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char shift_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0',  176,  '+',  127,    9,
	'A',  'Z',  'E',  'R',  'T',  'Y',  'U',  'I',
	'O',  'P',  168,  163,   13,    0,  'Q',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L',  'M',
	'%',    0,    0,  181,  'W',  'X',  'C',  'V',
	'B',  'N',  '?',  '.',  '/',  167,    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '>',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char alt_map[] = {
	  0,	0,    0,  '~',  '#',  '{',  '[',  '|',
	'`', '\\',   '^',  '@', ']',  '}',    0,    0,
	'@',    0,    0,    0,    0,    0,    0,    0,
	  0,	0,    0,  164,	 13,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,  '|',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_DK

static unsigned char key_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0',  '+', '\'',  127,    9,
	'q',  'w',  'e',  'r',  't',  'y',  'u',  'i',
	'o',  'p',  229,    0,   13,    0,  'a',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',  230,
	162,	0,    0, '\'',  'z',  'x',  'c',  'v',
	'b',  'n',  'm',  ',',  '.',  '-',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char shift_map[] = {
	  0,   27,  '!', '\"',  '#',  '$',  '%',  '&',
	'/',  '(',  ')',  '=',  '?',  '`',  127,    9,
	'Q',  'W',  'E',  'R',  'T',  'Y',  'U',  'I',
	'O',  'P',  197,  '^',   13,    0,  'A',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L',  198,
	165,	0,    0,  '*',  'Z',  'X',  'C',  'V',
	'B',  'N',  'M',  ';',  ':',  '_',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '>',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char alt_map[] = {
	  0,	0,    0,  '@',  163,  '$',    0,    0,
	'{',   '[',  ']', '}',    0,  '|',    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,  '~',   13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,  '\\',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_DK_LATIN1

static unsigned char key_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0',  '+',  180,  127,    9,
	'q',  'w',  'e',  'r',  't',  'y',  'u',  'i',
	'o',  'p',  229,  168,   13,    0,  'a',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',  230,
	162,  189,    0, '\'',  'z',  'x',  'c',  'v',
	'b',  'n',  'm',  ',',  '.',  '-',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char shift_map[] = {
	  0,   27,  '!', '\"',  '#',  '$',  '%',  '&',
	'/',  '(',  ')',  '=',  '?',  '`',  127,    9,
	'Q',  'W',  'E',  'R',  'T',  'Y',  'U',  'I',
	'O',  'P',  197,  '^',   13,    0,  'A',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L',  198,
	165,  167,    0,  '*',  'Z',  'X',  'C',  'V',
	'B',  'N',  'M',  ';',  ':',  '_',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '>',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char alt_map[] = {
	  0,	0,    0,  '@',  163,  '$',    0,    0,
	'{',   '[',  ']', '}',    0,  '|',    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,  '~',   13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0, '\\',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_DVORAK

static unsigned char key_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0', '\\',  '=',  127,    9,
	'\'', ',',  '.',  'p',  'y',  'f',  'g',  'c',
	'r',  'l',  '/',  ']',   13,    0,  'a',  'o',
	'e',  'u',  'i',  'd',  'h',  't',  'n',  's',
	'-',  '`',    0,  '[',  ';',  'q',  'j',  'k',
	'x',  'b',  'm',  'w',  'v',  'z',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char shift_map[] = {
	  0,   27,  '!',  '@',  '#',  '$',  '%',  '^',
	'&',  '*',  '(',  ')',  '|',  '+',  127,    9,
	'"',  '<',  '>',  'P',  'Y',  'F',  'G',  'C',
	'R',  'L',  '?',  '}',   13,    0,  'A',  'O',
	'E',  'U',  'I',  'D',  'H',  'T',  'N',  'S',
	'_',  '~',    0,  '{',  ':',  'Q',  'J',  'K',
	'X',  'B',  'M',  'W',  'V',  'Z',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char alt_map[] = {
	  0,	0,    0,  '@',    0,  '$',    0,    0,
	'{',   '[',  ']', '}', '\\',    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,  '~',   13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,  '|',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_SG

static unsigned char key_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0', '\'',  '^',  127,    9,
	'q',  'w',  'e',  'r',  't',  'z',  'u',  'i',
	'o',  'p',    0,    0,   13,    0,  'a',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',    0,
	  0,	0,    0,  '$',  'y',  'x',  'c',  'v',
	'b',  'n',  'm',  ',',  '.',  '-',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char shift_map[] = {
	  0,   27,  '+',  '"',  '*',    0,  '%',  '&',
	'/',  '(',  ')',  '=',  '?',  '`',  127,    9,
	'Q',  'W',  'E',  'R',  'T',  'Z',  'U',  'I',
	'O',  'P',    0,  '!',   13,    0,  'A',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L',    0,
	  0,	0,    0,    0,	'Y',  'X',  'C',  'V',
	'B',  'N',  'M',  ';',  ':',  '_',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '>',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char alt_map[] = {
	  0,	0,    0,  '@',  '#',    0,    0,    0,
	'|',    0,    0,    0, '\'',  '~',    0,    0,
	'@',    0,    0,    0,    0,    0,    0,    0,
	  0,	0,   '[',  ']',  13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	'{',    0,    0,  '}',    0,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0, '\\',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_SG_LATIN1

static unsigned char key_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0', '\'',  '^',  127,    9,
	'q',  'w',  'e',  'r',  't',  'z',  'u',  'i',
	'o',  'p',  252,    0,   13,    0,  'a',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',  246,
	228,  167,    0,  '$',  'y',  'x',  'c',  'v',
	'b',  'n',  'm',  ',',  '.',  '-',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char shift_map[] = {
	  0,   27,  '+',  '"',  '*',  231,  '%',  '&',
	'/',  '(',  ')',  '=',  '?',  '`',  127,    9,
	'Q',  'W',  'E',  'R',  'T',  'Z',  'U',  'I',
	'O',  'P',  220,  '!',   13,    0,  'A',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L',  214,
	196,  176,    0,  163,	'Y',  'X',  'C',  'V',
	'B',  'N',  'M',  ';',  ':',  '_',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '>',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char alt_map[] = {
	  0,	0,    0,  '@',  '#',    0,    0,  172,
	'|',  162,    0,    0, '\'',  '~',    0,    0,
	'@',    0,    0,    0,    0,    0,    0,    0,
	  0,	0,  '[',  ']',   13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,  233,
	'{',    0,    0,  '}',    0,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0, '\\',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_NO

static unsigned char key_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0',  '+', '\\',  127,    9,
	'q',  'w',  'e',  'r',  't',  'y',  'u',  'i',
	'o',  'p',  '}',  '~',   13,    0,  'a',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',  '|',
	'{',  '|',    0, '\'',  'z',  'x',  'c',  'v',
	'b',  'n',  'm',  ',',  '.',  '-',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char shift_map[] = {
	  0,   27,  '!', '\"',  '#',  '$',  '%',  '&',
	'/',  '(',  ')',  '=',  '?',  '`',  127,    9,
	'Q',  'W',  'E',  'R',  'T',  'Y',  'U',  'I',
	'O',  'P',  ']',  '^',   13,    0,  'A',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L', '\\',
	'[',    0,    0,  '*',  'Z',  'X',  'C',  'V',
	'B',  'N',  'M',  ';',  ':',  '_',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '>',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

static unsigned char alt_map[] = {
	  0,	0,    0,  '@',    0,  '$',    0,    0,
	'{',   '[',  ']', '}',    0, '\'',    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,  '~',   13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_SF

static unsigned char key_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0', '\'',  '^',  127,    9,
	'q',  'w',  'e',  'r',  't',  'z',  'u',  'i',
	'o',  'p',    0,    0,   13,    0,  'a',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',    0,
	  0,	0,   0,   '$',  'y',  'x',  'c',  'v',
	'b',  'n',  'm',  ',',  '.',  '-',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };
static unsigned char shift_map[] = {
	  0,   27,  '+',  '"',  '*',    0,  '%',  '&',
	'/',  '(',  ')',  '=',  '?',  '`',  127,    9,
	'Q',  'W',  'E',  'R',  'T',  'Z',  'U',  'I',
	'O',  'P',    0,  '!',   13,    0,  'A',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L',    0,
	  0,	0,    0,    0,	'Y',  'X',  'C',  'V',
	'B',  'N',  'M',  ';',  ':',  '_',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '>',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };
static unsigned char alt_map[] = {
	  0,	0,    0,  '@',  '#',    0,    0,    0,
	'|',    0,    0,    0,  '\'', '~',    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,   '[',  ']',  13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	 '{',   0,    0,   '}',   0,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,  '\\',   0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };

#elif defined KBD_SF_LATIN1

static unsigned char key_map[] = {
	  0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0', '\'',  '^',  127,    9,
	'q',  'w',  'e',  'r',  't',  'z',  'u',  'i',
	'o',  'p',  232,  168,   13,    0,  'a',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',  233,
	224,  167,    0,  '$',  'y',  'x',  'c',  'v',
	'b',  'n',  'm',  ',',  '.',  '-',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '<',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };
static unsigned char shift_map[] = {
	  0,   27,  '+',  '"',  '*',  231,  '%',  '&',
	'/',  '(',  ')',  '=',  '?',  '`',  127,    9,
	'Q',  'W',  'E',  'R',  'T',  'Z',  'U',  'I',
	'O',  'P',  252,  '!',   13,    0,  'A',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L',  246,
	228,  176,    0,  163,	'Y',  'X',  'C',  'V',
	'B',  'N',  'M',  ';',  ':',  '_',    0,  '*',
	  0,   32,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,  '-',    0,    0,    0,  '+',    0,
	  0,	0,    0,    0,	  0,	0,  '>',    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };
static unsigned char alt_map[] = {
	  0,	0,    0,  '@',  '#',    0,    0,  172,
	'|',   162,   0,    0,  180,  '~',    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,   '[',  ']',  13,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	 '{',   0,    0,   '}',   0,    0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0,	0,    0,    0,	  0,	0,  '\\',   0,
	  0,	0,    0,    0,	  0,	0,    0,    0,
	  0 };
#else
#error "KBD-type not defined"
#endif

static void do_self(int sc)
{
    unsigned char ch;

    if (kbd_flag(KG_ALTGR))
	ch = alt_map[sc];
    else if (kbd_flag(KG_LSHIFT) || kbd_flag(KG_RSHIFT) ||
	     kbd_flag(KG_LCTRL) || kbd_flag(KG_RCTRL))
	ch = shift_map[sc];
    else
	ch = key_map[sc];

    if (ch == 0)
	return;

    if ((ch = handle_diacr(ch)) == 0)
	return;

    if (kbd_flag(KG_LCTRL) || kbd_flag(KG_RCTRL) ||
	vc_kbd_flag(kbd,VC_CAPSLOCK))   /* ctrl or caps */
	if ((ch >= 'a' && ch <= 'z') || (ch >= 224 && ch <= 254))
	    ch -= 32;
    if (kbd_flag(KG_LCTRL) || kbd_flag(KG_RCTRL))       /* ctrl */
	ch &= 0x1f;

    if (kbd_flag(KG_ALT))
	if (vc_kbd_flag(kbd,VC_META)) {
	    kb_put_queue('\033');
	    kb_put_queue(ch);
	} else
	    kb_put_queue(ch|0x80);
    else
	kb_put_queue(ch);
}

unsigned char accent_table[5][64] = {
	" \300BCD\310FGH\314JKLMN\322PQRST\331VWXYZ[\\]^_"
	"`\340bcd\350fgh\354jklmn\362pqrst\371vwxyz{|}~",   /* accent grave */

	" \301BCD\311FGH\315JKLMN\323PQRST\332VWX\335Z[\\]^_"
	"`\341bcd\351fgh\355jklmn\363pqrst\372vwxyz{|}~",   /* accent acute */

	" \302BCD\312FGH\316JKLMN\324PQRST\333VWXYZ[\\]^_"
	"`\342bcd\352fgh\356jklmn\364pqrst\373vwxyz{|}~",   /* circumflex */

	" \303BCDEFGHIJKLMN\325PQRSTUVWXYZ[\\]^_"
	"`\343bcdefghijklm\361\365pqrstuvwxyz{|}~",         /* tilde */

	" \304BCD\313FGH\316JKLMN\326PQRST\334VWXYZ[\\]^_"
	"`\344bcd\353fgh\357jklmn\366pqrst\374vwx\377z{|}~" /* dieresis */
};

/*
 * Check if dead key pressed. If so, check if same key pressed twice;
 * in that case return the char, otherwise store char and return 0.
 * If dead key not pressed, check if accented character pending. If
 * not: return the char, otherwise check if char is a space. If it is
 * a space return the diacritical. Else combine char with diacritical
 * mark and return.
 */

unsigned int handle_diacr(unsigned int ch)
{
	static unsigned char diacr_table[] =
		{'`', 180, '^', '~', 168, 0};           /* Must end with 0 */
	static unsigned char ret_diacr[] =
		{'`', '\'', '^', '~', '"' };            /* Must not end with 0 */
	int i;

	for(i=0; diacr_table[i]; i++)
		if (ch==diacr_table[i] && ((1<<i)&kbd->kbd_flags)) {
			if (diacr == i) {
				diacr=-1;
				return ret_diacr[i];	/* pressed twice */
			} else {
				diacr=i;		/* key is dead */
				return 0;
			}
		}
	if (diacr == -1)
		return ch;
	else if (ch == ' ') {
		ch=ret_diacr[diacr];
		diacr=-1;
		return ch;
	} else if (ch<64 || ch>122) {
		diacr=-1;
		return ch;
	} else {
		ch=accent_table[diacr][ch-64];
		diacr=-1;
		return ch;
	}
}

#if defined KBD_FR || defined KBD_US || defined KBD_UK || defined KBD_FR_LATIN1
static unsigned char num_table[] = "789-456+1230.";
#else
static unsigned char num_table[] = "789-456+1230,";
#endif

static unsigned char cur_table[] = "1A5-DGC+4B623";
static unsigned int pad_table[] = { 7,8,9,0,4,5,6,0,1,2,3,0,0 };

/*

    Keypad NumLock		80	      P
    Keypad ScrollLock		81	      Q
    Keypad /			82	      R
    Keypad *  (PrtSc)           83            S
    Keypad 7  (Home)            71            w
    Keypad 8  (Up arrow)        72            x
    Keypad 9  (PgUp)            73            y
    Keypad -			85	      S
    Keypad 4  (Left arrow)      68            t
    Keypad 5			69	      u
    Keypad 6  (Right arrow)     70            v
    Keypad +			84	      l
    Keypad 1  (End)             65            q
    Keypad 2  (Down arrow)      66            r
    Keypad 3  (PgDn)            67            s
    Keypad 0  (Ins)             64            p
    Keypad .  (Del)             87            n
*/

static unsigned char appl_table[] = "wxyStuvlqrspn";

/*
  Set up keyboard to generate DEC VT200 F-keys.
  DEC F1  - F5	not implemented (DEC HOLD, LOCAL PRINT, SETUP, SW SESS, BREAK)
  DEC F6  - F10 are mapped to F6 - F10
  DEC F11 - F20 are mapped to Shift-F1 - Shift-F10
  DEC HELP and DEC DO are mapped to F11, F12 or Shift- F11, F12.
  Regular (?) Linux F1-F5 remain the same.
*/

static char *func_table[2][12] = { /* DEC F1 - F12 */ {
	"\033[[A",  "\033[[B",  "\033[[C",  "\033[[D",
	"\033[[E",  "\033[17~", "\033[18~", "\033[19~",
	"\033[20~", "\033[21~", "\033[28~", "\033[29~"
}, /* DEC F12 - F24 */ {
	"\033[23~", "\033[24~", "\033[25~", "\033[26~",
	"\033[28~", "\033[29~", "\033[31~", "\033[32~",
	"\033[33~", "\033[34~", "\033[28~", "\033[29~"
}};

static void arrow(int sc)
{
    static char curinds[] = { 1, 9, 6, 4 };

    cur(curinds[sc-KB_UP]);
}

static void cursor(int sc)
{
    switch (sc) {
      case KB_KP1:
      case KB_KP2:
      case KB_KP3:
	sc = sc - KB_KP1 + 8;
	break;
      case KB_KP4:
      case KB_KP5:
      case KB_KP6:
	sc = sc - KB_KP4 + 4;
	break;
      case KB_KP7:
      case KB_KP8:
      case KB_KP9:
	sc = sc - KB_KP7;
	break;
      case KB_KP0:
	sc = 11;
	break;
      case KB_KPDECIMAL:   /* KP . */
	sc = 12;
	break;
      default:
	return;
    }

    if (kbd_flag(KG_ALT) && sc != 12) {             /* Alt-numpad */
	npadch=npadch*10+pad_table[sc];
	return;
    }

    if (vc_kbd_flag(kbd,VC_APPLIC) &&
	!kbd_flag(KG_LSHIFT) && /* shift forces cursor */
	!kbd_flag(KG_RSHIFT)) {
	applkey(appl_table[sc]);
	return;
    }

    if (vc_kbd_flag(kbd,VC_NUMLOCK)) {
	kb_put_queue(num_table[sc]);
    } else
	cur(sc);
}

static void cur(int sc)
{
	char buf[] = { 0x1b, '[', 0, 0, 0 };       /* must not be static */

	buf[2]=cur_table[sc];
	if (buf[2] < '9')
	    buf[3]='~';
	else
	    if ((buf[2] >= 'A' && buf[2] <= 'D') ?
		vc_kbd_flag(kbd,VC_CKMODE) :
		vc_kbd_flag(kbd,VC_APPLIC))
		buf[1]='O';
	puts_queue(buf);
}

static void func(int sc)
{
    if (sc < KB_F1 || sc > KB_F12)
	return;

    sc -= KB_F1;

    if (kbd_flag(KG_ALT))
	change_console(sc);
    else
	if (kbd_flag(KG_LSHIFT) || kbd_flag(KG_RSHIFT)) /* DEC F13 - F24 */
	    puts_queue(func_table[1][sc]);
	else					/* DEC F1 - F12 */
	    puts_queue(func_table[0][sc]);
}

static void help(int sc)
{
    /* help key -> DEC HELP */
    puts_queue(func_table[0][10]);
}

static void slash(int sc)
{
	if (vc_kbd_flag(kbd,VC_APPLIC))
		applkey('Q');
	else
		kb_put_queue('/');
}

static void star(int sc)
{
	if (kbd_dead(KGD_E0))
		/* Print screen key sends E0 2A E0 37 and puts
		   the VT100-ESC sequence ESC [ i into the queue, ChN */
		puts_queue("\033\133\151");
	else if (vc_kbd_flag(kbd,VC_APPLIC))
		applkey('R');
	else
		kb_put_queue ('*');
}

static void enter(int sc)
{
	if (kbd_dead(KGD_E0) && vc_kbd_flag(kbd,VC_APPLIC))
		applkey('M');
	else {
		kb_put_queue(13);
		if (vc_kbd_flag(kbd,VC_CRLF))
			kb_put_queue(10);
	}
}

static void minus(int sc)
{
	if (vc_kbd_flag(kbd,VC_APPLIC))
		applkey('S');
	else
		kb_put_queue ('-');
}

static void plus(int sc)
{
	if (vc_kbd_flag(kbd,VC_APPLIC))
		applkey('l');
	else
		kb_put_queue ('+');
}

static void none(int sc)
{
}

fptr key_table[] = {
	do_self,do_self,do_self,do_self,	/* 00-03 a b c d */
	do_self,do_self,do_self,do_self,	/* 04-07 e f g h */
	do_self,do_self,do_self,do_self,	/* 08-0B i j k l */
	do_self,do_self,do_self,do_self,	/* 0C-0F m n o p */
	do_self,do_self,do_self,do_self,	/* 10-13 q r s t */
	do_self,do_self,do_self,do_self,	/* 14-17 u v w x */
	do_self,do_self,do_self,do_self,	/* 18-1B y z 0 1 */
	do_self,do_self,do_self,do_self,	/* 1C-1F 2 3 4 5 */
	do_self,do_self,do_self,do_self,	/* 20-23 6 7 8 9 */
	do_self,do_self,do_self,do_self,	/* 24-27 esc bs del tab */
	do_self,do_self,do_self,do_self,	/* 28-2B sp  - = / */
	do_self,do_self,do_self,do_self,	/* 2C-2F \ [ ] ` */
	do_self,do_self,do_self,do_self,	/* 30-33 ; , . ' */
	func,func,func,func,			/* 34-37 F1 F2 F3 F4 */
	func,func,func,func,			/* 38-3B F5 F6 F7 F8 */
	func,func,func,func,			/* 3C-3F F9 F10 F11 F12 */
	cursor,cursor,cursor,cursor,		/* 40-43 KP0 KP1 KP2 KP3 */
	cursor,cursor,cursor,cursor,		/* 44-47 KP4 KP5 KP6 KP7 */
	cursor,cursor,enter,help,		/* 48-4B KP8 KP9
							 enter help */
	arrow,arrow,arrow,arrow,		/* 4C-4F up dn left right */
	num,scroll,slash,star,			/* 50-53 num scr
							 slash star */
	plus,minus,enter,cursor,		/* 54-57 plus minus
							 enter kp. */
	lshift,rshift,ctrl,ctrl,		/* 58-5B lshift rshift
							 lctrl rctrl */
	alt,alt,caps,lmach,			/* 5C-5F lalt ralt
							 caps lmach */
	rmach,unlshift,unrshift,unctrl, 	/* 60-63 rmach unlshift
							 unrshift unlctrl */
	unctrl,unalt,unalt,uncaps,		/* 64-67 unrctrl unlalt
							 unralt uncaps */
	unlmach,unrmach,none,none,		/* 68-6B unlmach unrmach
							 none none */
	none					/* 6C-6F none */
};


unsigned long kbd_init(unsigned long kmem_start)
{
    int i;
    struct kbd_struct * kbd;

    kbd = kbd_table + 0;
    for (i = 0 ; i < NR_CONSOLES ; i++,kbd++) {
	kbd->flags = KBD_DEFFLAGS;
	kbd->default_flags = KBD_DEFFLAGS;
	kbd->kbd_flags = KBDFLAGS;
    }

    return mach_keyb_init (kmem_start);
}
