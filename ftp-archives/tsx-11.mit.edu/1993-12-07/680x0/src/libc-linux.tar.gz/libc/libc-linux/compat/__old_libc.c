#include <gnu-stabs.h>

symbol_alias(_NEEDS_SHRLIB_libc_4, __jump_libc_v4);
