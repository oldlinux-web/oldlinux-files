#include <signal.h>
#include <sys/syscall.h>

sigset_t
__siggetmask (void)
{
	sigset_t __res;
	__asm__ __volatile__ ("moveq %1,d0\n\t"
			      "trap  #0\n\t"
			      "movel d0,%0"
			      : "=g" (__res)
			      : "i" (SYS_siggetmask) : "d0");
	return	__res;
}
