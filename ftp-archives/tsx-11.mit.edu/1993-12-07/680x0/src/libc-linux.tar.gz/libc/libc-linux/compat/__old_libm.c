#include <gnu-stabs.h>

symbol_alias(_NEEDS_SHRLIB_libm_4, __jump_libm_v4);
