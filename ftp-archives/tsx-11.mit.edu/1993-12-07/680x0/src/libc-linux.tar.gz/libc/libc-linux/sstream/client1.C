// $Header: /usr/u/moudgill/project/Socket/RCS/client1.C,v 1.6 1992/10/02 18:34:02 moudgill Exp moudgill $
// 17th December, 1991. Mayan Moudgill

static const char rcsid[]="$Id: client1.C,v 1.6 1992/10/02 18:34:02 moudgill Exp moudgill $";

#include "sstream.h"
#ifdef __linux__
#include <stdlib.h>
#else
#include <libc.h>
#endif

void pipedef(sstream& s)
{
   cerr << "lost other end of " << s.sd() << "\n";
   exit(3);
}

void main(int argc, char *argv[])
{
// sstream::showtrace = 1;
// sstream::showerror = 1;
// sstream::showmonitor = 1;
// sstream::showsyscall = 1;

sstream s;
sstream t;
int     n;

   if( argc < 3) {
      cerr << "error: usage : " << argv[0] << "<host> <port>\n";
      exit(1);
   }
   s.open(argv[1], atoi(argv[2]));
   if( !s ) {
      cerr << "could not connect to " << argv[1] << " " << atoi(argv[2]) <<"\n";
      exit(2);
   }
   cerr << s.sd() << "connected to " << s.tohost() << " " << s.toport() << "\n";

   s.pipehandler(pipedef);
   s.sstate(sstream::unitbufferbit);

   cin >> n;
   s << osend((char) n);
   for(int i = 0; i < n; i++) {
      int c;

      cin >> c;
      s << c << "\n";
      if( !s ) {
	 cerr << "couldn't send\n";
      }

      s >> c;
      if( !s ) {
	 cerr << "couldn't recv\n";
      }

      cerr << c << "\n";
  }
}
