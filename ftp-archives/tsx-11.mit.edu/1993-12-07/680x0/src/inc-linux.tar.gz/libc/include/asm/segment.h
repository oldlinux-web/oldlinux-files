/*
 *  linux/include/asm/segment.h
 *
 *  Copyright (C) 1991, 1992  Linus Torvalds
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

/*
 * 680x0 support added by Hamish Macdonald
 */

#ifndef _ASM_SEGMENT_H
#define _ASM_SEGMENT_H

static inline unsigned char get_fs_byte(const char * addr)
{
	register unsigned char _v;

	__asm__ ("movesb %1,%0":"=r" (_v):"m" (*addr));
	return _v;
}

static inline unsigned short get_fs_word(const unsigned short *addr)
{
	unsigned short _v;

	__asm__ ("movesw %1,%0":"=r" (_v):"m" (*addr));
	return _v;
}

static inline unsigned long get_fs_long(const unsigned long *addr)
{
	unsigned long _v;

	__asm__ ("movesl %1,%0":"=r" (_v):"m" (*addr)); \
	return _v;
}

static inline void put_fs_byte(char val,char *addr)
{
__asm__ ("movesb %0,%1"::"r" (val),"m" (*addr) : "memory");
}

static inline void put_fs_word(short val,short * addr)
{
__asm__ ("movesw %0,%1"::"r" (val),"m" (*addr) : "memory");
}

static inline void put_fs_long(unsigned long val,unsigned long * addr)
{
__asm__ ("movesl %0,%1"::"r" (val),"m" (*addr) : "memory");
}

static inline void memcpy_tofs(void * to, const void * from, unsigned long n)
{
	const unsigned char *f = from;
	unsigned char *t = to;

	while (n-- > 0)
		__asm__ __volatile__ ("movesb %2,%0@+"
				      : "=a" (t)
				      : "0" (t), "d" (*f++));
}

static inline void memcpy_fromfs(void * to, const void * from, unsigned long n)
{
	const unsigned char *f = from;
	unsigned char *t = to, c;

	while (n-- > 0) {
		__asm__ __volatile__ ("movesb %0@+,%1"
				      : "=a" (f), "=d" (c) : "0" (f));
		*t++ = c;
	}
}

/*
 * Get/set the SFC/DFC registers for MOVES instructions
 */

static inline unsigned long get_fs(void)
{
	unsigned long _v;
	__asm__("movec dfc,%0":"=r" (_v):);

	return _v;
}

static inline unsigned long get_ds(void)
{
    /* return the supervisor data space code */
    return 0x5;
}

static inline void set_fs(unsigned long val)
{
	__asm__ __volatile__ ("movec %0,sfc\n\t"
			      "movec %0,dfc\n\t"
			      :: "r" (val), "r" (val));
}

#endif /* _ASM_SEGMENT_H */
