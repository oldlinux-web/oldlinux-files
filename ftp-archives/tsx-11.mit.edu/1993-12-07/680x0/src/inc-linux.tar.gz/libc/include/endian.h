#ifndef	_ENDIAN_H
#define	_ENDIAN_H	1
#define BIG_ENDIAN      4321
#define __BIG_ENDIAN    4321
#endif	/* endian.h */
