#ifndef _BSD_TZFILE_H
#define _BSD_TZFILE_H

#define SECSPERDAY	(60*60*24)
#define DAYSPERNYEAR	365

#endif /* _BSD_TZFILE_H */
