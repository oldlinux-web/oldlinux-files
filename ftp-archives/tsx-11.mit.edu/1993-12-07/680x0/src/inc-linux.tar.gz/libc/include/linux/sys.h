/*
 * Why isn't this a .c file?  Enquiring minds....
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#define sys_clone sys_fork

typedef int (*fn_ptr)(...);

extern int sys_setup(...);
extern int sys_exit(...);
extern int sys_fork(...);
extern int sys_read(...);
extern int sys_write(...);
extern int sys_open(...);
extern int sys_close(...);
extern int sys_waitpid(...);
extern int sys_creat(...);
extern int sys_link(...);
extern int sys_unlink(...);
extern int sys_execve(...);
extern int sys_chdir(...);
extern int sys_time(...);
extern int sys_mknod(...);
extern int sys_chmod(...);
extern int sys_chown(...);
extern int sys_break(...);
extern int sys_stat(...);
extern int sys_lseek(...);
extern int sys_getpid(...);
extern int sys_mount(...);
extern int sys_umount(...);
extern int sys_setuid(...);
extern int sys_getuid(...);
extern int sys_stime(...);
extern int sys_ptrace(...);
extern int sys_alarm(...);
extern int sys_fstat(...);
extern int sys_pause(...);
extern int sys_utime(...);
extern int sys_stty(...);
extern int sys_gtty(...);
extern int sys_access(...);
extern int sys_nice(...);
extern int sys_ftime(...);
extern int sys_sync(...);
extern int sys_kill(...);
extern int sys_rename(...);
extern int sys_mkdir(...);
extern int sys_rmdir(...);
extern int sys_dup(...);
extern int sys_pipe(...);
extern int sys_times(...);
extern int sys_prof(...);
extern int sys_brk(...);
extern int sys_setgid(...);
extern int sys_getgid(...);
extern int sys_signal(...);
extern int sys_geteuid(...);
extern int sys_getegid(...);
extern int sys_acct(...);
extern int sys_phys(...);
extern int sys_lock(...);
extern int sys_ioctl(...);
extern int sys_fcntl(...);
extern int sys_mpx(...);
extern int sys_setpgid(...);
extern int sys_ulimit(...);
extern int sys_uname(...);
extern int sys_umask(...);
extern int sys_chroot(...);
extern int sys_ustat(...);
extern int sys_dup2(...);
extern int sys_getppid(...);
extern int sys_getpgrp(...);
extern int sys_setsid(...);
extern int sys_sigaction(...);
extern int sys_sgetmask(...);
extern int sys_ssetmask(...);
extern int sys_setreuid(...);
extern int sys_setregid(...);
extern int sys_sigpending(...);
extern int sys_sigsuspend(...);
extern int sys_sethostname(...);
extern int sys_setrlimit(...);
extern int sys_getrlimit(...);
extern int sys_getrusage(...);
extern int sys_gettimeofday(...);
extern int sys_settimeofday(...);
extern int sys_getgroups(...);
extern int sys_setgroups(...);
extern int sys_select(...);
extern int sys_symlink(...);
extern int sys_lstat(...);
extern int sys_readlink(...);
extern int sys_uselib(...);
extern int sys_swapon(...);
extern int sys_reboot(...);
extern int sys_readdir(...);
extern int sys_mmap(...);
extern int sys_munmap(...);
extern int sys_truncate(...);
extern int sys_ftruncate(...);
extern int sys_fchmod(...);
extern int sys_fchown(...);
extern int sys_getpriority(...);
extern int sys_setpriority(...);
extern int sys_profil(...);
extern int sys_statfs(...);
extern int sys_fstatfs(...);
extern int sys_ioperm(...);
extern int sys_socketcall(...);
extern int sys_syslog(...);
extern int sys_getitimer(...);
extern int sys_setitimer(...);
extern int sys_newstat(...);
extern int sys_newlstat(...);
extern int sys_newfstat(...);
extern int sys_newuname(...);
extern int sys_iopl(...);
extern int sys_vhangup(...);
extern int sys_idle(...);
extern int sys_vm86(...);
extern int sys_wait4(...);
extern int sys_swapoff(...);
extern int sys_sysinfo(...);
extern int sys_ipc(...);
extern int sys_fsync(...);
extern int sys_sigreturn(...);
extern int sys_setdomainname(...);
extern int sys_olduname(...);
extern int sys_old_syscall(...);

/*
 * These are system calls that will be removed at some time
 * due to newer versions existing..
 */
#if 1
#define sys_waitpid	sys_old_syscall /* sys_wait4	*/
#define sys_olduname	sys_old_syscall /* sys_newuname */
#define sys_stat	sys_old_syscall /* sys_newstat	*/
#define sys_fstat	sys_old_syscall /* sys_newfstat */
#define sys_lstat	sys_old_syscall /* sys_newlstat */
#define sys_signal	sys_old_syscall /* sys_sigaction */
#endif

fn_ptr sys_call_table[] =
{
    sys_setup, sys_exit, sys_fork, sys_read,
    sys_write, sys_open, sys_close, sys_waitpid,
    sys_creat, sys_link, sys_unlink, sys_execve,
    sys_chdir, sys_time, sys_mknod, sys_chmod,
    sys_chown, sys_break, sys_stat, sys_lseek,
    sys_getpid, sys_mount, sys_umount, sys_setuid,
    sys_getuid, sys_stime, sys_ptrace, sys_alarm,
    sys_fstat, sys_pause, sys_utime, sys_stty,
    sys_gtty, sys_access, sys_nice, sys_ftime,
    sys_sync, sys_kill, sys_rename, sys_mkdir,
    sys_rmdir, sys_dup, sys_pipe, sys_times,
    sys_prof, sys_brk, sys_setgid, sys_getgid,
    sys_signal, sys_geteuid, sys_getegid, sys_acct,
    sys_phys, sys_lock, sys_ioctl, sys_fcntl,
    sys_mpx, sys_setpgid, sys_ulimit, sys_olduname,
    sys_umask, sys_chroot, sys_ustat, sys_dup2,
    sys_getppid, sys_getpgrp, sys_setsid, sys_sigaction,
    sys_sgetmask, sys_ssetmask, sys_setreuid,sys_setregid,
    sys_sigsuspend, sys_sigpending, sys_sethostname, sys_setrlimit,
    sys_getrlimit, sys_getrusage, sys_gettimeofday, sys_settimeofday,
    sys_getgroups, sys_setgroups, sys_select, sys_symlink,
    sys_lstat, sys_readlink, sys_uselib, sys_swapon,
    sys_reboot, sys_readdir, sys_mmap, sys_munmap,
    sys_truncate, sys_ftruncate, sys_fchmod, sys_fchown,
    sys_getpriority, sys_setpriority, sys_profil, sys_statfs,
    sys_fstatfs, 0 /*sys_ioperm*/, 0 /*sys_socketcall*/, sys_syslog,
    sys_setitimer, sys_getitimer, sys_newstat, sys_newlstat,
    sys_newfstat, sys_uname, 0 /*sys_iopl*/, sys_vhangup,
    sys_idle, 0 /*sys_vm86*/, sys_wait4, sys_swapoff,
    sys_sysinfo, sys_ipc, sys_fsync, sys_sigreturn, sys_clone,
    sys_setdomainname, sys_newuname
    };

/* So we don't have to do any more manual updating.... */
int NR_syscalls = sizeof(sys_call_table)/sizeof(fn_ptr);
