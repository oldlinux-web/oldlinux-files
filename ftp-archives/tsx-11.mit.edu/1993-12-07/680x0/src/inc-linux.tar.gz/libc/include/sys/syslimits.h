#ifndef _LINUX_LIMITS_H
#include <linux/limits.h>
#endif
