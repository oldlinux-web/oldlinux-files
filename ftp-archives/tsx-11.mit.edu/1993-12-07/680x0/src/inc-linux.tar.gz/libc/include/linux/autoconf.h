/*
 * Automatically generated C config: don't edit
 */

/*
 * General setup
 */
#define CONFIG_AMIGA 1

/*
 * SCSI support
 */

/*
 * SCSI support type (disk, tape, CDrom)
 */

/*
 * SCSI low-level drivers
 */

/*
 * Filesystems
 */
#define CONFIG_MINIX_FS 1

/*
 * Various character device drivers..
 */
