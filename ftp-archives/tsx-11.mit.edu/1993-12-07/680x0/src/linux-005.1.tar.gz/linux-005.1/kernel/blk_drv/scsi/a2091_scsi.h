#ifndef _A2091_SCSI_H

/* $Id$
 *
 * Header file for the Commodore A2091 Zorro II SCSI controller for Linux
 *
 * Written and (C) 1993, Hamish Macdonald, see a2091_scsi.c for more info
 *
 */

#include <linux/types.h>

int a2091_scsi_detect(int);
int a2091_scsi_command(Scsi_Cmnd *);
int a2091_scsi_queuecommand(Scsi_Cmnd *, void (*done)(Scsi_Cmnd *));
int a2091_scsi_abort(Scsi_Cmnd *, int);
const char *a2091_scsi_info(void);
int a2091_scsi_reset(void);
int a2091_scsi_biosparam(int, int, int*);

#ifndef NULL
#define NULL 0
#endif

#define A2091_SCSI {"Commodore A2091 SCSI controller",      \
		    a2091_scsi_detect,			    \
		    a2091_scsi_info, 			    \
		    a2091_scsi_command,			    \
		    a2091_scsi_queuecommand, 		    \
		    a2091_scsi_abort,			    \
		    a2091_scsi_reset,			    \
		    NULL,				    \
		    a2091_scsi_biosparam,		    \
		    1, 7, SG_NONE, 1, 0, 0}

#endif
