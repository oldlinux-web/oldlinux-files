#ifndef _A3000_SCSI_H

/* $Id$
 *
 * Header file for the Amiga 3000 built-in SCSI controller for Linux
 *
 * Written and (C) 1993, Hamish Macdonald, see a3000_scsi.c for more info
 *
 */

#include <linux/types.h>

int a3000_scsi_detect(int);
int a3000_scsi_command(Scsi_Cmnd *);
int a3000_scsi_queuecommand(Scsi_Cmnd *, void (*done)(Scsi_Cmnd *));
int a3000_scsi_abort(Scsi_Cmnd *, int);
const char *a3000_scsi_info(void);
int a3000_scsi_reset(void);
int a3000_scsi_biosparam(int, int, int*);

#ifndef NULL
#define NULL 0
#endif

#define A3000_SCSI {"Amiga 3000 built-in SCSI",             \
		    a3000_scsi_detect,			    \
		    a3000_scsi_info, 			    \
		    a3000_scsi_command,			    \
		    a3000_scsi_queuecommand, 		    \
		    a3000_scsi_abort,			    \
		    a3000_scsi_reset,			    \
		    NULL,				    \
		    a3000_scsi_biosparam,		    \
		    1, 7, SG_NONE, 1, 0, 0}

#endif
