/*
 *  linux/kernel/fork.c
 *
 *  Copyright (C) 1991, 1992  Linus Torvalds
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

/*
 * 680x0 support by Hamish Macdonald
 */

/*
 *  'fork.c' contains the help-routines for the 'fork' system call
 * (see also system_call.S).
 * Fork is rather simple, once you get the hang of it, but the memory
 * management can be a bitch. See 'mm/mm.c': 'copy_page_tables()'
 */

#include <asm/segment.h>
#include <asm/system.h>

#include <linux/errno.h>
#include <linux/sched.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/stddef.h>
#include <linux/unistd.h>
#include <linux/string.h>

#define MAX_TASKS_PER_USER (NR_TASKS/2)

extern int shm_fork (struct task_struct *, struct task_struct *);
long last_pid=0;

static int find_empty_process(void)
{
	int i, task_nr;
	int this_user_tasks;

repeat:
	if ((++last_pid) & 0xffff8000)
		last_pid=1;
	this_user_tasks = 0;
	for(i=0 ; i < NR_TASKS ; i++) {
		if (!task[i])
			continue;
		if (task[i]->uid == current->uid)
			this_user_tasks++;
		if (task[i]->pid == last_pid || task[i]->pgrp == last_pid)
			goto repeat;
	}
	if (this_user_tasks > MAX_TASKS_PER_USER && !suser())
		return -EAGAIN;
/* Only the super-user can fill the last available slot */
	task_nr = 0;
	for(i=1 ; i<NR_TASKS ; i++)
		if (!task[i])
			if (task_nr)
				return task_nr;
			else
				task_nr = i;
	if (task_nr && suser())
		return task_nr;
	return -EAGAIN;
}

static struct file * copy_fd(struct file * old)
{
	struct file * new = get_empty_filp();
	int error;

	if (new) {
		memcpy(new,old,sizeof(*new));
		new->f_count = 1;
		if (new->f_inode)
			new->f_inode->i_count++;
		if (new->f_op && new->f_op->open) {
			error = new->f_op->open(new->f_inode,new);
			if (error) {
				iput(new->f_inode);
				new->f_count = 0;
				new = NULL;
			}
		}
	}
	return new;
}

#define IS_CLONE (is_clone)
#define copy_vm(p) ((clone_flags & COPYVM)?copy_page_tables:clone_page_tables)(p)

/*
 *  Ok, this is the main fork-routine. It copies the system process
 * information (task[nr]) and sets up the necessary registers. It
 * also copies the data segment in it's entirety.
 *
 */
int do_fork(int is_clone, unsigned long flags, unsigned long usp)
{
	struct task_struct *p;
	int i,nr;
	struct file *f;
	unsigned long clone_flags = COPYVM | SIGCHLD;

	p = (struct task_struct *) get_free_page(GFP_KERNEL);

	if (!p)
		return -EAGAIN;

	nr = find_empty_process();
	if (nr < 0) {
		free_page((unsigned long) p);
		return nr;
	}

#ifdef DEBUG
	asm volatile ("movew sr,d0\n\t"
		      "extl d0\n\t"
		      "movel d0,%0" : "=g" (i) :: "d0");
	printk ("fork: task # is %d (sr is %x) \n", nr, i);
#endif

	task[nr] = p;
	*p = *current;
	p->kernel_stack_page = 0;
	p->state = TASK_UNINTERRUPTIBLE;
	p->flags &= ~(PF_PTRACED|PF_TRACESYS);
	p->pid = last_pid;
	if (p->pid > 1)
		p->swappable = 1;
	p->p_pptr = p->p_opptr = current;
	p->p_cptr = NULL;
	SET_LINKS(p);
	p->signal = 0;
	p->it_real_value = p->it_virt_value = p->it_prof_value = 0;
	p->it_real_incr = p->it_virt_incr = p->it_prof_incr = 0;
	p->leader = 0;		/* process leadership doesn't inherit */
	p->utime = p->stime = 0;
	p->cutime = p->cstime = 0;
	p->min_flt = p->maj_flt = 0;
	p->cmin_flt = p->cmaj_flt = 0;
	p->start_time = jiffies;

	if (IS_CLONE) {
		if (usp)
			;/* somehow set up new user stack pointer */;
		clone_flags = flags;
		if (0 /*usp == current usp*/)
			clone_flags |= COPYVM;
	}

	p->exit_signal = clone_flags & CSIGNAL;

	p->semun = NULL; p->shm = NULL;
	/* allocate and copy kernel stack */
	p->kernel_stack_page = get_free_page(GFP_KERNEL);
#if 0
	/*
	 * have to set up new stack if syscall is CLONE
	 */
#endif
	if (!p->kernel_stack_page || copy_vm(p) || shm_fork (current, p)) {
		task[nr] = NULL;
		REMOVE_LINKS(p);
		free_page(p->kernel_stack_page);
		free_page((long) p);
		return -EAGAIN;
	}

	if (clone_flags & COPYFD) {
		for (i=0; i<NR_OPEN;i++)
			if ((f = p->filp[i]) != NULL)
				p->filp[i] = copy_fd(f);
	} else {
		for (i=0; i<NR_OPEN;i++)
			if ((f = p->filp[i]) != NULL)
				f->f_count++;
	}
	if (current->pwd)
		current->pwd->i_count++;
	if (current->root)
		current->root->i_count++;
	if (current->executable)
		current->executable->i_count++;
	for (i=0; i < current->numlibraries ; i++)
		if (current->libraries[i].library)
			current->libraries[i].library->i_count++;

	/* cpu_fork returns 1 in the child, 0 in the parent */
	if (cpu_fork (p)) {
#ifdef DEBUG
		asm volatile ("movew sr,d0\n\t"
		     "extl d0\n\t"
		     "movel d0,%0" : "=g" (nr) :: "d0");
		printk ("new task returning 0 (with sr %x)\n", nr);
#endif
		return 0;
	}

#ifdef DEBUG
	printk ("new task is %#lx\n", p);
#endif

	p->counter = current->counter >> 1;
	p->state = TASK_RUNNING;	/* do this last, just in case */
	return p->pid;
}
