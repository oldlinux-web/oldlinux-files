#include <linux/sched.h>
#include <linux/sys_info.h>

#define offsetof(type, member) ((size_t)(&((type *)0)->member))

void printf (const char *fmt, ...);

int main()
{
	printf ("TS_SR = %d\n", offsetof (struct task_struct, sr));
	printf ("TS_FS = %d\n", offsetof (struct task_struct, fs));
	printf ("TS_USP = %d\n", offsetof (struct task_struct, usp));
	printf ("TS_REGS = %d\n", offsetof (struct task_struct, regs));
	printf ("TS_KSTACKP = %d\n",
		offsetof (struct task_struct, kernel_stack_page));
	printf ("TS_PMAP = %d\n", offsetof (struct task_struct, pmap));

	printf ("TS_STATE = %d\n", offsetof (struct task_struct, state));
	printf ("TS_COUNTER = %d\n", offsetof (struct task_struct, counter));
	printf ("TS_PRIORITY = %d\n",
		offsetof (struct task_struct, priority));
	printf ("TS_SIGNAL = %d\n", offsetof (struct task_struct, signal));
	printf ("TS_BLOCKED = %d\n", offsetof (struct task_struct, blocked));
	printf ("TS_FLAGS = %d\n", offsetof (struct task_struct, flags));
	printf ("TS_ERRNO = %d\n", offsetof (struct task_struct, errno));

	printf ("PMAP_KSTACKP = %d\n", offsetof (pmap_t, kstack_p));
	printf ("PMAP_CRP = %d\n", offsetof (pmap_t, crp));

	printf ("KSTACK_ADDR = %d\n", KSTACK_ADDR);
	printf ("FLUSH_I_AND_D = %d\n", FLUSH_I_AND_D);
	printf ("PAGE_PRESENT = %d\n", PAGE_PRESENT);

	/* sys_info structure field offsets */
	printf ("SYS_INFO_MACHTYPE = %d\n",
		offsetof (struct sys_info, machtype));
	printf ("SYS_INFO_AMIGA_ECLK = %d\n",
		offsetof (struct sys_info, si_amiga.eclock));
}
