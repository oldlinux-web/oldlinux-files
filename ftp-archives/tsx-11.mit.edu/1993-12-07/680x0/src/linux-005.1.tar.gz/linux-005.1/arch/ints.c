/*
 * ints.c -- 680x0 Linux general interrupt handling code
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#include <asm/system.h>

#include <linux/types.h>
#include <linux/config.h>
#include <linux/interrupt.h>
#include <linux/sched.h>

/* list is accessed 0-6 for IRQs 1-7 */
static isr_node_t *isr_list[IRQ7];

/* The number of spurious interrupts */
unsigned long num_spurious;

/*
 * void init_INTS(void)
 *
 * Parameters:	None
 *
 * Returns:	Nothing
 *
 * This function should be called during kernel startup to initialize
 * the IRQ handling routines.
 */

void init_INTS(void)
{
    int i;

    /* initialize the ISR list pointers */
    for (i = 0; i < IRQ7; i++)
	isr_list[i] = NULL;

    num_spurious = 0;

    mach_init_INTS ();

    /* enable CPU interrupts */
    sti();
}

void insert_isr (isr_node_t **listp, isr_node_t *node)
{
    unsigned long spl;
    isr_node_t *cur, *last;

    save_flags(spl);
    cli();

    cur = *listp;

    if (!cur || cur->pri > node->pri) {
	if (cur)
	    node->next = cur;
	*listp = node;
	restore_flags (spl);
	return;
    }

    while (cur->next && cur->pri <= node->pri)
    {
	last = cur;
	cur = cur->next;
    }

    if (!cur->next) {
	cur->next = node;
    } else {
	node->next = cur;
	last->next = node;
    }

    restore_flags(spl);
}

isr_node_t *new_isr_node(void)
{
    isr_node_t *np;

#if 0 /* stupid memory allocator unusable until mem_init has run */
    np = (isr_node_t *)kmalloc(sizeof(isr_node_t), GFP_ATOMIC);
    if (!np) {
	panic ("new_isr_node: unable to allocate an isr_node_t");
    }
#else
    static isr_node_t nodes[100];
    static int curnode = 0;

    np = &nodes[curnode++];
    if (curnode == 100)
	panic ("new_isr_node: out of nodes");
#endif

    return np;
}

int add_isr (unsigned long source, isrfunc isr, int pri, void *data)
{
    isr_node_t *p;

    if (source & IRQ_MACHSPEC)
    {
	return mach_add_isr (source, isr, pri, data);
    }

    if (source < IRQ1 || source > IRQ7)
	panic ("add_isr: Incorrect IRQ source");

    p = new_isr_node();
    p->isr = isr;
    p->pri = pri;
    p->data = data;
    p->next = NULL;

    insert_isr (&isr_list[source-1], p);

    return 1;
}

void call_isr_list(isr_node_t *p, struct intframe *fp)
{
    while (p) {
	p->isr (fp, p->data);
	p = p->next;
    }
}

void process_int(int level, struct intframe *fp)
{
    call_isr_list (isr_list[level-1], fp);
}
