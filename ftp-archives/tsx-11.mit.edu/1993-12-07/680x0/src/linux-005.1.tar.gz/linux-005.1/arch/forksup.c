int savectx(struct task *p, int altreturn)
{
	__asm__ __volatile__ ("movew sr,%0"           : "=g" (p->sr));
	__asm__ __volatile__ ("movec sfc,%0"          : "=d" (p->fs));
	__asm__ __volatile__ ("movel usp,%0"          : "=a" (p->usp));
	__asm__ __volatile__ ("movml d2-d7/a2-a7,%0@" :: "a" (p->regs));
	
	return 0;
}


#if 0
    if (last_task_used_math == current)
	__asm__("clts ; fnsave %0 ; frstor %0"::"m" (p->tss.i387));
#endif

