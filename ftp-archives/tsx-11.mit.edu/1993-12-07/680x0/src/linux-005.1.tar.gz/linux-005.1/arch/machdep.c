#include <linux/sched.h>
#include <linux/string.h>

extern int savectx (struct task_struct *p, int altreturn);

int cpu_fork (struct task_struct *p)
{
	memcpy ((void *)p->kernel_stack_page,
		(void *)current->kernel_stack_page, PAGE_SIZE);

	if (savectx (p, 1))
		return 1;
	else
		return 0;
}
