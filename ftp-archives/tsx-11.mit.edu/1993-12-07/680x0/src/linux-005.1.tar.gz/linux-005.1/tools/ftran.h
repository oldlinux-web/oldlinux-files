#ifndef _ftran_h_
#define _ftran_h_

#define MAX_NAMELEN  255

struct ftranbuf {
	unsigned long len;
	unsigned long namelen;
	unsigned char name[MAX_NAMELEN+1];
};

#endif /* _ftran_h_ */
