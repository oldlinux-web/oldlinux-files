#ifndef _EXT_FS_I
#define _EXT_FS_I

/*
 * extended file system inode data in memory
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */
struct ext_inode_info {
	unsigned long i_data[16];
};

#endif
