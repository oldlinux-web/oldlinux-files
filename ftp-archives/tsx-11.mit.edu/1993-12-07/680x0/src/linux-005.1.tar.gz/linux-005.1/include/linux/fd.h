#ifndef _LINUX_FD_H
#define _LINUX_FD_H

/*
** FD iocntl codes
*/

#define FDCLRPRM 0 /* clear user-defined parameters */
#define FDSETPRM 1 /* set user-defined parameters for current media */
#define FDDEFPRM 2 /* set user-defined parameters until explicitly cleared */
#define FDGETPRM 3 /* get disk parameters */
#define	FDMSGON  4 /* issue kernel messages on media type change */
#define	FDMSGOFF 5 /* don't issue kernel messages on media type change */
#define FDFMTBEG 6 /* begin formatting a disk */
#define	FDFMTTRK 7 /* format the specified track */
#define FDFMTEND 8 /* end formatting a disk */
#define FDSETEMSGTRESH	10	/* set fdc error reporting treshold */

/*
** Misc definitions
*/

#define FD_FILL_BYTE 0xF6       /* format fill byte */

#define FORMAT_NONE	0	/* no format request */
#define FORMAT_WAIT	1	/* format request is waiting */
#define FORMAT_BUSY	2	/* formatting in progress */
#define FORMAT_OKAY	3	/* successful completion */
#define FORMAT_ERROR	4	/* formatting error */

#define FD_MAX_UNITS    4

/*
** Floppy type descriptions
*/

struct fd_drive_type {
    unsigned long code;		/* code returned from drive */
    char *name;			/* description of drive */
    unsigned int tracks;	/* number of tracks */
    unsigned int heads;		/* number of heads */
    unsigned int raw_size;	/* raw size of one track */
    unsigned int sect_mult;	/* sectors multiplier (HD = 2) */
    unsigned int precomp1;	/* start track for precomp 1 */
    unsigned int precomp2;	/* start track for precomp 2 */
    unsigned int step_delay;	/* time (in ms) for delay after step */
    unsigned int settle_time;	/* time to settle after dir change */
    unsigned int side_time;	/* time needed to change sides */
};

struct fd_data_type {
    char *name;			/* description of data type */
    int sects;			/* sectors per track */
};

struct floppy_struct {
    struct fd_drive_type *type;	/* type of floppy for this unit */
    struct fd_data_type *dtype;	/* type of floppy for this unit */
    int side;			/* current side (0=top, 1=bottom) */
    int dir;			/* current dir (0=out, 1=in) */
    int cyl;			/* current cylinder (-1 == unknown) */

    int blocks;			/* total # blocks on disk */
    int sects;			/* number of sectors per track */

    int disk;			/* disk in drive (-1 == unknown) */
    int motor;			/* true when motor is at speed */
    int busy;			/* true when drive is active */
    int status;			/* current error code for unit */
};

struct floppy_type_struct 
    {
    unsigned int
        blocks,             /* nr of 512-byte sectors total */
        sects,              /* sectors per track */
        heads,              /* nr of heads */
        cyls;               /* nr of cylinders */

    char
        *name;              /* used only for predefined formats */
    };

#endif
