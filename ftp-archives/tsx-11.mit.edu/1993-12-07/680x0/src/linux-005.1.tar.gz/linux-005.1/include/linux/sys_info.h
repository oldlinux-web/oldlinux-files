/*
** sys_info.h -- Defintion of the Amiga Linux system information structure
**
** Copyright 1992 by Greg Harp
**
** This file is subject to the terms and conditions of the GNU General Public
** License.  See the file README.legal in the main directory of this archive
** for more details.
**
** Created 09/29/92 by Greg Harp
*/

#ifndef SYS_INFO_H
#define SYS_INFO_H

#include <amiga/types.h>

/*
 * Amiga specific part of sys_info structure.
 */

#define NUM_AUTO    16

#define NTSC_ECLOCK 715909
#define PAL_ECLOCK  709379

struct si_Amiga {
    int
        model;				/* Amiga Model (3000?) */
    int
	num_autocon;			/* # of autoconfig devices found */

    struct ConfigDev
	autocon[NUM_AUTO];		/* up to 16 autoconfig devices */

    u_long
	chip_size;			/* size of chip memory (bytes) */

    u_char
	vblank; 			/* VBLANK frequency */

    u_char
	psfreq; 			/* power supply frequency */

    u_long
	eclock; 			/* EClock frequency */
};


/*
 * CPU and FPU types
 */
#define CPU_68020    (1)
#define CPU_68030    (2)
#define CPU_68040    (4)
#define FPU_68881    (32)
#define FPU_68882    (64)

struct mem_info {
    void  *addr;	/* physical address of memory chunk */
    u_long size;		/* length of memory chunk (in bytes) */
};

#define NUM_MEMINFO  4

#define MACH_AMIGA   1
#define MACH_ATARI   2
#define MACH_MAC     3

struct sys_info {
    u_long
	machtype;			/* machine type */

    u_long
	cputype;			/* system CPU & FPU */

    struct mem_info
	memory[NUM_MEMINFO];		/* memory description */

    int
	num_memory;			/* # of memory blocks found */

    u_long
	ramdisk_size;			/* ramdisk size in 1024 byte blocks */

    u_long
	ramdisk_addr;			/* address of the ram disk in mem */

    u_long
	root_dev;			/* root device number */

    union {
	struct si_Amiga si_ami; 	/* Amiga specific information */
    } si_un;
};
#define si_amiga si_un.si_ami
#define si_atari si_un.si_at
#define si_mac	 si_un.si_m

extern struct sys_info
    sys_info;

#endif /* SYS_INFO_H */
