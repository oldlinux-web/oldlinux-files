/*
 *  linux/include/atari/config.h
 *
 *  Copyright (C) 1993        Hamish Macdonald
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#ifndef _ATARI_CONFIG_H_
#define _ATARI_CONFIG_H_ 1

#ifdef CONFIG_ATARI

#else  /* !CONFIG_ATARI */

static __inline void config_atari(void) {}

#endif /* CONFIG_ATARI */

#endif /* atari/config.h */
