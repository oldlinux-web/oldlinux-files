#ifndef _MINIX_FS_I
#define _MINIX_FS_I

/*
 * minix fs inode data in memory
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */
struct minix_inode_info {
	unsigned short i_data[16];
};

#endif
