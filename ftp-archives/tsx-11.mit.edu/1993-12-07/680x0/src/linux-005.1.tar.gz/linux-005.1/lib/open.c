/*
 *  linux/lib/open.c
 *
 *  Copyright (C) 1991, 1992  Linus Torvalds
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

/*
 * 680x0 support by Hamish Macdonald
 */

#define __LIBRARY__
#include <linux/unistd.h>
#include <stdarg.h>

int open(const char * filename, int flag, ...)
{
	register int res __asm__ ("d0");
	va_list arg;

	va_start(arg,flag);
	__asm__("movel %1,d1\n\t"
		"movel %2,d2\n\t"
		"movel %3,d3\n\t"
		"movel %0,d0\n\t"
		"trap  #0\n\t"
		"bcc   1f\n\t"
		"movel d0,_errno\n\t"
		"moveq #-1,d0\n\t"
		"1:"
		:: "i" (__NR_open), "g" (filename), "g" (flag),
		"d" (va_arg(arg,int)) : "d0", "d1", "d2", "d3" );
	va_end(arg);
	return res;
}
