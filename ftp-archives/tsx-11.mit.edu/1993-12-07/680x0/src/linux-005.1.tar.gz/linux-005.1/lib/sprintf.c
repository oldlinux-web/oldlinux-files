#include <stdarg.h>

extern int vsprintf (char *buf, const char *fmt, va_list arg);

int sprintf (char *buf, const char *fmt, ...)
{
   va_list arg;
   int count;

   va_start (arg, fmt);
   count = vsprintf (buf, fmt, arg);
   va_end (arg);

   return count;
}

