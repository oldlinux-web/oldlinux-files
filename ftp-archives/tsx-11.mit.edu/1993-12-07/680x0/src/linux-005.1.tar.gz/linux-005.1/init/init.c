/*
 * Copyright 1993 Hamish Macdonald
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#include <stdarg.h>
#include <linux/types.h>
#include <linux/fcntl.h>
#include <linux/unistd.h>
#include <linux/stat.h>

#include <wait.h>

static inline _syscall3(int,write,int,fd,const char *,buf,off_t,count)
static inline _syscall3(int,read,int,fd,char *,buf,off_t,count)
static inline _syscall1(int,close,int,fd)
static inline _syscall2(int,fchmod,int,fd,int,mode)
static inline _syscall0(int,fork)
static inline _syscall0(int,sync)
static inline _syscall0(int,setsid)
static inline _syscall1(int,setup,void *,bios)
static inline _syscall1(int,dup,int,oldfd);
static inline _syscall3(int,lseek,int,fd,long,offset,int,whence)
static inline _syscall3(int,execve,const char *,file,char **,argv,
			char **,envp)
static inline _syscall1(int,unlink,const char *,file)
static inline _syscall2(int,mkdir,const char *,path,int,mode)
static inline _syscall3(int,mknod,const char *,file,int,mode,dev_t,dev)

static int printf (const char *, ...);

extern char *linux_banner;

#if 1
#define MAX_INIT_ARGS 8
#define MAX_INIT_ENVS 8

static char * argv_init[MAX_INIT_ARGS+2] = { "init", NULL, };
static char * envp_init[MAX_INIT_ENVS+2] = { "HOME=/", "TERM=console", NULL, };

static char * argv_rc[] = { "/bin/sh", NULL };
static char * envp_rc[] = { "HOME=/", "TERM=console", NULL };

static char * argv[] = { "-/bin/sh",NULL };
static char * envp[] = { "HOME=/usr/root", "TERM=console", NULL };

void init(void)
{
	int pid,i;

	setup(NULL);
	(void) open("/dev/tty1",O_RDWR,0);
	(void) dup(0);
	(void) dup(0);

	printf(linux_banner);
	execve("/etc/init",argv_init,envp_init);
	execve("/bin/init",argv_init,envp_init);
	execve("/sbin/init",argv_init,envp_init);
	/* if this fails, fall through to original stuff */

	if (!(pid=fork())) {
		close(0);
		if (open("/etc/rc",O_RDONLY,0))
			_exit(1);
		execve("/bin/sh",argv_rc,envp_rc);
		_exit(2);
	}
	if (pid>0)
		while (pid != wait(&i))
			/* nothing */;
	while (1) {
		if ((pid = fork()) < 0) {
			printf("Fork failed in init\n\r");
			continue;
		}
		if (!pid) {
			close(0);close(1);close(2);
			setsid();
			(void) open("/dev/tty1",O_RDWR,0);
			(void) dup(0);
			(void) dup(0);
			_exit(execve("/bin/sh",argv,envp));
		}
		while (1)
			if (pid == wait(&i))
				break;
		printf("\n\rchild %d died with code %04x\n\r",pid,i);
		sync();
	}
	_exit(0);       /* NOTE! _exit, not exit() */
}

#else

int errno;
extern void subproc(void);
extern void showstat (int pid, int status);

void init(void)
{
    int pid;
    int status;

    setup(NULL);

    setsid();

    open ("/dev/tty1", O_RDWR, 0);
    dup (0);
    dup (0);

#if 1
    mkdir ( "/bin",  S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH);
    mkdir ( "/dev",  S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH);
    mkdir ( "/sbin", S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH);
    mkdir ( "/etc",  S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH);
    mkdir ( "/tmp",  S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH);
    mknod ( "/dev/console", S_IFCHR | S_IWUSR | S_IRUSR, 0x0400);
    mknod ( "/dev/tty1",    S_IFCHR | S_IWUSR | S_IRUSR, 0x0401);
    mknod ( "/dev/fd0",     S_IFBLK | S_IWUSR | S_IRUSR, 0x0204);
    mknod ( "/dev/sda1",    S_IFBLK | S_IWUSR | S_IRUSR, 0x0801);
    mknod ( "/dev/sda2",    S_IFBLK | S_IWUSR | S_IRUSR, 0x0802);
    mknod ( "/dev/sda3",    S_IFBLK | S_IWUSR | S_IRUSR, 0x0803);
    mknod ( "/dev/sdb1",    S_IFBLK | S_IWUSR | S_IRUSR, 0x0811);
    mknod ( "/dev/sdb2",    S_IFBLK | S_IWUSR | S_IRUSR, 0x0812);
    mknod ( "/dev/sdb3",    S_IFBLK | S_IWUSR | S_IRUSR, 0x0813);
    mknod ( "/dev/sdb4",    S_IFBLK | S_IWUSR | S_IRUSR, 0x0814);
#endif

    if (fork() == 0)
	subproc();

    while (1) {
	pid = wait4(-1,&status,WUNTRACED,NULL);
	if (pid != -1)
	    showstat (pid, status);
    }
}

void showstat (int pid, int status)
{
    if (WIFSTOPPED(status))
	printf ("pid %d stopped with signal %d\n", pid, WSTOPSIG(status));
    else if (WIFSIGNALED(status))
	printf ("pid %d terminated with signal %d\n", pid, WTERMSIG(status));
    else if (WIFEXITED(status))
	printf ("pid %d exited with code %d\n", pid, WEXITSTATUS(status));
}

void subproc(void)
{
    int fd, nr;
    char buffer[80];
    unsigned long sum;
    extern char progdata[];
    extern int progsize;
    char *filetodel, *filetowrite;
    char *argv[2], *envp[2];

#ifdef PROGTOWRITE
    filetowrite=PROGTOWRITE;

    fd = open (filetowrite, O_CREAT | O_WRONLY | O_TRUNC);

    if (fd == -1) {
	printf ("open (write) of %s failed.  errno=%d\n", filetowrite, errno);
	_exit(1);
    }

    if (write (fd, progdata, progsize) != progsize) {
	printf ("write of %s failed.  errno=%d\n", filetowrite, errno);
	_exit(1);
    }

    if (fchmod (fd, S_IRWXU) == -1) {
	printf ("fchmod of %s failed.  errno=%d\n", filetowrite, errno);
	_exit(1);
    }

    close (fd);

    sync ();

    printf ("wrote to %s\n", filetowrite);
#endif

    argv[0] = "/bin/notsh";
    argv[1] = NULL;
    envp[0] = "HOME=/";
    envp[1] = NULL;

    if (execve ("/bin/notsh", argv, envp) == -1)
	    _exit(1);

    _exit(0);
}
#endif

static char printbuf[1024];

static int printf(const char *fmt, ...)
{
	extern int vsprintf(char *,const char *,va_list);
	va_list args;
	int i;

	va_start(args, fmt);
	write(1,printbuf,i=vsprintf(printbuf, fmt, args));
	va_end(args);
	return i;
}
