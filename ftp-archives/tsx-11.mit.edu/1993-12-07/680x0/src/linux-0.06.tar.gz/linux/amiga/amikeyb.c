/*
 * linux/amiga/amikeyb.c
 *
 * Amiga Keyboard driver for 680x0 Linux
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

/*
 * Amiga support by Hamish Macdonald
 */

#include <linux/config.h>
#include <linux/sched.h>
#include <linux/keyboard.h>
#include <linux/interrupt.h>

#include <amiga/types.h>
#include <amiga/interrupt.h>
#include <amiga/chipregs.h>

extern void process_scancode (int);
extern void do_gettimeofday (struct timeval *);

#define AMIKEY_CAPS     (0x62)
#define BREAK_MASK      (0x80)

/*
 * This table maps the Amiga keyboard scan codes to
 * the Linux "virtual" scan codes.  These "virtual" scan
 * codes mostly conform to the scan codes given by an IBM
 * keyboard, except that the E0 xx codes are given unique
 * codes.  These are the codes > 96.  See linux/keyboard.h
 */

static unsigned char ami_kmap[] =
{
/* 00-03 */    KB_BACKQUOTE,  KB_1,	    KB_2,	  KB_3,
/* 04-07 */    KB_4,	      KB_5,	    KB_6,	  KB_7,
/* 08-0B */    KB_8,	      KB_9,	    KB_0,	  KB_DASH,
/* 0C-0F */    KB_EQUAL,      KB_BACKSLASH, KB_NONE,	  KB_KP0,
/* 10-13 */    KB_Q,	      KB_W,	    KB_E,	  KB_R,
/* 14-17 */    KB_T,	      KB_Y,	    KB_U,	  KB_I,
/* 18-1B */    KB_O,	      KB_P,	    KB_LSQUARE,   KB_RSQUARE,
/* 1C-1F */    KB_NONE,       KB_KP1,	    KB_KP2,	  KB_KP3,
/* 20-23 */    KB_A,	      KB_S,	    KB_D,	  KB_F,
/* 24-27 */    KB_G,	      KB_H,	    KB_J,	  KB_K,
/* 28-2B */    KB_L,	      KB_SEMICOLON, KB_APOSTROPHE,KB_NONE,
/* 2C-2F */    KB_NONE,       KB_KP4,	    KB_KP5,	  KB_KP6,
/* 30-33 */    KB_NONE,       KB_Z,	    KB_X,	  KB_C,
/* 34-37 */    KB_V,	      KB_B,	    KB_N,	  KB_M,
/* 38-3B */    KB_COMMA,      KB_PERIOD,    KB_SLASH,	  KB_NONE,
/* 3C-3F */    KB_KPDECIMAL,  KB_KP7,	    KB_KP8,	  KB_KP9,
/* 40-43 */    KB_SPACE,      KB_BACKSPACE, KB_TAB,	  KB_KPENTER,
/* 44-47 */    KB_ENTER,      KB_ESCAPE,    KB_DELETE,	  KB_NONE,
/* 48-4B */    KB_NONE,       KB_NONE,	    KB_KPMINUS,   KB_NONE,
/* 4C-4F */    KB_UP,	      KB_DOWN,	    KB_RIGHT,	  KB_LEFT,
/* 50-53 */    KB_F1,	      KB_F2,	    KB_F3,	  KB_F4,
/* 54-57 */    KB_F5,	      KB_F6,	    KB_F7,	  KB_F8,
/* 58-5B */    KB_F9,	      KB_F10,	    KB_NUMLOCK,   KB_SCROLLLOCK,
/* 5B-5F */    KB_KPDIVIDE,   KB_KPMULTIPLY,KB_KPPLUS,	  KB_F11,
/* 60-63 */    KB_LSHIFT,     KB_RSHIFT,    KB_CAPS,	  KB_LCTRL,
/* 64-67 */    KB_LALT,       KB_ALTGR,     KB_LMACH,	  KB_RMACH,
/* 68-6B */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 6C-6F */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 70-73 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 74-77 */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 78-7B */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE,
/* 7C-7F */    KB_NONE,       KB_NONE,	    KB_NONE,	  KB_NONE
};

static void keyboard_interrupt(struct intframe *fp, void *data)
{
    unsigned char scancode, break_flag;
    struct timeval endtime, curtime;

    /* get and invert scancode (keyboard is active low) */
    scancode = ~ciaa.sdr;

    /* switch SP pin to output and record time for start of handshake */
    ciaa.cra |= 0x40;
    do_gettimeofday (&endtime);
    endtime.tv_usec += 85;
    if (endtime.tv_usec > 1000000) {
	endtime.tv_sec++;
	endtime.tv_usec -= 1000000;
    }
    /* wait until 85 us have expired */
    do {
	do_gettimeofday (&curtime);
    } while (curtime.tv_sec <= endtime.tv_sec &&
	     curtime.tv_usec <= endtime.tv_usec);
    /* switch CIA serial port to input mode */
    ciaa.cra &= ~0x40;

    /* rotate scan code to get up/down bit in proper position */
    __asm__ __volatile__ ("rorb #1,%0" : "=g" (scancode) : "0" (scancode));

    /*
     * do machine independent keyboard processing of "normalized" scancode
     * A "normalized" scancode is one that an IBM PC might generate
     * Check make/break first
     */
    break_flag = scancode & BREAK_MASK;
    scancode &= (unsigned char )~BREAK_MASK;

    if (scancode == AMIKEY_CAPS) {
	    /* if the key is CAPS, fake a press/release. */
	    process_scancode (ami_kmap[AMIKEY_CAPS]);
	    process_scancode (BREAK_MASK | ami_kmap[AMIKEY_CAPS]);
    } else
	    process_scancode (break_flag | ami_kmap[scancode]);


    return;
}

unsigned long amiga_keyb_init (unsigned long mem_start)
{
    /*
     * Initialize serial data direction.
     */
    ciaa.cra &= ~0x41;	     /* serial data in, turn off TA */

    /*
     * arrange for processing of keyboard interrupt
     */
    add_isr (IRQ_AMIGA_CIAA_SP, keyboard_interrupt, 0, NULL);

    return mem_start;
}
