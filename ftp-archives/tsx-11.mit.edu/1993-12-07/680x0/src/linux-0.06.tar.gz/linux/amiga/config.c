/*
 *  linux/amiga/config.c
 *
 *  Copyright (C) 1993 Hamish Macdonald
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

/*
 * Miscellaneous Amiga stuff
 */

#include <linux/config.h>
#include <linux/types.h>
#include <linux/interrupt.h>
#include <linux/sys_info.h>

#include <amiga/chipregs.h>
#include <amiga/interrupt.h>

#include <asm/system.h>

#if 0
caddr_t CustomBase;
caddr_t CiaABase;
caddr_t CiaBBase;
#endif

void amiga_sched_init (isrfunc timer_routine)
{
    /* number of ticks depends on NTSC or PAL CIA EClock */
    unsigned short ticks =
	sys_info.si_amiga.eclock == NTSC_ECLOCK ?
	    NTSC_JIFFY_TICKS : PAL_JIFFY_TICKS;

    /* CIA interrupts when counter underflows, so adjust ticks by 1 */
    ticks -= 1;

    ciab.cra &= 0xC0;	 /* turn off timer A, continous mode, from Eclk */
    ciab.talo = ticks % 256;
    ciab.tahi = ticks / 256;

    /* install interrupt service routine for CIAB Timer A */
    add_isr (IRQ_AMIGA_CIAB_TA, timer_routine, 0, NULL);
    /* start timer */
    ciab.cra |= 0x01;
}

void amiga_gettime_usecs (struct timeval *tv)
{
    unsigned short hi, lo, hi2;
    unsigned long ticks, flags;

    save_flags(flags);
    cli();
    /* read CIA B timer A current value */
    hi	= ciab.tahi;
    lo	= ciab.talo;
    hi2 = ciab.tahi;

    if (hi != hi2)
	lo = ciab.talo;
    restore_flags(flags);

    ticks = hi << 8 | lo;

    if (sys_info.si_amiga.eclock == NTSC_ECLOCK) {
	ticks = (NTSC_JIFFY_TICKS-1) - ticks;
	ticks = 10000 * ticks / NTSC_JIFFY_TICKS;
    } else {
	ticks = (PAL_JIFFY_TICKS-1) - ticks;
	ticks = 10000 * ticks / PAL_JIFFY_TICKS;
    }

    tv->tv_usec += ticks;
    while (tv->tv_usec > 1000000) {
	tv->tv_sec++;
	tv->tv_usec -= 1000000;
    }
}

void waitbut (void)
{
    int i;

    while (1) {
	while (ciaa.pra & 0x40);

	/* debounce */
	for (i = 0; i < 1000; i++);

	if (!(ciaa.pra & 0x40))
	    break;
    }

    /* wait for button up */
    while (1) {
	while (!(ciaa.pra & 0x40));

	/* debounce */
	for (i = 0; i < 1000; i++);

	if (ciaa.pra & 0x40)
	    break;
    }
}

void ami_serial_print (const char *str)
{
	ushort c;

	while (*str) {
		c = *str++;

		custom.serdat = c | 0x100;
		while (!(custom.serdatr & 0x2000))
			;
		if (c == '\n') {
			custom.serdat = '\r' | 0x100;
			while (!(custom.serdatr & 0x2000))
				;
		}
	}
}
