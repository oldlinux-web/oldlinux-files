/*
 *  linux/include/linux/mm.h
 *
 *  Copyright (C) 1991, 1992  Linus Torvalds
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

/*
 * 680x0 support by Hamish Macdonald
 */

#ifndef _LINUX_MM_H
#define _LINUX_MM_H

#include <linux/page.h>
#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/traps.h>
#include <linux/fs.h>

/* The address of the kernel stack in kernel virtual space */
#define KSTACK_ADDR	(0xD0001000)

/* The address of the interrupt stack in kernel virtual space */
#define ISTACK_ADDR	(0xD0003000)

extern unsigned long __bad_page(void);
extern unsigned long __bad_pagetable(void);
extern unsigned long __zero_page(void);

#define BAD_PAGETABLE __bad_pagetable()
#define BAD_PAGE __bad_page()
#define ZERO_PAGE __zero_page()

/*
 * Definitions for MMU descriptors
 */
#define PAGE_PRESENT	0x001
#define PAGE_SHORT	0x002
#define PAGE_RW 	0x000
#define PAGE_RONLY	0x004
#define PAGE_ACCESSED	0x008
#define PAGE_DIRTY	0x010
#define PAGE_COW	0x800	/* implemented in software */
#define PAGE_NOCACHE	0x040
#define PAGE_GLOBAL040  0x400   /* 68040 global bit, used for kva descs */
#define PAGE_CACHE040   0x020   /* 68040 cache mode, cachable, copyback */

#define CACHEMASK040    (~0x060)

extern unsigned long mm_cachebits;
#define PAGE_PRIVATE	(PAGE_PRESENT | PAGE_RW | PAGE_COW | mm_cachebits)
#define PAGE_SHARED	(PAGE_PRESENT | PAGE_RW | mm_cachebits)
#define PAGE_COPY	(PAGE_PRESENT | PAGE_RONLY | PAGE_COW | mm_cachebits)
#define PAGE_READONLY   (PAGE_PRESENT | PAGE_RONLY | mm_cachebits)
#define PAGE_TABLE	(PAGE_SHORT   | PAGE_RW)

#define PAGE_IS_RW(prot) (!((prot) & PAGE_RONLY))

/*
 * This structure describes the virtual memory map for a task.
 *
 * It contains the following:
 *  - virtual pointer to the page directory for the task
 *  - physical pointer to the page directory for the task
 *  - virtual pointer to the kernel stack page for the task
 *  - physical pointer to the kernel stack page for the task
 *  - CPU root pointer for the task
 */
typedef struct {
    unsigned long *pagedir_v;
    unsigned long pagedir_p;
    unsigned long *kstack_v;
    unsigned long kstack_p;
    unsigned long crp[2];
} pmap_t;

#define NUM_L1_ENTRIES	(128)    /* the number of entries in an L1 table
				  * (root table)
				  */
#define NUM_L2_ENTRIES	(8)      /* number of entries in an L2 table.
				  * (pointer table).  Each "entry" is
				  * actually 16 descriptors.  The descriptors
				  * refer to the page table.
				  */
#define NUM_L3_ENTRIES	(1024)   /* number of entries in an L3 table.
				  * (page table)
				  */

/* these constants define how many bytes are mapped by a single pt entry */
#define NBP_L2E 	(NUM_L3_ENTRIES * PAGE_SIZE)
#define NBP_L1E 	(NUM_L2_ENTRIES * NPB_L2E)

/* size of a pointer (or root) table */
#define PTABLE_SIZE     (sizeof(long)*NUM_L1_ENTRIES)

#define L1_SHIFT	(25)      /* to retrieve L1 index */
#define L2_SHIFT	(22)      /* to retrieve L2 index */
#define L3_SHIFT	(12)      /* to retrieve L3 index */

/* macros to retrieve a page table index from an address */
#define L1_INDEX(addr) (((unsigned long)addr) >> L1_SHIFT)
#define L2_INDEX(addr) (((((unsigned long)addr) >> L2_SHIFT) \
			& (NUM_L2_ENTRIES-1))*16)
#define L3_INDEX(addr) ((((unsigned long)addr) >> L3_SHIFT) \
			& (NUM_L3_ENTRIES-1))

#define TABLE_MASK	(0xfffffe00)

/* For virtual address to physical address conversion */
extern unsigned long mm_vtop(unsigned long addr);
extern unsigned long mm_ptov(unsigned long addr);
#define VTOP(addr)  (mm_vtop((unsigned long)(addr)))
#define PTOV(addr)  (mm_ptov((unsigned long)(addr)))

#define invalidate() \
{ \
	if (sys_info.cputype & CPU_68040) \
		__asm__ __volatile__(".word 0xf510"); /* pflushan */ \
	else \
		__asm__ __volatile__("pflusha"); \
}

#define flush_icache() \
{ \
	if (sys_info.cputype & CPU_68040) \
		asm (".word 0xf498"); /* CINVA I */ \
	else \
		asm ("movec cacr,d0;" \
		     "andiw %0,d0;" \
		     "movec d0,cacr" \
		     : /* no outputs */ \
		     : "i" FLUSH_I \
		     : "d0"); \
}

/*
 * invalidate the cache for the specified memory range.
 * It starts at the physical address specified for
 * the given number of bytes.
 */
extern void cache_clear (unsigned long paddr, int len);
/*
 * push any dirty cache in the specified memory range.
 * It starts at the physical address specified for
 * the given number of bytes.
 */
extern void cache_push (unsigned long paddr, int len);

/* cache code */
#define FLUSH_I_AND_D	(0x00000808)
#define FLUSH_I		(0x00000008)

/* memory map definitions */
#define KSTART_ADDR  (0xC0000000)
#define MAP_NR(addr) ((addr-KSTART_ADDR) >> PAGE_SHIFT)
#define MAP_PAGE_RESERVED (1<<15)
extern unsigned short * mem_map;

extern unsigned long free_page_list;
extern unsigned long secondary_page_list;
extern int nr_swap_pages;
extern int nr_free_pages;
extern int nr_secondary_pages;
extern volatile short free_page_ptr; /* used by malloc and tcp/ip. */

#define MAX_SECONDARY_PAGES 10

/* highest kernel memory location */
extern unsigned long high_memory;

/*
 * This is timing-critical - most of the time in getting a new page
 * goes to clearing the page. If you want a page without the clearing
 * overhead, just use __get_free_page() directly..
 */
extern unsigned long __get_free_page(int priority);
extern inline unsigned long get_free_page(int priority)
{
    unsigned long page;

    page = __get_free_page(priority);
    if (page)
	__asm__ __volatile__("movel %0,a0\n\t"
			     "movew #255,d4\n\t"
			     "moveq #0,d0\n\t"
			     "movel d0,d1\n\t"
			     "movel d0,d2\n\t"
			     "movel d0,d3\n\t"
			     "1: moveml d0-d3,a0@-\n\t"
			     "dbra  d4,1b"
			     : /* no outputs */ : "a" (page+PAGE_SIZE)
			     : "d0","d1","d2","d3","d4","a0");
    return page;
}

/* memory.c */
extern void paging_init(unsigned long *start_mem, unsigned long *end_mem);
extern void mem_init(unsigned long start_mem, unsigned long end_mem);
asmlinkage void do_page_fault (struct frame *fp, unsigned long address, unsigned long writecycle);
extern int  copy_page_tables(struct task_struct * to);
extern int clone_page_tables(struct task_struct * to);
extern void free_page_tables(struct task_struct * tsk);
extern void clear_page_tables(struct task_struct * tsk);
extern void show_mem(void);
extern int remap_page_range(unsigned long from, unsigned long to, unsigned long size, int mask);
extern int unmap_page_range(unsigned long from, unsigned long size);
extern int zeromap_page_range(unsigned long from, unsigned long size, int mask);
extern void do_wp_page(unsigned long error_code, unsigned long address,
		       struct task_struct *tsk, unsigned long user_esp);
extern void do_no_page(unsigned long error_code, unsigned long address,
		       struct task_struct *tsk, unsigned long user_esp);
extern void oom(struct task_struct * task);
/*
 * Return the number of valid bytes at 'addr', up to a maximum of 'count'
 * A byte is valid if /dev/mem can read/write it.
 */
extern int valid_addr(unsigned long addr, int count);
extern void si_meminfo(struct sysinfo * val);
extern unsigned long put_dirty_page(struct task_struct * tsk,unsigned long page,
	unsigned long address);

/* swap.c */
/* priority types for get_free_page */
#define GFP_BUFFER	0x00
#define GFP_ATOMIC	0x01
#define GFP_USER	0x02
#define GFP_KERNEL	0x03


/* vm_ops not present page codes */
#define SHM_SWP_TYPE 0x41
extern void shm_no_page (unsigned long *);
extern unsigned long get_free_page(int priority);
extern void free_page(unsigned long addr);
extern void si_swapinfo(struct sysinfo * val);
extern void swap_free(unsigned long page_nr);
extern unsigned long swap_duplicate(unsigned long page_nr);
extern void swap_in(unsigned long *table_ptr);
extern void rw_swap_page(int rw, unsigned long nr, char * buf);
/* mmap.c */
extern int do_mmap(struct file * file, unsigned long addr, unsigned long len,
	unsigned long prot, unsigned long flags, unsigned long off);

#define read_swap_page(nr,buf) \
	rw_swap_page(READ,(nr),(buf))
#define write_swap_page(nr,buf) \
	rw_swap_page(WRITE,(nr),(buf))

/* mmap.c */

/*
 * Linux kernel virtual memory manager primitives.
 * The idea being to have a "virtual" mm in the same way
 * we have a virtual fs - giving a cleaner interface to the
 * mm details, and allowing different kinds of memory mappings
 * (from shared memory to executable loading to arbitrary
 * mmap() functions).
 */

/*
 * This struct defines a memory VMM memory area. There is one of these
 * per VM-area/task.  A VM area is any part of the process virtual memory
 * space that has a special rule for the page-fault handlers (ie a shared
 * library, the executable area etc).
 */
struct vm_area_struct {
	struct task_struct * vm_task;		/* VM area parameters */
	unsigned long vm_start;
	unsigned long vm_end;
	unsigned short vm_page_prot;
	struct vm_area_struct * vm_next;	/* linked list */
	struct vm_area_struct * vm_share;	/* linked list */
	struct inode * vm_inode;
	unsigned long vm_offset;
	struct vm_operations_struct * vm_ops;
};

/*
 * These are the virtual MM functions - opening of an area, closing it (needed to
 * keep files on disk up-to-date etc), pointer to the functions called when a
 * no-page or a wp-page exception occurs, and the function which decides on sharing
 * of pages between different processes.
 */
struct vm_operations_struct {
	void (*open)(struct vm_area_struct * area);
	void (*close)(struct vm_area_struct * area);
	void (*nopage)(int error_code,
		       struct vm_area_struct * area, unsigned long address);
	void (*wppage)(struct vm_area_struct * area, unsigned long address);
	int (*share)(struct vm_area_struct * from, struct vm_area_struct * to, unsigned long address);
};

#endif /* _LINUX_MM_H */
