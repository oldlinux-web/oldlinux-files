/*
 *  linux/include/mac/config.h
 *
 *  Copyright (C) 1993        Hamish Macdonald
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#ifndef _MAC_CONFIG_H_
#define _MAC_CONFIG_H_ 1

#ifdef CONFIG_MAC


#else  /* !CONFIG_MAC */

static __inline void config_mac(void) {}

#endif /* CONFIG_MAC */

#endif /* mac/config.h */
