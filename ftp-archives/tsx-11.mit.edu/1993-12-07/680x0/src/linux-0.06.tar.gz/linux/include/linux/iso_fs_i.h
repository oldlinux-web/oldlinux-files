#ifndef _ISO_FS_I
#define _ISO_FS_I

/*
 * iso fs inode data in memory
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */
struct iso_inode_info {
	unsigned int i_first_extent;
	unsigned int i_backlink;
	unsigned char i_file_format;
};

#endif
