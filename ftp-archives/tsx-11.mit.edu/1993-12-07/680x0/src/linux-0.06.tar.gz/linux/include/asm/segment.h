/*
 *  linux/include/asm/segment.h
 *
 *  Copyright (C) 1991, 1992  Linus Torvalds
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

/*
 * 680x0 support added by Hamish Macdonald
 */

#ifndef _ASM_SEGMENT_H
#define _ASM_SEGMENT_H

static inline unsigned char get_user_byte(const char * addr)
{
	register unsigned char _v;

	__asm__ ("movesb %1,%0":"=r" (_v):"m" (*addr));
	return _v;
}

#define get_fs_byte(addr) get_user_byte((char *)(addr))

static inline unsigned short get_user_word(const short *addr)
{
	unsigned short _v;

	__asm__ ("movesw %1,%0":"=r" (_v):"m" (*addr));
	return _v;
}

#define get_fs_word(addr) get_user_word((short *)(addr))

static inline unsigned long get_user_long(const int *addr)
{
	unsigned long _v;

	__asm__ ("movesl %1,%0":"=r" (_v):"m" (*addr)); \
	return _v;
}

#define get_fs_long(addr) get_user_long((int *)(addr))

static inline void put_user_byte(char val,char *addr)
{
__asm__ ("movesb %0,%1": /* no outputs */ :"r" (val),"m" (*addr) : "memory");
}

#define put_fs_byte(x,addr) put_user_byte((x),(char *)(addr))

static inline void put_user_word(short val,short * addr)
{
__asm__ ("movesw %0,%1": /* no outputs */ :"r" (val),"m" (*addr) : "memory");
}

#define put_fs_word(x,addr) put_user_word((x),(short *)(addr))

static inline void put_user_long(unsigned long val,int * addr)
{
__asm__ ("movesl %0,%1": /* no outputs */ :"r" (val),"m" (*addr) : "memory");
}

#define put_fs_long(x,addr) put_user_long((x),(int *)(addr))

static inline void memcpy_tofs(void * to, const void * from, unsigned long n)
{
	__asm__ __volatile__ ("movel %1,a0\n\t"
			      "movel %2,a1\n\t"
			      "1:\n\t"
			      "moveb a0@+,d0\n\t"
			      "movesb d0,a1@+\n\t"
			      "dbra %0,1b\n\t"
			      "subl #65536,%0\n\t"
			      "bccs 1b"
			      : "=d" (n) : "g" (from), "g" (to), "0" (n-1)
			      : "d0", "a0", "a1");
}

static inline void memcpy_fromfs(void * to, const void * from, unsigned long n)
{
	__asm__ __volatile__ ("movel %1,a0\n\t"
			      "movel %2,a1\n\t"
			      "1:\n\t"
			      "movesb a0@+,d0\n\t"
			      "moveb d0,a1@+\n\t"
			      "dbra %0,1b\n\t"
			      "subl #65536,%0\n\t"
			      "bccs 1b"
			      : "=d" (n) : "g" (from), "g" (to), "0" (n-1)
			      : "d0", "a0", "a1");
}

/*
 * Get/set the SFC/DFC registers for MOVES instructions
 */

static inline unsigned long get_fs(void)
{
	unsigned long _v;
	__asm__("movec dfc,%0":"=r" (_v):);

	return _v;
}

static inline unsigned long get_ds(void)
{
    /* return the supervisor data space code */
    return 0x5;
}

static inline void set_fs(unsigned long val)
{
	__asm__ __volatile__ ("movec %0,sfc\n\t"
			      "movec %0,dfc\n\t"
			      : /* no outputs */ : "r" (val), "r" (val));
}

#endif /* _ASM_SEGMENT_H */
