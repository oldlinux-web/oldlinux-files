void __main (void) {}
