/*
 *  linux/lib/memcmp.c
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#include <linux/types.h>
#include <linux/string.h>

int memcmp(const void * cs,const void * ct,size_t count)
{
  register const unsigned char *s1 = (const unsigned char *) cs;
  register const unsigned char *s2 = (const unsigned char *) ct;
  unsigned char c1, c2;

  do
    {
      c1 = (unsigned char) *s1++;
      c2 = (unsigned char) *s2++;
    }
  while (c1 == c2 && count-- > 0);

  return c1 - c2;
}

