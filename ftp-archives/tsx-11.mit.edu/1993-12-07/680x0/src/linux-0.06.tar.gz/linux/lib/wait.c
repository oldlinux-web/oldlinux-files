/*
 *  linux/lib/wait.c
 *
 *  Copyright (C) 1991, 1992  Linus Torvalds
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

#define __LIBRARY__
#include <linux/unistd.h>
#include <linux/time.h>
#include <linux/resource.h>
#include <linux/types.h>

_syscall4(pid_t,wait4,pid_t,pid,unsigned long *,stat_addr,int,options,
	  struct rusage *, ru);

pid_t wait(int * wait_stat)
{
	return wait4(-1,(unsigned long *)wait_stat,0,0);
}

pid_t waitpid(pid_t pid, int *wait_stat, int options)
{
	return wait4(pid,(unsigned long *)wait_stat,options,0);
}
