#include <linux/autoconf.h>

#include <linux/sched.h>
#include <linux/sys_info.h>

#define offsetof(type, member) ((size_t)(&((type *)0)->member))

void printf (const char *fmt, ...);

int main(void)
{
	printf ("LTS_SR = %d\n", offsetof (struct task_struct, sr));
	printf ("LTS_FS = %d\n", offsetof (struct task_struct, fs));
	printf ("LTS_USP = %d\n", offsetof (struct task_struct, usp));
	printf ("LTS_REGS = %d\n", offsetof (struct task_struct, regs));
	printf ("LTS_KSTACKP = %d\n",
		offsetof (struct task_struct, kernel_stack_page));
	printf ("LTS_PMAP = %d\n", offsetof (struct task_struct, pmap));

#ifdef CONFIG_M68K_FLOAT
	printf ("LTS_FPREGS = %d\n", offsetof (struct task_struct, fpregs));
	printf ("LTS_FPCNTL = %d\n", offsetof (struct task_struct, fpcntl));
	printf ("LTS_FPSTATE = %d\n", offsetof (struct task_struct, fpstate));
#endif /* CONFIG_M68K_FLOAT */

	printf ("LTS_STATE = %d\n", offsetof (struct task_struct, state));
	printf ("LTS_COUNTER = %d\n", offsetof (struct task_struct, counter));
	printf ("LTS_PRIORITY = %d\n",
		offsetof (struct task_struct, priority));
	printf ("LTS_SIGNAL = %d\n", offsetof (struct task_struct, signal));
	printf ("LTS_BLOCKED = %d\n", offsetof (struct task_struct, blocked));
	printf ("LTS_FLAGS = %d\n", offsetof (struct task_struct, flags));
	printf ("LTS_ERRNO = %d\n", offsetof (struct task_struct, errno));

	printf ("LPMAP_KSTACKP = %d\n", offsetof (pmap_t, kstack_p));
	printf ("LPMAP_CRP = %d\n", offsetof (pmap_t, crp));

	printf ("LKSTART_ADDR = %d\n", KSTART_ADDR);
	printf ("LKSTACK_ADDR = %d\n", KSTACK_ADDR);
	printf ("LISTACK_ADDR = %d\n", ISTACK_ADDR);
	printf ("LFLUSH_I_AND_D = %d\n", FLUSH_I_AND_D);
	printf ("LPAGE_PRESENT = %d\n", PAGE_PRESENT);
	printf ("LPAGE_CACHE040 = %d\n", PAGE_CACHE040);
	printf ("LPAGE_SIZE = %d\n", PAGE_SIZE);

	/* sys_info structure field offsets */
	printf ("LSI_MACH = %d\n",
		offsetof (struct sys_info, machtype));
	printf ("LSI_CPU = %d\n",
		offsetof (struct sys_info, cputype));
	printf ("LSI_AMIGA_ECLK = %d\n",
		offsetof (struct sys_info, si_amiga.eclock));

	printf ("LMACH_AMIGA = %d\n",MACH_AMIGA);
}
