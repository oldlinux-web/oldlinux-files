/*
 *  linux/kernel/traps.c
 *
 *  Copyright (C) 1993        Hamish Macdonald
 *
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file README.legal in the main directory of this archive
 * for more details.
 */

/*
 * Sets up all exception vectors
 */

#include <asm/system.h>
#include <asm/segment.h>
#include <linux/traps.h>
#include <linux/sched.h>
#include <linux/signal.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/types.h>
#include <linux/sys_info.h>

/* assembler routines */
asmlinkage void system_call(void);
asmlinkage void buserr(void);
asmlinkage void trap(void);
asmlinkage void inthandler(void);

e_vector vectors[256] = {
	0, 0, buserr, trap, trap, trap, trap, trap,
	trap, trap, trap, trap, 0, trap, trap, trap,
	0, 0, 0, 0, 0, 0, 0, 0,
	inthandler, inthandler, inthandler, inthandler,
	inthandler, inthandler, inthandler, inthandler,
	/* TRAP #0-15 */
	system_call, trap, trap, trap, trap, trap, trap, trap,
	trap, trap, trap, trap, trap, trap, trap, trap,
	trap, trap, trap, trap, trap, trap, trap, 0,
	trap, trap, trap, 0,
};

void vec_init (void)
{
	/* setup the exception vector table */
	__asm__ volatile ("movec %0,vbr" : : "r" ((void*)vectors));

#ifdef CONFIG_FPSP_040
	if (sys_info.cputype & CPU_68040) {
		/* set up FPSP entry points */
		asmlinkage void dz_vec(void) asm ("dz");
		asmlinkage void inex_vec(void) asm ("inex");
		asmlinkage void ovfl_vec(void) asm ("ovfl");
		asmlinkage void unfl_vec(void) asm ("unfl");
		asmlinkage void snan_vec(void) asm ("snan");
		asmlinkage void operr_vec(void) asm ("operr");
		asmlinkage void bsun_vec(void) asm ("bsun");
		asmlinkage void fline_vec(void) asm ("fline");
		asmlinkage void unsupp_vec(void) asm ("unsupp");

		vectors[VEC_FPDIVZ] = dz_vec;
		vectors[VEC_FPIR] = inex_vec;
		vectors[VEC_FPOVER] = ovfl_vec;
		vectors[VEC_FPUNDER] = unfl_vec;
		vectors[VEC_FPNAN] = snan_vec;
		vectors[VEC_FPOE] = operr_vec;
		vectors[VEC_FPBRUC] = bsun_vec;
		vectors[VEC_FPBRUC] = bsun_vec;
		vectors[VEC_LINE11] = fline_vec;
		vectors[VEC_FPUNSUP] = unsupp_vec;
	}
#endif
}

char *vec_names[] = {
	"RESET SP", "RESET PC", "BUS ERROR", "ADDRESS ERROR",
	"ILLEGAL INSTRUCTION", "ZERO DIVIDE", "CHK", "TRAPcc",
	"PRIVELIGE VIOLATION", "TRACE", "LINE 1010", "LINE 1111",
	"UNASSIGNED RESERVED 12", "COPROCESSOR PROTOCOL VIOLATION",
	"FORMAT ERROR", "UNINITIALIZED INTERRUPT",
	"UNASSIGNED RESERVED 16", "UNASSIGNED RESERVED 17",
	"UNASSIGNED RESERVED 18", "UNASSIGNED RESERVED 19",
	"UNASSIGNED RESERVED 20", "UNASSIGNED RESERVED 21",
	"UNASSIGNED RESERVED 22", "UNASSIGNED RESERVED 23",
	"SPURIOUS INTERRUPT", "LEVEL 1 INT", "LEVEL 2 INT", "LEVEL 3 INT",
	"LEVEL 4 INT", "LEVEL 5 INT", "LEVEL 6 INT", "LEVEL 7 INT",
	"SYSCALL", "TRAP #1", "TRAP #2", "TRAP #3",
	"TRAP #4", "TRAP #5", "TRAP #6", "TRAP #7",
	"TRAP #8", "TRAP #9", "TRAP #10", "TRAP #11",
	"TRAP #12", "TRAP #13", "TRAP #14", "TRAP #15"
	};

char *space_names[] = {
	"Space 0", "User Data", "User Program", "Space 3",
	"Space 4", "Super Data", "Super Program", "CPU"
	};



extern void die_if_kernel(char *,struct frame *,int);

asmlinkage void trap_c(struct frame *fp);

static unsigned long probe040 (int iswrite, int fc, unsigned long addr)
{
	unsigned long mmusr;
	unsigned short fs = get_fs();

	set_fs (fc);

	if (iswrite)
		/* write */
		asm volatile ("movel %1,a0\n\t"
			      /* ptestw (a0) */
			      ".word 0xf548\n\t"
			      /* movec mmusr,a0 */
			      ".long 0x4e7a8805\n\t"
			      "movel a0,%0"
			      : "=g" (mmusr)
			      : "g" (addr)
			      : "a0");
	asm volatile ("movel %1,a0\n\t"
		      /* ptestr (a0) */
		      ".word 0xf568\n\t"
		      /* movec mmusr,a0 */
		      ".long 0x4e7a8805\n\t"
		      "movel a0,%0"
		      : "=g" (mmusr)
		      : "g" (addr)
		      : "a0");

	set_fs (fs);

	return mmusr;
}

static void do_040writeback (unsigned short wbs,
			     unsigned long wba,
			     unsigned long wbd,
			     struct frame *fp)
{
	unsigned short fs = get_fs ();
	unsigned long mmusr;

	/*
	 * to avoid another page fault, check the address we're going to,
	 * and map it in
	 */
	mmusr = probe040 (1, wbs & WBTM_040,  wba);
	if (mmusr & MMU_R_040)
		do_page_fault (fp, wba, 1);
	else
		do_page_fault (fp, wba, 0);

	/*
	 * if the write spans a page, make sure that the extra page
	 * is mapped in.
	 */
	if ((wbs & WBSIZ_040) == BA_SIZE_WORD &&
	    (wba >> PAGE_SHIFT) != ((wba + 1) >> PAGE_SHIFT)) {
		mmusr = probe040 (1, wbs & WBTM_040, wba + 1);
		if (mmusr & MMU_R_040)
			do_page_fault (fp, wba + 1, 1);
		else
			do_page_fault (fp, wba + 1, 0);
	} else if((wbs & WBSIZ_040) == BA_SIZE_LONG &&
		  (wba >> PAGE_SHIFT) != ((wba + 3) >> PAGE_SHIFT)) {
		mmusr = probe040 (1, wbs & WBTM_040, wba + 3);
		if (mmusr & MMU_R_040)
			do_page_fault (fp, wba + 3, 1);
		else
			do_page_fault (fp, wba + 3, 0);
	}

	set_fs (wbs & WBTM_040);
	switch (wbs & WBSIZ_040) {
	    case BA_SIZE_BYTE:
		put_user_byte (wbd & 0xff, (char *)wba);
		break;
	    case BA_SIZE_WORD:
		put_user_word (wbd & 0xffff, (short *)wba);
		break;
	    case BA_SIZE_LONG:
		put_user_long (wbd, (int *)wba);
		break;
	}
	set_fs (fs);
}

static inline void access_error040 (struct frame *fp)
{
	unsigned short ssw = fp->un.fmt7.ssw;
	unsigned long mmusr;

	if (ssw & ATC_040) {
		unsigned long addr = fp->un.fmt7.faddr;

		/* MMU error, get the MMUSR info for this access */
		mmusr = probe040 (!(ssw & RW_040), ssw & TM_040, addr);

		if (mmusr & MMU_R_040)
			do_page_fault (fp, addr, 1);
		else
			do_page_fault (fp, addr, 0);
	} else {
		printk ("68040 access error, ssw=%x\n", ssw);
		trap_c (fp);
	}

	/*
	 * We may have to do a couple of writebacks here.
	 */
	if (fp->un.fmt7.wb2s & WBV_040
	    && (fp->un.fmt7.wb2s & WBTT_040) != BA_TT_MOVE16)
		do_040writeback (fp->un.fmt7.wb2s, fp->un.fmt7.wb2a,
				 fp->un.fmt7.wb2d, fp);

	if (fp->un.fmt7.wb3s & WBV_040)
		do_040writeback (fp->un.fmt7.wb3s, fp->un.fmt7.wb3a,
				 fp->un.fmt7.wb3d, fp);
}

static inline void bus_error030 (struct frame *fp)
{
	volatile unsigned short mmusr;
	unsigned long addr, desc;
	unsigned short ssw = fp->un.fmtb.ssw;

#ifdef DEBUG
	printk ("SSW=%#06x  ", ssw);

	if (ssw & (FC | FB))
		printk ("Instruction fault at %#010x\n",
			ssw & FC ?
			fp->format == 0xa ? fp->pc + 2 : fp->un.fmtb.baddr - 2
			:
			fp->format == 0xa ? fp->pc + 4 : fp->un.fmtb.baddr);
	if (ssw & DF)
		printk ("Data %s fault at %#010x in %s (pc=%#lx)\n",
			ssw & RW ? "read" : "write",
			fp->un.fmtb.daddr,
			space_names[ssw & DFC], fp->pc);
#endif

	if (fp->sr & PS_S) {
		/* kernel fault must be a data fault to user space */
		if (! ((ssw & DF) && ((ssw & DFC) == USER_DATA))) {
			/* instruction fault or kernel data fault! */
			if (ssw & (FC | FB))
				printk ("Instruction fault at %#010x\n",
					fp->pc);
			if (ssw & DF) {
				printk ("Data %s fault at %#010x in %s (pc=%#lx)\n",
					ssw & RW ? "read" : "write",
					fp->un.fmtb.daddr,
					space_names[ssw & DFC], fp->pc);
			}
			printk ("BAD KERNEL BUSERR");
			trap_c (fp);
		}
	} else {
		/* user fault */
		if (!(ssw & (FC | FB)) && !(ssw & DF))
			/* not an instruction fault or data fault! BAD */
			panic ("USER BUSERR w/o instruction or data fault");
	}

	/* get the fault address */
	if (fp->format == 0xA )
		if (ssw & FC)
			addr = fp->pc + 2;
		else if (ssw & FB)
			addr = fp->pc + 4;
		else /* data fault */
			addr = fp->un.fmta.daddr;
	else
		if (ssw & FC)
			addr = fp->un.fmtb.baddr - 2;
		else if (ssw & FB)
			addr = fp->un.fmtb.baddr;
		else /* data fault */
			addr = fp->un.fmtb.daddr;

	asm volatile ("ptestr #1,%2@,#7,%0\n\t"
		      "pmove psr,%1@"
		      : "=a&" (desc)
		      : "a" (&mmusr), "a" (addr)
		      : "memory");
#ifdef DEBUG
	printk ("mmusr is %#x for addr %#x in task %p\n",
		mmusr, addr, current);
	printk ("descriptor address is %#x, contents %#x\n",
		PTOV(desc), *(unsigned long *)PTOV(desc));
#endif
	if (mmusr & MMU_WP)
		do_page_fault (fp, addr, 1);
	else if (mmusr & MMU_I)
		do_page_fault (fp, addr, 0);
	else {
		printk ("invalid %s access at %#lx from pc %#lx\n",
			!(ssw & RW) ? "write" : "read", addr, fp->pc);
		die_if_kernel("Oops",fp,mmusr);
		if (!(fp->sr & PS_S)) {
			send_sig(SIGSEGV, current, 1);
			return;
		}
	}

	/* setup an ATC entry for the access about to be retried */
	if (!(ssw & RW))
		asm volatile ("ploadw #1,%0@" : /* no outputs */
			      : "a" (addr));
	else
		asm volatile ("ploadr #1,%0@" : /* no outputs */
			      : "a" (addr));
}

asmlinkage void buserr_c(struct frame *fp)
{

#ifdef DEBUG
	printk ("*** Bus Error *** Format is %x\n", fp->format);
#endif

	switch (fp->format) {
	    case 7:				/* 68040 access error */
		access_error040 (fp);
		break;
	    case 0xa:
	    case 0xb:
		bus_error030 (fp);
		break;
	    default:
		panic ("bad frame format %d", fp->format);
	}
}


asmlinkage void trap_c(struct frame *fp)
{
	unsigned long isp;
	int sig;

	/* fetch interrupt stack pointer */
	__asm__ __volatile__ ("movec isp,%0" : "=g" (isp));

	if (fp->vector < 48*4)
		printk ("*** %s ***   FORMAT=%X\n",
			vec_names[fp->vector >> 2], fp->format);
	else
		printk ("*** Exception %d ***   FORMAT=%X\n", fp->vector >> 2,
			fp->format);

	printk ("PC=%#010x   SR=%#06x       SP=%#010x  ISP=%#010x\n",
		fp->pc, fp->sr, (ulong)fp, isp);
	printk ("D0=%#010x   D1=%#010x   D2=%#010x   D3=%#010x\n",
		fp->d0, fp->regs[0], fp->regs[1], fp->regs[2]);
	printk ("D4=%#010x   D5=%#010x   D6=%#010x   D7=%#010x\n",
		fp->regs[3], fp->regs[4], fp->regs[5], fp->regs[6]);
	printk ("A0=%#010x   A1=%#010x   A2=%#010x   A3=%#010x\n",
		fp->regs[7], fp->regs[8], fp->regs[9], fp->regs[10]);
	printk ("A4=%#010x   A5=%#010x   A6=%#010x  USP=%#010x\n",
		fp->regs[11], fp->regs[12], fp->regs[13], fp->usp);

	if ((fp->vector >> 2) == VEC_ADDRERR
	    && !(sys_info.cputype & CPU_68040)) {
		unsigned short ssw = fp->un.fmtb.ssw;

		printk ("SSW=%#06x  ", ssw);

		if (ssw & RC)
			printk ("Pipe stage C instruction fault at %#010x\n",
				fp->format == 0xA ? fp->pc + 2 :
				fp->un.fmtb.baddr - 2);
		if (ssw & RB)
			printk ("Pipe stage B instruction fault at %#010x\n",
				fp->format == 0xA ? fp->pc + 4 :
				fp->un.fmtb.baddr);
		if (ssw & DF)
			printk ("Data %s fault at %#010x in %s (pc=%#lx)\n",
				ssw & RW ? "read" : "write",
				fp->un.fmtb.daddr, space_names[ssw & DFC],
				fp->pc);

		if (fp->sr & PS_S) {
			/* kernel fault must be a data fault to user space */
			if (!(ssw & DF) || (ssw & DFC) != USER_DATA)
				/* instruction fault! BAD */
				panic ("BAD KERNEL ADDRESS ERROR");
		} else {
			/* user fault */
			if (!(ssw & (RC | RB)) && !(ssw & DF))
				/* not an instruction fault or data fault! */
				panic ("USER ADDRERR w/o instruction or"
				       " data fault");
		}
	}

	if ((fp->vector >> 2) == VEC_ADDRERR) {
		unsigned short iw;

		if (fp->sr & PS_S)
			iw = *(ushort *)fp->pc;
		else
			iw = get_fs_word ((ushort *)fp->pc);

		printk ("Word at pc is %#x\n", iw);
	}

	if (fp->sr & PS_S)
		panic ("BAD KERNEL TRAP");

	/* send the appropriate signal to the user program */
	switch (fp->vector >> 2) {
	    case VEC_BUSERR:
	    case VEC_ADDRERR:
		sig = SIGSEGV;
		break;
	    case VEC_ILLEGAL:
	    case VEC_PRIV:
	    case VEC_LINE10:
	    case VEC_LINE11:
	    case VEC_COPROC:
	    case VEC_TRAP1:
	    case VEC_TRAP2:
	    case VEC_TRAP3:
	    case VEC_TRAP4:
	    case VEC_TRAP5:
	    case VEC_TRAP6:
	    case VEC_TRAP7:
	    case VEC_TRAP8:
	    case VEC_TRAP9:
	    case VEC_TRAP10:
	    case VEC_TRAP11:
	    case VEC_TRAP12:
	    case VEC_TRAP13:
	    case VEC_TRAP14:
	    case VEC_TRAP15:
		sig = SIGILL;
		break;
	    case VEC_ZERODIV:
	    case VEC_FPBRUC:
	    case VEC_FPIR:
	    case VEC_FPDIVZ:
	    case VEC_FPUNDER:
	    case VEC_FPOE:
	    case VEC_FPOVER:
	    case VEC_FPNAN:
		sig = SIGFPE;
		break;
	    default:
		sig = SIGILL;
		break;
	}

	send_sig (sig, current, 1);
}

void die_if_kernel (char *str, struct frame *fp, int nr)
{
	u_char *ssp = (u_char *)fp;
	int i;

	if (!(fp->sr & PS_S))
		return;

	printk("%s: %04x\n",str,nr&0xffff);
	printk("PC:    %08x\nSR: %04x\n", fp->pc,fp->sr);
	printk("Pid: %d\n",current->pid);
	for (i = 0; i < 10; i++)
		printk ("%02x ", 0xff & ssp[i]);
	printk ("\n");
	do_exit(SIGSEGV);
}

#if 0
void showwierd(struct frame *fp)
{
	ulong reg;

	printk ("Current pid is %d\n", current->pid);

	__asm__ __volatile__ ("movew sr,%0" : "=d" (reg));
	printk ("Current sr is %#06x\n", reg);

	printk ("Format is %#x, vector is %d\n", fp->format,
		fp->vector >> 2);

	__asm__ __volatile__ ("movec isp,%0" : "=d" (reg));

	printk ("PC=%#010x   SR=%#06x       SP=%p  ISP=%#010x\n",
		fp->pc, fp->sr, fp, reg);
	printk ("D0=%#010x   D1=%#010x   D2=%#010x   D3=%#010x\n",
		fp->d0, fp->regs[0], fp->regs[1], fp->regs[2]);
	printk ("D4=%#010x   D5=%#010x   D6=%#010x   D7=%#010x\n",
		fp->regs[3], fp->regs[4], fp->regs[5], fp->regs[6]);
	printk ("A0=%#010x   A1=%#010x   A2=%#010x   A3=%#010x\n",
		fp->regs[7], fp->regs[8], fp->regs[9], fp->regs[10]);
	printk ("A4=%#010x   A5=%#010x   A6=%#010x  USP=%#010x\n",
		fp->regs[11], fp->regs[12], fp->regs[13], fp->usp);

	printk ("orig_d0=%#010x  stkadj=%#06x\n", fp->orig_d0, fp->stkadj);
}
#endif
