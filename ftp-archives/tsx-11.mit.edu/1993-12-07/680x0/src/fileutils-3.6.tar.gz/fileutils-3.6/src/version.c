#include "version.h"
const char *version_string = "GNU fileutils 3.6";
