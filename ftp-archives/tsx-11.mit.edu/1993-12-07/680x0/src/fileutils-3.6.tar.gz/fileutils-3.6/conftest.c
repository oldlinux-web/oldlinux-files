#include <stdio.h>
_errno __g