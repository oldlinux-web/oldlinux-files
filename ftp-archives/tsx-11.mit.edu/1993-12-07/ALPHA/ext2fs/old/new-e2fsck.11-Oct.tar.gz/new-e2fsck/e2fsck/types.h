/*
 * types.h --- some basic type declarations for e2fsck and friends.
 */

typedef unsigned long	blk_t;
typedef unsigned int	dgrp_t;

