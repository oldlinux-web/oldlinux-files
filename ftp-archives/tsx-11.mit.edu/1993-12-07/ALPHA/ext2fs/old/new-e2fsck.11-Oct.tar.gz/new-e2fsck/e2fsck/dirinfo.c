/*
 * dirinfo.c
 */

#include <et/com_err.h>
#include "e2fsck.h"

static errcode_t dir_info_check_directory(ext2_filsys fs, ino_t ino);
static errcode_t dir_info_get_blocks(ext2_filsys fs, ino_t ino, blk_t *blocks);
static int dircmp(const void *a, const void *b);

static int		dir_info_count = 0;
static int		dir_info_size = 0;
static struct dir_info	*dir_info = 0;
static struct	dir_info	**dir_info_sorted = 0;

/*
 * This subroutine is called during pass1 to stash away the block
 * numbers for the directory, which we will need later.  The idea is
 * to avoid reading directory inodes twice.
 */
void add_dir_info(ext2_filsys fs, ino_t ino, ino_t parent,
		struct ext2_inode *inode)
{
	struct dir_info *dir;
	int	i, j;

#if 0
	printf("add_dir_info for inode %d...\n", ino);
#endif
	if (!dir_info) {
		dir_info_count = 0;
		dir_info_size = 0;
		for (i = 0; i < fs->group_desc_count; i++)
			dir_info_size += fs->group_desc[i].bg_used_dirs_count;
		dir_info_size += 10;

		dir_info  = allocate_memory(dir_info_size *
					   sizeof (struct dir_info),
					   "directory map");
	}
	
	if (dir_info_count >= dir_info_size) {
		dir_info_size += 10;
		dir_info = realloc(dir_info,
				  dir_info_size * sizeof(struct dir_info));
	}

	/*
	 * Normally, add_dir_info is called with each inode in
	 * sequential order; but once in a while (like when pass 3
	 * needs to recreate the root directory or lost+found
	 * directory) it is called out of order.  In those cases, we
	 * need to move the dir_info entries down to make room, since
	 * the dir_info array needs to be sorted by inode number for
	 * get_dir_info()'s sake.
	 */
	if (dir_info_count && dir_info[dir_info_count-1].ino > ino) {
		for (i = 0; i < dir_info_count++; i++)
			if (dir_info[i].ino >= ino)
				break;
		dir = &dir_info[i];
		if (dir->ino != ino) 
			for (j = dir_info_count++; j > i; j--)
				dir_info[j] = dir_info[j-1];
	} else
		dir = &dir_info[dir_info_count++];
	
	dir->ino = ino;
	dir->dotdot = parent;
	dir->parent = get_dir_info(parent);
	for (i=0; i < EXT2_N_BLOCKS; i++)
		dir->block[i] = inode->i_block[i];
}

/*
 * get_dir_info() --- given an inode number, try to find the directory
 * informaion entry for it.
 */
struct dir_info *get_dir_info(ino_t ino)
{
	int	low, high, mid;

	low = 0;
	high = dir_info_count-1;
	if (ino == dir_info[low].ino)
		return &dir_info[low];
	if  (ino == dir_info[high].ino)
		return &dir_info[high];

	while (low < high) {
		mid = (low+high)/2;
		if (mid == low || mid == high)
			break;
		if (ino == dir_info[mid].ino)
			return &dir_info[mid];
		if (ino < dir_info[mid].ino)
			high = mid;
		else
			low = mid;
	}
	return 0;
}

errcode_t get_sorted_dir_info(struct dir_info ***ret_info, int *ret_count)
{
	int	i;
	
	if (!dir_info_sorted) {
		dir_info_sorted = malloc(dir_info_count *
					sizeof(struct dir_info *));
		if (!dir_info_sorted)
			return ENOMEM;
		for (i=0; i < dir_info_count; i++)
			dir_info_sorted[i] = &dir_info[i];
		qsort(dir_info_sorted, dir_info_count,
		      sizeof(struct dir_info *), dircmp);
	}
	*ret_info = dir_info_sorted;
	*ret_count = dir_info_count;
	return 0;
}

static int dircmp(const void *a, const void *b)
{
	const struct dir_info **dir_a = (const struct dir_info **) a;
	const struct dir_info **dir_b = (const struct dir_info **) b;
	
	return ((*dir_a)->block[0] - (*dir_b)->block[0]);
}

void use_dir_info(ext2_filsys fs)
{
	fs->get_blocks = dir_info_get_blocks;
	fs->check_directory = dir_info_check_directory;
}

/*
 * These subroutines short circuits ext2fs_get_blocks and
 * ext2fs_check_directory; we use them since we already have the
 * directory inode information already stashed away.
 */
static errcode_t dir_info_get_blocks(ext2_filsys fs, ino_t ino, blk_t *blocks)
{
	struct dir_info *dir;
	int	i;

	dir = get_dir_info(ino);

	if (dir) {
		for (i=0; i < EXT2_N_BLOCKS; i++)
			blocks[i] = dir->block[i];
		return 0;
	}
	return ENOTDIR;
}

static errcode_t dir_info_check_directory(ext2_filsys fs, ino_t ino)
{
	if (ext2fs_test_inode_bitmap(fs, inode_dir_map, ino))
		return 0;
	return ENOTDIR;
}

/*
 * Free the dir_info structure when it isn't needed any more.
 */
void free_dir_info(ext2_filsys fs)
{
	if (dir_info) {
		free(dir_info);
		dir_info = 0;
	}
	dir_info_size = 0;
	dir_info_count = 0;
	if (dir_info_sorted) {
		free(dir_info_sorted);
		dir_info_sorted = 0;
	}
	if (fs->get_blocks == dir_info_get_blocks)
		fs->get_blocks = 0;
	if (fs->check_directory == dir_info_check_directory)
		fs->check_directory = 0;
	
}
