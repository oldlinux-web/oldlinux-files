/*
 * bitops.h --- Bitmap frobbing code.
 *
 * Taken from <asm/bitops.h>, Copyright 1992, Linus Torvalds.
 */

#ifdef i386
/*
 * These have to be done with inline assembly: that way the bit-setting
 * is guaranteed to be atomic. All bitoperations return 0 if the bit
 * was cleared before the operation and != 0 if it was not.
 *
 * bit 0 is the LSB of addr; bit 32 is the LSB of (addr+1).
 */

/*
 * Some hacks to defeat gcc over-optimizations..
 */
struct __dummy_h { unsigned long a[100]; };
#define ADDR (*(struct __dummy_h *) addr)

extern __inline__ int set_bit(int nr, void * addr)
{
	int oldbit;

	__asm__ __volatile__("btsl %2,%1\n\tsbbl %0,%0"
		:"=r" (oldbit),"=m" (ADDR)
		:"r" (nr));
	return oldbit;
}

extern __inline__ int clear_bit(int nr, void * addr)
{
	int oldbit;

	__asm__ __volatile__("btrl %2,%1\n\tsbbl %0,%0"
		:"=r" (oldbit),"=m" (ADDR)
		:"r" (nr));
	return oldbit;
}

/*
 * This routine doesn't need to be atomic, but it's faster to code it
 * this way.
 */
extern __inline__ int test_bit(int nr, void * addr)
{
	int oldbit;

	__asm__ __volatile__("btl %2,%1\n\tsbbl %0,%0"
		:"=r" (oldbit)
		:"m" (ADDR),"r" (nr));
	return oldbit;
}

#undef ADDR

#else
/*
 * For non 386 architectures, just call the subroutines in bitops.c
 */

extern int set_bit(int nr,int * addr);
extern int clear_bit(int nr, int * addr);
extern int test_bit(int nr, int * addr);

#endif	/* i386 */

/*
 * EXT2FS bitmap manipulation routines.
 */

/* Support for sending warning messages from the inline subroutines */
extern char *ext2fs_block_string;
extern char *ext2fs_inode_string;
extern char *ext2fs_mark_string;
extern char *ext2fs_unmark_string;
extern char *ext2fs_test_string;
extern void ext2fs_warn_bitmap(ext2_filsys fs, char *op, char *type, int arg);

extern inline void ext2fs_mark_block_bitmap(ext2_filsys fs, char *bitmap,
					    int block)
{
	if ((block < fs->super->s_first_data_block) ||
	    (block >= fs->super->s_blocks_count)) {
		ext2fs_warn_bitmap(fs, ext2fs_mark_string,
				   ext2fs_block_string, block);
		return;
	}
	set_bit(block - fs->super->s_first_data_block, bitmap);
}

extern inline void ext2fs_unmark_block_bitmap(ext2_filsys fs, char *bitmap,
					      int block)
{
	if ((block < fs->super->s_first_data_block) ||
	    (block >= fs->super->s_blocks_count)) {
		ext2fs_warn_bitmap(fs, ext2fs_unmark_string,
				   ext2fs_block_string, block);
		return;
	}
	clear_bit(block - fs->super->s_first_data_block, bitmap);
}

extern inline int ext2fs_test_block_bitmap(ext2_filsys fs, char *bitmap,
					   int block)
{
	if ((block < fs->super->s_first_data_block) ||
	    (block >= fs->super->s_blocks_count)) {
		ext2fs_warn_bitmap(fs, ext2fs_test_string,
				   ext2fs_block_string, block);
		return 0;
	}
	return test_bit(block - fs->super->s_first_data_block, bitmap);
}

extern inline void ext2fs_mark_inode_bitmap(ext2_filsys fs, char *bitmap,
					    int inode)
{
	if ((inode < 1) || (inode > fs->super->s_inodes_count)) {
		ext2fs_warn_bitmap(fs, ext2fs_mark_string,
				   ext2fs_inode_string, inode);
		return;
	}
	set_bit(inode - 1, bitmap);
}

extern inline void ext2fs_unmark_inode_bitmap(ext2_filsys fs, char *bitmap,
					      int inode)
{
	if ((inode < 1) || (inode > fs->super->s_inodes_count)) {
		ext2fs_warn_bitmap(fs, ext2fs_unmark_string,
				   ext2fs_inode_string, inode);
		return;
	}
	clear_bit(inode - 1, bitmap);
}

extern inline int ext2fs_test_inode_bitmap(ext2_filsys fs, char *bitmap,
					   int inode)
{
	if ((inode < 1) || (inode > fs->super->s_inodes_count)) {
		ext2fs_warn_bitmap(fs, ext2fs_test_string,
				   ext2fs_inode_string, inode);
		return 0;
	}
	return test_bit(inode - 1, bitmap);
}
