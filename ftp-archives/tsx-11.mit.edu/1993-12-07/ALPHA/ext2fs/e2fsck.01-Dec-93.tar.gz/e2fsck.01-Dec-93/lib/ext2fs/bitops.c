/*
 * bitops.c --- Bitmap frobbing code.
 *
 * Copyright (C) 1993 Theodore Ts'o.  This file may be redistributed
 * under the terms of the GNU Public License.
 * 
 * Taken from <asm/bitops.h>, Copyright 1992, Linus Torvalds.
 */

#include <stdio.h>
#include <sys/types.h>
#include <linux/fs.h>
#include <linux/ext2_fs.h>

#include "ext2fs.h"

#ifdef i386
/*
 * These have to be done with inline assembly: that way the bit-setting
 * is guaranteed to be atomic. All bitoperations return 0 if the bit
 * was cleared before the operation and != 0 if it was not.
 *
 * bit 0 is the LSB of addr; bit 32 is the LSB of (addr+1).
 */

/*
 * Some hacks to defeat gcc over-optimizations..
 */
struct __dummy { unsigned long a[100]; };
#define ADDR (*(struct __dummy *) addr)

int set_bit(int nr, void * addr)
{
	int oldbit;

	__asm__ __volatile__("btsl %2,%1\n\tsbbl %0,%0"
		:"=r" (oldbit),"=m" (ADDR)
		:"r" (nr));
	return oldbit;
}

int clear_bit(int nr, void * addr)
{
	int oldbit;

	__asm__ __volatile__("btrl %2,%1\n\tsbbl %0,%0"
		:"=r" (oldbit),"=m" (ADDR)
		:"r" (nr));
	return oldbit;
}

/*
 * This routine doesn't need to be atomic, but it's faster to code it
 * this way.
 */
int test_bit(int nr, void * addr)
{
	int oldbit;

	__asm__ __volatile__("btl %2,%1\n\tsbbl %0,%0"
		:"=r" (oldbit)
		:"m" (ADDR),"r" (nr));
	return oldbit;
}

#else
/*
 * For the benefit of those who are trying to port Linux to another
 * architecture, here are some C-language equivalents.  You should
 * recode these in the native assmebly language, if at all possible.
 * To guarantee atomicity, these routines call cli() and sti() to
 * disable interrupts while they operate.  (You have to provide inline
 * routines to cli() and sti().)
 *
 * Also note, these routines assume that you have 32 bit integers.
 * You will have to change this if you are trying to port Linux to the
 * Alpha architecture or to a Cray.  :-)
 * 
 * C language equivalents written by Theodore Ts'o, 9/26/92
 */

int set_bit(int nr,int * addr)
{
	int	mask, retval;

	addr += nr >> 5;
	mask = 1 << (nr & 0x1f);
	cli();
	retval = (mask & *addr) != 0;
	*addr |= mask;
	sti();
	return retval;
}

int clear_bit(int nr, int * addr)
{
	int	mask, retval;

	addr += nr >> 5;
	mask = 1 << (nr & 0x1f);
	cli();
	retval = (mask & *addr) != 0;
	*addr &= ~mask;
	sti();
	return retval;
}

int test_bit(int nr, int * addr)
{
	int	mask;

	addr += nr >> 5;
	mask = 1 << (nr & 0x1f);
	return ((mask & *addr) != 0);
}
#endif	/* i386 */

/*
 * Now here are some specific routines to manipulate ext2fs
 * bitmaps....
 */

/*
 * These are routines print warning messages; they are called by
 * inline routines.
 */
char *ext2fs_block_string = "block";
char *ext2fs_inode_string = "inode";
char *ext2fs_mark_string = "mark";
char *ext2fs_unmark_string = "unmark";
char *ext2fs_test_string = "test";

void ext2fs_warn_bitmap(ext2_filsys fs, char *op, char *type, int arg)
{
	char	func[80];

	sprintf(func, "ext2fs_%s_%s_bitmap", op, type);
	com_err(func, 0, "INTERNAL ERROR: illegal %s #%d for %s",
		type, arg, fs->device_name);
}

/*
 * The following routines are duplicated in bitops.h, in inline
 * fashion....
 */
void ext2fs_mark_block_bitmap(ext2_filsys fs, char *bitmap, int block)
{
	if ((block < fs->super->s_first_data_block) ||
	    (block >= fs->super->s_blocks_count)) {
		ext2fs_warn_bitmap(fs, ext2fs_mark_string,
				   ext2fs_block_string, block);
		return;
	}
	set_bit(block - fs->super->s_first_data_block, bitmap);
}

void ext2fs_unmark_block_bitmap(ext2_filsys fs, char *bitmap, int block)
{
	if ((block < fs->super->s_first_data_block) ||
	    (block >= fs->super->s_blocks_count)) {
		ext2fs_warn_bitmap(fs, ext2fs_unmark_string,
				   ext2fs_block_string, block);
		return;
	}
	clear_bit(block - fs->super->s_first_data_block, bitmap);
}

int ext2fs_test_block_bitmap(ext2_filsys fs, char *bitmap, int block)
{
	if ((block < fs->super->s_first_data_block) ||
	    (block >= fs->super->s_blocks_count)) {
		ext2fs_warn_bitmap(fs, ext2fs_test_string,
				   ext2fs_block_string, block);
		return 0;
	}
	return test_bit(block - fs->super->s_first_data_block, bitmap);
}

void ext2fs_mark_inode_bitmap(ext2_filsys fs, char *bitmap, int inode)
{
	if ((inode < 1) || (inode > fs->super->s_inodes_count)) {
		ext2fs_warn_bitmap(fs, ext2fs_mark_string,
				   ext2fs_inode_string, inode);
		return;
	}
	set_bit(inode - 1, bitmap);
}

void ext2fs_unmark_inode_bitmap(ext2_filsys fs, char *bitmap, int inode)
{
	if ((inode < 1) || (inode > fs->super->s_inodes_count)) {
		ext2fs_warn_bitmap(fs, ext2fs_unmark_string,
				   ext2fs_inode_string, inode);
		return;
	}
	clear_bit(inode - 1, bitmap);
}

int ext2fs_test_inode_bitmap(ext2_filsys fs, char *bitmap, int inode)
{
	if ((inode < 1) || (inode > fs->super->s_inodes_count)) {
		ext2fs_warn_bitmap(fs, ext2fs_test_string,
				   ext2fs_inode_string, inode);
		return 0;
	}
	return test_bit(inode - 1, bitmap);
}


