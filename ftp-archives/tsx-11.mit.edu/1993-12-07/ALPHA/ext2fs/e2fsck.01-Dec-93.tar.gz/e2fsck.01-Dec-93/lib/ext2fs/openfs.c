/*
 * openfs --- open an ext2 filesystem
 * 
 * Copyright (C) 1993 Theodore Ts'o.  This file may be redistributed
 * under the terms of the GNU Public License.
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <linux/fs.h>
#include <linux/ext2_fs.h>

#include "ext2fs.h"

void ext2fs_free(ext2_filsys fs)
{
	if (!fs)
		return;
	if (fs->io) {
		io_channel_close(fs->io);
	}
	if (fs->device_name)
		free(fs->device_name);
	if (fs->super)
		free(fs->super);
	if (fs->group_desc)
		free(fs->group_desc);
	if (fs->block_map)
		free(fs->block_map);
	if (fs->inode_map)
		free(fs->inode_map);
	free(fs);
}

/*
 *  Note: if superblock is non-zero, block-size must also be non-zero.
 * 	Superblock and block_size can be zero to use the default size.
 */
errcode_t ext2fs_open(char *name, int flags, int superblock, int block_size,
		      io_manager manager, ext2_filsys *ret_fs)
{
	ext2_filsys	fs;
	errcode_t	retval;
	int		i, group_block;
	char		*dest;
	
	fs = (ext2_filsys) malloc(sizeof(struct struct_ext2_filsys));
	if (!fs)
		return ENOMEM;
	
	memset(fs, 0, sizeof(struct struct_ext2_filsys));
	fs->flags = flags;
	retval = manager->open(name, (flags & EXT2_FLAG_RW) ? IO_FLAG_RW : 0,
			       &fs->io);
	if (retval)
		goto cleanup;
	fs->device_name = strdup(name);

	/*
	 * Read in the superblock
	 */
	if (superblock) {
		if (!block_size) {
			retval = EINVAL;
			goto cleanup;
		}
		io_channel_set_blksize(fs->io, block_size);
		fs->super = malloc((block_size < SUPERBLOCK_SIZE) ?
				   SUPERBLOCK_SIZE : block_size);
		if (!fs->super) {
			retval = ENOMEM;
			goto cleanup;
		}
		retval = io_channel_read_blk(fs->io, superblock, 1, fs->super);
		if (retval)
			goto cleanup;
	} else {
		io_channel_set_blksize(fs->io, SUPERBLOCK_SIZE);
		fs->super = malloc(SUPERBLOCK_SIZE);
		if (!fs->super) {
			retval = ENOMEM;
			goto cleanup;
		}
		retval = io_channel_read_blk(fs->io, SUPERBLOCK_NR, 1,
					     fs->super);
		if (retval)
			goto cleanup;
	}
	if (fs->super->s_magic != EXT2_SUPER_MAGIC) {
		retval = EXT2_ET_BAD_MAGIC;
		goto cleanup;
	}
	fs->blocksize = EXT2_BLOCK_SIZE (fs->super);
	fs->inode_blocks_per_group = (fs->super->s_inodes_per_group /
				      EXT2_INODES_PER_BLOCK(fs->super));
	if (block_size) {
		if (block_size != fs->blocksize) {
			retval = EXT2_ET_UNEXPECTED_BLOCK_SIZE;
			goto cleanup;
		}
	}
	/*
	 * Set the blocksize to the filesystem's blocksize.
	 */
	io_channel_set_blksize(fs->io, fs->blocksize);
	
	/*
	 * Read group descriptors
	 */
	fs->group_desc_count = (fs->super->s_blocks_count -
				fs->super->s_first_data_block +
				EXT2_BLOCKS_PER_GROUP(fs->super) - 1)
		/ EXT2_BLOCKS_PER_GROUP(fs->super);
	fs->desc_blocks = (fs->group_desc_count +
			   EXT2_DESC_PER_BLOCK(fs->super) - 1)
		/ EXT2_DESC_PER_BLOCK(fs->super);
	fs->group_desc = malloc(fs->desc_blocks * fs->blocksize);
	if (!fs->group_desc) {
		retval = ENOMEM;
		goto cleanup;
	}
	group_block = 2;
	dest = (char *) fs->group_desc;
	for (i=0 ; i < fs->desc_blocks; i++) {
		retval = io_channel_read_blk(fs->io, group_block, 1, dest);
		if (retval)
			goto cleanup;
		group_block++;
		dest += fs->blocksize;
	}

	*ret_fs = fs;
	return 0;
cleanup:
	ext2fs_free(fs);
	return retval;
}

errcode_t ext2fs_close(ext2_filsys fs)
{
	int		i;
	int		group_block;
	errcode_t	retval;
	char		*group_ptr;
	
	if (!(fs->flags & EXT2_FLAG_DIRTY))
		goto done;

	/*
	 * Write out the superblock
	 */
	fs->super->s_wtime = time(NULL);
	io_channel_set_blksize(fs->io, SUPERBLOCK_SIZE);
	retval = io_channel_write_blk(fs->io, SUPERBLOCK_NR, 1, fs->super);
	if (retval)
		return retval;
	io_channel_set_blksize(fs->io, fs->blocksize);
	
	/*
	 * Write out the group descriptors
	 */
	group_block = 2;
	group_ptr = (char *) fs->group_desc;
	for (i=0; i < fs->desc_blocks; i++) {
		retval = io_channel_write_blk(fs->io, group_block, 1,
					      group_ptr);
		if (retval) {
			return retval;
		}
		group_block++;
		group_ptr += fs->blocksize;
	}
	
done:
	ext2fs_free(fs);
	return 0;
}

/*
 * This routine sanity checks the group descriptors
 */
int ext2fs_check_desc(ext2_filsys fs)
{
	int i;
	int block = fs->super->s_first_data_block;
	int next, inode_blocks_per_group;

	inode_blocks_per_group = fs->super->s_inodes_per_group /
		EXT2_INODES_PER_BLOCK (fs->super);

	for (i = 0; i < fs->group_desc_count; i++) {
		next = block + fs->super->s_blocks_per_group;
		/*
		 * Check to make sure block bitmap for group is
		 * located within the group.
		 */
		if (fs->group_desc[i].bg_block_bitmap < block ||
		    fs->group_desc[i].bg_block_bitmap >= next)
			return EXT2_ET_GDESC_BAD_BLOCK_MAP;
		/*
		 * Check to make sure inode bitmap for group is
		 * located within the group
		 */
		if (fs->group_desc[i].bg_inode_bitmap < block ||
		    fs->group_desc[i].bg_inode_bitmap >= next)
			return EXT2_ET_GDESC_BAD_INODE_MAP;
		/*
		 * Check to make sure inode table for group is located
		 * within the group
		 */
		if (fs->group_desc[i].bg_inode_table < block ||
		    fs->group_desc[i].bg_inode_table+inode_blocks_per_group >=
		    next)
			return EXT2_ET_GDESC_BAD_INODE_TABLE;
		
		block = next;
	}
	return 0;
}

/*
 * NOTE: This routines are duplicated as inline functions in ext2fs.h
 */

/*
 * Mark a filesystem superblock as dirty
 */
void ext2fs_mark_super_dirty(ext2_filsys fs)
{
	fs->flags |= EXT2_FLAG_DIRTY | EXT2_FLAG_CHANGED;
}

/*
 * Mark a filesystem as changed
 */
void ext2fs_mark_changed(ext2_filsys fs)
{
	fs->flags |= EXT2_FLAG_CHANGED;
}

/*
 * Check to see if a filesystem has changed
 */
int ext2fs_test_changed(ext2_filsys fs)
{
	return (fs->flags & EXT2_FLAG_CHANGED);
}

/*
 * Mark a filesystem as valid
 */
void ext2fs_mark_valid(ext2_filsys fs)
{
	fs->flags |= EXT2_FLAG_VALID;
}

/*
 * Mark a filesystem as NOT valid
 */
void ext2fs_unmark_valid(ext2_filsys fs)
{
	fs->flags &= ~EXT2_FLAG_VALID;
}

/*
 * Check to see if a filesystem is valid
 */
int ext2fs_test_valid(ext2_filsys fs)
{
	return (fs->flags & EXT2_FLAG_VALID);
}

/*
 * Mark the inode bitmap as dirty
 */
void ext2fs_mark_ib_dirty(ext2_filsys fs)
{
	fs->flags |= EXT2_FLAG_IB_DIRTY | EXT2_FLAG_CHANGED;
}

/*
 * Mark the block bitmap as dirty
 */
void ext2fs_mark_bb_dirty(ext2_filsys fs)
{
	fs->flags |= EXT2_FLAG_BB_DIRTY | EXT2_FLAG_CHANGED;
}

/*
 * Check to see if a filesystem's inode bitmap is dirty
 */
int ext2fs_test_ib_dirty(ext2_filsys fs)
{
	return (fs->flags & EXT2_FLAG_IB_DIRTY);
}

/*
 * Check to see if a filesystem's block bitmap is dirty
 */
int ext2fs_test_bb_dirty(ext2_filsys fs)
{
	return (fs->flags & EXT2_FLAG_BB_DIRTY);
}
