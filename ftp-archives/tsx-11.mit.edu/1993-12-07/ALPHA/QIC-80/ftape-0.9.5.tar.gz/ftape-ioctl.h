#ifndef _FTAPE_IOCTL_H
#define _FTAPE_IOCTL_H

/*
 * Copyright (C) 1993 Bas Laarhoven.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 *
 $Source: /usr/src/distr/driver/RCS/ftape-ioctl.h,v $
 $Author: bas $
 *
 $Revision: 1.5 $
 $Date: 1993/08/29 15:24:41 $
 $State: Alpha $
 *
 *      This file contains the IOCTL related definitions
 *      for the QIC-40/80 floppy-tape driver for Linux.
 */

#include <linux/ioctl.h>
#include <linux/mtio.h>
#include "ftape-io.h"

#define TAPE_QIC_117_MAJOR 27

#define FT_RESET	        _IO( 'z', 100)
#define FT_REPORT_STATUS	_IOR( 'z', 101, int)
#define FT_REPORT_ERROR_CODE	_IOR( 'z', 102, struct fdt_error)
#define FT_REPORT_CONFIGURATION _IOR( 'z', 103, int)
#define FT_REPORT_ROM_VERSION	_IOR( 'z', 104, int)
#define FT_REPORT_VENDOR_ID	_IOR( 'z', 105, int)
#define FT_SEEK_TO_END		_IO( 'z', 106)
#define FT_SEEK_TO_BEGINNING	_IO( 'z', 107)
#define FT_SEEK_FORWARD	        _IOW( 'z', 108, int)
#define FT_SEEK_REVERSE	        _IOW( 'z', 109, int)
#define FT_STOP_TAPE		_IO( 'z', 110)
#define FT_SUBMIT_ERROR_MAP	_IOW( 'z', 111, struct error_map)
#define FT_READ		        _IOWR( 'z', 112, struct tape_read)
#define FT_WRITE		_IOWR( 'z', 113, struct tape_write)
#define FT_SET_TRACK_LENGTH	_IOW( 'z', 114, int)
#define FT_CEASE_WRITING	_IOR( 'z', 115, struct write_cease)
#define FT_READ_STOP		_IO( 'z', 116)
#define FT_SET_DATA_RATE	_IOW( 'z', 117, int)

/* Temporary operations until this is moved completely into the
   driver. */

#define FT_LOGICAL_FORWARD	_IO( 'z', 200)
#define FT_PAUSE		_IO( 'z', 201)
#define FT_SEEK_TO_TRACK	_IOW( 'z', 202, int)
#define FT_READ_ID		_IOR( 'z', 203, struct _fdt_id)
#define FT_FIND_ME		_IOWR( 'z', 204, struct _fdt_find_me)

#define FT_SET_TRACE_LEVEL      _IOW( 'z', 205, int)

#endif










