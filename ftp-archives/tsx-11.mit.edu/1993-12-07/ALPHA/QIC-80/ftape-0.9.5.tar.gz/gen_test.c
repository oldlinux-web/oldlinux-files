/*
 *      Copyright (C) 1993 Bas Laarhoven.
 *
 $Source: /usr/src/distr/driver/RCS/gen_test.c,v $
 $Author: bas $
 *
 $Revision: 1.4 $
 $Date: 1993/08/29 15:24:41 $
 $State: Alpha $
 *
 *      Generate a file with recognizable data for testing
 *      the QIC-117 ftape driver.
 *
 */

static char RCSid[] = "$Id: gen_test.c,v 1.4 1993/08/29 15:24:41 bas Alpha $";

#include <stdio.h>
#include <time.h>

#define NR_SECTORS (10 * 29)

int main( void)
{
  int i;
  FILE* fv = fopen( "INPUT", "w");
  time_t t;
  char s[ 40];
  int l;

  time( &t);
  strcpy( s, ctime( &t));
  l = strlen( s);

  for (i = 0; i < NR_SECTORS; ++i) {
    fprintf( fv, "Segment %3d, Sector %4d, %s %*c\n", i / 29, i, s, 996 - l, '.');
  }

  fclose( fv);

  return 0;
}
