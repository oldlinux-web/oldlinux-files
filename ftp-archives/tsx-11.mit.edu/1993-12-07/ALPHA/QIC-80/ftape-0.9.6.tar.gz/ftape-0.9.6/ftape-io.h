#ifndef _FTAPE_IO_H
#define _FTAPE_IO_H

/*
 * Copyright (C) 1993 Bas Laarhoven.
 * Some parts:
 * Copyright (C) 1992 David L. Brown, Jr.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

 *
 $Source: /usr/src/distr/driver/RCS/ftape-io.h,v $
 $Author: bas $
 *
 $Revision: 1.7 $
 $Date: 1993/09/07 21:06:38 $
 $State: Alpha $
 *
 *      This file contains definitions for the glue part
 *      of the QIC-40/80 floppy-tape driver for Linux.
 */


struct fdt_error {
  int error;
  int command;
};

struct _fdt_id {
  int cylinder;
  int head;
  int sector;
};

struct _fdt_find_me {
  int segment;
  int first_segment;
  int actual_segment;
  int result;
};

struct error_map {
  int count;
  unsigned long *error_masks;
};

struct tape_read {
  int segment;			/* In:  Segment to read. */
  int count;			/* In:  Hint of number of segments
				   we're going to read. */
  int actual_segment;		/* Out: Error or segment read. */
  char *buffer;			/* In: 32k buffer to place data into. */
  unsigned long error_bits;	/* Out: Bits indicating read error.
				   These bits correspond to the blocks
				   in the segment _after_ the blocks
				   have been packed from the
				   error_mask. */
};

struct tape_write {
  int segment;			/* In:  Segment to read. */
  int actual_segment;		/* Out: Error or segment read. */
  char *buffer;			/* In:  Buffer to write.  Must be
				   32768 bytes long */
  int error_location;		/* Out: What segment was being written
				   when the error occurred? */
};

struct write_cease {
  int actual_segment;		/* Actual segment written (-1 is ok). */
  int error_location;		/* What segment was being written when
				   the error occurred? */
};

/*
 *      ftape-io.c defined global vars.
 */
extern int ftape_failure;
extern int ftape_track;
extern int segments_per_track;
extern int segments_per_head;
extern int segments_per_cylinder;
extern int sectors_per_segment;
extern int tracks_per_tape;
extern int ftape_chr_pos;
extern int ftape_seg_pos;
extern int first_data_segment;
extern int ftape_state;
extern struct _fdt_id location;
extern int location_known;
extern int unknown_drive_config;

/*
 *      ftape-io.c defined global functions.
 */
extern int ftape_command( int command);
extern int ftape_report_drive_status( int *status);
extern int ftape_report_status( int* status);
extern int ftape_interrupt_wait( int time);
extern int _ftape_open( void);
extern int _ftape_close( void);
extern int _ftape_ioctl( unsigned int command, void * arg);
extern int ftape_ready_wait( int timeout, int* status);
extern int ftape_seek_head_to_track( int track);
extern void ftape_sleep( unsigned int time);
extern int ftape_parameter( int command);
extern int ftape_new_cartridge( void);
extern int ftape_abort_operation( void);
extern void ftape_reset_position( void);
extern void udelay( int usecs);
extern int udelay_calibrate( void);

#endif
