/*
 * Use the "hello, world" system call.
 */

main() {
      int rc;
      extern int errno;

      rc = syscall(128);
      printf("syscall returned %d, errno = %d\n", rc, errno);
      return 0;
}
