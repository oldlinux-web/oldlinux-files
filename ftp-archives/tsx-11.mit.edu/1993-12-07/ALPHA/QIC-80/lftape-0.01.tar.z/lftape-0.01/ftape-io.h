/* Floppy tape drive control.
   Copyright (C) 1992 David L. Brown, Jr.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/*
 * fdtape-io.h,v 1.10 1992/10/13 01:44:24 dbrown Exp
 *
 * fdtape-io.h,v
 * Revision 1.10  1992/10/13  01:44:24  dbrown
 * Added FSF copyright.
 *
 * Revision 1.9  1992/10/12  05:12:20  dbrown
 * Added ioctl to set drive data rate.
 *
 * Revision 1.8  1992/10/10  03:19:19  dbrown
 * Added write error handling so that errors and their location can be
 * passed back to the user.
 *
 * Revision 1.7  1992/10/09  05:53:26  dbrown
 * Read is reliable.  Write is flaky and can't handle errors.
 *
 * Revision 1.6  1992/10/09  00:35:56  dbrown
 * Initial writing of full write.  Untested.
 *
 * Revision 1.5  1992/10/08  23:45:10  dbrown
 * Read now does a copyout instead of using mapped buffers.  Before, read
 * didn't have any control of when the user would actually get the data
 * out of the buffer.  If the user delayed, then that data could be
 * overwritten with the read from tape.
 *
 * Revision 1.4  1992/10/08  04:52:23  dbrown
 * First attempt to add streaming read.  Doesn't really work and panics
 * periodically.
 *
 * Revision 1.3  1992/10/04  23:10:04  dbrown
 * Added facilities for performing seek test.
 *
 * Revision 1.2  1992/10/04  21:45:50  dbrown
 * Now supports non-streaming, single sector reads.
 *
 * Revision 1.1  1992/10/03  22:20:19  dbrown
 * Copied originally from old fdtape driver.
 *
 */

#ifndef _FDTAPE_H_
#define _FDTAPE_H_

#ifndef __STDC__
#error Need support for non-ansi C.
#endif

/* Reset the tape drive. */

#define FDT_RESET	_IO ('z', 0)

/* Report drive status.  Returns the status as an integer. */

#define FDT_REPORT_STATUS	_IOR ('z', 1, int)

/* Status bits. */

#define FDT_READY	0x01	/* Drive is ready. */
#define FDT_ERROR	0x02	/* Error detected, must read error
				   code to clear. */
#define FDT_CARTRIDGE_PRESENT \
			0x04	/* Tape is present. */
#define FDT_WRITE_PROTECT 0x08
#define FDT_NEW_CARTRIDGE \
			0x10	/* New cartridge has been inserted.
				   Must read error code to clear. */
#define FDT_REFERENCED	0x20	/* Cartridge appears to have been
				   formatted. */
#define FDT_AT_BOT	0x40	/* At beginning of tape. */
#define FDT_AT_EOT	0x80	/* At end of tape. */

/* Report drive error code.  There is an error code and the associated
   QIC command that caused it. */

struct fdt_error {
  int error;
  int command;
};

#define FDT_REPORT_ERROR_CODE	_IOR ('z', 2, struct fdt_error)

/* Report the drive configuration. */

#define FDT_REPORT_CONFIGURATION _IOR ('z', 3, int)

#define FDT_CONF_RATE_MASK	0x18
#define FDT_CONF_RATE_250	0x00
#define FDT_CONF_RATE_500	0x10
#define FDT_CONF_RATE_1000	0x18
#define FDT_CONF_EXTRA_LENGTH	0x40
#define FDT_CONF_QIC_80		0x80

/* Report the drive ROM version. */

#define FDT_REPORT_ROM_VERSION	_IOR ('z', 4, int)

/* Report the unit vendor ID. */

#define FDT_REPORT_VENDOR_ID	_IOR ('z', 5, int)

/* Various seeks. */

#define FDT_SEEK_TO_END		_IO ('z', 6)
#define FDT_SEEK_TO_BEGINNING	_IO ('z', 7)
#define FDT_SEEK_FORWARD	_IOW ('z', 8, int)
#define FDT_SEEK_REVERSE	_IOW ('z', 9, int)

#define FDT_STOP_TAPE		_IO ('z', 10)

/* Temporary operations until this is moved completely into the
   driver. */

#define FDT_LOGICAL_FORWARD	_IO ('z', 200)
#define FDT_PAUSE		_IO ('z', 201)
#define FDT_SEEK_TO_TRACK	_IOW ('z', 202, int)

struct _fdt_id {
  int cylinder;
  int head;
  int sector;
};

#define FDT_READ_ID		_IOR ('z', 203, struct _fdt_id)

struct _fdt_find_me {
  int segment;
  int first_segment;
  int actual_segment;
  int result;
};

#define FDT_FIND_ME		_IOWR ('z', 204, struct _fdt_find_me)

/* The read and write requests have an error mask.  Each bit starting
   from the lowest bit correspond to each sector in the segment.  Any
   bits that are set in the error mask will not be read from or
   written to the tape.  The data should be packed in around these
   missing sectors.  For example, if sector number 3 (the forth one)
   is bad, the error_mask will be 0x00000008.  There will only be 29K
   of data with sector 4 immediately following sector number 2. */

/* Before any reading and writing can occur, the bad sector table for
   the current track must be given to the driver. */

struct error_map {
  int count;
  unsigned long *error_masks;
};

#define FDT_SUBMIT_ERROR_MAP	_IOW ('z', 11, struct error_map)

/* Read data from the tape.  Reads the specified segment.  Assmes that
   the tape is already positioned properly.  actual_segment returns
   the result code.  -3 indicates a read error.  -2 is end of tape
   reached.  -1 indicates data has been properly read.  Any value >= 0
   indicates that this numbered segment just passed under the tape
   head instead of the desired value.  [Design a better interface
   here.] */

struct tape_read {
  int segment;			/* In:  Segment to read. */
  int count;			/* In:  Hint of number of segments
				   we're going to read. */
  int actual_segment;		/* Out: Error or segment read. */
  char *buffer;			/* In: 32k buffer to place data into. */
  unsigned long error_bits;	/* Out: Bits indicating read error.
				   These bits correspond to the blocks
				   in the segment _after_ the blocks
				   have been packed from the
				   error_mask. */
};

#define FDT_READ		_IOWR ('z', 12, struct tape_read)

/* Write data to the tape.  Writes the specified segment.  Assumes
   that the tape is already positioned properly.  actual_segment
   returns the result code.  -3 indicates a write error.  -2 is end of
   tape.  -1 is proper write.  Any value >= 0 indicates that this
   numbered segment just passed under the tape head instead of the
   desired segment. */

struct tape_write {
  int segment;			/* In:  Segment to read. */
  int actual_segment;		/* Out: Error or segment read. */
  char *buffer;			/* In:  Buffer to write.  Must be
				   32768 bytes long */
  int error_location;		/* Out: What segment was being written
				   when the error occurred? */
};

#define FDT_WRITE		_IOWR ('z', 13, struct tape_write)

/* Inform driver that writes are done and wait for tape to stop
   writing.  The integer is the actual segment as an error result from
   previous writing. */

struct write_cease {
  int actual_segment;		/* Actual segment written (-1 is ok). */
  int error_location;		/* What segment was being written when
				   the error occurred? */
};
#define FDT_CEASE_WRITING	_IOR ('z', 15, struct write_cease)

/* Set the track length in segments. */

#define FDT_SET_TRACK_LENGTH	_IOW ('z', 14, int)

/* Stop reading. */

#define FDT_READ_STOP		_IO ('z', 16)

/* Set data rate. */

#define FDT_RATE_250 250
#define FDT_RATE_500 500
#define FDT_RATE_1000 1000

#define FDT_SET_DATA_RATE	_IOW ('z', 17, int)

#if 0
#define FDT_SLEEP		_IOW ('z', 14, int)
#endif

/* Bits in the QIC status register. */

#define QIC_STATUS_READY	0x01 /* Drive is ready or idle. */
#define QIC_STATUS_ERROR	0x02 /* Error detected. */
#define QIC_STATUS_CARTRIDGE_PRESENT 0x04
#define QIC_STATUS_WRITE_PROTECT 0x08
#define QIC_STATUS_NEW_CARTRIDGE 0x10 /* New cartridge inserted, must
					 read error status to clear. */
#define QIC_STATUS_REFERENCED	0x20 /* Cartridge appears to have been
					formatted. */
#define QIC_STATUS_AT_BOT	0x40 /* Cartridge is at physical
					beginning of tape. */
#define QIC_STATUS_AT_EOT	0x80 /* Cartridge is at physical end
					of tape. */

/* Configuration bits. */
#define QIC_CONFIG_LONG		0x40 /* Extra Length Tape Detected */
#define QIC_CONFIG_80		0x80 /* QIC-80 detected. */

#endif _FDTAPE_H_
