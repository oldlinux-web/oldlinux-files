/* Floppy Tape driver.
   Copyright (C) 1993 Florian  La Roche
   Copyright (C) 1992 David L. Brown, Jr.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* Use slow I/O for the floppy controller. */
#define REALLY_SLOW_IO

/* Number of possible tape drives. Maybe this should change to one only. */
#define NFDTAPE 2

/* Device major number for tape drives. */
#define TAPE_QIC_117_MAJOR 13

#define TBUF 65536/16
#define TBUF_2 32768/16

#include <errno.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/user.h>

#include <linux/sched.h>
#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/timer.h>
#include <linux/fdreg.h>
#include <linux/fd.h>
#include <linux/errno.h>
#include <linux/mtio.h>
#include <linux/string.h>
#include <linux/types.h>
#include <asm/dma.h>
#include <asm/system.h>
#include <asm/io.h>
#include <asm/segment.h>

/* declared in ../../blk_drv/blk.h */
extern void (*do_floppy) (void);

#include "ftape-regs.h"
#include "ftape-io.h"


/************************************************************************/
/* Some utility routines. */

/* Sleep for 'ticks'. */
static void
sleep_ticks (int ticks)
{
  struct wait_queue *dummy = NULL;

  sleep_timeout (&dummy, ticks);
}

/* Make a small delay... */
static void
fdt_sleep (int time)
{
  unsigned delay = 4 * time;

  while (delay--)
    (void volatile) inb (0x80);
}

/************************************************************************/
/* Interrupt routines. */

/* Set to one, when an interrupt occurs. */
static int interrupt_seen = 0;

#ifdef DEBUG
#define RESET_INTERRUPT_SEEN(s) \
	if (interrupt_seen == 1) \
	  printk ("ftape: There was an unexpected interrupt before " s "\n"); \
	interrupt_seen = 0
#else
#define RESET_INTERRUPT_SEEN interrupt_seen = 0
#endif

/* Wakes up 'interrupt_wait', if an interrupt occurs. */
struct wait_queue *wait_intr = NULL;

/* Wait 'time' ticks for an interrupt. Return ETIME if no
   interrupt happened and 0 if there was an interrupt. */
static int
interrupt_wait (int unit, int time)
{
  int result = 0;
  struct wait_queue wait =
  {current, NULL};

  if (interrupt_seen == 0)
    {
      current->state = TASK_INTERRUPTIBLE;
      current->timeout = jiffies + time;
      add_wait_queue (&wait_intr, &wait);
      if (interrupt_seen == 0)
	{
	  schedule ();
	}
      remove_wait_queue (&wait_intr, &wait);
      if (interrupt_seen == 0)
	{
	  result = ETIME;
	  current->timeout = 0;
	}
    }
  interrupt_seen = 0;
  return result;
}

/* Interrupt routine. Sets 'interrut_seen' and wakes up 'wait_interrupt'. */
static void
qic_117_interrupt (void)
{
  do_floppy = qic_117_interrupt;
#ifdef DEBUG
  if (interrupt_seen == 1)
    printk ("ftape: this is a stray interrupt!\n");
#endif
  interrupt_seen = 1;
  wake_up (&wait_intr);

  return;
}

/************************************************************************/
/* Routines for the floppy disk controller (FDC).
   If you like, you can have a look at "linux/kernel/blk_drv/floppy.c". */

/* Save an internal state of the FD controller. */
static int old_vfo;

/* Reset the floppy disk controller.  Leaves the FDTAPE unit selected. */
static void
reset_controller (int unit, int motor)
{
  int data = unit;

  RESET_INTERRUPT_SEEN ("reset_controller");

  /* Assert the reset line.  Leave the proper unit selected. */
  outb_p (data, FD_DOR);
  SLOW_DOWN_IO;			/* Maybe I will delete these slow-downs. */

  /* Now lower the reset line. */
  data |= FDC_RESET;
  outb_p (data, FD_DOR);
  SLOW_DOWN_IO;

  /* Enable dma mode. */
  data |= FDC_DMA_REQUEST;
  if (motor)
    data |= FDC_MOTOR_0 << unit;
  outb_p (data, FD_DOR);
  SLOW_DOWN_IO;

  /* Select clock for fdc.  May need to be changed to select data rate. */
  old_vfo = inb_p (FD_DCR);
  outb_p (0x00, FD_DCR);
  SLOW_DOWN_IO;

  /* Some FDCs will maybe not generate an interrupt. Please tell me,
     if your does so! */
  if (interrupt_wait (unit, HZ * 2))
    printk ("ftape: warning: no interrupt from FDC reset\n");
}

/* When we're done, put the fdc into reset mode so that the regular
   floppy disk driver will figure out that something is wrong and
   initialize the controller the way it wants. */
static void
disable_controller (int unit)
{
  RESET_INTERRUPT_SEEN ("disable_controller");

  outb (old_vfo, FD_DCR);
  outb (unit, FD_DOR);

  if (interrupt_wait (unit, HZ * 2))
    printk ("ftape: warning: no interrupt from FDC disable\n");
}

/* Output one byte to the FDC. */
static int
output_byte (unsigned char byte)
{
  int counter = 10000;
  unsigned char status;

  while (counter--)
    {
      status = inb_p (FD_STATUS) & (STATUS_READY | STATUS_DIR);
      if (status == STATUS_READY)
	{
	  outb_p (byte, FD_DATA);
	  return 0;
	}
    }
  printk ("ftape: unable to send byte to FDC\n");
  return -1;
}

/* Read one byte from the FDC. */
static int
result (unsigned char *byte)
{
  int counter = 10000;
  unsigned char status;

  while (counter--)
    {
      status = inb_p (FD_STATUS) & (STATUS_DIR | STATUS_READY | STATUS_BUSY);
      if (status == STATUS_READY)
	{
	  printk ("ftape: FDC has no more bytes to send\n");
	  return -1;
	}
      if (status == (STATUS_DIR | STATUS_READY | STATUS_BUSY))
	{
	  *byte = inb_p (FD_DATA);
	  return 0;
	}
    }
  printk ("ftape: unable to receive byte from FDC\n");
  return -1;
}

/* Send 'out_count' bytes to the FDC and receive 'in_count' bytes from it. */
static int
issue_command (unsigned char *out_data, int out_count,
	       unsigned char *in_data, int in_count)
{
  int counter = 10000;
  unsigned char status;

  while (out_count--)
    if (output_byte (*out_data++))
      return -1;

  while (in_count--)
    if (result (in_data++))
      return -1;

  while (--counter)
    {
      status = inb_p (FD_STATUS) & (STATUS_DIR | STATUS_READY | STATUS_BUSY);
      if (status == STATUS_READY)
	break;
      if (status == (STATUS_DIR | STATUS_READY | STATUS_BUSY))
	{
	  printk ("ftape: FDC still wants to give you data\n");
	  return -1;
	}
    }
  if (!counter)
    {
      printk ("ftape: FDC timed out\n");
      return -1;
    }

  return 0;
}

/************************************************************************/
/* Specific fdc commands.  Refer to ftape-regs.h for more detail on
   these commands. */

/* Specify timing parameters.  Accepts hut (head unload time), srt
   (seek rate time), hlt (head load time), and (nd) non-dma.  Returns
   0 if no error, -1 on error. */
/* - SRT - step rate time - interval between step pulses encoded as
   16 minus the number of ms (15 = 1ms, 14 = 2ms).
   This command should not generate an interrupt. */
static int
specify (int hut, int srt, int hlt, int nd)
{
  unsigned char cmd[3];

  cmd[0] = FD_SPECIFY;
  cmd[1] = (srt << 4) | hut;
  cmd[2] = (hlt << 1) | nd;

  return issue_command (cmd, 3, NULL, 0);
}

/* Sense drive status. Return the drive status ST3 from a given unit.
   This command should not generate an interrupt. */
static int
sense_drive_status (int unit, int *st3)
{
  unsigned char out[2], in[1];

  out[0] = FD_SENSE;
  out[1] = unit;
  if (issue_command (out, 2, in, 1))
    return -1;

  *st3 = in[0];
  return 0;
}

/* Return the interrupt status.  Returns 0 for success.
   This command generates an interrupt. */
static int
sense_interrupt_status (int *st0, int *pcn)
{
  unsigned char out[1];
  unsigned char in[2];

  out[0] = FD_SENSEI;
  if (issue_command (out, 1, in, 2))
    return -1;

  *st0 = in[0];
  *pcn = in[1];

  return 0;
}

/* Recalibrate and wait until recalibration completed.
  (Returns 0 for success.) */
static int
recalibrate (int unit)
{
  unsigned char out[2];
  int st0, pcn, i;

  /* Set other timing for recalibration. */
  if (specify (13, 10, 1, 0))
    return -1;

  RESET_INTERRUPT_SEEN ("recalibrate");
  out[0] = FD_RECALIBRATE;
  out[1] = unit;
  if (issue_command (out, 2, NULL, 0))
    return -1;

  for (i = 40; --i;)
    {
      if (interrupt_wait (unit, RECALIBRATE_TIMEOUT))
	{
	  printk ("ftape: recalibrate timeout\n");
	  return ETIME;
	}
      if (sense_interrupt_status (&st0, &pcn))
	return -1;
      if (st0 & ST0_SEEK_END)
	break;
    }
  if (!i)
    printk ("ftape: ST0_SEEK_END not set in recalibrate\n");

#ifdef DEBUG_VERBOSE
  printk ("ftape: recalibrate: st0 = 0x%2x and pcn = %d\n", st0, pcn);
#endif

  /* unit_data[unit].pcn = pcn; ??? */

  /* Reset to normal timing. */
  if (specify (13, 15, 1, 0))
    return -1;

  return 0;
}

/* Begin a read. */
static int
read_id (int unit, struct _fdt_id *location)
{
  unsigned char out[2];
  unsigned char in[7];

  RESET_INTERRUPT_SEEN ("read_id");
  out[0] = FD_READ_TAPE;
  out[1] = unit;
  if (issue_command (out, 2, NULL, 0))
    return -1;

  if (interrupt_wait (unit, READ_TIMEOUT))
    {
      printk ("ftape: read_id timeout\n");
      return ETIME;
    }

  if (issue_command (NULL, 0, in, 7))
    return -1;

#ifdef DEBUG_VERBOSE
  printk ("ftape: read_id: st0=0x%02x, st1=0x%02x, st2=0x%02x, cyl=0x%02x, hd=0x%02x, sec=0x%02x, size=0x%02x\n",
	  in[0], in[1], in[2], in[3], in[4], in[5], in[6]);
#endif

  /* Check return for normal. */
  if ((in[0] & ST0_CODE_MASK) == ST0_NORMAL)
    {
      location->cylinder = in[3];
      location->head = in[4];
      location->sector = in[5];
    }
  else
    {
      printk ("ftape: read_id error st0=0x%02x, st1=0x%02x, st2=0x%02x\n",
	      in[0], in[1], in[2]);
      return -1;
    }

  return 0;
}

/************************************************************************/
/* Two utility routines to send QIC commands. */

/* Although there may be multiple units, the unit number is only to
   select which drive unit the drive is attached to.  Although two
   tape drives could be conceivably be connected, this driver will not
   support their simultaneous use. */
static int tape_unit = 0;

/* Device (unit) structure. */
struct fdtape_unit_data
  {
    int pcn;			/* Present cylinder number. */
    int drive_type;		/* What kind of drive was detected. */
    int track;			/* Last track we think the drive is on. */
  };

static struct fdtape_unit_data unit_data[NFDTAPE];

/* Issue a tape command.  Seeks command tracks from the current track. */
static int
tape_command (int unit, int command)
{
  unsigned char out[3];
  int st0, pcn;
  int destination;
  int count;

  sleep_ticks (HZ / 10);

  /* Figure out where to seek to.  Seek toward zero if possible to
     keep these as small integers. */
  if (unit_data[unit].pcn >= command)
    unit_data[unit].pcn -= command;
  else
    unit_data[unit].pcn += command;
  destination = unit_data[unit].pcn;

  RESET_INTERRUPT_SEEN ("fd_seek");
  out[0] = FD_SEEK;
  out[1] = unit;
  out[2] = destination;
  if (issue_command (out, 3, NULL, 0))
    {
      int real_old_vfo = old_vfo;
      /* Try hitting the fdc over the head. */
      reset_controller (tape_unit, 0);
      specify (13, 15, 1, 0);	/* ignore result */
      printk ("ftape: seek command error FDC reset didn't even work\n");
      old_vfo = real_old_vfo;
      return -1;
    }

  for (count = SEEK_RESULT_RETRIES; --count;)
    {
      if (interrupt_wait (unit, SEEK_TIMEOUT))
	{
	  printk ("ftape: tape_command timeout\n");
	  return ETIME;
	}
      if (sense_interrupt_status (&st0, &pcn))
	return -1;
      if (st0 & ST0_SEEK_END)
	break;
    }
  if (!count)
    {
      printk ("ftape: tape_command: ST0_SEEK_END was not set\n");
      return -1;
    }

  /* Verify that we seek to the proper track. */
  if (pcn != destination)
    {
      unit_data[unit].pcn = pcn;
      printk ("ftape: tape_command: seek to incorrect track\n");
      return -1;
    }

  return 0;
}

/* Query the drive about its status.  The command is sent and
   result_length bits of status are returned (2 extra bits are read
   for start and stop). */
static int
report_status_operation (int unit, int *status, int command, int result_length)
{
  int i, st3;
  int result;
  int count = 0;

  /* Are these necessary ?? */
  tape_command (unit, QIC_REPORT_NEXT_BIT);
  tape_command (unit, QIC_REPORT_NEXT_BIT);
  tape_command (unit, QIC_REPORT_NEXT_BIT);
  tape_command (unit, QIC_REPORT_NEXT_BIT);

  result = tape_command (unit, command);
  if (result)
    {
      printk ("ftape: report_drive_status: tape_command timeout\n");
      return result;
    }

  fdt_sleep (10);

  st3 = 0;
  while ((st3 & ST3_TRACK_0) == 0)
    {
      if (sense_drive_status (unit, &st3))
	return -1;
      if (count++ == 1000)
	return -1;
    }

  *status = 0;
  for (i = 0; i < result_length + 1; i++)
    {
      result = tape_command (unit, QIC_REPORT_NEXT_BIT);
      if (result)
	{
	  printk ("ftape: report_drive_status: report next bit timeout\n");
	  return result;
	}

      fdt_sleep (10);

      if (sense_drive_status (unit, &st3))
	return -1;

      *status >>= 1;
      if (i < result_length)
	*status |= ((st3 & ST3_TRACK_0) != 0) << result_length;
      else if (!(st3 & ST3_TRACK_0))
	{
	  printk ("ftape: report_status, stop bit not present\n");
	  return -1;
	}
    }
  tape_command (unit, QIC_REPORT_NEXT_BIT);

  return 0;
}

/************************************************************************/
/* QIC commands. */

static int
report_error (int unit, int *error)
{
  return report_status_operation (unit, error, QIC_REPORT_ERROR_CODE, 16);
}

static int
report_configuration (int unit, int *configuration)
{
  return report_status_operation (unit, configuration,
				  QIC_REPORT_DRIVE_CONFIGURATION, 8);
}

static int
report_rom_version (int unit, int *version)
{
  return report_status_operation (unit, version, QIC_REPORT_ROM_VERSION, 8);
}

static int
report_vendor_id (int unit, int *id)
{
  return report_status_operation (unit, id, QIC_REPORT_VENDOR_ID, 16);
}

/************************************************************************/
/* Status and error handling. */

/* List of error codes, and their fatalness. */
struct _fdtape_error
{
  char *message;		/* Text describing the error. */
  int fatal;			/* Non-zero if the error is fatal. */
};

/* These error messages were taken from the Quarter-Inch Cartridge
   Drive Standards, Inc. document titled ``Common Command Set
   Interface Specification for Flexible Disk Controller Based
   Minicartridge Tape Drives,'' document QIC-117 Revision B, 6 Dec 89.
   For more information, contact,
      Quarter-Inch Cartridge Drive Standards, Inc.
      311 East Carrillo Street
      Santa Barbara, California 93101
      Telephone (805) 963-3853
      Fax       (805) 962-1541 */

static struct _fdtape_error fdtape_errors[] =
{
  {"No error", 0,},
  {"Command Received while Drive Not Ready", 0,},
  {"Cartridge Not Present or Removed", 1,},
  {"Motor Speed Error", 1,},
  {"Motor Speed fault", 1,},
  {"Cartridge Write Protected", 1,},
  {"Undefined or Reserved Command Code", 1,},
  {"Illegal Track address specified for Seek", 1,},
  {"Illegal Command in Report Subcontext", 0,},
  {"Illegal Entry into a Diagnostic Mode", 1,},
  {"Broken Tape Detected", 1,},
  {"Warning--Read Gain Setting Error", 1,},
  {"Command Received while Error Status Pending", 1,},
  {"Command Received while New Cartridge Pending", 1,},
  {"Command Illegal or Undefined in Primary Mode", 1,},
  {"Command Illegal or Undefined in Format Mode", 1,},
  {"Command Illegal or Undefined in Verify Mode", 1,},
  {"Logical Forward not a Logical BOT in Format Mode", 1,},
  {"Logical EOT before all Segments generated", 1,},
  {"Command Illegal when Cartridge Not Referenced", 1,},
  {"Self-Diagnostic Failed", 1,},
  {"Warning EEPROM Not Initialized, defaults set", 1,},
  {"EEPROM Corrupted or Hardware Failure", 1,},
  {"Motion Time-out error", 1,},
  {"Datat Segment Too Long--Logical Forward or Pause", 1,},
  {"Transmit Overrun", 1,},
  {"Power On Reset Occurred", 0,},
  {"Software Reset Occurred", 0,},
  {"Diagnostic Mode 1 Error", 1,},
  {"Diagnostic Mode 2 Error", 1,},
  {"Command Received During Non-Interruptable Process", 1,},
  {"Rate Selection error", 1,},
  {"Illegal command while in high speed mode", 1,},
  {"Illegal seek segment value", 1,}
};
#define MAXIMUM_ERROR 33

/* Report the current drive status. */
static int
report_drive_status (int unit, int *status)
{
  int result, count, command, error;

  for (count = 4; count--;)
    {
      result = report_status_operation (unit, status,
					QIC_REPORT_DRIVE_STATUS, 8);
      if (result == 0)
	break;
    }

  /* If there is an error pending and new cartridge present. */
  if ((*status & QIC_STATUS_READY) != 0
      && (*status & QIC_STATUS_ERROR) != 0
      && (*status & QIC_STATUS_NEW_CARTRIDGE) == 0)
    {
      result = report_error (unit, &error);
      if (result)
	return result;

      command = error >> 8;
      error &= 0xff;
      if (error < 0 || error > MAXIMUM_ERROR)
	printk ("ftape: tape error out of range (%d)\n", error);
      else
	{
	  printk ("ftape: error %d(%d): \"%s\"\n",
		  error, command, fdtape_errors[error].message);
	  if (fdtape_errors[error].fatal)
	    return EIO;
	}

      /* Get the new drive status. */
      return report_status_operation (unit, status,
				      QIC_REPORT_DRIVE_STATUS, 8);
    }

  return result;
}

/************************************************************************/
/* More top level QIC commands. */

/* Wait for the drive to be ready. */
static int
_wait_for_ready (void)
{
  int count = 200;		/* 20 seconds. */
  int result, status;

  result = report_drive_status (tape_unit, &status);
  if (result)
    return EIO;

  while (count > 0 && (status & QIC_STATUS_READY) == 0)
    {
      sleep_ticks (HZ / 10);
      result = report_drive_status (tape_unit, &status);
      if (result)
	return EIO;
    }

  return 0;
}

/* Perform the specified tape operation and wait up to time_limit
   seconds for the operation to complete.  The resultant status will
   be placed into *status.  Returns 0 for success, or EIO for
   an error. */
static int
operate_and_wait (int command, int time_limit, int *status)
{
  int count;
  int result;

  /* Assume the user process will wait for drive ready.  Should
     actually do that here. */
  tape_command (tape_unit, command);

  /* Now poll the drive every 1/4 second and wait for the drive to
     become ready. */
  result = report_drive_status (tape_unit, status);
  if (result)
    return EIO;

  count = time_limit * 4;	/* Wait up to 85 seconds for operation. */
  while (count-- && (*status & QIC_STATUS_READY) == 0)
    {
      sleep_ticks (HZ / 4);
      result = report_drive_status (tape_unit, status);
      if (result)
	return EIO;
    }

  result = report_drive_status (tape_unit, status);
  if (result)
    return EIO;

  return 0;
}

/* Seek to the end of the tape, and wait. */
static int
_seek_to_end_thread (void)
{
  int result, status;

  result = _wait_for_ready ();
  if (result)
    return result;

  result = operate_and_wait (QIC_PHYSICAL_FORWARD, 185, &status);
  if (result)
    return result;

  /* Now make sure the drive thinks we're at the end of the tape. */
  return ((status & QIC_STATUS_AT_EOT) == 0) ? EIO : 0;
}

/* Seek to the beginning of the tape. */
static int
_seek_to_beginning_thread (void)
{
  int result, status;

  result = _wait_for_ready ();
  if (result)
    return result;

  result = operate_and_wait (QIC_PHYSICAL_REVERSE, 185, &status);
  if (result)
    return result;

  /* Now make sure the drive thinks we're at the start of the tape. */
  return ((status & QIC_STATUS_AT_BOT) == 0) ? EIO : 0;
}

/* Perform the specified seek.  The absolute value of the argument is
   one more than the number of segments to issue to the qic command.
   If the argument is negative, the seek is done in the reverse
   logical direction, otherwise it is done in the forward logical
   direction. */
static int
_seek_thread (int *amount)
{
  int dir, count;
  int status;
  int result = 0;

  count = *amount;

  if (count > 0)
    {
      dir = QIC_SKIP_FORWARD;
      count--;
    }
  else
    {
      dir = QIC_SKIP_REVERSE;
      count = -1 - count;
    }

  result = _wait_for_ready ();
  if (result)
    return result;

  /* Issue this tape command first. */
  result = tape_command (tape_unit, dir);
  if (result)
    return result;

  /* Issue the low nibble of the command. */
  result = tape_command (tape_unit, (count & 0x0f) + 2);
  if (result)
    return result;

  /* Issue the high nibble and wait for the command to complete. */
  return operate_and_wait (((count & 0xf0) >> 4) + 2, 85, &status);
}

/* Seek the head to the specified track. */
static int
_seek_to_track_thread (int *track)
{
  int count;
  int status;
  int result;

  count = *track;
  unit_data[tape_unit].track = *track;

  if (count < 0 || count > 27)
    return EINVAL;

  result = _wait_for_ready ();
  if (result)
    return result;

  /* Issue this tape command first. */
  result = tape_command (tape_unit, QIC_SEEK_HEAD_TO_TRACK);
  if (result)
    return result;

  /* Issue the track and wait for the command to complete. */
  return operate_and_wait (count + 2, 85, &status);
}

/* Set data rate. */
static int
_set_data_rate_thread (int *rate)
{
  int vfo;
  int qic_rate;
  int result;
  int status;

  switch (*rate)
    {
    case FDT_RATE_250:
      vfo = 0x02;
      qic_rate = 0;
      break;
    case FDT_RATE_500:
      vfo = 0x00;
      qic_rate = 2;
      break;
    case FDT_RATE_1000:
      vfo = 0x03;
      qic_rate = 3;
      break;
    default:
      return EINVAL;
    }

  result = _wait_for_ready ();
  if (result)
    return result;

  result = tape_command (tape_unit, QIC_SELECT_RATE);
  if (result)
    return result;

  result = operate_and_wait (qic_rate + 2, 1, &status);
  if (result)
    return result;

  outb (vfo, FD_DCR);

  return 0;
}

/************************************************************************/

static struct wait_queue *th_wait_queue = NULL;

static char *tape_buffer = NULL;

/* Tape length of current tape.  Just tackily set here by the user
   program to allow shorter length tapes to be used. */
static int segments_per_track = 150;
static long error_results[2];	/* Error results from reads. */
static int buffered_segment[2];	/* Segment that is in the numbered
				   buffer.  -1 indicates that the
				   buffer has nothing. */
static int segment_being_read;	/* What segment is being read in. */
static int segment_count;	/* How many more do we expect to read. */
static int read_into;		/* Which buffer to read into. */
static int last_actual_segments[2];
#define CURRENT_BUFFER read_into
#define PREVIOUS_BUFFER (read_into ^ 1)
#define INCREMENT_BUFFER (read_into ^= 1)

/* Reading from tape. */

/* Current error map. */
static unsigned long error_masks[150];

/* Start the tape moving and wait for the segment before the given
   segment to pass by.  Returns 0 if the tape is spinning and ready to
   read the proper segment.  If an error is returned, actual_segment
   will be set to the segment that just passed by, or a value < 0 if
   the location cannot be determined (such as end of a track). */

static int
_start_tape (int segment, int *actual_segment,
	     int *first_segment	/* Temporary! */
)
{
  int retries = 10 * 32;	/* Read up to 10 segments ahead. */
  int result;
  int trash;

  if (first_segment == NULL)
    first_segment = &trash;

  *first_segment = -1;

  /* Wait for the drive to be ready. */
  result = _wait_for_ready ();
  if (result)
    return result;

  if (tape_command (tape_unit, QIC_LOGICAL_FORWARD))
    return EIO;

  /* Wait for ID of previous segment to go by unless we are at the
     beginning of the tape. */
  if ((segment % segments_per_track) != 0)
    {
      struct _fdt_id location;
      do
	{
	  result = read_id (tape_unit, &location);
	  if (result)
	    {
	      *actual_segment = -2;
	      sleep_ticks (HZ / 5);	/* A read id error usually means the
				    tape has run off of the end, wait
				    here to avoid trouble. */
	      _wait_for_ready ();	/* Even wait for it to become ready.
				     This even causes a lot of problems
				     if the drive isn't given a chance
				     to calm down. */
	      return EIO;
	    }
	  *actual_segment = (600 * location.head
			     + 4 * location.cylinder
			     + (location.sector - 1) / 32);
	  if (*first_segment < 0)
	    *first_segment = *actual_segment;
	  if (*actual_segment >= segment ||
	      segment - *actual_segment > 9)
	    return EIO;
	}
      while (*actual_segment != segment - 1
	     && retries-- > 0);
    }
  if (retries <= 0)
    return EIO;

  return 0;
}

/* Read one segment.  The tape is assumed to be spinning and the
   proper segment should pass next under the head.  The bits in
   error_mask that are set will not have their sectors read.
   actual_segment will be set as per _start_tape, with -1 being a
   successful read, and -3 being a real read error. */
static int
_read_segment (int segment,
	       unsigned long error_mask,
	       char *buffer,
	       int *actual_segment,
	       unsigned long *error_bits)
{
  unsigned char out[9], in[7];
  unsigned long error_runner;
  long address;
  int result;
  int head, cylinder, sector;
  int offset, remaining;
  int data_offset;
  int count;

  *error_bits = 0;

  /* Clear out actual segment. */
  *actual_segment = -1;

  head = segment / 600;
  cylinder = (segment % 600) / 4;
  sector = (segment % 4) * 32 + 1;

  offset = 0;
  data_offset = 0;
  remaining = 32;
  error_runner = error_mask;
  while (remaining > 0)
    {
      if (error_runner & 1)
	{
	  error_runner >>= 1;
	  offset++;
	  remaining--;
	  continue;
	}
#if 0
      for (count = 0; (count < remaining
		       && (error_runner & 1) == 0); count++)
	error_runner >>= 1;
#else
      count = 1;
      error_runner >>= 1;
#endif

      /* Program the DMA controller to read. */
      address = (long) (buffer + data_offset * 1024);
      outb (0, DMA_COMMAND);
      outb (6, DMA_MASK_BIT);
      outb (DMA_MODE_READ, DMA_CLEAR_FLIP_FLOP);
      outb (DMA_MODE_READ, DMA_MODE);
      outb (address, DMA_ADDRESS);
      outb (address >> 8, DMA_ADDRESS);
      outb (address >> 16, DMA_PAGE);
      outb (1024 * count - 1, DMA_COUNT);
      outb ((1024 * count - 1) >> 8, DMA_COUNT);
      outb (2, DMA_MASK_BIT);

      /* Issue FDC command to start reading. */
      out[0] = FD_READ_TAPE;
      out[1] = tape_unit;
      out[2] = cylinder;
      out[3] = head;
      out[4] = sector + offset;
      out[5] = 3;		/* Sector size of 1K. */
      out[6] = sector + offset + count - 1;
      out[7] = 116;		/* Gap length.  From the suggested
				   value for 1K MFM sectors 500K data
				   rate.  The value 116 I made up myself. */
      out[8] = 0xff;		/* No limit to transfer size. */
      RESET_INTERRUPT_SEEN ("read_segment");
      result = issue_command (out, 9, NULL, 0);
      if (result)
	{
	  printk ("ftape: read issue error\n");
	  return EIO;
	}

      result = interrupt_wait (tape_unit, READ_TIMEOUT);
      if (result)
	{
	  printk ("ftape: read timeout\n");
	  return EIO;
	}

      result = issue_command (NULL, 0, in, 7);
      /* st0 st1 st2 cyl head secto sec_size */
      if (result)
	{
	  printk ("ftape: read result error\n");
	  return result;
	}

      if ((in[0] & ST0_CODE_MASK) != ST0_NORMAL)
	{
	  /* Figure out the type of error. */
	  if (in[1] & ST1_DATA_ERROR)
	    {
	      /* Rewind the tape. */
	      tape_command (tape_unit, QIC_PAUSE);
	      printk ("ftape: crc error in sector %d or segment %d (%d)\n",
		      (in[5] - 1) % 32 + 1, segment, in[5]);

	      /* Make sure the floppy disk controller is sane and
		 reporting a sector of a reasonable range. */
	      if (in[5] < sector + offset || in[5] >= sector + offset + count)
		{
		  printk ("ftape: crc error in unrelated data\n");
		  return EIO;
		}

	      /* Run backward into the error. */
	      while (sector + offset + count - 1 > in[5])
		count--;

	      /* Set the error bit. */
	      *error_bits |= 1 << (offset + count - 1);

	      /* Restart the tape. */
	      result = _start_tape (segment, actual_segment, 0);
	      if (result == 0)
		*actual_segment = -1;
	      /* else
		return_value = result; */

	      printk ("ftape: start=%d,count=%d,bits=0x%02x, do=%d\n",
		      sector + offset, count, *error_bits, data_offset);
	    }
	  else
	    {
	      printk ("ftape: error st0 = 0x%02x, st1 = 0x%02x, st2 = 0x%02x\n",
		      in[0], in[1], in[2]);
	      printk ("ftape: read_segment, error cyl=%d, head=%d, sec=%d, ss=%d\n",
		      in[3], in[4], in[5], in[6]);
	      *actual_segment = -3;	/* Some kind of read error. */
	      return EIO;
	    }
	}

      offset += count;
      data_offset += count;
      remaining -= count;
    }

  return 0;
}


/* Buffering and reading the data. */

/* The read routines exist in one of these states:

   XXX This isn't correct.

     Name               Buffers                 User process.
			Thread
   ------------------------------------------------------------
   - idle               empty                   Nothing
			Not running
   - request            cur:read                Waiting
			Reading->cur
   - read_next          cur:read, prev:used     Nothing
			Reading->cur
   - got                cur:read, prev:data     Waiting
			Reading->cur.
   - idle_buffer        cur:data prev:data      Nothing
			Not running.
   - idle_one_buffer    prev:data, cur:empty    Nothing
			Not running

   State transition conditions:

   idle: if user request -> request
   request: if finish read then
	       if more to read -> read_next
	       else -> idle_one_buffer
   read_next: if user gets buffer -> got
	      if finish read -> idle_buffer
   got: if finish read then
	   if more to read -> read_next
	   else -> idle
   idle_buffer: if user gets buffer then
		   if more to read -> request
		   else -> idle_one_buffer
   idle_one_buffer: if user gets buffer -> idle
*/

enum read_states
{
  READ_IDLE, READ_REQUEST, READ_NEXT, READ_GOT, READ_BUFFER,
  READ_WAIT, READ_STOPPING, READ_STOPPING_WAIT
};

static int read_state = READ_IDLE;

static char *read_state_names[] =
{
  "Idle", "Request", "Next", "Got", "Buffer", "Wait",
  "Stopping", "Stopping Wait"
};

/* Transitions within thread.  These are indexed by
   2*read_state + (count>0). */

struct read_thread_transitions
  {
    enum read_states next;	/* Next state. */
    int wake;			/* Wake up the user process. */
    int done;			/* Done reading? */
  };

static struct read_thread_transitions _read_thread_transitions[8 * 2] =
{
 /* i0 */
  {-1, -1, -1},
  {-1, -1, -1},
 /* q0 */
  {READ_IDLE, 1, 1},
  {READ_NEXT, 1, 0},
 /* n0 */
  {READ_BUFFER, 1, 1},
  {READ_WAIT, 0, 1},
 /* g0 */
  {READ_IDLE, 1, 1},
  {READ_NEXT, 1, 0},
 /* b0 */
  {-1, -1, -1},
  {-1, -1, -1},
 /* w0 */
  {-1, -1, -1},
  {-1, -1, -1},
 /* s0 */
  {-1, -1, -1},
  {-1, -1, -1},
 /* S0 */
  {-1, -1, -1},
  {-1, -1, -1}
};

static int
_read_thread (void *nothing)
{
  int old_state;
  int result = 0;
  int done = 0;
  int wake_them = 0;
  int index;

#if 0
  printk ("_read_thread starts, state = %s (%d)\n",
	  read_state_names[read_state], segment_count);
#endif

  result = _start_tape (segment_being_read,
			&last_actual_segments[CURRENT_BUFFER], 0);
  if (result)
    {
      read_state = READ_IDLE;
      INCREMENT_BUFFER;
      segment_count = 0;
    }
  else
    {
      while (!done)
	{
	  result = _read_segment (segment_being_read,
		       error_masks[segment_being_read % segments_per_track],
				  tape_buffer + TBUF_2 * CURRENT_BUFFER,
				  &last_actual_segments[CURRENT_BUFFER],
				  &error_results[CURRENT_BUFFER]);
	  INCREMENT_BUFFER;
	  segment_being_read++;
	  segment_count--;
	  old_state = read_state;
	  if (result)
	    {
	      read_state = READ_IDLE;
	      segment_count = 0;
	      done = 1;
	    }
	  else
	    {
	      index = 2 * old_state + (segment_count > 0);
	      if (_read_thread_transitions[index].next == -1)
		{
		  printk ("ftape error: invalid read thread state %d\n",
			  index);
		  read_state = READ_IDLE;
		  return 0;
		}
	      read_state = _read_thread_transitions[index].next;
	      wake_them = _read_thread_transitions[index].wake;
	      done = _read_thread_transitions[index].done;
	    }
	  if (!done && wake_them)
#if 0
	    printk ("_read_thread wakes, not done, state = %s (%d)\n",
		    read_state_names[read_state], segment_count),
#endif
	      wake_up (&th_wait_queue);	/* Process needs to be awoken. */
	}
    }

  old_state = read_state;
  read_state = READ_STOPPING;
  /* Stop tape appropriately */
  /* Can't wait for ready, because if the tape is moving, the drive
     won't be ready.  The stop seems to fail if we're at the beginning
     of the tape. */
  /*_wait_for_ready ();*/
  if (old_state == READ_IDLE)
    tape_command (tape_unit, QIC_STOP_TAPE);
  else
    tape_command (tape_unit, QIC_PAUSE);

  read_state = old_state;

#if 0
  printk ("_read_thread finishes, state = %s (%d)\n",
	  read_state_names[read_state], segment_count);
#endif

  return 0;
}

struct read_transitions
{
  enum read_states next;	/* Next state. */
  int start;			/* Start thread? */
  int block;			/* Block for thread? */
};

/* These are indexed by read_state. */

struct read_transitions read_transitions[8] =
{
 /* i */
  {READ_REQUEST, 1, 1},
 /* q */
  {-1, -1, -1},
 /* n */
  {READ_GOT, 0, 1},
 /* g */
  {-1, -1, -1},
 /* b */
  {READ_IDLE, 0, 0},
 /* w */
  {READ_NEXT, 1, 0},
 /* s */
  {-1, -1, -1},
 /* S */
  {-1, -1, -1}
};

static int
_do_read (struct tape_read *tr)
  {
    int old_state;
    int result = 0;
    int dont_really_wait = 0;

    printk ("Read is in state %s\n", read_state_names[read_state]);

    if (read_state == READ_STOPPING)
      {
	read_state = READ_STOPPING_WAIT;	/* ??????? */
	sleep_on (&th_wait_queue);
	dont_really_wait = 1;
      }

    old_state = read_state;
    if (read_transitions[old_state].next == -1)
      {
	printk ("ftape error: Read in invalid state %s\n",
		read_state_names[read_state]);
	return result;
      }
    else
      {
	if (old_state == READ_IDLE)
	  {
	    segment_being_read = tr->segment;
	    segment_count = tr->count;
	  }
	read_state = read_transitions[old_state].next;
	switch (read_transitions[old_state].start * 2
		+ read_transitions[old_state].block)
	  {
	  case 0:
	    break;
	  case 1:
	    if (!dont_really_wait)
	      sleep_on (&th_wait_queue);
	    break;
	  case 2:
	    _read_thread (0);
	    break;
	  case 3:
	    _read_thread (0);
	    break;
	  default:
	  }
	tr->actual_segment = last_actual_segments[PREVIOUS_BUFFER];
	memcpy (&tape_buffer[PREVIOUS_BUFFER * TBUF_2],
		&(tr->buffer),
		TBUF_2);
	tr->error_bits = error_results[PREVIOUS_BUFFER];
      }

    printk ("Read finished in state %s\n", read_state_names[read_state]);

    return result;
  }

struct read_stop_trans
{
  int count;			/* What to set segment count to. */
  int block;			/* Should we block? */
};

struct read_stop_trans _read_stop_trans[9] =
{				/* 8 or 9 ??? */
 /* i */
  {0, 0},
 /* q */
  {1, 1},
 /* n */
  {1, 1},
 /* g */
  {0, 0},
 /* b */
  {0, 0},
 /* w */
  {0, 0},
 /* s */
  {0, 0},
 /* S */
  {0, 0}
};

static int
_do_read_stop (void)
{
  if (read_state == READ_STOPPING)
    {
      read_state = READ_STOPPING_WAIT;	/* ???? */
      sleep_on (&th_wait_queue);
    }
  else
    {
      segment_count = _read_stop_trans[read_state].count;
      if (_read_stop_trans[read_state].block)
	sleep_on (&th_wait_queue);
    }

  read_state = READ_IDLE;

  return 0;
}

static int
_read_id_thread (struct _fdt_find_me *fm)
{
  fm->result = _start_tape (fm->segment, &fm->actual_segment,
			    &fm->first_segment);
  tape_command (tape_unit, QIC_STOP_TAPE);
  tape_command (tape_unit, QIC_STOP_TAPE);

  return 0;
}

/* Writing to tape. */

static int write_actual_segment = -1;
static int write_error_location = -1;

/* Write one segment.  The tape is assumed to be spinning and the
   proper segment should pass next under the head. */
static int
_write_segment (int segment, unsigned long error_mask, char *buffer)
{
  unsigned char out[9], in[7];
  unsigned long error_runner;
  long address;
  int result;
  int head, cylinder, sector;
  int offset, remaining;
  int data_offset;
  int count;

  /* Clear out actual segment. */
  write_actual_segment = -1;

  head = segment / 600;
  cylinder = (segment % 600) / 4;
  sector = (segment % 4) * 32 + 1;

  offset = 0;
  data_offset = 0;
  remaining = 32;
  error_runner = error_mask;
  while (remaining > 0)
    {
      if (error_runner & 1)
	{
	  error_runner >>= 1;
	  offset++;
	  remaining--;
	  continue;
	}
#if 0
      /* This is for larger chunks. */
      for (count = 0; (count < remaining
		       && (error_runner & 1) == 0); count++)
	error_runner >>= 1;
#else
      count = 1;
      error_runner >>= 1;
#endif

      /* Program the DMA controller to write. */
      address = (long) (buffer + data_offset * 1024);
      outb (0, DMA_COMMAND);
      outb (6, DMA_MASK_BIT);
      outb (DMA_MODE_WRITE, DMA_CLEAR_FLIP_FLOP);
      outb (DMA_MODE_WRITE, DMA_MODE);
      outb (address, DMA_ADDRESS);
      outb (address >> 8, DMA_ADDRESS);
      outb (address >> 16, DMA_PAGE);
      outb (1024 * count - 1, DMA_COUNT);
      outb ((1024 * count - 1) >> 8, DMA_COUNT);
      outb (2, DMA_MASK_BIT);

      /* Issue FDC command to start reading. */
      out[0] = FD_WRITE_TAPE;
      out[1] = tape_unit;
      out[2] = cylinder;
      out[3] = head;
      out[4] = sector + offset;
      out[5] = 3;		/* Sector size of 1K. */
      out[6] = sector + offset + count - 1;
      out[7] = 1;		/* Gap length.  From the suggested
				   value for 1K MFM sectors 500K data
				   rate.  The value 116 I made up myself.
				   I don't know what this is for.
				   Since write has more problems than
				   read, I'll set it to 1 and see if
				   that helps.  Does this affect the
				   data written? */
      out[8] = 0xff;		/* No limit to transfer size. */
      result = issue_command (out, 9, NULL, 0);
      if (result)
	{
	  printk ("ftape: write issue error\n");
	  return EIO;
	}

      result = interrupt_wait (tape_unit, WRITE_TIMEOUT);
      if (result)
	{
	  printk ("ftape: write timeout\n");
	  return EIO;
	}

      result = issue_command (NULL, 0, in, 7);
      if (result)
	{
	  printk ("ftape: write result error\n");
	  return result;
	}

      if ((in[0] & ST0_CODE_MASK) != ST0_NORMAL)
	{
	  printk ("ftape: write error st0 = 0x%02x, st1 = 0x%02x, st2 = 0x%02x\n",
		  in[0], in[1], in[2]);
	  printk ("ftape: write_segment, error cyl=%d, head=%d, sec=%d, ss=%d\n",
		  in[3], in[4], in[5], in[6]);
	  write_actual_segment = -3;	/* Some kind of write error. */
	  return EIO;
	}

      offset += count;
      data_offset += count;
      remaining -= count;
    }

  return 0;
}

/* Writing exists in one of seven states, i, q, qq, s, pp, w, and ww (for
   lack of better names). */
enum write_states
{
  WRITE_i, WRITE_q, WRITE_qq, WRITE_s, WRITE_pp,
  WRITE_w, WRITE_ww,
  WRITE_stopping, WRITE_stopping_wait,
  WRITE_error,
};
enum write_states write_state = WRITE_i;

/* Transitions for write thread. */
struct write_thread_transitions
  {
    enum write_states next;	/* Next state. */
    int wake;			/* Wake up user process? */
    int done;			/* Done writing? */
  };

static struct write_thread_transitions _write_thread_transitions[10] =
{
  {-1, -1, -1},
  {WRITE_s, 1, 1},
  {WRITE_q, 0, 0},
  {-1, -1, -1},
  {WRITE_qq, 1, 0},
  {WRITE_i, 1, 1},
  {WRITE_w, 0, 0},
  {-1, -1, -1},
  {-1, -1, -1},
  {-1, -1, -1}
};

static char *write_state_names[10] =
{
  "i", "q", "Q", "s", "P", "w", "W", "st", "ST", "Error"
};

static int
_write_thread (void *nothing)
{
  int old_state;
  int result = 0;
  int done = 0;
  int wake_them = 0;
  int buffer;

#if 0
  printk ("_write_thread starts, state = %s (%d)\n",
	  write_state_names[write_state], segment_count);
#endif

  buffer = PREVIOUS_BUFFER;
  result = _start_tape (segment_being_read, &write_actual_segment, 0);
  if (result)
    {
      write_state = WRITE_error;
      write_error_location = segment_being_read;
      INCREMENT_BUFFER;
    }
  else
    {
      while (!done)
	{
	  result = _write_segment (segment_being_read,
				   error_masks[segment_being_read
					       % segments_per_track],
				   (tape_buffer
				    + TBUF_2 * buffer));
	  segment_being_read++;
	  old_state = write_state;
	  if (result)
	    {
	      write_state = WRITE_error;
	      write_error_location = segment_being_read - 1;
	      done = 1;
	    }
	  else
	    {
	      if (_write_thread_transitions[old_state].next == -1)
		{
		  printk ("ftape error: invalid write thread state %d\n",
			  old_state);
		  write_state = WRITE_error;
		  return 0;
		}
	      write_state = _write_thread_transitions[old_state].next;
	      wake_them = _write_thread_transitions[old_state].wake;
	      done = _write_thread_transitions[old_state].done;
	    }
	  if (!done && wake_them)
#if 0
	    printk ("_write_thread wakes, not done, state = %s (%d)\n",
		    write_state_names[write_state], segment_count),
#endif
	      wake_up (&th_wait_queue);	/* Process needs to be awoken. */

	  buffer = PREVIOUS_BUFFER;
	}
    }

  old_state = write_state;
  /* Stop tape appropriately */
  /* Can't wait for ready, because if the tape is moving, the drive
     won't be ready.  The stop seems to fail if we're at the beginning
     of the tape. */
  /*_wait_for_ready ();*/
  if (old_state == WRITE_w)
    tape_command (tape_unit, QIC_STOP_TAPE);
  else
    tape_command (tape_unit, QIC_PAUSE);
#if 0
  if (read_state == READ_STOPPING_WAIT)
    wake_up (&th_wait_queue);
#endif /* The done wakes us up. */

  write_state = old_state;

#if 0
  printk ("_write_thread finishes, state = %s (%d)\n",
	  write_state_names[write_state], segment_count);
#endif

  return 0;
}

struct write_transitions
{
  enum write_states next;	/* Next state. */
  int start;			/* Start thread? */
  int block;			/* Block? */
  int cease_next;		/* Next thread for cease. */
  int cease_block;		/* Block on cease? */
};

static struct write_transitions write_transitions[10] =
{
 /*       Next       start Blk  cNext   cBlock */
 /* i  */
  {WRITE_q, 1, 0, WRITE_i, 0},
 /* q  */
  {WRITE_qq, 0, 0, WRITE_w, 1},
 /* qq */
  {WRITE_pp, 0, 1, WRITE_ww, 1},
 /* s  */
  {WRITE_q, 1, 0, WRITE_i, 0},
 /* pp */
  {-1, -1, -1, -1, -1},
 /* w  */
  {-1, -1, -1, -1, -1},
 /* ww */
  {-1, -1, -1, -1, -1},
 /* st */
  {-1, -1, -1, -1, -1},
 /* ST */
  {-1, -1, -1, -1, -1},
 /* ER */
  {-1, -1, -1, WRITE_i, 0}
};

static int
_do_write (struct tape_write *tw)
  {
    int old_state;
    int result = 0;
    int dont_really_wait = 0;

#if 0
    printk ("Write is in state %s\n", write_state_names[write_state]);;
#endif

    if (write_state == WRITE_stopping)
      {
	write_state = WRITE_stopping_wait;	/* ???? */
	sleep_on (&th_wait_queue);
	dont_really_wait = 1;
      }

    old_state = write_state;

    if (old_state == WRITE_error)
      {
      real_bad:
	tw->actual_segment = write_actual_segment;
	if (tw->actual_segment == -1)
	  tw->actual_segment = -4;
	tw->error_location = write_error_location;
	return result;
      }

    if (write_transitions[old_state].next == -1)
      {
	printk ("ftape error: Write in invalid state %s\n",
		write_state_names[write_state]);
	return result;
      }
    else
      {
	write_state = write_transitions[old_state].next;
	if (write_transitions[old_state].block
	    && !dont_really_wait)
	  sleep_on (&th_wait_queue);
	if (write_state == WRITE_error)
	  goto real_bad;	/* Yuck. */
	if (old_state == WRITE_i)
	  segment_being_read = tw->segment;

	memcpy (&tape_buffer[CURRENT_BUFFER * TBUF_2],
		&(tw->buffer),
		TBUF_2);
	INCREMENT_BUFFER;
	if (write_transitions[old_state].start)
	  _write_thread (0);
	tw->actual_segment = -1;
	tw->error_location = -1;
      }

#if 0
    printk ("Write finished in state %s\n", write_state_names[write_state]);
#endif

    return result;
  }

static int
_do_write_cease (struct write_cease *tc)
{
  int block;
  int dont_really_wait = 0;
  int was_error;

#if 0
  printk ("Cease is in state %s\n", write_state_names[write_state]);
#endif

  was_error = write_state == WRITE_error;
  if (write_state == WRITE_stopping)
    {
      write_state = WRITE_stopping_wait;	/* ??? */
      sleep_on (&th_wait_queue);
      dont_really_wait = 1;
    }

  was_error |= write_state == WRITE_error;
  if (write_transitions[write_state].cease_next == -1)
    {
      printk ("ftape: write cease, impossible state %s\n",
	      write_state_names[write_state]);
      return 0;
    }

  block = write_transitions[write_state].cease_block;
  write_state = write_transitions[write_state].cease_next;
  if (block & !dont_really_wait)
    sleep_on (&th_wait_queue);

  /* Yes, check again. */
  if (write_state == WRITE_stopping)
    {
      write_state = WRITE_stopping_wait;	/* ??? */
      sleep_on (&th_wait_queue);
      dont_really_wait = 1;
    }

  was_error |= write_state == WRITE_error;
  if (was_error)
    {
      write_state = WRITE_i;
      tc->actual_segment = write_actual_segment;
      write_actual_segment = -1;
      tc->error_location = write_error_location;
    }
  else
    {
      tc->actual_segment = -1;
      tc->error_location = -1;
    }

  return 0;
}

static int busy_flag = 0;

int
_fdtape_close (int unit)
{
  struct write_cease tc;

  unit &= 0x03;

  /* Make sure thing is shut down. */
  if (read_state != READ_IDLE)
    _do_read_stop ();
  if (read_state != READ_IDLE)
    printk ("ftape: warning: close can't stop read\n");

  if (write_state != WRITE_i)
    _do_write_cease (&tc);
  if (read_state != WRITE_i)
    printk ("ftape: warning: close can't stop write\n");

  switch (unit_data[unit].drive_type)
    {
    case DRIVE_IS_COLORADO:
      tape_command (unit, QIC_COLORADO_DISABLE);
      break;
    case DRIVE_IS_MOUNTAIN:
      tape_command (unit, QIC_MOUNTAIN_DISABLE);
      break;
    default:
      break;
    }

  disable_controller (unit);
  busy_flag = 0;

  return 0;
}

int
_fdtape_ioctl (int unit, unsigned int command, void *arg, int mode)
{
  int result = EINVAL;
  int tmp_int;
  struct fdt_error tmp_error;
  struct _fdt_find_me tmp_find;

  if (tape_unit != unit)
    printk ("ftape: access wrong unit!\n");

  /* Don't do anything if reading or writing. */
  if ((read_state != READ_IDLE
       && command != FDT_READ && command != FDT_READ_STOP)
      || (write_state != WRITE_i
	  && command != FDT_WRITE && command != FDT_CEASE_WRITING))
    {
      return EBUSY;
    }
  switch (command)
    {
    case FDT_REPORT_STATUS:
      result = (report_drive_status (tape_unit, &tmp_int) == 0) ? 0 : EIO;
      verify_area (VERIFY_READ, arg, sizeof (int));
      put_fs_long (tmp_int, arg);
      break;
    case FDT_REPORT_ERROR_CODE:
      result = 0;
      {
	int code;
	if (report_error (tape_unit, &code))
	  result = EIO;
	else
	  {
	    tmp_error.error = code & 0xff;
	    tmp_error.command = code >> 8;
	  }
      }
      verify_area (VERIFY_READ, arg, sizeof (struct fdt_error));
      memcpy_tofs (arg, &tmp_error, sizeof (struct fdt_error));
      break;
    case FDT_REPORT_CONFIGURATION:
      result = (report_configuration (tape_unit, &tmp_int) == 0) ? 0 : EIO;
      verify_area (VERIFY_READ, arg, sizeof (int));
      put_fs_long (tmp_int, arg);
      break;
    case FDT_REPORT_ROM_VERSION:
      result = (report_rom_version (tape_unit, &tmp_int) == 0) ? 0 : EIO;
      verify_area (VERIFY_READ, arg, sizeof (int));
      put_fs_long (tmp_int, arg);
      break;
    case FDT_REPORT_VENDOR_ID:
      result = (report_vendor_id (tape_unit, &tmp_int) == 0) ? 0 : EIO;
      verify_area (VERIFY_READ, arg, sizeof (int));
      put_fs_long (tmp_int, arg);
      break;
    case FDT_SEEK_TO_END:
      result = _seek_to_end_thread ();
      break;
    case FDT_SEEK_TO_BEGINNING:
      result = _seek_to_beginning_thread ();
      break;
    case FDT_SEEK_FORWARD:
    case FDT_SEEK_REVERSE:
      {
	int value;		/* = *((int *) arg); */
	verify_area (VERIFY_READ, arg, sizeof (int));
	value = get_fs_long (arg);
	if (value < 0 || value > 255)
	  return EINVAL;
	value++;
	if (command == FDT_SEEK_REVERSE)
	  value = -value;
	result = _seek_thread (&value);
      }
      break;
    case FDT_SEEK_TO_TRACK:
      verify_area (VERIFY_READ, arg, sizeof (int));
      tmp_int = get_fs_long (arg);
      result = _seek_to_track_thread (&tmp_int);
      break;
    case FDT_FIND_ME:
      verify_area (VERIFY_READ, arg, sizeof (struct _fdt_find_me));
      memcpy_fromfs (&tmp_find, arg, sizeof (struct _fdt_find_me));
      result = _read_id_thread (&tmp_find);
      verify_area (VERIFY_READ, arg, sizeof (struct _fdt_find_me));
      memcpy_tofs (arg, &tmp_find, sizeof (struct _fdt_find_me));
      break;
    case FDT_SUBMIT_ERROR_MAP:
      {
	struct error_map map;
	verify_area (VERIFY_READ, arg, sizeof (struct error_map));
	memcpy_fromfs (&map, arg, sizeof (struct error_map));
	/* Zero out error map. */
	memset (error_masks, 0, segments_per_track * sizeof (unsigned long));
	memcpy (&error_masks, &map.error_masks, map.count * sizeof (unsigned long));
	result = 0;
      }
      break;
    case FDT_SET_TRACK_LENGTH:
      {
	int value;
	verify_area (VERIFY_READ, arg, sizeof (int));
	value = get_fs_long (arg);
	if (value != 150 && value != 100)
	  result = EINVAL;
	else
	  {
	    segments_per_track = value;
	    result = 0;
	  }
      }
      break;
    case FDT_READ:
      {
	struct tape_read tmp_read;
	verify_area (VERIFY_READ, arg, sizeof (struct tape_read));
	memcpy_fromfs (&tmp_read, arg, sizeof (struct tape_read));
	result = _do_read (&tmp_read);
	verify_area (VERIFY_READ, arg, sizeof (struct tape_read));
	memcpy_tofs (arg, &tmp_read, sizeof (struct tape_read));
	break;
      }
    case FDT_READ_STOP:
      result = _do_read_stop ();
      break;
    case FDT_WRITE:
      {
	struct tape_write tmp_write;
	verify_area (VERIFY_READ, arg, sizeof (struct tape_write));
	memcpy_fromfs (&tmp_write, arg, sizeof (struct tape_write));
	result = _do_write (&tmp_write);
	verify_area (VERIFY_READ, arg, sizeof (struct tape_write));
	memcpy_tofs (arg, &tmp_write, sizeof (struct tape_write));
	break;
      }
    case FDT_CEASE_WRITING:
      {
	struct write_cease tmp_wcease;
	result = _do_write_cease (&tmp_wcease);
	verify_area (VERIFY_READ, arg, sizeof (struct write_cease));
	memcpy_tofs (arg, &tmp_wcease, sizeof (struct write_cease));
	break;
      }
    case FDT_SET_DATA_RATE:
      verify_area (VERIFY_READ, arg, sizeof (int));
      tmp_int = get_fs_long (arg);
      result = _set_data_rate_thread (&tmp_int);
      break;
    default:
      result = EINVAL;
      break;
    }
  return result;
}

void
ftape_close (struct inode *inode, struct file *filep)
{
  int result;
  int unit = MINOR (inode->i_rdev);

  result = _fdtape_close (unit);

  if (tape_buffer != NULL)
    {
      kfree (tape_buffer);
      tape_buffer = NULL;
    }
}

int
ftape_ioctl (struct inode *inode, struct file *filep,
	     unsigned command, unsigned long arg)
{
  int unit = MINOR (inode->i_rdev);
  int mode = 0;

  return _fdtape_ioctl (unit, command, (void *) arg /* ??? */ , mode);
}

int
ftape_select (struct inode *inode, struct file *filep)
{
  printk ("ftape select called %d\n", MINOR (inode->i_rdev));

  return 1;
}

/* Transfer operations. */
static int
_open_thread (int unit)
{
  int value;
  int status;

  do_floppy = qic_117_interrupt;

  reset_controller (unit, 0);

  if (recalibrate (unit))
    return EIO;

  value = report_drive_status (unit, &status);

  if (value == 0)
    {
      unit_data[unit].drive_type = DRIVE_IS_UNKNOWN;
    }
  else
    {
      /* Drive doesn't respond.  Try and wake it up using the known
	 methods of drive wakeup. */
      printk ("ftape: using wakeup methods:");

      /* Try colorado. */
      value = tape_command (unit, QIC_COLORADO_ENABLE1);
      fdt_sleep (1);
      value = tape_command (unit, QIC_COLORADO_ENABLE2);
      fdt_sleep (1);
      value = report_drive_status (unit, &status);
      if (value == 0)
	{
	  printk ("Drive is COLORADO\n");
	  unit_data[unit].drive_type = DRIVE_IS_COLORADO;
	}
      else
	{
	  /* Try mountain. */
	  value = tape_command (unit, QIC_MOUNTAIN_ENABLE1);
	  fdt_sleep (1);
	  value = tape_command (unit, QIC_MOUNTAIN_ENABLE2);
	  fdt_sleep (1);
	  value = report_drive_status (unit, &status);
	  if (value == 0)
	    {
	      printk ("Drive is MOUNTAIN\n");
	      unit_data[unit].drive_type = DRIVE_IS_MOUNTAIN;
	    }
	  else
	    {
	      printk ("Unknown drive\n");
	      return ENODEV;
	    }
	}
    }

  /* Now we have valid status from the drive. */

#if 0
  printk ("ftape: drive status = 0x%02x, type = %d\n", status,
	  unit_data[unit].drive_type);
#endif

  buffered_segment[0] = -1;
  buffered_segment[1] = -1;
  segment_being_read = -1;
  segment_count = 0;
  read_into = 0;
  read_state = READ_IDLE;

  write_state = WRITE_i;
  write_actual_segment = -1;

  return 0;
}

/* Open */
int
_fdtape_open (int unit)
{
  int result;

  if (busy_flag)
    return EBUSY;

  tape_unit = unit;

  result = _open_thread (unit);
  if (result)
    return result;

  busy_flag = 1;

  return 0;
}

int
ftape_open (struct inode *inode, struct file *filep)
{
  int result;
#if 0
  int i;
#endif
  int unit = MINOR (inode->i_rdev);

  if (tape_buffer == NULL)
    {
      tape_buffer = kmalloc (TBUF, 1);
      if (tape_buffer == NULL)
	return ENOMEM;
#if 0
      for (i = 0; i < TBUF; i++)
	tape_buffer[i] = i / 256;
#endif
    }

  result = _fdtape_open (unit);

  /* If open failed, free memory. */
  if (result && tape_buffer != NULL)
    {
      kfree (tape_buffer);
      tape_buffer = NULL;
    }

  return result;
}

/************************************************************************/
/* Definitions for dynamic loading and linux. */

static struct file_operations ftape_cdev =
{
  NULL,				/* seek */
  NULL,				/* read */
  NULL,				/* write */
  NULL,				/* readdir */
  NULL,				/* select */
  ftape_ioctl,			/* ioctl */
  NULL,				/* mmap */
  ftape_open,			/* open */
  ftape_close,			/* close/release */
  NULL				/* fsync */
};

extern struct file_operations *chrdev_fops[];

int
init (void)
{
  printk ("ftape: Loading the device ...\n");
  chrdev_fops[TAPE_QIC_117_MAJOR] = &ftape_cdev;

  busy_flag = 0;
  tape_unit = -1;
  printk ("ftape: present\n");

  return 0;
}

void
cleanup (void)
{
  chrdev_fops[TAPE_QIC_117_MAJOR] = NULL;
  printk ("ftape: Removing the driver ...\n");
}
