/* Floppy disk controller and tape definitions.
   Copyright (C) 1992 David L. Brown, Jr.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; see the file COPYING.  If not, write to
the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.  */


/* The control register contains the following bits: */
#define FDC_UNIT_MASK		0x01 /* 0 - unit select.  The unit
					to by used must be selected
					here.  This enables the
					drive select line. */
#define FDC_RESET		0x04 /* 2 - Reset bit.  When 0 the
					!reset line is asserted on the
					FDC. */
#define FDC_DMA_REQUEST		0x08 /* 3 - DMA request.  Unknown? */
#define FDC_MOTOR_0		0x10 /* 4,5 - Motor select for drives
					0 and 1.  A 1 bit enables the
					motor. */

/* Commands themselves are pushed onto a stack through the data
   register.  Each command has a specified number of fixed arguments
   and returns a specified number of result values on return.  The
   parameters are indicated here with a W for write.  The result codes
   are indicated with an R for read. */

/* Specify timing parameters.
   - SRT (Step rate time) is the interval between step pulses.
   Encoded as 16 minus the number of ms.  (15 = 1ms, 14 = 2ms).
   - HUT (Head unload time) is the time between the completion of a
   read or write and the head unload.  Encoded in increments of 16ms
   (1 = 16ms, 2 = 32ms).
   - HLT (Head load time) is the time between the Head load signal
   going high and the start of a read or write operation.  Encoded in
   increments of 2 ms (1 = 2ms, 2 = 4ms, 127 = 254ms).
   - ND (Non-dma) selects non-dma mode.
        7  6  5  4  3  2  1  0
   W - ........Specify.........
   W - ....SRT.... ....HUT.....
   W - .........HLT......... ND */


/* Status information. */

/* Status register 0 is the interrupt status register.  When an
   interrupt occurs, the SENSE_INTERRUPT_STATUS command should be
   issued to determine why. */

/* The reason for the interrupt is storred in the top two bits.
   Normal means that a command has completed.  Abnormal means that the
   command did not complete (such as a recalibrate with no track 0).
   Invalid means the command was never issued.  Ready changed
   indicates that the drive ready bit on one of the drives has changed
   (such as inserting or removing a disk). */

#define ST0_CODE_MASK	0xc0
#define ST0_NORMAL	0x00
#define ST0_ABNORMAL	0x40
#define ST0_INVALID	0x80
#define ST0_READY_CHANGED 0xc0

#define ST0_SEEK_END	0x20	/* A seek command has completed. */
#define ST0_EQUIPMENT_CHECK 0x10 /* Recalibrate failed. */
#define ST0_NOT_READY	0x08	/* Read or write attempted while drive
				   not ready. */
#define ST0_HEAD_ADDRESS 0x04	/* State of the head at the interrupt. */
#define ST0_UNIT_MASK	0x03	/* Unit selected at time of interupt. */

/* Status register 1.  Reports result from reading or writing. */

#define ST1_END_OF_CYLINDER	0x80 /* Read past last sector of the
					track. */
#define ST1_DATA_ERROR		0x20 /* A CRC error occurred on either
					the ID field or the data
					field. */
#define ST1_OVERRUN		0x10 /* A data over or under run
					occurred.  Probably means the
					DMA controller is not properly
					configured. */
#define ST1_NO_DATA		0x04 /* The command could not find the
					proper data to read/write. */
#define ST1_NOT_WRITABLE	0x02 /* Write Protect became asserted
					during write. */
#define ST1_MISSING_ADDRESS_MARK 0x01 /* Address mark was missing. */

/* Status register 2.  This reports result from a read or write. */

#define ST2_CONTROL_MARK	0x40 /* A read found a deleted sector,
					or a read deleted sector found
					a non/deleted sector. */
#define ST2_DATA_ERROR		0x20 /* A CRC error occurred in the
					data field. */
#define ST2_WRONG_CYLINDER	0x10 /* The FDC thinks we're on a
					different track than what was
					read. */
#define ST2_BAD_CYLINDER	0x02 /* The FDC encountered a cylinder
					marked bad. */
#define ST2_MISSING_DATA_MARK	0x01 /* The data address mark was not
					found. */

/* Status register 3.  This reports the current status and state of
   the drive.  This is returned with report drive status. */

#define ST3_FAULT	0x80	/* From the fault signal on the drive.
				   This might not be connected. */
#define ST3_WRITE_PROTECT 0x40	/* From the write protect line on the
				   drive. */
#define ST3_READY	0x20	/* Drive ready indicator.  This might
				   be connected to disk change. */
#define ST3_TRACK_0	0x10	/* Track 0 indicator from line. */
#define ST3_2_SIDE	0x08	/* 2 side line.  Probably not
				   connected. */
#define ST3_HEAD_ADDRESS 0x04	/* Which side is selected. */
#define ST3_UNIT_MASK	0x03	/* Unit selected. */

/* Unit number for the tape drive. */

#define FDTAPE_UNIT 1
#undef FDTAPE_USE_MOTOR

/* QIC commands.  These commands are sent as pulses over the step
   line. */

#define QIC_RESET			1
#define QIC_REPORT_NEXT_BIT		2
#define QIC_PAUSE			3
#define QIC_MICRO_STEP_PAUSE		4
#define QIC_ALTERNATE_TIMEOUT		5
#define QIC_REPORT_DRIVE_STATUS		6
#define QIC_REPORT_ERROR_CODE		7
#define QIC_REPORT_DRIVE_CONFIGURATION	8
#define QIC_REPORT_ROM_VERSION		9
#define QIC_LOGICAL_FORWARD		10
#define QIC_PHYSICAL_REVERSE		11
#define QIC_PHYSICAL_FORWARD		12
#define QIC_SEEK_HEAD_TO_TRACK		13
#define QIC_SEEK_LOAD_POINT		14
#define QIC_ENTER_FORMAT_MODE		15
#define QIC_WRITE_REFERENCE_BURST	16
#define QIC_ENTER_VERIFY_MODE		17
#define QIC_STOP_TAPE			18
#define QIC_MICRO_STEP_HEAD_UP		21
#define QIC_MICRO_STEP_HEAD_DOWN	22
#define QIC_SKIP_REVERSE		25
#define QIC_SKIP_FORWARD		26
#define QIC_SELECT_RATE			27
#define QIC_ENTER_PRIMARY_MODE		28
#define QIC_REPORT_VENDOR_ID		32

/* In order to allow the tape drives to coexist with floppy drives at
   the same unit, manufacturers have added their own commands that
   enable and disable the tape drives.  The Mountain Tape drive
   requires two commands to enable.  However, this drive doesn't care
   about motor on so it is conceivable that ordinary floppy use could
   enable the drive causing unusual havoc. */

#define QIC_COLORADO_ENABLE1		46
#define QIC_COLORADO_ENABLE2		2
#define QIC_COLORADO_DISABLE		47
#define QIC_MOUNTAIN_ENABLE1		23
#define QIC_MOUNTAIN_ENABLE2		20
#define QIC_MOUNTAIN_DISABLE		24

/* Drive types detected by startup. */

enum _drive_types {
  DRIVE_IS_UNKNOWN,
  DRIVE_IS_COLORADO,
  DRIVE_IS_MOUNTAIN,
};

/* Timeouts for various operations. */
#define RECALIBRATE_RESULT_RETRIES 3
#define RECALIBRATE_TIMEOUT	(5 * HZ)
#define SEEK_RESULT_RETRIES  3
#define SEEK_TIMEOUT (5 * HZ)
#define READ_TIMEOUT (10 * HZ)
#define WRITE_TIMEOUT (10 * HZ)

/* Number of times to retry reading the controller status before a
   timeout is given. */
#define FDC_STATUS_RETRIES 0x2800

/* Parameters to specify for different modes.  Recalibrate causes the
   head to step slower to keep the drive from interpreting the seek as
   a command, and to keep from damaging any floppy drives. */
#define specify_normal()   specify (13, 15, 1, 0)
#define specify_recalibrate()	specify (13, 10, 1, 0)

/* Reasons to be waken. */
#define WAKEN_BY_TIMEOUT  1
#define WAKEN_BY_INTERRUPT 2

/* DMA registers and values.  Refer to documentation on Intel 8237 for
   details. */
#define DMA_COMMAND	0x08	/* Command register */
#define DMA_MASK	0x0f	/* Set the mask register.  A 0 bit
				   means this DMA channel is masked. */
#define DMA_MODE	0x0b	/* Mode of dma operation.  See below
				   for meaningful values here. */
#define DMA_CLEAR_FLIP_FLOP  0x0c /* Must write before writing the
				     address. */
#define DMA_ADDRESS	0x04	/* Write 2 bytes, low byte first for
				   the first 16 bits of the address. */
#define DMA_COUNT	0x05	/* Write 2 bytes, low byte first for
				   the 16 bits of the count.  1
				   greater than this value will be
				   copied. */
#define DMA_PAGE	0x81	/* bits 16-23 of the address.  This
				   allows for a 16Meg address range. */
#define DMA_MASK_BIT	0x0a	/* Enable a single channel by setting
				   the bit here.  The other channels
				   are not affected. */

