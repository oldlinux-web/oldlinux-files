/* miscellaneous BIOS stuff */
#ifndef BIOS_H
#define BIOS_H

#define INT2F_IDLE_MAGIC	0x1680


#endif
