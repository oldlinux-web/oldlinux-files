/* very simple semaphores */

#ifndef MUTEX_H
#define MUTEX_H

typedef int sem_t;

#endif /* MUTEX_H */
