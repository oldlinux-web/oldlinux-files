#include <linux/vm86.h>
#include "emu.h"

void x_mouse()
{  
switch (_regs.eax) {
	case 0:
#if	0
		printf("mouse status %x %x\n", _regs.cs, _regs.eip);
		printf("%04x %04x %04x %04x\n",
			 _regs.eax,_regs.ebx, _regs.ecx,_regs.edx);
		_regs.eax=0xffff;  /* installed */
		_regs.ebx=3; /* 3 buttton */

		if (_regs.cs==0xe000) {
			us *ssp;

			ssp = SEG_ADR((us *), ss, sp);
			_regs.eip = *(ssp++);
			_regs.cs = *(ssp++);
			_regs.eflags = (_regs.eflags & 0xffff0000) | *(ssp++);
			_regs.esp += 6;
		}
		return;
#endif
	defaults:
		printf("mouse ax:%x bx:%x, cx:%x\n",
			_regs.eax, _regs.ebx, _regs.ecx);
}

}
