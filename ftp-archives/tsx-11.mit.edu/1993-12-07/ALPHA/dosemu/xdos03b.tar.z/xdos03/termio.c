#include "emu.h"

extern unsigned short kbd_read();
extern void char_out();

void ReadString(int max, char *buf)
{
	char ch, *cp = buf +1, *ce = buf + max;
	int c;

	for (;;) {
		ch = (char)kbd_read();
		if (ch >= ' ' && ch <= '~' && cp < ce) {
			*cp++ = ch;
			char_out(ch, c_screen);
			continue;
		}
		if (ch == '\010' && cp > buf +1) { /* BS */
			cp--;
			char_out('\010', c_screen);
			char_out(' ', c_screen);
			char_out('\010', c_screen);
			continue;
		}
		if (ch == 13) {
			*cp = ch;
			break;
		}
	}
	*buf = (cp - buf) -1; /* length of string */
}
