#include <stdio.h>

void (*dosemu)();
char dummy[1088*1024+ 64*1024]; /* make sure that the lower 1MB+64K is unused */

int main(int argc, char **argv)
{
	if (uselib("/lib/libxdosemu") != 0) {
		printf("cannot load shared lib\n");
		exit(1);
	}
	dosemu = (void *) LIBSTART;
	dosemu(argc, argv);
}
