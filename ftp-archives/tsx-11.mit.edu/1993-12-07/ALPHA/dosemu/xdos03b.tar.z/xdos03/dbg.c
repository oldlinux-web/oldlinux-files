void d_printf()
{
}
void R_printf()
{
}
void dump_int_vect()
{ unsigned short *p;
  int i=0;

  p=0; 
	for(i=0; i<0x40; i++) {
		printf("%4x:%4x|", *(p+1), *p);
		p+=2;
		if ((i%8)==7) puts("");
	}
}
