/*
 *	buslogic.c	(C) 1993 David B. Gentzel
 *	Low-level scsi driver for BusLogic adapters
 *	by David B. Gentzel, Whitfield Software Services, Carnegie, PA
 *	    (gentzel@nova.enet.dec.com)
 *	Thanks to BusLogic for providing the necessary documentation
 *
 *	The original version of this driver was derived from aha1542.[ch] which
 *	is Copyright (C) 1992 Tommy Thorn.  Much has been reworked, but most of
 *	basic structure and substantial chunks of code still remain.
 */

/*
 * TODO:
 *	1. Cleanup error handling & reporting.
 *	2. Find out why scatter/gather is limited to 16 requests per command.
 *	3. Add multiple outstanding requests.
 *	4. See if we can make good use of having more than one command per lun.
 *	5. Test/improve/fix abort & reset functions.
 *	6. Look at command linking.
 */

/*
 * NOTES:
 *    BusLogic (formerly BusTek) manufactures an extensive family of
 *    intelligent, high performance SCSI-2 host adapters.  They all support
 *    command queueing and scatter/gather I/O.  Most importantly, they all
 *    support identical programming interfaces, so a single driver can be used
 *    for all boards.
 *
 *    Actually, they all support TWO identical programming interfaces!  They
 *    have an Adaptec 154x compatible interface (complete with 24 bit
 *    addresses) as well as a "native" 32 bit interface.  As such, the Linux
 *    aha1542 driver be used to drive them, but with less than optimal
 *    performance (at least for the EISA, VESA, and MCA boards).
 *
 *    Here is the scoop on the various models:
 *	BT-542B - ISA first-party DMA with floppy support.
 *	BT-545S - 542B + FAST SCSI and active termination.
 *	BT-545D - 545S + differential termination.
 *	BT-445S - VESA bus-master FAST SCSI with active termination and floppy
 *		  support.
 *	BT-640A - MCA bus-master with floppy support.
 *	BT-646S - 640A + FAST SCSI and active termination.
 *	BT-646D - 646S + differential termination.
 *	BT-742A - EISA bus-master with floppy support.
 *	BT-747S - 742A + FAST SCSI, active termination, and 2.88M floppy.
 *	BT-747D - 747S + differential termination.
 *	BT-757S - 747S + WIDE SCSI.
 *	BT-757D - 747D + WIDE SCSI.
 *
 *    Should you require further information on any of these boards, BusLogic
 *    can be reached at (408)492-9090.
 *
 *    This driver SHOULD support all of these boards.  It has only been tested
 *    with a 747S.  An earlier version was tested with a 445S.
 *
 *    Places flagged with a triple question-mark are things which are either
 *    unfinished, questionable, or wrong.
 */

#include <linux/string.h>
#include <linux/sched.h>
#include <linux/kernel.h>
#include <linux/head.h>
#include <linux/types.h>
#include <linux/ioport.h>

#include <asm/io.h>
#include <asm/system.h>
#include <asm/dma.h>

#include "../blk.h"
#include "scsi.h"
#include "hosts.h"
#define BUSLOGIC_PRIVATE_H	/* Get the "private" stuff */
#include "buslogic.h"

#define BUSLOGIC_DEBUG 0

#define WAITNEXTTIMEOUT 3000000

/* ??? This is due to scsi_malloc(512) in buslogic_queuecommand. */
#define MAX_SG (512 / sizeof (struct chain))

/* The DMA-Controller.  We need to fool with this because we want to be able to
   use an ISA BusLogic without having to have the BIOS enabled. */
#define DMA_MODE_REG 0xD6
#define DMA_MASK_REG 0xD4
#define	CASCADE 0xC0

/* BusLogic boards can be configured for quite a number of port addresses (six
   to be exact), but I generally do not want the driver poking around at
   random.  We allow two port addresses - this allows people to use a BusLogic
   with a MIDI card, which frequently also used 0x330.  If different port
   addresses are needed (e.g. to install more than two cards), you must define
   BUSLOGIC_PORT_OVERRIDE to be a list of the addresses which will be checked.
   This can also be used to resolve a conflict if the port-probing at a
   standard port causes problems with another board. */
static const unsigned int bases[] = {
#ifdef BUSLOGIC_PORT_OVERRIDE
    BUSLOGIC_PORT_OVERRIDE
#else
    0x330, 0x334, /* 0x130, 0x134, 0x230, 0x234 */
#endif
};

static struct config config;

static struct mailbox mb[2 * BUSLOGIC_MAILBOXES];
static struct ccb ccbs[BUSLOGIC_MAILBOXES];

static Scsi_Cmnd *SCint[BUSLOGIC_MAILBOXES] = { NULL, };

/* This will effectively start both of them at the first mailbox. */
static size_t last_mbi_used = 2 * BUSLOGIC_MAILBOXES - 1;
static size_t last_mbo_used = BUSLOGIC_MAILBOXES - 1;

static int buslogic_hostnum;

static void setup_mailboxes(void);

#define INTR_RESET() outb(RINT, CONTROL)

#define buslogic_printk buslogic_prefix(),printk

#define CHECK(cond) if (cond) ; else goto fail

#define WAIT(port, mask, allof, noneof) CHECK(wait(port, mask, allof, noneof))
#define WAIT_WHILE(port, mask) WAIT(port, mask, 0, mask)
#define WAIT_UNTIL(port, mask) WAIT(port, mask, mask, 0)

static __inline__ int wait(unsigned short port, unsigned char mask,
			   unsigned char allof, unsigned char noneof)
{
    int bits;
    int timeout = WAITNEXTTIMEOUT;

    for (;;) {
	bits = inb(port) & mask;
	if ((bits & allof) == allof && (bits & noneof) == 0)
	    break;
	if (--timeout == 0)
	    return 0;
    }
    return 1;
}

static void buslogic_prefix(void)
{
    printk("BusLogic SCSI: ");
}

static void buslogic_stat(void)
{
#if 0
    int s = inb(STATUS), i = inb(INTERRUPT);

    printk("status=%02X intrflags=%02X\n", s, i);
#endif
}

static int buslogic_out(const unsigned char *cmdp, size_t len)
{
    while (len--) {
	WAIT_WHILE(STATUS, CPRBSY);
	outb(*cmdp++, COMMAND_PARAMETER);
    }
    return 0;
  fail:
    buslogic_printk("buslogic_out failed(%u): ", len + 1);
    buslogic_stat();
    return 1;
}

static int buslogic_in(unsigned char *cmdp, size_t len)
{
    while (len--) {
	WAIT_UNTIL(STATUS, DIRRDY);
	*cmdp++ = inb(DATA_IN);
    }
    return 0;
  fail:
    buslogic_printk("buslogic_in failed(%u): ", len + 1);
    buslogic_stat();
    return 1;
}

static unsigned int makecode(unsigned int hosterr, unsigned int scsierr)
{
    switch (hosterr) {
      case 0x0:
      case 0xA:		/* Linked command complete without error and linked
			   normally. */
      case 0xB:		/* Linked command complete without error, interrupt
			   generated. */
	hosterr = 0;
	break;

      case 0x11:	/* Selection time out: the initiator selection or
			   target reselection was not complete within the SCSI
			   Time out period. */
	hosterr = DID_TIME_OUT;
	break;

      case 0x12:	/* Data overrun/underrun: the target attempted to
			   transfer more data than was allocated by the Data
			   Length field or the sum of the Scatter/Gather Data
			   Length fields. */

      case 0x13:	/* Unexpected bus free-The target dropped the SCSI BSY
			   at an unexpected time. */

      case 0x15:	/* MBO command was not 00, 01 or 02-The first byte of
			   the CB was invalid.  This usually indicates a
			   software failure. */

      case 0x16:	/* Invalid CCB Operation Code-The first byte of the
			   CCB was invalid.  This usually indicates a software
			   failure. */

      case 0x17:	/* Linked CCB does not have the same LUN-A subsequent
			   CCB of a set of linked CCB's does not specify the
			   same logical unit number as the first. */

      case 0x18:	/* Invalid Target Direction received from Host-The
			   direction of a Target Mode CCB was invalid. */

      case 0x19:	/* Duplicate CCB Received in Target Mode-More than
			   once CCB was received to service data transfer
			   between the same target LUN and initiator SCSI ID
			   in the same direction. */

      case 0x1A:	/* Invalid CCB or Segment List Parameter-A segment
			   list with a zero length segment or invalid segment
			   list boundaries was received.  A CCB parameter was
			   invalid. */
	hosterr = DID_ERROR;	/* Couldn't find any better. */
	break;

      case 0x14:	/* Target bus phase sequence failure-An invalid bus
			   phase or bus phase sequence was requested by the
			   target.  The host adapter will generate a SCSI
			   Reset Condition, notifying the host with a RSTS
			   interrupt. */
	hosterr = DID_RESET;
	break;

      default:
	buslogic_printk("makecode: unknown hoststatus %08X\n", hosterr);
	break;
    }
    return (hosterr << 16) | scsierr;
}

static int test_port(int port)
{
    volatile int debug = 0;

    config.port = port;

    /* Reset the adapter.  I ought to make a hard reset, but it's not really
       necessary. */

#if BUSLOGIC_DEBUG
    buslogic_printk("test_port called\n");
#endif

    outb(RHARD | RINT/* | RSBUS*/, CONTROL);

    debug = 1;
    /* Expect INREQ and HARDY, any of the others are bad. */
    WAIT(STATUS, STATMASK, INREQ | HARDY,
	 DACT | DFAIL | CMDINV | DIRRDY | CPRBSY);

    debug = 2;
    /* Shouldn't have generated any interrupts during reset. */
    if (inb(INTERRUPT) & INTRMASK)
	goto fail;
    setup_mailboxes();

    debug = 3;
    /* Test the basic ECHO command. */
    outb(CMD_ECHO, COMMAND_PARAMETER);

    debug = 4;
    /* Wait for CPRBSY=0.  If any of the others are set, it's bad. */
    WAIT_WHILE(STATUS, DACT | DFAIL | CMDINV | DIRRDY | CPRBSY);

    debug = 5;
    /* The meaning of life. */
    outb(42, COMMAND_PARAMETER);

    debug = 6;
    /* Expect only DIRRDY, that is, data ready. */
    WAIT(STATUS, STATMASK, DIRRDY, DACT | DFAIL | CPRBSY | CMDINV);

    debug = 7;
    /* Is the answer correct? */
    if (inb(DATA_IN) != 42)
	goto fail;

    debug = 8;
    /* Reading port should reset DIRRDY. */
    if (inb(STATUS) & DIRRDY)
	goto fail;

    debug = 9;
    /* When CMDC, command is completed, and we're though testing. */
    WAIT_UNTIL(INTERRUPT, CMDC);

    /* now initialize adapter. */

    debug = 10;
    /* Clear interrupts. */
    outb(RINT, CONTROL);

    debug = 11;

    return debug;				/* 1 = ok */
  fail:
    return 0;					/* 0 = not ok */
}

const char *buslogic_info(void)
{
    static char buf[64];
    size_t len;

    len = sprintf(buf, "BusLogic %s HA at port 0x%03X, IRQ %u",
		  (config.bus_type == 'A' ? "ISA"
		   : (config.bus_type == 'E' ? "EISA/VESA" : "MCA")),
		  config.port, config.irq);
    if (config.dma)
	len += sprintf(buf + len, ", DMA %u", config.dma);
    sprintf(buf + len, ", ID %u\n", config.id);
    return buf;
}

/* A "high" level interrupt handler. */
static void buslogic_interrupt(int junk)
{
    void (*my_done)(Scsi_Cmnd *) = NULL;
    int errstatus, mbistatus, number_serviced, found;
    size_t mbi, mbo;
    Scsi_Cmnd *SCtmp;

#if BUSLOGIC_DEBUG
    {
	int flag = inb(INTERRUPT);

	buslogic_printk("buslogic_interrupt: ");
	if (!(flag & INTV))
	    printk("no interrupt? ");
	if (flag & IMBL)
	    printk("IMBL ");
	if (flag & MBOR)
	    printk("MBOR ");
	if (flag & CMDC)
	    printk("CMDC ");
	if (flag & RSTS)
	    printk("RSTS ");
	printk("status %02X\n", inb(STATUS));
    }
#endif

    number_serviced = 0;

    for (;;) {
	INTR_RESET();

	cli();

	mbi = last_mbi_used + 1;
	if (mbi >= 2 * BUSLOGIC_MAILBOXES)
	    mbi = BUSLOGIC_MAILBOXES;

	found = 0;
	do {
	    if (mb[mbi].status != 0) {
		found = 1;
		break;
	    }
	    mbi++;
	    if (mbi >= 2 * BUSLOGIC_MAILBOXES)
		mbi = BUSLOGIC_MAILBOXES;
	} while (mbi != last_mbi_used);

	if (found) {
	    mbo = (struct ccb *)mb[mbi].ccbptr - ccbs;
	    mbistatus = mb[mbi].status;
	    mb[mbi].status = 0;
	    last_mbi_used = mbi;
	}

	sti();

	if (!found) {
	    /* Hmm, no mail.  Must have read it the last time around. */
	    if (number_serviced)
		return;
	    buslogic_printk("interrupt received, but no mail\n");
	    return;
	}

#if BUSLOGIC_DEBUG
	if (ccbs[mbo].tarstat || ccbs[mbo].hastat)
	    buslogic_printk("buslogic_interrupt: returning %08X (status %d)\n",
			    ((int)ccbs[mbo].hastat << 16) | ccbs[mbo].tarstat,
			    mb[mbi].status);
#endif

	if (mbistatus == 3)
	    continue;	/* Aborted command not found. */

#if BUSLOGIC_DEBUG
	buslogic_printk("...done %u %u\n", mbo, mbi);
#endif

	SCtmp = SCint[mbo];

	if (!SCtmp || !SCtmp->scsi_done) {
	    buslogic_printk("buslogic_interrupt: Unexpected interrupt\n");
	    return;
	}

	my_done = SCtmp->scsi_done;
	if (SCtmp->host_scribble)
	    scsi_free(SCtmp->host_scribble, 512);


	/* is there mail :-) */

	/* more error checking left out here */
	if (mbistatus != 1)
	    /* This is surely wrong, but I don't know what's right. */
	    errstatus = makecode(ccbs[mbo].hastat, ccbs[mbo].tarstat);
	else
	    errstatus = 0;

#if BUSLOGIC_DEBUG
	if (errstatus)
	    buslogic_printk("error: %08X %04X %04X\n",
			    errstatus, ccbs[mbo].hastat, ccbs[mbo].tarstat);

	if (status_byte(ccbs[mbo].tarstat) == CHECK_CONDITION) {
	    size_t i;

	    buslogic_printk("buslogic_interrupt: sense: ");
	    for (i = 0; i < sizeof SCtmp->sense_buffer; i++)
		printk(" %02X", SCtmp->sense_buffer[i]);
	    printk("\n");
	}

	if (errstatus)
	    buslogic_printk("buslogic_interrupt: returning %08X\n", errstatus);
#endif

	SCtmp->result = errstatus;
	SCint[mbo] = NULL;	/* This effectively frees up the mailbox slot,
				   as far as queuecommand is concerned. */
	my_done(SCtmp);
	number_serviced++;
    }
}

int buslogic_queuecommand(Scsi_Cmnd *SCpnt, void (*done)(Scsi_Cmnd *))
{
    static const unsigned char buscmd[] = { CMD_START_SCSI };
    unsigned char direction;
    unsigned char *cmd = (unsigned char *)SCpnt->cmnd;
    unsigned char target = SCpnt->target;
    unsigned char lun = SCpnt->lun;
    void *buff = SCpnt->request_buffer;
    int bufflen = SCpnt->request_bufflen;
    int mbo;

#if BUSLOGIC_DEBUG
    if (target > 1) {
	SCpnt->result = DID_TIME_OUT << 16;
	done(SCpnt);
	return 0;
    }
#endif

    if (*cmd == REQUEST_SENSE) {
#ifndef DEBUG
	if (bufflen != sizeof SCpnt->sense_buffer) {
	    buslogic_printk("Wrong buffer length supplied for request sense (%d)\n",
			    bufflen);
	    panic("buslogic.c: wrong buffer length for request sense");
	}
#endif
	SCpnt->result = 0;
	done(SCpnt);
	return 0;
    }

#if BUSLOGIC_DEBUG
    {
	int i;

	if (*cmd == READ_10 || *cmd == WRITE_10)
	    i = xscsi2int(cmd + 2);
	else if (*cmd == READ_6 || *cmd == WRITE_6)
	    i = scsi2int(cmd + 2);
	else
	    i = -1;
	buslogic_printk("buslogic_queuecommand: dev %d cmd %02X pos %d len %d ",
			target, *cmd, i, bufflen);
	buslogic_stat();
	buslogic_printk("buslogic_queuecommand: dumping scsi cmd: ");
	for (i = 0; i < (COMMAND_SIZE(*cmd)); i++)
	    printk(" %02X", cmd[i]);
	printk("\n");
	if (*cmd == WRITE_10 || *cmd == WRITE_6)
	    return 0;	/* we are still testing, so *don't* write */
    }
#endif

    /* Use the outgoing mailboxes in a round-robin fashion, because this
       is how the host adapter will scan for them. */

    cli();

    mbo = last_mbo_used + 1;
    if (mbo >= BUSLOGIC_MAILBOXES)
	mbo = 0;

    do {
	if (mb[mbo].status == 0 && SCint[mbo] == NULL)
	    break;
	mbo++;
	if (mbo >= BUSLOGIC_MAILBOXES)
	    mbo = 0;
    } while (mbo != last_mbo_used);

    if (mb[mbo].status || SCint[mbo]) {
	/* ??? Instead of panicing, we should enable OMBR interrupts and
	   sleep until we get one. */
	panic("buslogic.c: unable to find empty mailbox");
    }

    SCint[mbo] = SCpnt;	/* This will effectively prevent someone else from
			   screwing with this cdb. */

    last_mbo_used = mbo;

    sti();

#if BUSLOGIC_DEBUG
    buslogic_printk("sending command (%d %08X)...", mbo, done);
#endif

    mb[mbo].ccbptr = &ccbs[mbo];		/* This gets trashed for some
						   reason */

    memset(&ccbs[mbo], 0, sizeof (struct ccb));

    ccbs[mbo].cdblen = COMMAND_SIZE(*cmd);	/* SCSI Command Descriptor
						   Block Length */

    direction = 0;
    if (*cmd == READ_10 || *cmd == READ_6)
	direction = 8;
    else if (*cmd == WRITE_10 || *cmd == WRITE_6)
	direction = 16;

    memcpy(ccbs[mbo].cdb, cmd, ccbs[mbo].cdblen);

    if (SCpnt->use_sg) {
	struct scatterlist *sgpnt;
	struct chain *cptr;
	size_t i;

	ccbs[mbo].op = CCB_OP_INIT_SG;	/* SCSI Initiator Command w/scatter-gather */
	SCpnt->host_scribble = (unsigned char *)scsi_malloc(512);	/* ??? */
	if (SCpnt->host_scribble == NULL)
	    panic("buslogic.c: unable to allocate DMA memory");
	sgpnt = (struct scatterlist *)SCpnt->request_buffer;
	cptr = (struct chain *)SCpnt->host_scribble;
	if (SCpnt->use_sg > scsi_hosts[buslogic_hostnum].sg_tablesize) {
	    buslogic_printk("buslogic_queuecommand bad segment list, %d > %d\n",
			    SCpnt->use_sg,
			    scsi_hosts[buslogic_hostnum].sg_tablesize);
	    panic("buslogic.c: bad segment list");
	}
	for (i = 0; i < SCpnt->use_sg; i++) {
	    cptr[i].dataptr = sgpnt[i].address;
	    cptr[i].datalen = sgpnt[i].length;
	}
	ccbs[mbo].datalen = SCpnt->use_sg * sizeof (struct chain);
	ccbs[mbo].dataptr = cptr;
#if BUSLOGIC_DEBUG
	{
	    unsigned char *ptr;

	    buslogic_printk("cptr %08X: ", cptr);
	    ptr = (unsigned char *)cptr;
	    for (i = 0; i < 18; i++)
		printk(" %02X", ptr[i]);
	    printk("\n");
	}
#endif
    } else {
	ccbs[mbo].op = CCB_OP_INIT;	/* SCSI Initiator Command */
	SCpnt->host_scribble = NULL;
	ccbs[mbo].datalen = bufflen;
	ccbs[mbo].dataptr = buff;
    }
    ccbs[mbo].id = target;
    ccbs[mbo].lun = lun;
    ccbs[mbo].dir = direction;
    ccbs[mbo].rsalen = sizeof SCpnt->sense_buffer;
    ccbs[mbo].senseptr = SCpnt->sense_buffer;
    ccbs[mbo].linkptr = NULL;
    ccbs[mbo].commlinkid = 0;

#if BUSLOGIC_DEBUG
    {
	size_t i;

	buslogic_printk("buslogic_queuecommand: sending...");
	for (i = 0; i < sizeof ccbs[mbo]; i++)
	    printk(" %02X", ((unsigned char *)&ccbs[mbo])[i]);
	printk("\n");
    }
#endif

    if (done) {
#if BUSLOGIC_DEBUG
	buslogic_printk("buslogic_queuecommand: now waiting for interrupt: ");
	buslogic_stat();
#endif
	SCpnt->scsi_done = done;
	mb[mbo].status = 1;
	buslogic_out(buscmd, sizeof buscmd);	/* start scsi command */
#if BUSLOGIC_DEBUG
	buslogic_printk("buslogic_queuecommand: status: ");
	buslogic_stat();
#endif
    } else
	buslogic_printk("buslogic_queuecommand: done can't be NULL\n");

    return 0;
}

#if 0
static volatile int internal_done_flag = 0;
static volatile int internal_done_errcode = 0;

static void internal_done(Scsi_Cmnd *SCpnt)
{
    internal_done_errcode = SCpnt->result;
    internal_done_flag++;
}

int buslogic_command(Scsi_Cmnd *SCpnt)
{
#if BUSLOGIC_DEBUG
    buslogic_printk("buslogic_command: ..calling buslogic_queuecommand\n");
#endif

    buslogic_queuecommand(SCpnt, internal_done);

    while (!internal_done_flag)
	continue;
    internal_done_flag = 0;
    return internal_done_errcode;
}
#endif

/* Initialize mailboxes. */
static void setup_mailboxes(void)
{
    size_t i;
    struct {
	unsigned char cmd, count;
	void *base PACKED;
    } cmd = { CMD_INITEXTMB, BUSLOGIC_MAILBOXES, mb };

    for (i = 0; i < BUSLOGIC_MAILBOXES; i++) {
	mb[i].status = mb[BUSLOGIC_MAILBOXES + i].status = 0;
	mb[i].ccbptr = &ccbs[i];
    }
    INTR_RESET();	/* reset interrupts, so they don't block */
    buslogic_out((unsigned char *)&cmd, sizeof cmd);
    WAIT_UNTIL(INTERRUPT, CMDC);
    while (0) {
      fail:
	buslogic_printk("buslogic_detect: failed setting up mailboxes\n");
    }
    INTR_RESET();
}

static int getconfig(int hostnum)
{
    unsigned char inquiry_cmd[2];
    unsigned char inquiry_result[4];
    int i;

    i = inb(STATUS);
    if (i & DIRRDY)
	i = inb(DATA_IN);
    inquiry_cmd[0] = CMD_RETCONF;
    buslogic_out(inquiry_cmd, 1);
    buslogic_in(inquiry_result, 3);
    WAIT_UNTIL(INTERRUPT, CMDC);
    INTR_RESET();
    switch (inquiry_result[0]) {
      case 0x20:
	config.dma = 5;
	break;
      case 0x40:
	config.dma = 6;
	break;
      case 0x80:
	config.dma = 7;
	break;
      case 0:	/* This indicates a that no DMA channel is used. */
	config.dma = 0;
	break;
      default:
	buslogic_printk("Unable to determine BusLogic DMA channel.  Disabling board\n");
	return -1;
    }
    switch (inquiry_result[1]) {
      case 0x01:
	config.irq = 9;
	break;
      case 0x02:
	config.irq = 10;
	break;
      case 0x04:
	config.irq = 11;
	break;
      case 0x08:
	config.irq = 12;
	break;
      case 0x20:
	config.irq = 14;
	break;
      case 0x40:
	config.irq = 15;
	break;
      default:
	buslogic_printk("Unable to determine BusLogic IRQ level.  Disabling board\n");
	return -1;
    }
    config.id = inquiry_result[2] & 0x7;

    inquiry_cmd[0] = CMD_INQEXTSETUP;
    inquiry_cmd[1] = 4;
    buslogic_out(inquiry_cmd, 2);
    buslogic_in(inquiry_result, 4);
    WAIT_UNTIL(INTERRUPT, CMDC);
    INTR_RESET();

#ifdef BUSLOGIC_BUS_TYPE_OVERRIDE
    config.bus_type = BUS_TYPE_OVERRIDE;
#else
    config.bus_type = inquiry_result[0];
#endif
    CHECK(config.bus_type == 'A'
	  || config.bus_type == 'E'
	  || config.bus_type == 'M');
#ifdef BUSLOGIC_BUS_TYPE_OVERRIDE
    if (inquiry_result[0] != BUS_TYPE_OVERRIDE)
	buslogic_printk("Overriding bus type %c with %c\n",
			inquiry_result[0], BUS_TYPE_OVERRIDE);
#endif
    config.max_sg = (inquiry_result[3] << 8) | inquiry_result[2];

    while (0) {
      fail:
	buslogic_printk("buslogic_detect: query board settings\n");
	return -1;
    }

    return 0;
}

/* Query the board to find out if it is a 1542 or a 1740, or whatever. */
static void buslogic_query(int hostnum)
{
#if 0
    unsigned const char inquiry_cmd[] = { CMD_INQUIRY };
    unsigned char inquiry_result[4];
    int i;

    i = inb(STATUS);
    if (i & DIRRDY)
	i = inb(DATA_IN);
    buslogic_out(inquiry_cmd, sizeof inquiry_cmd);
    buslogic_in(inquiry_result, 4);
    WAIT_UNTIL(INTERRUPT, CMDC);
    while (0) {
      fail:
	buslogic_printk("buslogic_detect: query card type\n");
    }
    INTR_RESET();
#endif
}

/* return non-zero on detection */
int buslogic_detect(int hostnum)
{
    int indx;

#if BUSLOGIC_DEBUG
    buslogic_printk("buslogic_detect:\n");
#endif

    for (indx = 0; indx < ARRAY_SIZE(bases); indx++)
	if (!check_region(bases[indx], 3) && test_port(bases[indx]))
	    break;
    if (indx == ARRAY_SIZE(bases))
	return 0;

    /* Set the Bus on/off-times as not to ruin floppy performance. */
    {
	/* The default ON/OFF times for BusLogic adapters is 7/4. */
	static const unsigned char oncmd[] = { CMD_BUSON_TIME, 7 };
	static const unsigned char offcmd[] = { CMD_BUSOFF_TIME, 5 };

	INTR_RESET();
	buslogic_out(oncmd, sizeof oncmd);
	WAIT_UNTIL(INTERRUPT, CMDC);
	/* CMD_BUSOFF_TIME is a noop for EISA boards, but as there is no way to
	   to differentiate EISA from VESA we send it unconditionally. */
	INTR_RESET();
	buslogic_out(offcmd, sizeof offcmd);
	WAIT_UNTIL(INTERRUPT, CMDC);
	while (0) {
	  fail:
	    buslogic_printk("buslogic_detect: setting bus on/off-time failed\n");
	}
	INTR_RESET();
    }
    buslogic_query(hostnum);

    if (getconfig(hostnum) == -1)
	return 0;

#if BUSLOGIC_DEBUG
    buslogic_printk("buslogic_detect: status: ");
    buslogic_stat();
#endif
    setup_mailboxes();
#if BUSLOGIC_DEBUG
    buslogic_printk("buslogic_detect: status: ");
    buslogic_stat();
#endif

    scsi_hosts[hostnum].this_id = config.id;
    /* Only type 'A' (AT/ISA) bus adapters use unchecked DMA. */
    scsi_hosts[hostnum].unchecked_isa_dma = (config.bus_type == 'A');
    scsi_hosts[hostnum].sg_tablesize = config.max_sg;
    if (scsi_hosts[hostnum].sg_tablesize > MAX_SG)
	scsi_hosts[hostnum].sg_tablesize = MAX_SG;

#if BUSLOGIC_DEBUG
    buslogic_printk("buslogic_detect: enable interrupt channel %d\n",
		    config.irq);
#endif

    if (request_irq(config.irq, buslogic_interrupt)) {
	buslogic_printk("Unable to allocate IRQ for BusLogic controller.\n");
	return 0;
    }

    if (config.dma) {
	if (request_dma(config.dma)) {
	    buslogic_printk("Unable to allocate DMA channel for BusLogic controller.\n");
	    free_irq(config.irq);
	    return 0;
	}

	if (config.dma >= 5) {
	    outb((config.dma - 4) | CASCADE, DMA_MODE_REG);
	    outb(config.dma - 4, DMA_MASK_REG);
	}
    }

#if 0
    {
	unsigned char buf[8];
	unsigned char cmd[] = { READ_CAPACITY, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	size_t i;

#if BUSLOGIC_DEBUG
	buslogic_printk("*** READ CAPACITY ***\n");
#endif
	for (i = 0; i < sizeof buf; i++)
	    buf[i] = 0x87;
	for (i = 0; i < 2; i++)
	    if (!buslogic_command(i, cmd, buf, sizeof buf)) {
		buslogic_printk("bus_detect: LU %u sector_size %d device_size %d\n",
				i, xscsi2int(buf + 4), xscsi2int(buf));
	    }

#if BUSLOGIC_DEBUG
	buslogic_printk("*** NOW RUNNING MY OWN TEST ***\n");
#endif
	for (i = 0; i < 4; i++) {
	    static buffer[512];

	    cmd[0] = READ_10;
	    cmd[1] = 0;
	    xany2scsi(cmd + 2, i);
	    cmd[6] = 0;
	    cmd[7] = 0;
	    cmd[8] = 1;
	    cmd[9] = 0;
	    buslogic_command(0, cmd, buffer, 512);
	}
    }
#endif

    snarf_region(bases[indx], 3);	/* Register the IO ports that we use */
    buslogic_hostnum = hostnum;
    return 1;
}

/* The abort command does not leave the device in a clean state where it is
   available to be used again.  Until this gets worked out, we will leave it
   commented out. */
int buslogic_abort(Scsi_Cmnd *SCpnt, int i)
{
#if 0
    static const unsigned char buscmd[] = { CMD_START_SCSI };
    int mbo;
#endif

#if BUSLOGIC_DEBUG
    buslogic_printk("buslogic_abort\n");
#endif

#if 0
    cli();
    for (mbo = 0; mbo < BUSLOGIC_MAILBOXES; mbo++)
	if (SCpnt == SCint[mbo]) {
	    mb[mbo].status = 2;			/* Abort command */
	    buslogic_out(buscmd, sizeof buscmd);/* start scsi command */
	    break;
	}
    sti();
#endif

    return 0;
}

int buslogic_reset(void)
{
#if BUSLOGIC_DEBUG
    buslogic_printk("buslogic_reset\n");
#endif
    return 0;
}

int buslogic_biosparam(int size, int dev, int *ip)
{
    /* ??? This is wrong if disk is configured for > 1G mapping.
       Unfortunately, unlike UltraStor, I see know way of determining whether
       > 1G mapping has been enabled. */
    ip[0] = 64;
    ip[1] = 32;
    ip[2] = size >> 11;
/*    if (ip[2] > 1024)
      ip[2] = 1024; */
    return 0;
}
