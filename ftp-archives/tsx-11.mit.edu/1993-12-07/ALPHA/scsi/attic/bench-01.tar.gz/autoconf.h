/*
 * Automatically generated C config: don't edit
 */

/* 
 * General setup
 * 
 */
#undef CONFIG_MATH_EMULATION
#define CONFIG_BLK_DEV_HD 1
#undef CONFIG_BLK_DEV_XD
#undef CONFIG_INET
#undef CONFIG_MAX_16M
#define CONFIG_SYSVIPC 1
#define CONFIG_M486 1

/* 
 * Program binary formats
 * 
 */
#undef CONFIG_BINFMT_ELF

/* 
 * SCSI support
 * 
 */
#define CONFIG_SCSI 1

/* 
 * SCSI support type (disk, tape, CDrom)
 * 
 */
#define CONFIG_BLK_DEV_SD 1
#undef CONFIG_CHR_DEV_ST
#undef CONFIG_BLK_DEV_SR
#undef CONFIG_CHR_DEV_SG

/* 
 * SCSI low-level drivers
 * 
 */
#define CONFIG_SCSI_DEBUG
#undef CONFIG_SCSI_AHA152X
#undef CONFIG_SCSI_AHA1542
#undef CONFIG_SCSI_AHA1740
#undef CONFIG_SCSI_FUTURE_DOMAIN
#undef CONFIG_SCSI_GENERIC_NCR5380
#undef CONFIG_SCSI_PAS16
#undef CONFIG_SCSI_SEAGATE
#undef CONFIG_SCSI_T128
#undef CONFIG_SCSI_ULTRASTOR
#undef CONFIG_SCSI_7000FASST

/* 
 * Network device support
 * 
 */
#undef CONFIG_ETHERCARDS

/* 
 */
#undef CONFIG_CDU31A
#undef CONFIG_MCD

/* 
 * Filesystems
 * 
 */
#define CONFIG_MINIX_FS 1
#undef CONFIG_EXT_FS
#define CONFIG_EXT2_FS 1
#undef CONFIG_XIA_FS
#define CONFIG_MSDOS_FS 1
#define CONFIG_PROC_FS 1
#define CONFIG_NFS_FS 1
#undef CONFIG_ISO9660_FS

/* 
 * character devices
 * 
 */
#define CONFIG_KBD_META 1
#define CONFIG_KBD_NUML 1
#define CONFIG_PRINTER 1
#undef CONFIG_BUSMOUSE
#undef CONFIG_QUICKPORT_MOUSE
#undef CONFIG_PSMOUSE
#undef CONFIG_MS_BUSMOUSE
#undef CONFIG_ATIXL_BUSMOUSE
#define CONFIG_SELECTION 1
#undef CONFIG_TAPE_QIC02

/* 
 * Sound
 * 
 */
#undef CONFIG_SOUND

/* 
 * Kernel hacking
 * 
 */
#undef CONFIG_DEBUG_MALLOC
#undef CONFIG_PROFILE
#define CONFIG_SCSI_CONSTANTS 1

#undef cli
#define cli()
#undef sti
#define sti()
