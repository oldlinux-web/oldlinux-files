/* aha152x.c -- Adaptec AHA-152x driver
 * Author: Juergen E. Fischer, fischer@server.et-inf.fho-emden.de
 * Copyright 1993 Juergen E. Fischer
 *
 *
 * This driver is based on
 *   fdomain.c -- Future Domain TMC-16x0 driver
 * which is
 *   Copyright 1992, 1993 Rickard E. Faith (faith@cs.unc.edu)
 *

 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.

 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 
 *
 * $Id: aha152x.c,v 0.8 1993/09/06 23:09:39 root Exp root $
 *

 * $Log: aha152x.c,v $
 * Revision 0.8  1993/09/06  23:09:39  root
 * - added support for the drive activity
 * - minor changes
 *
 * Revision 0.7  1993/09/05  14:30:15  root
 * - improved phase detection
 * - now using the new snarf_region code of 0.99pl13
 *
 * Revision 0.6  1993/09/02  11:01:38  root
 * first public release; added some signatures and biosparam()
 *
 * Revision 0.5  1993/08/30  10:23:30  root
 * fixed timing problems with my IBM drive
 *
 * Revision 0.4  1993/08/29  14:06:52  root
 * fixed some problems with timeouts due incomplete commands
 *
 * Revision 0.3  1993/08/28  15:55:03  root
 * writing data works too.  mounted and worked on a dos partition
 *
 * Revision 0.2  1993/08/27  22:42:07  root
 * reading data works.  Mounted a msdos partition.
 *
 * Revision 0.1  1993/08/25  13:38:30  root
 * first "damn thing doesn't work" version
 *
 * Revision 0.0  1993/08/14  19:54:25  root
 * empty function bodies; detect() works.
 *

 **************************************************************************


 
 DESCRIPTION:

 This is the Linux low-level SCSI driver for Adaptec AHA-1520/1522
 SCSI host adapters.


 PER-DEFINE CONFIGURABLE OPTIONS:

 CONF_RECONNECT : configure reconnection from controller's jumpers
 RECONNECT      : enable or disable reconnection
 CONF_PARITY    : configure reconnection from controller's jumpers
 PARIRY         : enable or disable parity
 CONF_SCSI_ID   : configure scsi id of controller from its jumpers
 SCSI_ID        : Override jumpered SCSI-ID
  

 REFERENCES USED:

 "AIC-6260 SCSI Chip Specification", Adaptec Corporation.

 "SCSI COMPUTER SYSTEM INTERFACE - 2 (SCSI-2)", X3T9.2/86-109 rev. 10h

 "Writing a SCSI device driver for Linux", Rik Faith (faith@cs.unc.edu)

 "Kernel Hacker's Guide", Michael K. Johnson (johnsonm@sunsite.unc.edu)

 "Adaptec 1520/1522 User's Guide", Adaptec Corporation.
 
 Michael K. Johnson (johnsonm@sunsite.unc.edu)

 Drew Eckhardt (drew@cs.colorado.edu)

 Eric Youngdale (eric@tantalus.nrl.navy.mil) 

 special thanks to Eric Youngdale for the free(!) supplying the
 documentation on the chip.

 **************************************************************************/

#include "aha152x.h"

#include <linux/sched.h>
#include <asm/io.h>
#include "../blk.h"
#include "scsi.h"
#include "hosts.h"
#include "constants.h"
#include <asm/system.h>
#include <linux/errno.h>
#include <linux/string.h>
#include <linux/ioport.h>

/* DEFINES */
#define  CHECK_PASSING_BUSFREE
#define  RECONNECT	0	/* dis-/reconnection is not supported yet */

/* I use this when I'm looking for weird bugs */
#define DEBUG_TIMING 
#define DEBUG_BIOSPARAM

#if defined(DEBUG)

#undef  SKIP_PORTS		/* don't display ports */

#undef  DEBUG_DETECTION		/* debug detect() */
#undef  DEBUG_QUEUE		/* debug queue() */
#undef  DEBUG_RESET		/* debug reset() */
#undef  DEBUG_INTR		/* debug intr() */
#undef  DEBUG_SELECTION		/* debug selection part in intr() */
#undef  DEBUG_MSGO		/* debug message out phase in intr() */
#undef  DEBUG_MSGI		/* debug message in phase in intr() */
#undef  DEBUG_STATUS		/* debug status phase in intr() */
#undef  DEBUG_CMD		/* debug command phase in intr() */
#undef  DEBUG_DATAI		/* debug data in phase in intr() */
#undef  DEBUG_DATAO		/* debug data out phase in intr() */
#undef  DEBUG_ABORT		/* debug abort() */
#undef  DEBUG_DONE		/* debug done() */
#undef  DEBUG_BIOSPARAM		/* debug biosparam() */

#undef  DEBUG_RACE		/* debug race conditions */
#undef  DEBUG_PHASES		/* debug phases (useful to trace) */

#define DEBUG_RESET

#endif
/* END OF DEFINES */

#if defined(CONF_RECONNECT) && defined(RECONNECT)
#error Only one of CONF_RECONNECT && RECONNECT should be set
#endif

#if defined(CONF_RECONNECT)
#define RECONNECT can_disconnect
static int can_disconnect = 1;
#else
#if !defined(RECONNECT)
#define RECONNECT 1
#endif
#endif

#if defined(CONF_PARITY) && defined(PARITY)
#error Only one of CONF_PARITY && PARITY should be set
#endif

#if defined(CONF_PARITY)
#define PARITY  do_parity
static int  do_parity    = 1;
#else
#if !defined(PARITY)
#define PARITY  1
#endif
#endif

#if defined(CONF_SCSI_ID) && defined(SCSI_ID)
#error Only one of CONF_SCSI_ID && SCSI_ID should be set
#else
#if !defined(SCSI_ID)
#define SCSI_ID 7
#endif
#endif


char *aha152x_id = "Adaptec 152x SCSI driver; $Revision: 0.8 $\n";

static int port_base       = 0;
static int interrupt_level = 0;
static int this_host       = 0;
static int in_command      = 0;

enum {
   in_selection     = 0x01,
   in_other         = 0x02,
   disconnected     = 0x04,
   aborted          = 0x08,
   sent_ident       = 0x10,
};
 
static Scsi_Cmnd *current_SC = NULL;

void aha152x_intr( int irqno );
void aha152x_done( int error );

static void disp_ports();

#if defined(DEBUG_INTR)
static void disp_enintr();
#endif

#if defined(DEBUG_RACE)
static void enter_driver(const char *);
static void leave_driver(const char *);
#endif

static void *addresses[] =
{
  (void *) 0xd8000, (void *) 0xdc000,
  (void *) 0xd0000, (void *) 0xd4000,
  (void *) 0xc8000, (void *) 0xcc000,
  (void *) 0xe0000, (void *) 0xe4000,
};
#define ADDRESS_COUNT (sizeof( addresses ) / sizeof( unsigned ))

static unsigned short ports[] = { 0x340, 0x140 };
#define PORT_COUNT (sizeof( ports ) / sizeof( unsigned short ))

static unsigned short ints[] = { 9, 10, 11, 12 };

static struct signature {
  char *signature;
  int  sig_offset;
  int  sig_length;
} signatures[] =
{
  {
   "Adaptec AHA-1520 BIOS\r\n\0\
Version 1.4      \r\n\0\
Copyright 1990 Adaptec, Inc.\r\n\
All Rights Reserved\r\n \r\n \r\n", 0x102e, 101
  },
  {"Adaptec BIOS: ASW-B626", 0x0F, 22},			     /* not reported to work */
  {"SCSI V1.0 03-05-90DATA TECHNOLOGY CORPORATION", 19, 45}, /* not reported to work */
  {"SCSI V1.3 02-22-91DATA TECHNOLOGY CORPORATION", 19, 45}, /* not reported to work */
};
#define SIGNATURE_COUNT (sizeof( signatures ) / sizeof( struct signature ))


/* These defines are copied from kernel/blk_drv/hd.c */

#define insw( buf, count, port ) \
  __asm__ volatile \
  ("cld;rep;insw": :"d" (port),"D" (buf),"c" (count):"cx","di" )

#define outsw( buf, count, port ) \
  __asm__ volatile \
  ("cld;rep;outsw": :"d" (port),"S" (buf),"c" (count):"cx","si")


static void do_pause( unsigned amount ) /* Pause for amount*10 milliseconds */
{
   unsigned long the_time = jiffies + amount; /* 0.01 seconds per jiffy */

   while (jiffies < the_time)
     ;
}

static void make_acklow()
{
  int forget;

  SETPORT( SXFRCTL0, CH1|SPIOEN );
  forget=GETPORT(SCSIDAT);
  SETPORT( SXFRCTL0, CH1 );

  while( TESTHI( SCSISIG, ACKI ) )
    ;
}

/*
 * detect current phase more reliable:
 * phase is valid, when the target asserts REQ after we've deasserted ACK.
 *
 * return value is a valid phase or an error code.
 *
 * errorcodes:
 *   1 BUS FREE phase detected
 *   2 RESET IN detected
 *   3 parity error in DATA phase
 */
static int getphase()
{
  int phase, sstat1;
  
  while( 1 )
    {
      do
        {
          while( !( ( sstat1 = GETPORT( SSTAT1 ) ) & (BUSFREE|SCSIRSTI|REQINIT ) ) )
            ;

          if( sstat1 & BUSFREE )
            return 1;
          if( sstat1 & SCSIRSTI )
            return 2;
        }
      while( TESTHI( SCSISIG, ACKI ) || TESTLO( SSTAT1, REQINIT ) );

      SETPORT( SSTAT1, CLRSCSIPERR );
  
      phase = GETPORT( SCSISIG ) & P_MASK ;

      if( TESTHI( SSTAT1, SCSIPERR ) )
        {
          if( phase & (CDO|MSGO) )		/* DATA phase */
            return 3;

          SETPORT( SCSISIG, phase );
          make_acklow();
        }
      else
        {
          SETPORT( SCSISIG, phase );
          return phase;
        }
    }
}

int aha152x_detect(int hostno)
{
  int                 i, j,  ok=0;
  aha152x_config      conf;
  struct sigaction    sa;
  
#if defined(DEBUG_RACE)
  enter_driver("detect");
#else
#if defined(DEBUG_DETECTION)
  printk("aha152x: detect(), ");
#endif
#endif
  
  for( i=0; i < ADDRESS_COUNT && !ok; i++)
    for( j=0; j < SIGNATURE_COUNT && !ok; j++)
      if(!memcmp((void *) addresses[i]+signatures[j].sig_offset,
                 (void *)              signatures[j].signature,
                 (int)                 signatures[j].sig_length))
        {
#if defined(DEBUG_DETECTION)
          printk("BIOS ok at 0x%x, ", addresses[i]);
#endif
          ok++;
        }
#if defined(DEBUG_DETECTION)
      else
        printk("no BIOS at 0x%x / %d, ", addresses[i], j);
#endif
  
  if(!ok)
    {
#if defined(DEBUG_DETECTION)
      printk("BIOS detection failed, ");
#endif
#if defined(DEBUG_RACE)
      leave_driver("(1) detect");
#endif
      return 0;
    }
  
  ok=0;
  for( i=0; i<PORT_COUNT && !ok; i++)
    {
      port_base=ports[i];

      if(check_region(port_base, TEST-SCSISEQ))
        continue;
      
      SETSTCNT(0xffffff);
      
#if defined(DEBUG_DETECTION)
      printk("stcnt=0x%x should be 0xffffff, ", GETSTCNT() );
#endif
      
      if(GETSTCNT()==0xffffff)
        {
          SETBITS( SXFRCTL0, CLRSTCNT);
          CLRBITS( SXFRCTL0, CLRSTCNT);
   
#if defined(DEBUG_DETECTION)
          printk("stcnt=0x%x should be 0x000000, ", GETSTCNT() );
#endif
   
          if(GETSTCNT()==0)
            {
#if defined(DEBUG_DETECTION)
               printk("port address ok, ");
#endif
               ok++;
            }
        }
    }
  
  if(!ok)
    {
#if defined(DEBUG_DETECTION)
      printk("port detection failed, ");
#endif
#if defined(DEBUG_RACE)
      leave_driver("(2) detect");
#endif
      return 0;
    }
  
#if defined(DEBUG_DETECTION)
  printk("auto configuration in progress, current board configuration:");
#endif
  
  conf.cf_porta = inb(PORTA);
  conf.cf_portb = inb(PORTB);
  
#if defined(CONF_PARITY)
  PARITY=conf.cf_parity;
#endif
#if defined(DEBUG_DETECTION)
  printk("SCSI parity %s, ", PARITY ? "enabled" : "disabled" );
#endif
  
#if defined(DEBUG_DETECTION)
  if(conf.cf_dma)
    printk("transfer mode DMA overridden, ");
  printk("transfer mode: PIO, ");
#endif
  
  sa.sa_handler  = aha152x_intr;
  sa.sa_flags    = SA_INTERRUPT;
  sa.sa_mask     = 0;
  sa.sa_restorer = NULL;
  
  interrupt_level = ints[conf.cf_irq];
  ok = irqaction( interrupt_level, &sa);
  
  if(ok<0)
    {
      if(ok == -EINVAL)
        {
           printk("aha152x: bad IRQ %d.\n", interrupt_level);
           printk("         Contact author.\n");
        }
      else
        if( ok == -EBUSY)
          printk( "aha152x: IRQ %d already in use. Configure another.\n",
                  interrupt_level);
        else
          {
            printk( "\naha152x: Unexpected error code on requesting IRQ %d.\n",
                    interrupt_level);
            printk("         Contact author.\n");
          }
      panic("aha152x: driver needs an IRQ.\n");
    }
#if defined(DEBUG_DETECTION)
  else
    printk("\naha152x: IRQ %d requested.\n", interrupt_level);
#endif

#if defined(CONF_SCSI_ID)
  this_host = conf.cf_id;
#else
  this_host = SCSI_ID;
#endif

  SETPORT( SCSIID, this_host << 4 );
  scsi_hosts[hostno].this_id=this_host;

#if defined(DEBUG_DETECTION)
  printk("jumpered SCSI-ID: %d, ", conf.cf_id);
  printk("SCSI-ID: %d, ", this_host );
#endif
  
#if defined(DEBUG_DETECTION)
  printk( "boot : %s, ", conf.cf_boot ? "enabled" : "disabled" );
  printk( "initial sync neg : %s, ", conf.cf_syncneg ? "enabled" : "disabled" );
#endif
  
#if defined(CONF_RECONNECT)
  RECONNECT=conf.cf_tardisc;
#endif
#if defined(DEBUG_DETECTION)
  printk( "target disconnect: %s, ", RECONNECT ? "enabled" : "disabled" );
#endif

  aha152x_reset();

  snarf_region(port_base, TEST-SCSISEQ);        /* Register */
  
  SETPORT( SIMODE0, 0);
  SETPORT( SIMODE1, 0);

#if defined(DEBUG_RACE)
  leave_driver("(3) detect");
#endif

  SETBITS( DMACNTRL0, INTEN);
  return 1;
}

const char *aha152x_info(void)
{
#if defined(DEBUG_RACE)
  enter_driver("info");
  leave_driver("info");
#else
#if defined(DEBUG_INFO)
  printk("\naha152x: info()\n");
#endif
#endif
  return(aha152x_id);
}

int aha152x_queue( Scsi_Cmnd * SCpnt, void (*done)(Scsi_Cmnd *))
{
  CLRBITS( DMACNTRL0, INTEN);

#if defined(DEBUG_RACE)
  enter_driver("queue");
#else
#if defined(DEBUG_QUEUE)
  printk("aha152x: queue(), ");
#endif
#endif


#if defined(DEBUG_QUEUE)
  printk( "SCpnt (target = %d lun = %d cmnd = 0x%02x pieces = %d size = %u), ",
          SCpnt->target,
          SCpnt->lun,
          *(unsigned char *)SCpnt->cmnd,
          SCpnt->use_sg,
          SCpnt->request_bufflen );
  disp_ports();
#endif

  SCpnt->scsi_done =  done;

  if(in_command)
    panic("aha152x: queue() called within command\n");

#ifdef 0
  /* now in done() */
  if( TESTLO( SSTAT1, BUSFREE ))
    {
      printk("bus should be free, ");
      do_pause(5);
 
      if( TESTLO( SSTAT1, BUSFREE ))
        {
          disp_ports();
          panic("aha152x: bus not free");
        }
    }
#endif

  in_command++;

  SETPORT( PORTA, 1 );		/* turn led on */

  current_SC = SCpnt;

  /* setup SCSI pointers
     SCp.ptr         	  : buffer pointer
     SCp.this_residual	  : buffer length
     SCp.buffer           : next buffer
     SCp.buffers_residual : left buffers in list */
  if (current_SC->use_sg)
    {
      current_SC->SCp.buffer =
      (struct scatterlist *)current_SC->request_buffer;
      current_SC->SCp.ptr              = current_SC->SCp.buffer->address;
      current_SC->SCp.this_residual    = current_SC->SCp.buffer->length;
      current_SC->SCp.buffers_residual = current_SC->use_sg - 1;
    }
  else
    {
      current_SC->SCp.ptr              = (char *)current_SC->request_buffer;
      current_SC->SCp.this_residual    = current_SC->request_bufflen;
      current_SC->SCp.buffer           = NULL;
      current_SC->SCp.buffers_residual = 0;
    }
        
  current_SC->SCp.Status              = 0;
  current_SC->SCp.Message             = 0;
  current_SC->SCp.have_data_in        = 0;
  current_SC->SCp.sent_command        = 0;
  current_SC->SCp.phase               = in_selection;

#if defined(DEBUG_QUEUE) || defined(DEBUG_PHASES)
  printk("selecting %d, ", current_SC->target); 
#endif
  SETPORT( SCSIID, (this_host << OID_) | current_SC->target );

  /* Enable interrupts for SELECTION OUT DONE and SELECTION OUT INITIATED */
  SETPORT( SXFRCTL1, ENSPCHK|ENSTIMER);

  /* enable interrupts for SELECTION OUT DONE and SELECTION TIME OUT */
  SETPORT( SIMODE0, ENSELDO );
  SETPORT( SIMODE1, ENSELTIMO );

  /* Enable SELECTION OUT sequence */
  SETPORT(SCSISEQ, ENSELO | ENAUTOATNO );

#if defined(DEBUG_RACE)
  leave_driver("queue");
#endif
  SETBITS( DMACNTRL0, INTEN );
  return 0;
}

int aha152x_command( Scsi_Cmnd *SCpnt )
{
  panic( "aha152x: must use interrupt-driven driver\n" );
  return -1;
}

int aha152x_abort( Scsi_Cmnd *SCpnt, int code )
{
  cli();

#if defined(DEBUG_ABORT)
  printk("aha152x: abort() (%x), ", jiffies);
#endif

#if defined(DEBUG_ABORT)
  disp_ports();
#endif

  if (!in_command)
    {
#if defined(DEBUG_ABORT)
       printk( "not in command, " );
#endif

       sti();
       return 0;
    }
#if defined(DEBUG_ABORT)
  else
    printk( "abort code = %d, ", code );
#endif

  current_SC->SCp.phase |= aborted;
  current_SC->result    =  code ? code : DID_ABORT;
  aha152x_reset();

  sti();

  /* Aborts are not done well. . . */
  aha152x_done( code << 16 );

  return 0;
}

int aha152x_reset()
{
#if defined( DEBUG_RESET )
  printk("aha152x: reset(), resetting ports, SCSI RESET OUT\n");
#endif

  SETPORT(SCSISEQ, SCSIRSTO);
  do_pause(5);
  SETPORT(SCSISEQ, 0);

  /* disable interrupts */
  SETPORT( DMACNTRL0, 0 );

  SETPORT(SCSISEQ, 0);

  SETPORT(SXFRCTL1, 0);
  SETPORT(SCSISIG, 0);
  SETPORT(SCSIRATE, 0);

  /* clear all interrupt conditions */
  SETPORT(SSTAT0, 0x7f);
  SETPORT(SSTAT1, 0xef);

  SETPORT(SSTAT4, SYNCERR|FWERR|FRERR);

  SETPORT(DMACNTRL0, 0);
  SETPORT(DMACNTRL1, 0);

  SETPORT(BRSTCNTRL, 0xf1);

  SETPORT(DMACNTRL0, RSTFIFO);

  /* clear channel 0 and transfer count */
  SETPORT(SXFRCTL0, CLRCH1|CLRSTCNT);
  SETPORT(SXFRCTL0, CH1);

  /* enable interrupts, but don't expect any */
  SETPORT( SIMODE0, 0);
  SETPORT( SIMODE1, 0);
  SETPORT( DMACNTRL0, INTEN );

  return 0;
}

int aha152x_biosparam( int size, int dev, int *info_array )
{
#if defined(DEBUG_RACE)
  enter_driver("biosparam");
#else
#if defined(DEBUG_BIOSPARAM)
  printk("\naha152x: biosparam(), ");
#endif
#endif

#ifdef DEBUG_BIOSPARAM
  printk("dev=%x, size=%d, ", dev, size);
#endif
  
/* I took this from other SCSI drivers, since it provides
   the correct data for my devices. */
  info_array[0]=64;
  info_array[1]=32;
  info_array[2]=size>>11;

#ifdef DEBUG_BIOSPARAM
  printk("bios geometry: head=%d, sec=%d, cyl=%d\n",
         info_array[0], info_array[1], info_array[2]);
  printk("WARNING: check if the bios geometry is correct.\n");
#endif

#if defined(DEBUG_RACE)
  leave_driver("biosparam");
#endif
  return 0;
}

void aha152x_done( int error )
{
#if defined(DEBUG_DONE)
  printk("\naha152x: done(), ");
  disp_ports();
#endif

  if (in_command)
    {
#if defined(DEBUG_DONE)
      printk("done(%x), ", error);
#endif
      in_command = 0;
      SETPORT( PORTA, 0 );		/* turn led off */

      SETPORT( SIMODE0, 0);
      SETPORT( SIMODE1, 0);

#if defined(DEBUG_PHASES)
      printk("BUS FREE loop, ");
#endif
      while( TESTLO( SSTAT1, BUSFREE ) )
        ;
#if defined(DEBUG_PHASES)
      printk("BUS FREE\n");
#endif

      current_SC->result = error;
      if(current_SC->scsi_done)
        {
#if defined(DEBUG_DONE)
          printk("calling scsi_done, ");
#endif
          current_SC->scsi_done( current_SC );
#if defined(DEBUG_DONE)
          printk("done returned, ");
#endif
        }
      else
        panic( "aha152x: current_SC->scsi_done() == NULL" );
    }
  else
    panic( "aha152x: done() called outside of command\n" );
}

void aha152x_intr( int irqno )
{
  int done=0, phase;

#if defined(DEBUG_RACE)
  enter_driver("intr");
#else
#ifdef DEBUG_INTR
  printk("\naha152x: intr(), ");
#endif
#endif

  /* no more interrupts from the controller, while we busy.
     INTEN has to be restored, when we're ready to leave
     intr(). To avoid race conditions we have to return
     immediately afterwards. */
  CLRBITS( DMACNTRL0, INTEN);
  sti();

  if(!in_command)
    {
      disp_ports();
      panic("aha152x: spurious interrupt.\n");
    }

#if defined(DEBUG_INTR)
  disp_ports();
#endif

  if (current_SC->SCp.phase & aborted)
    {
#if defined(DEBUG_PHASES)
      printk("ABORT, ");
#endif
#if defined(DEBUG_INTR)
      if (current_SC->SCp.phase & (in_other | disconnected))
        printk( "aborted (%s) = %d, ",
                current_SC->SCp.phase & in_other ? "in_other" : "disconnected",
                current_SC->result );
      else
        printk( "aborted = %d, ", current_SC->result );
#endif

#if defined(DEBUG_RACE)
      leave_driver("(2) intr");
#endif
      SETPORT( SIMODE0, 0);
      SETPORT( SIMODE1, 0);
      SETBITS( DMACNTRL0, INTEN);

      if (current_SC->SCp.phase & (in_other | disconnected))
        {
           aha152x_reset();
           aha152x_done( DID_RESET << 16 );
        }
      else
        aha152x_done( current_SC->result << 16 );

      return;
    }
 
  if(current_SC->SCp.phase & in_selection)
    {
      if( TESTLO( SSTAT1, SELTO ) )
        /* no timeout */
        if( TESTHI( SSTAT0, SELDO ) )
          {
#if defined(CHECK_PASSING_BUSFREE)
/* The documentation suggests this to catch a passing bus free phase.
   Should do without it... */
     
            /* clear BUS FREE interrupt */
            SETPORT( SSTAT1, CLRBUSFREE);

            /* Disable SELECTION OUT sequence */
            CLRBITS(SCSISEQ, ENSELO|ENAUTOATNO );

            /* Disable SELECTION OUT DONE interrupt */
            CLRBITS(SIMODE0, ENSELDO);
            CLRBITS(SIMODE1, ENSELTIMO);

            if( TESTLO(SSTAT0, SELDO) )
              {
                printk("passing bus free condition, ");

#if defined(DEBUG_RACE)
        	leave_driver("(3) intr");
#endif
                aha152x_done( DID_NO_CONNECT << 16 );
        	return;
              }
#else
            /* Disable SELECTION OUT sequence */
            SETPORT(SCSISEQ, ENAUTOATNP );
#endif
#if defined(DEBUG_SELECTION) || defined(DEBUG_PHASES)
            printk("SELDO (SELID=%x), ", GETPORT(SELID));
#endif

            /* selection was done */
            SETPORT( SSTAT0, CLRSELDO );

            current_SC->SCp.phase = in_other;

#if defined(DEBUG_RACE)
            leave_driver("(4) intr");
#endif

	    SETPORT( SCSISIG, P_MSGO );

            SETPORT( SIMODE0, 0 );
            SETPORT( SIMODE1, ENREQINIT );
            SETBITS( DMACNTRL0, INTEN);
            return;
          }
        else
          {
            disp_ports();
            panic("aha152x: neither timeout nor selection\007\n");
          }
      else
        {
#if defined(DEBUG_SELECTION) || defined(DEBUG_PHASES)
          printk("SELTO, ");
#endif
          /* timeout */
          SETPORT( SSTAT1, CLRSELTIMO );

          SETPORT( SIMODE0, 0 );
          SETPORT( SIMODE1, 0 );
          SETBITS( DMACNTRL0, INTEN );
#if defined(DEBUG_RACE)
          leave_driver("(5) intr");
#endif
          if( TESTLO( SSTAT0, SELINGO ) )
            /* ARBITRATION not won */
            aha152x_done( DID_BUS_BUSY << 16 );
          else
            /* ARBITRATION won, but SELECTION failed */
            aha152x_done( DID_NO_CONNECT << 16 );
          return;
        }
    }

  /* enable interrupt, when target leaves current phase */
  phase = getphase();
  SETPORT(SSTAT1, CLRPHASECHG);

  /* information transfer phase */
  switch( phase )
    {
    case P_MSGO:                                               /* MESSAGE OUT */
      {
        unsigned char message;

#if defined(DEBUG_INTR) || defined(DEBUG_MSGO) || defined(DEBUG_PHASES)
        printk("MESSAGE OUT, ");
#endif

        /* If we didn't identify yet, do it. Otherwise there's nothing to do,
           but reject (perhaps one could do as NOP as well) */
        if( !(current_SC->SCp.phase & sent_ident))
          {
             message=IDENTIFY(RECONNECT,current_SC->lun);
#if defined(DEBUG_MSGO)
             printk("IDENTIFY (reconnect=%s;lun=%d), ", 
                    RECONNECT ? "enabled" : "disabled", current_SC->lun);
#endif
          }
        else
          {
             message=MESSAGE_REJECT;
#if defined(DEBUG_MSGO)
             printk("REJECT, ");
#endif
          }
          
        CLRSETBITS( SXFRCTL0, ENDMA, SPIOEN);

        SETPORT( SIMODE0, ENSPIORDY );
        SETPORT( SIMODE1, ENPHASEMIS );

        /* wait for data latch to become ready or a phase change */
        while( TESTLO( DMASTAT, INTSTAT ) )
          ;

        if( TESTLO( SSTAT0, SPIORDY ) )
          {
            disp_ports();
            panic("aha152x: couldn't send message.\n");
          }

        /* Leave MESSAGE OUT after transfer */
        SETPORT( SSTAT1, CLRATNO);

        SETPORT( SCSIDAT, message );
        if(message!=MESSAGE_REJECT)
          current_SC->SCp.phase |= sent_ident;

        CLRBITS( SXFRCTL0, SPIOEN);
      }
      break;

    case P_CMD:                                          /* COMMAND phase */
#if defined(DEBUG_INTR) || defined(DEBUG_CMD) || defined(DEBUG_PHASES)
      printk("COMMAND, ");
#endif
      if( !(current_SC->SCp.sent_command) )
        {

          SETPORT(SIMODE0, 0);
          SETPORT(SIMODE1, ENPHASEMIS|ENREQINIT);

#if defined(DEBUG_CMD)
          printk("waiting for REQINIT, ");
#endif
          while( TESTLO( DMASTAT, INTSTAT ) )
            ;

#if defined(DEBUG_CMD)
          if( TESTLO( SSTAT1, REQINIT ) )
            {
              disp_ports();
              if( TESTHI(SSTAT1, PHASEMIS) )
                panic("PHASEMIS while waiting for REQINIT, ");
              else
                panic("no PHASEMIS, no REQINIT, ");
            }
          else
            printk("REQINIT, ");
#endif
          if(GETPORT(FIFOSTAT))
            {
              printk("%d bytes left in FIFO, ", GETPORT(FIFOSTAT));
              disp_ports();
              panic("FIFO should be empty");
            }

          SETPORT(DMACNTRL0, WRITE_READ|RSTFIFO);
          SETPORT(DMACNTRL0, ENDMA|WRITE_READ);

          SETPORT(SXFRCTL0, CH1|CLRSTCNT|CLRCH1 );
          SETPORT(SXFRCTL0, SCSIEN|DMAEN|CH1);
   
          SETPORT( SIMODE0, 0 );
          SETPORT( SIMODE1, ENPHASEMIS );
  
#if defined(DEBUG_CMD)
          printk("waiting, ");
#endif
          /* wait for FIFO to get empty */
          while( TESTLO ( DMASTAT, DFIFOEMP|INTSTAT ) )
            ;
  
          if( TESTHI( SSTAT1, PHASEMIS ) )
            {
              disp_ports();
              panic("aha152x: target left COMMAND phase.\n");
            }

#if defined(DEBUG_CMD)
          printk("DFIFOEMP, outsw (%d words), ",
                 COMMAND_SIZE(current_SC->cmnd[0])>>1);
          disp_ports();
#endif
  
      	  outsw( &current_SC->cmnd,
                 COMMAND_SIZE(current_SC->cmnd[0])>>1,
                 DATAPORT );

#if defined(DEBUG_CMD)
          printk("FCNT=%d, STCNT=%d, ", GETPORT(FIFOSTAT), GETSTCNT() );
          disp_ports();
#endif

#ifdef 0
          /* wait for FIFO to get empty */
          while( TESTLO ( DMASTAT, DFIFOEMP ) )
            ;
#endif

          /* wait for SCSI FIFO to get empty.
             very important to send complete commands. */
          while( TESTLO ( SSTAT2, SEMPTY ) )
            ;

          CLRBITS(SXFRCTL0, SCSIEN|DMAEN);
#if defined(DEBUG_TIMING)
      if(TESTHI( SXFRCTL0, SCSIEN ))
        printk("(1) SCSIEN stays hi, ");
#endif

          /* transfer can be considered ended, when SCSIEN reads back zero */
          while( TESTHI( SXFRCTL0, SCSIEN ) )
            ;

          CLRBITS(DMACNTRL0, ENDMA);

#if defined(DEBUG_CMD) || defined(DEBUG_INTR)
          printk("sent %d/%d command bytes, ", GETSTCNT(),
                 COMMAND_SIZE(current_SC->cmnd[0]));
#endif

        }
      else
        {
          disp_ports();
          panic("aha152x: Nothing to sent while in COMMAND OUT.\n");
        }
      break;

    case P_MSGI:                                          /* MESSAGE IN phase */
#if defined(DEBUG_INTR) || defined(DEBUG_MSGI) || defined(DEBUG_PHASES)
      printk("MESSAGE IN, ");
#endif
      SETPORT( SXFRCTL0, CH1|SPIOEN);

      SETPORT( SIMODE0, ENSPIORDY);
      SETPORT( SIMODE1, ENREQINIT|ENPHASEMIS|ENBUSFREE);

      SETBITS( SXFRCTL0, SCSIEN );

#if defined(DEBUG_MSGI)
      printk("waiting for message, ");
#endif
      while( TESTLO( DMASTAT, INTSTAT ) )
        {
#if defined(DEBUG_MSGI)
          disp_ports();
#endif
        }

#ifdef 0
{
  /* don't ask me, why SPIORDY stays low... */
  int the_time = jiffies + 10;
  while(TESTLO( SSTAT0, SPIORDY ) && (jiffies<the_time) )
    ;
}
#endif

#if defined(DEBUG_MSGI)
      if(TESTLO( SSTAT0, SPIORDY ) )
        printk("SPIORDY low ignored, ");
#endif


      current_SC->SCp.Message = GETPORT( SCSIDAT );
      switch(current_SC->SCp.Message)
        {
        case DISCONNECT:
#if defined(DEBUG_MSGI)
          printk("target disconnected, ");
#endif
          current_SC->SCp.Message = 0;
          current_SC->SCp.phase   |= disconnected;
#if defined(DEBUG_MSGI)
          if(!RECONNECT)
            {
              disp_ports();
              panic("aha152x: target was not allowed to disconnect.\n");
            }
#endif
          break;
            
        case COMMAND_COMPLETE:
#if defined(DEBUG_MSGI)
          printk("inbound message ( COMMAND COMPLETE ), ");
#endif
          done++;
          break;

        case MESSAGE_REJECT:
#if defined(DEBUG_MSGI)
          printk("inbound message ( MESSAGE REJECT ), ");
#endif
          break;

/* my IBM drive responds to the first command with a extended message.
   I just ignore it... */
        case EXTENDED_MESSAGE:
          {
            int           i, code;

#if defined(DEBUG_MSGI)
            printk("inbound message ( EXTENDED MESSAGE ), ");
#endif
#ifdef 0
            SETBITS( SXFRCTL0, SCSIEN );
#endif

            while( TESTLO( SSTAT1, SPIORDY) )
              ;

            i=GETPORT(SCSIDAT);

#if defined(DEBUG_MSGI)
            printk("length (%d), ", i);
#endif

            while( TESTLO( SSTAT1, SPIORDY) )
              ;

#if defined(DEBUG_MSGI)
            printk("code ( ");
#endif

            code = GETPORT(SCSIDAT);

#if defined(DEBUG_MSGI)
            switch( code )
              {
              case 0x00:
                printk("MODIFY DATA POINTER ");
	        break;
              case 0x01:
                printk("SYNCHRONOUS DATA TRANSFER REQUEST ");
	        break;
              case 0x02:
                printk("former EXTENDED IDENTIFY ");
	        break;
              case 0x03:
                printk("WIDE DATA TRANSFER REQUEST ");
	        break;
              default:
                if( code & 0x80 )
                  printk("reserved (%d) ", code );
                else
                  printk("vendor specific (%d) ", code);
                break;
              }
            printk(" ), data ( ");
#endif

            while( --i )
              {
                while( TESTLO( SSTAT1, SPIORDY) )
                  ;
                code=GETPORT(SCSIDAT);
#if defined(DEBUG_MSGI)
                printk("%x ", GETPORT(SCSIDAT)  );
#endif
              }
#if defined(DEBUG_MSGI)
            printk(" ), ");
#endif

#ifdef 0 
            CLRBITS( SXFRCTL0, SCSIEN );
#if defined(DEBUG_TIMING)
      if(TESTHI( SXFRCTL0, SCSIEN ))
        printk("(2) SCSIEN stays hi, ");
#endif
            while( TESTHI( SXFRCTL0, SCSIEN ) )
              ;
#endif
          }
          break;

        default:
#if defined(DEBUG_MSGI)
          printk("inbound message %x, ", current_SC->SCp.Message);
#endif
          break;
 
        }
 
      CLRBITS( SXFRCTL0, SCSIEN );
#if defined(DEBUG_TIMING)
      if(TESTHI( SXFRCTL0, SCSIEN ))
        printk("(3) SCSIEN stays hi, ");
#endif
      while( TESTHI( SXFRCTL0, SCSIEN ) )
        ;
       
      CLRBITS( SXFRCTL0, SPIOEN);
      break;

    case P_STATUS:                                         /* STATUS IN phase */
#if defined(DEBUG_STATUS) || defined(DEBUG_INTR) || defined(DEBUG_PHASES)
      printk("STATUS, ");
#endif
      SETPORT( SXFRCTL0, CH1|SPIOEN);

      SETPORT( SIMODE0, ENSPIORDY );
      SETPORT( SIMODE1, ENPHASEMIS );


      SETBITS( SXFRCTL0, SCSIEN );
#if defined(DEBUG_STATUS)
      printk("waiting for status, ");
#endif
#if defined(DEBUG_STATUS)
      disp_ports();
#endif
      while( TESTLO( DMASTAT, INTSTAT ) )
        ;

      if(TESTLO( SSTAT0, SPIORDY ) )
        {
          disp_ports();
          panic("aha152x: passing STATUS phase.\n");
        }

#ifdef 0
      SETBITS( SSTAT0, CLRSPIORDY );
#endif


      current_SC->SCp.Status = GETPORT( SCSIDAT );
#if defined(DEBUG_STATUS)
      printk("inbound status ");
      print_status( current_SC->SCp.Status );
      printk(", ");
#endif
      CLRBITS( SXFRCTL0, SCSIEN );
#if defined(DEBUG_TIMING)
      if(TESTHI( SXFRCTL0, SCSIEN ))
        printk("(4) SCSIEN stays hi, ");
#endif
      while( TESTHI( SXFRCTL0, SCSIEN ) )
        ;
        
      CLRBITS( SXFRCTL0, SPIOEN);
      break;

    case P_DATAI:                                            /* DATA IN phase */
      {
        int fifodata, data_count, done;

#if defined(DEBUG_DATAI) || defined(DEBUG_INTR) || defined(DEBUG_PHASES)
        printk("DATA IN, ");
#endif
        SETPORT(SIMODE0, 0);
        SETPORT(SIMODE1, ENPHASEMIS|ENREQINIT);

#if defined(DEBUG_DATAI)
        printk("waiting for REQINIT, ");
#endif
        while( TESTLO( DMASTAT, INTSTAT ) )
          ;

#if defined(DEBUG_DATAI)
        if(TESTLO( SSTAT1, REQINIT ) )
          if( TESTHI(SSTAT1, PHASEMIS) )
            printk("PHASEMIS while waiting for REQINIT, ");
          else
            printk("no PHASEMIS, no REQINIT, ");
#endif
        SETPORT( SIMODE0, 0 );
        SETPORT( SIMODE1, ENPHASEMIS );

        SETPORT(DMACNTRL0, ENDMA);

        SETPORT(SXFRCTL0, CH1|CLRSTCNT|CLRCH1 );
        SETPORT(SXFRCTL0, SCSIEN|DMAEN|CH1);

        /* done is set when the FIFO is empty after the target left DATA IN */
        done=0;
      
        /* while the target stays in DATA to transfer data */
        while ( !done ) 
          {
#if defined(DEBUG_DATAI)
            printk("expecting data, ");
#endif
            /* wait for PHASEMIS or full FIFO */
            while( TESTLO ( DMASTAT, DFIFOFULL|INTSTAT ) )
               ;

            if( TESTHI( DMASTAT, DFIFOFULL ) )
	      /* fifo contains 132, when full. */
              fifodata=132;
            else
              {
		/* wait for SCSI fifo to get empty */
		while( TESTLO( SSTAT2, SEMPTY ) )
                  ;

                /* rest of data in FIFO */
                fifodata=GETPORT(FIFOSTAT);
#if defined(DEBUG_DATAI)
                printk("last transfer, ");
#endif
                done=1;
              }
  
#if defined(DEBUG_DATAI)
            printk("fifodata=%d, ", fifodata);
#endif

            while( fifodata )
              {
                data_count=fifodata;
  
                /* limit data transfer to size of first sg buffer */
                if (data_count > current_SC->SCp.this_residual)
                  data_count = current_SC->SCp.this_residual;
  
                fifodata -= data_count;

#if defined(DEBUG_DATAI)
                printk("data_count=%d, ", data_count);
#endif
  
                if(data_count == 1)
                  {
                    /* get a single byte in byte mode */
        	    SETBITS(DMACNTRL0, _8BIT );
        	    *current_SC->SCp.ptr++ = GETPORT( DATAPORT );
        	    current_SC->SCp.this_residual--;
        	  }
                else
                  {
                    CLRBITS(DMACNTRL0, _8BIT );
        	    data_count >>= 1; /* Number of words */
        	    insw( current_SC->SCp.ptr, data_count, DATAPORT );
#if defined(DEBUG_DATAI)
/* show what comes with the last transfer */
		    if(done)
                      {
                        int           i;
                        unsigned char *data;

                        printk("data on last transfer (%d bytes: ",
                               2*data_count);
                        data = (unsigned char *) current_SC->SCp.ptr;
                        for( i=0; i<2*data_count; i++)
                          printk("%2x ", *data++);
                        printk("), ");
                      }
#endif
        	    current_SC->SCp.ptr           += 2 * data_count;
        	    current_SC->SCp.this_residual -= 2 * data_count;
        	  }
              
    
                /* if this buffer is full and there are more buffers left */
                if (!current_SC->SCp.this_residual)
          	  if(current_SC->SCp.buffers_residual)
                    {
           	      /* advance to next buffer */
        	      current_SC->SCp.buffers_residual--;
                      current_SC->SCp.buffer++;
                      current_SC->SCp.ptr =
                        current_SC->SCp.buffer->address;
                      current_SC->SCp.this_residual =
                        current_SC->SCp.buffer->length;
                    } 
                  else
                    {
                      if(fifodata)
                        printk("aha152x: more data from target than expected\n");
                      done=1;
                      break;
                    }
              }
#if defined(DEBUG_DATAI)
            printk("fifo empty, ");
#endif
          } 

#if defined(DEBUG_DATAI)
	if(current_SC->SCp.buffers_residual || current_SC->SCp.this_residual)
          printk("left buffers (buffers=%d, bytes=%d), ",
                 current_SC->SCp.buffers_residual, 
                 current_SC->SCp.this_residual);
#endif

        CLRBITS(SXFRCTL0, SCSIEN|DMAEN);
#if defined(DEBUG_TIMING)
      if(TESTHI( SXFRCTL0, SCSIEN ))
        printk("(5) SCSIEN stays hi, ");
#endif

        /* transfer can be considered ended, when SCSIEN reads back zero */
        while( TESTHI( SXFRCTL0, SCSIEN ) )
          ;
        CLRBITS(DMACNTRL0, ENDMA );

#if defined(DEBUG_DATAI) || defined(DEBUG_INTR)
        printk("got %d bytes, ", GETSTCNT());
#endif

        current_SC->SCp.have_data_in++;
      }
      break;

    case P_DATAO:                                           /* DATA OUT phase */
      {
        int data_count;

#if defined(DEBUG_DATAO) || defined(DEBUG_INTR) || defined(DEBUG_PHASES)
        printk("DATA OUT, ");
#endif

        SETPORT(SIMODE0, 0);
        SETPORT(SIMODE1, ENPHASEMIS|ENREQINIT);

#if defined(DEBUG_DATAO)
        printk("got data to send (bytes=%d, buffers=%d), ",
                    current_SC->SCp.this_residual,
                    current_SC->SCp.buffers_residual );
        printk("waiting for REQINIT, ");
#endif
        while( TESTLO( DMASTAT, INTSTAT ) )
          ;

#if defined(DEBUG_DATAO)
        if( TESTLO( SSTAT1, REQINIT ) )
          if( TESTHI(SSTAT1, PHASEMIS) )
            printk("PHASEMIS while waiting for REQINIT, ");
          else
            printk("no PHASEMIS, no REQINIT, ");
        else
          printk("REQINIT, ");
        if(GETPORT(FIFOSTAT))
          {
            printk("%d left in FIFO, ", GETPORT(FIFOSTAT));
            disp_ports();
            panic("FIFO should be empty");
          }
#endif

        SETPORT(DMACNTRL0, WRITE_READ|RSTFIFO);
        SETPORT(DMACNTRL0, ENDMA|WRITE_READ);

        SETPORT(SXFRCTL0, CH1|CLRSTCNT|CLRCH1 );
        SETPORT(SXFRCTL0, SCSIEN|DMAEN|CH1);
 
        SETPORT( SIMODE0, 0 );
        SETPORT( SIMODE1, ENPHASEMIS );

        /* while current buffer is not empty or
           there are more buffers to transfer */
        while(current_SC->SCp.this_residual ||
              current_SC->SCp.buffers_residual)
          {
#if defined(DEBUG_DATAO)
            printk("sending data (left: bytes=%d, buffers=%d), ",
                    current_SC->SCp.this_residual,
                    current_SC->SCp.buffers_residual);
            printk("waiting, ");
#endif
            /* wait for FIFO to get empty */
            while( TESTLO ( DMASTAT, DFIFOEMP|INTSTAT ) )
               ;

            if( TESTHI( SSTAT1, PHASEMIS ) )
              {
                disp_ports();
                panic("aha152x: target left DATA OUT phase.\n");
              }

#if defined(DEBUG_DATAO)
            printk("DFIFOEMP, transfered (%d bytes), ",
                    GETSTCNT() );
#endif

            /* transfer rest of buffer, but max. 128 byte */
            data_count = current_SC->SCp.this_residual > 128 ?
                         128 : current_SC->SCp.this_residual ;

#if defined(DEBUG_DATAO)
            printk("data_count=%d, ", data_count);
#endif
  
            if(data_count == 1)
              {
                /* put a single byte in byte mode */
                SETBITS(DMACNTRL0, _8BIT );
        	SETPORT(DATAPORT, *current_SC->SCp.ptr++);
                current_SC->SCp.this_residual--;
              }
            else
              {
                CLRBITS(DMACNTRL0, _8BIT );
        	data_count >>= 1; /* Number of words */
        	outsw( current_SC->SCp.ptr, data_count, DATAPORT );
        	current_SC->SCp.ptr           += 2 * data_count;
        	current_SC->SCp.this_residual -= 2 * data_count;
              }
              
            /* if this buffer is empty and there are more buffers left */
            if (!current_SC->SCp.this_residual &&
                 current_SC->SCp.buffers_residual)
              {
                 /* advance to next buffer */
        	 current_SC->SCp.buffers_residual--;
        	 current_SC->SCp.buffer++;
        	 current_SC->SCp.ptr =
                   current_SC->SCp.buffer->address;
        	 current_SC->SCp.this_residual =
                   current_SC->SCp.buffer->length;
              }
          }

#ifdef 0
        /* wait for FIFO to get empty */
        while( TESTLO( DMASTAT, DFIFOEMP ) )
          ;
#endif

        /* wait for SCSI fifo to get empty */
        while( TESTLO( SSTAT2, SEMPTY ) )
          ;

#if defined(DEBUG_DATAO)
        printk("left data (bytes=%d, buffers=%d) ",
               current_SC->SCp.this_residual,
               current_SC->SCp.buffers_residual);
#endif
        CLRBITS(SXFRCTL0, SCSIEN|DMAEN);
#if defined(DEBUG_TIMING)
      if(TESTHI( SXFRCTL0, SCSIEN ))
        printk("(6) SCSIEN stays hi, ");
#endif
 
        /* transfer can be considered ended, when SCSIEN reads back zero */
        while( TESTHI( SXFRCTL0, SCSIEN ) )
          ;

        CLRBITS(DMACNTRL0, ENDMA);

#if defined(DEBUG_DATAO) || defined(DEBUG_INTR)
        printk("sent %d data bytes, ", GETSTCNT() );
#endif
      }
      break;

    case 1:		/* BUSFREE */
#if defined(DEBUG_RACE)
      leave_driver("(6) intr");
#endif
#if defined(DEBUG_PHASE)
      printk("unexpected BUS FREE, ");
#endif
      aha152x_done( DID_ERROR << 16 );		/* Don't know any better */
      return;
      break;

    case 2:		/* RESET IN */
#if defined(DEBUG_RACE)
      leave_driver("(7) intr");
#endif
#if defined(DEBUG_PHASE)
      printk("RESET IN, ");
#endif
      aha152x_reset();
      aha152x_done( DID_RESET << 16 );
      return;
      break;

    case 3:		/* parity error in DATA phase */
#if defined(DEBUG_RACE)
      leave_driver("(8) intr");
#endif
#if defined(DEBUG_PHASE)
      printk("PARITY error in DATA phase, ");
#endif
      aha152x_done( DID_PARITY << 16 );
      return;
      break;

    default:
#if defined(DEBUG_INTR)
      printk("unexpected phase, ");
#endif
      break;
    }

  if(done)
    {
#if defined(DEBUG_INTR)
      printk("command done.\n");
#endif
#if defined(DEBUG_RACE)
      leave_driver("(9) intr");
#endif
      SETPORT( SIMODE0, 0 );
      SETPORT( SIMODE1, 0 );
      SETBITS( DMACNTRL0, INTEN );

      /* done() will be called while interrupts are enabled.
         Perhaps this will cause stack problems in case of heavy load,
         but since I don't know if done() returns, I had to do it like this.

         I should do a closer look into scsi.c...
      */

      aha152x_done(   (current_SC->SCp.Status  & 0xff)
                    | ( (current_SC->SCp.Message & 0xff) << 8)
                    | ( DID_OK << 16) );

#if defined(DEBUG_RACE)
      printk("done returned (DID_OK: Status=%x; Message=%x).\n",
             current_SC->SCp.Status, current_SC->SCp.Message);
#endif
      return;
    }

  SETPORT( SIMODE0, 0 );
  SETPORT( SIMODE1, ENPHASEMIS );
#if defined(DEBUG_INTR)
  disp_enintr();
#endif
#if defined(DEBUG_RACE)
  leave_driver("(10) intr");
#endif

  SETBITS( DMACNTRL0, INTEN);
  return;
}

static void disp_ports()
{
#if !defined(SKIP_PORTS)
  int s;

  printk("\n%s: ", in_command ? "busy" : "waiting");

  s=GETPORT(SCSISEQ);
  printk("SCSISEQ ( ");
  if( s & TEMODEO ) 	printk("TARGET MODE ");
  if( s & ENSELO )	printk("SELO ");
  if( s & ENSELI )	printk("SELI ");
  if( s & ENRESELI )	printk("RESELI ");
  if( s & ENAUTOATNO )	printk("AUTOATNO ");
  if( s & ENAUTOATNI )	printk("AUTOATNI ");
  if( s & ENAUTOATNP )	printk("AUTOATNP ");
  if( s & SCSIRSTO )	printk("SCSIRSTO ");
  printk(");");

  printk(" SCSISIG ( ");
  s=GETPORT(SCSISIG);
  switch(s & P_MASK)
    {
    case P_DATAO:	printk("DATA OUT");
        		break;
    case P_DATAI:	printk("DATA IN");
        		break;
    case P_CMD:		printk("COMMAND"); 
        		break;
    case P_STATUS:	printk("STATUS"); 
        		break;
    case P_MSGO:	printk("MESSAGE OUT");
        		break;
    case P_MSGI:	printk("MESSAGE IN");
        		break;
    default:            printk("*illegal*");
        		break;
    }
  
  printk(" ); ");

  printk("INTSTAT ( %s ); ", TESTHI(DMASTAT, INTSTAT) ? "hi" : "lo");

  printk("SSTAT ( ");
  s=GETPORT(SSTAT0);
  if( s & TARGET ) 	printk("TARGET ");
  if( s & SELDO ) 	printk("SELDO ");
  if( s & SELDI ) 	printk("SELDI ");
  if( s & SELINGO ) 	printk("SELINGO ");
  if( s & SWRAP ) 	printk("SWRAP ");
  if( s & SDONE )	printk("SDONE ");
  if( s & SPIORDY )	printk("SPIORDY ");
  if( s & DMADONE )	printk("DMADONE ");

  s=GETPORT(SSTAT1);
  if( s & SELTO ) 	printk("SELTO ");
  if( s & ATNTARG ) 	printk("ATNTARG ");
  if( s & SCSIRSTI ) 	printk("SCSIRSTI ");
  if( s & PHASEMIS ) 	printk("PHASEMIS ");
  if( s & BUSFREE ) 	printk("BUSFREE ");
  if( s & SCSIPERR )	printk("SCSIPERR ");
  if( s & PHASECHG )	printk("PHASECHG ");
  if( s & REQINIT )	printk("REQINIT ");
  printk("); ");


  printk("SSTAT ( ");

  s=GETPORT(SSTAT0) & GETPORT(SIMODE0);

  if( s & TARGET ) 	printk("TARGET ");
  if( s & SELDO ) 	printk("SELDO ");
  if( s & SELDI ) 	printk("SELDI ");
  if( s & SELINGO ) 	printk("SELINGO ");
  if( s & SWRAP ) 	printk("SWRAP ");
  if( s & SDONE )	printk("SDONE ");
  if( s & SPIORDY )	printk("SPIORDY ");
  if( s & DMADONE )	printk("DMADONE ");

  s=GETPORT(SSTAT1) & GETPORT(SIMODE1);

  if( s & SELTO ) 	printk("SELTO ");
  if( s & ATNTARG ) 	printk("ATNTARG ");
  if( s & SCSIRSTI ) 	printk("SCSIRSTI ");
  if( s & PHASEMIS ) 	printk("PHASEMIS ");
  if( s & BUSFREE ) 	printk("BUSFREE ");
  if( s & SCSIPERR )	printk("SCSIPERR ");
  if( s & PHASECHG )	printk("PHASECHG ");
  if( s & REQINIT )	printk("REQINIT ");
  printk("); ");

  printk("SXFRCTL0 ( ");

  s=GETPORT(SXFRCTL0);
  if( s & SCSIEN )	printk("SCSIEN ");
  if( s & DMAEN )	printk("DMAEN ");
  if( s & CH1 )		printk("CH1/CH2 ");
  if( s & CLRSTCNT )	printk("CLRSTCNT ");
  if( s & SPIOEN )	printk("SPIOEN ");
  if( s & CLRCH1 )	printk("CLRCH1 ");
  printk("); ");

#ifdef 0
  printk("SXFRCTL1 ( ");

  s=GETPORT(SXFRCTL1);
  if( s & BITBUCKET )	printk("BITBUCKET ");
  if( s & SWRAPEN )	printk("SWRAPEN ");
  if( s & ENSPCHK )	printk("ENSPCHK ");
  if( s & ENSTIMER )	printk("ENSTIMER ");
  if( s & BYTEALIGN )	printk("BYTEALIGN ");
  printk("); ");
#endif

  
  printk("SIGNAL ( ");

  s=GETPORT(SCSISIG);
  if( s & ATNI )	printk("ATNI ");
  if( s & SELI )	printk("SELI ");
  if( s & SELI )	printk("SELI ");
  if( s & BSYI )	printk("BSYI ");
  if( s & REQI )	printk("REQI ");
  if( s & ACKI )	printk("ACKI ");
  printk("); ");

#ifdef 0
  printk("SSTAT2 ( ");

  s=GETPORT(SSTAT2);
  if( s & SOFFSET)	printk("SOFFSET ");
  if( s & SEMPTY)	printk("SEMPTY ");
  if( s & SFULL)	printk("SFULL ");
  printk("); ");


  printk("SFCNT ( %d ); ", s & SFCNT);


  printk("SSTAT4 ( ");
  s=GETPORT(SSTAT4);
  if( s & SYNCERR)	printk("SYNCERR ");
  if( s & FWERR)	printk("FWERR ");
  if( s & FRERR)	printk("FRERR ");
  printk("); ");
#endif

  printk("FCNT ( %d ); ", GETPORT(FIFOSTAT) );

  printk("DMACNTRL0 ( ");
  s=GETPORT(DMACNTRL0);
  if( s & ENDMA )	printk("ENDMA ");
  printk( "%s ", s & _8BIT ? "8BIT"  : "16BIT");
  printk( "%s ", s & DMA   ? "DMA"   : "PIO");
  printk( "%s ", s & WRITE_READ ? "WRITE" : "READ");
  if( s & INTEN )	printk("INTEN ");
  if( s & RSTFIFO )	printk("RSTFIFO ");
  if( s & SWINT )	printk("SWINT ");
  printk("); ");


#ifdef 0
  printk("DMACNTRL1 ( ");

  s=GETPORT(DMACNTRL1);
  if( s & PWRDWN )	printk("PWRDN ");
  printk("); ");


  printk("STK ( %d ); ", s & 0xf);

  printk("DMASTAT (");
  s=GETPORT(DMASTAT);
  if( s & ATDONE )	printk("ATDONE ");
  if( s & WORDRDY )	printk("WORDRDY ");
  if( s & DFIFOFULL )	printk("DFIFOFULL ");
  if( s & DFIFOEMP )	printk("DFIFOEMP ");
  printk(")");

#endif

  printk("\n");
#endif
}

#if defined(DEBUG_INTR)
static void disp_enintr()
{
  int s;

  printk("enabled interrupts ( ");
  
  s=GETPORT(SIMODE0);
  if( s & ENSELDO )    printk("ENSELDO ");
  if( s & ENSELDI )    printk("ENSELDI ");
  if( s & ENSELINGO )  printk("ENSELINGO ");
  if( s & ENSWRAP )    printk("ENSWRAP ");
  if( s & ENSDONE )    printk("ENSDONE ");
  if( s & ENSPIORDY )  printk("ENSPIORDY ");
  if( s & ENDMADONE )  printk("ENDMADONE ");

  s=GETPORT(SIMODE1);
  if( s & ENSELTIMO )    printk("ENSELTIMO ");
  if( s & ENATNTARG )    printk("ENATNTARG ");
  if( s & ENPHASEMIS )   printk("ENPHASEMIS ");
  if( s & ENBUSFREE )    printk("ENBUSFREE ");
  if( s & ENSCSIPERR )   printk("ENSCSIPERR ");
  if( s & ENPHASECHG )   printk("ENPHASECHG ");
  if( s & ENREQINIT )    printk("ENREQINIT ");
  printk(")\n");
}
#endif

#if defined(DEBUG_RACE)

static const char *should_leave;
static int in_driver=0;

static void enter_driver(const char *func)
{
  cli();
  printk("aha152x: entering %s() (%x)\n", func, jiffies);
  if(in_driver)
    {
      printk("%s should leave first.\n", should_leave);
      panic("aha152x: already in driver\n");
    }

  in_driver++;
  should_leave=func;
  sti();
}

static void leave_driver(const char *func)
{
  cli();
  printk("\naha152x: leaving %s() (%x)\n", func, jiffies);
  if(!in_driver)
    {
      printk("aha152x: %s already left.\n", should_leave);
      panic("aha152x: %s already left driver.\n");
    }

  in_driver--;
  should_leave=func;
  sti();
}
#endif

