#include <stdio.h>
#include <sys/times.h>
#include <linux/fs.h>

#ifdef USE_VARARGS
#include <varargs.h>
#else
#include <stdarg.h>
#endif

#define NGROUPS 32
#define RLIM_NLIMITS 6
#define MAJOR_NR 3

struct task_struct {
/* these are hardcoded - don't touch */
	long state;		/* -1 unrunnable, 0 runnable, >0 stopped */
	long counter;
	long priority;
	unsigned long signal;
	unsigned long blocked;	/* bitmap of masked signals */
	unsigned long flags;	/* per process flags, defined below */
	int errno;
	int debugreg[8];  /* Hardware debugging registers */
/* various fields */
};

static double
  time_so_far()
{
  clock_t        val;
  struct tms tms;


  if ((val = times(&tms)) == -1)
    perror("times");

  return ((double) val) / ((double) CLK_TCK);
}

#ifdef USE_VARARGS
void panic(va_alist)
  va_dcl
#else
void panic(char *format, ...)
#endif
{
  va_list vp;
#ifdef USE_VARARGS
  char *format;
#endif

  fprintf(stderr, "kbench: ");

#ifdef USE_VARARGS
  va_start(vp);
  format = va_arg (vp, char *);
#else
  va_start(vp, format);
#endif
  vfprintf(stderr, format, vp);
  va_end(va);

  fputc('\n', stderr);

  exit(1);
}

int check_cdrom_media_change(){ return 0; }
int check_scsidisk_media_change(){ return 0; }
int floppy_change(struct buffer_head * bh){ return; }
void invalidate_inodes(dev_t dev){ return; }
void put_super(dev_t dev){ return; }
int revalidate_scsidisk(){ return 0; }
void sync_supers(dev_t dev){ return; }
void sync_inodes(dev_t dev){ return; }
int hd_init(int a, int b){ return a; }
int rd_init(int a, int b){ return a; }


int ramdisk_size = 0;
int nr_free_pages = 0;
int high_memory = 16*1024*1024; /* 16Mb */
unsigned short int int_mem_map[1024];
unsigned short int * mem_map = &int_mem_map[0];

struct task_struct myjob;
struct task_struct * current = &myjob;

struct super_block super_blocks[NR_SUPER];

int schedule(){
  fprintf(stderr,"Schedule");
  exit(1);
}

int free_page(void * page){
  fprintf(stderr,"Free page %x\n", page);
  exit(1);
}

void * __get_free_page(int prior){
  fprintf(stderr,"Get free page %x\n", prior);
  exit(1);
}

int sleep_on(struct wait_queue ** foo){
  fprintf(stderr,"Sleeping...\n");
  sleep(1);
}


int wake_up(struct wait_queue ** foo){
  if((*foo) == NULL) return;
  fprintf(stderr,"Wake up!\n");
}

char test_buffer[1024];
char test_buffer2[1024];
extern struct buffer_head * free_list;

struct blk_dev_struct {
	void (*request_fn)(void);
	struct request * current_request;
};


extern struct blk_dev_struct blk_dev[10];
#ifndef CURRENT
#define CURRENT (blk_dev[MAJOR_NR].current_request)
#endif

struct request {
	int dev;		/* -1 if no request */
	int cmd;		/* READ or WRITE */
	int errors;
	unsigned long sector;
	unsigned long nr_sectors;
	unsigned long current_nr_sectors;
	char * buffer;
	struct task_struct * waiting;
	struct buffer_head * bh;
	struct buffer_head * bhtail;
	struct request * next;
};


void fake_disk_fn(void){
	struct request * req;
	struct buffer_head * bh;

	req = CURRENT;
      repeat:
	if ((bh = req->bh) != NULL) {
		req->bh = bh->b_reqnext;
		bh->b_reqnext = NULL;
		bh->b_uptodate = 1;
		bh->b_lock = 0;
		if ((bh = req->bh) != NULL) {
			req->current_nr_sectors = bh->b_size >> 9;
			if (req->nr_sectors < req->current_nr_sectors) {
				req->nr_sectors = req->current_nr_sectors;
				printk("end_request: buffer-list destroyed\n");
			}
			req->buffer = bh->b_data;
			goto repeat;
		}
	}
	CURRENT = req->next;
	req->dev = -1;
}

main(int argc, char * argv[]){
  struct buffer_head * bh;
  double starttime, endtime, datarate;
  struct file filep;
  struct inode ind;
  int i, j;
  int mb;

  nr_buffers = 0;
  for(i=0; i<1024; i++) mem_map[i] = 1;

  if(argc < 2) exit(0);
  sscanf(argv[1], "%d", &mb);

  free_list = (struct buffer_head *) malloc(sizeof(struct buffer_head));
  free_list->b_prev_free = free_list;
  free_list->b_next_free = free_list;

  for(i=0; i<15000; i++){
    bh = (struct buffer_head *) malloc(sizeof(struct buffer_head));
    bh->b_size = 1024;
    bh->b_dev = 0x301;
    bh->b_data = test_buffer;
    bh->b_blocknr = i;
    nr_buffers++;
    insert_into_queues(bh);
    buffermem++;
  };

  blk_dev_init(0, 0);

  
  filep.f_pos = 0;
  filep.f_reada = 0;
  ind.i_rdev = (MAJOR_NR << 8) | 0x2;  /* Simulate an IDE disk */
  blk_dev[3].request_fn = fake_disk_fn;

  i = 0;
  starttime = time_so_far();
  do{
    block_write(&ind, &filep, test_buffer2, sizeof(test_buffer2));
  } while(filep.f_pos < mb*1000*1024);

  endtime = time_so_far() - starttime;
  datarate = filep.f_pos / endtime;
  fprintf(stderr,"Finished writing, %g seconds, datarate=%g\n", endtime, datarate);
  starttime = time_so_far();

  filep.f_pos = 0;
  filep.f_reada = 0;

  do{
    block_read(&ind, &filep, test_buffer2, sizeof(test_buffer2));
    if((filep.f_pos % 1000) == 0) fprintf(stderr,"%d ", filep.f_pos);
  } while(filep.f_pos < mb*1000*1024);
  endtime = time_so_far() - starttime;
  datarate = filep.f_pos / endtime;
  fprintf(stderr,"Finished reading, %g seconds, datarate = %g\n", endtime, datarate);
  return 0;
}

