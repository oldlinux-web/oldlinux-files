/*
 * Copyright (c) 1987, 1989 University of Maryland
 * Department of Computer Science.  All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

#ifndef fio_h
#define fio_h

/*
 * File I/O: numbers.
 *
 * We deal in fixed format numbers and (FILE *)s here.
 * For pointer I/O, see pio.h.
 *
 * N.B.: These do the `wrong thing' at EOF.  It is imperative
 * that the caller add appropriate `if (feof(fp))' statements.
 */

/*
 * Get one unsigned byte.  Note that this is a proper expression.
 * The reset have more limited contexts, and are therefore OddLy
 * CapItaliseD.
 */
#define	fgetbyte(fp)	(unsigned)getc(fp)

/*
 * Get a two-byte unsigned integer, a three-byte unsigned integer,
 * or a four-byte signed integer.
 */
#define fGetWord(fp, r)	((r)  = (unsigned)getc(fp) << 8,  (r) |= (unsigned)getc(fp))
#define fGet3Byte(fp,r) ((r)  = (unsigned long)getc(fp) << 16, (r) |= (unsigned long)getc(fp) << 8, \
			 (r) |= (unsigned long)getc(fp))
#define fGetLong(fp, r)	((r)  = (unsigned long)getc(fp) << 24, (r) |= (unsigned long)getc(fp) << 16, \
			 (r) |= (unsigned long)getc(fp) << 8,  (r) |= (unsigned long)getc(fp))

/*
 * Fast I/O write (and regular write) macros.
 */
#define	putbyte(fp, r)	((void) putc((r), fp))

#define PutWord(fp, r)	((void) putc((r) >> 8,  fp), \
			 (void) putc((r), fp))
#define Put3Byte(fp, r)	((void) putc((r) >> 16, fp), \
			 (void) putc((r) >> 8, fp), \
			 (void) putc((r), fp))
#define PutLong(fp, r)	((void) putc((r) >> 24, fp), \
			 (void) putc((r) >> 16, fp), \
			 (void) putc((r) >> 8, fp), \
			 (void) putc((r), fp))

/*
 * Function types
 */

#endif
