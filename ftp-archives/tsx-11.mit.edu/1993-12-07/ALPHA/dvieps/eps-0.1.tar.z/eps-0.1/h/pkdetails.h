#ifndef pkdetails_h
#define pkdetails_h

struct cp {
	char	*cp_packet;	/* the beginning of the packet */
	int	cp_type;	/* decoded pre type, see below */
};

struct pk_details {
	char	*pk_ptr;	/* next byte to fetch */
	int	pk_c;		/* most recent byte fetched, if nybbling */
	int	pk_1nyb;	/* true => nybble 1 is next (bits 0..3) */
	char	*pk_base;	/* base of allocated memory */
	int	pk_dyn_f;	/* the dyn_f value */
	int	pk_repeat;	/* the repeat count */
	int	pk_minc;	/* minimum character value */
	int	pk_maxc;	/* maximum character value */
#define MAXSTD	256		/* maximum `standard' character value */
	int	pk_gleft;	/* number of valid glyphs left uninterpreted */
	struct	cp pk_cpack[MAXSTD];	/* for characters in [0..MAXSTD) */
	struct	cp *pk_morec;		/* for characters in [MAXSTD..maxc] */
};

#endif
