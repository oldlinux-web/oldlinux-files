#ifndef Bset_h
#define Bset_h

/* $Header: c:/mctex/imagen/rcs/bset.h 1.1 91/08/05 23:41:08 ROOT_DOS Exp Locker: ROOT_DOS $ */

/* Copyright (c) 1993 Neal Becker
 * All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
*/

/*
$Log:	bset.h $
 * Revision 1.1  91/08/05  23:41:08  ROOT_DOS
 * Initial revision
 * 
*/

void Bset( char* S, int Slen, char* D, int Dlen, int Pos );

void SetBits( int Slen, char* D, int Dlen, int Pos );

#endif





