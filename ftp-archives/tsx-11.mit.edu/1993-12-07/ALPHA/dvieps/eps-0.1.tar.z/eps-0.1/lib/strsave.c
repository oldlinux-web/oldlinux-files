#include "PROTO.h"
/*
 * Copyright (c) 1987, 1989 University of Maryland
 * Department of Computer Science.  All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

/*
 * Save a string in managed memory.
 */

/* char	*malloc(), *realloc(); */
#include <stdlib.h> /* for malloc, realloc */
#include <string.h> /* for strlen */

extern int errno;

#include "types.h"		/* for bcopy */
#include "error.h"

extern char *strsave(register char *s)
{
	register int l = strlen(s) + 1;
	register char *p = (char*)malloc((unsigned) l);

	if (p == 0)
		error(1, errno, "no room for %d bytes of string", l);
	bcopy(s, p, l);
	return (p);
}
