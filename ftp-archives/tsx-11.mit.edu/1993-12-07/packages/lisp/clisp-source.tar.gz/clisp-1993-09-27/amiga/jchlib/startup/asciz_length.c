#include <exec/types.h>

ULONG asciz_length(const char* str)
{
  register ULONG count;
  for (count = 0L; *str != '\0'; count++, str++) ;
  return count;
}
