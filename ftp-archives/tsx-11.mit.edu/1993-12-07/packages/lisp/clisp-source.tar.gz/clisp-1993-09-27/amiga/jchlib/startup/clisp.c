#include <exec/types.h>
#include <libraries/dos.h>

/* for inclusion with CLISP */

/* CLISP defines these handles */
BPTR Input_handle = NULL;
BPTR Output_handle = NULL;

char _WDefName13[] = "CON:0/11/640/186/CLISP-Listener";
char _WDefName[] =  "CON:0/11//186/CLISP-Listener/CLOSE/AUTO/WAIT";
