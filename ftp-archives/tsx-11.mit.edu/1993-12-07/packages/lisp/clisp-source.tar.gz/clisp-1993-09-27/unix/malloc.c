/* compile:  cc -o malloc malloc.c
   try:      malloc 50000
             malloc 100000
             malloc 1000000
*/
#include <stdio.h>
int main (argc,argv)
  int argc;
  char** argv;
{ int arg = (argc>1 ? atoi(argv[1]) : 10000);
  printf ("malloc(%d) = #x%8X\n",arg,(int)malloc(arg));
  exit(0);
}
