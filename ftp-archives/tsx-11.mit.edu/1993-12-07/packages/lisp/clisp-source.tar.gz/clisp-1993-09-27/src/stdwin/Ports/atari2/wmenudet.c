
#include "window.h"

void
wmenudetach(win, pm)
WINDOW *win;
void *pm;
{
	delofbar(&win->mbar, pm);
	if ( win == active ) barchanged = TRUE;
}

