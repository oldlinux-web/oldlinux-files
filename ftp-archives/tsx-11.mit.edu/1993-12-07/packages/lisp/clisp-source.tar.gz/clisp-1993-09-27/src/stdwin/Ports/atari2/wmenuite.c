
#include "window.h"

void
wmenuitemset(pm, item, text)
void *pm;
int item;
char *text;
{
	struct m_item *it;
	int	len = 0;

	if ( item < 0 || item >= ((MENU *)pm)->nritems ) return;

	it = ((MENU *)pm)->itemlist[item];

	FREE (it->ittext);

	it->enabled = text != NULL && *text != 0;

	if (it->enabled) {
		it->ittext = strdup (text);
		len = 2 + strlen (it->ittext);
		if ( it->sctext != NULL && *it->sctext != '\0' )
			len += 2 + strlen(it->sctext);
	}
	else it->checked = FALSE;

	len++;
	if ( it->line && it->enabled && len <= ((MENU *)pm)->maxlen &&
	((MENU *)pm)->maxlen == strlen(it->line) ) {
		char *cp = it->line, *s = text;
		*cp++ = ' '; *cp++ = ' ';
		while ( *s ) *cp++ = *s++;
		s = it->sctext;
		len = ((MENU *)pm)->maxlen - strlen(text) - 3;
		if ( s ) len -= strlen(s);
		while ( len-- > 0 ) *cp++ = ' ';
		if ( s ) { while ( *s ) *cp++ = *s++; }
		*cp++ = ' ';
		*cp = '\0';

		if (menu != NULL) {
			int	obj = 4;
			int	i;

			for (i = 0; i < active->mbar.nrmenus; ++i) {
				MENU *mp = active->mbar.menulist[i];

				if (((MENU *)pm) == mp) break;

				obj += mp->nritems + 1;
			}

			obj += item + 1 + active->mbar.nrmenus;
			menu_text(menu, obj, it->line);
		}
	}
	else {
		if ( len > ((MENU *)pm)->maxlen ) ((MENU *)pm)->maxlen = len;
		((MENU *)pm)->dirty = TRUE;
		barchanged = TRUE;
		if ( it->line != NULL ) it->line[0] = '\0';
	}
}

