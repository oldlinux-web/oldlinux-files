
#include "window.h"

void
_setsize (win, h, v, width, height)
WINDOW	*win;
int	h;
int	v;
int	width;
int	height;
{
	win->h = h;
	win->v = v;
	win->width = width;
	win->height = height;
	if ( !win->console ) {
		win->h += w_l_border;
		win->v += w_t_border;
		win->width -= w_l_border + w_r_border;
		win->height -= w_t_border + w_b_border;
	}
}

