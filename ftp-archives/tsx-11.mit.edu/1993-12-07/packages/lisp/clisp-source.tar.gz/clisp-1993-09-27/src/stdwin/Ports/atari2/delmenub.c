
#include "window.h"

void
delmenubar()
{
	int	i;

	for (i = globmenus.nrmenus; (--i) >= 0; ) {
		wmenudelete (globmenus.menulist[i]);
	}
	if (menu != NULL) {
		menu_bar (menu, 0);
		FREE (menu);
	}
}

