
#include "window.h"

void
setkey(id, item, key)
int	id;
int	item;
int	key;
{
	if (key < 0 || key >= 256 || keytab[key].id != 0) return;

	keytab[key].id = id;
	keytab[key].item = item;
}

