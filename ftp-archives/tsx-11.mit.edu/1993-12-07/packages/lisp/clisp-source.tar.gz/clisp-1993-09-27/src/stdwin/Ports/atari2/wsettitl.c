
#include "window.h"

void
wsettitle(win, title)
WINDOW *win;
char *title;
{
	FREE(win->title);
	win->title = strdup(title);
	wind_set(win->handle, WF_NAME, win->title);
}

