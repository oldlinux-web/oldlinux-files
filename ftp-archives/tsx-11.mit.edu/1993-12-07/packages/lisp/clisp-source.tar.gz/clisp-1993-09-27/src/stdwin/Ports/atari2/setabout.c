
#include "window.h"

static char zero = 0;

void
setabout(argc,argv)
int argc;
char **argv;
{
	int n, i;
	TEDINFO *t;
	if ( argc > 0 ) {
/*
		if ( w_rootmenu ) {
			wmenusetitem(w_rootmenu,0,*argv);
		}
*/
		w_about = *argv++;
		argc--;
	}

	t = linfi;
	for ( i = 0; i < 6; i++, t++ ) {
		if ( argc > 0 ) {
			n = strlen(*argv);
			t->te_ptext = *argv++;
			t->te_txtlen = n;
			argc--;
		}
		else {
			t->te_ptext = &zero;
			t->te_txtlen = 0;
		}
	}
}
