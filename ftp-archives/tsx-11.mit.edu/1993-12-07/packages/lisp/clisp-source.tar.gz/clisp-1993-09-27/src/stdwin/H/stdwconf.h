/* "stdwconf.h" -- mess with predefined symbols.
   This file is supposed to be portable between all OSes.
   It is also reentrant.
*/

#ifndef __STDWCONF_H__      /* Guard against multiple inclusion */
#define __STDWCONF_H__

#if defined(unix) || defined(__unix)

/* Include list of features found by `configure'. */
#include "config.h"

#else /* non-Unix systems can't execute the configure script */

#if defined(__EMX__)
#if defined(__GNUC__) && !defined(__STDC__)
#define inline __inline
#endif
#define STDC_HEADERS
#define HAVE_UNISTD_H
#define DIRENT
#define HAVE_STDARG_H
#define HAVE_VARARGS_H
#define HAVE_STRING_H
#define HAVE_GETOPT_H
#define HAVE_TERMIO_H
#define HAVE_SYS_TERMIO_H
#define HAVE_SGTTY_H
#define RETMALLOCTYPE void*
#define RETFREETYPE void
#define HAVE_ALLOCA_H
#define RETSIGTYPE_VOID
#define SIGNAL_NEED_REINSTALL /* signals need acknowledge ?? */
#define HAVE_SELECT /* emx 0.8f or newer */
#define SELECT_WIDTH_T int
#define SELECT_SET_T struct _fd_set
#define SELECT_CONST
#define HAVE_SETTIMEOFDAY
#define HAVE_MEMCPY
#define HAVE_GETOPT
#define HAVE_STRDUP
#define HAVE_STRCHR
#define HAVE_STRRCHR
#endif

#if defined(macintosh) || defined(THINK_C)

/* Some portable code tests for "MACINTOSH" to detect any Mac implementation. */
#define MACINTOSH

/* MPW defines "macintosh"; THINK C defines "THINK_C".
   The distinction between MPW and THINK C is made by checking for
   "MPW" or "THINK_C".
   For Think C 3.0, you must manually define THINK_C and THINK_C_3_0
*/

/* If "macintosh" defined but not "THINK_C", it must be MPW */
/* XXX (I hope I remember this right -- I haven't used MPW for years) */
#ifndef THINK_C
#define MPW
#define const
#define RETSIGTYPE void
#endif

#ifdef THINK_C
#if THINK_C < 5
#define THINK_C_PRE_5_0
#endif
#ifndef __STDC__
#define __STDC__ 0 /* ?? */
#endif
#define USG
#define RETSIGTYPE int
#endif

#endif /* MACINTOSH */

#endif /* not Unix */

#endif /* __STDWCONF_H__ */
