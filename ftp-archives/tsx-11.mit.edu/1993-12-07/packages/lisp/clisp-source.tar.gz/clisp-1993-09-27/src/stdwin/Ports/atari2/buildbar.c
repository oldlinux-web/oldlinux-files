
#include "window.h"
#include "trees.h"

void checkmenu(void *);
int getascii(int scan);
OBJECT *tr_add(TREE *t,int as_child,int type,int flags,int state,long spec,int x,int y,int width,int height);
bool tr_parent(TREE *t);
OBJECT *tr_tree(TREE *t);

OBJECT *
buildbar(win)
WINDOW *win;
{
	TREE tree = { 0, 0, 0 };
	TREE *t = &tree;
	int	act;
	int	scr;
	int	box;
	int	title;
	int	dummy = 0;
	int	lh = w_ch_height;
	int	first = 1;
	int	act_x = 2 * w_ch_width;
	int	m_width = 0;
	int	s_height = 0;
	int	i;
	int	j;

	tr_add (t, 0, G_IBOX, NONE, NORMAL, 0L, 0, 0, scr_width, scr_height);
	m_link[t->focus].m = m_link[t->focus].it = -1;

	tr_add (t, 1, G_BOX, NONE, NORMAL, BAR, 0, 0, scr_width, BAR_HEIGHT);
	m_link[t->focus].m = m_link[t->focus].it = -1;

	tr_add (t, 1, G_IBOX, NONE, NORMAL, 0L, act_x, 0,
							dummy, BAR_HEIGHT);
	act = t->focus;
	m_link[t->focus].m = m_link[t->focus].it = -1;

	for (i = 0; i < win->mbar.nrmenus; i++) {
		int	width;
		MENU *pm = win->mbar.menulist[i];

		width = wtextwidth (pm->title, -1);

		tr_add(t, first, G_TITLE, NONE, NORMAL, (long)(pm->title), m_width, 0,
							width, BAR_HEIGHT);
		m_width += width;
		m_link[t->focus].m = pm->id;
		m_link[t->focus].it = -1;
		if (first)
			first = 0;
	}
	t->obj[act].ob_width = m_width;

	tr_parent(t);
	tr_parent(t);

	tr_add (t, 0, G_IBOX, NONE, NORMAL, 0L, 0, BAR_HEIGHT, scr_width, dummy);
	scr = t->focus;
	m_link[t->focus].m = m_link[t->focus].it = -1;

	first = 1;
	title = t->obj[act].ob_head;

	for (i = 0; i < win->mbar.nrmenus; i++) {
		int	firstit = 1;
		int	b_width = 0;
		int	box_x   = t->obj[title].ob_x + t->obj[act].ob_x;
		MENU *pm    = win->mbar.menulist[i];

		if (pm->dirty) checkmenu((void *)pm);

		tr_add (t, first, G_BOX, NONE, NORMAL, BOX, box_x, 0, dummy, dummy);
		box = t->focus;
		m_link[t->focus].m = m_link[t->focus].it = -1;
		for (j = 0; j < pm->nritems; j++) {
			struct m_item *it = pm->itemlist[j];
			int	width         = wtextwidth (it->line, -1);
			int	state         = (it->enabled ? NORMAL : DISABLED);

			if (it->checked) state |= CHECKED;

			tr_add(t, firstit, G_STRING, NONE, state, (long)(it->line), 0,
							j * lh, width, lh);
			if (width > b_width) b_width = width;
			m_link[t->focus].m   = pm->id;
			m_link[t->focus].it  = j;

			firstit = 0;
		}
		if (!firstit) tr_parent (t);

		for (j = 0; j < pm->nritems; j++) {
			OBJECT	*o = &t->obj[t->focus + j + 1];

			o->ob_width = b_width;
		}
		t->obj[box].ob_width = b_width;
		t->obj[box].ob_height = pm->nritems * lh;
		if (t->obj[box].ob_height > s_height ) s_height = t->obj[box].ob_height;
		first = 0;
		title = t->obj[title].ob_next;
	}

	t->obj[scr].ob_height = s_height;
/*
	tr_dump (t);
*/
	return (tr_tree (t));
}
