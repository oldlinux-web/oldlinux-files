
#include "window.h"

void
rectsubt(a, b, diff, nr_diff)
int	*a;
int	*b;
int	diff[][4];
int	*nr_diff;
{
	int	i = 0;

	*nr_diff = 0;
	if ( a[LEFT] < b[LEFT] ) {
		diff[i][LEFT] = a[LEFT];
		diff[i][TOP] = a[TOP];
		diff[i][RIGHT] = b[LEFT];
		diff[i][BOTTOM] = a[BOTTOM];
		i++;

		if (a[RIGHT] < b[LEFT]) {
			diff[i - 1][RIGHT] = a[RIGHT];
			*nr_diff = i;
			return;
		}
	}

	if ( a[RIGHT] > b[RIGHT] ) {
		diff[i][LEFT] = b[RIGHT];
		diff[i][TOP] = a[TOP];
		diff[i][RIGHT] = a[RIGHT];
		diff[i][BOTTOM] = a[BOTTOM];
		i += 1;

		if ( a[LEFT] > b[RIGHT] ) {
			diff[i - 1][LEFT] = a[LEFT];
			*nr_diff = i;
			return;
		}
	}

	if ( a[TOP] < b[TOP] ) {
		diff[i][LEFT] = a[LEFT];
		diff[i][TOP] = a[TOP];
		diff[i][RIGHT] = a[RIGHT];
		diff[i][BOTTOM] = b[TOP];
		i += 1;

		if ( a[BOTTOM] < b[TOP] ) {
			diff[i - 1][BOTTOM] = a[BOTTOM];
			*nr_diff = i;
			return;
		}
	}

	if ( a[BOTTOM] > b[BOTTOM] ) {
		diff[i][LEFT] = a[LEFT];
		diff[i][TOP] = b[BOTTOM];
		diff[i][RIGHT] = a[RIGHT];
		diff[i][BOTTOM] = a[BOTTOM];
		i += 1;

		if ( a[TOP] > b[BOTTOM] ) {
			diff[i - 1][TOP] = a[TOP];
			*nr_diff = i;
			return;
		}
	}
	*nr_diff = i;
}

