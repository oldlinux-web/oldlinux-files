
#include "window.h"

void
wshade(left, top, right, bottom, perc)
int left;
int top;
int right;
int bottom;
int perc;
{
	int area[4];

	if ( drawing == NULL ) return;
	
	if ( right <= left || bottom <= top ) return; 	/* Empty box */

	area[0] = left + extrah;
	area[1] = top + extrav;
	area[2] = right + extrah - 1;
	area[3] = bottom + extrav - 1;

	if ( curr_interior != 2 ) {
		vsf_interior(vdi_handle, 2);
		curr_interior = 2;
	}
	if ( curr_color != 1 ) {
		vsf_color(vdi_handle, 1);
		curr_color = 1;
	}
	if ( curr_mode != 2 ) {
		vswr_mode(vdi_handle, 2);
		curr_mode = 2;
	}
	vsf_style(vdi_handle, (perc * 10) / 125);

	vr_recfl(vdi_handle, area);
}

