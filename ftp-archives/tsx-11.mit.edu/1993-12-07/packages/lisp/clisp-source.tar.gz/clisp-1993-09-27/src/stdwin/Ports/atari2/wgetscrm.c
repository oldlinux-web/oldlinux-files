
#include "window.h"

void
wgetscrmm(pmmhor, pmmvert)
int	*pmmhor;
int	*pmmvert;
{
	*pmmhor  = (long)pix_width  * scr_width  / 1000L;
	*pmmvert = (long)pix_height * scr_height / 1000L;
}

