extern int w_no_erase;

void
wnoerase(x)
int x;
{
	w_no_erase = x;
}
