
#include "window.h"

void
wdrawcircle(h, v, radius)
int h;
int v;
int radius;
{
	int scr_h;
	int scr_v;

	if ( drawing == NULL ) return;
	
	scr_h = h + extrah;
	scr_v = v + extrav;

	if ( curr_interior != 0 ) {
		vsf_interior(vdi_handle, 0);
		curr_interior = 0;
	}
	if ( curr_color != 1 ) {
		vsf_color(vdi_handle, 1);
		curr_color = 1;
	}
	if ( curr_mode != 1 ) {
		vswr_mode(vdi_handle, 1);
		curr_mode = 1;
	}

	v_circle(vdi_handle, scr_h, scr_v, radius);
}

