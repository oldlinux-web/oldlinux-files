/*
 * $XFree86: mit/server/ddx/x386/common/x386Conf.c,v 1.6 1993/05/23 10:25:48 dawes Exp $
 */

#define IN_X386CONF	/* For x386Vendor.h */

#include "X.h"
#include "os.h"
#include "x386.h"

#ifdef X386MONOVGA

#define SCREEN0 NULL

#ifdef BUILD_VGA2
extern ScrnInfoRec vga2InfoRec;
#define SCREEN1 &vga2InfoRec
#else
#define SCREEN1 NULL
#endif

#ifdef BUILD_HGA2
extern ScrnInfoRec hga2InfoRec;
#define SCREEN2 &hga2InfoRec
#else
#define SCREEN2 NULL
#endif

#else /* !X386MONOVGA */

#ifdef BUILD_VGA256
extern ScrnInfoRec vga256InfoRec;
#define SCREEN0 &vga256InfoRec
#else
#define SCREEN0 NULL
#endif

#define SCREEN1 NULL
#define SCREEN2 NULL

#endif /* X386MONOVGA */

ScrnInfoPtr x386Screens[] = 
{
  SCREEN0,
  SCREEN1,
  SCREEN2,
};

int  x386MaxScreens = sizeof(x386Screens) / sizeof(ScrnInfoPtr);


/* Dummy function for PEX in LinkKit and mono server */

#if defined(X386MONOVGA) || (defined(LINKKIT) && !defined(PEXEXT))
PexExtensionInit() {}
#endif
