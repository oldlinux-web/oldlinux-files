enum tokens {
     /* punctuation */
     COMMA = 257,
     EQ,
     DASH,
     AT,

     /* keywords */
     DEVICE = 270,
     IO,
     IRQ,
     MEM,
     NONE,

     /* valued tokens */
     STRING = 300,
     INT,
     IDENTIFIER,
};

typedef union {
     int n;
     char *s;
} toktype;

extern toktype tokval;
extern int config_lineno;
