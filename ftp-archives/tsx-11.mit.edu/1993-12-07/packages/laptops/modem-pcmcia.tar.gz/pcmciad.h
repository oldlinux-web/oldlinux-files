#ifndef __PCMCIAD_H__
#define __PCMCIAD_H__

enum devtypes {
     UNKNOWN,
     MODEM,
     ETHERNET,

     MAX_DEVTYPE,
};

/*
 * data structures for configuration file information
 */
struct prod_map {
     enum devtypes devtype;
     char *manufacturer, *prod_name, *addl_info1, *addl_info2;
     struct prod_map *next;
};

struct dev_action {
     enum devtypes devtype;
     struct pcmcia_cfentry cfent;
     char *init, *reset;
     int busy;
     struct dev_action *next;
};

/*
 * state information for each PC card socket
 */
enum sockstate {
     EMPTY,
     FULL,
};

struct sock_state {
     enum sockstate state;
     enum devtypes devtype;
};    

/* DO NOT ADD ANYTHING AFTER THIS #endif */
#endif /* __PCMCIAD_H__ */
