/******************************************************************************
 *
 *	File:	oimem.C
 *
 *	Function(s):
 *
 *	Description:
 *		Template for prototyper generated application
 *		The root name of your application is "oimem"
 *		To ensure that this module compiles correctly, the user should
 *		place all additional definitions into oimem.H.
 *
 *	RCSid = "$Id: app.src,v 2.12 1993/05/12 00:52:57 misek Exp $"
 *
 ******************************************************************************
 */
#include <OI/gauge.H>
#include <OI/appwin.H>
#include <OI/mnu.H>
#include <OI/bind.H>
#include <stdlib.h>

enum	oimem_mode_t { percent, megabytes };

OI_gauge		*free_memG;
OI_gauge		*swapG;
OI_gauge		*sharedG;
OI_gauge		*bufferG;
OI_gauge		*used_memG;

int			mem_total;
int			mem_used;
int			mem_free;
int			mem_shared;
int			mem_buffers;
int			swap_total;
int			swap_used;
int			swap_free;

oimem_mode_t		mode;

const int ONE_MEG = 1024 * 1024;

#define	OI_user_var	(OI_translation_fnp)(void*)

void set_units(OI_menu_cell *, void *, OI_number);

OI_actions_rec	oimem_action_tbl[] = {	/* binding table */
	{"free_memG", OI_user_var &free_memG, NULL, NULL },
	{"swapG", OI_user_var &swapG, NULL, NULL },
	{"sharedG", OI_user_var &sharedG, NULL, NULL },
	{"bufferG", OI_user_var &bufferG, NULL, NULL },
	{"used_memG", OI_user_var &used_memG, NULL, NULL },
	{"set_units", (OI_translation_fnp) set_units, NULL, NULL },
	{"percent", OI_user_var percent, NULL, NULL },
	{"megabytes", OI_user_var megabytes, NULL, NULL },
} ;

#undef	OI_user_var

void
update_gauges( void * )
{
			FILE			*fp;
			char			buffer[1024];
	
	fp = fopen( "/proc/meminfo", "r" );
	if (!fp) {
		swapG->push_help_str( "Can't open /proc/meminfo for reading." );
		return;
	}

	fgets( buffer, sizeof( buffer ) , fp );
	fscanf( fp, "%*s%d%d%d%d%d", &mem_total, &mem_used, & mem_free, &mem_shared, &mem_buffers );
	fscanf( fp, "%*s%d%d%d", &swap_total, &swap_used, &swap_free );
	fclose( fp );

	switch (mode) {
	 case percent:
		free_memG->set_value((int) ((double) mem_free * 100.0 / (double) mem_total));
		used_memG->set_value((int) ((double) mem_used * 100.0 / (double) mem_total));
		sharedG->set_value((int) ((double) mem_shared * 100.0 / (double) mem_total));
		bufferG->set_value((int) ((double) mem_buffers * 100.0 / (double) mem_total));
		swapG->set_value(swap_total ? ((int) ((double) swap_used * 100.0 / (double) swap_total)) : 0);
		break;

	 case megabytes:
		free_memG->set_value(mem_free / ONE_MEG );
		used_memG->set_value(mem_used / ONE_MEG );
		sharedG->set_value(mem_shared / ONE_MEG );
		bufferG->set_value(mem_buffers / ONE_MEG );
		swapG->set_value(swap_used / ONE_MEG );
		break;
	}
}

int
main( int argc, char ** argv )
{
			int			rtn ;			// Return value
			OI_number		i ;			// loops
			OI_d_tech		**topLevel ;		// vector of top level objects
			OI_connection		*cp ;			// connection to X server

	rtn = 1;
	if (cp = OI_init(&argc,argv)) {
		OI_add_actions( oimem_action_tbl, OI_count( oimem_action_tbl ) );

		if (topLevel = cp->build_from_configuration_file( OI_translate_filename( "oimem.cf" ), OI_no )) {
			for ( i=0 ; topLevel[i] ; ++i )
				topLevel[i]->set_associated_object( topLevel[i]->root(),OI_def_loc,OI_def_loc,OI_active );
			((OI_app_window *) topLevel[0])->help_menu()->delete_all();
			delete [] topLevel;
			update_gauges( NULL );
			OI_add_wall_timeout( 5*1000, (OI_timeout_fnp) &update_gauges );
			OI_begin_interaction() ;
		}
		else
			fprintf(stderr,"ERROR reading read file oimem.cf or no TopLevel resource available\n") ;
		OI_fini() ;
		rtn = 0 ;
	}
	return( rtn );
}

void
set_units(
			OI_menu_cell		*cellp,		// (input) ptr to cell which fired
			void			*argp,		// (input) ptr to user supplied argument
			OI_number		)		// (input) mouse button used to fire cell
{
 /*	External Procedures */
 /*	Local Variables */
			char			buffer[100];
 /*
	Procedure:
 */
	if (cellp->selected()) {
		mode = (oimem_mode_t) argp;
		switch (mode) {
		 case percent:
			free_memG->set_max_label( "100%" );
			free_memG->set_span( 100, 0 );
			swapG->set_max_label( "100%" );
			swapG->set_span( 100, 0 );
			used_memG->set_max_label( "100%" );
			used_memG->set_span( 100, 0 );
			sharedG->set_max_label( "100%" );
			sharedG->set_span( 100, 0 );
			bufferG->set_max_label( "100%" );
			bufferG->set_span( 100, 0 );
			break;

		 case megabytes:
			sprintf( buffer, "%dM", mem_total / ONE_MEG );
			free_memG->set_max_label( buffer );
			free_memG->set_span( mem_total / ONE_MEG, 0 );
			sharedG->set_max_label( buffer );
			sharedG->set_span( mem_total / ONE_MEG, 0 );
			bufferG->set_max_label( buffer );
			bufferG->set_span( mem_total / ONE_MEG, 0 );
			used_memG->set_max_label( buffer );
			used_memG->set_span( mem_total / ONE_MEG, 0 );
			sprintf( buffer, "%dM", swap_total / ONE_MEG );
			swapG->set_max_label( buffer );
			swapG->set_span( swap_total / ONE_MEG, 0 );
			break;
		}
		update_gauges( NULL );
	}

	return ;
}
