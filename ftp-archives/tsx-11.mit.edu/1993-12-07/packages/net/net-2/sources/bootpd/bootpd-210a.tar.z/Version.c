
/*
 * Copyright (c) 1988 by Carnegie Mellon.
 *
 * Permission to use, copy, modify, and distribute this program for any
 * purpose and without fee is hereby granted, provided that this copyright
 * and permission notice appear on all copies and supporting documentation,
 * the name of Carnegie Mellon not be used in advertising or publicity
 * pertaining to distribution of the program without specific prior
 * permission, and notice be given in supporting documentation that copying
 * and distribution is by permission of Carnegie Mellon and Stanford
 * University.  Carnegie Mellon makes no representations about the
 * suitability of this software for any purpose.  It is provided "as is"
 * without express or implied warranty.
 *
 *
 * Version.c (this file):
 *
 * Copyright (c) 1986, 1987 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that this notice is preserved and that due credit is given
 * to the University of California at Berkeley. The name of the University
 * may not be used to endorse or promote products derived from this
 * software without specific prior written permission. This software
 * is provided ``as is'' without express or implied warranty.
 *
 *	@(#)Version.c	4.8 (Berkeley) 4/7/88
 */

#ifndef lint
char sccsid[] = "@(#)bootpd 2.1 %VERSION% %WHOANDWHERE%\n";
char rcsid[] = "$Header: Version.c,v 1.2 88/11/22 17:53:04 ww0n Exp $";
#endif /* not lint */

char Version[] = "bootpd 2.1 %VERSION%\n\t%WHOANDWHERE%\n";

