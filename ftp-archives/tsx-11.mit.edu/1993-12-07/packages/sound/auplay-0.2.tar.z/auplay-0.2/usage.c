
#ifndef VERSION
#define VERSION "unknown"
#endif

void usage_exit()
{
  printf("auplay version %s\n",VERSION);
  printf("\tauplay doesn't currently accept arguments\n");
  exit(-1);
}

