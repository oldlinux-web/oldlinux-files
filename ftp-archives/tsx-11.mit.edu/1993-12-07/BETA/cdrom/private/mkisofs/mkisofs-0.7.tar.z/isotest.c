#include <stdio.h>
#include "iso9660.h"

char buffer[2048];
FILE  * infile;

int iso733(char *  pnt){
	int * ip;

	ip  = (int *) pnt;
	return *ip;
}

int iso723(char *  pnt){
	int i;
	short int * ip;

	ip  = (short int *) pnt;
	i =  *ip;
	return i;
}

int dumpblock(char *  buffer){
	int dirlen;
	int i;
	struct iso_directory_record *  de;

	de  = (struct iso_directory_record *) &buffer[0];
	while(1==1){
		if(de->length[0] == 0) break;
		fprintf(stderr,"Name:  ");
		if(de->name_len[0] ==  1 &&  de->name[0] <=  1){
			fprintf(stderr,".");
			if(de->name[0] == 0) fprintf(stderr," ");
			if(de->name[0] == 1) fprintf(stderr,".");
			if(de->name[0] == 0) dirlen = iso733(de->size);
		} else {
		for(i=0; i<de->name_len[0]; i++)  fprintf(stderr,"%c",de->name[i]);
	};
		for(i=14; i>de->name_len[0]; i--)  fprintf(stderr," ");
		fprintf(stderr,"  Extent: %d\t",  iso733(de->extent));
		fprintf(stderr,"  Size: %d\t",  iso733(de->size));
		fprintf(stderr,"  VSN: %d\n",  iso723(de->volume_sequence_number));
		de = (struct iso_directory_record *) 
			(((char *) de) + de->length[0]);
	
	};
	return dirlen;
}

main(int argc, char * argv[]){
	int blkno;
	int size;
	int i;

	if(argc<2) exit(1);
	infile = fopen(argv[1],"r");

	fprintf(stderr,"Enter block number:");
	scanf("%d",&blkno);
	lseek(fileno(infile), blkno << 11, 0);
	fread(buffer, sizeof(buffer), 1, infile);
	
 	size = dumpblock(buffer);
	size = size  >> 11;
	if(size > 1){
		for(i=1;  i<size; i++){
			fread(buffer, sizeof(buffer), 1, infile);
			dumpblock(buffer);
		};
	};
}
