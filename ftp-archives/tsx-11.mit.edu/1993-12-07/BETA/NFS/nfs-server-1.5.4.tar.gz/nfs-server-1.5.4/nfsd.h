/*
 * nfsd		This program implements a user-space NFS server.
 *
 * Version:	@(#)nfsd.h	1.5	93/04/10
 *
 * Authors:	Mark A. Shand, May 1988
 *		Rick Sladkey, <jrs@world.std.com>
 *		Fred N. van Kempen, <waltje@uWalt.NL.Mugnet.ORG>
 *		Copyright 1988 Mark A. Shand
 *
 *		This software maybe be used for any purpose provided
 *		the above copyright notice is retained.  It is supplied
 *		as is, with no warranty expressed or implied.
 */

#include <sys/types.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>			/* needed for lseek(2) et al	*/
#endif

#include <sys/param.h>			/* needed for MAXPATHLEN	*/
#include <sys/stat.h>
#include <sys/ioctl.h>			/* needed for ioctl(2)		*/
#include <sys/socket.h>
#include <stdio.h>
#include <rpc/rpc.h>
#include <ctype.h>
#include <errno.h>
#ifdef HAVE_FCNTL_H
#include <fcntl.h>
#endif
#include <netdb.h>			/* needed for gethostbyname	*/
#include <netinet/in.h>
#undef NOERROR				/* blasted sysv4 */
#include <arpa/nameser.h>		/* needed for <resolv.h>	*/
#include <arpa/inet.h>			/* for inet_ntoa(3)		*/
#include <resolv.h>			/* needed for h_errno	YUCK	*/
#include <signal.h>
#ifdef __STDC__
#include <stdarg.h>			/* needed for va_arg et al	*/
#else
#include <varargs.h>
#endif
#ifdef STDC_HEADERS
#include <stdlib.h>
#endif
#ifdef TIME_WITH_SYS_TIME
#include <sys/time.h>
#include <time.h>
#else /* not TIME_WITH_SYS_TIME */
#ifdef HAVE_SYS_TIME_H
#include <sys/time.h>
#else /* not HAVE_SYS_TIME_H */
#include <time.h>
struct timeval {
	long tv_sec;
	long tv_usec;
};
#endif /* not HAVE_SYS_TIME_H */
#endif /* not TIME_WITH_SYS_TIME */
#ifdef HAVE_SYS_FILE_H
#include <sys/file.h>
#endif

#if defined(STDC_HEADERS) || defined(HAVE_STRING_H)
#include <string.h>
/* An ANSI string.h and pre-ANSI memory.h might conflict.  */
#if !defined(STDC_HEADERS) && defined(HAVE_MEMORY_H)
#include <memory.h>
#endif /* not STDC_HEADERS and HAVE_MEMORY_H */
#else /* not STDC_HEADERS and not HAVE_STRING_H */
#include <strings.h>
/* memory.h and strings.h conflict on some systems.  */
#ifndef strchr
#define strchr(s, c) index((s), (c))
#endif
#ifndef strrchr
#define strrchr(s, c) rindex((s), (c))
#endif
#ifndef memcpy
#define memcpy(d, s, n) bcopy((s), (d), (n))
#endif
#ifndef memcmp
#define memcmp(s1, s2, n) bcmp((s1), (s2), (n))
#endif
#ifndef memset
#define memset(s, c, n) \
	do {						\
		char *_s = (s);				\
		int _c = (c);				\
		int _n = (n);				\
		int _i;					\
							\
		if (_c == 0)				\
			bzero(_s, _n);			\
		else					\
			for (i = 0; i < _n; i++)	\
				*_s++ = _c;		\
	} while (0)
#endif
#endif /* not STDC_HEADERS and not HAVE_STRING_H */

/* unistd.h defines _POSIX_VERSION on POSIX.1 systems.  */
#if defined(DIRENT) || defined(_POSIX_VERSION)
#include <dirent.h>
#define NLENGTH(dirent) (strlen((dirent)->d_name))
#else /* not (DIRENT or _POSIX_VERSION) */
#define dirent direct
#define NLENGTH(dirent) ((dirent)->d_namlen)
#ifdef SYSNDIR
#include <sys/ndir.h>
#endif /* SYSNDIR */
#ifdef SYSDIR
#include <sys/dir.h>
#endif /* SYSDIR */
#ifdef NDIR
#include <ndir.h>
#endif /* NDIR */
#endif /* not (DIRENT or _POSIX_VERSION) */

#ifndef __GNUC__
#define inline
#endif

#ifndef S_ISREG
#define mode_t unsigned short
#endif

#ifndef S_IFMT
#define S_IFMT 0170000
#endif

#if !defined(S_ISBLK) && defined(S_IFBLK)
#define S_ISBLK(m) (((m) & S_IFMT) == S_IFBLK)
#endif
#if !defined(S_ISCHR) && defined(S_IFCHR)
#define S_ISCHR(m) (((m) & S_IFMT) == S_IFCHR)
#endif
#if !defined(S_ISDIR) && defined(S_IFDIR)
#define S_ISDIR(m) (((m) & S_IFMT) == S_IFDIR)
#endif
#if !defined(S_ISREG) && defined(S_IFREG)
#define S_ISREG(m) (((m) & S_IFMT) == S_IFREG)
#endif
#if !defined(S_ISFIFO) && defined(S_IFFIFO)
#define S_ISFIFO(m) (((m) & S_IFMT) == S_IFFIFO)
#endif
#if !defined(S_ISLNK) && defined(S_IFLNK)
#define S_ISLNK(m) (((m) & S_IFMT) == S_IFLNK)
#endif
#if !defined(S_ISSOCK) && defined(S_IFSOCK)
#define S_ISSOCK(m) (((m) & S_IFMT) == S_IFSOCK)
#endif

#ifndef S_ISLNK
#define lstat stat
#endif

#ifndef F_OK
#define F_OK 0
#define X_OK 1
#define W_OK 2
#define R_OK 4
#endif

#ifndef HAVE_SETREUID
#define setreuid(r, e) setuid((e))
#define setregid(r, e) setgid((e))
#endif

#if !defined(getdtablesize) && !defined(HAVE_GETDTABLESIZE)
#define getdtablesize() 20
#endif

#include "mount.h"
#include "nfs_prot.h"

union argument_types {
	nfs_fh			nfsproc_getattr_2_arg;
	sattrargs		nfsproc_setattr_2_arg;
	diropargs		nfsproc_lookup_2_arg;
	nfs_fh			nfsproc_readlink_2_arg;
	readargs		nfsproc_read_2_arg;
	writeargs		nfsproc_write_2_arg;
	createargs		nfsproc_create_2_arg;
	diropargs		nfsproc_remove_2_arg;
	renameargs		nfsproc_rename_2_arg;
	linkargs		nfsproc_link_2_arg;
	symlinkargs		nfsproc_symlink_2_arg;
	createargs		nfsproc_mkdir_2_arg;
	diropargs		nfsproc_rmdir_2_arg;
	readdirargs		nfsproc_readdir_2_arg;
	nfs_fh			nfsproc_statfs_2_arg;
};

union result_types {
	attrstat		attrstat;
	diropres		diropres;
	readlinkres		readlinkres;
	readres			readres;
	nfsstat			nfsstat;
	readdirres		readdirres;
	statfsres		statfsres;
};

typedef struct options {
	enum {map_daemon, identity}
				uidmap;		/* uid/gid mapping functions */
	int			root_squash;
	int			secure_port;	/* client options */
	int			read_only;
	int			link_relative;
} options;

typedef struct clnt_param {
	struct clnt_param	*next;
	struct in_addr		clnt_addr;
	char			*clnt_name;
	char			*mount_point;
	options			o;
} clnt_param;

/* Global variables. */
extern union argument_types	argument;
extern union result_types	result;

/* Include the other module definitions. */
#ifdef __STDC__
#   define _PRO(f, a)	f a
#else
#   define _PRO(f, a)	f ()
#endif
#include "auth.h"
#include "fh.h"
#include "logging.h"

/* Global Function prototypes. */
extern _PRO( void mallocfailed, (void)					);
extern _PRO( nfsstat getattr, (nfs_fh *fh, fattr *attr,			\
			       struct stat *stat_optimize)		);
extern _PRO( char *realpath, (char *path, char *resolved_path)		);

#ifndef HAVE_STRERROR
extern _PRO( char *strerror, (int errno)				);
#endif

/* End of nfsd.h. */
