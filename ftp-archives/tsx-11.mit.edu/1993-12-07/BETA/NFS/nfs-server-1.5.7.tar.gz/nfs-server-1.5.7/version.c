char version[] = "Universal NFS Server, version 1.5.7";
