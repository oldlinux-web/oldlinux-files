/*
 * getflags.c		- Get a file flags on an ext2 file system
 *
 * Copyright (C) 1993  Remy Card <card@masi.ibp.fr>
 *
 * This file can be redistributed under the terms of the GNU General
 * Public License
 */

/*
 * History:
 * 93/10/30	- Creation
 */

#include <sys/ioctl.h>

#include <linux/ext2_fs.h>

int getflags (int fd, unsigned long * flags)
{
	return ioctl (fd, EXT2_IOC_GETFLAGS, flags);
}
