/*
 * setversion.c		- Set a file version on an ext2 file system
 *
 * Copyright (C) 1993  Remy Card <card@masi.ibp.fr>
 *
 * This file can be redistributed under the terms of the GNU General
 * Public License
 */

/*
 * History:
 * 93/10/30	- Creation
 */

#include <sys/ioctl.h>

#include <linux/ext2_fs.h>

int setversion (int fd, unsigned long version)
{
	return ioctl (fd, EXT2_IOC_SETVERSION, &version);
}
