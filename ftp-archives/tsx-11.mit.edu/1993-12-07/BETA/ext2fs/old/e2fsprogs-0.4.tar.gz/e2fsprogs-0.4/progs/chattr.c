
/*
 * chattr.c		- Change file attributes on an ext2 file system
 *
 * Copyright (C) 1993  Remy Card <card@masi.ibp.fr>
 *
 * This file can be redistributed under the terms of the GNU General
 * Public License
 */

/*
 * History:
 * 93/10/30	- Creation
 */

#include <dirent.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/param.h>
#include <sys/stat.h>
#include <linux/ext2_fs.h>

#include "e2fsprogs.h"

extern int fgetflags (const char *, unsigned long *);
extern int fsetflags (const char *, unsigned long);
extern int fsetversion (const char *, unsigned long);
extern int iterate_on_dir (const char *,
			   int (*) (const char *, struct dirent *, void *),
			   void *);
extern void print_flags (FILE *, unsigned long);

char * program_name = "chattr";

int add = 0;
int rem = 0;
int set = 0;
int set_version = 0;

unsigned long version;

int recursive = 0;
int verbose = 0;

unsigned long af;
unsigned long ef;
unsigned long sf;

static void volatile fatal_error (const char * fmt_string, int errcode)
{
	fprintf (stderr, fmt_string, program_name);
	exit (errcode);
}

#define usage() fatal_error ("usage: %s [-RV] [-+=csu] [-v version] files...\n", \
			     1)

int decode_arg (int * i, int argc, char ** argv)
{
	char * p;
	char * tmp;

	switch (argv[*i][0])
	{
	case '-':
		for (p = &argv[*i][1]; *p; p++)
			switch (*p)
			{
			case 'R':
				recursive = 1;
				break;
			case 'V':
				verbose = 1;
				break;
			case 'c':
				sf |= EXT2_COMPR_FL;
				rem = 1;
				break;
			case 's':
				sf |= EXT2_SECRM_FL;
				rem = 1;
				break;
			case 'u':
				sf |= EXT2_UNRM_FL;
				rem = 1;
				break;
			case 'v':
				if (*i >= argc)
					usage ();
				(*i)++;
				version = strtol (argv[*i], &tmp, 0);
				if (*tmp)
				{
					fprintf (stderr, "%s: bad version: %s\n",
						 program_name, argv[*i]);
					usage ();
				}
				set_version = 1;
				break;
			default:
				fprintf (stderr, "%s: Unrecognized argument: %c\n",
					 program_name, *p);
				usage ();
			}
		break;
	case '+':
		add = 1;
		for (p = &argv[*i][1]; *p; p++)
			switch (*p)
			{
			case 'c':
				af |= EXT2_COMPR_FL;
				break;
			case 's':
				af |= EXT2_SECRM_FL;
				break;
			case 'u':
				af |= EXT2_UNRM_FL;
				break;
			default:
				usage ();
			}
		break;
	case '=':
		set = 1;
		for (p = &argv[*i][1]; *p; p++)
			switch (*p)
			{
			case 'c':
				ef |= EXT2_COMPR_FL;
				break;
			case 's':
				ef |= EXT2_SECRM_FL;
				break;
			case 'u':
				ef |= EXT2_UNRM_FL;
				break;
			default:
				usage ();
			}
		break;
	default:
		return EOF;
		break;
	}
	return 1;
}

int chattr_dir_proc (const char *, struct dirent *, void *);

void change_attributes (const char * name)
{
	unsigned long flags;
	struct stat st;

	if (stat (name, &st) == -1)
	{
		perror (name);
		return;
	}
	if (set)
	{
		if (verbose)
		{
			printf ("Flags of %s set as ", name);
			print_flags (stdout, ef);
			printf ("\n");
		}
		if (fsetflags (name, ef) == -1)
			perror (name);
	}
	else
	{
		if (fgetflags (name, &flags) == -1)
			perror (name);
		else
		{
			if (rem)
				flags &= ~sf;
			if (add)
				flags |= af;
			if (verbose)
			{
				printf ("Flags of %s set as ", name);
				print_flags (stdout, flags);
				printf ("\n");
			}
			if (fsetflags (name, flags) == -1)
				perror (name);
		}
	}
	if (set_version)
	{
		if (verbose)
			printf ("Version of %s set as %d\n", name, version);
		if (fsetversion (name, version) == -1)
			perror (name);
	}
	if (S_ISDIR(st.st_mode) && recursive)
		iterate_on_dir (name, chattr_dir_proc, (void *) NULL);
}

int chattr_dir_proc (const char * dir_name, struct dirent * de, void * private)
{
	char path[MAXPATHLEN];

	if (strcmp (de->d_name, ".") && strcmp (de->d_name, ".."))
	{
		sprintf (path, "%s/%s", dir_name, de->d_name);
		change_attributes (path);
	}
	return 0;
}
void main (int argc, char ** argv)
{
	int i, j;
	int end_arg = 0;

	fprintf (stderr, "chattr %s, %s for EXT2 FS %s, %s\n",
		 E2FSPROGS_VERSION, E2FSPROGS_DATE,
		 EXT2FS_VERSION, EXT2FS_DATE);
	if (argc && *argv)
		program_name = *argv;
	i = 1;
	while (i < argc && !end_arg)
	{
		if (decode_arg (&i, argc, argv) == EOF)
			end_arg = 1;
		else
			i++;
	}
	if (i >= argc)
		usage ();
	if (set && (add || rem))
	{
		fprintf (stderr, "= is incompatible with - and +\n");
		exit (1);
	}
	if (!(add || rem || set))
	{
		fprintf (stderr, "Must use =, - or +\n");
		exit (1);
	}
	for (j = i; j < argc; j++)
		change_attributes (argv[j]);
}
