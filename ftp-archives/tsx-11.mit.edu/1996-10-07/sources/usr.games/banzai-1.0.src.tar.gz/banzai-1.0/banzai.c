/*##############################################################################


                                 B A N Z A I

                     a nice game for Linux, Unix... DOS :(
                            by Francesco Munaretto
                                 Version 1.0
                                (c)March 1996

                           HOW TO COMPILE banzai.c
         AT THE LINUX PROMPT YOU MUST TYPE THE FOLLOWING COMMAND LINE

                          gcc -o banzai banzai.c -lm

                                THAT IS ALL!

    IF YOU ARE ENJOY TO PLAY WITH  'B A N Z A I'  PLEASE SEND ME AN E-MAIL

                        franz@milliways.stat.unipd.it


##############################################################################*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#define CPU_SPEED 0.01   /* 0.05 - 0.03 good for 386 25-40 MHz
                            0.02 - 0.01 good for 486 33-66 MHz
                            0.005       good for Pentium or P6 */

int title(void);
int draw_player(int color, int col, int row);
int draw_all(int battle);
int input_data(int col, int *v, double *ag);
int arrow1(int *ok);
int arrow2(int *ok, char *player2);
int banzai(int color1, int color2, int col1, int row1, int col2, int row2);

int n, k, j, i;
int xblu, yblu, xred, yred;


int title(void)
{
  printf("\x1b[0m\x1b[7;28H by Francesco Munaretto");
  printf("\x1b[8;29H      Version 1.0\x1b[9;29H     (c)March 1996");
  for (j=1; j<10; j++) {
    for (k=1; k<8; k++) {
      for (i=1; i<50; i++) {
        printf("\x1b[5;35H\x1b[1;%dmB A N Z A I\b", k+30);
      }
    }
  }
  return 0;
}


int draw_player(int color, int col, int row)
{
  printf("\x1b[0m\x1b[%d;%dH", row, col);
  printf("\x1b[1;%dm_O_", color);
  printf("\x1b[%d;%dH/ \\", row+1, col);
  printf("\x1b[44m\x1b[%d;%dH     ", row+2, col-1);
  for(k=row+3; k<25; k++)
    printf("\x1b[%d;%dH     ", k, col-1);
  return 0;
}


int draw_all(int battle)
{
  printf("\x1b[2J\x1b[44m\x1b[25;1H                                                                                ");
  draw_player(36, xblu, yblu);
  draw_player(33, xred, yred);
  printf("\x1b[0m\x1b[1;36HBattle %d", battle);
  return 0;
}


int input_data(int col, int *v, double *ag)
{
  char power[5];
  char angle[5];
  int a;

  do {
    printf("\x1b[0m\x1b[2;%dH\x1b[KPower=", col);
    gets(power);
    *v = atoi(power);
  }
  while ((*v <= 0) || (*v > 99) || (strlen(power) == 0));
  do {
    printf("\x1b[3;%dH\x1b[KAngle=", col);
    gets(angle);
    a = atoi(angle);
  }
  while ((a <= 0) || (a > 90) || (strlen(angle) == 0));
  *ag = (a * 3.14) / 180;
  return 0;
}


int arrow1(int *ok)
{
  int v;
  double ag;
  double x_arrow, y_arrow;

  input_data(1, &v, &ag);
  x_arrow = 0;
  while (x_arrow <= 80) {
    y_arrow=(sin(ag)/cos(ag)*x_arrow)-(0.5*9.82*pow(x_arrow, 2))/
            pow(v*cos(ag), 2);
    if (((yblu-y_arrow) < 1) || (xblu+x_arrow > 80) || ((yblu-y_arrow) > 26)) {
      printf("\x1b[36m\x1b[%d;%dH?\b", yblu-1, xblu);
    }
    else {
      printf("\x1b[1;36m\x1b[%d;%dH->\b\b", (int)(yblu-1-y_arrow),
            (int)(xblu+x_arrow));
      printf("\x1b[30m\x1b[%d;%dH  \b\b", (int)(yblu-1-y_arrow),
            (int)(xblu+x_arrow));
      if (((int)(xblu+x_arrow) == xred) && (((yblu-y_arrow) > (yred+3)) &&
         ((yblu-y_arrow) < 25)))
        break;
      if ((((int)(yblu-1-y_arrow) == yred) || ((int)(yblu-1-y_arrow) ==
         (yred+1))) && ((xred+1) == ((int)(xblu+x_arrow)))) {
        banzai(36, 33, xblu, yblu, xred, yred);
        *ok = 1;
        break;
      }
    }
    x_arrow = x_arrow + CPU_SPEED;
  }
  return 0;
}


int arrow2(int *ok, char *player2)
{
  int v, a;
  double ag;
  double x_arrow, y_arrow;

  if ((strcmp(player2, "-1")) == 0) {
    v = 20 + (rand() % 10);
    a = 10 + (rand() % 30);
    ag = (a * 3.14) / 180;
  }
  else
    input_data(71, &v, &ag);
  x_arrow=0;
  while (x_arrow <= 80) {
    y_arrow=(sin(ag)/cos(ag)*x_arrow)-(0.5*9.82*pow(x_arrow, 2))/
            pow(v*cos(ag), 2);
    if (((yred-y_arrow) < 1) || (xred-x_arrow < 0) || ((yred-y_arrow) > 26)) {
      printf("\x1b[33m\x1b[%d;%dH?\b", yred-1, xred+2);
    }
    else {
      printf("\x1b[1;33m\x1b[%d;%dH<-\b", (int)(yred-1-y_arrow),
            (int)(xred-x_arrow));
      printf("\x1b[30m\x1b[%d;%dH  \b", (int)(yred-1-y_arrow),
            (int)(xred-x_arrow));
      if (((int)(xred-x_arrow) == (xblu+1)) && (((yred-y_arrow) > (yblu+3)) &&
         ((yred-y_arrow) < 25)))
        break;
      if ((((int)(yred-1-y_arrow) == yblu) || ((int)(yred-1-y_arrow) ==
         (yblu+1))) && ((xblu+1) == ((int)(xred-x_arrow)))) {
        banzai(33, 36, xred-4, yred, xblu, yblu);
        *ok = 1;
        break;
      }
    }
    x_arrow = x_arrow + CPU_SPEED;
  }
  return 0;
}


int banzai(int color1, int color2, int col1, int row1, int col2, int row2)
{
  printf("\x1b[1;%dm", color1);
  printf("\x1b[%d;%dHBanzai!", row1-1, col1);
  for (j=1; j<20; j++) {
    for (i=1; i<50; i++) {
      printf("\x1b[1;%dm", color2);
      printf("\x1b[%d;%dH_O_\b", row2, col2);
      printf("\x1b[%d;%dH/ \\\b", row2+1, col2);
    }
    for (i=1; i<50; i++) {
      printf("\x1b[0;30m\x1b[%d;%dH_O_\b", row2, col2);
      printf("\x1b[%d;%dH/ \\\b", row2+1, col2);
    }
  }
  return 0;
}


int main(int argc, char *argv[])
{
  time_t t;
  char nbattles[5];
  int battles;
  int ok;
 
  if ((strcmp(argv[1], "-v") == 0) && (argc == 2)) {
    printf("\nBanzai v1.0 - (c)March 1996\n");
    printf("by Francesco Munaretto\n");
    printf("franz@milliways.stat.unipd.it\n\n");
    exit(1);
  }
  if (((strcmp(argv[1], "-1") == 0) || (strcmp(argv[1], "-2") == 0)) &&
     (argc == 2)) {
    printf("\x1b[2J\x1b[12;30HNumber of battles: ");
    gets(nbattles);
    for(n=1; n<atoi(nbattles)+1; n++) {
      ok = 0;
      srand((unsigned) time(&t));
      xblu = 2 + (rand() % 20);
      yblu = 5 + (rand() % 17);
      xred = 60 + (rand() % 17);
      yred = 5 + (rand() % 17);
      draw_all(n);
      title();
      do {
        draw_all(n);
        arrow1(&ok);
        if (ok != 1) {
          draw_all(n);
          arrow2(&ok, argv[1]);
        }
      }
      while (ok != 1);
      printf("\x1b[0m\x1b[25;1H\x1b[2J");
    }
  }
  else {
    printf("usage: banzai [option]\n");
    printf("options: -1 one player\n");
    printf("         -2 tow players\n");
    printf("         -v prints version information\n\n");
    printf("Your mission is to hit your opponent with an arrow-shot.\n");
    printf("You must type the initial power (1-99) and angle (1-90) of the arrow.\n"); 
  }
  return 0;
}
