/*
    X Snake -- snake for the X Window System
    Copyright (C) 1996  Ronen Tzur  (rtzur@shani.net)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <fcntl.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pwd.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <X11/keysym.h>
#include <X11/Xlib.h>
#include <X11/Xresource.h>
#include <X11/Xutil.h>
#include "icon.xbm"

#define WINDOW_X 50
#define WINDOW_Y 50
#define WINDOW_WIDTH 450
#define WINDOW_HEIGHT 350
#define PLAYFIELD_WIDTH 100
#define PLAYFIELD_HEIGHT 100
#define FRAME_TIME_DIFF 40000           /* 25 fps */
#define MIN_ZOOM 2
#define SNAKE_MAX_LENGTH 100
#define SNAKE_START_LENGTH 10
#define SNAKE_APPLE_LENGTH 5
#define SNAKE_LIVES 3
#define ALLOC_STEP 20
#define ANGLE_STEP 0.3
#define APPLE_SCORE 50
#define SMALL_APPLE 1
#define MEDIUM_APPLE 2
#define LARGE_APPLE 3
#define APPLE_BLINK_COUNT 5
#define APPLE_TIME_DIFF 2
#define MAX_LEVEL_WALLS 100
#define EXTRA_LIFE_DIFF 2000
#define APPLES_PER_LEVEL 15
#define FONT_NAME "-misc-fixed-medium-*-normal-*-15-0-*-*-*-*-iso8859-1"
#define MAX_USER_NAME 32

#define NORMALIZE(x) ((int)((x) * 1000))
#define DENORMALIZE(x) ((double)x / 1000)
#define TRUNCATE(x) (DENORMALIZE(NORMALIZE((x))))
#define DEGREES_45  TRUNCATE(M_PI_4)
#define DEGREES_135 TRUNCATE(M_PI_2 + M_PI_4)
#define DEGREES_225 TRUNCATE(M_PI + M_PI_4)
#define DEGREES_315 TRUNCATE(M_PI + M_PI_2 + M_PI_4)

static Display *display = NULL;
static Window window;
static Atom protocol_atom, delete_window_atom;
static GC white_gc, black_gc;
static int window_width, window_height;
static XFontStruct *font_struct;
static char *score_file;

static int game_running, game_freeze;
static int game_over = 0, level_done = 0;
static int game_score, game_level, last_extra_score;
static int last_game_score, high_score = 0;
static char high_user[MAX_USER_NAME + 1];
static int key_left_down = 0, key_right_down = 0;
static struct timeval last_frame_time;
static int frame_time_diff = FRAME_TIME_DIFF;

static int playfield_width = PLAYFIELD_WIDTH;
static int playfield_height = PLAYFIELD_HEIGHT;
static int cell_width, cell_height;

static struct {
   double x, y;
} *snake_body;
static int snake_max_length = SNAKE_MAX_LENGTH;
static int snake_length, snake_new_length;
static double snake_angle;
static int snake_dead = 0;
static int snake_lives;

static int apple_x, apple_y;
static int apple_size, apple_score;
static int apple_blink_count;
static int apple_showing;
static struct timeval last_apple_time;
static int apple_time_diff = APPLE_TIME_DIFF;
static int apples_left;

static struct {
   double x, y;
} *level_walls;
static int num_level_walls;
static int max_level_walls = MAX_LEVEL_WALLS;

static XrmDatabase init_resource_and_display(int *argc, char **argv);
static void init_window(XrmDatabase database, int argc, char **argv);
static void read_score(void);
static void init_game(int *argc, char **argv);
static void close_game(void);
static int collision(double ax, double ay, int asize,
                     double bx, double by, int bsize);
static void status_line(int show);
static void level_line(double x1, double y1, double x2, double y2);
static void new_level(void);
static void new_demo(void);
static void new_game(void);
static void expose_window(int x, int y, int width, int height);
static int event_loop(void);
static void move_snake(void);
static void computer_snake(void);
static void handle_apple(struct timeval *tv);
static int game_loop(void);
void main(int argc, char *argv[]);

XrmDatabase init_resource_and_display(int *argc, char **argv)
{
   static XrmOptionDescRec options[] = {
      { "-display", ".display", XrmoptionSepArg, NULL },
      { "-reverse", ".reverse", XrmoptionNoArg, "true" },
      { "-noreverse", ".reverse", XrmoptionNoArg, "false" },
      { "-width", ".width", XrmoptionSepArg, NULL },
      { "-height", ".height", XrmoptionSepArg, NULL },
      { "-fps", ".fps", XrmoptionSepArg, NULL },
      { "-font", ".font", XrmoptionSepArg, NULL },
      { "-geometry", ".geometry", XrmoptionSepArg, NULL }
   };
   XrmDatabase database;
   char *str;
   char *type;
   XrmValue value;
   int fps;
   
   XrmInitialize();
   database = NULL;
   XrmParseCommand(&database, options, sizeof(options) / sizeof(options[0]),
                   "XSnake", argc, argv);
   if (*argc != 1) {
      printf("usage: %s\n"
             "\t[-display displayname]\n"
             "\t[-reverse] [-noreverse]\n"
             "\t[-width number] [-height number]\n"
             "\t[-fps number]\n"
             "\t[-font fontname]\n"
             "\t[-geometry geometry]\n", argv[0]);
      exit(EXIT_FAILURE);
   }

   if (!XrmGetResource(database, "xsnake.display", "XSnake.display",
                       &type, &value))
      value.addr = NULL;
   display = XOpenDisplay(value.addr);
   if (display == NULL) {
      printf("cannot open display %s\n", value.addr);
      exit(EXIT_FAILURE);
   }

   str = XScreenResourceString(XDefaultScreenOfDisplay(display));
   if (str != NULL)
      XrmCombineDatabase(XrmGetStringDatabase(str), &database, False);
   str = XResourceManagerString(display);
   if (str != NULL)
      XrmCombineDatabase(XrmGetStringDatabase(str), &database, False);
   XrmCombineDatabase(XrmGetFileDatabase("/usr/lib/X11/app-defaults/XSnake"),
                      &database, False);

   if (XrmGetResource(database, "xsnake.width", "XSnake.width",
                      &type, &value))
      playfield_width = atoi(value.addr);
   if (XrmGetResource(database, "xsnake.height", "XSnake.height",
                      &type, &value))
      playfield_height = atoi(value.addr);
      
   if (XrmGetResource(database, "xsnake.fps", "XSnake.fps",
                      &type, &value)) {
      fps = atoi(value.addr);
      if (fps < 1)
         fps = 1;
      frame_time_diff = 1000000 / fps;
   }

   protocol_atom = XInternAtom(display, "WM_PROTOCOLS", False);
   delete_window_atom = XInternAtom(display, "WM_DELETE_WINDOW", False);
   
   return database;
}

void init_window(XrmDatabase database, int argc, char **argv)
{
   char *type;
   XrmValue value;
   int white, black;
   int mask;
   XSizeHints sh;
   XWMHints wmh;
   XClassHint ch;

   if (!XrmGetResource(database, "xsnake.reverse", "XSnake.reverse",
                       &type, &value))
      value.addr = "false";

   /*
      Important: `white' is used to turn pixels on, `black' to turn
      them off. These are semantics only, as the real colors will
      probably go the other way around.
   */

   if (strcasecmp(value.addr, "true") == 0) {
      white = WhitePixel(display, DefaultScreen(display));
      black = BlackPixel(display, DefaultScreen(display));
   } else {
      white = BlackPixel(display, DefaultScreen(display));
      black = WhitePixel(display, DefaultScreen(display));
   }
   
   if (!XrmGetResource(database, "xsnake.geometry", "XSnake.geometry",
                       &type, &value))
      value.addr = NULL;
   sh.flags = 0;
   mask = XParseGeometry(value.addr, &sh.x, &sh.y, &sh.width, &sh.height);
   
   if (mask & WidthValue)
      sh.flags |= USSize;
   else {
      sh.flags |= PSize;
      sh.width = WINDOW_WIDTH;
   }
   if (sh.width < playfield_width * MIN_ZOOM)
      sh.width = playfield_width * MIN_ZOOM;
   sh.width -= sh.width % playfield_width;   
   
   if (mask & HeightValue)
      sh.flags |= USSize;
   else {
      sh.flags |= PSize;
      sh.height = WINDOW_HEIGHT;
   }
   if (sh.height < playfield_height * MIN_ZOOM)
      sh.height = playfield_height * MIN_ZOOM;
   sh.height -= sh.height % playfield_height;
   
   sh.win_gravity = ForgetGravity;
   if (mask & XValue) {
      sh.flags |= USPosition;
      if (mask & XNegative) {
         sh.x += DisplayWidth(display, DefaultScreen(display)) - sh.width - 2;
         sh.win_gravity = EastGravity;
      } else
         sh.win_gravity = WestGravity;
   } else {
      sh.x = WINDOW_X;
      sh.win_gravity = WestGravity;
   }
   
   if (mask & YValue) {
      sh.flags |= USPosition;
      if (mask & YNegative) {
         sh.y += DisplayHeight(display, DefaultScreen(display)) -
                 sh.height - 2;
         if (sh.win_gravity == WestGravity)
            sh.win_gravity = SouthWestGravity;
         if (sh.win_gravity == EastGravity)
            sh.win_gravity = SouthEastGravity;
      } else {
         if (sh.win_gravity == WestGravity)
            sh.win_gravity = NorthWestGravity;
         if (sh.win_gravity == EastGravity)
            sh.win_gravity = NorthEastGravity;
      }
   } else {
      sh.y = WINDOW_Y;
      if (sh.win_gravity == WestGravity)
         sh.win_gravity = NorthWestGravity;
      if (sh.win_gravity == EastGravity)
         sh.win_gravity = NorthEastGravity;
   }
   sh.flags |= PWinGravity;

   window = XCreateSimpleWindow(display,
                                RootWindow(display, DefaultScreen(display)),
                                sh.x, sh.y, sh.width, sh.height, 1,
                                black, black);
   XSelectInput(display, window, KeyPressMask | KeyReleaseMask |
                ExposureMask | FocusChangeMask | ResizeRedirectMask |
                StructureNotifyMask);

   sh.flags |= PMinSize | PResizeInc;
   sh.min_width = playfield_width * MIN_ZOOM;
   sh.min_height = playfield_height * MIN_ZOOM;
   sh.width_inc = playfield_width;
   sh.height_inc = playfield_height;

   wmh.flags = InputHint | StateHint | IconPixmapHint;
   wmh.input = True;
   wmh.initial_state = NormalState;
   wmh.icon_pixmap = XCreateBitmapFromData(display, window, icon_bits,
                                           ICON_WIDTH, ICON_HEIGHT);
   ch.res_name = NULL;
   ch.res_class = "XSnake";
   XmbSetWMProperties(display, window, "X Snake", "X Snake", argv, argc,
                      &sh, &wmh, &ch);
   XSetWMProtocols(display, window, &delete_window_atom, 1);

   if (!XrmGetResource(database, "xsnake.font", "XSnake.font",
                      &type, &value))
      value.addr = FONT_NAME;
   font_struct = XLoadQueryFont(display, value.addr);
   if (font_struct == NULL) {
      printf("cannot load font %s\n", value.addr);
      exit(EXIT_FAILURE);
   }

   white_gc = XCreateGC(display, window, 0, NULL);
   XSetForeground(display, white_gc, white);
   XSetFillStyle(display, white_gc, FillSolid);
   XSetFont(display, white_gc, font_struct->fid);
   
   black_gc = XCreateGC(display, window, 0, NULL);
   XSetForeground(display, black_gc, black);
   XSetFillStyle(display, black_gc, FillSolid);
   XSetFont(display, black_gc, font_struct->fid);

   window_width = sh.width;
   window_height = sh.height;
   cell_width = window_width / playfield_width;
   cell_height = window_height / playfield_height;
   
   XMapWindow(display, window);
}

void read_score(void)
{
   FILE *fp;
   struct flock lock;
   int score;
   char user[MAX_USER_NAME + 1];
   
   fp = fopen(score_file, "rb");
   if (fp != NULL) {
      lock.l_type = F_RDLCK;
      lock.l_whence = SEEK_SET;
      lock.l_start = 0;
      lock.l_len = 1;
      fcntl(fileno(fp), F_SETLKW, &lock);
      fread(&score, sizeof(score), 1, fp);
      fread(user, sizeof(user), 1, fp);
      user[MAX_USER_NAME] = 0;
      fclose(fp);
      if (score >= high_score) {
         high_score = score;
         strcpy(high_user, user);
      }
   } else {
      high_score = 0;
      strcpy(high_user, "nobody");
   }
}

void init_game(int *argc, char *argv[])
{
   XrmDatabase database;
   char *home;

   database = init_resource_and_display(argc, argv);
   init_window(database, *argc, argv);
   XSync(display, False);

   snake_body = malloc(snake_max_length * sizeof(snake_body[0]));
   level_walls = malloc(max_level_walls * sizeof(level_walls[0]));
   srand(time(NULL));

   home = getenv("HOME");
   score_file = malloc(strlen(home) + 20);
   sprintf(score_file, "%s/.xsnake.score", home);

   new_demo();
}

void close_game(void)
{
   FILE *fp;
   struct flock lock;
   
   XCloseDisplay(display);

   read_score();
   fp = fopen(score_file, "w+b");
   if (fp != NULL) {
      lock.l_type = F_WRLCK;
      lock.l_whence = SEEK_SET;
      lock.l_start = 0;
      lock.l_len = 1;
      fcntl(fileno(fp), F_SETLKW, &lock);
      fwrite(&high_score, sizeof(high_score), 1, fp);
      fwrite(&high_user, sizeof(high_user), 1, fp);
      fclose(fp);
   }
}

int collision(double ax, double ay, int asize,
              double bx, double by, int bsize)
{
   int ax1, ay1;
   int ax2, ay2;
   int bx1, by1;
   int bx2, by2;

   ax1 = ax * cell_width;
   ay1 = ay * cell_height;
   ax2 = (ax + asize) * cell_width;
   ay2 = (ay + asize) * cell_height;
   
   bx1 = bx * cell_width;;
   by1 = by * cell_height;
   bx2 = (bx + bsize) * cell_width;
   by2 = (by + bsize) * cell_height;

   if (ax1 >= bx1 && ay1 >= by1 && ax1 < bx2 && ay1 < by2) /* ax1,ay1 */
      return 1;
   if (ax1 >= bx1 && ay2 >= by1 && ax1 < bx2 && ay2 < by2) /* ax1,ay2 */
      return 1;
   if (ax2 >= bx1 && ay1 >= by1 && ax2 < bx2 && ay1 < by2) /* ax2,ay1 */
      return 1;
   if (ax2 >= bx1 && ay2 >= by1 && ax2 < bx2 && ay2 < by2) /* ax2,ay2 */
      return 1;

   if (bx1 >= ax1 && by1 >= ay1 && bx1 < ax2 && by1 < ay2) /* bx1,by1 */
      return 1;
   if (bx1 >= ax1 && by2 >= ay1 && bx1 < ax2 && by2 < ay2) /* bx1,by2 */
      return 1;
   if (bx2 >= ax1 && by1 >= ay1 && bx2 < ax2 && by1 < ay2) /* bx2,by1 */
      return 1;
   if (bx2 >= ax1 && by2 >= ay1 && bx2 < ax2 && by2 < ay2) /* bx2,by2 */
      return 1;

   return 0;
}
       
void status_line(int show)
{
   char msg[64];
   int dir;
   int ascent, descent;
   XCharStruct cs;
   int x, y;

   if (game_freeze)
      strcpy(msg, "Game Paused");
   else
      if (snake_dead || level_done)
         strcpy(msg, snake_dead ? "Snake Lost" : "Level Completed");
      else
         if (game_running)
            sprintf(msg, "Level %ld  Lives %ld  Apples %ld  Score %ld",
                    game_level, snake_lives, apples_left, game_score);
         else
            if (game_over)
               sprintf(msg, "Game Over ... Score %ld", last_game_score);
            else
               sprintf(msg, "Demo ... High score %ld by %s",
                       high_score, high_user);

   XTextExtents(font_struct, msg, strlen(msg), &dir, &ascent, &descent, &cs);
   x = (window_width - (cs.rbearing - cs.lbearing)) / 2;
   y = window_height - (font_struct->max_bounds.ascent +
                        font_struct->max_bounds.descent);
   XDrawString(display, window, show ? white_gc : black_gc, x, y,
               msg, strlen(msg));
}

void level_line(double x1, double y1, double x2, double y2)
{
   int vert, done;

   vert = x1 == x2;
   x1 *= playfield_width;
   y1 *= playfield_height;
   x2 *= playfield_width;
   y2 *= playfield_height;
   done = 0;

   while (!done) {
      level_walls[num_level_walls].x = x1;
      level_walls[num_level_walls].y = y1;
      num_level_walls++;
      if (num_level_walls == max_level_walls) {
         max_level_walls += ALLOC_STEP;
         level_walls = realloc(level_walls,
                               max_level_walls * sizeof(level_walls[0]));
      }
      if (vert) {
         y1++;
         done = y1 > y2;
      } else {
         x1++;
         done = x1 > x2;
      }
   }
}

void new_level(void)
{
   num_level_walls = 0;
   apples_left = game_level * APPLES_PER_LEVEL;

   switch (game_level) {
      case 1:
         break;

      case 2:
         level_line(0.1, 0.1, 0.9, 0.1);
         level_line(0.3, 0.3, 0.7, 0.3);
         level_line(0.3, 0.7, 0.7, 0.7);
         level_line(0.1, 0.9, 0.9, 0.9);
         break;

      case 3:
         level_line(0.1, 0.1, 0.1, 0.9);
         level_line(0.9, 0.1, 0.9, 0.9);
         level_line(0.3, 0.1, 0.7, 0.1);
         level_line(0.3, 0.9, 0.7, 0.9);
         level_line(0.3, 0.3, 0.3, 0.7);
         level_line(0.7, 0.3, 0.7, 0.7);
         break;

      case 4:
         level_line(0.0, 0.2, 0.8, 0.2);
         level_line(0.8, 0.2, 0.8, 0.8);
         level_line(0.2, 0.8, 0.8, 0.8);
         level_line(0.2, 0.4, 0.6, 0.4);
         level_line(0.6, 0.4, 0.6, 0.6);
         level_line(0.4, 0.6, 0.6, 0.6);
         break;

      case 5:
         level_line(0.2, 0.0, 0.2, 0.8);
         level_line(0.4, 0.2, 0.4, 1.0);
         level_line(0.6, 0.0, 0.6, 0.8);
         level_line(0.8, 0.2, 0.8, 1.0);
         break;

      case 6:
         level_line(0.2, 0.2, 0.4, 0.2);
         level_line(0.6, 0.2, 0.8, 0.2);
         level_line(0.2, 0.2, 0.2, 0.4);
         level_line(0.4, 0.2, 0.4, 0.5);
         level_line(0.6, 0.2, 0.6, 0.5);
         level_line(0.8, 0.2, 0.8, 0.4);
         level_line(0.0, 0.5, 0.4, 0.5);
         level_line(0.6, 0.5, 1.0, 0.5);
         level_line(0.2, 0.6, 0.2, 0.8);
         level_line(0.4, 0.5, 0.4, 0.8);
         level_line(0.6, 0.5, 0.6, 0.8);
         level_line(0.8, 0.6, 0.8, 0.8);
         level_line(0.2, 0.8, 0.4, 0.8);
         level_line(0.6, 0.8, 0.8, 0.8);
         break;

      case 7:
         level_line(0.1, 0.2, 0.4, 0.2);
         level_line(0.6, 0.2, 0.9, 0.2);
         level_line(0.1, 0.2, 0.1, 0.8);
         level_line(0.9, 0.2, 0.9, 0.8);
         level_line(0.1, 0.8, 0.4, 0.8);
         level_line(0.6, 0.8, 0.9, 0.8);
         level_line(0.2, 0.4, 0.4, 0.4);
         level_line(0.6, 0.4, 0.8, 0.4);
         level_line(0.2, 0.4, 0.2, 0.6);
         level_line(0.8, 0.4, 0.8, 0.6);
         level_line(0.2, 0.6, 0.4, 0.6);
         level_line(0.6, 0.6, 0.8, 0.6);
         break;
         
      case 8:
         level_line(0.0, 0.1, 0.1, 0.1);
         level_line(0.3, 0.1, 0.4, 0.1);
         level_line(0.6, 0.1, 0.7, 0.1);
         level_line(0.9, 0.1, 1.0, 0.1);
         level_line(0.0, 0.3, 0.3, 0.3);
         level_line(0.4, 0.3, 0.6, 0.3);
         level_line(0.7, 0.3, 1.0, 0.3);
         level_line(0.0, 0.5, 0.4, 0.5);
         level_line(0.6, 0.5, 1.0, 0.5);
         level_line(0.0, 0.7, 0.3, 0.3);
         level_line(0.4, 0.7, 0.6, 0.3);
         level_line(0.7, 0.7, 1.0, 0.3);
         level_line(0.0, 0.9, 0.1, 0.9);
         level_line(0.3, 0.9, 0.4, 0.9);
         level_line(0.6, 0.9, 0.7, 0.9);
         level_line(0.9, 0.9, 1.0, 0.9);
         break;

      case 9:
         level_line(0.4, 0.4, 0.6, 0.4);
         level_line(0.4, 0.4, 0.4, 0.6);
         level_line(0.6, 0.4, 0.6, 0.6);
         level_line(0.4, 0.6, 0.6, 0.6);
         break;
   }
}

void new_demo(void)
{
   read_score();
   new_game();
   status_line(0);
   apples_left = 0;
   game_running = game_freeze = 0;
   switch (rand() % 4) {
      case 0:
         snake_angle = DEGREES_45;
         break;
      case 1:
         snake_angle = DEGREES_135;
         break;
      case 2:
         snake_angle = DEGREES_225;
         break;
      case 3:
         snake_angle = DEGREES_315;
         break;
   }
}

void new_game(void)
{
   key_left_down = key_right_down = 0;
   snake_body[0].x = playfield_width / 2;
   snake_body[0].y = playfield_height / 2;
   snake_angle = M_PI_2;
   snake_length = 1;
   gettimeofday(&last_frame_time, NULL);
   gettimeofday(&last_apple_time, NULL);
   apple_x = -1;
   if (snake_dead || level_done) {
      if (level_done) {
         snake_new_length = SNAKE_START_LENGTH;
         game_level++;
         new_level();
      }
      snake_dead = level_done = 0;
   } else {
      snake_new_length = SNAKE_START_LENGTH;
      snake_lives = SNAKE_LIVES;
      game_score = last_extra_score = 0;
      game_level = 1;
      new_level();
   }
   game_running = 1;
   expose_window(0, 0, window_width, window_height);
}
         
void expose_window(int x, int y, int width, int height)
{
   XRectangle rect;
   int i;

   XClearArea(display, window, x, y, width, height, False);
   rect.x = x;
   rect.y = y;
   rect.width = width;
   rect.height = height;
   XSetClipRectangles(display, white_gc, 0, 0, &rect, 1, Unsorted);
   XSetClipRectangles(display, black_gc, 0, 0, &rect, 1, Unsorted);

   status_line(1);
   
   for (i = 0; i < snake_length; i++)
      XFillRectangle(display, window, white_gc,
                     (int)(snake_body[i].x * cell_width),
                     (int)(snake_body[i].y * cell_height),
                     cell_width, cell_height);

   for (i = 0; i < num_level_walls; i++)
      XFillRectangle(display, window, white_gc,
                     (int)(level_walls[i].x * cell_width),
                     (int)(level_walls[i].y * cell_height),
                     cell_width, cell_height);

   if (apple_x != -1 && apple_showing)
      XFillRectangle(display, window, white_gc,
                     apple_x * cell_width, apple_y * cell_height,
                     cell_width * apple_size, cell_height * apple_size);
   
   XSetClipMask(display, white_gc, None);
   XSetClipMask(display, black_gc, None);
   XSync(display, False);
}
   
int event_loop(void)
{
   XEvent ev;
   XSetWindowAttributes swa;
   XWindowChanges wc;
   
   while (XEventsQueued(display, QueuedAfterReading) > 0) {
      XNextEvent(display, &ev);
      switch (ev.type) {
      
         case KeyPress:
            switch (XLookupKeysym(&ev.xkey, ev.xkey.state)) {
               case XK_Left:
                  if (game_running)
                     key_left_down = 1;
                  break;
               case XK_Right:
                  if (game_running)
                     key_right_down = 1;
                  break;
               case XK_Up:
                  if (!game_running && !game_freeze)
                     new_game();
                  break;
               case XK_Escape:
                  status_line(0);
                  game_freeze = !game_freeze;
                  status_line(1);
                  break;
               case XK_a:
                  if (game_freeze) {
                     snake_dead = level_done = game_over = 0;
                     new_demo();
                  }
                  break;
               case XK_q:
                  if (game_freeze)
                     return 0;
                  break;
            }
            break;
            
         case KeyRelease:
            switch (XLookupKeysym(&ev.xkey, ev.xkey.state)) {
               case XK_Left:
                  key_left_down = 0;
                  break;
               case XK_Right:
                  key_right_down = 0;
                  break;
            }
            break;

         case Expose:
            expose_window(ev.xexpose.x, ev.xexpose.y,
                          ev.xexpose.width, ev.xexpose.height);
            break;

         case ResizeRequest:
            if (ev.xresizerequest.width != window_width ||
                ev.xresizerequest.height != window_height) {
               window_width = ev.xresizerequest.width;
               window_height = ev.xresizerequest.height;
               cell_width = window_width / playfield_width;
               cell_height = window_height / playfield_height;
               swa.override_redirect = True;
               XChangeWindowAttributes(display, window,
                                       CWOverrideRedirect, &swa);
               wc.width = window_width;
               wc.height = window_height;
               XConfigureWindow(display, window, CWWidth | CWHeight, &wc);
               swa.override_redirect = False;
               XChangeWindowAttributes(display, window,
                                       CWOverrideRedirect, &swa);
               expose_window(0, 0, window_width, window_height);
            }
            break;

         case FocusIn:
            if (!game_running) {
               status_line(0);
               game_freeze = 0;
               status_line(1);
            }
            break;

         case FocusOut:
            if (game_running) {
               status_line(0);
               game_freeze = 1;
               status_line(1);
            }
            break;

         case UnmapNotify:
            game_freeze = 1;
            break;

         case MappingNotify:
            XRefreshKeyboardMapping(&ev.xmapping);
            break;
            
         case ClientMessage:
            if (ev.xclient.message_type == protocol_atom &&
                ev.xclient.data.l[0] == delete_window_atom)
               return 0;
            break;
      }
   }
   
   return 1;
}

void move_snake(void)
{
   int i;
   int redraw;
   
   redraw = 0;
   if (snake_length < snake_new_length) {
      snake_length++;
      if (snake_length == snake_max_length) {
         snake_max_length += ALLOC_STEP;
         snake_body = realloc(snake_body,
                              snake_max_length * sizeof(snake_body[0]));
      }
   } else {
      for (i = 0; i < snake_length - 2; i++)
         if (collision(snake_body[snake_length - 1].x,
                       snake_body[snake_length - 1].y, 1,
                       snake_body[i].x, snake_body[i].y, 1)) {
            redraw = 1;
            break;
         }
      XFillRectangle(display, window, black_gc,
                        (int)(snake_body[snake_length - 1].x * cell_width),
                        (int)(snake_body[snake_length - 1].y * cell_height),
                        cell_width, cell_height);
   }

   for (i = snake_length - 1; i > 0; i--) {
      snake_body[i].x = snake_body[i - 1].x;
      snake_body[i].y = snake_body[i - 1].y;
   }
   snake_body[0].x += cos(snake_angle);
   snake_body[0].y -= sin(snake_angle);
   XFillRectangle(display, window, white_gc,
                  (int)(snake_body[0].x * cell_width),
                  (int)(snake_body[0].y * cell_height),
                  cell_width, cell_height);

   if (key_left_down) {
      snake_angle = snake_angle + ANGLE_STEP;
      if (snake_angle > 2 * M_PI)
         snake_angle -= 2 * M_PI;
   }
   if (key_right_down) {
      snake_angle = snake_angle - ANGLE_STEP;
      if (snake_angle < 0)
         snake_angle += 2 * M_PI;   
   }
   if (redraw)
      expose_window(0, 0, window_width, window_height);
   else
      status_line(1);
}

void computer_snake(void)
{
   int x, y;
   
   x = snake_body[0].x + cos(snake_angle) * 2;
   y = snake_body[0].y - sin(snake_angle) * 2;
   
   if (x >= 0 && x < playfield_width &&
       y >= 0 && y < playfield_height &&
       rand() % 100 == 0) {
      if (snake_angle == DEGREES_45)
         snake_angle = DEGREES_135;
      else
         if (snake_angle == DEGREES_135)
            snake_angle = DEGREES_225;
         else
            if (snake_angle == DEGREES_225)
               snake_angle = DEGREES_315;
            else
               snake_angle = DEGREES_45;

      if (snake_new_length < SNAKE_MAX_LENGTH)
         snake_new_length++;
   }
            
   if (x < 0 || x >= playfield_width)
      if (x < 0) {
         if (snake_angle == DEGREES_135)
            snake_angle = DEGREES_45;
         else                           /* DEGREES_225 */
            snake_angle = DEGREES_315;
      } else {
         if (snake_angle == DEGREES_45)
            snake_angle = DEGREES_135;
         else                           /* DEGREES_315 */
            snake_angle = DEGREES_225;
      }

   if (y < 0 || y >= playfield_height)
      if (y < 0) {
         if (snake_angle == DEGREES_135)
            snake_angle = DEGREES_225;
         else                           /* DEGREES_45 */
            snake_angle = DEGREES_315;
      } else {
         if (snake_angle == DEGREES_225)
            snake_angle = DEGREES_135;
         else                           /* DEGREES_315 */
            snake_angle = DEGREES_45;
      }
}

void handle_apple(struct timeval *tv)
{
   static int sizes[] = {
      LARGE_APPLE, LARGE_APPLE, LARGE_APPLE, LARGE_APPLE,
      MEDIUM_APPLE, MEDIUM_APPLE, MEDIUM_APPLE,
      SMALL_APPLE, SMALL_APPLE
   };
   int i;
   
   if (apple_x == -1) {
      if (tv->tv_sec - last_apple_time.tv_sec > apple_time_diff) {
         apple_size = sizes[rand() % (sizeof(sizes) / sizeof(sizes[0]))];
         apple_score = (LARGE_APPLE - apple_size + 1) * APPLE_SCORE;
         while (1) {
            apple_x = rand() % (playfield_width - apple_size) + 1;
            apple_y = rand() % (playfield_height - apple_size) + 1;
            for (i = 0; i < snake_length; i++)
               if (collision(snake_body[i].x, snake_body[i].y, 1,
                             apple_x, apple_y, apple_size))
                  break;
            if (i == snake_length) {
               for (i = 0; i < num_level_walls; i++)
                  if (collision(level_walls[i].x, level_walls[i].y, 1,
                                apple_x, apple_y, apple_size))
                     break;
               if (i == num_level_walls)
                  break;
            }
         }
         apple_showing = 0;
         apple_blink_count = 1;
      }
   }

   if (apple_x != -1) {
      apple_blink_count--;
      if (apple_blink_count == 0) {
         XFillRectangle(display, window,
                        apple_showing ? black_gc : white_gc,
                        apple_x * cell_width, apple_y * cell_height,
                        cell_width * apple_size, cell_height * apple_size);
         apple_blink_count = APPLE_BLINK_COUNT;
         apple_showing = !apple_showing;
         if (apple_score > 0)
            apple_score--;
      }
   
      if (collision(snake_body[0].x, snake_body[0].y, 1,
                    apple_x, apple_y, apple_size)) {
         XFillRectangle(display, window,
                        black_gc,
                        apple_x * cell_width, apple_y * cell_height,
                        cell_width * apple_size, cell_height * apple_size);
         XFillRectangle(display, window, white_gc,
                        (int)(snake_body[0].x * cell_width),
                        (int)(snake_body[0].y * cell_height),
                        cell_width, cell_height);
         XFillRectangle(display, window, white_gc,
                        (int)(snake_body[1].x * cell_width),
                        (int)(snake_body[1].y * cell_height),
                        cell_width, cell_height);
         if (game_running || snake_new_length < SNAKE_MAX_LENGTH)
            snake_new_length += SNAKE_APPLE_LENGTH;
         apple_x = -1;
         last_apple_time.tv_sec = tv->tv_sec;
         last_apple_time.tv_usec = tv->tv_usec;
         status_line(0);
         game_score += apple_score;
         if (game_score - last_extra_score > EXTRA_LIFE_DIFF) {
            last_extra_score = game_score;
            snake_lives++;
         }
         apples_left--;
         if (apples_left == 0) {
            level_done = 1;
            game_running = 0;
         }
         status_line(1);
      }
   }
}

int game_loop(void)
{
   struct timeval tv;
   int i;
   
   gettimeofday(&tv, NULL);
   if (tv.tv_sec > last_frame_time.tv_sec ||
       tv.tv_usec - last_frame_time.tv_usec > frame_time_diff) {
      last_frame_time.tv_sec = tv.tv_sec;
      last_frame_time.tv_usec = tv.tv_usec;

      if (!snake_dead && !level_done) {
         if (!game_freeze)
            move_snake();

         if (game_running) {
            if (snake_body[0].x < 0 || snake_body[0].x >= playfield_width ||
                snake_body[0].y < 0 || snake_body[0].y >= playfield_height)
               snake_dead = 1;
            for (i = 2; i < snake_length; i++)
               if (collision(snake_body[0].x, snake_body[0].y, 1,
                             snake_body[i].x, snake_body[i].y, 1))
                  snake_dead = 1;
            for (i = 0; i < num_level_walls; i++)
               if (collision(snake_body[0].x, snake_body[0].y, 1,
                             level_walls[i].x, level_walls[i].y, 1))
                  snake_dead = 1;
            if (snake_dead) {
               snake_dead = 0;
               if (snake_lives > 1) {
                  status_line(0);
                  snake_dead = 1;
                  snake_lives--;
                  status_line(1);
               } else {
                  last_game_score = game_score;
                  if (game_score > high_score) {
                     high_score = game_score;
                     strncpy(high_user, getpwuid(getuid())->pw_name, 32);;
                     high_user[MAX_USER_NAME] = 0;
                  }
                  game_over = 1;
                  new_demo();
               }
               game_running = 0;
            }
         } else
            if (!game_freeze)
               computer_snake();
      
         if (!game_freeze)
            handle_apple(&tv);
      }
      XSync(display, False);
   }
   
   return 1;
}

void main(int argc, char *argv[])
{
   init_game(&argc, argv);
   while (1) {
      if (!event_loop())
         break;
      if (!game_loop())
         break;
   }
   close_game();
}
