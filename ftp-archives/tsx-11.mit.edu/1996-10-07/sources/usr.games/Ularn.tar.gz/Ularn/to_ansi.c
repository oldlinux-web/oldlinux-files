/*
 * convert ascii sequence '^[' into escape characters
 */
#include <stdio.h>

main()
{
	int c, c2;

	while ((c = getc(stdin)) != EOF) {
	  if (c == '^') {
	    if ((c2 = getc(stdin)) != EOF) {
	      if (c2 == '[')
		putc('\033', stdout);
	      else {
		putc((char)c, stdout);
		putc((char)c2, stdout);
	      }
	    } else {
	      putc((char)c, stdout);
	      exit(0);
	    }
	  } else
	    putc((char)c, stdout);
	}
	exit(0);
}
