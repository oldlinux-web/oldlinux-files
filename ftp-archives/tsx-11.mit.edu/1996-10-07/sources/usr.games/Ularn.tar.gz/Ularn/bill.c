/* bill.c		 */

#include "header.h"

static char mail600[32];

/*
 *	function to create the tax bill for the user
 */
static int pid;

static int letter_hdr(err_num)
int    err_num;
{
int  ret_val;

        ret_val = 1;
#ifdef __MSDOS__
        clear();
#else
	sprintf(mail600, "/tmp/#%dmail600",pid); /* prepare path */
	if (lcreat(mail600,0) < 0) { 
	        sprintf(mail600, "can't write 60%1d letter\n", err_num);
		write(1, mail600, strlen(mail600)); 
		ret_val = 0;
	};
        lprcat("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
#endif
        return ( ret_val );
}


static  letter_trl()
{
#ifdef __MSDOS__
        retcont();
#else
	lwclose(); 
#endif
}

letter1()
{
int     ret_val;

        ret_val = letter_hdr(1);
        if ( ret_val ){
lprcat("From:"); 
lprcat("  the URS (Ularn Revenue Service)\n");
lprcat("\nSubject:"); 
lprcat("  undeclared income\n");
lprcat("\n   We heard you survived the caverns of Ularn.  Let me be the");
lprcat("\nfirst to congratulate you on your success.  It is quite a feat.");
lprcat("\nIt must also have been very profitable for you.");
lprcat("\n\n   The Dungeon Master has informed us that you brought");
lprintf("\n%d gold pieces back with you from your journey.  As the",
	(long)c[GOLD]);
lprcat("\ncounty of Ularn is in dire need of funds, we have spared no time");
lprintf("\nin preparing your tax bill.  You owe %d gold pieces as",
	(long)c[GOLD]*TAXRATE);
lprcat("\nof this notice, and is due within 5 days.  Failure to pay will");
lprcat("\nmean penalties.  Once again, congratulations, We look forward");
lprcat("\nto your future successful expeditions.\n");
          letter_trl();
        };
	return(ret_val);
}

letter2()
{
int     ret_val;

        ret_val = letter_hdr(2);
        if ( ret_val ){
lprcat("From:"); 
lprcat("  the USPCA (Ularn Society for the Prevention of Cruelty to Animals)\n");
lprcat("\nSubject:"); 
lprcat("  Endangered species\n");
lprcat("\n   We heard you slaughtered lots of dragons during your");
lprcat("\nadventures in the caverns of Ularn. These totally harmless");
lprcat("\ncreatures are now near extinction due to bloodthirsty butchers");
lprcat("\nlike you are. We will prove our solidarity with the cause of");
lprcat("\nthe weak and helpless whenever we shall see profit greedy");
lprcat("\nmurderers like you!\n");
lprcat("\nWE are prepared to DIE for our good cause, are YOU?");
          letter_trl();
        };
	return(ret_val);
}

letter3()
{
int     ret_val;

        ret_val = letter_hdr(3);
        if ( ret_val ){
lprcat("From:"); 
lprcat("  His Majesty King Wilfred of Ularndom\n");
lprcat("\nSubject:"); 
lprcat("  a noble deed\n");
lprcat("\n   I have heard of your magnificent feat, and I, King Wilfred,");
lprcat("\nforthwith declare today to be a national holiday.  Furthermore,");
lprcat("\nhence three days, Ye be invited to the castle to receive the");
lprcat( is_male ? 
       "\nhonour of Knight of the realm.  Upon thy name shall it be written. . ." :
       "\nhonour of Knightess of the realm.  Upon thy name shall it be written. . ." );
lprcat("\nBravery and courage be yours.");
lprcat("\nMay you live in happiness forevermore . . .\n");
          letter_trl();
        };
	return(ret_val);
}

letter4()
{
int     ret_val;

        ret_val = letter_hdr(4);
        if ( ret_val ){
	lprcat("From:"); 
	lprcat("  Count Endelford\n");
	lprcat("\nSubject:"); 
	lprcat( is_male ?
               "  You Bastard!\n" :
	       "  You Bitch!\n" );
        lprcat("\n   I heard (from sources) of your journey.  Congratulations!");
 	lprcat( is_male ? 
               "\nYou Bastard!  " :
	       "\nYou Bitch!  " );
lprcat("With several attempts I have yet to endure the");
lprcat(" caves,\nand you, a nobody, makes the journey!  From this time");
lprcat(" onward, bewarned\nupon our meeting you shall pay the price!\n");
          letter_trl();
        };
	return(ret_val);
}

letter5()
{
int     ret_val;

        ret_val = letter_hdr(5);
        if ( ret_val ){
	lprcat("From:"); 
	lprcat("  Mainair, Duke of Ularnty\n");
	lprcat("\nSubject:"); 
	lprcat("  High Praise\n");
lprcat("\n   With a certainty a hero I declare to be amongst us!  A nod of");
lprcat("\nfavour I send to thee.  Me thinks Count Endelford this day of");
lprcat("\nright breath'eth fire as of dragon of whom ye are slayer.  I");
lprcat("\nyearn to behold his anger and jealously.  Should ye choose to");
lprcat("\nunleash some of thy wealth upon those who be unfortunate, I,");
	lprcat("\nDuke Mainair, Shall equal thy gift also.\n");
          letter_trl();
        };
	return(ret_val);
}

letter6()
{
int     ret_val;

        ret_val = letter_hdr(6);
        if ( ret_val ){
	lprcat("From:"); 
	lprcat("  St. Mary's Children's Home\n");
	lprcat("\nSubject:"); 
	lprcat("  these poor children\n");
lprcat("\n   News of your great conquests has spread to all of Ularndom.");
lprcat("\nMight I have a moment of a great ");
lprcat(is_male ? "man's" : "woman's");
lprcat(" time.  We here at St.");
lprcat("\nMary's Children's Home are very poor, and many children are");
lprcat("\nstarving.  Disease is widespread and very often fatal without");
lprcat("\ngood food.  Could you possibly find it in your heart to help us");
	lprcat("\nin our plight?  Whatever you could give will help much.");
	lprcat("\n(your gift is tax deductible)\n");
          letter_trl();
        };
	return(ret_val);
}

letter7()
{
int     ret_val;

        ret_val = letter_hdr(7);
        if ( ret_val ){
  	lprcat("From:"); 
	lprcat("  The National Dianthroritis Society of Ularn\n");
	lprcat("\nSubject:"); 
	lprcat("  hope\n");
lprcat("\nCongratulations on your successful expedition.  We are sure much");
lprcat("\ncourage and determination were needed on your quest.  There are");
lprcat("\nmany though, that could never hope to undertake such a journey");
lprcat("\ndue to an enfeebling disease -- dianthroritis.  We at the National");
lprcat("\nDianthroritis Society of Ularn wish to appeal to your philanthropy in");
lprcat("\norder to save many good people -- possibly even yourself or a loved one a few");
lprcat("\nyears from now.  Much work needs to be done in researching this");
lprcat("\ndreaded disease, and you can help today.  Could you please see it");
lprcat("\nin your heart to give generously?  Your continued good health");
	lprcat("\ncan be your everlasting reward.\n");
          letter_trl();
        };
	return(ret_val);
}

/*
 *	function to mail the letters to the player if a winner
 */
static int (*pfn[])()= { 
	letter1, letter2, letter3, letter4, letter5, letter6, letter7 
};

mailbill()
{
	register int i;
	char buf[128];

#ifndef __MSDOS__
	wait(0);  
	pid=getpid();
	if (fork() == 0) {
#endif
		resetscroll();
		for (i=0; i<sizeof(pfn)/sizeof(int (*)()); i++)
			if ((*pfn[i])()) {
#ifndef __MSDOS__
				nap(20200);  
				sprintf(buf,"mail %s < %s",loginname,mail600);
				system(buf);  
				unlink(mail600);
#endif
			}
#ifndef __MSDOS__
		exit(0);
	}
#endif
}















