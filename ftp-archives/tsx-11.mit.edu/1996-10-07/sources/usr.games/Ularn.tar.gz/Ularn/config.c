/*
 *	config.c	
 *		    This defines the installation dependent variables.
 *                  Some strings are modified later.  ANSI C would
 *                  allow compile time string concatenation, we must
 *                  do runtime concatenation, in main.
 */
#include "header.h"

#ifdef __MSDOS__

# define HOMESIZE SAVEFILENAMESIZE
# define HOME ""

#else

# define HOMESIZE sizeof(HOME)

#endif

/* the game save filename   */
char savefilename[SAVEFILENAMESIZE] = 	HOME;

/* the score file	    	*/
char scorefile[HOMESIZE+sizeof(SCORENAME)] =	HOME;

/* the logging file    	*/
char logfile[HOMESIZE+sizeof(LOGFNAME)]  =	HOME;

/* the help text file	*/
char helpfile[HOMESIZE+sizeof(HELPNAME)] =	HOME;

/* the maze data file	*/
char larnlevels[HOMESIZE+sizeof(LEVELSNAME)] = 	HOME;

/* the fortune data file */
char fortfile[HOMESIZE+sizeof(FORTSNAME)] =	HOME;

/* the .Ularnopts filename */
char optsfile[SAVEFILENAMESIZE] ="/.Ularnopts";	/* the option file */

char diagfile[] ="Diagfile";		/* the diagnostic filename	*/
char ckpfile[] ="Ularn.ckp";		/* the checkpoint filename	*/
char *password ="takala";		/* the wizards password */
