/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/



#include <vga.h>

/*
 * compatible to BORLAND's TurboC(tm) function call:
 */

void putimage(int x0, int y0, void *buf, int dummy)
{
	short int *iptr = buf;
	short int xs = *iptr, ys = *(iptr+1);
	short int i,j;
	char *cptr = buf;
	cptr += 4;

	for(j =  y0; j-y0 <= ys; j++)
		for(i = x0; i-x0 <= xs; i++)
		{	vga_setcolor(*(cptr++));
			vga_drawpixel(i,j);
		}
}

