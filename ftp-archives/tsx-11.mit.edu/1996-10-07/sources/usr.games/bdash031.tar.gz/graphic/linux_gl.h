/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/

/***********************************************************************

linux_gl.h:	graphic interface for LinuX's svgalib/vgagllib HEADERFILE


*****************************************************end of header*****/
#ifdef OS_LINUX

#include "gr_interface.h"

#define GRAPHICS_MODE	G320x200x256

#define TEXTWIDTH(string)	(strlen(string)<<3)
#define TEXTHEIGHT(string)	8
#define FONTSIZE_X	8
#define FONTSIZE_Y	8
#define TEXTCOLOR	15
#define BLUE		9
#endif
