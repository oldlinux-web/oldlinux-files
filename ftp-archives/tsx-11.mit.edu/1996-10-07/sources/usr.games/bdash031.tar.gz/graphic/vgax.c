/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/



#include <vga.h>
#include <vgagl.h>

/*
 * compatible to BORLAND's TurboC(tm) function call:
 */

void putimage(int x0, int y0, void *buf, int dummy)
{
	char 	*cptr = buf;
	int	*iptr = buf;

	cptr += 4;

	gl_putbox(x0,y0,32,25,cptr);
}

