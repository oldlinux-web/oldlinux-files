/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/

/***********************************************************************

dos_bgi.h:	graphics interface for TurboC's BGI driver HEADERFILE

*****************************************************end of header*****/
#if defined OS_DOS && CC_TURBOC

#include "gr_interface.h"

#define TEXTWIDTH(string)	textwidth(string)
#define TEXTHEIGHT(string)	textheight(string)
#define FONTSIZE_X	8
#define FONTSIZE_Y	8
#define TEXTCOLOR	YELLOW

#endif
