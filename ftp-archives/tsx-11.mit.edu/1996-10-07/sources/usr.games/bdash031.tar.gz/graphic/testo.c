#include "GObject.h"
#include <vga.h>
#include <vgagl.h>
#include <assert.h>
#include "zfopen.h"
#define 	W	32
#define 	H	25

#define		GMODE	G320x200x256
char data[W][H];

int main(void)
{
	int x,y;
	FILE *in = zfopen("bdashobj","rb");
	vga_setmode(GMODE); 
	gl_setcontextvga(GMODE);

	assert(in);
	for(y=0;y < 200; y+=H)
		for(x = 0; x < 320; x+=W)
			godisplay(load(new(GObject,32,25,1),in), x, y);
	
	getchar();
	vga_setmode(TEXT);
	
	return 0;
}
