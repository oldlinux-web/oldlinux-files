# ifndef Point_h
# define Point_h

# include "Object.h"

extern const void * Point;

void move (void * _self, int dx, int dy);

void draw (const void * _self);

extern const void * PointClass;

#define	x(p)	(((const struct Point *)(p)) -> x)
#define	y(p)	(((const struct Point *)(p)) -> y)

# endif
