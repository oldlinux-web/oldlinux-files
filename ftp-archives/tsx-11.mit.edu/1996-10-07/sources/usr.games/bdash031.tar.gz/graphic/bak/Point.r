# ifndef Point_r
# define Point_r

# include "Object.r"

struct Point { const struct Object _;
	int x;
	int y;
};

struct PointClass { const struct Class _;
	struct Method draw;
};

void super_draw (const void * _class, const void * _self);

# endif
