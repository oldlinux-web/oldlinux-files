# ifndef GObject_h
# define GObject_h

# include "Object.h"

extern const void * GObject;

struct GObject * setdata (void * _self, void * data);
struct GObject * godisplay (void * _self, int x, int y);
struct GObject * move (void * _self, int x1, int y1, int x2, int y2);
struct GObject * save (void * _self, FILE * fp);
struct GObject * load (void * _self, FILE * fp);

extern const void * GClass;

#define width(g)    (((const struct GObject *)(g)) -> width)
#define height(g)    (((const struct GObject *)(g)) -> height)

# endif
