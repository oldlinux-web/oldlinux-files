
#include <vga.h>
#include <vgagl.h>
#include <stdlib.h>

#define		GMODE	G640x480x256
#define 	WHITE 15

void initfont() {
        void *font;
        font = malloc(256 * 8 * 8 * BYTESPERPIXEL);
        gl_expandfont(8, 8, WHITE, gl_font8x8, font);
        gl_setfont(8, 8, font);
}

int main(void)
{
	vga_setmode(GMODE); 
	gl_setcontextvga(GMODE);

	initfont();
	gl_setwritemode(WRITEMODE_OVERWRITE);
	
	gl_writen(0,0,6,"Hallo");
	getchar();	
	gl_writen(5,5,12,"Hello again");



	getchar();
	vga_setmode(TEXT);
	
	return 0;
}
