/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/****
*******> Kommunikationsroutinen fuer Boulder-Dash
****/
#ifdef __TURBOC__
#	ifdef BIOSCOM
#		include "commun_b.c"
#	else
#		include "commun_d.c"
#	endif
#else
void InitComm(void) {}
void SendByte(unsigned char Dta){}
void Send_Taste(int taste){}
int Receive_byte(void){ return 0;}
int Receive_Taste(void){ return Receive_byte();}
int detect_mode(void){ return 0;}
#endif
