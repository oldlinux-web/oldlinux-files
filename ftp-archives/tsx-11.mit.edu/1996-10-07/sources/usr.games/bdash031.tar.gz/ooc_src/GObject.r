# ifndef GObject_r
# define GObject_r

# include "Object.r"

struct GObject { const struct Object _;
	int width;
	int height;
	int bytesperpixel;
	void * buffer;
};

struct GClass { const struct Class _;
	struct Method setdata;
	struct Method godisplay;
	struct Method goundisplay;
	struct Method gomove;
	struct Method save;
	struct Method load;
};

struct GObject * super_setdata (const void * _class, void * _self, void * data);
struct GObject * super_godisplay (const void * _class, void * _self, int x, int y);
struct GObject * super_goundisplay (const void * _class, void * _self, int x, int y);
struct GObject * super_gomove (const void * _class, void * _self, int x1, int y1, int x2, int y2);
struct GObject * super_save (const void * _class, void * _self, FILE * fp);
struct GObject * super_load (const void * _class, void * _self, FILE * fp);

# endif
