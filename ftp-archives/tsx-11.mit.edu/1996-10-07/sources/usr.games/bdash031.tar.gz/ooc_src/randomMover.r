# ifndef randomMover_r
# define randomMover_r

# include "Mover.r"

struct randomMover { const struct Mover _;
};

# endif
