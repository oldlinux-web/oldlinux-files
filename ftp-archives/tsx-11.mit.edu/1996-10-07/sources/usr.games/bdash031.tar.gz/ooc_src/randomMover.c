# include "randomMover.h"
# include "randomMover.r"

/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
**** Changelog: ***************************************************************
Sat Dec 25 20:54:17  1993
*/

static struct Mover * randomMover_animate (void * _self) {
	struct randomMover * self = cast(randomMover, _self);

	int moved = '\0', tested = '\0';

	debug_printf("move_beetle_random()\n");
	while(! moved)
	{	if((direction(self) = direction(self) % 4) < 0)
			direction(self) =  0;
		debug_printf("\tnew direction = %d\n", direction(self));
		switch(direction(self))
		{ 	case 0:
			debug_printf("\tcase 0\n");
			if(xpos(self) > 0 && level_table[ypos(self)][xpos(self)-1] < FELD_ERDE)
			{ 	if(level_table[ypos(self)][xpos(self)-1] == FELD_SPIELER_1)
					tod();
				mmove(self, FELD_KAEFER_3+3,xpos(self),ypos(self),xpos(self)-1,ypos(self));
				xpos(self) =  xpos(self)-1; moved = '\1';
			}
			else
				if(rand()%2)
					direction(self) =  direction(self)+1;
				else
					direction(self) = direction(self)-1;

			break;

			case 1:
			debug_printf("\tcase 1\n");
			if(ypos(self) > 0 && level_table[ypos(self)-1][xpos(self)] < FELD_ERDE)
			{ 	if(level_table[ypos(self)-1][xpos(self)]==FELD_SPIELER_1)
					tod();
				mmove(self, FELD_KAEFER_3,xpos(self),ypos(self),xpos(self),ypos(self)-1);
				ypos(self) =  ypos(self)-1; moved = '\1';
			}
			else
				if(rand()%2)
					direction(self) =  direction(self)+1;
				else
					direction(self) = direction(self)-1;

			break;
			case 2:
			debug_printf("\tcase 2\n");
			if(xpos(self) < level_x_size-1 &&
				level_table[ypos(self)][xpos(self)+1] < FELD_ERDE)
			{ 	if(level_table[ypos(self)][xpos(self)+1]==FELD_SPIELER_1)
					tod();
				 mmove(self, FELD_KAEFER_3+1,xpos(self),ypos(self),xpos(self)+1,ypos(self));
				 xpos(self) = xpos(self)+1; moved = '\1';
			}
			else
				if(rand()%2)
					direction(self) =  direction(self)+1;
				else
					direction(self) = direction(self)-1;

			break;
			case 3:
			debug_printf("\tcase 3\n");
			if(ypos(self) < level_y_size-1 &&
				 level_table[ypos(self)+1][xpos(self)] < FELD_ERDE)
			{ 	if(level_table[ypos(self)+1][xpos(self)]==FELD_SPIELER_1)
				    tod();
				mmove(self,FELD_KAEFER_3+2,xpos(self),ypos(self),xpos(self),ypos(self)+1);
				ypos(self) =  ypos(self)+1; moved = '\1';
			}
			else
			{	if(rand()%2)
					direction(self) =  direction(self)+1;
				else
					direction(self) = direction(self)-1;
				moved = tested;      /* falls eingesperrt, nach 2. Durchlauf */
				tested = '\1';       /* abbrechen */
			}
			break;
		}
		debug_printf("\tend of while\n");
	    }/* switch & while */
}
static const void * initrandomMover (void)
{
	return ((struct Object *) randomMover) -> class ? randomMover :
		(randomMover = new(MoverClass,
			"randomMover", Mover, sizeof(struct randomMover),
			animate, "animate", randomMover_animate,
			(void *) 0));
}

static const struct ClassInit _randomMover = { { MAGIC }, initrandomMover };
const void * randomMover = & _randomMover;
