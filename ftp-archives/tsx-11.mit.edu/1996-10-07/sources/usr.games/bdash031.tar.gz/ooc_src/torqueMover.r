# ifndef torqueMover_r
# define torqueMover_r

# include "Mover.r"

struct torqueMover { const struct Mover _;
};

# endif
