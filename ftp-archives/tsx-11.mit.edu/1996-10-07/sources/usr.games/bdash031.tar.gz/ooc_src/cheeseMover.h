# ifndef cheeseMover_h
# define cheeseMover_h

# include "Mover.h"

/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
**** Changelog: ***************************************************************
*/

#ifndef CHEESE_DELAY
#	define CHEESE_DELAY 3
#endif

extern const void * cheeseMover;

# endif
