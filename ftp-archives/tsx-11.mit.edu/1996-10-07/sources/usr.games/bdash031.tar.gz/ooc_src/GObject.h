# ifndef GObject_h
# define GObject_h

# include "Object.h"

/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
**** Changelog: ***************************************************************
*/

extern const void * GObject;

struct GObject * setdata (void * _self, void * data);
struct GObject * godisplay (void * _self, int x, int y);
struct GObject * goundisplay (void * _self, int x, int y);
struct GObject * gomove (void * _self, int x1, int y1, int x2, int y2);
struct GObject * save (void * _self, FILE * fp);
struct GObject * load (void * _self, FILE * fp);

extern const void * GClass;

#define width(g)    (((const struct GObject *)(g)) -> width)
#define height(g)    (((const struct GObject *)(g)) -> height)

# endif
