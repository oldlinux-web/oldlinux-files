# include "lrMover.h"
# include "lrMover.r"

/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
**** Changelog: ***************************************************************
Sat Dec 25 20:53:27  1993
*/

static struct Mover * lrMover_animate (void * _self) {
	struct lrMover * self = cast(lrMover, _self);

	int moved = '\0', tested = '\0';

	D_ENTRY("lrMover.animate");

	while(! moved)
	{	debug_printf("direction = %d\n", direction(self));
		switch(direction(self))
		{	case 1: /* left */
			if(xpos(self) > 0 && level_table[ypos(self)][xpos(self)-1] < FELD_ERDE)
			{	if(level_table[ypos(self)][xpos(self)-1] == FELD_SPIELER_1)
					tod();
				mmove(self, FELD_KAEFER_5+direction(self),xpos(self),ypos(self),
					xpos(self)-1,ypos(self));
				xpos(self)--;
				moved = '\1';
			}
			else
				direction(self) = 0, tested = 1;
			break;

			case 0: /* right */
			if(xpos(self) < level_x_size && level_table[ypos(self)][xpos(self)+1] < FELD_ERDE)
			{	if(level_table[ypos(self)][xpos(self)+1] == FELD_SPIELER_1)
					tod();
				mmove(self, FELD_KAEFER_5+direction(self),xpos(self),ypos(self),
					xpos(self)+1,ypos(self));
				xpos(self)++;
				moved = '\1';
			}
			else
				direction(self) = 1, moved = tested, tested = 1;
		}
	}
	D_LEAVE
	return self;
}
static const void * initlrMover (void)
{
	return ((struct Object *) lrMover) -> class ? lrMover :
		(lrMover = new(MoverClass,
			"lrMover", Mover, sizeof(struct lrMover),
			animate, "animate", lrMover_animate,
			(void *) 0));
}

static const struct ClassInit _lrMover = { { MAGIC }, initlrMover };
const void * lrMover = & _lrMover;
