# ifndef cheeseMover_r
# define cheeseMover_r

# include "Mover.r"

struct cheeseMover { const struct Mover _;
	int counter;
};

# endif
