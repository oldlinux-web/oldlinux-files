# ifndef AnimObject_r
# define AnimObject_r

# include "GObject.r"

struct AnimObject { const struct GObject _;
};

# endif
