# ifndef List_h
# define List_h

# include "Collection.h"

/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
**** Changelog: ***************************************************************
*/

extern const void * List;

struct Object * addFirst (void * _self, const void * element);
struct Object * addLast (void * _self, const void * element);
struct Object * lookAt (const void * _self, unsigned n);
struct Object * takeFirst (void * _self);
struct Object * takeLast (void * _self);

struct Object * take (void * _self);

extern const void * ListClass;

# endif
