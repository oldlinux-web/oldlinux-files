# ifndef Queue_r
# define Queue_r

# include "List.r"

struct Queue { const struct List _;
};

# endif
