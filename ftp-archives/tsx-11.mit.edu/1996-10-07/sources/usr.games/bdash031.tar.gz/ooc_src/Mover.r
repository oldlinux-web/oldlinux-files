# ifndef Mover_r
# define Mover_r

# include "Object.r"

struct Mover { const struct Object _;
	int xpos;
	int ypos;
	int type;
	int direction;
	void * gobject;
};

struct MoverClass { const struct Class _;
	struct Method getxpos;
	struct Method getypos;
	struct Method gettype;
	struct Method getdir;
	struct Method setdir;
	struct Method setxpos;
	struct Method setypos;
	struct Method settype;
	struct Method mmove;
	struct Method mdisplay;
	struct Method animate;
};

int super_getxpos (const void * _class, void * _self);
int super_getypos (const void * _class, void * _self);
int super_gettype (const void * _class, void * _self);
int super_getdir (const void * _class, void * _self);
int super_setdir (const void * _class, void * _self, int dir);
int super_setxpos (const void * _class, void * _self, int x);
int super_setypos (const void * _class, void * _self, int y);
int super_settype (const void * _class, void * _self, int type);
struct Mover * super_mmove (const void * _class, void * _self, int figurnr, int x1, int y1, int x2, int y2);
struct Mover * super_mdisplay (const void * _class, void * _self);
struct Mover * super_animate (const void * _class, void * _self);

# endif
