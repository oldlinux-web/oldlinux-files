# ifndef List_r
# define List_r

# include "Collection.r"

struct List { const struct Collection _;
	unsigned nelts;
	unsigned begin;
	unsigned end;
};

struct ListClass { const struct CollectionClass _;
	struct Method take;
};

struct Object * super_take (const void * _class, void * _self);

# endif
