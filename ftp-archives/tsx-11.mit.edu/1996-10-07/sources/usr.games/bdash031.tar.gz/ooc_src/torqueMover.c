# include "torqueMover.h"
# include "torqueMover.r"

/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
**** Changelog: ***************************************************************
*/

static struct Mover * torqueMover_animate (void * _self) {
	struct torqueMover * self = cast(torqueMover, _self);

	int moved = '\0', tested = '\0';

	while(! moved)
	switch(direction(self))
	{ 	case 0:
		if(xpos(self) > 0 && level_table[ypos(self)][xpos(self)-1] < FELD_ERDE)
		{ 	if(level_table[ypos(self)][xpos(self)-1] == FELD_SPIELER_1)
				tod();

			mmove(self,FELD_KAEFER_1+(direction(self) = 3),xpos(self),ypos(self),xpos(self)-1,ypos(self));
			xpos(self) = xpos(self)-1; moved = '\1';
	              }
	              else
		     direction(self) =  direction(self)+1;
	              break;

		case 1:
		if(ypos(self) > 0 && level_table[ypos(self)-1][xpos(self)] < FELD_ERDE)
		{ 	if(level_table[ypos(self)-1][xpos(self)]==FELD_SPIELER_1)
				tod();
			mmove(self, FELD_KAEFER_1+(direction(self)=00),
				xpos(self),ypos(self),xpos(self),ypos(self)-1);
			 ypos(self)--; moved = '\1';
	              }
	              else
			 direction(self) =  direction(self)+1;
	              break;
		case 2:
		if(xpos(self) < level_y_size-1 &&
			level_table[ypos(self)][xpos(self)+1] < FELD_ERDE)
		{ 	if(level_table[ypos(self)][xpos(self)+1]==FELD_SPIELER_1)
				tod();
			  mmove(self, FELD_KAEFER_1+(direction(self) = 1),xpos(self),ypos(self),xpos(self)+1,ypos(self));
			  xpos(self) = xpos(self)+1; moved = '\1';
	              }
	              else
			 direction(self) =  direction(self)+1;
	              break;
		case 3:
		if(ypos(self) < level_y_size-1 &&
			 level_table[ypos(self)+1][xpos(self)] < FELD_ERDE)
		{ 	if(level_table[ypos(self)+1][xpos(self)]==FELD_SPIELER_1)
			    tod();
			  mmove(self,FELD_KAEFER_1+(direction(self) = 2), xpos(self),ypos(self),xpos(self),ypos(self)+1);
			  ypos(self) =  ypos(self)+1; moved = '\1';
	              }
	              else
		      {	 direction(self) = 0;
			  moved = tested;      /* falls eingesperrt, nach 2. Durchlauf */
			  tested = '\1';       /* abbrechen */
	              }
	              break;
	    }/* switch & while */
}
static const void * inittorqueMover (void)
{
	return ((struct Object *) torqueMover) -> class ? torqueMover :
		(torqueMover = new(MoverClass,
			"torqueMover", Mover, sizeof(struct torqueMover),
			animate, "animate", torqueMover_animate,
			(void *) 0));
}

static const struct ClassInit _torqueMover = { { MAGIC }, inittorqueMover };
const void * torqueMover = & _torqueMover;
