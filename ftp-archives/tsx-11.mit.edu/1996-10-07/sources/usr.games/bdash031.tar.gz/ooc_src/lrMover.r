# ifndef lrMover_r
# define lrMover_r

# include "Mover.r"

struct lrMover { const struct Mover _;
};

# endif
