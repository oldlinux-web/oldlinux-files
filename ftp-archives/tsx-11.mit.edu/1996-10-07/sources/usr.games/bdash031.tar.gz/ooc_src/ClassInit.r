# ifndef ClassInit_r
# define ClassInit_r

# include "Object.r"

typedef const void * (* initializer) (void);

struct ClassInit { const struct Object _;
	initializer init;
};

# endif
