# include "cheeseMover.h"
# include "cheeseMover.r"

/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
**** Changelog: ***************************************************************
*/

static struct Mover * cheeseMover_animate (void * _self) {
	struct cheeseMover * self = cast(cheeseMover, _self);

	unsigned zu = 0;
	int feld;

	if(self->counter ++ < CHEESE_DELAY)
		return;
	self->counter = 0;
	debug_printf("split_cheese() checking at %d, %d\n", xpos(self), ypos(self));
	if(xpos(self) < level_x_size)
	{	if((feld = level_table[ypos(self)][xpos(self)+1]) == FELD_LEER)
		{	level_table[ypos(self)][xpos(self)+1] = FELD_CHEESE_1;
			add_object(xpos(self)+1,ypos(self),CHEESE1,FELD_CHEESE_1,0);
		}
		else if(feld == FELD_CHEESE_1 || feld == FELD_MAUER)
			zu++;
	}
	else
		zu++;
	if(xpos(self) > 0)
	{	if((feld = level_table[ypos(self)][xpos(self)-1]) == FELD_LEER)
		{	level_table[ypos(self)][xpos(self)-1] = FELD_CHEESE_1;
			add_object(xpos(self)-1,ypos(self),CHEESE1,FELD_CHEESE_1,0);
		}
		else if(feld == FELD_CHEESE_1 || feld == FELD_MAUER)
			zu++;
	}
	else
		zu++;
	if(ypos(self) > 0)
	{	if((feld = level_table[ypos(self)-1][xpos(self)]) == FELD_LEER)
		{	level_table[ypos(self)-1][xpos(self)] = FELD_CHEESE_1;
			add_object(xpos(self),ypos(self)-1,CHEESE1,FELD_CHEESE_1,0);
		}
		else if(feld == FELD_CHEESE_1 || feld == FELD_MAUER)
			zu++;
	}
	else
		zu++;
	if(ypos(self) < level_y_size)
	{	if((feld = level_table[ypos(self)+1][xpos(self)]) == FELD_LEER)
		{	level_table[ypos(self)+1][xpos(self)] = FELD_CHEESE_2;
			draw_image(xpos(self),ypos(self)+1,FELD_CHEESE_2);
		}
		else if(feld == FELD_CHEESE_1 || feld == FELD_MAUER)
			zu++;
	}
	else
		zu++;
	if(zu == 4)
		kill_object(xpos(self),ypos(self));
}
static const void * initcheeseMover (void)
{
	return ((struct Object *) cheeseMover) -> class ? cheeseMover :
		(cheeseMover = new(MoverClass,
			"cheeseMover", Mover, sizeof(struct cheeseMover),
			animate, "animate", cheeseMover_animate,
			(void *) 0));
}

static const struct ClassInit _cheeseMover = { { MAGIC }, initcheeseMover };
const void * cheeseMover = & _cheeseMover;
