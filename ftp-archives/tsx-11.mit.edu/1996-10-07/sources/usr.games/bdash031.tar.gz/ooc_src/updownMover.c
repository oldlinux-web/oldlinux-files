# include "updownMover.h"
# include "updownMover.r"

/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
**** Changelog: ***************************************************************
Sat Dec 25 20:57:59  1993
*/

static struct Mover * updownMover_animate (void * _self) {
	struct updownMover * self = cast(updownMover, _self);

	int moved = '\0', tested = '\0';

	while(! moved)
	switch(direction(self))
	{	case 0: /* up */
		if(ypos(self) > 0 && level_table[ypos(self)-1][xpos(self)] < FELD_ERDE)
		{       if(level_table[ypos(self)-1][xpos(self)] == FELD_SPIELER_1)
				tod();
			move_object(xpos(self),ypos(self),xpos(self),ypos(self)-1,FELD_KAEFER_4);
			ypos(self) =  ypos(self)-1;
			level_table[ypos(self)][xpos(self)] = FELD_KAEFER_4;
			moved = '\1';
		}
		else
			direction(self) = 1, tested = 1;
		break;

		case 1: /* down */
		if(ypos(self) < level_y_size && level_table[ypos(self)+1][xpos(self)] < FELD_ERDE)
		{	if(level_table[ypos(self)+1][xpos(self)] == FELD_SPIELER_1)
				tod();
			move_object(xpos(self),ypos(self),xpos(self),ypos(self)+1,FELD_KAEFER_4a);
			ypos(self) = ypos(self)+1;
			level_table[ypos(self)][xpos(self)] = FELD_KAEFER_4a;
			moved = '\1';
		}
		else
			direction(self) = 0, moved = tested, tested = 1;
	}
}
static const void * initupdownMover (void)
{
	return ((struct Object *) updownMover) -> class ? updownMover :
		(updownMover = new(MoverClass,
			"updownMover", Mover, sizeof(struct updownMover),
			animate, "animate", updownMover_animate,
			(void *) 0));
}

static const struct ClassInit _updownMover = { { MAGIC }, initupdownMover };
const void * updownMover = & _updownMover;
