# ifndef Collection_h
# define Collection_h

# include "Object.h"

/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
**** Changelog: ***************************************************************
*/

typedef int (* Action) (void *, va_list);

extern const void * Collection;

int isEmpty (const void * _self);

struct Object * add (void * _self, const void * element, ...);
struct Object * find (const void * _self, const void * element);
unsigned count (const void * _self);
int apply (const void * _self, Action action, ...);

extern const void * CollectionClass;

# endif
