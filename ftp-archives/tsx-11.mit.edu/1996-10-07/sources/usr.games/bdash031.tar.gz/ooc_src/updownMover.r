# ifndef updownMover_r
# define updownMover_r

# include "Mover.r"

struct updownMover { const struct Mover _;
};

# endif
