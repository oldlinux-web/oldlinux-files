/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


void InitComm(void);

void Send_byte(unsigned char Dta);

int Receive_byte(void);

void Send_Taste(int taste);

int Receive_Taste(void);

int detect_mode(void); /* returns slave or master - mode */

