/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/
/*
**	zfopen: open compressed file for readonly mode
*/

#ifndef _ZFOPEN_H
#define _ZFOPEN_H
#ifndef _STDIO_H
#	include <stdio.h>
#endif
#ifndef ZFO_PROG
#	define ZFO_PROG	"gzip -c -d"
#endif
#ifndef ZFO_SUFFIX1
#	define ZFO_SUFFIX1	".gz"
#endif
#ifndef ZFO_SUFFIX2
#	define ZFO_SUFFIX2	".Z"
#endif

FILE * zfopen(char *filename, char *type);

#endif
