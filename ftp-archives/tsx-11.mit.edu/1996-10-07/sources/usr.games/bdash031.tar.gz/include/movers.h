/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/******
      MOVERS.C : moving animals

******/
#ifndef _MOVERS_H
#define _MOVERS_H
/*
 * available objects:
 */
enum {STD_BEETLE,STRAIGHT_BEETLE,RANDOM_BEETLE,UPDOWN_BEETLE,LR_BEETLE,CHEESE1,CHEESE2};

/*** activate object at x,y ***/
extern void add_object(int x, int y, int type, int imagenum, int dir);

/*** remove object at x,y ***/
extern void kill_object(unsigned x, unsigned y);

/*** move all objects */
extern void move_objects(void);

extern void movers_cleanup(void);
#endif
