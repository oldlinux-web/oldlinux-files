/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/************
** B--DASH **
****************************************************************
           ** (C) Copyright 1992 by:              ------      **
           **                                     \    /      **
           **                                      \  /       **
           **                                       \/        **
           ** N-A-B-L-A->Productions, K. Ball�der             **
           *****************************************************
           ** email: kballued@charon.physik.uni-osnabrueck.de **
           *****************************************************

           All rights reserved, see BDASH.DOC for details.

***********************************************************************

scores.c: Keeping track of scores and management of high-score-list

*****************************************************end of header*****/

void increment_score(int factor);

void display_score(void);

unsigned long get_score(void);

struct highscore_entry
{	char 		name[21];
	unsigned long   score;
	unsigned	level;		/* level player died on */
};

extern struct highscore_entry highscore_table[10];

void display_scoretable(void);	/* displays and edits highscoretable */


