/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/*
 * Graphic.h : Definition der Grafikfunktionen zu Boulder-Dash
 *
 */

#define IMAGEWIDTH	32
#define IMAGEHEIGHT	25
int load_graphics(void);/* Laden der Bildchen und der Palette */
			/* Initialisieren der Grafik */
                          
void update_graphics(void);	/* show graphics screen */

void display(int gxoffset_x, int gxoffset_y); /* das Spielfeld (mit Offset) darstellen */

void scroll_up(int py); /* Spielfeld um eine Zeile hochscrollen */

void scroll_down(int py); /* Spielfeld um eine Zeile herunterrollen */

void scroll_left(int px); /* Spielfeld um eine Spalte nach links scrollen */

void scroll_right(int px); /* Spielfeld um eine Spalte nach rechts scrollen */

void draw_image(int x, int y, unsigned char object); /* Feld malen */

void draw_spieler(int x, int y, int player); /* Die Spielfiguren darstellen, bei x,y */

void draw_leer(int x, int y); /* bei x,y ein leeres Feld darstellen */

void display_message(char *l1, char *l2, char *l3);

void gr_display_score(unsigned long score);
/* ein Objekt verschieben */

void move_object(int alt_x, int alt_y, int neu_x, int neu_y, unsigned obj_num);

extern int gr_maxx, gr_maxy;
extern int gxoffset_x, gxoffset_y;	/* only for Movers.dc */
extern int graphics_initialized;	/* true/false */
