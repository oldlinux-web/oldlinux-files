/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/*
 * Boulder-Dash: Level laden, Grafikmodus aktivieren, etc
 */


int load_level(unsigned level_no);/* Level laden und in level_table ablegen */

void free_level(void);

int load_scores(void);
int save_scores(void);

void fatal_error(char *err); /* Fehler ausgeben und Prg beenden */

void debug_printf(char *mesg, ...);
void debug_entry(char *fcall, char *file, int line);
void debug_leave(char *file, int line); 

#define D_ENTRY(fcall) debug_entry(fcall, __FILE__, __LINE__)
#define D_LEAVE debug_leave(__FILE__,__LINE__);
