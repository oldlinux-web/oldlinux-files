/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/


/************
** B--DASH **
****************************************************************
	   ** (C) Copyright 1992,1993 by:         ------      **
           **                                     \    /      **
           **                                      \  /       **
           **                                       \/        **
           ** N-A-B-L-A->Productions, K. Ballue�der           **
           *****************************************************
           ** email: kballued@jupiter.rz.uni-osnabrueck.de    **
           *****************************************************

           All rights reserved, see BDASH.DOC for details.

***********************************************************************

systems.h:  System-dependant definitions

*****************************************************end of header*****/



/********* determine operating system *********/
#ifdef __unix__
#	define OS_UNIX
#	ifdef __linux__
#		define OS_LINUX
#	endif
#endif

#ifdef __MSDOS__
#	define OS_DOS
#	ifdef __TURBOC__
#		define CC_TURBOC
#	endif
#endif

#ifdef OS_DOS
#	if !(__LARGE__ || __COMPACT__ || __HUGE__)
#		error  Illegal memory model, Compact, Large or Huge required!
#	endif
#	define BDASH_OS	"Dos"
#	include <alloc.h>  /* fuer k_alloc() */
#	define MAX_SPEED	(75L)
#	define DEFAULT_SPEED	(68L)
#	define BASE_SPEED	(0L)
#	define WAITKEY	{getch();}
#endif
#ifdef OS_UNIX
#	define MAX_SPEED	(5000L)
#	define DEFAULT_SPEED	(3000L)
#	define BASE_SPEED	(2000L)
#	define getch()	getchar()
#	ifdef OS_LINUX
#		define BDASH_OS "Linux"
#	else
#		define BDASH_OS "generic UNIX"
#	endif
#	define WAITKEY	{ while(getchar() != ' '); }
#endif


