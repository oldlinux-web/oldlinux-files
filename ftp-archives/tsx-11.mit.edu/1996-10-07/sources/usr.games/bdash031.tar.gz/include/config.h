
/******************************************************************************
*									      *
*	(C) 1993 by K. Ballueder					      *
*									      *
*	See README and COPYING for details.				      *
*									      *
*	Please feel free to contact me:					      *
*		kballued@charon.physik.uni-osnabrueck.de		      *
*		kballued@jupiter.rz.uni-osnabrueck.de			      *
*									      *
******************************************************************************/
/***********************************************************************

config.h : system dependant configurations

*****************************************************end of header*****/


#define BDASH_RELEASE "0.31"

#ifdef __unix__
#	define OS_UNIX
#endif
#ifdef __linux__
#	define OS_LINUX
#	define CC_GNUC
#endif
#ifdef __TURBOC__
#	define OS_DOS
#	define CC_TURBOC
#endif
#ifdef OS_DOS
#	define BDASH_OS	"Dos"
#	include <alloc.h>  /* fuer k_alloc() */
#	define MAX_SPEED	(75L)
#	define DEFAULT_SPEED	(68L)
#	define BASE_SPEED	(0L)
#	define UMLAUT_U		129
#endif
#ifdef OS_UNIX
#	define MAX_SPEED	(5000L)
#	define DEFAULT_SPEED	(3000L)
#	define BASE_SPEED	(2000L)
#	define getch()	getchar()
#	define UMLAUT_U		252
#endif
#ifdef OS_LINUX
#	define BDASH_OS "Linux"
#endif


#ifdef OS_DOS
#	define CONFIGFILE	"bdash.cfg"
#	define BGIPATH		"c:\\anw\\tc\\bgi"
/* 	BGIPATH can be overwritten by environment variable BGI
 * 	just type:  SET BGI=new_path
 */
#	define DATAPATH		""
#	define HSCPATH		""
#endif
#ifdef OS_UNIX
#	ifndef DATAPATH
#		define DATAPATH		"/usr/games/lib"
#	endif
#	ifndef HSCPATH
#		define HSCPATH		"/var/games/scores"
#	endif
#	define CONFIGFILE	"bdashrc"
#	ifdef SND_DEV_DSP
#		define SND_DEVICE	"/dev/dsp"
#	else
#		define SND_DEVICE	"/dev/audio"
#	endif
#endif
#define FILELEVEL 	"bdash%03u.lvl"
#define FILECOLOR 	"bdashcol.cmp"
#define FILECOLORBW     "bdash_sw.cmp"
#define FILEDATA	"bdash.dta"
#define FILESCORE	"bdash.hsc"


#define COPYRIGHT_MESSAGE \
	"*************\n"\
	"** B--DASH **\n"\
	"**********************************************************************\n"\
	"           ** (C) Copyright 1992,1993 by:                           **\n"\
	"           **                                                       **\n"\
	"           ** Karsten Ball%cder                                      **\n"\
	"           **                                                       **\n"\
	"           ** email:  kballued@charon.physik.uni-osnabrueck.de      **\n"\
	"           **         kballued@reliant.uni-osnabrueck.de            **\n"\
	"           ***********************************************************\n"\
	"           ** snail-mail:  Lessingstrasse 2, 32756 Detmold, Germany **\n"\
	"           ***********************************************************\n"\
	"\nCurrent Release: "BDASH_VERSION"     Date: "__DATE__"     Time: "__TIME__"\n"

#define SHOW_COPYRIGHT	printf(COPYRIGHT_MESSAGE,UMLAUT_U);

#ifdef OS_DOS
#	define HELPTEXT \
	"\tAvailable options:\n"\
	"-lxxx : level xxx           -m  : monochrome\n"\
	"-2    : two player option   -s  : set speed (0-%ld, default: %ld)\n"\
	"-cx   : use COMx            -px : x = s,1,2,q play sounds on speaker or LPTx\n"\
	"                                  x = q quiet mode, no sounds at all\n"
#endif
#ifdef OS_LINUX
#	define HELPTEXT \
	"\tAvailable options:\n"\
	"-lxxx  : level xxx                  -m  : monochrome\n"\
	"-p dev : play sound on device dev   -s  : set speed (0-%ld, default: %ld)\n"
#	define OPTS "h?l:ms:p:"
#endif

#define BDASH_VERSION BDASH_RELEASE " for " BDASH_OS

#ifdef __TURBOC__
extern int getch(void);
#endif

#ifdef OS_DOS
#	ifdef OS_LINUX
#		error "Ambiguous definition!"
#	endif
#endif
