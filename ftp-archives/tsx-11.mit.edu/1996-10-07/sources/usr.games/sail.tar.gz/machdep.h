/*
 * Copyright (c) 1983 Regents of the University of California.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that this notice is preserved and that due credit is given
 * to the University of California at Berkeley. The name of the University
 * may not be used to endorse or promote products derived from this
 * software without specific prior written permission. This software
 * is provided ``as is'' without express or implied warranty.
 *
 *	@(#)machdep.h	5.2 (Berkeley) 3/9/88
 */

#define LOGFILE "/usr/games/lib/saillog"	/* has to match the makefile */

#define TIMEOUT 300				/* Sync() timeout in seconds */

#define blockalarm()	(SIG_BLOCK << SIGALRM-1)
#define unblockalarm()	(sigsetmask(SIG_BLOCK & ~(1 << SIGALRM-1)))


