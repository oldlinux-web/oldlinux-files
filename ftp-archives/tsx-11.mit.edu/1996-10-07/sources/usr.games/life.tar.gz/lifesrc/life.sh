#\- run Life with options
#usage: % [-options] [filelist]
#options:
#-m	display list of pattern files
#-a	execute Life successively with all pattern files listed by -m;
#	INT signal (DEL) results in user query: 
#		continue with next file?, or exit
#-g#, -c#, -ooutputfile		options as for unwrapped Life
#
#Note--
#edit LIFEDIR and LIFE appropriately; 
#the patterns in */xpatterns perhaps should be copied to */patterns;
#script was written for ksh, but it seems pretty standard and should work 
#under the Bourne shell.

LIFEDIR=`pwd`/patterns
LIFE=`pwd`/life

USAGE="\n\
usage: $0 [-options] [filelist]\n\
read stdin if no filelist\n\
options:\n\
 -m\tdisplay list of pattern files that can be read by Life\n\
 -a\texecute Life successively with all pattern files listed by -m\n\
\t(INT signal (DEL) produces query = continue with next file?, or exit)\n\
 -g#\texit life after # generations\n\
 -c#\tcontrol code for pattern-display correspondence:\n\
\t\t0 = display center fixed at center of _input_ pattern\n\
\t\t[1-4] = display fixed at quadrant I-IV of _input_ pattern\n\
\t\t5 = display center tracks center of evolving pattern (default)\n\
\t\t[6-9] = display tracks quadrant I-IV of evolving pattern\n\
\t\t\t(quadrants numbered counter-clockwise from upper right)\n\
 -ofile\tcopy all of pattern for each generation to file\n"

while [ "x"$1 != "x" ]
do
	case $1 in
	-m)	cd $LIFEDIR;ls -C [a-z]*;exit 0;;
	-a)	all=all
		if [ -z "`echo $OPTS | egrep '\-c'`" ]
		then
			OPTS="$OPTS -c0"
		fi
		shift;;
	-c*|-g*|-o*)	OPTS="$OPTS "$1;shift;;
	--)	LIFEDIR="";shift;;
	-*)	echo $USAGE;exit 0;;
	core|life)	echo $1 is not a pattern file;exit 0;;
	*)	break;;
	esac
done

if [ "x"$LIFEDIR != "x" ]
then
	cd $LIFEDIR
fi

if [ \( "x"$all = "xall" \) -o \( "x"$1 = "x*" \) ]
then
	set [a-z]*
elif [ $# -gt 0 ]
then
	set $@
else
	$LIFE $OPTS
	exit 0
fi

if [ $# -gt 1 ]
then
	trap "echo \"continue (n/y(default)? \\c\"
		read DUMMY
		if [ \"x\"\$DUMMY = \"xn\" ] 
		then 
			exit 0
		fi" 2
fi

while [ "x"$1 != "x" ]
do
	$LIFE $OPTS $1
	shift
done
exit 0
