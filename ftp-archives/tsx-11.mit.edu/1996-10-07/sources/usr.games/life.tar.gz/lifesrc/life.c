/*-
 * "LIFE" 
 *
 * The simulation invented by John Conway.
 *
 * This version written by Leor Zolman to exemplify PROPER use of "goto"
 * statements in C programs! 
 *
 * Note that the Universe is a toroid; i.e, the left extreme is adjacent to the
 * right extreme, the top is adjacent to the bottom, and each corner is
 * adjacent to each other corner. In other words, there ARE NO EXTREMES !!
 * Or, in a more physical illustration: If I could take a peek straight ahead
 * through the magical eyepiece of an infinitely powerful telescope, I'd be
 * able to see the back of my brain-damaged head....that is, of course,
 * assuming no galaxies or cats get in the way. 
 *							Leor Zolman
 */

/*-
 * The original code dates to the early days of BDS C, the 8080, 
 * and before Apple had produced the glint in IBM's eye that lead to 
 * conception of the PC.
 *
 * BDS C lacked some features of K&R C, but it was FAST, in both 
 * compilation and execution.
 *
 * 3/1/89 -- Modifications for UNIX with curses or termcap, and a bit more.
 *
 * John Rupley
 *  uucp: ..{cmcl2 | hao!ncar!noao}!arizona!rupley!local
 *  internet: rupley!local@cs.arizona.edu
 *  (H) 30 Calle Belleza, Tucson AZ 85716 - (602) 325-4533
 */

/* 
 * Changed slightly to compile under linux using GCC 2.1. Linux lacks
 * the pad stuff in libcurses.a, so it compiles similar to bsd with a
 * few changes.
 * 
 * Karl Buck kxb@matt.ksu.ksu.edu
 */

#include	<curses.h>

#ifdef LINUX 
#define BSD
#endif 				

#if defined(TCAP) && !defined(BSD)
#include	<termcap.h>
#endif				/* TCAP && !BSD */

#include	<signal.h>

#ifdef BSD
/*-
 * SysV compatible getopt(3) needed. There are versions in comp.sources.unix.
 *
 * Some versions of curses lack pad structures, which allow somewhat
 * simpler handling of windows larger than the display screen. 
 */
#define		NOPAD
#include	<ctype.h>
#include	<strings.h>
#ifndef 	LINUX
#define strrchr	rindex 		/* not LINUX but BSD */
#endif
#else				/* BSD */
#include	<string.h>
void            exit();
unsigned        sleep();
#endif				/* BSD */

#define PAD
#if defined(TCAP) || defined(NOPAD)
#undef PAD
#endif				/* TCAP || NOPAD */

/*-
 * Put pretty high limits on size of cell array, so interesting patterns 
 * are not destroyed by truncation or wrapping; keep default smaller 
 * than 2^15, for compilers that limit size of aggregates.  
 */
#ifndef XMAX
#define XMAX	50
#endif				/* XMAX */
#ifndef YMAX
#define YMAX	160
#endif				/* YMAX */
char            cell[XMAX][YMAX];	/* the universe matrix */

/*-
 * To see how the toroid works, try reducing XMAX and YMAX 
 * to around 10 or 20.			 
 */

/*-
 * [XY]SIZE determine the size of the part of the cell array displayed
 * on the terminal; values are set according to terminfo, in curse_on(),
 * to the size of the display screen.
 */
int             XSIZE, YSIZE;

/*-
 * If the cell array is larger than the terminal screen, the part selected
 * for display is determined by the value of "center"; the display can be fixed 
 * at a point of the initial pattern, or it can track the evolving pattern;
 * the value of center defaults to TRACK_CENTER or it can be set from the
 * command line (-cn option);
 */

/*-				/* display		initial pattern */
/*-				/* -----   fixed at   --------------- */
#define FIX_CENTER	0	/* center 		center	 */
#define FIX_UPPER_R	1	/* 0,COLS-1		minx,maxy */
#define FIX_UPPER_L	2	/* 0,0			minx,miny */
#define FIX_LOWER_L	3	/* LINES-1,0		maxx,miny */
#define FIX_LOWER_R	4	/* LINES-1,COLS-1	maxx,maxy */

/*-				/* display		current pattern */
/*-				/* -------   tracks     --------------- */
#define TRACK_CENTER	5	/* center 		center	 */
#define TRACK_UPPER_R	6	/* 0,COLS-1		minx,maxy */
#define TRACK_UPPER_L	7	/* 0,0			minx,miny */
#define TRACK_LOWER_L	8	/* LINES-1,0		maxx,miny */
#define TRACK_LOWER_R	9	/* LINES-1,COLS-1	maxx,maxy */


#define SLEEPTIME	0	/* Delay after each pattern display */
#define BOREDOM_THRESHOLD 5	/* This is how many generations are allowed
				 * to pass without a population change before
				 * Divine intervention is called for. */

/*
 * Control values read as command line options
 */
unsigned        gen_limit;	/* quit program after gen_limit iterations */
				/* set by command line option, -gn */
int             center;		/* control of display-pattern correspondence */
				/* set by command line option, -cn */
FILE           *infile;		/* input stream (stdin default) */
				/* loop over list of command line arguments */
char           *infile_name;
FILE           *outfile;	/* output stream (in __addition__ to stdout); */
char           *outfile_name;	/* set by command line option, -ofile */

/*
 * Control values set internally. 
 */
int             quitflag;	/* set by SIGINT in signal handler die() */
int             adjp_flag;	/* set if adjust_pattern() shifts pattern */
int             doneflag;	/* set if stasis = no change in pattern */
unsigned        boring;		/* count of how many generations go by
				 * without population change	 */
unsigned        pop, gen;	/* current population and generation	 */
int             minx, maxx, miny, maxy;	/* values for pattern bounds */
int             dminx, dmaxx, dminy, dmaxy;	/* and for pattern display */
int             x_offset, y_offset;

/*
 * Curses structures. 
 */
#ifdef TCAP
char           *CLEARS;
#else				/* TCAP */
#ifdef PAD
WINDOW         *padwin;		/* full pattern (XMAX*YMAX) display info */
#endif				/* PAD */
WINDOW         *commentwin;	/* one line comment given at screen bottom */
#endif				/* TCAP */

/*
 * The main driving routine, to accept initial population configurations and
 * display their evolution according to a proximity-based formula. 
 */

main(argc, argv)
	int             argc;
	char          **argv;
{
	void            startup();
	void            quitit();
	void            curse_on();
	int             c;
	char            string[BUFSIZ];

	startup(argc, argv);
	curse_on();
	for (;;) {
		if (setup())
			quitit();
		while (pop) {
			if (quitflag)
				quitit();
			if (gen_limit && gen == gen_limit) {
				sprintf(string, "Generation limit reached at %d.  Continue evolving? (y/n/q(default)) ", gen_limit);
				c = user_query(string, "YNQ");
				if (c == 1)
					continue;
				else if (c == 2)
					break;
				else
					quitit();
			}
			if (center >= TRACK_CENTER)
				adjp_flag = adjust_pattern(0);

			dogen();/* do everything that counts */

			if (boring == BOREDOM_THRESHOLD) {
				boring++;
				sprintf(string, "Population stable for %d generations. Continue evolving? (y(default)/n/q) ", BOREDOM_THRESHOLD);
				c = user_query(string, "QNY");
				if (c == 1)
					quitit();
				else if (c == 2)
					break;
				else
					continue;
			}
			if (doneflag) {
				sprintf(string, "Stasis at generation %d. Enter another pattern? (y/q(default)) ", gen);
				c = user_query(string, "Y");
				if (c == 1)
					break;
				else
					quitit();
			}
			if (!pop && gen) {
				sprintf(string, "Life ends at generation %d. Enter another pattern? (y/q(default)) ", gen);
				c = user_query(string, "Y");
				if (c == 1)
					break;
				else
					quitit();
			}
		}
	}
}

/* Signal handler -- set flag for exit. */

int
die()
{
	quitflag = 1;
	signal(SIGINT, die);
	return;
}

/* Initialize the cell matrix to all dead. */

void
xclear()
{

	memset(&cell[0][0], '\0', (XMAX * YMAX));
}

/* Clean up at exit. */

void
quitit()
{
	void            display_comment();

	display_comment("");
#ifdef TCAP
	fflush(stdout);
#else				/* TCAP */
	endwin();
#endif				/* TCAP */
	if (outfile)
		fprintf(outfile, "\f");
	exit(0);
}

/* Set-up termcap or curses. */

void
curse_on()
{
#ifdef TCAP
	int             tgetent();
	int             tgetnum();
	char           *getenv();
	char           *tgetstr();
	char           *tbufptr;
	char           *tptr;
	char           *term;
	static char     tbuf[BUFSIZ];
	static char     t[1024];

	signal(SIGINT, die);
	tbufptr = tbuf;
	tptr = t;
	term = getenv("TERM");
	tgetent(tptr, term);
	CLEARS = tgetstr("cl", &tbufptr);
	XSIZE = tgetnum("li") - 1;
	YSIZE = tgetnum("co") - 1;
	XSIZE = XSIZE >= XMAX ? (XMAX - 1) : XSIZE;
	YSIZE = YSIZE >= YMAX ? (YMAX - 1) : YSIZE;
	if (!term || !CLEARS || XSIZE < 1 || YSIZE < 1) {
		fprintf(stderr, "life: failure in terminfo setup\n");
		exit(1);
	}
	fputs(CLEARS, stdout);
#else				/* TCAP */
	signal(SIGINT, die);
	initscr();
	XSIZE = (LINES - 1) >= XMAX ? (XMAX - 1) : (LINES - 1);
	YSIZE = (COLS - 1) >= YMAX ? (YMAX - 1) : (COLS - 1);
	commentwin = newwin(1, YSIZE, XSIZE, 0);
#ifdef PAD
	padwin = newpad(XMAX, YMAX);
#endif				/* PAD */
#endif				/* TCAP */
}

/* Get user respose. */

int
user_query(string, response)
	char           *string, *response;
{
	void            display_comment();
	int             c;
	char           *ptr;

	display_comment(string);
	if (isatty(fileno(infile))) {
#ifdef TCAP
		c = getchar();
#else				/* TCAP */
		c = getch();	/* nice to need no newline */
#endif				/* TCAP */
		c = toupper(c);
		if ((ptr = strrchr(response, c)) != (char *) 0)
			return (ptr - response + 1);
		else
			return 0;
	} else {
		return 0;
	}
}

/* Get command line information and user input, if appropriate. */

void
startup(xargc, xargv)
	int             xargc;
	char          **xargv;
{
	extern char    *optarg;
	extern int      optind;
	int             getopt();
	int             c;
	static char     usage[2000] =
	{
	 "\n\
usage: life [-options] [file]\n\
read stdin if no file\n\
options:\n\
 -g#  exit life after # generations\n\
 -c#  control code for pattern-display correspondence\n\
\t0 = display center fixed at center of _input_ pattern\n\
\t[1-4] = display fixed at quadrant I-IV of _input_ pattern\n\
\t5 = display center tracks center of evolving pattern (default)\n\
\t[6-9] = display tracks quadrant I-IV of evolving pattern\n\
\t\t(quadrants numbered counter-clockwise from upper right)\n\
 -ofile  copy all of pattern for each generation to file\n\
\n"
	};

	center = TRACK_CENTER;
	gen_limit = 0;
	infile = (FILE *) 0;
	while ((c = getopt(xargc, xargv, "g:c:o:?z")) != EOF) {
		switch (c) {
		case 'g':
			if (!(gen_limit = atoi(optarg))) {
				fprintf(stderr, "Bad value for gen_limit = %s\n", optarg);
				fprintf(stderr, usage);
				exit(1);
			}
			break;
		case 'c':
			if ((center = atoi(optarg)) >= 10) {
				fprintf(stderr, "Bad value for center = %s\n", optarg);
				fprintf(stderr, usage);
				exit(1);
			}
			break;
		case 'o':
			if ((outfile = fopen(optarg, "w")) == (FILE *) 0) {
				fprintf(stderr, "Can't open output file %s\n", optarg);
				fprintf(stderr, usage);
				exit(1);
			}
			outfile_name = optarg;
			break;
		case '?':	/* fall through */
		case 'z':	/* fall through */
		default:	/* getopt(3) defaults to '?' */
			fprintf(stderr, usage);
			exit(1);
		}
	}
	if (optind < xargc) {
		if ((infile = fopen(xargv[optind], "r")) == (FILE *) 0) {
			fprintf(stderr, "Can't open file %s\n", xargv[optind]);
			fprintf(stderr, usage);
			exit(1);
		}
		infile_name = xargv[optind];
	} else {
		infile = stdin;
		infile_name = "stdin";
	}
}

/* Get initial pattern from user. */

int
setup()
{
	void            xclear();
	void            find_offset();
	void            display();
	char           *fgets();
	int             y;
	int             length;
	char            string[BUFSIZ], *ptr;
#ifdef PAD
	int             i, j;
#endif				/* PAD */

#ifdef TCAP
	fputs(CLEARS, stdout);
#else				/* TCAP */
	clear();
	refresh();
#ifdef PAD
	def_prog_mode();
	reset_shell_mode();
#endif				/* PAD */
#endif				/* TCAP */
	xclear();
	fprintf(stdout, "\t *** BDS Life ***\n\n");
	if (isatty(fileno(infile))) {
		fprintf(stdout, "Enter initial configuration (single period to end):\n\n");
	}
	adjp_flag = 0;
	boring = 0;
	pop = gen = 0;
	y = minx = maxx = miny = maxy = 0;
	while ((fgets(string, sizeof(string), infile) > 0) && *string != '.') {
		if ((length = strlen(string)) > (YMAX)) {
			string[YMAX - 1] = '\0';
			fprintf(stdout, "Truncated to %d chars\n", YMAX);
		} else {
			/* fgets() retains \n */
			string[length - 1] = '\0';
		}
		ptr = string;
		y = 0;
		while (*ptr) {
			if (*ptr++ != ' ') {
				cell[maxx][y] = 10;
				++pop;
			}
			++y;
		}
		--y;
		if (y > maxy)
			maxy = y;
		++maxx;
		if (maxx >= XMAX) {
			fprintf(stdout, "Limit of %d lines reached\n", XMAX);
			break;
		}
	}
	--maxx;
	if (!pop)
		return 1;
	adjust_maxmin();	/* find pattern in cell[][] */
	adjust_pattern(1);	/* force centering of pattern in cell[][] */
	find_offset();		/* find correspondence pattern <--> display */
#ifndef TCAP
#ifdef PAD
	reset_prog_mode();
	wclear(padwin);		/* clean up pattern pad, and blank screen */
	prefresh(padwin, 0, 0, 0, 0, XSIZE, YSIZE);
	for (i = minx; i <= maxx; i++) {	/* copy cell[][] to pad */
		for (j = miny; j <= maxy; j++)
			if (cell[i][j]) {
				mvwaddch(padwin, i, j, '*');
			}
	}
#endif				/* PAD */
	clear();		/* clean up stdscr */
	refresh();
#endif				/* TCAP */
	display();
	gen++;
	sleep((unsigned) (SLEEPTIME ? 2 * SLEEPTIME : 2));
	return 0;
}

/* Display comment line at bottom of screen. */

void
display_comment(comm_string)
	char           *comm_string;
{
#ifdef TCAP
	fprintf(stdout, "\r%s", comm_string);
	fflush(stdout);
#else				/* TCAP */
	werase(commentwin);
	wmove(commentwin, 0, 0);
	wprintw(commentwin, comm_string);
/* 	touchwin(commentwin); */
	wrefresh(commentwin);
#endif				/* TCAP */
	if (outfile)
		fprintf(outfile, "\n%s\n", comm_string);
}

/* Display the current generation. */

void
display()
{
	void            quitit();
	void            display_comment();
	char            string[BUFSIZ];
	int             i, j;
#ifdef TCAP
	int             x_line;
	int             del_x, del_y, jmaxy;
#endif				/* TCAP */

	if (quitflag)
		quitit();
#ifdef TCAP
	fputs(CLEARS, stdout);
	fprintf(stdout, "\r");
	x_line = 0;
	del_x = dminx - x_offset;
	del_y = dminy - y_offset;
	for (j = 0; j < del_x; j++) {
		fprintf(stdout, "\n");
		x_line++;
	}
	for (i = dminx; i <= dmaxx; i++) {
		for (j = 0; j < del_y; j++) {
			fprintf(stdout, "%c", ' ');
		}
		for (jmaxy = dmaxy; jmaxy >= dminy; jmaxy--) {
			if (cell[i][jmaxy])
				break;
		}
		for (j = dminy; j <= jmaxy; j++) {
			fprintf(stdout, "%c",
				cell[i][j] ? '*' : ' ');
		}
		x_line++;
		fprintf(stdout, "\n");
	}
	for (i = x_line; i < XSIZE; i++)
		fprintf(stdout, "\n");
#else				/* TCAP */
#ifdef PAD
	clearok(curscr, TRUE);
/* 	touchwin(padwin); */
	prefresh(padwin, dminx, dminy, dminx - x_offset, dminy - y_offset,
		 dmaxx - x_offset, dmaxy - y_offset);
#else				/* PAD */
	clear();
	for (i = dminx; i <= dmaxx; i++) {
		for (j = dminy; j <= dmaxy; j++)
			if (cell[i][j])
				mvaddch(i - x_offset, j - y_offset, '*');
	}
/* 	touchwin(stdscr); */
	refresh();
#endif				/* PAD */
#endif				/* TCAP */
	if (outfile) {
		for (i = minx; i <= maxx; i++) {
			fprintf(outfile, "\n");
			for (j = miny; j <= maxy; j++)
				fprintf(outfile, "%c",
					cell[i][j] ? '*' : ' ');
		}
	}
	sprintf(string, "%04d   %03d  %s", gen, pop, infile_name);
	display_comment(string);
	if (SLEEPTIME)
		sleep((unsigned) SLEEPTIME);
}

/*-
 * Set delimiters of region of pattern = cell array to be displayed, 
 * and set offset values used for matching cell pattern to screen display.
 *
 * Globals to be set before function invocation:
 * minx, miny, maxx, maxy = lower and upper limits of x,y coords of
 * active region of pattern;
 * XSIZE, YSIZE = upper bounds of screen (origin at 0,0).
 *
 * Globals set within function:
 * dminx, dminy, dmaxx, dmaxy = lower and upper limits of x,y coords of
 * __sub__region of pattern that is copied to display;
 * x_offset, y_offset = values subtracted from pattern coordinates, 
 * to give display coordinates.
 */

void
find_offset()
{
	void            expandx(), expandy();
	void            quitit();
	void            find_offset();
	int             ax, ay;
	int             xlim, ylim;
	int             xpat, ypat;
	int             dx, dy;
	int             xend, yend;
	int		hold_the_center;

	xlim = XSIZE - 1;
	ylim = YSIZE - 1;
	xend = XMAX - 1;
	yend = YMAX - 1;
	xpat = maxx - minx;
	ypat = maxy - miny;
	dx = xlim - xpat;
	dy = ylim - ypat;
	ax = xlim - maxx;
	ay = ylim - maxy;
	switch (center) {
	case FIX_CENTER:
		/* 
		 * Not nice, but need dmax - dmin == lim to get full screen
		 * display for FIXed-display options; for these, 
		 * find_offset() is entered only once, at gen = 0, and
		 * after pattern has been centered by pattern_adjust(). 
		 */
		x_offset = minx - dx / 2;
		y_offset = miny - dy / 2;
		expandx(xend, xlim);
		expandy(yend, ylim);
		while (dmaxx - dminx < xlim) {
			if (dminx)
				--dminx;
			else if (dmaxx - dminx < xlim && dmaxx < xend)
				++dmaxx;
		}
		while (dmaxy - dminy < ylim) {
			if (dminy)
				--dminy;
			else if (dmaxy - dminy < ylim && dmaxy < yend)
				++dmaxy;
		}
		return;
	case TRACK_CENTER:
		x_offset = minx - dx / 2;
		y_offset = miny - dy / 2;
		break;
	case FIX_UPPER_L:
	case TRACK_UPPER_L:
		x_offset = minx;
		y_offset = miny;
		break;
	case FIX_LOWER_L:
	case TRACK_LOWER_L:
		x_offset = -ax;
		y_offset = miny;
		break;
	case FIX_UPPER_R:
	case TRACK_UPPER_R:
		x_offset = minx;
		y_offset = -ay;
		break;
	case FIX_LOWER_R:
	case TRACK_LOWER_R:
		x_offset = -ax;
		y_offset = -ay;
		break;
	default:
		fprintf(stderr, "Impossible value of center = %d\n", center);
		quitit();
	}
	expandx(xend, xlim);
	expandy(yend, ylim);

	/*
	 * Low limits (eg testing toroidal wrapping), with YMAX ~ YSIZE <
	 * COLS, can give problems when shifting pattern to corners -- so do
	 * below for FIXed displays, to center poor off-center displays;
	 */
	if (center < TRACK_CENTER) {
		if (dmaxx - dminx < xlim || dmaxy - dminy < ylim) {
			hold_the_center = center;
			center = FIX_CENTER;
			find_offset();
			center = hold_the_center;
		}
	}
}

void
expandx(xend, xlim)
	int             xend, xlim;
{
	dminx = minx;
	while (dminx && dminx - x_offset > 0)
		dminx--;
	while (dminx - x_offset < 0)
		dminx++;
	dmaxx = maxx;
	while (dmaxx < xend && dmaxx - x_offset < xlim)
		dmaxx++;
	while (dmaxx - x_offset > xlim)
		dmaxx--;
}

void
expandy(yend, ylim)
	int             yend, ylim;
{
	dminy = miny;
	while (dminy && dminy - y_offset > 0)
		dminy--;
	while (dminy - y_offset < 0)
		dminy++;
	dmaxy = maxy;
	while (dmaxy < yend && dmaxy - y_offset < ylim)
		dmaxy++;
	while (dmaxy - y_offset > ylim)
		dmaxy--;
}

/* Adjust values of maxx, minx, etc; dogen() may change range of pattern. */

int
adjust_maxmin()
{
	int             ominx, ominy, omaxx, omaxy;

	ominx = minx;
	ominy = miny;
	omaxx = maxx;
	omaxy = maxy;
	if (minx && prow(minx - 1))
		minx--;
	if (miny && pcol(miny - 1))
		miny--;
	if ((maxx < (XMAX - 1)) && prow(maxx + 1))
		maxx++;
	if ((maxy < (YMAX - 1)) && pcol(maxy + 1))
		maxy++;

	while (!prow(minx))
		minx++;
	while (!prow(maxx))
		maxx--;
	while (!pcol(miny))
		miny++;
	while (!pcol(maxy))
		maxy--;
	if (ominx != minx || ominy != miny || omaxx != maxx || omaxy != maxy)
		return 1;
	else
		return 0;
}

/* Test if given column is populated. */

int
pcol(n)
{
	int             i, hi;

	hi = (maxx >= (XMAX - 1)) ? XMAX - 1 : maxx + 1;
	for (i = (minx <= 0 ? 0 : minx - 1); i <= hi; ++i)
		if (cell[i][n])
			return 1;
	return 0;
}

/* Test if given row is populated. */

int
prow(n)
{
	int             i, hi;

	hi = (maxy >= (YMAX - 1)) ? (YMAX - 1) : maxy + 1;
	for (i = (miny <= 0 ? 0 : miny - 1); i <= hi; ++i)
		if (cell[n][i])
			return 1;
	return 0;
}


/*-
 * Compute next generation. Algorithm used is a two-pass cuteness suggested
 * to me by Ward Christensen (he uses it on a machine-language version on a
 * 1024 character display, and it cranks out 20 generations a second at 2
 * MHz.) The algorithm uses the low order 3 bits of each 1-byte cell as a
 * neighbor count. The first pass finds all live cells and increments the
 * count of each of the 8 neighbors of such live cells. For the first pass,
 * dead cells are totally ignored. The second pass then comes along and
 * checks the counts off all cells within the active square to determine who
 * lives and who dies. Note that this is a significant improvement over the
 * "obvious" method of examining all 8 neighbors of each and every cell, dead
 * or alive, in the array. 
 *							Leor Zolman
 */

int
dogen()
{
	void            pass1();
	int             oldpop;

	oldpop = pop;
	pass1();
	if (pass2())
		return 1;
	if (pop == oldpop)
		boring++;
	else
		boring = 0;
	return 0;
}

/*-
 * In pass1, use mod(a,b) where needed to wrap pattern array into toroid:
 * 		cell[0][i] = cell[XMAX][i]
 *		cell[i][0] = cell[i][YMAX]
 * Filled cell in column 0 increments counts in column YMAX - 1, etc.
 * There are, of course, no rows cell[XMAX][i] or columns cell[i][YMAX].
 */

#define mod(a,b)	((a) < 0 ? (b) + (a) : ((a) < (b) ? (a) : (a) - (b)))

void
pass1()
{
	int             bigflag;
	int             i, j;
	int             k, l;
	char            c;

	bigflag = (minx < 2 || maxx > (XMAX - 3) ||
		   miny < 2 || maxy > (YMAX - 3));
	for (i = minx; i <= maxx; ++i) {
		for (j = miny; j <= maxy; ++j) {
			c = cell[i][j];
			if (c >= 10) {
				if (bigflag) {
					for (k = -1; k <= 1; k++)
						for (l = -1; l <= 1; l++)
							cell[mod(i + k, XMAX)][mod(j + l, YMAX)]++;
				} else {
					for (k = -1; k <= 1; k++)
						for (l = -1; l <= 1; l++)
							cell[i + k][j + l]++;
				}
			}
		}
	}
	/* wrapped perhaps? update range of the pattern, before pass2 */
	if (bigflag) {
		minx = miny = 0;
		maxx = XMAX - 1;
		maxy = YMAX - 1;
		adjust_maxmin();
	}
}

/* Update pattern in cell[][] and curses struct pad at same time. */

int
pass2()
{
	void            find_offset();
	void            display();
	int             i, j, i1, j1, i2, j2;
	char            c;

	/* leave set if no change in pattern */
	doneflag = 1;
#ifdef PAD
	/* clear pad only if pattern shifted */
	if (adjp_flag == 1) {
		wclear(padwin);
		adjp_flag = 0;
	}
#endif				/* PAD */
	i1 = (minx <= 0) ? 0 : (minx - 1);
	j1 = (miny <= 0) ? 0 : (miny - 1);
	i2 = (maxx >= (XMAX - 1)) ? (XMAX - 1) : (maxx + 1);
	j2 = (maxy >= (YMAX - 1)) ? (YMAX - 1) : (maxy + 1);
	for (i = i1; i <= i2; ++i) {
		for (j = j1; j <= j2; ++j) {
			c = cell[i][j];
			if (c > 10) {
				if (c < 13 || c > 14) {
					cell[i][j] = 0;
					pop--;
					doneflag = 0;
#ifdef PAD
					mvwaddch(padwin, i, j, ' ');
#endif				/* PAD */
				} else {
					cell[i][j] = 10;
#ifdef PAD
					mvwaddch(padwin, i, j, '*');
#endif				/* PAD */
				}
			} else if (c == 3) {
				cell[i][j] = 10;
				pop++;
				doneflag = 0;
#ifdef PAD
				mvwaddch(padwin, i, j, '*');
#endif				/* PAD */
			} else {
				cell[i][j] = 0;
			}
		}
	}
	if (!pop || doneflag) {
		return 1;
	}
	adjust_maxmin();
	if (center >= TRACK_CENTER)
		find_offset();
	display();
	++gen;
	return 0;
}

/* Keep pattern away from edges, if possible. */

int
adjust_pattern(force_it)
	int             force_it;
{
	/* 
	 * for overflow in x and y directions;
	 * must enter both procedures adjx() and adjy() 
	 * on each call of adjust_pattern()
	 */
	if (adjx(force_it) + adjy(force_it))
		return 1;
	else
		return 0;
}

/* Adjust vertical position. */

int
adjx(force_it)
	int             force_it;
{
	int             delta, i, j;
	int             savdelta;

	delta = (((XMAX - 1) - maxx) - minx) / 2;
	if (!delta) {
		return 0;
	} else if (minx == 0 || (force_it && delta > 0)) {
		delta = delta + maxx;
		savdelta = delta;
		for (i = maxx; i >= minx; --i) {
			for (j = miny; j <= maxy; ++j) {
				cell[delta][j] = cell[i][j];
				cell[i][j] = 0;
			}
			--delta;
		}
		minx = delta + 1;
		maxx = savdelta;
		return 1;
	} else if (maxx == (XMAX - 1) || (force_it && delta < 0)) {
		delta = delta + minx;
		savdelta = delta;
		for (i = minx; i <= maxx; ++i) {
			for (j = miny; j <= maxy; ++j) {
				cell[delta][j] = cell[i][j];
				cell[i][j] = 0;
			}
			++delta;
		}
		maxx = delta - 1;
		minx = savdelta;
		return 1;
	} else
		return 0;
}

/* Adjust horizontal position. */

int
adjy(force_it)
	int             force_it;
{
	int             delta, i, j;
	int             savdelta;

	delta = (((YMAX - 1) - maxy) - miny) / 2;
	if (!delta) {
		return 0;
	} else if (miny == 0 || (force_it && delta > 0)) {
		delta = delta + maxy;
		savdelta = delta;
		for (i = maxy; i >= miny; --i) {
			for (j = minx; j <= maxx; ++j) {
				cell[j][delta] = cell[j][i];
				cell[j][i] = 0;
			}
			--delta;
		}
		miny = delta + 1;
		maxy = savdelta;
		return 1;
	} else if (maxy == (YMAX - 1) || (force_it && delta < 0)) {
		delta = delta + miny;
		savdelta = delta;
		for (i = miny; i <= maxy; ++i) {
			for (j = minx; j <= maxx; ++j) {
				cell[j][delta] = cell[j][i];
				cell[j][i] = 0;
			}
			++delta;
		}
		maxy = delta - 1;
		miny = savdelta;
		return 1;
	} else
		return 0;
}
