/* --------------------------------- nosound.c ------------------------------ */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* The Sound device driver for when you have none.
*/

#include "fly.h"


LOCAL_FUNC void FAR
SndPoll (int force)
{}

LOCAL_FUNC int FAR
SndBeep (int f, int milli)
{return (0);}

LOCAL_FUNC int FAR
SndList (int *list, int id)
{return (0);}

LOCAL_FUNC int FAR
SndEffect (int eff, int command, ...)
{return(0);}

LOCAL_FUNC int FAR
SndInit (char *name)
{return (0);}

LOCAL_FUNC void FAR
SndTerm (void)
{}

struct SndDriver NEAR SndNone = {
	"NoSound",
	0,
	NULL,
	SndInit,
	SndTerm,
	SndPoll,
	SndBeep,
	SndEffect,
	SndList
};
