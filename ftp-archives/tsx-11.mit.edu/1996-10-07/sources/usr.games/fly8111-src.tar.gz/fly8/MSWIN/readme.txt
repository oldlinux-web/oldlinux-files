# readme
#
# This is part of the flight simulator 'fly8'.
# Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
#
# MS Windows part by: Michael Taylor (miket@canb.auug.org.au)

Last Modification: 18th November 1994


To install:

Extract the files into a subdirectory e.g. c:\games\fly8win 
Add a new program item in the program manager in the GAMES group. 
Set the default directory to be where you have the fly.ini and other files.
(NOTE fly8 has no icon so it will get the default icon).

Now double click on the icon to run Fly8. (or use the file manager to
run it).

If Fly8 fails to run check the file fly.log in the fly8 directory for
diagnostic information. 


IMPORTANT: keep all the files together otherwise fly8 will not be able to
find its support files.

VIDEO DRIVERS ARE:

GrWinG          uses the new WinG library for no flicker and better performance
GrGDI           uses standard Windows API and flickers
GrBitBlt        uses standard WIndows API and BitBlt for no flicker

If building this from the source release then the MSWIN\config.
bat takes two parameters. Adding a second parameter builds the
WinG version.
