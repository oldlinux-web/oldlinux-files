/* wave.h
 * Interface to simple tone generation function.
*/
extern BOOL	FAR FInitSnd(void);
extern void	FAR CloseSnd(void);
extern void	FAR Fly8PlaySnd (int Freq);
extern void	FAR StopSnd(void);
