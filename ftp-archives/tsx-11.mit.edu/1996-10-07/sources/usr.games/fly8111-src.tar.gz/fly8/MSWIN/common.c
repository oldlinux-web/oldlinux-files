#define STRICT
#include <windows.h>
#include <fly.h>

HDC	hdc = 0;	/* handle of device context	*/

int 	usingWinG = 0;
int	resetSSize = 0;
int	newx = 0, newy = 0;

char _Gbuf[2048] = "";

HWND		ghWndMain  = (HWND)0;
HWND		ghWndText  = (HWND)0;

void FAR
perror (const char *p)
{
	MessageBox((HWND)0, (LPCSTR)p, (LPCSTR)"Fly8 Error", MB_OK);
}
