extern HDC 	hdc;	/* handle of device context	*/

extern int 	usingWinG;
extern int	resetSSize;
extern int	newx, newy;

extern char	_Gbuf[2048];

extern HWND	ghWndMain;
extern HWND	ghWndText;

extern HINSTANCE	Fly8Instance;
extern char	FAR Fly8AppName[10];
extern char	FAR Fly8Message[15];
extern char	FAR Fly8Text[10];

extern Ulong	FAR GrStats[2048];
