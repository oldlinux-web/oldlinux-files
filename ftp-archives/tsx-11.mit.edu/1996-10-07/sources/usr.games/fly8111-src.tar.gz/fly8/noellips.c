/* --------------------------------- noellips.c ----------------------------- */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* Draw a 16-gon instead of an ellipse.
*/

#include "fly.h"


extern void FAR
NoEllipse (Uint x1, Uint y1, Uint rx, Uint ry, Uint color)
{
	int	ax, bx, cx, dx, ay, by, cy, dy;

	ax = fmul ( 3196, rx);		/* sin (pi/16) */
	ay = fmul ( 3196, ry);
	bx = fmul ( 9102, rx);		/* sin (3*pi/16) */
	by = fmul ( 9102, ry);
	cx = fmul (13623, rx);		/* sin (5*pi/16) */
	cy = fmul (13623, ry);
	dx = fmul (16069, rx);		/* sin (7*pi/16) */
	dy = fmul (16069, ry);

	Gr->MoveTo (x1+dx, y1-ay);
	Gr->DrawTo (x1+cx, y1-by, color);
	Gr->DrawTo (x1+bx, y1-cy, color);
	Gr->DrawTo (x1+ax, y1-dy, color);
	Gr->DrawTo (x1-ax, y1-dy, color);
	Gr->DrawTo (x1-bx, y1-cy, color);
	Gr->DrawTo (x1-cx, y1-by, color);
	Gr->DrawTo (x1-dx, y1-ay, color);
	Gr->DrawTo (x1-dx, y1+ay, color);
	Gr->DrawTo (x1-cx, y1+by, color);
	Gr->DrawTo (x1-bx, y1+cy, color);
	Gr->DrawTo (x1-ax, y1+dy, color);
	Gr->DrawTo (x1+ax, y1+dy, color);
	Gr->DrawTo (x1+bx, y1+cy, color);
	Gr->DrawTo (x1+cx, y1+by, color);
	Gr->DrawTo (x1+dx, y1+ay, color);
	Gr->DrawTo (x1+dx, y1-ay, color);
}
