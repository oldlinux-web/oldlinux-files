/* --------------------------------- xkeys.h -------------------------------- */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* Header for Unix video drivers, for xkeys.c.
*/

extern int	xGetKey (XKeyEvent *xkey);
