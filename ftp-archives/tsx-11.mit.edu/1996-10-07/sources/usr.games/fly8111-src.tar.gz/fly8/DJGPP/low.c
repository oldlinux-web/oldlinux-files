/* --------------------------------- low.c ---------------------------------- */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* Low level componnents for grasm/line.
 *
 * SetActiveBase (Ulong b)
 * SetVisualBase (Ulong b)
 * ScrClear (int x, int y, int sizex, int sizey, Uint color)
*/

#include "fly.h"
#include "grdj.h"

#include <graphics.h>
#include <pc.h>
#include <dos.h>


static char	BPTR *VideoBase = VGA_PAGE;
static Ulong	VisualBase = 0;
static Uint	xbytes = 0;


extern void FAR
SetActiveBase (Ulong b)
{
	bSetActive (VideoBase + b);
}

extern void FAR
SetVisualBase (Ulong base)		/* t4k/VBE specific!!!!!!!!!!!!!!! */
{
	int		i;
	Ulong		flags;
	union REGS	regs;

	if (base == VisualBase)
		return;

	switch (Gr->flags & GR_TYPES) {
	case GR_TYPE_T4K:
		flags = Sys->Disable ();
		outportb (0x3d4, 0x0d);	/* start base low */
		outportb (0x3d5, (int)((base>>2)&0x00ff));

		outportb (0x3d4, 0x0c);	/* start base high */
		outportb (0x3d5, (int)((base>>10)&0x00ff));

		outportb (0x3d4, 0x33);	/* start base very high */
		i = inportb (0x3d5);
		outportb (0x3d5, (i&~3)|(int)((base>>18)&3));
		Sys->Enable (flags);
		break;
	case GR_TYPE_VESA:
		regs.x.ax = 0x4F07;
		regs.x.bx = 0;
		regs.x.dx = base / xbytes;
		regs.x.cx = base - regs.x.dx * (long)xbytes;
		int86 (0x10, &regs, &regs);
		break;
	default:
		/* oops! */
		break;
	}
	VisualBase = base;
}

extern void FAR
InitGr (int mode, int sizex, int sizey)
{
	GrSetMode (mode, sizex, sizey);
	xbytes = GrMaxX () + 1;
	bSetSize (xbytes, GrMaxY () + 1, xbytes);
	bSetActive (VideoBase);
	VisualBase = 0;
}
