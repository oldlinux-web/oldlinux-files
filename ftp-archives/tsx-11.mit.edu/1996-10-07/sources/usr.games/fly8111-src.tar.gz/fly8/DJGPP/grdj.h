/* --------------------------------- grdj.h --------------------------------- */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* Vga graphics low level routines.
*/

#ifndef FLY8_FAST_GRDJ
#define FLY8_FAST_GRDJ

#include "bgr.h"

#define VGA_PAGE	((char BPTR *)0xd0000000)

#define GR_TYPES	0x000f
#define GR_TYPE_T4K	0x0000
#define GR_TYPE_S3	0x0001
#define GR_TYPE_VESA	0x0002

/* low.c */
extern void	FAR SetActiveBase (Ulong b);
extern void	FAR SetVisualBase (Ulong b);
extern void	FAR InitGr (int mode, int sizex, int sizey);

#endif
