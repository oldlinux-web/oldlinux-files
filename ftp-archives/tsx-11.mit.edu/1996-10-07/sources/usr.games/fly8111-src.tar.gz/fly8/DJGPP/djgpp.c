/* --------------------------------- djgpp.c -------------------------------- */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* general system-specific stuff for UNIX.
*/

#include "fly.h"


/* ints.s */
extern void IntOn (Ulong flags);
extern Ulong IntOff (void);

static int FAR
init (void)
{return (0);}

static void FAR
term (void)
{}

static void FAR
poll (void)
{
	Tm->Milli ();
}

static Ulong FAR
disable (void)
{
	return (IntOff ());
}

static void FAR
enable (Ulong flags)
{
	IntOn (flags);
}

static void FAR
shell (void)
{
	MsgWPrintf (20, "shell not implemented");
}

static void FAR
BuildFileName (char *FullName, char *path, char *name, char *ext)

/* Build file name from parts.
 * path is NULL for "current directory".
 * path is ""   for "root directory".
*/

{
	FullName[0] = '\0';

	if (path) {
		strcat (FullName, path);
		strcat (FullName, "\\");
	}
	strcat (FullName, name);
	if (ext && ext[0]) {
		strcat (FullName, ".");
		strcat (FullName, ext);
	}
}

struct SysDriver SysDriver = {
	"DJGPP",
	0,
	NULL,	/* extra */
	init,
	term,
	poll,
	disable,
	enable,
	shell,
	BuildFileName
};
