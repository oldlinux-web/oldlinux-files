/* --------------------------------- drivers.c ------------------------------ */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* User defined lists of drivers. This one is for UNIX/X11.
 *
 * Associated with the player we have one of each:
 *  Graphics Driver (output)
 *  Sound Driver (output)
 *  Keyboard Driver (input)
 *  Pointer Driver (input)
 *  Network Drivers (i/o)
*/

#include "fly.h"


extern struct GrDriver GrASM;
extern struct GrDriver GrDJ;

struct GrDriver *GrDrivers[] = {
	&GrASM,		/* default */
	&GrDJ,
0};


extern struct SndDriver NEAR SndPlSpeaker;

struct SndDriver NEAR* FAR SndDrivers[] = {
	&SndPlSpeaker,
0};

extern struct PtrDriver PtrKeypad;
extern struct PtrDriver PtrRandom;
extern struct PtrDriver PtrMouse;
extern struct PtrDriver PtrAstick;
extern struct PtrDriver PtrBstick;

struct PtrDriver *PtrDrivers[] = {
	&PtrKeypad,
	&PtrAstick,
	&PtrBstick,
	&PtrMouse,
	&PtrRandom,
0};


extern struct KbdDriver KbdConsole;

struct KbdDriver *KbdDrivers[] = {
	&KbdConsole,
0};


struct NetDriver *NetDrivers[] = {
0};
