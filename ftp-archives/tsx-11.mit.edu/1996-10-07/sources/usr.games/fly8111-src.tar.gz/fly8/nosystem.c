/* --------------------------------- nosystem.c ----------------------------- */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* Dummy system driver.
*/

#include "fly.h"


LOCAL_FUNC int FAR
nsys_init (void)
{return (0);}

LOCAL_FUNC void FAR
nsys_term (void)
{}

LOCAL_FUNC Ulong FAR
nsys_disable (void)
{return (0);}

LOCAL_FUNC void FAR
nsys_enable (Ulong flags)
{}

LOCAL_FUNC void FAR
nsys_shell (void)
{}

LOCAL_FUNC void FAR
nsys_build (char *FullName, char *path, char *name, char *ext)
{}

struct SysDriver NEAR SysNone = {
	"NoSystem",
	0,
	NULL,
	nsys_init,
	nsys_term,
	0,	/* poll */
	nsys_disable,
	nsys_enable,
	nsys_shell,
	nsys_build
};
