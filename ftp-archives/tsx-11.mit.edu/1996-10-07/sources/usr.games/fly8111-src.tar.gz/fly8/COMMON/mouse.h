/* --------------------------------- mouse.h -------------------------------- */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* Header for mouse.c.
*/


extern int	GetMouse (int *win_x, int *win_y, char *btn, int *nbtn);
