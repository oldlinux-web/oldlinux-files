/* --------------------------------- misc.c --------------------------------- */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* Miscelanious functions.
*/

#include "fly.h"
