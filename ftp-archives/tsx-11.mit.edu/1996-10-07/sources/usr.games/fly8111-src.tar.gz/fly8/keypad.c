/* --------------------------------- keypad.c ------------------------------- */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* Handler for the keyboard as a pointing device.
*/

#include "fly.h"


LOCAL_FUNC void FAR
Kkey (POINTER *p, int key)
{
	switch (key) {
	case KF_UP:			/* counter clockwise */
		if (p->a[1] < 100)
			p->a[1] += 10;
		else
			p->a[1] = 100;
		break;
	case KF_DOWN:			/* clockwise */
		if (p->a[1] > -100)
			p->a[1] -= 10;
		else
			p->a[1] = -100;
		break;

	case KF_RIGHT_TURN:		/* clockwise */
		if (p->a[0] > -100)
			p->a[0] -= 10;
		else
			p->a[0] = -100;
		break;
	case KF_LEFT_TURN:		/* counter clockwise */
		if (p->a[0] < 100)
			p->a[0] += 10;
		else
			p->a[0] = 100;
		break;

	default:
		std_key (p, key);
		break;
	}
}

LOCAL_FUNC int FAR
Kcal (POINTER *p)
{
	p->a[0] = p->a[1] = 0;
	p->l[0] = p->l[1] = 0;
	return (0);
}

LOCAL_FUNC int FAR
Kread (POINTER *p, int transfer)
{
	if (transfer) {
		p->l[0] = p->a[0];
		p->l[1] = p->a[1];
	}
	do_btns (p, NULL, 0);
	return (0);
}

LOCAL_FUNC int FAR
Kinit (POINTER *p, char *options)
{
	return (Kcal (p));
}

LOCAL_FUNC void FAR
Kterm (POINTER *p)
{}

struct PtrDriver NEAR PtrKeypad = {
	"KEYPAD",
	0,
	NULL,	/* extra */
	Kinit,
	Kterm,
	Kcal,
	Kcal,			/* center */
	Kread,
	Kkey
};
