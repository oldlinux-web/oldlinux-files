/* --------------------------------- misc.c --------------------------------- */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* Miscellanious functions.
*/

#include "fly.h"
