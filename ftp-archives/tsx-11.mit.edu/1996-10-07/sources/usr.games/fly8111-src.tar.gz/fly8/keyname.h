/* --------------------------------- keyname.h ------------------------------ */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* key names, used by mac2max and max2mac.
*/

#ifndef FLY8_KEYNAME
#define FLY8_KEYNAME

#include "keymap.h"

#define	VK_DEF	0x00010000L
#define	VK_EOF	0x00020000L
#define	VK_COM	0x00040000L
#define	VK_STR	0x00080000L

struct names {
	char	*name;
	long	value;
};

#if 0
static struct names f_name[] = {		/* function names */
	{"MENU",	KF_MENU},

	{"UP",		KF_UP},
	{"DOWN",	KF_DOWN},
	{"LEFT_TURN",	KF_LEFT_TURN},
	{"RIGHT_TURN",	KF_RIGHT_TURN},
	{"STABLE",	KF_STABLE},
	{"RESET_ROLL",	KF_RESET_ROLL},
	{"LEVEL",	KF_LEVEL},
	{"ORIGIN",	KF_ORIGIN},
	{"POWER_UP",	KF_POWER_UP},
	{"POWER_DOWN",	KF_POWER_DOWN},
	{"POWER_0",	KF_POWER_0},
	{"POWER_100",	KF_POWER_100},
	{"POWER_AB",	KF_POWER_AB},
	{"FIRE",	KF_FIRE},
	{"FRUDLEFT",	KF_FRUDLEFT},
	{"FRUDCNTR",	KF_FRUDCNTR},
	{"FRUDRITE",	KF_FRUDRITE},
	{"ZOOMIN",	KF_ZOOMIN},
	{"ZOOMOUT",	KF_ZOOMOUT},
	{"MACRECORD",	KF_MACRECORD},
	{"MACPLAY",	KF_MACPLAY},

	{"XUP",		KF_XUP},
	{"XDOWN",	KF_XDOWN},
	{"XLEFT",	KF_XLEFT},
	{"XRIGHT",	KF_XRIGHT},

	{"YUP",		KF_YUP},
	{"YDOWN",	KF_YDOWN},
	{"YLEFT",	KF_YLEFT},
	{"YRIGHT",	KF_YRIGHT},

	{"ZUP",		KF_ZUP},
	{"ZDOWN",	KF_ZDOWN},
	{"ZLEFT",	KF_ZLEFT},
	{"ZRIGHT",	KF_ZRIGHT},
{0,0}};
#endif

static struct names k_name[] = {		/* key names */
	{"",		0},
	{"F1",		K_F1},
	{"F2",		K_F2},
	{"F3",		K_F3},
	{"F4",		K_F4},
	{"F5",		K_F5},
	{"F6",		K_F6},
	{"F7",		K_F7},
	{"F8",		K_F8},
	{"F9",		K_F9},
	{"F10",		K_F10},
	{"F11",		K_F11},
	{"F12",		K_F12},
	{"Left",	K_LEFT},
	{"Right",	K_RIGHT},
	{"Up",		K_UP},
	{"Dn",		K_DOWN},
	{"Down",	K_DOWN},
	{"PgUp",	K_PGUP},
	{"PageUp",	K_PGUP},
	{"PgDn",	K_PGDN},
	{"PageDown",	K_PGDN},
	{"Home",	K_HOME},
	{"End",		K_END},
	{"Ins",		K_INS},
	{"Insert",	K_INS},
	{"Ctr",		K_CENTER},
	{"Center",	K_CENTER},

	{"Del",		K_DEL},
	{"Delete",	K_DEL},
	{"Sp",		' '},
	{"Space",	' '},
	{"Bell",	K_BELL},
	{"Bs",		K_RUBOUT},
	{"Ro",		K_RUBOUT},
	{"Rubout",	K_RUBOUT},
	{"Esc",		K_ESC},
	{"Escape",	K_ESC},
	{"Ff",		K_FF},
	{"Cr",		K_ENTER},
	{"Enter",	K_ENTER},
	{"Ent",		K_ENTER},
	{"Ret",		K_ENTER},
	{"Nl",		K_NL},
	{"Tab",		K_TAB},
	{"Vt",		K_VTAB},

	{"Brl",		K_BTN|K_RLS},

	{"Spc",		K_SPECIAL},
	{"Special",	K_SPECIAL},
	{"Sh",		K_SHIFT},
	{"Shift",	K_SHIFT},
	{"Ctrl",	K_CTRL},
	{"Alt",		K_ALT},
	{"Rls",		K_RLS},
	{"Btn",		K_BTN},
	{"Qte",		K_QUOTE},
	{"Quote",	K_QUOTE},
	{"Def",		VK_DEF},
{0,0}};

#endif
