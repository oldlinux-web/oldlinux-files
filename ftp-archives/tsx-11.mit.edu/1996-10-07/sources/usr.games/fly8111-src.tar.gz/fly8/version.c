/* --------------------------------- version.c ------------------------------ */

/* This is part of the flight simulator 'fly8'.
 * Author: Eyal Lebedinsky (eyal@ise.canberra.edu.au).
*/

/* version number and last date/time.
*/

#include "fly.h"


#define	VERSION		"1.11"

extern char * FAR
welcome (int where)
{
	static char	ver[1 + sizeof (VERSION) +
			sizeof (__DATE__) + sizeof (__TIME__)];

	strcpy (ver, "v");
	strcat (ver, VERSION);
	strcat (ver, " ");
	strcat (ver, __DATE__);
	strcat (ver, " ");
	strcat (ver, __TIME__);

	switch (where) {
	case 0:						/* to screen */
		MsgPrintf (100, "Welcome to Fly8");
		MsgPrintf (100, "Version: %s", ver);
		MsgPrintf (100, "By Eyal Lebedinsky");
		MsgPrintf (100, "(eyal@ise.canberra.edu.au)");
		break;
	case 2:						/* to stderr */
#ifndef NOSTDERR
		fprintf (stderr, "Welcome to Fly8 ");
		fprintf (stderr, "Version: %s\n", ver);
		fprintf (stderr, "By Eyal Lebedinsky ");
		fprintf (stderr, "(eyal@ise.canberra.edu.au)\n");
		break;
#endif
	case 1:						/* to log */
		LogPrintf ("Welcome to Fly8 ");
		LogPrintf ("Version: %s\n", ver);
		LogPrintf ("By Eyal Lebedinsky ");
		LogPrintf ("(eyal@ise.canberra.edu.au)\n");
		break;
	default:					/* just get it */
		break;
	}

	return (ver);
}
#undef VERSION
