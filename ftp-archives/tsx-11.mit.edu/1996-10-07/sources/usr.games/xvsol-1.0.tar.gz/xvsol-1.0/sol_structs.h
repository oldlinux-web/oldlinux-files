/* xvSolitaire, version 1.0
 * Copyright (C) 1993  Andreas Almroth
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <xview/panel.h>

struct board {
  char name[32];
  int data[81];
  Panel_item item[81];
  struct board *next;
};
