/* xvSolitaire, version 1.0
 * Copyright (C) 1993  Andreas Almroth
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

struct board *board,*work,*next,*now;
struct board *parse_resource(void);
int move_ball(Panel_item,Event);
void update_board(int,int,int);
int proj_proc(Menu,Menu_item);
int board_proc(Menu,Menu_item);
void draw_board(struct board *);
void destroy_board(struct board *);
void check_board(void);
extern void free_boards(struct board *);
int main(int,char **);
