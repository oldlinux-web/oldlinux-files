/* Sleep a given number of milliseconds.
   Copyright (C) 1992 Free Software Foundation, Inc.
   Francois Pinard <pinard@iro.umontreal.ca>, 1992.
*/

/* Code heavily borrowed from Taylor UUCP 1.03.	 Ian picked one of
   usleep, nap, napms, poll, select and sleep, in decreasing order of
   preference.	The sleep function is always available.  */

/* In many cases, we will sleep if the wanted number of milliseconds
   is higher than this value.  */
#define THRESHOLD_FOR_SLEEP 30000

/* Insure defines for testing file headers.  */
#ifndef HAVE_POLL_H
#define HAVE_POLL_H 0
#endif
#ifndef HAVE_STROPTS_H
#define HAVE_STROPTS_H 0
#endif

/* Insure defines for testing system functions.  */
#ifndef HAVE_NAP
#define HAVE_NAP 0
#endif
#ifndef HAVE_NAPMS
#define HAVE_NAPMS 0
#endif
#ifndef HAVE_POLL
#define HAVE_POLL 0
#endif
#ifndef HAVE_SELECT
#define HAVE_SELECT 0
#endif
#ifndef HAVE_USLEEP
#define HAVE_USLEEP 0
#endif

/* Include necessary files.  */
#if HAVE_POLL
#if HAVE_STROPTS_H
#include <stropts.h>
#endif
#if HAVE_POLL_H
#include <poll.h>
#endif
#if ! HAVE_STROPTS_H && ! HAVE_POLL_H
/* We need a definition for struct pollfd, although it doesn't matter
   what it contains.  */
struct pollfd
{
  int idummy;
};
#endif /* ! HAVE_STROPTS_H && ! HAVE_POLL_H */
#else /* not HAVE_POLL */
#if HAVE_SELECT
#include <sys/time.h>
#endif /* HAVE_SELECT */
#endif /* not HAVE_POLL */


/*---------------------------------------.
| Sleep a given number of milliseconds.	 |
`---------------------------------------*/

void
msleep (int milliseconds)
{
#if HAVE_USLEEP

  if (milliseconds > 0)
    usleep (milliseconds * (long) 1000);

#else /* not HAVE_USLEEP */
#if HAVE_NAP

  if (milliseconds > 0)
    nap ((long) milliseconds);

#else /* not HAVE_NAP */
#if HAVE_NAPMS

  if (milliseconds >= THRESHOLD_FOR_SLEEP)
    {
      sleep (milliseconds / 1000);
      milliseconds %= 1000;
    }
  if (milliseconds > 0)
    napms (milliseconds % 1000);

#else /* not HAVE_NAPMS */
#if HAVE_POLL

  struct pollfd sdummy;		/* poll(2) checks this address */

  if (milliseconds >= THRESHOLD_FOR_SLEEP)
    {
      sleep (milliseconds / 1000);
      milliseconds %= 1000;
    }
  if (milliseconds > 0)
    poll (&sdummy, 0, milliseconds);

#else /* not HAVE_POLL */
#if HAVE_SELECT

  struct timeval s;

  if (milliseconds >= THRESHOLD_FOR_SLEEP)
    {
      sleep (milliseconds / 1000);
      milliseconds %= 1000;
    }
  if (milliseconds > 0)
    {
      s.tv_sec = milliseconds / 1000;
      s.tv_usec = (milliseconds % 1000) * (long) 1000;
      select (0, (int *) NULL, (int *) NULL, (int *) NULL, &s);
    }

#else /* not HAVE_SELECT */

  /* Round the time up to the next full second.  */

  if (milliseconds > 0)
    sleep ((milliseconds + 999) / 1000);

#endif /* not HAVE_SELECT */
#endif /* not HAVE_POLL */
#endif /* not HAVE_NAPMS */
#endif /* not HAVE_NAP */
#endif /* not HAVE_USLEEP */
}
