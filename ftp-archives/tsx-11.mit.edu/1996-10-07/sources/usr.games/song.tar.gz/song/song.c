/* Reproduce a multi-voice song on a 386/ix 2.0.2 (ISC) system console.
   Copyright (C) 1992 Free Software Foundation, Inc.
   Francois Pinard <pinard@iro.umontreal.ca>, 1992.
*/

/*=======================================================================\
| NOTE: standard input must be associated a virtual terminals.	Further, |
| it must be currently displayed for any sound to occur.		 |
\=======================================================================*/

/* Diapason frequency in Hertz for a3.  */
#define DIAPASON 440

/* Wave length for DIAPASON Hertz, found experimentally.  */
#define DIAPASON_WAVE_LENGTH 2712

/* Expected milliseconds for all voices in a hashed multi-voice play.  */
#define EXPECTED_HASHING 120

/* Minimum milliseconds time per voice for hashed multi-voice play.  */
#define MINIMUM_HASHING 35

/* If non-zero, hash even a single voice.  Timing seems to be better.  */
#define HASH_SINGLE_VOICE 1

#include <stdio.h>
#include <sys/types.h>
#include <sys/fcntl.h>
#ifndef linux
#include <sys/at_ansi.h>
#endif /* !linux */
#include <sys/kd.h>

#include "song.h"

/* Frequencies in Hertz of the chromatic scale, from c3 to b4, for an
   equal temperament, tuned to a 440 diapason.  */
static int chromatic_scale_in_hertz[12]
  = {523, 554, 587, 622, 659, 698, 740, 784, 831, 880, 932, 988};

/* Array of wave lengths for all natural notes, in unknown units.  */
static int wave_length[NUMBER_OF_NOTES];


/* Library functions.  */

extern void *malloc (int);
extern void *realloc (void *, int);

static void *
xmalloc (int length)
{
  void *result;

  result = malloc (length);
  if (result == NULL)
    {
      fprintf (stderr, "Virtual memory exhausted.\n");
      exit (1);
    }
  return result;
}

static void *
xrealloc (void *pointer, int length)
{
  void *result;

  result = realloc (pointer, length);
  if (result == NULL)
    {
      fprintf (stderr, "Virtual memory exhausted.\n");
      exit (1);
    }
  return result;
}

/* Internal functions.  */

/*-----------------------------------.
| Initialize the wave_length array.  |
`-----------------------------------*/

static void
compute_wave_length_array ()
{
  int note;

  /* Initialize the main scale.  */

  for (note = c3; note < c3 + 12; note++)
    wave_length[note] = (DIAPASON_WAVE_LENGTH * DIAPASON
			 / chromatic_scale_in_hertz [note - c3]);

  /* Initialize octaves and suboctaves.  */

  for (note = c3 - 1; note >= 0; note--)
    wave_length[note] = wave_length[note + octave] * 2;
  for (note = c3 + octave; note < NUMBER_OF_NOTES; note++)
    wave_length[note] = (wave_length[note - octave] + 1) / 2;
}

/*-----------------------------------------------------------------------.
| Play a single NOTE, then wait for some DURATION in milliseconds before |
| returning.  Beware that the note is not silenced before the routine	 |
| returns.  If NOTE is negative, the last note is silenced instead of a	 |
| new one being started, the wait is still effected.			 |
`-----------------------------------------------------------------------*/

static void
sing_note (int note, int duration)
{
  if (note < 0)
    {

      /* Silence the last sound.  */

      if (ioctl (0, KIOCSOUND, 0) < 0)
	{
	  perror ("silence_note");
	  exit (1);
	}
    }
  else
    {

      /* Start a new sound.  */

      if (ioctl (0, KIOCSOUND, wave_length[note]) < 0)
	{
	  perror ("sing_note");
	  exit (1);
	}
    }

  /* Wait if some wait duration has been specified.  */

  if (duration > 0)
      msleep (duration);
}

/*----------------------------------------------------------------------.
| Play all notes from NOTE_ARRAY of length NUMBER_OF_VOICES, by hashing |
| them until some DURATION, in milliseconds, has expired.		|
`----------------------------------------------------------------------*/

static void
sing_many_notes (int *note_array, int number_of_voices, int duration)
{
  int n_voices;			/* number of voices */
  int hashing;			/* milliseconds per voice */
  int voice;			/* current voice */

  /* Remove any silent voice from both ends.  */

  while (number_of_voices > 0 && note_array[0] < 0)
    {
      note_array++;
      number_of_voices--;
    }
  while (number_of_voices > 0 && note_array[number_of_voices - 1] < 0)
    number_of_voices--;

  /* Count the number of speaking voices.  */

  n_voices = 0;
  for (voice = 0; voice < number_of_voices; voice++)
    if (note_array[voice] >= 0)
      n_voices++;

  switch (n_voices)
    {
    case 0:

      /* If no speaking voice, ask for silence.  */

      sing_note (-1, duration);
      break;

#if !HASH_SINGLE_VOICE

    case 1:

      /* If only one speaking voice, do not hash it.  */

      sing_note (note_array[0], duration);
      break;

#endif /* !HASH_SINGLE_VOICE */

    default:

      /* If many speaking voices, compute the hashing, and play them.  */

      if (duration < EXPECTED_HASHING)
	hashing = duration / n_voices;
      else
	hashing = EXPECTED_HASHING / n_voices;
      if (hashing < MINIMUM_HASHING)
	hashing = MINIMUM_HASHING;

      voice = 0;
      while (1)
	{

	  /* Play the voice for no more than HASHING milliseconds.  */

	  if (duration > hashing)
	    {
	      sing_note (note_array[voice], hashing);
	      duration -= hashing;
	    }
	  else
	    {
	      sing_note (note_array[voice], duration);
	      break;
	    }

	  /* Prepare for next voice, skipping any silent voice.  */

	  do
	    {
	      voice++;
	      if (voice == number_of_voices)
		voice = 0;
	    }
	  while (note_array[voice] < 0);
	}
    }
}


/* User callable functions.  */

struct note
{
  int timer;			/* absolute start time in milliseconds */
  int voice;			/* voice to which this note pertains */
  int note;			/* note to be started or < 0 for silence */
};

static int n_voices;		/* number of voices */
static int *timer;		/* array of timers, one per voice */
static int voice;		/* current voice */

static struct note *tape;	/* array of recorded notes */
static int tape_length;		/* number of recorded notes */
static int sorted_tape;		/* if tape has been sorted */

/* Number of available positions for voices.  */
static int allocated_timers = 0;
/* Number of available positions on tape for recorded notes.  */
static int allocated_notes = 0;

/*-------------------------------------------------------------------.
| Initialize recording of a new song with a given NUMBER_OF_VOICES.  |
`-------------------------------------------------------------------*/

void
new_song_recording (int number_of_voices)
{
  compute_wave_length_array ();

  /* Insure sufficient allocation.  */

  if (number_of_voices > allocated_timers)
    {
      if (allocated_timers > 0)
	free (timer);
      timer = (int *) xmalloc (number_of_voices * sizeof (int));
      allocated_timers = number_of_voices;
    }
  if (allocated_notes == 0)
    {
      tape = (struct note *) xmalloc (2000 * sizeof (struct note));
      allocated_notes = 2000;
    }

  /* Complete initialization.  */

  n_voices = number_of_voices;
  for (voice = 0; voice < n_voices; voice++)
    timer[voice] = 0;
  voice = 0;
  tape_length = 0;
  sorted_tape = 0;
}

/*------------------------------------------.
| Change the recording voice to NEW_VOICE.  |
`------------------------------------------*/

void
record_on_voice (int new_voice)
{
  voice = new_voice;
}

/*----------------------------------------------------------.
| Record a NOTE for a given DURATION on the current voice.  |
`----------------------------------------------------------*/

void
record_note (int note, int duration)
{

  /* Insure there is space for a new note.  */

  if (tape_length == allocated_notes)
    {
      allocated_notes += 2000;
      tape = (struct note *)
	xrealloc (tape, allocated_notes * sizeof (struct note));
    }

  /* Add the note.  */

  tape[tape_length].timer = timer[voice];
  tape[tape_length].voice = voice;
  tape[tape_length].note = note;
  timer[voice] += duration;
  tape_length++;
}

/*-------------------------------------------.
| Comparison function for sorting the tape.  |
`-------------------------------------------*/

int
tape_sorter (struct note *x, struct note *y)
{
  int value;

  value = x->timer - y->timer;
  if (value != 0)
    return value;
  value = x->voice - y->voice;
  if (value != 0)
    return value;
  return x->note - y->note;
}

/*----------------------------.
| Execute the recorded song.  |
`----------------------------*/

void
playback_recorded_song (void)
{
  int play_timer;		/* timer while playing */
  int *play_note;		/* array of notes for multi-play */
  struct note *head;		/* read head on tape */

  /* If the tape has not been sorted yet, do it, after having added
     silencing notes for each voice.  */

  if (!sorted_tape)
    {
      for (voice = 0; voice < n_voices; voice++)
	record_note (-1, 0);
      qsort (tape, tape_length, sizeof (struct note), tape_sorter);
      sorted_tape = 1;
    }

  /* Initialize tape reading.  */

  play_note = (int *) xmalloc (n_voices * sizeof (int));
  for (voice = 0; voice < n_voices; voice++)
    play_note[voice] = -1;
  play_timer = 0;

  /* Play the tape.  */

  for (head = tape; head < tape + tape_length; head++)
    {
      if (head->timer > play_timer)
	{
	  sing_many_notes (play_note, n_voices, head->timer - play_timer);
	  play_timer = head->timer;
	}
      play_note[head->voice] = head->note;
    }
  sing_many_notes (play_note, n_voices, 0);

  /* End tape play.  */

  free (play_note);
}


#ifdef TEST_PROGRAM

/* Demonstration program.  */

/* Define the time value for the `noire', `blanche' and `croche' figures.  */

#define n METRONOME (120)
#define b (n * 2)
#define c (n / 2)

const char *program_name;	/* Name of this program.  */

/* Make the song for the given VOICE, playing it at some INTERVAL from
   its current base, and waiting some DELAY first.  */

make_voice (int voice, int interval, int delay)
{
  int k;

  record_on_voice (voice);
  record_note (-1, delay);

  for (k = 0; k < 2; k++)
    {
      record_note (c3 + interval, n);
      record_note (d3 + interval, n);
      record_note (e3 + interval, n);
      record_note (c3 + interval, n);
    }
  for (k = 0; k < 2; k++)
    {
      record_note (e3 + interval, n);
      record_note (f3 + interval, n);
      record_note (g3 + interval, b);
    }
  for (k = 0; k < 2; k++)
    {
      record_note (g3 + interval, c);
      record_note (a3 + interval, c);
      record_note (g3 + interval, c);
      record_note (f3 + interval, c);
      record_note (e3 + interval, n);
      record_note (c3 + interval, n);
    }
  for (k = 0; k < 2; k++)
    {
      record_note (c3 + interval, n);
      record_note (g2 + interval, n);
      record_note (c3 + interval, b);
    }
}

/*--------------------------------------------------.
| Make the three voices on the tape, then play it.  |
`--------------------------------------------------*/

int
main (int argc, const char *argv[])
{
  int k;

  program_name = argv[0];
  
  new_song_recording (4);
  make_voice (1, 0, 0);
  make_voice (3, 2*octave, 8*n);
  make_voice (2, octave, 16*n);
  make_voice (0, -octave, 24*n);
  playback_recorded_song ();

  exit (0);
}

#endif /* TEST_PROGRAM */

