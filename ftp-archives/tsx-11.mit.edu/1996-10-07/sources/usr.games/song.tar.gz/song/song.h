/* Reproduce a multi-voice song on a 386/ix 2.0.2 (ISC) system console.
   Copyright (C) 1992 Free Software Foundation, Inc.
   Francois Pinard <pinard@iro.umontreal.ca>, 1992.
*/

/* Convert the Maetzel Metronome tempo in milliseconds.  */

#define METRONOME(beats_per_minute) \
  (60000 / (beats_per_minute))

/* Correction for an octave.  Use as in `note - octave', `note + octave'.  */
#define octave 12

/* Corrections to obtain sharps and flats.  Use as in `c3 s' or `b4 f'.	 */
#define s +1
#define f -1

/* Notes names.  */

#define c0 0
#define d0 (c0 + 2)
#define e0 (c0 + 4)
#define f0 (c0 + 5)
#define g0 (c0 + 7)
#define a0 (c0 + 9)
#define b0 (c0 + 11)
#define c1 (c0 + octave)
#define d1 (d0 + octave)
#define e1 (e0 + octave)
#define f1 (f0 + octave)
#define g1 (g0 + octave)
#define a1 (a0 + octave)
#define b1 (b0 + octave)
#define c2 (c1 + octave)
#define d2 (d1 + octave)
#define e2 (e1 + octave)
#define f2 (f1 + octave)
#define g2 (g1 + octave)
#define a2 (a1 + octave)
#define b2 (b1 + octave)
#define c3 (c2 + octave)
#define d3 (d2 + octave)
#define e3 (e2 + octave)
#define f3 (f2 + octave)
#define g3 (g2 + octave)
#define a3 (a2 + octave)
#define b3 (b2 + octave)
#define c4 (c3 + octave)
#define d4 (d3 + octave)
#define e4 (e3 + octave)
#define f4 (f3 + octave)
#define g4 (g3 + octave)
#define a4 (a3 + octave)
#define b4 (b3 + octave)
#define c5 (c4 + octave)
#define d5 (d4 + octave)
#define e5 (e4 + octave)
#define f5 (f4 + octave)
#define g5 (g4 + octave)
#define a5 (a4 + octave)
#define b5 (b4 + octave)
#define c6 (c5 + octave)
#define d6 (d5 + octave)
#define e6 (e5 + octave)
#define f6 (f5 + octave)
#define g6 (g5 + octave)

/* Number of known natural notes.  */
#define NUMBER_OF_NOTES (g6 + 1)
