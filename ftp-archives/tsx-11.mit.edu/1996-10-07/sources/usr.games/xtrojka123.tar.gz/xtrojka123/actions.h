/*
 *	xtrojka (c) 1994,1995,1996 Maarten Los
 *
 *	#include "COPYRIGHT"	
 *
 *	created:	12.iii.1996
 *	modified:
 *
 *	header file for actions.c
 */

#ifndef _actions_h_
#define _actions_h_

/*
 *	function prototypes
 */

void init_actions(void);


#endif /* _actions_h_ */
