/* acconfig.h -- autoheader configuration file

   This file is part of the LZO real-time data compression library.

   Copyright (C) 1996 Markus Franz Xaver Johannes Oberhumer

   The LZO library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   The LZO library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   Library General Public License for more details.

   You should have received a copy of the GNU Library General Public
   License along with the LZO library; see the file COPYING.LIB.
   If not, write to the Free Software Foundation, Inc.,
   675 Mass Ave, Cambridge, MA 02139, USA.

   Markus F.X.J. Oberhumer
   markus.oberhumer@jk.uni-linz.ac.at
 */


#ifndef __LZO_CONFIG_AC
#define __LZO_CONFIG_AC


@TOP@

/* acconfig.h

   Descriptive text for the C preprocessor macros that
   the distributed Autoconf macros can define.
   No software package will use all of them; autoheader copies the ones
   your configure.in uses into your configuration header file templates.

   The entries are in sort -df order: alphabetical, case insensitive,
   ignoring punctuation (such as underscores).  Although this order
   can split up related entries, it makes it easier to check whether
   a given entry is in the file.

   Leave the following blank line there!!  Autoheader needs it.  */



/* See src/lzo_conf.h, config/config.lzo and configure.in.  */
#undef LZO_UNALIGNED_OK_2

/* See src/lzo_conf.h, config/config.lzo and configure.in.  */
#undef LZO_UNALIGNED_OK_4

/* See src/lzo_conf.h.  */
#undef MFX_BYTE_ORDER

/* Define if your memcmp is broken.  */
#undef MFX_MEMCMP_BROKEN

/* Define to `long' if <stddef.h> doesn't define.  */
#undef ptrdiff_t

/* Define to `int' if <stddef.h> doesn't define.  */
#undef wchar_t

/* The following comments are here to suppress an error message
   from autoheader. */
/* PACKAGE */
/* VERSION */



/* Leave that blank line there!!  Autoheader needs it.
   If you're adding to this file, keep in mind:
   The entries are in sort -df order: alphabetical, case insensitive,
   ignoring punctuation (such as underscores).  */



@BOTTOM@


#endif /* already included */

/*
vi:ts=4
*/
