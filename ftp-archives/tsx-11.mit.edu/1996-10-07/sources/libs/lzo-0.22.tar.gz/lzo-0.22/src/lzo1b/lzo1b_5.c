#define COMPRESS_ID		5

#define DDBITS			1
#define CLEVEL			3
#include "compr.h"

