/*
 * unlink.c
 *
 * Copyright (C) 1993 Alain Knaff
 */
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <string.h>
#include <syscall.h>
#include "zlibc.h"

int unlink(__const char *file_name)
{
  int st;
  struct stat buf;
  char newname[MAXPATHLEN + MAXEXTLEN + 1];


  st = syscall(SYS_unlink,file_name);

  if ( st >= 0 || errno != ENOENT )
    return st;

  zlib_initialise();
  if ( zlib_mode & CM_DISAB )
    return st;
  if ( (zlib_getfiletype(file_name,-1) & PM_READ_MASK) == PM_LEAVE_COMPR)
    return st;
  
  if ( zlib_mode & CM_VERBOSE )
    fprintf(stderr,"Unlinking %s\n",file_name);
  
  strncpy(newname,file_name,1024);
  strcat(newname,zlib_ext);

  st=0;
  if ( zlib_mode & CM_UNLINK)
    st= syscall(SYS_unlink,newname);
  else
    st = ___zlibc_lstat(newname, &buf);
  if ( st < 0 ){
    errno = ENOENT;
    return st;
  }

  /* the file exists with z extension, ignore error */
  return 0;
}
