/*
 * stat.c
 *
 * Copyright (C) 1993 Alain Knaff
 */
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <string.h>
#include "zlibc.h"
#include <syscall.h>

int ___zlibc_lstat(const char *file_name, struct stat *buf)
{
#ifdef __ELF__
	return syscall(SYS_prev_lstat,file_name, buf );
#else
	return syscall(SYS_lstat,file_name, buf );
#endif
}


int ___zlibc_stat(const char *file_name, struct stat *buf)
{
#ifdef __ELF__
	return syscall(SYS_prev_stat,file_name, buf );
#else
	return syscall(SYS_stat,file_name, buf );
#endif
}

static int zstat(__const char *name, char *newname, struct stat *buf)
{
  int fd,st,ft;
  unsigned char size_buffer[4];

  if( (zlib_getfiletype(name,-1) & PM_READ_MASK) == PM_LEAVE_COMPR ){
    errno = ENOENT ;
    return -1;
  }

  fd=syscall(SYS_open,newname, O_RDONLY | O_NDELAY);
  if ( fd < 0 ){
    if ( errno == ENOENT )
      return -1;
    return 2;
  } else {  
    st = fstat(fd,buf);    
    if ( st < 0 ){
      close(fd);
      return st;
    }	

    if ( ! S_ISREG ( buf->st_mode ))
      /* not a regular file. Don't waste time determining its size */
      return st;

    lseek(fd, -4 , SEEK_END);
    read(fd, size_buffer, 4 );

    buf->st_size = size_buffer[0] + ( size_buffer[1] << 8 ) + 
                  (size_buffer[2] << 16 ) + (size_buffer[3] << 24 );
    close(fd);
    
    ft = zlib_getfiletype(name,-1);
    if ((ft & PM_READ_MASK) == PM_SHOW_PIPE)
      buf->st_mode ^= S_IFIFO | S_IFREG;

    if (!(ft & (PM_CREATE_COMPR | PM_APPEND_COMPR | PM_UNCOMPR_BEFORE_WRITE)))
      buf->st_mode &= ~0222;

#ifdef NEGATE_INODES
    buf->st_ino= -buf->st_ino;
#endif
  }
  return 0;
}

static int zlibc_stat(__const char *file_name, struct stat *buf)
{
  int st, olderrno;

  errno = 0;

  st = ___zlibc_stat(file_name, buf );


  if ( st >= 0 || errno != ENOENT )
    return st;

  {
    char newname[MAXPATHLEN + MAXEXTLEN + 1];
    olderrno = errno;
    zlib_initialise();
    errno = olderrno;

    if ( zlib_mode & CM_DISAB )
      return st;

    if ( zlib_mode & CM_VERBOSE )
      fprintf(stderr,"stating %s\n", file_name);

    strncpy(newname,file_name,MAXPATHLEN);
    strcat(newname,zlib_ext);

    st = zstat(file_name,newname, buf);

    if ( zlib_mode & CM_VERBOSE )
      fprintf(stderr,"stated %s, rv=%d\n", file_name, st);

    if ( st == 2 ){
      st = stat(newname, buf);
      buf->st_size = 0;
    }

    if ( st < 0 ){
      errno = ENOENT;
      return st;
    }

  }
  return st;
}

static int zlibc_lstat(__const char *file_name, struct stat *buf)
{
  int st;

  st = ___zlibc_lstat(file_name, buf);

  if ( st >= 0 || errno != ENOENT )
    return st;

  {
    char newname[MAXPATHLEN + MAXEXTLEN + 1];

    zlib_initialise();
    if ( zlib_mode & CM_DISAB )
      return st;
    if ( zlib_mode & CM_VERBOSE )
      fprintf(stderr,"lstating %s\n", file_name);

    strncpy(newname,file_name,MAXPATHLEN);
    strcat(newname,zlib_ext);

    st = ___zlibc_lstat(newname, buf);

    if ( st < 0 ){
      errno = ENOENT;
      return st;
    }

    if ( S_ISLNK(buf->st_mode) ){
      if ( buf->st_size > zlib_extlen )
	buf->st_size -= zlib_extlen;
      return st;
    }
     
    st = zstat(file_name,newname,buf);
    if ( st == 2 )
      /* could not zstat it, keep first info */
      st=0;
  }

  return st;
}

#ifdef __ELF__

struct stat0 {
	unsigned short st_dev;
	unsigned short st_ino;
	unsigned short st_mode;
	unsigned short st_nlink;
	unsigned short st_uid;
	unsigned short st_gid;
	unsigned short st_rdev;
	unsigned long  st_size;
	unsigned long  st_atime;
	unsigned long  st_mtime;
	unsigned long  st_ctime;
};



struct stat1 {
	unsigned short 	st_dev;
	unsigned short	__pad1;
	unsigned long  	st_ino;
	unsigned short 	st_mode;
	unsigned short 	st_nlink;
	unsigned short 	st_uid;
	unsigned short 	st_gid;
	unsigned short 	st_rdev;
	unsigned short	__pad2;
	long		st_size;
	unsigned long	st_blksize;
	unsigned long	st_blocks;
	long		st_atime;
	unsigned long	__unused1;
	long		st_mtime;
	unsigned long	__unused2;
	long		st_ctime;
	unsigned long	__unused3;
	unsigned long	__unused4;
	unsigned long	__unused5;
};


static void translate(int ver, struct stat *kernel, struct stat *app0)
{
	switch(ver){
	case 0:
#define STATSTRUCT stat0
#include "translation.h"

	case 1:
#define STATSTRUCT stat1
#include "translation.h"

	default:
		fprintf(stderr,"Stat type %d not yet supported\n", ver);
		fprintf(stderr,
			"Please define this stat type in your zlibc/stat.c\n");
		_exit(1);
	}
}

int _xstat(int ver, __const char *name, struct stat *buf)
{
	struct stat buf0;
	int ret;

	if ( ver == LINUX_STAT_VERSION){
		return zlibc_stat(name, buf);
	} else {
		ret = zlibc_stat(name, &buf0);
		translate(ver,&buf0, buf);
		return ret;
	}
}

int _lxstat(int ver, __const char *name, struct stat *buf)
{
	struct stat buf0;
	int ret;

	if ( ver == LINUX_STAT_VERSION){
		return zlibc_lstat(name, (struct stat *)buf);
	} else {
		ret = zlibc_lstat(name, &buf0);
		translate(ver,&buf0, buf);
		return ret;
	}
}

#if 0
int stat(__const char *name, struct stat *buf)
{
	return _xstat(1, name, buf);
}

int __stat(__const char *name, struct stat *buf)
{
	return _xstat(1, name, buf);
}

int lstat(__const char *name, struct stat *buf)
{
	return _lxstat(1, name, buf);
}
#endif


#else

#ifdef linux
int __stat(__const char *name, struct stat *buf)
#else
int stat(__const char *name, struct stat *buf)
#endif
{
	return zlibc_stat(name, buf);
}

int lstat(__const char *name, struct stat *buf)
{
	return zlibc_lstat(name, buf);
}


#endif
