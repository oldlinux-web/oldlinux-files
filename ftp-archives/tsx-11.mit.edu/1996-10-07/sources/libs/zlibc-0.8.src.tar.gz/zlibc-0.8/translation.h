{
	struct STATSTRUCT *app = (struct STATSTRUCT *) app0;

	memset(app, 0, sizeof(*app));
	app->st_dev = kernel->st_dev;
	app->st_ino = kernel->st_ino;
	app->st_mode = kernel->st_mode;
	app->st_nlink = kernel->st_nlink;
	app->st_uid = kernel->st_uid;
	app->st_gid = kernel->st_gid;
	app->st_rdev = kernel->st_rdev;
	app->st_size = kernel->st_size;
#ifdef BLKSIZE
	app->st_blksize = kernel->st_blksize;
	app->st_blocks = kernel->st_blocks;
#endif
	app->st_atime = kernel->st_atime;
	app->st_mtime = kernel->st_mtime;
	app->st_ctime = kernel->st_ctime;
}
break;
#undef BLKSIZE
#undef STATSTRUCT
