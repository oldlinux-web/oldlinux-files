/*
 * setaddress.c
 *
 * Copyright (C) 1993 Alain Knaff
 */
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

void main(int argc, char **argv)
{
  int fd;
  int target;
  int contents;
  int skip;

  if ( argc != 4 && argc != 5 ){
    fprintf(stderr,"Bad argument count\n");
    fprintf(stderr,"Usage: %s library-file target [contents]\n",argv[0]);
    exit(1);
  }

  if ( argc == 5 )
    skip = strtoul(argv[4],0,0);
  else
    skip = 0x400;

  fd= open( argv[1], O_WRONLY);

  if ( fd < 0 ){
    perror(argv[1]);
    exit(1);
  }

  target = strtoul( argv[2],0,0);
  
  if( lseek( fd, target + 1 + skip - 0x60000000 , SEEK_SET ) < 0 ){
    perror("seek");
    exit(1);
  }

  contents = strtoul(argv[3],0,0 ) - 5 - target;
  write(fd, &contents , 4 );
  exit(0);
}



  

  
