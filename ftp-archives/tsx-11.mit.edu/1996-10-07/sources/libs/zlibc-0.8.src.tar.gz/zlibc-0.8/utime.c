/*
 * utime.c
 *
 * Copyright (C) 1993 Alain Knaff
 */
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <string.h>
#include <syscall.h>
#include <utime.h>
#include <sys/time.h>
#include "zlibc.h"

#ifdef linux
#define TIME_CALL(x,y) syscall(SYS_utime, (x), (y))
#endif

#ifdef sun
#define TIME_CALL(x,y) syscall(SYS_utimes, (x), (y))
#endif


#ifdef linux
int utime(__const char *file_name, struct utimbuf *buf)
#else
int utimes(__const char *file_name, struct timeval *buf)
#endif
{
  int st;
  char newname[MAXPATHLEN + MAXEXTLEN + 1];

  st=TIME_CALL(file_name, buf);

  if ( st >= 0 || errno != ENOENT )
    return st;

  zlib_initialise();
  if ( zlib_mode & CM_DISAB )
    return st;
  if ( (zlib_getfiletype(file_name,-1) & PM_READ_MASK) == PM_LEAVE_COMPR)
    return st;
  
  if ( zlib_mode & CM_VERBOSE )
    fprintf(stderr,"Utiming %s\n",file_name);
  
  strncpy(newname,file_name,1024);
  strcat(newname,zlib_ext);
  
  errno = 0;
  st=TIME_CALL(newname, buf);
  if ( st < 0 && errno == EINVAL )
    errno = ENOENT;
  return st;
}

