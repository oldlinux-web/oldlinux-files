/*
 * chmod.c
 *
 * Copyright (C) 1993 Alain Knaff
 */
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <string.h>
#include "zlibc.h"
#include <syscall.h>

int chmod(__const char *file_name, mode_t mode)
{
  int st;
  char newname[MAXPATHLEN + MAXEXTLEN + 1];

  st = syscall(SYS_chmod,file_name, mode);

  if ( st >= 0 || errno != ENOENT )
    return st;


  zlib_initialise();
  if ( zlib_mode & CM_DISAB )
    return st;
  if ( (zlib_getfiletype(file_name,-1) & PM_READ_MASK) == PM_LEAVE_COMPR)
    return st;
  
  if ( zlib_mode & CM_VERBOSE )
    fprintf(stderr,"Chowning %s\n",file_name);
  
  strncpy(newname,file_name,1024);
  strcat(newname,zlib_ext);
  
  errno = 0;
  return syscall(SYS_chmod,newname, mode);
}
