/*
 * inject.c
 *
 * Copyright (C) 1993 Alain Knaff
 */
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#define BUFSIZE 1024


void main(int argc, char **argv)
{
  int fd;
  int length;
  char buffer[BUFSIZE];
  char zeropage[BUFSIZE];
  int have_skipped;
  int current_offset;


  if ( argc < 3 ){
    fprintf(stderr,"Too few arguments\n");
    fprintf(stderr,"%s file offset\n",argv[0]);
    exit(1);
  }

  fd=open(argv[1],O_RDWR );
  if ( fd < 0 ){
    perror(argv[1]);
    exit(1);
  }


  current_offset = strtoul(argv[2],0,0);
  if ( argc >= 4 )
    current_offset += strtoul(argv[3],0,0);
  have_skipped = 1;

  bzero( zeropage, BUFSIZE );

  while(1){
    if(have_skipped && lseek(fd,current_offset, SEEK_SET) < 0 ){
      perror("seek");
      exit(1);
    }
    have_skipped = 0;

    length = read( 0, buffer, BUFSIZE);
    if ( !length)
      exit(0);
    if ( length < 0 ){
      perror("read");
      exit(1);
    }
    current_offset += length ;

    if ( memcmp( zeropage, buffer, 4096 ) ){
      if(write(fd,buffer,length) < length ){
	perror("write");
	exit(1);
      } else
	have_skipped = 1;
    }
  }
}



