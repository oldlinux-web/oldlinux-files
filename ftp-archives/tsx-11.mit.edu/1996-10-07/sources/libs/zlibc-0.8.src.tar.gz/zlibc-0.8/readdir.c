#ifdef linux
#define DIRENT_ILLEGAL_ACCESS /* for dirent */
#endif
/*
 * readdir.c
 *
 * Copyright (C) 1993 Alain Knaff
 */
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/dirent.h>
#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/param.h>
#include <string.h>
#include "zlibc.h"
#include <syscall.h>

#ifdef linux
#ifndef d_namlen
#define	d_namlen	d_reclen	/* glibc compatibility.  */
#endif

struct dirent *readdir(DIR *dirp)
{
  struct dirent *ptr;
  char *extension;

  int result;
  int count = 1;

  if (!dirp) {
    errno = EBADF;
    return NULL; 
  }

  if (dirp->dd_size <= dirp->dd_loc) {
    /* read count of directory entries. For now it should be one. */
    result = syscall(SYS_readdir, dirp->dd_fd, dirp->dd_buf, count);
    if (result <= 0){
      errno=0;
      return NULL;
    }
    /*
     * Right now the readdir system call return the number of
     * characters in the name - in the future it will probably return
     * the number of entries gotten. No matter - right now we just
     * check for positive:
     */
#if 0
    dirp->dd_size = result;
#else
    dirp->dd_size = 1;
#endif

    dirp->dd_loc = 0;
  }


#else
/* SunOS */

struct dirent *readdir(DIR *dirp)
{
  struct dirent *ptr;
  char *extension;

  if (!dirp) {
    errno = EBADF;
    return NULL; 
  }

  if ( dirp->dd_size){
    ptr = (struct dirent *) ( dirp->dd_buf + dirp->dd_loc);
    dirp->dd_loc += ptr->d_reclen;
  }
    
  if ( dirp->dd_size <= dirp->dd_loc ){
    dirp->dd_size=getdents( dirp->dd_fd, dirp->dd_buf, dirp->dd_bsize);
    if ( dirp->dd_size == 0 )
      return 0;
    dirp->dd_loc = 0;
  }
#endif

  ptr = (struct dirent *) ( dirp->dd_buf + dirp->dd_loc);
#ifdef linux
  dirp->dd_loc++; /* is this correct ? */
#else
  dirp->dd_off = ptr->d_off;
#endif

  zlib_initialise();
  if ( zlib_mode & CM_VERBOSE )
	  fprintf(stderr,"readdir %s\n", ptr->d_name);
  /* substitute .z by nothing */
  if (!( zlib_mode & ( CM_DISAB | CM_READDIR_COMPR )) && 
      ptr->d_namlen > zlib_extlen){
    /* we ask for name-length stricly bigger than extlen, in order to
     * avoid empty file names :-) */
    extension = (ptr->d_name + 
                 ptr->d_namlen -
                 zlib_extlen);
    if ( strncmp(extension, zlib_ext, zlib_extlen) == 0 ){
      *extension='\0';
      if ( (zlib_getfiletype(ptr->d_name,dirp->dd_fd) & PM_READ_MASK) <
	  PM_DIR_LEAVE_COMPR)
        ptr->d_namlen -= zlib_extlen;
      else
        /* put back into place, if we "hide" these files */
        *extension=*zlib_ext;
    }
  }

  return ptr;
}
