/*
 * set_datastart.c
 *
 * Copyright (C) 1993 Alain Knaff
 */
#include <a.out.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>

void usage(char *progname)
{
  fprintf(stderr,"Usage: %s executable [bss_end]\n", progname);
  exit(1);
}


void main(int argc, char **argv )
{
  struct exec buf;
  unsigned int data_start, bss_start, bss_end;
  int fd;
  char *end;
  unsigned int newdata=0;

  if ( argc < 2 || argc > 3 )
    usage(argv[0]);

  if ( argc == 3 ){
    if ( argv[2][0] == '\0' )
      usage(argv[0]);
    
    newdata = strtoul( argv[2], & end, 0 );
    if ( *end )
      usage(argv[0]);
  }

  fd = open( argv[1], argc == 3 ? O_RDWR : O_RDONLY );
  if ( fd < 0 ){
    perror("open");
    exit(1);
  }

  if ( read(fd, & buf, sizeof(struct exec)) < sizeof(struct exec) ){
    perror("read");
    exit(1);
  }

  data_start = buf.a_entry + buf.a_text;
  bss_start  = data_start + buf.a_data ;
  bss_end    = bss_start + buf.a_bss;

  if ( argc == 2 ){
    printf("0x%x\n", data_start );
  }else{
    if ( lseek( fd, 0, SEEK_SET)  ){
      perror("lseek");
      exit(1);
    }
    
    buf.a_text = newdata - buf.a_entry;
    buf.a_data = bss_start - newdata;

    if ( write(fd, &buf, sizeof(struct exec)) < sizeof(struct exec) ) {
      perror("write");
      exit(1);
    }
  }

  exit(0);
}



