/*
 * smv.c
 *
 * Copyright (C) 1993 Alain Knaff
 */
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <errno.h>
#include <stdio.h>

/*
 * statically linked mv, ln and symlink replacement.
 * Should be used when the libraries get hosed
 */
int rename(__const char *a, __const char *b);

struct commands {
  char *name;
  int (*command)( __const char* old, __const char *new);
} table[] = {
  { "mv", rename },
  { "move", rename },
  { "rename", rename },
  { "sln", symlink },
  { "symlink", symlink },
  { "ln", link },
  { "link", link },
  { 0, 0} };

char str1[]="Usage: ";
char str2[]=" [command] old-name new-name\n";

static void stringprint(char *s)
{
  write(2, s, strlen(s));
}

static void usage(char *prog)
{
  stringprint(str1);
  stringprint(prog);
  stringprint(str2);
  exit(1);
}

static void myperror(char *prog)
{
  stringprint(prog);
  stringprint(": ");
  if(errno > sys_nerr || errno < 1 )
    errno = 0;
  stringprint(sys_errlist[errno]);
  exit(1);
}

void main(int argc, char **argv)
{
  char *command,*old,*new,*prog,*tmp;
  struct commands *ptr;

  prog = argv[0];
  tmp=strrchr(argv[0],'/');
  if(tmp)
    prog=tmp+1;
  switch(argc){
  case 3:
    command = prog+1;
    break;
  case 4:
    command = argv[1];
    argv++;
    break;
  default:
    usage(prog);
    return;
  }

  old = argv[1];
  new = argv[2];
  for(ptr = table; ptr->name; ptr++)
    if ( !strcmp(ptr->name, command))
      break;
  if ( !ptr->name )
    usage(prog);
  
  if(ptr->command(old, new) >= 0)
    exit(0);

  if (errno != EEXIST )
    myperror(command);

  unlink(new);
  if(ptr->command(old, new) < 0)
    myperror(command);

  exit(0);
}

