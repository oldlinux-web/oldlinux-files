exec tput clear
