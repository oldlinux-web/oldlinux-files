#include <vga.h>


main()
{
    vga_dumpregs();
    vga_setmode(TEXT);
}
