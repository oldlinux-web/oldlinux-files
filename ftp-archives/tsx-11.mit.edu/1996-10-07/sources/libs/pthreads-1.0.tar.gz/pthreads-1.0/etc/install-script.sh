#!/bin/bash
# $Id: install-script.sh,v 1.3 1996/07/01 01:04:10 mtp Exp $
############################################################################
#    
#  COPYRIGHT NOTICE
#    
#  Copyright (C) 1995, 1996 Michael T. Peterson
#  This file is part of the PCthreads (tm) multithreading library
#  package.
#    
#  The source files and libraries constituting the PCthreads (tm) package
#  are free software; you can redistribute them and/or modify them under
#  the terms of the GNU Library General Public License as published by the Free
#  Software Foundation; either version 2 of the License, or (at your
#  option) any later version.
#    
#  The PCthreads (tm) package is distributed in the hope that it will
#  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Library General Public License for more details.
#    
#  You should have received a copy of the GNU Library General Public
#  License along with this library (see the file COPYING.LIB); if not,
#  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
#  MA 02139, USA.
#    
#  To report bugs, bug fixes, or provide feedback you may contact the
#  author, Michael T. Peterson, at either of the two email addresses listed
#  below:
#    
#             mtp@big.aa.net (preferred)
#             mtp@zso.dec.com
#    
#    
#  Michael T. Peterson
#  Redmond, WA.
#  13 January, 1996
############################################################################
# $Log: install-script.sh,v $
# Revision 1.3  1996/07/01 01:04:10  mtp
# + Changed LIBDIDR to LIBDIR.
#
# Revision 1.2  1996/06/29 15:38:56  mtp
# + Added COPYRIGHT NOTICE to file header.
#
# Revision 1.1  1996/06/29 15:30:54  mtp
# + Initial submission
#
############################################################################
WHOAMI=root
VERSION=1.0.0
LIBDIR=/usr/lib
INCDIR=/usr/include

if [ `whoami` != "$WHOAMI" ]
then
   echo ""
   echo "  Sorry, you must have root privileges to execute this script"
   echo ""
   exit 1
fi

echo "+ Installing libpthread.a, libpthread.so."$VERSION", pthread.h, and typedefs.h"

rm -f $INCDIR/pthread.h $INCDIR/typedefs.h $LIBDIR/libpthread.so.$VERSION $LIBDIR/libpthread.so.1 $LIBDIR/libpthread.a

cp -f ../include/*.h $INCDIR
cp -f ../lib/libpth* $LIBDIR

if [ -f $LIBDIR/libpthread.so.$VERSION ]
then
    ln -s $LIBDIR/libpthread.so.$VERSION $LIBDIR/libpthread.so.1
    /sbin/ldconfig $LIBDIR
fi

echo "+ Installing PCthread man pages into "$DEST_MANDIR.""
DEST_MANDIR=/usr/local/man/man3
SRC_MANDIR=../man
if [ ! -d $DEST_MANDIR ]
then
    echo    "  "$DEST_MANDIR" does not exist. Please create and rerun installation."
    echo    ""
    echo    "  Installation of man pages has been aborted!"
    exit 1
fi

# This block of commands copies the manpages into the destination directory
# and then sets the appropriate symbolic links.
rm -f $DEST_MANDIR/sigwait.3.gz
rm -f $DEST_MANDIR/pthread_*.3.gz

cp -f $SRC_MANDIR/pthread_*.3.gz $DEST_MANDIR

ln -s $DEST_MANDIR/pthread_mutex_lock.3.gz $DEST_MANDIR/pthread_mutex_unlock.3.gz
ln -s $DEST_MANDIR/pthread_mutex_init.3.gz $DEST_MANDIR/pthread_mutex_destroy.3.gz
ln -s $DEST_MANDIR/pthread_lock_global_np.3.gz $DEST_MANDIR/pthread_unlock_global_np.3.gz
ln -s $DEST_MANDIR/pthread_attr_init.3.gz $DEST_MANDIR/pthread_attr_destroy.3.gz
ln -s $DEST_MANDIR/pthread_mutexattr_init.3.gz $DEST_MANDIR/pthread_mutexattr_destroy.3.gz
ln -s $DEST_MANDIR/pthread_condattr_init.3.gz $DEST_MANDIR/pthread_condattr_destroy.3.gz
ln -s $DEST_MANDIR/pthread_cond_init.3.gz $DEST_MANDIR/pthread_cond_destroy.3.gz
ln -s $DEST_MANDIR/pthread_cond_signal.3.gz $DEST_MANDIR/pthread_cond_broadcast.3.gz
ln -s $DEST_MANDIR/pthread_key_create.3.gz $DEST_MANDIR/pthread_key_delete.3.gz
ln -s $DEST_MANDIR/pthread_key_getspecific.3.gz $DEST_MANDIR/pthread_setspecific.3.gz
ln -s $DEST_MANDIR/pthread_sigwait.3.gz $DEST_MANDIR/sigwait.3.gz
ln -s $DEST_MANDIR/pthread_setcancelstate.3.gz $DEST_MANDIR/pthread_setcanceltype.3.gz

echo ""
echo "  Installation of man pages is complete.  Try the following"
echo "  command to see that the man pages are setup correctly."
echo ""
echo "      prompt> man pthread_info"
echo ""
exit 0
