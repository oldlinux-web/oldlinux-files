/*
 * $Id: config.h,v 1.1.1.1 1996/06/29 01:20:51 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: config.h,v $
 * Revision 1.1.1.1  1996/06/29 01:20:51  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:00  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:41  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:28  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#ifndef _config_
#define _config_
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <private.h>

typedef struct PTHREAD_CONFIG
{
   long    timer_interval;         /* Default is 20,000 microseconds */
   long    timer_idle_interval;    /* Default is 20,000 microseconds */
   int     default_quantum;        /* Default is 2 timer_intervals */
   int     default_sched_policy;   /* Default is round robin */
   int     default_thread_prio;    /* Default is 16 */
   size_t  default_stack_size;     /* Default is 8192 */

} config_t;

extern void
init_config( config_t *config );

#endif
