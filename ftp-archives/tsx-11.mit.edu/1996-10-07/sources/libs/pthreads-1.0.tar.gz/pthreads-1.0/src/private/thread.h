/*
 * $Id: thread.h,v 1.1.1.1 1996/06/29 01:20:53 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: thread.h,v $
 * Revision 1.1.1.1  1996/06/29 01:20:53  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:07  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:47  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:35  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:41:59  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#ifndef _thread_
#define _thread_

#include "pthread.h"
#include <setjmp.h>
#include "private.h"
#include "pools.h"
#include "stack.h"
#include "thread_attr.h"
#include "cleanup.h"

typedef enum VALID_CONTEXT
{
   CTX_C_TIMER,
   CTX_C_STACK
} valid_context_t;

#define FPU_CONTEXT_SIZE   108

typedef unsigned char fpu_context_t[FPU_CONTEXT_SIZE];

typedef struct THREAD_OBJECT
{
   stack_t *               stack;          /* Must be first member */
   jmp_buf                 saved_context;
   long                    guard1;
   fpu_context_t           fpu_context;
   long                    guard2;
   valid_context_t         valid_context;
   thread_state_t          thread_state;
   struct sched_param      sched_param;
   thread_attr_obj_t       attr_obj;
   void                    *exit_value;
   mutex_pool_t            locked_mutexes;
   int                     new_thread;

   /*
    *  --  This member is a list of cleanup handlers used by
    *      pthread_cleanup_push() and pthread_cleanup_pop().
    */
   handler_stack_t         cleanup_stack;

   /*
    *  --  These members are used to implement per-thread signal semantics.
    */
   sigset_t                current_sigs;
   sigset_t                pending_sigs;

   /*
    *  --  Thread-private storage for pointers to client-specified storage.
    */
   any_t                   key[PTHREAD_C_MAX_DATAKEYS];

   /*
    *  --  These members are used to implement the join/detached operations.
    */
   detached_state_t        detached_state;
   counter_t               join_count;
   pthread_mutex_t         join_mutex;
   pthread_cond_t          join_condv;

   /*
    *  --  If thread is blocked at a mutex or waiting to be signaled at a
    *      condition variable, the next two members point to the mutex or
    *      condition variable at which the thread is currently stalled.
    */
   pthread_mutex_t         *mu_blocked_at;
   pthread_cond_t          *cv_waiting_at;

   int                     saved_prio;
   int                     cancel_pending;
   int                     cancel_state;
   int                     cancel_type;
   int                     errno;
   counter_t               total_ctxsw_count;
   counter_t               async_preemptions;
   counter_t               start_time;   /* Nub microseconds when created */

} thread_obj_t;

struct PTHREAD_HANDLE
{
   struct PTHREAD_HANDLE   *prev_th;
   struct PTHREAD_HANDLE   *next_th;
   struct PTHREAD_HANDLE   *next_in_pool;

   counter_t       id;
   thread_obj_t    obj;
   object_type_t   type;
};

extern counter_t
init_th_obj( thread_obj_t *th, 
             thread_attr_obj_t *th_attr_obj,
             void * (*th_proc)(void *),
             void *th_arg );

extern void
destroy_th_obj( thread_obj_t *obj );

extern void
sys_save_fpu_context( thread_obj_t *th );

extern void
sys_restore_fpu_context( thread_obj_t *th );

#endif
