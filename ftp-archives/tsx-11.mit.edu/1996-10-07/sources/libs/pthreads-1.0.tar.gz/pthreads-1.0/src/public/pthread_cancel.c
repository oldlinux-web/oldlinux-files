#ifndef lint
static const char rcsid[] = "$Id: pthread_cancel.c,v 1.1.1.1 1996/06/29 01:20:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: pthread_cancel.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:53  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:13  mtp
 * + Release 2.0
 *
 * Revision 1.4  1996/01/14 20:22:55  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.3  1996/01/14 18:32:44  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.2  1995/12/31 06:23:53  mtp
 * + Major overhaul.  Put asynchronous cancellation into the nub.c module.  Now,
 *   an asynchronously cancelled thread will remove itself when it is interrupted
 *   or acquires the processor.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include "public.h"
#include "error.h"
#include "thread.h"
#include "nub.h"

extern void thread_exit_proc( void );

int  
pthread_cancel( pthread_t handle )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   /*
    *  Ensure that the handle referencing the thread to be canceled is valid.
    */
   sys_disable_ctxsw( flag );
   if( handle == NULL || handle->type != THREAD_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   handle->obj.cancel_pending = TRUE;
   RETURN( SUCCESS );
}

void  
pthread_testcancel( void )
{
   struct PTHREAD_HANDLE *active_th;
   int cancel_state, cancel_pending, flag;

   (void) system_init();

   sys_disable_ctxsw( flag );
   active_th = nub_get_active_thread();

   cancel_state = active_th->obj.cancel_state;
   cancel_pending = active_th->obj.cancel_pending;

   if( cancel_state  == PTHREAD_CANCEL_ENABLE && cancel_pending  == TRUE )
       pthread_exit( (void *) PTHREAD_CANCELED );

   VRETURN;
}

int  
pthread_setcancelstate( int new_state, int *prev_state )
{
   struct PTHREAD_HANDLE *handle;
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   if( new_state != PTHREAD_CANCEL_ENABLE &&
       new_state != PTHREAD_CANCEL_DISABLE )
       return( EINVAL );

   sys_disable_ctxsw( flag );
   handle = nub_get_active_thread();
   *prev_state = handle->obj.cancel_state;
   handle->obj.cancel_state = new_state;

   RETURN( SUCCESS );
}

int 
pthread_setcanceltype( int new_type, int *old_type )
{
   struct PTHREAD_HANDLE *handle;
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   if( new_type != PTHREAD_CANCEL_ASYNCHRONOUS &&
       new_type != PTHREAD_CANCEL_DEFERRED )
       return( EINVAL );

   sys_disable_ctxsw( flag );
   handle = nub_get_active_thread();
   *old_type = handle->obj.cancel_type;
   handle->obj.cancel_type = new_type;

   RETURN( SUCCESS );
}
