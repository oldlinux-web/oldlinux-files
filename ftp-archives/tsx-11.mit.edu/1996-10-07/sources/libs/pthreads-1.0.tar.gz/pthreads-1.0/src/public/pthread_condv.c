#ifndef lint
static const char rcsid[] = "$Id: pthread_condv.c,v 1.1.1.1 1996/06/29 01:20:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: pthread_condv.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:53  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:14  mtp
 * + Release 2.0
 *
 * Revision 1.4  1996/01/14 20:22:55  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.3  1996/01/14 18:32:45  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.2  1995/12/31 06:25:37  mtp
 * + Consolidated and cleaned up the cancellation code.  Logic didn't change
 *   however.  It's just much easier to follow.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include "pthread.h"
#include "thread.h"
#include "mutex.h"
#include "condv.h"
#include "nub.h"
#include "error.h"
#include "public.h"

extern condv_attr_obj_t
*get_default_cv_attr_obj( void );

extern int
unlock_mutex_struct( struct PTHREAD_MUTEX_HANDLE *mu_h,
                     struct PTHREAD_HANDLE *active_th );


int  
pthread_cond_init( pthread_cond_t  *handle, pthread_condattr_t  *cv_attr_h )
{
   struct PTHREAD_CONDV_HANDLE *cv_h;
   condv_attr_obj_t *cv_attr_obj;
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   if( cv_attr_h == NULL )
       cv_attr_obj = get_default_cv_attr_obj();
   else
   {
       if( (*cv_attr_h)->type != CONDV_ATTR_C )
       {
           set_thread_errno( EINVAL );
           RETURN( EINVAL );
       }
       cv_attr_obj = (*cv_attr_h)->obj;
   }


   if( (cv_h = allocate_handle( CONDV_C )) == NULL )
   {
       set_thread_errno( ENOMEM );
       RETURN( ENOMEM );
   }

   cv_h->id = init_cv_obj( &cv_h->obj, cv_attr_obj );
   cv_h->type = CONDV_C;

   *handle = cv_h;
   RETURN( SUCCESS );
}

int  
pthread_cond_destroy( pthread_cond_t  *handle )
{
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != CONDV_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   if( (*handle)->obj.waiting_threads.elements > 0 )
   {
       set_thread_errno( EBUSY );
       RETURN( EBUSY );
   }

   destroy_cv_obj( &(*handle)->obj );
   free_handle( *handle );
   handle = NULL;

   RETURN( SUCCESS );
}

int  
pthread_cond_wait( pthread_cond_t  *cv_h,  pthread_mutex_t *mu_h )
{
   struct PTHREAD_HANDLE *active_th;
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );

   /*
    * Check whether the two handles are valid.
    */
   if( cv_h == NULL || (*cv_h)->type != CONDV_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   if( mu_h == NULL || (*mu_h)->type != MUTEX_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   /*
    * First, we need to unlock the mutex without calling 
    * pthread_mutex_unlock().  Otherwise, we'll just get put on the 
    * ready queue and since we're already on the condition variable's 
    * ready queue we'll end up clobbering the relevant list pointers.
    */
   active_th = nub_get_active_thread();
   if( (st = unlock_mutex_struct( *mu_h, active_th )) != SUCCESS )
       RETURN( st );

   /*
    * pthread_cond_wait() is a cancellation point.  If the calling thread
    * has received a cancel and cancels are enabled, then goodby.
    */
   if( active_th->obj.cancel_pending && 
       active_th->obj.cancel_state == PTHREAD_CANCEL_ENABLE )
   {
       pthread_exit( (void *) PTHREAD_CANCELED );
   }

   /*
    * Having unlocked the mutex, we now insert the thread into the
    * cv's queue of waiting threads and issue a reschedule request.
    */
   active_th->obj.thread_state = THREAD_WAITING_C;
   active_th->obj.cv_waiting_at = cv_h;
   enqueue_thread( &(*cv_h)->obj.waiting_threads, active_th );
   nub_reschedule( active_th );

   /*
    * Now, the active thread checks that it hasn't been cancelled while
    * it was waiting and, if not, relocks the mutex, this time using 
    * pthread_mutex_lock().
    */
   active_th->obj.cv_waiting_at = NULL;
   if( active_th->obj.cancel_pending && 
       active_th->obj.cancel_state == PTHREAD_CANCEL_ENABLE )
   {
       pthread_exit( (void *) PTHREAD_CANCELED );
   }

   sys_restore_ctxsw( flag );
   return( pthread_mutex_lock( mu_h ) );
}

int  
pthread_cond_signal( pthread_cond_t  *handle )
{
   struct PTHREAD_HANDLE *waiting_th;
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != CONDV_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   /*
    *  --  The basic strategy is to remove the highest priority thread
    *      from the condition variable's queue of waiting threads, insert 
    *      it into the ready queue.
    */
   waiting_th = dequeue_thread( &(*handle)->obj.waiting_threads );
   if( waiting_th != NULL )
   {
       /*
        *  --  Enqueue the thread on the ready queue and, if a context
        *      switch is required, execute one.
        */
       waiting_th->obj.thread_state = THREAD_READY_C;
       enqueue_thread( &thread_rq, waiting_th );
       LOG(waiting_th, "waiting->ready");

       if( nub_get_active_prio() < get_highest_prio( &thread_rq ) )
       {
           struct PTHREAD_HANDLE *active_th;
           active_th = nub_get_active_thread();
           active_th->obj.thread_state = THREAD_READY_C;
           nub_reschedule( active_th );
       }
   }

   RETURN( SUCCESS );
}

int
pthread_cond_broadcast( pthread_cond_t *handle )
{
   struct PTHREAD_HANDLE *waiting_th;
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != CONDV_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   /*
    *  --  The basic strategy is to remove ALL of the threads from the
    *      condition variable's queue of waiting threads, inserting each
    *      into the ready queue.  Then, if a context switch is necessary,
    *      call nub_reschedule().
    */
   waiting_th = dequeue_thread( &(*handle)->obj.waiting_threads );
   while( waiting_th )
   {
       /*
        *  --  Enqueue the waiting thread to the ready queue.
        */
       waiting_th->obj.thread_state = THREAD_READY_C;
       enqueue_thread( &thread_rq, waiting_th );
       LOG( waiting_th, "waiting->ready");

       /*
        *  --  Get the next thread from the ready queue (returns NULL if
        *      no more threads exist.
        */
       waiting_th = dequeue_thread( &(*handle)->obj.waiting_threads );
   }

   if( nub_get_active_prio() < get_highest_prio( &thread_rq ) )
   {
       struct PTHREAD_HANDLE *active_th;
       active_th = nub_get_active_thread();
       active_th->obj.thread_state = THREAD_READY_C;
       nub_reschedule( active_th );
   }

   RETURN( SUCCESS );
}

/*
 * The next section of this module declares and defines the variables
 * and functions necessary to implement pthread_cond_timedwait().
 */
static pthread_attr_t attr;
struct sched_param param = { SCHED_FCFS_C, PTHREAD_MAX_PRIO_C, 1 };

static void
abs2rel( struct timespec *rel, const struct timespec abs )
{
	counter_t abs_nsec, rel_nsec;

	abs_nsec = abs.tv_sec * NSEC_PER_SECOND + abs.tv_nsec;
	rel_nsec = abs_nsec - (nub_get_elapsed_usecs() * 1000);

	rel->tv_sec = rel_nsec / NSEC_PER_SECOND;
	rel->tv_nsec = rel_nsec % NSEC_PER_SECOND;
}

struct arg_block
{
	pthread_cond_t        *cv_h;
	struct PTHREAD_HANDLE *wait_th;
	struct timespec       *abstime;
};

static void
cv_timer( const struct arg_block *arg )
{
	int flag, st;
	struct timespec ns_delay;
	struct PTHREAD_HANDLE *waiting_th;
	pthread_cond_t *cv_h;

	cv_h = arg->cv_h;
	waiting_th = arg->wait_th;

	/*
	 * Convert the absolute time in the argument block to a relative
	 * delay time then delay the thread.
	 */
	abs2rel( &ns_delay, *arg->abstime );
	pthread_delay_np( &ns_delay );

	/*
	 * The basic strategy is to yank the specified thread from the
	 * queue of threads at this condition variable.
	 */
	sys_disable_ctxsw( flag );
	st = yank_thread( &(*cv_h)->obj.waiting_threads, waiting_th );
	if( st == SUCCESS )
	{
		/*
		 * Enqueue the thread on the ready queue and exit.
		 */
		waiting_th->obj.thread_state = THREAD_READY_C;
		enqueue_thread( &thread_rq, waiting_th );
		LOG(waiting_th, "waiting->ready");
	}

	sys_restore_ctxsw( flag );

	pthread_exit( (void *) SUCCESS );
}

int  
pthread_cond_timedwait( pthread_cond_t  *cv_h, 
                        pthread_mutex_t  *mu_h, 
                        const struct timespec *abstime )
{
   int st;
   struct arg_block args;
   pthread_t timer_th;

   if( (st = system_init()) == FAILURE )
       return( st );

   if( !attr )
   {
	   pthread_attr_init( &attr );
	   pthread_attr_setschedparam( &attr, &param );
   }

   /*
	* Calculate the delay time, then initialize the block of arguments
	* to be passed to the CV timer thread.
	*/
   args.abstime = (struct timespec *) abstime;
   args.cv_h = cv_h;
   args.wait_th = nub_get_active_thread();

   pthread_create( &timer_th, &attr, (thread_proc_t) cv_timer, &args );
   pthread_yield( NULL );
   return( pthread_cond_wait( cv_h, mu_h ) );
}
