/*
 * $Id: mutex.h,v 1.1.1.1 1996/06/29 01:20:52 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: mutex.h,v $
 * Revision 1.1.1.1  1996/06/29 01:20:52  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:02  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:43  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:30  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:41:59  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#ifndef _mutex_
#define _mutex_

#include "private.h"
#include "priority_q.h"
#include "mutex_attr.h"
#include "machdep.h"

typedef struct MUTEX_OBJ
{
   semaphore_t             lock;               /* Set if locked, clear if not */
   mutex_attr_obj_t        attr_obj;           /* Describes the type of mutex */
   priority_queue_t        blocked_threads;
   counter_t               ref_count;
   counter_t               accum_lock_count;
   struct PTHREAD_HANDLE   *active_th;         /* Thread that holds the mutex */

} mutex_obj_t;

struct PTHREAD_MUTEX_HANDLE
{
   struct PTHREAD_MUTEX_HANDLE *next_in_pool;

   counter_t               id;
   mutex_obj_t             obj;
   object_type_t           type;

};

extern counter_t
init_mu_obj( mutex_obj_t *mu, mutex_attr_obj_t *attr );

extern void
destroy_mu_obj( mutex_obj_t *obj );

#endif
