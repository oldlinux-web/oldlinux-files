#ifndef lint
static const char rcsid[] = "$Id: pthread_attr.c,v 1.1.1.1 1996/06/29 01:20:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: pthread_attr.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:53  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:13  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:54  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:44  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include "pthread.h"
#include "public.h"
#include "thread_attr.h"
#include "error.h"

extern thread_attr_obj_t *
get_default_th_attr_obj( void );

/*------------------------------------------------------------------------*/
/*                          ATTR SERVICES                                 */
/*------------------------------------------------------------------------*/
int  
pthread_attr_init( pthread_attr_t *handle )
{
   int flag, st;
   struct PTHREAD_ATTR_HANDLE *attr_h;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   /*
    *  --  Create an attributes handle initialized with default values.
    */
   if( (attr_h = allocate_handle( ATTR_C )) == NULL )
   {
       set_thread_errno( ENOMEM );
       RETURN( ENOMEM );
   }

   attr_h->type = ATTR_C;
   attr_h->obj = get_default_th_attr_obj();

   *handle = attr_h;

   RETURN( SUCCESS );
}

int  
pthread_attr_destroy( pthread_attr_t *handle )
{
   int flag,st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   /*
    *  --  Ensure that the handle is valid.
    */
   if( handle == NULL || (*handle)->type != ATTR_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   destroy_th_attr_obj( (*handle)->obj );
   free_handle( *handle );
   handle = NULL;
   
   RETURN( SUCCESS );
}

int 
pthread_attr_setdetachstate( pthread_attr_t  *handle,
                             int  detached_state )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != ATTR_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   if( detached_state != PTHREAD_CREATE_JOINABLE &&
       detached_state != PTHREAD_CREATE_DETACHED )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   (*handle)->obj->detached_state = detached_state;
   RETURN( SUCCESS );
}
                             
int 
pthread_attr_getdetachstate( pthread_attr_t  *handle,
                             int *detached_state )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != ATTR_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   *detached_state = (*handle)->obj->detached_state;
   RETURN( SUCCESS );
}

int  
pthread_attr_setstacksize( pthread_attr_t  *handle, size_t stack_size )
{
   int flag, st;
   struct PTHREAD_ATTR_HANDLE *attr_h;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   attr_h = *handle;
   if( attr_h == NULL || attr_h->type != ATTR_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   attr_h->obj->stack_size = stack_size;
   RETURN( SUCCESS );
}

int  
pthread_attr_getstacksize( pthread_attr_t  *handle, size_t  *stack_size )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != ATTR_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   *stack_size = (*handle)->obj->stack_size;
   RETURN( SUCCESS );
}

int  
pthread_attr_setinheritsched( pthread_attr_t  *handle, int inherit_sched )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != ATTR_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   (*handle)->obj->inherit_sched = inherit_sched;
   RETURN( SUCCESS );
}

int  
pthread_attr_getinheritsched( pthread_attr_t *handle, int *inherit_sched )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != ATTR_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   *inherit_sched = (*handle)->obj->inherit_sched;
   RETURN( SUCCESS );
}

int  
pthread_attr_setschedpolicy( pthread_attr_t  *handle, int sched_policy )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != ATTR_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   (*handle)->obj->sched_param.sched_policy = sched_policy;
   RETURN( SUCCESS );
}

int
pthread_attr_getschedpolicy( pthread_attr_t *handle, int *sched_policy )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != ATTR_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   *sched_policy = (*handle)->obj->sched_param.sched_policy;
   RETURN( SUCCESS );
}

int  
pthread_attr_getschedparam( pthread_attr_t *handle,
                            struct sched_param *sched_param )
{
   struct sched_param *tmp;
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != ATTR_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   tmp = &(*handle)->obj->sched_param;
   memcpy( sched_param, tmp, sizeof( struct sched_param ));
   RETURN( SUCCESS );
}

int  
pthread_attr_setschedparam( pthread_attr_t  *handle, 
                            const struct sched_param *sched_param )
{
   struct sched_param *tmp;
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != ATTR_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   tmp = &(*handle)->obj->sched_param;
   memcpy( tmp, sched_param, sizeof( struct sched_param ));
   RETURN( SUCCESS );
}

int
pthread_attr_getschedpriority( pthread_attr_t *handle, int *sched_priority )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != ATTR_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   *sched_priority = (*handle)->obj->sched_param.sched_priority;
   RETURN( SUCCESS );
}

int 
pthread_attr_setscope( pthread_attr_t *handle, int contention_scope )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   set_thread_errno( ENOSYS );
   RETURN( ENOSYS );
}

int 
pthread_attr_getscope( pthread_attr_t *handle, int *contention_scope )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   set_thread_errno( ENOSYS );
   RETURN( ENOSYS );
}
