#ifndef lint
static const char rcsid[] = "$Id: init.c,v 1.1.1.1 1996/06/29 01:20:52 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: init.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:52  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:02  mtp
 * + Release 2.0
 *
 * Revision 1.4  1996/01/14 20:22:42  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.3  1996/01/14 18:32:30  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.2  1995/12/31 06:15:17  mtp
 * + Removed a block of code that had already been commented out.  Did some
 *   minor reformatting.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include <errno.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include "pthread.h"
#include "clock.h"
#include "private.h"
#include "thread.h"
#include "mutex.h"
#include "condv.h"
#include "machdep.h"
#include "nub.h"
#include "delay.h"
#include "config.h"

typedef void (*exit_routine_t)(void);
extern char *sys_errlist[];

extern void
execute_sigaction( int sig, struct PTHREAD_HANDLE *active_th );

extern void
nub_init_control_block( struct PTHREAD_HANDLE *th_h );

static thread_attr_obj_t       *default_th_attr_obj;
static mutex_attr_obj_t        *default_mu_attr_obj;
static condv_attr_obj_t        *default_cv_attr_obj;

static struct PTHREAD_HANDLE   *main_th, *idle_th;

static config_t sys_config;

#undef sigprocmask

static void
install_general_sig_handler( long timer_interval )
{
   int sig;
   sigset_t sigmask;

   /*
	* block all signals while we're installing the signal handlers.
	*/
   sigfillset( &sigmask );
   sigprocmask( SIG_BLOCK, &sigmask, NULL );

   /*
    * The install_sig() function (see posix_signal.c) installs a
	* common signal handler for all threads.
	*/
   for(sig = 1; sig < NSIG; sig++ )
	   install_sig( sig );

   /*
    * We're all set - Allow any and all signals to be delivered to the 
    * process and then install the interval timer.
    */
   sigemptyset( &sigmask );
   sigprocmask( SIG_SETMASK, &sigmask, NULL );
   install_interval_timer( timer_interval );
}

static int
idle_select( int nd,
            fd_set * in,
            fd_set * out,
            fd_set * ex,
            struct timeval * tv);

#undef IDLE_C_LOST_INTR
#define IDLE_C_LOST_INTR (sys_config.timer_idle_interval / sys_config.timer_interval)
static  struct timeval x_tv;

static void
micro_sleep( void )
{
   x_tv.tv_sec = 0;
   x_tv.tv_usec = sys_config.timer_idle_interval;
   while( idle_select( 0, NULL, NULL, NULL, &x_tv ) < 0 )
       break;

   /*
    * While we've been sleeping, timer interrupts have continued to happen.
    * To this end, we now update the nub's control block for the number of 
    * interrupts we've missed.
    */
   nub_set_idle_intr( IDLE_C_LOST_INTR );
}

/*
 * --  This procedure is executed by the idle thread.  The idle
 *     thread is invoked when no other threads are waiting in the
 *     pthread ready queue.
 */
void
idle_proc( void *arg )
{
   int flag;

   while( 1 )
   {
       sys_disable_ctxsw( flag );

       /*
        * Put the process to sleep for "x_tv.tv_usecs" milliseconds.
        * Then, wakeup and unwait any delayed threads and yield() the
        * processor to any threads have been moved from the delay queue to 
        * the ready queue.
		*/
       micro_sleep();

       thread_unwait( nub_update_timer() );
           if( thread_rq.elements > 0 )
	   {
		   idle_th->obj.thread_state = THREAD_READY_C;
		   nub_reschedule( idle_th );
	   }

       sys_restore_ctxsw( flag );
   }
}

/*
 * --  This service is called every time a public function is called, but
 *     the body is only executed once. 
 *
 *     Note that if we run out of memory during system initialization,
 *     that we deallocate everything allocated so far before returning
 *     an error status (and errno set to ENOMEM).
 *
 *     Also, we can get away with setting errno because, presumably, we're
 *     not multithreaded yet.
 */
int
system_init( void )
{
   sigset_t sigset;
   static semaphore_t  initialized = 0;

   /*
    *  --  The test of whether the system has been initialized.
    */
   if( sys_test_and_set( &initialized ) == SEMAPHORE_C_SET )
       return( SUCCESS );

   /*
    * Block all signals (except the usual ones we can't block such as
    * SIGKILL, etc.)
    */
   sigemptyset( &sigset );
   sigprocmask( SIG_SETMASK, &sigset, NULL );

   init_config( &sys_config );

   /**********************************************************************
    *  --   Create a default attributes object for threads, mutexes, and
    *       condition variables.
    **********************************************************************/
   default_th_attr_obj = init_th_attr_obj( sys_config.default_sched_policy,
                                           sys_config.default_thread_prio,
                                           sys_config.default_quantum,
                                           PTHREAD_DEFAULT_SCHED_INHERIT_C,
                                           sys_config.default_stack_size,
                                           PTHREAD_DETACHED_C );

   if( default_th_attr_obj == NULL )
   {
       fprintf( stderr, "internal error: %s\n", sys_errlist[ENOMEM] );
       errno = ENOMEM;
       return( ENOMEM );
   }

   default_cv_attr_obj = init_cv_attr_obj(  SCHED_FIFO );
   if( default_cv_attr_obj == NULL )
   {
       FREE( default_th_attr_obj );
       fprintf( stderr, "internal error: %s\n", sys_errlist[ENOMEM] );
       errno = ENOMEM;
       return( ENOMEM );
   }

   default_mu_attr_obj = init_mu_attr_obj( MUTEX_SCHED_DEFAULT );
   if( default_mu_attr_obj == NULL )
   {
       FREE( default_th_attr_obj );
       FREE( default_cv_attr_obj );
       fprintf( stderr, "internal error: %s\n", sys_errlist[ENOMEM] );
       errno = ENOMEM;
       return( ENOMEM );
   }

   /**********************************************************************
    *  --  Allocate and initialize the main thread, i.e., the thread that
    *      is currently executing (also called the INIITAL_THREAD)
    **********************************************************************/
   if((main_th = allocate_handle( THREAD_C )) == NULL )
   {
       FREE( default_th_attr_obj );
       FREE( default_cv_attr_obj );
       FREE( default_mu_attr_obj );
       fprintf( stderr, "internal error: %s\n", sys_errlist[ENOMEM] );
       errno = ENOMEM;
       return( ENOMEM );
   }

   main_th->id = init_th_obj( &main_th->obj, default_th_attr_obj, NULL, NULL );
   if( main_th->obj.stack == NULL )
   {
       FREE( default_th_attr_obj );
       FREE( default_cv_attr_obj );
       FREE( default_mu_attr_obj );
       FREE( main_th );
       fprintf( stderr, "internal error: %s\n", sys_errlist[ENOMEM] );
       errno = ENOMEM;
       return( ENOMEM );
   }
   main_th->id = PTHREAD_INITIAL_ID_C;
   main_th->obj.sched_param.sched_priority = PTHREAD_INITIAL_PRIO_C;
   main_th->obj.attr_obj.sched_param.sched_priority = PTHREAD_INITIAL_PRIO_C;
   main_th->obj.saved_prio = PTHREAD_INITIAL_PRIO_C;

   /*
    *  --  Register the main thread as the active thread.
    */
   main_th->obj.thread_state = THREAD_ACTIVE_C;
   nub_init_control_block( main_th );
   LOG( main_th, "Main thread active");   

   /***********************************************************************
    *  --  Allocate and initialize the idle thread, i.e., the thread that
    *      will execute if no other threads are able to run.
    ***********************************************************************/
   if( (idle_th = allocate_handle( THREAD_C )) == NULL )
   {
       FREE( default_th_attr_obj );
       FREE( default_cv_attr_obj );
       FREE( default_mu_attr_obj );
       FREE( main_th->obj.stack );
       FREE( main_th );
       fprintf( stderr, "internal error: %s\n", sys_errlist[ENOMEM] );
       errno = ENOMEM;
       return( ENOMEM );
   }
   
   idle_th->id = init_th_obj( &idle_th->obj, 
                               default_th_attr_obj, 
                               (thread_proc_t) idle_proc, 
                               NULL );
   if( idle_th->obj.stack == NULL )
   {
       FREE( default_th_attr_obj );
       FREE( default_cv_attr_obj );
       FREE( default_mu_attr_obj );
       FREE( main_th->obj.stack );
       FREE( main_th );
       FREE( idle_th );
       fprintf( stderr, "internal error: %s\n", sys_errlist[ENOMEM] );
       errno = ENOMEM;
       return( ENOMEM );
   }
   /*
    *  --  Custom adjustments because the idle thread is not a 'default'
    *      thread.
    */
   idle_th->id = PTHREAD_IDLE_ID_C;
   idle_th->obj.sched_param.sched_priority = PTHREAD_IDLE_PRIO_C;
   idle_th->obj.attr_obj.sched_param.sched_priority = PTHREAD_IDLE_PRIO_C;
   idle_th->obj.saved_prio = PTHREAD_IDLE_PRIO_C;

   /*
    *  --  Insert the idle thread into the ready queue.
    */
   enqueue_thread( &thread_rq, idle_th );

   atexit( (exit_routine_t) pthread_exit );
   install_general_sig_handler( sys_config.timer_interval );

   return( SUCCESS );
}

thread_attr_obj_t *
get_default_th_attr_obj( void )
{
   thread_attr_obj_t *obj;

   obj = MALLOC( sizeof( thread_attr_obj_t ));
   memcpy( obj, default_th_attr_obj, sizeof( thread_attr_obj_t ));
   return( obj );
}

mutex_attr_obj_t *
get_default_mu_attr_obj( void )
{
   mutex_attr_obj_t *obj;

   obj = MALLOC( sizeof( mutex_attr_obj_t ));
   memcpy( obj, default_mu_attr_obj, sizeof( mutex_attr_obj_t ));
   return( obj );
}

condv_attr_obj_t *
get_default_cv_attr_obj( void )
{
   condv_attr_obj_t *obj;

   obj = MALLOC( sizeof( condv_attr_obj_t ));
   memcpy( obj, default_cv_attr_obj, sizeof( condv_attr_obj_t ));
   return( obj );
}

/*
 * idle_select() is a wrapper around the select() system call.  Because
 * idle_select() is private to the thread library, we don't have to worry
 * about inadvertantly calling the non-blocking version.  In the idle()
 * routine we *want* to block the whole process.
 */
static int
idle_select( int nd,
             fd_set * in,
             fd_set * out,
             fd_set * ex,
             struct timeval * tv )
{
   long __res;

#if defined(__PIC__) || defined (__pic__)
   __asm__ volatile ("pushl %%ebx\n\t"
                     "movl %%ecx,%%ebx\n\t"
                     "int $0x80\n\t"
                     "popl %%ebx"
            : "=a" (__res)
            : "0" (SYS_select),"c" ((long) &nd));
#else
   __asm__ volatile ("int $0x80"
           : "=a" (__res)
           : "0" (SYS_select),"b" ((long) &nd));
#endif

   if (__res >= 0)
       return (int) __res;

   errno = -__res;

   return -1;
}

#include <gnu-stabs.h>
#ifdef weak_alias
weak_alias (__select, select);
#endif
