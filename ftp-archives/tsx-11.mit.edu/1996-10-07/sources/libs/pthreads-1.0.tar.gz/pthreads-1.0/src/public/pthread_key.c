#ifndef lint
static const char rcsid[] = "$Id: pthread_key.c,v 1.1.1.1 1996/06/29 01:20:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: pthread_key.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:53  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:14  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:55  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:45  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include "pthread.h"
#include "public.h"
#include "dbgmem.h"
#include "error.h"
#include "thread.h"
#include "nub.h"

/*
 * Keep a global count of keys and their associated destructors.
 */
static volatile pthread_key_t n_keys;
static void (*key_destructor_table[PTHREAD_KEYS_MAX])(void *);

void
call_thread_destructors( const struct PTHREAD_HANDLE *h )
{
   int i;

   for(i = 0; i < n_keys; i++ )
   {
       /*
        * Only call a destructor if the key AND the
        * destructor is non-NULL.
        */
       if( h->obj.key[i] && key_destructor_table[i] )
       {
           (key_destructor_table[i])(h->obj.key[i]);
       }
   }
}

/*
 * Return the address of the pointer to the thread-specific data
 * associated with the specified key.  If the thread-specific data
 * does not exist, the 'data' argument is set to NULL.
 */
int
pthread_getspecific( pthread_key_t key, void **data )
{
	struct PTHREAD_HANDLE *active_th;
	int flag, st;

	if( (st = system_init()) != SUCCESS )
		return( st );

	sys_disable_ctxsw( flag );
	if( key < 0 || key >= n_keys )
	{
		set_thread_errno( EINVAL );
		RETURN( EINVAL );
	}

	active_th = nub_get_active_thread();
	*data = active_th->obj.key[key];

	RETURN( SUCCESS );
}

/*
 * --  This service causes a thread-private data node to be created,
 *     initialized, and inserted into the calling thread's list of private 
 *     data nodes.
 */
int
pthread_setspecific( pthread_key_t key, void *data )
{
	struct PTHREAD_HANDLE *active_th;
	int flag, st;

	if( (st = system_init()) != SUCCESS )
		return( st );

	sys_disable_ctxsw( flag );
	if( key < 0 || key >= n_keys )
	{
		set_thread_errno( EINVAL );
		RETURN( EINVAL );
	}

	active_th = nub_get_active_thread();
	active_th->obj.key[key] = data;

	RETURN( st );
}

/*
 * Create a key with which is associated a destructor.  If the key
 * already exists, return harmlessly.
 */
int
pthread_key_create( pthread_key_t *key, void (*destructor)(void *) )
{
	int flag, st;

	if( (st = system_init()) != SUCCESS )
		return( st );

	sys_disable_ctxsw( flag );
	if( key == NULL || n_keys >= PTHREAD_KEYS_MAX )
	{
		set_thread_errno( EINVAL );
		RETURN( EINVAL );
	}

	key_destructor_table[n_keys] = destructor;
	*key = n_keys++;

	RETURN( SUCCESS );
}
