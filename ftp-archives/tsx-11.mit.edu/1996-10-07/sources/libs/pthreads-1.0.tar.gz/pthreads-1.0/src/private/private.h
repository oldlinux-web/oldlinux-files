/*
 * $Id: private.h,v 1.1.1.1 1996/06/29 01:20:52 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: private.h,v $
 * Revision 1.1.1.1  1996/06/29 01:20:52  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:06  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:45  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:34  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:41:59  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#ifndef _private_
#define _private_

#include <stdlib.h>
#include <signal.h>
#include <typedefs.h>
#include <dbgmem.h>
#include "clock.h"

#define NSEC_PER_SECOND         ((long) 1000000000)
#define TIMER_C_IDLE_INTERVAL   ((long) 20000) /* = 20 milliseconds */
#define TIMER_C_INTERVAL_USECS  ((long) 20000) /* = 20 milliseconds */

typedef unsigned long counter_t;

/*
 * --  These constants identify and specify the initial (aka main) 
 *     and the idle threads, respectively.
 */
#define PTHREAD_IDLE_ID_C              ((counter_t) 0)
#define PTHREAD_INITIAL_ID_C           ((counter_t) 1)
#define PTHREAD_INITIAL_PRIO_C         (PTHREAD_DEFAULT_PRIO_C)
#define PTHREAD_IDLE_PRIO_C            ((int) 0)

typedef enum OBJECT_TYPE
{
   THREAD_C,
   MUTEX_C,
   CONDV_C,
   ATTR_C,
   MUTEX_ATTR_C,
   CONDV_ATTR_C

} object_type_t;

typedef enum
{
   THREAD_STATE_MIN_C, /* Must be first */
   THREAD_ACTIVE_C,    /* Thread is currently executing */
   THREAD_READY_C,     /* Thread is on nub's ready queue */
   THREAD_DELAYED_C,   /* Thread is delayed in the nub's timer queue */
   THREAD_BLOCKED_C,   /* Thread is blocked at a mutex */
   THREAD_WAITING_C,   /* Thread is waiting at a condition variable */
   THREAD_COMPLETE_C,  /* Thread has terminated */
   THREAD_STATE_MAX_C  /* Must be last */

} thread_state_t;

#define PTHREAD_DEFAULT_SCHED_POLICY_C (SCHED_ROUND_ROBIN_C)
#define PTHREAD_DEFAULT_QUANTUM_C      ((int) 2)           /* = 2 clock ticks */
#define PTHREAD_DEFAULT_STACKSIZE_C    ((size_t) 8192)     /* bytes */
#define PTHREAD_DEFAULT_SCHED_INHERIT_C PTHREAD_SCHED_INHERIT_C

#ifdef _TRACE_ON_
   #define LOG(th,str) printf("th[%ld]: %s\n", th->id,str);
#else
   #define LOG(th,str) {;}
#endif

/*
 * --  initializes the pthreads runtime data structures.  This service is 
 *     called by every public service in the API, but is executed only once, 
 *     i.e., only the first time it is called.
 */
extern int
system_init( void );

/*
 * --  Generic allocate/deallocate services for thread, mutex, condition 
 *     variable, and  attributes handle.
 */
extern void *
allocate_handle( object_type_t type );

extern void
free_handle( void * );

#endif
