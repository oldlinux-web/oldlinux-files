/*
 * $Id: machdep.h,v 1.1.1.1 1996/06/29 01:20:52 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: machdep.h,v $
 * Revision 1.1.1.1  1996/06/29 01:20:52  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:02  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:42  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:30  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:41:59  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#ifndef _machdep_
#define _machdep_
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include "private.h"
#include "stack.h"

/*
 * --  Credit where credit's due -- I stole these macros from Chris 
 *     Provenzano's pthreads package (with some minor modifications).
 */
typedef long semaphore_t;

#define SEMAPHORE_C_CLEAR ((long) 0)
#define SEMAPHORE_C_SET   ((long) 1)

extern int critical;

#define sys_test_and_set(lock)    \
({                                      \
   volatile long temp = SEMAPHORE_C_SET;  \
   __asm__("xchgl %0,(%2)"              \
           :"=r" (temp)                 \
           :"0" (temp),"r" (lock));     \
   temp;                                \
})

#define sys_reset(lock)  ((*lock)=SEMAPHORE_C_CLEAR)

extern void
sys_switch_thread_stacks( stack_t *new, stack_t *curr );

extern void *
sys_get_return_value( void );

extern int
sys_set_critical( void );

extern int
sys_restore_critical( int flag );

#define sys_disable_ctxsw(f)   (f)=sys_set_critical()
#define sys_restore_ctxsw(f)   sys_restore_critical(f)

#endif
