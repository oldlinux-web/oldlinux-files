#ifndef lint
static const char rcsid[] = "$Id: stack_cache.c,v 1.1.1.1 1996/06/29 01:20:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: stack_cache.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:53  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:07  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:46  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:35  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include "private.h"
#include "stack_cache.h"

/*
 * Constants and data structures.
 */
#define GET_NODE_FROM_CACHE(n) \
{ \
    n = cache_nodes.next; \
    cache_nodes.next = n->next; \
    node_count -= 1; \
}

#define PUT_NODE_IN_CACHE(n) \
{ \
    n->next = cache_nodes.next; \
    cache_nodes.next = n; \
    node_count += 1; \
}

typedef struct STACK_CACHE_NODE
{
    struct STACK_CACHE_NODE *next;
    stack_t                 *st;

} stack_cache_node_t;
    
/*
 * Internal function prototypes.
 */
static stack_cache_node_t *
allocate_stack_node( void );

static void 
deallocate_stack_node( stack_cache_node_t *node );

/*
 * Internal variables.
 */
static const size_t         SIZEOF_STACK_STRUCT = sizeof( stack_t );
static const size_t         SIZEOF_CACHE_NODE = sizeof( stack_cache_node_t );
static const size_t         STACK_CACHE_NODE_MAX_COUNT = 3;
static size_t               node_count = 0;
static stack_cache_node_t   cache_nodes = { NULL, NULL };

static stack_cache_node_t *
allocate_stack_node( void )
{
    stack_cache_node_t *node;

    if( cache_nodes.next )
    {
        GET_NODE_FROM_CACHE(node);
    }
    else
        node = malloc( SIZEOF_CACHE_NODE );

    return( node );
}

static void
deallocate_stack_node( stack_cache_node_t *node )
{
    if( node_count >= STACK_CACHE_NODE_MAX_COUNT )
        free( node );
    else
    {
        PUT_NODE_IN_CACHE(node);
    }
}

/*------------------------------------------------------------------*/
/*                       EXPORTED FUNCTIONS                         */
/*------------------------------------------------------------------*/
typedef struct STACK_CACHE
{
    stack_cache_node_t  *first;
    long                elements;

} stack_cache_t;

static const size_t STACK_CACHE_MAX_COUNT = 10;
static stack_cache_t cache = { NULL, 0 };

static void
return_stack_to_cache( stack_t *st )
{
    stack_cache_node_t *node;

    if( cache.elements == STACK_CACHE_MAX_COUNT )
    {
        free( st );
        return;
    }

    /*
     * Allocate a cache node, link in the stack and put the node
     * at the front of the stack.
     */
    node = allocate_stack_node();
    node->st = st;

    node->next = cache.first;
    cache.first = node;
    cache.elements += 1;    
}

static stack_t *
get_stack_from_cache( size_t size )
{
    stack_t *stack = NULL;
    stack_cache_node_t *prev, *curr;

    if( cache.elements )
    {
        prev = curr = cache.first;

        while( size > curr->st->stack_hdr.elements && curr->next != NULL )
        {
            prev = curr;
            curr = curr->next;
        }

        if( size <= curr->st->stack_hdr.elements )
        {
            /* 
             * We've found a compatible stack.  Assign the pointer and
             * unlink the node.
             */
            stack = curr->st;
            if( curr == cache.first )
                cache.first = curr->next;
            else
                prev->next = curr->next;

            cache.elements -= 1;
            deallocate_stack_node(curr);
        }
    }

    if( stack == NULL )
    {
        stack = malloc( SIZEOF_STACK_STRUCT + (size * 4) );
    }
            
    return( stack );
}

stack_t *
allocate_stack( size_t elements )
{
    stack_t *stack = NULL;

    stack = get_stack_from_cache( elements );
    if( stack )
        stack->stack_hdr.elements = elements;

    return( stack );
}

void
deallocate_stack( stack_t *st )
{
    return_stack_to_cache( st );
}
