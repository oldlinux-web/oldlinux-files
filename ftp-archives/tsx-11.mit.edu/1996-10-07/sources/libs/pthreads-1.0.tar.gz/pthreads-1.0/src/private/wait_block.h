/*
 * $Id: wait_block.h,v 1.1.1.1 1996/06/29 01:20:53 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: wait_block.h,v $
 * Revision 1.1.1.1  1996/06/29 01:20:53  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:08  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:48  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:36  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#ifndef _wait_block_
#define _wait_block_
#include <pthread.h>
#include "posix_signal.h"

/****************************************************************************
 * --  Here is the sigwait block at which one or more threads whose sigmasks
 *     are the same will wait.  The system will create one of these for
 *     every unique sigmask passed into the sigwait() call.  Once created,
 *     waitblocks last until removed by a reaper thread.  The reaper thread
 *     wakes up and walks the list of waitblocks deleting each one at which
 *     no threads wait.
 ***************************************************************************/
typedef struct SIGWAIT_BLOCK
{
   struct SIGWAIT_BLOCK *next;
   int                   signal_pending;
   pthread_mutex_t       wb_lock;
   pthread_cond_t        wb_cond;
   sigset_t              wb_sigset;
      
} sigwait_block_t;

typedef struct SIGWAIT_BLOCK_LIST
{
    sigwait_block_t *first;
    pthread_mutex_t lock;
    int elements;

} sigwait_block_list_t;

/*
 * Insert, remove, and get operations on lists of sigwait blocks.
 */
extern void
insert_waitblock( sigwait_block_list_t *wbl, sigwait_block_t *wb );

extern void
remove_waitblock( sigwait_block_list_t *wbl, sigwait_block_t *wb );

extern sigwait_block_t *
get_waitblock( sigwait_block_list_t *wbl, int sig );

/*
 * --  Initialize and Destroy sigwait blocks
 */
extern sigwait_block_t *
init_sigwait_block( void );

extern void
destroy_sigwait_block( sigwait_block_t *wb );

extern int
waitblock_get_waiter_count( sigwait_block_t *wb );

extern sigwait_block_t *
waitblock_get_matching( sigwait_block_list_t *list, sigset_t set );

#endif
