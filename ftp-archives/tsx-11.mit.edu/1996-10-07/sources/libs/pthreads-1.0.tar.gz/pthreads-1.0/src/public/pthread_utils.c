#ifndef lint
static const char rcsid[] = "$Id: pthread_utils.c,v 1.1.1.1 1996/06/29 01:20:54 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: pthread_utils.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:54  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:15  mtp
 * + Release 2.0
 *
 * Revision 1.6  1996/01/14 20:16:31  mtp
 * + Changed pthread_unblockasync_np() to return void.
 *
 * Revision 1.5  1996/01/14 18:32:46  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.4  1996/01/10 19:06:06  mtp
 * + Removed an unused variable in pthread_blockasync_np().
 *
 * Revision 1.3  1996/01/10 17:12:43  mtp
 * + Added pthread_blockasync_np(), pthread_unblockasync_np(), and
 *   pthread_cond_signal_intr_np().
 *
 * Revision 1.2  1995/12/31 06:27:12  mtp
 * + Made pthread_delay_np() a cancellation point because DCE requires it.  Ugh!
 * + Changed pthread_get_expiration_np() to pthread_getexpiration_np().
 * + Changed pthread_get_errno_np() pthread_geterrno_np().
 * + Changed pthread_set_errno_np() pthread_seterrno_np().
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include "pthread.h"
#include "public.h"
#include "thread.h"
#include "mutex.h"
#include "condv.h"
#include "nub.h"
#include "error.h"
#include "delay.h"
#include "machdep.h"

typedef int global_lock_t;

int
pthread_blockasync_np( void )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   return( flag );
}

void
pthread_unblockasync_np( int flag )
{
    (void) system_init();
    sys_restore_ctxsw( flag );
}

int
pthread_getcancelstate_np( pthread_t th );

/*
 * Set an element in the nub's control block signal action vector.
 * NB: This function replaces sigaction().
 */
int
pthread_sigaction_np( int signal,
                      const struct sigaction *new,
                      struct sigaction *prev )
{
   int st, flag;
   struct PTHREAD_HANDLE *active_th;

   if( (st = system_init()) != SUCCESS )
       return( st );

   if( signal < 1 || signal > (NSIG - 1))
	   return( EINVAL );

   sys_disable_ctxsw( flag );

   if( prev )
	   nub_get_sigaction( signal, prev );

   if( new == NULL )
	   RETURN( SUCCESS );

   active_th = nub_get_active_thread();

   /*
	* If the action is to 'ignore' the signal, then we need to clear
	* the signal from both its current and pending sig mask.
	*/
   if( new->sa_handler == SIG_IGN )
   {
	   sigdelset( &active_th->obj.current_sigs, signal );
	   sigdelset( &active_th->obj.pending_sigs, signal );
   }

   nub_set_sigaction( signal, new );

   RETURN( SUCCESS );
}

int
pthread_getexpiration_np( const struct timespec *delta,
                          struct timespec *abstime )
{
   counter_t curr_nsecs, delta_nsecs, exp_nsecs;
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( delta->tv_nsec > (NSEC_PER_SECOND - 1))
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   curr_nsecs = nub_get_elapsed_usecs() * 1000;    /* convert to nanoseconds */
   delta_nsecs = (delta->tv_sec * NSEC_PER_SECOND) + delta->tv_nsec;
   exp_nsecs = curr_nsecs + delta_nsecs;

   abstime->tv_sec = exp_nsecs / NSEC_PER_SECOND;
   abstime->tv_nsec = exp_nsecs % NSEC_PER_SECOND;

   RETURN( SUCCESS );
}

#define USEC_PER_SECOND    (1000000)
#define NSEC_PER_USEC      (1000)

static int
cvt_timespec_to_usec( counter_t *usecs, const struct timespec *interval )
{
	int status = SUCCESS;

	if( interval->tv_nsec > (NSEC_PER_SECOND - 1))
	{
		set_thread_errno( EINVAL );
		return( EINVAL );
	}

	*usecs = (interval->tv_sec * USEC_PER_SECOND) +
		                (interval->tv_nsec/NSEC_PER_USEC);

	return( status );
}

int
pthread_delay_np( const struct timespec *interval )
{
   counter_t usecs;
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   pthread_testcancel();
   sys_disable_ctxsw( flag );

   /*
	* Convert the caller's interval time from nano-seconds to microseconds.
    */
   st = cvt_timespec_to_usec( &usecs, interval );
   if( st != SUCCESS )
		RETURN( st );

   thread_delay( usecs );

   sys_restore_ctxsw( flag );

   pthread_testcancel();
   return( SUCCESS );   
}

int
pthread_get_ctxsw_counts_np( pthread_t handle,
                             unsigned long *total_count,
                             unsigned long *async_count )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   *total_count = handle->obj.total_ctxsw_count;
   *async_count = handle->obj.async_preemptions;

   RETURN( SUCCESS );
}

int
pthread_gettimeofday_np( struct timeval *tv, struct timezone *tz )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   nub_get_timeofday( tv, tz );
   RETURN( SUCCESS );
}


int
system_get_state( unsigned long *intr_count,
                  unsigned long *ctxsw_count,
                  unsigned long *async_preemptions,
                  unsigned long *elapsed_time,
                  int *active_priority )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );

   if( intr_count )
       *intr_count = nub_get_intr_count();

   if( ctxsw_count )
       *ctxsw_count = nub_get_ctxsw_count();

   if( async_preemptions )
       *async_preemptions = nub_get_async_preemptions();

   if( active_priority )
       *active_priority = nub_get_active_prio();

   if( elapsed_time )
       *elapsed_time = nub_get_elapsed_usecs();

   RETURN( SUCCESS );
}

int
pthread_checkstack_np( pthread_t handle, size_t *bytes )
{
   struct PTHREAD_HANDLE *active_th;
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL )
       active_th = nub_get_active_thread();
   else
   {
       if( handle->type != THREAD_C )
           RETURN( EINVAL );

       active_th = handle;
   }

   *bytes = 0;
   if( active_th->id == 1 )
       RETURN( SUCCESS );

   st = check_thread_stack( active_th->obj.stack, bytes );

   RETURN( st );
}

int 
pthread_seterrno_np( int err )
{
   struct PTHREAD_HANDLE *th_h;
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   th_h = nub_get_active_thread();
   th_h->obj.errno = err;

   RETURN( SUCCESS );
}

int
pthread_geterrno_np( pthread_t handle, int *err )
{
   struct PTHREAD_HANDLE *th_h;
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   *err = 0;
   th_h = handle;
   sys_disable_ctxsw( flag );
   if( th_h == NULL )
   {
       th_h = nub_get_active_thread();
       *err = th_h->obj.errno;
   }
   else
   {
       if( th_h->type != THREAD_C )
       {
           set_thread_errno( EINVAL );
           RETURN( EINVAL );
       }

       *err = th_h->obj.errno;
   }

   RETURN( SUCCESS );
}

int
pthread_cond_getwaiters_np( pthread_cond_t handle,
                            unsigned int *waiting_threads )
{
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   *waiting_threads = 0;
   sys_disable_ctxsw( flag );
   if( handle == NULL || handle->type != CONDV_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   *waiting_threads = handle->obj.waiting_threads.elements;
   RETURN( SUCCESS );
}

int
pthread_mutex_getblocked_np( pthread_mutex_t handle,
                             unsigned int *blocked_threads )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   *blocked_threads = 0;
   if( handle == NULL || handle->type != MUTEX_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   *blocked_threads = handle->obj.blocked_threads.elements;
   RETURN( SUCCESS );
}

int
pthread_getprio_np( pthread_t handle, int *current_prio )
{
   struct PTHREAD_HANDLE *target_th;
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   *current_prio = 0;
   if( handle == NULL )
       target_th = nub_get_active_thread();
   else
   {
       if( handle->type != THREAD_C )
           RETURN( EINVAL );

       target_th = handle;
   }

   *current_prio = target_th->obj.sched_param.sched_priority;
   RETURN( SUCCESS );
}


int
pthread_setprio_np( pthread_t handle, int new_priority )
{
   int flag, st, policy;
   struct sched_param param;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );

   /*
    *  --  Ensure that the handle referencing the thread to be joined is valid.
    */
   if( handle == NULL || handle->type != THREAD_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   if( new_priority > PTHREAD_MAX_PRIO_C &&
       new_priority < PTHREAD_MIN_PRIO_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   st = pthread_getschedparam( handle, &policy, &param );
   if( st == FAILURE )
       return( st );

   param.sched_priority = new_priority;

   if( handle == nub_get_active_thread() )
       nub_set_active_prio( new_priority );

   /*
    *  --  This function could cause the active thread to sustain a
    *      context switch.
    */
   st = pthread_setschedparam( handle,
                               policy,
                               (const struct sched_param *) &param );
   RETURN( st );
}

long
pthread_getsequence_np( const pthread_t th )
{
   return( th->id );
}

int
pthread_getcancelstate_np( pthread_t th )
{
   return( th->obj.cancel_state );
}

int  
pthread_cond_signal_intr_np( pthread_cond_t  *handle )
{
   struct PTHREAD_HANDLE *waiting_th;
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != CONDV_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   /*
    *  --  The basic strategy is to remove the highest priority thread
    *      from the condition variable's queue of waiting threads, insert 
    *      it into the ready queue.
    */
   waiting_th = dequeue_thread( &(*handle)->obj.waiting_threads );
   if( waiting_th != NULL )
   {
       /*
        *  --  Enqueue the thread on the ready queue and, if a context
        *      switch is required, execute one.
        */
       waiting_th->obj.thread_state = THREAD_READY_C;
       enqueue_thread( &thread_rq, waiting_th );
       LOG(waiting_th, "waiting->ready");
   }

   RETURN( SUCCESS );
}
