#ifndef lint
static const char rcsid[] = "$Id: posix_signal.c,v 1.1.1.1 1996/06/29 01:20:52 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: posix_signal.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:52  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:04  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:45  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:33  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include <string.h>
#include "nub.h"
#include "thread.h"
#include "posix_signal.h"
#include "machdep.h"
#include "sigwait.h"


const char * const sys_signame[] = 
{
    "",
    "SIGHUP",     /* 1 */
    "SIGINT",     /* 2 */
    "SIGQUIT",    /* 3 */
    "SIGILL",     /* 4 */
    "SIGTRAP",    /* 5 */
    "SIGABRT",    /* 6 == SIGIOT */
    "SIGBUS",     /* 7 */
    "SIGFPE",     /* 8 */
    "SIGKILL",    /* 9 */
    "SIGUSR1",    /* 10 */
    "SIGSEGV",    /* 11 */
    "SIGUSR2",    /* 12 */
    "SIGPIPE",    /* 13 */
    "SIGALRM",    /* 14 */
    "SIGTERM",    /* 15 */
    "SIGSTKFLT",  /* 16 */
    "SIGCHLD",    /* 17 */
    "SIGCONT",    /* 18 */
    "SIGSTOP",    /* 19 */
    "SIGTSTP",    /* 20 */
    "SIGTTIN",    /* 21 */
    "SIGTTOU",    /* 22 */
    "SIGURG",     /* 23 */
    "SIGXCPU",    /* 24 */
    "SIGXFSZ",    /* 25 */
    "SIGVTALRM",  /* 26 */
    "SIGPROF",    /* 27 */
    "SIGWINCH",   /* 28 */
    "SIGIO",      /* 29 == SIGPOLL */
    "SIGPWR",     /* 30 */
    "SIGUNUSED"   /* 31 */
};


#define sig_panic(s) \
{ \
	  fprintf( stderr, "%s: ", sys_signame[s] ); \
	  fprintf( stderr, "sigpanic %s, line %d!\n", __FILE__, __LINE__ - 1 ); \
	  fflush(NULL); \
	  _exit(1); \
}

int allowed( int sig );

/*
 * Cause the runtime to execute the nub's sigaction for the specified signal.
 *
 * To accomplish this, the process's default sigaction (installed by the
 * thread's runtime during initialization) is replaced with the one
 * obtained from the nub's control block.  The process's default sigaction
 * is saved in the 'proc_act' data structure, and then restored if the call
 * to kill() returns.
 */
void
execute_sigaction( int sig, struct PTHREAD_HANDLE *active_th )
{
	struct sigaction proc_act, act;

	/*
	 * Check whether the signal is currently blocked.  If so, mark the
	 * signal as pending and return.
	 */
	if( sigismember( &active_th->obj.current_sigs, sig ) == TRUE )
	{
		if( allowed( sig ))
		{
			/*
			 * Add the signal to the thread's set of pending signals.
			 */
			sigaddset( &active_th->obj.pending_sigs, sig );
			return;
		}
	}

	nub_get_sigaction( sig, &act );

	if( allowed( sig ) )
	{
		if( sigaction( sig, &act, &proc_act ) < 0 )
			sig_panic( sig );
	}

	if( sig != SIGKILL && sig != SIGSTOP )
		sigaction( sig, NULL, &proc_act );

	(void) sys_restore_critical( 0 );

	if( kill( getpid(), sig ) < 0 )
		sig_panic( sig );

	(void) sys_set_critical();

	/*
	 * Restore the process's default sigaction.
	 */
	if( !allowed(sig) )
		return;

	if( sigaction( sig, &proc_act, NULL ) < 0 )
		sig_panic(sig);
}

/*
 * All asynchronous signals except SIGKILL, SIGSTOP, SIGTRAP, SIGCONT, and 
 * SIGVTARLM are delivered to the process via the sig_common_handler() service
 * defined here.
 */
void
sig_common_handler( int sig )
{
	struct PTHREAD_HANDLE *active_th = NULL;
	int flag, saved_prio;

	if( sig > NSIG - 1 )
		return;

	sys_disable_ctxsw( flag );

	/*
	 * These signals should never be seen in this routine.
	 */
	if(sig == SIGKILL ||
	   sig == SIGSTOP ||
	   sig == SIGTRAP ||
	   sig == SIGCONT ||
	   sig == SIGVTALRM )
	{
		fprintf(stderr, "Unexpected ");
		sig_panic(sig);
	}

	/*
	 * Under no circumstances can we permit this routine to be preempted.
	 */
	saved_prio = nub_get_active_prio();
	nub_set_active_prio( PTHREAD_MAX_PRIO_C + 1 );

	/*
	 * Check for any sigwaiter threads.  If one is unwaited, then this
	 * signal is handled.  Restore the priority and interrupt state and
	 * return.
	 */
	if( sig_unwait_thread( sig ) == TRUE )
	{
		nub_set_active_prio( saved_prio );
		sys_restore_ctxsw( flag );
		return;
	}

	/*
	 * Check whether the signal is currently blocked.  If so, mark the
	 * signal as pending and return.
	 */
	active_th = nub_get_active_thread();

	/*
	 * Since the thread wasn't sigwaiting and the signal wasn't blocked.
	 * Execute the sigaction for this signal.
	 */
	nub_set_active_prio( saved_prio );
	execute_sigaction( sig, active_th );

	sys_restore_ctxsw( flag );
}

int
allowed( int sig )
{
	int ok = TRUE;

	if(sig == SIGKILL ||
	   sig == SIGTRAP ||
	   sig == SIGSTOP ||
	   sig == SIGCONT ||
	   sig == SIGVTALRM )
	{
		ok = FALSE;
    }

	return( ok );
}

void
install_sig( int sig )
{
   struct sigaction action;

   if( allowed( sig ) == FALSE )
	   return;

   sigfillset( &action.sa_mask );
   sigdelset( &action.sa_mask, SIGVTALRM );

   action.sa_handler = sig_common_handler;
   action.sa_flags = (SA_RESTART);
   if( sigaction( sig, &action, NULL ) < 0 )
	   sig_panic( sig );
}
