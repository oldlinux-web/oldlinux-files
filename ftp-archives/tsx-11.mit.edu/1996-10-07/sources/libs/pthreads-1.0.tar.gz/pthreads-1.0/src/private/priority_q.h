/*
 * $Id: priority_q.h,v 1.1.1.1 1996/06/29 01:20:52 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: priority_q.h,v $
 * Revision 1.1.1.1  1996/06/29 01:20:52  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:05  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:45  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:33  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:41:59  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#ifndef _priority_q_
#define _priority_q_
#include "private.h"

/*
 * --  Implement a FIFO queue using a simple doubly-linked list.  Threads are 
 *     inserted at the end of the list and removed from its front.
 */
typedef struct THREAD_QUEUE
{
   struct PTHREAD_HANDLE   *first_thread;
   struct PTHREAD_HANDLE   *last_thread;
   counter_t               thread_count;

} thread_queue_t;

/*
 * --  A priority queue is simply an array, or table, of thread queues.
 */
typedef struct PRIORITY_QUEUE
{
   thread_queue_t  prio[PTHREAD_MAX_PRIO_C + 1];  /* (MAX PRIO + 1) levels */
   unsigned int    elements;

} priority_queue_t;

extern priority_queue_t thread_rq;        /* Contained in nub.c */

extern void
init_prio_queue( priority_queue_t *rq );

extern int
get_highest_prio( priority_queue_t *rq );

extern void
enqueue_thread( priority_queue_t *rq, struct PTHREAD_HANDLE *th );

extern struct PTHREAD_HANDLE *
dequeue_thread( priority_queue_t *rq );

extern int
yank_thread( priority_queue_t *rq, struct PTHREAD_HANDLE *th );

extern int
thread_on_queue( priority_queue_t *rq, struct PTHREAD_HANDLE *th );

#endif
