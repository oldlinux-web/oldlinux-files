#ifndef lint
static const char rcsid[] = "$Id: priority_q.c,v 1.1.1.1 1996/06/29 01:20:52 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: priority_q.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:52  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:05  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:45  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:33  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include "priority_q.h"
#include "thread.h"
#include "machdep.h"

static void
x_unlink_first_thread( thread_queue_t *q )
{
   struct PTHREAD_HANDLE *h;

   if( q->thread_count == 1 )
   {
       q->first_thread = NULL;
       q->last_thread = NULL;
   }
   else
   {
       h = q->first_thread;
       q->first_thread = h->next_th;
       q->first_thread->prev_th = NULL;
       h->next_th = NULL;
   }

   q->thread_count -= 1;
}

static void
x_unlink_middle_thread( thread_queue_t *q, struct PTHREAD_HANDLE *h )
{
   h->prev_th->next_th = h->next_th;
   h->next_th->prev_th = h->prev_th;

   h->next_th = NULL;
   h->prev_th = NULL;
   q->thread_count -= 1;
}

static void
x_unlink_last_thread( thread_queue_t *q )
{
   struct PTHREAD_HANDLE *h;

   h = q->last_thread;
   q->last_thread = h->prev_th;

   h->prev_th->next_th = NULL;
   h->prev_th = NULL;
   q->thread_count -= 1;
}

/*
 * --  This service fails if the target thread isn't on the queue.
 */
static int
x_unlink_thread( thread_queue_t *q, struct PTHREAD_HANDLE *h )
{
   int status = FAILURE;

   if( q->thread_count == 0 )
       return( status );

   if( h == q->first_thread )
       x_unlink_first_thread( q );

   else if( h == q->last_thread )
       x_unlink_last_thread( q );

   else
       x_unlink_middle_thread( q, h );

   return( SUCCESS );
}

static int
x_thread_on_queue( thread_queue_t *q, counter_t thread_id )
{
   struct PTHREAD_HANDLE *curr;
   int on_queue = FALSE;

   if( q->thread_count == 0 )
       return( on_queue );
   /*
    *  --  Traverse the queue until we find a thread with a matching
    *      identity.
    */
   curr = q->first_thread;
   while( curr->id != thread_id && curr->next_th != NULL )
       curr = curr->next_th;

   if( curr->id == thread_id )
       on_queue = TRUE;

   return( on_queue );
}

/*
 * --  Insert a thread at the end of a queue.
 */
static void
x_enqueue_thread( thread_queue_t *q, struct PTHREAD_HANDLE *h )
{
   if( q->thread_count )
   {
      h->prev_th = q->last_thread;     /* Point h to the last node */
      q->last_thread->next_th = h;     /* Point the last node to h */
      q->last_thread = h;              /* Update the list head to point to h */ 
   }
   else
   {
       q->first_thread = h;
       q->last_thread = h;
       h->prev_th = NULL;
       h->next_th = NULL;
   }

   q->thread_count += 1;
}

/*
 * --  Remove a thread from the head of the queue.  NULL is returned
 *     if no threads remain on the queue.
 */
static struct PTHREAD_HANDLE *
x_dequeue_thread( thread_queue_t *q )
{
   struct PTHREAD_HANDLE *h = NULL;

   if( q->thread_count == 0 )
       return( h );

   h = q->first_thread;
   x_unlink_first_thread( q );

   return( h );
}

static int
x_yank_thread( thread_queue_t *q, counter_t thread_id )
{ 
   struct PTHREAD_HANDLE *h;
   int on_queue = FALSE;

   if( q->thread_count == 0 )
       return( on_queue );
   /*
    *  --  Traverse the queue until we find the thread with the matching
    *      identity.
    */
   h = q->first_thread;
   while( h->id != thread_id && h->next_th != NULL )
       h = h->next_th;

   if( h->id == thread_id )
   {
       x_unlink_thread( q, h );
       on_queue = TRUE;
   }

   return( on_queue );
}

void
init_prio_queue( priority_queue_t *rq )
{
   int i;

   for(i = PTHREAD_IDLE_PRIO_C; i <= PTHREAD_MAX_PRIO_C; i++ )
   {
       rq->prio[i].thread_count = 0;
       rq->prio[i].first_thread = NULL;
       rq->prio[i].last_thread = NULL;
   }

   rq->elements = 0;
}
       
int
get_highest_prio( priority_queue_t *rq )
{
   int i, prio = PTHREAD_IDLE_PRIO_C;

   for(i = PTHREAD_MAX_PRIO_C; i >= PTHREAD_IDLE_PRIO_C; i-- )
   {
       if( rq->prio[i].thread_count > 0 )
       {
           prio = i;
           break;
       }
   }

   return( prio );
}

void
enqueue_thread( priority_queue_t *rq, struct PTHREAD_HANDLE *th )
{
   int sched_prio;

   sched_prio = th->obj.sched_param.sched_priority;
   x_enqueue_thread( &rq->prio[ sched_prio ], th );   
   rq->elements += 1;
}

struct PTHREAD_HANDLE *
dequeue_thread( priority_queue_t *rq )
{
   struct PTHREAD_HANDLE *th = NULL;
   int i;

   for(i = PTHREAD_MAX_PRIO_C; i >= PTHREAD_IDLE_PRIO_C; i-- )
   {
       if( (th = x_dequeue_thread( &rq->prio[i] )) != NULL )
       {
           rq->elements -= 1;
           break;
       }
   }

   return( th );
}

int
yank_thread( priority_queue_t *rq, struct PTHREAD_HANDLE *th )
{
   int status = FAILURE, sched_prio;

   sched_prio = th->obj.sched_param.sched_priority;
   if( x_thread_on_queue( &rq->prio[sched_prio], th->id ))
   {
       x_yank_thread( &rq->prio[sched_prio], th->id );
       rq->elements -= 1;
       status = SUCCESS;
   }

   return( status );
}

int
thread_on_queue( priority_queue_t *pq, struct PTHREAD_HANDLE *th )
{
   int on_queue = FALSE, sched_prio;

   sched_prio = th->obj.sched_param.sched_priority;
   if( x_thread_on_queue( &pq->prio[sched_prio], th->id ))
       on_queue = TRUE;

   return( on_queue );
}
