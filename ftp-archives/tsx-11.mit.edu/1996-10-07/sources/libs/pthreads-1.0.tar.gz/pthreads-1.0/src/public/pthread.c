#ifndef lint
static const char rcsid[] = "$Id: pthread.c,v 1.1.1.1 1996/06/29 01:20:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: pthread.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:53  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:13  mtp
 * + Release 2.0
 *
 * Revision 1.4  1996/01/14 20:22:54  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.3  1996/01/14 18:32:44  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.2  1995/12/31 06:20:22  mtp
 * + Removed stack checking code at thread rundown.
 * + Moved code that logged a message when a thread exited with a locked
 *   mutex.  This was necessary because threads that were releasing mutexes
 *   as a part of popping cancellation handlers weren't generating this
 *   message.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include "pthread.h"
#include "error.h"
#include "thread.h"
#include "mutex.h"
#include "condv.h"
#include "nub.h"
#include "machdep.h"
#include "priority_q.h"
#include "posix_signal.h"
#include "cleanup.h"
#include "public.h"

static void x_internal_exit( void *exit_arg );
extern char *sys_errlist[];

extern thread_attr_obj_t *
get_default_th_attr_obj( void );           /* Imported from objects.c */

extern mutex_attr_obj_t *
get_default_mu_attr_obj( void );           /*  Same as previous */

extern condv_attr_obj_t *
get_default_cv_attr_obj( void );           /* Same as previous */

extern void
call_thread_destructors( const struct PTHREAD_HANDLE *h );

int  
pthread_create( pthread_t      *handle,
                pthread_attr_t *th_attr,
                void *         (*th_proc)(void *),
                void *         th_proc_arg )
{
	struct PTHREAD_HANDLE *new_th = NULL, *active_th;
	thread_attr_obj_t *attr_obj = NULL;
	int st, flag;

	if( (st = system_init()) != SUCCESS )
		return( st );

	sys_disable_ctxsw( flag );
	if( handle == NULL )
	{
		set_thread_errno( EINVAL );
		RETURN( EINVAL );
	}

	active_th = nub_get_active_thread();
	if( th_attr == NULL )
	{
		/*
		 * If the parent thread's inherit_sched flag is TRUE, use the
		 * parent's attributes when creating this thread.  Otherwise,
		 * use the default attributes supplied by the runtime.
		 */
		if( active_th->obj.attr_obj.inherit_sched )
			attr_obj = &active_th->obj.attr_obj;
		else
			attr_obj = get_default_th_attr_obj();
	}
	else
	{
		if( *th_attr == NULL || (*th_attr)->type != ATTR_C )
		{
			set_thread_errno( EINVAL );
			RETURN( EINVAL );
		}

		attr_obj = (*th_attr)->obj;
	}

	/*
	 * Allocate and initialize a thread handle data structure.
	 */
	new_th = allocate_handle( THREAD_C );
	if( new_th == NULL )
	{
		set_thread_errno( EAGAIN );
		RETURN( EAGAIN );
	}

	new_th->type = THREAD_C;

	if( attr_obj->stack_size == 0 )
		new_th->id = 1;

	new_th->id = init_th_obj( &new_th->obj, 
                                   attr_obj,
                                   th_proc, 
                                   th_proc_arg );
	if( new_th->id == 0 )
	{
		if( new_th->obj.errno == 0 )    /* Couldn't allocate enough memory */
			set_thread_errno( EAGAIN ); /* for the stack */

		free_handle( new_th );
		RETURN( EAGAIN );
	}

	/*
	 * Inherit the parent thread's signal mask.
	 */
	new_th->obj.current_sigs = active_th->obj.current_sigs;


	/*
	 *  --  Enqueue the new thread on the ready queue.
	 */
	new_th->obj.thread_state = THREAD_READY_C;
	LOG( new_th, "created->ready");
	enqueue_thread( &thread_rq, new_th );

	*handle = new_th;

	/*
	 *  --  If a higher priority thread is now on the ready queue (e.g., the
	 *      child thread that was just created) then change the state of the
	 *      active thread to THREAD_READY_C and reschedule.
	 */
	if( new_th->obj.sched_param.sched_priority > nub_get_active_prio() )
	{
		struct PTHREAD_HANDLE *active_th;

		active_th = nub_get_active_thread();
		active_th->obj.thread_state = THREAD_READY_C;

		nub_reschedule( active_th );
	}

	RETURN( SUCCESS );
}

/*  
 *  -- A thread may wait for the completion of another and obtain the return
 *     value of its action routine, if any.
 */
int  
pthread_join( pthread_t handle, void **return_value )
{
   int st, flag;
   struct PTHREAD_HANDLE *active_th;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );

   /*
    *  --  Ensure that the handle referencing the thread to be joined is valid.
    */
   if( handle == NULL || handle->type != THREAD_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   if( handle == (active_th = nub_get_active_thread()) )
   {
       set_thread_errno( EDEADLK );
       RETURN( EDEADLK );
   }

   /*
    *  --  Return harmlessly if the target thread is not joinable, i.e.,
    *      has already been detached.
    */
   if( handle->obj.detached_state != PTHREAD_CREATE_JOINABLE )
   {
       if( return_value )
           *return_value = NULL;

       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   handle->obj.join_count += 1;

   /*
    *  --  Block the current thread at the target thread's condition 
    *      variable until signaled.  After the last thread has completed
    *      its join, set the target thread to PTHREAD_DETACHED_C.
    */
   if( handle->obj.thread_state != THREAD_COMPLETE_C )
   {
       if( pthread_mutex_lock( &handle->obj.join_mutex ) != SUCCESS )
           RETURN( active_th->obj.errno );

       if( pthread_cond_wait( &handle->obj.join_condv, &handle->obj.join_mutex ) != SUCCESS )
           RETURN( active_th->obj.errno );

       if( pthread_mutex_unlock( &handle->obj.join_mutex ) != SUCCESS )
           RETURN( active_th->obj.errno );
   }

   handle->obj.join_count -= 1;
   if( handle->obj.join_count == 0 )
       handle->obj.detached_state = PTHREAD_CREATE_DETACHED;

   if( return_value )
       *return_value = handle->obj.exit_value;   

   RETURN( SUCCESS );
}

/*
 *  --   Detach a thread. Once detached, a thread may not be joined.
 */
int  
pthread_detach( pthread_t  handle )
{
   int st, flag;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || handle->type != THREAD_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   /*
    *  --  If the thread has completed and no threads are joined, 
    *      utterably destroy it.
    */
   if( handle->obj.thread_state == THREAD_COMPLETE_C && 
       handle->obj.join_count  == 0 )
   {
       st = nub_reclaim_thread( handle );
       RETURN( st );
   }

   /*
    *  --  The thread has not yet completed.  Set the detached_state flag so
    *      that it may not be joined.  This routine may have been called after
    *      one or more threads have already requested to join with it.  
    */
   handle->obj.detached_state = PTHREAD_DETACHED_C;
   RETURN( SUCCESS );
}

/*
 *  --   Execute a one-time library initialization.
 */
int 
pthread_once( pthread_once_t  *once_control, 
              void (*init_routine)(void) )
{
   int st, flag = 0;

   if( (st = system_init()) != SUCCESS )
       return( st );

   /*
    *  --  Atomically read and evaluate the 'once_control'
    *      flag.  Return if it's been set.
    */
   if( sys_test_and_set( once_control ) == SEMAPHORE_C_SET )
       return( SUCCESS );
       
   sys_disable_ctxsw( st );

   (*init_routine)();
   RETURN( SUCCESS );
}

int  
pthread_setschedparam( pthread_t handle, 
                       int new_policy, 
                       const struct sched_param *param )
{
   struct PTHREAD_HANDLE *active_th;
   pthread_mutex_t *mu;
   pthread_cond_t *cv;
   int st, flag, sched_prio, ctxsw_required = FALSE;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || handle->type != THREAD_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   /*
    *  --  Check the thread's state.  If it's on the ready, blocked, or
    *      waiting queues, we have to yank it and reinsert at its new
    *      priority.  Of course, if the thread is on the ready queue, then
    *      then we must check to see whether, as a result of changing the
    *      priority of the thread, a context switch is required.
    *      Finally, if the thread is the active thread, then all we need to
    *      do is adjust its priority and, if we the priority was increased, 
    *      check whether a context switch is required.
    */
   sched_prio = handle->obj.sched_param.sched_priority;
   switch( handle->obj.thread_state )
   {
       case THREAD_WAITING_C:
           cv = handle->obj.cv_waiting_at;
           yank_thread( &(*cv)->obj.waiting_threads, handle );

           /*
            *  --  Change the parameters in the thread object data structure.
            */
           memcpy( &handle->obj.sched_param, 
                   param, 
                   sizeof( struct sched_param ));
           handle->obj.sched_param.sched_policy = new_policy;           
           enqueue_thread( &(*cv)->obj.waiting_threads, handle );
       break;

       case THREAD_BLOCKED_C:
           mu = handle->obj.mu_blocked_at;
           yank_thread( &(*mu)->obj.blocked_threads, handle );

           /*
            *  --  Change the parameters in the thread object data structure.
            */
           memcpy( &handle->obj.sched_param, 
                   param, 
                   sizeof( struct sched_param ));
           handle->obj.sched_param.sched_policy = new_policy;           
           enqueue_thread( &(*mu)->obj.blocked_threads, handle );
       break;

       case THREAD_READY_C:
           yank_thread( &thread_rq, handle );

           /*
            *  --  Change the parameters in the thread object data structure.
            */
           memcpy( &handle->obj.sched_param, 
                   param, 
                   sizeof( struct sched_param ));
           handle->obj.sched_param.sched_policy = new_policy;           
           enqueue_thread( &thread_rq, handle );

           /*
            *  -- Check whether a context switch is now required.
            */
           if( sched_prio < get_highest_prio(&thread_rq))
               ctxsw_required = TRUE;
       break;

       case THREAD_ACTIVE_C:
           memcpy( &handle->obj.sched_param, 
                   param, 
                   sizeof( struct sched_param ));

           /*
            *  -- Check whether a context switch is now required.
            */
           if( sched_prio < get_highest_prio(&thread_rq))
               ctxsw_required = TRUE;
       break;

       case THREAD_DELAYED_C:
       case THREAD_COMPLETE_C:
       default:
           memcpy( &handle->obj.sched_param, 
                   param, 
                   sizeof( struct sched_param ));
       break;
   }

   /*
    *  -- After all this if a context switch is now required "make it so!"
    */
   if( ctxsw_required )
   {
       active_th = nub_get_active_thread();
       active_th->obj.thread_state = THREAD_READY_C;
       nub_reschedule( active_th );
   }

   RETURN( SUCCESS );
}

int  
pthread_getschedparam( pthread_t handle, 
                       int *current_policy, 
                       struct sched_param *param )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || handle->type != THREAD_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   *current_policy = handle->obj.sched_param.sched_policy;
   memcpy( param, &handle->obj.sched_param, sizeof( struct sched_param ));
   RETURN( SUCCESS );
}

/* 
 *  -- Client threads may obtain their own handles
 */
pthread_t
pthread_self( void )
{
   struct PTHREAD_HANDLE *handle;
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( NULL );

   sys_disable_ctxsw( flag );
   handle = nub_get_active_thread();
   RETURN( (pthread_t)handle );
}

/* 
 *  -- Client threads may unconditionally yield the processor to all
 *     threads of equal or higher priority.  POSIX requires arg to be
 *     equal to NULL.
 */
void  
pthread_yield( void  *arg )
{
   struct PTHREAD_HANDLE *active_th;
   int prio, flag = 0, st;

   if( system_init() != SUCCESS )
       return;

   sys_disable_ctxsw( st );
   active_th = nub_get_active_thread();

   /*
    *  --  If the active thread is of equal or lower priority than
    *      any thread on the ready queue, execute a reschedule operation.
    */
   if( (prio = get_highest_prio( &thread_rq )) > 0 )
   {
       if( active_th->obj.sched_param.sched_priority <= prio )
       {
           active_th->obj.thread_state = THREAD_READY_C;
           nub_reschedule( active_th );
       }
   }

   VRETURN;
}

/*
 *  --   Client applications may test two threads for equality
 */
int  
pthread_equal( pthread_t th1_handle, pthread_t th2_handle )
{
   int flag, st;

   if( (st = system_init()) != SUCCESS )
       return( st );

   sys_disable_ctxsw( flag );
   RETURN( th1_handle == th2_handle );
}

void
pthread_cleanup_push( void (*cleanup)(void *), void *arg )
{
   struct PTHREAD_HANDLE *active_th;
   int flag;

   (void) system_init();

   sys_disable_ctxsw( flag );
   active_th = nub_get_active_thread();
   push_cleanup( &active_th->obj.cleanup_stack, 
                 (cleanup_t) cleanup, 
                 arg );

   VRETURN;
}

void
pthread_cleanup_pop( int execute )
{
   struct PTHREAD_HANDLE *active_th;
   int flag;

   (void) system_init();

   sys_disable_ctxsw( flag );
   active_th = nub_get_active_thread();
   pop_cleanup( &active_th->obj.cleanup_stack, execute );

   VRETURN;
}

/*
 *  --   A thread may terminate itself and pass a status value back to any 
 *       thread that is waiting for it to complete (i.e., via the
 *       pthread_join() service ).
 */
void  
pthread_exit( void *exit_value )
{
   x_internal_exit( exit_value );
}

void
thread_exit_proc( void )
{
   x_internal_exit( sys_get_return_value() );
}
 
static void
x_internal_exit( void *exit_value )
{
   int flag, detached_state, join_count, exit_status = SUCCESS;
   struct PTHREAD_HANDLE *active_th;

   sys_disable_ctxsw( flag );
   active_th = nub_get_active_thread();

   /*
	* Execute any/all cleanup handlers.
	*/
   while( pop_cleanup( &active_th->obj.cleanup_stack, 1 ))
	   ;

   active_th->obj.exit_value = exit_value;
   active_th->obj.thread_state = THREAD_COMPLETE_C;
   /*
    *  --  First, remove any/all of the thread's private data
    *      objects.
    */
   call_thread_destructors( active_th );

   detached_state = active_th->obj.detached_state;
   join_count = active_th->obj.join_count;
   if( detached_state == PTHREAD_CREATE_JOINABLE && join_count > 0 )
   {
       (void) pthread_mutex_lock( &active_th->obj.join_mutex );
       (void) pthread_cond_broadcast( &active_th->obj.join_condv );
       (void) pthread_mutex_unlock( &active_th->obj.join_mutex );
   }

    /*
     * Check whether, after popping the cleanup handlers AND executing
     * all of this thread's private data destructors, any mutexes remain
     * locked.  If so, allow the exit to proceed but print a warning
     * to stdout.
     */
   if( active_th->obj.locked_mutexes.mutex_count )
   {
       char buf[64];
       sprintf( buf,"th[%ld]: %s", active_th->id, 
                                   get_system_err_msg( ERR_C_EXIT_W_LOCK ));
       errlog( NULL, buf );
   }

   if( active_th->id != PTHREAD_INITIAL_ID_C && 
       active_th->id != PTHREAD_IDLE_ID_C )
   {
       nub_reschedule( active_th );
   }

   LOG( active_th, "Application terminated");
   if( (int) exit_value != 0 )
       exit_status = FAILURE;

   _exit( exit_status );
}
