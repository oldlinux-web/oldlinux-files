/*
 * $Id: dbgmem.h,v 1.1.1.1 1996/06/29 01:20:51 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: dbgmem.h,v $
 * Revision 1.1.1.1  1996/06/29 01:20:51  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:01  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:41  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:28  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#ifndef _dbgmem_
#define _dbgmem_
#include <stdlib.h>
#include <stdio.h>
#include "machdep.h"

extern void * malloc( size_t );
extern void free( void * );

typedef enum DBGMEM_STATUS
{
   DBGMEM_S_FAILURE = -1,
   DBGMEM_S_SUCCESS = 0

} dbgmem_status_t;

typedef enum DBGMEM_CODE
{
   DBGMEM_E_PREFIX_CORRUPT,
   DBGMEM_E_SUFFIX_CORRUPT,
   DBGMEM_E_NULL_PTR,
   DBGMEM_E_PREV_DEALLOCATED

} dbgmem_error_t;

/*
 *     --  Prototypes for the all the debugging allocation functions.
 *         These should not be directly called by application code.  Instead,
 *         use the macros defined below.
 */
extern void *
dbg_malloc(size_t, char *, int);

extern void *
dbg_calloc( size_t, size_t, char *, int );

extern dbgmem_status_t
dbg_free( void *, dbgmem_error_t * );

extern char *
dbg_error_str( dbgmem_error_t error );

extern void
dbg_memstats( void );

extern long
dbg_allo_mem( void );

extern long
dbg_accum_mem( void );

extern  long
dbg_requests( void );

extern void
dbg_set_threshold( long new_threshold );

extern long
dbg_get_threshold( void );

extern void
dbg_cancel_threshold( void );

extern void
dbg_dump_chain( void );

/*
 * --  Define wrapper macros for all the allocation functions.
 */
#undef MALLOC
#undef CALLOC
#undef FREE

#if 0
#define MALLOC(size) \
        ({ int flag = sys_set_critical_flag(); \
         dbg_malloc( (size), __FILE__, __LINE__); \
         sys_restore_critical_flag( flag ); \
})
#endif

#define CALLOC(nelem, size)    dbg_calloc(nelem, size, __FILE__, __LINE__)
#define MALLOC(size)  dbg_malloc( (size), __FILE__, __LINE__)

#define CHECK_MALLOC(ptr) \
        { \
           if((ptr) == NULL ) \
               fprintf( stderr, "DBGMEM:no more memory!\n"); \
        }

#define FREE(ptr) \
        ({ \
           dbgmem_error_t err; \
           if( dbg_free(ptr, &err) != DBGMEM_S_SUCCESS ) \
               fprintf(stderr, "%s\n", dbg_error_str(err) ); \
        })
#endif
