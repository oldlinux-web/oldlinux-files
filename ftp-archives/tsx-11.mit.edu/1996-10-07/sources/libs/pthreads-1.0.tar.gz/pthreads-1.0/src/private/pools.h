/*
 * $Id: pools.h,v 1.1.1.1 1996/06/29 01:20:52 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: pools.h,v $
 * Revision 1.1.1.1  1996/06/29 01:20:52  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:04  mtp
 * + Release 2.0
 *
 * Revision 1.4  1996/01/14 20:22:44  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.3  1996/01/14 18:32:32  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.2  1996/01/14 18:00:12  mtp
 * + Removed @@ comment tokens.
 *
 * Revision 1.1.1.1  1995/12/16 21:41:59  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#ifndef _pools_
#define _pools_

#include "private.h"

/*
 * --  The list head of a pool of threads (A simple singly-linked list
 *     in this version).
 */
typedef struct THREAD_POOL
{
   struct PTHREAD_HANDLE   *first_thread;
   counter_t               thread_count;

} thread_pool_t;   

typedef struct MUTEX_POOL
{
   struct PTHREAD_MUTEX_HANDLE *first_mutex;
   counter_t                    mutex_count;

}  mutex_pool_t;

typedef struct CONDV_POOL
{
   struct PTHREAD_CONDV_HANDLE *first_condv;
   counter_t                    condv_count;

} condv_pool_t;

/*
 * --  Remove the first thread from a pool of threads.  If no threads
 *     remain, NULL is returned.
 */
struct PTHREAD_HANDLE *
remove_first_thread_from_pool( thread_pool_t *pool );

/*
 * --  Remove a thread from a pool of threads.  If the thread is found 
 *     in the pool and removed, a value of SUCCESS is returned.  Otherwise, 
 *     a value of FAILURE is returned.
 */
extern int
remove_thread_from_pool( thread_pool_t *pool, counter_t thread_id );

/*
 * --  Given a thread identity (i.e., a thread sequence number), return
 *     a pointer to its handle structure.  This service *DOES NOT*
 *     remove the handle from the pool.
 */
extern struct PTHREAD_HANDLE *
return_thread_from_pool( thread_pool_t *pool, counter_t thread_id );

/*
 * --  Insert a thread into a pool of threads.  Pools are implemented as
 *     simple, singly-linked lists.  A more performance sensitive
 *     implementation would implement pools as splay trees keyed on the
 *     thread identity.
 */
extern void
insert_thread_into_pool( thread_pool_t *pool, struct PTHREAD_HANDLE *h );

/*
 * --  Same three services for pools of mutexes.
 */
extern struct PTHREAD_MUTEX_HANDLE *
remove_first_mutex_from_pool( thread_pool_t *pool ); /* Not implemented */

extern int
remove_mutex_from_pool( mutex_pool_t *pool, counter_t mutex_id );

extern struct PTHREAD_MUTEX_HANDLE *
return_mutex_from_pool( mutex_pool_t *pool, counter_t mutex_id );

extern void
insert_mutex_into_pool( mutex_pool_t *pool, struct PTHREAD_MUTEX_HANDLE *h );

/*
 * --  ...And finally the condition variable pool services.
 */
extern struct PTHREAD_CONDV_HANDLE *
remove_first_condv_from_pool( thread_pool_t *pool );  /* Not implemented */

extern int
remove_condv_from_pool( condv_pool_t *pool, counter_t condv_id );

extern struct PTHREAD_CONDV_HANDLE *
return_condv_from_pool( condv_pool_t *pool, counter_t condv_id );

extern void
insert_condv_into_pool( condv_pool_t *pool, struct PTHREAD_CONDV_HANDLE *h );

#endif
