#ifndef lint
static const char rcsid[] = "$Id: pthread_signal.c,v 1.1.1.1 1996/06/29 01:20:54 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: pthread_signal.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:54  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:15  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:56  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:46  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include <signal.h>
#include "pthread.h"
#include "nub.h"
#include "machdep.h"
#include "public.h"
#include "sigwait.h"

extern void
sig_common_handler( int sig );

extern void
execute_sigaction( int sig, struct PTHREAD_HANDLE *th );

extern int
allowed( int sig );

int
pthread_sigmask( int how, const sigset_t *new, sigset_t *prev )
{
	struct PTHREAD_HANDLE *active_th;
	int i, flag, st;

	if( (st = system_init()) == FAILURE )
		return( st );

	sys_disable_ctxsw( flag );

	/*
	 * Save the current signal mask, if specified,
	 */
	active_th = nub_get_active_thread();
	if( prev )
		*prev = active_th->obj.current_sigs;

	if( !new )
		RETURN( st );

	switch( how )
	{
	  /* 
	   * Make the current mask the union of the current and new masks.
	   */
	  case SIG_BLOCK:
		active_th->obj.current_sigs |= *new;
		break;

	  /*
	   * For every signal in the new mask, unblock the bit in the current
	   * mask. NB: if one or more pending signals are unmasked, then at least
	   * one of those signals *must* be delivered to the process.
	   */
	  case SIG_UNBLOCK:
		active_th->obj.current_sigs &= ~(*new);

		for(i = 1; i < NSIG; i++ )
		{
			if( !sigismember( &active_th->obj.current_sigs, i ) &&
			     sigismember( &active_th->obj.pending_sigs, i ) )
			{
				if( allowed( i ) == FALSE )
					execute_sigaction( i, active_th );
				else
					sig_common_handler( i );

				break;
			}
		}

		break;

	  /*
	   * Make the new mask the current mask.  As for the SIG_UNBLOCK case,
	   * deliver one of any pending signals that have been unmasked.
	   */
	  case SIG_SETMASK:
		active_th->obj.current_sigs = *new;


		for(i = 1; i < NSIG; i++ )
		{
			if( !sigismember( &active_th->obj.current_sigs, i ) &&
			     sigismember( &active_th->obj.pending_sigs, i ) )
			{
				if( allowed( i ) == FALSE )
					execute_sigaction( i, active_th );
				else
					sig_common_handler( i );

				break;
			}
		}

		break;
	
	  default:
		st = EINVAL;
		break;
	}

	RETURN( st );
}

/*
 * Block a thread until one of the signals in sigset becomes pending.
 */
int
sigwait( sigset_t sigset )
{
   struct PTHREAD_HANDLE *active_th;
   int i, st, flag, sig;

   if( (st = system_init()) != SUCCESS )
       return( st );


   sys_disable_ctxsw( flag );
   active_th = nub_get_active_thread();
   sys_restore_ctxsw( flag );

   /*
	* Perform error checking on the signal set.
    */
   for(i = 1; i < NSIG; i++ )
   {
	   /*
		* Ensure that the calling thread has properly blocked the
		* signals for which it wants to wait.  In otherwords, every
		* member of the sigset must ALSO be present in the thread's
		* signal mask, but not necessarily vice versa.
		*/
	   if( sigismember( &sigset, i ) &&
		  !sigismember( &active_th->obj.current_sigs, i ))
	   {
		   return( EINVAL );
	   }
   }

   /*
	* Check whether any of the signals in sigset, have become pending
    * in the thread's set of pending signals.  If so, clear the signal
	* from the caller's set of pending signals and return. No wait is
	* necessary.
	*/
   for(i = 1; i < NSIG; i++ )
   {
	   if( sigismember( &sigset, i ) && 
		   sigismember( &active_th->obj.pending_sigs, i ) )
	   {
		   sigdelset( &active_th->obj.current_sigs, i );
		   sigdelset( &active_th->obj.pending_sigs, i );
		   return( i );
	   }
   }

   /*
    *  --  Now wait until we are signaled.
    */
   sig = sig_wait_thread( sigset, active_th );
   sigdelset( &active_th->obj.pending_sigs, sig );

   return( sig );
}

int
pthread_kill( pthread_t th_h, int sig )
{
	int flag, st;
	struct PTHREAD_HANDLE *active_th;

	if( (st = system_init()) == FAILURE )
		return( st );

	if( sig < 0 || sig > (NSIG - 1) )
		return( EINVAL );

	if( sig == 0 )
	{
		/*
		 * If th_h isn't NULL, then we need to check whether th_h references
		 * a valid thread.  If it doesn't, return EINVAL.
		 */
		if( &th_h->obj != NULL )
		{
			if( th_h->obj.thread_state != THREAD_COMPLETE_C )
				st = SUCCESS;
			else
				st = EINVAL;
		}

		return( st );
	}
	sys_disable_ctxsw( flag );

	if( th_h == NULL )
		th_h = nub_get_active_thread();

	/*
	 * If the target thread is not currently active, then add this signal
	 * to the thread's set of pending signals and return.  The target thread
	 * will take the signal when it becomes active.
	 */
	if( th_h->obj.thread_state != THREAD_ACTIVE_C )
	{
		sigaddset( &th_h->obj.pending_sigs, sig );
		RETURN( SUCCESS );
	}
	    
	/*
	 * If the thread has the signal currently blocked, add it to its set of
	 * pending signals and return.
	 */
	if( sigismember( &th_h->obj.current_sigs, sig ) )
	{
		/*
		 * The thread currently has the signal blocked. Add the
		 * signal to the thread's set of pending signals and
		 * then pass the signal on to the process.  The process
		 * will call sig_common_handler() and, if a thread is
		 * waiting in a sigwait(), the right thing will happen.
		 */
		sigaddset( &th_h->obj.pending_sigs, sig );
		RETURN( SUCCESS );
	}

	/*
	 * The thread is active, i.e., on a uniprocessor we're sending the signal
	 * to ourself.
	 */
	if( allowed( sig ) == FALSE )
	{
		active_th = nub_get_active_thread();
		execute_sigaction( sig, active_th );
	}
	else
		sig_common_handler( sig );

	RETURN( SUCCESS );
}






