#ifndef lint
static const char rcsid[] = "$Id: pthread_mutex.c,v 1.1.1.1 1996/06/29 01:20:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Redmond, WA.
 *  13 January, 1996
 ****************************************************************************
 * $Log: pthread_mutex.c,v $
 * Revision 1.1.1.1  1996/06/29 01:20:53  mtp
 * pthreads 1.0 distribution
 *
 * Revision 1.1.1.1  1996/06/28 15:45:41  mtp
 * Official V1.0 Sources
 *
 * Revision 2.0  1996/06/28 14:58:14  mtp
 * + Release 2.0
 *
 * Revision 1.3  1996/01/14 20:22:55  mtp
 * + Modified copyright and permission notice to conform with GNU requirements.
 *
 * Revision 1.2  1996/01/14 18:32:45  mtp
 * + Replaced @Header@ with COPYRIGHT NOTICE.
 *
 * Revision 1.1.1.1  1995/12/16 21:42:00  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#include "pthread.h"
#include "public.h"
#include "thread.h"
#include "mutex.h"
#include "nub.h"
#include "error.h"

extern mutex_attr_obj_t *  get_default_mu_attr_obj( void );

int
unlock_mutex_struct( struct PTHREAD_MUTEX_HANDLE *mu_h, 
                     struct PTHREAD_HANDLE *active_th )
{
   struct PTHREAD_HANDLE *unblocked_th;
   int st;

   st = remove_mutex_from_pool( &active_th->obj.locked_mutexes, mu_h->id );
   if( st == FAILURE )
   {
       set_thread_errno( ESRCH );
       return( ESRCH );
   }

   /*
    *  --  Select the highest priority blocked thread, remove it from the
    *      queue of threads blocked at the mutex, transfer ownership of
    *      the mutex, and move the unblocked thread onto the ready queue.  
    */
   unblocked_th = dequeue_thread( &mu_h->obj.blocked_threads );
   if( unblocked_th )
   {
       mu_h->obj.active_th = unblocked_th;
       mu_h->obj.accum_lock_count += 1;
       mu_h->obj.ref_count += 1;
       
       insert_mutex_into_pool( &unblocked_th->obj.locked_mutexes, mu_h );
       unblocked_th->obj.thread_state = THREAD_READY_C;
       enqueue_thread( &thread_rq, unblocked_th );
       LOG(unblocked_th,"blocked->ready");
   }
   else
   {
       /*
        * No threads were blocked at this mutex.  Clear all of the state
        * and return.
        */
       mu_h->obj.active_th = NULL;
       mu_h->obj.ref_count -= 1;
       sys_reset( &mu_h->obj.lock );
   }

   return( SUCCESS );
}

int  
pthread_mutex_init( pthread_mutex_t  *handle, 
                    pthread_mutexattr_t  *mu_attr_h )
{
   struct PTHREAD_MUTEX_HANDLE *mu_h;
   mutex_attr_obj_t *mu_attr_obj;
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   if( mu_attr_h == NULL )
       mu_attr_obj = get_default_mu_attr_obj();
   else
   {
       if( (*mu_attr_h)->type != MUTEX_ATTR_C )
       {
           set_thread_errno( EINVAL );
           RETURN( EINVAL );
       }

       mu_attr_obj = (*mu_attr_h)->obj;
   }

   if((mu_h = allocate_handle( MUTEX_C )) == NULL )
   {
       set_thread_errno( ENOMEM );
       RETURN( ENOMEM );
   }

   mu_h->type = MUTEX_C;
   mu_h->id = init_mu_obj( &mu_h->obj, mu_attr_obj );
   *handle = mu_h;

   RETURN( SUCCESS );
}

int  
pthread_mutex_destroy( pthread_mutex_t  *handle )
{
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );
   if( handle == NULL || (*handle)->type != MUTEX_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   if( sys_test_and_set( &(*handle)->obj.lock ) == SEMAPHORE_C_SET )
   {
       set_thread_errno( EBUSY );
       RETURN( EBUSY );
   }

   sys_reset( &(*handle)->obj.lock );
   if( (*handle)->obj.blocked_threads.elements != 0 )
   {
       set_thread_errno( EBUSY );
       RETURN( EBUSY );
   }

   /*
    *  --  OK!  No thread holds the mutex, no thread is blocked at the
    *      mutex, and the mutex is unlocked.  Go ahead and destroy the
    *      the mutex.
    */
   destroy_mu_obj( &(*handle)->obj );
   free_handle( *handle );
   handle = NULL;

   RETURN( SUCCESS );
}

int  
pthread_mutex_trylock( pthread_mutex_t  *mu_h )
{
   struct PTHREAD_HANDLE *active_th;
   struct PTHREAD_MUTEX_HANDLE *handle;

   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );
   if( mu_h == NULL )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   handle = *mu_h;

   if( handle == NULL || handle->type != MUTEX_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   if( sys_test_and_set( &handle->obj.lock) == SEMAPHORE_C_SET)
       RETURN(EBUSY);

   /*
    *  --  Lock the mutex, add it to the pool of locked mutexes already
    *      held by this thread, and register the thread's handle with the
    *      mutex.  This way we can find the mutex if we have the thread or
    *      can find the thread if we have the mutex.
    */
   active_th = nub_get_active_thread();
   insert_mutex_into_pool( &active_th->obj.locked_mutexes, handle );
   handle->obj.active_th = active_th;
   handle->obj.accum_lock_count += 1;
   handle->obj.ref_count += 1;

   RETURN( SUCCESS );
}

int 
pthread_mutex_getprio_ceiling( pthread_mutex_t mu_h )
{
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );
   RETURN( ENOSYS );
}

int 
pthread_mutex_setprio_ceiling( pthread_mutex_t  *mu_h, int prio_ceiling )
{
   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );
   RETURN( ENOSYS );
}

int  
pthread_mutex_lock( pthread_mutex_t  *mu_h )
{
   struct PTHREAD_HANDLE *active_th;
   struct PTHREAD_MUTEX_HANDLE *handle;

   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );
   if( mu_h == NULL )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   handle = *mu_h;

   if( handle == NULL || handle->type != MUTEX_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   active_th = nub_get_active_thread();
   if( sys_test_and_set( &handle->obj.lock) == SEMAPHORE_C_SET)
   {
       /*
        *  --  The mutex has already been locked.  Check that we're not 
        *      trying to lock a mutex that we already hold.  Later, when
        *      recursive mutexes are supported, we'll have to revisit this
        *      logic.
        */
       if( handle->obj.active_th == active_th )
       {
           set_thread_errno( EDEADLK );
           RETURN( EDEADLK );
       }

       /*
        *  --  Enqueue the active thread to the mutex's queue of blocked
        *      threads, change the thread's state to BLOCKED and
        *      context switch to the next ready thread.
        */
       enqueue_thread( &handle->obj.blocked_threads, active_th );
       active_th->obj.thread_state = THREAD_BLOCKED_C;
       active_th->obj.mu_blocked_at = mu_h;
       nub_reschedule( active_th );
   }
   else
   {
       /*
        *  --  Lock the mutex, add it to the pool of locked mutexes already
        *      held by this thread, and register the thread's handle with the
        *      mutex.  This way we can find the mutex if we have the thread or
        *      can find the thread if we have the mutex.
        */
      insert_mutex_into_pool( &active_th->obj.locked_mutexes, handle );
      handle->obj.active_th = active_th;
      handle->obj.accum_lock_count += 1;
      handle->obj.ref_count += 1;
   }

   RETURN( SUCCESS );
}

int  
pthread_mutex_unlock( pthread_mutex_t  *mu_h )
{
   struct PTHREAD_HANDLE *active_th;
   struct PTHREAD_MUTEX_HANDLE *handle;

   int flag, st;

   if( (st = system_init()) == FAILURE )
       return( st );

   sys_disable_ctxsw( flag );

   if( mu_h == NULL )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   handle = *mu_h;
   if( handle == NULL || handle->type != MUTEX_C )
   {
       set_thread_errno( EINVAL );
       RETURN( EINVAL );
   }

   /*
    *  --  If the mutex semaphore isn't set, then the mutex is not locked.
    *      Return with an appropriate error code.
    */
   if( handle->obj.lock == SEMAPHORE_C_CLEAR )
   {
       set_thread_errno( ENOLCK );
       RETURN( ENOLCK );
   }

   /*
    *  --  Make sure that we're the thread that holds this mutex.
    */
   if( handle->obj.active_th != (active_th = nub_get_active_thread()))
   {
       set_thread_errno( ENOLCK );
       RETURN( ENOLCK );
   }

   if( (st = unlock_mutex_struct( handle, active_th )) != SUCCESS )
       RETURN( st );       

   /*
    *  --  Reschedule if necessary.
    */
   if( active_th->obj.sched_param.sched_priority < get_highest_prio( &thread_rq ) )
   {
       active_th->obj.thread_state = THREAD_READY_C;
       nub_reschedule( active_th );
   }

   RETURN( SUCCESS );
}
