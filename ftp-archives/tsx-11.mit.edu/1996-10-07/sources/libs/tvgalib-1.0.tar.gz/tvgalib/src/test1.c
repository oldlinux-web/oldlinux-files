#include "tvga.h"
#include <stdio.h>

char	d[1024];

main()
{

int	i, j, x, y;


	for(i=0;i<512;i ++) d[i] = i>>5;
	for(i=512;i<1024;i++) d[i] = 4;


	printf("WARNING:  this program sets some video modes which could be\n");
	printf("potentially hazardous to some monitors.  Study your manuals\n");
	printf("and look at the code to see which modes may give problems.\n\n");

	printf("Continue - press return, ^C stop\n\n");
	getchar();

	printf("Testing scanline code.\n");
	printf("These lines are drawn from left to right.\n");
	printf("Blank lines are left to check for screen clear.\n\n");
	printf("16 colour modes first.\n\n");
	printf("Press <return> to start each test.\n");
	getchar();

	sdrawline(G640x480x16, 640, 480, 16);
	sdrawline(G800x600x16, 800, 600, 16);
	sdrawline(G768x1024x16, 768, 1024, 16);
	sdrawline(G1024x768x16, 1024, 768, 16);

	printf("256 colour scanlines\n");
	getchar();

	sdrawline(G320x200x256, 320, 200, 256);
	sdrawline(G640x400x256, 640, 400, 256);
	sdrawline(G320x240x256, 320, 240, 256);
	sdrawline(G640x480x256, 640, 480, 256);
	sdrawline(G800x600x256, 800, 600, 256);
	sdrawline(G1024x768x256, 1024, 768, 256);

	printf("\nThese tests are for the pixel code.\n");
	printf("These lines are drawn from top to bottom.\n\n");
	printf("16 colour modes first.\n");
	getchar();

	pdrawline(G320x200x16, 320, 200, 16);
	pdrawline(G800x600x16, 800, 600, 16);
	pdrawline(G768x1024x16, 768, 1024, 16);
	pdrawline(G1024x768x16, 1024, 768, 16);

	printf("256 colour pixels\n");
	getchar();
	
	pdrawline(G360x480x256, 360, 480, 256);
	pdrawline(G800x600x256, 800, 600, 256);
	pdrawline(G1024x768x256, 1024, 768, 256);

	printf("\nThe final tests are of the ellipse and box routines.\n");
	getchar();

	if (!vga_setmode(G1024x768x256)){
		for(i=500; i > 10; i -= 10){
			vga_setcolor(i / 20);
			vga_drawellipse(512, 384, i, i>>1);
		}
		vga_getch();
		vga_clear();
		for(i=50; i < 380; i+= 10){
			vga_setcolor(i / 25);
			vga_drawbox(i, i, 1024 - i, 768 - i);
		}
		vga_getch();
		vga_setmode(TEXT);
	}else
		printf("Can't do 1024x768x256\n");

}

pdrawline(mode, xr, yr, col)
int mode, xr, yr, col;
{
int	i, j;

	if (!vga_setmode(mode)){
		for (i=0; i<xr; i+=10){
			for (j=0; j<yr; j++){
				vga_setcolor(i/64);
				vga_drawpixel(i, j);
			}
		}
		vga_getch();
		vga_setmode(TEXT);
	}else{
		printf("Can't do %dx%dx%d\n", xr, yr, col);
		getchar();
	}

}


sdrawline(mode, xr, yr, col)
int mode, xr, yr, col;
{
int	i;

	if (!vga_setmode(mode)){
		for(i=0;i<yr;i+=5) vga_drawscanline(i, d);
		vga_getch();
		vga_setmode(TEXT);
	}else{
		printf("Can't do %dx%dx%d\n", xr, yr, col);
		getchar();
	}
}
