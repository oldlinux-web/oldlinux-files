#include "tvga.h"
#include <stdio.h>

char	d[1024];

main()
{

int	i, j, x, y;


	for(i=0;i<512;i ++) d[i] = i>>5;
	for(i=512;i<1024;i++) d[i] = 4;

	printf("WARNING:  this program sets some video modes which could be\n");
	printf("potentially hazardous to some monitors.  Study your manuals\n");
	printf("and look at the code to see which modes may give problems.\n\n");

	printf("Continue - press return, ^C stop\n\n");
	getchar();

	printf("\nThis test simply shows which modes are working.\n");
	printf("All screens have 50 scanlines drawn with the scanline code.\n");
	getchar();

	for (i=1; i<= G1024x768x256; i++)
		testmode(i);
}

testmode(mode)
int	mode;
{
int	j;

	if (vga_setmode(mode) < 0){
		vga_setmode(TEXT);
		printf("Can't do mode %d\n", mode);
		getchar();
	}else{
		for(j=0; j<100; j++) vga_drawscanline(j, d);
		vga_getch();
		vga_setmode(TEXT);
	}
}

pdrawline(mode, xr, yr, col)
int mode, xr, yr, col;
{
int	i, j;

	if (!vga_setmode(mode)){
		for (i=0; i<xr; i+=10){
			for (j=0; j<yr; j++){
				vga_setcolor(i/64);
				vga_drawpixel(i, j);
			}
		}
		vga_getch();
		vga_setmode(TEXT);
	}else{
		printf("Can't do %dx%dx%d\n", xr, yr, col);
		getchar();
	}

}


sdrawline(mode, xr, yr, col)
int mode, xr, yr, col;
{
int	i;

	if (!vga_setmode(mode)){
		for(i=0;i<yr;i+=5) vga_drawscanline(i, d);
		vga_getch();
		vga_setmode(TEXT);
	}else{
		printf("Can't do %dx%dx%d\n", xr, yr, col);
		getchar();
	}
}

