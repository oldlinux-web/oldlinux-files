/*
 * $Id: pthread_dce.h,v 1.1.1.1 1996/06/30 15:50:53 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: pthread_dce.h,v $
 * Revision 1.1.1.1  1996/06/30 15:50:53  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#ifndef _pthread_dce_
#define _pthread_dce_

#ifdef __cplusplus
    extern "C" {
#endif

/*
 * These data types are used by POSIX Draft 4 and DCE threads, but not by
 * Linux (POSIX) threads.
 */
typedef void *pthread_addr_t;
typedef void *(*pthread_startroutine_t)(void *);
typedef void  (*pthread_cleanup_t)(void *);
typedef void  (*pthread_destructor_t)(void *);
typedef void  (*pthread_initroutine_t)(void);

extern pthread_attr_t      pthread_attr_default;
extern pthread_mutexattr_t pthread_mutexattr_default;
extern pthread_condattr_t  pthread_condattr_default;

#ifndef CANCEL_ON
#define CANCEL_ON (1)
#endif

#ifndef CANCEL_OFF
#define CANCEL_OFF (0)
#endif

#ifdef _DCE_COMPAT_

#define TH_CHECK(st,str) \
{ \
   if( st != SUCCESS ) \
   {   int err; \
       pthread_geterrno_np( NULL, &err ); \
       fprintf( stderr, "%s: ", sys_errlist[err] ); \
       fprintf( stderr, "In %s: ", str ); \
       fprintf( stderr, "Line %d in %s\n", __LINE__, __FILE__ ); \
       _exit(1); \
   } \
}

#define pthread_attr_create         (pthd4_attr_create)
#define pthread_attr_delete         (pthd4_attr_delete )
#define pthread_attr_setstacksize   (pthd4_attr_setstacksize)
#define pthread_attr_getstacksize   (pthd4_attr_getstacksize)
#define pthread_create              (pthd4_create)
#define pthread_detach              (pthd4_detach)
#define pthread_exit                (pthd4_exit)
#define pthread_join                (pthd4_join)
#define pthread_mutex_init          (pthd4_mutex_init)
#define pthread_mutex_destroy       (pthd4_mutex_destroy)
#define pthread_cond_init           (pthd4_cond_init)
#define pthread_cond_destroy        (pthd4_cond_destroy)
#define pthread_setspecific         (pthd4_setspecific)
#define pthread_getspecific         (pthd4_getspecific)
#define pthread_cancel              (pthd4_cancel)
#define pthread_get_expiration_np    (pthd4_get_expiration_np)
#define pthread_yield               (pthd4_yield)
#define pthread_once                (pthd4_once)
#define pthread_keycreate           (pthd4_keycreate)
#define pthread_setcancel           (pthd4_setcancel)
#define pthread_setasynccancel      (pthd4_setasynccancel)

#endif

extern int 
pthd4_keycreate( pthread_key_t *key, pthread_destructor_t destructor );

extern int 
pthd4_setcancel( int state );

extern int
pthd4_setasynccancel( int state );

extern void
pthd4_yield( void );

extern int
pthd4_attr_create( pthread_attr_t *attr );

extern int 
pthd4_attr_delete ( pthread_attr_t *attr);

extern long
pthd4_attr_getstacksize( pthread_attr_t attr );

extern int
pthd4_attr_setstacksize( pthread_attr_t *attr, long stacksize );

extern int 
pthd4_create( pthread_t *thread,
              pthread_attr_t attr,
              pthread_startroutine_t start_routine,
              pthread_addr_t arg );

extern int
pthd4_detach( pthread_t *thread );

extern void
pthd4_exit( pthread_addr_t status );

extern int 
pthd4_join( pthread_t thread, pthread_addr_t *status );

extern pthread_t 
pthd4_self( void );

extern int 
pthd4_mutex_init( pthread_mutex_t *mutex, pthread_mutexattr_t attr );

extern int 
pthd4_mutex_destroy( pthread_mutex_t *mutex );

extern int
pthd4_mutex_lock( pthread_mutex_t *mutex );

extern int
pthd4_mutex_trylock( pthread_mutex_t *mutex );

extern int
pthd4_mutex_unlock( pthread_mutex_t *mutex );
  
extern int 
pthd4_cond_init( pthread_cond_t *cond, pthread_condattr_t attr );

extern int 
pthd4_cond_destroy( pthread_cond_t *cond );

extern int
pthd4_cond_broadcast( pthread_cond_t *cond );

extern int
pthd4_cond_signal( pthread_cond_t *cond );

extern int
pthd4_cond_wait( pthread_cond_t *cond, pthread_mutex_t *mutex );

extern int
pthd4_cond_timedwait( pthread_cond_t *cond,
                      pthread_mutex_t *mutex,
                      struct timespec *abstime );

extern int
pthd4_once( pthread_once_t *once_block, void (*init_routine)(void) );

int 
pthd4_setspecific( pthread_key_t key, pthread_addr_t value );

extern int 
pthd4_getspecific( pthread_key_t key, pthread_addr_t *value );

extern int 
pthd4_cancel( pthread_t thread );

extern int 
pthd4_get_expiration_np( struct timespec *delta, struct timespec *abstime );

extern int
pthd4_delay_np( struct timespec *interval );

#ifdef __cplusplus
}
#endif

#endif
