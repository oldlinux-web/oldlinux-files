#ifndef lint
static const char rcsid[] = "$Id: exc_test.c,v 1.1.1.1 1996/06/30 15:50:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: exc_test.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:53  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <exc_handling.h>

EXCEPTION MyExc;

static void 
foo( void )
{
   RAISE( MyExc );
}

void bar( void )
{
	TRY
		foo();
	CATCH_ALL
		pthread_lock_global_np();
	    printf("Child caught exception!\n");
	    pthread_unlock_global_np();
	ENDTRY

    pthread_exit( (void *)SUCCESS );
}
static pthread_t th;

int 
main( int argc, char *argv[] )
{
   int st = 0, *p;

   EXCEPTION_INIT( MyExc );

   TRY
	   pthread_lock_global_np();
	   p = malloc( sizeof( p ));
       pthread_unlock_global_np();

       TRY

		    (void) pthread_create( &th, 
							       pthread_attr_default,
								   (pthread_startroutine_t) bar,
								   NULL );

           (void) pthread_join( th, (void **) &st );
           pthread_lock_global_np();
           fprintf( stderr, "child exited with %d status!\n", st );
           pthread_unlock_global_np();

       FINALLY

		   free( p );
           pthread_lock_global_np();
           fprintf( stderr, "Deallocated p\n");
           pthread_unlock_global_np();

       ENDTRY

   CATCH_ALL

	   pthread_lock_global_np();
       fprintf(stderr, "Caught an error!\n");
       pthread_unlock_global_np();

   ENDTRY

   return( EXIT_SUCCESS );
}
