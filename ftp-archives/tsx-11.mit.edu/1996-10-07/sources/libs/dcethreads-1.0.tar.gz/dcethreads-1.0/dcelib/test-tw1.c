#ifndef lint
static const char rcsid[] = "$Id: test-tw1.c,v 1.1.1.1 1996/06/30 15:50:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: test-tw1.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:53  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <exc_handling.h>
#include <utils.h>

#define ITERATIONS (200000)
static int safe = FALSE;

static pthread_t *th;
static pthread_mutex_t mu;
static pthread_cond_t cv;
static int thread_count = 1;

static void 
cv_timer( struct timespec *ts )
{
    int i, status, success = SUCCESS;
    double foo = 0.0;

    for(i = 0; i < ITERATIONS; i++ )
        foo += i*3.14 / i*3.11;

    status = pthread_mutex_lock( &mu );
    TH_CHECK(status, "pthread_mutex_lock()" );

    while( !safe )
    {
        status = pthread_cond_timedwait( &cv, &mu, ts );
        TH_CHECK( status, "pthread_cond_timedwait()" );
    }

    thread_count += 1;
    status = pthread_mutex_unlock( &mu );
    TH_CHECK(status, "pthread_mutex_unlock()" );

    pthread_testcancel();
    pthread_exit( (void *) success );
}

int 
main( int argc, char *argv[] )
{
    int i, st, exit_status, thread_count = 1;
    struct timespec *tspec, tmo;
    struct timeval now;

    if( argc == 2 )
        thread_count = atoi( argv[1] );

    st = pthread_mutex_init( &mu, NULL );
        TH_CHECK( st, "pthread_mutex_init()");

    st = pthread_cond_init( &cv, NULL );
    TH_CHECK( st, "pthread_cond_init()");

    th = malloc( thread_count * sizeof( pthread_t ) );
    tspec = malloc( thread_count * sizeof( struct timespec ) );

    for(i = 0; i < thread_count; i++ )
    {
        gettimeofday( &now, NULL );
        tspec[i].tv_sec = now.tv_sec + 1;
        tspec[i].tv_nsec = rand() % 999999;

        st =  create_joinable( &th[i], (thread_proc_t) cv_timer, &tspec[i] );
        TH_CHECK( st, "create_joinable()");
    }

    tmo.tv_sec = 0; tmo.tv_nsec = 300000; /* 0.3 seconds */
    pthread_delay_np( &tmo );

    safe = TRUE;
    for(i = 0; i < thread_count; i++ )
    {    
        st = pthread_cancel( th[i] );
        TH_CHECK(st, "pthread_cancel()");
    }

    for(i = 0; i < thread_count; i++ )
    {
        st = pthread_join( th[i], (void **) &exit_status );
        TH_CHECK( st, "pthread_join()");

        if( exit_status == PTHREAD_CANCELED )
            printf("th[%d] was cancelled!\n", i );
        else
            printf( "th[%d] exited with status %d!\n", i, exit_status );
    }

    free( th );
    free( tspec );
    st = pthread_cond_destroy( &cv );
    TH_CHECK( st, "pthread_cond_destroy()");

    st = pthread_mutex_destroy( &mu );
    TH_CHECK( st, "pthread_mutex_destroy()");

    print_system_counters();
    return( EXIT_SUCCESS );
}
