#ifndef lint
static const char rcsid[] = "$Id: test-tw4.c,v 1.1.1.1 1996/06/30 15:50:53 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: test-tw4.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:53  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <exc_handling.h>
#include <utils.h>

#define TIMEOUT ((long) 3*10) /* 30 seconds */

static pthread_t *th;
static struct timespec *tspec;
static pthread_mutex_t mu;
static pthread_cond_t cv;

static void 
cv_timer( struct timespec *ts )
{
    int exit_status = SUCCESS, status;
    struct timeval now;
    struct timespec waketime;

    /*
     * Compute the expiration time (i.e., the time at which the thread will
     * be awoken), from the procedure's argument.
     */
    gettimeofday( &now, NULL );
    waketime.tv_sec = now.tv_sec + ts->tv_sec;
    waketime.tv_nsec = 0;

    status = pthread_mutex_lock( &mu );
    TH_CHECK(status, "pthread_mutex_lock()" );

    TRY
        while(1)
        {
            /*
             * Release lock and wait to be signaled, timed-out, or canceled.
             * If the thread is signaled or if its timeout expires, it will 
             * loop back into the timedwait.  If it is signaled, an exception
             * will be propagated out to the CATCH_ALL clause.
             */
            status = pthread_cond_timedwait( &cv, &mu, &waketime );
            TH_CHECK( status, "pthread_cond_timedwait()" );

            gettimeofday( &now, NULL );
            waketime.tv_sec = now.tv_sec + (rand() % 30);
            waketime.tv_nsec = 0;

            printf("."); fflush(NULL);
        }

    CATCH(pthread_cancel_e)

        /*
         * Received a cancel. By construction we were cancelled within the
         * pthread_cond_timedwait() and therefore no longer have the mutex.
         * Accordingly, we must relock the mutex and proceed.
         */
        exit_status = PTHREAD_CANCELED;
        status = pthread_mutex_lock( &mu );
        TH_CHECK(status, "pthread_mutex_lock()" );

    CATCH_ALL

        /*
         * Bogus.  An exception other than a cancel was raised.
         */
        exit_status = PTHREAD_CANCELED;
        status = pthread_mutex_lock( &mu );
        TH_CHECK(status, "pthread_mutex_lock()");
        printf("Unexpected exception!\n");

    ENDTRY

    /*
     * The thread was either canceled, signaled, or its expiration time was
     * reached.  In all three cases the mutex is unlocked and the thread's
     * exit status is communicated to any joining threads.
     */
    status = pthread_mutex_unlock( &mu );
    TH_CHECK(status, "pthread_mutex_unlock()" );

    pthread_exit( (void *) exit_status );
}

int 
main( int argc, char *argv[] )
{
    int i, st, exit_status = -1, thread_count = 1;
    struct timespec tmo;

    if( argc == 2 )
        thread_count = atoi( argv[1] );

    st = pthread_mutex_init( &mu, NULL );
        TH_CHECK( st, "pthread_mutex_init()");

    st = pthread_cond_init( &cv, NULL );
    TH_CHECK( st, "pthread_cond_init()");

    th = malloc( thread_count * sizeof( pthread_t ) );
    tspec = malloc( thread_count * sizeof( struct timespec ) );

    for(i = 0; i < thread_count; i++ )
    {
        tspec[i].tv_sec = 1;
        tspec[i].tv_nsec = rand() % 999999;

        st =  create_joinable( &th[i], (thread_proc_t) cv_timer, &tspec[i] );
        TH_CHECK( st, "create_joinable()");
    }

    /*
     * Delay for a long time allowing the child threads to loop exercising
     * the timedwait logic.
     */
    tmo.tv_sec = TIMEOUT; tmo.tv_nsec = 0;
    pthread_delay_np( &tmo );

    /*
     * Cancel all of the child threads.
     */
    for(i = 0; i < thread_count; i++ )
    {    
        st = pthread_cancel( th[i] );
        TH_CHECK(st, "pthread_cancel()");
    }

    for(i = 0; i < thread_count; i++ )
    {
        st = pthread_join( th[i], (void **) &exit_status );
        TH_CHECK( st, "pthread_join()");

        if( exit_status == PTHREAD_CANCELED )
            printf("\n%x cancelled!\n", th[i] );
        else
            printf( "\n%x terminated with status = %d!\n", th[i], exit_status );
    }

    free( th );
    free( tspec );
    st = pthread_cond_destroy( &cv );
    TH_CHECK( st, "pthread_cond_destroy()");

    st = pthread_mutex_destroy( &mu );
    TH_CHECK( st, "pthread_mutex_destroy()");

    return( EXIT_SUCCESS );
}
