#ifndef lint
static const char rcsid[] = "$Id: test5.c,v 1.1.1.1 1996/06/30 15:50:54 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: test5.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:54  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <signal.h>
#include <utils.h>

static int safe = FALSE;

static pthread_t *th;
static pthread_mutex_t mu;
static pthread_cond_t cv;

static void 
cv_timer( struct timespec *ts )
{
	int status, success = SUCCESS;

	status = pthread_mutex_lock( &mu );
	CHECK(status, "pthread_mutex_lock()" );

	while( !safe )
	{
		status = pthread_cond_timedwait( &cv, &mu, ts );
		CHECK( status, "pthread_cond_timedwait()" );
	}

	status = pthread_mutex_unlock( &mu );
	CHECK(status, "pthread_mutex_unlock()" );

	pthread_exit( (void *) success );
}

int 
main( int argc, char *argv[] )
{
	int i, st, exit_status, thread_count = 1;
	struct timespec *tspec;
        struct timeval now;

	if( argc == 2 )
		thread_count = atoi( argv[1] );

	st = pthread_mutex_init( &mu, NULL );
	CHECK( st, "pthread_mutex_init()");

	st = pthread_cond_init( &cv, NULL );
	CHECK( st, "pthread_cond_init()");

	th = malloc_r( thread_count * sizeof( pthread_t ) );
	tspec = malloc_r( thread_count * sizeof( struct timespec ) );

	for(i = 0; i < thread_count; i++ )
	{
                gettimeofday( &now, NULL );
		tspec[i].tv_sec = now.tv_sec + rand() % 5;
		tspec[i].tv_nsec = rand() % 9999;

		st =  create_joinable( &th[i], (thread_proc_t) cv_timer, &tspec[i] );
		CHECK( st, "create_joinable()");

                st = pthread_cancel( th[i] );
                CHECK(st, "pthread_cancel()");

		pthread_yield( NULL );
	}

	safe = TRUE;

	for(i = 0; i < thread_count; i++ )
	{
		st = pthread_join( th[i], (void **) &exit_status );
		CHECK( st, "pthread_join()");

		if( exit_status != SUCCESS )
                {
                   if( exit_status == PTHREAD_CANCELED )
                       printf_r("th[%d] was cancelled!\n", i );
                   else
			printf_r( "th[%d] exited with error status %d!\n", i, exit_status );
	       }
        }

	free_r( th );
	free_r( tspec );
	st = pthread_cond_destroy( &cv );
	CHECK( st, "pthread_cond_destroy()");

	st = pthread_mutex_destroy( &mu );
	CHECK( st, "pthread_mutex_destroy()");

	print_system_counters();
	return( EXIT_SUCCESS );
}
