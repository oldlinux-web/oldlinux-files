#ifndef lint
static const char rcsid[] = "$Id: test6.c,v 1.1.1.1 1996/06/30 15:50:54 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: test6.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:54  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<utils.h>
#include<math.h>

#define STACK_SIZE ((size_t)4096)
pthread_attr_t attrib;
pthread_t thread[40];

pthread_mutex_t mutex;
pthread_cond_t cv;

long double 
pigreco( void )        /* @@ */
{
  long double x;

  x = pow((double) 2, (double) 10);

  return x;
}

extern int sys_set_critical( void );
extern void sys_restore_critical( int f );

void *
proc(void *arg)
{
  double p;
  int i, n = (int) arg;
  int st;

  printf_r("attendo via libera %d\n", n);
  st = pthread_mutex_lock(&mutex);
  CHECK(st,"thread_mutex_lock");
  st = pthread_cond_wait(&cv, &mutex);
  CHECK(st,"thread_cond_wait");
  st = pthread_mutex_unlock(&mutex);
  CHECK(st,"thread_mutex_unlock");
  printf_r("sveglio %d\n", n);
  for (i = 0; i < 10000000; i++)
    {
      p = pigreco();
    }
  pthread_mutex_lock(&mutex);
  printf_r("%d finito %E\n", n, p);
  pthread_mutex_unlock(&mutex);
  return ((void *) 1);
}

int 
main(int argc, char *argv[])
{
  int i, st, N_PROCESS = 4;
  struct sched_param param = { SCHED_ROUND_ROBIN_C, PRI_RR_MAX, 1};

  st = pthread_cond_init(&cv, NULL);
  CHECK(st, "thread_cond_init");
  st = pthread_mutex_init(&mutex, NULL);
  CHECK(st, "thread_mutex_init");

  (void) pthread_attr_init(&attrib);
  (void) pthread_attr_setdetachstate(&attrib, PTHREAD_CREATE_JOINABLE);

  (void) pthread_attr_setschedparam(&attrib, &param);
  (void) pthread_attr_setstacksize(&attrib, STACK_SIZE);
  printf_r("creo thread \n");
  for (i = 0; i < N_PROCESS; i++)
    {
      (void) pthread_create(&thread[i], &attrib, proc, (void *) i);
    }

  sleep(2);
  printf_r("verde \n");
   /* pthread_mutex_unlock(&mutex);  @@ */
  st = pthread_cond_broadcast(&cv);
   CHECK(st,"thread_cond_broadcast");

  for (i = 0; i < N_PROCESS; i++)
    (void) pthread_join(thread[i], NULL);

  printf_r("thread terminati \n");

  (void) pthread_attr_destroy(&attrib);
  (void) pthread_mutex_destroy(&mutex);
  (void) pthread_cond_destroy(&cv);
  return (EXIT_SUCCESS);
}
