/*
 * $Id: errormsg.h,v 1.1.1.1 1996/06/30 15:50:54 mtp Exp $
 ****************************************************************************
 * @Header@
 ****************************************************************************
 * $Log: errormsg.h,v $
 * Revision 1.1.1.1  1996/06/30 15:50:54  mtp
 * DCE threads for Linux V1.0
 *
 * Revision 1.1.1.1  1995/12/17 00:20:19  mtp
 * Placed under CVS control
 *
 ****************************************************************************
 */
#ifndef _error_
#define _error_

#include <errno.h>		/* for definition of errno */
#include <stdarg.h>		/* ANSI C header file */

#define ERRMSG_C_STRLEN ((size_t) 1024)

extern void
err_ret(const char *fmt, ...);

/* 
 * Fatal error related to a system call. Print a message and terminate.
 */
extern void
err_sys(const char *fmt, ...);

/* 
 * Fatal error related to a system call.  Print a message, dump core, 
 * and terminate. 
 */
extern void
err_dump(const char *fmt, ...);

/* 
 * Nonfatal error unrelated to a system call. Print a message and return.
 */
extern void
err_msg(const char *fmt, ...);

/*
 * Fatal error unrelated to a system call. Print a message and terminate.
 */
extern void
err_quit(const char *fmt, ...);

#endif
