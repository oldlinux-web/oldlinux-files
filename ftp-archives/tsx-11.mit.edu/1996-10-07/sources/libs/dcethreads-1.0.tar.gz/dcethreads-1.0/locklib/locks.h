/*
 * $Id: locks.h,v 1.1.1.1 1996/06/30 15:50:53 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: locks.h,v $
 * Revision 1.1.1.1  1996/06/30 15:50:53  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#ifndef _locks_
#define _locks_
#ifdef __cplusplus
    extern "C" {
#endif

#include <pthread.h>

/*
 * --  Forward declarations used as opaque types.
 */
typedef struct SHARED_LOCK *pthread_rwlock_t;
typedef struct PRIO_LOCK   *pthread_priolock_t;


/*-------------------------------------------------------------------------*/
/*                  SHARED AND EXLUSIVE LOCKING PRIMITIVES                 */
/*-------------------------------------------------------------------------*/
extern int
pthread_rw_init_np( pthread_rwlock_t *shared );

extern int
pthread_rw_destroy_np( pthread_rwlock_t *shared );

extern int
pthread_rw_lock_shared_np( const pthread_rwlock_t *shared );

extern int
pthread_rw_unlock_shared_np( const pthread_rwlock_t *shared );

extern int
pthread_rw_lock_exclusive_np( const pthread_rwlock_t *shared );

extern int
pthread_rw_unlock_exclusive_np( const pthread_rwlock_t *shared );


/*-------------------------------------------------------------------------*/
/*                         PRIORITY INHERITANCE LOCKS                      */
/*-------------------------------------------------------------------------*/
extern int
pthread_priolock_init_np( pthread_priolock_t *prio_lock );
         
extern int
pthread_priolock_destroy_np( pthread_priolock_t *prio_lock );


extern int
pthread_priolock_lock_np( const pthread_priolock_t *prio_lock );
          
extern int
pthread_priolock_unlock_np( const pthread_priolock_t *prio_lock );

#ifdef __cplusplus
      }
#endif
#endif
