#!/bin/bash
# $Id: remove-dcethreads.sh,v 1.1.1.1 1996/06/30 15:50:53 mtp Exp $
############################################################################
#    
#  COPYRIGHT NOTICE
#    
#  Copyright (C) 1995, 1996 Michael T. Peterson
#  This file is part of the PCthreads (tm) multithreading library
#  package.
#    
#  The source files and libraries constituting the PCthreads (tm) package
#  are free software; you can redistribute them and/or modify them under
#  the terms of the GNU Library General Public License as published by the Free
#  Software Foundation; either version 2 of the License, or (at your
#  option) any later version.
#    
#  The PCthreads (tm) package is distributed in the hope that it will
#  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Library General Public License for more details.
#    
#  You should have received a copy of the GNU Library General Public
#  License along with this library (see the file COPYING.LIB); if not,
#  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
#  MA 02139, USA.
#    
#  To report bugs, bug fixes, or provide feedback you may contact the
#  author, Michael T. Peterson, at either of the two email addresses listed
#  below:
#    
#                 mtp@big.aa.net (Preferred)
#                 mtp@zso.dec.com
#    
#    
#  Michael T. Peterson
#  Issaquah, WA
#  29 June, 1996
############################################################################
# $Log: remove-dcethreads.sh,v $
# Revision 1.1.1.1  1996/06/30 15:50:53  mtp
# DCE threads for Linux V1.0
#
############################################################################
set -x
WHOAMI=root
VERSION=1.0.0
LIBDIR=/usr/lib
INCDIR=/usr/include
DCEDIR=/usr/include/dce

INCSRC=../include
LIBSRC=../lib

if [ `whoami` != "$WHOAMI" ]
then
   echo ""
   echo "  Sorry, you must have root privileges to execute this script"
   echo ""
   exit 1
fi


#
# Remove headers
#
if [ -d $DCEDIR ]
then
    rm -f $DCEDIR/pthread_dce.h
    rm -f $DCEDIR/exc_handling.h
    rm -f $DCEDIR/pthread_exc.h
fi

rm -f $INCDIR/pthread_dce.h
rm -f $INCDIR/errorlog.h
rm -f $INCDIR/errormsg.h
rm -f $INCDIR/locks.h
rm -f $INCDIR/utils.h

#
# Remove the libraries
#
rm -f $LIBDIR/libc.so.1
rm -f $LIBDIR/libc_r.a
rm -f $LIBDIR/libc_r.so.1
rm -f $LIBDIR/libc_r.so.1.0.0
rm -f $LIBDIR/liblocks.a
rm -f $LIBDIR/liblocks.so.1
rm -f $LIBDIR/liblocks.so.1.0.0
rm -f $LIBDIR/libpthread-ext.a
rm -f $LIBDIR/libpthread-ext.so.1
rm -f $LIBDIR/libpthread-ext.so.1.0.0
rm -f $LIBDIR/libpthread_dce.a
rm -f $LIBDIR/libpthread_dce.so.1
rm -f $LIBDIR/libpthread_dce.so.1.0.0
rm -f $LIBDIR/libsock_r.a
rm -f $LIBDIR/libsock_r.so.1
rm -f $LIBDIR/libsock_r.so.1.0.0

/sbin/ldconfig $LIBDIR

exit 0
