#ifndef lint
static const char rcsid[] = "$Id: bind.c,v 1.1.1.1 1996/06/30 15:50:54 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: bind.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:54  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include "pthread_socket.h"
#include "pthread_io_delay.h"

static inline
_syscall2(long,socketcall,int,call,unsigned long *,args);

static int
syscall_bind( int fd, struct sockaddr *my_addr, int addrlen )
{
   unsigned long args[3];

   args[0] = (unsigned long) fd;
   args[1] = (unsigned long) my_addr;
   args[2] = (unsigned long) addrlen;

   return( socketcall( SYS_BIND, args ) );
}

/*--------------------------------------------------------------------------
 * @@          B I N D
 *-------------------------------------------------------------------------*/
int 
bind( int fd, struct sockaddr *my_addr, int addrlen )
{
   int  ret;
   int flags, blocking;

   flags = fcntl( fd, F_GETFL, 0 );
   if( flags == NOTOK ) 
       return( NOTOK );

   /*
    * If the file was opened for normal, blocking I/O, we use fcntl()
    * to make it non-blocking so our thread can execute its delay poll().
    * If, however, the caller has specified non-blocking, then she is
    * expecting an immediate return.  Hence, execute the call only once.
    */
   blocking = (flags & O_NONBLOCK);
   if( !blocking )
   {
       if( fcntl(fd, F_SETFL, flags | O_NONBLOCK) < OK ) 
           return( NOTOK );
   }
   else
   {
       ret = syscall_bind( fd, my_addr, addrlen );
       RETURN( ret );
   }

   /*
    * Attempt the bind.
    */
   while( (ret = syscall_bind( fd, my_addr, addrlen )) < OK ) 
   {
       if( ret != -EWOULDBLOCK ) 
       {
           SET_ERRNO(ret);
           ret = NOTOK;
           break;
       }

       pthread_delay_np( &delay_interval );
       pthread_testcancel();
   }

   if( !blocking )
   {
       if( fcntl( fd, F_SETFL, flags ) < OK ) 
       {
           pthread_seterrno_np( errno );
           ret = NOTOK;
       }
   }

   return( ret );
}
