#ifndef lint
static const char rcsid[] = "$Id: connect.c,v 1.1.1.1 1996/06/30 15:50:54 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: connect.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:54  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include "pthread_socket.h"
#include "pthread_io_delay.h"

extern void fd_init( void );
extern pthread_once_t io_initialized;

static inline
_syscall2(long,socketcall,int,call,unsigned long *,args); 

static int
syscall_connect( int fd, struct sockaddr *addr, int addrlen )
{
   unsigned long args[3];
   int ret;

   args[0] = (unsigned long) fd;
   args[1] = (unsigned long) addr;
   args[2] = (unsigned long) addrlen;

   LOCK_ON

       ret = socketcall( SYS_CONNECT, args );

   LOCK_OFF

   return( ret );
}

/*--------------------------------------------------------------------------
 * @@          C O N N E C T
 *-------------------------------------------------------------------------*/
int 
connect( int fd, struct sockaddr *addr, int addrlen )
{
   int ret, err, st;

   st = pthread_once( &io_initialized, fd_init );
   if( st != SUCCESS )
       return( NOTOK );

   if( nonblock_is_set( fd ))
   {
       ret = syscall_connect( fd, addr, addrlen );
       RETURN( ret );
   }

   set_fd_nonblock( fd );
   while( (ret = syscall_connect( fd, addr, addrlen )) < OK ) 
   {
       (void) pthread_geterrno_np( NULL, &err );
       if( err != EINPROGRESS )   /* All others use EWOULDBLOCK */
           break;

       pthread_delay_np( &delay_interval );
       pthread_testcancel();
   }

   clear_fd_nonblock( fd );
   return( ret );
}
