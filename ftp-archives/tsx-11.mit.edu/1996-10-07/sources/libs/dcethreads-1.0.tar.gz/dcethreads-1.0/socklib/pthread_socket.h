/*
 * $Id: pthread_socket.h,v 1.1.1.1 1996/06/30 15:50:54 mtp Exp $
 ****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: pthread_socket.h,v $
 * Revision 1.1.1.1  1996/06/30 15:50:54  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#ifndef _pthread_socket_
#define _pthread_socket_

#include <fcntl.h>
#include <syscall.h>
#include <sys/socket.h>
#include <sys/socketcall.h>
#include <sys/time.h>
#include <sys/types.h>
#include <arpa/inet.h>         /* inet_addr() and friends */
#include <linux/net.h>
#include <errno.h>
#include <pthread.h>

#undef OK
#define OK ((int) 0)

#undef NOTOK
#define NOTOK ((int) -1)

#define LOCK_ON \
{ \
   pthread_lock_global_np(); \
   errno = 0; \
   {
/* syscall goes here */

#define LOCK_OFF \
   } \
   if( errno ) \
       pthread_seterrno_np( errno ); \
   pthread_unlock_global_np(); \
}


#define SET_ERRNO(v) \
{ \
   pthread_lock_global_np(); \
   errno = (v) * -1; \
   pthread_unlock_global_np(); \
   pthread_seterrno_np( ((v) * -1) ); \
}

#define RETURN(r) \
{\
   if( r < OK ) \
   { \
       pthread_seterrno_np( errno ); \
       r = -1; \
   } \
   return(r); \
}

#ifndef ssize_t
#define ssize_t int
#endif 

extern int
sys_set_critical( void );

extern void
sys_restore_critical( int );

/*
 * Return TRUE if the specified file descriptor is set for O_NONBLOCK.
 * Otherwise, a value of FALSE is returned.
 */
extern int
nonblock_is_set( int fd );

/*
 * Set the input file descriptor to specify non-blocking I/O.  The
 * original value of the file descriptor's flags are saved in the
 * location referenced by the saved_flags variable.
 */ 
extern int
set_fd_nonblock( int fd );

/*
 * Set a file descriptor's flags to the values contained in the
 * saved flags parameter.  This function is used to restore a file
 * descriptor's flags to their original value after having been set
 * to non-blocking.
 */
extern int
clear_fd_nonblock(int fd );

#endif
