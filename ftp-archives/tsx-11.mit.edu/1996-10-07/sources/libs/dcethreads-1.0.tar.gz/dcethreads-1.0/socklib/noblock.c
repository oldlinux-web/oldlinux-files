#ifndef lint
static const char rcsid[] = "$Id: noblock.c,v 1.1.1.1 1996/06/30 15:50:54 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: noblock.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:54  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include "pthread_socket.h"

int
nonblock_is_set( int fd )
{
   int non_blocking = FALSE, fd_flags;

   pthread_lock_global_np();
   fd_flags = fcntl( fd, F_GETFL, 0 );
   pthread_unlock_global_np();

   if( fd_flags & O_NONBLOCK )
       non_blocking = TRUE;

   return( non_blocking );
}
   
/*
 * Set the input file descriptor to specify non-blocking I/O.  The
 * original value of the file descriptor's flags are saved in the
 * location referenced by the saved_flags variable.
 */
int
set_fd_nonblock( int fd )
{
   int st, flags;

   pthread_lock_global_np();
   flags = fcntl( fd, F_GETFL, 0 );
   if( flags < 0 )
   {
       pthread_unlock_global_np();
       return( NOTOK );
   }

   st = fcntl( fd, F_SETFL, (flags |= O_NONBLOCK) );

   pthread_unlock_global_np();
   return( st );
}

int
clear_fd_nonblock( int fd )
{
   int st, flags;

   pthread_lock_global_np();
   flags = fcntl( fd, F_GETFL, 0 );
   if( flags < 0 )
   {
       pthread_unlock_global_np();
       return( NOTOK );
   }

   st = fcntl( fd, F_SETFL, (flags &= ~O_NONBLOCK) );

   pthread_unlock_global_np();
   return( st );
}

