#ifndef lint
static const char rcsid[] = "$Id: main.c,v 1.1.1.1 1996/06/30 15:50:54 mtp Exp $";
#endif
/****************************************************************************
 *    
 *  COPYRIGHT NOTICE
 *    
 *  Copyright (C) 1995, 1996 Michael T. Peterson
 *  This file is part of the PCthreads (tm) multithreading library
 *  package.
 *    
 *  The source files and libraries constituting the PCthreads (tm) package
 *  are free software; you can redistribute them and/or modify them under
 *  the terms of the GNU Library General Public License as published by the Free
 *  Software Foundation; either version 2 of the License, or (at your
 *  option) any later version.
 *    
 *  The PCthreads (tm) package is distributed in the hope that it will
 *  be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *    
 *  You should have received a copy of the GNU Library General Public
 *  License along with this library (see the file COPYING.LIB); if not,
 *  write to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *  MA 02139, USA.
 *    
 *  To report bugs, bug fixes, or provide feedback you may contact the
 *  author, Michael T. Peterson, at either of the two email addresses listed
 *  below:
 *    
 *             mtp@big.aa.net (preferred)
 *             mtp@zso.dec.com
 *    
 *    
 *  Michael T. Peterson
 *  Issaquah, WA
 *  29 January, 1996
 ****************************************************************************
 * $Log: main.c,v $
 * Revision 1.1.1.1  1996/06/30 15:50:54  mtp
 * DCE threads for Linux V1.0
 *
 ****************************************************************************
 */
#include <stdio.h>
#include <fcntl.h>
#include <pthread.h>
#include <linux/net.h>         /* struct msghdr */
#include <errormsg.h>

static const char *filename = "/etc/ieee_802_addr";

/*
char *buf = "abcdefghijklm";
static char buf[] = "abcdefghijkl";
*/
char buf[13];

static int
test_select( int argc, char *argv[] )
{
   int failed = FALSE, count = 3, ret, nfds;
   fd_set testfds, *readfds = NULL, *writefds = NULL, *exceptfds = NULL;
   struct timeval delay = { 0, 0 };
   struct timeval no_delay = { 0, 0 };

   /*
    * Pass an invalid argument for the first argument.
    */
   nfds = -1;
   ret = select( nfds, &testfds, writefds, exceptfds, &delay );
   if( ret != -1 && errno != 22 )
   {
       fprintf( stderr, "select() test failed!\n");
       failed = TRUE;
   }

   nfds = 0;
   while( count-- > 0 )
   {
       delay.tv_sec = count;
       ret = select( nfds, readfds, writefds, exceptfds, &delay );
       if( ret < 0 )
       {
           perror("select() failed!");
           exit(1);
       }

       if( delay.tv_sec != 0 )
       {
            fprintf( stderr, "select() test failed!\n");
            failed = TRUE;
       }
   }
   
   ret = select( nfds, readfds, writefds, exceptfds, &no_delay );
   if( ret < 0 )
   {
        perror("select() failed!");
        exit(1);
   }
   
   return( failed );
}

static int
test_read( int argc, char *argv[] )
{
   int failed = FALSE, fd, nbytes;


   fd = open( filename, O_RDONLY );
   if( fd < 0 )
   {
       perror("open() failed!");
       exit(1);
   }

   /*
    * Test test file has 12 characters in it.
    */
   nbytes = read( fd, buf, 12 );
   if( nbytes < 0 )
   {
       return( TRUE );
       fprintf( stderr, "read() test failed!\n");
   }

   if( nbytes != 12)
   {
       close(fd);
       fprintf( stderr, "read %d bytes, not 12!\n", nbytes );
       return( TRUE );
   }

   /*
    * Attempt to write to the file.  Should fail with errno = EBADF
    * (file not open for writing).
    */
   nbytes = write( fd, buf, 12 );
   if( nbytes != -1 && errno != 9 )
   {
       close(fd);
       fprintf( stderr, "write() test failed!\n");
       failed = TRUE;
   }

   close(fd);
   return( failed );
}

int
main( int argc, char *argv[] )
{
   int fd = 1;
   struct msghdr msg;

   if( test_select( argc, argv ))
       printf("select() failed!\n");
   else
       printf("select() passed!\n");

   if( test_read( argc, argv ))
       printf("read-write() failed!\n");
   else
       printf("read-write() passed!\n");

    if( sendmsg( fd, &msg, 0 ) < 0 )
        perror("sendmsg()");

    if( recvmsg( fd, &msg, 0 ) < 0 )
        perror("recvmsg()");

   return(0);
}
