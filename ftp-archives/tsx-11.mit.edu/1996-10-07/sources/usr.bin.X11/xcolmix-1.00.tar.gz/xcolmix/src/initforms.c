
#include "xcolmix.h"
#include "version.h" 

void initforms ()
{
    FL_OBJECT
	*obj;

    /* initialize fore/background color */
    makecolor ();

    
    /* color mixer form definition */

    colormixer = fl_bgn_form(FL_NO_BOX, 320, 230);
    
    fl_add_box(FL_UP_BOX,0,0,320,230,"");
    
    logo = fl_add_text(FL_NORMAL_TEXT,15,155,200,60,"Color Mixer\nV" VER);
    fl_set_object_lcol (logo, FG_COL);
    fl_set_object_color (logo, BG_COL, 0);
    fl_set_object_lsize (logo, FL_MEDIUM_SIZE);
    fl_set_object_lstyle (logo, FL_BOLDITALIC_STYLE);
    
    obj = fl_add_button(FL_NORMAL_BUTTON,235, 15,75,35,"Dismiss");
    fl_set_object_callback(obj,cb_quit,0);
    
    red_slider = fl_add_valslider(FL_HOR_SLIDER,40,120,270,25,"Red");
    fl_set_slider_bounds (red_slider, 0, 255);
    fl_set_slider_step (red_slider, 1);
    fl_set_slider_precision (red_slider, 0);
    fl_set_slider_value (red_slider, bg_red);
    fl_set_object_lsize(red_slider,FL_DEFAULT_SIZE);
    fl_set_object_lalign(red_slider,FL_ALIGN_LEFT);
    fl_set_object_callback(red_slider,cb_red,0);
    
    green_slider = fl_add_valslider(FL_HOR_SLIDER,40,90,270,25,"Green");
    fl_set_slider_bounds (green_slider, 0, 255);
    fl_set_slider_step (green_slider, 1);
    fl_set_slider_precision (green_slider, 0);
    fl_set_slider_value (green_slider, bg_green);
    fl_set_object_lsize(green_slider,FL_DEFAULT_SIZE);
    fl_set_object_lalign(green_slider,FL_ALIGN_LEFT);
    fl_set_object_callback(green_slider,cb_green,0);

    blue_slider = fl_add_valslider(FL_HOR_SLIDER,40,60,270,25,"Blue");
    fl_set_slider_bounds (blue_slider, 0, 255);
    fl_set_slider_step (blue_slider, 1);
    fl_set_slider_precision (blue_slider, 0);
    fl_set_slider_value (blue_slider, bg_blue);
    fl_set_object_lsize(blue_slider,FL_DEFAULT_SIZE);
    fl_set_object_lalign(blue_slider,FL_ALIGN_LEFT);
    fl_set_object_callback(blue_slider,cb_blue,0);

    obj = fl_add_button(FL_NORMAL_BUTTON,145,15,75,35,"Lookup");
    fl_set_object_callback(obj,cb_lookup,0);
    
    obj = fl_add_choice (FL_NORMAL_CHOICE,40,15,90,35, "F/B");
    fl_addto_choice (obj, "Background | Foreground");
    fl_set_choice (obj, 1);
    fl_set_object_boxtype (obj, FL_ROUNDED_BOX);
    fl_set_object_callback (obj, cb_fore_back, 0);
    fl_end_form();

    
    /* the lookup form definition */

    lookup = fl_bgn_form(FL_NO_BOX, 315, 375);
    
    fl_add_box(FL_UP_BOX,0,0,315,375,"");

    obj = fl_add_button (FL_NORMAL_BUTTON, 10,340, 75, 25, "Dismiss");
    fl_set_object_callback (obj, cb_lookupdone, 0);
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    
    obj = fl_add_browser(FL_HOLD_BROWSER,10,10,295,325,"");
    fl_set_object_callback(obj,cb_selectcolor,0);
    fl_load_browser (obj, rgbfile);

    fl_end_form();
}

