
#include "xcolmix.h"

void cb_quit(FL_OBJECT *ob, long data)
{
    fl_finish ();
    exit (0);
}

void cb_red (FL_OBJECT *ob, long data)
{
    register int
	val = (int) fl_get_slider_value (ob);
    
    if (foreground_selected)
	fg_red = val;
    else
	bg_red = val;
    makecolor ();
}

void cb_green (FL_OBJECT *ob, long data)
{
    register int
	val = (int) fl_get_slider_value (ob);
    
    if (foreground_selected)
	fg_green = val;
    else
	bg_green = val;
    makecolor ();
}

void cb_blue (FL_OBJECT *ob, long data)
{
    register int
	val = (int) fl_get_slider_value (ob);
    
    if (foreground_selected)
	fg_blue = val;
    else
	bg_blue = val;
    makecolor ();
}

void cb_lookup (FL_OBJECT *ob, long data)
{
    if (! lookup_on_screen)
    {
	fl_show_form (lookup, FL_PLACE_CENTER, FL_FULLBORDER, "Color Lookup");
	lookup_on_screen = 1;
    }
}

void cb_selectcolor (FL_OBJECT *ob, long data)
{
    register int
	sel = fl_get_browser (ob);
    register char const
	*text;
    int
	r,
	g,
	b;

    if (! sel)
	return;
    text = fl_get_browser_line (ob, sel);
    if (sscanf (text, "%d %d %d", &r, &g, &b) < 3)
	return;
    
    if (foreground_selected)
    {
	fg_red = r;
	fg_green = g;
	fg_blue = b;
    }
    else
    {
	bg_red = r;
	bg_green = g;
	bg_blue = b;
    }

    makecolor ();
}

void cb_fore_back (FL_OBJECT *ob, long data)
{
    foreground_selected =  (fl_get_choice (ob) == 2);
    makecolor ();
}

void cb_lookupdone (FL_OBJECT *ob, long data)
{
    fl_hide_form (lookup);
    lookup_on_screen = 0;
}
