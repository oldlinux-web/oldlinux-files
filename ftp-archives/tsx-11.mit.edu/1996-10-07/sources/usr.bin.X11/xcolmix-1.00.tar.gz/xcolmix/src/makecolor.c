
#include "xcolmix.h"

void makecolor ()
{
    fl_mapcolor (FG_COL, fg_red, fg_green, fg_blue);
    fl_mapcolor (BG_COL, bg_red, bg_green, bg_blue);

    if (logo)
    {
	fl_redraw_object (logo);

	if (foreground_selected)
	{
	    fl_set_slider_value (red_slider, fg_red);
	    fl_set_slider_value (green_slider, fg_green);
	    fl_set_slider_value (blue_slider, fg_blue);
	}
	else
	{
	    fl_set_slider_value (red_slider, bg_red);
	    fl_set_slider_value (green_slider, bg_green);
	    fl_set_slider_value (blue_slider, bg_blue);
	}
	    
	fl_redraw_object (red_slider);
	fl_redraw_object (green_slider);
	fl_redraw_object (blue_slider);
    }
}
