
#include "xcolmix.h"
#include "version.h"

void usage ()
{
    fprintf
(stderr,
 "\n"
 "X Color Mixer  V" VER "\n"
 "Copyright (c) Karel Kubat 1995. All rights reserved.\n"
 "Another MegaHard production!\n"
 "\n"
 "Usage: xcolmix [X options] \n"
 "   or: xcolmix [X options] rgb-database-file\n"
 "The rgb-database-file is the file which holds the X-windows color\n"
 "definitions, when absent: /usr/lib/X11/rgb.txt is used.\n"
 "Options may be:\n"
 "    -display host:display - the display, default: $DISPLAY\n"
 "    -name applicationname - application name for X resource managing\n"
 "                            default: xcolmix\n"
 "    -visual class         - visual class, e.g. TrueColor\n"
 "    -depth n              - visual depth\n"
 "    -private, -shared,\n"
 "    -stdcmap              - defines color mapping\n"
 "    -debug d              - verbosity of XForms window management\n"
 "    -sync                 - forces synchronous mode\n"
 );

    exit (1);
}
