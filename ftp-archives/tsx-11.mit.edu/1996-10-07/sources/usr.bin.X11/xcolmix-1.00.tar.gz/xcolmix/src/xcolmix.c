
#include "xcolmix.h"

/* global vars */
FL_FORM
    *colormixer,
    *lookup;
FL_OBJECT
    *red_slider,
    *green_slider,
    *blue_slider,
    *logo;
int
    fg_red = 0, fg_green = 0, fg_blue = 0,
    bg_red = 255, bg_green = 255, bg_blue = 255,
    foreground_selected = 0,
    lookup_on_screen = 0;
char
    *rgbfile = "/usr/lib/X11/rgb.txt";

void main (int argc, char **argv)
{
    /* initialize XForms */
    fl_initialize ("xcolmix", "XColmix", 0, 0, &argc, argv);

    /* check arguments */
    if (argc > 2)
	usage ();
    else if (argc == 2)
    {
	if (access (argv [1], R_OK))
	    usage ();
	rgbfile = argv [1];
    }

    initforms ();
    fl_show_form (colormixer, FL_PLACE_CENTER, FL_FULLBORDER,
		  "Color Mixer");
    fl_do_forms ();

    /* not reached */
}
