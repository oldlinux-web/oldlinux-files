#include <forms.h>
#include <stdio.h>
#include <unistd.h> 

/* defines */
#define FG_COL FL_FREE_COL1
#define BG_COL FL_FREE_COL2

/* global vars */
extern FL_FORM
    *colormixer,
    *lookup;
extern FL_OBJECT
    *logo,
    *red_slider,
    *green_slider,
    *blue_slider;
extern int
    fg_red, fg_green, fg_blue,
    bg_red, bg_green, bg_blue,
    foreground_selected,
    lookup_on_screen;
extern char
    *rgbfile;
    
/* functions */
extern void cb_quit (FL_OBJECT *, long);
extern void cb_red (FL_OBJECT *, long);
extern void cb_green (FL_OBJECT *, long);
extern void cb_blue (FL_OBJECT *, long);
extern void cb_lookup (FL_OBJECT *, long);
extern void cb_selectcolor(FL_OBJECT *, long);
extern void cb_fore_back (FL_OBJECT *, long);
extern void cb_lookupdone (FL_OBJECT *, long);
extern void initforms (void);
extern void makecolor (void);
extern void usage (void);
