/**************************************************************************
 * SPICE2XGRAPH.H							  *
 *                                                                        *
 * This program converts spice output into a format suitable for reading  *
 * into xgraph.                                                           *
 *                                                                        *
 * usage: spice2xgraph 	< spice.out > xgraph.in          		  *
 *    or:  spice < spice.in | spice1xgraph | xgraph			  *
 *                                                                        *
 *    or: spice2xgraph spice.out xgraph.in                                *
 * 									  *
 * 									  *
 * Copyright (c) 1993, 1994 David Frey                                    * 
 * 									  *
 * This program is free software; you can redistribute it and/or modify   *
 * it under the terms of the GNU General Public License as published by   *
 * the Free Software Foundation; either version 2 of the License, or      *
 * (at your option) any later version.                                    *
 *									  * 
 * This program is distributed in the hope that it will be useful,        *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 * GNU General Public License for more details.                           *
 *									  *   
 * You should have received a copy of the GNU General Public License      *
 * along with this program; if not, write to the Free Software            *
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.              *
 *									  * 
 **************************************************************************/

#define MAXLINELENGTH 132

#define FALSE 0
#define TRUE  1

#define FIRST 0
#define TRAN  1
#define AC    2

#define FETCHLINE 	1
#define SIGNOTFOUND 	2
#define NODATA		3
#define GARBAGE		4
#define	NOTFOUND	5
#define DISKFULL	6

struct XDataPointType
{
  float X;
  struct XDataPointType *nextX;
} XDataPoint;


struct YDataPointType
{
  float Y;
  struct YDataPointType *nextY;
} YDataPoint;

static struct option const long_options[] =
{
  {"ac", optional_argument, 0, 'a'},
  {"help", no_argument, 0, 'h'},
  {"help", no_argument, 0, '?'},
  {"input",  optional_argument, 0, 'i'},
  {"output", optional_argument, 0, 'o'},
  {"transient", optional_argument, 0, 't'},
  {"verbose", no_argument, 0, 'v'},
  {"version", no_argument, 0, 'V'},
  {0, 0, 0, 0}
};

const char template[3][MAXLINELENGTH] =
{"the first comer (either ac or transient)",
 "transient analysis",
 "ac analysis"};
