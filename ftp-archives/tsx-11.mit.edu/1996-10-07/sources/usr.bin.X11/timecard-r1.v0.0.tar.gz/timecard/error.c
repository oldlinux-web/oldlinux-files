/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: transientwindow.c
 *            DESCRIPTION: routines dealing with transient windows
 *      DEFINED CONSTANTS: timecard.h
 *       TYPE DEFINITIONS: timecard.h
 *      MACRO DEFINITIONS: timecard.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: TMCCreateTransient()
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/TMC, no underscores, mixed case	TMCPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/TMC, underscores, mixed case		TMC_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef ERROR_C
#define ERROR_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Dialog.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Viewport.h>

/* === Project Headers === */
#include "timecard.h"
#include "debug.h"

/* === external routines === */
extern void TMCPopUpWindow();

/* === Global variables === */
extern Widget TMC_Transient_App_Shell;	/* top level shell for transients */

Widget TMC_Error_Shell;			/* pop up window for error information */
Widget TMC_Error_Dialog;		/* dialog containing error information */



/*========================================================================
 *	Name:			TMCDestroyError
 *	Prototype:	TMCDestroyError()
 *					
 *
 *	Description:
 *		Destroys the error shell and its children.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
TMCDestroyError(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{
	XtDestroyWidget ( (Widget) client_data );
}


/*========================================================================
 *	Name:			TMCPopUpError
 *	Prototype:	TMCPopUpError()
 *					
 *
 *	Description:
 *		Creates and pops up the error shell and its children.  It is
 *		necessary to recreate the error shell each time since geometry
 *		management tools don't seem to allow for changing the parent shell
 *		width when the childs Dialog label changes.  At least *I* couldn't
 *		get them to do so.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
TMCPopUpError(
	char	*errormsg
)
{
#ifdef DEBUG
	char	fname[]="TMCPopUpError()";
#endif

	Arg	args[3];
	int	nargs;

	Widget		errorOK;		/* OK button for error dialog */


	DBGEnter();

	DBGPrintf(DBG_INFO, ("%s\n", errormsg ));

	/*
	 * Create popup for error messages
	 */
	TMC_Error_Shell = XtCreatePopupShell (
		"Error",								/* widget name */
		transientShellWidgetClass,		/* class */
		TMC_Transient_App_Shell,		/* parent */
		NULL,	0								/* arg list */
		);

	/*
	 * Dialog containing error message
	 */
	nargs=0;
	XtSetArg ( args[nargs], XtNlabel, errormsg ); nargs++;
	TMC_Error_Dialog = XtCreateManagedWidget (
		"errorDialog",				/* widget name */
		dialogWidgetClass,		/* class */
		TMC_Error_Shell,			/* parent */
		args,	nargs					/* arg list */
		);

	/*
	 * button to close dialog
	 */
	nargs=0;
	XtSetArg ( args[nargs], XtNlabel, "OK"); nargs++;
	errorOK = XtCreateManagedWidget (
		"errorOK",					/* widget name */
		commandWidgetClass,		/* class */
		TMC_Error_Dialog,			/* parent */
		args,	nargs					/* arg list */
		);

	/*
	 * callbacks for pressing the OK button on the Error Dialog
	 */
	XtAddCallback ( errorOK, XtNcallback,
		(XtCallbackProc) TMCDestroyError, TMC_Error_Shell );

	TMCPopUpWindow ( TMC_Error_Shell );
}

#endif /* ERROR_C */
