/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: transientwindow.c
 *            DESCRIPTION: routines dealing with transient windows
 *      DEFINED CONSTANTS: timecard.h
 *       TYPE DEFINITIONS: timecard.h
 *      MACRO DEFINITIONS: timecard.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: TMCCreateTransient()
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/TMC, no underscores, mixed case	TMCPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/TMC, underscores, mixed case		TMC_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef TRANSIENT_C
#define TRANSIENT_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Dialog.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Viewport.h>

/* === Project Headers === */
#include "timecard.h"
#include "debug.h"

/* === external routines === */
extern void TMCPopDownWindow();
extern void TMCWrite();
extern void TMCWriteTimeSheet2();
extern void TMCFreeLink();
extern void TMCPopDown();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
extern Widget		TMC_Top_Level;				/* parent of all widgets */

Widget TMC_Project_Shell;			/* pop up window for project information */
Widget TMC_Project_Dialog;			/* dialog containing project name */
Widget TMC_FileName_Shell;			/* pop up window for filename information */
Widget TMC_FileName_Dialog;		/* dialog containing filename */
Widget TMC_Transient_App_Shell;	/* top level shell for transients */

/* === Static Variables === */


/*========================================================================
 *	Name:			TMCCreateTransient
 *	Prototype:	TMCCreateTransient()
 *
 *	Description:
 *		create all windows that get popped up and down
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
TMCCreateTransient()
{
#ifdef DEBUG
	char 			fname[]="TMCCreateTransient()";
#endif

	Arg			args[5];
	int			nargs;

	Widget		projectOK, projectCancel;	/* buttons for project dialog */
	Widget		filenameOK, filenameCancel;/* buttons for filename dialog */

	DBGEnter();

	/*
	 * Create a new application shell for all transients
	 */
	TMC_Transient_App_Shell = XtAppCreateShell (
			"Timecard",							/* name */
			"transientAppShell",				/* app class */
			applicationShellWidgetClass,	/* widget class */
			XtDisplay (TMC_Top_Level),		/* display */
			NULL, 0								/* args */
			);


	/*
	 * create windows that are transient - they get popped up and down
	 * due to actions by the user
	 */


	/*
	 * Create popup that will request project information
	 * This pop up is only called when a Start action
	 * has been requested.
	 */
	TMC_Project_Shell = XtCreatePopupShell (
		"Project",							/* widget name */
		transientShellWidgetClass,		/* class */
		TMC_Transient_App_Shell,				/* parent */
		NULL,	0								/* arg list */
		);

	/*
	 * Dialog for retrieving project information
	 */
	nargs=0;
	XtSetArg ( args[nargs], XtNlabel, "Project Name"); nargs++;
	XtSetArg ( args[nargs], XtNvalue, ""); nargs++;
	TMC_Project_Dialog = XtCreateManagedWidget (
		"projectDialog",			/* widget name */
		dialogWidgetClass,		/* class */
		TMC_Project_Shell,		/* parent */
		args,	nargs					/* arg list */
		);

	/*
	 * button to close dialog
	 */
	nargs=0;
	XtSetArg ( args[nargs], XtNlabel, "OK"); nargs++;
	projectOK = XtCreateManagedWidget (
		"projectOK",				/* widget name */
		commandWidgetClass,		/* class */
		TMC_Project_Dialog,		/* parent */
		args,	nargs					/* arg list */
		);

	/*
	 * button to cancel dialog
	 */
	nargs=0;
	XtSetArg ( args[nargs], XtNlabel, "Cancel"); nargs++;
	projectCancel = XtCreateManagedWidget (
		"projectCancel",			/* widget name */
		commandWidgetClass,		/* class */
		TMC_Project_Dialog,		/* parent */
		args,	nargs					/* arg list */
		);

	/*
	 * callbacks for pressing the OK button on the Project Dialog
	 */
	XtAddCallback ( projectOK, XtNcallback,
		(XtCallbackProc) TMCPopDownWindow, TMC_Project_Shell );

	XtAddCallback ( projectOK, XtNcallback,
		(XtCallbackProc) TMCWrite, TMC_START );

	/*
	 * callbacks for pressing the Cancel button on the Project Dialog
	 */
	XtAddCallback ( projectCancel, XtNcallback,
		(XtCallbackProc) TMCPopDownWindow, TMC_Project_Shell );


	/*
	 * Create popup that will request filename information
	 */
	TMC_FileName_Shell = XtCreatePopupShell (
		"Filename",							/* widget name */
		transientShellWidgetClass,		/* class */
		TMC_Transient_App_Shell,		/* parent */
		NULL,	0								/* arg list */
		);

	/*
	 * Dialog for retrieving filename information
	 */
	nargs=0;
	XtSetArg ( args[nargs], XtNlabel, "File Name"); nargs++;
	XtSetArg ( args[nargs], XtNvalue, ""); nargs++;
	TMC_FileName_Dialog = XtCreateManagedWidget (
		"filenameDialog",			/* widget name */
		dialogWidgetClass,		/* class */
		TMC_FileName_Shell,		/* parent */
		args,	nargs					/* arg list */
		);

	/*
	 * button to close dialog
	 */
	nargs=0;
	XtSetArg ( args[nargs], XtNlabel, "OK"); nargs++;
	filenameOK = XtCreateManagedWidget (
		"filenameOK",				/* widget name */
		commandWidgetClass,		/* class */
		TMC_FileName_Dialog,		/* parent */
		args,	nargs					/* arg list */
		);

	/*
	 * button to cancel dialog
	 */
	nargs=0;
	XtSetArg ( args[nargs], XtNlabel, "Cancel"); nargs++;
	filenameCancel = XtCreateManagedWidget (
		"filenameCancel",			/* widget name */
		commandWidgetClass,		/* class */
		TMC_FileName_Dialog,		/* parent */
		args,	nargs					/* arg list */
		);

	/*
	 * callbacks for pressing the buttons in the Project Dialog
	 */
	XtAddCallback ( filenameOK, XtNcallback,
		(XtCallbackProc) TMCPopDownWindow, TMC_FileName_Shell );

	XtAddCallback ( filenameOK, XtNcallback,
		(XtCallbackProc) TMCWriteTimeSheet2, NULL );

	XtAddCallback ( filenameCancel, XtNcallback,
		(XtCallbackProc) TMCPopDownWindow, TMC_FileName_Shell );

	XtAddCallback ( filenameCancel, XtNcallback,
		(XtCallbackProc) TMCFreeLink, NULL );
}

#endif /* TRANSIENT_C */
