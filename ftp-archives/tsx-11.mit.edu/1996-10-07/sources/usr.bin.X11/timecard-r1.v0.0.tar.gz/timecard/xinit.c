/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: xinit.c
 *            DESCRIPTION: initializes widgets for timecard
 *      DEFINED CONSTANTS: timecard.h
 *       TYPE DEFINITIONS: timecard.h
 *      MACRO DEFINITIONS: timecard.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: TMCXinit
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout all timecard
 * source:
 * Public routines:
 *		prefixed w/TMC, no underscores, mixed case	TMCPublicRoutine
 * Private routines:
 *		no underscores, key words capitalized			PrivateRoutine
 * Global variables:
 *		prefixed w/TMC, underscores, mixed case		TMC_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 *		no underscores, mixed case							staticVariable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 *	$Log$
 *
 *========================================================================*/
#ifndef INIT_C
#define INIT_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/SmeLine.h>
#include <X11/Xaw/SmeBSB.h>
#include <stdio.h>

/* === Project Headers === */
#include "timecard.h"
#include "debug.h"

/* === external routines === */
extern void TMCStartProject();
extern void TMCStopProject();
extern void TMCTimeSheet();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
extern Widget			TMC_Top_Level;		/* shell of main window */

Widget		TMC_Main_Window;				/* visible main window */
Widget		TMC_Status_Bar;				/* status of logging */


/* === Static Variables === */

static Widget mw_title_bar;
static Widget getHelp;
static Widget fileButton;

char *file_menu[] = {			/* items in the File pull down menu */
	"Timesheet",
	"Quit"
	};



/*========================================================================
 *	Name:			TMCShutdown
 *	Prototype:	TMCShutdown()
 *					
 *
 *	Description:
 *		Creates all static widgets necessary for the Administrator
 *		to begin running.  Other widgets are created and destoryed
 *		on the fly.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
TMCShutdown(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{
	exit (0);
}


/*========================================================================
 *	Name:			TMCReadjustStatus
 *	Prototype:	TMCReadjustStatus()
 *					
 *
 *	Description:
 *		readjust the size of the status bar
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
TMCReadjustStatus(
)
{
	Arg		args[5];
	int		nargs;
	int		width, twidth;

	/* readjust the width of the status bar */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &twidth ); nargs++;
	XtGetValues( fileButton, args, nargs );
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( getHelp, args, nargs );
	twidth = twidth + width;
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( mw_title_bar, args, nargs );
	twidth = width - twidth + 1;
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, twidth ); nargs++;
	XtSetValues( TMC_Status_Bar, args, nargs );
}


/*========================================================================
 *	Name:			TMCXInit
 *	Prototype:	TMCXInit()
 *					
 *
 *	Description:
 *		Creates all static widgets necessary for the Administrator
 *		to begin running.  Other widgets are created and destoryed
 *		on the fly.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
TMCXInit ( )
{

#ifdef DEBUG
	char			fname[]="TMCXInit()";	/* name of this routine */
#endif

	int 			i;
	int			nargs;
	Arg			args[20];
	char 			buf[255];				
	Dimension	twidth, width, height;


	/* === Widgets used statically === */

	/* 
	 * the main windows
	 */
	Widget 	mw_menubox;
	Widget	mainForm;


	/*
	 * File button and menu
	 */
	Widget 	fileMenu, fileLine, fileMenuButton[NUM_FILEMENU];

	/*
	 * help button (which isn't used yet
	 */
	Widget	helpButtonBox;

	/*
	 * logging buttons
	 */
	Widget	startButton, stopButton;


	DBGEnter();

	/* 
	 * create main application window in which all other windows
	 * are displayed 
	 */

	nargs = 0;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	TMC_Main_Window = XtCreateWidget(
		"mainWindow",			/* widget name */
		formWidgetClass,		/* widget class */
		TMC_Top_Level,			/* parent widget*/
		args, nargs				/* terminate varargs list */
		);

	/*
	 * a Title Bar in the Main Window
	 */
	DBGPrint(DBG_INFO,"creating title bar\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( TMC_Top_Level, args, nargs );

	(void) sprintf ( buf, "%s R%s V%s", PROGNAME, RELEASE, VERSION );
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, width ); nargs++;
	XtSetArg ( args[nargs], XtNlabel, buf ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	mw_title_bar = XtCreateManagedWidget (
		"TitleBar",				/* widget name */
		labelWidgetClass,		/* widget class */
		TMC_Main_Window,		/* parent widget */
		args, nargs				/* argument list */
		);

	/*
	 * three windows inside the main window: a menu bar a Form/box
	 * window for the buttons, and a form window inside which will go 
	 * two main input/output windows
	 */

	/*
	 * CREATE A BOX FOR THE 4 MENU BUTTONS
	 */
	DBGPrint(DBG_INFO,"creating menu box\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( TMC_Top_Level, args, nargs );

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, width ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, mw_title_bar ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNorientation, XtorientHorizontal ); nargs++;
	XtSetArg ( args[nargs], XtNvSpace, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhSpace, 0 ); nargs++;
	mw_menubox = XtCreateManagedWidget (
		"MenuBox",
		boxWidgetClass,
		TMC_Main_Window,
		args, nargs
		);

	/*
	 * create the 4 menu buttons
	 */


	/*
	 * CREATE FILE MENU AND CHILDREN
	 */

	DBGPrint(DBG_INFO,"creating file menu\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "File" ); nargs++;
	XtSetArg ( args[nargs], XtNmenuName, "fileMenu" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	fileButton = XtCreateManagedWidget(
		"fileButton",				/* widget name */
		menuButtonWidgetClass,	/* widget class */
		mw_menubox,					/* parent */
		args, nargs					/* argument list */
		);

	/* start to add up the widths of the buttons */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &twidth ); nargs++;
	XtGetValues( fileButton, args, nargs );

	/*
	 * create menu popped down by fileButton
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Menu" ); nargs++;
	fileMenu = XtCreatePopupShell(
		"fileMenu",					/* name */
		simpleMenuWidgetClass,	/* class */
		TMC_Top_Level,				/* parent */
		args, nargs					/* no argument list needed */
		);

	/*
	 * a line seperator in the menu
	 */
	fileLine = XtCreateManagedWidget(
		"fileMenuLine",			/* name */
		smeLineObjectClass,		/* class */
		fileMenu,					/* parent */
		NULL, 0						/* no argument list needed */
		);

	/*
	 * set the menu items in the pull-down menu
	 */
	for ( i = 0; i < NUM_FILEMENU; i++ )
	{
		if ( i == NUM_FILEMENU -1 )
			(void) sprintf ( buf, "Quit" );
		else
			(void) sprintf ( buf, "fileMenu%d", i );

		nargs = 0;
		XtSetArg ( args[nargs], XtNlabel, file_menu[i] ); nargs++;

    	fileMenuButton[i] = XtCreateManagedWidget(
            buf,						/* widget name */
            smeBSBObjectClass,	/* widget class */
            fileMenu,				/* parent widget*/
				args, nargs				/* argument list */
				);

		/* set the callbacks */
		switch ( i )
		{
			case QUITOPTION:
				XtAddCallback( fileMenuButton[i], XtNcallback, TMCShutdown, NULL );
				DBGPrint(DBG_INFO,"set call back for Quit button\n");
				break;

			case TIMESHEETOPTION:
				XtAddCallback( fileMenuButton[i], XtNcallback, TMCTimeSheet, NULL );
				DBGPrint(DBG_INFO,"set call back for Timesheet button\n");
				break;

			default:
				break;
		}

	}


	/*
	 * CREATE A SPACER BETWEEN THE MENU BUTTONS AND THE HELP BUTTON
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &height ); nargs++;
	XtGetValues( fileButton, args, nargs );

	DBGPrint(DBG_INFO,"creating menu spacer\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Out" ); nargs++;
	XtSetArg ( args[nargs], XtNheight, height ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, mw_title_bar ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, mw_menubox ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNresizable, True ); nargs++;
	TMC_Status_Bar = XtCreateManagedWidget(
		"statusBar",
		labelWidgetClass,
		TMC_Main_Window,
		args, nargs
		);

	/*
	 * create a box for the help button
	 */
	DBGPrint(DBG_INFO,"creating help box\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, mw_title_bar ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, TMC_Status_Bar ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNorientation, XtorientHorizontal ); nargs++;
	XtSetArg ( args[nargs], XtNvSpace, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhSpace, 0 ); nargs++;
	helpButtonBox = XtCreateManagedWidget(
		"helpButtonBox",			/* name */
		boxWidgetClass,			/* class */
		TMC_Main_Window,			/* parent */
		args, nargs					/* arg list */
		);


	/*
	 * create button that will pop up the help window
	 */
	DBGPrint(DBG_INFO,"creating help windows\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "    " ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	getHelp = XtCreateManagedWidget(
		"getHelp",					/* name */
		commandWidgetClass,		/* class */
		helpButtonBox,				/* parent */
		args, nargs					/* arg list */
		);

	/*
	 * tell help button what routine to call when pressed
	 */
	/*
    XtAddCallback ( getHelp, XtNcallback, 
			(XtCallbackProc)ADMPopUpHelp, (XtPointer)0 );
	*/

	/* readjust the width of the status bar */
	TMCReadjustStatus();

	/* CREATE FORM WINDOW UNDER MAIN APPLICATION SHELL */

	/* 
	 * create a form window in which the record windows will go
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( mw_title_bar, args, nargs );

	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, mw_menubox); nargs++;
	XtSetArg ( args[nargs], XtNwidth, width ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	mainForm = XtCreateManagedWidget(
		"mainForm",
		formWidgetClass,
		TMC_Main_Window,
		args, nargs
		);


	/*
	 * add the buttons that will be used to start and stop
	 * project time logging
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainLeft); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNlabel, "Start Log" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 1 ); nargs++;
	startButton = XtCreateManagedWidget(
		"startButton",				/* widget name */
		commandWidgetClass,		/* class */
		mainForm,					/* parent */
		args, nargs					/* argument list */
		);

	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainLeft); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, startButton); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNlabel, "Stop Log" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 1 ); nargs++;
	stopButton = XtCreateManagedWidget(
		"stopButton",				/* widget name */
		commandWidgetClass,		/* class */
		mainForm,					/* parent */
		args, nargs					/* argument list */
		);



	/* ADD CALLBACKS FOR THE MENU FUNCTIONS */


	/*
	 * Start button callbacks
	 */
	XtAddCallback( startButton, XtNcallback,
			(XtCallbackProc)TMCStartProject, NULL );

	/*
	 * Stop button callbacks
	 */
	XtAddCallback( stopButton, XtNcallback,
			(XtCallbackProc)TMCStopProject, NULL );


	/*
	 * Manage the main windows visible form
	 */
	XtManageChild ( TMC_Main_Window );


	DBGExit();

}


#endif /* INIT_C */


