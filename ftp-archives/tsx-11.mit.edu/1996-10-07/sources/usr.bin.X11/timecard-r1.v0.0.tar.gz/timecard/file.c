/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: file.c
 *            DESCRIPTION: handles file I/O for timecard
 *      DEFINED CONSTANTS: timecard.h
 *       TYPE DEFINITIONS: timecard.h
 *      MACRO DEFINITIONS: timecard.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: TMCInit, TMCWrite
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout all timecard
 * source:
 * Public routines:
 *		prefixed w/TMC, no underscores, mixed case	TMCPublicRoutine
 * Private routines:
 *		no underscores, key words capitalized			PrivateRoutine
 * Global variables:
 *		prefixed w/TMC, underscores, mixed case		TMC_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 *		no underscores, mixed case							staticVariable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 *	$Log$
 *
 *========================================================================*/
#ifndef FILE_C
#define FILE_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Xaw/Dialog.h>
#include <X11/Xaw/Label.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* === Project Headers === */
#include "timecard.h"
#include "debug.h"

/* === external routines === */
extern void TMCPopUpWindow();
extern void TMCPopUpError();
extern void TMCReadjustStatus();

/* === Public routine prototypes === */
void TMCWriteTimeSheet();
void TMCFreeLink();
void TMCWrite();
void TMCStart();

/* === Private routine prototypes === */
time_t	makeTime( char *date, char *time );
void		addLink ( char *date, char *project, int hours, int minutes );
void		freeLink ();
void		writeTimeSheet ();

/* === Global Variables === */
extern Widget	TMC_Project_Dialog;
extern Widget	TMC_Status_Bar;
extern Widget	TMC_Error_Shell;
extern Widget	TMC_Error_Dialog;
extern Widget	TMC_FileName_Shell;
extern Widget	TMC_FileName_Dialog;

extern AppData	TMC_App_Data;

/* === Static Variables === */
static char			errormsg[255];	/* used for error message windows */
static TMC_LINK	*header=NULL;	/* head of a link list */


/*========================================================================
 *	Name:			TMCWrite
 *	Prototype:	TMCWrite()
 *					
 *
 *	Description:
 *		saves an entry to the log file
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *		TMCStart() is just the front end for allowing an action table
 *		entry for the Return key in the filename dialog.
 *	Notes:
 *		
 *========================================================================*/
void
TMCStart(
)
{
	TMCWrite( NULL, TMC_START, NULL );
	return;
}


void
TMCWrite(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{
#ifdef DEBUG
	char					fname[]="TMCWrite()";
#endif

	Arg					args[5];
	int					nargs;

	int					fd;
	char					buf[255];
	char					file[255];
	char					*project;
	char					*status;
	struct timeval		tv;
	struct timezone	tz;
	struct tm			*timeptr;
	char					date[10];
	char					time[10];


	DBGEnter();

	/*
	 * build output line
	 */

	/*
	 * first, grab the system time
	 */
	(void) gettimeofday ( &tv, &tz );
	timeptr = localtime ( &(tv.tv_sec) );

	/*
	 * get the date
	 */
	sprintf ( date, "%02d/%02d/%02d",
		timeptr->tm_mon, timeptr->tm_mday, timeptr->tm_year );

	/*
	 * get the time
	 */
	sprintf ( time, "%02d:%02d:%02d",
		timeptr->tm_hour, timeptr->tm_min, timeptr->tm_sec );

	/*
	 * what is the status of this write?
	 */
	switch ( (int) client_data )
	{
		case TMC_START:
			status = "Start";
			break;

		case TMC_STOP:
			status = "Stop";
			break;

		default:
			status = "Unknown";
			break;

	}

	/*
	 * What is the name of the project
	 */
	nargs=0;
	XtSetArg ( args[nargs], XtNvalue, &project ); nargs++;
	XtGetValues ( TMC_Project_Dialog, args, nargs );

	/*
	 * use spaces as delimeters - makes it easier to parse later
	 */
	sprintf ( buf, "%s %s %s %s\n", date, status, time, project );

	/*
	 * save it to the log file
	 */

	sprintf ( file, "%s/%s", TMC_App_Data.db_dir, TMC_App_Data.db_file );

	if ( (fd = open ( file, O_CREAT | O_APPEND | O_WRONLY, 0744 ) ) == -1 )
	{
		/*
		 * report the problem
		 */
		sprintf ( errormsg, "Can't open\n%s.\nerrno=%d", file, errno );
		TMCPopUpError ( errormsg );

	}
	else 
	{

		/*
		 * write the entry to file
		 */
		if ( write ( fd, buf, strlen(buf) ) == -1 )
		{
			/*
			 * report the problem
			 */
			sprintf ( errormsg, "Can't write to\n%s.\nerrno=%d", file, errno );
			TMCPopUpError ( errormsg );

		}
		else
		{
			DBGPrintf(DBG_INFO, ("Wrote to log file:\n\t*%s*\n", buf) );
			close ( fd );

			/*
			 * change the status bar to its appropriate setting
			 */
			switch ( (int) client_data )
			{
				case TMC_START:
					nargs=0;
					XtSetArg ( args[nargs], XtNlabel, "In" ); nargs++;
					XtSetArg ( args[nargs], XtNjustify, XtJustifyCenter ); nargs++;
					XtSetValues ( TMC_Status_Bar, args, nargs );
					TMCReadjustStatus();
					break;

				case TMC_STOP:
					nargs=0;
					XtSetArg ( args[nargs], XtNlabel, "Out" ); nargs++;
					XtSetArg ( args[nargs], XtNjustify, XtJustifyCenter ); nargs++;
					XtSetValues ( TMC_Status_Bar, args, nargs );
					TMCReadjustStatus();
					break;
	
				default:
					status = "Unknown";
					break;

			}

		}
	}


	DBGExit();

}

/*========================================================================
 *	Name:			TMCTimeSheet
 *	Prototype:	TMCTimeSheet()
 *					
 *
 *	Description:
 *		builds a timesheet from data in the log file.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
TMCTimeSheet(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{
#ifdef DEBUG
	char		fname[]="TMCTimeSheet()";
#endif

	char		buf[255];
	char		file[255];
	char		date[10];
	char		time[10];
	char		status[6];
	char		project[255];
	FILE		*fd;
	int		state;
	time_t	starttime=0;
	time_t	stoptime=0;
	int		difftm;
	int		hours, minutes;


	DBGEnter();


	/*
	 * open the log file
	 */
	sprintf ( file, "%s/%s", TMC_App_Data.db_dir, TMC_App_Data.db_file );

	if ( ( fd = fopen ( file, "r" ) ) == NULL )
	{
		/*
		 * report the problem
		 */
		sprintf ( errormsg, "Can't open\n%s.\nerrno=%d", file, errno );
		TMCPopUpError ( errormsg );
		return;

	}

	/*
	 * state is what we are expecting next from the log file
	 */
	state = TMC_START;

	/*
	 * while more lines in file...
	 */
	while ( fgets ( buf, 255, fd ) != NULL )
	{

		sscanf ( buf, "%s %s %s %[^\n]s", date, status, time, project);

		DBGPrintf(DBG_INFO,("\n\tDate: %s\tStatus: %s\n\tTime: %s\tProject: %s\n",
					date, status, time, project ));

		switch ( state )
		{
			case TMC_START:
				/*
				 * if the line we just read is a Start but the current state
				 * is Start then we've got bogus info - ignore it
				 */
				if ( strcmp ( status, "Stop" ) == 0 )
				{
					DBGPrint(DBG_INFO, 
						"Expected Start, found Stop!  Ignoring.\n" );
					continue;
				}

				/*
				 * convert the date and time to a time_t struct
				 */
				if ( (starttime = makeTime( date, time )) == (time_t)(-1) )
				{
					DBGPrint(DBG_INFO, 
						"Expected Stop, found Start!  Ignoring.\n" );
					continue;
				}

				state = TMC_STOP;

				break;


			case TMC_STOP:
				/*
				 * if the line we just read is a Stop but the current state
				 * is Stop then we've got bogus info - ignore it
				 */
				if ( strcmp ( status, "Start" ) == 0 )
				{
					DBGPrint(DBG_INFO, 
						"Expected Stop, found Start!  Ignoring.\n" );
					continue;

				}
				/*
				 * convert the date and time to a time_t struct
				 */
				if ( (stoptime = makeTime( date, time )) == (time_t)(-1) )
				{
					DBGPrint(DBG_INFO, 
						"Expected Stop, found Start!  Ignoring.\n" );
					continue;
				}

				/*
				 * compute the amount of time worked
				 */
				difftm = (int) difftime( stoptime, starttime );
				hours = (int) ( difftm / 3600 );
				difftm = difftm - (hours * 3600);
				minutes = (int) ( difftm / 60 );

				/*
				 * add a link with the total time info
				 */
				addLink( date, project, hours, minutes );

				state = TMC_START;

				break;

		}
	}

	/*
	 * close the open log file
	 */
	fclose ( fd );

	/*
	 * write out the timesheet
	 */
	writeTimeSheet();

}



/*========================================================================
 *	Name:			makeTime
 *	Prototype:	makeTime( char *date, char *time )
 *					
 *
 *	Description:
 *		converts date and time strings into time_t structures.
 *
 *	Input Arguments:
 *		char *date		must be of the format of mm/dd/yy where
 *							mm is the month, dd the day, and yy the year since 1900
 *		char *time		must be of the format hh:mm:ss where
 *							hh is the hour, mm is the minute, ss is the seconds.
 *
 *	Output Arguments:
 *	Return Values:
 *		returns a time_t value (a long on Linux).
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *
 *	Restrictions:
 *		No error checking is done on the input.
 *
 *	Notes:
 *		time_t is a long on Linux - this should allocate a pointer to a
 *		time_t and return the pointer, but I'm cheating.
 *		
 *========================================================================*/
time_t
makeTime(
	char	*date,
	char	*time
)
{
#ifdef DEBUG
	char			fname[]="makeTime()";
#endif

	struct tm	tmstruct;
	int			month, day, year;
	int			hours, minutes, seconds;
	char			dummy;

	DBGEnter();

	/*
	 * pull the day, month, and year from the date
	 */
	sscanf ( date, "%02d%c%02d%c%02d", 
		&month, &dummy, &day, &dummy, &year );
	DBGPrintf(DBG_INFO,
		("Month: %d\tDay: %d\tYear: %d\n", month, day, year));

	/*
 	 * pull the hours, minutes and seconds from the time
	 */
	sscanf ( time, "%02d%c%02d%c%02d", 
		&hours, &dummy, &minutes, &dummy, &seconds );
	DBGPrintf(DBG_INFO,
		("Hours: %d\tMinutes: %d\tSeconds: %d\n", hours, minutes, seconds));

	/*
 	 * fill in the tm struct
	 */
	tmstruct.tm_sec = seconds;
	tmstruct.tm_min = minutes;
	tmstruct.tm_hour = hours;
	tmstruct.tm_mday = day;
	tmstruct.tm_mon = month;
	tmstruct.tm_year = year;

	/*
	 * do the conversion and return
	 */
	return ( mktime ( &tmstruct ) );

}


/*========================================================================
 *	Name:			addLink
 *	Prototype:	addLink( char *date, char *project, int hours, int minutes )
 *					
 *
 *	Description:
 *		add a link to the list of total-worked times computed
 *
 *	Input Arguments:
 *		char *date		must be of the format of mm/dd/yy where
 *							mm is the month, dd the day, and yy the year since 1900
 *		char *project	name of project that was worked on
 *		int hours		number of hours worked
 *		int minutes		number of minutes (>1 hour) worked
 *
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *		TMC_LINK		*header		head of link list
 *
 *	External Routines:
 *	Method:
 *
 *	Restrictions:
 *		No error checking is done on the input.
 *
 *	Notes:
 *		
 *========================================================================*/
void
addLink(
	char	*date,
	char	*project,
	int	hours,
	int	minutes
)
{
#ifdef DEBUG
	char	fname[]="addLink()";
#endif

	TMC_LINK		*linkptr, *current;

	DBGEnter();

	/*
	 * allocate a link
	 */

	linkptr = (TMC_LINK *) malloc ( sizeof ( TMC_LINK ) );

	/*
	 * fill it in
	 */
	linkptr->next = (int)NULL;
	strcpy(linkptr->date, date );
	strcpy(linkptr->project, project );
	linkptr->hours = hours;
	linkptr->minutes = minutes;

	/*
	 * if the header is not set, make this the first link
	 */
	if ( header == NULL )
		header = linkptr;
	else
	{
		/*
		 * find the end of the link list
		 */
		current = header;
		while ( current->next != (int) NULL )
			current = (TMC_LINK *)current->next;

		/*
		 * add the link to the end of the list
		 */
		current->next = (int)linkptr;
	}

	DBGExit();
}
	

/*========================================================================
 *	Name:			freeLink
 *	Prototype:	freeLink()
 *					
 *
 *	Description:
 *		free up link list
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *		TMC_LINK		*header		head of link list
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
freeLink(
)
{
	TMC_LINK		*current, *next;

	current = header;
	while ( current != NULL )
	{
		next = (TMC_LINK *)current->next;
		free ( current );
		current = next;
	}

	header = NULL;
}

/*
 * a callback version, so "Cancel" in the filename dialog can clean up
 */
void
TMCFreeLink(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{
	freeLink();
}


/*========================================================================
 *	Name:			writeTimeSheet
 *	Prototype:	writeTimeSheet()
 *					
 *
 *	Description:
 *		Front end to writeTimeSheet2() which does the actual writing.
 *		This routine just pops up the dialog to get the filename.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
writeTimeSheet(
)
{
	TMCPopUpWindow ( TMC_FileName_Shell );
}


/*========================================================================
 *	Name:			TMCWriteTimeSheet2
 *	Prototype:	TMCWriteTimeSheet2()
 *					
 *
 *	Description:
 *		Runs the link list and writes the totals to a date stamped file.
 *		This is actually a callback for the file name dialog box.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *
 *	Global Variables:
 *		TMC_LINK		*header		head of link list
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
TMCWriteTimeSheet2(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{
	TMC_LINK	*current;
	char		startdate[10], enddate[10], currentdate[10];
	int		hours, minutes, total=0, worktotal=0;
	int		fd;
	char		*file;
	char		buf[255];

	current = header;
	if ( current != NULL )
	{

		/*
		 * open the output file
		 */
		file = XawDialogGetValueString ( TMC_FileName_Dialog );
		sprintf ( buf, "%s/%s", TMC_App_Data.db_dir, file );

		if ( (fd = open ( buf, O_WRONLY | O_CREAT | O_EXCL, 0744 ) ) == -1 )
		{
			/*
			 * report the problem
			 */
			sprintf ( errormsg, "Can't open\n%s.\nerrno=%d", buf, errno );
			TMCPopUpError ( errormsg );
			return;
	
		}
	
		/*
		 * find the start and end dates
		 */
		strcpy ( startdate, current->date );
		while ( current->next != (int) NULL )
			current = (TMC_LINK *)current->next;
		strcpy ( enddate, current->date );


		/*
		 * print out the headers
		 */
		sprintf ( buf, "%s\n", LINE );
		write ( fd, buf, strlen ( buf ) );
		sprintf (buf, "Timesheet from %s to %s\n\n", startdate, enddate );
		write ( fd, buf, strlen ( buf ) );
		sprintf ( buf, "Date     Time Worked  Project Totals\n"); 
		write ( fd, buf, strlen ( buf ) );
		sprintf ( buf, "%s\n", LINE );
		write ( fd, buf, strlen ( buf ) );


		/*
		 * and initialize the output date
		 */
		strcpy ( currentdate, "" );
	}
	else
	{
		/*
		 * print error
		 */
		sprintf ( errormsg, "No data for timesheet!" );
		TMCPopUpError ( errormsg );
		return;
	}

	current = header;
	while ( current != NULL )
	{
		/*
		 * if the date in this link is the same as the current date
		 * then print
		 *		<nothing> hours:minutes project
		 *		and add the time to the current total
		 * else print
		 *		<nothing> <nothing>     "Total:" total-time
		 *		date      hours:minutes project
		 *		and save the new date
		 */
		if ( strcmp ( currentdate, current->date ) == 0 )
		{
			sprintf ( buf, "%s    %02d:%02d     %s\n", 
				"        ", current->hours, current->minutes, current->project );
			write ( fd, buf, strlen ( buf ) );
			total = total + current->hours * 60 + current->minutes;
		}
		else
		{
			/*
			 * if this is not the very first link
			 */
			if ( strcmp ( currentdate, "" ) != 0 )
			{
				/*
				 * compute total time in hours and minutes
				 */
				hours = (int) ( total / 60 );
				minutes = total - ( hours * 60 );
				worktotal = worktotal + total;
	
				/*
				 * print the total time for the last project
				 */
				sprintf ( buf, "%s    %s%s   %02d:%02d\n\n", 
					currentdate, "         ", "        ", hours, minutes );
				write ( fd, buf, strlen ( buf ) );
				sprintf ( buf, "%s\n", LINE );
				write ( fd, buf, strlen ( buf ) );

			}

			/*
			 * print the new date and data
			 */
			sprintf ( buf, "%s    %02d:%02d     %s\n", 
				current->date, current->hours, current->minutes, current->project );
			write ( fd, buf, strlen ( buf ) );

			/*
			 * save the new date and total
			 */
			strcpy ( currentdate, current->date );
			total = current->hours * 60 + current->minutes;
		}

		/*
		 * get next link
		 */
		current = (TMC_LINK *)current->next;

	}
	/*
	 * compute total time in hours and minutes for the last project
	 */
	hours = (int) ( total / 60 );
	minutes = total - ( hours * 60 );
	worktotal = worktotal + total;
	
	/*
	 * print the total time for the last project
	 */
	sprintf ( buf, "%s    %s%s   %02d:%02d\n", 
		currentdate, "         ", "        ", hours, minutes );
	write ( fd, buf, strlen ( buf ) );
	sprintf ( buf, "%s\n", LINE );
	write ( fd, buf, strlen ( buf ) );

	/*
	 * finally, compute and print the total hours worked for the period
	 */
	hours = (int) ( worktotal / 60 );
	minutes = worktotal - ( hours * 60 );
	sprintf ( buf, "Total hours worked:   %02d:%02d\n", hours, minutes );
	write ( fd, buf, strlen ( buf ) );

	close ( fd );

	/*
	 * and free up the links - we can't do this anyplace else since we
	 * could end up freeing the links before we actually write the data!
	 */
	freeLink();
}

#endif /* FILE_C */
