/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: xutil.c
 *            DESCRIPTION: utilities for handling windows
 *      DEFINED CONSTANTS: timecard.h
 *       TYPE DEFINITIONS: timecard.h
 *      MACRO DEFINITIONS: timecard.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: TMCPopUpWindow, TMCStart, TMCStop
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout all timecard
 * source:
 * Public routines:
 *		prefixed w/TMC, no underscores, mixed case	TMCPublicRoutine
 * Private routines:
 *		no underscores, key words capitalized			PrivateRoutine
 * Global variables:
 *		prefixed w/TMC, underscores, mixed case		TMC_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 *		no underscores, mixed case							staticVariable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 *	$Log$
 *
 *========================================================================*/
#ifndef XUTIL_C
#define XUTIL_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <stdio.h>

#include "timecard.h"
#include "debug.h"

extern void TMCWrite();
extern void TMCPopUpError();

extern Widget TMC_Top_Level;
extern Widget TMC_Status_Bar;
extern Widget TMC_Error_Shell;
extern Widget TMC_Error_Dialog;
extern Widget TMC_Project_Shell;

void
TMCPopUpWindow(
	Widget w
)
{
	Arg				args[5];
	int				nargs;
   Window 			root, child;
   unsigned int 	mask;
   int 				root_x, root_y, child_x, child_y;

	/*
	 * place the pop up right by the cursor
	 */
	XQueryPointer(XtDisplay(TMC_Top_Level), XtWindow(TMC_Top_Level),
		&root, &child,
		&root_x, &root_y, &child_x, &child_y, &mask);

	nargs=0;
	XtSetArg( args[nargs], XtNx, root_x ); nargs++;
	XtSetArg( args[nargs], XtNy, root_y ); nargs++;
	XtSetValues( w, args, nargs );

	XtPopup ( w, XtGrabExclusive );
}

void
TMCPopDownWindow(
	Widget w,
	XtPointer client_data,
	XtPointer clall_data
)
{
	XtPopdown ( (Widget) client_data );
}

void
TMCPopDown(
	Widget w,
	XEvent *event,
	String *string,
	Cardinal *cardinal
)
{
	Widget	parent;

	/*
	 * find the Shell to pop down
	 */
	parent = w;
	while ( XtIsShell ( parent ) != True ) 
		parent = XtParent ( parent );
		
	XtPopdown ( (Widget) (parent) );
}


void
TMCStartProject(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{
	Arg		args[4];
	int		nargs;
	String	string;
	char		buf[128];

	/*
	 * Check state of project
	 */
	nargs=0;
	XtSetArg( args[nargs], XtNlabel, &string ); nargs++;
	XtGetValues ( TMC_Status_Bar, args, nargs );

	if ( strcmp ( string, "In" ) == 0 )
	{
		/*
		 * already logged in - tell user
		 */
		sprintf ( buf, "Already\nLogged In!" );
		TMCPopUpError ( buf );
	}
	else
	{
		/*
		 * get the project info
		 */
		TMCPopUpWindow ( TMC_Project_Shell );
	}
}


void
TMCStopProject(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{
	Arg		args[4];
	int		nargs;
	String	string;
	char		buf[128];

	/*
	 * Check state of project
	 */
	nargs=0;
	XtSetArg( args[nargs], XtNlabel, &string ); nargs++;
	XtGetValues ( TMC_Status_Bar, args, nargs );

	if ( strcmp ( string, "Out" ) == 0 )
	{
		/*
		 * already logged out - tell user
		 */
		sprintf ( buf, "Not Currently\nLogged In!" );
		TMCPopUpError ( buf );
	}
	else
	{
		/*
		 * logout
		 */
		TMCWrite( NULL, TMC_STOP, NULL );
	}
}

#endif /* XUTIL_C */
