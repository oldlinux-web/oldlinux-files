/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: main.c
 *            DESCRIPTION: initialization of timecard
 *      DEFINED CONSTANTS: timecard.h
 *       TYPE DEFINITIONS: timecard.h
 *      MACRO DEFINITIONS: timecard.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: 
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout all timecard
 * source:
 *
 * Public routines:
 *		prefixed w/TMC, no underscores, mixed case	TMCPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/TMC, underscores, mixed case		TMC_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef MAIN_C
#define MAIN_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <stdio.h>

/* === Project Headers === */
#include "timecard.h"
#include "debug.h"

/* === external routines === */
extern void TMCInit();
extern void TMCXInit();
extern void TMCCreateTransient();
extern void TMCWrite();
extern void TMCStart();
extern void TMCWriteTimeSheet2();
extern void TMCPopDown();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */

/*
 * local
 */
Widget			TMC_Top_Level;			/* mother of all widgets */
XtAppContext	TMC_App_Context;		/* application context */
AppData			TMC_App_Data;			/* application resource data */


/* === Static Variables === */
static XrmOptionDescRec	options[] = {
	{"-dbdir",		"*dbDir",		XrmoptionSepArg,	NULL },
	{"-dbfile",		"*dbFile",		XrmoptionSepArg,	NULL },
	{"-help",		"*help",			XrmoptionNoArg,	"True" },
};

static XtActionsRec	dialogActions[] = {
	{"TMCtimesheet", (XtActionProc)TMCWriteTimeSheet2},
	{"TMCfilename", (XtActionProc)TMCStart},
	{"TMCpopdown", (XtActionProc)TMCPopDown},
};

#define offset(field)		XtOffset(AppDataPtr, field)
static XtResource resources[] = {
	{ "dbDir", "DbDir",			/* resource name and class */
		XtRString,					/* resource type representation */
		sizeof(String),			/* size of resource representation */
		offset(db_dir),			/* offset into resource list */
		XtRImmediate,				/* representative type for default value */
		DEFAULT_DB_DIR				/* default value */
	},
	{ "dbFile", "DbFile",		/* resource name and class */
		XtRString,					/* resource type representation */
		sizeof(String),			/* size of resource representation */
		offset(db_file),			/* offset into resource list */
		XtRImmediate,				/* representative type for default value */
		DEFAULT_DB_FILE			/* default value */
	},
	{ "help", "help",				/* resource name and class */
		XtRBoolean,					/* resource type representation */
		sizeof(Boolean),			/* size of resource representation */
		offset(help),				/* offset into resource list */
		XtRImmediate,				/* representative type for default value */
		False							/* default value */
	},
};
#undef offset
		

/*========================================================================
 *	Name:			main	
 *	Prototype:	main( int argc, char **argv )
 *
 *	Description:
 *		well, you gotta start somewhere....
 *
 *	Input Arguments:
 *		int	argc			number of command line arguments
 *		char	**argv		command line argument list
 *		
 *	Output Arguments:
 *	Return Values:
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
main(
	int argc,
	char **argv
)
{

#ifdef DEBUG
	char				fname[]="main()";
#endif


	/*
	 * debug output to /dev/console, if -DDEBUG was set at compile time
	 * otherwise DBGxxx macros have no effect.
	 */
	DBGOpen( DEBUG_FD );
	DBGEnter();

	
	/*
	 * initialize the top level so we can check command line args
	 * before doing much else.
	 */
	TMC_Top_Level = XtVaAppInitialize(
			&TMC_App_Context,					/* Application context */
			"Timecard",							/* application class name */
			options, XtNumber(options),	/* command line option list */
			&argc, argv,						/* command line args */
			NULL,									/* for missing app-defaults file */
			NULL);								/* terminate varargs list */

	/*
	 * Grab all the application specific resources
	 */
	XtVaGetApplicationResources(
			TMC_Top_Level,
			&TMC_App_Data,
			resources,
			XtNumber( resources ),
			NULL
			);

	/*
	 * if the user requested help, provide it
	 */
	if ( TMC_App_Data.help == True ) {
		(void) printf( USAGE );
		exit ( 0 );
	}

	/*
	 * add default actions
	 */
	XtAppAddActions(TMC_App_Context, dialogActions, XtNumber ( dialogActions ));


	/*
	 * NOW BUILD ALL THE WIDGETS WE'LL NEED AT START UP
	 */


	/* 
	 * all transients we'll need right from the start
	 */
	TMCCreateTransient();

	/* 
	 * the rest of the windows
	 */
	TMCXInit();


	/*
	 * make me real, Gepetto!
	 */
	DBGPrint(DBG_INFO, "Calling XtRealizeWidget\n");
	XtRealizeWidget(TMC_Top_Level);


	/*
	 * ok, sit and spin...
	 */
	DBGPrint(DBG_INFO, "Calling XtAppMainLoop\n");
	XtAppMainLoop(TMC_App_Context);

}

#endif /* MAIN_C */
