/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: debug.h
 *            DESCRIPTION: header file for debug facility
 *      DEFINED CONSTANTS: 
 *       TYPE DEFINITIONS: 
 *      MACRO DEFINITIONS: 
 *       GLOBAL VARIABLES: 
 *                  NOTES: Set tabstops=3 for readability
 *								 : The debug macros make use of a static
 *								 : character string called fname[].  If this
 *								 : is not defined, the debug macros will not
 *								 : compile.
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Defined values (except debug macros):	
 *		prefixed w/ADM, underscores and all caps		ADM_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DEBUG_H
#define DEBUG_H

/* make sure the top level header file is included */
#ifndef ADMIN_H
#include "timecard.h"
#endif
#ifndef _SYS_STAT_H
#include <sys/stat.h>
#endif
#ifndef _SYS_TYPES_H
#include <sys/types.h>
#endif
#ifndef _UNISTD_H
#include <unistd.h>
#endif
#ifndef _FCNTL_H
#include <fcntl.h>
#endif

#ifdef DEBUG


#define DBG						"DBG411"				/* identifies debug lines */
#define DEBUG_CONSOLE_DEV	"/dev/console"		/* wher to write to */
#define DEBUG_ENTER			"Entered routine\n"
#define DEBUG_EXIT			"Exiting routine\n"

#define DBG_PROC			0x01					/* procedure specific debug */
#define DBG_INFO			0x02					/* general info */
#define DBG_SPECIAL		0x0A					/* special? */


extern char *ADMDebugOut();		/* found in debug.c */


/* provide some storage for the debug message strings */
#ifdef MAIN_C
int	debug_level = DBG_PROC | DBG_INFO | DBG_SPECIAL;		
/*
char	DBGbuf[MAXRECORDSIZE];
*/
char	*DBGbuf;
int	DEBUG_FD;					/* filedesc for debug output */

#else

extern char	*DBGbuf;
extern int	debug_level;
extern int	DEBUG_FD;

#endif

/* Open the Debug output stream */
#define DBGOpen(fd)																	\
{																							\
	struct stat DBG_stat_buf;														\
	if ( stat( DEBUG_CONSOLE_DEV, &DBG_stat_buf) != 0 )					\
	{																						\
		printf( "%s: Can't stat %s\n",DBG, DEBUG_CONSOLE_DEV );			\
		exit(-1);																		\
	}																						\
	if ( ( DBG_stat_buf.st_mode & S_IWOTH ) != S_IWOTH )					\
	{																						\
		printf( "%s: Can't write to %s\n", DBG, DEBUG_CONSOLE_DEV );	\
		exit(-1);																		\
	}																						\
	fd = open ( "/dev/console", O_WRONLY );									\
}


/* Close the Debug output stream */
#define DBGClose(fd)					\
{											\
	if ( fd != 0 )						\
		close ( fd );					\
}

	
/* Enter a routine */
#define DBGEnter()															\
{																					\
	if (debug_level & DBG_PROC)											\
	{																				\
		write ( DEBUG_FD, fname, strlen(fname) );						\
		write ( DEBUG_FD, ": ", 2 );										\
		write ( DEBUG_FD, DEBUG_ENTER, strlen (DEBUG_ENTER) );	\
	}																				\
}

/* Exit a routine */
#define DBGExit()																\
{																					\
	if (debug_level & DBG_PROC)											\
	{																				\
		write ( DEBUG_FD, fname, strlen(fname) );						\
		write ( DEBUG_FD, ": ", 2 );										\
		write ( DEBUG_FD, DEBUG_EXIT, strlen (DEBUG_EXIT) );		\
	}																				\
}


/*
 * Print just the message provided
 *
 * NOTE:  the newline is provided!
 */
#define DBGPrint(level,A)									\
{																	\
	if (debug_level & level)		 						\
	{																\
		write ( DEBUG_FD, fname, strlen(fname) );		\
		write ( DEBUG_FD, ": ", 2 );						\
		write ( DEBUG_FD, A, strlen(A) );				\
	}																\
}


/*
 * format some debug output
 * An example of using this is:
 *		DBGPrintf(DBG_INFO, ("name: %s\n", name));
 *
 * This would expand the sprintf() call below to:
 * sprintf ( DBGbuf, "name: %s\n", name );
 *
 * NOTE:  the caller must specify the newline!
 * NOTE2: this macro relies on the ADMDebugOut()
 * 		 routine found in debug.c!
 */

#define DBGPrintf(level,A)									\
{																	\
	if (debug_level & level) 								\
	{																\
/* \
		strcpy ( DBGbuf, (char *)ADMDebugOut A );		\
*/ \
		DBGbuf= (char *)ADMDebugOut A ;		\
		write ( DEBUG_FD, fname, strlen(fname) );		\
		write ( DEBUG_FD, ": ", 2 );						\
		write ( DEBUG_FD, DBGbuf, strlen(DBGbuf) );	\
	}																\
}

#else

#define DBGOpen(fd)
#define DBGClose(fd)
#define DBGEnter()
#define DBGExit()
#define DBGPrint(level, A)
#define DBGPrintf(level, A)

#endif /* DEBUG */


#endif /* DEBUG_H */
