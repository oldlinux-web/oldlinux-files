/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: timecard.h
 *            DESCRIPTION: header file for timecard program
 *      DEFINED CONSTANTS: 
 *       TYPE DEFINITIONS: 
 *      MACRO DEFINITIONS: 
 *       GLOBAL VARIABLES: 
 *                  NOTES: Set tabstops=3 for readability
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Defined values (except debug macros):	
 *		prefixed w/TMC, underscores and all caps		TMC_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef TIMECARD_H
#define TIMECARD_H

#ifndef _XtStringDefs_h_
#include <X11/StringDefs.h>
#endif
#ifndef _XtIntrinsic_h
#include <X11/Intrinsic.h>
#endif


/*
 * Usage statement
 */

#define USAGE \
"Timecard accepts all standard X Toolkit command line options, plus\n\
the following:\n\
\n\
timecard [ -dbdir directory | -dbfile dbfilename | -help ]\n\
where\n\
directory      specifies what directory the database files are in\n\
dbfilename     name of the database file\n\
help           gives this help text\n\
\n\
"

/*
 * an ASCII line seperator
 */
#define LINE \
"------------------------------------------------------------------------------"

/*
 * Program info
 */
#define PROGNAME		"Timecard"
#define RELEASE		"1"
#define VERSION		"0.0"


/*
 * file and directory names
 */
#define DEFAULT_DB_DIR	"/usr/local/timecard"
#define DEFAULT_DB_FILE "tc"


/*
 * menu options
 */
#define NUM_FILEMENU		2	/* number of options in the File pull down menu */
#define TIMESHEETOPTION	0	/* timesheet option */
#define QUITOPTION		1	/* quit option */


/*
 * Start and Stop states
 */
#define TMC_START			0
#define TMC_STOP			1


/* === typedefs and structs === */

/*
 * The application resources data structure
 */
typedef struct {
   String   db_dir;        /* name of the directory where the db lives */
   String   db_file;       /* name of the database flat file */
   Boolean  help;          /* provide cmd line help, if requested */
} AppData, *AppDataPtr;


/*
 * link used when computing total time worked
 */
typedef struct {
	int	next;
	char	date[10];
	char	project[255];
	int	hours;
	int	minutes;
} TMC_LINK;

#endif /* TIMECARD_H */
