#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <Xm/XmAll.h>
#include "funmenu.h"

#define Nbsecond 200 
#define NbDialog 10
#define Nb_element 100
#define FUNMENURC "/usr/local/etc/"

Widget  main_widget;
Widget dialog[Nb_element];
Widget dialogcurrent;
Widget Button[Nb_element];
Widget menu_bar;
Widget WarningDialog0;
int NbDtotal=0,NbTtotal=0;

char namesave[200];
Boolean knownamesave=False;

char second[Nbsecond][100];
Boolean erasetmp=False;
Boolean orientation=True;

char *PrendentreGuillemet(FILE *f)
{char s[100];
int n=0;char c;
s[n]=0;
while((c=fgetc(f))!=(int)'"')  
 {if (c==-1){fprintf(stderr,"error file format \n");exit(-1);}
  s[n]=c;n++;
 }
s[n]=0;
return s;
}
char DonneNextChar(FILE *f)
{char c;
do {c=fgetc(f);
 if (c==-1){fprintf(stderr,"error file format \n");exit(-1);}
   } while(c!='"' &&  c!='{');
return c;
}

/***********************************************/
/*   call back  
************************************************/

void action2(Widget w,XtPointer client,XtPointer appel)
{
int bit = (int) client;
char tmp[200];
strcpy(tmp,second[bit]);
strcat(tmp," &");
system(tmp);
}

void SetupButton(FILE *fichier,Widget mere)
{
char nom[100];
XmString label_str;
char c;
WarningDialog0=XmCreateWarningDialog(mere,"WarningDialog0",NULL,0);
while(1)  /* boucle infinie sortie par } */
{
fscanf(fichier,"%s",nom);
if (nom[0]=='}') return;
c= DonneNextChar(fichier);
switch (c) {
case '{':
	dialog[NbDtotal]=XmCreatePulldownMenu(mere,nom,NULL,0);
	label_str=XmStringCreateSimple(nom);
 	XtVaCreateManagedWidget(nom,xmCascadeButtonWidgetClass,mere,
				XmNlabelString,label_str,
				XmNsubMenuId,dialog[NbDtotal],NULL);
	SetupButton(fichier,dialog[NbDtotal]);
	break;
case  '"':
	strcpy( second[NbTtotal], PrendentreGuillemet(fichier));
	Button[NbTtotal]= XtVaCreateManagedWidget(nom,xmPushButtonGadgetClass,mere,NULL);
	XtAddCallback(Button[NbTtotal],XmNactivateCallback, action2,NbTtotal);
	NbTtotal++;
	break;
default:
	fprintf(stderr,"erreur fichier %c ",c);
	exit(-1);
 	break;
  } 
 }
}

SetupDialog(FILE *f)
{int ac=0;
 char nom[100];
 Arg args[10];
Widget row,other;
char c;
row=XmCreateForm(main_widget,"Row",NULL,0);
XtSetArg(args[ac], XmNtopAttachment, XmATTACH_FORM); ac++;
XtSetArg(args[ac], XmNrightAttachment, XmATTACH_FORM); ac++;
XtSetArg(args[ac], XmNleftAttachment, XmATTACH_FORM); ac++;
XtSetArg(args[ac], XmNbottomAttachment, XmATTACH_FORM); ac++;
if (!orientation) XtSetArg(args[ac], XmNorientation, XmVERTICAL); ac++;
menu_bar=XmCreateMenuBar(row,"MenuBar",args,ac);
/*dialog[NbDtotal]=XmCreatePulldownMenu(menu_bar,"Linux",NULL,0);
label_str=XmStringCreateSimple("Start Linux");
other=XtVaCreateManagedWidget("Linux",xmCascadeButtonWidgetClass,menu_bar,
				XmNlabelString,label_str,
				XmNsubMenuId,dialog[NbDtotal],NULL);*/
c= DonneNextChar(f);
if (c!='{') {fprintf(stderr,"erreur debut fichier \n");exit(-1);}
SetupButton(f,menu_bar);
XtManageChild(menu_bar);
XtManageChild(row);
}
/* to destroy zombi process */
filappelpere(int n)
{
wait(0);
signal(SIGCLD,filappelpere);
}
main(int argc,char **argv)
{
char tmp[200],tmp2[200],tmp3[50];
char *home;
FILE *fichier;
Boolean std=False;
if ((home=getenv("HOME"))==NULL) {fprintf(stderr,"env HOME ?"); exit(1);}
strcpy(tmp,home);
strcat(tmp,"/.funmenurc");
strcpy(tmp2,"/tmp/funmenurc");
sprintf(tmp3,"%d",getpid);
strcat(tmp2,tmp3);
if (argc>1) 
  {if (!strcmp(argv[1],"-h")) {printf("%s\n",help);exit(0);
				}
  if (!strcmp(argv[1],"-Win95")) {erasetmp=True;
				if ((fichier=fopen(tmp2,"w"))==NULL)
				{fprintf (stderr,"error creation file ");
				exit(-1);}
				fprintf(fichier,"%s\n",ressourc);
				fclose(fichier);
				}
  if (!strcmp(argv[1],"-Linux")) {erasetmp=True;
				if ((fichier=fopen(tmp2,"w"))==NULL) 
				{fprintf (stderr,"error creation file ");
				exit(-1);}
				fprintf(fichier,"%s\n",ressourc2);
				fclose(fichier);
				}
  if (!strcmp(argv[1],"-NeXT")) {erasetmp=True;
				if ((fichier=fopen(tmp2,"w"))==NULL) 
				{fprintf (stderr,"error creation file ");
				exit(-1);}
				fprintf(fichier,"%s\n",ressourc3);
				fclose(fichier);
				orientation=False;
				}
  if (!strcmp(argv[1],"-rc")) {fichier=fopen(tmp,"w");
				fprintf(fichier,"%s",ressourc);
				fclose(fichier);
				exit(0);
				}
  if (!strcmp(argv[1],"-c")) std=True;
			
  }
signal(SIGCLD,filappelpere);
if (std==True) fichier=stdin;
 else 
if (erasetmp==True) 
{if ((fichier=fopen(tmp2,"r"))==NULL) 
{fprintf(stderr,"no .funmenurc create\n%s",help );exit(1);}}
else 
{
if ((fichier=fopen(tmp,"r"))==NULL) {
strcpy(tmp,FUNMENURC);
strcat(tmp,"/.funmenurc");
if ((fichier=fopen(tmp,"r"))==NULL) {
fprintf(stderr,"no .funmenurc \n%s",help );exit(1);}
}
}
main_widget = XtInitialize(argv[0],"funmenu",NULL,0,&argc,argv);
SetupDialog(fichier);
fclose(fichier);
if (erasetmp) unlink(tmp2);
XtRealizeWidget(main_widget);
XtMainLoop();
}
