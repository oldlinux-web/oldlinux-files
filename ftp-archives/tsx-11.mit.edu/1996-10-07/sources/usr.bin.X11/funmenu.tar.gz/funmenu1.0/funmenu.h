char *ressourc="{ start_linux {
		internet { news	{ xrn \"xrn\"
				tin 	\"xterm -e rtin\"
				}
			  mail { xmail \"xmail\"
				 elm \"xterm -e elm\"
				 xbiff \"xbiff\"
				}
			  web { netscape \"netscape\"
				xmosaic \"xmosaic\"
				lynx \"xterm -e lynx \"
				}
			}
		edit 	{	xemacs \"xemacs\"
				xedit \"xedit\"
				aXe	\"faxe\"
			}
		graphic	{	xpaint \"xpaint\"
				xv \"xv\"
			}
		terminal  { xterm \"xterm -sb -fn 7x14 \"
			    vt100  \"rxvt -font 7x14 -ls \"
			  }
		Games	{	xblast \"xterm -e xblast\"
				tetris { xtetris \"xtetris\"
					 xhextris \"xhextris\"
					}
				netmaze \"netmaze\"
				xtank \"xtank\"
			}			
	screen  {
		swarn \"xlock -nice 0 -mode swarm\"
		flame \"xlock -nice 0 -mode flame\"
		lockswarn \"xlock -nice 0 -mode swarm\"
		lockflame \"xlock -nice 0 -mode flame\"
		}
	xkill {xkill \"xkill \"}
	}
}\n";
char *ressourc2="{ internet { news	{ xrn \"xrn\"
				tin 	\"xterm -e rtin\"
				}
			  mail { xmail \"xmail\"
				 elm \"xterm -e elm\"
				 xbiff \"xbiff\"
				}
			  web { netscape \"netscape\"
				xmosaic \"xmosaic\"
				lynx \"xterm -e lynx \"
				}
			}
		edit 	{	xemacs \"xemacs\"
				xedit \"xedit\"
				aXe	\"faxe\"
			}
		graphic	{	xpaint \"xpaint\"
				xv \"xv\"
			}
		terminal  { xterm \"xterm -sb -fn 7x14 \"
			    vt100  \"rxvt -font 7x14 -ls \"
			  }
		Games	{	xblast \"xterm -e xblast\"
				tetris { xtetris \"xtetris\"
					 xhextris \"xhextris\"
					}
				netmaze \"netmaze\"
				xtank \"xtank\"
			}			
	screen  {
		swarn \"xlock -nice 0 -mode swarm\"
		flame \"xlock -nice 0 -mode flame\"
		lockswarn \"xlock -nice 0 -mode swarm\"
		lockflame \"xlock -nice 0 -mode flame\"
		}
	xkill {xkill \"xkill \"}
}\n";
char *ressourc3="{
		internet { news	{ xrn \"xrn\"
				tin 	\"xterm -e rtin\"
				}
			  mail { xmail \"xmail\"
				 elm \"xterm -e elm\"
				 xbiff \"xbiff\"
				}
			  web { netscape \"netscape\"
				xmosaic \"xmosaic\"
				lynx \"xterm -e lynx \"
				}
			}
		edit 	{	xemacs \"xemacs\"
				xedit \"xedit\"
				aXe	\"faxe\"
			}
		graphic	{	xpaint \"xpaint\"
				xv \"xv\"
			}
		terminal  { xterm \"xterm -sb -fn 7x14 \"
			    vt100  \"rxvt -font 7x14 -ls \"
			  }
		Games	{	xblast \"xterm -e xblast\"
				tetris { xtetris \"xtetris\"
					 xhextris \"xhextris\"
					}
				netmaze \"netmaze\"
				xtank \"xtank\"
			}			
	screen  {
		swarn \"xlock -nice 0 -mode swarm\"
		flame \"xlock -nice 0 -mode flame\"
		lockswarn \"xlock -nice 0 -mode swarm\"
		lockflame \"xlock -nice 0 -mode flame\"
		}
	xkill {xkill \"xkill \"}
}\n";
char *help=" funmenu charles vidal copyrect 95 \n
		-h help 
		-Win95 for a menubar like win95
		-Linux for a menubar linux
		-NeXT for a menubar like Next
		-c get config by stdin
		-rc create ressource file .funmenurc\n";
