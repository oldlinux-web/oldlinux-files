/* s3/s3.c
   Routine to set the third clock on a Steath VRAM board. I don't know if
this will work on any other hardware and it may cause damage to either the
card or monitor. I have only used it <s3 4 8 0> with my Stealth VRAM and
a DELL UltraScan monitor. This needs to be compiled with the -O6 option.
This program seems to leave the text mode in a flaky way. But it does work
with X? The actual routine to set the clock was posted by Batman ?? several
weeks ago while most of the other code is based on examples from S3*/

#include <linux/unistd.h>
#include <asm/io.h>

static _syscall1(int,iopl,int,level)

extern inline void outw(unsigned short value, unsigned short port)
{
__asm__ __volatile__ ("outw %%ax,%%dx"
		::"a" ((unsigned short) value),"d" ((unsigned short) port));
}

int INTRLCE; /*INTRLCE flag see OC()*/

void set_clock();

extern void scr_off(),scr_on(),wait_for_vsync();

/*These magic numbers are from the Batman post*/
long H_CLOCKS[]={0x0000a3,0x89189e,0xcc0596,0x0c2dd6,0xb824f6,0x1411f6};
long V_CLOCKS[]={0x0000a3,0x3d15a2,0x350692,0xbc2ac2,0xc522b2,0xbc35a2,0xc422b2,
		0x852af2,0x5410c2,0x0c3ff2,0xd437f2,0x3c15a2,0xad1bd2,
		0xac1bd2,0x3427f2};

main(argc,argv)
int argc;
char *argv[];
{
unsigned short tmp;
iopl(3);		/*give us the power to in/out to all ports. This
			  probably should be changed to only allow access to
			  the needed ports now that the code doesn't use the
			  S3 magic ports*/
			  
unlk();			/*unlock the magic S3 registers !*/
scr_off();		/*shutdown the screen*/
outw(0,0x3c4);		/*turn off sequencer*/
tmp=inb(0x3cc);		/*save ??*/
tmp=tmp | 0x0c;		/*turn off ??*/
outb(tmp,0x3c2);	/*do it*/
set_clock(V_CLOCKS[atoi(argv[2])]);
/*INTRLCE=atoi(argv[3]);*/
INTRLCE=0;
wait_for_vsync();
set_clock(H_CLOCKS[atoi(argv[1])]);
wait_for_vsync();
tmp=inb(0x3cc);
tmp=tmp & 0xf7;		/*enable ??*/
outb(tmp,0x03c2);	/*do it*/
wait_for_vsync();
outw(0x300,0x3c4);	/*enable sequencer*/
scr_on();		/*turn the screen back on*/
lk();			/*lock the registers back up*/
iopl(0);		/*remove all i/o permissions*/
}

/*This was a macro in Batman's post but I needed to by able to easily control
the interface option for testing. If this program is run in text mode the
INTERLCE flag should always be 0, since text mode is non-interlaced 8-)*/
inline unsigned short OC(x)
unsigned short x;
{
unsigned short ret;
ret=0x42 | ((x & 3) << 8);
if (INTRLCE) ret|=0x2000;
return(ret);
}

unlk()	/*unlock the S3 extended registers*/
{
outw(0x4838,0x3d4);
outw(0xa039,0x3d4);
outw(0x0e11,0x3d4);
}

lk()	/*lock the S3 extended registers*/
{
outw(0x38,0x3d4);
outw(0x39,0x3d4);
outw(0x8e11,0x3d4);
}

/* This is the code that was posted to comp.os.linux by Batman several
weeks ago. */
void set_clock(l)
long l;
{
long bit;
int i;
unsigned char c,idx;
c=inb(0x3cc);
idx=inb(0x3d4);
outw(OC(3),0x3cc);
outb(c,0x3c2);
for(i=1;i<=6;i++) {
	outw(OC(2),0x3d4);
	outw(OC(3),0x3d4);
}
outw(OC(2),0x3d4);
outw(OC(0),0x3d4);
outw(OC(1),0x3d4);
outw(OC(0),0x3d4);
outw(OC(1),0x3d4);
for(bit=1<<23;bit;bit>>=1)
	if (l & bit) {
		outw(OC(1),0x3d4);
		outw(OC(0),0x3d4);
		outw(OC(2),0x3d4);
		outw(OC(3),0x3d4);
	}
	else {
		outw(OC(3),0x3d4);
		outw(OC(2),0x3d4);
		outw(OC(0),0x3d4);
		outw(OC(1),0x3d4);
	}
outw(OC(3),0x3d4);
outw(OC(2),0x3d4);
outw(OC(3),0x3d4);
outb(idx,0x3d4);
}
