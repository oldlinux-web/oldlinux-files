
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/notice.h>
#include <xview/panel.h>

/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "externs.h"

#include "constants.h"
#include "grays.h"
#include "funcs.h"


extern char *version;
extern char *dbname;

extern bool ValidDatabase;

char *alberi_PQexec();


/*
 * Notify callback function for `database_button'.
 */
void
database_name_change_proc(item, event)
     Panel_item      item;
     Event           *event;
{
  first_window1_objects   *ip =
    (first_window1_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);

  check_database(ip, 1);        
       
}

void
create_database(item, event)
     Panel_item      item;
     Event          *event;
{
  first_window1_objects *ip = (first_window1_objects *)
    				xv_get(item, XV_KEY_DATA, INSTANCE);

  xv_set(create_database_dialog->pop, XV_KEY_DATA, OPER, marco, NULL);
  xv_set(create_database_dialog->pop, XV_SHOW, TRUE, NULL);
        
}

void
destroy_database(item, event)
     Panel_item      item;
     Event          *event;
{
  first_window1_objects *ip = (first_window1_objects *)
    				xv_get(item, XV_KEY_DATA, INSTANCE);
        
  xv_set(destroy_database_dialog->pop, XV_KEY_DATA, OPER, marco, NULL);
  xv_set(destroy_database_dialog->pop, XV_SHOW, TRUE, NULL);
        
}


void
check_database(ip, later_check)
     first_window1_objects *ip;
     int later_check;
{
   PortalBuffer *p;
   int i, j, k, g, n, m, t, x, array_size, valid;
   char *datbase;
   char title[100], *label;
   char *ret;

   while ((int) xv_get(database_select_dialog->databases_list, 
		       PANEL_LIST_NROWS))  
     xv_set(database_select_dialog->databases_list, 
            PANEL_LIST_DELETE, 0,
            NULL);
   xv_set(database_select_dialog->pop, XV_KEY_DATA, OPER, ip->window1, NULL);
   valid = 0;

   if (Debugging)
     PQtracep = 0;
   ret = alberi_PQexec("begin");
   if ( ret[0] == 'R' || ret[0] == 'E' )
     if ( !ValidDatabase ) {
       fprintf( stderr, "%s\n", ret+1 );
       exit(1);
     }
   alberi_PQexec("retrieve portal dbeses (pg_database.datname)");
                      
   alberi_PQexec("fetch all in dbeses");
   p = PQparray("dbeses");
   g = PQngroups(p);
   t = 0;
   for(k = 0; k < g; k++) {
     n = PQntuplesGroup(p, k);
     m = PQnfieldsGroup(p, k);
     for(i = 0; i < n; i++) {
	 for(j = 0; j < m; j++)  {
             datbase = strdup(PQgetvalue(p, t + i, j));
             if(!strcmp(dbname, datbase)) valid = 1;
             xv_set(database_select_dialog->databases_list, 
                    PANEL_LIST_INSERT, 
		      (int) xv_get(database_select_dialog->databases_list, 
				   PANEL_LIST_NROWS) ,
                    PANEL_LIST_STRING, 
		      (int) xv_get(database_select_dialog->databases_list, 
				   PANEL_LIST_NROWS) ,
		      datbase,
                    NULL);             
	   } 
                                  
       }
     t += n;
     
  }
  alberi_PQexec("close dbeses");
  alberi_PQexec("end");

   if (Debugging)
     PQtracep = 1;

   if(valid) {
     PQsetdb(dbname);
   }
   else {
/*     dbname = strdup("postgres"); */
     sprintf(title, "Postgres GLI Alberi [%s]\t Database -> %s on host -> %s", 
	     version, dbname, PQhost);
     label = strdup(title);
     xv_set(ip->window1, FRAME_LABEL, label, NULL);
     update_schema();
     xv_set(ip->window1,
	    FRAME_LEFT_FOOTER, "Invalid database",
	    NULL);
   }

   if (later_check)
     xv_set(database_select_dialog->pop, XV_SHOW, TRUE, NULL);
 }

