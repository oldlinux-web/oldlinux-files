
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>

/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "externs.h"

#include "constants.h"
#include "grays.h"
#include "funcs.h"

void
retrieve_into_classname_proc(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
  Canvas_shell the_owner;
  Frame the_frame;
  int len1, len2;
  char *the_retrieve_overhead, new_footer[64];
  char *into_begin, *unique_begin;
  char	 *footer;

  the_owner = (Canvas_shell) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
  the_frame = (Frame) xv_get(the_owner, XV_OWNER);

  xv_set(target_shell,
	 RECTOBJ_ACCEPTS_DROP, TRUE,
	 RECTOBJ_DROP_PROC, adding_stuff_in_the_array,
	 NULL);

  into_begin = NULL;
  if ( footer = (char *) xv_get(the_frame, FRAME_LEFT_FOOTER) )
    into_begin = strstr( footer, "into" );

  if ( into_begin == NULL ) {
    xv_set(retrieve_into_dialog->pop, XV_KEY_DATA, OPER, the_frame, NULL);
    xv_set(retrieve_into_dialog->pop, XV_SHOW, TRUE, NULL);
  }
  else {

    /* cut out "into <classname>" */

    unique_begin = strstr( footer, "unique" );
    if ( unique_begin )	/* there was a "unique" modifier */
      strcpy( new_footer, "retrieve unique" );
    else
      strcpy( new_footer, "retrieve" );
    xv_set(the_frame, 
	   FRAME_LEFT_FOOTER, strdup(new_footer),
	   NULL);
  }
}

void
unique_on_off_proc(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
  static int unique = 0;
  int len1, len2;
  char *the_retrieve_overhead, newy[64];
  Canvas_shell the_shell;
  Frame the_frame;

  the_shell = (Canvas_shell) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
  the_frame = (Frame) xv_get(the_shell, XV_OWNER);
  xv_set(target_shell, 
	 RECTOBJ_ACCEPTS_DROP, TRUE, 
	 RECTOBJ_DROP_PROC, adding_stuff_in_the_array, 
	 NULL);

  if ( !unique ) { /* switch unique on */
    if((char *) xv_get(the_frame, FRAME_LEFT_FOOTER)) {
      the_retrieve_overhead =
	        strdup((char *) xv_get(the_frame, FRAME_LEFT_FOOTER));
      (void) strcpy(newy, the_retrieve_overhead);
      (void) strcat(newy, "unique ");
      the_retrieve_overhead = strdup(newy);
      xv_set(the_frame, FRAME_LEFT_FOOTER, the_retrieve_overhead, NULL);
      unique = 1;
    }
    else {
      (void) strcpy(newy, "retrieve unique ");
      the_retrieve_overhead = strdup(newy);
      xv_set(the_frame, FRAME_LEFT_FOOTER, the_retrieve_overhead, NULL);
      unique = 1;
    }
  }
  else {
    if ((char *) xv_get(the_frame, FRAME_LEFT_FOOTER)) {
      the_retrieve_overhead = strdup((char *) xv_get(the_frame,
						     FRAME_LEFT_FOOTER));
      (void) strcpy(newy, the_retrieve_overhead);
      the_retrieve_overhead = strdup(strstr(newy, "unique"));
      len1 = strlen(newy);
      len2 = strlen(the_retrieve_overhead);
      len2 = len1 - len2;
      newy[len2] = '\0';
      the_retrieve_overhead = strdup(newy);
      xv_set(the_frame, FRAME_LEFT_FOOTER, the_retrieve_overhead, NULL);
      unique = 0;
    }
  }   
}  

