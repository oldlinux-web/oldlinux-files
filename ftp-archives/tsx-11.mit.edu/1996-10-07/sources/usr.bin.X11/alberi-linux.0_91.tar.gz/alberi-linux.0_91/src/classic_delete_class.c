
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "constants.h"
#include "classic_delete_class_ui.h"
#include "delete_interface_ui.h"


extern int tuple_fetch1();
extern delete_interface_pop_objects *delete_interface_dialog;

/*
 * Notify callback function for `class_list'.
 */
int
classic_delete_class_proc(item, string, client_data, op, event)
     Panel_item		item;
     char		*string;
     Xv_opaque		client_data;
     Panel_list_op	op;
     Event		*event;
{
  classic_delete_class_pop_objects *ip = 
    (classic_delete_class_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
  char *classname;
  int tuples;
	
  switch(op) {
  case PANEL_LIST_OP_DESELECT:
		
    break;

  case PANEL_LIST_OP_SELECT:
    classname = strdup(string);

    xv_set(ip->pop, FRAME_BUSY, TRUE, NULL);

    tuples = tuple_fetch1(classname, 0);

    xv_set(ip->pop, FRAME_BUSY, FALSE, NULL);
    if (tuples) {
      xv_set(delete_interface_dialog->pop, 
	     XV_SHOW, TRUE, 
	     FRAME_LABEL, classname, 
	     FRAME_LEFT_FOOTER, "tuple", 
	     FRAME_RIGHT_FOOTER, "0",
	     NULL);
      xv_set(delete_interface_dialog->delete_button,
	     XV_SHOW, TRUE,
	     NULL);
      xv_set(delete_interface_dialog->which_tuple_setting,
	     XV_SHOW, TRUE,
	     NULL);
      xv_set(delete_interface_dialog->tuple_message,
	     XV_SHOW, TRUE,
	     NULL);                  
      xv_set(delete_interface_dialog->tuple_slider,
	     PANEL_VALUE, 0,
	     PANEL_MAX_VALUE, tuples - 1,
	     XV_SHOW, TRUE,
	     NULL);
    }
    else {
      xv_set(delete_interface_dialog->pop, 
	     XV_SHOW, TRUE, 
	     FRAME_LABEL, classname, 
	     FRAME_LEFT_FOOTER, "No tuples", 
	     FRAME_RIGHT_FOOTER, "",
	     NULL);
      xv_set(delete_interface_dialog->delete_button,
	     XV_SHOW, FALSE,
	     NULL);
      xv_set(delete_interface_dialog->which_tuple_setting,
	     XV_SHOW, FALSE,
	     NULL);
      xv_set(delete_interface_dialog->tuple_message,
	     XV_SHOW, FALSE,
	     NULL);                  
      xv_set(delete_interface_dialog->tuple_slider,
	     XV_SHOW, FALSE,
	     NULL);
    }

	
		break;

	case PANEL_LIST_OP_VALIDATE:
	
		break;

	case PANEL_LIST_OP_DELETE:
	
		break;
	}
	return XV_OK;
}

