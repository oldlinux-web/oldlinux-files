
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <stdio.h>
#include <sys/param.h>
#include <sys/types.h>
#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include "name_instance_ui.h"
#include "constants.h"

extern void free_you();
/*
 * Notify callback function for `new_instance_field'.
 */
Panel_setting
add_new_instance_proc(item, event)
	Panel_item	item;
	Event		*event;
{
	name_instance_pop_objects	*ip = (name_instance_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
	char *	value = (char *) xv_get(item, PANEL_VALUE);
	char *the_name, *the_whole_name, *none, *some, *the_attribute;
        int length, character, occurrence, conflict;
        Rectobj the_element, the_other, the_class, temp;
        Rectobj_list *the_guys, *class_list, *instance_array_pointer;
        Array_tile the_array, the_classes, the_instances_owner;

        if ((length = strlen(value)) > 16) {
            xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names are 16 characters or less!!", NULL);
            xv_set(item, PANEL_VALUE, "Error", NULL);
         } else {
           if ((!isalpha(value[0]))  && (value[0] != '_'))  {
              xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names start with alphabetic or underscore", NULL);
              xv_set(item, PANEL_VALUE,"Error" , NULL);
           } else {
             for(character =  1; character < length; character++) {
                 if ((!isalnum(value[character])) && (value[character] != '_')) {
                    xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names include alphanumeric and underscore", NULL);
                    xv_set(item, PANEL_VALUE, "Error ", NULL);
                    break;
                 }
             }
          }
        }
        
        if(strcmp(value, "Error") != 0)  {
	   the_array = (Array_tile) xv_get(ip->new_instance_field, PANEL_CLIENT_DATA);
           the_name = strdup(value);
	   if(the_guys = (Rectobj_list *) xv_get(the_array, RECTOBJ_CHILDREN)) {
	     occurrence = 0;
       	     length = strlen(the_name);
	     list_for(the_guys) {
	       the_other = RECTOBJ_LIST_HANDLE(the_guys);
               if(!strcmp(the_name, (char *) xv_get(the_other, DRAWTEXT_STRING)))  {
		 if(!occurrence) { occurrence++; } else {
                    xv_set(ip->pop, FRAME_LEFT_FOOTER, "Select it from the list", NULL);
                    xv_set(item, PANEL_VALUE, "Error", NULL);
                    value = strdup("Error");
                 }
               }
             }
           }
        }
        if(strcmp(value, "Error")) {
         /* the name is bona-fide but it is not known if it is already in use then check for its existence 
         * in some other class instances
         */
        the_classes = (Array_tile) xv_get(ip->pop, XV_KEY_DATA, FUNC); 
	the_class = (Rectobj) xv_get(ip->instances_list, XV_KEY_DATA, UNARY);
        class_list = (Rectobj_list *) xv_get(the_classes, RECTOBJ_CHILDREN);
        conflict = 0;
        list_for(class_list) {
           temp = RECTOBJ_LIST_HANDLE(class_list);
           if(temp != the_class) {
             instance_array_pointer = (Rectobj_list *) xv_get(temp, RECTOBJ_CHILDREN);
             list_for(instance_array_pointer) {
                the_instances_owner = RECTOBJ_LIST_HANDLE(instance_array_pointer);
             }
             the_guys = (Rectobj_list *) xv_get(the_instances_owner, RECTOBJ_CHILDREN);
             list_for(the_guys) { /* the instances */
                the_element = RECTOBJ_LIST_HANDLE(the_guys);
                none = strdup((char *) xv_get(the_element, DRAWTEXT_STRING));
                if(!strcmp(none, value)) { conflict = 1; }
             }
           }
        }
        if(conflict) {
          xv_set(ip->pop, FRAME_LEFT_FOOTER, "This name used for other instance class", XV_SHOW, TRUE, NULL);

        } else {
          the_element = (Rectobj) xv_get(ip->pop, XV_KEY_DATA, OPER);
          xv_set((Frame) xv_get((Canvas_shell) xv_get((Tree) xv_get(the_element, RECTOBJ_PARENT), RECTOBJ_PARENT), XV_OWNER), 
               FRAME_BUSY, TRUE,
               NULL);
          xv_set((Canvas_shell) xv_get((Tree) xv_get(the_element, RECTOBJ_PARENT), RECTOBJ_PARENT), 
                CANVAS_SHELL_DELAY_REPAINT, TRUE,
                NULL);

           some = strdup(value);
           (void) xv_create((Array_tile) xv_get(ip->new_instance_field, PANEL_CLIENT_DATA), DRAWTEXT,
                            DRAWTEXT_STRING, some, 
                            XV_SHOW, FALSE,
                            NULL);
           
           xv_set(ip->instances_list, 
                      PANEL_LIST_INSERT, (int) xv_get(ip->instances_list, PANEL_LIST_NROWS), 
                      PANEL_LIST_STRING, (int) xv_get(ip->instances_list, PANEL_LIST_NROWS), some,
                      NULL);
                  
           
           the_whole_name = strdup((char *) xv_get((Rectobj) xv_get(ip->pop, XV_KEY_DATA, OPER), DRAWTEXT_STRING));
           
           the_attribute = strdup(strchr(the_whole_name, '.'));
           if(the_whole_name = (char *) malloc(sizeof(value) + sizeof(the_attribute) + 1)) {
               sprintf(the_whole_name, "%s%s", value, the_attribute);
           }
           
           the_name = strdup(the_whole_name);
           
           none = strdup("None");
            
           xv_set(the_element,
               DRAWTEXT_STRING, the_name,
               NULL);
           xv_set((Frame) xv_get((Canvas_shell) xv_get((Tree) xv_get(the_element, RECTOBJ_PARENT), RECTOBJ_PARENT), XV_OWNER), 
               FRAME_BUSY, FALSE,
               NULL);
           xv_set((Canvas_shell) xv_get((Tree) xv_get(the_element, RECTOBJ_PARENT), RECTOBJ_PARENT), 
                CANVAS_SHELL_DELAY_REPAINT, FALSE,
                NULL);
           xv_set(ip->pop, XV_SHOW, FALSE, NULL);
         }
        }
        
	
	return panel_text_notify(item, event);
}

/*
 * Notify callback function for `instances_list'.
 */
int
select_existing_instance_proc(item, string, client_data, op, event)
	Panel_item	item;
	char		*string;
	Xv_opaque	client_data;
	Panel_list_op	op;
	Event		*event;
{
	name_instance_pop_objects	*ip = (name_instance_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
        char *the_name, *the_whole_name, *none, *temp, *the_attribute;
	
	switch(op) {
	case PANEL_LIST_OP_DESELECT:
		
		break;

	case PANEL_LIST_OP_SELECT:
		
                
                the_whole_name = strdup((char *) xv_get((Rectobj) xv_get(ip->pop, XV_KEY_DATA, OPER), DRAWTEXT_STRING));
                
                the_attribute = strdup(strchr(the_whole_name, '.'));
                the_name = (char *) malloc(sizeof(string) + sizeof(the_attribute) + 1);
                sprintf(the_name, "%s%s", string, the_attribute);
                the_whole_name = strdup(the_name);
               
                none = strdup("None");
                xv_set((Rectobj) xv_get(ip->pop, XV_KEY_DATA, OPER),
                                        DRAWTEXT_STRING, the_whole_name,
                                        NULL);
                xv_set(ip->pop, XV_SHOW, FALSE, NULL);
		break;

	case PANEL_LIST_OP_VALIDATE:
	
		break;

	case PANEL_LIST_OP_DELETE:
		
		break;
	}
	return XV_OK;
}

/*
 * Notify callback function for `done_button'.
 */
void
instance_done_proc(item, event)
	Panel_item	item;
	Event		*event;
{
	name_instance_pop_objects	*ip = (name_instance_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
	
	
}


void
free_you(object, key, data)
Xv_object object;
int key;
caddr_t data;
{
  
  free(data);
}
