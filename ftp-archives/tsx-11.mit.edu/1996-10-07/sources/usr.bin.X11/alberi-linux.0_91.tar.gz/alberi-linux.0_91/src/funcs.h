 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

extern void  recursive_recursive_delete(), delete_where_tree_binary_node(),
	     delete_where_tree_negate_node();
extern void  start_where_tree(), adding_stuff_to_the_where_tree(),
	     kill_this_tree();
extern void  delete_where_tree_leaf_proc(), negate_the_branch_proc(),
  	     adding_inheritance_proc();
extern void  submmit_the_query_proc(), menu_submmit(), clean_the_icon_query();
extern void  show_query_system(), hide_query_system(),
	     show_class_creation_system(), hide_class_creation_system();
extern void  free_string(), switch_bool(), add_new_attribute_in_the_array();
extern void  recursive_delete(), name_retrieve_attr_proc(),
	     delete_all_attribute_in_the_array();
extern void  delete_leaf_proc(), delete_node_proc(), name_the_new_class();
extern void  add_constant_proc(), add_unary_opr_proc(), delete_new_attr_proc();
extern void  delete_array_elem_proc(), assign_constant_proc();
extern void  name_change_opr_proc(), name_change_fun_proc(),
	     assign_type_new_attribute();
extern void  class_info_proc(), attribute_check_proc(), query_drop();
extern void  initialize_QT(), set_operator_or_function_proc(),
	     initialize_CCT(), initialize_SCM();
extern void  name_change_unary_proc(), name_class_instance_proc();
extern void  show_hide_expression_tree(), adding_stuff_in_the_array(); 
extern void  adding_stuff_to_the_expression_tree(),
	     adding_a_constant_to_the_array();
extern void  retrieve_into_classname_proc(), unique_on_off_proc(),
	     append_classname_proc();
extern void  replace_classname_proc(), delete_classname_proc(),
	     check_database();
extern void  update_schema(), class_information(), show_attributes_proc();
extern void  add_attributes_proc(), rename_class_proc(),
	     nuke_that_class_proc();
extern void  insert_in_command_stack(), print_command_stack();
extern void  classic_append(), classic_replace(), classic_delete();
extern int   tuple_fetch(), tuple_fetch1(), alberi_error_handler();

extern void  dumbo(), Welcome();


char 	*retrieve_constructor(), *from_constructor(), *where_constructor(), 
     	*expression_constructor(), *where_tree_constructor(),
	*create_constructor(),
     	*inheritance_constructor(), *addattr_constructor();

Notify_value destroy_func();


Notify_value tiempo();
