
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

extern first_window1_objects			*first_window1;
extern operator_select_operator_selection_pop_objects  
						*operator_selector_popup;
extern unary_select_popup1_objects 		*unary_selector_popup;
extern name_attribute_pop_objects 		*name_attribute_popup;
extern funct_select_pop_objects 		*funct_selector_popup;
extern constant_select_pop_objects 		*constant_selector_popup;
extern name_instance_pop_objects 		*name_instance_popup;
extern new_attrib_type_pop_objects 		*new_type_dialog;
extern name_new_class_pop_objects 		*name_new_class_dialog;
extern retrieve_into_classname_pop_objects 	*retrieve_into_dialog;
extern append_class_pop_objects 		*append_class_dialog;
extern delete_replace_instances_pop_objects    *delete_replace_instances_dialog;
extern delete_instances_pop_objects 	       	*delete_instances_dialog;
extern database_select_pop_objects 		*database_select_dialog;
extern append_interface_pop_objects 		*append_interface_dialog;
extern classic_append_class_pop_objects 	*classic_append_class_dialog;
extern classic_replace_class_pop_objects 	*classic_replace_class_dialog;
extern replace_interface_pop_objects 		*replace_interface_dialog;
extern classic_delete_class_pop_objects 	*classic_delete_class_dialog;
extern delete_interface_pop_objects 		*delete_interface_dialog;
extern rename_interface_pop_objects 		*rename_interface_dialog;

extern create_database_pop_objects		*create_database_dialog;
extern destroy_database_pop_objects		*destroy_database_dialog;
extern command_log_pop_objects			*command_log_pop;

extern char *PQhost;
extern char *PQport;
extern char *PQtty;
extern char *PQoption;
extern char *optarg;
extern FILE  *debug_port;
extern int   PQportset;
extern int   PQtracep;
extern int   optind,opterr;

extern bool TerseOutput;
extern bool PrintAttNames;
extern bool Silent;
extern bool Verbose;
extern bool Debugging;

extern bool CatalogClasses;
extern bool CatalogClassesOnly;

extern Frame marco, qual_frame, target_frame, expression_frame,
	     attrib_creation_frame, inheritance_frame, attrib_addition_frame;

extern Panel class_title, attribute_title, parents_title, children_title;

extern Canvas_shell shell1, attribute_shell, parents_shell, children_shell,
	     	    dropping_shell, qual_shell, expression_shell, target_shell;

extern Tree 	     qual_tree;

extern Array_tile   classes, attributes, parents, children;

