
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/


#include <stdio.h>
#include <sys/param.h>
#include <sys/types.h>
#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include "funct_select_ui.h"
#include "constants.h"


/*
 * Notify callback function for `func_list'.
 */
int
tell_function_name_proc(item, string, client_data, op, event)
	Panel_item	item;
	char		*string;
	Xv_opaque	client_data;
	Panel_list_op	op;
	Event		*event;
{
	funct_select_pop_objects	*ip = (funct_select_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
	
	switch(op) {
	case PANEL_LIST_OP_DESELECT:
		
		break;

	case PANEL_LIST_OP_SELECT:
		
		xv_set((Rectobj) xv_get(ip->pop, XV_KEY_DATA, OPER), 
				                              DRAWTEXT_STRING, (char *) string,
							      XV_KEY_DATA, TYPENAME, (char *) client_data,
							      XV_KEY_DATA, NAME_SET, 1,
							      NULL);
		break;

	case PANEL_LIST_OP_VALIDATE:
	
		break;

	case PANEL_LIST_OP_DELETE:
	
		break;
	}
	return XV_OK;
}

/*
 * Notify callback function for `func_name_field'.
 */
Panel_setting
name_the_function_by_hand_proc(item, event)
	Panel_item	item;
	Event		*event;
{
	funct_select_pop_objects	*ip = (funct_select_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
	char *	value = (char *) xv_get(item, PANEL_VALUE);
        char *the_name;
        int length, character, occurrence;
        Rectobj the_element, the_other;
        Rectobj_list *the_guys;
        Array_tile the_array;

        if ((length = strlen(value)) > 16) {
            xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names are 16 characters or less!!", NULL);
            xv_set(item, PANEL_VALUE, "Error", NULL);
         } else {
           if ((!isalpha(value[0]))  && (value[0] != '_'))  {
              xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names start with alphabetic or underscore", NULL);
              xv_set(item, PANEL_VALUE,"Error" , NULL);
           } else {
             for(character =  1; character < length; character++) {
                 if ((!isalnum(value[character])) && (value[character] != '_')) {
                    xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names include alphanumeric and underscore", NULL);
                    xv_set(item, PANEL_VALUE, "Error ", NULL);
                    break;
                 }
             }
          }
        }
        if(strcmp(value, "Error") != 0) {
           the_name = (char *) malloc(20*sizeof(char) + 1);
           sprintf(the_name, "%s", value);
           xv_set((Rectobj) xv_get(ip->pop, XV_KEY_DATA, OPER),
               DRAWTEXT_STRING, (char *) the_name,
               XV_KEY_DATA, TYPENAME, NULL,
               XV_KEY_DATA, NAME_SET, 1,
               NULL);
           xv_set(ip->pop, XV_SHOW, FALSE, NULL);
        }
	
	
	return panel_text_notify(item, event);
}

/*
 * Notify callback function for `done_button'.
 */
void
done_proc(item, event)
	Panel_item	item;
	Event		*event;
{
	funct_select_pop_objects	*ip = (funct_select_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
	
	
}

