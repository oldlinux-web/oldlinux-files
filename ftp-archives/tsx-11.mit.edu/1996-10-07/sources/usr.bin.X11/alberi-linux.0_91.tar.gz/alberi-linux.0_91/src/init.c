
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <time.h>
#include <stdio.h>
#include <sys/param.h>
#include <sys/types.h>
#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>
#include <xview/notify.h>
#include <xview/scrollbar.h>
#include <xview/cursor.h>
#include <xview/notice.h>
#include <xview/termsw.h>
#include <xview/tty.h>
#include <xview/font.h>
#include <xview/svrimage.h>


/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "externs.h"

#include "constants.h"
#include "grays.h"
#include "funcs.h"

#include "q_process.h"
#include "icons/lookattr.xbm"




extern Array_tile   target_tile;

extern Array_tile   attrib_creation_tile, inheritance_tile, 
		    attrib_addition_tile;


void initialize_QT()
{
  /* Canvas_shell	target_shell; */
  Drawtext        temptext;
  Drawicon        drop_source;
  Drawrect        adding_droppers_area;
  Scrollbar       vscroll;
  Scrollbar       hscroll;
  Menu            some_menu, target_menu;
  Menu            retrieve, append, replace, zap;
  int 		  FRAMEWIDTHUNIT, FRAMEWIDTH, FRAMERIGHTUNITHEIGHT;

        


  gray1 = (Server_image)xv_create(XV_NULL, SERVER_IMAGE,
				  XV_WIDTH,               gray1_width,
				  XV_HEIGHT,              gray1_height,
				  SERVER_IMAGE_BITS,      gray1_bits,
				  NULL);
  gray2 = (Server_image)xv_create(XV_NULL, SERVER_IMAGE,
				  XV_WIDTH,               gray2_width,
				  XV_HEIGHT,              gray2_height,
				  SERVER_IMAGE_BITS,      gray2_bits,
				  NULL);
  gray3 = (Server_image)xv_create(XV_NULL, SERVER_IMAGE,
				  XV_WIDTH,               gray3_width,
				  XV_HEIGHT,              gray3_height,
				  SERVER_IMAGE_BITS,      gray3_bits,
				  NULL);
  gray4 = (Server_image)xv_create(XV_NULL, SERVER_IMAGE,
				  XV_WIDTH,               gray4_width,
				  XV_HEIGHT,              gray4_height,
				  SERVER_IMAGE_BITS,      gray4_bits,
				  NULL);
  gray5 = (Server_image)xv_create(XV_NULL, SERVER_IMAGE,
				  XV_WIDTH,               gray5_width,
				  XV_HEIGHT,              gray5_height,
				  SERVER_IMAGE_BITS,      gray5_bits,
				  NULL);

  FRAMEWIDTHUNIT = (int) xv_get(target_frame, XV_WIDTH) / 2;
  FRAMEWIDTH = (int) xv_get(target_frame, XV_WIDTH);
  FRAMERIGHTUNITHEIGHT = ((int) xv_get(target_frame, XV_HEIGHT));

  target_shell = (Canvas_shell) xv_create(target_frame, CANVAS_SHELL,
					  XV_X, 0, XV_Y, 0, 
					  /*CANVAS_MIN_PAINT_WIDTH, 1000,
					    CANVAS_MIN_PAINT_HEIGHT, 1000, */
					  RECTOBJ_ACCEPTS_DROP, TRUE,
					  RECTOBJ_DROP_PROC,
					    adding_stuff_in_the_array,
					  NULL);
  retrieve = (Menu) xv_create(XV_NULL, MENU,
			      MENU_ACTION_ITEM,
			        "Into (Add/Remove)",
			        retrieve_into_classname_proc,
			      MENU_ACTION_ITEM,
			        "Unique (On/Off)",
			        unique_on_off_proc,
			      MENU_ACTION_ITEM,
			        "Add constant", 
			        adding_a_constant_to_the_array,
			      XV_KEY_DATA, MENU_OWNER, target_shell,
			      MENU_RELEASE,
			      NULL);

  append = (Menu) xv_create(XV_NULL, MENU,
			    MENU_ACTION_ITEM,
			      "Simple append ...",
			      classic_append,
			    MENU_ACTION_ITEM, 
			      "Class ...", append_classname_proc,
			    MENU_ACTION_ITEM,
			      "Add constant", adding_a_constant_to_the_array,
			    XV_KEY_DATA, MENU_OWNER, target_shell,
			    MENU_RELEASE,
			    NULL);

  replace = (Menu) xv_create(XV_NULL, MENU,
			     MENU_ACTION_ITEM,
			       "Simple replace ...", classic_replace,
			     MENU_ACTION_ITEM,
			       "Class instance ...", replace_classname_proc,
			     MENU_ACTION_ITEM,
			       "Add constant",
			       adding_a_constant_to_the_array,
			     XV_KEY_DATA, MENU_OWNER, target_shell,
			     MENU_RELEASE,
			     NULL);

  zap = (Menu) xv_create(XV_NULL, MENU,
			 MENU_ACTION_ITEM,
			   "Simple delete ...", classic_delete,
			 MENU_ACTION_ITEM,
			   "Class instance ...", delete_classname_proc,
			 XV_KEY_DATA, MENU_OWNER, target_shell,
			 MENU_RELEASE,
			 NULL);


  target_menu = (Menu) xv_create(XV_NULL, MENU,
				 MENU_TITLE_ITEM, "Target Workshell Menu",
				 MENU_PULLRIGHT_ITEM, "Retrieve", retrieve,
				 MENU_PULLRIGHT_ITEM, "Append", append,
				 MENU_PULLRIGHT_ITEM, "Replace", replace,
				 MENU_PULLRIGHT_ITEM, "Delete", zap,
/*				 MENU_ACTION_ITEM, "Clear Workshell", dumbo, */
				 XV_KEY_DATA, MENU_OWNER, target_shell,
				 NULL);
  xv_set(target_shell,  RECTOBJ_MENU, target_menu, NULL);

  vscroll = (Scrollbar) xv_create(target_shell, SCROLLBAR, 
				  SCROLLBAR_DIRECTION, SCROLLBAR_VERTICAL, 
				  SCROLLBAR_PIXELS_PER_UNIT, 35,
				  NULL);
  hscroll = (Scrollbar) xv_create(target_shell, SCROLLBAR, 
				  SCROLLBAR_DIRECTION, SCROLLBAR_HORIZONTAL, 
				  SCROLLBAR_PIXELS_PER_UNIT, 55,
				  NULL);
  window_fit(target_shell);

  FRAMEWIDTHUNIT = (int) xv_get(qual_frame, XV_WIDTH) / 2;
  FRAMEWIDTH = (int) xv_get(qual_frame, XV_WIDTH);
  FRAMERIGHTUNITHEIGHT = ((int) xv_get(qual_frame, XV_HEIGHT));
  

  qual_shell = (Canvas_shell) xv_create(qual_frame, CANVAS_SHELL,
					XV_X, 0, XV_Y, 0,
					RECTOBJ_ACCEPTS_DROP, TRUE,
					RECTOBJ_DROP_PROC,
					  start_where_tree,    /* HERE!!!!! */
					NULL);
  some_menu = (Menu) xv_create(XV_NULL, MENU,
			       MENU_TITLE_ITEM, "Qualifier Workshell Menu",
			       MENU_ACTION_ITEM,
			         "Delete the tree", kill_this_tree,
			       XV_KEY_DATA, MENU_OWNER, qual_shell,
			       NULL);

  xv_set(qual_shell, RECTOBJ_MENU, some_menu, NULL);

  vscroll = (Scrollbar) xv_create(qual_shell, SCROLLBAR, 
				  SCROLLBAR_DIRECTION, SCROLLBAR_VERTICAL, 
				  SCROLLBAR_PIXELS_PER_UNIT, 34,
				  NULL);

  hscroll = (Scrollbar) xv_create(qual_shell, SCROLLBAR, 
				  SCROLLBAR_DIRECTION, SCROLLBAR_HORIZONTAL, 
				  SCROLLBAR_PIXELS_PER_UNIT, 34,
				  NULL);

  window_fit(qual_shell);

  FRAMEWIDTHUNIT = (int) xv_get(expression_frame, XV_WIDTH) / 2;
  FRAMEWIDTH = (int) xv_get(expression_frame, XV_WIDTH);
  FRAMERIGHTUNITHEIGHT = ((int) xv_get(expression_frame, XV_HEIGHT) / 3);

  expression_shell = (Canvas_shell) xv_create(expression_frame, CANVAS_SHELL,
					      XV_X, 0, XV_Y, 0,
					      NULL);
  vscroll = (Scrollbar) xv_create(expression_shell, SCROLLBAR, 
				  SCROLLBAR_DIRECTION, SCROLLBAR_VERTICAL,
				  SCROLLBAR_PIXELS_PER_UNIT, 34,
				  NULL);   

  hscroll = (Scrollbar) xv_create(expression_shell, SCROLLBAR, 
				  SCROLLBAR_DIRECTION, SCROLLBAR_HORIZONTAL, 
				  SCROLLBAR_PIXELS_PER_UNIT, 34,
				  NULL);

  window_fit(expression_shell);

  target_tile = (Array_tile) xv_create(target_shell, ARRAY_TILE,
				       ARRAY_TILE_N_COLUMNS, 4,
				       XV_X, 5, XV_Y, 20,
				       RECTOBJ_ACCEPTS_DROP, TRUE,
				       RECTOBJ_DROP_PROC,
				         adding_stuff_in_the_array,
				       XV_KEY_DATA,
				         EXPRESSION_CANVAS, expression_shell,
				       XV_KEY_DATA, TYPE, 0,
				       NULL);

       
 
  xv_set(target_shell,
	 XV_KEY_DATA, THE_ARRAY, target_tile,
	 NULL);

  xv_set(qual_shell,
	 XV_KEY_DATA, THE_ARRAY, 0 , /* qual_tile */
	 NULL);

}

void 
initialize_CCT()
{
	Canvas_shell	attrib_creation_shell, inheritance_shell;
        Drawtext        temptext;
        Drawicon        drop_source;
        Drawrect        adding_droppers_area;
        Scrollbar       vscroll;
        Scrollbar       hscroll;
        int FRAMEWIDTHUNIT, FRAMEWIDTH, FRAMERIGHTUNITHEIGHT;
        Menu attri_menu, inheritance_menu;
        




    FRAMEWIDTHUNIT = (int) xv_get(attrib_creation_frame, XV_WIDTH) / 2;
    FRAMEWIDTH = (int) xv_get(attrib_creation_frame, XV_WIDTH);
    FRAMERIGHTUNITHEIGHT = ((int) xv_get(attrib_creation_frame, XV_HEIGHT));

    attrib_creation_shell = (Canvas_shell)
      				xv_create(attrib_creation_frame, CANVAS_SHELL,
					  XV_X, 0, XV_Y, 0, 
					  /*CANVAS_MIN_PAINT_WIDTH, 1000,
					    CANVAS_MIN_PAINT_HEIGHT, 1000, */
					  RECTOBJ_ACCEPTS_DROP, TRUE,
					  NULL);

    attri_menu = (Menu) xv_create(XV_NULL, MENU,
                                 MENU_TITLE_ITEM, "Attribute creation menu",
                                 MENU_ACTION_ITEM,
				  "Add attribute",
				  add_new_attribute_in_the_array,
                                 MENU_ACTION_ITEM,
				  "Name the new class ...",
				  name_the_new_class,
                                 MENU_ACTION_ITEM,
				  "Delete all",
				  delete_all_attribute_in_the_array,
                                 XV_KEY_DATA, MENU_OWNER, attrib_creation_shell,
                                 NULL);
    xv_set(attrib_creation_shell, RECTOBJ_MENU, attri_menu, NULL);
    vscroll = (Scrollbar) xv_create(attrib_creation_shell, SCROLLBAR, 
				    SCROLLBAR_DIRECTION, SCROLLBAR_VERTICAL, 
				    SCROLLBAR_PIXELS_PER_UNIT, 35,
				    NULL);
    hscroll = (Scrollbar) xv_create(attrib_creation_shell, SCROLLBAR, 
				    SCROLLBAR_DIRECTION, SCROLLBAR_HORIZONTAL,
				    SCROLLBAR_PIXELS_PER_UNIT, 45, 
				    NULL);
    window_fit(attrib_creation_shell);

    FRAMEWIDTHUNIT = (int) xv_get(inheritance_frame, XV_WIDTH) / 2;
    FRAMEWIDTH = (int) xv_get(inheritance_frame, XV_WIDTH);
    FRAMERIGHTUNITHEIGHT = ((int) xv_get(inheritance_frame, XV_HEIGHT));

    inheritance_shell = (Canvas_shell)
      				xv_create(inheritance_frame, CANVAS_SHELL,
					  XV_X, 0, XV_Y, 0,
					  /* CANVAS_MIN_PAINT_WIDTH, 1000,
					     CANVAS_MIN_PAINT_HEIGHT, 1000, */
					  RECTOBJ_ACCEPTS_DROP, TRUE,
					  RECTOBJ_DROP_PROC,
					    adding_inheritance_proc,
							  /* add it later */
					  /*CANVAS_RESIZE_PROC, resize_qual, */
					  NULL);
    inheritance_menu = (Menu) xv_create(XV_NULL, MENU,
					MENU_TITLE_ITEM,
					 "Inheritance of class menu",
					MENU_ACTION_ITEM,
					 "Clear",
					 delete_all_attribute_in_the_array,
					XV_KEY_DATA,
					MENU_OWNER, inheritance_shell,
					NULL);
    xv_set(inheritance_shell, RECTOBJ_MENU, inheritance_menu, NULL);
    vscroll = (Scrollbar) xv_create(inheritance_shell, SCROLLBAR, 
				    SCROLLBAR_DIRECTION, SCROLLBAR_VERTICAL, 
				    SCROLLBAR_PIXELS_PER_UNIT, 35,
				    NULL);
    hscroll = (Scrollbar) xv_create(inheritance_shell, SCROLLBAR, 
				    SCROLLBAR_DIRECTION, SCROLLBAR_HORIZONTAL,
				    SCROLLBAR_PIXELS_PER_UNIT, 45,
				    NULL);
    window_fit(inheritance_shell);


    attrib_creation_tile = (Array_tile)
      			     xv_create(attrib_creation_shell, ARRAY_TILE,
				       ARRAY_TILE_N_COLUMNS, 4,
				       XV_X, 5, XV_Y, 20,
				       XV_KEY_DATA,
				         EXPRESSION_CANVAS,
				         attrib_creation_shell,
				       XV_KEY_DATA, TYPE, 0,
				       NULL);

    inheritance_tile = (Array_tile) xv_create(inheritance_shell, ARRAY_TILE,
					      ARRAY_TILE_N_COLUMNS, 4,
					      XV_X, 5, XV_Y, 20,
					      XV_KEY_DATA,
					      	EXPRESSION_CANVAS,
					        attrib_creation_shell,
					      XV_KEY_DATA, TYPE, 1,
					      NULL);
    
 
     xv_set(attrib_creation_shell, 
	    XV_KEY_DATA, THE_ARRAY, attrib_creation_tile,
	    NULL);
     xv_set(inheritance_shell,
	    XV_KEY_DATA, THE_ARRAY, inheritance_tile,
	    NULL);

      }

void
initialize_SCM()
{
	Canvas_shell	attrib_addition_shell;
        Drawtext        temptext;
        Drawicon        drop_source;
        Drawrect        adding_droppers_area;
        Scrollbar       vscroll;
        Scrollbar       hscroll;
        int FRAMEWIDTHUNIT, FRAMEWIDTH, FRAMERIGHTUNITHEIGHT;
        Menu attri_menu;
        




    FRAMEWIDTHUNIT = (int) xv_get(attrib_addition_frame, XV_WIDTH);
    FRAMEWIDTH = (int) xv_get(attrib_addition_frame, XV_WIDTH);
    FRAMERIGHTUNITHEIGHT = ((int) xv_get(attrib_addition_frame, XV_HEIGHT));

    attrib_addition_shell = (Canvas_shell)
      xv_create(attrib_addition_frame, CANVAS_SHELL,
                                     XV_X, 0, XV_Y, 0, 
                                     /*CANVAS_MIN_PAINT_WIDTH, 1000,
                                     CANVAS_MIN_PAINT_HEIGHT, 1000, */
                                     RECTOBJ_ACCEPTS_DROP, FALSE,
                                     /* CANVAS_RESIZE_PROC, resize_target, */
                                     NULL);

    attri_menu = (Menu) xv_create(XV_NULL, MENU,
                                 MENU_TITLE_ITEM, "Attribute addition menu",
                                 MENU_ACTION_ITEM, 
				  "Add attribute", 
				  add_new_attribute_in_the_array,
                                 MENU_ACTION_ITEM, 
				  "Delete all", 
				  delete_all_attribute_in_the_array,
                                 XV_KEY_DATA, MENU_OWNER, attrib_addition_shell,
                                 NULL);
    xv_set(attrib_addition_shell, RECTOBJ_MENU, attri_menu, NULL);
    vscroll = (Scrollbar) xv_create(attrib_addition_shell, SCROLLBAR, 
				    SCROLLBAR_DIRECTION, 
				      SCROLLBAR_VERTICAL, 
				    SCROLLBAR_PIXELS_PER_UNIT, 35,
				    NULL);
    hscroll = (Scrollbar) xv_create(attrib_addition_shell, SCROLLBAR, 
				    SCROLLBAR_DIRECTION, SCROLLBAR_HORIZONTAL,
				    SCROLLBAR_PIXELS_PER_UNIT, 45, 
				    NULL);
    window_fit(attrib_addition_shell);



    attrib_addition_tile = (Array_tile)
      xv_create(attrib_addition_shell, ARRAY_TILE,
		ARRAY_TILE_N_COLUMNS, 4,
                XV_X, 5, XV_Y, 20,
                /* RECTOBJ_ACCEPTS_DROP, TRUE, */
                /* RECTOBJ_DROP_PROC, adding_stuff_in_the_array, */
                XV_KEY_DATA, EXPRESSION_CANVAS, attrib_addition_shell,
                XV_KEY_DATA, TYPE, 0,
                /* XV_KEY_DATA_REMOVE_PROC, free_string, */
		NULL);

    
 
     xv_set(attrib_addition_shell,
                   XV_KEY_DATA, THE_ARRAY, attrib_addition_tile,
                   NULL);
 
}

