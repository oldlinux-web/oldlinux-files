
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <sys/param.h>
#include <sys/types.h>
#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>
#include <xview/notify.h>
#include <xview/scrollbar.h>
#include <xview/cursor.h>
#include <xview/notice.h>
#include <xview/termsw.h>
#include <xview/tty.h>
#include <xview/font.h>
#include <xview/svrimage.h>


/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>


/* _ui.h (user interface) headers */

#include "all_ui.h"
#include "fontset_ui.h"
#include "hostset_ui.h"
#include "displayset_ui.h"
#include "load_ui.h"
#include "insert_ui.h"
#include "constants.h"
#include "q_process.h"
#include "icons/lookattr.xbm"



#define FRAME_FONT "-b&h-lucida-medium-r-*-*-*-120-*-*-*-*-*-*"

#define USER_NAMESIZE 16

#define THEIGHT 20 /* Title Height */

extern void  recursive_recursive_delete(), delete_where_tree_binary_node(),
	     delete_where_tree_negate_node();
extern void  start_where_tree(), adding_stuff_to_the_where_tree(),
	     kill_this_tree();
extern void  delete_where_tree_leaf_proc(), negate_the_branch_proc(),
  	     adding_inheritance_proc();
extern void  submmit_the_query_proc(), menu_submmit(), clean_the_icon_query();
extern void  show_query_system(), hide_query_system(),
	     show_class_creation_system(), hide_class_creation_system();
extern void  free_string(), switch_bool(), add_new_attribute_in_the_array();
extern void  recursive_delete(), name_retrieve_attr_proc(),
	     delete_all_attribute_in_the_array();
extern void  delete_leaf_proc(), delete_node_proc(), name_the_new_class();
extern void  add_constant_proc(), add_unary_opr_proc(), delete_new_attr_proc();
extern void  delete_array_elem_proc(), assign_constant_proc();
extern void  name_change_opr_proc(), name_change_fun_proc(),
	     assign_type_new_attribute();
extern void  class_info_proc(), attribute_check_proc(), query_drop();
extern void  initialize_QT(), set_operator_or_function_proc(),
	     initialize_CCT(), initialize_SCM();
extern void  name_change_unary_proc(), name_class_instance_proc();
extern void  show_hide_expression_tree(), adding_stuff_in_the_array(); 
extern void  adding_stuff_to_the_expression_tree(),
	     adding_a_constant_to_the_array();
extern void  retrieve_into_classname_proc(), unique_on_off_proc(),
	     append_classname_proc();
extern void  replace_classname_proc(), delete_classname_proc(),
	     check_database();
extern void  update_schema(), class_information(), show_attributes_proc();
extern void  add_attributes_proc(), rename_class_proc(),
	     nuke_that_class_proc();
extern void  insert_in_command_stack(), print_command_stack();
extern void  classic_append(), classic_replace(), classic_delete();
extern int   tuple_fetch(), tuple_fetch1(), alberi_error_handler();

extern void  dumbo(), Welcome();


char 	*retrieve_constructor(), *from_constructor(), *where_constructor(), 
     	*expression_constructor(), *where_tree_constructor(),
	*create_constructor(),
     	*inheritance_constructor(), *addattr_constructor();

Notify_value destroy_func();


Notify_value tiempo();
struct itimerval timer;
int commas = 0;

/* These are as in POSTGRES Monitor */

bool TerseOutput = false;
bool PrintAttNames = true;
bool Silent = false;
bool Verbose = true;
bool Debugging = false;

bool CatalogClasses = false;
bool CatalogClassesOnly = false;

bool ValidDatabase = false;


Frame        marco, qual_frame, target_frame, expression_frame,
	     attrib_creation_frame, inheritance_frame, attrib_addition_frame;

Panel 	     class_title, attribute_title, parents_title, children_title;

Canvas_shell shell1, attribute_shell, parents_shell, children_shell,
	     dropping_shell, qual_shell, expression_shell, target_shell;

Tree 	     qual_tree;

Array_tile   classes, attributes, parents, children;

Array_tile   target_tile, qual_tile;

Array_tile   attrib_creation_tile, inheritance_tile, attrib_addition_tile;

Panel_item   class_info, attribute_info, parents_info, children_info;

Xv_cursor    cursor;

Icon 	     APPIcon;

Server_image gray1, gray2, gray3, gray4, gray5, gray6, APPImage, schema_image;

Server_image gray[3]; /*move this to global setting */

char 	     *dbname;

char 	     main_title[100];

Rect 	     original_main_size_and_position, saved_main_size_and_position;

char *command_stack[5]; /* a little stack of commands */

first_window1_objects				*first_window1;
operator_select_operator_selection_pop_objects  *operator_selector_popup;
unary_select_popup1_objects 			*unary_selector_popup;
name_attribute_pop_objects 			*name_attribute_popup;
funct_select_pop_objects 			*funct_selector_popup;
constant_select_pop_objects 			*constant_selector_popup;
name_instance_pop_objects 			*name_instance_popup;
new_attrib_type_pop_objects 			*new_type_dialog;
name_new_class_pop_objects 			*name_new_class_dialog;
retrieve_into_classname_pop_objects 		*retrieve_into_dialog;
append_class_pop_objects 			*append_class_dialog;
delete_replace_instances_pop_objects 	      *delete_replace_instances_dialog;
delete_instances_pop_objects 			*delete_instances_dialog;
database_select_pop_objects 			*database_select_dialog;
append_interface_pop_objects 			*append_interface_dialog;
classic_append_class_pop_objects 		*classic_append_class_dialog;
classic_replace_class_pop_objects 		*classic_replace_class_dialog;
replace_interface_pop_objects 			*replace_interface_dialog;
classic_delete_class_pop_objects 		*classic_delete_class_dialog;
delete_interface_pop_objects 			*delete_interface_dialog;
rename_interface_pop_objects 			*rename_interface_dialog;

create_database_pop_objects			*create_database_dialog;
destroy_database_pop_objects			*destroy_database_dialog;
command_log_pop_objects				*command_log_pop;
fontset_popup1_objects				*fontset_dialog;
hostset_popup1_objects				*hostset_dialog;
displayset_popup_objects			*displayset_dialog;
load_popup1_objects				*load_dialog;
insert_popup1_objects				*insert_dialog;


#define gray1_width 16
#define gray1_height 16

short gray1_bits[] = {

#include "albericons/class2.ico" 

};

#define gray2_width 16
#define gray2_height 16

short gray2_bits[] = {

#include "albericons/atri2.ico"

};

#define gray3_width  16
#define gray3_height 16

short gray3_bits[] = {

#include "albericons/expression1.ico"

};

#define gray4_width 16
#define gray4_height 16

short gray4_bits[] = {

#include "albericons/constant.ico"

};

#define gray5_width 16
#define gray5_height 16

short gray5_bits[] = {

#include "albericons/all.ico"

};

#define gray6_width 32
#define gray6_height 32

short gray6_bits[] = {

#include "albericons/proc2.ico"

};

#define APPImage_width 64
#define APPImage_height 64

short APPImage_bits[] = {

#include "albericons/alberi.ico"

};

/*
 * Instance XV_KEY_DATA key.  An instance is a set of related
 * user interface objects.  A pointer to an object's instance
 * is stored under this key in every object.  This must be a
 * global variable.
 */


Attr_attribute	INSTANCE;
char query_buffer[8196];
Xv_font Highlight, Normal;

extern char *PQhost;
extern char *PQport;
extern char *PQtty;
extern char *PQoption;
extern char *optarg;
extern FILE  *debug_port;
extern int   PQportset;
extern int   PQtracep;
extern int   optind,opterr;

extern char *version;

void
main ( argc, argv )
     int      argc;
     char   **argv;
{
  char	       *progname;
  unsigned int 	setting; 
  Scrollbar	vscroll;
  Scrollbar	hscroll;
  Panel		query_panel;
  Menu		the_queries_menu, commands, qius, clius;
  int 		FRAMEUNITWIDTH, 
  		FRAMELEFTUNITHEIGHT, 
		FRAMERIGHTUNITHEIGHT;
  int		index;
  Rect 		position_and_size_info, other;
  int 		errflag = 0;
  Rect 		image_rect, label_rect;
  bool 		RunOneCommand = false;
  char 	       *debug_file;
  char 	       *command;
  char 		c;
  int 		host=0;
  char		hostbuf[MAXHOSTNAMELEN];
  char	      **set_alberi_font();
  char	       *username, usernamebuf[USER_NAMESIZE+1];
#ifdef POSTGRES_4_1
  char	       *fe_getauthname();
#endif



  progname = *argv;
  for( index = 0 ; index < 5 ; index++ ) /* Initializing the command stack */
    command_stack[index] = strdup(" ");

  argv = set_alberi_font( &argc, argv );

  xv_init(XV_INIT_ARGC_PTR_ARGV, &argc, argv,
	  XV_ERROR_PROC, alberi_error_handler,
	  NULL);

  INSTANCE = xv_unique_key();

  first_window1 =
    first_window1_objects_initialize(NULL, NULL);
  displayset_dialog =
    displayset_popup_objects_initialize(XV_NULL, first_window1->window1);
  hostset_dialog =
    hostset_popup1_objects_initialize(XV_NULL, first_window1->window1);
       

 /* some code modified from the POSTGRES monitor here */

  while ( (c = getopt(argc, argv, "h:p:t:qTNAQ")) != EOF ) {
    switch (c) {
	case 'h' :
	  PQhost = optarg;
          host = 1;
	  break;
	case 'p' :
	  PQport = optarg;
	  break;
	case 't' :
	  PQtty = optarg;
	  break;
	case 'T' :
        case 'N' :
	  TerseOutput = true;
          setting = (unsigned int) xv_get(displayset_dialog->setting1,
					  PANEL_VALUE);
          setting = (unsigned int) 1 | setting;
          xv_set(displayset_dialog->setting1, PANEL_VALUE, setting, NULL);
	  break;
	case 'A' :
	  PrintAttNames = false;
          setting = (unsigned int) xv_get(displayset_dialog->setting1,
					  PANEL_VALUE);
          setting = (unsigned int) 2 | setting;
          xv_set(displayset_dialog->setting1, PANEL_VALUE, setting, NULL);
	  break;
	case 'q' :
	  Verbose = false;
          setting = (unsigned int) xv_get(displayset_dialog->setting1, 
					  PANEL_VALUE);
          setting = (unsigned int) 4 | setting;
          xv_set(displayset_dialog->setting1, PANEL_VALUE, setting, NULL);
	  break;
	case 'Q' :
	  Verbose = false;
	  Silent = true;
          setting = (unsigned int) xv_get(displayset_dialog->setting1, 
					  PANEL_VALUE);
          setting = (unsigned int) 12 | setting;
          xv_set(displayset_dialog->setting1, PANEL_VALUE, setting, NULL);
	  break;
	case '?' :
	default :
	  errflag++;
	  break;
	}
    }
    if (errflag) {
      fprintf(stderr, "Available options are: - {h, p, t, o, d, q} \n");
      exit(2);
    }

	
	
  /*
   * Initialize user interface components.
   */

  cursor = xv_create(XV_NULL, CURSOR, CURSOR_SRC_CHAR, OLC_COPY_PTR, NULL);


  xv_set(first_window1->window1, XV_X, 0, XV_Y, 0, NULL);
        
  Welcome();
        
  frame_get_rect(first_window1->window1, &position_and_size_info);


#ifdef POSTGRES_4_1
  /* Determine our username (according to the authentication system, if
   * there is one).
   */
  if ((username = fe_getauthname()) == (char *) NULL) {
    fprintf(stderr, "%s: could not find a valid user name\n",
	    progname);
    exit(2);
  }

  bzero(usernamebuf, sizeof(usernamebuf));
  (void) strncpy(usernamebuf, username, USER_NAMESIZE);
  username = usernamebuf;
#else
  username = getenv("USER");
#endif
    
  /*
   *  Determine the hostname of the database server.  Try to avoid using
   * "localhost" if at all possible.
   */
  if (!PQhost && !(PQhost = getenv("PGHOST")))
    PQhost = "localhost";
  if (!strcmp(PQhost, "localhost")) {
    if (gethostname(hostbuf, MAXHOSTNAMELEN) != -1)
      PQhost = hostbuf;
  }

  /* find database */
  if (!(dbname = argv[optind]) &&
      !(dbname = getenv("DATABASE")) &&
      !(dbname = username)) {
    fprintf(stderr, "%s: no database name specified\n", progname);
    exit (2);
  }

  PQsetdb(dbname);
         
  xv_set(hostset_dialog->textfield1, PANEL_VALUE, PQhost, NULL);
    
  sprintf(main_title, "Postgres GLI Alberi [%s]\t Database -> %s on host -> %s", 
		       version, dbname, PQhost);
       
  xv_set(first_window1->window1, FRAME_LEFT_FOOTER, "No errors", 
	 FRAME_RIGHT_FOOTER, "I used to live to serve you, get lost!", 
	 FRAME_LABEL, main_title, 
	 NULL);


  gray[0] = (Server_image)xv_create(XV_NULL, SERVER_IMAGE,
				    XV_WIDTH,               gray1_width,
				    XV_HEIGHT,              gray1_height,
				    SERVER_IMAGE_BITS,      gray1_bits,
				    NULL);

  gray[1] = (Server_image)xv_create(XV_NULL, SERVER_IMAGE,
				    XV_WIDTH,               gray2_width,
				    XV_HEIGHT,              gray2_height,
				    SERVER_IMAGE_BITS,      gray2_bits,
				    NULL);

  gray[2] = (Server_image)xv_create(XV_NULL, SERVER_IMAGE,
				    XV_WIDTH,               gray3_width,
				    XV_HEIGHT,              gray3_height,
				    SERVER_IMAGE_BITS,      gray3_bits,
				    NULL);

  gray6 = (Server_image)xv_create(XV_NULL, SERVER_IMAGE,
				  XV_WIDTH,               gray6_width,
				  XV_HEIGHT,              gray6_height,
				  SERVER_IMAGE_BITS,      gray6_bits,
				  NULL);

  APPImage = (Server_image)xv_create(XV_NULL, SERVER_IMAGE,
				     XV_WIDTH,               APPImage_width,
				     XV_HEIGHT,              APPImage_height,
				     SERVER_IMAGE_BITS,      APPImage_bits,
				     NULL); 

  schema_image = (Server_image)xv_create(XV_NULL, SERVER_IMAGE,
					 XV_WIDTH,            lookattr_width,
					 XV_HEIGHT,           lookattr_height,
					 SERVER_IMAGE_X_BITS, lookattr_bits,
					 NULL);
   
  rect_construct(&image_rect, 0, 10, 64, 74);
  rect_construct(&label_rect, 0, 5, 64, 10);
  APPIcon = (Icon) xv_create(first_window1->window1, ICON,
			     XV_HEIGHT, 64 + 10, 
			     XV_LABEL, dbname,
			     ICON_LABEL_RECT, &label_rect,
			     ICON_IMAGE, APPImage,
			     ICON_IMAGE_RECT, &image_rect,
			     NULL);
  xv_set(first_window1->window1, FRAME_ICON, APPIcon, NULL);
  position_and_size_info.r_top = position_and_size_info.r_left = 0;
  frame_set_rect(first_window1->window1, &position_and_size_info);
  frame_get_rect(first_window1->window1, &original_main_size_and_position);
    
  marco = (Frame)xv_create(first_window1->window1, FRAME_CMD,
			   FRAME_LABEL,  dbname, 
			   XV_WIDTH, 400, XV_HEIGHT, 510,   
			   XV_Y, 0, 
			   XV_X, position_and_size_info.r_width  /*716*/,
			   /* FRAME_SHOW_RESIZE_CORNER, TRUE, */
			   FRAME_CMD_PUSHPIN_IN, TRUE,
			   FRAME_SHOW_FOOTER, TRUE,
			   NULL);
    
  notify_interpose_destroy_func( marco, destroy_func );






  FRAMEUNITWIDTH = ((int) xv_get(marco, XV_WIDTH) +
		    (int) xv_get(first_window1->window1, XV_WIDTH) - 10) / 3;
  FRAMELEFTUNITHEIGHT = ((int) xv_get(marco, XV_HEIGHT) - 100) / 4;
  FRAMERIGHTUNITHEIGHT = ((int) xv_get(marco, XV_HEIGHT) / 3);

  frame_get_rect(marco, &other);
    
  target_frame = (Frame)xv_create(first_window1->window1, FRAME_CMD, 
				  FRAME_LABEL, "TARGET LIST WORKSHELL",
				  XV_WIDTH, FRAMEUNITWIDTH, XV_HEIGHT, 200, 
				  XV_X, 0 * FRAMEUNITWIDTH /*0*/,
				  XV_Y, position_and_size_info.r_height,
				  /* FRAME_SHOW_RESIZE_CORNER, TRUE, */
				  FRAME_CMD_PUSHPIN_IN, TRUE,
				  FRAME_SHOW_FOOTER, TRUE, 
				  NULL);
  qual_frame = (Frame)xv_create(first_window1->window1, FRAME_CMD,
				FRAME_LABEL, "QUALIFIER EXPRESSION WORKSHELL", 
				XV_WIDTH, FRAMEUNITWIDTH, XV_HEIGHT, 200, 
				XV_X, 2 * FRAMEUNITWIDTH + 20 /*448*/,
				XV_Y,  position_and_size_info.r_height, 
				/* FRAME_SHOW_RESIZE_CORNER, TRUE, */
				FRAME_CMD_PUSHPIN_IN, TRUE,
				FRAME_SHOW_FOOTER, TRUE, 
				NULL);
  expression_frame = (Frame)xv_create(first_window1->window1, FRAME_CMD,
				      FRAME_LABEL, "EXPRESSIONS WORKSHELL", 
				      XV_WIDTH, FRAMEUNITWIDTH,
				      XV_HEIGHT, 200, 
				      XV_X, 1 * FRAMEUNITWIDTH + 10 /*224*/,
				      XV_Y,  position_and_size_info.r_height, 
				      /* FRAME_SHOW_RESIZE_CORNER, TRUE, */
				      FRAME_CMD_PUSHPIN_IN, TRUE,
				      FRAME_SHOW_FOOTER, TRUE, 
				      NULL);
  FRAMEUNITWIDTH = ((int) xv_get(marco, XV_WIDTH)
		    + (int) xv_get(first_window1->window1, XV_WIDTH) - 10);
  FRAMELEFTUNITHEIGHT = ((int) xv_get(marco, XV_HEIGHT) - (100 + 10)) / 4;
  FRAMERIGHTUNITHEIGHT = ((int) xv_get(marco, XV_HEIGHT) / 3);

  attrib_addition_frame = (Frame)
    			   xv_create(first_window1->window1, FRAME_CMD,
				     FRAME_LABEL, "ADD ATTRIBUTES WORKSHELL",
				     XV_WIDTH, FRAMEUNITWIDTH, XV_HEIGHT, 200,
				     XV_X, 0 * FRAMEUNITWIDTH + 0 * 10 /*224*/,
				     XV_Y,  position_and_size_info.r_height,
				     FRAME_CMD_PUSHPIN_IN, TRUE,
				     FRAME_SHOW_FOOTER, TRUE,
				     NULL);

  FRAMEUNITWIDTH = ((int) xv_get(marco, XV_WIDTH) +
		    (int) xv_get(first_window1->window1, XV_WIDTH) - 10) / 2;
  FRAMELEFTUNITHEIGHT = ((int) xv_get(marco, XV_HEIGHT) - (100 + 10)) / 4;
  FRAMERIGHTUNITHEIGHT = ((int) xv_get(marco, XV_HEIGHT) / 3);

  attrib_creation_frame = (Frame)
    xv_create(first_window1->window1, FRAME_CMD,
	      FRAME_LABEL, "CREATE-NEW ATTRIBUTES WORKSHELL",
	      XV_WIDTH, FRAMEUNITWIDTH, XV_HEIGHT, 200,
	      XV_X, 0 * FRAMEUNITWIDTH + 0 * 10 /*224*/,
	      XV_Y,  position_and_size_info.r_height /*574*/,
	      FRAME_CMD_PUSHPIN_IN, TRUE,
	      FRAME_SHOW_FOOTER, TRUE,
	      NULL);
  inheritance_frame = (Frame)
    xv_create(first_window1->window1, FRAME_CMD,
	      FRAME_LABEL, "CREATE INHERITANCE WORKSHELL",
	      XV_WIDTH, FRAMEUNITWIDTH, XV_HEIGHT, 200,
	      XV_X, 1 * FRAMEUNITWIDTH + 1 * 10 /*224*/,
	      XV_Y,  position_and_size_info.r_height /*574*/,
	      FRAME_CMD_PUSHPIN_IN, TRUE,
	      FRAME_SHOW_FOOTER, TRUE,
	      NULL);

  FRAMEUNITWIDTH = ((int) xv_get(marco, XV_WIDTH) / 2);
    
  class_title = (Panel) xv_create(marco, PANEL, 
				  XV_X, 0, XV_Y, 0, 
				  XV_WIDTH, FRAMEUNITWIDTH * 2, 
				  XV_HEIGHT, THEIGHT, 
				  /* CANVAS_RESIZE_PROC, resize_class_title, */
				  NULL);
  class_info = (Panel_item) xv_create(class_title, PANEL_MESSAGE, 
				      PANEL_LABEL_STRING, "Classes", 
				      PANEL_LABEL_BOLD, TRUE,  
				      NULL);  
  shell1 = (Canvas_shell) xv_create(marco,  CANVAS_SHELL, 
				    WIN_BELOW, class_title,
				    XV_WIDTH, FRAMEUNITWIDTH * 2,
				    XV_HEIGHT, FRAMELEFTUNITHEIGHT,
				    XV_X,  0, 
				    XV_Y, (int)xv_get(class_title, XV_Y) +
				          (int)xv_get(class_title, XV_HEIGHT), 
				    CANVAS_MIN_PAINT_WIDTH, 1000,
				    CANVAS_MIN_PAINT_HEIGHT, 1000,
				    /* CANVAS_RESIZE_PROC, resize_class, */
				    NULL);
  vscroll = (Scrollbar) xv_create(shell1, SCROLLBAR, 
				  SCROLLBAR_DIRECTION, SCROLLBAR_VERTICAL,
				  SCROLLBAR_PIXELS_PER_UNIT, 35,
				  NULL);

  attribute_title = (Panel) xv_create(marco, PANEL, 
				      WIN_BELOW, shell1,
				      XV_X, 0, 
				      XV_Y, (int) xv_get(shell1, XV_Y) +
				            (int) xv_get(shell1, XV_HEIGHT), 
				      XV_WIDTH, FRAMEUNITWIDTH * 2, 
				      XV_HEIGHT, THEIGHT, 
				      NULL);
  attribute_info = (Panel_item) xv_create(attribute_title, PANEL_MESSAGE, 
					  PANEL_LABEL_STRING, "Attributes", 
					  PANEL_LABEL_BOLD, TRUE, 
					  NULL);
  attribute_shell = (Canvas_shell)
    xv_create(marco, CANVAS_SHELL,
	      WIN_BELOW, attribute_title,
	      XV_WIDTH, FRAMEUNITWIDTH * 2, 
	      XV_HEIGHT, FRAMELEFTUNITHEIGHT, 
	      XV_X, 0, 
	      XV_Y, (int) xv_get(attribute_title, XV_Y) +
	            (int) xv_get(attribute_title, XV_HEIGHT), 
	      CANVAS_MIN_PAINT_WIDTH, 1000,
	      CANVAS_MIN_PAINT_HEIGHT, 1000,
	      /* CANVAS_RESIZE_PROC, resize_attribs, */
	      NULL);
  vscroll = (Scrollbar) xv_create(attribute_shell, SCROLLBAR, 
				  SCROLLBAR_DIRECTION, SCROLLBAR_VERTICAL, 
				  SCROLLBAR_PIXELS_PER_UNIT, 35,
				  NULL);
  window_fit(attribute_shell);

  parents_title = (Panel)
    xv_create(marco, PANEL,
	      WIN_BELOW, attribute_shell, 
	      XV_X, 0, 
	      XV_Y, (int) xv_get(attribute_shell, XV_Y) +
	            (int) xv_get(attribute_shell, XV_HEIGHT), 
	      XV_WIDTH, FRAMEUNITWIDTH * 2,
	      XV_HEIGHT, THEIGHT,
	      /* CANVAS_RESIZE_PROC, resize_parents_title, */
	      NULL);
  parents_info = (Panel_item) xv_create(parents_title, PANEL_MESSAGE, 
					PANEL_LABEL_STRING, "Parents", 
					PANEL_LABEL_BOLD, TRUE, 
					NULL);
  parents_shell = (Canvas_shell)
    xv_create(marco, CANVAS_SHELL,
	      WIN_BELOW, parents_title,
	      XV_WIDTH, FRAMEUNITWIDTH * 2,
	      XV_HEIGHT, FRAMELEFTUNITHEIGHT, 
	      XV_X, 0, 
	      XV_Y, (int) xv_get(parents_title, XV_Y) + 
	            (int) xv_get(parents_title, XV_HEIGHT), 
	      CANVAS_MIN_PAINT_WIDTH, 1000, 
	      CANVAS_MIN_PAINT_HEIGHT, 1000,
	      /* CANVAS_RESIZE_PROC, resize_parents, */
	      NULL);
  vscroll = (Scrollbar) xv_create(parents_shell, SCROLLBAR, 
				  SCROLLBAR_DIRECTION, SCROLLBAR_VERTICAL, 
				  SCROLLBAR_PIXELS_PER_UNIT, 35,
				  NULL);
  window_fit(parents_shell);

  children_title = (Panel) xv_create(marco, PANEL,
				     WIN_BELOW, parents_shell, 
				     XV_X, 0, 
				     XV_Y, 
				      (int) xv_get(parents_shell, XV_Y) + 
				      (int) xv_get(parents_shell, XV_HEIGHT), 
				     XV_WIDTH, FRAMEUNITWIDTH * 2,
				     XV_HEIGHT, THEIGHT, 
				     NULL);
  children_info = (Panel_item) xv_create(children_title, PANEL_MESSAGE, 
					 PANEL_LABEL_STRING, "Children",
					 PANEL_LABEL_BOLD, TRUE, 
					 NULL);
  children_shell = (Canvas_shell)
    xv_create(marco, CANVAS_SHELL,
	      WIN_BELOW, children_title, 
	      XV_WIDTH, FRAMEUNITWIDTH * 2,
	      XV_HEIGHT, FRAMELEFTUNITHEIGHT, 
	      XV_X, 0 , 
	      XV_Y, (int) xv_get(children_title, XV_Y) + 
	            (int) xv_get(children_title, XV_HEIGHT), 
	      CANVAS_MIN_PAINT_WIDTH, 1000, 
	      CANVAS_MIN_PAINT_HEIGHT, 1000,
	      /* CANVAS_RESIZE_PROC, resize_children, */
	      NULL);
  vscroll = (Scrollbar) xv_create(children_shell, SCROLLBAR, 
				  SCROLLBAR_DIRECTION, SCROLLBAR_VERTICAL,
				  SCROLLBAR_PIXELS_PER_UNIT, 35,
				  NULL);
  window_fit(children_shell);


  dropping_shell = (Canvas_shell) 
    xv_create(marco, CANVAS_SHELL, WIN_BELOW, children_shell, 
	      XV_X, 0, 
	      XV_Y, (int) xv_get(children_shell, XV_Y) +
	            (int) xv_get(children_shell, XV_HEIGHT),
	      XV_WIDTH, FRAMEUNITWIDTH ,
	      XV_HEIGHT, THEIGHT + 10, 
	      /* CANVAS_RESIZE_PROC, resize_drop_area, */
	      NULL);

  the_queries_menu = (Menu)
    xv_create(XV_NULL, MENU ,
	      MENU_GEN_PIN_WINDOW, marco, "Visual Postquel",
	      MENU_TITLE_ITEM, "Visual Postquel",
	      MENU_PULLRIGHT_ITEM, "Command", 
	      (Menu) xv_create(XV_NULL, MENU,
			       MENU_ACTION_ITEM,
			         "Submmit command", menu_submmit,
			       MENU_ACTION_ITEM,
			         "Clear command (Start over)",
			          clean_the_icon_query,
			       MENU_RELEASE,
			       NULL),
	      MENU_PULLRIGHT_ITEM, "Data Management Interface", 
	      (Menu) xv_create(XV_NULL, MENU,
			       MENU_ACTION_ITEM,
			          "Show Query System", show_query_system,
			       MENU_ACTION_ITEM,
			          "Hide Query System", hide_query_system,
			       MENU_RELEASE,
			       NULL),
	      MENU_PULLRIGHT_ITEM, "Class Management Interface",
	      (Menu) xv_create(XV_NULL, MENU,
			       MENU_ACTION_ITEM,
			          "Show Class Creation System", 
			          show_class_creation_system,
			       MENU_ACTION_ITEM,
			          "Hide Class Creation System", 
			          hide_class_creation_system,
			       MENU_RELEASE, 
			       NULL),
	      XV_KEY_DATA, MENU_OWNER, dropping_shell,
	      MENU_RELEASE,
	      NULL);

  xv_set(dropping_shell,  RECTOBJ_MENU, the_queries_menu, NULL);

  query_panel = (Panel) xv_create(marco, PANEL, 
				  WIN_BELOW,  children_shell, 
				  XV_X, FRAMEUNITWIDTH,
				  XV_Y, (int)xv_get(children_shell, XV_Y) + 
				        (int)xv_get(children_shell, XV_HEIGHT),
				  XV_WIDTH, FRAMEUNITWIDTH,
				  XV_HEIGHT, THEIGHT + 10, 
				  /* CANVAS_RESIZE_PROC, resize_drop_area, */
				  NULL);

  (void) xv_create(query_panel, PANEL_BUTTON, 
		   PANEL_LABEL_STRING, "Visual POSTQUEL",
		   /* PANEL_NOTIFY_PROC, dumb, */
		   PANEL_ITEM_MENU, the_queries_menu,
		   NULL);

  (void) xv_create(dropping_shell, DRAWIMAGE, DRAWIMAGE_SVRIMAGE, gray6,
		   RECTOBJ_ACCEPTS_DROP, TRUE,
		   RECTOBJ_DROP_PROC, query_drop,
		   RECTOBJ_DBL_CLICK_PROC, submmit_the_query_proc,  
		   NULL);

  classes = (Array_tile) 
    xv_create(shell1, ARRAY_TILE, ARRAY_TILE_N_COLUMNS, 3, 
	      XV_WIDTH, 550, XV_HEIGHT, 400, NULL);

  attributes = (Array_tile) xv_create(attribute_shell,
				      ARRAY_TILE,
				      ARRAY_TILE_N_COLUMNS, 3,
				      NULL);
  parents =  (Array_tile) xv_create(parents_shell,
				    ARRAY_TILE,
				    ARRAY_TILE_N_COLUMNS, 3,
				    NULL);
  children = (Array_tile) xv_create(children_shell,
				    ARRAY_TILE,
				    ARRAY_TILE_N_COLUMNS, 3, 
				    NULL);

  initialize_QT();
  initialize_CCT();
  initialize_SCM();

  operator_selector_popup = operator_select_operator_selection_pop_objects_initialize(XV_NULL, first_window1->window1);
  unary_selector_popup = unary_select_popup1_objects_initialize(XV_NULL, first_window1->window1);
  name_attribute_popup = name_attribute_pop_objects_initialize(XV_NULL, first_window1->window1);
  funct_selector_popup = funct_select_pop_objects_initialize(XV_NULL,  first_window1->window1);
  constant_selector_popup = constant_select_pop_objects_initialize(XV_NULL, first_window1->window1);
  name_instance_popup = name_instance_pop_objects_initialize(XV_NULL, first_window1->window1);
  new_type_dialog = new_attrib_type_pop_objects_initialize(XV_NULL, first_window1->window1);
  name_new_class_dialog = name_new_class_pop_objects_initialize(XV_NULL, first_window1->window1);
  retrieve_into_dialog = retrieve_into_classname_pop_objects_initialize(XV_NULL, first_window1->window1);
  append_class_dialog = append_class_pop_objects_initialize(XV_NULL, first_window1->window1);
  delete_replace_instances_dialog = delete_replace_instances_pop_objects_initialize(XV_NULL, first_window1->window1);
  delete_instances_dialog = delete_instances_pop_objects_initialize(XV_NULL, first_window1->window1);
  database_select_dialog = database_select_pop_objects_initialize(XV_NULL, first_window1->window1);
  append_interface_dialog = append_interface_pop_objects_initialize(XV_NULL, first_window1->window1);
  classic_append_class_dialog = classic_append_class_pop_objects_initialize(XV_NULL, first_window1->window1);
  classic_replace_class_dialog = classic_replace_class_pop_objects_initialize(XV_NULL, first_window1->window1);
  replace_interface_dialog = replace_interface_pop_objects_initialize(XV_NULL, first_window1->window1);
  classic_delete_class_dialog = classic_delete_class_pop_objects_initialize(XV_NULL, first_window1->window1);
  delete_interface_dialog = delete_interface_pop_objects_initialize(XV_NULL, first_window1->window1);
  rename_interface_dialog = rename_interface_pop_objects_initialize(XV_NULL, first_window1->window1); 
  create_database_dialog = create_database_pop_objects_initialize(XV_NULL, first_window1->window1);
  destroy_database_dialog = destroy_database_pop_objects_initialize(XV_NULL, first_window1->window1);
  command_log_pop = command_log_pop_objects_initialize(XV_NULL, first_window1->window1);
  fontset_dialog = fontset_popup1_objects_initialize(XV_NULL, first_window1->window1);
  load_dialog = load_popup1_objects_initialize(XV_NULL, first_window1->window1);
  insert_dialog = insert_popup1_objects_initialize(XV_NULL, first_window1->window1);

  window_fit(marco);


  timer.it_value.tv_usec = 6000;
  timer.it_interval.tv_sec = 30;
  notify_set_itimer_func(first_window1->window1, tiempo,
			 ITIMER_REAL, &timer,
			 NULL); 
        
  check_database(first_window1, 0); 
  /*
   * Turn control over to XView.
   */
  xv_main_loop(first_window1->window1);
  xv_destroy(gray[0]);
  xv_destroy(gray[1]);
  xv_destroy(gray[2]);
  xv_destroy(gray1);
  xv_destroy(gray2);
  xv_destroy(gray3);
  xv_destroy(gray4);
  xv_destroy(gray5);
  xv_destroy(gray6);
  xv_destroy(APPImage);
  xv_destroy(schema_image);

                              
  exit(0);
        
}


void
Welcome()
{
  textsw_reset(first_window1->textpane3, 0, 0);
  textsw_reset(first_window1->textpane1, 0, 0);
  xv_set(first_window1->textpane3,
	 TEXTSW_MEMORY_MAXIMUM, 250000,
	 /* TEXTSW_BROWSING, TRUE, */
	 NULL);
  xv_set(first_window1->textpane1,
	 TEXTSW_MEMORY_MAXIMUM, 250000,
	 /* TEXTSW_BROWSING, TRUE, */
	 NULL);

  if ( Verbose ) {
    xv_set(first_window1->textpane3,
	   TEXTSW_CONTENTS, "POSTGRES GLI Alberi\n\n\n", 
	   NULL);
  }

}

/*
 * Event callback function for `window1'.
 */
Notify_value
close_inform(win, event, arg, type)
     Xv_window       win;
     Event           *event;
     Notify_arg      arg;
     Notify_event_type type;
{
  first_window1_objects   *ip = (first_window1_objects *)
				  xv_get(win, XV_KEY_DATA, INSTANCE);

       
  switch ( event_action( event ) ) {
  case ACTION_CLOSE :
    xv_set((Icon) xv_get(ip->window1, FRAME_ICON),
	   XV_LABEL, dbname,
	   NULL);      
    break;
  default : ;
  }
        
  return notify_next_event_func(win, (Notify_event) event, arg, type);
}

int
quit()
{
  xv_destroy_safe( marco );
  return XV_OK;
}

void
free_string(object, key, data)
     Xv_object object;
     int key;
     caddr_t data;
{
  
  free(data);
}

/*
 * copy argv into new area and add "-fn FRAME_FONT"
 * where FRAME FONT is defined at the beginning
 *
 */

char **
set_alberi_font( argc, argv )
     int *argc;
     char **argv;
{
  char **newargv = (char**) malloc( (*argc+2) * sizeof( char* ) );
  char **tmp;
  int i;

  if ( newargv == NULL )
    abend( "No space for argument vector" );
  for( i = 0, tmp = newargv; i < *argc; i++, tmp++ ) {
    *tmp = (char*) malloc( strlen( argv[i] ) + 1 );
    if ( *tmp == NULL )
      abend( "No space for argument vector" );
    strcpy( *tmp, argv[i] );
  }
  newargv[*argc] = (char*) malloc( strlen( "-fn" ) + 1 );
  strcpy( newargv[*argc], "-fn" );
  (*argc)++;
  newargv[*argc] = (char*) malloc( strlen( FRAME_FONT ) + 1 );
  strcpy( newargv[*argc], FRAME_FONT );
  (*argc)++;
  newargv[*argc] = NULL;
  return newargv;
}
