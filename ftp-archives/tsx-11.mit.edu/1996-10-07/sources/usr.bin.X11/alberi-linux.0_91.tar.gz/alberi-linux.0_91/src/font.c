
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/font.h>
#include <xview/panel.h>

/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "fontset_ui.h"
#include "externs.h"

extern Xv_opaque family_panel, style_panel, scale_panel;
extern fontset_popup1_objects	*fontset_dialog;



/*
 * Notify callback function for `font_family_setting'.
 */
void
change_font(item, event)
        Panel_item      item;
        Event           *event;
{
  fontset_popup1_objects *ip = (fontset_popup1_objects *) 
    				   xv_get(item, XV_KEY_DATA, INSTANCE);

  static int  family, style, scale;
  char        buf[128];
  Frame       frame;
  char        family_name[100], *fn, fn1[100];
  char        style_name[100], *sn, sn1[100];
  int         scale_value;
  Xv_Font     font;
  Panel_item      family_item, style_item, scale_item, name_item;
  char       *convert_font_name();

  family_item = ip->font_family_setting;
  style_item = ip->font_style_setting;
  scale_item = ip->font_scale_setting;

  frame = (Frame)xv_get(xv_get(item, PANEL_PARENT_PANEL), XV_OWNER);
  fn = (char *) xv_get(family_item, PANEL_CHOICE_STRING,
		       xv_get(family_item, PANEL_VALUE));
  if ( !strcmp( fn, "Courier" ) )
    fn[4] = '\0';
  strcpy( fn1, fn );
  convert_font_name( fn1 );
  strcpy( family_name, "FONT_FAMILY_" );
  strcat( family_name, fn1 );
  sn = (char *) xv_get(style_item, PANEL_CHOICE_STRING,
			       xv_get(style_item, PANEL_VALUE));
  strcpy( sn1, sn );
  convert_font_name( sn1 );
  strcpy( style_name, "FONT_STYLE_" );
  strcat( style_name, sn1 );
  scale_value = (int) xv_get(scale_item, PANEL_VALUE);

  xv_set(first_window1->window1, FRAME_BUSY, TRUE, NULL);
  font = (Xv_Font)xv_find(first_window1->window1, FONT,
			  FONT_FAMILY,    family_name,
			  FONT_STYLE,     style_name,
			  FONT_SCALE,     scale_value,
			  FONT_SIZES_FOR_SCALE, 12, 14, 16, 22,
			  NULL);
  xv_set(first_window1->window1, FRAME_BUSY, FALSE, NULL);

  if (!font) {
    if (item == family_item) {
      sprintf(buf, "cannot load '%s'", family_name);
      xv_set(family_item, PANEL_VALUE, family, NULL);
    } else if (item == style_item) {
      sprintf(buf, "cannot load '%s'", style_name);
      xv_set(style_item, PANEL_VALUE, style, NULL);
    } else {
      sprintf(buf, "Not available in %s scale.",
	      xv_get(scale_item, PANEL_CHOICE_STRING, scale));
      xv_set(scale_item, PANEL_VALUE, scale, NULL);
    }
    xv_set(first_window1->window1, FRAME_RIGHT_FOOTER, buf, NULL);
    return;
  }
/*  if (item == family_item)
    family = value;
  else if (item == style_item)
    style = value;
  else
    scale = value; */
  xv_set(first_window1->textpane3, WIN_FONT, font, NULL);
  xv_set(ip->popup1, XV_SHOW, FALSE, NULL);


}


void
cancel_fontset(item, event)
        Panel_item      item;
        Event           *event;
{
  fontset_popup1_objects *ip = (fontset_popup1_objects *) 
    				   xv_get(item, XV_KEY_DATA, INSTANCE);
  Panel_item      family_item, style_item, scale_item;

  family_item = fontset_dialog->font_family_setting;
  style_item = fontset_dialog->font_style_setting;
  scale_item = fontset_dialog->font_scale_setting;
  xv_set(family_item, PANEL_VALUE, family_panel, NULL);
  xv_set(style_item, PANEL_VALUE, style_panel, NULL);
  xv_set(scale_item, PANEL_VALUE, scale_panel, NULL);
  xv_set(ip->popup1, XV_SHOW, FALSE, NULL);
}

char *
convert_font_name( name )
     char *name;
{
  char *np;
  
  for( np = name; *np != '\0'; np++ )
    if ( *np == ' ' )
      *np = '_';
    else if ( islower( *np ) )
      *np = toupper( *np );

  return name;
}
