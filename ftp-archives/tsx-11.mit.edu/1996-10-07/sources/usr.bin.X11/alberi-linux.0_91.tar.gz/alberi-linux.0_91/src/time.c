
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <time.h>
#include <stdio.h>
#include <sys/param.h>
#include <sys/types.h>

#include <xview/xview.h>
#include <xview/panel.h>

/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "externs.h"

#include "constants.h"
#include "grays.h"
#include "funcs.h"


/* This is date & time function */
Notify_value tiempo( client, which)
     Notify_client client;
     int 	   which;
{
  char time_str[50];
  /* static char time_str_second[50]; */
  time_t count;
  time_t *count1 = NULL;
  struct tm *this_is_the_right_one_baby_ah_ha;

  count = time(count1);
  this_is_the_right_one_baby_ah_ha = localtime(&count);
  
  strftime(time_str, 40, "%A %B, %d %Y == %I:%M %p",
	   this_is_the_right_one_baby_ah_ha);
  
  xv_set(client, FRAME_RIGHT_FOOTER, time_str, NULL);
  return NOTIFY_DONE;
}
  
