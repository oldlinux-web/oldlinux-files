
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "retrieve_into_classname_ui.h"
#include "constants.h"

extern int PQtracep;
extern bool Debugging;

/*
 * Notify callback function for `classname_field'.
 */
Panel_setting
assign_class(item, event)
	Panel_item	item;
	Event		*event;
{
	retrieve_into_classname_pop_objects	*ip = (retrieve_into_classname_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
	char *	value = (char *) xv_get(item, PANEL_VALUE);
        int conflict, length, character;
        PortalBuffer *p;
        int i, j, k, g, n, m, t, x, s;
        char *class_name, create_ahead[64], old[64];

        conflict = 0;

if(Debugging) PQtracep = 0;

        alberi_PQexec("begin");
        alberi_PQexec("retrieve portal schema (pg_class.relname)");
        alberi_PQexec("fetch all in schema");

        p = PQparray("schema");
        g = PQngroups(p);
        t = 0;

        for(k = 0; k < g; k++) {
         n = PQntuplesGroup(p, k);
	 m = PQnfieldsGroup(p, k);
         for(i = 0; i < n; i++) {    
            class_name = strdup( PQgetvalue(p, t + i, 0));
            if(!strcmp(value, class_name)) conflict = 1;
         }
	 t += n;
	}
        alberi_PQexec("close schema");
        alberi_PQexec("end");

if(Debugging) PQtracep = 1;

        if(!conflict) {
         if ((length = strlen(value)) > 16) {
            xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names are 16 characters or less!!", NULL);
            xv_set(item, PANEL_VALUE, "Error", NULL);
            value = strdup("Error");
         } else {
           if ((!isalpha(value[0]))  && (value[0] != '_'))  {
              xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names start with alphabetic or underscore", NULL);
              xv_set(item, PANEL_VALUE,"Error" , NULL);
              value = strdup("Error");
           } else {
             for(character =  1; character < length; character++) {
                 if ((!isalnum(value[character])) && (value[character] != '_')) {
                    xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names include alphanumeric and underscore", NULL);
                    xv_set(item, PANEL_VALUE, "Error ", NULL);
                    value = strdup("Error");
                    break;
                 }
             }
          }
        } 
        } else {
          xv_set(ip->pop, FRAME_LEFT_FOOTER, value, NULL);
          xv_set(ip->pop, FRAME_RIGHT_FOOTER, "already in use", NULL);
          value = strdup("Error");
        }
        /* xv_set((Frame) xv_get(ip->pop, XV_KEY_DATA, OPER), FRAME_LEFT_FOOTER, "retrieve ", NULL); */

        if((char *) xv_get((Frame) xv_get(ip->pop, XV_KEY_DATA, OPER), FRAME_LEFT_FOOTER))
               (void) strcpy(old, (char *) xv_get((Frame) xv_get(ip->pop, XV_KEY_DATA, OPER), FRAME_LEFT_FOOTER));
        else old[0] = '\0';

        if(!strcmp(value, "NULL")) {
          if(old[0]) {
               if(strstr(old, "unique")) {
                 class_name = strdup("retrieve unique ");
               } else class_name = strdup("retrieve ");
          } else class_name = strdup("retrieve ");
          xv_set((Frame) xv_get(ip->pop, XV_KEY_DATA, OPER), FRAME_LEFT_FOOTER, class_name, NULL);
          value = strdup("Error");
        }     
        if(strcmp(value, "Error") != 0) {
           if(!strcmp(value, "") || !strcmp(value, " ")) {
             if(old[0]) {
               if(strstr(old, "unique")) {
                 class_name = strdup("retrieve unique ");
               } else class_name = strdup("retrieve ");
             } else class_name = strdup("retrieve ");
           } else {
             if(old[0]) {
              if(strstr(old, "unique")) {
	        (void) strcpy(create_ahead ,"retrieve into "); 
                (void) strcat(create_ahead, value);
                class_name = strdup(strcat(create_ahead, " unique "));
              } else {
                (void) strcpy(create_ahead ,"retrieve into "); 
                (void) strcat(create_ahead, value);
                class_name = strdup(strcat(create_ahead, " "));
              }
             } else {
                (void) strcpy(create_ahead ,"retrieve into "); 
                (void) strcat(create_ahead, value);
                class_name = strdup(strcat(create_ahead, " "));
             }    
           }
           xv_set((Frame) xv_get(ip->pop, XV_KEY_DATA, OPER), FRAME_LEFT_FOOTER, class_name, NULL);
           xv_set(ip->pop, XV_SHOW, FALSE, NULL);
        }
       

	
	
	return panel_text_notify(item, event);
}

