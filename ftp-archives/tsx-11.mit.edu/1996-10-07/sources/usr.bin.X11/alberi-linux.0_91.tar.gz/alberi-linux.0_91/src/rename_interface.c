
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "constants.h"
#include "switches.h"
#include "rename_interface_ui.h"
#include "first_ui.h"

extern Frame marco;
extern first_window1_objects *first_window1;
extern PQtracep;

/*
 * Notify callback function for `new_class_textfield'.
 */
Panel_setting
rename_class_interface_proc(item, event)
	Panel_item	item;
	Event		*event;
{
  rename_interface_pop_objects	*ip = (rename_interface_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
  char *	value = (char *) xv_get(item, PANEL_VALUE);
  int conflict, length, character;
  PortalBuffer *p;
  int i, j, k, g, n, m, t, x, s;
  char *class_name, create_ahead[32];
  char temp[8196], query_buffer[8196], temp_q[8196];


        xv_set(ip->pop, FRAME_BUSY, TRUE, NULL);
        temp[0] = '\0';
        conflict = 0;
if(Debugging) PQtracep = 0;
        alberi_PQexec("begin");
        alberi_PQexec("retrieve portal schema (pg_class.relname)");
        alberi_PQexec("fetch all in schema");

        p = PQparray("schema");
        g = PQngroups(p);
        t = 0;

        for(k = 0; k < g; k++) {
         n = PQntuplesGroup(p, k);
	 m = PQnfieldsGroup(p, k);
         for(i = 0; i < n; i++) {    
            class_name = strdup( PQgetvalue(p, t + i, 0));
            if(!strcmp(value, class_name)) conflict = 1;
         }
	 t += n;
	}
        alberi_PQexec("close schema");
        alberi_PQexec("end");
if(Debugging) PQtracep = 1;
        if(!conflict) {
         if ((length = strlen(value)) > 16) {
            xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names are 16 characters or less!!", NULL);
            xv_set(item, PANEL_VALUE, "Error", NULL);
            value = strdup("Error");
	  } else {
	    if ((!isalpha(value[0]))  && (value[0] != '_'))  {
              xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names start with alphabetic or underscore", NULL);
              xv_set(item, PANEL_VALUE,"Error" , NULL);
              value = strdup("Error");
           } else {
             for(character =  1; character < length; character++) {
                 if ((!isalnum(value[character])) && (value[character] != '_')) {
                    xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names include alphanumeric and underscore", NULL);
                    xv_set(item, PANEL_VALUE, "Error ", NULL);
                    value = strdup("Error");
                    break;
                 }
             }
          }
        } 
        } else {
          xv_set(ip->pop, FRAME_LEFT_FOOTER, value, NULL);
          xv_set(ip->pop, FRAME_RIGHT_FOOTER, "already in use", NULL);
          value = strdup("Error");
        }     
        if(strcmp(value, "Error") != 0) {
            (void) strcpy(temp, "rename ");
            (void) strcat(temp, (char *) xv_get(ip->old_name_class, PANEL_LABEL_STRING));
            (void) strcat(temp, " to ");
            (void) strcat(temp, value);
	    strcpy(query_buffer, temp);
     
         

  
            xv_set(marco, 
                FRAME_LEFT_FOOTER, "Rename...",  
                FRAME_RIGHT_FOOTER, "Submmited",
                NULL);
 
	    if ( Verbose )
	      textsw_insert(first_window1->textpane3, "\n", 1);

	    strcpy(temp_q, clean_query(query_buffer));
 
	    if ( Verbose ) {
	      textsw_insert(first_window1->textpane3, 
			    "Query sent to Postgres Backend:\n", 32);
	      textsw_insert(first_window1->textpane3, temp_q, strlen(temp_q));
	      textsw_insert(first_window1->textpane3, "\n", 1); 
	    }
 
	    if (handle_execution(temp_q, first_window1) == 1) 
	      backend_error( "Postgres backend returned error" );
	    else {
	      xv_set(first_window1->window1,
		     FRAME_LEFT_FOOTER, "No errors", 
		     NULL); 
	      if(temp_q[0]) insert_in_command_stack(temp_q);
	    }

	    if((char *) strstr(temp_q, "create") || 
	       (char *) strstr(temp_q, "retrieve into") || 
	       (char *) strstr(temp_q, "addattr") ||
	       (char *) strstr(temp_q, "rename")) {
	      update_schema();
	    }

	    bzero(query_buffer, strlen(query_buffer)); /* query_buffer[0] = 0 */

	    xv_set(ip->pop, XV_SHOW, FALSE, NULL);
	  }
       
	xv_set(ip->pop, FRAME_BUSY, FALSE, NULL);	
	
	return panel_text_notify(item, event);
      }











