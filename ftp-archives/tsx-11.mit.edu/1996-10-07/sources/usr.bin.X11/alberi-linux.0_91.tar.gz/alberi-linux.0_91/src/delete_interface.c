
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>
#include <xview/notice.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "constants.h"
#include "switches.h"
#include "delete_interface_ui.h"
#include "first_ui.h"


extern int PQtracep;
extern first_window1_objects *first_window1;
extern int tuple_fetch1();

/*
 * Notify callback function for `attribute_list'.
 */
int
attribute_select_delete(item, string, client_data, op, event)
	Panel_item	item;
	char		*string;
	Xv_opaque	client_data;
	Panel_list_op	op;
	Event		*event;
{
	delete_interface_pop_objects	*ip = (delete_interface_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
        char *temp, value[8196], *whole_thing;
        int ROWS, row, item_no;
	
	switch(op) {
	case PANEL_LIST_OP_DESELECT:
                xv_set(ip->type_message, XV_SHOW, FALSE, NULL);
		
		break;

	case PANEL_LIST_OP_SELECT:
                /* Strcat the value typed in the text item with the contents of client_data 
                 * PANEL_LIST_CLIENT_DATA for the value.  
                 */
                ROWS = (int) xv_get(ip->attribute_list, PANEL_LIST_NROWS);
                for(row = 0 ; row < ROWS ; row++) { /* list_item selected */
                    if(xv_get(ip->attribute_list, PANEL_LIST_SELECTED, row)) {
                        item_no = row;
                    }
                }
                whole_thing = strdup((char *) client_data);
                
                xv_set(ip->type_message, PANEL_LABEL_STRING, whole_thing, PANEL_CLIENT_DATA, item_no, NULL);
                
                xv_set(ip->type_message, XV_SHOW, TRUE, NULL);
		
		break;

	case PANEL_LIST_OP_VALIDATE:
	
		break;

	case PANEL_LIST_OP_DELETE:
	
		break;
	}
	return XV_OK;
}

/*
 * Notify callback function for `delete_button'.
 */
void
delete_tuple_proc(item, event)
     Panel_item	item;
     Event		*event;
{
  delete_interface_pop_objects	*ip = 
    (delete_interface_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
  char temp[8196], query_buffer[8196], temp_q[8196], oid[20];
  char *type, *whole, *value, t_value[8196];
  int sure_to_delete, new_total;

  
  temp[0] = '\0';
  strcpy(temp, "delete ");
  strcat(temp, (char *) xv_get(ip->pop, FRAME_LABEL));
  strcat(temp, " where ");
  sprintf(oid, "%s.oid = \"%s\"::oid", 
	  (char *) xv_get(ip->pop, FRAME_LABEL), 
	  (char *) xv_get(ip->pop, XV_KEY_DATA, TYPENAME));
  strcat(temp, oid);

  sure_to_delete = notice_prompt(ip->pop, NULL,
				 NOTICE_MESSAGE_STRINGS, 
				   "Delete this tuple?", NULL,
				 NOTICE_BUTTON_YES, "Yes",
				 NOTICE_BUTTON_NO, "No",
				 NULL);

  if ( sure_to_delete == NOTICE_YES ) {

    strcpy(query_buffer, temp);

    xv_set(ip->pop, FRAME_LEFT_FOOTER, "Delete submitted", NULL);
 
    if ( Verbose )
      textsw_insert( first_window1->textpane3, "\n", 1 );
                  
    strcpy( temp_q, clean_query( query_buffer ) );
 
    if ( Verbose ) {
      textsw_insert( first_window1->textpane3,
		    "Query sent to Postgres Backend:\n", 32 );
      textsw_insert(first_window1->textpane3, temp_q, strlen(temp_q));
      textsw_insert(first_window1->textpane3, "\n", 1); 
    }
 
    if (handle_execution(temp_q, first_window1) == 1)
      backend_error( "Postgres backend returned error" );
    else { 
      xv_set(first_window1->window1, FRAME_LEFT_FOOTER, "No errors", NULL); 
      if(temp_q[0])
	insert_in_command_stack(temp_q);
    }

    if((char *) strstr(temp_q, "create") || 
       (char *) strstr(temp_q, "retrieve into") || 
       (char *) strstr(temp_q, "addattr"))
      update_schema();
  
    bzero(query_buffer, strlen(query_buffer));

    /* get the new values oficially */
    xv_set(ip->pop, FRAME_BUSY, TRUE, NULL);
    new_total = tuple_fetch1((char *) xv_get(ip->pop, FRAME_LABEL), 0);
    if( !new_total ) {
      xv_set(ip->pop, 
	     FRAME_LEFT_FOOTER, "No tuples", 
	     FRAME_RIGHT_FOOTER, "",
	     NULL);
      xv_set(ip->which_tuple_setting,
	     XV_SHOW, FALSE,
	     NULL);
      xv_set(ip->tuple_message,
	     XV_SHOW, FALSE,
	     NULL);                  
      xv_set(ip->tuple_slider,
	     XV_SHOW, FALSE,
	     NULL);
    }
    if ( new_total )
      xv_set(ip->tuple_slider,
	     PANEL_MAX_VALUE, new_total - 1,
	     PANEL_VALUE, atoi((char *) xv_get(ip->pop, FRAME_RIGHT_FOOTER)),
	     NULL);
    xv_set(ip->pop, FRAME_BUSY, FALSE, XV_KEY_DATA, CLASS, new_total, NULL);
  }
}

/*
 * Notify callback function for `which_tuple_setting'.
 */
void
which_tuple_proc1(item, value, event)
	Panel_item	item;
	int		value;
	Event		*event;
{
	delete_interface_pop_objects	*ip = (delete_interface_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
        int total_tuples, current_tuple, new_tuple;
        char new_index[100], *new_index_ptr;

        xv_set(ip->pop, FRAME_BUSY, TRUE, NULL);
        total_tuples = xv_get(ip->pop, XV_KEY_DATA, CLASS);
        current_tuple = atoi((char *) xv_get(ip->pop, FRAME_RIGHT_FOOTER));

        switch(value) {
         case 0: /* Next */
            if((total_tuples) != (current_tuple + 1)) {
             sprintf(new_index, "%d", current_tuple + 1);
             new_tuple = current_tuple + 1;
             total_tuples = tuple_fetch1((char *) xv_get(ip->pop, FRAME_LABEL), new_tuple);
            } else {
             sprintf(new_index, "%d", 0);
             new_tuple = 0;
             total_tuples = tuple_fetch1((char *) xv_get(ip->pop, FRAME_LABEL), new_tuple);
            }
            break;
         case 1: /* Re-read the current one */
            sprintf(new_index, "%d", current_tuple);
            new_tuple = current_tuple;
            total_tuples = tuple_fetch1((char *) xv_get(ip->pop, FRAME_LABEL), new_tuple);
            break;
         case 2: /* Prior */
            if(0 > (current_tuple - 1)) {
             sprintf(new_index, "%d", total_tuples - 1);
             new_tuple = total_tuples - 1;
             total_tuples = tuple_fetch1((char *) xv_get(ip->pop, FRAME_LABEL), new_tuple);
            } else {
             sprintf(new_index, "%d", current_tuple - 1);
             new_tuple = current_tuple - 1;
             total_tuples = tuple_fetch1((char *) xv_get(ip->pop, FRAME_LABEL), new_tuple);
            }            
            break;
        }
if(total_tuples) {

        xv_set(ip->tuple_slider,
              PANEL_VALUE, new_tuple,
              PANEL_MAX_VALUE, total_tuples - 1,
              NULL);
        new_index_ptr = strdup(new_index);
        xv_set(ip->pop, 
                      XV_SHOW, TRUE,  
                      FRAME_LEFT_FOOTER, "tuple", 
                      FRAME_RIGHT_FOOTER, new_index_ptr,
                      NULL);
        xv_set(ip->which_tuple_setting,
                      XV_SHOW, TRUE,
                      NULL);
} else {
                   xv_set(ip->pop, 
                      FRAME_LEFT_FOOTER, "No tuples",
                      XV_KEY_DATA, CLASS, total_tuples, 
                      FRAME_RIGHT_FOOTER, "",
                      NULL);
                   xv_set(ip->which_tuple_setting,
                      XV_SHOW, FALSE,
                      NULL);
                   xv_set(ip->tuple_message,
                      XV_SHOW, FALSE,
                      NULL);                  
                   xv_set(ip->tuple_slider,
                      XV_SHOW, FALSE,
                      NULL);
        
} 
        xv_set(ip->pop, FRAME_BUSY, FALSE, NULL);
	

}

/*
 * Notify callback function for `tuple_slider'.
 */
void
delete_tuple_easy_travel(item, value, event)
        Panel_item      item;
        int             value;
        Event           *event;
{
        delete_interface_pop_objects    *ip = (delete_interface_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
        char new_index[100], *new_index_ptr;
        int new_tuple, total_tuples;

        xv_set(ip->pop, FRAME_BUSY, TRUE, NULL);

        sprintf(new_index, "%d", value);
        new_tuple = value;
        total_tuples = tuple_fetch1((char *) xv_get(ip->pop, FRAME_LABEL), new_tuple);
if(total_tuples) {
        new_index_ptr = strdup(new_index);
        xv_set(ip->pop, 
                      XV_SHOW, TRUE,
                      XV_KEY_DATA, CLASS, total_tuples,  
                      FRAME_LEFT_FOOTER, "tuple", 
                      FRAME_RIGHT_FOOTER, new_index_ptr,
                      NULL);
        xv_set(item, PANEL_MAX_VALUE, total_tuples - 1, NULL);

} else {
                   xv_set(ip->pop, 
                      FRAME_LEFT_FOOTER, "No tuples",
                      XV_KEY_DATA, CLASS, total_tuples, 
                      FRAME_RIGHT_FOOTER, "",
                      NULL);
                   xv_set(ip->which_tuple_setting,
                      XV_SHOW, FALSE,
                      NULL);
                   xv_set(ip->tuple_message,
                      XV_SHOW, FALSE,
                      NULL);                  
                   xv_set(ip->tuple_slider,
                      XV_SHOW, FALSE,
                      NULL);
        
}         
        xv_set(ip->pop, FRAME_BUSY, FALSE, NULL);

       
}

