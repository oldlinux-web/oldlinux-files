
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <unistd.h>

#include <xview/xview.h>
#include <xview/panel.h>

/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "constants.h"
#include "load_ui.h"
#include "externs.h"


extern load_popup1_objects	*load_dialog;


/*
 * Notify callback function for `load_button'.
 */
void
load_object_file(item, event)
	Panel_item	item;
	Event		*event;
{
  first_window1_objects *ip = 
    (first_window1_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
  char pathname[256];

  getcwd( pathname, 256 );

  xv_set(load_dialog->popup1, XV_KEY_DATA, OPER, marco, NULL);
  xv_set(load_dialog->textfield1, PANEL_VALUE, pathname, NULL );
  xv_set(load_dialog->popup1, XV_SHOW, TRUE, NULL);
        
}


Panel_setting
load_file_proc(item, event)
	Panel_item	item;
	Event		*event;
{
  load_popup1_objects *ip = 
    (load_popup1_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
  char query_buffer[8196], temp_q[8196];
  Panel_item  dirname_item;
  char *fname = (char *) xv_get(item, PANEL_VALUE), *fp;
  char *dirname, *dp;
  char pathname[256];
  
  dirname_item = ip->textfield1;
  dirname = (char *) xv_get(dirname_item, PANEL_VALUE);
  for( dp = dirname + strlen( dirname ); dp >= dirname; dp-- )
    if ( *dp != ' ' )
      break;
    else
      *dp = '\0';
  strcpy( pathname, dirname );
  if ( dirname != dp && *dp != '/' )
    strcat( pathname, "/" );
  else
    pathname[0] = '\0';
  for( fp = fname + strlen( fname ); fp >= fname; fp-- )
    if ( *fp != ' ' )
      break;
    else
      *fp = '\0';
  strcat( pathname, fname );

  if ( !access( pathname, F_OK | R_OK ) ) {
    sprintf( query_buffer, "load \"%s\"", pathname );

    if ( Verbose )
      textsw_insert( first_window1->textpane3, "\n", 1 );

    if ( Verbose ) {
      textsw_insert( first_window1->textpane3,
		    "Query sent to Postgres Backend:\n", 32 );
      textsw_insert( first_window1->textpane3, query_buffer, 
		    			       strlen( query_buffer ) );
      textsw_insert( first_window1->textpane3, "\n", 1 ); 
    }

    if ( ( handle_execution(query_buffer, first_window1 ) ) == 1 )
      backend_error( "Postgres backend returned error" );
    else
      xv_set( first_window1->window1, FRAME_LEFT_FOOTER, "No errors",
	      NULL);
    bzero( query_buffer, strlen( query_buffer ) );
    xv_set(ip->popup1, XV_SHOW, FALSE, NULL);
  }
  else {
    window_bell( ip->popup1 );
    xv_set(ip->popup1, FRAME_LEFT_FOOTER, pathname, NULL);
    xv_set(ip->popup1, FRAME_RIGHT_FOOTER, "unreadable", NULL);
  }

  return panel_text_notify(item, event);
}
