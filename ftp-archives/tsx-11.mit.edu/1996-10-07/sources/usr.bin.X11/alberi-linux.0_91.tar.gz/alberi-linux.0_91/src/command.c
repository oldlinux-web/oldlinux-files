
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/textsw.h>
/*#include <xview/notice.h>
#include <xview/svrimage.h>*/
#include <xview/panel.h>

/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "externs.h"

#include "constants.h"
#include "funcs.h"


void command_log(item, event)
     Panel_item      item;
     Event          *event;
{
  first_window1_objects *ip = (first_window1_objects *)
    				xv_get(item, XV_KEY_DATA, INSTANCE);
        
  xv_set(command_log_pop->pop, XV_KEY_DATA, OPER, marco, NULL);
  xv_set(command_log_pop->pop, XV_SHOW, TRUE, NULL);
        
}

/*
 * Menu handler for `query_stack (Command 1)'.
 */
Menu_item
command_stack_print(item, op)
     Menu_item       item;
     Menu_generate   op;
{
  first_window1_objects *ip = (first_window1_objects *)
    				xv_get(item, XV_KEY_DATA, INSTANCE);
  char *entry;
  int index;
        
  switch (op) {
  case MENU_DISPLAY:
    break;

  case MENU_DISPLAY_DONE:
    break;

  case MENU_NOTIFY:
    entry = strdup((char *) xv_get(item, MENU_STRING));
    if ( !strcmp(entry, "Command 1") )
      index = 0; 
    else if ( !strcmp(entry, "Command 2") )
      index = 1;
    else if( !strcmp(entry, "Command 3") )
      index = 2;
    else if ( !strcmp(entry, "Command 4") )
      index = 3;
    else if ( !strcmp(entry, "Command 5") )
      index = 4;
    else
      abend( "command_stack_print: unknown selection" );

    print_command_stack(index);

    break;

  case MENU_NOTIFY_DONE:
    break;
  }
  return item;
}
extern char *command_stack[];


int
empty_command( cmd )
     char *cmd;
{
  for( ; *cmd == ' '; cmd++ );
  return *cmd == '\0';
}
  


void
insert_in_command_stack(command)
     char *command;
{
  int index;
  char *old, *newy;

  if ( empty_command(command) )
    return;
  newy = strdup(command);

  for( index = 0 ; index < 5 ; index++ ) {
    old = strdup( command_stack[index] );
    command_stack[index] = strdup(newy);
    newy = old;
  }
  free( old );
}

void
print_command_stack(index)
     int index;
{
  char *current;

  current = strdup( command_stack[index] ); 
  xv_set(first_window1->textpane1, TEXTSW_CONTENTS, "", NULL);
  xv_set(first_window1->textpane1, TEXTSW_CONTENTS, current, NULL); 
}


