 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/


#define EXPRESSION_TREE 9
#define EXPRESSION_HIDE 10
#define THE_ARRAY       11
#define ARRAY_ELEMENT  12
#define PARENT_NAME 13
#define TREE_EMPTY 14
#define EXPRESSION_CANVAS 15
#define NAME_SET 16
#define MENU_OWNER 17
#define TYPENAME 1
#define FUNC     101
#define OPER     100
#define CONSTANT 103
#define UNARY    102
#define TYPE 7 /* 0 is class, 1 is attribute */
#define CLASS 8 /* it contains a handle to the Rectobj class */
#define ANDOP 200
#define OROP 201
#define NOTOP 202
#define NONEOP 203
#define LEFTPAR 204
#define RIGHTPAR 205
#define INSTANCES 20
#define COMMAS 21
#define LINKS 22
