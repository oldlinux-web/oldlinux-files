
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/


#include <stdio.h>
#include <string.h>
#include <sys/param.h>
#include <sys/types.h>
#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>


#include "name_attribute_ui.h"
#include "constants.h"


/*
 * Notify callback function for `name_field'.
 */
Panel_setting
give_attribute_name_proc(item, event)
	Panel_item	item;
	Event		*event;
{
	name_attribute_pop_objects	*ip = (name_attribute_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
	char *the_name;
        int length, character, occurrence;
	Rectobj the_element, the_other;
	Rectobj_list *the_guys;
	Array_tile the_array;

	char *	value = (char *) xv_get(item, PANEL_VALUE);
        if ((length = strlen(value)) > 16) {
            xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names are 16 characters or less!!", NULL);
            xv_set(item, PANEL_VALUE, "Error", NULL);
         } else {
           if ((!isalpha(value[0]))  && (value[0] != '_'))  {
              xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names start with alphabetic or underscore", NULL);
              xv_set(item, PANEL_VALUE,"Error" , NULL);
           } else {
             for(character =  1; character < length; character++) {
                 if ((!isalnum(value[character])) && (value[character] != '_')) {
                    xv_set(ip->pop, FRAME_LEFT_FOOTER, "Names include alphanumeric and underscore", NULL);
                    xv_set(item, PANEL_VALUE, "Error ", NULL);
                    break;
                 }
             }
          }
        }
        if(strcmp(value, "Error") != 0)  {
	   the_element = (Rectobj) xv_get(ip->pop, XV_KEY_DATA, OPER);
	   the_array = (Array_tile) xv_get(the_element, XV_OWNER);
	   the_guys = (Rectobj_list *) xv_get(the_array, RECTOBJ_CHILDREN);
	   occurrence = 0;
           the_name = (char *) malloc(20*sizeof(char) + 1);
	   sprintf(the_name, "%s = ", value);
	   length = strlen(the_name);
	   list_for(the_guys) {
	     the_other = RECTOBJ_LIST_HANDLE(the_guys);
             if(!strcmp(the_name, (char *) xv_get(the_other, DRAWTEXT_STRING)))  {
		 if(occurrence) { occurrence++; } else {
                    xv_set(ip->pop, FRAME_LEFT_FOOTER, "This name is not allowed", NULL);
                    xv_set(item, PANEL_VALUE, "Error", NULL);
                    value = strdup("Error");
                 }
              }
           }
        }
        if(strcmp(value, "Error") != 0) {
	   the_name = (char *) malloc(20*sizeof(char) + 1);
           sprintf(the_name, "%s = ", value);
           xv_set((Rectobj) xv_get(ip->pop, XV_KEY_DATA, OPER),
	       DRAWTEXT_STRING, (char *) the_name,
	       NULL);
           xv_set(ip->pop, XV_SHOW, FALSE, NULL);
        }
	
        
	
	return panel_text_notify(item, event);
}

