
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "constants.h"
#include "new_attrib_type_ui.h"



/*
 * Notify callback function for `types_list'.
 */
int
type_selection(item, string, client_data, op, event)
	Panel_item	item;
	char		*string;
	Xv_opaque	client_data;
	Panel_list_op	op;
	Event		*event;
{
	new_attrib_type_pop_objects	*ip = (new_attrib_type_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
        PortalBuffer *p;
        int i, j, k, g, n, m, t, x, ic,s, count, max_array_size;
        char queryp[8192];
        char entry[8];

	
	switch(op) {
	case PANEL_LIST_OP_DESELECT:
		
		break;

	case PANEL_LIST_OP_SELECT:
                xv_set(ip->type_field, PANEL_VALUE, string, NULL);
                sprintf(queryp, "retrieve portal array_size (arr_size = ( \"8196\"::int2 / pg_type.typlen)) where pg_type.typname = \"%s\"", string);
                alberi_PQexec("begin");
                alberi_PQexec(queryp);
                      
                alberi_PQexec("fetch all in array_size");

                p = PQparray("array_size");
                g = PQngroups(p);
                t = 0;
   
                for(k = 0; k < g; k++) {
                  n = PQntuplesGroup(p, k);
                  m = PQnfieldsGroup(p, k);

                  for(i = 0; i < n; i++) {
                      sprintf(entry, "%s", PQgetvalue(p, t + i, 0));
                  }
                  t += n;
                }
                alberi_PQexec("close array_size");
                alberi_PQexec("end");
                max_array_size = atoi(entry);
                if(max_array_size > 0) {
                  xv_set(ip->array_setting, 
                         XV_SHOW, TRUE,
                         NULL);
                  xv_set(ip->array_size_slider, 
                         PANEL_MAX_VALUE, max_array_size,
                         XV_SHOW, TRUE,
                         NULL);
                  xv_set(ip->message1, XV_SHOW, TRUE, NULL);
                  xv_set(ip->message2, XV_SHOW, TRUE, NULL);
                } else {
                  xv_set(ip->message1, XV_SHOW, FALSE, NULL);
                  xv_set(ip->message2, XV_SHOW, FALSE, NULL);
                  xv_set(ip->array_setting, 
                         XV_SHOW, FALSE,
                         PANEL_VALUE, 0,
                         NULL);
                  xv_set(ip->array_size_slider, 
                         XV_SHOW, FALSE,
                         NULL);
                }
		
		break;

	case PANEL_LIST_OP_VALIDATE:
		
		break;

	case PANEL_LIST_OP_DELETE:
		
		break;
	}
	return XV_OK;
}

/*
 * Notify callback function for `array_size_slider'.
 */
void
array_size(item, value, event)
	Panel_item	item;
	int		value;
	Event		*event;
{
	new_attrib_type_pop_objects	*ip = (new_attrib_type_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
	
	
}

/*
 * Notify callback function for `type_field'.
 */
Panel_setting
type_typing(item, event)
	Panel_item	item;
	Event		*event;
{
	new_attrib_type_pop_objects	*ip = (new_attrib_type_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
        PortalBuffer *p;
        int i, j, k, g, n, m, t, x, ic,s, count, max_array_size, row, rows, bingo;
        char queryp[8192];
        char entry[8];
	char *	value = (char *) xv_get(item, PANEL_VALUE);

        bingo = 0;
        rows = (int) xv_get(ip->types_list, PANEL_LIST_NROWS);
        for(row = 0 ; row < rows; row++) {
           if(!strcmp(value, (char *) xv_get(ip->types_list, PANEL_LIST_STRING, row))) {
               xv_set(ip->types_list, PANEL_LIST_SELECT, row, TRUE, NULL);
               bingo = 1;
           }
        }
        if(!bingo) { 
           xv_set(item, PANEL_VALUE, "unknown type", NULL); 
        } else { 
           sprintf(queryp, "retrieve portal array_size (arr_size = ( \"8196\"::int2 / pg_type.typlen)) where pg_type.typname = \"%s\"", value);
           alberi_PQexec("begin");
           alberi_PQexec(queryp);
                      
           alberi_PQexec("fetch all in array_size");

           p = PQparray("array_size");
           g = PQngroups(p);
           t = 0;
   
           for(k = 0; k < g; k++) {
            n = PQntuplesGroup(p, k);
            m = PQnfieldsGroup(p, k);

            for(i = 0; i < n; i++) {
               sprintf(entry, "%s", PQgetvalue(p, t + i, 0));
            }
            t += n;
           }
           alberi_PQexec("close array_size");
           alberi_PQexec("end");
           max_array_size = atoi(entry);
           if(max_array_size > 0) {
             xv_set(ip->array_setting, 
                  XV_SHOW, TRUE,
                  NULL);
             xv_set(ip->array_size_slider, 
                  PANEL_MAX_VALUE, max_array_size,
                  XV_SHOW, TRUE,
                  NULL);
             xv_set(ip->message1, XV_SHOW, TRUE, NULL);
             xv_set(ip->message2, XV_SHOW, TRUE, NULL);
           } else {
             xv_set(ip->message1, XV_SHOW, FALSE, NULL);
             xv_set(ip->message2, XV_SHOW, FALSE, NULL);
             xv_set(ip->array_setting, 
                         XV_SHOW, FALSE,
                         PANEL_VALUE, 0,
                         NULL);
             xv_set(ip->array_size_slider, 
                         XV_SHOW, FALSE,
                         NULL);
           }

        }        
	
	return panel_text_notify(item, event);
}

/*
 * Notify callback function for `array_setting'.
 */
void
to_array_or_not_to_array(item, value, event)
	Panel_item	item;
	int		value;
	Event		*event;
{
	new_attrib_type_pop_objects	*ip = (new_attrib_type_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);

        if(value) {
          xv_set(ip->array_size_slider, XV_SHOW, TRUE, NULL);
        } else {
          xv_set(ip->array_size_slider, XV_SHOW, FALSE, NULL);
        }
	
}

/*
 * Notify callback function for `Done_button'.
 */
void
assign_type(item, event)
	Panel_item	item;
	Event		*event;
{
	new_attrib_type_pop_objects	*ip = (new_attrib_type_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
        Rectobj the_attribute;
        int bingo, size, row, rows;
        char *typename;

        the_attribute = (Rectobj) xv_get(ip->pop, XV_KEY_DATA, OPER);
        bingo = 0;
        rows = (int) xv_get(ip->types_list, PANEL_LIST_NROWS);
        for(row = 0 ; row < rows ; row++) {
           if((Bool) xv_get(ip->types_list, PANEL_LIST_SELECTED, row)) {
              typename = strdup((char *) xv_get(ip->types_list, PANEL_LIST_STRING, row));
              xv_set(the_attribute, XV_KEY_DATA, TYPENAME, typename, NULL);
              bingo = 1;
           }
	}
        if(!bingo) xv_set(ip->pop, FRAME_LEFT_FOOTER, "No type chosen, please select one ...", NULL);
        else {
            if((int) xv_get(ip->array_setting, PANEL_VALUE)) {
                size = (int) xv_get(ip->array_size_slider, PANEL_VALUE);
                xv_set(the_attribute, 
                       XV_KEY_DATA, THE_ARRAY, size,
                       NULL);
            } else xv_set(the_attribute, XV_KEY_DATA, THE_ARRAY, -1, NULL);
           
            xv_set(ip->pop, FRAME_CMD_PUSHPIN_IN, FALSE, NULL);
            xv_set(ip->pop, XV_SHOW, FALSE, NULL);
        }

}

