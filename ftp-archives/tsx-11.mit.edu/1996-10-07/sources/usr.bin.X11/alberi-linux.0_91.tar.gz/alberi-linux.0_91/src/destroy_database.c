
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>
#include <xview/notice.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "destroy_database_ui.h"
#include "constants.h"


/*
 * Notify callback function for `textfield1'.
 */
Panel_setting
destroy_database_notify(item, event)
     Panel_item	 item;
     Event	*event;
{
  destroy_database_pop_objects *ip = 
    (destroy_database_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
  char 	       *value = (char *) xv_get(item, PANEL_VALUE);
  int   	exists, length, character, ans;
  PortalBuffer *p;
  int 		i, j, k, g, n, m, t, x, s;
  char 	       *database_name, create_ahead[32];
  char		msg[80];
	
  exists = 0;
  alberi_PQexec("begin");
  alberi_PQexec("retrieve portal schema (pg_database.datname)");
  alberi_PQexec("fetch all in schema");

  p = PQparray("schema");
  g = PQngroups(p);
  t = 0;

  for ( k = 0; k < g; k++ ) {
    n = PQntuplesGroup(p, k);
    m = PQnfieldsGroup(p, k);
    for ( i = 0; i < n; i++ ) {    
      database_name = strdup( PQgetvalue(p, t + i, 0));
      if ( !strcmp( value, database_name ) )
	exists = 1;
    }
    t += n;
  }
  alberi_PQexec("close schema");
  alberi_PQexec("end");
  if ( !exists ) {
    window_bell( ip->pop );
    xv_set(ip->pop, FRAME_LEFT_FOOTER, value, NULL);
    xv_set(ip->pop, FRAME_RIGHT_FOOTER, "does not exist", NULL);
    value = strdup("Error");
  }
  else {
    strcpy( msg, "Destroy database " );
    strcat( msg, value );
    strcat( msg, "?" );
    ans = notice_prompt( ip->pop, NULL,
			 NOTICE_MESSAGE_STRINGS, msg, NULL,
			 NOTICE_BUTTON_YES, "No",
			 NOTICE_BUTTON_NO, "Yes",
			 NULL );
    if ( ans != NOTICE_YES ) {
      strcpy(create_ahead ,"destroydb "); 
      strcat(create_ahead, value);
      if ( system( create_ahead ) ) {
	window_bell( ip->pop );
	xv_set(ip->pop, FRAME_LEFT_FOOTER, "Could not destroy", NULL);
      }
      else {
	xv_set(ip->pop, FRAME_LEFT_FOOTER, "", NULL);
	xv_set(ip->pop, FRAME_RIGHT_FOOTER, "", NULL);
	xv_set(ip->pop, XV_SHOW, FALSE, NULL);
      }
    }
  }

  return panel_text_notify(item, event);
}

