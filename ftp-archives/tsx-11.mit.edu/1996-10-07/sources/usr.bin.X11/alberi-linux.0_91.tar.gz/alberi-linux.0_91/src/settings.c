
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>

/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "externs.h"

#include "constants.h"
#include "grays.h"
#include "funcs.h"
#include "fontset_ui.h"
#include "displayset_ui.h"
#include "hostset_ui.h"

extern fontset_popup1_objects	*fontset_dialog;
extern displayset_popup_objects	*displayset_dialog;
extern hostset_popup1_objects	*hostset_dialog;


extern char *dbname;
extern char *version;

Xv_opaque family_panel, style_panel, scale_panel;

void
font_settings(item, event)
     Panel_item      item;
     Event          *event;
{
  first_window1_objects *ip = (first_window1_objects *)
    				xv_get(item, XV_KEY_DATA, INSTANCE);
  Panel_item      family_item, style_item, scale_item;

  xv_set(fontset_dialog->popup1, XV_KEY_DATA, OPER, marco, NULL);
  xv_set(fontset_dialog->popup1, XV_SHOW, TRUE, NULL);
  family_item = fontset_dialog->font_family_setting;
  style_item = fontset_dialog->font_style_setting;
  scale_item = fontset_dialog->font_scale_setting;
  family_panel = xv_get(family_item, PANEL_VALUE);
  style_panel = xv_get(style_item, PANEL_VALUE);
  scale_panel = xv_get(scale_item, PANEL_VALUE);

        
}

void
pref_settings(item, event)
     Panel_item      item;
     Event          *event;
{
  first_window1_objects *ip = (first_window1_objects *)
    				xv_get(item, XV_KEY_DATA, INSTANCE);

  xv_set(displayset_dialog->popup, XV_KEY_DATA, OPER, marco, NULL);
  xv_set(displayset_dialog->popup, XV_SHOW, TRUE, NULL);
        
}

void
host_selection(item, event)
     Panel_item      item;
     Event          *event;
{
  first_window1_objects *ip = (first_window1_objects *)
    				xv_get(item, XV_KEY_DATA, INSTANCE);

  xv_set(hostset_dialog->popup1, XV_KEY_DATA, OPER, marco, NULL);
  xv_set(hostset_dialog->popup1, XV_SHOW, TRUE, NULL);
        
}



/*
 * Notify callback function for `textfield2'.
 */
Panel_setting
host_name(item, event)
     Panel_item	item;
     Event		*event;
{
  hostset_popup1_objects *ip = 
    (hostset_popup1_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
  char title[100], *label;
  char *value = (char *) xv_get(item, PANEL_VALUE);

  strcpy(PQhost, value);
  sprintf(title, "Postgres GLI Alberi [%s]\t Database -> %s on host -> %s", 
	  	 version, dbname, PQhost);
  label = strdup(title);
  xv_set(first_window1->window1, FRAME_LABEL, label, NULL);
  xv_set(ip->popup1, XV_SHOW, FALSE, NULL);

  return panel_text_notify(item, event);
}

/*
 * Notify callback function for `setting1'.
 */
void
settings_proc(item, value, event)
     Panel_item	item;
     int		value;
     Event		*event;
{
  displayset_popup_objects *ip = 
    (displayset_popup_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);

  TerseOutput   = (bool) (1 & value);
  PrintAttNames = (bool) !(2 & value);
  Verbose       = (bool) !(4 & value);
  Silent        = (bool) (8 & value);
	 
}


/*
 * Notify callback function for `setting2'.
 */
void
catalog_settings_proc(item, value, event)
     Panel_item	item;
     int	value;
     Event      *event;
{
  displayset_popup_objects *ip = 
    (displayset_popup_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);

  CatalogClasses = (bool) (1 & value);
  CatalogClassesOnly = (bool) (2 & value);

}
