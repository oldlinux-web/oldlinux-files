 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/


#include "first_ui.h"
#include "operator_select_ui.h"
#include "funct_select_ui.h"
#include "unary_select_ui.h"
#include "name_attribute_ui.h"
#include "constant_select_ui.h"
#include "name_instance_ui.h"
#include "new_attrib_type_ui.h"
#include "name_new_class_ui.h"
#include "retrieve_into_classname_ui.h"
#include "append_class_ui.h"
#include "delete_replace_instances_ui.h"
#include "delete_instances_ui.h"
#include "database_select_ui.h"
#include "append_interface_ui.h"
#include "classic_append_class_ui.h"
#include "replace_interface_ui.h"
#include "classic_replace_class_ui.h"
#include "delete_interface_ui.h"
#include "classic_delete_class_ui.h"
#include "rename_interface_ui.h"
#include "create_database_ui.h"
#include "destroy_database_ui.h"
#include "command_log_ui.h"

