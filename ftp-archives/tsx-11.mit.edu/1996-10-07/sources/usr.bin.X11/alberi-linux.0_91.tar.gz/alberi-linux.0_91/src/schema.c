 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/


#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/cursor.h>

/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "externs.h"

#include "constants.h"
#include "grays.h"
#include "funcs.h"




extern char      *dbname;
extern Xv_cursor  cursor;
Panel_item        attribute_info;



/*
 * Notify callback function for `schema_button1'.
 */
void
schema_br_proc(item, event)
     Panel_item	item;
     Event *event;
{
  first_window1_objects	*ip = 
    (first_window1_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);

  update_schema();
                         
}


void 
update_schema()
{
  PortalBuffer *p;
  int i, j, k, g, n, m, t, x, s;
  char *num_attr, this_title[256], *class_name;
  Menu temp_menu;
  Rectobj class;        



  xv_set(marco, XV_SHOW, TRUE, NULL);
  xv_set(marco, FRAME_BUSY, TRUE, NULL);
  xv_set(shell1, CANVAS_SHELL_DELAY_REPAINT, TRUE, NULL);
        
                 
  xv_set(attribute_info, PANEL_LABEL_STRING, "Attributes", NULL);
  while(xv_get(classes, ARRAY_TILE_POSITION, 0, 0)) {
    xv_set(classes, ARRAY_TILE_AUTO_LAYOUT, FALSE, NULL);
    temp_menu = (Menu)
      xv_get((Rectobj) xv_get(classes,
			      ARRAY_TILE_POSITION, 0, 0), 
	     RECTOBJ_MENU); 
    xv_destroy((Rectobj) xv_get(classes, ARRAY_TILE_POSITION, 0, 0));
    if(temp_menu) xv_destroy(temp_menu);
    xv_set(classes, ARRAY_TILE_AUTO_LAYOUT, TRUE, NULL);
  }
  while (xv_get(attributes, ARRAY_TILE_POSITION, 0, 0)) {
    xv_set(attributes, ARRAY_TILE_AUTO_LAYOUT, FALSE, NULL);
    xv_destroy((Drawicon) xv_get(attributes, 
				 ARRAY_TILE_POSITION, 0, 0));
    xv_set(attributes, ARRAY_TILE_AUTO_LAYOUT, TRUE, NULL);
  }
  while (xv_get(parents, ARRAY_TILE_POSITION, 0, 0)) {
    xv_set(parents, ARRAY_TILE_AUTO_LAYOUT, FALSE, NULL); 
    xv_destroy((Drawicon) xv_get(parents, 
				 ARRAY_TILE_POSITION, 0, 0));
    xv_set(parents, ARRAY_TILE_AUTO_LAYOUT, TRUE, NULL);
  }
  while (xv_get(children, ARRAY_TILE_POSITION, 0, 0)) {
    xv_set(children, ARRAY_TILE_AUTO_LAYOUT, FALSE, NULL);
    xv_destroy((Drawicon) xv_get(children, 
				 ARRAY_TILE_POSITION, 0, 0));
    xv_set(children, ARRAY_TILE_AUTO_LAYOUT, TRUE, NULL);
  }

      
  if (Debugging)
    PQtracep = 0;


  alberi_PQexec("begin");

  if ( !CatalogClasses && !CatalogClassesOnly ) /* user classes only */
    alberi_PQexec(

"retrieve portal schema (pg_class.relname, pg_class.relnatts) \
where pg_class.relname !~ \"pg_.*\""

			);
  else if ( CatalogClassesOnly ) /* catalog classes only */
    alberi_PQexec(

"retrieve portal schema (pg_class.relname, pg_class.relnatts) \
where pg_class.relname ~ \"pg_.*\""

		  );
  else				/* all classes */
    alberi_PQexec(

"retrieve portal schema (pg_class.relname, pg_class.relnatts)"

		  );


  alberi_PQexec("fetch all in schema");

  p = PQparray("schema");
  g = PQngroups(p);
  t = 0;

  for(k = 0; k < g; k++) {
    n = PQntuplesGroup(p, k);
    m = PQnfieldsGroup(p, k);                               
    for(i = 0; i < n; i++) {
                                    
      num_attr = strdup(PQgetvalue(p, t + i, 1));
                                     
      class_name = strdup( PQgetvalue(p, t + i, 0));
      class = (Drawicon) xv_create(classes, DRAWICON, 
				   DRAWIMAGE_SVRIMAGE, gray[0], 
				   DRAWTEXT_STRING, class_name, 
				   RECTOBJ_DBL_CLICK_PROC, 
				     class_info_proc,
				   RECTOBJ_DRAGGABLE, TRUE,
				   RECTOBJ_DRAG_CURSOR, cursor,
				   XV_KEY_DATA, 1, 1, 
				   XV_KEY_DATA, 2, num_attr,
				   XV_KEY_DATA_REMOVE_PROC, 
				     2, free_string, 
				   XV_KEY_DATA, TYPE, 0, 
				   XV_KEY_DATA, INSTANCES, 0,
				   NULL);
      temp_menu = (Menu) xv_create(XV_NULL, MENU,
				   MENU_TITLE_ITEM, "Class menu",
				   MENU_ACTION_ITEM,
				     "Show attributes", 
				     show_attributes_proc,
				   MENU_ACTION_ITEM, 
				     "Add attributes ", 
				     add_attributes_proc,
				   MENU_ACTION_ITEM, 
				     "Rename the class", 
				     rename_class_proc,
				   MENU_ACTION_ITEM, 
				     "Destroy the class", 
				     nuke_that_class_proc,
				   XV_KEY_DATA, MENU_OWNER, class,
				   NULL);
      xv_set(class, RECTOBJ_MENU, temp_menu, NULL);
      window_fit(marco);
				 
    }
    t += n;
  }

  sprintf(this_title, "Database -> \"%.16s\" :: %d classes", dbname, n); 

  xv_set(marco, FRAME_LABEL, this_title, NULL);
  alberi_PQexec("close schema");
  alberi_PQexec("end");

  if (Debugging) 
    PQtracep = 1;
                         
  xv_set(shell1, 
	 CANVAS_MIN_PAINT_WIDTH, xv_get(classes, XV_WIDTH) + 10,
	 CANVAS_MIN_PAINT_HEIGHT, xv_get(classes, XV_HEIGHT) + 10,
	 NULL);
                         
  xv_set(shell1, CANVAS_SHELL_DELAY_REPAINT, FALSE, NULL);
  xv_set(marco, FRAME_BUSY, FALSE, NULL);
}

void
class_info_proc(paint_window, event, canvas_shell, rectobj)
     Xv_window paint_window;
     Event *event;
     Canvas_shell canvas_shell;
     Rectobj rectobj;

{

  class_information(rectobj);

}

void
class_information(rectobj)
     Rectobj rectobj;
{
  PortalBuffer   *p;
  int             i, j, k, g, n, m, t, x, ic, s;
  char            queryp[8192];
  char           *string, *title, *parent_name;
  char           *type_name, *element_type, *parent_num_attr,
  		 *child_num_attr, *generic_char, *icon_label;
  char           *title_fmt = "<Class \"%s\" has %s attributes (plus 'oid')>";
  char           *class_name_str, *num_attrs_str;
  char		 *next_class_name;


  class_name_str = strdup((char *) xv_get((Rectobj) xv_get(rectobj,
							   DRAWICON_TEXT),
					  DRAWTEXT_STRING));
  num_attrs_str = strdup((char *) xv_get(rectobj, XV_KEY_DATA, 2));

  title = (char *) malloc((strlen(title_fmt)-4) +
			  strlen(class_name_str) +
			  strlen(num_attrs_str) + 1);

  sprintf(title, title_fmt, class_name_str, num_attrs_str);
  xv_set(attribute_info, PANEL_LABEL_STRING, title, NULL);
  xv_set(marco, FRAME_LEFT_FOOTER,
	 	"Double click on the attribute icon to display type...",
	 	FRAME_RIGHT_FOOTER, "", NULL);

  sprintf(queryp, 

"retrieve portal schema \
(attribute=a.attname,types=t.typname, t.typtype, t.typelem, classes=r.relname) \
from a in pg_attribute, t in pg_type, r in pg_class \
where a.attrelid = r.oid \
      and a.atttypid = t.oid \
      and a.attnum > 0 \
      and  r.relname =  \"%s\"",

          class_name_str);

  if (Debugging) 
    PQtracep = 0;

  alberi_PQexec("begin");
  alberi_PQexec(queryp);

  alberi_PQexec("fetch all in schema");

	
  xv_set(marco, FRAME_BUSY, TRUE, NULL);
  xv_set(attribute_shell, CANVAS_SHELL_DELAY_REPAINT, TRUE, NULL);
  xv_set(parents_shell, CANVAS_SHELL_DELAY_REPAINT, TRUE, NULL);
  xv_set(children_shell, CANVAS_SHELL_DELAY_REPAINT, TRUE, NULL);

  while (xv_get(attributes, ARRAY_TILE_POSITION, 0, 0)) {
    xv_set(attributes, ARRAY_TILE_AUTO_LAYOUT, FALSE, NULL);
    xv_destroy((Drawicon) xv_get(attributes, ARRAY_TILE_POSITION, 0, 0));
    xv_set(attributes, ARRAY_TILE_AUTO_LAYOUT, TRUE, NULL);
  }
  while (xv_get(parents, ARRAY_TILE_POSITION, 0, 0)) {
    xv_set(parents, ARRAY_TILE_AUTO_LAYOUT, FALSE, NULL); 
    xv_destroy((Drawicon) xv_get(parents, ARRAY_TILE_POSITION, 0, 0));
    xv_set(parents, ARRAY_TILE_AUTO_LAYOUT, TRUE, NULL);
  }
  while (xv_get(children, ARRAY_TILE_POSITION, 0, 0)) {
    xv_set(children, ARRAY_TILE_AUTO_LAYOUT, FALSE, NULL);
    xv_destroy((Drawicon) xv_get(children, ARRAY_TILE_POSITION, 0, 0));
    xv_set(children, ARRAY_TILE_AUTO_LAYOUT, TRUE, NULL);
  }

  p = PQparray("schema");
  g = PQngroups(p);
  t = 0;

  for (k = 0; k < g; k++) {

    n = PQntuplesGroup(p, k);
    m = PQnfieldsGroup(p, k);

    for(i = 0; i < n; i++) {
                                                         
      if (strcmp(PQgetvalue(p, t+i, 2), "t") == 0) ic = 1;
      if (strcmp(PQgetvalue(p, t+i, 2), "c") == 0) ic = 0;
      
                                                             
      type_name = strdup(PQgetvalue(p, t + i, 1));
	   
      element_type = strdup(PQgetvalue(p, t + i, 3));
           
      icon_label = strdup(PQgetvalue(p, t + i, 0));

      parent_name = strdup(class_name_str);
      next_class_name = strdup(class_name_str);

      xv_create(attributes, DRAWICON, DRAWIMAGE_SVRIMAGE, gray[ic], 
		DRAWTEXT_STRING, icon_label,
		RECTOBJ_DBL_CLICK_PROC, attribute_check_proc, 
		RECTOBJ_DRAGGABLE, TRUE,
		RECTOBJ_DRAG_CURSOR, cursor,
		XV_KEY_DATA, 0, ic, 
		XV_KEY_DATA, 1, type_name,
		XV_KEY_DATA_REMOVE_PROC, 1, free_string, 
		XV_KEY_DATA, 2, element_type,
		XV_KEY_DATA_REMOVE_PROC, 2, free_string,
		XV_KEY_DATA, 3, i, 
		XV_KEY_DATA, TYPE, 1,
		XV_KEY_DATA, CLASS, next_class_name,
		XV_KEY_DATA_REMOVE_PROC, CLASS, free_string,
		XV_KEY_DATA, PARENT_NAME, parent_name,
		XV_KEY_DATA_REMOVE_PROC, PARENT_NAME, free_string,
		NULL);
      window_fit(attribute_shell);
             
            
    }
    t += n;
  }
  alberi_PQexec("close schema");
  alberi_PQexec("end");


  sprintf(queryp, 

"retrieve portal schema \
(class=clase.relname, parent=padre.relname, padre.relnatts) \
from clase, padre in pg_class, hereda in pg_inherits \
where hereda.inhrel = clase.oid \
      and hereda.inhparent = padre.oid \
      and clase.relname =  \"%s\"", 

	class_name_str);

  alberi_PQexec("begin");
  alberi_PQexec(queryp);
                      
  alberi_PQexec("fetch all in schema");
                             

  p = PQparray("schema");
  g = PQngroups(p);
  t = 0;

  for( k = 0; k < g; k++ ) {
  
    n = PQntuplesGroup(p, k);
    m = PQnfieldsGroup(p, k);

    for(i = 0; i < n; i++) {
    
      parent_num_attr = strdup(PQgetvalue(p, t + i, 2));
   
      icon_label = strdup( PQgetvalue(p, t + i, 1));
      xv_create(parents, DRAWICON, DRAWIMAGE_SVRIMAGE, gray[0],
		DRAWTEXT_STRING, icon_label,
		RECTOBJ_DBL_CLICK_PROC, class_info_proc,
		RECTOBJ_DRAGGABLE, TRUE,
		RECTOBJ_DRAG_CURSOR, cursor,
		XV_KEY_DATA, 0, 0, 
		XV_KEY_DATA, 1, 1, 
		XV_KEY_DATA, 2, parent_num_attr, 
		XV_KEY_DATA_REMOVE_PROC, 2, free_string,
		XV_KEY_DATA, TYPE, 0,
		/*XV_KEY_DATA_REMOVE_PROC, free_string, */ 
		NULL);

      window_fit(parents_shell);
      
    }
    t += n;
    if ( n == 0 ) {  
      xv_create(parents, DRAWTEXT, DRAWTEXT_STRING, "None", NULL); 
      window_fit(parents_shell);  
    
    } 
  }
  alberi_PQexec("close schema");
  alberi_PQexec("end");

  sprintf(queryp, 

"retrieve portal schema \
(class=clase.relname, child=hijo.relname, hijo.relnatts) \
from  clase, hijo in pg_class, hereda in pg_inherits \
where hereda.inhparent = clase.oid \
      and hereda.inhrel = hijo.oid \
      and clase.relname =  \"%s\"", 
	  class_name_str);

  alberi_PQexec("begin");
  alberi_PQexec(queryp);
                      
  alberi_PQexec("fetch all in schema");
                             
                             
  p = PQparray("schema");
  g = PQngroups(p);
  t = 0;

  for(k = 0; k < g; k++) {
    
    n = PQntuplesGroup(p, k);
    m = PQnfieldsGroup(p, k);
                                    
    for(i = 0; i < n; i++) {
       
      child_num_attr = strdup(PQgetvalue(p, t + i, 2));

      icon_label = strdup(PQgetvalue(p, t + i, 1));
      xv_create(children, DRAWICON, DRAWIMAGE_SVRIMAGE, gray[0],
		DRAWTEXT_STRING, icon_label,
		RECTOBJ_DBL_CLICK_PROC, class_info_proc,
		RECTOBJ_DRAGGABLE, TRUE,
		RECTOBJ_DRAG_CURSOR, cursor,
		XV_KEY_DATA, 0, 0,
		XV_KEY_DATA, 1, 1, 
		XV_KEY_DATA, 2, child_num_attr, 
		XV_KEY_DATA_REMOVE_PROC, 2, free_string,
		XV_KEY_DATA, TYPE, 0,
		/* XV_KEY_DATA_REMOVE_PROC, free_string, */
		NULL);
                                                          
      window_fit(children_shell);
         
    }
    t += n;
    if ( n == 0 ) {
      xv_create(children, DRAWTEXT, 
		DRAWTEXT_STRING, "None",
		XV_KEY_DATA, 0, 0, 
		NULL);  
                                                        
      window_fit(children_shell);  
      
    } 
  }
  alberi_PQexec("close schema");
  alberi_PQexec("end");

  if ( Debugging ) 
    PQtracep = 1;

  xv_set(marco, FRAME_BUSY, FALSE, NULL);
  xv_set(attribute_shell, CANVAS_SHELL_DELAY_REPAINT, FALSE, NULL);
  xv_set(parents_shell, CANVAS_SHELL_DELAY_REPAINT, FALSE, NULL);
  xv_set(children_shell, CANVAS_SHELL_DELAY_REPAINT, FALSE, NULL);

  free( class_name_str );

}

void
attribute_check_proc( paint_window, event, canvas_shell, rectobj )
     Xv_window paint_window;
     Event *event;
     Canvas_shell canvas_shell;
     Rectobj rectobj;

{
  char query[8196], footer[120], *elemen, *temp, *typename;
  PortalBuffer *p;
  int i, j, k, g, n, m, t, x, array_size;

  if ( Debugging )
    PQtracep = 0;

  typename = strdup((char *) xv_get(rectobj, XV_KEY_DATA, 1));
  if ( strstr(typename, "_") )
    temp = strdup(strstr(typename, "_"));
  else
    temp = strdup("no arrays");

  if ( !strcmp(typename, temp) ) {

    sprintf(query,

"retrieve portal array \
 (basetype.typname, size = atributo.attnelems) \
 from tipo, basetype in pg_type, atributo in pg_attribute \
 where tipo.typname = \"%s\" \
       and atributo.attname = \"%s\" \
       and (atributo.attrelid = pg_class.oid \
            and pg_class.relname = \"%s\") \
       and atributo.atttypid = tipo.oid \
       and basetype.oid = tipo.typelem",

	    typename,
	    (char *) xv_get(rectobj, DRAWTEXT_STRING),
	    (char *) xv_get(rectobj, XV_KEY_DATA, CLASS));


    alberi_PQexec("begin");
    alberi_PQexec(query);
                      
    alberi_PQexec("fetch all in array");

    p = PQparray("array");
    g = PQngroups(p);
    t = 0;
    for(k = 0; k < g; k++) {
	   
      n = PQntuplesGroup(p, k);
      m = PQnfieldsGroup(p, k);
      for( i = 0; i < n; i++ ) {
	for( j = 0; j < m; j++ )  {
	  elemen = strdup( PQgetvalue(p, t + i, j) );
	  xv_set(rectobj, XV_KEY_DATA, 4 + j, elemen,
		 XV_KEY_DATA_REMOVE_PROC, 4 + j, free_string, 
		 NULL);
	} 
                                  
      }
      t += n;
     
    }
    alberi_PQexec("close array");
    alberi_PQexec("end");

    if ( n ) {
      sprintf(footer, "<Attribute \"%s\", type:  %s = %s[%s]>", 
	      (char *) xv_get(rectobj, DRAWTEXT_STRING), 
	      (char *) xv_get(rectobj, XV_KEY_DATA, 1),
	      (char *) xv_get(rectobj, XV_KEY_DATA, 4), 
	      (char *) xv_get(rectobj, XV_KEY_DATA, 5)); 
      xv_set((Xv_window) xv_get(canvas_shell, XV_OWNER),
	     FRAME_LEFT_FOOTER, footer, 
	     FRAME_RIGHT_FOOTER, "Array", 
	     NULL);
      if ( (int) xv_get(rectobj, XV_KEY_DATA, 0) == 0 ) { 
	xv_set((Xv_window) xv_get(canvas_shell, XV_OWNER), 
	       FRAME_RIGHT_FOOTER, "Class Array", 
	       NULL); 
      }
    }
    else {
      sprintf( footer, "<Attribute \"%s\",  type: %s>", 
	      (char *) xv_get(rectobj, DRAWTEXT_STRING), 
	      (char *) xv_get(rectobj, XV_KEY_DATA, 1) );
      xv_set((Xv_window) xv_get(canvas_shell, XV_OWNER), 
	     FRAME_LEFT_FOOTER, footer, 
	     FRAME_RIGHT_FOOTER, "", 
	     NULL);
      if ( (int) xv_get(rectobj, XV_KEY_DATA, 0) == 0 ) { 
	xv_set((Xv_window) xv_get(canvas_shell, XV_OWNER), 
	       FRAME_RIGHT_FOOTER, "Class", 
	       NULL); 
      }
    }

  }
  else {
    if ( strcmp( "-1", (char *) xv_get(rectobj, XV_KEY_DATA, 2) )
	 || strcmp( "0", (char *) xv_get(rectobj, XV_KEY_DATA, 2) ) ) {
      sprintf(query,

"retrieve portal array \
(tipo.typname, size = pg_type.typlen \/ tipo.typlen) \
from tipo in pg_type \
where tipo.oid = \"%s\"::oid \
      and pg_type.typname = \"%s\"" , 

              (char *) xv_get(rectobj, XV_KEY_DATA, 2),
              (char *) xv_get(rectobj, XV_KEY_DATA, 1));


      alberi_PQexec("begin");
      alberi_PQexec(query);
                      
      alberi_PQexec("fetch all in array");

      p = PQparray("array");
      g = PQngroups(p);
      t = 0;
      for( k = 0; k < g; k++ ) {
	
	n = PQntuplesGroup(p, k);
	m = PQnfieldsGroup(p, k);
	for( i = 0; i < n; i++ ) {
	  for( j = 0; j < m; j++ )  {
	    elemen = strdup(PQgetvalue(p, t + i, j));
	    xv_set( rectobj, XV_KEY_DATA, 4 + j, elemen,
		    XV_KEY_DATA_REMOVE_PROC, 4 + j, free_string, 
		    NULL);
	  } 
	  
	}
	t += n;
      }

      alberi_PQexec("close array");
      alberi_PQexec("end");

      if ( n ) {
	sprintf(footer, "<Attribute \"%s\", type:  %s = %s[%s]>", 
		(char *) xv_get(rectobj, DRAWTEXT_STRING), 
		(char *) xv_get(rectobj, XV_KEY_DATA, 1),
		(char *) xv_get(rectobj, XV_KEY_DATA, 4), 
		(char *) xv_get(rectobj, XV_KEY_DATA, 5)); 
	xv_set((Xv_window) xv_get(canvas_shell, XV_OWNER),
	       FRAME_LEFT_FOOTER, footer, 
	       FRAME_RIGHT_FOOTER, "Array", 
	       NULL);
	if ( (int) xv_get(rectobj, XV_KEY_DATA, 0) == 0 ) { 
	  xv_set((Xv_window) xv_get(canvas_shell, XV_OWNER), 
		 FRAME_RIGHT_FOOTER, "Class Array", 
		 NULL); 
	}
      }
      else {
	sprintf(footer, "<Attribute \"%s\",  type: %s>", 
		(char *) xv_get(rectobj, DRAWTEXT_STRING), 
		(char *) xv_get(rectobj, XV_KEY_DATA, 1));
	xv_set((Xv_window) xv_get(canvas_shell, XV_OWNER), 
	       FRAME_LEFT_FOOTER, footer, 
	       FRAME_RIGHT_FOOTER, "", 
	       NULL);
	if ( (int) xv_get(rectobj, XV_KEY_DATA, 0) == 0 ) { 
	  xv_set((Xv_window) xv_get(canvas_shell, XV_OWNER), 
		 FRAME_RIGHT_FOOTER, "Class", 
		 NULL); 
	}
      }
    }
    else {
      if ( !strcmp("-1", (char *) xv_get(rectobj, XV_KEY_DATA, 2)) ) {
	sprintf(footer, "<Attribute \"%s\" type:  %s = %s[]>", 
		(char *) xv_get(rectobj, DRAWTEXT_STRING), 
		(char *) xv_get(rectobj, XV_KEY_DATA, 1),
		(char *) xv_get(rectobj, XV_KEY_DATA, 4));
	xv_set((Xv_window) xv_get(canvas_shell, XV_OWNER), 
	       FRAME_LEFT_FOOTER, footer, 
	       FRAME_RIGHT_FOOTER, "Variable Array",
	       NULL);
	if ( (int) xv_get(rectobj, XV_KEY_DATA, 0) == 0 ) { 
	  xv_set((Xv_window) xv_get(canvas_shell, XV_OWNER), 
		 FRAME_RIGHT_FOOTER, "Variable Class Array", 
		 NULL); 
	}
      }
      else {
	sprintf(footer, "<Attribute \"%s\" type:  %s>",  
		(char *) xv_get(rectobj, DRAWTEXT_STRING), 
		(char *) xv_get(rectobj, XV_KEY_DATA, 1));                    
	xv_set((Xv_window) xv_get(canvas_shell, XV_OWNER), 
	       FRAME_LEFT_FOOTER, footer, 
	       FRAME_RIGHT_FOOTER, "", 
	       NULL);
	if ( (int) xv_get(rectobj, XV_KEY_DATA, 0) == 0 ) { 
	  xv_set((Xv_window) xv_get(canvas_shell, XV_OWNER), 
		 FRAME_RIGHT_FOOTER, "Class", 
		 NULL); 
	}
      }
    }
  }
  if ( Debugging )
    PQtracep = 1;
}


void
show_attributes_proc(menu, menu_item)
     Menu menu;
     Menu_item menu_item; 
{
  Rectobj class;
  
  class = (Rectobj) xv_get(menu, XV_KEY_DATA, MENU_OWNER);

  class_information(class);

}

