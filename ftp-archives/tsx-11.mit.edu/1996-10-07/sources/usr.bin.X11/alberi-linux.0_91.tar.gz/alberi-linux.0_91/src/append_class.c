
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/


#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "append_class_ui.h"
#include "constants.h"



extern int PQtracep;
extern bool Debugging;
extern Server_image gray2, gray4;
extern void free_string(),  adding_stuff_to_the_expression_tree(), 
	    show_hide_expression_tree(),	
            assign_constant_proc(), delete_array_elem_proc(), 
	    name_retrieve_attr_proc(), 
            delete_leaf_proc(), add_unary_opr_proc(), recursive_delete();

/*
 * Notify callback function for `class_list'.
 */
int
class_proc(item, string, client_data, op, event)
	Panel_item	item;
	char		*string;
	Xv_opaque	client_data;
	Panel_list_op	op;
	Event		*event;
{
	append_class_pop_objects	*ip = (append_class_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
        Canvas_shell the_shell;
        char *footer, temp[32], *type_name, *element_type, *icon_label;
        Frame the_frame;
        Array_tile attrib_array;
        Tree tree;
        Rectobj attribute, constant, the_new_leaf;
        Menu array_elem_menu, the_menu;
        PortalBuffer   *p;
        int             i, j, k, g, n, m, t, x, ic, s;
        char            queryp[8192];
        char            type[2];
        char           *string2, *title, *parent_name;

	
        
	switch(op) {
	case PANEL_LIST_OP_DESELECT:
	
		break;

	case PANEL_LIST_OP_SELECT:
                the_shell = (Canvas_shell) xv_get(ip->pop, XV_KEY_DATA, OPER);
                the_frame = (Frame) xv_get(the_shell, XV_OWNER);
                xv_set(the_shell, RECTOBJ_ACCEPTS_DROP, FALSE, NULL);
                attrib_array = (Array_tile) xv_get(the_shell, XV_KEY_DATA, THE_ARRAY);
                xv_set(the_frame, FRAME_BUSY, TRUE, NULL);
                if(Debugging) PQtracep = 0;
                /* get the attributes and construct the array and expression tree related */
                sprintf(queryp, "retrieve portal schema (classes=r.relname,attribute=a.attname,types=t.typname, t.typtype, t.typelem) from a in pg_attribute, t in pg_type, r in pg_class where a.attrelid = r.oid  and a.atttypid = t.oid and (a.attnum > 0 \/* or a.attnum = -3 *\/) and  r.relname =  \"%s\"", string);
                alberi_PQexec("begin");
                alberi_PQexec(queryp);

                alberi_PQexec("fetch all in schema");

                p = PQparray("schema");
                g = PQngroups(p);
                t = 0;

	        while (xv_get(attrib_array, ARRAY_TILE_POSITION, 0, 0)) {
                  xv_set(attrib_array, ARRAY_TILE_AUTO_LAYOUT, FALSE, NULL);
                  recursive_delete((Tree) xv_get((Rectobj) xv_get(attrib_array, ARRAY_TILE_POSITION, 0, 0), XV_KEY_DATA, EXPRESSION_TREE), 
                                   (Tree) xv_get((Rectobj) xv_get(attrib_array, ARRAY_TILE_POSITION, 0, 0), XV_KEY_DATA, EXPRESSION_TREE));
		  xv_destroy((Drawicon) xv_get(attrib_array, ARRAY_TILE_POSITION, 0, 0));
                  
                  xv_set(attrib_array, ARRAY_TILE_AUTO_LAYOUT, TRUE, NULL);
	        }

                for (k = 0; k < g; k++) {

	          n = PQntuplesGroup(p, k);
	          m = PQnfieldsGroup(p, k);

                  for(i = 0; i < n; i++) {
                                                         
                   sprintf(type, "%c", PQgetvalue(p, t+i, 3) );
                   if (strcmp(PQgetvalue(p, t+i, 3), "b") == 0) ic = 1;
                   if (strcmp(PQgetvalue(p, t+i, 3), "c") == 0) ic = 0;
           
                                                             
                   type_name = strdup(PQgetvalue(p, t + i, 2));
	   
                   element_type = strdup(PQgetvalue(p, t + i, 4));
           
                   sprintf(temp, "%s = ", (char *) PQgetvalue(p, t + i, 1));
                   icon_label = strdup(temp);

                   parent_name = strdup(string);
                   attribute = (Drawicon) xv_create(attrib_array, DRAWICON, 
                                      DRAWTEXT_STRING, icon_label,
                                      DRAWIMAGE_SVRIMAGE, gray2,
                                      DRAWTEXT_STRING, icon_label,
                                      RECTOBJ_DBL_CLICK_PROC, show_hide_expression_tree,
                                      XV_KEY_DATA, EXPRESSION_HIDE, 0,
                                      XV_KEY_DATA, EXPRESSION_TREE, 0,
                                      NULL);
                   array_elem_menu = (Menu) xv_create(XV_NULL, MENU,
                                 MENU_TITLE_ITEM, "Target List Element",
                                 MENU_ACTION_ITEM, "Delete", delete_array_elem_proc,
                                 XV_KEY_DATA, MENU_OWNER, attribute,
                                 NULL);
                   xv_set(attribute, RECTOBJ_MENU, array_elem_menu, NULL);

                   tree = (Tree) xv_create((Canvas_shell) xv_get(attrib_array, XV_KEY_DATA, EXPRESSION_CANVAS), TREE,
                                      XV_SHOW, FALSE,                                      
                                      RECTOBJ_ACCEPTS_CHILD_DROP, TRUE,
                                      RECTOBJ_CHILD_DROP_PROC, adding_stuff_to_the_expression_tree,
                                      XV_KEY_DATA, ARRAY_ELEMENT, attribute, 
                                      XV_KEY_DATA, TREE_EMPTY, 1,
                                      XV_KEY_DATA, THE_ARRAY, attrib_array, 
                                      NULL);
                   xv_set(attribute, XV_KEY_DATA, EXPRESSION_TREE, tree, NULL);
                   the_new_leaf = (Rectobj) xv_create(tree, DRAWICON, 
                                                 DRAWTEXT_STRING, "Constant {Un-assigned}",
                                                 DRAWIMAGE_SVRIMAGE, gray4,
                                                 XV_KEY_DATA, TYPE, CONSTANT,
                                                 XV_KEY_DATA, NAME_SET, 0,
                                                 XV_KEY_DATA, TYPENAME, type_name,
                                                 XV_KEY_DATA_REMOVE_PROC, TYPENAME, free_string,
                                                 XV_KEY_DATA, INSTANCES, 1,                                                  
                                                 NULL);
                  the_menu = (Menu) xv_create(XV_NULL, MENU, 
                                        MENU_TITLE_ITEM, "Constant",
                                        MENU_ACTION_ITEM, "Delete", delete_leaf_proc,
                                        MENU_ACTION_ITEM, "Add operator", add_unary_opr_proc,
                                        MENU_ACTION_ITEM, "Assigned the constant...", assign_constant_proc,
                                        XV_KEY_DATA, MENU_OWNER, the_new_leaf,
                                        NULL);
                  xv_set(the_new_leaf, RECTOBJ_MENU, the_menu, NULL);
                  xv_set(tree, TREE_ADD_LINK, tree, the_new_leaf,  
                         NULL);
                  xv_set((Canvas_shell) xv_get(tree, XV_OWNER),
                                CANVAS_MIN_PAINT_WIDTH, xv_get(tree, XV_WIDTH) + 10,
                                CANVAS_MIN_PAINT_HEIGHT, xv_get(tree, XV_HEIGHT) + 10,
                                NULL);


                   window_fit(the_shell);
             
            
             }
             t += n;
          }
          alberi_PQexec("close schema");
          alberi_PQexec("end");

          xv_set(the_frame, FRAME_BUSY, FALSE, NULL);

                (void) strcpy(temp, "append ");
                footer = strdup(strcat(temp, string));
                xv_set(the_frame, FRAME_LEFT_FOOTER, footer, NULL); 
	
                if(Debugging) PQtracep = 1;
		break;

	case PANEL_LIST_OP_VALIDATE:
	
		break;

	case PANEL_LIST_OP_DELETE:
		
		break;
	}
	return XV_OK;
}

