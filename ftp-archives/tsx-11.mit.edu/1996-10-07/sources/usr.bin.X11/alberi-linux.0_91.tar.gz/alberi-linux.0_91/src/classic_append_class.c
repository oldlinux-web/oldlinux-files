
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <stdio.h>
#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "constants.h"
#include "classic_append_class_ui.h"
#include "append_interface_ui.h"


extern int PQtracep;
extern append_interface_pop_objects *append_interface_dialog;
extern bool Debugging;

/*
 * Notify callback function for `class_list'.
 */
int
classic_append_class_proc(item, string, client_data, op, event)
	Panel_item	item;
	char		*string;
	Xv_opaque	client_data;
	Panel_list_op	op;
	Event		*event;
{
	classic_append_class_pop_objects	*ip = (classic_append_class_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
        PortalBuffer   *p;
        int             i, j, k, g, n, m, t, x, ic, s;
        char            queryp[8192];
        char            type[2];
        char           *string2, *title, *parent_name;
        char           temp[100], *element_type, *icon_label, *type_name;
	
	switch(op) {
	case PANEL_LIST_OP_DESELECT:
		
		break;

	case PANEL_LIST_OP_SELECT:
                xv_set(append_interface_dialog->attribute_value_field, XV_SHOW, FALSE, NULL);
                xv_set(append_interface_dialog->type_message, XV_SHOW, FALSE, NULL);
                xv_set(append_interface_dialog->attribute_value_field, PANEL_VALUE, "", NULL);
                while((int) xv_get(append_interface_dialog->attribute_list, PANEL_LIST_NROWS))  
                   xv_set(append_interface_dialog->attribute_list, 
                          PANEL_LIST_DELETE, 0,
                          NULL);
                xv_set(ip->pop, FRAME_BUSY, TRUE, NULL);
                if(Debugging) PQtracep = 0;
                /* get the attributes and construct the array and expression tree related */
                sprintf(queryp, "retrieve portal schema (classes=r.relname,attribute=a.attname,types=t.typname, t.typtype, t.typelem) from a in pg_attribute, t in pg_type, r in pg_class where a.attrelid = r.oid  and a.atttypid = t.oid and (a.attnum > 0 \/* or a.attnum = -3 *\/) and  r.relname =  \"%s\"", string);
                alberi_PQexec("begin");
                alberi_PQexec(queryp);

                alberi_PQexec("fetch all in schema");

                p = PQparray("schema");
                g = PQngroups(p);
                t = 0;
                for (k = 0; k < g; k++) {

	          n = PQntuplesGroup(p, k);
	          m = PQnfieldsGroup(p, k);

                  for(i = 0; i < n; i++) {
                                                         
                   sprintf(type, "%c", PQgetvalue(p, t+i, 3) );
                   if (strcmp(PQgetvalue(p, t+i, 3), "b") == 0) ic = 1;
                   if (strcmp(PQgetvalue(p, t+i, 3), "c") == 0) ic = 0;
           
                   sprintf(temp, "::%s", PQgetvalue(p, t + i, 2));                                          
                   type_name = strdup(temp);
	   
                   element_type = strdup(PQgetvalue(p, t + i, 4));
           
                   sprintf(temp, "%s = ", (char *) PQgetvalue(p, t + i, 1));
                   icon_label = strdup(temp);

                   parent_name = strdup(string);
                   xv_set(append_interface_dialog->attribute_list, 
                          PANEL_LIST_INSERT, (int) xv_get(append_interface_dialog->attribute_list, PANEL_LIST_NROWS) ,
                          PANEL_LIST_STRING, (int) xv_get(append_interface_dialog->attribute_list, PANEL_LIST_NROWS) , icon_label,
                          PANEL_LIST_CLIENT_DATA, (int) xv_get(append_interface_dialog->attribute_list, PANEL_LIST_NROWS), type_name,
                          NULL);
             }
             t += n;
          }
          alberi_PQexec("close schema");
          alberi_PQexec("end");
          if(Debugging) PQtracep = 1;
          xv_set(ip->pop, FRAME_BUSY, FALSE, NULL);
          xv_set(append_interface_dialog->pop, XV_SHOW, TRUE, FRAME_LABEL, parent_name, NULL);
		
		break;

	case PANEL_LIST_OP_VALIDATE:
	
		break;

	case PANEL_LIST_OP_DELETE:
	
		break;
	}
	return XV_OK;
}

