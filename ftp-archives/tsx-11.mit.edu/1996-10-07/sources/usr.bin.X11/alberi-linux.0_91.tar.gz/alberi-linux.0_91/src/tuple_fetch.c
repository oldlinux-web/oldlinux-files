
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>

/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "externs.h"

#include "constants.h"
#include "grays.h"
#include "funcs.h"


int
tuple_fetch(classname, tuple_index)
     char *classname;
     int tuple_index;
{

/* ======================================================================== */
  int fields, total_tuples, typeid;
  char *field_value, whole[2048], temp[100], *wholeness;
  PortalBuffer   *p, *p1;
  int  i, j, k, g, n, m, t, x, ic, s, i1, j1, k1, g1, n1, m1, t1, x1, ic1, s1;
  char            queryp[8192];
  char            type[2];
  char           *string, *title, *parent_name;
  char           *type_name, *element_type, *parent_num_attr,
                 *child_num_attr, *generic_char, *icon_label;
/* ======================================================================== */

  
  xv_set(replace_interface_dialog->attribute_value_field, 
	 XV_SHOW, FALSE, 
	 NULL);
  xv_set(replace_interface_dialog->type_message, XV_SHOW, FALSE, NULL);
  xv_set(replace_interface_dialog->attribute_value_field, PANEL_VALUE, "",
	 NULL);

  while ((int) xv_get(replace_interface_dialog->attribute_list,
		      PANEL_LIST_NROWS))  
    xv_set(replace_interface_dialog->attribute_list, 
	   PANEL_LIST_DELETE, 0,
	   NULL);

  if (Debugging) 
    PQtracep = 0;

  sprintf(queryp, 

"retrieve portal schema (%s.all, %s.oid)",

	  classname, classname);

  alberi_PQexec("begin");
  alberi_PQexec(queryp);

  alberi_PQexec("fetch all in schema");

  p = PQparray("schema");
  g = PQngroups(p);
  t = 0;
  for (k = 0; k < g; k++) { /* groups, usually 1 */
    
    n = PQntuplesGroup(p, k); total_tuples = n;
    m = PQnfieldsGroup(p, k); fields = m;

    
    if (n) 
      ic = 1; 
    else 
      ic = 0;

    for(i = 0; i < ic ; i++) { /* one tuple */ 
      /* fetch only the tuple of interest */
      
      for(j = 0 ; j < m ; j++) { /* fields */

	/* the oid is the last field so take it at that point: j == m - 1 */
	/* you need the field name */
	if (j != (m - 1)) {  
	  sprintf(temp, "%s = ", (char *) PQfname(p, t + tuple_index, j));
   
	  icon_label = strdup(temp);
	  /* Now to ask for the typename of this field */
	  typeid = PQftype(p, t + tuple_index, j);    
 
/* ========================================================================= */

	  sprintf(queryp, 

"retrieve portal tipo (t.typname) \
from t in pg_type \
where t.oid = \"%u\"::oid", 

		  typeid);

	  /* alberi_PQexec("begin"); */
	  alberi_PQexec(queryp);
	  alberi_PQexec("fetch all in tipo");
	  p1 = PQparray("tipo");
	  g1 = PQngroups(p1);
	  t1 = 0;
	  for (k1= 0; k1 < g1; k1++) { /* groups, usually 1 */
	    
	    n1 = PQntuplesGroup(p1, k1); 
	    m1 = PQnfieldsGroup(p1, k1); 

	    for(i1 = 0; i1 < n1 ; i1++) {
	      sprintf(temp, "::%s", PQgetvalue(p1, t1 + i1, 0));                                          
	      type_name = strdup(temp);
	    }
	    t1 += n1;
	  }
	  alberi_PQexec("close tipo");
	  /* alberi_PQexec("end"); */

/* ======================================================================== */

	  if (!PQgetvalue(p, t + tuple_index, j)) {
	    strcpy(whole, type_name);
	    field_value = strdup(whole);
	  }
	  else {
	    element_type = strdup(PQgetvalue(p, t + tuple_index, j));
	    strcpy(whole, element_type);
	    strcat(whole, type_name);
	    field_value = strdup(whole);
	  }
	  parent_name = strdup(classname);
	  xv_set(replace_interface_dialog->attribute_list, 
		 PANEL_LIST_INSERT, 
		   (int) xv_get(replace_interface_dialog->attribute_list, 
				PANEL_LIST_NROWS) ,
		 PANEL_LIST_STRING, 
		   (int) xv_get(replace_interface_dialog->attribute_list, 
				PANEL_LIST_NROWS) , 
		   icon_label,
		 PANEL_LIST_CLIENT_DATA, 
		   (int) xv_get(replace_interface_dialog->attribute_list, 
				PANEL_LIST_NROWS), 
		   field_value,
		 NULL);
	} 
	else { /* OID */
	  generic_char = strdup(PQgetvalue(p, t + tuple_index, j));
	  xv_set(replace_interface_dialog->pop, 
		 XV_KEY_DATA, TYPENAME, generic_char,
		 XV_KEY_DATA_REMOVE_PROC, TYPENAME, free_string,
		 XV_KEY_DATA, CLASS, total_tuples,
		 NULL); 

	}

      } /* new field */
    } /* new tuple */
    t += n;
  }
  alberi_PQexec("close schema");
  alberi_PQexec("end");
  if (Debugging) 
    PQtracep = 1;
 
  return total_tuples;

}



int
tuple_fetch1(classname, tuple_index)
     char *classname;
     int tuple_index;
{

/* ======================================================================== */
  int fields, total_tuples, typeid;
  char *field_value, whole[2048], temp[100], *wholeness;
  PortalBuffer   *p, *p1;
  int   i, j, k, g, n, m, t, x, ic, s, i1, j1, k1, g1, n1, m1, t1, x1, ic1, s1;
  char            queryp[8192];
  char            type[2];
  char           *string, *title, *parent_name;
  char           *type_name, *element_type, *parent_num_attr,
                 *child_num_attr, *generic_char, *icon_label;
/* ======================================================================== */

  
  xv_set(delete_interface_dialog->type_message, XV_SHOW, FALSE, NULL);
                

  while ((int) xv_get(delete_interface_dialog->attribute_list, 
		      PANEL_LIST_NROWS))  
    xv_set(delete_interface_dialog->attribute_list, 
	   PANEL_LIST_DELETE, 0,
	   NULL);

  if (Debugging) 
    PQtracep = 0;

  sprintf(queryp, 

"retrieve portal schema (%s.all, %s.oid)",

	  classname, classname);
  alberi_PQexec("begin");
  alberi_PQexec(queryp);

  alberi_PQexec("fetch all in schema");

  p = PQparray("schema");
  g = PQngroups(p);
  t = 0;
  for (k = 0; k < g; k++) { /* groups, usually 1 */
    
    n = PQntuplesGroup(p, k); total_tuples = n;
    m = PQnfieldsGroup(p, k); fields = m;

                 
    if (n) 
      ic = 1;
    else ic = 0;

    for(i = 0; i < ic ; i++) { /* one tuple */ 
      /* fetch only the tuple of interest */

      for(j = 0 ; j < m ; j++) { /* fields */

	/* the oid is the last field so take it at that point: j == m - 1 */
	/* you need the field name */
	if (j != (m - 1)) {                                                  
	  sprintf(temp, "%s = ", (char *) PQfname(p, t + tuple_index, j));
   
	  icon_label = strdup(temp);
	  /* Now to ask for the typename of this field */
	  typeid = PQftype(p, t + tuple_index, j);    
 
/* ====================================================================== */

	  sprintf(queryp, 

"retrieve portal tipo (t.typname) \
from t in pg_type \
where t.oid = \"%u\"::oid", 

		  typeid);
	  /* alberi_PQexec("begin"); */
	  alberi_PQexec(queryp);
	  alberi_PQexec("fetch all in tipo");
	  p1 = PQparray("tipo");
	  g1 = PQngroups(p1);
	  t1 = 0;
	  for (k1= 0; k1 < g1; k1++) { /* groups, usually 1 */

	    n1 = PQntuplesGroup(p1, k1); 
	    m1 = PQnfieldsGroup(p1, k1); 
	    
	    for(i1 = 0; i1 < n1 ; i1++) {
	      sprintf(temp, "::%s", PQgetvalue(p1, t1 + i1, 0));
	      type_name = strdup(temp);
	    }
	    t1 += n1;
	  }
	  alberi_PQexec("close tipo");
	  /* alberi_PQexec("end"); */

/* ===================================================================== */

	  if (!PQgetvalue(p, t + tuple_index, j)) {
	    strcpy(whole, type_name);
	    field_value = strdup(whole);
	  }
	  else {
	    element_type = strdup(PQgetvalue(p, t + tuple_index, j));
	    strcpy(whole, element_type);
	    strcat(whole, type_name);
	    field_value = strdup(whole);
	  }
	  parent_name = strdup(classname);
	  xv_set(delete_interface_dialog->attribute_list, 
		 PANEL_LIST_INSERT, 
		   (int) xv_get(delete_interface_dialog->attribute_list,
				PANEL_LIST_NROWS) ,
		 PANEL_LIST_STRING, 
		   (int) xv_get(delete_interface_dialog->attribute_list, 
				PANEL_LIST_NROWS) , 
		   icon_label,
		 PANEL_LIST_CLIENT_DATA, 
		   (int) xv_get(delete_interface_dialog->attribute_list, 
				PANEL_LIST_NROWS), 
		   field_value,
		 NULL);
	} 
	else { /* OID */
	  generic_char = strdup(PQgetvalue(p, t + tuple_index, j));
	  xv_set(delete_interface_dialog->pop, 
		 XV_KEY_DATA, TYPENAME, generic_char,
		 XV_KEY_DATA_REMOVE_PROC, TYPENAME, free_string,
		 XV_KEY_DATA, CLASS, total_tuples,
		 NULL); 
                        
	}

      } /* new field */
    } /* new tuple */
    t += n;
  }
  alberi_PQexec("close schema");
  alberi_PQexec("end");
  if (Debugging) 
    PQtracep = 1;
 
  return total_tuples;

}

