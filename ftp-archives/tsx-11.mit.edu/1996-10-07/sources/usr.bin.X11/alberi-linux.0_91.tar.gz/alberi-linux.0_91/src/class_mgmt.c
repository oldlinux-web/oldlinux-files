
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>

/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "externs.h"

#include "constants.h"
#include "grays.h"
#include "funcs.h"


extern Array_tile  attrib_creation_tile, inheritance_tile, attrib_addition_tile;



void
add_new_attribute_in_the_array(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
  Rectobj attribute;
  Array_tile the_new_attributes;
  Canvas_shell the_shell;
  Menu attribute_menu;

  the_shell = (Canvas_shell) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
  the_new_attributes = (Array_tile) xv_get(the_shell, XV_KEY_DATA, THE_ARRAY);

  attribute = (Drawicon) xv_create(the_new_attributes, DRAWICON,
                                 DRAWIMAGE_SVRIMAGE, gray2,
                                 DRAWTEXT_STRING, "\/* new attr *\/",
                                 XV_KEY_DATA, NAME_SET, 0,
                                 XV_KEY_DATA, THE_ARRAY, -1,
                                 XV_KEY_DATA, TYPENAME, 0,
                                 XV_KEY_DATA_REMOVE_PROC, TYPENAME, free_string,
                                 NULL);

  attribute_menu = (Menu) xv_create(XV_NULL, MENU,
                                 MENU_TITLE_ITEM, "New attribute Menu",
                                 MENU_ACTION_ITEM,
				   "Name the attribute", 
				   name_retrieve_attr_proc,
                                 MENU_ACTION_ITEM, 
				    "Assign type", 
				    assign_type_new_attribute,
                                 MENU_ACTION_ITEM, 
				  "Delete", delete_new_attr_proc,
                                 XV_KEY_DATA, MENU_OWNER, attribute,
				  NULL); 
  xv_set(attribute, 
	 RECTOBJ_MENU, attribute_menu,
	 NULL);
  xv_set(the_shell, 
	 CANVAS_MIN_PAINT_WIDTH, xv_get(the_new_attributes, XV_WIDTH) + 20,
	 CANVAS_MIN_PAINT_HEIGHT, xv_get(the_new_attributes, XV_HEIGHT) + 10,
	 NULL);        
}




void
delete_new_attr_proc(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
   Array_tile the_array;
   Rectobj  the_element;
   Tree the_expression;
   

   the_element = (Rectobj) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
   the_array = (Array_tile) xv_get(the_element, XV_OWNER);
   
   
   xv_set((Frame) xv_get((Canvas_shell) xv_get(the_array, XV_OWNER),
			 XV_OWNER),
	  FRAME_BUSY, TRUE, 
	  NULL);
   
   
   xv_destroy(the_element);
   xv_destroy(menu);

   xv_set(expression_frame, FRAME_BUSY, FALSE, NULL);

   xv_set((Canvas_shell) xv_get(the_array, XV_OWNER),
         CANVAS_MIN_PAINT_WIDTH, xv_get(the_array, XV_WIDTH) + 10,
         CANVAS_MIN_PAINT_HEIGHT, xv_get(the_array, XV_HEIGHT) + 10,
         NULL);
   xv_set((Frame) xv_get((Canvas_shell) xv_get(the_array, XV_OWNER), XV_OWNER),
	  FRAME_BUSY, FALSE, 
	  NULL); 
   
}

void
assign_type_new_attribute(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
  Rectobj the_attribute;
  PortalBuffer *p;
  int i, j, k, g, n, m, t, x, ic,s, count;
  char queryp[8192];
  char entry[20];
  char type[2];

  sprintf(queryp, 

"retrieve portal tipos (pg_type.typname) \
where pg_type.typname !~ \"^_.*\" \
      and pg_type.typname !~ \"pg_.*\""

	  );

  while((int) xv_get(new_type_dialog->types_list, PANEL_LIST_NROWS))  
    xv_set(new_type_dialog->types_list, 
	   PANEL_LIST_DELETE, 0,
	   NULL);


  if(Debugging) PQtracep = 0;

  alberi_PQexec("begin");
  alberi_PQexec(queryp);
                      
  alberi_PQexec("fetch all in tipos");

  p = PQparray("tipos");
  g = PQngroups(p);
  t = 0;

  for(k = 0; k < g; k++) {
    n = PQntuplesGroup(p, k);
    m = PQnfieldsGroup(p, k);

    for(i = 0; i < n; i++) {
      sprintf(entry, "%s", PQgetvalue(p, t + i, 0));
      xv_set(new_type_dialog->types_list, 
	     PANEL_LIST_INSERT, 
	       (int) xv_get(new_type_dialog->types_list, PANEL_LIST_NROWS) ,
	     PANEL_LIST_STRING, 
	       (int) xv_get(new_type_dialog->types_list, PANEL_LIST_NROWS) , 
	       (char *) entry,
	     NULL);
    }
    t += n;
  }
  alberi_PQexec("close tipos");
  alberi_PQexec("end");

  if(Debugging) PQtracep = 1;

  the_attribute = (Rectobj) xv_get(menu, XV_KEY_DATA, MENU_OWNER);

  xv_set(new_type_dialog->pop,
	 XV_KEY_DATA, OPER, the_attribute,
	 NULL);
  xv_set(new_type_dialog->array_size_slider, XV_SHOW, FALSE, NULL);
  xv_set(new_type_dialog->message1, XV_SHOW, FALSE, NULL);
  xv_set(new_type_dialog->message2, XV_SHOW, FALSE, NULL);
  xv_set(new_type_dialog->array_setting, XV_SHOW, FALSE, PANEL_VALUE, 0, NULL);
  xv_set(new_type_dialog->pop, FRAME_CMD_PUSHPIN_IN, TRUE, NULL);
  xv_set(new_type_dialog->pop, 
	 XV_SHOW, TRUE, 
	 NULL);
}

void
delete_all_attribute_in_the_array(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
  Canvas_shell the_shell;
  Array_tile the_new_attributes;
  Menu the_attribute_menu;

  the_shell = (Canvas_shell) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
  the_new_attributes = (Array_tile) xv_get(the_shell, XV_KEY_DATA, THE_ARRAY);

  while(xv_get(the_new_attributes, ARRAY_TILE_POSITION, 0, 0)) {
    the_attribute_menu = (Menu) xv_get((Rectobj) xv_get(the_new_attributes,
						      ARRAY_TILE_POSITION,0,0), 
				       RECTOBJ_MENU);
    xv_destroy((Rectobj) xv_get(the_new_attributes, ARRAY_TILE_POSITION, 0, 0));
    xv_destroy(the_attribute_menu);
  }

}

void
adding_inheritance_proc(canvas_shell, 
			rectobj, 
			drop_canvas_shell, 
			drop_rectobj, 
			drop_event)
     Canvas_shell canvas_shell;
     Rectobj rectobj;
     Canvas_shell drop_canvas_shell;
     Rectobj drop_rectobj;
     Event *drop_event;
{
  Rectobj_list *the_parents;
  Rectobj one_parent, parent_copy;
  Array_tile heritage;
  Menu the_parent_menu;
  char *name;

  the_parents = get_selected_list();
  heritage = (Array_tile) xv_get(drop_canvas_shell, XV_KEY_DATA, THE_ARRAY);

  list_for(the_parents) {
    one_parent = RECTOBJ_LIST_HANDLE(the_parents);
    if(!((int) xv_get(one_parent, XV_KEY_DATA, TYPE))) {
      name = strdup((char *) xv_get(one_parent, DRAWTEXT_STRING));
      parent_copy = (Drawicon)
	xv_create(heritage, DRAWICON,
		  DRAWIMAGE_SVRIMAGE, 
		    (Server_image) xv_get(one_parent, DRAWIMAGE_SVRIMAGE),
		  DRAWTEXT_STRING, name,
		  NULL);
      the_parent_menu = (Menu)
	xv_create(XV_NULL, MENU,
		  MENU_TITLE_ITEM, "New Class Parent Menu",
		  MENU_ACTION_ITEM, "Remove this parent", delete_new_attr_proc,
		  XV_KEY_DATA, MENU_OWNER, parent_copy,
		  NULL);
      xv_set(parent_copy, RECTOBJ_MENU, the_parent_menu, NULL);
    }
  }  
}

void
name_the_new_class(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
  Canvas_shell the_shell;
  Frame the_frame;

  the_shell = (Canvas_shell) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
  the_frame = (Frame) xv_get(the_shell, XV_OWNER);

  xv_set(name_new_class_dialog->pop, XV_KEY_DATA, OPER, the_frame, NULL);
  xv_set(name_new_class_dialog->pop, XV_SHOW, TRUE, NULL);
}


char 
*create_constructor()
{
/* do the following:
 * "create classname" = from the header of attrib_creation_frame
 * concatenate it with " ("
 * 
 * travel the attrib_creation_array doing the following:
 *  if not the first time add ", "
 *  "label = typname" if XV_KEY_DATA, THE_ARRAY is -1 then add " "
 *  if 0 add "[] " else add "[value] "
 * end travel
 *
 * add ") "
 * return the string
 */
 char temp[8196], array_size[15];
 char *tmp_ptr;
 char *tail;
 int ROWS, COLS, row, col, first, size;

 tmp_ptr = (char *) xv_get(attrib_creation_frame, FRAME_LEFT_FOOTER);
 if ( tmp_ptr == NULL )
   return "";
 (void) strcpy(temp, tmp_ptr);
 (void) strcat(temp, " (");

 ROWS = (int) xv_get(attrib_creation_tile, ARRAY_TILE_N_ROWS);
 COLS = (int) xv_get(attrib_creation_tile, ARRAY_TILE_N_COLUMNS);
 first = 0;

 for (row = 0; row < ROWS; row++) {
   for (col = 0; col < COLS; col++) {
     if (first &&
	 xv_get(attrib_creation_tile, ARRAY_TILE_POSITION, col, row)) 
       (void) strcat(temp, ", ");
     else first++;
     if ( (Rectobj) xv_get( attrib_creation_tile, 
			    ARRAY_TILE_POSITION, col, row) ) {
       tail = (char *) xv_get((Rectobj) xv_get(attrib_creation_tile,
					       ARRAY_TILE_POSITION, col, row),
			      DRAWTEXT_STRING);
       if ( tail != NULL )
	 strcat(temp, tail );
       tail = (char *) xv_get((Rectobj) xv_get(attrib_creation_tile,
					       ARRAY_TILE_POSITION, col, row),
			      XV_KEY_DATA, TYPENAME);
       if ( tail != NULL )
	 strcat(temp, tail );
       if ( (size = (int) xv_get((Rectobj) xv_get(attrib_creation_tile,
						  ARRAY_TILE_POSITION,
						    col, row),
				 XV_KEY_DATA, THE_ARRAY)) > 0 ) {
	 sprintf(array_size, "[%d]", size);
	 (void) strcat(temp, array_size);
       }
       else if ( (int) xv_get((Rectobj) xv_get(attrib_creation_tile,
					       ARRAY_TILE_POSITION, col, row),
			      XV_KEY_DATA, THE_ARRAY) == 0 ) {
	 (void) strcat(temp, "[]");
       }
     }
   }
 }
 (void) strcat(temp, ") ");
 xv_set(attrib_creation_frame, FRAME_LEFT_FOOTER, "", NULL);
 return temp;
}

char 
*inheritance_constructor()
{

/* Just check if there is some parent present and add it */

  Rectobj_list *heritage;
  char temp[8196];
  int ROWS, COLS, row, col, first;

  heritage = (Rectobj_list *) xv_get(inheritance_tile, RECTOBJ_CHILDREN);
  temp[0] = '\0';

  if (heritage) {
    (void) strcpy(temp, "inherits (");
    ROWS = (int) xv_get(inheritance_tile, ARRAY_TILE_N_ROWS);
    COLS = (int) xv_get(inheritance_tile, ARRAY_TILE_N_COLUMNS);
    first = 0;

    for(row = 0; row < ROWS; row++) {
      for(col = 0; col < COLS; col++) {
	if (first &&  xv_get(inheritance_tile, ARRAY_TILE_POSITION, col, row)) 
	  (void) strcat(temp, ", ");
	else first++;
	if ( (Rectobj) xv_get(inheritance_tile, 
			      ARRAY_TILE_POSITION, col, row)) {
	  strcat(temp,
		 (char *) xv_get( (Rectobj) xv_get(inheritance_tile,
						   ARRAY_TILE_POSITION,
						     col, row), 
				  DRAWTEXT_STRING));
	}
      }
    }
    (void) strcat(temp, ") ");
  }
  return temp;
}

void
add_attributes_proc(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
  Rectobj the_class;
  char temp[32], *footer;

    the_class = (Rectobj) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
    footer = strdup((char *) xv_get(the_class, DRAWTEXT_STRING));
    xv_set(attrib_addition_frame,
	   FRAME_LEFT_FOOTER, "addattr", 
	   FRAME_RIGHT_FOOTER, footer, 
	   NULL);

    xv_set(attrib_creation_frame, 
	   FRAME_CMD_PUSHPIN_IN, FALSE, 
	   XV_SHOW, FALSE, 
	   NULL);
    xv_set(inheritance_frame, 
	   FRAME_CMD_PUSHPIN_IN, FALSE, 
	   XV_SHOW, FALSE, 
	   NULL);
    xv_set(attrib_addition_frame, 
	   FRAME_CMD_PUSHPIN_IN, TRUE, 
	   XV_SHOW, TRUE, 
	   NULL);

    xv_set(target_frame, 
	   XV_SHOW, FALSE, 
	   FRAME_CMD_PUSHPIN_IN, FALSE, 
	   NULL);
    xv_set(target_shell, 
	   RECTOBJ_ACCEPTS_DROP, TRUE, 
	   RECTOBJ_DROP_PROC, adding_stuff_in_the_array, 
	   NULL);
    xv_set(qual_frame, 
	   XV_SHOW, FALSE, 
	   FRAME_CMD_PUSHPIN_IN, FALSE, 
	   NULL);
    xv_set(expression_frame, 
	   XV_SHOW, FALSE, 
	   FRAME_CMD_PUSHPIN_IN, FALSE, 
	   NULL);


}



char 
*addattr_constructor()
{

/* do the following:
 * "addattr" = from the header of attrib_creation_frame
 * concatenate it with " ("
 * 
 * travel the attrib_addition_array doing the following:
 *  if not the first time add ", "
 *  "label = typname" if XV_KEY_DATA, THE_ARRAY is -1 then add " "
 *  if 0 add "[] " else add "[value] "
 * end travel
 *
 * add ") "
 * add "to "
 * add classname from the right footer
 * return the string
 */

  char temp[8196], array_size[15];
  char *tmp_ptr;
  int ROWS, COLS, row, col, first;
  int size;

  tmp_ptr = (char *) xv_get(attrib_addition_frame, FRAME_LEFT_FOOTER);
  if ( tmp_ptr == NULL )
    return "";
  (void) strcpy(temp, tmp_ptr);
  (void) strcat(temp, " (");

  ROWS = (int) xv_get(attrib_addition_tile, ARRAY_TILE_N_ROWS);
  COLS = (int) xv_get(attrib_addition_tile, ARRAY_TILE_N_COLUMNS);
  first = 0;

  for(row = 0; row < ROWS; row++) {
    for(col = 0; col < COLS; col++) {
      if(first &&
	 xv_get(attrib_addition_tile, ARRAY_TILE_POSITION, col, row)) 
	(void) strcat(temp, ", "); 
      else first++;
      if ((Rectobj) xv_get(attrib_addition_tile, 
			   ARRAY_TILE_POSITION, col, row)) {
	strcat(temp,
	       (char *) xv_get((Rectobj) xv_get(attrib_addition_tile,
						ARRAY_TILE_POSITION,
						  col, row), 
			       DRAWTEXT_STRING));
	strcat(temp, 
	       (char *) xv_get((Rectobj) xv_get(attrib_addition_tile,
						ARRAY_TILE_POSITION, col, row),
			       XV_KEY_DATA, TYPENAME));
	if ( (size = (int) xv_get((Rectobj) xv_get(attrib_addition_tile, 
					  ARRAY_TILE_POSITION, col, row), 
			  XV_KEY_DATA, THE_ARRAY)) > 0 ) {
	  sprintf(array_size, "[%d]", size);
	  (void) strcat(temp, array_size);
	} 
	else if ( (int) xv_get((Rectobj) xv_get(attrib_addition_tile, 
						ARRAY_TILE_POSITION, col, row),
			       XV_KEY_DATA, THE_ARRAY) == 0 ) {
	  (void) strcat(temp, "[]");
	}
      }
    }
  }
  (void) strcat(temp, ") ");
  (void) strcat(temp, "to ");
  (void) strcat(temp, 
		(char *) xv_get(attrib_addition_frame, FRAME_RIGHT_FOOTER));
  xv_set(attrib_addition_frame, 
	 FRAME_LEFT_FOOTER, "", 
	 FRAME_RIGHT_FOOTER, "", 
	 NULL);

{
  Menu the_attribute_menu;

  while(xv_get(attrib_addition_tile, ARRAY_TILE_POSITION, 0, 0)) {
    the_attribute_menu = (Menu) xv_get((Rectobj) xv_get(attrib_addition_tile,
						      ARRAY_TILE_POSITION,0,0), 
				       RECTOBJ_MENU);
    xv_destroy((Rectobj) xv_get(attrib_addition_tile, 
				ARRAY_TILE_POSITION, 0, 0));
    xv_destroy(the_attribute_menu);
  }
}

  return temp;
}

void
rename_class_proc(menu, menu_item)
     Menu menu;
     Menu_item menu_item; 
{
  Rectobj class;
  char *old_name;

  class = (Rectobj) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
  old_name = strdup((char *) xv_get(class, DRAWTEXT_STRING));
  
  xv_set(rename_interface_dialog->old_name_class, 
	 PANEL_LABEL_STRING, old_name, 
	 XV_SHOW, TRUE, 
	 NULL);
  xv_set(rename_interface_dialog->pop, XV_SHOW, TRUE, NULL);


}



void
show_class_creation_system(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
  xv_set(target_frame, FRAME_CMD_PUSHPIN_IN, FALSE, XV_SHOW, FALSE, NULL);
  xv_set(target_shell, 
	 RECTOBJ_ACCEPTS_DROP, TRUE,
	 RECTOBJ_DROP_PROC, adding_stuff_in_the_array, 
	 NULL);
  xv_set(expression_frame, FRAME_CMD_PUSHPIN_IN, FALSE, XV_SHOW, FALSE, NULL);
  xv_set(qual_frame, FRAME_CMD_PUSHPIN_IN, FALSE, XV_SHOW, FALSE, NULL);
  xv_set(attrib_addition_frame,
	 XV_SHOW, FALSE,
	 FRAME_CMD_PUSHPIN_IN, 	FALSE, 
	 NULL);
  xv_set(attrib_creation_frame,
	 XV_SHOW, TRUE,
	 FRAME_CMD_PUSHPIN_IN, TRUE, 
	 NULL);
  xv_set(inheritance_frame,
	 XV_SHOW, TRUE,
	 FRAME_CMD_PUSHPIN_IN, TRUE,
	 NULL);
}

void
hide_class_creation_system(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
  xv_set(attrib_creation_frame,
	 FRAME_CMD_PUSHPIN_IN, FALSE, 
	 XV_SHOW, FALSE, 
	 NULL);
  xv_set(inheritance_frame, 
	 FRAME_CMD_PUSHPIN_IN, FALSE,
	 XV_SHOW, FALSE, 
	 NULL);
  xv_set(attrib_addition_frame, 
	 FRAME_CMD_PUSHPIN_IN, FALSE, 
	 XV_SHOW, FALSE,
	 NULL);
  xv_set(target_frame, FRAME_CMD_PUSHPIN_IN, FALSE, XV_SHOW, FALSE, NULL);
  xv_set(target_shell,
	 RECTOBJ_ACCEPTS_DROP, TRUE,
	 RECTOBJ_DROP_PROC, adding_stuff_in_the_array, 
	 NULL);
  xv_set(expression_frame,
	 FRAME_CMD_PUSHPIN_IN, FALSE,
	 XV_SHOW, FALSE, 
	 NULL);
  xv_set(qual_frame,
	 FRAME_CMD_PUSHPIN_IN, FALSE,
	 XV_SHOW, FALSE,
	 NULL);
}

