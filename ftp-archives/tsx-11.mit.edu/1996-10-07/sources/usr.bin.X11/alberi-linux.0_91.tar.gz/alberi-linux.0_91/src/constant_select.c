
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/


#include <stdio.h>
#include <sys/param.h>
#include <sys/types.h>
#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include "constant_select_ui.h"
#include "constants.h"



/*
 * Notify callback function for `constant_field'.
 */
Panel_setting
constant_guts_proc(item, event)
	Panel_item	item;
	Event		*event;
{
	constant_select_pop_objects	*ip = (constant_select_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
	char *	value = (char *) xv_get(item, PANEL_VALUE);
        char the_constant[40], *the_label;
        Rectobj constant;

	constant = (Rectobj) xv_get(ip->pop, XV_KEY_DATA, OPER);
        if((int) xv_get(constant, XV_KEY_DATA, INSTANCES)) {
           sprintf(the_constant, "\"%s\"::%s", value, (char *) xv_get(constant, XV_KEY_DATA, TYPENAME));
           the_label = strdup(the_constant);
           xv_set(constant, 
                       DRAWTEXT_STRING, (char *) the_label,
                       XV_KEY_DATA, NAME_SET, 1,
                       NULL);
                  xv_set(ip->pop, XV_SHOW, FALSE, NULL);
                  xv_set(ip->constant_field, PANEL_VALUE, "", NULL);
        }
	
	return panel_text_notify(item, event);
}

/*
 * Notify callback function for `type_list'.
 */
int
constant_type_select_proc(item, string, client_data, op, event)
	Panel_item	item;
	char		*string;
	Xv_opaque	client_data;
	Panel_list_op	op;
	Event		*event;
{
	constant_select_pop_objects	*ip = (constant_select_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
        char *the_constant;
        
	
	switch(op) {
	case PANEL_LIST_OP_DESELECT:
		
		break;

	case PANEL_LIST_OP_SELECT:
		
                if((char *)  xv_get(ip->constant_field, PANEL_VALUE) != NULL) {
                  the_constant = (char *) malloc(300*sizeof(char) + 1);
                  sprintf(the_constant, "\"%s\"::%s", (char *) xv_get(ip->constant_field, PANEL_VALUE), string);
                  xv_set((Rectobj) xv_get(ip->pop, XV_KEY_DATA, OPER), 
                       DRAWTEXT_STRING, (char *) the_constant,
                       XV_KEY_DATA, TYPENAME, (char *) string,
                       XV_KEY_DATA, NAME_SET, 1,
                       NULL);
                  xv_set(ip->pop, XV_SHOW, FALSE, NULL);
                  xv_set(ip->constant_field, PANEL_VALUE, "", NULL);
                } else {
                  xv_set(ip->pop, FRAME_LEFT_FOOTER, "You haven\'t entered the constant...", NULL);
                }
		break;

	case PANEL_LIST_OP_VALIDATE:
		
		break;

	case PANEL_LIST_OP_DELETE:
		
		break;
	}
	return XV_OK;
}

/*
 * Notify callback function for `button1'.
 */
void
constant_done_proc(item, event)
	Panel_item	item;
	Event		*event;
{
  constant_select_pop_objects	*ip = (constant_select_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
  Rectobj the_constant, the_parent, the_sibling, temp;
  Tree the_expression;
  Rectobj_list *the_rest;
  char the_constant_value[300], *string, *value;
  int  found_sibling;
  
  the_constant = (Rectobj) xv_get(ip->pop, XV_KEY_DATA, OPER);
  the_expression = (Tree) xv_get(the_constant, XV_OWNER);
  the_parent = (Rectobj) xv_get(the_expression, TREE_LINK_FROM, the_constant);
  
  the_rest = (Rectobj_list *) xv_get(the_expression, 
				     TREE_LINK_TO_LIST, the_parent);
  found_sibling = 0;
  list_for ( the_rest ) {
    temp = RECTOBJ_LIST_HANDLE(the_rest);
    if ( temp != the_constant ) {
      the_sibling = temp;
      found_sibling = 1;
    }
  }

  value = (char *) xv_get(ip->constant_field, PANEL_VALUE);

  if( value != NULL && value[0] != '\0' ) {
    
    if ( found_sibling )
      string = (char *) xv_get(the_sibling, XV_KEY_DATA, TYPENAME);
    else
      string = NULL;

    if ( string != NULL ) {
      string = strdup(string );
      value = strdup(value);
      sprintf(the_constant_value, "\"%s\"::%s ", value, string);
      xv_set((Rectobj) xv_get(ip->pop, XV_KEY_DATA, OPER), 
	     DRAWTEXT_STRING, the_constant_value,
	     XV_KEY_DATA, TYPENAME, string,
	     XV_KEY_DATA, NAME_SET, 1,
	     NULL);
      xv_set(ip->pop, XV_SHOW, FALSE, NULL);
      xv_set(ip->constant_field, PANEL_VALUE, NULL, NULL);
    }
    else {
      xv_set(ip->pop, XV_SHOW, TRUE, NULL);
      xv_set(ip->pop, FRAME_LEFT_FOOTER,
	     "You haven\'t entered the type...", NULL); 
    }
  } 
  else {
    xv_set(ip->pop, XV_SHOW, TRUE, NULL);
    xv_set(ip->pop, FRAME_LEFT_FOOTER, 
	   "You haven\'t entered the constant...", NULL);
  }     
  
}

