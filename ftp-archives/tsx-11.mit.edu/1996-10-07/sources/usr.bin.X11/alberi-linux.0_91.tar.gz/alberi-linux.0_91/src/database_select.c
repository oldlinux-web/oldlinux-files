
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "constants.h"
#include "database_select_ui.h"



extern char *version;
extern char *dbname;
extern void update_schema();
extern char *PQhost;

/*
 * Notify callback function for `databases_list'.
 */
int
database_selection_proc(item, string, client_data, op, event)
	Panel_item	item;
	char		*string;
	Xv_opaque	client_data;
	Panel_list_op	op;
	Event		*event;
{
	database_select_pop_objects	*ip = (database_select_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
        char title[100], *label;
        Frame the_frame;
	
	switch(op) {
	case PANEL_LIST_OP_DESELECT:
		
		break;

	case PANEL_LIST_OP_SELECT:
                the_frame = (Frame) xv_get(ip->pop, XV_KEY_DATA, OPER);
                dbname = strdup(string);
                xv_set(ip->pop, FRAME_LEFT_FOOTER, "", NULL);
                PQsetdb(dbname);
                sprintf(title, "GLI Alberi [%s]\t Database -> %s on host -> %s",
			version, dbname, PQhost);
                label = strdup(title);
                xv_set(the_frame, FRAME_LABEL, label, NULL);
                update_schema();
	
		break;

	case PANEL_LIST_OP_VALIDATE:
	
		break;

	case PANEL_LIST_OP_DELETE:
		
		break;
	}
	return XV_OK;
}

