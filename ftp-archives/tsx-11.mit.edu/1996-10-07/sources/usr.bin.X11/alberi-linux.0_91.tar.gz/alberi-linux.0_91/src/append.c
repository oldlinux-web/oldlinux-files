
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>

/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "externs.h"

#include "constants.h"


void
append_classname_proc(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
  PortalBuffer *p;
  int i, j, k, g, n, m, t, x, ic,s, count;
  char queryp[8192];
  char entry[20];
  char type[2];
  Canvas_shell the_shell;
  
  if(Debugging)
    PQtracep = 0;
  sprintf(queryp, 

"retrieve portal clases (pg_class.relname) \
where pg_class.relname !~ \"pg_.*\""

	  );

  while((int) xv_get(append_class_dialog->class_list, PANEL_LIST_NROWS))  
     xv_set(append_class_dialog->class_list, 
            PANEL_LIST_DELETE, 0,
            NULL);

  alberi_PQexec("begin");
  alberi_PQexec(queryp);
                      
  alberi_PQexec("fetch all in clases");

  p = PQparray("clases");
  g = PQngroups(p);
  t = 0;

  for(k = 0; k < g; k++) {
    n = PQntuplesGroup(p, k);
    m = PQnfieldsGroup(p, k);

    for(i = 0; i < n; i++) {
      sprintf(entry, "%s", PQgetvalue(p, t + i, 0));
      xv_set(append_class_dialog->class_list, 
	     PANEL_LIST_INSERT, 
	       (int) xv_get(append_class_dialog->class_list, PANEL_LIST_NROWS) ,
	     PANEL_LIST_STRING, 
	       (int) xv_get(append_class_dialog->class_list, PANEL_LIST_NROWS) ,
	       (char *) entry,
	     NULL);
    }
    t += n;
  }
  alberi_PQexec("close clases");
  alberi_PQexec("end");


  if (Debugging)
    PQtracep = 1;

  the_shell = (Canvas_shell) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
  xv_set(append_class_dialog->pop,
	 XV_KEY_DATA, OPER, the_shell,
	 NULL);

  xv_set(append_class_dialog->pop,
	 XV_SHOW, TRUE, 
	 NULL);
}


void
classic_append(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{

  PortalBuffer *p;
  int i, j, k, g, n, m, t, x, ic,s, count;
  char queryp[8192];
  char entry[20];
  char type[2];
  Canvas_shell the_shell;

  if (Debugging) 
    PQtracep = 0;
  sprintf(queryp, 

"retrieve portal clases (pg_class.relname) \
where pg_class.relname !~ \"pg_.*\""

	  );

  while ((int) xv_get(classic_append_class_dialog->class_list, 
		      PANEL_LIST_NROWS))  
    xv_set(classic_append_class_dialog->class_list, 
	   PANEL_LIST_DELETE, 0,
	   NULL);

  alberi_PQexec("begin");
  alberi_PQexec(queryp);
                      
  alberi_PQexec("fetch all in clases");

  p = PQparray("clases");
  g = PQngroups(p);
  t = 0;

  for(k = 0; k < g; k++) {
    n = PQntuplesGroup(p, k);
    m = PQnfieldsGroup(p, k);

    for(i = 0; i < n; i++) {
      sprintf(entry, "%s", PQgetvalue(p, t + i, 0));
      xv_set(classic_append_class_dialog->class_list, 
	     PANEL_LIST_INSERT, 
	       (int) xv_get(classic_append_class_dialog->class_list, 
			    PANEL_LIST_NROWS) ,
	     PANEL_LIST_STRING, 
	       (int) xv_get(classic_append_class_dialog->class_list, 
			    PANEL_LIST_NROWS) , 
	       (char *) entry,
	     NULL);
    }
    t += n;
  }
  alberi_PQexec("close clases");
  alberi_PQexec("end");


  if (Debugging)
    PQtracep = 1;

  the_shell = (Canvas_shell) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
  xv_set(classic_append_class_dialog->pop,
	 XV_KEY_DATA, OPER, the_shell,
	 NULL);

  xv_set(classic_append_class_dialog->pop,
	 XV_SHOW, TRUE, 
	 NULL);

}


