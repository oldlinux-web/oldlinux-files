#include <xview/xview.h>
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/notice.h>

#include "first_ui.h"

extern first_window1_objects *first_window1;

int
alberi_error_handler(obj, avlist)
     Xv_object   obj;
     Attr_avlist avlist;
{
  Attr_attribute *attrs;
  Error_severity severity = ERROR_RECOVERABLE;
  char *err;

  for (attrs = avlist; *attrs; attrs = attr_next(attrs))
    switch (attrs[0]) {
    case ERROR_SEVERITY:
      severity = (Error_severity) attrs[1];
      break;
    }
  
  if ( severity != ERROR_RECOVERABLE ) {
    fprintf(stderr, "%s", xv_error_format(obj, avlist));
    exit(1);
  }

  err = xv_error_format(obj, avlist);
  window_bell( first_window1->textpane3 );
  textsw_insert( first_window1->textpane3, "\n", 1 );
  textsw_insert( first_window1->textpane3, err, strlen( err ) );
  textsw_insert( first_window1->textpane3, "\n", 1 );

  return XV_OK;
}

Notify_value
destroy_func( client, status )
     Notify_client  client;
     Destroy_status status;
{
  if ( status == DESTROY_CHECKING ) {
    int ans = notice_prompt( client, NULL,
			    NOTICE_MESSAGE_STRINGS, "Quit Alberi?", NULL,
			    NOTICE_BUTTON_YES, "No",
			    NOTICE_BUTTON_NO, "Yes",
			    NULL );
    if ( ans == NOTICE_YES )
      notify_veto_destroy( client );
    else
      exit(0);
  }
  else if ( status == DESTROY_CLEANUP )
    return notify_next_destroy_func( client, status );
  else 
    exit(0);
}

int
backend_error( msg )
     char *msg;
{
  window_bell( first_window1->textpane3 );
  xv_set( first_window1->window1, FRAME_LEFT_FOOTER, msg, NULL );
}

int
print_error( msg )
     char *msg;
{
  textsw_insert(first_window1->textpane3, msg, strlen(msg));
}


int
abend( msg )
     char *msg;
{
  fprintf( stderr, "Mortal error: %s\n", msg );
  exit(1);
}
