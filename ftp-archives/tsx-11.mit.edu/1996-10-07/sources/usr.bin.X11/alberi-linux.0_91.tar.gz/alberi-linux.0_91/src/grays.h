
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#define gray1_width 16
#define gray1_height 16

extern short gray1_bits[];

#define gray2_width 16
#define gray2_height 16

extern short gray2_bits[];

#define gray3_width  16
#define gray3_height 16

extern short gray3_bits[];

#define gray4_width 16
#define gray4_height 16

extern short gray4_bits[];

#define gray5_width 16
#define gray5_height 16

extern short gray5_bits[];

#define gray6_width 32
#define gray6_height 32

extern short gray6_bits[];

#define APPImage_width 64
#define APPImage_height 64

extern short APPImage_bits[];

extern Server_image gray1, gray2, gray3, gray4, 
  		    gray5, gray6, APPImage, schema_image;

extern Server_image gray[];

