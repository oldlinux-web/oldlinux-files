
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/textsw.h>
#include <xview/xv_xrect.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "constants.h"
#include "switches.h"
#include "first_ui.h"
#include "append_interface_ui.h"



extern first_window1_objects *first_window1;
extern void update_schema(), insert_in_command_stack();

/*
 * Notify callback function for `attribute_list'.
 */
int
attribute_select(item, string, client_data, op, event)
	Panel_item	item;
	char		*string;
	Xv_opaque	client_data;
	Panel_list_op	op;
	Event		*event;
{
	append_interface_pop_objects	*ip = (append_interface_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
        char *temp, value[8196], *whole_thing;
        int ROWS, row, item_no;
	
	switch(op) {
	case PANEL_LIST_OP_DESELECT:
                xv_set(ip->attribute_value_field, XV_SHOW, FALSE, NULL);
                xv_set(ip->type_message, XV_SHOW, FALSE, NULL);                
	
		break;

	case PANEL_LIST_OP_SELECT:

                /* Strcat the value typed in the text item with the contents of client_data 
                 * PANEL_LIST_CLIENT_DATA for the value.  
                 */
                ROWS = (int) xv_get(ip->attribute_list, PANEL_LIST_NROWS);
                for(row = 0 ; row < ROWS ; row++) { /* list_item selected */
                    if(xv_get(ip->attribute_list, PANEL_LIST_SELECTED, row)) {
                        item_no = row;
                    }
                }
                whole_thing = ((char *) client_data);
                temp = strdup(strstr(whole_thing, "::")); 
                xv_set(ip->type_message, PANEL_LABEL_STRING, temp, PANEL_CLIENT_DATA, item_no, NULL);
                (void) strcpy(value, whole_thing);
                if(!strcmp(temp, whole_thing)) { /* no value */
                   xv_set(ip->attribute_value_field, PANEL_VALUE, "", NULL);
                } else { /* value */
                   value[strlen(whole_thing) - strlen(temp)] = '\0'; /* cut the value out */
                   xv_set(ip->attribute_value_field, PANEL_VALUE, value, NULL);
                }
                xv_set(ip->attribute_value_field, XV_SHOW, TRUE, NULL);
                xv_set(ip->type_message, XV_SHOW, TRUE, NULL);
	
		break;

	case PANEL_LIST_OP_VALIDATE:
	
		break;

	case PANEL_LIST_OP_DELETE:
	
		break;
	}
	return XV_OK;
}

/*
 * Notify callback function for `attribute_value_field'.
 */
Panel_setting
attribute_value_change(item, event)
	Panel_item	item;
	Event		*event;
{
	append_interface_pop_objects	*ip = (append_interface_pop_objects *) xv_get(item, XV_KEY_DATA, INSTANCE);
        int item_list_no;
        char *type, *whole_thing, final[8196];
	char *	value = (char *) xv_get(item, PANEL_VALUE);

        item_list_no = (int) xv_get(ip->type_message, PANEL_CLIENT_DATA);
        whole_thing = strdup((char *) xv_get(ip->attribute_list, PANEL_LIST_CLIENT_DATA, item_list_no));
        type = strdup(strstr(whole_thing, "::"));
        (void) strcpy(final, value);
        (void) strcat(final, type);
        whole_thing = strdup(final);
        xv_set(ip->attribute_list, PANEL_LIST_CLIENT_DATA, item_list_no, whole_thing, NULL);
        
	
	
	return panel_text_notify(item, event);
}

/*
 * Notify callback function for `append_button'.
 */
void
append_tuple_proc(item, event)
     Panel_item      item;
     Event           *event;
{
  append_interface_pop_objects *ip = (append_interface_pop_objects *)
    					xv_get(item, XV_KEY_DATA, INSTANCE);
  char temp[8196], query_buffer[8196],
       temp_q[8196], *type, *whole, *value, t_value[8196];
  int ROWS, row, later_item, first;

  
  temp[0] = '\0';
  later_item = 0;
  first = 1;
  ROWS = (int) xv_get(ip->attribute_list, PANEL_LIST_NROWS);
  for ( row = 0 ; row < ROWS ; row++ ) { /* construct the query */
    whole = strdup((char *) xv_get(ip->attribute_list,
				   PANEL_LIST_CLIENT_DATA, row));
    (void) strcpy(t_value, whole);
    type = strdup(strstr(whole, "::"));
    t_value[strlen(whole) - strlen(type)] = '\0';
    value = strdup(t_value);
    if ( strcmp(whole, type) ) { /* include */
      if ( first ) { /* first item */
	(void) strcpy(temp, "append ");
	(void) strcat(temp, (char *) xv_get(ip->pop, FRAME_LABEL));
	(void) strcat(temp, " (");
	(void) strcat(temp, xv_get(ip->attribute_list, PANEL_LIST_STRING, row));
	(void) strcat(temp, "\"");
	(void) strcat(temp, value);
	(void) strcat(temp, "\"");
	(void) strcat(temp, type);
	first = 0;
      }
      else { /* not first append a comma */
	(void) strcat(temp, ", ");
	(void) strcat(temp, xv_get(ip->attribute_list, PANEL_LIST_STRING, row));
	(void) strcat(temp, "\"");
	(void) strcat(temp, value);
	(void) strcat(temp, "\"");
	(void) strcat(temp, type);
      }
    }
  }
  if ( !first )
    strcat(temp, ")");
  
  strcpy(query_buffer, temp);
  
  xv_set(ip->pop, FRAME_LEFT_FOOTER, "Append submitted", NULL);

  if ( Verbose )
    textsw_insert(first_window1->textpane3, "\n", 1);
  
  strcpy(temp_q, clean_query(query_buffer));
 
  if ( Verbose ) {
    textsw_insert(first_window1->textpane3,
		  "Query sent to Postgres Backend:\n", 32);
    textsw_insert(first_window1->textpane3, temp_q, strlen(temp_q));
    textsw_insert(first_window1->textpane3, "\n", 1); 
  }
 
  if ( handle_execution(temp_q, first_window1) == 1)
    backend_error( "Postgres backend returned error" );
  else { 
    xv_set(first_window1->window1, FRAME_LEFT_FOOTER, "No errors", NULL); 
    if ( temp_q[0] ) {
      insert_in_command_stack(temp_q);
                  
      for(row = 0 ; row < ROWS ; row++) { /* cut the values from the client_datas */
	whole = strdup((char *) xv_get(ip->attribute_list, PANEL_LIST_CLIENT_DATA, row));
	type = strdup(strstr(whole, "::"));
	xv_set(ip->attribute_list, PANEL_LIST_CLIENT_DATA, row, type, NULL);
      }
    } 
  }

  if ((char *) strstr(temp_q, "create") || 
      (char *) strstr(temp_q, "retrieve into") || 
      (char *) strstr(temp_q, "addattr"))
    update_schema();

  bzero(query_buffer, strlen(query_buffer));

 
  xv_set(ip->attribute_value_field, XV_SHOW, FALSE, NULL);
  xv_set(ip->type_message, XV_SHOW, FALSE, NULL);
  xv_set(ip->attribute_value_field, PANEL_VALUE, "", NULL);
  
  for ( row = 0 ; row < ROWS ; row++ ) { 
                   
    type = strdup(strstr((char *) xv_get(ip->attribute_list,
					 PANEL_LIST_CLIENT_DATA, row), "::"));
    xv_set(ip->attribute_list, 
	   PANEL_LIST_CLIENT_DATA, row, type,
	   NULL);
  } 
}
