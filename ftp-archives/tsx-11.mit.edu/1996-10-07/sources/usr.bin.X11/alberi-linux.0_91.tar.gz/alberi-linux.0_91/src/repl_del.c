/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/textsw.h>
#include <xview/notice.h>
#include <xview/panel.h>

/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "externs.h"

#include "constants.h"
#include "grays.h"
#include "funcs.h"

void
delete_classname_proc(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
  PortalBuffer *p;
  int i, j, k, g, n, m, t, x, ic,s, count;
  char queryp[8192];
  char entry[20];
  char type[2];
  Canvas_shell the_shell;

  if (Debugging) 
    PQtracep = 0;
  sprintf(queryp, 

"retrieve portal clases (pg_class.relname) \
where pg_class.relname !~ \"pg_.*\""

	  );

  while((int) xv_get(delete_instances_dialog->class_list, PANEL_LIST_NROWS))  
    xv_set(delete_instances_dialog->class_list, 
	   PANEL_LIST_DELETE, 0,
	   NULL);

  alberi_PQexec("begin");
  alberi_PQexec(queryp);
                      
  alberi_PQexec("fetch all in clases");

  p = PQparray("clases");
  g = PQngroups(p);
  t = 0;
  
  for(k = 0; k < g; k++) {
    n = PQntuplesGroup(p, k);
    m = PQnfieldsGroup(p, k);
    
    for(i = 0; i < n; i++) {
      sprintf(entry, "%s", PQgetvalue(p, t + i, 0));
      xv_set(delete_instances_dialog->class_list, 
	     PANEL_LIST_INSERT, 
	       (int) xv_get(delete_instances_dialog->class_list,
			    PANEL_LIST_NROWS) ,
	     PANEL_LIST_STRING, 
	       (int) xv_get(delete_instances_dialog->class_list,
			    PANEL_LIST_NROWS) , 
	       (char *) entry,
	     NULL);
    }
    t += n;
  }
  alberi_PQexec("close clases");
  alberi_PQexec("end");


  if (Debugging)
    PQtracep = 1;

  the_shell = (Canvas_shell) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
  xv_set(delete_instances_dialog->pop,
	 XV_KEY_DATA, OPER, the_shell,
	 XV_KEY_DATA, FUNC, classes,
	 NULL);

  xv_set(delete_instances_dialog->pop,
	 XV_SHOW, TRUE, 
	 NULL);
}


void
classic_delete(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{

  PortalBuffer *p;
  int i, j, k, g, n, m, t, x, ic,s, count;
  char queryp[8192];
  char entry[20];
  char type[2];
  Canvas_shell the_shell;

  if (Debugging) 
    PQtracep = 0;
  sprintf(queryp, 

"retrieve portal clases (pg_class.relname) \
where pg_class.relname !~ \"pg_.*\""

	  );

  while((int) xv_get(classic_delete_class_dialog->class_list, 
		     PANEL_LIST_NROWS))  
    xv_set(classic_delete_class_dialog->class_list, 
	   PANEL_LIST_DELETE, 0,
	   NULL);

  alberi_PQexec("begin");
  alberi_PQexec(queryp);
                      
  alberi_PQexec("fetch all in clases");

  p = PQparray("clases");
  g = PQngroups(p);
  t = 0;

  for(k = 0; k < g; k++) {
    n = PQntuplesGroup(p, k);
    m = PQnfieldsGroup(p, k);
    
    for(i = 0; i < n; i++) {
      sprintf(entry, "%s", PQgetvalue(p, t + i, 0));
      xv_set(classic_delete_class_dialog->class_list, 
	     PANEL_LIST_INSERT, 
	       (int) xv_get(classic_delete_class_dialog->class_list, 
			    PANEL_LIST_NROWS) ,
	     PANEL_LIST_STRING,
	       (int) xv_get(classic_delete_class_dialog->class_list, 
			    PANEL_LIST_NROWS) , 
	       (char *) entry,
	     NULL);
    }
    t += n;
  }
  alberi_PQexec("close clases");
  alberi_PQexec("end");


  if (Debugging)
    PQtracep = 1;

  the_shell = (Canvas_shell) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
  xv_set(classic_delete_class_dialog->pop,
	 XV_KEY_DATA, OPER, the_shell,
	 NULL);

  xv_set(classic_delete_class_dialog->pop,
	 XV_SHOW, TRUE, 
	 NULL);

}

void
nuke_that_class_proc(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
  Rectobj class;
  char *classname;
  int sure;
  PortalBuffer *p;
  int i, j, k, g, n, m, t, x, s;
  char *class_name, create_ahead[32];
  char temp[8196], query_buffer[8196], temp_q[8196];

  class = (Rectobj) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
  classname = strdup((char *) xv_get(class, DRAWTEXT_STRING));
  sure = notice_prompt(marco, NULL,
		       NOTICE_MESSAGE_STRINGS, 
		         "Do you really want to delete this class?", NULL,
		       NOTICE_BUTTON_YES, "No",
		       NOTICE_BUTTON_NO, "Yes",
		       NULL);

  if (!sure) {

    (void) strcpy(temp, "destroy ");
    (void) strcat(temp, classname);
    strcpy(query_buffer, temp);
     
    xv_set(marco, 
	   FRAME_LEFT_FOOTER, "Destroy...",  
	   FRAME_RIGHT_FOOTER, "Submmited",
	   NULL);
 
    if ( Verbose )
      textsw_insert(first_window1->textpane3, "\n", 1);
                                    
    strcpy(temp_q, clean_query(query_buffer));
 
    if ( Verbose ) {
      textsw_insert(first_window1->textpane3, 
		    "Query sent to Postgres Backend:\n", 32);
      textsw_insert(first_window1->textpane3, temp_q, strlen(temp_q));
      textsw_insert(first_window1->textpane3, "\n", 1); 
    }
 
    if ((x = handle_execution(temp_q, first_window1)) == 1)
      backend_error( "Postgres backend returned error" );
    else {
      xv_set(first_window1->window1, FRAME_LEFT_FOOTER, "No errors", NULL); 
      bzero(query_buffer, strlen(query_buffer)); /* and query_buffer   */
      if ( temp_q[0] )
	insert_in_command_stack(temp_q); 
    }

    if((char *) strstr(temp_q, "create") || 
       (char *) strstr(temp_q, "retrieve into") || 
       (char *) strstr(temp_q, "addattr") ||
       (char *) strstr(temp_q, "rename") ||
       (char *) strstr(temp_q, "destroy")) {
 
      /* update_schema() */;
			 }

    if(!x) {
      xv_destroy(class);
      xv_destroy(menu);
    }

    
  }

}


void
classic_replace(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{

  PortalBuffer *p;
  int i, j, k, g, n, m, t, x, ic,s, count;
  char queryp[8192];
  char entry[20];
  char type[2];
  Canvas_shell the_shell;

  if (Debugging) 
    PQtracep = 0;
  sprintf(queryp, 

"retrieve portal clases (pg_class.relname) \
where pg_class.relname !~ \"pg_.*\""

	  );

  while ((int) xv_get(classic_replace_class_dialog->class_list, 
		      PANEL_LIST_NROWS))  
    xv_set(classic_replace_class_dialog->class_list, 
	   PANEL_LIST_DELETE, 0,
	   NULL);

  alberi_PQexec("begin");
  alberi_PQexec(queryp);
                      
  alberi_PQexec("fetch all in clases");

  p = PQparray("clases");
  g = PQngroups(p);
  t = 0;

  for(k = 0; k < g; k++) {
    n = PQntuplesGroup(p, k);
    m = PQnfieldsGroup(p, k);

    for(i = 0; i < n; i++) {
      sprintf(entry, "%s", PQgetvalue(p, t + i, 0));
      xv_set(classic_replace_class_dialog->class_list, 
	     PANEL_LIST_INSERT, 
	       (int) xv_get(classic_replace_class_dialog->class_list, 
			    PANEL_LIST_NROWS) ,
	     PANEL_LIST_STRING, 
	       (int) xv_get(classic_replace_class_dialog->class_list, 
			    PANEL_LIST_NROWS) , 
	       (char *) entry,
	     NULL);
    }
    t += n;
  }
  alberi_PQexec("close clases");
  alberi_PQexec("end");


  if (Debugging)
    PQtracep = 1;

  the_shell = (Canvas_shell) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
  xv_set(classic_replace_class_dialog->pop,
	 XV_KEY_DATA, OPER, the_shell,
	 NULL);

  xv_set(classic_replace_class_dialog->pop,
	 XV_SHOW, TRUE, 
	 NULL);

}




void
replace_classname_proc(menu, menu_item)
     Menu menu;
     Menu_item menu_item;
{
  PortalBuffer *p;
  int i, j, k, g, n, m, t, x, ic,s, count;
  char queryp[8192];
  char entry[20];
  char type[2];
  Canvas_shell the_shell;

  if(Debugging) 
    PQtracep = 0;
  sprintf(queryp, 

"retrieve portal clases (pg_class.relname) \
where pg_class.relname !~ \"pg_.*\""

	  );

  while((int) xv_get(delete_replace_instances_dialog->class_list,
		     PANEL_LIST_NROWS))  
    xv_set(delete_replace_instances_dialog->class_list, 
	   PANEL_LIST_DELETE, 0,
	   NULL);

  alberi_PQexec("begin");
  alberi_PQexec(queryp);
                      
  alberi_PQexec("fetch all in clases");

  p = PQparray("clases");
  g = PQngroups(p);
  t = 0;

  for(k = 0; k < g; k++) {
    n = PQntuplesGroup(p, k);
    m = PQnfieldsGroup(p, k);

    for(i = 0; i < n; i++) {
      sprintf(entry, "%s", PQgetvalue(p, t + i, 0));
      xv_set(delete_replace_instances_dialog->class_list, 
	     PANEL_LIST_INSERT, 
	       (int) xv_get(delete_replace_instances_dialog->class_list, 
			    PANEL_LIST_NROWS) ,
	     PANEL_LIST_STRING, 
	       (int) xv_get(delete_replace_instances_dialog->class_list, 
			    PANEL_LIST_NROWS) , 
	       (char *) entry,
	     NULL);
    }
    t += n;
  }
  alberi_PQexec("close clases");
  alberi_PQexec("end");


  if (Debugging)
    PQtracep = 1;

  the_shell = (Canvas_shell) xv_get(menu, XV_KEY_DATA, MENU_OWNER);
  xv_set(delete_replace_instances_dialog->pop,
	 XV_KEY_DATA, OPER, the_shell,
	 XV_KEY_DATA, FUNC, classes,
	 NULL);

  xv_set(delete_replace_instances_dialog->pop,
	 XV_SHOW, TRUE, 
	 NULL);
}
