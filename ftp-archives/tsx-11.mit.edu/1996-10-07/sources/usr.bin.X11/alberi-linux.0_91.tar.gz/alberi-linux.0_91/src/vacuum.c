
 
/***************************************************************************
 *                                                                         *
 * Alberi:  Graphical Language Interface for POSTGRES                      *
 *                                                                         *
 * Copyright (c) 1992, 1993 The University of Georgia Research             *
 *                          Foundation, Inc.                               *
 *                                                                         *
 ***************************************************************************
 *                                                                         *
 * Designer and Programmer:  Ruben Robles                                  *
 * Email:  ruben@pollux.cs.uga.edu or rubenr3@aol.com or                   *
 *         rubenr3@psi.com@aol.com                                         *
 *                                                                         *
 * Modified by:		K.J. Kochut                                        *
 *			Department of Computer Science                     *
 *			University of Georgia                              *
 *			Athens, GA 30602                                   *
 *                                                                         *
 * Send comments/fixes/improvements/modifications to:                      *
 *                                                                         *
 *                     kochut@cs.uga.edu                                   *
 *                                                                         *
 ***************************************************************************/

#include <xview/xview.h>
#include <xview/panel.h>
#include <xview/notice.h>

/* slingshot headers */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/tree.h>
#include <sspkg/array.h>
#include <sspkg/list.h>

#include <tmp/c.h>
#include <tmp/libpq-fe.h>

#include "all_ui.h"
#include "externs.h"

/*
 * Notify callback function for `vacuum_button'.
 */
void
vacuum_database(item, event)
     Panel_item      item;
     Event          *event;
{
  first_window1_objects *ip = (first_window1_objects *)
    				xv_get(item, XV_KEY_DATA, INSTANCE);
  char query_buffer[8196], temp_q[8196];
  int ans;
        
  ans = notice_prompt( ip->window1, NULL,
		       NOTICE_MESSAGE_STRINGS,
		         "Do you really want to vacuum now?", 
		         NULL,
		       NOTICE_BUTTON_YES, "Yes",
		       NOTICE_BUTTON_NO, "No",
		       NULL );
  if ( ans == NOTICE_YES ) {

    strcpy( query_buffer, "vacuum" );

    if ( Verbose )
      textsw_insert( first_window1->textpane3, "\n", 1 );

    strcpy( temp_q, clean_query( query_buffer ) );

    if ( Verbose ) {
      textsw_insert( first_window1->textpane3,
		    "Query sent to Postgres Backend:\n", 32 );
      textsw_insert( first_window1->textpane3, temp_q, strlen( temp_q ) );
      textsw_insert( first_window1->textpane3, "\n", 1 ); 
    }

    if ( ( handle_execution(temp_q, first_window1 ) ) == 1 )
      backend_error( "Postgres backend returned error" );
    else
      xv_set( first_window1->window1, FRAME_LEFT_FOOTER, "No errors",
	      NULL);
                     /* Clear query buffer */
    bzero( query_buffer, strlen( query_buffer ) ); /* query_buffer[0] = 0; */
  }

}
