/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef lint
#ifdef sccs
static char     sccsid[] = "@(#)rectobj_data.c 1.5 91/05/06";
#endif
#endif

#include <sspkg/rectobj.h>
#include "r_impl.h"

Pkg_private int rectobj_init();
Pkg_private Xv_opaque rectobj_set_avlist();
Pkg_private Xv_opaque rectobj_get_attr();
Pkg_private int rectobj_destroy();

Xv_pkg          rectobj_pkg = {
	"Rectobj",
	ATTR_RECTOBJ,
	sizeof(Rectobj_struct),
	&xv_generic_pkg,
	rectobj_init,
	rectobj_set_avlist,
	rectobj_get_attr,
	rectobj_destroy,
	NULL
};
