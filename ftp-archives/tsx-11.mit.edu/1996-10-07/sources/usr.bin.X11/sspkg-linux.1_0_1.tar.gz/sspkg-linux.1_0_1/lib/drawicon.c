/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef lint
#ifdef sccs
static char     sccsid[] = "@(#)drawicon.c 1.14 91/05/06";
#endif
#endif

#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <xview/rect.h>
#include <xview/xv_xrect.h>
#include <xview/win_input.h>
#include <string.h>
#include <sspkg/drawobj.h>
#include "do_impl.h"
#include "r_impl.h"
#include <sspkg/canshell.h>

Pkg_private int 	drawicon_init();
Pkg_private Xv_opaque	drawicon_set_avlist();
Pkg_private Xv_opaque	drawicon_get_attr();
Pkg_private int 	drawicon_destroy();

Rectobj		drawicon_map_event_proc();
extern 	int	start_dbl_click();
void 		drawicon_set_geometry_proc();
void		drawicon_manage_child_proc();


/*ARGSUSED*/
Pkg_private int
drawicon_init(parent, drawicon_public, avlist)
	Xv_opaque	parent;
	Drawicon	drawicon_public;
	Attr_avlist	avlist;
{
	Drawicon_info	*dinfo;
	Rectobj_info 	*rinfo = RECTOBJ_PRIVATE(drawicon_public);
	Drawicon_struct	*drawicon_object;

	dinfo = xv_alloc(Drawicon_info);
	dinfo->public_self = drawicon_public;
	drawicon_object = (Drawicon_struct*) drawicon_public;
	drawicon_object->private_data = (Xv_opaque) dinfo;

	rinfo->selectable = TRUE;
	rinfo->map_event_proc = drawicon_map_event_proc;
	rinfo->event_proc = start_dbl_click;
	rinfo->set_geometry_proc = drawicon_set_geometry_proc;
	rinfo->manage_child_proc = drawicon_manage_child_proc;

	dinfo->text = xv_create(0, DRAWTEXT, 
			RECTOBJ_SELECTABLE, FALSE,
			XV_NULL);

	dinfo->icon = xv_create(0, DRAWIMAGE, 
			RECTOBJ_SELECTABLE, FALSE,
			XV_NULL);

	return(XV_OK);
}


Pkg_private Xv_opaque
drawicon_set_avlist(drawicon_public, avlist)
	Drawicon		drawicon_public;
	register Attr_avlist	avlist;
{
        register Drawobj_attr attr;
        register Drawicon_info *dinfo = DRAWICON_PRIVATE(drawicon_public);
	Rectobj_info	*rinfo = RECTOBJ_PRIVATE(drawicon_public);
	Shared_info	*sh_info = rinfo->shared_info;
	int		manage_self = FALSE;

	if(*avlist != XV_END_CREATE) {
		Xv_opaque set_result;
		set_result =
		  xv_super_set_avlist(drawicon_public, &drawicon_pkg, avlist);
		if(set_result != XV_OK) {
			rectobj_reset_set_info(drawicon_public);
			return(set_result);
		}
	}

	while (attr = (Drawobj_attr) * avlist++)
	  switch (attr) {

		case DRAWICON_TEXT:
		case DRAWICON_ICON:
			/* get only */
			avlist = attr_skip(attr, avlist);
			break;

		case DRAWIMAGE_SVRIMAGE:
		case DRAWIMAGE_HIGHLIGHT_IMAGE:
		case DRAWICON_ICON_COLOR:
			xv_set(dinfo->icon, attr, *avlist, XV_NULL);
			avlist = attr_skip(attr, avlist);
			manage_self= TRUE;
			break;

		case DRAWTEXT_STRING:
		case DRAWTEXT_FONT:
		case DRAWICON_TEXT_COLOR:
			xv_set(dinfo->text, attr, *avlist, XV_NULL);
			avlist = attr_skip(attr, avlist);
			manage_self= TRUE;
			break;

		case RECTOBJ_BACKGROUND_COLOR:
		case RECTOBJ_FOREGROUND_COLOR:
			xv_set(dinfo->text, attr, *avlist, XV_NULL);
			xv_set(dinfo->icon, attr, *avlist, XV_NULL);
			avlist = attr_skip(attr, avlist);
			break;

		case RECTOBJ_SELECTED: {
			Rectobj_info *dtinfo = RECTOBJ_PRIVATE(dinfo->text);
			Rectobj_info *diinfo = RECTOBJ_PRIVATE(dinfo->icon);
			
			dtinfo->selected = *avlist;
			diinfo->selected = *avlist;

			avlist = attr_skip(attr, avlist);
			}
			break;

		case XV_END_CREATE: {
        		Rectobj_info    *tinfo = RECTOBJ_PRIVATE(dinfo->text);
		        Rectobj_info    *iinfo = RECTOBJ_PRIVATE(dinfo->icon);

			xv_set(dinfo->text, 
				RECTOBJ_PARENT, drawicon_public, 
				XV_NULL);
			xv_set(dinfo->icon, 
				RECTOBJ_PARENT, drawicon_public, 
				XV_NULL);

			rinfo->rect.r_width = MAX(tinfo->rect.r_width, 
					iinfo->rect.r_width);
			rinfo->rect.r_height= tinfo->rect.r_height + 
					iinfo->rect.r_height + 1;
			/* 
			 * Because rinfo->rect is changed, rectobj_finish_set
			 * will recognize this and call the geometry functions
			 */
			}
			break;

		default:
			avlist = attr_skip(attr, avlist);

	  }

	rectobj_finish_set(drawicon_public);
	return(XV_SET_DONE);
}


/*ARGSUSED*/
Pkg_private Xv_opaque
drawicon_get_attr(drawicon_public, status, which_attr, avlist)
	Drawicon		drawicon_public;
	int		*status;
	register Attr_attribute which_attr;
	Attr_avlist	avlist;
{
	Drawicon_info  *dinfo = DRAWICON_PRIVATE(drawicon_public);

	switch (which_attr) {

		case DRAWICON_TEXT:
			return (Xv_opaque) dinfo->text;

		case DRAWICON_ICON:
			return (Xv_opaque) dinfo->icon;

		case DRAWIMAGE_SVRIMAGE:
		case DRAWIMAGE_HIGHLIGHT_IMAGE:
		case DRAWICON_ICON_COLOR:
			return (Xv_opaque) xv_get(dinfo->icon, which_attr, 
				XV_NULL);

		case DRAWTEXT_STRING:
		case DRAWTEXT_FONT:
		case DRAWICON_TEXT_COLOR:
			return (Xv_opaque) xv_get(dinfo->text, which_attr, 
				XV_NULL);

		default:
			*status = XV_ERROR;
			return (Xv_opaque) 0;
	}
}

/*ARGSUSED*/
Pkg_private int
drawicon_destroy(drawicon_public, status)
	Drawicon		drawicon_public;
	Destroy_status	status;
{
	Drawicon_info	*dinfo = DRAWICON_PRIVATE(drawicon_public);
	Rectobj_info *rinfo = RECTOBJ_PRIVATE(drawicon_public);

	if ((status == DESTROY_CHECKING) || (status == DESTROY_SAVE_YOURSELF))
		return XV_OK;

	free(dinfo);
	return XV_OK;
}


Rectobj
drawicon_map_event_proc(rectobj, event)
        Rectobj         rectobj;
        Event           *event;
{
	Drawicon_info	*dinfo = DRAWICON_PRIVATE(rectobj);
        Rectobj_info    *rinfo = RECTOBJ_PRIVATE(rectobj);
        Rectobj         return_val;
	Rectobj_info	*tmp;

        if(rinfo->painted == FALSE)
                return 0;

	tmp = RECTOBJ_PRIVATE(dinfo->text);
	if(rect_includespoint(&tmp->rect, event_x(event), event_y(event)))
		return rectobj;

	tmp = RECTOBJ_PRIVATE(dinfo->icon);
	if(rect_includespoint(&tmp->rect, event_x(event), event_y(event)))
		return rectobj;
	
        return 0;
}

void
drawicon_set_geometry_proc(drawicon, newrect, oldrect)
	Drawicon	drawicon;
	Rect		*newrect;
	Rect		*oldrect;
{
	Drawicon_info	*dinfo = DRAWICON_PRIVATE(drawicon);
        Rectobj_info    *rinfo = RECTOBJ_PRIVATE(drawicon);
        Rectobj_info    *child_rinfo;
	Rect		irect;
	Rect		trect;
	int center_x;

/*
	xv_set(drawicon_public, 
		XV_WIDTH,  MAX(	xv_get(dinfo->icon, XV_WIDTH), 
				xv_get(dinfo->text, XV_WIDTH)),
		XV_HEIGHT, 	xv_get(dinfo->icon, XV_HEIGHT) +
				xv_get(dinfo->text, XV_HEIGHT) + 1,
		XV_NULL);
*/

	center_x = rinfo->rect.r_width/2 + rinfo->rect.r_left;

	child_rinfo = RECTOBJ_PRIVATE(dinfo->icon);
	irect = child_rinfo->rect;
	irect.r_left = center_x - child_rinfo->rect.r_width/2;
	irect.r_top = rinfo->rect.r_top;
	rectobj_set_geometry(dinfo->icon, &irect);

	child_rinfo = RECTOBJ_PRIVATE(dinfo->text);
	trect = child_rinfo->rect;
	trect.r_left = center_x - child_rinfo->rect.r_width/2;
	trect.r_top = rinfo->rect.r_top + irect.r_height + 1;
	rectobj_set_geometry(dinfo->text, &trect);
}


void
drawicon_manage_child_proc(drawicon, child, child_new_rect, child_old_rect)
        Rectobj drawicon;
        Rectobj child;
        Rect    *child_new_rect;
        Rect    *child_old_rect;
{
	Drawicon_info	*dinfo = DRAWICON_PRIVATE(drawicon);
        Rectobj_info    *rinfo = RECTOBJ_PRIVATE(drawicon);
        Rectobj_info    *tinfo = RECTOBJ_PRIVATE(dinfo->text);
        Rectobj_info    *iinfo = RECTOBJ_PRIVATE(dinfo->icon);
	Rect		rect;

	rect.r_width = MAX(tinfo->rect.r_width, iinfo->rect.r_width);
	rect.r_height= tinfo->rect.r_height + iinfo->rect.r_height + 1;
	rect.r_left= rinfo->rect.r_left;
	rect.r_top = rinfo->rect.r_top;

	if( (rinfo->rect.r_width != rect.r_width) ||
	    (rinfo->rect.r_height!= rect.r_height) )
		rectobj_geometry_manage(drawicon, &rect);
	else
		drawicon_set_geometry_proc(drawicon, &rect, NULL);
}

