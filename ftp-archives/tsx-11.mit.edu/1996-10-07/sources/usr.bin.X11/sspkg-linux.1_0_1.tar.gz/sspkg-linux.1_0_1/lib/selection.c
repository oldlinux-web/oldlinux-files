/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef lint
#ifdef sccs
static char     sccsid[] = "@(#)selection.c 1.6 91/05/06";
#endif
#endif

#include <sspkg/rectobj.h>

Rectobj_list	*selected_list;
int		num_selected = 0;

Rectobj_list *
get_selected_list()
{
	return(selected_list);
}

void
add_to_selected_list(new)
	Rectobj new;
{
	Rectobj_list *new_node;
	/* Warning: no checking if it is already on the list */

	new_node = xv_alloc(Rectobj_list);
	new_node->handle = (void*)new;
	selected_list = (Rectobj_list*) list_concat(selected_list, new_node);
	num_selected++;
}

void
del_from_selected_list(rectobj)
	Rectobj rectobj;
{
	Rectobj_list *node;

	/* Warning: no error if not on list */
	if(node = list_find(selected_list, rectobj))
	  selected_list = (Rectobj_list*) list_first( list_delete_node(node) );
	num_selected--;
}

void
clear_selection(new)
	Rectobj new;
{
#ifdef beta1_0bug
	Rectobj rectobj;
	Rectobj_list *node;

	node = (Rectobj_list*) list_first(selected_list);
	while(node) {
		rectobj = RECTOBJ_LIST_HANDLE(node);
		node = (Rectobj_list*) list_delete_node(node);
		xv_set(rectobj, RECTOBJ_SELECTED, FALSE,
			XV_NULL);
	}
#else
	while(selected_list)
		xv_set(RECTOBJ_LIST_HANDLE(selected_list),
			RECTOBJ_SELECTED, FALSE,
			NULL);

#endif
	if(new) 
		xv_set(new, RECTOBJ_SELECTED, TRUE, 
			XV_NULL);
}

