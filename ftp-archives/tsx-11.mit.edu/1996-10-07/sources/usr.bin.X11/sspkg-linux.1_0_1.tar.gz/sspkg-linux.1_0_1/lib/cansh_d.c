/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef lint
#ifdef sccs
static char     sccsid[] = "@(#)canshell_data.c 1.6 91/05/06";
#endif
#endif

#include <sspkg/canshell.h>
#include "canshell_impl.h"

Pkg_private int 	canvas_shell_init();
Pkg_private Xv_opaque	canvas_shell_set_avlist();
Pkg_private Xv_opaque	canvas_shell_get_attr();
Pkg_private int 	canvas_shell_destroy();

Xv_pkg canvas_shell_pkg = {
	"CanvasShell", 
	ATTR_CANVAS_SHELL,
	sizeof(Canvas_shell_struct),
	&xv_canvas_pkg,
	canvas_shell_init,
	canvas_shell_set_avlist,
	canvas_shell_get_attr,
	canvas_shell_destroy,
	NULL
};
