/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef CANVAS_SHELL_IMPL_H
#define CANVAS_SHELL_IMPL_H

/* @(#)canshell_impl.h 1.13 91/05/06 */

#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/list.h>
#include "r_impl.h"

typedef struct canvas_shell_info {
	Rectobj_info	rectobj_info;	/* must be first for dual inheritance */
	Shared_info	shared_info;
	Rect		repaint_rect;
	int		repaint_clear;
	Listnode	listnode;	/* attach to list of all canvas shells*/
	int		delay_repaint;
	Pixmap		batch_pixmap;
} Canvas_shell_info;

#define CANVAS_SHELL_PRIVATE(canvas_shell)	\
		XV_PRIVATE(Canvas_shell_info, Canvas_shell_struct, canvas_shell)
#define CANVAS_SHELL_PUBLIC(canvas_shell_info)	\
		(Canvas_shell)(canvas_shell_info->rectobj_info.listnode.handle)

#endif

