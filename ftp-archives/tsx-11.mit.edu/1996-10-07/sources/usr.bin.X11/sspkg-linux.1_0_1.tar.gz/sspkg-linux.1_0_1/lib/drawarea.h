/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */


/*
  @(#)SSM2 drawarea.h 1.4 91/05/06 
*/

/***********************************************************************
 *
 *	stuff for drawarea package
 *
 ***********************************************************************/


#ifndef _drawarea_h
#define _drawarea_h


typedef double DCoord;
typedef short  SCoord;

typedef struct dpoint {
  DCoord x, y;
} DPoint;

typedef struct dd_line_data {
  DCoord x1,y1,x2,y2;
} Dd_Line_Data;

typedef struct dd_arc_data {
  DCoord x,y,width, height, start, stop;
} Dd_Arc_Data;

typedef struct dd_rect_data {
  DCoord x,y,width, height;
} Dd_Rect_Data;

typedef struct dd_string_data {
  DCoord x,y;
  int length;
  char chars[1];/* embeded string trick (watch out ) */
} Dd_String_Data;

typedef struct dd_poly_data {
  int shape, mode, npoints;
  DPoint points[1];   /* embedded array (careful) */
} Dd_Poly_Data;

typedef struct ds_line_data {
  SCoord x1,y1,x2,y2;
} Ds_Line_Data;

typedef struct ds_arc_data {
  SCoord x,y,width, height, start, stop;
} Ds_Arc_Data;

typedef struct ds_rect_data {
  SCoord x,y,width, height;
} Ds_Rect_Data;

typedef struct ds_string_data {
  SCoord x,y;
  int length;
  char chars[1];/* embeded string trick (watch out ) */
} Ds_String_Data;

typedef struct ds_poly_data {
  int shape, mode, npoints;
  XPoint points[1];   /* embedded array (careful) */
} Ds_Poly_Data;

typedef struct dl_gc_data {
  enum Gc_Data_Type 
    { 
      Gc_LineStyle, 	Gc_LineWidth, 
      Gc_Color,		Gc_Tile, 
      Gc_FillStyle, 	Gc_Font,
      Gc_Stipple
    } type;

  union {
    int linestylewidth[2];
    int color;
    int fillstyle;
    XID font_xid;
    Pixmap pixmap;
  } data;
} Dl_Gc_Data;

typedef struct dl_interp {
  double x_m, x_b,
         y_m, y_b;
} Dl_Interp;

typedef struct dl_drawargs {
  Display * dpy;	/* display to draw onto 		*/
  XID win_xid;		/* drawable to draw onto 		*/
  GC gc;		/* our graphics context 		*/
  Rect * rect;		/* size of our bounding box		*/
  caddr_t data;		/* pointer to function specific data 	*/
  Dl_Interp * dl_interp;/* interpolation for x and y doubles	*/
  Dl_Limits * dl_limits;/* limits of drawing in last pass
			   through scaled portion of display
			   list					*/
} Dl_Drawargs;

#define xd2X(d, x)	((d)->x_m * (x) + (d)->x_b)
#define yd2X(d, y)	((d)->y_m * (y) + (d)->y_b)

#define wv2X(r, n)	((int)((double)(n)*(double)((r)->r_width-1) * .0001))
#define hv2X(r, n)	((int)((double)(n)*(double)((r)->r_height-1) * .0001))
#define xv2X(r, x)	((int)(wv2X((r),(x))+(r)->r_left))
#define yv2X(r, y)	((int)(hv2X((r),(y))+(r)->r_top))

#define wX2v(r, n)	(((double)(n)*10000./(double)((r)->r_width-1)))
#define hX2v(r, n)	(((double)(n)*10000./(double)((r)->r_height-1)))
#define xX2v(r, x)	((wX2v((r),(x) - (r)->r_left)))
#define yX2v(r, y)	((hX2v((r),(y) - (r)->r_top)))

typedef int VCoord;

#endif /* _drawarea_h */
