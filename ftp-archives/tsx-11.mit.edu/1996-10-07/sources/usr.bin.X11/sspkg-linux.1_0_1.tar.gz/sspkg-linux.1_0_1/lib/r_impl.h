/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef RECTOBJ_IMPL_DEFINED
#define RECTOBJ_IMPL_DEFINED

/* @(#)r_impl.h 1.21 91/05/06 */

#include <sspkg/rectobj.h>
#include <xview/rect.h>
#include <xview/cursor.h>
#include <xview/openmenu.h>
#include "sh_info.h"


typedef struct rectobj_info {
	Rectobj_list   *children;
	Rectobj_list	listnode;	/* link to siblings */
	Rectobj         parent;

	int             painted;
	int             selectable;
	int             selected;
	Rectobj_state	state;
	Rect            rect;
	Shared_info	*shared_info;
	int		fg_color;
	int		bg_color;
	void		*layout_data;

	/* Class oriented fields -- these may be moved into a struct */

	void            (*paint_proc) ();
	int		(*event_proc) ();
	Rectobj		(*map_event_proc) ();

	void		(*set_geometry_proc)();
	void		(*add_child_proc)();
	void		(*del_child_proc)();
	void		(*manage_child_proc)();/* was geometry_manage_proc */

	/* user oriented data */
	int		draggable;
	int		accept_drop;
	void		(*drop_proc);
	int		accept_child_drop;
	void		(*child_drop_proc);
	Xv_Cursor	drag_cursor;
	Menu		menu;
	int		inherit_menu;
	void		(*dbl_click_proc);

	/* for while in context of xv_set */
	Rect		old_rect;
	Rectobj		previous_parent;
	int		repaint;
	int		invocation_level;
	int		no_manage_child;

} Rectobj_info;

extern Menu rectobj_get_menu();

/* values returned from do_dbl_click_drag - should be public? */
#define	DO_DBL_NOTHING	0
#define	DO_DBL_CLICK	1
#define	DO_DBL_DRAG	2

#define rectcmp(_r1, _r2) (memcmp((char*)(_r1), (char*)(_r2), sizeof(Rect)))

#define RECTOBJ_PRIVATE(rectobj)	XV_PRIVATE(Rectobj_info, Rectobj_struct, rectobj)
#define RECTOBJ_PUBLIC(rectobj_info)	((rectobj_info)->listnode.handle)
#endif
