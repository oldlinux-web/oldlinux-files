/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef lint
#ifdef sccs
static char     sccsid[] = "@(#)drawrect.c 1.13 91/05/06";
#endif
#endif

#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <xview/rect.h>
#include <xview/xv_xrect.h>
#include <xview/win_input.h>
#include <sspkg/drawobj.h>
#include "do_impl.h"
#include "r_impl.h"
#include <sspkg/canshell.h>

Pkg_private int 	drawrect_init();
Pkg_private Xv_opaque	drawrect_set_avlist();
Pkg_private Xv_opaque	drawrect_get_attr();
Pkg_private int 	drawrect_destroy();

void	drawrect_paint_proc();

/*ARGSUSED*/
Pkg_private int
drawrect_init(parent, drawrect_public, avlist)
	Xv_opaque	parent;
	Drawrect		drawrect_public;
	Attr_avlist	avlist;
{
	Drawrect_info	*dinfo;
	Drawrect_struct	*drawrect_object;

	dinfo = xv_alloc(Drawrect_info);
	dinfo->public_self = drawrect_public;
	drawrect_object = (Drawrect_struct*) drawrect_public;
	drawrect_object->private_data = (Xv_opaque) dinfo;

	dinfo->opaque = TRUE;

	xv_set(drawrect_public, 
		RECTOBJ_PAINT_PROC, drawrect_paint_proc, 
		XV_NULL);

	return(XV_OK);
}


Pkg_private Xv_opaque
drawrect_set_avlist(drawrect_public, avlist)
	Drawrect		drawrect_public;
	register Attr_avlist	avlist;
{
        register Drawobj_attr attr;
        register Drawrect_info *dinfo = DRAWRECT_PRIVATE(drawrect_public);

	if(*avlist != XV_END_CREATE) {
		Xv_opaque set_result;
		set_result =
		    xv_super_set_avlist(drawrect_public, &drawrect_pkg, avlist);
		if(set_result != XV_OK) {
			rectobj_reset_set_info(drawrect_public);
			return(set_result);
		}
	}


	while (attr = (Drawobj_attr) * avlist++)
	  switch (attr) {

		case DRAWOBJ_OPAQUE:
			dinfo->opaque	= (int)*avlist++;
			break;

		default:
			avlist = attr_skip(attr, avlist);

	  }

	rectobj_finish_set(drawrect_public);
	return(XV_SET_DONE);
}


/*ARGSUSED*/
Pkg_private Xv_opaque
drawrect_get_attr(drawrect_public, status, which_attr, avlist)
	Drawrect		drawrect_public;
	int		*status;
	register Attr_attribute which_attr;
	Attr_avlist	avlist;
{
	Drawrect_info  *dinfo = DRAWRECT_PRIVATE(drawrect_public);

	switch (which_attr) {

		case DRAWOBJ_OPAQUE:
			return (Xv_opaque) dinfo->opaque;

		default:
			*status = XV_ERROR;
			return (Xv_opaque) 0;
	}
}

/*ARGSUSED*/
Pkg_private int
drawrect_destroy(drawrect_public, status)
	Drawrect		drawrect_public;
	Destroy_status	status;
{
	Drawrect_info	*dinfo = DRAWRECT_PRIVATE(drawrect_public);

	if ((status == DESTROY_CHECKING) || (status == DESTROY_SAVE_YOURSELF))
		return XV_OK;

	free(dinfo);
	return XV_OK;
}

/*ARGSUSED*/
Pkg_private void
drawrect_paint_proc(drawrect_public, dpy, win, xrects)
        Drawrect drawrect_public;
        Display *dpy;
        Window  win;
        Xv_xrectlist *xrects;
{
	Drawrect_info *dinfo = DRAWRECT_PRIVATE(drawrect_public);
	Rectobj_info *rinfo = RECTOBJ_PRIVATE(drawrect_public);
	GC gc;
	Rect *rect;
	int i;

	rect = (Rect*)xv_get(drawrect_public, XV_RECT);
	if(!rinfo->shared_info)
		return;

	gc = XCreateGC(dpy, win, 0, 0);
	if(xrects && xrects->count)
		XSetClipRectangles(dpy, gc,
			0, 0,
			xrects->rect_array,
			xrects->count,
			Unsorted);
	if(dinfo->opaque) {
		XSetForeground(dpy, gc, 
			rinfo->shared_info->pixels[rinfo->bg_color]);
		/* perhaps a need to split these up into successive calls */
		XFillRectangle(dpy, win, gc,
			rect->r_left, rect->r_top,
			rect->r_width, rect->r_height);

	}
	XSetForeground(dpy, gc, rinfo->shared_info->pixels[rinfo->fg_color]);

	XDrawRectangle(dpy, win, gc, rect->r_left, rect->r_top,
				rect->r_width-1, rect->r_height-1);
	XFreeGC(dpy, gc);

        rectobj_paint_children(drawrect_public, dpy, win, xrects);
}

