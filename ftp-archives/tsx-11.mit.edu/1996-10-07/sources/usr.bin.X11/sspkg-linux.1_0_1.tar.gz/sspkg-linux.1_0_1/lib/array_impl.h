/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef ARRAY_TILE_IMPL_DEFINED
#define ARRAY_TILE_IMPL_DEFINED

/* @(#)array_impl.h 1.11 91/05/06 */

#include <sspkg/rectobj.h>
#include <sspkg/array.h>

#define UNMANAGED 	1
#define NEW_CHILD	2

typedef struct array_layout_data {
	int	column;
	int	row;
	int	flags;
} Array_layout_data;


typedef struct array_tile_info {

	int	n_managed;/* number of managed children */

	int	column_gap;
	int	row_gap;  
 
	int	column_width;
	int	row_height;

	int	n_columns;
	int	n_rows;
	int	array_size; /* n_columns * n_rows */

	Array_tile_layout layout;
	int	auto_layout;

	int	relayout;

	Rectobj	*arrayp;

	Array_tile_align align;

} Array_tile_info;

#define ARRAY_TILE_PRIVATE(array_tile)    XV_PRIVATE(Array_tile_info, Array_tile_struct, array_tile)

#endif
