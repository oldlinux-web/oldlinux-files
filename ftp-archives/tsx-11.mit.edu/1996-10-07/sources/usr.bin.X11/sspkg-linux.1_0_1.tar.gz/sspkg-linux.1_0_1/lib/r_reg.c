/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */


#ifndef lint
static  char sccsid[] = "@(#)SSM2 rectobj_reg.c 1.8 91/05/07 ";
#endif

/***********************************************************************
 *
 *	a routine to create a region that is suitable for the
 *	painting of a rectobj in such a way that the children do
 *	not need to be repainted.  The region should be freed
 *	with XDestroyRegion.
 *	
 *
 ***********************************************************************/


#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <xview/rect.h>
#include <xview/xv_xrect.h>
#include <xview/win_input.h>
#include <sspkg/drawobj.h>
#include <sspkg/canshell.h>
#include "r_impl.h"
#include "do_impl.h"

Region RectobjRegion(rectobj_public, xrects)
Rectobj rectobj_public;
Xv_xrectlist *xrects;
{
  Rectobj_info *	rinfo 		= RECTOBJ_PRIVATE(rectobj_public);
  Shared_info *		shared_info 	= rinfo->shared_info;
  Rect *		rect		= &(rinfo->rect);
  Region 		region;	
  Region		subtract_region;
  Region		intersection_region;
  int			i;
  
  Rectobj 		child;
  Rectobj_info *	child_rinfo;
  Rectobj_list *	node;

  region = XCreateRegion();
  subtract_region = XCreateRegion();

  XUnionRectWithRegion((XRectangle*)rect, region, region);

  
  if(xrects)
    {
      intersection_region = XCreateRegion();
      for(i = 0; i < xrects->count; i++)
	XUnionRectWithRegion((XRectangle*) (xrects->rect_array + i), 
			     intersection_region, 
			     intersection_region);

      XIntersectRegion(region, intersection_region, region);        
      XDestroyRegion(intersection_region);
    }

  node = rinfo->children;

  list_for(node) 
    {
      child = RECTOBJ_LIST_HANDLE(node);
      child_rinfo = RECTOBJ_PRIVATE(child);
      XUnionRectWithRegion((XRectangle*) (&child_rinfo->rect),
			   subtract_region, 
			   subtract_region);
    }

  XSubtractRegion(region, subtract_region, region);

  XDestroyRegion(subtract_region);

  return(region);
}


