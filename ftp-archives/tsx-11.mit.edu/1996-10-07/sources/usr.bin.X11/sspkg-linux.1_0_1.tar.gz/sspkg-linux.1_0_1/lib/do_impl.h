/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef DRAWOBJ_IMPL_DEFINED
#define DRAWOBJ_IMPL_DEFINED

/* @(#)do_impl.h 1.20 91/05/06 */

#include <X11/Xlib.h>
#include <xview/svrimage.h>
#include <xview/font.h>
#include <sspkg/drawobj.h>
 
typedef struct drawrect_info {
	Drawrect	public_self;
	int		opaque;
}               Drawrect_info;

typedef struct {
	Arrow_style	style;
	int		length;
	int		inset_length;
	int		angle_degrees;	/* degrees * 64 */
	double		angle;		/* in radians */
	short		tip_ax, tip_ay;
	short		tip_bx, tip_by;
	short		interior_x, interior_y;
}		Arrow_head;

typedef struct drawline_info {
	Drawline	public_self;
	short		x[2], y[2];
	Arrow_head	arrow[2];
}               Drawline_info;

typedef struct drawimage_info {
	Drawimage	public_self;
	Server_image	server_image;
	int		depth;
	Server_image	highlight_image;
	int		highlight_depth;
}               Drawimage_info;



typedef struct drawtext_info {
	Drawtext	public_self;
	char		*string;
	Xv_font		font;
	XFontStruct	*font_info;
	GC		gc;
}               Drawtext_info;

typedef struct drawicon_info {
	Drawicon	public_self;
	Drawimage	icon;
	Drawtext	text;
}		Drawicon_info;

typedef struct dl_cmd {
  int (*func)();
  caddr_t data_ptr;
} Dl_Cmd;

typedef struct dl_cmds {
  int allocated;
  int used;
  int displayed;
  Dl_Cmd * cmds;
} Dl_Cmds;


typedef struct dl_transform {
  double right_x, left_x, upper_y, lower_y;
} Dl_Transform;

typedef struct dl_limits {
  double min_x, max_x, min_y, max_y;
  int    checked;
} Dl_Limits;

typedef struct drawarea_info {
  Drawarea	public_self;
  GC		gc;			/* maintained GC  	*/
  Xv_font	font;
  XFontStruct	*font_info;
  int 		linestyle;
  int		linewidth;
  int 		color;
  int 		auto_x;
  int 		auto_y;
  Dl_Cmds       dl_cmds;
  Dl_Transform	dl_transform;
  Dl_Limits	dl_limits;		/* max range of scaled drawing */
} Drawarea_info;


#define DRAWRECT_PRIVATE(drawrect)    XV_PRIVATE(Drawrect_info, Drawrect_struct, drawrect)
#define DRAWRECT_PUBLIC(drawrect)     XV_PUBLIC(drawrect)

#define DRAWLINE_PRIVATE(drawline)    XV_PRIVATE(Drawline_info, Drawline_struct, drawline)
#define DRAWLINE_PUBLIC(drawline)     XV_PUBLIC(drawline)

#define DRAWIMAGE_PRIVATE(drawimage)    XV_PRIVATE(Drawimage_info, Drawimage_struct, drawimage)
#define DRAWIMAGE_PUBLIC(drawimage)     XV_PUBLIC(drawimage)

#define DRAWTEXT_PRIVATE(drawtext)    XV_PRIVATE(Drawtext_info, Drawtext_struct, drawtext)
#define DRAWTEXT_PUBLIC(drawtext)     XV_PUBLIC(drawtext)

#define DRAWICON_PRIVATE(drawicon)    XV_PRIVATE(Drawicon_info, Drawicon_struct, drawicon)
#define DRAWICON_PUBLIC(drawicon)     XV_PUBLIC(drawicon)

#define DRAWAREA_PRIVATE(drawarea)    XV_PRIVATE(Drawarea_info, Drawarea_struct, drawarea)
#define DRAWAREA_PUBLIC(drawarea)     XV_PUBLIC(drawarea)

#endif

