/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef X_MISC_INCLUDED
#define X_MISC_INCLUDED

/* @(#)sh_info.h 1.2 91/05/06 */

#include <X11/Xlib.h>
#include <sspkg/canshell.h>

typedef struct {
	Canvas_shell	canvas_shell;
	Display 	*dpy;
	int		screen_number;
	int		num_colors;
	unsigned long	*pixels;
} Shared_info;


#define FOREGROUND_PIXEL(shared_info, color) \
		((color == -1) \
			? (shared_info->pixels[shared_info->num_colors - 1)] \
			: (shared_info->pixels[color]))
 
#define BACKGROUND_PIXEL(shared_info, color) \
		((color == -1) \
			? (shared_info->pixels[0)] \
			: (shared_info->pixels[color]))
 
#endif

