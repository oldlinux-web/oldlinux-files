/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef GRIP_IMPL_H
#define GRIP_IMPL_H


/* @(#)grip_impl.h 1.5 91/05/06 */

#include <sspkg/grip.h>

typedef struct grip_info {
	Grip		public_self;
	int		(*grip_move_proc)();
	void		(*grip_done_proc)();
	int		slide_x;
	int		slide_y;
	/*
	 * might have to use a Rect instead of these four...
	 */
	short		min_x;
	short		min_y;
	short		max_x;
	short		max_y;
} Grip_info;

#define GRIP_PRIVATE(grip)	XV_PRIVATE(Grip_info, Grip_struct, grip)
#define GRIP_PUBLIC(grip)	XV_PUBLIC(grip)

#endif

