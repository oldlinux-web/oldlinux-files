/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef RECTOBJ_DEFINED
#define RECTOBJ_DEFINED

/* @(#)rectobj.h 1.22 91/05/06 */

#include <xview/generic.h>
#include <xview/canvas.h>
#include <sspkg/list.h>

typedef	Xv_opaque 	Rectobj;

extern	Xv_pkg   	rectobj_pkg;
#define RECTOBJ 	&rectobj_pkg

typedef struct {
	/*
	 * This union is such that the RECTOBJ_PRIVATE macro returns
	 * Rectobj_info for both canvas_shells and rectobjs.
	 */
	union {
		Xv_generic_struct 	generic_parent_data;
		Xv_canvas		canvas_parent_data;
	} parent_data;
	Xv_opaque       private_data;
} Rectobj_struct;

#define ATTR_RECTOBJ			ATTR_PKG_UNUSED_LAST
#define RECTOBJ_ATTR(type, ordinal)	ATTR(ATTR_RECTOBJ, type, ordinal)

typedef enum {

	RECTOBJ_CHILDREN = 	RECTOBJ_ATTR(ATTR_OPAQUE, 		1),
	RECTOBJ_SELECTABLE = 	RECTOBJ_ATTR(ATTR_BOOLEAN, 		2),
	RECTOBJ_SELECTED = 	RECTOBJ_ATTR(ATTR_BOOLEAN, 		3),
	RECTOBJ_CANVAS = 	RECTOBJ_ATTR(ATTR_OPAQUE, 		4),
	RECTOBJ_FOREGROUND_COLOR = RECTOBJ_ATTR(ATTR_INT, 		5),
	RECTOBJ_BACKGROUND_COLOR = RECTOBJ_ATTR(ATTR_INT,		6),
	RECTOBJ_X = 		RECTOBJ_ATTR(ATTR_INT,			7),
	RECTOBJ_Y =	 	RECTOBJ_ATTR(ATTR_INT,			8),
	RECTOBJ_PARENT = 	RECTOBJ_ATTR(ATTR_OPAQUE, 		9),
	RECTOBJ_NTH_CHILD =	RECTOBJ_ATTR(ATTR_INT,			10),
	RECTOBJ_STATE = 	RECTOBJ_ATTR(ATTR_OPAQUE,		11),
	RECTOBJ_STACKING_POSITION =RECTOBJ_ATTR(ATTR_INT,		12),

	RECTOBJ_PAINT_PROC = 	RECTOBJ_ATTR(ATTR_FUNCTION_PTR, 	20),
	RECTOBJ_EVENT_PROC = 	RECTOBJ_ATTR(ATTR_FUNCTION_PTR,		21),
	RECTOBJ_MAP_EVENT_PROC = RECTOBJ_ATTR(ATTR_FUNCTION_PTR,	22),
	RECTOBJ_NO_MANAGE_CHILD = RECTOBJ_ATTR(ATTR_BOOLEAN,		23),

	RECTOBJ_SET_GEOMETRY_PROC = RECTOBJ_ATTR(ATTR_FUNCTION_PTR, 	24),
	RECTOBJ_ADD_CHILD_PROC=	RECTOBJ_ATTR(ATTR_FUNCTION_PTR,		25),
	RECTOBJ_DEL_CHILD_PROC=	RECTOBJ_ATTR(ATTR_FUNCTION_PTR,		26),
	RECTOBJ_MANAGE_CHILD_PROC=RECTOBJ_ATTR(ATTR_FUNCTION_PTR,	27),
	RECTOBJ_LAYOUT_DATA = 	RECTOBJ_ATTR(ATTR_OPAQUE,		28),
	RECTOBJ_SHARED_INFO = 	RECTOBJ_ATTR(ATTR_OPAQUE,		29),

        RECTOBJ_DRAGGABLE = 	RECTOBJ_ATTR(ATTR_BOOLEAN, 		40), 
        RECTOBJ_DRAG_CURSOR = 	RECTOBJ_ATTR(ATTR_OPAQUE, 		41), 
        RECTOBJ_DROP_PROC = 	RECTOBJ_ATTR(ATTR_FUNCTION_PTR, 	42),
        RECTOBJ_ACCEPTS_DROP =	RECTOBJ_ATTR(ATTR_BOOLEAN, 		43),
	RECTOBJ_ACCEPTS_CHILD_DROP = RECTOBJ_ATTR(ATTR_BOOLEAN, 	44),
	RECTOBJ_CHILD_DROP_PROC = RECTOBJ_ATTR(ATTR_FUNCTION_PTR, 	45),
	RECTOBJ_MENU =		RECTOBJ_ATTR(ATTR_OPAQUE, 		46),
	RECTOBJ_INHERIT_MENU =	RECTOBJ_ATTR(ATTR_BOOLEAN, 		47),
	RECTOBJ_DBL_CLICK_PROC=	RECTOBJ_ATTR(ATTR_FUNCTION_PTR,		48),

} Rectobj_attr;

/* public functions */
extern	void	(*root_window_drop_proc)();
extern	int	count_buttons_down( /* (Event*) */ );
extern	void	*traverse_rectobj_tree();


/* rectobj subclasses */
extern	Rectobj	event_to_rectobj();
extern	void 	rectobj_paint_children();
extern	int	rectobj_paint_child();
extern	void	rectobj_repaint_rect();
extern	void	rectobj_flush_repaint();
extern	void	rectobj_finish_set();
extern	void	rectobj_reset_set_info();
extern	void	rectobj_geometry_manage();
extern	void	rectobj_set_geometry();
extern	void	rectobj_move_adjust_rect();
extern	void	rectobj_move_children();
extern	int	rectobj_own_rect();
extern	void	rectobj_set_delay_repaint();


typedef enum {
	RECTOBJ_STATE_INIT,
	RECTOBJ_STATE_CREATED,
	RECTOBJ_STATE_DESTROYING,
} Rectobj_state;


typedef Listnode Rectobj_list;
#define RECTOBJ_LIST_HANDLE(_list) (Rectobj)list_handle(_list)

extern Rectobj_list *get_selected_list();
extern void     add_to_selected_list();
extern void     del_from_selected_list();
extern void     clear_selection();


#endif

