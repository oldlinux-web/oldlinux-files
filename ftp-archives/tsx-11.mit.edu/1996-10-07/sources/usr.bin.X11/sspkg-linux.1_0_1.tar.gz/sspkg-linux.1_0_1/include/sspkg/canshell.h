/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef CANVAS_SHELL_DEFINED
#define CANVAS_SHELL_DEFINED

/* @(#)canshell.h 1.8 91/05/06 */

#include <sspkg/rectobj.h>

typedef Xv_opaque	Canvas_shell;

extern Xv_pkg		canvas_shell_pkg;
#define CANVAS_SHELL	&canvas_shell_pkg

typedef Rectobj_struct Canvas_shell_struct;

#define ATTR_CANVAS_SHELL	ATTR_PKG_UNUSED_LAST-1

#define CANVAS_SHELL_ATTR(type, ordinal)	\
				ATTR(ATTR_CANVAS_SHELL, type, ordinal)

typedef enum {

	CANVAS_SHELL_DELAY_REPAINT = CANVAS_SHELL_ATTR(ATTR_BOOLEAN, 1),
	CANVAS_SHELL_BATCH_REPAINT = CANVAS_SHELL_ATTR(ATTR_BOOLEAN, 2),

} Canvas_shell_attr;

#endif
