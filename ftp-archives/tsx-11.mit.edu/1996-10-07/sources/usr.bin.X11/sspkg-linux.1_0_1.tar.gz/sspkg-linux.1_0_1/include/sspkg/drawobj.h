/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef DRAWOBJ_DEFINED
#define DRAWOBJ_DEFINED

/* @(#)drawobj.h 1.18 91/05/06 */

/*
 * issues:
 * - DRAWOBJ_OPAQUE is a fill style.
 *   maybe this could be implemented by setting the color to -2 (default = -1)
 */
#include <sspkg/rectobj.h>

/*
 * types 
 */
typedef Xv_opaque Drawobj;	/* generic */
typedef Xv_opaque Drawrect;
typedef Xv_opaque Drawline;
typedef Xv_opaque Drawimage;
typedef Xv_opaque Drawtext;
typedef Xv_opaque Drawicon;
typedef Xv_opaque Drawarea;

/*
 * packages
 */
extern Xv_pkg   drawrect_pkg;
#define DRAWRECT	&drawrect_pkg

extern Xv_pkg   drawline_pkg;
#define DRAWLINE	&drawline_pkg

extern Xv_pkg   drawimage_pkg;
#define DRAWIMAGE	&drawimage_pkg

extern Xv_pkg   drawtext_pkg;
#define DRAWTEXT	&drawtext_pkg

extern Xv_pkg   drawicon_pkg;
#define DRAWICON	&drawicon_pkg

extern Xv_pkg   drawarea_pkg;
#define DRAWAREA	&drawarea_pkg

/*
 * structs for subpackages
 */
typedef struct {
	Rectobj_struct	parent_data;
	Xv_opaque	private_data;
} Drawrect_struct;

typedef struct {
	Rectobj_struct	parent_data;
	Xv_opaque	private_data;
} Drawline_struct;

typedef struct {
	Rectobj_struct	parent_data;
	Xv_opaque	private_data;
} Drawimage_struct;

typedef struct {
	Rectobj_struct	parent_data;
	Xv_opaque	private_data;
} Drawtext_struct;

typedef struct {
	Rectobj_struct	parent_data;
	Xv_opaque	private_data;
} Drawicon_struct;

typedef struct {
  Rectobj_struct	parent_data;
  Xv_opaque	private_data;
} Drawarea_struct;

/*
 * attribute defines
 */
#define ATTR_DRAWOBJ      ATTR_PKG_UNUSED_LAST-2
#define DRAWOBJ_ATTR(type, ordinal)       ATTR(ATTR_DRAWOBJ, type, ordinal)

typedef enum {
	DRAWOBJ_OPAQUE = DRAWOBJ_ATTR(ATTR_BOOLEAN, 1),
	DRAWOBJ_COLOR = DRAWOBJ_ATTR(ATTR_INT, 2),
	DRAWOBJ_BORDER_COLOR = DRAWOBJ_ATTR(ATTR_INT, 3),
	DRAWOBJ_BORDER_WIDTH = DRAWOBJ_ATTR(ATTR_INT, 4),
	DRAWOBJ_RESIZABLE = DRAWOBJ_ATTR(ATTR_BOOLEAN, 5),

	DRAWLINE_X0 = DRAWOBJ_ATTR(ATTR_INT, 11),
	DRAWLINE_Y0 = DRAWOBJ_ATTR(ATTR_INT, 12),
	DRAWLINE_X1 = DRAWOBJ_ATTR(ATTR_INT, 13),
	DRAWLINE_Y1 = DRAWOBJ_ATTR(ATTR_INT, 14),
	DRAWLINE_X = DRAWOBJ_ATTR(ATTR_INT_PAIR, 15),
	DRAWLINE_Y = DRAWOBJ_ATTR(ATTR_INT_PAIR, 16),
	DRAWLINE_WIDTH = DRAWOBJ_ATTR(ATTR_INT, 17),
	DRAWLINE_ARROW_STYLE = DRAWOBJ_ATTR(ATTR_OPAQUE_PAIR, 18),
	DRAWLINE_ARROW_ANGLE = DRAWOBJ_ATTR(ATTR_INT_PAIR, 19),
	DRAWLINE_ARROW_LENGTH = DRAWOBJ_ATTR(ATTR_INT_PAIR, 20),
	DRAWLINE_ARROW_INSET_LENGTH = DRAWOBJ_ATTR(ATTR_INT_PAIR, 21),

	DRAWIMAGE_IMAGE = DRAWOBJ_ATTR(ATTR_OPAQUE, 25),
	DRAWIMAGE_SVRIMAGE = DRAWIMAGE_IMAGE,	/* old */
	DRAWIMAGE_HIGHLIGHT_IMAGE = DRAWOBJ_ATTR(ATTR_OPAQUE, 26),

	DRAWTEXT_STRING = DRAWOBJ_ATTR(ATTR_STRING, 30),
	DRAWTEXT_FONT = DRAWOBJ_ATTR(ATTR_OPAQUE, 31),

	DRAWICON_TEXT = DRAWOBJ_ATTR(ATTR_OPAQUE, 40), /* get only */
	DRAWICON_ICON = DRAWOBJ_ATTR(ATTR_OPAQUE, 41), /* get only */
	DRAWICON_ICON_COLOR = DRAWOBJ_ATTR(ATTR_INT, 42),
	DRAWICON_TEXT_COLOR = DRAWOBJ_ATTR(ATTR_INT, 43),

	DRAWAREA_X		= DRAWOBJ_ATTR(ATTR_INT, 50),
	DRAWAREA_Y 		= DRAWOBJ_ATTR(ATTR_INT, 51),
	DRAWAREA_WIDTH		= DRAWOBJ_ATTR(ATTR_INT, 52),
	DRAWAREA_HEIGHT 	= DRAWOBJ_ATTR(ATTR_INT, 53),
	DRAWAREA_LEFT_X		= DRAWOBJ_ATTR(ATTR_OPAQUE, 54),
	DRAWAREA_RIGHT_X	= DRAWOBJ_ATTR(ATTR_OPAQUE, 55),
	DRAWAREA_UPPER_Y	= DRAWOBJ_ATTR(ATTR_OPAQUE, 56),
	DRAWAREA_LOWER_Y	= DRAWOBJ_ATTR(ATTR_OPAQUE, 57),
	DRAWAREA_MIN_X		= DRAWOBJ_ATTR(ATTR_OPAQUE, 58),
	DRAWAREA_MAX_X		= DRAWOBJ_ATTR(ATTR_OPAQUE, 59),
	DRAWAREA_MIN_Y		= DRAWOBJ_ATTR(ATTR_OPAQUE, 60),
	DRAWAREA_MAX_Y		= DRAWOBJ_ATTR(ATTR_OPAQUE, 61),
	DRAWAREA_FONT_DIMS 	= DRAWOBJ_ATTR(ATTR_OPAQUE_TRIPLE, 62)
} Drawobj_attr;

typedef Drawobj_attr Drawrect_attr;
typedef Drawobj_attr Drawline_attr;
typedef Drawobj_attr Drawimage_attr;
typedef Drawobj_attr Drawtext_attr;
typedef Drawobj_attr Drawicon_attr;
typedef Drawobj_attr Drawarea_attr;

typedef enum {
	ARROW_FILLED,
	ARROW_HOLLOW,
	ARROW_SIMPLE,
	ARROW_NONE
} Arrow_style;

#endif

