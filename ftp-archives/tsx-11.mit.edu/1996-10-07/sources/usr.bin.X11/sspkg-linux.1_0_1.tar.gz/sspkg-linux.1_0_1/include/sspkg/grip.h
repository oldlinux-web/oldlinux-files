/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */

#ifndef GRIP_DEFINED
#define GRIP_DEFINED

/* @(#)grip.h 1.8 91/05/06 */

#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>

typedef Xv_opaque	Grip;

extern Xv_pkg		grip_pkg;
#define GRIP		&grip_pkg

typedef struct {
	Drawimage_struct	parent_data;
	Xv_opaque	private_data;
}		Grip_struct;

#define ATTR_GRIP 	ATTR_PKG_UNUSED_FIRST - 3
#define GRIP_ATTR(type, ordinal)	ATTR(ATTR_GRIP, type, ordinal)

typedef enum {
	GRIP_SLIDE_X		= GRIP_ATTR(ATTR_BOOLEAN,	1),
	GRIP_SLIDE_Y		= GRIP_ATTR(ATTR_BOOLEAN,	2),
	GRIP_MOVE_PROC		= GRIP_ATTR(ATTR_FUNCTION_PTR,	3),
	GRIP_DONE_PROC		= GRIP_ATTR(ATTR_FUNCTION_PTR,	4),
	GRIP_MAX_X		= GRIP_ATTR(ATTR_SHORT,		5),
	GRIP_MAX_Y		= GRIP_ATTR(ATTR_SHORT,		6),
	GRIP_MIN_X		= GRIP_ATTR(ATTR_SHORT,		7),
	GRIP_MIN_Y		= GRIP_ATTR(ATTR_SHORT,		8),
} Grip_attr;

extern int default_grip_move_proc();

#endif

