# include "stdio.h"
# define U(x) x
# define NLSTATE yyprevious=YYNEWLINE
# define BEGIN yybgin = yysvec + 1 +
# define INITIAL 0
# define YYLERR yysvec
# define YYSTATE (yyestate-yysvec-1)
# define YYOPTIM 1
# define YYLMAX BUFSIZ
# define output(c) putc(c,yyout)
# define input() (((yytchar=yysptr>yysbuf?U(*--yysptr):getc(yyin))==10?(yylineno++,yytchar):yytchar)==EOF?0:yytchar)
# define unput(c) {yytchar= (c);if(yytchar=='\n')yylineno--;*yysptr++=yytchar;}
# define yymore() (yymorfg=1)
# define ECHO fprintf(yyout, "%s",yytext)
# define REJECT { nstr = yyreject(); goto yyfussy;}
int yyleng; extern char yytext[];
int yymorfg;
extern char *yysptr, yysbuf[];
int yytchar;
FILE *yyin = {stdin}, *yyout = {stdout};
extern int yylineno;
struct yysvf { 
	struct yywork *yystoff;
	struct yysvf *yyother;
	int *yystops;};
struct yysvf *yyestate;
extern struct yysvf yysvec[], *yybgin;

typedef enum {
	T_EOF = 0, 
	T_STR, 
	T_LPAR, 
	T_RPAR,
	T_FONT,
	T_ICON,
	T_COLOR,
} Token;

int lineno = 1;

# define COMMENT 2
# define STRING 4
# define YYNEWLINE 10
yylex(){
int nstr; extern int yyprevious;
while((nstr = yylook()) >= 0)
yyfussy: switch(nstr){
case 0:
if(yywrap()) return(0); break;
case 1:
		;
break;
case 2:
		{ lineno++; BEGIN 0; }
break;
case 3:
			{ BEGIN COMMENT; }
break;
case 4:
			{ yytext[0] = '\0';return(T_STR); }
break;
case 5:
		{ return(T_STR); }
break;
case 6:
		{ BEGIN 0; }
break;
case 7:
			{ BEGIN STRING; }
break;
case 8:
			{ return(T_LPAR); }
break;
case 9:
			{ return(T_RPAR); }
break;
case 10:
			{ lineno++ ; }
break;
case 11:
			;
break;
case 12:
		{ return(T_STR); }
break;
case -1:
break;
default:
fprintf(yyout,"bad switch yylook %d",nstr);
} return(0); }
/* end of yylex */

#include <xview/frame.h>
#include <xview/openmenu.h>
#include <xview/scrollbar.h>
#include <sspkg/canshell.h> 
#include <sspkg/tree.h>
#include <sspkg/rectobj.h> 
#include <sspkg/drawobj.h> 
 

void	read_node_descr();
int	read_node();
Rectobj	add_leaf();
void	set_horizontal();
void	set_vertical();
void	resize();

Tree		tree = 0;
Canvas_shell	shell;


main(argc, argv)
	int	argc;
	char	*argv[];
{
	Frame		frame;
	Menu		menu;
	Scrollbar	vscroll;
	Scrollbar	hscroll;
 
	xv_init(XV_INIT_ARGC_PTR_ARGV, &argc, argv, NULL);
 
	frame = (Frame) xv_create(XV_NULL, FRAME,
			FRAME_LABEL, argv[0],
			XV_WIDTH, 400,
			XV_HEIGHT, 300,
			NULL);

	menu = (Menu) xv_create(XV_NULL, MENU_COMMAND_MENU,
			MENU_GEN_PIN_WINDOW, frame, "Layout",
			MENU_ITEM,
				MENU_STRING, "Horizontal",
				MENU_ACTION_PROC, set_horizontal,
				NULL,
			MENU_ITEM,
				MENU_STRING, "Vertical",
				MENU_ACTION_PROC, set_vertical,
				NULL,
			NULL);

	shell = (Canvas_shell) xv_create(frame, CANVAS_SHELL, 
			CANVAS_RESIZE_PROC, resize,
			RECTOBJ_MENU, menu,
			NULL);

	vscroll = (Scrollbar) xv_create(shell, SCROLLBAR,
			SCROLLBAR_DIRECTION, SCROLLBAR_VERTICAL,
			SCROLLBAR_SPLITTABLE, TRUE,
			SCROLLBAR_PIXELS_PER_UNIT, 10,
			NULL);

	hscroll = (Scrollbar) xv_create(shell, SCROLLBAR,
			SCROLLBAR_DIRECTION, SCROLLBAR_HORIZONTAL,
			SCROLLBAR_SPLITTABLE, TRUE,
			SCROLLBAR_PIXELS_PER_UNIT, 10,
			NULL);

	tree = (Tree) xv_create(shell, TREE,
			XV_WIDTH, 400,
			XV_HEIGHT, 300,
			NULL);


	while( read_node(tree) )
		;

	xv_set(shell,	
		CANVAS_MIN_PAINT_WIDTH, xv_get(tree, XV_WIDTH),
		CANVAS_MIN_PAINT_HEIGHT, xv_get(tree, XV_HEIGHT),
		NULL);

	xv_main_loop(frame); 
}

void
syntax_error()
{
	fprintf(stderr,"htool: Syntax error on line %d.\n", lineno);
	exit(1);
}

void
read_node_descr(node)
	Rectobj	node;
{
	Rectobj new;

	switch((Token) yylex()) {
		case T_STR:
			new = add_leaf(yytext, node);
			break;
		default:
			syntax_error();
			break;
	}

	while(1) 
	  switch((Token) yylex()) {
		case T_RPAR:
			return;
		case T_LPAR: 
			read_node_descr(new);
			break;
		default:
			syntax_error();
			break;
	}
}

int
read_node(node)
	Rectobj	node;
{

	switch((Token) yylex()) {
		case T_LPAR: 
			break;
		case T_EOF:
			return FALSE;
		default:
			syntax_error();
			break;
	}
	read_node_descr(node);
	return TRUE;
}

yywrap()
{
	return(1);
}


Rectobj
add_leaf(string, node)
	char		*string;
	Rectobj		node;
{
	Rectobj		new;

	new = (Rectobj) xv_create(tree, DRAWTEXT, 
		DRAWTEXT_STRING, string,
		NULL);

	xv_set(tree, 
		TREE_ADD_LINK, node, new, 
		NULL);
	return new;
}



void
set_horizontal(menu, menu_item)
	Menu	menu;
	Menu_item menu_item;
{

	/*
	 * Set the size of the tree before changing it. 
	 * This will have the effect of centering it if
	 * all the space isn't used.
	 */
	xv_set(tree,
		XV_WIDTH, xv_get(shell, XV_WIDTH),
		XV_HEIGHT, xv_get(shell, XV_HEIGHT),

		TREE_LAYOUT, TREE_LAYOUT_HORIZONTAL,
		NULL);

	/*
	 * In case the tree grew bigger than the paint window,
	 * set the paint window size.  This way, the scrollbars
	 * will be properly set.
	 */
	xv_set(shell,	
		CANVAS_MIN_PAINT_WIDTH, xv_get(tree, XV_WIDTH),
		CANVAS_MIN_PAINT_HEIGHT, xv_get(tree, XV_HEIGHT),
		NULL);
}


void
set_vertical(menu, menu_item)
	Menu	menu;
	Menu_item menu_item;
{
	xv_set(tree,
		XV_WIDTH, xv_get(shell, XV_WIDTH),
		XV_HEIGHT, xv_get(shell, XV_HEIGHT),

		TREE_LAYOUT, TREE_LAYOUT_VERTICAL,
		NULL);

	xv_set(shell,	
		CANVAS_MIN_PAINT_WIDTH, xv_get(tree, XV_WIDTH),
		CANVAS_MIN_PAINT_HEIGHT, xv_get(tree, XV_HEIGHT),
		NULL);
}


void
resize(shell, width, height)
	Canvas_shell	shell;
	int		width;	
	int		height;
{
	if(tree)
		xv_set(tree,	
			XV_WIDTH, width,
			XV_HEIGHT, height,
			NULL);
}

int yyvstop[] = {
0,

1,
5,
0,

1,
5,
0,

1,
5,
0,

1,
5,
0,

1,
5,
0,

1,
5,
0,

12,
0,

11,
0,

10,
0,

7,
0,

8,
0,

9,
0,

3,
12,
0,

1,
12,
0,

1,
11,
0,

2,
10,
0,

1,
10,
0,

1,
7,
0,

1,
8,
0,

1,
9,
0,

1,
3,
12,
0,

5,
12,
0,

5,
11,
0,

5,
10,
0,

6,
7,
0,

5,
8,
0,

5,
9,
0,

3,
5,
12,
0,

4,
0,

1,
0,

1,
4,
0,

5,
0,
0};
# define YYTYPE char
struct yywork { YYTYPE verify, advance; } yycrank[] = {
0,0,	0,0,	1,7,	0,0,	
15,30,	0,0,	23,32,	3,14,	
17,30,	19,30,	1,8,	1,9,	
5,22,	15,0,	1,9,	3,15,	
3,16,	17,0,	19,0,	3,17,	
5,23,	5,24,	7,7,	20,30,	
5,24,	21,0,	0,0,	0,0,	
0,0,	0,0,	7,0,	7,0,	
20,0,	0,0,	7,0,	1,10,	
10,29,	2,13,	4,21,	23,0,	
3,18,	1,11,	1,12,	2,12,	
4,20,	5,25,	3,19,	3,20,	
6,28,	24,32,	18,30,	5,26,	
5,27,	7,0,	6,27,	7,0,	
13,0,	13,0,	14,14,	18,0,	
13,0,	7,0,	7,0,	22,22,	
28,0,	26,32,	14,30,	14,0,	
27,32,	30,30,	14,30,	22,32,	
22,32,	32,32,	0,0,	22,32,	
31,30,	0,0,	30,0,	13,0,	
0,0,	13,0,	24,0,	18,31,	
0,0,	31,0,	0,0,	13,0,	
13,0,	0,0,	0,0,	14,30,	
0,0,	0,0,	0,0,	0,0,	
22,0,	14,30,	26,0,	0,0,	
0,0,	27,0,	22,32,	0,0,	
0,0,	0,0,	32,0,	0,0,	
0,0};
struct yysvf yysvec[] = {
0,	0,	0,
yycrank+-1,	0,		yyvstop+1,
yycrank+-2,	yysvec+1,	yyvstop+4,
yycrank+-6,	0,		yyvstop+7,
yycrank+-3,	yysvec+3,	yyvstop+10,
yycrank+-11,	0,		yyvstop+13,
yycrank+-13,	yysvec+5,	yyvstop+16,
yycrank+-21,	0,		yyvstop+19,
yycrank+0,	0,		yyvstop+21,
yycrank+0,	0,		yyvstop+23,
yycrank+2,	0,		yyvstop+25,
yycrank+0,	0,		yyvstop+27,
yycrank+0,	0,		yyvstop+29,
yycrank+-47,	yysvec+7,	yyvstop+31,
yycrank+-57,	0,		yyvstop+34,
yycrank+-3,	yysvec+14,	yyvstop+37,
yycrank+0,	0,		yyvstop+40,
yycrank+-7,	yysvec+14,	yyvstop+43,
yycrank+-49,	yysvec+14,	yyvstop+46,
yycrank+-8,	yysvec+14,	yyvstop+49,
yycrank+-22,	yysvec+14,	yyvstop+52,
yycrank+-15,	yysvec+14,	yyvstop+55,
yycrank+-62,	0,		yyvstop+59,
yycrank+-5,	yysvec+22,	yyvstop+62,
yycrank+-48,	yysvec+22,	yyvstop+65,
yycrank+0,	yysvec+10,	yyvstop+68,
yycrank+-64,	yysvec+22,	yyvstop+71,
yycrank+-67,	yysvec+22,	yyvstop+74,
yycrank+-30,	yysvec+22,	yyvstop+77,
yycrank+0,	0,		yyvstop+81,
yycrank+-68,	yysvec+14,	yyvstop+83,
yycrank+-75,	yysvec+14,	yyvstop+85,
yycrank+-72,	yysvec+22,	yyvstop+88,
0,	0,	0};
struct yywork *yytop = yycrank+106;
struct yysvf *yybgin = yysvec+1;
char yymatch[] = {
00  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,011 ,012 ,01  ,01  ,015 ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
011 ,01  ,'"' ,01  ,01  ,01  ,01  ,01  ,
'(' ,'(' ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
01  ,01  ,01  ,01  ,01  ,01  ,01  ,01  ,
0};
char yyextra[] = {
0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,
0};
#ifndef lint
static	char ncform_sccsid[] = "@(#)ncform 1.6 88/02/08 SMI"; /* from S5R2 1.2 */
#endif

int yylineno =1;
# define YYU(x) x
# define NLSTATE yyprevious=YYNEWLINE
char yytext[YYLMAX];
struct yysvf *yylstate [YYLMAX], **yylsp, **yyolsp;
char yysbuf[YYLMAX];
char *yysptr = yysbuf;
int *yyfnd;
extern struct yysvf *yyestate;
int yyprevious = YYNEWLINE;
yylook(){
	register struct yysvf *yystate, **lsp;
	register struct yywork *yyt;
	struct yysvf *yyz;
	int yych, yyfirst;
	struct yywork *yyr;
# ifdef LEXDEBUG
	int debug;
# endif
	char *yylastch;
	/* start off machines */
# ifdef LEXDEBUG
	debug = 0;
# endif
	yyfirst=1;
	if (!yymorfg)
		yylastch = yytext;
	else {
		yymorfg=0;
		yylastch = yytext+yyleng;
		}
	for(;;){
		lsp = yylstate;
		yyestate = yystate = yybgin;
		if (yyprevious==YYNEWLINE) yystate++;
		for (;;){
# ifdef LEXDEBUG
			if(debug)fprintf(yyout,"state %d\n",yystate-yysvec-1);
# endif
			yyt = yystate->yystoff;
			if(yyt == yycrank && !yyfirst){  /* may not be any transitions */
				yyz = yystate->yyother;
				if(yyz == 0)break;
				if(yyz->yystoff == yycrank)break;
				}
			*yylastch++ = yych = input();
			yyfirst=0;
		tryagain:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"char ");
				allprint(yych);
				putchar('\n');
				}
# endif
			yyr = yyt;
			if ( (int)yyt > (int)yycrank){
				yyt = yyr + yych;
				if (yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
# ifdef YYOPTIM
			else if((int)yyt < (int)yycrank) {		/* r < yycrank */
				yyt = yyr = yycrank+(yycrank-yyt);
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"compressed state\n");
# endif
				yyt = yyt + yych;
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transitions */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				yyt = yyr + YYU(yymatch[yych]);
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"try fall back character ");
					allprint(YYU(yymatch[yych]));
					putchar('\n');
					}
# endif
				if(yyt <= yytop && yyt->verify+yysvec == yystate){
					if(yyt->advance+yysvec == YYLERR)	/* error transition */
						{unput(*--yylastch);break;}
					*lsp++ = yystate = yyt->advance+yysvec;
					goto contin;
					}
				}
			if ((yystate = yystate->yyother) && (yyt= yystate->yystoff) != yycrank){
# ifdef LEXDEBUG
				if(debug)fprintf(yyout,"fall back to state %d\n",yystate-yysvec-1);
# endif
				goto tryagain;
				}
# endif
			else
				{unput(*--yylastch);break;}
		contin:
# ifdef LEXDEBUG
			if(debug){
				fprintf(yyout,"state %d char ",yystate-yysvec-1);
				allprint(yych);
				putchar('\n');
				}
# endif
			;
			}
# ifdef LEXDEBUG
		if(debug){
			fprintf(yyout,"stopped at %d with ",*(lsp-1)-yysvec-1);
			allprint(yych);
			putchar('\n');
			}
# endif
		while (lsp-- > yylstate){
			*yylastch-- = 0;
			if (*lsp != 0 && (yyfnd= (*lsp)->yystops) && *yyfnd > 0){
				yyolsp = lsp;
				if(yyextra[*yyfnd]){		/* must backup */
					while(yyback((*lsp)->yystops,-*yyfnd) != 1 && lsp > yylstate){
						lsp--;
						unput(*yylastch--);
						}
					}
				yyprevious = YYU(*yylastch);
				yylsp = lsp;
				yyleng = yylastch-yytext+1;
				yytext[yyleng] = 0;
# ifdef LEXDEBUG
				if(debug){
					fprintf(yyout,"\nmatch ");
					sprint(yytext);
					fprintf(yyout," action %d\n",*yyfnd);
					}
# endif
				return(*yyfnd++);
				}
			unput(*yylastch);
			}
		if (yytext[0] == 0  /* && feof(yyin) */)
			{
			yysptr=yysbuf;
			return(0);
			}
		yyprevious = yytext[0] = input();
		if (yyprevious>0)
			output(yyprevious);
		yylastch=yytext;
# ifdef LEXDEBUG
		if(debug)putchar('\n');
# endif
		}
	}
yyback(p, m)
	int *p;
{
if (p==0) return(0);
while (*p)
	{
	if (*p++ == m)
		return(1);
	}
return(0);
}
	/* the following are only used in the lex library */
yyinput(){
	return(input());
	}
yyoutput(c)
  int c; {
	output(c);
	}
yyunput(c)
   int c; {
	unput(c);
	}
