/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */
/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms of the license.
 */
#include <xview/xview.h>
#include <sspkg/canshell.h>
#include <sspkg/rectobj.h>
#include <sspkg/drawobj.h>
#include <sspkg/array.h>

static unsigned short smiley_bits[] = {
#include "icons/smiley.icon"
};

static unsigned short frown_bits[] = {
#include "icons/frown.icon"
};

static unsigned short amper_bits[] = {
#include "icons/amper.icon"
};

main(argc, argv)
	int             argc;
	char           *argv[];

{
	Frame		frame;
	Canvas_shell	shell;
	Array_tile	atile;
	Server_image    smiley, frown;
	Server_image    ampersand;
	

	xv_init(XV_INIT_ARGC_PTR_ARGV, &argc, argv, NULL);


	frame = (Frame) xv_create(XV_NULL, FRAME,
			FRAME_LABEL, argv[0],
			NULL);

	shell = (Canvas_shell) xv_create(frame, CANVAS_SHELL,
			NULL);
	
	atile = (Array_tile) xv_create(shell, ARRAY_TILE,
			ARRAY_TILE_N_COLUMNS, 3,
			NULL);

	smiley = (Server_image) xv_create(XV_NULL, SERVER_IMAGE,
			XV_WIDTH, 32,
			XV_HEIGHT, 20,
			SERVER_IMAGE_BITS, smiley_bits,
			NULL);

	frown = (Server_image) xv_create(XV_NULL, SERVER_IMAGE,
			XV_WIDTH, 32,
			XV_HEIGHT, 20,
			SERVER_IMAGE_BITS, frown_bits,
			NULL);

	ampersand = (Server_image) xv_create(XV_NULL, SERVER_IMAGE,
			XV_WIDTH, 64,
			XV_HEIGHT, 49,
			SERVER_IMAGE_BITS, amper_bits,
			NULL);

	/* 
	 * Create some objects inside the array_tile.
	 * They will be automatically positioned by the
	 * array_tile.
	 */

	(void) xv_create(atile, DRAWTEXT,
		DRAWTEXT_STRING, "Text",
		NULL);

	(void) xv_create(atile, DRAWIMAGE,
		DRAWIMAGE_SVRIMAGE, ampersand,
		NULL);

	(void) xv_create(atile, DRAWICON,
		DRAWIMAGE_SVRIMAGE, smiley,
		DRAWIMAGE_HIGHLIGHT_IMAGE, frown,
		DRAWTEXT_STRING, "Graphics",
		NULL);

	/* size the canvas to the size of the array_tile */
	xv_set(shell, 
		XV_WIDTH, xv_get(atile, XV_WIDTH),
		XV_HEIGHT, xv_get(atile, XV_HEIGHT),
		NULL);

	window_fit(frame);

	xv_main_loop(frame);

	xv_destroy( smiley );
	xv_destroy( frown );
	xv_destroy( ampersand );
}


