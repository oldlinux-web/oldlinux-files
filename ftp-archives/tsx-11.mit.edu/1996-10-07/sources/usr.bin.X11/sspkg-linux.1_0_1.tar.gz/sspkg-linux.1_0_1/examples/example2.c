/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms and restrictions.
 */
/*
 *	(c) Copyright 1991 Sun Microsystems, Inc.  All rights reserved.
 *	See LEGAL_NOTICE file for terms of the license.
 */

#include <xview/frame.h>
#include <xview/font.h>
#include <xview/cms.h>
#include <sspkg/canshell.h> 
#include <sspkg/rectobj.h> 
#include <sspkg/drawobj.h> 
 

#define RED	1
#define GREEN	2
#define BLUE	3
#define BLACK	4

Cms	cms;
Drawrect drawrect1;

void	print_selected_list();


main(argc, argv)
	int	argc;
	char	*argv[];
{
	Frame		frame;
	Canvas_shell	shell;
	Xv_Font		romankana;
	Drawtext	drawtext1;
	Drawtext	drawtext2;
	Drawtext	drawtext3;
	Drawtext	drawtext4;
	Drawtext	drawtext5;
	void		dbl_click_proc();
	void		drop_proc();


	xv_init(XV_INIT_ARGC_PTR_ARGV, &argc, argv, NULL);
 
	cms = xv_create(XV_NULL, CMS,
			CMS_SIZE, 5,
			CMS_NAMED_COLORS, "white", "red", "green", "blue", "black", NULL,
			NULL);

	frame = (Frame) xv_create(NULL, FRAME,
			FRAME_LABEL, argv[0],
			XV_WIDTH, 100,
			XV_HEIGHT, 175,
			WIN_CMS, cms,
			NULL);
 
	romankana = (Xv_Font) xv_find(frame, FONT,
			FONT_NAME, "8x16romankana",
			NULL);

	shell = (Canvas_shell) xv_create(frame, CANVAS_SHELL, 
			NULL);
 
	drawrect1 = (Drawrect) xv_create(shell, DRAWRECT, 
			XV_X, 10,
			XV_Y, 10,
			XV_WIDTH, 75,
			XV_HEIGHT, 130,
			NULL);
		
	drawtext1 = (Drawtext) xv_create(drawrect1, DRAWTEXT, 
			DRAWTEXT_STRING, "Red",
			DRAWTEXT_FONT, romankana,
			RECTOBJ_DBL_CLICK_PROC, dbl_click_proc,
			XV_X, 20,
			XV_Y, 10,
			RECTOBJ_DRAGGABLE, TRUE,
			RECTOBJ_FOREGROUND_COLOR, RED,
			NULL);

	drawtext2 = (Drawtext) xv_create(drawrect1, DRAWTEXT, 
			DRAWTEXT_STRING, "Green",
			DRAWTEXT_FONT, romankana,
			RECTOBJ_DBL_CLICK_PROC, dbl_click_proc,
			XV_X, 20,
			XV_Y, 40,
			RECTOBJ_DRAGGABLE, TRUE,
			RECTOBJ_FOREGROUND_COLOR, GREEN,
			NULL);

	drawtext3 = (Drawtext) xv_create(drawrect1, DRAWTEXT, 
			DRAWTEXT_STRING, "Blue",
			DRAWTEXT_FONT, romankana,
			RECTOBJ_DBL_CLICK_PROC, dbl_click_proc,
			XV_X, 20,
			XV_Y, 70,
			RECTOBJ_DRAGGABLE, TRUE,
			RECTOBJ_FOREGROUND_COLOR, BLUE,
			NULL);

	drawtext4 = (Drawtext) xv_create(drawrect1, DRAWTEXT, 
			DRAWTEXT_STRING, "Black",
			DRAWTEXT_FONT, romankana,
			RECTOBJ_DBL_CLICK_PROC, dbl_click_proc,
			XV_X, 20,
			XV_Y, 100,
			RECTOBJ_DRAGGABLE, TRUE,
			RECTOBJ_FOREGROUND_COLOR, BLACK,
			NULL);

	drawtext5 = (Drawtext) xv_create(shell, DRAWTEXT, 
			DRAWTEXT_STRING, "Drop Here",
			DRAWTEXT_FONT, romankana,
			XV_X, 10,
			XV_Y, 150,
			RECTOBJ_ACCEPTS_DROP, TRUE,
			RECTOBJ_DROP_PROC, drop_proc,
			NULL);

	xv_main_loop(frame); 
} 
 


void
dbl_click_proc(paint_window, event, canvas_shell, drawtext)
	Xv_window	paint_window;
	Event		*event;
	Canvas_shell	canvas_shell;
	Drawtext	drawtext;
{
	printf("The %s Drawtext object was double clicked.\n", 
			xv_get(drawtext, DRAWTEXT_STRING));
	xv_set(drawrect1,
		RECTOBJ_FOREGROUND_COLOR, 
			xv_get(drawtext, RECTOBJ_FOREGROUND_COLOR),
		NULL);
	print_selected_list();
}



void
drop_proc(canvas_shell, rectobj, drop_canvas_shell, drop_rectobj, drop_event)
	Canvas_shell	canvas_shell;
	Rectobj		rectobj;
	Canvas_shell	drop_canvas_shell;
	Rectobj		drop_rectobj;
	Event		*drop_event;
{
	xv_set(drop_rectobj,
	    RECTOBJ_FOREGROUND_COLOR, xv_get(rectobj, RECTOBJ_FOREGROUND_COLOR),
	    NULL);
	printf("dropped %s onto drop target\n",
			xv_get(rectobj, DRAWTEXT_STRING));
}
 


void
print_selected_list()
{
	Rectobj_list	*my_list;
	Rectobj		selected_rectobj;

	my_list = get_selected_list();

	if(my_list == NULL)
		return;

	printf("The selected objects are:  ");

	/* iterate through all the selected items */
	list_for(my_list) {

		selected_rectobj = RECTOBJ_LIST_HANDLE(my_list);

		/* print it out */
		printf("%s, ", (char*)xv_get(selected_rectobj, DRAWTEXT_STRING));
	}
	printf("\n\n");
}

