"?.title: Babaya",
"?.iconName: Babaya",
"?.geometry: -0-0",
"*shapeStyle: rectangle",
"*highlightThickness: 2",
"*Font: -adobe-new century schoolbook-bold-r-normal--*-120-*-*-*-*-iso8859-1",
"*Cursor: pirate",
"*input: True",
"*allowShellResize: True",
"*Command.Label: Babaya-Logout",
"*Command.Translations: #replace \\n\
	<EnterWindow>: highlight() \\n\
	<LeaveWindow>: reset() \\n\
	<Btn3Down>: set() \\n\
	<Btn3Up>: notify() unset()",
