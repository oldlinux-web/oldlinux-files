
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Xmu/WinUtil.h>
#include <X11/Xaw/Command.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static char version[] = "$Revision: 1.2b $";

Widget       topLevel;
Widget       logoutButton;
Atom         WM_PROTOCOLS,
             WM_DELETE_WINDOW;

struct _queryResources {
  Boolean         launchStartupApps;
  int             waitTime;
} qRes;

int
DummyErrorHandler(display, errorEvent)
	 Display              *display;
	 XErrorEvent          *errorEvent;
{
  return 0;
}

int
SendClientMessage(window, message)
	 Window window;
	 Atom   message;
{
  XClientMessageEvent  event;
  Display   *display = XtDisplay(topLevel);

  event.type = ClientMessage;
  event.window = window;
  event.message_type = WM_PROTOCOLS;
  event.format = 32;
  event.data.l[0] = message;
  event.data.l[1] = CurrentTime;
  XSendEvent (display, window, False, 0L, (XEvent*)&event);
  return 0;
}

int
SendDeleteWindow(window)
	 Window window;
{
  return SendClientMessage(window, WM_DELETE_WINDOW);
}

int
KillAllClients()
{
  Display           *display = XtDisplay(topLevel);
  Window             rootWindow = DefaultRootWindow(display),
                     dummyWindow,
                    *clientWindow;
  unsigned int       numClientWindows = 0,
                     i;
  XWindowAttributes  windowAttributes;

  XSync(display, False);
  XSetErrorHandler(DummyErrorHandler);
  
  if (XQueryTree(display, rootWindow, &dummyWindow, &dummyWindow, 
			 &clientWindow, &numClientWindows) == 0)
	return -1;
  
  for (i = 0; i < numClientWindows; i++)
	if (XGetWindowAttributes(display, clientWindow[i], &windowAttributes) &&
		(windowAttributes.map_state == IsViewable) && 
		(clientWindow[i] != XtWindow(topLevel)))
	  clientWindow[i] = XmuClientWindow(display, clientWindow[i]);
	else
	  clientWindow[i] = 0;
  
  for (i = 0; i < numClientWindows; i++)
	if (clientWindow[i]) SendDeleteWindow(clientWindow[i]);

  XSync(display, False);
  sleep(qRes.waitTime);

  for (i = 0; i < numClientWindows; i++)
	if (clientWindow[i]) XKillClient(display, clientWindow[i]);
  
  XSync(display, False);
  XSetErrorHandler(NULL);	

  XFree((char*)clientWindow);
  return 0;
}

void
KillAllExit()
{
  int exitStatus = KillAllClients();

  XtUnmapWidget(topLevel);
  XtDestroyApplicationContext(XtWidgetToApplicationContext(topLevel));
  exit(exitStatus);
}

void
ExitAction()
{
  exit(0);
}

/*---------------------------------------------------------------------------+
| GetResources - gets the application resources.
+---------------------------------------------------------------------------*/

void
GetResources()
{
#define offset(field) XtOffsetOf(struct _queryResources, field)
  static XtResource resources[] = {
    {"launchStartupApps", "LaunchStartupApps", XtRBoolean, sizeof(Boolean),
	   offset(launchStartupApps), XtRImmediate, (XtPointer)False},
    {"waitTime", "WaitTime", XtRInt, sizeof(int),
	   offset(waitTime), XtRImmediate, (XtPointer)10},
  };
#undef offset
  
  XtGetApplicationResources(topLevel, (XtPointer)&qRes, resources,
							XtNumber(resources), NULL, 0);
}

/*---------------------------------------------------------------------------+
| main: main routine.
+---------------------------------------------------------------------------*/

void
main(argc, argv)
	 int   argc;
	 char *argv[];
{
  XtAppContext appContext;

  static XrmOptionDescRec optionList[] =  {
    {"-startupapps", "launchStartupApps", XrmoptionNoArg, "True"},
    {"-nostartupapps", "launchStartupApps", XrmoptionNoArg, "False"},
    {"-waittime", "waitTime", XrmoptionSepArg, NULL},
  };

  static char    *fallbackResources[] = {
#include "Babaya.ad.h"
    NULL,
  };
  
  static XtActionsRec actionTable[] = {
    {"Exit", ExitAction},
  };

  /* ---------------------------------------------------------------------- */

  topLevel = XtAppInitialize(&appContext, "Babaya", optionList, 
							 XtNumber(optionList), &argc, argv,
							 fallbackResources, NULL, 0);

  if (argc > 1)
	fprintf(stderr, 
  "\n%s\n>> Babaya Error: Wrong or incomplete parameter `%s', ignored.\n%s\n",
			"------------------------------------------------------------",
			argv[1],
			"------------------------------------------------------------");


  logoutButton = XtCreateManagedWidget("exit", commandWidgetClass, topLevel,
									 NULL, 0);
  XtAddCallback(logoutButton, XtNcallback, KillAllExit, NULL);

  /* ---------------------------------------------------------------------- */

  WM_PROTOCOLS = XInternAtom(XtDisplay(topLevel), "WM_PROTOCOLS", False);
  WM_DELETE_WINDOW = XInternAtom(XtDisplay(topLevel), "WM_DELETE_WINDOW", 
								 False);
  
  XtAppAddActions(XtWidgetToApplicationContext(topLevel), actionTable, 
				  XtNumber(actionTable));
  XtOverrideTranslations(topLevel,
		            XtParseTranslationTable("<Message>WM_PROTOCOLS: Exit()"));

  /* ---------------------------------------------------------------------- */

  GetResources();

  if(qRes.launchStartupApps)
	system("sh $HOME/.babaya/startup >& $HOME/.babaya/startup-errors &");

  /* ---------------------------------------------------------------------- */

  XtRealizeWidget(topLevel);
  XSetWMProtocols(XtDisplay(topLevel), XtWindow(topLevel), 
				  &WM_DELETE_WINDOW, 1);
  XtAppMainLoop(appContext);
}
