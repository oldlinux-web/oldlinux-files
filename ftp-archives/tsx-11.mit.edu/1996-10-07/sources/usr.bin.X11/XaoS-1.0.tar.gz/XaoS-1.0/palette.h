#ifndef PALETTE_H
#define PALETTE_H

#include "zoom.h"

int mkpalette(zoom_context *, int (*)(int, int, int, int), int);

#endif /* PALETTE_H */
