#include <limits.h>
#include <math.h>
#include <string.h>
#include "config.h"
#include "complex.h"
#include "formulas.h"
#include "zoom.h"

int coloringmode;
int incoloringmode;

char *incolorname[] = {
	"maxiter",
	"zmag",
};

char *outcolorname[] = {
	"iter",
	"iter+real",
	"iter+imag",
	"iter+real/imag",
	"iter+real+imag+real/imag",
	"binary decomposition"
};

#define OUTPUT() if(iter>=MAXITER)\
		return(incoloringmode?incolor_output(zre,zim,iter,MAXITER):iter); else \
		return(!coloringmode?iter:color_output(zre,zim,iter,MAXITER))

int INLINE color_output(number_t zre, number_t zim, int iter, int maxiter)
{
	switch (coloringmode) {
	case 1:		/* real */
		return (iter + zre);
		break;
	case 2:		/* imag */
		return (iter + zim);
		break;
	case 3:		/* real / imag */
		return (iter + zre / zim);
		break;
	case 4: 	/* all of the above */
		return (iter + zre + zim + zre/zim);
		break;
	case 5:
		if(zim<0) return(iter); else return(MAXITER-iter);
		break;
	default:
		break;
	}
	return iter;
}

int INLINE incolor_output(number_t zre, number_t zim, int iter, int maxiter)
{
	switch (incoloringmode) {
	case 1:		/* zmag */
		return ((zre*zre+zim*zim)*(number_t)(maxiter>>1)+1);
		break;
	default:
		break;
	}
	return iter;
}


#if 0
static int mand_calc(number_t cre, number_t cim) REGISTERS(2);
static int mand3_calc(number_t cre, number_t cim) REGISTERS(2);
static int mand4_calc(number_t cre, number_t cim) REGISTERS(2);
static int mand5_calc(number_t cre, number_t cim) REGISTERS(2);
static int barsley1_calc(number_t cre, number_t cim) REGISTERS(2);
static int newton_calc(number_t cre, number_t cim) REGISTERS(2);
static int phoenix_calc(number_t cre, number_t cim) REGISTERS(2);
#endif

#ifdef FIXEDPOINT
static int mand_calc(register int cre, register int cim,register int pre, register int pim)
{
	register unsigned int rp = 0, ip = 0;
	register int iter = 0;
	register int zre, zim;
	CONST register int maxiter=MAXITER;

	zre=cre,zim = cim;
	rp=(zre>>(SIFT/2))*(zre>>(SIFT/2));
	ip=(zim>>(SIFT/2))*(zim>>(SIFT/2));
#if 1
	while ((rp + ip < 4 << SIFT) && (iter < maxiter)) {
		zim >>= SIFT / 2;
		ip = (zim * zim);
		zim = (zim * (zre >> (SIFT / 2 - 1))) + pim;
		zre >>= SIFT / 2;
		rp = (zre * zre);
		zre = rp - ip + pre;
		iter++;
	}
#else
	while ((rp + ip < 4 << SIFT) && (iter < MAXITER)) {
		ip = (zim * zim) >> SIFT;
		zim = ((zim * zre) >> (SIFT - 1)) + pim;
		rp = (zre * zre) >> SIFT;
		zre = rp - ip + pre;
		iter++;
	}
#endif
	return(iter);
}

struct formula formulas[] =
{
	{
		mand_calc, {"Mandelbrot","Julia"},
		{0.5, -2.0, 1.25, -1.25},
		1,0.0,0.0,
		{
			{INT_MAX, 0, 0, NULL},
			{INT_MAX, 0, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL}
		},
	},
};
#else

#if 0
#define HASHS	65536
#define HASHMASK 0xffff
#define HASHF 	(((int)((zre+zim+rp+ip+4)*65536.0*16))&HASHMASK)

int table[HASHS];

static int mand_calc(register number_t cre, register number_t cim, register number_t pre,register number_t pim)
{
	register number_t rp = 0, ip = 0;
	register int iter = 0,index;
	register number_t zre, zim;
	CONST register int maxiter=MAXITER;
	/*struct ltable*/ int *t;
	static int counter;
	static int sum;

	counter++;
	zre = cre;
	zim = cim;
	while ((rp + ip < 4) && (iter < maxiter)) {
		if(iter>20&&iter<60) {
		index=400*zre+160000*zim+5*160000;
		t=table+(index+counter)%HASHMASK;
		if(*t==counter) {
#if 0
			static int c1;
			c1++;
			sum+=iter;
			printf("%i\n",sum/c1);
#endif
			return MAXITER;
		} else {
			*t=counter;
		}
		}
		ip = (zim * zim);
		zim = (zim * zre) * 2 +pim;
		rp = (zre * zre);
		zre = rp - ip + pre;
		iter++;
	}
	OUTPUT();
}
#endif

static int mand_calc(register number_t cre, register number_t cim, register number_t pre,register number_t pim)
{
	register number_t rp = 0, ip = 0;
	register int iter = 0;
	register number_t zre, zim;
	CONST register int maxiter=MAXITER;
	zre = cre;
	zim = cim;
	while ((rp + ip < 4) && (iter < maxiter)) {
		ip = (zim * zim);
		zim = (zim * zre) * 2 +pim;
		rp = (zre * zre);
		zre = rp - ip + pre;
		iter++;
	}
	OUTPUT();
}

#if 0

static int mand_calc1(register number_t cre, register number_t cim, register number_t pre,register number_t pim)
{
	register number_t rp = 0, ip = 0, tr, ti, x,y;
	register int iter = 0;
	register number_t zre, zim;
	CONST register int maxiter=MAXITER;

	rp = zre = cre;
	ip = zim = cim;
	while ((zre*zre + zim*zim < 4) && (iter < maxiter)) {
		c_pow2(zre,zim, tr, ti);
		x = zre, y = zim;
		zre = tr + rp + pre;
		zim = ti + ip + pim;
		rp = x, ip = y;
		iter++;
	}
	OUTPUT();
}
#endif

static int mand3_calc(register number_t cre, register number_t cim, register number_t pre,register number_t pim)
{
	register number_t rp = 0, ip = 0;
	register int iter = 0;
	register number_t zre, zim;
	CONST register int maxiter=MAXITER;

	zre = cre;
	zim = cim;
	rp=zre*zre;
	ip=zim*zim;
	while ((rp + ip < 4) && (iter < maxiter)) {
		rp = zre * (rp - 3 * ip);
		zim = zim * (3 * zre * zre - ip) + pim;
		zre = rp + pre;
		rp = zre * zre;
		ip = zim * zim;
		iter++;
	}
	OUTPUT();
}

static int mand4_calc(register number_t cre, register number_t cim, register number_t pre,register number_t pim)
{
	register number_t rp = 0, ip = 0;
	register int iter = 0;
	register number_t zre, zim;
	CONST register int maxiter=MAXITER;

	zre = cre;
	zim = cim;
	rp = zre * zre;
	ip = zim * zim;
	while ((rp + ip < 4) && (iter < maxiter)) {
		rp = rp * rp - 6 * rp * ip + ip * ip + pre;
		zim = 4 * zre * zre * zre * zim - 4 * zre * ip * zim + pim;
		zre = rp;
		rp = zre * zre;
		ip = zim * zim;
		iter++;
	}
	OUTPUT();
}

static int mand5_calc(register number_t cre, register number_t cim, register number_t pre,register number_t pim)
{
	register number_t rp = 0, ip = 0, t;
	register int iter = 0;
	register number_t zre, zim;
	CONST register int maxiter=MAXITER;

	zre = cre;
	zim = cim;
	while ((rp + ip < 4) && (iter < maxiter)) {
		c_pow4(zre, zim, rp, ip);
		c_mul(zre, zim, rp, ip, t, zim);
		zre = t + pre;
		zim += pim;
		rp = zre * zre;
		ip = zim * zim;
		iter++;
	}
	OUTPUT();
}

static int mand6_calc(register number_t cre, register number_t cim, register number_t pre,register number_t pim)
{
	register number_t rp = 0, ip = 0, t;
	register int iter = 0;
	register number_t zre, zim;
	CONST register int maxiter=MAXITER;

	zre = cre;
	zim = cim;
	while ((rp + ip < 4) && (iter < maxiter)) {
		c_pow3(zre, zim, rp, ip);
		c_pow3(rp, ip, t, zim);
		zre = t + pre;
		zim += pim;
		rp = zre * zre;
		ip = zim * zim;
		iter++;
	}
	OUTPUT();
}

static int barnsley1_calc(register number_t cre, register number_t cim, register number_t pre,register number_t pim)
{
	register number_t rp = 0;
	register int iter = 0;
	register number_t zre, zim;
	CONST register int maxiter=MAXITER;

	zre = cre;
	zim = cim;
	while ((zre * zre + zim * zim < 4) && (iter < maxiter)) {
		if (zre >= 0) {
			c_mul(zre - 1, zim, pre, pim, rp, zim);

		} else {
			c_mul(zre + 1, zim, pre, pim, rp, zim);
		}
		zre = rp;
		iter++;
	}
	OUTPUT();
}

static int newton_calc(register number_t cre, register number_t cim, register number_t pre,register number_t pim)
{
	register number_t rp, ip;
	register int iter = 0;
	register number_t zre, zim, zre1 = 10.0, zim1 = 10.0;
	register number_t tr, ti;
	CONST register int maxiter=MAXITER;

	zre = cre;
	zim = cim;
	while (iter < maxiter && distance(zre1, zim1, zre, zim) > 1E-6) {
		iter++;
		zre1 = tr = zre;
		zim1 = ti = zim;
		c_pow2(zre, zim, tr, ti);
		c_mul(tr, ti, zre, zim, rp, ip);
		c_div(2 * rp + 1, 2 * ip, 3 * tr, 3 * ti, zre, zim);
	}
	OUTPUT();
}

#if 0
static int phoenix_err_calc(register number_t cre, register number_t cim, register number_t pre,register number_t pim)
{
	register number_t rp, ip, p1 = 0.56667000000000001, p2 = -0.5;
	register int iter = 0;
	register number_t zre, zim, zpr, zpm;
	register number_t tr, ti;
	CONST register int maxiter=MAXITER;

	zre = cre;
	zim = cim;
	while ((zpr * zpm + zpr * zpm < 4) && (iter < maxiter)) {
		tr = zre * zim;
		zpr = zre * zre - zim * zim + p1 + p2 * zpr;
		zpm = tr + tr + p2 * zpm;
		zre = zpr;
		zim = zpm;
		iter++;
	}
	return (iter);
}
#endif

static int phoenix_calc(register number_t cre, register number_t cim, register number_t pre,register number_t pim)
{
	register int iter = 0;
	register number_t zre, zim, zpr, zpm, rp = 0.0, ip = 0.0;
	CONST register int maxiter=MAXITER;

	zre = cre;
	zim = cim;
	zpr = zre * zre, zpm = zim * zim;
	while ((zpr + zpm < 4) && (iter < maxiter)) {
		zpr = zpr - zpm + pre + pim * rp;
		zpm = 2 * zre * zim + pim * ip;
		rp = zre, ip = zim;
		zre = zpr;
		zim = zpm;
		zpr = zre * zre, zpm = zim * zim;
		iter++;
	}
	OUTPUT();
}

static int octo_calc(register number_t cre, register number_t cim, register number_t pre,register number_t pim)
{
	register number_t rp, ip, tr, ti;
	register int iter = 0;
	CONST register int maxiter=MAXITER;
	register number_t zre = cre, zim = cim, zpr = 0, zpm = 0;

	while ((zpr * zpr + zpm * zpm < 4) && (iter < maxiter)) {
		rp = zre;
		ip = zim;
		c_pow3(zre, zim, tr, ti);
		c_add(tr, ti, zpr, zpm, zre, zim);
		zpr = rp;
		zpm = ip;
		iter++;
	}
	OUTPUT();
	return (iter);
}

/*FIXME: symetry for wont work */
symetry sym6[] =
{
	{0, 1.73205080758},
	{0, -1.73205080758}
};

symetry sym8[] =
{
	{0, 1},
	{0, -1}
};

symetry sym16[] =
{
	{0, 1},
	{0, -1},
	{0, 0.414214},
	{0, -0.414214},
	{0, 2.414214},
	{0, -2.414214}
};

struct formula formulas[] =
{
	{
		mand_calc, {"Mandelbrot","Julia"},
		{0.5, -2.0, 1.25, -1.25},
		1,0.0,0.0,
		{
			{INT_MAX, 0, 0, NULL},
			{INT_MAX, 0, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL}
		},
		{
			{INT_MAX, 0, 0, NULL},
			{INT_MAX, 0, 0, NULL}
		},
	},
	{
		mand3_calc, {"Mandelbrot^3","Julia^3"},
		{1.25, -1.25, 1.25, -1.25},
		1,0.0,0.0,
		{
			{0, 0, 0, NULL},
			{INT_MAX , 0, 0, NULL},
			{0, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{0, INT_MAX, 0, NULL}
		},
		{
			{0, 0, 0, NULL},
			{0, 0, 0, NULL}
		},
	},
	{
		mand4_calc, {"Mandelbrot^4","Julia^4"},
		{1.25, -1.25, 1.25, -1.25},
		1,0.0,0.0,
		{
			{INT_MAX, 0, 2, sym6},
			{INT_MAX, 0, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL}
		},
		{
			{INT_MAX, 0, 2, sym6},
			{INT_MAX, 0, 2, sym6}
		}
	},
	{
		mand5_calc, {"Mandelbrot^5","Julia^5"},
		{1.25, -1.25, 1.25, -1.25},
		1,0.0,0.0,
		{
			{0, 0, 2, sym8},
			{INT_MAX, 0, 0, NULL},
			{0,INT_MAX, 0, NULL},
			{INT_MAX,INT_MAX, 0, NULL},
			{INT_MAX,INT_MAX, 0, NULL},
			{0,INT_MAX, 0, NULL}
		},
		{
			{0, 0, 2, sym8},
			{0, 0, 2, sym8}
		},
	},
	{
		mand6_calc, {"Mandelbrot^6","Julia^6"},
		{1.25, -1.25, 1.25, -1.25},
		1,0.0,0.0,
		{
			{0, 0, 6, sym16},
			{INT_MAX, 0, 0, NULL},
			{0, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{0, INT_MAX, 0, NULL}
		},
		{
			{0, 0, 6, sym16},
			{0, 0, 6, sym16}
		},
	},
	{
		octo_calc, {"Octal","Octal"},
		{1.25, -1.25, 1.25, -1.25},
		0,0.0,0.0,
		{
			{0, 0, 6, sym16},
			{INT_MAX, 0, 0, NULL},
			{0, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{0, INT_MAX, 0, NULL}
		},
		{
			{0, 0, 6, sym16},
			{0, 0, 6, sym16}
		},
	},
	{
		newton_calc, {"Newton","Newton"},
		{1.25, -1.25, 1.25, -1.25},
		1,0.0,0.0,
		{
			{INT_MAX, 0, 2, sym6},
			{INT_MAX, 0, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL}
		},
		{
			{INT_MAX, 0, 2, sym6},
			{INT_MAX, 0, 2, sym6}
		},
	},
	{
		barnsley1_calc, {"Barnsley1 Mandelbrot","Barnsley1"},
		{1.25, -1.25, 1.25, -1.25},
		0,-0.6,1.1,
		{
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL}
		},
		{
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL}
		},
	},
	{
		phoenix_calc, {"MandPhoenix","Phoenix"},
		{1.25, -1.25, 1.25, -1.25},
	        0,0.56667000000000001,-0.5,
		{
			{INT_MAX, 0, 0, NULL},
			{INT_MAX, 0, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL},
			{INT_MAX, INT_MAX, 0, NULL}
		},
		{
			{INT_MAX, 0, 0, NULL},
			{INT_MAX, 0, 0, NULL}
		},
	},
};
#endif

struct formula *currentformula = formulas;
CONST int nformulas = sizeof(formulas) / sizeof(struct formula);
