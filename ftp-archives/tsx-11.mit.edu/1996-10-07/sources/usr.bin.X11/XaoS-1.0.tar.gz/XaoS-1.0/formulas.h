#ifndef FORMULAS_H
#define FORMULAS_H

#include "config.h"

#define INCOLORING 2
#define OUTCOLORING 6

typedef struct {
	double mc, nc;
	double mi, ni;
} vinfo;

typedef struct {
	double y0, k;
} symetry;

struct symetryinfo {
	number_t xsym, ysym;
	int nsymetries;
	symetry *symetry;
};

struct formula {
	int (*calculate) (number_t, number_t, number_t, number_t) /*REGISTERS(2) */ ;
	char *name[2];
	vinfo v;
	int mandelbrot;
	number_t pre,pim;
	struct symetryinfo out[OUTCOLORING];
	struct symetryinfo in[INCOLORING];
};

extern struct formula formulas[];
extern char *incolorname[];
extern char *outcolorname[];
extern CONST int nformulas;
extern int coloringmode;
extern int incoloringmode;

#endif /* FORMULAS_H */
