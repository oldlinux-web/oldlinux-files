#ifndef UI_H
#define UI_H

#define BUTTON1 256
#define BUTTON2 512
#define BUTTON3 1024

void ui_do_fractal();
void ui_message();
void ui_init(zoom_context *, void (*)(), int (*)(), int, void (*)(int, int, char *), int);
void ui_tbreak();
void ui_status();
void ui_savefile();
void ui_coloringmode();
void ui_mandelbrot(int,int);
void ui_incoloringmode();
int ui_autopilot();
void ui_speedup();
void ui_help();
void ui_updateparameters();
void ui_slowdown();
int ui_mouse(int, int, int, int);
int ui_inverse();

#endif /* UI_H */
