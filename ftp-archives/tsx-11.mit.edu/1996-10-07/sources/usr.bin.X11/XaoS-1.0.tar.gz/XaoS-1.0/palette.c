#include <stdlib.h>
#include "config.h"
#include "zoom.h"
#include "palette.h"

#define SEGMENTSIZE 8
#define NSEGMENTS (255/SEGMENTSIZE)

static unsigned char colors[NSEGMENTS][3];
static zoom_context *context;
static int (*set_color) (int, int, int, int);

int mksmooth(int nsegments)
{
	int i, y, n;
	float r, g, b, rs, gs, bs;

	for (i = 0; i < nsegments; i++) {
		r = colors[i][0];
		g = colors[i][1];
		b = colors[i][2];
		rs = (colors[(i + 1) % nsegments][0] - r) / SEGMENTSIZE;
		gs = (colors[(i + 1) % nsegments][1] - g) / SEGMENTSIZE;
		bs = (colors[(i + 1) % nsegments][2] - b) / SEGMENTSIZE;
		for (y = 0; y < SEGMENTSIZE; y++) {
			if ((n = context->colors[i * SEGMENTSIZE + y] = set_color((int) r, (int) g, (int) b, i == 0 && y == 0)) == -1)
				return 0;
			n = (unsigned char) n;
			context->cmap[0][n] = (unsigned char) r;
			context->cmap[1][n] = (unsigned char) g;
			context->cmap[2][n] = (unsigned char) b;
			r += rs;
			g += gs;
			b += bs;
		}
	}
	context->num_colors = i * SEGMENTSIZE;
	return 1;
}

void randomize_segments()
{
	int i = 0;

#if 0
	colors[0][0] = rand() % 10;
	colors[0][1] = rand() % 10;
	colors[0][2] = rand() % 10;
#endif
	for (i = 0; i < NSEGMENTS; i += 2)
		colors[i][0] = rand() % 35,
		    colors[i][1] = rand() % 35,
		    colors[i][2] = rand() % 35,
		    colors[i + 1][0] = rand() % 256,
		    colors[i + 1][1] = rand() % 256,
		    colors[i + 1][2] = rand() % 256;
}

int mkpalette(zoom_context * c, int (*sethandler) (int, int, int, int), int randomsize)
{
	int i;

	set_color = sethandler;
	context = c;
	randomize_segments();
	if (randomsize)
		i = rand() % NSEGMENTS;
	else
		i = NSEGMENTS;
	if (i < 0)
		i = 1;
	for (; i > 0; i--)
		if (mksmooth(i))
			break;
	return (context->num_colors);
#if 0
	int ncolors = 16, mul = 16;
	do {
		for (i = 0; i < ncolors; i++)
			if ((c->colors[i] = sethandler(i * mul, i * mul, i * mul, i == 0)) == -1) {
				ncolors /= 2, mul *= 2;
				break;
			}
	}
	while (i != ncolors);
	c->num_colors = i;
	return (c->num_colors);
#endif
}

