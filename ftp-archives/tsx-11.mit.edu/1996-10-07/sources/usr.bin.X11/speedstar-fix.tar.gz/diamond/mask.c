#include <stdio.h>
#include <dos.h>

#define T(a,b) if (val & a) X |= b

unsigned shift[8] = { 1,2,4,8,16,32,64,64 };

int main(int argc, char **argv)
  {
    unsigned adr;
    unsigned long val;
    unsigned long X=0;

    sscanf(argv[1],"%x",&adr);
    val=*(unsigned long far *)MK_FP(0xC000,adr);

    T(0x008000,0x000001);
    T(0x004000,0x000002);
    T(0x002000,0x000004);
    T(0x001000,0x000008);
    T(0x000800,0x000010);
    T(0x000400,0x000020);
    T(0x000200,0x000040);
    T(0x000100,0x000080);
    T(0x000080,0x000100);
    T(0x000040,0x000200);
    T(0x000020,0x000400);
    T(0x000010,0x000800);
    T(0x000008,0x001000);
    T(0x000004,0x002000);
    T(0x000002,0x004000);
    T(0x000001,0x008000);
    T(0x800000,0x010000);
    T(0x400000,0x020000);
    T(0x200000,0x040000);
    T(0x100000,0x080000);
    T(0x080000,0x100000);
    T(0x040000,0x200000);
    T(0x020000,0x400000);
    T(0x010000,0x800000);
    printf("%06lX = %5lu kHz\n",X,((32l*2*14318+4)*(((X>>10)&127)+3)/((X&127)+2))/shift[(X>>7)&3]/32);
    return 0;
  }
