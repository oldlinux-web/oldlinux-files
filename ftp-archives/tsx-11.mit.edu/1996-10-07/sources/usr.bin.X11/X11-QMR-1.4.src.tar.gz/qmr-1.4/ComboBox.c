/*
 * ComboBox.c - Das schon lange schmerzlich vermisste Combo-Box-
 *              Widget -- nun endlich auf fuer Motif!
 * 
 * Version 1.22a
 *
 * Letzte Modifikation: 
 * 07.05.1994    Drag'n'Drop funktioniert endlich!!! Zudem Anpassung an
 *               den fvwm ausgefuehrt ('st vom Focus-Verhalten ja ein halber
 *               twm). Hach', so'ne Linux-Box mit Motif 1.2 macht doch
 *               einfach Spass... vor allem geht hier so richtig die Post ab.
 *               Das kann man ja von M$ Windoze (Windoze for Mondays) nicht
 *               behaupten!
 * 14.04.1994    Ein paar Speicherlecks korrigiert.
 * 21.02.1994    Die Resourcen XmNitems und XmNitemCount lassen sich nun 
 *               auch von einer Resourcendatei aus initialisieren. ACHTUNG: 
 *		 diese beiden Resourcen mussen immer beide beim Aufruf von 
 *		 XtSetValues zugleich angegeben werden, ansonsten werden
 *               diese Angaben ignoriert.
 * 03.02.1994    Convenience-Funktionen auf Vordermann gebracht und noch
 *		 einen Callback eingebaut, der immer dann aufgerufen wird, 
 *		 wenn die List angezeigt oder wieder versteckt wird.
 * 01.02.1994    Motif 1.2-fest!!! Das wird aber heute abend gefeiert!!
 *               Endlich EIN Alptraum weniger! Naja, Drag'n'Drop bleibt
 *		 noch zu loesen. Spaeter...
 * 31.01.1994    VAX-fest (mit Hilfe von Vincenct Li)
 *               owlm sollte man abschaffen! Aber es scheint so, als ob
 *               ich jetzt doch noch das FocusOut-Problem geknackt habe.
 *               Ebenso die OSF...mit viel Arbeit habe ich nun auch noch
 *               eine anstaendige Initialisierung der Fontliste des Label-
 *               Kinds erreicht.
 * 12.01.1994	 Revisionsstand: 1.10a
 *               nun wirklich voll ANSI-faehiger C-Code
 *               Pixmaps werden ggf. aufgeraeumt; Druckrichtung
 *               wird vom Vater erfragt und an das Label weiter-
 *               gegeben.
 *               ESC-Behandlung implementiert.
 *               Spiegel-Resourcen-Initialisierung aus Resourcen-Daten-
 *               bank implementiert.
 *               Weitergabe von neu gesetzten Farben an die Kinder
 *               implementiert.
 *               Combo-Box kann jetzt wahlweise auch links neben dem
 *               Eingabefeld ein Label anzeigen.
 * 09.12.1993    Revisionsstand: 1.00
 *               erste oeffentlich zugaengliche Version der Combo-Box
 * 
 * (c) 1993, 1994 Harald Albrecht
 * Institut fuer Geometrie und Praktische Mathematik
 * RWTH Aachen, Germany
 * albrecht@igpm.rwth-aachen.de
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program (see the file COPYING for more details);
 * if not, write to the Free Software Foundation, Inc., 675 Mass Ave, 
 * Cambridge, MA 02139, USA.
 *
 */

#include <X11/IntrinsicP.h>
#include <X11/StringDefs.h>
#include <X11/cursorfont.h>
#include <X11/Shell.h>
#ifdef VMS /* Huch, wo gibt's denn noch sowas ... ?! */
           /* Bitte keine Mail bzgl. dieser Bemerkung schicken...
	    * Ich weiss, das ist ein Vorurteil...aber es gibt
	    * ja auch wahre Vorurteile....
	    */
#include <Xmu/Converters.h>
#else
#include <X11/Xmu/Converters.h>
#endif
#include <Xm/ArrowB.h>
#include <Xm/TextF.h>
#include <Xm/List.h>
#include <Xm/LabelP.h>
#include <string.h>

#include "ComboBoxP.h"

#include <stdio.h>

/* --- Systemspezifische Definitionen */
#ifdef VMS
#define strcasecmp(s1, s2) strcmp(s1, s2)
#endif

/* --- sonstiger Quark */
#ifdef DEBUG
#define LOG(p1)      fprintf(stderr, p1);
#define LOG2(p1, p2) fprintf(stderr, p1, p2);
#else
#define LOG(p1)
#define LOG2(p1, p2)
#endif

/* --------------------------------------------------------------------
 * Resourcen-Liste...
 * Hier werden diejenigen Resourcen definiert, die von "aussen" - also 
 * fuer den Programmierer oder Anwender - benutzbar und veraenderbar
 * sind.
 * 
 * Der Aufbau der einzelnen Eintraege ist immer wieder gleich:
 * Resourcen-Name	XmN... oder XtN
 * Resourcen-Klasse     XmC... oder XtC
 * Resourcen-Type       XmR... oder XtR (Datentyp der Variable in der
 *                      struct der jeweiligen Widgetinstanz)
 * Resourcen-Groesse	aktuelle Groesse dieses Datentyps
 * Resourcen-Offset     Lage der Variable innerhalb der struct der
 *			Widgetinstanz
 * Defaultwert-Type     Typ des Defaultwertes
 * Defaultwert		(normalerweise) Zeiger auf den Defaultwert
 */
#define offset(field) XtOffsetOf(XmComboBoxRec, field)
static XtResource resources[] = {
    { /* Eingabefeld kann veraendert werden, oder aber es sind nur
       * die Vorgaben aus der Liste auswaehlbar.
       */
	XmNeditable, XmCEditable, XmRBoolean, sizeof(Boolean), 
	offset(combobox.Editable), XmRString, "False"
    }, 
    { /* Liste wird automatisch sortiert -- wie konnten die bei
       * der OSF denn SOETWAS nur vergessen ??
       */
	XmNsorted, XmCSorted, XmRBoolean, sizeof(Boolean),
	offset(combobox.Sorted), XmRString, "False"
    }, 
    { /* Anzahl auf einmal sichtbarer Eintraege in der Liste (ent-
       * spricht damit der Listenhoehe.
       */
	XmNvisibleItemCount, XmCVisibleItemCount, XmRInt, sizeof(int), 
	offset(combobox.VisibleItemCount), XmRImmediate, (XtPointer) 8
    }, 
    { /* Fuer das Eingabefeld sowie die Liste verwandte Fonts */
	XmNfontList, XmCFontList, XmRFontList, sizeof(XmFontList), 
	offset(combobox.Font), XmRImmediate, NULL
    }, 
    { /* Rueckruf bei Anwahl */
	XmNselectionCallback, XmCSelectionCallback, XmRCallback, 
	sizeof(XtCallbackList), 
	offset(combobox.SelectionCBL), XmRCallback, NULL
    }, 
    { /* Rueckruf bei Liste ausklappen/verstecken */
	XmNdropDownCallback, XmCDropDownCallback, XmRCallback, 
	sizeof(XtCallbackList), 
	offset(combobox.DropDownCBL), XmRCallback, NULL
    }, 
    { /* Verhalten der ausgeklappten Liste bei Focus-Out */
	XmNpersistentDropDown, XmCPersistentDropDown, XmRBoolean, 
	sizeof(Boolean), 
	offset(combobox.Persistent), XmRString, "False"
    }, 
    { /* Wie verhaelt sich der Window-Manager? */
	XmNtwmHandlingOn, XmCTwmHandlingOn, XmRBoolean, sizeof(Boolean), 
	offset(combobox.TwmHandlingOn), XmRString, "False"
    }, 
    { /* Label anzeigen oder nicht? */
	XmNshowLabel, XmCShowLabel, XmRBoolean, sizeof(Boolean), 
	offset(combobox.ShowLabel), XmRString, "False"
    }, 
    { /* Abstand zw. linkem Rand Eingabefeld und linkem Rand Liste */
	XmNdropDownOffset, XmCDropDownOffset, XmRPosition, 
	sizeof(Position), offset(combobox.DropDownOffset), 
	XmRImmediate, (XtPointer) -1
    }, 
    { /* Neue Voreinstellung bzgl. des Randes */
	XmNborderWidth, XmCBorderWidth, XmRDimension, sizeof(Dimension), 
	offset(core.border_width), XmRImmediate, (XtPointer) 0
    },
    {
	XmNdropDownCursor, XmCDropDownCursor, XmRCursor, sizeof(Cursor),
	offset(combobox.ArrowCursor), XmRString, "center_ptr"
    }
}; /* resources[] */

/* --------------------------------------------------------------------
 * Funktions-Prototypen fuer die 'Methoden' des ComboBox-Widgets
 */
static void             Initialize(Widget, XmComboBoxWidget, ArgList, 
			    Cardinal *);
static void             Destroy(XmComboBoxWidget);
static void             Resize(XmComboBoxWidget);
static Boolean          SetValues(XmComboBoxWidget, XmComboBoxWidget, XmComboBoxWidget, 
			    ArgList, Cardinal *);
static void             GetValuesAlmost(XmComboBoxWidget, ArgList, Cardinal *);
static XtGeometryResult QueryGeometry(XmComboBoxWidget, XtWidgetGeometry *, 
			    XtWidgetGeometry *); 
static XtGeometryResult GeometryManager(XmComboBoxWidget, XtWidgetGeometry *, 
                            XtWidgetGeometry *);
static void		ClassInit();
/* --------------------------------------------------------------------
 * diverse restliche Prototypen... naja, hier halt etwas mager!
 */
static void ShowHideDropDownList(XmComboBoxWidget w, XEvent *event, 
                                 Boolean Show);
static void ShellCallback(Widget w, XtPointer cbw, 
                          XEvent *event, Boolean *ContDispatch);
/* --------------------------------------------------------------------
 * Klassen-Definition
 */
XmComboBoxClassRec xmComboBoxClassRec = {
    { /*** core-Klasse ***/
    /* superclass		    */	(WidgetClass) &xmManagerClassRec, 
    /* class_name		    */	"XmComboBox",
    /* widget_size		    */	sizeof(XmComboBoxRec),
    /* class_initialize   	    */	(XtProc) ClassInit,
    /* class_part_initialize	    */	NULL,
    /* class_inited       	    */	False, /* IMMER mit FALSE initialisieren !! */
    /* initialize	  	    */	(XtInitProc) Initialize,
    /* initialize_hook		    */	NULL,
    /* realize		  	    */	XtInheritRealize,
    /* actions		  	    */	NULL,
    /* num_actions	  	    */	0,
    /* resources	  	    */	resources,
    /* num_resources	  	    */	XtNumber(resources),
    /* xrm_class	  	    */	NULLQUARK,
    /* compress_motion	  	    */	True,
    /* compress_exposure  	    */	XtExposeCompressMultiple,
    /* compress_enterleave	    */	True,
    /* visible_interest	  	    */	False,
    /* destroy		  	    */	(XtWidgetProc) Destroy,
    /* resize		  	    */	(XtWidgetProc) Resize,
    /* expose		  	    */	NULL,
    /* set_values	  	    */	(XtSetValuesFunc) SetValues,
    /* set_values_hook		    */	NULL,
    /* set_values_almost	    */	XtInheritSetValuesAlmost,
    /* get_values_hook		    */	(XtArgsProc) GetValuesAlmost,
    /* accept_focus	 	    */	NULL,
    /* version			    */	XtVersion,
    /* callback_private   	    */	NULL,
    /* tm_table		   	    */	NULL,
    /* query_geometry		    */	(XtGeometryHandler) QueryGeometry,
    /* display_accelerator	    */	XtInheritDisplayAccelerator,
    /* extension          	    */	NULL
    }, 
    { /*** composite-Klasse ***/
    /* geometry_manager		    */	(XtGeometryHandler) GeometryManager,
    /* change_managed		    */	XtInheritChangeManaged,
    /* insert_child		    */	XtInheritInsertChild,
    /* delete_child		    */	XtInheritDeleteChild,
    /* extension		    */	NULL
    }, 
    { /*** constraint-Klasse ***/
    /* resources		    */	NULL,
    /* num_resources		    */	0,
    /* constraint_size		    */	sizeof(XmManagerConstraintPart),
    /* initialize		    */	NULL,
    /* destroy			    */	NULL,
    /* set_values		    */	NULL,
    /* extension		    */	NULL
    }, 
    { /*** xmManager-Klasse ***/
    /* translations                 */	XtInheritTranslations,
    /* syn_resources                */	NULL,
    /* num_syn_resources            */	0,
    /* syn_constraint_resources     */	NULL,
    /* num_syn_constraint_resources */	0,
    /* parent_process		    */	XmInheritParentProcess,
    /* extension		    */	NULL
    }, 
    { /*** combobox-Klasse ***/
    /*				    */	0
    }
}; /* xmComboBoxClassRec */
WidgetClass xmComboBoxWidgetClass = (WidgetClass) &xmComboBoxClassRec;

/* --------------------------------------------------------------------
 * --------------------------------------------------------------------
 * Translation-Tabelle (hier allerdings fuer das Eingabefeld!)
 * Tjaja....mit der Reihenfolge von Translations ist das schon so eine
 * ziemlich boese Sache!
 */
static char newEditTranslations[] =
    "Alt<Key>osfDown:	    ComboBox-Manager(show-hide-list)	\n\
     Meta<Key>osfDown:	    ComboBox-Manager(show-hide-list)	\n\
     Alt<Key>osfUp:	    ComboBox-Manager(hide-list)		\n\
     Meta<Key>osfUp:	    ComboBox-Manager(hide-list)		\n\
     <Key>osfUp:	    ComboBox-Manager(up)		\n\
     <Key>osfDown:	    ComboBox-Manager(down)		\n\
     <Key>osfCancel:	    ComboBox-Manager(cancel)		\n\
     <Key>Return:	    ComboBox-Manager(activate) activate()"
    ;
/* speziell bei der nicht editierbaren Combo-Box sind noch einige
 * andere Tasten belegt, die sonst dem Eingabefeld alleine gehoeren.
 * Die dazugehoerigen neuen Translations befinden sich in dieser
 * zusaetzlichen Tabelle, das Anhaengsel ...NE ist dabei die Ab-
 * kuerzung fuer "non editable".
 */
static char newEditTranslationsNE[] = 
    "<Key>osfBeginLine:	    ComboBox-Manager(top)		\n\
     <Key>osfEndLine:	    ComboBox-Manager(bottom)		  "
    ;
/* Momentan gibt es noch Aerger mit dem Drag'n'Drop-Mechanismus
 * von Motif 1.2. Legen wir ihn deshalb erst einmal still, solange
 * bis ich weiss, warum, und eine Loesung parat habe. NEU: Nur wenn
 * Sie mit einer libXm geschlagen sind, die partout nicht funktionieren
 * will, muessen Sie Drag'n'Drop stillegen, ansonsten klappts doch!
 */
#ifdef NODRAGNDROP
static char newListTranslations[] =
    "<Btn2Down>:	    ComboBox-Manager(no-operation)	";
#endif
    
/* --------------------------------------------------------------------
 * --------------------------------------------------------------------
 * Aktionen-Tabelle: Hierdurch werden den einzelnen Translations die
 * dazugehoerigen C-Routinen zugeordnet.
 * Da wir hier ein anstaendiges ANSI-C benutzen, sind hier zuerst einmal
 * die Prototypen faellig...
 * Noch ein Hinweis in eigener Sache... der ComboBox-Manager muss
 * applikationsweit registriert werden, da er auch von Translationen in
 * den Kindern der Combo-Box aktiviert wird.
 */
static void CBoxManager(Widget w, XEvent *event, String *params, 
                        Cardinal *num_params);

static XtActionsRec actions[] = {
    { "ComboBox-Manager", CBoxManager },
    { NULL, NULL }
}; /* actions */

    
/* --------------------------------------------------------------------
 * Eine Instanz dieser Widget-Klasse wird erstmalig in Betrieb ge-
 * nommen, daher sind noch Vorbereitungen notwendig, die nun hier
 * durchgefuehrt werden.
 */
static XtTranslations NewEditTranslations, NewEditTranslationsNE, 
                      NewListTranslations;

static XtConvertArgRec ConverterScreenConvertArg[] = {
    { XtBaseOffset, (XtPointer) XtOffset(Widget, core.screen), 
      sizeof(Screen *) }
};

static void ClassInit()
{
    NewEditTranslations =
	    XtParseTranslationTable(newEditTranslations);
    NewEditTranslationsNE =
	    XtParseTranslationTable(newEditTranslationsNE);
#ifdef NODRAGNDROP
    NewListTranslations =
	    XtParseTranslationTable(newListTranslations);
#endif
    XtAddConverter(XtRString, XtRBitmap, 
                   XmuCvtStringToBitmap, 
		   ConverterScreenConvertArg, 
                   XtNumber(ConverterScreenConvertArg));
} /* ClassInit */

/* --------------------------------------------------------------------
 * Suche dasjenige Fenster, in dem unsere Shell liegt, in der wiederum
 * die Combo-Box steckt. Diese Information wird benoetigt, um die
 * Drop-Down-Liste innerhalb des Fensterstacks immer direkt oberhalb
 * der Shell mit der Combo-Box zu halten.
 * Parameter:
 *   w			Diejenige Combo-Box, fuer die wir dasjenige
 *			Fenster des Window-Managers ermitteln sollen,
 *			dass direkt unterhalb des Root-Fensters liegt.
 * Ergebnis:
 *   besagtes zu suchendes Fenster.
 */
static Window GetDecorationWindow(XmComboBoxWidget w)
{
    Window       Root, Parent, AWindow;
    Window       *Children;
    unsigned int NumChildren;
    
    Parent = XtWindow((Widget) w);
    /* Suche nach dem Dekorationsfenster des Window-Managers */
    do {
	AWindow = Parent;
	XQueryTree(XtDisplay((Widget) w), AWindow, 
		   &Root, &Parent, &Children, &NumChildren);
	XFree((char *) Children);
    } while ( Parent != Root );
    return AWindow;
} /* GetDecorationWindow */

/* --------------------------------------------------------------------
 * Eine Combo-Box aus dem Wege raeumen...
 * Momentan muessen wir hier nur den Cursor wieder los werden sowie
 * eventuell reservierte Pixmaps.
 * Ups -- natuerlich muss auch wieder der Callback entfernt werden, 
 * der noch an der Shell haengt.
 */
static void Destroy(XmComboBoxWidget w)
{
/*    fprintf(stderr, "Destroy: %08X\n", w->core.window);*/
    if ( w->combobox.ConvertBitmapToPixmap )
	XFreePixmap(XtDisplay((Widget) w), 
	            w->combobox.LabelPixmap);
    if ( w->combobox.ConvertBitmapToPixmapInsensitive )
	XFreePixmap(XtDisplay((Widget) w), 
	            w->combobox.LabelInsensitivePixmap);
    if ( w->combobox.PendingFocusOut )
	XtRemoveWorkProc(w->combobox.WorkProcID);
    XtRemoveEventHandler(w->combobox.MyNextShell, 
                      StructureNotifyMask | FocusChangeMask, 
		      True, (XtEventHandler) ShellCallback, 
		      (XtPointer) w);
} /* Destroy */

/* --------------------------------------------------------------------
 * Berechne die voreinzustellende Groesse, die diese Combo-Box be-
 * sitzen muss, um ausreichenden Raum fuer das Eingabefeld und den
 * Pfeil rechts daneben zur Verfuegung zu stellen. Bei einer
 * editierbaren Combo-Box ist zwischen dem Eingabefeld und dem Pfeil
 * noch ein Angst-Rasen von der halben Breite eines Pfeiles vorhanden.
 */
static void DefaultGeometry(XmComboBoxWidget w, 
                            Dimension *TotalWidth, 
			    Dimension *TotalHeight, 
			    Dimension *EditCtrlWidth, 
			    Dimension *LabelCtrlWidth)
{
    XtWidgetGeometry EditGeom, ArrowGeom, LabelGeom;
    
    XtQueryGeometry(w->combobox.EditCtrl,  NULL, &EditGeom);
    XtQueryGeometry(w->combobox.ArrowCtrl, NULL, &ArrowGeom);
    XtQueryGeometry(w->combobox.LabelCtrl, NULL, &LabelGeom);
    *TotalWidth  = EditGeom.width + ArrowGeom.width;
    if ( w->combobox.ShowLabel )
	*TotalWidth += LabelGeom.width;
    if ( w->combobox.Editable ) *TotalWidth += ArrowGeom.width/2;
    *TotalHeight    = EditGeom.height;
    *EditCtrlWidth  = EditGeom.width;
    *LabelCtrlWidth = LabelGeom.width;
} /* DefaultGeometry */

/* --------------------------------------------------------------------
 * Anhand eines Widgets ermittele darueber die Screennummer desjenigen
 * Screens, auf dem das Widget erscheint.
 * Parameter:
 *   w			betroffenes Widget.
 * Ergebnis:
 *   Nummer desjenigen Screens, auf dem das Widget angezeigt wird.
 */
static int WidgetToScreen(Widget w)
{
    Screen  *screen;
    Display *display;
    int     NumScreens, i;
    
    screen = XtScreen(w); NumScreens = ScreenCount(XtDisplay(w));
    display = DisplayOfScreen(screen);
    for ( i = 0; i < NumScreens; ++i )
	if ( ScreenOfDisplay(display, i) == screen )
	    return i;
    XtError("WidgetToScreen: data structures are destroyed.");
} /* WidgetToScreen */

/* --------------------------------------------------------------------
 * Positioniere die DropDown-Liste (soweit sie natuerlich auch momentan
 * sichtbar ist) so auf dem Bildschirm, dass sie sich unterhalb des
 * Eingabefeldes anschliesst.
 */
static void DoDropDownLayout(XmComboBoxWidget w)
{
    Position  abs_x, abs_y;
    Dimension      ArrowWidth, ListWidth, ListHeight, LabelWidth;
    Window         Decoration;
    XWindowChanges WindowChanges;

/* etwa nicht sichtbar ?!! Dann sind wir jetzt sofort fertig. */
    if ( !w->combobox.ListVisible ) return;
/* Finde zuerst einmal heraus, wo wir uns denn auf dem
 * Bildschirm befinden sollen...
 * Beachte dabei auch, dass eventuell die Liste zu schmal werden
 * koennte und gib' ihr dann ggf. eine Mindestbreite, damit es
 * keinen core-Dump gibt.
 */
    XtVaGetValues(w->combobox.ArrowCtrl, 
	          XmNwidth, &ArrowWidth, NULL);
    XtTranslateCoords((Widget) w, 0, w->core.height, &abs_x, &abs_y);
    if ( w->combobox.DropDownOffset < 0 )
	w->combobox.DropDownOffset = ArrowWidth + 2;
    ListWidth  = w->core.width - w->combobox.DropDownOffset - 2;
    abs_x     += w->combobox.DropDownOffset;
    if ( w->combobox.ShowLabel ) {
	XtVaGetValues(w->combobox.LabelCtrl, XmNwidth, &LabelWidth, NULL);
	ListWidth -= LabelWidth;
	abs_x     += LabelWidth;
    }
    if ( ListWidth < 20 ) ListWidth = 20;
    XtVaGetValues(w->combobox.ListCtrl, XmNheight, &ListHeight, NULL);
    XtConfigureWidget(w->combobox.PopupShell, 
		      abs_x, abs_y, ListWidth, ListHeight, 1);

    /* TEST */
    if ( XtIsRealized((Widget) w) ) {
	WindowChanges.sibling    = GetDecorationWindow(w);
	WindowChanges.stack_mode = Above;
	XReconfigureWMWindow(XtDisplay((Widget) w), 
	    XtWindow(w->combobox.PopupShell), 
	    WidgetToScreen(w->combobox.PopupShell), 
	    CWSibling | CWStackMode, &WindowChanges);
    }
} /* DoDropDownLayout */

/* --------------------------------------------------------------------
 * Naja... diese Routine scheint ja bereits zu einer Institution beim
 * Schreiben von Composite-Widgets geworden zu sein.
 * 
 * Hier beim ComboBox-Widget ist die Aufgabe ziemlich einfach: es
 * genuegt, die Eingabezeile und den Pfeil-Button entsprechend inner-
 * halb des ComboBox-Widgets zu plazieren. Seit allerdings noch das
 * Textlabel hinzukommt, wird's langsam aufwendiger.
 */
static void DoLayout(XmComboBoxWidget w)
{
    Dimension EditCtrlWidth, ArrowCtrlWidth, LabelCtrlWidth;
    Dimension ComboBoxHeight;
    Dimension BorderWidth;
    Dimension HighlightThickness;
    Position  EditX;
    
    ComboBoxHeight = w->core.height;
    XtVaGetValues(w->combobox.ArrowCtrl,
                  XmNwidth, &ArrowCtrlWidth, NULL);
    XtVaGetValues(w->combobox.LabelCtrl, 
                  XmNwidth, &LabelCtrlWidth, NULL);
    EditCtrlWidth = w->core.width - ArrowCtrlWidth;
    if ( w->combobox.Editable ) EditCtrlWidth -= ArrowCtrlWidth/2;
    if ( w->combobox.ShowLabel ) {
	EditX          = LabelCtrlWidth;
	EditCtrlWidth -= LabelCtrlWidth;
    } else
        EditX = 0;
    if ( EditCtrlWidth < 20 ) EditCtrlWidth = 20;
/* Plaziere nun das Eingabefeld... */
    XtVaGetValues(w->combobox.EditCtrl, 
                  XmNborderWidth,        &BorderWidth, 
		  XmNhighlightThickness, &HighlightThickness, 
		  NULL);
    XtConfigureWidget(w->combobox.EditCtrl, 
                      EditX, 0, 
		      EditCtrlWidth, ComboBoxHeight, BorderWidth);
/* ...und nun den Pfeil... */
    XtVaGetValues(w->combobox.ArrowCtrl, 
                  XtNborderWidth, &BorderWidth, NULL);
    XtConfigureWidget(w->combobox.ArrowCtrl, 
                      w->core.width-ArrowCtrlWidth, HighlightThickness, 
		      ArrowCtrlWidth, 
		      ComboBoxHeight - 2 * HighlightThickness, 
		      BorderWidth);
/* ...und ggf. das Textlabel. */
    if ( w->combobox.ShowLabel ) {
	XtVaGetValues(w->combobox.LabelCtrl, 
		      XmNborderWidth, &BorderWidth, 
		      NULL);
	XtConfigureWidget(w->combobox.LabelCtrl, 
	                  0, 0, 
			  LabelCtrlWidth, ComboBoxHeight, 
			  BorderWidth);
    }
/* Falls da noch die Liste herumgurkt... */
    if ( w->combobox.ListVisible )
	DoDropDownLayout(w); 
} /* DoLayout */

/* --------------------------------------------------------------------
 * Pappi fragt nach, wie gross wir denn sein wollen.
 * Die hier benutzte Vorgehensweise zur Ermittlung der Groesse:
 *   Sobald der Vater uns eine Breite (oder aber Hoehe) vorschlaegt, 
 *   die fuer uns eigentlich zu klein ist, meckern wir und schlagen
 *   die von uns benoetigte Breite (Hoehe) vor.
 * Soweit also zur Theorie... leider sieht es beispielsweise das
 * Motif Form-Widget ueberhaupt nicht ein, uns auch nur ein einziges
 * Mal nach unseren Wuenschen zu fragen! Damit es bei derart unum-
 * gaenglichen Widgets dann doch noch geht, muss ChangedManaged die
 * Kohlen wieder aus dem Feuer holen mit einer Sondertour.
 * Parameter:
 *   *Request	    Vom Vater vorgeschlagene Geometrie
 * Ergebnis:
 *   *Reply	    Unsere Antwort auf die vorgeschlagene Geometrie
 *   sowie XtGeometryYes oder XtGeometryAlmost, je nachdem, wie gut
 *   uns Pappis Vorschlag in den Kram passt.
 */
static XtGeometryResult QueryGeometry(XmComboBoxWidget w, 
                                      XtWidgetGeometry *Request, 
			              XtWidgetGeometry *Reply)
{
    XtGeometryResult result = XtGeometryYes;
    Dimension        minW, minH, editW, labelW;
    
/* Elternteil will nichts weiter aendern, also ist uns das
 * recht so.
 */
    Request->request_mode &= CWWidth | CWHeight;
    if ( Request->request_mode == 0 ) return result;

    DefaultGeometry(w, &minW, &minH, &editW, &labelW);

/* Ueberpruefe, ob uns das in der Breite passt, was Pappi moechte... */
    if ( Request->request_mode & CWWidth ) {
	if ( Request->width < minW ) {
/* Wenn Pappi uns etwas vorschlaegt, was im wahrsten Sinne des Wortes 
 * vorn und hinten nicht reicht, dann versuchen wir ihn entsprechend
 * zu korrigieren. ("Versuchen" deshalb, weil er diesen Vorschlag auch
 * voellig ignorieren kann.)
 */
	    result               = XtGeometryAlmost;
	    Reply->width         = minW;
	    Reply->request_mode |= CWWidth;
	}
    }
/* Die ganze Chose nun noch vertikal */
    if ( Request->request_mode & CWHeight ) {
	if ( Request->height < minH ) {
	    result               = XtGeometryAlmost;
	    Reply->height        = minH;
	    Reply->request_mode |= CWHeight;
	}
    }
    return result;
} /* QueryGeometry */

/* --------------------------------------------------------------------
 * Die Groesse des ComboBox-Widgets hat sich veraendert und deshalb
 * mussen alle Kinder neu positioniert werden.
 * Letzten Endes laeuft hier alles auf ein ordinaeres DoLayout()
 * hinaus, um die Kinder umher zu schieben.
 * Parameter:
 *   w		    Die bereits hinlaenglich bekannte Instanz dieses
 *		    Widgets
 */
static void Resize(XmComboBoxWidget w)
{
    DoLayout(w);
} /* Resize */

/* --------------------------------------------------------------------
 * Dieses Widget hat sich in irgendeiner Form bewegt (und das nicht
 * nur relativ zum Vater, sondern moeglicherweise auch der Vater
 * selbst!) bzw. die Shell, in der sich irgendwo unsere Combo-Box
 * befindet, hat soeben den Fokus verschusselt und kann ihn nicht
 * mehr wiederfinden. Daneben kann es auch sein, dass die Shell
 * ikonisiert wurde. (Welch' Vielfalt! Dieses ist hier halt eine
 * multifunktionale Routine.)
 * 
 * Parameter:
 *   w		    Die naechste Shell in Reichweite ueber unserer
 *		    Combo-Box.
 *   cbw	    Diese Combo-Box.
 *   event	    ^ auf den Event, enthaelt genauerere Informationen
 *		    (naja... sieht so aus, als ob Motif hier auch 
 *		    schon 'mal Schrott 'reinpackt...)
 *   ContDispatch   Auf True setzen, damit dieser Event noch weiter-
 *		    gereicht wird an all' die anderen, die auch noch
 *		    mithoeren.
 */
static void ShellCallback(Widget w, XtPointer pClientData, 
                          XEvent *event, Boolean *ContDispatch)
{
    XmComboBoxWidget cbw = (XmComboBoxWidget) pClientData;
    
    switch ( event->type ) {
	case ConfigureNotify:
	case CirculateNotify:
	    DoDropDownLayout((XmComboBoxWidget) cbw);
	    break;
	case FocusOut:
	    LOG2("ShellCallback: FocusOut, mode: %i\n",
	         event->xfocus.mode);
	    if ( cbw->combobox.Persistent )
		cbw->combobox.IgnoreFocusOut = True;
	    else if ( (event->xfocus.mode == NotifyGrab) &&
	              cbw->combobox.ListVisible )
	        cbw->combobox.IgnoreFocusOut = True;
	    break;
	case UnmapNotify:
	    ShowHideDropDownList((XmComboBoxWidget) cbw, 
	                         event, False);
	    break;
    }
    *ContDispatch = True;
} /* ShellCallback */

/* --------------------------------------------------------------------
 * Diese Routine sorgt dafuer, dass die Liste nicht irrtuemlich bei
 * manchen Window Managern vom Bildschirm genommen wird, bloss weil
 * diese der OverrideShell den Tastaturfocus schenken bzw. diesen
 * dem Combo-Box-Widget wegnehmen, sobald der Mauszeiger in die Liste
 * bewegt wird.
 */
static void OverrideShellCallback(Widget w, XtPointer pClientData,
                                  XEvent *event, Boolean *ContDispatch)

{
    XmComboBoxWidget cbw = (XmComboBoxWidget) pClientData;
    switch ( event->type ) {
        case EnterNotify:
	    LOG2("OverrideShellCallback: EnterNotify, PendingFO: %s\n", 
	         cbw->combobox.PendingFocusOut ? "True" : "False");
            if ( cbw->combobox.PendingFocusOut )
                cbw->combobox.IgnoreFocusOut = True;
	    if ( cbw->combobox.TwmHandlingOn )
                cbw->combobox.PendingOverrideInOut = True;
            break;
        case LeaveNotify:
            LOG("OverrideShellCallback: LeaveNotify\n");
	    if ( cbw->combobox.TwmHandlingOn )
              cbw->combobox.PendingOverrideInOut = True;
            break;
    }
} /* OverrideShellCallback */

/* --------------------------------------------------------------------
 * Ha! Anscheinend kann man das Problem mit der einklappenden Liste,
 * sobald man den Arrow-Button anklickt, doch loesen! Allerdings geht
 * das auch nur von hinten durch die Brust in's Auge. Hier war die
 * Reihenfolge der Events bislang das Problem: Klickt man den Arrow-
 * Button an, so verliert das Eingabefeld den Focus, dann wird leider
 * schon die WorkProc aktiviert und laesst die Liste verschwinden.
 * Danach erst kommt der Arrow-Button-Callback an die Reihe. Um dieses
 * Dilemma doch noch zu loesen, wird hier darauf gelauert, wann und
 * welcher LeaveNotify kommt. Klickt der Benutzer den Pfeil an, so
 * kommt hier noch rechtzeitig ein LeaveNotify vorbei, der aber durch
 * einen Grab ausgeloest wurde. Und das ist eben nur beim Anklicken
 * der Fall. Damit wissen wir, das der FocusOut getrost ignoriert
 * werden darf.
 * Puhhh -- ist das ein kompliziertes Chaos.
 * Uebrigends...auch wenn manche Befehle zuerst ueberfluessig er-
 * scheinen...sie sind erforderlich, damit die ComboBox auch mit unter-
 * schiedlichen Window Managern zurechtkommt!
 */
static void ArrowCrossingCallback(Widget w, XtPointer pClientData,
                               XEvent *event, Boolean *ContDispatch)

{
    XmComboBoxWidget cbw = (XmComboBoxWidget) pClientData;
    switch ( event->type ) {
        case LeaveNotify:
	    LOG2("ArrowCrossingCallback: LeaveNotify, mode: %i\n", 
	         event->xcrossing.mode);
            if ( event->xcrossing.mode == NotifyGrab )
                cbw->combobox.IgnoreFocusOut = True;
            else
                cbw->combobox.IgnoreFocusOut = False;
            break;
    }
} /* ArrowCrossingCallback */

/* --------------------------------------------------------------------
 * Alle Hilfeaufrufe innerhalb der Kinder gehen an das eigentliche
 * Combo-Box-Widget weiter, so dass auch hier nach aussen hin die
 * Kinder-Widgets nicht in Erscheinung treten.
 */
static void HelpCallback(Widget w, XtPointer cbw, XtPointer CallData)
{
    XtCallCallbacks((Widget) cbw, XmNhelpCallback, CallData);
} /* HelpCallback */

/* --------------------------------------------------------------------
 * Ein Kind moechte sein Groesse veraendern und fragt deshalb hier bei
 * uns an.
 * Parameter:
 *   w		    Naja...
 *   *Request	    Vorschlag des Kindes
 * Ergebnis:
 *   *Reply	    Unsere Antwort darauf
 *   XtGeometryNo, da es uns bislang grundsaetzlich nie passt.
 */
static XtGeometryResult GeometryManager(XmComboBoxWidget w, 
                                        XtWidgetGeometry *Request, 
				        XtWidgetGeometry *Reply)
{
    return XtGeometryNo; /* Was ICH hier vorgegeben habe, gilt! */
} /* GeometryManager */

/* --------------------------------------------------------------------
 * Hier werden auf Wunsch diejenigen Farben, die bei der Combo-Box neu
 * gesetzt wurden, an alle Kinder weitergegeben.
 */
#define BOTTOMSHADOWCOLOR   0x0001
#define TOPSHADOWCOLOR	    0x0002
#define FOREGROUND	    0x0004
#define BACKGROUND	    0x0008

static struct { String Resource; int Flag; }
       ColorResources[] = {
	   { XmNbottomShadowColor, BOTTOMSHADOWCOLOR }, 
	   { XmNtopShadowColor,    TOPSHADOWCOLOR    }, 
	   { XmNforeground,        FOREGROUND        }, 
	   { XmNbackground,        BACKGROUND        }
       };

static UpdateColors(XmComboBoxWidget w, int flags)
{
    Pixel  Color;
    int    i, size = XtNumber(ColorResources);
    Widget ScrolledWin, ScrollBar;
    
    ScrolledWin = XtParent(w->combobox.ListCtrl);
    XtVaGetValues(ScrolledWin, XmNverticalScrollBar, &ScrollBar, NULL);
    for ( i=0; i<size; i++ )
	if ( flags & ColorResources[i].Flag ) {
	    XtVaGetValues((Widget) w, ColorResources[i].Resource, &Color,
	                  NULL);
	    XtVaSetValues(w->combobox.ListCtrl, 
	                  ColorResources[i].Resource, Color, NULL);
	    XtVaSetValues(ScrolledWin, 
	                  ColorResources[i].Resource, Color, NULL);
	    XtVaSetValues(ScrollBar, 
	                  ColorResources[i].Resource, Color, NULL);
	    XtVaSetValues(w->combobox.EditCtrl, 
	                  ColorResources[i].Resource, Color, NULL);
	    XtVaSetValues(w->combobox.LabelCtrl, 
	                  ColorResources[i].Resource, Color, NULL);
	    XtVaSetValues(w->combobox.ArrowCtrl, 
	                  ColorResources[i].Resource, Color, NULL);
	    if ( ColorResources[i].Flag & BACKGROUND )
		XtVaSetValues(ScrollBar, XmNtroughColor, Color, NULL);
	}
} /* UpdateColors */

/* --------------------------------------------------------------------
 * Liste aller vorgespiegelten Resourcen, die automatisch verarbeitet
 * werden koennen, ohne weiter darueber nachdenken zu muessen...
 */
typedef enum  { EDITCTRL, LISTCTRL, LABELCTRL } CHILDCTRL;
typedef struct {
    String                    rsc;
    CHILDCTRL                 ctrl;
    enum { RO, RW, RWS, RWL, RWI } dir;
    /* nur lesen, lesen&schreiben, lesen&schreiben spezial,
       lesen&schreiben label, lesen&schreiben items */
} MIRROR;

/* Alle mit !!! gekennzeichneten Eintraege werden auf die richtigen
 * Namen des entsprechenden Widgets umgesetzt.
 */
static MIRROR MirroredResources[] = {
    { XmNitems,			    LISTCTRL,  RWI }, /* Urgs! */
    { XmNitemCount,		    LISTCTRL,  RW  }, /* dto.  */
    { XmNlistMarginHeight,	    LISTCTRL,  RW  }, 
    { XmNlistMarginWidth,	    LISTCTRL,  RW  }, 
    { XmNlistSpacing,		    LISTCTRL,  RW  }, 
    { XmNstringDirection,	    LISTCTRL,  RO  }, /* Naja? */
    { XmNtopItemPosition,	    LISTCTRL,  RO  }, 
    
    { XmNblinkRate,		    EDITCTRL,  RW  }, 
    { XmNcolumns,		    EDITCTRL,  RW  }, 
    { XmNcursorPosition,	    EDITCTRL,  RW  }, 
    { XmNcursorPositionVisible,	    EDITCTRL,  RW  }, 
    { XmNmarginHeight,		    EDITCTRL,  RW  }, 
    { XmNmarginWidth,		    EDITCTRL,  RW  }, 
    { XmNmaxLength,		    EDITCTRL,  RW  }, 
    { XmNselectThreshold,	    EDITCTRL,  RW  }, 
    { XmNvalue,			    EDITCTRL,  RWS }, 
    
    { XmNalignment,		    LABELCTRL, RW  }, 
    { XmNlabelPixmap,		    LABELCTRL, RW  }, 
    { XmNlabelInsensitivePixmap,    LABELCTRL, RW  }, 
    { XmNlabelString,		    LABELCTRL, RW  }, 
    { XmNlabelType,		    LABELCTRL, RW  }, 
    { XmNlabelMarginBottom,	    LABELCTRL, RWL }, /* !!! */
    { XmNlabelMarginHeight,	    LABELCTRL, RWL }, /* !!! */
    { XmNlabelMarginLeft,	    LABELCTRL, RWL }, /* !!! */
    { XmNlabelMarginRight,	    LABELCTRL, RWL }, /* !!! */
    { XmNlabelMarginTop,	    LABELCTRL, RWL }, /* !!! */
    { XmNlabelMarginWidth,	    LABELCTRL, RWL }, /* !!! */
    { XmNlabelFontList,             LABELCTRL, RWL }, /* !!! */
};

typedef struct {
    char *from, *to;
} TRANSFORMATION;
static TRANSFORMATION Transformations[] = {
    { XmNlabelMarginBottom, XmNmarginBottom }, 
    { XmNlabelMarginHeight, XmNmarginHeight }, 
    { XmNlabelMarginLeft,   XmNmarginLeft   }, 
    { XmNlabelMarginRight,  XmNmarginRight  }, 
    { XmNlabelMarginTop,    XmNmarginTop    }, 
    { XmNlabelMarginWidth,  XmNmarginWidth  }, 
    { XmNlabelFontList,     XmNfontList     },
};

/* --------------------------------------------------------------------
 * Sobald irgendeine Resource veraendert wird, erfolgt der Aufruf
 * hierin als Benachrichtigung, einmal nach dem rechten zu sehen.
 * Parameter:
 *   current	    Kopie der Widget-Instanz, bevor irgendwelche
 *		    Resourcen veraendert oder set_values()-Methoden
 *		    aufgerufen wurden.
 *   req	    Kopie der Widget-Instanz, aber bereits mit den
 *		    durch XtSetValues veraenderten Werten
 *   new	    aktuellster Zustand der Widget-Instanz mit
 *		    veraenderten Werten (entweder durch XtSetValues
 *		    oder set_values()-Methoden der Superklasse)
 *   args	    Argumentenliste beim Aufruf von XtSetValues()
 *   NumArgs	    Anzahl der Argumente in der Liste
 * Ergebnis:
 *   True, falls Widget neu gezeichnet werden soll.
 */
static Boolean SetValues(XmComboBoxWidget current, XmComboBoxWidget req, 
                         XmComboBoxWidget new, 
	                 ArgList args, Cardinal *NumArgs)
{
    Boolean Update = False;
    int i, j, MirrorSize = XtNumber(MirroredResources);
    int k, TransformationSize = XtNumber(Transformations);
    Arg arg;
    int Flags;
    
/* Alle Resourcen, die nicht mehr nach dem Erstellen der Widget-Instanz
 * veraendert werden koennen.
 */
    new->combobox.Editable  = current->combobox.Editable;
    new->combobox.ListCtrl  = current->combobox.ListCtrl;
    new->combobox.EditCtrl  = current->combobox.EditCtrl;
    new->combobox.LabelCtrl = current->combobox.LabelCtrl;
    
/* Kontrolliere nun alle Resourcen, die sich veraendert haben koennten
 * und gebe die neuen Einstellungen entsprechend weiter...
 */
/* Anzahl der in der Liste gleichzeitig darstellbaren Eintraege */
    if ( current->combobox.VisibleItemCount != 
           new->combobox.VisibleItemCount ) {
	XtVaSetValues(new->combobox.ListCtrl, 
	              XmNvisibleItemCount, new->combobox.VisibleItemCount, 
		      NULL);
	Update = True;
    }
/* benutzter Font: hier erhalten Liste und Eingabefeld jeweils die
 * gleiche Fontliste, wohingegen das Label getrennt behandelt wird.
 * Das macht auch Sinn, denn Liste und Eingabefeld beinhalten gleich-
 * artigen Text, so dass hier auch tunlichst der gleiche Font zu
 * benutzen ist.
 */
    if ( current->combobox.Font != new->combobox.Font ) {
	XtVaSetValues(new->combobox.ListCtrl, 
	              XmNfontList, new->combobox.Font, NULL);
	XtVaSetValues(new->combobox.EditCtrl, 
	              XmNfontList, new->combobox.Font, NULL);
    }
    
    Flags = 0;
    if ( new->manager.top_shadow_color != 
         current->manager.top_shadow_color    ) Flags |= TOPSHADOWCOLOR;
    if ( new->manager.bottom_shadow_color != 
         current->manager.bottom_shadow_color ) Flags |= BOTTOMSHADOWCOLOR;
    if ( new->manager.foreground != 
         current->manager.foreground          ) Flags |= FOREGROUND;
    if ( new->core.background_pixel != 
         current->core.background_pixel       ) Flags |= BACKGROUND;
    if ( Flags ) { UpdateColors(new, Flags); Update = True; }
    
    
    if ( new->combobox.ArrowCursor != current->combobox.ArrowCursor ) {
	if ( new->combobox.ListVisible )
	    XDefineCursor(XtDisplay(new->combobox.PopupShell), 
			    XtWindow(new->combobox.PopupShell), 
			    new->combobox.ArrowCursor); 
   }
/* Hier werden die vorgespiegelten Resourcen verwaltet, die in
 * Wirklichkeit zu einem unserer Kinder gehoeren.
 */
     for ( i = 0; i < *NumArgs; i++ ) {
/* Ist es eine vorgespiegelte Resource ? Wenn ja, dann leite die
 * Anfrage an das entsprechende Kind-Widget weiter.
 */
	for ( j = 0; j < MirrorSize; j++ ) {
	    if ( (strcmp(args[i].name, MirroredResources[j].rsc) == 0) ) {
		switch ( MirroredResources[j].dir ) {
		case RW:   /* schreibender Zugriff erlaubt */
		    XtSetValues(MirroredResources[j].ctrl == LISTCTRL ?
			          new->combobox.ListCtrl :  
				(MirroredResources[j].ctrl == EDITCTRL ?
				  new->combobox.EditCtrl :
				  new->combobox.LabelCtrl), 
			&(args[i]), 1);
		    break;
		case RWS:  /* schreibender Zugriff unter Kontrolle */
		    if ( strcmp(args[i].name, XmNvalue) == 0 ) {
			if ( new->combobox.Editable )
			    XtSetValues(new->combobox.EditCtrl, 
			                &(args[i]), 1);
		    }
		    break;
		case RWL: /* Transformation in andere Resource beim
		             Label-Widget */
		    for ( k = 0; k < TransformationSize; k++ )
			if ( strcmp(args[i].name, Transformations[k].from) == 0 ) {
			    arg.value = args[i].value;
			    arg.name = Transformations[k].to;
			    XtSetValues(new->combobox.LabelCtrl, 
			                &arg, 1);
			    break;
			}
		case RWI: /* Zugriff auf XmNitems */
		    for ( k = 0; k < *NumArgs; k++ )
			if ( strcmp(args[k].name, XmNitemCount) == 0 ) {
			    XtVaSetValues(new->combobox.ListCtrl, 
			                  XmNitems,     args[i].value, 
					  XmNitemCount, args[k].value, 
					  NULL);
			    break;
			}
		    break;
		case RO:
		    break;
		} /* case write mode */
		goto ScanForNextResource;
	    } /* if entry found */
	} /* for every mirrored entry */
        ScanForNextResource: ;
    } /* for every Arg */
    
    return Update;
} /* SetValues */

/* --------------------------------------------------------------------
 * Werden irgendwelche Resourcen abgefragt, so muessen wir hier erst
 * noch vor der Rueckkehr zum Frager klaeren, ob davon eine Resource
 * betroffen ist, die nur vorgespiegelt ist, da sie eigentlich einem
 * der Widgets gehoert, die von uns hier verwaltet werden, um daraus
 * eine ordentliche Combo-Box zu machen.
 * Parameter:
 *   w		    Widget-Instanz
 *   args	    Abgefragte Resourcen
 *   NumArgs	    Anzahl der abgefragten Resourcen
 */
static void GetValuesAlmost(XmComboBoxWidget w, ArgList args, 
                            Cardinal *NumArgs)
{
    int i, j, MirrorSize = XtNumber(MirroredResources);
    int k, TransformationSize = XtNumber(Transformations);
    Arg arg;
    
    for ( i = 0; i < *NumArgs; i++ ) {
/* Ist es eine vorgespiegelte Resource ? Wenn ja, dann leite die
 * Anfrage an das entsprechende Kind-Widget weiter.
 */
	for ( j = 0; j < MirrorSize; j++ ) {
	    if ( strcmp(args[i].name, MirroredResources[j].rsc) == 0 ) {
		switch ( MirroredResources[j].dir ) {
		case RO:
		case RW:
		case RWS:
		case RWI:
		    XtGetValues(MirroredResources[j].ctrl == LISTCTRL ?
			          w->combobox.ListCtrl : 
				MirroredResources[j].ctrl == EDITCTRL ?
				  w->combobox.EditCtrl :
				  w->combobox.LabelCtrl, 
			&(args[i]), 1);
		    break;
		case RWL: /* Umzuleitende Resource bei Label-Widget */
		    for ( k = 0; k < TransformationSize; k++ )
			if ( strcmp(args[i].name, Transformations[k].from) == 0 ) {
			    arg.value = args[i].value;
			    arg.name = Transformations[k].to;
			    XtGetValues(w->combobox.LabelCtrl, 
			                (ArgList) &arg, 1);
			    break;
			}
		    break;
		} /* case read mode */
	    } /* if entry found */
	} /* for every mirrored entry */
    } /* for every Arg */
} /* GetValuesAlmost */

/* --------------------------------------------------------------------
 * Zeige beziehungsweise verstecke die Drop-Down-Liste der Combo-Box.
 * Falls die Liste bereits den entsprechenden Zustand hat, geht's
 * sofort zum Aufrufer zurueck.
 * Parameter:
 *   w		    Her Royal Majesty ComboBox
 *   Show	    True, falls anzuzeigen, andernfalls False
 */
static void ShowHideDropDownList(XmComboBoxWidget w, XEvent *event, 
                                 Boolean Show)
{
    XmComboBoxDropDownCallbackStruct info;
    
    if ( Show == w->combobox.ListVisible ) return;
    w->combobox.ListVisible = Show;
    if ( Show ) { /* Klapp' die Liste aus! */
	DoDropDownLayout(w);
	info.reason = XmCR_SHOW_LIST;
	info.event  = event;
	XtCallCallbacks((Widget) w, XmNdropDownCallback, 
	                (XtPointer) &info);
	XDefineCursor(XtDisplay(w->combobox.PopupShell), 
	                XtWindow(w->combobox.PopupShell), 
			w->combobox.ArrowCursor); 
	XtPopup(w->combobox.PopupShell, XtGrabNone);
	XtVaSetValues(w->combobox.ArrowCtrl, 
	              XmNarrowDirection, XmARROW_UP, NULL);
    } else {      /* Klapp' die Liste wieder ein... */
	XtPopdown(w->combobox.PopupShell);
	XtVaSetValues(w->combobox.ArrowCtrl, 
	              XmNarrowDirection, XmARROW_DOWN, NULL);
	info.reason = XmCR_HIDE_LIST;
	info.event  = event;
	XtCallCallbacks((Widget) w, XmNdropDownCallback, 
	                (XtPointer) &info);
    }
} /* ShowHideDropDownList */

/* --------------------------------------------------------------------
 * Hier laeuft die Nachricht auf, dass der Pfeil ausgeloest wurde...
 * (Daraufhin sollte die Liste aus- oder eingeklappt werden)
 * ...oder dass der Benutzer da draussen auf der anderen Seite der
 * Mattscheibe den Pfeil bereits anklickte ohne aber bereits losge-
 * gelassen zu haben. Bereits hier bekommt das Eingabefeld den Fokus
 * vor den Latz geknallt, denn sonst kann es passieren, dass zwar die
 * Liste ausgeklappt ist, aber das Eingabefeld noch keinen Tastatur-
 * fokus erhalten hat. Das sollte aber nicht so sein, denn es ist dann
 * keine konsequente Tastaturbedienung.
 */
static void ArrowCallback(Widget w, XtPointer pClientData, 
                          XmAnyCallbackStruct *info)
{
    XmComboBoxWidget cbw = (XmComboBoxWidget) XtParent(w);
    
    switch ( info->reason ) {
	case XmCR_ARM:
	    LOG("ArrowCallback: XmCR_ARM\n");
	    XmProcessTraversal(cbw->combobox.EditCtrl, XmTRAVERSE_CURRENT);
	    if ( cbw->combobox.TwmHandlingOn && cbw->combobox.ListVisible )
	        cbw->combobox.IgnoreFocusOut = True;
	    break;
	case XmCR_ACTIVATE:
	    XmProcessTraversal(cbw->combobox.EditCtrl, XmTRAVERSE_CURRENT);
	    ShowHideDropDownList(cbw, info->event, 
	                         (Boolean)(!cbw->combobox.ListVisible));
	    break;
    }
} /* ArrowCallback */

/* --------------------------------------------------------------------
 * Diese Benachrichtigung moechte uns nur mitteilen, dass wir soeben
 * den Fokus verloren haben (Ohhhh!) Sollte allerdings der Fokus nur
 * aus dem Grunde perdue sein, dass der Anwender den Mauszeiger ausser-
 * halb des Applikationsfensters plaziert hat, so koennen wir diese
 * Nachricht uebergehen. Erst wenn der Fokus an ein anderes Widget in
 * unserer Applikation verlorenging, muessen wir auf diese Information
 * reagieren.
 * Und jetzt zu noch einem total beknackten Problem - alles nur wegen
 * Motif und den diversen Window-Managern (bspw. olwm)... Leider kommt
 * beim FocusOut kein richtiger Hinweis auf den tatsaechlichen Event,
 * der dieses Callback ausloeste -- warum liefert denn dann Motif ueber-
 * haupt noch den Event???? Und ueberhauupt, die Geschichte mit dem
 * Fokus ist schon der reinste Horror. Aktueller Ausweg: wenn wir die
 * Benachrichtigung ueber den Focusabgang bekommen, registrieren wir
 * eine Work-Prozedur, die, sobald der Rechner wieder Luft hat, auf-
 * gerufen wird. Sie kann dann nachschauen, ob nicht inzwischen die
 * OverrideShell den Focus bekahm. Wenn ja, koennen wir den FocusOut
 * uebergehen, ansonsten muessen wir ihn beruecksichtigen.
 * -- Ist das eine ^@#$^*(#$^&! (Meine gute Erziehung hindert mich
 * daran, diesen Begriff hier zu nennen.)
 */
static Boolean DelayedFocusOutWorkProc(XtPointer pClientData)
{
    XmComboBoxWidget cbw = (XmComboBoxWidget) pClientData;
    LOG2("DelayedFocusOutWorkProc: IgnoreFocusOut: %s\n", 
         cbw->combobox.IgnoreFocusOut ? "True" : "False");
    if ( !cbw->combobox.IgnoreFocusOut )
        ShowHideDropDownList(cbw, &(cbw->combobox.xevent), False);
    cbw->combobox.IgnoreFocusOut  = False;
    cbw->combobox.PendingFocusOut = False;
    return True; /* diese Routine wird nicht mehr benoetigt. */
} /* DelayedFocusOutWorkProc */

static void EditFocusCallback(Widget w, XtPointer pClientData, 
                              XmAnyCallbackStruct *info)
{
    XmComboBoxWidget cbw = (XmComboBoxWidget) XtParent(w);
    
    if ( info->reason == XmCR_LOSING_FOCUS ) {
        LOG2("EditFocusCallback: PendingFocusOut: %s, ", 
	     cbw->combobox.PendingFocusOut ? "True" : "False");
	LOG2("PendingOverrideInOut: %s\n",
	     cbw->combobox.PendingOverrideInOut ? "True" : "False");
        if ( !cbw->combobox.PendingFocusOut &&
             !cbw->combobox.PendingOverrideInOut ) {
	    /* Normalerweise duerfen aber keine NULL-Events hier
	     * vorbeikommen...aber man weiss ja nie so genau und
	     * sicher ist sicher. Defensiv programmieren!
	     */
	    if ( info->event )
	        cbw->combobox.xevent = *info->event;
            cbw->combobox.WorkProcID = XtAppAddWorkProc(
	                     XtWidgetToApplicationContext((Widget) cbw),
                             (XtWorkProc) DelayedFocusOutWorkProc,
                             (XtPointer) cbw);
            cbw->combobox.PendingFocusOut = True;
        }
        cbw->combobox.PendingOverrideInOut = False;
    }
} /* EditFocusCallback */

/* --------------------------------------------------------------------
 * Hier wird der angegebene Eintrag in der Listbox der Combo-Box
 * markiert und zudem in den sichtbaren Bereich gerollt, sollte er
 * sich ausserhalb des dargestellten Bereichs der Liste befinden.
 * Parameter:
 *   w		    Die Combo-Box (ueblicher Parameter)
 *   Index	    Index des neu zu markierenden Eintrages.
 *   Notify	    Schickt Mitteilung via Callback
 * Ergebnis:
 *   Index des markierten Eintrages oder 0, falls die Listbox leer
 *   war und deshalb auch kein Eintrag markiert werden konnte.
 */
static int SetSelectionPos(XmComboBoxWidget w, int Index, Boolean Notify)
{
    Widget ListBox = w->combobox.ListCtrl;
    int            ItemCount;      /* Anzahl Eintraege in Listbox   */
    int            TopItem, VisibleItems;
     
    XtVaGetValues(ListBox, XmNitemCount,        &ItemCount, 
			   XmNtopItemPosition,  &TopItem, 
			   XmNvisibleItemCount, &VisibleItems,
	                   NULL);
    if ( Index < 1         ) Index = 1;
    if ( Index > ItemCount ) Index = ItemCount;
    if ( Index != 0 && ItemCount != 0 ) {
	if ( Index < TopItem )
	    XmListSetPos(ListBox, Index);
	if ( Index >= TopItem + VisibleItems )
	    XmListSetBottomPos(ListBox, Index);
	XmListSelectPos(ListBox, Index, Notify);
	return Index;
    } else
	return 0;
} /* SetSelectionPos */

/* --------------------------------------------------------------------
 * Diese Routine kuemmert sich darum, denjenigen Eintrag aus der List-
 * box mit der angegebenen Nummer herauszufischen und an die Eingabe-
 * zeile zu uebergeben. Dabei wird der Index auf den Eintrag auto-
 * matisch auf den zulaessigen Bereich begrenzt. Zugleich wird auch
 * noch der angegebene Eintrag in der Listbox markiert.
 */
static void TransferToEditCtrl(XmComboBoxWidget w, int SelectionIndex)
{
    Widget ListBox = w->combobox.ListCtrl;
    XmStringTable  Items;
    char           *pItemText;
    
    XtVaGetValues(ListBox, XmNitems, &Items, NULL);
    SelectionIndex = SetSelectionPos(w, SelectionIndex, False);
    if ( SelectionIndex > 0 ) {
	XmStringGetLtoR(Items[SelectionIndex-1], 
	                XmSTRING_DEFAULT_CHARSET, &pItemText);
	w->combobox.PassVerification = True;
	XmTextFieldSetString(w->combobox.EditCtrl, pItemText);
	XtFree(pItemText);
    }
} /* TransferToEditCtrl */

/* --------------------------------------------------------------------
 * Alle registrierten Callbacks bei Anwahl eines neuen Eintrages in
 * der Listbox aktivieren.
 */
static void CallSelectionCBL(XmComboBoxWidget w, XEvent *Event)
{
    XmComboBoxSelectionCallbackStruct info;
    XmStringTable                     Items;
    
    info.reason = XmCR_SINGLE_SELECT;
    info.event  = Event;
    info.index  = XmComboBoxGetSelectedPos((Widget) w);
    if ( info.index == 0 ) return;
    XtVaGetValues(w->combobox.ListCtrl, XmNitems, &Items, NULL);
    info.value  = Items[info.index-1];
    XtCallCallbacks((Widget) w, XmNselectionCallback, (XtPointer) &info);
} /* CallSelectionCBL */

/* --------------------------------------------------------------------
 *  Hier laeuft das Tastatur-Management fuer die ComboBox zusammen.
 */
static void CBoxManager(Widget w, XEvent *Event, String *params, 
                        Cardinal *num_params)
{
    XmComboBoxWidget cbw = (XmComboBoxWidget) XtParent(w);
    Widget         ListBox = cbw->combobox.ListCtrl;
    int            *SelectionList;
    int            SelectionCount;
    int            SelectionIndex; /* Wer denn nun markiert wird... */
    int            ItemCount;      /* Anzahl Eintraege in Listbox   */
    char           opt;
    
    switch ( *(params[0]) ) {
/* --------------------------------------------------------------------
 * Klappe die Liste auf Wunsch des Benutzers aus oder wieder ein.
 */
    case 's': /* show-hide-list */
	ShowHideDropDownList(cbw, Event, 
	                     (Boolean)(!cbw->combobox.ListVisible));
	break;
    case 'h': /* hide-list */
	ShowHideDropDownList(cbw, Event, False);
	break;
/* --------------------------------------------------------------------
 * Hier werden die Bewegungen in der Listbox behandelt.
 */
    case 'u': /* up     */
    case 'd': /* down   */
    case 't': /* top    */
    case 'b': /* bottom */
	opt = *(params[0]);
	XtVaGetValues(ListBox, XmNitemCount, &ItemCount, NULL);
	if ( XmListGetSelectedPos(ListBox,
	                          &SelectionList, &SelectionCount) ) {
	    SelectionIndex = *SelectionList;
	    XtFree((char *)SelectionList);
	    switch ( opt ) {
		case 'u': SelectionIndex--;		break;
		case 'd': SelectionIndex++;		break;
		case 't': SelectionIndex = 1;		break;
		case 'b': SelectionIndex = ItemCount;	break;
	    }
	} else { /* momentan noch kein Eintrag in der Liste ausgewaehlt */
	    if ( opt == 'b' ) SelectionIndex = ItemCount;
	    else              SelectionIndex = 1; /* nun ersten Eintrag nehmen */
	}
	TransferToEditCtrl(cbw, SelectionIndex);
	CallSelectionCBL(cbw, Event);
	break;
/* --------------------------------------------------------------------
 * Der Benutzer hat die Eingabetaste gedrueckt oder einen Eintrag in
 * der Listbox angeklickt.
 */
    case 'a': /* Return = activate */
    case 'S': /* Selection */
	if ( !cbw->combobox.ListVisible ) break;
	XtVaGetValues(ListBox, XmNitemCount, &ItemCount, NULL);
	if ( ItemCount == 0 ) break;
	if ( XmListGetSelectedPos(ListBox,
	                          &SelectionList, &SelectionCount) ) {
	    SelectionIndex = *SelectionList;
	    XtFree((char *)SelectionList);
	} else SelectionIndex = 1;
	TransferToEditCtrl(cbw, SelectionIndex);
	CallSelectionCBL(cbw, Event);
	ShowHideDropDownList(cbw, Event, (Boolean)
	                      (*(params[0]) == 'S' ? True : False));
	break;
/* --------------------------------------------------------------------
 * Der Benutzer hat die ESC-Taste gedrueckt. Ist die Liste zu diesem
 * Zeitpunkt noch ausgeklappt, so wird sie einfach nur eingeklappt und
 * weiter passiert nichts. Ist die Liste jedoch eingeklappt, so wird
 * das ESC an die normale Action-Routine des Eingabefeldes weiter-
 * gegeben, damit damit bspw. Dialog u.a. abgebrochen werden koennen.
 */
    case 'c': /* Cancel */
	if ( cbw->combobox.ListVisible )
	    ShowHideDropDownList(cbw, Event, False);
	else
	    XtCallActionProc(cbw->combobox.EditCtrl, 
	                     "process-cancel", Event, NULL, 0);
	break;
/* --------------------------------------------------------------------
 * Dummy-Operation
 */
    case 'n': /* no-operation */
        break;
    }
} /* CBoxManager */

/* --------------------------------------------------------------------
 * Der Benutzer hat einen Eintrag in der Listbox angeklickt. Der Ein-
 * fachkeit halber wird einfach nur ein Druecken der Eingabetaste
 * simuliert.
 */
static void ListSelectionCallback(Widget w, XtPointer pClientData, 
                                  XmAnyCallbackStruct *info)
{
    String   paramsMouse[1] = { "a" }, paramsKeyboard[1] = { "S" };
    Cardinal NumParams = 1;
/* Warum denn zweimal XtParent() ?! Nun: Die Listbox steckt in einem
 * ScrolledWindow, dass seinerseits in einer OverrideShell feststeckt, 
 * die ihrerseits der ComboBox gehoert -- jaja... die beliebten
 * russischen Pueppchen (Matrijoschkas ... Schreibweise?)
 * Und da nun CBoxManager eines der Kinder-Widgets der ComboBox
 * uebergeben bekommt...brauchen wir zweimal XtParent()!
 */
/* Wurde der Event durch die Tastatur oder einen Mausklick
 * ausgeloest?
 */
    if ( info->event == NULL )
	CBoxManager(XtParent(XtParent(w)), info->event, 
	            paramsKeyboard, &NumParams);
    else {
	XmComboBoxWidget cbw;
	CBoxManager(XtParent(XtParent(w)), info->event, 
	            paramsMouse, &NumParams);
	cbw = (XmComboBoxWidget) XtParent(XtParent(XtParent(w)));
	XmProcessTraversal(cbw->combobox.EditCtrl, 
	                   XmTRAVERSE_CURRENT);
    }
} /* ListSelectionCallback */

/* --------------------------------------------------------------------
 * Sobald sich irgendetwas im Eingabefeld veraenderte, kommt das
 * TextField-Widget zuerst zu uns gelaufen, um sich unser Okay zu
 * holen. Bei einer nicht editierbaren Combo-Box wird hierueber die
 * Schnellsuche realisiert.
 */
static void EditVerifyCallback(Widget w, XtPointer pClientData, 
                               XmTextVerifyCallbackStruct *info)
{
    XmComboBoxWidget cbw = (XmComboBoxWidget) XtParent(w);

/* Sollte gerade dem Eingabefeld Text aus der Listbox einverleibt
 * werden, so duerfen wir hier darueber natuerlich nicht meckern, 
 * sondern unser <<ok>> dazu geben. (D.h. in diesem Fall haben wir
 * kein Recht, zu intervenieren.)
 */
    if ( cbw->combobox.PassVerification ) {
	cbw->combobox.PassVerification = False;
	info->doit = True;
	return;
    }
/* Ist es eine Combo-Box, in die kein Text vom Benutzer eingegeben
 * werden kann, so wird bei der Eingabe von Zeichen die Schnellsuche
 * ausgeloest.
 */
    if ( !cbw->combobox.Editable ) {
	Widget         ListBox = cbw->combobox.ListCtrl;
	char           WarpCharLow, WarpCharHigh;
	XmString       Item;
	XmStringTable  Items;
	int            *SelectionList;
	int            SelectionCount;
	int            i, ItemCount, Start, End;
	char           *pItem;
	Boolean        Ignore;
	
	info->doit = False;
	if ( (info->text         == NULL ) ||
	     (info->text->length == 0    ) ) return; /* Hoppala! */
/* Nun aus dem Zeichen einen String (Motif-like) basteln und
 * in der Listbox danach auf die Suche gehen.
 */
        if ( info->text->length > 1 ) {
            /* Das ist nun endweder ein normaler Paste, oder aber
             * das Ergebnis einer Drag'n'Drop-Operation.
             */
            fprintf(stderr, ":%s:\n", info->text->ptr);
            Item = XmStringCreateSimple(info->text->ptr);
            XmComboBoxSelectItem((Widget) cbw, Item, True);
            XmStringFree(Item);
        } else {
            /* Ansonsten soll nur eine Schnellsuche ausgefuehrt
             * werden, der entsprechende Buchstabe ist das einzige 
             * Zeichen im dem Callback uebergebenen Text.
             */
	    WarpCharLow  = tolower(*(info->text->ptr));
	    WarpCharHigh = toupper(WarpCharLow);

            XtVaGetValues(ListBox, XmNitemCount, &ItemCount, 
    			           XmNitems,     &Items,  
    	                           NULL);
            if ( ItemCount < 1 ) return;
    	    /* Ermittele, wo's los geht mit der Suche... */
    	    if ( XmListGetSelectedPos(ListBox, 
    	                              &SelectionList, &SelectionCount) ) {
    	        Start = *SelectionList; i = Start + 1;
    	        XtFree((char *)SelectionList);
    	    } else i = Start = 1;
    	
    	    if ( i > ItemCount ) i = 1;
    	    Ignore = True;
    	    while ( i != Start || Ignore ) {
    	        Ignore = False;
    	        XmStringGetLtoR(Items[i-1], XmSTRING_DEFAULT_CHARSET, 
    	                        &pItem);
    	        if ( (strchr(pItem, WarpCharLow ) == pItem) ||
    	             (strchr(pItem, WarpCharHigh) == pItem) ) { 
    	            XtFree(pItem);
    		    TransferToEditCtrl(cbw, i);
    		    CallSelectionCBL(cbw, info->event);
    		    break;
    	        }
    	        XtFree(pItem);
    	        if ( ++i > ItemCount ) i = 1;
    	    }
    	}
    }
} /* EditVerifyCallback */

/* --------------------------------------------------------------------
 * Dieser Callback wird immer dann aufgerufen, wenn in einer ComboBox
 * mit einem veraenderlichem Eingabefeld der Eingabetext veraendert
 * wurde. In diesem Fall suchen wir hier nach einem passenden gleich-
 * lautenden Eintrag. Wenn wir einen finden, heben wir ihn in der Liste
 * sogleich hervor, ansonsten ist kein Eintrag hervorgehoben.
 */
static void EditChangedCallback(Widget w, XtPointer pClientDate, 
                                XmAnyCallbackStruct *info)
{
    XmComboBoxWidget cbw = (XmComboBoxWidget) XtParent(w);
    XmStringTable    Items;
    int              ItemCount, i;
    XmString         EditStr;
    String           EditLine;
    
    XtVaGetValues(cbw->combobox.EditCtrl, XmNvalue, &EditLine, NULL);
    XtVaGetValues(cbw->combobox.ListCtrl, 
                  XmNitemCount, &ItemCount, 
		  XmNitems,     &Items, 
		  NULL);
    EditStr = XmStringCreateSimple(EditLine);
    XtVaSetValues(cbw->combobox.ListCtrl, XmNselectedItemCount, 0, NULL);
    if ( ItemCount < 1 ) return;
    for ( i = 0; i < ItemCount; i++ )
	if ( XmStringCompare(Items[i], EditStr) ) {
	    SetSelectionPos(cbw, i+1, False);
	    break;
	}
    XmStringFree(EditStr);
} /* EditChangedCallback */

/* --------------------------------------------------------------------
 * Bastele einen vollstaendigen Namens- und Klassenbezeichner anhand
 * des angegebenen Widgets zusammen.
 */
static void MakeNameAndClass(Widget w, char *NameBuff, char *ClassBuff)
{
    Widget Parent = XtParent(w);
    
    if ( Parent ) MakeNameAndClass(Parent, NameBuff, ClassBuff);
    if ( XtIsSubclass(w, applicationShellWidgetClass) ) {
	/* Wenn wir ganz oben angekommen sind, holen wir uns den
	 * Namen und die Klasse der Applikation selbst und nicht die
	 * des Widgets.
	 */
	String AppName, AppClass;
	XtGetApplicationNameAndClass(
	    XtDisplayOfObject(w), &AppName, &AppClass);
	strcpy(NameBuff, AppName);
	strcpy(ClassBuff, AppClass);
    } else {
	/* Ansonsten sind wir noch mitten irgendwo in der Hierarchie
	 * und besorgen uns den Namen und die Klasse dieses Widgets
	 */
	strcat(NameBuff,  "."); 
	strcat(NameBuff,  XtName(w));
	strcat(ClassBuff, "."); 
	strcat(ClassBuff, ((CoreClassRec *) XtClass(w))->core_class.class_name);
    }
} /* MakeNameAndClass */

/* --------------------------------------------------------------------
 * Eine einzelne Resource aus der Datenbank herausholen. Diese Resource
 * kommt im Allgemeinen immer als String zurueck und muss daher erst
 * noch in das gewuenschte Zielformat konvertiert werden.
 */
static Boolean FetchResource(Widget w, 
                             char *FullName, char *FullClass, 
                             char *RscName, char *RscClass, 
			     XrmValue *RscValue, 
			     String   *RepresentationType)
{
    Boolean ok;
    char *EndOfName  = FullName  + strlen(FullName);
    char *EndOfClass = FullClass + strlen(FullClass);
    
    strcat(FullName,  "."); strcat(FullName,  RscName);
    strcat(FullClass, "."); strcat(FullClass, RscClass);
    ok = XrmGetResource(
	XtDatabase(XtDisplayOfObject(w)), 
	FullName, FullClass, RepresentationType, RscValue);
    /* Wieder den alten Namens- und Klassenrumpf herstellen */
    *EndOfName = 0; *EndOfClass = 0;
    return ok;
} /* FetchResource */

/* --------------------------------------------------------------------
 * Nun folgen diejenigen Routinen, mit denen die Konvertierung in das
 * gewuenschte Zielformat einer Resource moeglich ist.
 * Verfuegbar:
 *   String --> Int
 *   String --> Short
 *   String XmPIXMAP / XmSTRING --> unsigned char
 *   String --> Dimension
 *   String --> XmString
 *   String --> XmStringTable
 *   String --> XmFontList
 *   String --> Pixmap (genauer: Bitmap)
 */
static Boolean FetchIntResource(Widget w, 
                                char *FullName, char *FullClass, 
                                char *RscName, char *RscClass, 
			        int *pInt)
{
    XrmValue RscValue, RscDest;
    String   RepresentationType;
    
    if ( FetchResource(w, FullName, FullClass, 
                       RscName, RscClass, 
		       &RscValue, &RepresentationType) ) {
	RscDest.size = sizeof(int);
	RscDest.addr = (XtPointer) pInt;
	if ( XtConvertAndStore(w, RepresentationType, &RscValue, 
	                       XtRInt, &RscDest) )
	    return True;
    }
    return False;
} /* FetchIntResource */

static Boolean FetchShortResource(Widget w, 
                                char *FullName, char *FullClass, 
                                char *RscName, char *RscClass, 
			        short *pShort)
{
    XrmValue RscValue, RscDest;
    String   RepresentationType;
    
    if ( FetchResource(w, FullName, FullClass, 
                       RscName, RscClass, 
		       &RscValue, &RepresentationType) ) {
	RscDest.size = sizeof(short);
	RscDest.addr = (XtPointer) pShort;
	if ( XtConvertAndStore(w, RepresentationType, &RscValue, 
	                       XtRShort, &RscDest) )
	    return True;
    }
    return False;
} /* FetchShortResource */

static Boolean FetchLabelTypeResource(Widget w, 
                                char *FullName, char *FullClass, 
                                char *RscName, char *RscClass, 
			        unsigned char *pUChar)
{
    XrmValue RscValue, RscDest;
    String   RepresentationType;
    int      AInt;
    
    if ( FetchResource(w, FullName, FullClass, 
                       RscName, RscClass, 
		       &RscValue, &RepresentationType) ) {
	if ( strcasecmp((char *) RscValue.addr, "XmPIXMAP") == 0 )
	    *pUChar = XmPIXMAP;
	else
	    *pUChar = XmSTRING;
	return True;
   }
    return False;
} /* FetchLabelTypeResource */

static Boolean FetchDimensionResource(Widget w, 
                                char *FullName, char *FullClass, 
                                char *RscName, char *RscClass, 
			        Dimension *pDimension)
{
    XrmValue RscValue, RscDest;
    String   RepresentationType;
    
    if ( FetchResource(w, FullName, FullClass, 
                       RscName, RscClass, 
		       &RscValue, &RepresentationType) ) {
	RscDest.size = sizeof(Dimension);
	RscDest.addr = (XtPointer) pDimension;
	if ( XtConvertAndStore(w, RepresentationType, &RscValue, 
	                       XtRDimension, &RscDest) )
	    return True;
    }
    return False;
} /* FetchDimensionResource */

static Boolean FetchXmStringResource(Widget w, 
                                char *FullName, char *FullClass, 
                                char *RscName, char *RscClass, 
			        XmString *pString)
{
    XrmValue RscValue;
    String   RepresentationType;
    
    if ( FetchResource(w, FullName, FullClass, 
                       RscName, RscClass, 
		       &RscValue, &RepresentationType) ) {
	*pString = XmCvtCTToXmString((char *) RscValue.addr);
	return True;
    }
    return False;
} /* FetchXmStringResource */

static Boolean FetchXmStringTableResource(Widget w, 
                                char *FullName, char *FullClass, 
                                char *RscName, char *RscClass, 
			        XmStringTable *pStringTable, 
				int *pTableSize)
{
    XrmValue RscValue;
    String   RepresentationType;
    String   TmpList, p, pStart;
    int      Entries, Entry;
    
    if ( FetchResource(w, FullName, FullClass, 
                       RscName, RscClass, 
		       &RscValue, &RepresentationType) ) {
	/* 
	 * Zuerst eine Kopie erzeugen und dann daraus die Liste
	 * zusammenbasteln.
	 */
	TmpList = XtNewString((String)RscValue.addr);
	if ( TmpList == NULL ) return False;
	if ( *TmpList == 0 ) { XtFree(TmpList); return False; }
	/* Ermittele, wieviele Eintrage in der Liste sind und
	 * erstelle dann daraus die Liste.
	 */
	Entries = 1; p = TmpList;
	while ( *p )
	    if ( *p++ == ',' ) ++Entries;
	*pStringTable = (XmStringTable) 
	    XtMalloc(Entries * sizeof(XmString));
	
	p = TmpList;
	for ( Entry = 0; Entry < Entries; ++Entry ) {
	    pStart = p;
	    while ( (*p != 0) && (*p != ',') ) ++p;
	    *p++ = 0;
	    (*pStringTable)[Entry] = (XmString)
	        XmStringCreateSimple(pStart);
	}
	/* Hier geht ausnahmsweise einmal Rueckgabe vor
	 * Entschaedigung... hey, das war doch nur ein
	 * (wenn auch ziemlich miserabler) Scherz
	 */
	XtFree(TmpList);
	*pTableSize = Entries;
	return True;
    }
    return False;
} /* FetchXmStringTableResource */

static Boolean FetchXmFontListResource(Widget w, 
                                char *FullName, char *FullClass, 
                                char *RscName, char *RscClass, 
			        XmFontList *pFontList)
{
    XrmValue RscValue, RscDest;
    String   RepresentationType;
    
    if ( FetchResource(w, FullName, FullClass, 
                       RscName, RscClass, 
		       &RscValue, &RepresentationType) ) {
	RscDest.size = sizeof(XmFontList);
	RscDest.addr = (XtPointer) pFontList;
	if ( XtConvertAndStore(w, RepresentationType, &RscValue, 
	                       XmRFontList, &RscDest) )
	    return True;
    }
    return False;
} /* FetchXmFontListResource */

static Boolean FetchPixmapResource(Widget w, 
                                char *FullName, char *FullClass, 
                                char *RscName, char *RscClass,
				Pixmap *pPixmap)
{
    XrmValue RscValue, RscDest;
    String   RepresentationType;
    
    if ( FetchResource(w, FullName, FullClass, 
                       RscName, RscClass, 
		       &RscValue, &RepresentationType) ) {
	RscDest.size = sizeof(Pixmap);
	RscDest.addr = (XtPointer) pPixmap;
	if ( XtConvertAndStore(w, RepresentationType, &RscValue, 
	                       XtRBitmap, &RscDest) )
	    return True;
    }
    return False;
} /* FetchPixmapResource */

/* --------------------------------------------------------------------
 * Waehrend der Initialisierung alle gespiegelten Resourcen, fuer die
 * Eintraege in der Resourcen-Datenbank existieren an die passenden
 * Kinder-Widgets weiterleiten. Der Trick an der Sache: wir setzen
 * die betroffenen Resourcen vie XtSetValues mit uns selbst als Ziel.
 * Dadurch bekommt SetValues die Arbeit aufgehalst, die Resourcen den
 * richtigen Kindern zuzuordnen...
 */
typedef struct {
    String Name, Class;
    enum { RInt, RShort, RLType, RDimension, 
           RXmString, RPixmap, RXmFontList,
           RXmStringTable, RXmItemCount       } Converter;
} RESOURCEMIRROR;

static RESOURCEMIRROR ResourceMirror[] = {
    { XmNblinkRate,		 XmCBlinkRate,		    RInt,          }, 
    { XmNcolumns,		 XmCColumns,		    RShort,        }, 
    { XmNmaxLength,		 XmCMaxLength,		    RInt,          }, 
    { XmNmarginHeight,		 XmCMarginHeight,	    RDimension     }, 
    { XmNmarginWidth,		 XmCMarginWidth,	    RDimension     },
    { XmNselectThreshold,	 XmCSelectThreshold,	    RInt           }, 
     
    { XmNlistMarginHeight,	 XmCListMarginHeight,	    RDimension     }, 
    { XmNlistMarginWidth,	 XmCListMarginWidth,	    RDimension     }, 
    { XmNlistSpacing,		 XmCListSpacing,	    RDimension     },
    { XmNitems,		         XmCItems,		    RXmStringTable },
    { XmNitemCount,		 XmCItemCount,	    	    RXmItemCount   },
    
    { XmNlabelString,		 XmCLabelString,	    RXmString      }, 
    { XmNlabelMarginBottom,	 XmCLabelMarginBottom,	    RDimension     }, 
    { XmNlabelMarginHeight,	 XmCLabelMarginHeight,	    RDimension     }, 
    { XmNlabelMarginLeft,	 XmCLabelMarginLeft,	    RDimension     }, 
    { XmNlabelMarginRight,	 XmCLabelMarginRight,	    RDimension     }, 
    { XmNlabelMarginTop,	 XmCLabelMarginTop,	    RDimension     }, 
    { XmNlabelMarginWidth,	 XmCLabelMarginWidth,	    RDimension     }, 
    { XmNlabelPixmap,		 XmCLabelPixmap,	    RPixmap        },
    { XmNlabelInsensitivePixmap, XmCLabelInsensitivePixmap, RPixmap        }, 
    { XmNlabelType,		 XmCLabelType,		    RLType         }, 
    { XmNlabelFontList,          XmCLabelFontList,	    RXmFontList    }, 
};

static void InitMirrorResources(XmComboBoxWidget w)
{
    char          FullName[1024], FullClass[1024];
    int           AInt, TableSize;
    short         AShort;
    unsigned char AUChar;
    Dimension     ADimension;
    XmString      AString;
    XmStringTable AStringTable;
    Pixmap        APixmap;
    XmFontList    AFontList;
    XrmValue      RscValue;
    int           i, size = XtNumber(ResourceMirror);
    
    FullName[0] = 0; FullClass[0] = 0;
    MakeNameAndClass((Widget) w, FullName, FullClass);

    for ( i=0; i < size; i++ ) {
	switch ( ResourceMirror[i].Converter ) {
	    case RInt:
		if ( FetchIntResource((Widget) w, 
			FullName, FullClass, 
			ResourceMirror[i].Name, ResourceMirror[i].Class, 
			&AInt) )
		    XtVaSetValues((Widget) w, ResourceMirror[i].Name, 
		                  AInt, NULL);
		break;
	    case RXmItemCount:
		if ( FetchIntResource((Widget) w, 
			FullName, FullClass, 
			ResourceMirror[i].Name, ResourceMirror[i].Class, 
			&AInt) && ( AInt != 0) )
		    XtVaSetValues((Widget) w, ResourceMirror[i].Name, 
		                  AInt, NULL);
		break;
	    case RShort:
		if ( FetchShortResource((Widget) w, 
			FullName, FullClass, 
			ResourceMirror[i].Name, ResourceMirror[i].Class, 
			&AShort) )
		    XtVaSetValues((Widget) w, ResourceMirror[i].Name, 
		                  AShort, NULL);
		break;
	    case RLType:
		if ( FetchLabelTypeResource((Widget) w, 
			FullName, FullClass, 
			ResourceMirror[i].Name, ResourceMirror[i].Class, 
			&AUChar) )
		    XtVaSetValues((Widget) w, ResourceMirror[i].Name, 
		                  AUChar, NULL);
		break;
	    case RDimension:
		if ( FetchDimensionResource((Widget) w, 
			FullName, FullClass, 
			ResourceMirror[i].Name, ResourceMirror[i].Class, 
			&ADimension) )
		    XtVaSetValues((Widget) w, ResourceMirror[i].Name, 
		                  ADimension, NULL);
		break;
	    case RXmString:
		if ( FetchXmStringResource((Widget) w, 
			FullName, FullClass, 
			ResourceMirror[i].Name, ResourceMirror[i].Class, 
			&AString) )
		    XtVaSetValues((Widget) w, ResourceMirror[i].Name, 
		                  AString, NULL);
		break;
	    case RXmStringTable:
	        if ( FetchXmStringTableResource((Widget) w,
	                 FullName, FullClass,
	                 ResourceMirror[i].Name, ResourceMirror[i].Class,
	                 &AStringTable, &TableSize) ) {
		    XtVaSetValues((Widget) w, 
		         XmNitems, (XtPointer) AStringTable, 
			 XmNitemCount, TableSize, NULL);
		}
	        break;
	    case RPixmap:
		if ( FetchPixmapResource((Widget) w, 
			FullName, FullClass, 
			ResourceMirror[i].Name, ResourceMirror[i].Class, 
			&APixmap) ) {
		    XtVaSetValues((Widget) w, ResourceMirror[i].Name, 
		                  APixmap, NULL);
		    if ( strcmp(ResourceMirror[i].Name, XmNlabelPixmap) == 0 )
			w->combobox.ConvertBitmapToPixmap = True;
		    else
			w->combobox.ConvertBitmapToPixmapInsensitive = True;
		}
		break;
	    case RXmFontList:
	    	if ( FetchXmFontListResource((Widget) w,
	    	       FullName, FullClass,
	    	       ResourceMirror[i].Name, ResourceMirror[i].Class,
	    	       &AFontList) )
	    	    XtVaSetValues((Widget) w, ResourceMirror[i].Name,
	    	                  AFontList, NULL);
	    	break;
	}
    }
} /* InitMirrorResources */

/* --------------------------------------------------------------------
 * Wandelt ein 1-Bit tiefes Bitmap in ein n-Bit tiefes Pixmap um, dass
 * die gleiche Tiefe besitzt, wie der Bildschirm, auf dem das Pixmap
 * spaeter erscheinen soll.
 */
static Pixmap BitmapToPixmap(XmComboBoxWidget w, 
                           String Resource, GC ColorGC)
{
    Pixmap       LabelPixmap, LabelBitmap;
    Display      *display = XtDisplay(w);
    Window       root;
    int          PixX, PixY;
    unsigned int PixW, PixH, PixBW, PixDepth;

    XtVaGetValues(w->combobox.LabelCtrl, Resource, &LabelBitmap, NULL);
    XGetGeometry(display, LabelBitmap, &root, 
		 &PixX, &PixY, &PixW, &PixH, &PixBW, &PixDepth);
    LabelPixmap = XCreatePixmap(
			display, RootWindowOfScreen(XtScreen(w)), 
			PixW, PixH, 
			(w->combobox.LabelCtrl)->core.depth);
    XCopyPlane(display, LabelBitmap, LabelPixmap, 
	       ColorGC, 0, 0, PixW, PixH, 0, 0, 1);
    XtVaSetValues(w->combobox.LabelCtrl, Resource, LabelPixmap, NULL);
    XFreePixmap(display, LabelBitmap);
    return LabelPixmap;
} /* BitmapToPixmap */

/* --------------------------------------------------------------------
 * Alles initialisieren, sobald das Widget eingerichtet wird. Das sagt
 * sich hier so einfach, ist es aber *definitiv* nicht!!!!
 */
static void Initialize(Widget request, XmComboBoxWidget new, 
                       ArgList wargs, Cardinal *ArgCount)
{
    Dimension    width, height, dummy;
    Widget       w;
    Arg          args[10];
    int          n = 0;
    XmString     xmstr;
    Pixel        BackgroundColor;
    
/* Da ja eventuell dieser Programmcode in einer Shared Library sich befinden
 * kann und/oder zu allem Ueberfluss die einzelnen Instanzen einer XmComboBox
 * auf verschiedenen Displays auftauchen, wird:
 * 1. pro Widget ein eigener Cursor erzeugt (benoetigt fuer die Liste)
 * 2. pro Widget (hier = pro Applikation) die benoetigte Action-Routine
 * registiert. Doppelte Registrierung macht dem Toolkit nichts aus, da es
 * dann eine evtl. aeltere Definition loescht.
 */
    XtAppAddActions(XtWidgetToApplicationContext((Widget) new), 
	                actions, XtNumber(actions));
    
/* Allgemeine Initialisierungen... */
    new->combobox.ConvertBitmapToPixmap            = False;
    new->combobox.ConvertBitmapToPixmapInsensitive = False;
    
/* Lass' dich benachrichtigen, sobald dieses Widget in irgendeiner
 * Form bewegt wird -- und sei es nur, dass das gesamte Applikations-
 * fenster umhergeschoben wurde. Um die Benachrichtigung ueberhaupt
 * zu erreichen, ist es erforderlich, sich benachrichtigen zu lassen, 
 * sobald die naechste Shell (oder ein Nachkomme) im Widget-Instanzen-
 * Baum verschoben wurde.
 */
    w = (Widget) new;
    while ( !XtIsSubclass(w, shellWidgetClass) )
	w = XtParent(w);
    new->combobox.MyNextShell = w;
    XtAddEventHandler(w, 
                      StructureNotifyMask | FocusChangeMask, 
		      False, (XtEventHandler) ShellCallback, 
		      (XtPointer) new);
 
/* Richte nun alle zu diesem Widget gehoerenden Kinder ein, als da
 * waeren:
 * 1 x editierbare Zeile
 * 1 x ein Pfeil nach unten
 * 1 x ein Textlabel
 */
    new->combobox.EditCtrl = XtVaCreateManagedWidget(
	"edit", xmTextFieldWidgetClass, (Widget) new,
	XmNverifyBell, False, 
	NULL);
    XtAddCallback(new->combobox.EditCtrl, 
                  XmNlosingFocusCallback, 
		  (XtCallbackProc) EditFocusCallback, NULL);
    XtAddCallback(new->combobox.EditCtrl, 
                  XmNmodifyVerifyCallback, 
		  (XtCallbackProc) EditVerifyCallback, NULL);
    XtAddCallback(new->combobox.EditCtrl, 
                  XmNvalueChangedCallback, 
		  (XtCallbackProc) EditChangedCallback, NULL);
    XtAddCallback(new->combobox.EditCtrl, 
                  XmNhelpCallback, 
		  (XtCallbackProc) HelpCallback, 
		  (XtPointer) new);
/* Neue Translations fuer das Eingabefeld aufnehmen */
    XtOverrideTranslations(new->combobox.EditCtrl, 
                           NewEditTranslations);
    if ( !new->combobox.Editable )
	XtOverrideTranslations(new->combobox.EditCtrl, 
                               NewEditTranslationsNE);
#ifdef NODRAGNDROP
    XtOverrideTranslations(new->combobox.EditCtrl, 
                           NewListTranslations); /* Btn2Dwn aus! */
#endif

/* --- */
    new->combobox.ArrowCtrl = XtVaCreateManagedWidget(
	"arrow", xmArrowButtonWidgetClass, (Widget) new, 
	XmNarrowDirection,     XmARROW_DOWN, 
	XmNtraversalOn,	       False, 
	XmNnavigationType,     XmNONE,
	XmNborderWidth,        0, 
	XmNhighlightThickness, 0, 
	NULL);
    XmRemoveTabGroup(new->combobox.ArrowCtrl);
    XtAddEventHandler(new->combobox.ArrowCtrl, 
                      EnterWindowMask | LeaveWindowMask,
                      False, (XtEventHandler) ArrowCrossingCallback,
                      (XtPointer) new);
    XtAddCallback(new->combobox.ArrowCtrl, 
                  XmNactivateCallback, 
		  (XtCallbackProc) ArrowCallback, NULL);
    XtAddCallback(new->combobox.ArrowCtrl, 
                  XmNarmCallback, 
		  (XtCallbackProc) ArrowCallback, NULL);
    XtAddCallback(new->combobox.ArrowCtrl, 
                  XmNhelpCallback, 
		  (XtCallbackProc) HelpCallback, 
		  (XtPointer) new);
/* --- */
    new->combobox.LabelCtrl = XtVaCreateWidget(
	"label", xmLabelWidgetClass, (Widget) new, 
	XmNstringDirection, new->manager.string_direction, 
	NULL);
    if ( new->combobox.ShowLabel ) {
	XtManageChild((Widget) new->combobox.LabelCtrl);
	XtAddCallback(new->combobox.LabelCtrl, 
		      XmNhelpCallback, 
		      (XtCallbackProc) HelpCallback, 
		      (XtPointer) new);
    }

/* Zuerst noch die Shell erzeugen, die so einfach mir nichts dir nichts
 * frei auf dem Bildschirm herumschweben kann und damit das Ausklappen
 * der Liste erst ermoeglicht -- und uns allerhand Scherereien bereitet!
 * War das ein bloeder Fehler in Motif 1.2! Diese Version vertraegt ab-
 * solut keine ShellWidgetClass noch overrideShellWidgetClass!!!! Naja,
 * mit einer vendorShellWidgetClass laesst sich aber exakt der gleiche
 * Effekt erreichen. NEU: vor allem funktioniert dann endlich auch
 * Drag'n'Drop!!!
 */
    new->combobox.PopupShell = XtVaCreateWidget(
	"combobox_shell", vendorShellWidgetClass, (Widget) new, 
	XmNoverrideRedirect, True,
	XmNsaveUnder,        True,
	XmNallowShellResize, True, 
	NULL);
    XtAddEventHandler(new->combobox.PopupShell, 
                      EnterWindowMask | LeaveWindowMask, 
		      False, (XtEventHandler) OverrideShellCallback, 
		      (XtPointer) new);

/* Nun kommt die Drop-Down-Liste an die Reihe. Die Liste muss dabei
 * mit einer Convenience-Funktion erstellt werden, damit ein Rollbalken
 * 'dran ist und das Ganze wird dann in eine Override-Shell gepackt.
 * Nicht zu vergessen ist der XtManageChild-Aufruf, damit die Liste
 * sofort nach dem Aufklappen der Shell sichtbar wird.
 */
    XtSetArg(args[n], XmNselectionPolicy, XmBROWSE_SELECT); n++;
    XtSetArg(args[n], XmNhighlightThickness, 0); n++;
    XtSetArg(args[n], XmNautomaticSelection, False); n++;
    XtSetArg(args[n], XmNscrollBarDisplayPolicy, XmSTATIC); n++;
    XtSetArg(args[n], XmNlistSizePolicy, XmVARIABLE); n++;
    XtSetArg(args[n], XmNvisibleItemCount, 
                      new->combobox.VisibleItemCount); n++;
    new->combobox.ListCtrl = XmCreateScrolledList(
	new->combobox.PopupShell, "list",  
	args, n);
    XtVaSetValues(new->combobox.ListCtrl, 
                  XmNtraversalOn,  False,  NULL);
    XtVaSetValues(XtParent(new->combobox.ListCtrl), 
	          XmNtraversalOn, False, NULL);
		  
    XtManageChild(new->combobox.ListCtrl);
    XtAddCallback(new->combobox.ListCtrl, 
                  XmNsingleSelectionCallback, 
		  (XtCallbackProc) ListSelectionCallback, NULL);
    XtAddCallback(new->combobox.ListCtrl, 
                  XmNbrowseSelectionCallback, 
		  (XtCallbackProc) ListSelectionCallback, NULL);
    XtAddCallback(new->combobox.ListCtrl, 
                  XmNdefaultActionCallback, 
		  (XtCallbackProc) ListSelectionCallback, NULL);
    XtAddCallback(new->combobox.ListCtrl, 
                  XmNhelpCallback, 
		  (XtCallbackProc) HelpCallback, 
		  (XtPointer) new);
#ifdef NODRAGNDROP
    XtOverrideTranslations(new->combobox.ListCtrl, 
                           NewListTranslations);
#endif
/* Jetzt wird es dann erst richtig spannend... Zuerst alle evtl.
 * in der Resource-Datenbank abgelegten Resourcen an die Kinder
 * weitergeben. Danach die uebergebenen Parameter ebenfalls an
 * die Kinder weiterreichen und schliesslich das Layout ermitteln.
 */
    InitMirrorResources(new);
    UpdateColors(new, -1);
    SetValues(new, new, new, wargs, ArgCount);
    
    if ( new->combobox.ConvertBitmapToPixmap ) 
	new->combobox.LabelPixmap = 
	    BitmapToPixmap(new, XmNlabelPixmap, 
	               ((XmLabelRec *) new->combobox.LabelCtrl)->
		         label.normal_GC);
    if ( new->combobox.ConvertBitmapToPixmapInsensitive ) 
	new->combobox.LabelInsensitivePixmap = 
	    BitmapToPixmap(new, XmNlabelInsensitivePixmap, 
	               ((XmLabelRec *) new->combobox.LabelCtrl)->
		         label.insensitive_GC);
    
    DefaultGeometry(new, &width, &height, &dummy, &dummy);
    if ( new->core.width == 0 )
	new->core.width  = width;
    if ( new->core.height == 0 )
	new->core.height = height;

/*
 * Falls wir keine Fontliste besitzen, dann nehmen wir die von
 * dem Eingabefeld...
 */
    if ( new->combobox.Font == NULL ) {
	XtVaGetValues(new->combobox.EditCtrl, 
	              XmNfontList, &new->combobox.Font, NULL);
	XtVaSetValues(new->combobox.ListCtrl, 
	              XmNfontList, new->combobox.Font, NULL);
    } else {
	XtVaSetValues(new->combobox.ListCtrl, 
	              XmNfontList, new->combobox.Font, NULL);
	XtVaSetValues(new->combobox.EditCtrl, 
	              XmNfontList, new->combobox.Font, NULL);
    }
    
/* Initialisiere alle Statusflaggen, die mit diesem unseligen Focus-
 * problem zu tun haben...
 */
    new->combobox.ListVisible          = False;
    new->combobox.IgnoreFocusOut       = False;
    new->combobox.PendingFocusOut      = False;
    new->combobox.PendingOverrideInOut = False;
    
    new->combobox.PassVerification = False;

/* Jooa... bei der OSF pennen die wohl komplett?! Zusammen mit Form-
 * Widgets gibt das wohl immer Aerger...daher hier ein DoLayout()
 * aufrufen, damit Eingabefeld und Pfeil an der richtigen Stelle
 * sitzen!
 */
    DoLayout(new);
/* Endlich fertig mit der Initialisierung. Das hier ist aber auch
 * wirklich viel Arbeit fuer so ein Widget!
 */    
} /* Initialize */

/* --------------------------------------------------------------------
 * Diese Funktionen bitte nur im aeussersten Notfall benutzen, da sie
 * die Abstraktion dieser neuen Klasse umgehen und Informationen ueber
 * den internen Aufbau voraussetzen.
 */
Widget XmComboBoxGetEditWidget(Widget w)
{
    return ((XmComboBoxWidget) w)->combobox.EditCtrl;
} /* XmComboBoxGetEditWidget */

Widget XmComboBoxGetListWidget(Widget w)
{
    return ((XmComboBoxWidget) w)->combobox.ListCtrl;
} /* XmComboBoxGetListWidget */

Widget XmComboBoxGetLabelWidget(Widget w)
{
    return ((XmComboBoxWidget) w)->combobox.LabelCtrl;
} /* XmComboBoxGetLabelWidget */

/* --------------------------------------------------------------------
 * Sobald sich im Listenfeld Eintraege veraenderten, sei es, dass sie
 * geloescht wurden, sei es, dass sie veraendert wurden, so muss hier
 * gegebenenfalls auch der Text im Eingabefeld angepasst werden.
 * Letzteres betrifft aber nur Combo-Boxen mit nicht editierbarem
 * Eingabefeld. In jedem Fall wird aber bei jeder Combo-Box-Type in
 * dem Fall, dass ein Eintrag geloescht wird, der darauffolgende
 * Eintrag markiert. Eigentlich ist dieses nur eine nette Geste
 * gegenueber dem Benutzer...
 * 
 * Parameter:
 *   w		    Combo-Box-Widget
 *   Index	    Index auf denjenigen Eintrag der sich geaendert
 *		    hat, oder der geloescht wurde.
 *   Deleted	    Zeigt an, ob der Eintrag geloescht wurde (True)
 *		    oder sich nur veraenderte (False)
 */
static UpdateComboBox(XmComboBoxWidget w, int Index, Boolean Deleted)
{
    int OldIndex, ItemCount;
    
    OldIndex = XmComboBoxGetSelectedPos((Widget) w);
    if ( OldIndex == Index ) {
/* Es betrifft den Eintrag, der auch momentan ausgewaehlt ist.
 * Sollte er geloescht werden, so nimm' (soweit vorhanden) den
 * naechsten Eintrag, wurde er ausgetauscht, so lass ihn ausge-
 * waehlt.
 */
	if ( Deleted ) {
	    XtVaGetValues(w->combobox.ListCtrl, 
	                  XmNitemCount, &ItemCount, NULL);
	    if ( ItemCount != 0 ) {
		if ( Index >= ItemCount ) Index = ItemCount;
		/* Markieren des Eintrags, ohne jedoch jetzt schon
		 * den Eintrag in die Eingabezeile zu kopieren.
		 */
		SetSelectionPos(w, Index, False);
	    }
	}
    }
/* Das Problem betrifft uns nur bei nicht editierbaren Combo-Boxen
 * im vollen Umfang. Denn dann muss auch der Text im Eingabefeld
 * veraendert werden.
 */
    if ( !w->combobox.Editable ) {
	TransferToEditCtrl(w, Index);
    }
} /* UpdateComboBox */


/* --------------------------------------------------------------------
 * Die Eintragsposition finden, an der der Eintrag sortiert stehen
 * muesste.
 */
static int FindSortedItemPos(XmComboBoxWidget w, XmString item)
{
    Widget         ListBox = w->combobox.ListCtrl;
    XmStringTable  Items;
    int            ItemCount, i, BestFit;
    char           *pItemText, *pCompareText;
    
    XtVaGetValues(ListBox, XmNitems,     &Items, 
                           XmNitemCount, &ItemCount, NULL);
    XmStringGetLtoR(item, XmSTRING_DEFAULT_CHARSET, &pCompareText);

    BestFit = 0;
    for ( i = 0; i < ItemCount; i++ ) {
	XmStringGetLtoR(Items[i], XmSTRING_DEFAULT_CHARSET, &pItemText);
	if ( strcmp(pItemText, pCompareText) > 0 ) {
	    XtFree(pItemText);
	    BestFit = i+1;
	    break;
	}
	XtFree(pItemText);
    }
    XtFree(pCompareText);
    return BestFit;
} /* FindSortedItemPos */

/* --------------------------------------------------------------------
 * Kontrolliere, ob es sich ueberhaupt um eine Combo-Box (bzw. einen
 * hypothetischen Nachkommen) handelt -- ansonsten mecker kraeftig
 * herum!
 * Ergebnis:
 *   True, falls wir hier ein falsches Widget untergejubelt bekommen!
 */
static Boolean CheckComboBox(Widget w, char *pFuncName)
{
    char buff[256];
    char *pWName;
    
    if ( XmIsComboBox(w) ) return False;
    pWName = XrmQuarkToString(w->core.xrm_name);
    sprintf(buff, 
"Warning: %s called on widget named %s beeing \
not a descendant of class XmComboBox!", 
		  pFuncName, pWName);
    XtWarning(buff);
    return True;
} /* CheckComboBox */

/* --------------------------------------------------------------------
 * Saemtliche Interface-Routinen zur Combo-Box
 */
/* Zunaechst alles fuer die Listbox */
#define ListBox (((XmComboBoxWidget) w)->combobox.ListCtrl)
#define EditBox (((XmComboBoxWidget) w)->combobox.EditCtrl)
#define ComboBox ((XmComboBoxWidget) w)

/* !!!
 * So angepasst, dass bei doppelt auftretenden Eintraegen, der
 * alte Eintrag weiterhin markiert bleibt. Diese Massnahme soll
 * eigentlich nur verhindern, dass zufaellig zwei Eintraege
 * markiert sind, falls nach der Anwahl eines Eintrages ein zweiter
 * gleichlautender Eintrag hinzugefuegt wurde.
 * Was hier die reine Lehre (oder war das die Leere?) anbetrifft:
 * in einer Combo-Box sollten sich sowieso nie gleichlautende
 * Eintraege befinden, da sie dort unsinnig sind und den Benutzer
 * nur verwirren...
 */
void    XmComboBoxAddItem(Widget w, XmString item, int pos)
{
    int OldIndex = XmComboBoxGetSelectedPos(w);
    
    if ( CheckComboBox(w, "XmComboBoxAddItem") ) return;
    if ( ComboBox->combobox.Sorted )
	pos = FindSortedItemPos(ComboBox, item);
    XmListAddItem(ListBox, item, pos);
    if ( OldIndex != XmComboBoxGetSelectedPos(w) )
        /* Hier SetSelectionPos() statt XmComboBoxSelectPos(),
	 * da der Text nicht in das Eingabefeld uebertragen werden
	 * soll!
	 */
	SetSelectionPos(ComboBox, OldIndex, False);
} /* XmComboBoxAddItem */
/* !!!
 * Hier gilt das bereits oben gesagte (siehe XmComboBoxAddItem).
 * Bei sortierten Listboxen wird die Sortierung beim Gebrauch dieser
 * Funktion zerstoert!
 */
void    XmComboBoxAddItems(Widget w, XmString *items, int item_count, int pos)
{
    int OldIndex = XmComboBoxGetSelectedPos(w);

    if ( CheckComboBox(w, "XmComboBoxAddItems") ) return;
    XmListAddItems(ListBox, items, item_count, pos);
    if ( OldIndex != XmComboBoxGetSelectedPos(w) )
	/* Siehe Anmerkung in XmComboBoxAddItem */
	SetSelectionPos(ComboBox, OldIndex, False);
} /* XmComboBoxAddItems */

void    XmComboBoxAddItemUnselected(Widget w, XmString item, int pos)
{ XmListAddItemUnselected(ListBox, item, pos); }

/* !!!
 * Da bei den folgenden Routinen jeweils ein oder mehrere Eintraege
 * geloescht oder veraendert werden, muss gegebenefalls das Eingabe-
 * feld bei nicht editierbaren Combo-Boxen auf Vordermann gebracht
 * werden.
 */
void    XmComboBoxDeleteItem(Widget w, XmString item)
{
    int Index = XmListItemPos(ListBox, item);

    if ( CheckComboBox(w, "XmComboBoxDeleteItem") ) return;
    if ( Index ) XmComboBoxDeletePos(w, Index);
} /* XmComboBoxDeleteItem */

void    XmComboBoxDeleteItems(Widget w, XmString *items, int item_count)
{
    int i;

    if ( CheckComboBox(w, "XmComboBoxDeleteItems") ) return;
    for ( i = 0; i < item_count; i++ )
	XmListDeleteItem(w, items[i]);
} /* XmComboBoxDeleteItems */

void    XmComboBoxDeletePos(Widget w, int pos)
{
    int OldIndex = XmComboBoxGetSelectedPos(w);
    
    if ( CheckComboBox(w, "XmComboBoxDeletePos") ) return;
    XmListDeletePos(ListBox, pos);
    if ( pos == OldIndex ) UpdateComboBox(ComboBox, pos, True);
} /* XmComboBoxDeletePos */

void    XmComboBoxDeleteItemsPos(Widget w, int item_count, int pos)
{
    int i;

    if ( CheckComboBox(w, "XmComboBoxDeleteItemsPos") ) return;
    for ( i = 0; i < item_count; i++ )
	XmComboBoxDeletePos(w, pos++);
} /* XmComboBoxDeleteItemsPos */

void    XmComboBoxDeleteAllItems(Widget w)
{
    if ( CheckComboBox(w, "XmComboBoxAllDeleteItems") ) return;
    XmListDeleteAllItems(ListBox);
    UpdateComboBox(ComboBox, 0, True);
} /* XmComboBoxDeleteAllItems */

/* !!!
 * Werden Eintraege ausgetauscht, so heisst es fuer uns, auch hierbei
 * auf der Hut zu sein.
 */
void    XmComboBoxReplaceItems(Widget w, XmString *old_items, int item_count, XmString *new_items)
{
    if ( CheckComboBox(w, "XmComboBoxReplaceItems") ) return;
    XmListReplaceItems(ListBox, old_items, item_count, new_items);
    UpdateComboBox(ComboBox, XmComboBoxGetSelectedPos(w), False);
} /* XmComboBoxReplaceItems */

void    XmComboBoxReplaceItemsPos(Widget w, XmString *new_items, int item_count, int position)
{
    int OldIndex = XmComboBoxGetSelectedPos(w);

    if ( CheckComboBox(w, "XmComboBoxReplaceItemsPos") ) return;
    XmListReplaceItemsPos(ListBox, new_items, item_count, position);
    if ( (OldIndex >= position) && (OldIndex < position + item_count) )
	UpdateComboBox(ComboBox, OldIndex, False);
} /* XmComboBoxReplaceItemsPos */

Boolean XmComboBoxItemExists(Widget w, XmString item)
{
    if ( CheckComboBox(w, "XmComboBoxItemExists") ) return False;
    return XmListItemExists(ListBox, item);
} /* XmComboBoxItemExists */

int     XmComboBoxItemPos(Widget w, XmString item)
{
    if ( CheckComboBox(w, "XmComboBoxItemPos") ) return 0;
    return XmListItemPos(ListBox, item);
} /* XmComboBoxItemPos */

Boolean XmComboBoxGetMatchPos(Widget w, XmString item, int **pos_list, int *pos_count)
{
    if ( CheckComboBox(w, "XmComboBoxGetMatchPos") ) return False;
    return XmListGetMatchPos(ListBox, item, pos_list, pos_count);
} /* XmComboBoxGetMatchPos */

/* !!!
 * Sobald ein anderer Eintrag in der Listbox ausgewaehlt werden soll,
 * muessen wir hier helfend eingreifen.
 */
void    XmComboBoxSelectPos(Widget w, int pos, Boolean notify)
{
    int index;
    
    if ( CheckComboBox(w, "XmComboBoxSelectPos") ) return;
    index = SetSelectionPos(ComboBox, pos, notify);
    if ( index ) TransferToEditCtrl(ComboBox, index);
} /* XmComboBoxSelectPos */

/* !!!
 * dto. analog zu XmComboBoxSelectPos, nur statt des Index wird der
 * Eintragstext angegeben, um einen Eintrag in der Listbox zu
 * markieren.
 */
void    XmComboBoxSelectItem(Widget w, XmString item, Boolean notify)
{
    int index;
    
    if ( CheckComboBox(w, "XmComboBoxSelectItem") ) return;
    XmListSelectItem(ListBox, item, notify);
    index = SetSelectionPos(ComboBox, XmComboBoxGetSelectedPos(w), False);
    if ( index ) TransferToEditCtrl(ComboBox, index);
} /* XmComboBoxSelectItem */

/* !!!
 * Geaendert gegenueber dem ListBox-Pendant! Da in einer Combo-Box die
 * Liste nur maximal einen ausgewaehlten Eintrag besitzt, macht die
 * 'alte' Funktionalitaet von XmListGetSelectedPos ziemlich wenig Sinn.
 * Die neue Routine liefert statt dessen direkt den Index des aus-
 * gewaehlten Eintrages oder 0 zurueck.
 */
int     XmComboBoxGetSelectedPos(Widget w)
{
    int *SelectionList, SelectionCount, SelectionIndex;
    
    if ( CheckComboBox(w, "XmComboBoxGetSelectedPos") ) return 0;
    if ( XmListGetSelectedPos(ListBox,
	                      &SelectionList, &SelectionCount) ) {
	SelectionIndex = *SelectionList;
	XtFree((char *)SelectionList);
    } else SelectionIndex = 0;
    return SelectionIndex;
} /* XmComboBoxGetSelectedPos */



void    XmComboBoxClearSelection(Widget w, Time time)
{
    XmTextFieldClearSelection(EditBox, time);
} /* XmComboBoxClearSelection */

Boolean XmComboBoxCopy(Widget w, Time time)
{
    return XmTextFieldCopy(EditBox, time);
} /* XmComboBoxCopy */

Boolean XmComboBoxCut(Widget w, Time time)
{
    return XmTextFieldCut(EditBox, time);
} /* XmComboBoxCut */

XmTextPosition XmComboBoxGetInsertionPosition(Widget w)
{
    return XmTextFieldGetInsertionPosition(EditBox);
} /* XmComboBoxGetInsertionPosition */

XmTextPosition XmComboBoxGetLastPosition(Widget w)
{
    return XmTextFieldGetLastPosition(EditBox);
} /* XmComboBoxGetLastPosition */

int     XmComboBoxGetMaxLength(Widget w)
{
    return XmTextFieldGetMaxLength(EditBox);
} /* XmComboBoxGetMaxLength */

char *  XmComboBoxGetSelection(Widget w)
{
    return XmTextFieldGetSelection(EditBox);
} /* XmComboBoxGetSelection */

Boolean XmComboBoxGetSelectionPosition(Widget w, XmTextPosition *left, 
                                       XmTextPosition *right)
{
    return XmTextFieldGetSelectionPosition(EditBox, left, right);
} /* XmComboBoxGetSelectionPosition */

char *  XmComboBoxGetString(Widget w)
{
    return XmTextFieldGetString(EditBox);
} /* XmComboBoxGetString */

void    XmComboBoxInsert(Widget w, XmTextPosition position, char *value)
{
    XmTextFieldInsert(EditBox, position, value);
} /* XmComboBoxInsert */

Boolean XmComboBoxPaste(Widget w)
{
    return XmTextFieldPaste(EditBox);
} /* XmComboBoxPaste */

Boolean XmComboBoxRemove(Widget w)
{
    return XmTextFieldRemove(EditBox);
} /* XmComboBoxRemove */

void    XmComboBoxReplace(Widget w, XmTextPosition from_pos, 
                          XmTextPosition to_pos, char *value)
{
    XmTextFieldReplace(EditBox, from_pos, to_pos, value);
} /* XmComboBoxReplace */

void    XmComboBoxSetAddMode(Widget w, Boolean state)
{
    XmTextFieldSetAddMode(EditBox, state);
} /* XmComboBoxSetAddMode */

void    XmComboBoxSetHighlight(Widget w, XmTextPosition left, 
                               XmTextPosition right, XmHighlightMode mode)
{
    XmTextFieldSetHighlight(EditBox, left, right, mode);
} /* XmComboBoxSetHighlight */

void    XmComboBoxSetInsertionPosition(Widget w, XmTextPosition position)
{
    XmTextFieldSetInsertionPosition(EditBox, position);
} /* XmComboBoxSetInsertionPosition */

void    XmComboBoxSetMaxLength(Widget w, int max_length)
{
    XmTextFieldSetMaxLength(EditBox, max_length);
} /* XmComboBoxSetMaxLength */

void    XmComboBoxSetSelection(Widget w, XmTextPosition first, 
                               XmTextPosition last, Time time)
{
    XmTextFieldSetSelection(EditBox, first, last, time);
} /* XmComboBoxSetSelection */

void    XmComboBoxSetString(Widget w, char *value)
{
/* Liebe OSF...ihr ^&*#%$*&)*(@$(*^(*&%# habt doch einen ziemlich gemeinen
 * Fehler in XmTextFieldSetString() drin... wenn man einen leeren String
 * (also "") angiebt, gibt's nur noch Aerger, wenn man spaeter wieder an
 * den Inhalt des Eingabefeldes heranwill.
 */
    if ( (value == NULL) || (*value == 0) )
        XtVaSetValues(w, XmNvalue, "", NULL);
    else
	XmTextFieldSetString(EditBox, value);
} /* XmComboBoxSetString */

void    XmComboBoxShowPosition(Widget w, XmTextPosition position)
{
    XmTextFieldShowPosition(EditBox, position);
} /* XmComboBoxShowPosition */


/* Die Drop-Down-Liste ein oder ausklappen */
void    XmComboBoxShowList(Widget w)
{
    if ( CheckComboBox(w, "XmComboBoxShowList") ) return;
    ShowHideDropDownList((XmComboBoxWidget) w, NULL, False);
} /* XmComboBoxShowList */

void    XmComboBoxHideList(Widget w)
{
    if ( CheckComboBox(w, "XmComboBoxHideList") ) return;
    ShowHideDropDownList((XmComboBoxWidget) w, NULL, True);
} /* XmComboBoxShowList */

/* Ende von ComboBox.c */
