/*========================================================================*
 * TITLE:	Ansi File View for X11-QMR
 * MODULE:	aview.c
 * BY:		Ross C Linder (c) 1994
 *
 * NOTE: This simply read a file outputting the chars to the tty, it
 * then waits for a <CR> before returning. This allows us to say ..
 * color_xterm -e aview ansi_file
 * The window will remain displaying the file.
 *========================================================================*/

#include <stdio.h>

main (int argc, char *argv[])
{
int	c;
FILE	*fp;

    if (argc != 2) {
	fprintf (stderr, "Usage: %s ansi_file\n", argv[0]);
	exit (1);
	}

    if ((fp = fopen (argv[1], "r")) == NULL) {
	perror (argv[1]);
	exit (1);
	}

    while ((c = getc (fp)) != -1)
	putchar (c);

    fclose (fp);
    getchar ();
}
