/*========================================================================*
 * TITLE:	Qwik Mail Reader for Unix/Linux
 * MODULE:	mkhelp.c -- Create compilable help message
 * BY:		Ross C LINDER	(c) 1994 All rights reserved
 *
 * X11-QMR is Copyright (c) 1994 of Ross C Linder. X11-QMR is not public
 * domain. Permission is granted to use and distribute X11-QMR freely.
 * 
 * The only restriction is that you may not distibute modified source
 * code, and that you do not attempt to prevent others from having free
 * access to the source.
 *========================================================================*/

static char id[]=

"@(#)mkhelp.c	$Revision: 1.1 $	$Date: 1994/07/24 17:49:12 $";

#include <stdio.h>

/*========================================================================*
 * MAIN -- Ahh the K&R way
 *========================================================================*/

main ()
{
FILE	*fps, *fpo;
int	a, c;

    if ((fpo = fopen ("help.c", "w")) == NULL) {
	perror ("help.c");
	exit (1);
	}

    if ((fps = fopen ("help.dat", "r")) == NULL) {
	perror ("help.dat");
	exit (1);
	}

    fprintf (fpo, "/*==================================="
		  "=====================================*\n");
    fprintf (fpo, " * TITLE:\tX11-QMR\n");
    fprintf (fpo, " * MODULE:\thelp.c  (generated from help.dat by mkhelp)\n");
    fprintf (fpo, " * BY:\tRoss C LINDER\t(c) 1994 All rights reserved\n");
    fprintf (fpo, " *\n");
    fprintf (fpo, " * X11-QMR is Copyright (c) 1994 of Ross C Linder. X11-QMR is not public\n");
    fprintf (fpo, " * domain. Permission is granted to use and distribute X11-QMR freely.\n");
    fprintf (fpo, " * \n");
    fprintf (fpo, " * The only restriction is that you may not distibute modified source\n");
    fprintf (fpo, " * code, and that you do not attempt to prevent others from having free\n");
    fprintf (fpo, " * access to the source.\n");
    fprintf (fpo, "/*==================================="
		  "=====================================*/\n");

    fprintf (fpo, "\nstatic char id[]=\n\n");
    fprintf (fpo, "\"@(#)help.c\t$Revision: 1.1 $\t$Date: 1994/07/24 17:49:12 $\";\n");

    fprintf (fpo, "\nchar\thelp_str[]= {");

    a = 0;
    for (;;) {
	if (a == 0) {
	    fputc ('\n', fpo);
	    fputc ('\t', fpo);
	    }

	c = fgetc (fps);
	if (c == -1)
	    break;

	fprintf (fpo, " 0x%02X,", c);
	if (++a == 8)
	   a = 0;
	}

    fprintf (fpo, " 0};\n");

    fclose (fpo);
    fclose (fps);

    exit (0);
}

/*========================================================================*
 * $Log: mkhelp.c,v $
 * Revision 1.1  1994/07/24  17:49:12  ross
 * Initial revision
 *
 *========================================================================*/
