/*****************************************************************************
 *
 * gosh.h
 *
 ****************************************************************************/

#define EXIT_FAILURE -1


#define EMPTY -1
#define WHITE 0
#define BLACK 1
#define LIB 2

#define KILL -3
#define PASS -2
#define NOMOVE -1

#ifndef TRUE
#define TRUE 1
#endif

#define FALSE 0

#define MAXX 50
#define MAXY 50

struct MOVETREE {
  int x, y;       /* the x and y coordinates of the stone. */
  int color;      /* the color of the stone.               */
  char *comment;  /* a comment attached to the node.       */
  struct MOVETREE *next; /* next move tree.                       */
  struct MOVETREE *kill; /* list of killed stones.                */
};

typedef struct MOVETREE MoveTree;

struct BOARD {
  int sizex, sizey;
  MoveTree *movetree;
  int handicap;
  int grid[MAXX][MAXY];
};

typedef struct BOARD Board;

#define FORI(n,stmts) { int I; for(I=0; I<n; I++) { stmts } }

/******************************************************************************/

#ifdef TIMEFLAG
  long clock();
#define TIMESTART { long ts_timer; ts_timer = clock()
#define TIMEEND(str) printf("%s: TIME(%s)=%10.4f\n",MODULE,(str), (float)(clock(
) - ts_timer) / 1000.0); }
#else
#define TIMESTART ;
#define TIMEEND(str) ;
#endif

#define IN 1
#define OUT 0

#ifdef DEBUGFLAG
#define DEBUG(str,type) if(type==IN) printf("%s: %s IN\n",MODULE,str); else if (type==OUT) printf("%s: %s OUT\n",MODULE,str); else printf("%s: %s\n", MODULE, str); fflush(stdout);
#else
#define DEBUG(str,type) ;
#endif

/* return the maximum of two numbers. */
#ifndef MAX
#define MAX(x,y) (((x)>(y)) ? (x) : (y))
#endif

/* return the minimum of two numbers. */
#ifndef MIN
#define MIN(x,y) (((x)<(y)) ? (x) : (y))
#endif

MoveTree *InitMoveTree();
int DestroyMoveTree();
MoveTree *EndOfList();
MoveTree *NextNode();
MoveTree *PrevNode();
int InsertNode();
int AddNodeAtEnd();
MoveTree *AddNewNode();
int PrintList();
MoveTree *LoadMoves();


/******************************************************************************/



