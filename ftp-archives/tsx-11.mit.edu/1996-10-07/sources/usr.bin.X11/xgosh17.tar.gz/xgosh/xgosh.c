/*****************************************************************************
 *
 * xgosh 
 * (x) (go) by (s)cott (h)assan
 *
 * Sept. 11, 1990
 *
 * Version 1.7 Apr 10, 1991
 *
 *      Modified by Eric Osman (osman@hannah.enet.dec.com)
 *              Use X toolkit instead of "select" so it works on both
 *              vms as well as u*ix.
 *
 * Version 1.6 March 12, 1991
 * Version 1.5.2 March 8, 1991
 * Version 1.5 February 28, 1991
 * Version 1.2 January 5, 1991
 *
 * hassan@acsu.buffalo.edu
 * hassan@informatics.wustl.edu
 *
 * DESCRIPTION:
 *
 * xgosh is a quick and easy game of Go.  It allows two people to play a
 * game of Go easily over the Network.  It uses the X Windows' feature of
 * opening two displays (One for each player.)
 *
 * NOTE: Only one xgosh program runs per game.  It serves both displays at
 * the same time.  This is unlike the older netgo programs when both players
 * had to have a copy of the program and meet at a port.  X Windows handles
 * all of this busywork.
 *
 ****************************************************************************/

#define MODULE "xgosh"
/*#define DEBUGFLAG*/

#define VERSION "1.7"

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/X.h>
#include <X11/Xatom.h>
#include <X11/Intrinsic.h>

#include <sys/time.h>
#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

#include <math.h>
/*****************************************************************************/

#include "whitestone.bm"
#include "blackstone.bm"
#include "whitestonemask.bm"
#include "blackstonemask.bm"
#include "gray.bm"
#include "xgosh.bm"
#include "xgosh_title.bm"

#include "gosh.h"

XtAppContext app_context;
int global_argc;
char **global_argv;

/*****************************************************************************/

#define InfoHeight 30
#define InfoWidth 30
#define InfoBuffer 30

#define MESS_OFF_X 30
#define MESS_OFF_Y InfoHeight + 10

#define TITLE_BORDER 10
#define TITLE_BUFFER 100

#define BlackTimerPos 6*InfoWidth
#define WhiteTimerPos 8*InfoWidth

#if 0   /* commented out merely because these don't seem to be found on vms */
#define CoolFont "8x13"
#define BoldCoolFont "8x13bold"
#endif
#define CoolFont "fixed"
#define BoldCoolFont "fixed"


#define TITLEWINDOW 5
#define INFOWINDOW 4
#define BOARDWINDOW 2
#define MAINWINDOW 1 
#define ROOTWINDOW 0

#define TITLEMODE 0
#define PLAYMODE 1
#define HANDICAPMODE 2
#define KILLMODE 3
#define ENDMODE 4

/*****************************************************************************/

struct PLAYER {
  Display *display;
  Window window[10];
  GC gc[10];
  XSizeHints hint[10];
  int screen;
  XFontStruct *font_struct;
  XFontStruct *bold_font_struct;
  unsigned long foreground, background, boardcolor;
  Pixmap MouseStone, MouseStoneMask, IconPixmap, GreyPixmap, TitlePixmap;
  Cursor StoneCursor;
  int dx,dy,ox,oy;
  int color;
  int Mode;
};

/*****************************************************************************/

/*****************************************************************************
 * DrawStone(display, window, gc, foreground, bg, x, y, dx, dy, type)
 *  - Draws a stone of color type at x,y of size dx,dy in window of display
 *    and of foreground and bg.
 ****************************************************************************/

DrawStone(display, window, gc, fg, bg, x, y, dx, dy, type)
     Display *display;
     Window window;
     GC gc;
     unsigned long fg, bg;
     int x, y, dx,dy;
     int type;
{
  if(type==WHITE) {
    XSetForeground(display, gc, bg);
    XFillArc(display, window, gc, x-dx/2, y-dy/2, dx, dy, 0, 360*64);
    XSetForeground(display, gc, fg);
    XDrawArc(display, window, gc, x-dx/2, y-dy/2, dx, dy, 0, 360*64);
    /* Draw the glint */
    XDrawArc(display, window, gc, x-((dx*2)/6), y-((dy*2)/6), (dx*2)/3, (dy*2)/3, -15*64, -60*64);
  } else if(type==BLACK) {
    XSetForeground(display, gc, fg);
    XFillArc(display, window, gc, x-dx/2, y-dy/2 , dx, dy, 0, 360*64);
    XDrawArc(display, window, gc, x-dx/2, y-dy/2 , dx, dy, 0, 360*64);
    XSetForeground(display, gc, bg);
    /* Draw the glint */
    XDrawArc(display, window, gc, x-((dx*2)/6), y-((dy*2)/6), (dx*2)/3, (dy*2)/3, -15*64, -60*64);
  } 
/*else if(type==EMPTY) {
    XSetForeground(display, gc, bg);
    XFillArc(display, window, gc, x-dx/2, y-dy/2, dx, dy, 0, 360*64);
    XDrawArc(display, window, gc, x-dx/2, y-dy/2, dx, dy, 0, 360*64);
    XSetForeground(display, gc, fg);
    XDrawLine(display, window, gc, x, y-dy/2, x, y+dy/2);
    XDrawLine(display, window, gc, x-dx/2, y, x+dx/2, y);
  }*/
}

/*****************************************************************************
 * DrawCross(display, window, gc, fg, bg, x, y, dx, dy, type)
 *  - Draws a cross to mark the last move at x,y. 
 ****************************************************************************/

DrawCross(display, window, gc, fg, bg, x, y, dx, dy, type)
     Display *display;
     Window window;
     GC gc;
     unsigned long fg, bg;
     int x, y, dx,dy;
     int type;
{
  int ddx, ddy;
  ddx = dx / 6;
  ddy = dy / 6;

  if(type==BLACK)
    XSetForeground(display, gc, bg);
  else
    XSetForeground(display, gc, fg);

  XDrawLine(display, window, gc, x - ddx, y - ddy, x + ddx, y + ddy);
  XDrawLine(display, window, gc, x - ddx, y + ddy, x + ddx, y - ddy);
}

/*****************************************************************************
 * DrawPoint(display, window, gc, fg, bg, x, y, dx, dy)
 *  - Draws a small point at x,y.
 ****************************************************************************/

DrawPoint(display, window, gc, x, y, dx, dy)
     Display *display;
     Window window;
     GC gc;
     int x, y, dx,dy;
{
  XFillArc(display, window, gc, x-dx/8, y-dy/8, dx/4, dy/4, 0, 360*64);
  XDrawArc(display, window, gc, x-dx/8, y-dy/8, dx/4, dy/4, 0, 360*64);
}

/*****************************************************************************/

int GridToScrn(x, sx, dx)
     int x, sx, dx;
{
  return(sx + dx * x);
}

int ScrnToGrid(x, sx, dx)
     int x, sx, dx;
{
  return((x - sx) / dx);
}

/*****************************************************************************
 * FigureMouseClick(mx, my, sizex, sizey, dx, dy, sx, sy, x, y)
 *  - returns in x,y the coordinates on the game board of the
 *    mx,my position.
 *    returns TRUE if successful.
 *    returns FALSE otherwise.
 ****************************************************************************/

int FigureMouseClick(board, mx, my, dx, dy, sx, sy, x, y)
     Board *board;
     int mx, my;
     int dx, dy, sx, sy;
     int *x,*y;
{
  *x = ScrnToGrid(mx+dx/2, sx, dx);
  *y = ScrnToGrid(my+dy/2, sy, dy);

  return(IsInBoard(board, *x, *y));
}

DrawStoneOnBoard(display, window, gc, fg, bg, x, y, dx, dy, sx, sy, type)
     Display *display;
     Window window;
     GC gc;
     unsigned long fg, bg;
     int x, y, dx,dy;
     int sx,sy;
     int type;
{
  DrawStone(display, window, gc, fg, bg, GridToScrn(x, sx, dx), GridToScrn(y, sy, dy), dx, dy, type);
}

DrawAllPieces(display, window, gc, fg, bg, board, dx, dy, sx, sy)
     Display *display;
     Window window;
     GC gc;
     unsigned long fg, bg;
     Board *board;
     int dx,dy,sx,sy;
{
  int i,j;
  DEBUG("DrawAllPieces", IN);
  for(i=0; i<board->sizex; i++)
    for(j=0; j<board->sizey; j++)
      DrawStoneOnBoard(display, window, gc, fg, bg, i, j, dx, dy, sx, sy, GetStone(board, i, j));
  DEBUG("DrawAllPieces", OUT);
}     

/*****************************************************************************/

GetMeasures(board, width, height, dx, dy, ox, oy)
     Board *board;
     int width, height;
     int *dx, *dy;
     int *ox, *oy;
{
  int awidth, aheight;

  *dx = width / board->sizex;
  *dy = height / board->sizey;
  
  awidth = *dx * board->sizex;
  aheight = *dy * board->sizey;

  *ox = (width - awidth + *dx) / 2;
  *oy = (height - aheight + *dy) / 2;
}

/*****************************************************************************/

DrawBoard(display, window, gc, fg, bg, board, dx, dy, ox, oy)
     Display *display;
     Window window;
     GC gc;
     unsigned long fg, bg;
     Board *board;
     int dx, dy, ox, oy;
{
  int i,j;
  XSegment segments[MAXY+MAXX];

  DEBUG("DrawBoard", IN);

  if(board->sizey==1) {
    for(i=0; i<board->sizex; i++) {
      segments[i].x1 = ox + i * dx;
      segments[i].y1 = oy - dy/2;
      segments[i].x2 = ox + i * dx;
      segments[i].y2 = oy + (board->sizey-1) * dy + dy/2;
    }
    XDrawSegments(display, window, gc, segments, board->sizex);
  } else {
    for(i=0; i<board->sizey; i++) {
      segments[i].x1 = ox;
      segments[i].y1 = oy + i * dy;
      segments[i].x2 = ox + (board->sizex - 1) * dx;
      segments[i].y2 = oy + i * dy;
    }
    XDrawSegments(display, window, gc, segments, board->sizey);
  }

  if(board->sizex==1) {
    for(i=0; i<board->sizey; i++) {
      segments[i].x1 = ox - dx/2;
      segments[i].y1 = oy + i * dy;
      segments[i].x2 = ox + (board->sizex - 1) * dx + dx/2;
      segments[i].y2 = oy + i * dy;
    }
    XDrawSegments(display, window, gc, segments, board->sizey);
  } else {
    for(i=0; i<board->sizex; i++) {
      segments[i].x1 = ox + i * dx;
      segments[i].y1 = oy;
      segments[i].x2 = ox + i * dx;
      segments[i].y2 = oy + (board->sizey - 1) * dy;
    }
    XDrawSegments(display, window, gc, segments, board->sizex);
  }


  XDrawRectangle(display, window, gc, ox-2, oy-2, dx*(board->sizex-1)+4, dy*(board->sizey-1)+4);

  if(board->sizex == 19 && board->sizey == 19) {
    for(i=3; i<=15; i+=6)
      for(j=3; j<=15; j+=6)
        DrawPoint(display, window, gc, GridToScrn(i, ox, dx), GridToScrn(j, oy, dy), dx, dy);
  }

  DEBUG("DrawBoard", OUT);
}

DrawTimer(display, window, gc, fg, bg, x, y, dx, dy)
     Display *display;
     Window window;
     GC gc;
     unsigned long fg, bg;
     int x,y;
     int dx,dy;
{
  XSetForeground(display, gc, bg);
  XFillArc(display, window, gc, x-dx/2, y-dy/2, dx, dy, 0, 360*64);
  XSetForeground(display, gc, fg);
  XDrawArc(display, window, gc, x-dx/2, y-dy/2, dx, dy, 0, 360*64);
  
}

UpdateTimer(display, window, gc, x, y, dx, dy, time)
     Display *display;
     Window window;
     GC gc;
     int x,y;
     int dx,dy;
     time_t time;
{
  int min, sec;
  double angle;
  int x2,y2;
  min = time / 60;
  sec = time - (min * 60);

  angle = min / 60.0 * 2.0 * 3.14159 - 3.14159/2.0;
  x2 = 0.50 * (dx/2.0) * cos(angle);
  y2 = 0.50 * (dy/2.0) * sin(angle);
  XDrawLine(display, window, gc, x, y, x+x2, y+y2);

  angle = sec / 60.0 * 2.0 * 3.14159 - 3.14159/2.0;
  x2 = 0.80 * (dx/2.0) * cos(angle);
  y2 = 0.80 * (dy/2.0) * sin(angle);
  XDrawLine(display, window, gc, x, y, x+x2, y+y2);
}

DrawTurnMarkers(display, window, gc, fg, bg, dx, dy, turn)
     Display *display;
     Window window;
     GC gc;
     unsigned long fg, bg;
     int dx,dy;
     int turn;
{
  DrawStone(display, window, gc, fg, bg, dx+dx/2, 2+dy/2, dx, dy, WHITE);
  DrawStone(display, window, gc, fg, bg, 3*dx+dx/2, 2+dy/2, dx, dy, BLACK);
  if(turn == WHITE) {
    XSetForeground(display, gc, bg);
    XDrawRectangle(display, window, gc, dx*3-1, 1, dx+2, dy+2);
    XSetForeground(display, gc, fg);
    XDrawRectangle(display, window, gc, dx-1, 1, dx+2, dy+2);
  } else if(turn==BLACK) {
    XSetForeground(display, gc, bg);
    XDrawRectangle(display, window, gc, dx-1, 1, dx+2, dy+2);
    XSetForeground(display, gc, fg);
    XDrawRectangle(display, window, gc, dx*3-1, 1, dx+2, dy+2);
  }
}

XCenterString(display, window, gc, width, height, string, font_struct)
     Display *display;
     Window window;
     GC gc;
     int width, height;
     char *string;
     XFontStruct *font_struct;
{
  XCharStruct overall;
  int ascent, descent, dir;
  int a_width;
  int x,y;

  a_width = XTextWidth(font_struct, string, strlen(string));
  XTextExtents(font_struct, string, strlen(string), &dir, &ascent, &descent, &overall);
  x = (width - a_width) / 2;
  y = (height + ascent) / 2 ;
  
  XDrawImageString(display, window, gc, x, y, string, strlen(string));
}

XGetHeightWindow(display, window, width, height)
     Display *display;
     Window window;
     unsigned int *width, *height;
{
  Window root;
  int x,y;
  int bw, depth;

  return(XGetGeometry (display, window, &root, &x, &y, width, height, &bw, &depth));
}

DrawInfoText(display, window, gc, x, y, string, font_struct)
     Display *display;
     Window window;
     GC gc;
     int x,y;
     char *string;
     XFontStruct *font_struct;
{
  XCharStruct overall;
  int ascent, descent, dir;
  int a_width;
  unsigned width, height;

  a_width = XTextWidth(font_struct, string, strlen(string));
  XTextExtents(font_struct, string, strlen(string), &dir, &ascent, &descent, &overall);

  XGetHeightWindow(display, window, &width, &height);
  XClearArea(display, window, x, y, width, ascent+descent, FALSE);

  y = (y + ascent);

  XDrawImageString(display, window, gc, x, y, string, strlen(string));

  return(ascent+descent);
}



/*****************************************************************************/

/*****************************************************************************
 * LookUpColor(display, name, xcolor, color)
 *  - returns the color name in xcolor and the index of xcolor in color. 
 ****************************************************************************/

int LookUpColor(display, name, xcolor, color)
     Display *display;
     char *name;
     XColor *xcolor;
     unsigned long *color;
{
  XColor colour;
  if(XAllocNamedColor(display, DefaultColormap(display, DefaultScreen(display)), name, 
                      &colour, xcolor) == 0) {
/*    printf("LookUpColor: could not allocate %s.\n", name);*/
    return(FALSE);
  } 
  *color = xcolor->pixel;
  return(TRUE);
}

/*****************************************************************************
 * OpenDisplay(ply, displaystring, geostring)
 *  - Sets up everything in order to start using windows in X. 
 ****************************************************************************/

OpenDisplay(ply, displaystring, geostring, boardcolor, sizex, sizey)
     struct PLAYER *ply;
     char *displaystring;
     char *geostring;
     char *boardcolor;
     int sizex, sizey;
{
  Display *dpy;
  XWMHints WMHints;
  XColor fg, bg, color;
  char title[81];
  
  DEBUG("OpenDisplay", IN);

  /* initialization */
  if(!(ply->display = XtOpenDisplay(app_context, displaystring, "xgosh",
        "xgosh", 0, 0, &global_argc, global_argv))) {
    printf("OpenDisplay: can not open display (%s).\n", displaystring);
    exit(0);
  }
  dpy = ply->display;
  ply->screen = DefaultScreen(dpy);
  ply->window[ROOTWINDOW] = DefaultRootWindow(dpy);

  /* default pixel values */
  if(LookUpColor(dpy, "White", &bg, &(ply->background))==FALSE) 
    ply->background = WhitePixel( dpy, ply->screen);
  if(LookUpColor(dpy, "Black", &fg, &(ply->foreground))==FALSE) 
    ply->foreground = BlackPixel( dpy, ply->screen);

  ply->boardcolor = WhitePixel( dpy, ply->screen);
  if(boardcolor != 0L)
    LookUpColor(dpy, boardcolor, &color, &(ply->boardcolor));
  else
    LookUpColor(dpy, "Tan1", &color, &(ply->boardcolor));

  ply->hint[BOARDWINDOW].x = 200;
  ply->hint[BOARDWINDOW].y = 300;
  ply->hint[BOARDWINDOW].width = (400 / MAX(sizex, sizey)) * sizex;
  ply->hint[BOARDWINDOW].height = (400 / MAX(sizex, sizey)) * sizey;

  ply->hint[INFOWINDOW].x = 200;
  ply->hint[INFOWINDOW].y = 200;
  ply->hint[INFOWINDOW].width = 400;
  ply->hint[INFOWINDOW].height = 70;

  ply->hint[TITLEWINDOW].x = 200;
  ply->hint[TITLEWINDOW].y = 200;
  ply->hint[TITLEWINDOW].width = noname_width + 2*TITLE_BORDER;
  ply->hint[TITLEWINDOW].height = noname_height + 2*TITLE_BORDER + TITLE_BUFFER;

  if(geostring != 0L) 
    XParseGeometry(geostring, &ply->hint[BOARDWINDOW].x, &ply->hint[BOARDWINDOW].y, 
                   (unsigned int *) &ply->hint[BOARDWINDOW].width, 
                   (unsigned int *) &ply->hint[BOARDWINDOW].height);

  ply->hint[BOARDWINDOW].flags = PPosition | PSize | PAspect | PMinSize;
  ply->hint[BOARDWINDOW].min_aspect.x = sizex;
  ply->hint[BOARDWINDOW].min_aspect.y = sizey;
  ply->hint[BOARDWINDOW].max_aspect.x = sizex;
  ply->hint[BOARDWINDOW].max_aspect.y = sizey;
  ply->hint[BOARDWINDOW].min_width = 70;
  ply->hint[BOARDWINDOW].min_height = 70;

  ply->window[BOARDWINDOW] = 
    XCreateSimpleWindow(dpy, ply->window[ROOTWINDOW], ply->hint[BOARDWINDOW].x, 
                        ply->hint[BOARDWINDOW].y,
                        ply->hint[BOARDWINDOW].width,  ply->hint[BOARDWINDOW].height, 0,
                        ply->foreground, ply->background);

  ply->window[INFOWINDOW] = 
    XCreateSimpleWindow(dpy, ply->window[ROOTWINDOW], ply->hint[INFOWINDOW].x, 
                        ply->hint[INFOWINDOW].y,
                        ply->hint[INFOWINDOW].width,  ply->hint[INFOWINDOW].height, 1,
                        ply->foreground, ply->background);

  ply->window[TITLEWINDOW] = 
    XCreateSimpleWindow(dpy, ply->window[ROOTWINDOW], ply->hint[TITLEWINDOW].x, 
                        ply->hint[TITLEWINDOW].y,
                        ply->hint[TITLEWINDOW].width,  ply->hint[TITLEWINDOW].height, 1,
                        ply->foreground, ply->background);

  if(ply->color == WHITE)
    strcpy(title, "xgosh: Player White");
  else
    strcpy(title, "xgosh: Player Black");
    
  XSetStandardProperties(dpy,  ply->window[BOARDWINDOW], title, title, None, 
                         0L,  0, &ply->hint[BOARDWINDOW]);
  XSetStandardProperties(dpy,  ply->window[INFOWINDOW], title, title, None, 
                         0L,  0, &ply->hint[INFOWINDOW]);
  XSetStandardProperties(dpy,  ply->window[TITLEWINDOW], title, title, None, 
                         0L,  0, &ply->hint[TITLEWINDOW]);

  /* Set up the icon bitmap */

  ply->IconPixmap = XCreateBitmapFromData(dpy, ply->window[BOARDWINDOW], xgosh_bits, 
                                          xgosh_width, xgosh_height);
  
  /* tell the Window Manager about the icon */
  WMHints.icon_pixmap = ply->IconPixmap;
  WMHints.initial_state = NormalState;
  WMHints.input = True;                            /* thanks to Ken Blake */
  WMHints.flags = IconPixmapHint | StateHint | InputHint;
  
  XSetWMHints(dpy, ply->window[TITLEWINDOW], &WMHints);
  XSetWMHints(dpy, ply->window[INFOWINDOW], &WMHints);
  XSetWMHints(dpy, ply->window[BOARDWINDOW], &WMHints);

  /* input event selection */
  XSelectInput( dpy,  ply->window[TITLEWINDOW], StructureNotifyMask | KeyPressMask | 
               ButtonPressMask | ExposureMask );
  XSelectInput( dpy,  ply->window[BOARDWINDOW], StructureNotifyMask | KeyPressMask | 
               ButtonPressMask | ExposureMask );
  XSelectInput( dpy,  ply->window[INFOWINDOW], StructureNotifyMask |
               ButtonPressMask | ExposureMask);

  /* windowmn mapping */
  XMapWindow(dpy, ply->window[TITLEWINDOW]);

  ply->gc[BOARDWINDOW] = XCreateGC(dpy, ply->window[BOARDWINDOW],0,0);
  XSetBackground(dpy, ply->gc[BOARDWINDOW], ply->background);
  XSetForeground(dpy, ply->gc[BOARDWINDOW], ply->foreground);

  ply->gc[TITLEWINDOW] = XCreateGC(dpy, ply->window[TITLEWINDOW],0,0);
  XSetBackground(dpy, ply->gc[TITLEWINDOW], ply->background);
  XSetForeground(dpy, ply->gc[TITLEWINDOW], ply->foreground);
  ply->TitlePixmap = XCreateBitmapFromData(dpy, ply->window[TITLEWINDOW], noname_bits, 
                                                 noname_width, noname_height);
  ply->gc[INFOWINDOW] = XCreateGC(dpy, ply->window[INFOWINDOW],0,0);
  XSetBackground(dpy, ply->gc[INFOWINDOW], ply->background);
  XSetForeground(dpy, ply->gc[INFOWINDOW], ply->foreground);

  /* get a nice cool font for display. */
  if((ply->font_struct = XLoadQueryFont(ply->display, CoolFont)) != NULL) {
    XSetFont(ply->display, ply->gc[INFOWINDOW], ply->font_struct->fid);
    XSetFont(ply->display, ply->gc[TITLEWINDOW], ply->font_struct->fid);
  }
  else
        {
        printf ("Xgosh failed to XLoadQueryFont \"%s\"\n", CoolFont);
        exit (EXIT_FAILURE);
        }
  if
  ((ply->bold_font_struct = XLoadQueryFont(ply->display, BoldCoolFont)) != NULL)
        {}
  else
        {
        printf ("Xgosh failed to XLoadQueryFont \"%s\"\n", BoldCoolFont);
        exit (EXIT_FAILURE);
        }
  ply->gc[3] = XCreateGC(dpy, ply->window[BOARDWINDOW],0,0);
  XSetBackground(dpy, ply->gc[3], ply->background);
  XSetForeground(dpy, ply->gc[3], ply->foreground);
  ply->GreyPixmap = XCreateBitmapFromData(dpy, ply->window[BOARDWINDOW], gray_bits, 
                                          gray_width, gray_height);
  XSetStipple(dpy, ply->gc[3], ply->GreyPixmap);
  XSetFillStyle(dpy, ply->gc[3], FillOpaqueStippled);

  if(ply->color == WHITE) {
    ply->MouseStone = 
      XCreatePixmapFromBitmapData(dpy, ply->window[BOARDWINDOW], whitestone_bits, 
                                  whitestone_width, whitestone_height, ply->foreground, 
                                  ply->background, 1);
    ply->MouseStoneMask =  
      XCreatePixmapFromBitmapData(dpy, ply->window[BOARDWINDOW], whitestonemask_bits,
                                  whitestonemask_width, whitestonemask_height, 
                                  ply->foreground, ply->background, 1);
    ply->StoneCursor = 
      XCreatePixmapCursor(dpy, ply->MouseStone, ply->MouseStoneMask, &fg, &bg, 
                          whitestone_x_hot, whitestone_y_hot);
  } else {
    ply->MouseStone = 
      XCreatePixmapFromBitmapData(dpy, ply->window[BOARDWINDOW], blackstone_bits, 
                                  blackstone_width, blackstone_height, ply->foreground, 
                                  ply->background, 1);
    ply->MouseStoneMask =  
      XCreatePixmapFromBitmapData(dpy, ply->window[BOARDWINDOW], blackstonemask_bits, 
                                  blackstonemask_width, blackstonemask_height, 
                                  ply->foreground, ply->background, 1);
    ply->StoneCursor = 
      XCreatePixmapCursor(dpy, ply->MouseStone, ply->MouseStoneMask, &fg, &bg, 
                          blackstone_x_hot, blackstone_y_hot);
  }
  XDefineCursor(dpy, ply->window[TITLEWINDOW], ply->StoneCursor);
  XDefineCursor(dpy, ply->window[INFOWINDOW], ply->StoneCursor);
  XDefineCursor(dpy, ply->window[BOARDWINDOW], ply->StoneCursor);

  DEBUG("OpenDisplay", OUT);
}

/*****************************************************************************/

usage(s)
     char *s;
{
  printf("usage:  %s [-options ...]\n\n", s); 
  printf("where options include:\n");
  printf("        -whitedisplay dpy         X server on which to display white player.\n");
  printf("        -blackdisplay dpy         X server on which to display black player.\n");
  printf("        -whitegeometry WxH+X+Y    size and location of white player's window.\n");
  printf("        -blackgeometry WxH+X+Y    size and location of black player's window.\n");
  printf("        -handicap number          number of black handicap stones. [0]\n");
  printf("        -loadfile filename        filename to load in.\n");
  printf("        -savefile filename        filename to save under.\n");
  printf("        -blacktime time           Black's playing timer (in seconds.)\n");
  printf("        -whitetime time           White's playing timer (in seconds.)\n");
  printf("        -graystipple              A gray board color. \n");
  printf("        -boardcolor color         The color of the board. [tan1]. \n");
  printf("        -beep                     Sound a beep after opponent's move. \n");
  printf("        -singledisplay            use only one display. \n");
  printf("        -size x y                 Size of the game board. [19 19] MAX[%d %d]\n",MAXX, MAXY);
  printf("        -usage                    this description.\n\n");
}

int WhichPlayer(display, Players, n)
     Display *display;
     struct PLAYER Players[];
     int n;
{
  int i;
  for(i=0; i<n; i++)
    if(Players[i].display == display)
      return(i);
    
  return(-1);
}


FullRedraw(Player, ndisplays, type)
     struct PLAYER Player[];
     int type; /* type of redraw */
{
  XExposeEvent xexpose;

  xexpose.type = Expose;
  xexpose.x = xexpose.y = xexpose.width = xexpose.height = 0;
  xexpose.count = 0;
  FORI(ndisplays, xexpose.display = Player[I].display;
       if(type == MAINWINDOW || type == BOARDWINDOW) {
         xexpose.window = Player[I].window[BOARDWINDOW];
         XSendEvent(Player[I].display, Player[I].window[BOARDWINDOW], FALSE, 
                    ExposureMask, (XEvent *)&xexpose);
       }
       if(type == MAINWINDOW || type == INFOWINDOW) {
         xexpose.window = Player[I].window[INFOWINDOW];
         XSendEvent(Player[I].display, Player[I].window[INFOWINDOW], FALSE, 
                    ExposureMask, (XEvent *)&xexpose); 
       }
       );
}

  int Turn;
  time_t starttimer,endtimer;
  time_t timers[2];
  int ndisplays; /* the number of working displays to display to. */
  int lastmovecolor;
  MoveTree *lastmove;
  struct PLAYER Player[2];
  int Mode; /* mode of operation. */

/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/

timeout_handler ()
{
      if(Mode == PLAYMODE) {
        if(lastmove != NULL) {
          FORI(ndisplays, DrawCross(Player[I].display, Player[I].window[BOARDWINDOW], 
                                    Player[I].gc[2], 
                                    Player[I].foreground, Player[I].background, 
                                    GridToScrn(lastmove->x, Player[I].ox, Player[I].dx),
                                    GridToScrn(lastmove->y, Player[I].oy, Player[I].dy),
                                    Player[I].dx, Player[I].dy, lastmovecolor); );
          lastmovecolor = other(lastmovecolor);
        }

        time(&endtimer);
        if((endtimer - starttimer) > 0) {
          FORI(ndisplays, 
               XSetForeground(Player[I].display, Player[I].gc[INFOWINDOW], Player[I].background);
               if(Turn == WHITE)
               UpdateTimer(Player[I].display, Player[I].window[INFOWINDOW], Player[I].gc[INFOWINDOW],
                           BlackTimerPos, InfoHeight/2, InfoWidth, InfoHeight, timers[WHITE]);
               else
               UpdateTimer(Player[I].display, Player[I].window[INFOWINDOW], Player[I].gc[INFOWINDOW],
                           WhiteTimerPos, InfoHeight/2, InfoWidth, InfoHeight, timers[BLACK]);
               );
          timers[Turn] -= endtimer - starttimer;
          time(&starttimer);
          FORI(ndisplays, 
               XSetForeground(Player[I].display, Player[I].gc[INFOWINDOW], Player[I].foreground);
               if(Turn == WHITE)
               UpdateTimer(Player[I].display, Player[I].window[INFOWINDOW], Player[I].gc[INFOWINDOW],
                           BlackTimerPos, InfoHeight/2, InfoWidth, InfoHeight, timers[WHITE]);
               else
               UpdateTimer(Player[I].display, Player[I].window[INFOWINDOW], Player[I].gc[INFOWINDOW],
                           WhiteTimerPos, InfoHeight/2, InfoWidth, InfoHeight, timers[BLACK]);
               );
        }
      }
    XtAppAddTimeOut (app_context, 300, timeout_handler, 0);
}

main(argc, argv)
     int argc;
     char **argv;
{
  int i;
  char *whitegeometry, *blackgeometry;
  char *whitedisplay, *blackdisplay;
  char *boardcolor;
  Board board;
  int handicap;
  int ply;
  int x,y, offset;
  int greystipple;
  char text[255];
  KeySym key;
  int cbs, cws;

  XEvent event;
  XtInputMask whats_ready;
/*
  fd_set mask, readfds, wrfds, exfds;
  struct timeval timeout;
*/
  int nfds;
  int nfound;
  int done;
  int dpc; /* connection file pointer. */
  int beep;
  char savefile[81];
  char loadfile[81];
  int whitepoints, blackpoints, undet;

  XExposeEvent xexpose;
  DEBUG("main", IN);

  global_argc = argc;
  global_argv = argv;

  XtToolkitInitialize();
  app_context = XtCreateApplicationContext();

  timers[WHITE] = 1800;
  timers[BLACK] = 1800;
  greystipple = FALSE;
  beep = FALSE;
  whitedisplay = 0L;
  blackdisplay = 0L;
  whitegeometry = 0L;
  blackgeometry = 0L;
  handicap = 0;
  lastmove = NULL;
  ndisplays = 2;
  strcpy(loadfile,"");
  strcpy(savefile,"");

  board.sizex = 19;
  board.sizey = 19;
  boardcolor = 0L;

  x=1;
  while(x<argc) {
    if(!strcmp(argv[x], "-whitedisplay")) {
      whitedisplay = argv[x+1];
      x+=2;
    } else if(!strcmp(argv[x], "-blackdisplay")) {
      blackdisplay = argv[x+1];
      x+=2;
    } else if(!strcmp(argv[x], "-whitegeometry")) {
      whitegeometry = argv[x+1];
      x+=2;
    } else if(!strcmp(argv[x], "-blacktime")) {
      sscanf(argv[x+1], "%ld", &timers[BLACK]);
      x+=2;
    } else if(!strcmp(argv[x], "-whitetime")) {
      sscanf(argv[x+1], "%ld", &timers[WHITE]);
      x+=2;
    } else if(!strcmp(argv[x], "-blackgeometry")) {
      blackgeometry = argv[x+1];
      x+=2;
    } else if(!strcmp(argv[x], "-boardcolor")) {
      boardcolor = argv[x+1];
      x+=2;
    } else if(!strcmp(argv[x], "-handicap")) {
      sscanf(argv[x+1], "%d", &handicap);
      x+=2;
    } else if(!strcmp(argv[x], "-size")) {
      sscanf(argv[x+1], "%d", &(board.sizex));
      sscanf(argv[x+2], "%d", &(board.sizey));
      if(board.sizex > MAXX || board.sizey > MAXY || (board.sizex <= 1 && board.sizey <= 1)) {
        printf("%s: illegal size of board\n", argv[0]);
        exit(1);
      }
      x+=3;
    } else if(!strcmp(argv[x], "-loadfile")) {
      strcpy(loadfile, argv[x+1]);
      x+=2;
    } else if(!strcmp(argv[x], "-savefile")) {
      strcpy(savefile, argv[x+1]);
      x+=2;
    } else if(!strcmp(argv[x], "-usage")) {
      usage(argv[0]);
      x++;
      exit(0);
    } else if(!strcmp(argv[x], "-graystipple")) {
      greystipple = TRUE;
      x++;
    } else if(!strcmp(argv[x], "-singledisplay")) {
      ndisplays = 1;
      x++;
    } else if(!strcmp(argv[x], "-beep")) {
      beep = TRUE;
      x++;
    } else {
      printf("%s: Error in arguments!\n", argv[0]);
      usage(argv[0]);
      exit(0);
    }
  }

  board.handicap = handicap;
  InitPlayBoard(&board);

  board.movetree = InitMoveTree();

  if(board.handicap>0)
    Turn = WHITE;
  else
    Turn = BLACK;

  if(strcmp(loadfile,"")) {
    lastmove = LoadMoves(&board, loadfile);
    Turn = other(board.movetree->next->color);
  } else
    strcpy(loadfile,"go.save");

  if(strcmp(savefile,"")==0)
    strcpy(savefile,"go.save");

  Player[WHITE].color = WHITE;
  Player[BLACK].color = BLACK;

  if(whitedisplay==0L) {
    OpenDisplay(&Player[WHITE], "", whitegeometry, boardcolor, board.sizex, board.sizey);
    whitedisplay = XDisplayString(Player[WHITE].display);
  }
  else
    OpenDisplay(&Player[WHITE], whitedisplay, whitegeometry, boardcolor, board.sizex, board.sizey);
    
  if(ndisplays > 1) {
    if(blackdisplay==0L) {
      OpenDisplay(&Player[BLACK], "", blackgeometry, boardcolor, board.sizex, board.sizey);
      blackdisplay = XDisplayString(Player[BLACK].display);
    }
    else
      OpenDisplay(&Player[BLACK], blackdisplay, blackgeometry, boardcolor, board.sizex, board.sizey);
  }

  /*****************************************************************************/

/*
  timeout.tv_sec = 0;
  timeout.tv_usec = 300000;
  FD_ZERO(&mask);

  FORI(ndisplays, dpc = ConnectionNumber(Player[I].display);   
       FD_SET(dpc, &mask);  );
  nfds = getdtablesize();
*/
  time(&starttimer);

  /*****************************************************************************/
  Mode = TITLEMODE;
  Player[WHITE].Mode = TITLEMODE;
  Player[BLACK].Mode = TITLEMODE;

  done = FALSE;

  XtAppAddTimeOut (app_context, 300, timeout_handler, 0);

  while(!done) {

    XtAppNextEvent (app_context, &event);   /* block until event */

    switch(event.type) {
    case Expose:
      DEBUG("Expose", IN);

      ply = WhichPlayer(event.xexpose.display, Player, ndisplays);
      if(event.xexpose.count == 0 && event.xexpose.window == Player[ply].window[TITLEWINDOW]) {
        XCopyPlane(Player[ply].display, Player[ply].TitlePixmap, Player[ply].window[TITLEWINDOW],
                   Player[ply].gc[TITLEWINDOW],
                   0, 0, noname_width, noname_height, TITLE_BORDER, TITLE_BORDER, 1);

        x = TITLE_BORDER;
        y = noname_height + TITLE_BORDER*2;

        sprintf(text, "xgosh version: %s", VERSION); 
        offset = DrawInfoText(Player[ply].display, Player[ply].window[TITLEWINDOW], 
                     Player[ply].gc[TITLEWINDOW], x, y,
                     text, Player[ply].font_struct);
        
        y += offset;
        if(ndisplays>1) {
          if(ply==WHITE) 
            sprintf(text, "Player: White");
          else
            sprintf(text, "Player: Black");
        } else
          sprintf(text, "Player: White and Black");
        DrawInfoText(Player[ply].display, Player[ply].window[TITLEWINDOW], 
                     Player[ply].gc[TITLEWINDOW], x, y,
                     text, Player[ply].font_struct);

        sprintf(text, "handicap: %d", board.handicap);
        DrawInfoText(Player[ply].display, Player[ply].window[TITLEWINDOW], 
                     Player[ply].gc[INFOWINDOW], x, y,
                     text, Player[ply].font_struct);

        y += offset;
        sprintf(text, "board size: %dx%d", board.sizex, board.sizey);
        DrawInfoText(Player[ply].display, Player[ply].window[TITLEWINDOW], 
                     Player[ply].gc[TITLEWINDOW], x, y,
                     text, Player[ply].font_struct);

        if(ndisplays > 1) {
          y += offset;
          sprintf(text, "WhiteDisplay: %s", whitedisplay);
          DrawInfoText(Player[ply].display, Player[ply].window[TITLEWINDOW], 
                       Player[ply].gc[TITLEWINDOW], x, y,
                       text, Player[ply].font_struct);
          y += offset;
          sprintf(text, "BlackDisplay: %s", blackdisplay);
          DrawInfoText(Player[ply].display, Player[ply].window[TITLEWINDOW], 
                       Player[ply].gc[TITLEWINDOW], x, y,
                       text, Player[ply].font_struct);
        } else {
          y += offset;
          sprintf(text, "Display: %s", whitedisplay);
          DrawInfoText(Player[ply].display, Player[ply].window[TITLEWINDOW], 
                       Player[ply].gc[TITLEWINDOW], x, y,
                       text, Player[ply].font_struct);
        }
        y+=offset*2;
        x+=50;
        sprintf(text, "Click on window to begin play...");
        DrawInfoText(Player[ply].display, Player[ply].window[TITLEWINDOW], 
                     Player[ply].gc[TITLEWINDOW], x, y,
                     text, Player[ply].font_struct);

        x = noname_width/2 + TITLE_BORDER*2;
        y = noname_height + TITLE_BORDER*2;

        y += offset;
        sprintf(text, "Whitetime: %d", timers[WHITE]); 
        DrawInfoText(Player[ply].display, Player[ply].window[TITLEWINDOW], 
                     Player[ply].gc[TITLEWINDOW], x, y,
                     text, Player[ply].font_struct);
        y += offset;
        sprintf(text, "Blacktime: %d", timers[BLACK]);
        DrawInfoText(Player[ply].display, Player[ply].window[TITLEWINDOW], 
                     Player[ply].gc[TITLEWINDOW], x, y,
                     text, Player[ply].font_struct);
        

        XFlush(Player[ply].display);
      }
      if(event.xexpose.count == 0 && event.xexpose.window == Player[ply].window[BOARDWINDOW]) {
        XSetForeground(Player[ply].display, Player[ply].gc[2], Player[ply].foreground);
        if(greystipple) {
          XFillRectangle(Player[ply].display, Player[ply].window[BOARDWINDOW], Player[ply].gc[3], 
                         0, 0, Player[ply].hint[BOARDWINDOW].width, 
                         Player[ply].hint[BOARDWINDOW].height);
        } else {
          XSetForeground(Player[ply].display, Player[ply].gc[2], Player[ply].boardcolor);
          XFillRectangle(Player[ply].display, Player[ply].window[BOARDWINDOW], Player[ply].gc[2], 
                         0, 0, Player[ply].hint[BOARDWINDOW].width, 
                         Player[ply].hint[BOARDWINDOW].height);
          XSetForeground(Player[ply].display, Player[ply].gc[2], Player[ply].foreground);
        }
        GetMeasures(&board, Player[ply].hint[BOARDWINDOW].width, 
                    Player[ply].hint[BOARDWINDOW].height, 
                    &(Player[ply].dx), &(Player[ply].dy), &(Player[ply].ox), &(Player[ply].oy));
        
        DrawBoard(Player[ply].display, Player[ply].window[BOARDWINDOW], Player[ply].gc[2], 
                  Player[ply].foreground, Player[ply].background, &board, Player[ply].dx, 
                  Player[ply].dy, Player[ply].ox, Player[ply].oy);      
        
        DrawAllPieces(Player[ply].display, Player[ply].window[BOARDWINDOW], Player[ply].gc[2], 
                      Player[ply].foreground, Player[ply].background, &board, Player[ply].dx, 
                      Player[ply].dy, Player[ply].ox, Player[ply].oy);
        
      }
      if(event.xexpose.count == 0 && event.xexpose.window == Player[ply].window[INFOWINDOW]) {
        CountCapturedStones(&board, &cbs, &cws);
        
        sprintf(text, "Captured Stones: White(%d) Black(%d)", cbs, cws);
        
        DrawTimer(Player[ply].display, Player[ply].window[INFOWINDOW], Player[ply].gc[INFOWINDOW],
                  Player[ply].foreground, Player[ply].background, BlackTimerPos, 
                  InfoHeight/2, InfoWidth, InfoHeight);
        DrawTimer(Player[ply].display, Player[ply].window[INFOWINDOW], Player[ply].gc[INFOWINDOW],
                  Player[ply].foreground, Player[ply].background, WhiteTimerPos, InfoHeight/2, 
                  InfoWidth, InfoHeight);
        
        UpdateTimer(Player[ply].display, Player[ply].window[INFOWINDOW], Player[ply].gc[INFOWINDOW],
                    BlackTimerPos, InfoHeight/2, InfoWidth, InfoHeight, timers[WHITE]);
        UpdateTimer(Player[ply].display, Player[ply].window[INFOWINDOW], Player[ply].gc[INFOWINDOW],
                    WhiteTimerPos, InfoHeight/2, InfoWidth, InfoHeight, timers[BLACK]);

        DrawInfoText(Player[ply].display, Player[ply].window[INFOWINDOW], 
                     Player[ply].gc[INFOWINDOW], MESS_OFF_X, MESS_OFF_Y, 
                     text, Player[ply].font_struct);

        DrawTurnMarkers(Player[ply].display, Player[ply].window[INFOWINDOW], Player[ply].gc[INFOWINDOW],
                        Player[ply].foreground, Player[ply].background, 
                        InfoWidth, InfoHeight, Turn);
        
        XFlush(Player[ply].display);
      }
      DEBUG("Expose", OUT);
      break;
      
    case ConfigureNotify:
      DEBUG("ConfigureNotify", IN);
      ply = WhichPlayer(event.xconfigure.display, Player, ndisplays);
      if(event.xconfigure.window == Player[ply].window[BOARDWINDOW]) {
        Player[ply].hint[BOARDWINDOW].x = event.xconfigure.x;
        Player[ply].hint[BOARDWINDOW].y = event.xconfigure.y;
        Player[ply].hint[BOARDWINDOW].width = event.xconfigure.width;
        Player[ply].hint[BOARDWINDOW].height = event.xconfigure.height;
/*      if(event.xconfigure.width != event.xconfigure.height) {
          Player[ply].hint[BOARDWINDOW].width = MIN(event.xconfigure.width, event.xconfigure.height);
          Player[ply].hint[BOARDWINDOW].height = MIN(event.xconfigure.height, event.xconfigure.width);
          XResizeWindow(Player[ply].display, Player[ply].window[BOARDWINDOW], 
                        Player[ply].hint[BOARDWINDOW].width,
                        Player[ply].hint[BOARDWINDOW].height);
        }*/
      } else if(event.xconfigure.window == Player[ply].window[INFOWINDOW]) {
        Player[ply].hint[INFOWINDOW].x = event.xconfigure.x;
        Player[ply].hint[INFOWINDOW].y = event.xconfigure.y;
        Player[ply].hint[INFOWINDOW].width = event.xconfigure.width;
        Player[ply].hint[INFOWINDOW].height = event.xconfigure.height;
      }
      DEBUG("ConfigureNotify", OUT);
      break;
      
    case MappingNotify:
      XRefreshKeyboardMapping((XMappingEvent *)&event);
      break;
      
    case ButtonPress:
      DEBUG("ButtonPress Event!", IN);
      ply = WhichPlayer(event.xbutton.display, Player, ndisplays);
      if(event.xbutton.window == Player[ply].window[TITLEWINDOW]) {
        if(Player[ply].Mode == TITLEMODE)
          Player[ply].Mode = PLAYMODE;
        if(ndisplays==1 || Player[other(ply)].Mode == PLAYMODE) {
          Mode = PLAYMODE;
          FORI(ndisplays, 
               XUnmapWindow(Player[I].display, Player[I].window[TITLEWINDOW]);
               XMapWindow(Player[I].display, Player[I].window[BOARDWINDOW]);
               XMapWindow(Player[I].display, Player[I].window[INFOWINDOW]); );
          time(&starttimer);
        }
      }
      if(Mode == KILLMODE && event.xbutton.window == Player[ply].window[BOARDWINDOW]) {
        if(event.xbutton.button == Button1) {
          if(Turn == ply || ndisplays == 1) {
            if(FigureMouseClick(&board, event.xbutton.x, event.xbutton.y, Player[ply].dx, 
                                Player[ply].dy, Player[ply].ox, Player[ply].oy, &x, &y) == TRUE) {

              if(GetStone(&board, x, y) != EMPTY) {
                AddNewNode(board.movetree, KILL, KILL, KILL);
                KillStones(&board, x, y, GetStone(&board, x, y));
                FullRedraw(Player, ndisplays,  MAINWINDOW);
              } else
                XBell(Player[ply].display, 20);
            } else
              XBell(Player[ply].display, 20);
          }
        }
      }
      if(Mode == PLAYMODE && event.xbutton.window == Player[ply].window[BOARDWINDOW]) {
        if(event.xbutton.button == Button1) {
          if(Turn == ply || ndisplays == 1) {
            if(FigureMouseClick(&board, event.xbutton.x, event.xbutton.y, Player[ply].dx, 
                                Player[ply].dy, Player[ply].ox, Player[ply].oy, &x, &y) == TRUE) {
              if(GetStone(&board, x, y) == EMPTY) {
                MoveTree *temp;
                AddStone(&board, x, y, Turn);
                temp = AddNewNode(board.movetree, x, y, Turn);
                if(PlaceStoneOnBoard(&board, x, y, Turn) == 0) {
                  XBell(Player[ply].display, 20);
                  AddStone(&board, x, y, EMPTY);
                  DeleteNode(board.movetree);
                } else if(lastmove != NULL && 
                          (Length(temp->kill) == 1) &&
                          (Length(lastmove->kill) == 1) &&
                          lastmove->x == temp->kill->next->x && 
                          lastmove->y == temp->kill->next->y && 
                          lastmove->color == temp->kill->next->color &&
                          lastmove->kill->next->x == temp->x && 
                          lastmove->kill->next->y == temp->y && 
                          lastmove->kill->next->color == temp->color) {
                  UndoLastMove(&board);
                  sprintf(text, "Illegal Move: KO!");
                  
                  DrawInfoText(Player[ply].display, Player[ply].window[INFOWINDOW], 
                               Player[ply].gc[INFOWINDOW], MESS_OFF_X, MESS_OFF_Y, 
                               text, Player[ply].font_struct);
                  
                  XBell(Player[ply].display, 20);
                }
                else {
                  if(lastmove != NULL)
                    FORI(ndisplays, DrawCross(Player[I].display, Player[I].window[BOARDWINDOW], 
                                              Player[I].gc[2], 
                                              Player[I].foreground, Player[I].background, 
                                              GridToScrn(lastmove->x, Player[I].ox, Player[I].dx),
                                              GridToScrn(lastmove->y, Player[I].oy, Player[I].dy),
                                              Player[I].dx, Player[I].dy, other(lastmove->color)); );
                  lastmove = temp; /* keep track of the last move played. */
                  lastmovecolor = lastmove->color;
                  if(!IsEmpty(board.movetree->next->kill)) {
                    FullRedraw(Player, ndisplays,  MAINWINDOW);
                    Turn = other(Turn);
                  } else {
                    FORI(ndisplays, 
                         DrawStoneOnBoard(Player[I].display, Player[I].window[BOARDWINDOW], 
                                          Player[I].gc[2], 
                                          Player[I].foreground, Player[I].background, 
                                          x, y, Player[I].dx, 
                                          Player[I].dy, Player[I].ox, Player[I].oy, Turn);
                         DrawTurnMarkers(Player[I].display, Player[I].window[INFOWINDOW], 
                                         Player[I].gc[INFOWINDOW],
                                         Player[I].foreground, Player[I].background, 
                                         InfoWidth, InfoHeight, other(Turn)); );
                    
                    /* re-draw the information window after a valid move occurs. */
                    
                    FullRedraw(Player, ndisplays,  INFOWINDOW);
                    
                    Turn = other(Turn);
                  }
                  if(beep)
                    XBell(Player[other(ply)].display, 50);
                }
              } else {
                XBell(Player[ply].display, 20);
              }
            } else {
              XBell(Player[ply].display,20);
            }
          } else {
            XBell(Player[ply].display,20);
          }
        }
      }
      DEBUG("ButtonPress Event!", OUT);
      break;
      
    case KeyPress:
      DEBUG("KeyPress", IN);
      i = XLookupString((XKeyEvent *) &event, text, 10, &key, 0);
      
      if(i==1 && Mode == TITLEMODE) {
        switch(text[0]) {
        case 'q': /* Quit game */
          done = TRUE;
          break;
        }
      } else if(i==1 && Mode == KILLMODE) {
        switch(text[0]) {
        case 'k': /* kill mode. */
          if(Mode == KILLMODE){
            Mode = PLAYMODE;
            sprintf(text, "KillMode Cleared.  Playmode.");
            FORI(ndisplays, 
                 XBell(Player[I].display, 20);
                 DrawInfoText(Player[I].display, Player[I].window[INFOWINDOW], 
                              Player[I].gc[INFOWINDOW], 
                              MESS_OFF_X, MESS_OFF_Y,
                              text, Player[I].font_struct); );
          }
        }
      } else if(i==1 && Mode == PLAYMODE) {
        switch(text[0]) {
        case 'u': /* Undo move */
          if(!IsEmpty(board.movetree->next)) {
            
            UndoLastMove(&board);
            lastmove = board.movetree->next;
            Turn = other(Turn);
            FullRedraw(Player, ndisplays,  MAINWINDOW);
            
            if(Turn==BLACK)
              sprintf(text, "Black Player takes back a move.");
            else if(Turn==WHITE)
              sprintf(text, "White Player takes back a move.");
            
            FORI(ndisplays, 
                 DrawInfoText(Player[I].display, Player[I].window[INFOWINDOW], 
                              Player[I].gc[INFOWINDOW], MESS_OFF_X, MESS_OFF_Y, 
                              text, Player[I].font_struct); );
          } else {
            FORI(ndisplays, 
                 XBell(Player[I].display, 20););
          }
          break;
        case 'p': /* pass */
          if(Turn == ply || ndisplays == 1) {
            AddNewNode(board.movetree, PASS, PASS, PASS);
          
            if(Turn==BLACK)
              sprintf(text, "Black Player passed.");
            else if(Turn==WHITE)
              sprintf(text, "White Player passed.");
          
            FORI(ndisplays, 
                 XBell(Player[I].display, 20);
                 DrawInfoText(Player[I].display, Player[I].window[INFOWINDOW], 
                              Player[I].gc[INFOWINDOW], MESS_OFF_X, MESS_OFF_Y, 
                              text, Player[I].font_struct);
                 DrawTurnMarkers(Player[I].display, Player[I].window[INFOWINDOW], Player[I].gc[INFOWINDOW],
                                 Player[I].foreground, Player[I].background, 
                                 InfoWidth, InfoHeight, Turn); );
            Turn = other(Turn);
          }
          break;
        case 'q': /* Quit game */
          done = TRUE;
          break;
        case 's': /* Save file */
          sprintf(text, "Saved game in file %s.", savefile);
          
          FORI(ndisplays, 
               DrawInfoText(Player[I].display, Player[I].window[INFOWINDOW], 
                            Player[I].gc[INFOWINDOW], MESS_OFF_X, MESS_OFF_Y, 
                            text, Player[I].font_struct); );
          
          SaveMoves(&board, savefile);
          break;
         case 'k': /* KillMode Set */
          Mode = KILLMODE;
          sprintf(text, "KillMode Set.");
          FORI(ndisplays, 
               XBell(Player[I].display, 20);
               DrawInfoText(Player[I].display, Player[I].window[INFOWINDOW], 
                            Player[I].gc[INFOWINDOW], 
                            MESS_OFF_X, MESS_OFF_Y,
                            text, Player[I].font_struct); );
          break;

        case 'c': /* Calculate */
          CountCapturedStones(&board, &cbs, &cws);
          CalcuBoard(&board, &whitepoints, &blackpoints, &undet);
          sprintf(text, "Black: %d+%d=%d -- White: %d+%d=%d -- U: %d ", 
                  blackpoints,cws,blackpoints+cws,
                  whitepoints,cbs,whitepoints+cbs+handicap,
                  undet);
          FORI(ndisplays,
               XBell(Player[I].display, 20);
               DrawInfoText(Player[I].display, Player[I].window[INFOWINDOW], 
                            Player[I].gc[INFOWINDOW], 
                            MESS_OFF_X, MESS_OFF_Y,
                            text, Player[I].font_struct); );
          break;
        case 'l': /* Load file */
          DestroyMoveTree(board.movetree);
          lastmove = LoadMoves(&board, loadfile);
          Turn = board.movetree->next->color;
          
          FullRedraw(Player, ndisplays, MAINWINDOW);
          
          Turn = other(Turn);
          break;
        }
      }
      DEBUG("KeyPress", OUT);
      break;
    }   /* end of switch (event.type) */

  }   /* end of while (!done) */

  DEBUG("main", OUT);
}   /* end of main() */

