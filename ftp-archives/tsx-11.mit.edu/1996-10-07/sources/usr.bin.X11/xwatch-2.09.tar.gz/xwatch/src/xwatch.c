/* <<< Start of information >>>                                       */
/* ------------------------------------------------------------------ */
/* This file is part of the xwatch program. Copyright (C) ICCE /      */
/* Karel Kubat 1995. All rights reserved. You are permitted to        */
/* redistribute this package, if you include all unmodified sources   */
/* and all unmodified documentation (including this text). You are    */
/* NOT permitted to distribute files of this package with             */
/* modifications.  See the file COPYING for more information. When in */
/* doubt, mail me at karel@icce.rug.nl.                               */
/* XWatch is maintained by Frank Brokken, frank@icce.rug.nl. If you   */
/* have remarks about bugs or features, please mail Frank.            */
/* ------------------------------------------------------------------ */
/* <<< End of information >>>                                         */

#include "xwatch.h"

/* global data section */
#undef EXTERN
#define EXTERN
#include "data.inc"

/* main function */ 
void main(int argc, char *argv[])
{
    int
	i;
    static int
	border,				/* flag: use border? */ 
	xpos, ypos,			/* startup screen coords */ 
	height,				/* initial height */ 
	printversion;			/* flag: print version/copyright? */
    static char
	*copyrightmsg [] =              /* our copyright msg */
	{
	    "\n",
	    "XWatch V" VER "\n",
	    "\n",
	    "Copyright (c) ICCE / Karel Kubat (karel@icce.rug.nl)\n",
            "Maintained by Frank Brokken (frank@icce.rug.nl)\n"
	    "All rights reserved. Another MegaHard production!\n",
	    "\n",
	},
	titlebuffer [128],              /* window title */
	gagbuffer [1024],               /* things to gag */
	colorstring [1024],             /* messages to color */
        ignorestring [1024],            /* files to be ignored */
	geometry [80],                  /* geometry string */
        fgstring [80], bgstring [80];   /* foreground/background strings */

#include "flres.h"     
#include "settings.h"     

    /* count total cmdline length.. X barfs on too long cmdlines (!) */
#ifdef MAXCMDLINE
    register int
	totlength = 0;
    
    for (i = 0; i < argc; i++)
	totlength += strlen (argv [i]) + 1;
    if (totlength > MAXCMDLINE)
	error ("too many strings on the commandline");
#endif

    /* parse in options */
    fl_initialize (&argc, argv, "XWatch", 
                   cmdopt, sizeof (cmdopt) / sizeof (FL_CMD_OPT));
    fl_get_app_resources (res, sizeof (res) / sizeof (FL_resource));

    /* check the settings */
    for (i = 0; i < sizeof (setting) / sizeof (Setting); i++)
	checksetting (*setting [i].var, setting [i].min,
		      setting [i].max, setting [i].desc);

    /* show usage if no args */
    if (argc < 2)
	usage ();
        
    /* parse gag strings and color strings */
    parsegag (gagbuffer);
    parsecolorstring (colorstring);
    parsegeometry (geometry, &xpos, &ypos, &width, &height);
    parsecolors (fgstring, bgstring);
    argc = parseignore(ignorestring, argc, argv);

    /* now create and initialize the forms */
    create_the_forms ();

    /* fontsize is now 1..4, remap to 8/10/12/14 */
    fontsize <<= 1;
    fontsize += 6;
    fl_set_browser_fontsize (watch_browser, fontsize);
    fl_set_browser_fontstyle (watch_browser, fontstyle);
    fl_set_object_color (watch_browser, backgr, foregr);
    fl_set_object_lcol (watch_browser, foregr);

    /* show browser form */
    fl_set_form_geometry (browser_form, xpos, ypos, width, height);
    fl_set_form_position (browser_form, xpos, ypos);
    fl_show_form (browser_form, FL_PLACE_GEOMETRY,
		      border ? FL_FULLBORDER : FL_NOBORDER,
                      *titlebuffer ? titlebuffer : "XWatch");

    /* add our own message */
    if (printversion)
	for (i = 0; i < sizeof (copyrightmsg) / sizeof (char *); i++)
	    warning (copyrightmsg [i]);

    /* add all files */
    for (i = 1; i < argc; i++)
	addfile (argv [i]);

    /* forms action loop , interrupted each `interval' secs */ 
    signal (SIGALRM, alarmhandler);
    alarm (interval);

    /* here goes..  */ 
    fl_do_forms();

    /* never reached, exit is from `quit' button */ 
}
