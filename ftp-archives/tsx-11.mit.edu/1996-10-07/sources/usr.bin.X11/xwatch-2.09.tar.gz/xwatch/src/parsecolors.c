/* <<< Start of information >>>                                       */
/* ------------------------------------------------------------------ */
/* This file is part of the xwatch program. Copyright (C) ICCE /      */
/* Karel Kubat 1995. All rights reserved. You are permitted to        */
/* redistribute this package, if you include all unmodified sources   */
/* and all unmodified documentation (including this text). You are    */
/* NOT permitted to distribute files of this package with             */
/* modifications.  See the file COPYING for more information. When in */
/* doubt, mail me at karel@icce.rug.nl.                               */
/* XWatch is maintained by Frank Brokken, frank@icce.rug.nl. If you   */
/* have remarks about bugs or features, please mail Frank.            */
/* ------------------------------------------------------------------ */
/* <<< End of information >>>                                         */

#include "xwatch.h"

void parsecolors (char *fgstring, char *bgstring)
{
    int
        r, g, b;
        
    if (fgstring && *fgstring && colorname2rgb (fgstring, &r, &g, &b))
        foregr = getcolorindex (r, g, b);
    else
        foregr = FL_BLACK;
    
    if (bgstring && *bgstring && colorname2rgb (bgstring, &r, &g, &b))
        backgr = getcolorindex (r, g, b);
    else
        backgr = FL_WHITE;
}
