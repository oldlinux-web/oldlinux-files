/* <<< Start of information >>>                                       */
/* ------------------------------------------------------------------ */
/* This file is part of the xwatch program. Copyright (C) ICCE /      */
/* Karel Kubat 1995. All rights reserved. You are permitted to        */
/* redistribute this package, if you include all unmodified sources   */
/* and all unmodified documentation (including this text). You are    */
/* NOT permitted to distribute files of this package with             */
/* modifications.  See the file COPYING for more information. When in */
/* doubt, mail me at karel@icce.rug.nl.                               */
/* XWatch is maintained by Frank Brokken, frank@icce.rug.nl. If you   */
/* have remarks about bugs or features, please mail Frank.            */
/* ------------------------------------------------------------------ */
/* <<< End of information >>>                                         */

#include "xwatch.h"

/* convert geometry string to xpos, ypos, width, height */
void parsegeometry (char *str, int *xp, int *yp, int *wp, int *hp)
{
    int
        x,
        y,
        w,
        h,
	nread;
        
    if (! str || ! *str)                    /* no string, no parsing */
        return;
        
    /* try to match NRxNR as first part of the string */
    if (sscanf (str, "%dx%d%n", &w, &h, &nread) > 1)
    {
        *wp = w;
        *hp = h;
        str += nread;
        if (! *str)
            return;
    }
    
    /* now try all forms +NR+NR, -NR-NR, etc.. */
    if (sscanf (str, "+%d+%d", &x, &y) > 1)
    {
        *xp = x; 
        *yp = y;
    }
    else if (sscanf (str, "-%d+%d", &x, &y) > 1)
    {
        *xp = -x;
        *yp = y;
    }
    else if (sscanf (str, "+%d-%d", &x, &y) > 1)
    {
        *xp = x;
        *yp = -y;
    }
    else if (sscanf (str, "-%d-%d", &x, &y) > 1)
    {
        *xp = -x;
        *yp = -y;
    }
}
