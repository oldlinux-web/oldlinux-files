/* <<< Start of information >>>                                       */
/* ------------------------------------------------------------------ */
/* This file is part of the xwatch program. Copyright (C) ICCE /      */
/* Karel Kubat 1995. All rights reserved. You are permitted to        */
/* redistribute this package, if you include all unmodified sources   */
/* and all unmodified documentation (including this text). You are    */
/* NOT permitted to distribute files of this package with             */
/* modifications.  See the file COPYING for more information. When in */
/* doubt, mail me at karel@icce.rug.nl.                               */
/* XWatch is maintained by Frank Brokken, frank@icce.rug.nl. If you   */
/* have remarks about bugs or features, please mail Frank.            */
/* ------------------------------------------------------------------ */
/* <<< End of information >>>                                         */

#include "xwatch.h"

void addline (char *buf, int colindex)
{
    char
	outbuf [1000];
    int
        i,
        length_so_far,
        extra_length,
	curwidth,
	curheight,
	curx,
	cury;
    char
        *bufcopy,
	*cp;
        
    /* clear trailing \n chars */
    if ( (cp = strchr (buf, '\n')) && cp > buf )
	*cp = '\0';
    if (! *buf)
        return;

    /* see if the contents of the line is `gagged' */
    for (i = 0; i < ngagstring; i++)
        if (strstr (buf, gagstring [i]))
            return;

    /* determine width to use */
    fl_get_browser_dimension (watch_browser, &curx, &cury, 
        &curwidth, &curheight);
    curwidth -= 5;

    /* reset outbuffer */
    outbuf [0] = '\0';

    /* process whole buf, cut it up if necessary */
    bufcopy = xstrdup (buf);
    cp = strtok (bufcopy, " \t");
    while (cp)
    {
	/* add color code if necessary */
	if (! outbuf [0])
	{
	    if (colindex != foregr)
		sprintf (outbuf, "@C%d ", colindex);
            else
		strcpy (outbuf, " ");
	}

	/* determine length of string so far, flush if necessary */
        length_so_far = fl_get_string_width (fontstyle, fontsize, outbuf,
            strlen (outbuf));
        extra_length = fl_get_string_width (fontstyle, fontsize, cp, 
            strlen (cp));
        if (length_so_far + extra_length > curwidth)
        {
	    fl_addto_browser (watch_browser, outbuf);
	    outbuf [0] = '\0';
	}
        else
        {
            strcat (outbuf, " ");
	    strcat (outbuf, cp);
            cp = strtok (NULL, " \t");
        }
    }
    
    /* flush whatever's left */
    if (cp)
        strcat (outbuf, cp);
    if (outbuf [0])
	fl_addto_browser (watch_browser, outbuf);
        
    /* release memory */
    free (bufcopy);
}
