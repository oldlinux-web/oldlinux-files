
inline void bzero(char* where,int count)  
{
  register char* look = where;
  register int to = 0;
  while(to++ < count)
    *look++ = '\0';
}


inline void bcopy(char* to, char* from,int count)  
{
  memcpy(to, from, count);
}

