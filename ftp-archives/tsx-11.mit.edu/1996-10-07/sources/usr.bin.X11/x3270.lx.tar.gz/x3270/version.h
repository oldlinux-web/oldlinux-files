static char *version = "x3270-1.2, Aug 23 1990";
