
/*******************************************************************************
       file_dialog.h
       This header file is included by file_dialog.c

*******************************************************************************/

#ifndef	_FILE_DIALOG_INCLUDED
#define	_FILE_DIALOG_INCLUDED


#include <stdio.h>
#include <Xm/Xm.h>
#include <Xm/MwmUtil.h>
#include <Xm/DialogS.h>
#include <Xm/MenuShell.h>
#include "UxXt.h"

#include <Xm/List.h>
#include <Xm/ScrolledW.h>
#include <Xm/TextF.h>
#include <Xm/Separator.h>
#include <Xm/PushB.h>
#include <Xm/Label.h>
#include <Xm/Form.h>

/*******************************************************************************
       The definition of the context structure:
       If you create multiple copies of your interface, the context
       structure ensures that your callbacks use the variables for the
       correct copy.

       For each swidget in the interface, each argument to the Interface
       function, and each variable in the Interface Specific section of the
       Declarations Editor, there is an entry in the context structure.
       and a #define.  The #define makes the variable name refer to the
       corresponding entry in the context structure.
*******************************************************************************/

typedef	struct
{
	Widget	Uxlabel6;
	Widget	UxpushButton8;
	Widget	UxpushButton7;
	Widget	UxpushButton12;
	Widget	UxpushButton4;
	Widget	Uxseparator1;
	Widget	Uxlabel7;
	Widget	UxscrolledWindow2;
	Widget	UxscrolledWindow3;
	Widget	Uxlabel5;
} _UxCfile_dialog;

#ifdef CONTEXT_MACRO_ACCESS
static _UxCfile_dialog         *UxFile_dialogContext;
#define label6                  UxFile_dialogContext->Uxlabel6
#define pushButton8             UxFile_dialogContext->UxpushButton8
#define pushButton7             UxFile_dialogContext->UxpushButton7
#define pushButton12            UxFile_dialogContext->UxpushButton12
#define pushButton4             UxFile_dialogContext->UxpushButton4
#define separator1              UxFile_dialogContext->Uxseparator1
#define label7                  UxFile_dialogContext->Uxlabel7
#define scrolledWindow2         UxFile_dialogContext->UxscrolledWindow2
#define scrolledWindow3         UxFile_dialogContext->UxscrolledWindow3
#define label5                  UxFile_dialogContext->Uxlabel5

#endif /* CONTEXT_MACRO_ACCESS */

extern Widget	file_dialog;
extern Widget	textField4;
extern Widget	filelist;
extern Widget	dirlist;

/*******************************************************************************
       Declarations of global functions.
*******************************************************************************/

Widget	create_file_dialog();

#endif	/* _FILE_DIALOG_INCLUDED */
