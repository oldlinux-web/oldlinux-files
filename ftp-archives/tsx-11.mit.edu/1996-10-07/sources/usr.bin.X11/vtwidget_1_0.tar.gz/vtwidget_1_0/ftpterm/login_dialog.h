
/*******************************************************************************
       login_dialog.h
       This header file is included by login_dialog.c

*******************************************************************************/

#ifndef	_LOGIN_DIALOG_INCLUDED
#define	_LOGIN_DIALOG_INCLUDED


#include <stdio.h>
#include <Xm/Xm.h>
#include <Xm/MwmUtil.h>
#include <Xm/DialogS.h>
#include <Xm/MenuShell.h>
#include "UxXt.h"

#include <Xm/PushB.h>
#include <Xm/Label.h>
#include <Xm/TextF.h>
#include <Xm/Form.h>

/*******************************************************************************
       The definition of the context structure:
       If you create multiple copies of your interface, the context
       structure ensures that your callbacks use the variables for the
       correct copy.

       For each swidget in the interface, each argument to the Interface
       function, and each variable in the Interface Specific section of the
       Declarations Editor, there is an entry in the context structure.
       and a #define.  The #define makes the variable name refer to the
       corresponding entry in the context structure.
*******************************************************************************/

typedef	struct
{
	Widget	UxtextField1;
	Widget	Uxlabel1;
	Widget	UxtextField2;
	Widget	Uxlabel2;
	Widget	Uxlabel3;
	Widget	UxpushButton1;
	Widget	UxpushButton2;
	Widget	UxpushButton3;
	Widget	UxpushButton5;
	Widget	UxtextField3;
} _UxClogin_dialog;

#ifdef CONTEXT_MACRO_ACCESS
static _UxClogin_dialog        *UxLogin_dialogContext;
#define textField1              UxLogin_dialogContext->UxtextField1
#define label1                  UxLogin_dialogContext->Uxlabel1
#define textField2              UxLogin_dialogContext->UxtextField2
#define label2                  UxLogin_dialogContext->Uxlabel2
#define label3                  UxLogin_dialogContext->Uxlabel3
#define pushButton1             UxLogin_dialogContext->UxpushButton1
#define pushButton2             UxLogin_dialogContext->UxpushButton2
#define pushButton3             UxLogin_dialogContext->UxpushButton3
#define pushButton5             UxLogin_dialogContext->UxpushButton5
#define textField3              UxLogin_dialogContext->UxtextField3

#endif /* CONTEXT_MACRO_ACCESS */

extern Widget	login_dialog;

/*******************************************************************************
       Declarations of global functions.
*******************************************************************************/

Widget	create_login_dialog();

#endif	/* _LOGIN_DIALOG_INCLUDED */
