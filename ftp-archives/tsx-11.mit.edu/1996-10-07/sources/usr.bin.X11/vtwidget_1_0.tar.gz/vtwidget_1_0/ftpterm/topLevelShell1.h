
/*******************************************************************************
       topLevelShell1.h
       This header file is included by topLevelShell1.c

*******************************************************************************/

#ifndef	_TOPLEVELSHELL1_INCLUDED
#define	_TOPLEVELSHELL1_INCLUDED


#include <stdio.h>
#include <Xm/Xm.h>
#include <Xm/MwmUtil.h>
#include <Xm/MenuShell.h>
#include "UxXt.h"

#include <Xm/CascadeB.h>
#include <Xm/PushB.h>
#include <Xm/RowColumn.h>
#include <Xm/Form.h>
#include <X11/Shell.h>

/*******************************************************************************
       The definition of the context structure:
       If you create multiple copies of your interface, the context
       structure ensures that your callbacks use the variables for the
       correct copy.

       For each swidget in the interface, each argument to the Interface
       function, and each variable in the Interface Specific section of the
       Declarations Editor, there is an entry in the context structure.
       and a #define.  The #define makes the variable name refer to the
       corresponding entry in the context structure.
*******************************************************************************/

typedef	struct
{
	Widget	UxtopLevelShell1;
	Widget	Uxform1;
	Widget	Uxmenu1;
	Widget	Uxmenu1_p2;
	Widget	Uxmenu1_p2_b1;
	Widget	Uxmenu1_top_b2;
	Widget	Uxmenu1_p1;
	Widget	Uxmenu1_p1_b2;
	Widget	Uxmenu1_p1_b3;
	Widget	Uxmenu1_p1_b1;
	Widget	Uxmenu1_top_b1;
	Widget	Uxmenu1_p9;
	Widget	Uxmenu1_p9_b1;
	Widget	Uxmenu1_p9_b2;
	Widget	Uxmenu1_p9_b3;
	Widget	Uxmenu1_p9_b4;
	Widget	Uxmenu1_top_b5;
	Widget	Uxmenu1_p8;
	Widget	Uxmenu1_p8_b1;
	Widget	Uxmenu1_p8_b2;
	Widget	Uxmenu1_top_b4;
	Widget	Uxmenu1_p3;
	Widget	Uxmenu1_p3_b4;
	Widget	Uxmenu1_p3_b5;
	Widget	Uxmenu1_p3_b6;
	Widget	Uxmenu1_top_b3;
	Widget	Uxmenu1_p10;
	Widget	Uxmenu1_p10_b1;
	Widget	Uxmenu1_p10_b2;
	Widget	Uxmenu1_top_b6;
} _UxCtopLevelShell1;

#ifdef CONTEXT_MACRO_ACCESS
static _UxCtopLevelShell1      *UxTopLevelShell1Context;
#define topLevelShell1          UxTopLevelShell1Context->UxtopLevelShell1
#define form1                   UxTopLevelShell1Context->Uxform1
#define menu1                   UxTopLevelShell1Context->Uxmenu1
#define menu1_p2                UxTopLevelShell1Context->Uxmenu1_p2
#define menu1_p2_b1             UxTopLevelShell1Context->Uxmenu1_p2_b1
#define menu1_top_b2            UxTopLevelShell1Context->Uxmenu1_top_b2
#define menu1_p1                UxTopLevelShell1Context->Uxmenu1_p1
#define menu1_p1_b2             UxTopLevelShell1Context->Uxmenu1_p1_b2
#define menu1_p1_b3             UxTopLevelShell1Context->Uxmenu1_p1_b3
#define menu1_p1_b1             UxTopLevelShell1Context->Uxmenu1_p1_b1
#define menu1_top_b1            UxTopLevelShell1Context->Uxmenu1_top_b1
#define menu1_p9                UxTopLevelShell1Context->Uxmenu1_p9
#define menu1_p9_b1             UxTopLevelShell1Context->Uxmenu1_p9_b1
#define menu1_p9_b2             UxTopLevelShell1Context->Uxmenu1_p9_b2
#define menu1_p9_b3             UxTopLevelShell1Context->Uxmenu1_p9_b3
#define menu1_p9_b4             UxTopLevelShell1Context->Uxmenu1_p9_b4
#define menu1_top_b5            UxTopLevelShell1Context->Uxmenu1_top_b5
#define menu1_p8                UxTopLevelShell1Context->Uxmenu1_p8
#define menu1_p8_b1             UxTopLevelShell1Context->Uxmenu1_p8_b1
#define menu1_p8_b2             UxTopLevelShell1Context->Uxmenu1_p8_b2
#define menu1_top_b4            UxTopLevelShell1Context->Uxmenu1_top_b4
#define menu1_p3                UxTopLevelShell1Context->Uxmenu1_p3
#define menu1_p3_b4             UxTopLevelShell1Context->Uxmenu1_p3_b4
#define menu1_p3_b5             UxTopLevelShell1Context->Uxmenu1_p3_b5
#define menu1_p3_b6             UxTopLevelShell1Context->Uxmenu1_p3_b6
#define menu1_top_b3            UxTopLevelShell1Context->Uxmenu1_top_b3
#define menu1_p10               UxTopLevelShell1Context->Uxmenu1_p10
#define menu1_p10_b1            UxTopLevelShell1Context->Uxmenu1_p10_b1
#define menu1_p10_b2            UxTopLevelShell1Context->Uxmenu1_p10_b2
#define menu1_top_b6            UxTopLevelShell1Context->Uxmenu1_top_b6

#endif /* CONTEXT_MACRO_ACCESS */


/*******************************************************************************
       Declarations of global functions.
*******************************************************************************/

Widget	create_topLevelShell1();

#endif	/* _TOPLEVELSHELL1_INCLUDED */
