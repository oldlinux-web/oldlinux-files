
/*******************************************************************************
       softkeyform.h
       This header file is included by softkeyform.c

*******************************************************************************/

#ifndef	_SOFTKEYFORM_INCLUDED
#define	_SOFTKEYFORM_INCLUDED


#include <stdio.h>
#include <Xm/Xm.h>
#include <Xm/MwmUtil.h>
#include <Xm/MenuShell.h>
#include "UxXt.h"

#include <Xm/Text.h>
#include <Xm/ArrowB.h>
#include <Xm/PushB.h>
#include <Xm/Form.h>
#include <X11/Shell.h>

/*******************************************************************************
       The definition of the context structure:
       If you create multiple copies of your interface, the context
       structure ensures that your callbacks use the variables for the
       correct copy.

       For each swidget in the interface, each argument to the Interface
       function, and each variable in the Interface Specific section of the
       Declarations Editor, there is an entry in the context structure.
       and a #define.  The #define makes the variable name refer to the
       corresponding entry in the context structure.
*******************************************************************************/

typedef	struct
{
	Widget	Uxsoftkeyform;
	Widget	Uxform1;
	Widget	UxpushButton1;
	Widget	UxPF1;
	Widget	UxPF2;
	Widget	UxPF3;
	Widget	UxPF4;
	Widget	UxPF5;
	Widget	UxPF6;
	Widget	UxPF7;
	Widget	UxPF8;
	Widget	UxPF9;
	Widget	UxPF10;
	Widget	UxPF11;
	Widget	UxPF12;
	Widget	UxPF13;
	Widget	UxPF15;
	Widget	UxPF16;
	Widget	UxPF14;
	Widget	UxPF17;
	Widget	UxEnter;
	Widget	UxarrowButton1;
	Widget	UxarrowButton2;
	Widget	UxarrowButton3;
	Widget	UxarrowButton4;
	Widget	Uxtext1;
	Widget	UxpushButton20;
} _UxCsoftkeyform;

#ifdef CONTEXT_MACRO_ACCESS
static _UxCsoftkeyform         *UxSoftkeyformContext;
#define softkeyform             UxSoftkeyformContext->Uxsoftkeyform
#define form1                   UxSoftkeyformContext->Uxform1
#define pushButton1             UxSoftkeyformContext->UxpushButton1
#define PF1                     UxSoftkeyformContext->UxPF1
#define PF2                     UxSoftkeyformContext->UxPF2
#define PF3                     UxSoftkeyformContext->UxPF3
#define PF4                     UxSoftkeyformContext->UxPF4
#define PF5                     UxSoftkeyformContext->UxPF5
#define PF6                     UxSoftkeyformContext->UxPF6
#define PF7                     UxSoftkeyformContext->UxPF7
#define PF8                     UxSoftkeyformContext->UxPF8
#define PF9                     UxSoftkeyformContext->UxPF9
#define PF10                    UxSoftkeyformContext->UxPF10
#define PF11                    UxSoftkeyformContext->UxPF11
#define PF12                    UxSoftkeyformContext->UxPF12
#define PF13                    UxSoftkeyformContext->UxPF13
#define PF15                    UxSoftkeyformContext->UxPF15
#define PF16                    UxSoftkeyformContext->UxPF16
#define PF14                    UxSoftkeyformContext->UxPF14
#define PF17                    UxSoftkeyformContext->UxPF17
#define Enter                   UxSoftkeyformContext->UxEnter
#define arrowButton1            UxSoftkeyformContext->UxarrowButton1
#define arrowButton2            UxSoftkeyformContext->UxarrowButton2
#define arrowButton3            UxSoftkeyformContext->UxarrowButton3
#define arrowButton4            UxSoftkeyformContext->UxarrowButton4
#define text1                   UxSoftkeyformContext->Uxtext1
#define pushButton20            UxSoftkeyformContext->UxpushButton20

#endif /* CONTEXT_MACRO_ACCESS */


/*******************************************************************************
       Declarations of global functions.
*******************************************************************************/

Widget	create_softkeyform();

#endif	/* _SOFTKEYFORM_INCLUDED */
