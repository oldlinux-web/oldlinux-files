
/*******************************************************************************
	softkeyform.c

       Associated Header file: softkeyform.h
       Associated Resource file: softkeyform.rf
*******************************************************************************/

#include <stdio.h>
#include <Xm/Xm.h>
#include <Xm/MwmUtil.h>
#include <Xm/MenuShell.h>
#include "UxXt.h"

#include <Xm/Text.h>
#include <Xm/ArrowB.h>
#include <Xm/PushB.h>
#include <Xm/Form.h>
#include <X11/Shell.h>

/*******************************************************************************
       Includes, Defines, and Global variables from the Declarations Editor:
*******************************************************************************/

#include <sys/ioctl.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <fcntl.h>
#include <signal.h>
#include <termio.h>
#include <unistd.h>


/*******************************************************************************
       The following header file defines the context structure.
*******************************************************************************/

#define CONTEXT_MACRO_ACCESS 1
#include "softkeyform.h"
#undef CONTEXT_MACRO_ACCESS


/*******************************************************************************
       The following are translation tables.
*******************************************************************************/

static char	*transTable1 = "#override\n\
<Key>:mine()\n";

/*******************************************************************************
Auxiliary code from the Declarations Editor:
*******************************************************************************/

void popup_softkeyform()
{
    UxPopupInterface( softkeyform, no_grab );
}

/*******************************************************************************
       The following are Action functions.
*******************************************************************************/

static	void	action_mine( UxWidget, UxEvent, UxParams, p_UxNumParams )
	Widget		UxWidget;
	XEvent		*UxEvent;
	String		*UxParams;
	Cardinal	*p_UxNumParams;

{
	Cardinal		UxNumParams = *p_UxNumParams;
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	    Modifiers out;
	    KeySym symbol = 0;
	    XKeyEvent *current_event = ( XKeyEvent * )UxEvent;
	    char keybuffer[BUFSIZ];
	    XComposeStatus  status_in_out;
	    XLookupString( current_event, keybuffer, BUFSIZ, &symbol, &status_in_out );
	    if( keybuffer[0] != 0 ) data_input( keybuffer );    
	}
	UxSoftkeyformContext = UxSaveCtx;
}

/*******************************************************************************
       The following are callback functions.
*******************************************************************************/

static	void	activateCB_pushButton1( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	UxPopdownInterface (softkeyform);
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF1( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?OP" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF2( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?OQ" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF3( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?OR" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF4( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?OS" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF5( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?Ow" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF6( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?Ox" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF7( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?Oy" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF8( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?Om" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF9( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?Ot" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF10( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?Ou" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF11( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?Ov" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF12( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?Ol" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF13( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?Oq" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF15( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?Os" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF16( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?Op" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF14( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?Or" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_PF17( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?On" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_Enter( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?OM" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_arrowButton1( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?OA" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_arrowButton2( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?OB" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_arrowButton3( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?OC" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_arrowButton4( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( "?OD" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_text1( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( XmTextGetString( UxGetWidget( text1 ) ) );
	data_input( "\n" );
	XmTextSetString( UxGetWidget(text1), "" );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

static	void	activateCB_pushButton20( UxWidget, UxClientData, UxCallbackArg )
	Widget		UxWidget;
	XtPointer	UxClientData, UxCallbackArg;

{
	_UxCsoftkeyform         *UxSaveCtx, *UxContext;

	UxSaveCtx = UxSoftkeyformContext;
	UxSoftkeyformContext = UxContext =
			(_UxCsoftkeyform *) UxGetContext( UxWidget );
	{
	data_input( XmTextGetString( UxGetWidget( text1 ) ) );
	}
	UxSoftkeyformContext = UxSaveCtx;
}

/*******************************************************************************
       The 'build_' function creates all the widgets
       using the resource values specified in the Property Editor.
*******************************************************************************/

static Widget	_Uxbuild_softkeyform()
{


	/* Creation of softkeyform */
	softkeyform = XtVaCreatePopupShell( "softkeyform",
			topLevelShellWidgetClass,
			UxTopLevel,
			XmNx, 448,
			XmNy, 664,
			XmNwidth, 265,
			XmNheight, 183,
			XmNiconName, "Key Pad",
			XmNinitialState, InactiveState,
			XmNinput, FALSE,
			XmNbaseHeight, 190,
			XmNbaseWidth, 270,
			XmNminHeight, 190,
			XmNminWidth, 270,
			NULL );
	UxPutContext( softkeyform, (char *) UxSoftkeyformContext );


	/* Creation of form1 */
	form1 = XtVaCreateManagedWidget( "form1",
			xmFormWidgetClass,
			softkeyform,
			XmNresizePolicy, XmRESIZE_NONE,
			XmNunitType, XmPIXELS,
			XmNx, 0,
			XmNy, 0,
			XmNwidth, 265,
			XmNheight, 183,
			NULL );
	UxPutContext( form1, (char *) UxSoftkeyformContext );


	/* Creation of pushButton1 */
	pushButton1 = XtVaCreateManagedWidget( "pushButton1",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 170,
			XmNy, 268,
			XmNwidth, 88,
			XmNheight, 34,
			RES_CONVERT( XmNlabelString, "Cancel" ),
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomOffset, 0,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightOffset, 0,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNbottomPosition, 98,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 85,
			XmNleftPosition, 40,
			XmNrightPosition, 60,
			NULL );
	XtAddCallback( pushButton1, XmNactivateCallback,
		(XtCallbackProc) activateCB_pushButton1,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( pushButton1, (char *) UxSoftkeyformContext );


	/* Creation of PF1 */
	PF1 = XtVaCreateManagedWidget( "PF1",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 8,
			XmNy, 3,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 18,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 1,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 1,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 19,
			NULL );
	XtAddCallback( PF1, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF1,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF1, (char *) UxSoftkeyformContext );


	/* Creation of PF2 */
	PF2 = XtVaCreateManagedWidget( "PF2",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 80,
			XmNy, 2,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 18,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 1,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 19,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 37,
			NULL );
	XtAddCallback( PF2, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF2,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF2, (char *) UxSoftkeyformContext );


	/* Creation of PF3 */
	PF3 = XtVaCreateManagedWidget( "PF3",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 156,
			XmNy, 2,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 18,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 1,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 37,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 55,
			NULL );
	XtAddCallback( PF3, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF3,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF3, (char *) UxSoftkeyformContext );


	/* Creation of PF4 */
	PF4 = XtVaCreateManagedWidget( "PF4",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 223,
			XmNy, 3,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 18,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 1,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 55,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 73,
			NULL );
	XtAddCallback( PF4, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF4,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF4, (char *) UxSoftkeyformContext );


	/* Creation of PF5 */
	PF5 = XtVaCreateManagedWidget( "PF5",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 8,
			XmNy, 31,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 35,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 18,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 1,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 19,
			NULL );
	XtAddCallback( PF5, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF5,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF5, (char *) UxSoftkeyformContext );


	/* Creation of PF6 */
	PF6 = XtVaCreateManagedWidget( "PF6",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 80,
			XmNy, 32,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 35,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 18,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 19,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 37,
			NULL );
	XtAddCallback( PF6, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF6,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF6, (char *) UxSoftkeyformContext );


	/* Creation of PF7 */
	PF7 = XtVaCreateManagedWidget( "PF7",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 156,
			XmNy, 31,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 35,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 18,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 37,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 55,
			NULL );
	XtAddCallback( PF7, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF7,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF7, (char *) UxSoftkeyformContext );


	/* Creation of PF8 */
	PF8 = XtVaCreateManagedWidget( "PF8",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 222,
			XmNy, 31,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 35,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 18,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 55,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 73,
			NULL );
	XtAddCallback( PF8, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF8,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF8, (char *) UxSoftkeyformContext );


	/* Creation of PF9 */
	PF9 = XtVaCreateManagedWidget( "PF9",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 8,
			XmNy, 60,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 52,
			XmNtopPosition, 35,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 1,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 19,
			NULL );
	XtAddCallback( PF9, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF9,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF9, (char *) UxSoftkeyformContext );


	/* Creation of PF10 */
	PF10 = XtVaCreateManagedWidget( "PF10",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 80,
			XmNy, 60,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 52,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 35,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 19,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 37,
			NULL );
	XtAddCallback( PF10, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF10,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF10, (char *) UxSoftkeyformContext );


	/* Creation of PF11 */
	PF11 = XtVaCreateManagedWidget( "PF11",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 156,
			XmNy, 58,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 52,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 35,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 37,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 55,
			NULL );
	XtAddCallback( PF11, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF11,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF11, (char *) UxSoftkeyformContext );


	/* Creation of PF12 */
	PF12 = XtVaCreateManagedWidget( "PF12",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 222,
			XmNy, 60,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 52,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 35,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 55,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 73,
			NULL );
	XtAddCallback( PF12, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF12,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF12, (char *) UxSoftkeyformContext );


	/* Creation of PF13 */
	PF13 = XtVaCreateManagedWidget( "PF13",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 7,
			XmNy, 89,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 68,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 52,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 1,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 19,
			NULL );
	XtAddCallback( PF13, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF13,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF13, (char *) UxSoftkeyformContext );


	/* Creation of PF15 */
	PF15 = XtVaCreateManagedWidget( "PF15",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 156,
			XmNy, 90,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 68,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 52,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 37,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 55,
			NULL );
	XtAddCallback( PF15, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF15,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF15, (char *) UxSoftkeyformContext );


	/* Creation of PF16 */
	PF16 = XtVaCreateManagedWidget( "PF16",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 3,
			XmNy, 119,
			XmNwidth, 107,
			XmNheight, 28,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomOffset, 0,
			XmNbottomPosition, 84,
			XmNtopPosition, 68,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 1,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 37,
			NULL );
	XtAddCallback( PF16, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF16,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF16, (char *) UxSoftkeyformContext );


	/* Creation of PF14 */
	PF14 = XtVaCreateManagedWidget( "PF14",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 80,
			XmNy, 90,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 68,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 52,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 19,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 37,
			NULL );
	XtAddCallback( PF14, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF14,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF14, (char *) UxSoftkeyformContext );


	/* Creation of PF17 */
	PF17 = XtVaCreateManagedWidget( "PF17",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 156,
			XmNy, 117,
			XmNwidth, 50,
			XmNheight, 40,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 84,
			XmNtopPosition, 68,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 37,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 55,
			NULL );
	XtAddCallback( PF17, XmNactivateCallback,
		(XtCallbackProc) activateCB_PF17,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( PF17, (char *) UxSoftkeyformContext );


	/* Creation of Enter */
	Enter = XtVaCreateManagedWidget( "Enter",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 223,
			XmNy, 91,
			XmNwidth, 50,
			XmNheight, 86,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 84,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 52,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 55,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 73,
			NULL );
	XtAddCallback( Enter, XmNactivateCallback,
		(XtCallbackProc) activateCB_Enter,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( Enter, (char *) UxSoftkeyformContext );


	/* Creation of arrowButton1 */
	arrowButton1 = XtVaCreateManagedWidget( "arrowButton1",
			xmArrowButtonWidgetClass,
			form1,
			XmNx, 340,
			XmNy, -1,
			XmNwidth, 30,
			XmNheight, 33,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 18,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 81,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 91,
			NULL );
	XtAddCallback( arrowButton1, XmNactivateCallback,
		(XtCallbackProc) activateCB_arrowButton1,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( arrowButton1, (char *) UxSoftkeyformContext );


	/* Creation of arrowButton2 */
	arrowButton2 = XtVaCreateManagedWidget( "arrowButton2",
			xmArrowButtonWidgetClass,
			form1,
			XmNx, 341,
			XmNy, 52,
			XmNwidth, 30,
			XmNheight, 31,
			XmNarrowDirection, XmARROW_DOWN,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 42,
			XmNleftOffset, 0,
			XmNleftPosition, 81,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 91,
			NULL );
	XtAddCallback( arrowButton2, XmNactivateCallback,
		(XtCallbackProc) activateCB_arrowButton2,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( arrowButton2, (char *) UxSoftkeyformContext );


	/* Creation of arrowButton3 */
	arrowButton3 = XtVaCreateManagedWidget( "arrowButton3",
			xmArrowButtonWidgetClass,
			form1,
			XmNx, 369,
			XmNy, 22,
			XmNwidth, 30,
			XmNheight, 30,
			XmNarrowDirection, XmARROW_RIGHT,
			XmNbottomPosition, 30,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 90,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 99,
			NULL );
	XtAddCallback( arrowButton3, XmNactivateCallback,
		(XtCallbackProc) activateCB_arrowButton3,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( arrowButton3, (char *) UxSoftkeyformContext );


	/* Creation of arrowButton4 */
	arrowButton4 = XtVaCreateManagedWidget( "arrowButton4",
			xmArrowButtonWidgetClass,
			form1,
			XmNx, 309,
			XmNy, 23,
			XmNwidth, 32,
			XmNheight, 30,
			XmNarrowDirection, XmARROW_LEFT,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 30,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 73,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 82,
			NULL );
	XtAddCallback( arrowButton4, XmNactivateCallback,
		(XtCallbackProc) activateCB_arrowButton4,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( arrowButton4, (char *) UxSoftkeyformContext );


	/* Creation of text1 */
	text1 = XtVaCreateManagedWidget( "text1",
			xmTextWidgetClass,
			form1,
			XmNx, 280,
			XmNy, 77,
			XmNwidth, 140,
			XmNheight, 40,
			XmNbottomPosition, 67,
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 45,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNleftOffset, 0,
			XmNleftPosition, 73,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 99,
			NULL );
	XtAddCallback( text1, XmNactivateCallback,
		(XtCallbackProc) activateCB_text1,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( text1, (char *) UxSoftkeyformContext );


	/* Creation of pushButton20 */
	pushButton20 = XtVaCreateManagedWidget( "pushButton20",
			xmPushButtonWidgetClass,
			form1,
			XmNx, 296,
			XmNy, 212,
			XmNwidth, 80,
			XmNheight, 40,
			RES_CONVERT( XmNlabelString, "Send Text" ),
			XmNbottomAttachment, XmATTACH_POSITION,
			XmNbottomPosition, 84,
			XmNtopAttachment, XmATTACH_POSITION,
			XmNtopPosition, 70,
			XmNleftOffset, 0,
			XmNleftPosition, 73,
			XmNleftAttachment, XmATTACH_POSITION,
			XmNrightAttachment, XmATTACH_POSITION,
			XmNrightPosition, 99,
			NULL );
	XtAddCallback( pushButton20, XmNactivateCallback,
		(XtCallbackProc) activateCB_pushButton20,
		(XtPointer) UxSoftkeyformContext );

	UxPutContext( pushButton20, (char *) UxSoftkeyformContext );


	XtAddCallback( softkeyform, XmNdestroyCallback,
		(XtCallbackProc) UxDestroyContextCB,
		(XtPointer) UxSoftkeyformContext);


	return ( softkeyform );
}

/*******************************************************************************
       The following is the 'Interface function' which is the
       external entry point for creating this interface.
       This function should be called from your application or from
       a callback function.
*******************************************************************************/

Widget	create_softkeyform()
{
	Widget                  rtrn;
	_UxCsoftkeyform         *UxContext;
	static int		_Uxinit = 0;

	UxSoftkeyformContext = UxContext =
		(_UxCsoftkeyform *) UxNewContext( sizeof(_UxCsoftkeyform), False );


	if ( ! _Uxinit )
	{
		static XtActionsRec	_Uxactions[] = {
			{ "mine", (XtActionProc) action_mine }};

		XtAppAddActions( UxAppContext,
				_Uxactions,
				XtNumber(_Uxactions) );

		UxLoadResources( "softkeyform.rf" );
		_Uxinit = 1;
	}

	rtrn = _Uxbuild_softkeyform();

	{
	    return(rtrn);
	}
}

/*******************************************************************************
       END OF FILE
*******************************************************************************/

