/*+****************************************************************************/
/*+                                                                           */
/*+ Copyright (c) 1992-1996 Bruce M. Corwin                                   */
/*+                                                                           */
/*+****************************************************************************/
/*+****************************************************************************/
/*+                                                                           */
/*+ Module Name: Vt.h                                                         */
/*+                                                                           */
/*+ Program ID:  vtwidget                                                     */
/*+                                                                           */
/*+ Functions:  None                                                          */
/*+                                                                           */
/*+****************************************************************************/

#ifndef _ORAXmVt_h
#define _ORAXmVt_h
#ifndef XmNapplication
#define XmNapplication            "application"
#endif
#ifndef XmCApplication
#define XmCApplication            "Application"
#endif
#ifndef XmNrootMenu
#define XmNrootMenu               "rootMenu"
#endif
#ifndef XmCRootMenu
#define XmCRootMenu               "RootMenu"
#endif
#ifndef XmNmenuFile
#define XmNmenuFile               "menuFile"
#endif
#ifndef XmCMenuFile
#define XmCMenuFile               "MenuFile"
#endif
#ifndef XmNmaxHistory
#define XmNmaxHistory             "maxHistory"
#endif
#ifndef XmCMaxHistory
#define XmCMaxHistory             "MaxHistory"
#endif
#ifndef XmNhyperFilter
#define XmNhyperFilter            "hyperFilter"
#endif
#ifndef XmCHyperFilter
#define XmCHyperFilter            "HyperFilter"
#endif
#ifndef XmNbuttonFilter
#define XmNbuttonFilter           "buttonFilter"
#endif
#ifndef XmCButtonFilter
#define XmCButtonFilter           "ButtonFilter"
#endif
#ifndef XmNcutPaste
#define XmNcutPaste               "cutPaste"
#endif
#ifndef XmCCutPaste
#define XmCCutPaste               "CutPaste"
#endif
#ifndef XmNimageShadowThickness
#define XmNimageShadowThickness   "imageShadowThickness"
#endif
#ifndef XmCImageShadowThickness
#define XmCImageShadowThickness   "ImageShadowThickness"
#endif
#ifndef XmNundefinedIcon
#define XmNundefinedIcon          "undefinedIcon"
#endif
#ifndef XmCUndefinedIcon
#define XmCUndefinedIcon          "UndefinedIcon"
#endif
#ifndef XmNgraphicsIdentity
#define XmNgraphicsIdentity       "graphicsIdentity"
#endif
#ifndef XmCGraphicsIdentity
#define XmCGraphicsIdentity       "GraphicsIdentity"
#endif
#ifndef XmNscrolled
#define XmNscrolled               "scrolled"
#endif
#ifndef XmCScrolled
#define XmCScrolled               "Scrolled"
#endif
#ifndef XmNblinkCount
#define XmNblinkCount             "blinkCount"
#endif
#ifndef XmCBlinkCount
#define XmCBlinkCount             "BlinkCount"
#endif
#ifndef XmNmonitorCount
#define XmNmonitorCount           "monitorCount"
#endif
#ifndef XmCMonitorCount
#define XmCMonitorCount           "MonitorCount"
#endif
#ifndef XmNrepaintCount
#define XmNrepaintCount           "repaintCount"
#endif
#ifndef XmCRepaintCount
#define XmCRepaintCount           "RepaintCount"
#endif
#ifndef XmNblockBreakCount
#define XmNblockBreakCount        "blockBreakCount"
#endif
#ifndef XmCBlockBreakCount
#define XmCBlockBreakCount        "BlockBreakCount"
#endif
#ifndef XmNscrollBarWidth
#define XmNscrollBarWidth         "scrollBarWidth"
#endif
#ifndef XmCScrollBarWidth
#define XmCScrollBarWidth         "ScrollBarWidth"
#endif
#ifndef XmNhighlightThickness
#define XmNhighlightThickness     "highlightThickness"
#endif
#ifndef XmCHighlightThickness
#define XmCHighlightThickness     "HighlightThickness"
#endif
#ifndef XmNiconForegroundColor
#define XmNiconForegroundColor    "iconForegroundColor"
#endif
#ifndef XmCIconForegroundColor
#define XmCIconForegroundColor    "IconForegroundColor"
#endif
#ifndef XmNiconBackgroundColor
#define XmNiconBackgroundColor    "iconBackgroundColor"
#endif
#ifndef XmCIconBackgroundColor
#define XmCIconBackgroundColor    "IconBackgroundColor"
#endif
#ifndef XmNselectColor
#define XmNselectColor            "selectColor"
#endif
#ifndef XmCSelectColor
#define XmCSelectColor            "SelectColor"
#endif
#ifndef XmNcursorColor
#define XmNcursorColor            "cursorColor"
#endif
#ifndef XmCCursorColor
#define XmCCursorColor            "CursorColor"
#endif
#ifndef XmNreverseColor
#define XmNreverseColor           "reverseColor"
#endif
#ifndef XmCReverseColor
#define XmCReverseColor           "ReverseColor"
#endif
#ifndef XmNboldColor
#define XmNboldColor              "boldColor"
#endif
#ifndef XmCBoldColor
#define XmCBoldColor              "BoldColor"
#endif
#ifndef XmNdimColor
#define XmNdimColor               "dimColor"
#endif
#ifndef XmCDimColor
#define XmCDimColor               "DimColor"
#endif
#ifndef XmNblinkColor
#define XmNblinkColor             "blinkColor"
#endif
#ifndef XmCBlinkColor
#define XmCBlinkColor             "BlinkColor"
#endif
#ifndef XmNspecialColor
#define XmNspecialColor           "specialColor"
#endif
#ifndef XmCSpecialColor
#define XmCSpecialColor           "SpecialColor"
#endif
#ifndef XmNarmedColor
#define XmNarmedColor             "armedColor"
#endif
#ifndef XmCArmedColor
#define XmCArmedColor             "ArmedColor"
#endif
#ifndef XmNansi0Color
#define XmNansi0Color             "ansi0Color"
#endif
#ifndef XmCAnsi0Color
#define XmCAnsi0Color             "Ansi0Color"
#endif
#ifndef XmNansi1Color
#define XmNansi1Color             "ansi1Color"
#endif
#ifndef XmCAnsi1Color
#define XmCAnsi1Color             "Ansi1Color"
#endif
#ifndef XmNansi2Color
#define XmNansi2Color             "ansi2Color"
#endif
#ifndef XmCAnsi2Color
#define XmCAnsi2Color             "Ansi2Color"
#endif
#ifndef XmNansi3Color
#define XmNansi3Color             "ansi3Color"
#endif
#ifndef XmCAnsi3Color
#define XmCAnsi3Color             "Ansi3Color"
#endif
#ifndef XmNansi4Color
#define XmNansi4Color             "ansi4Color"
#endif
#ifndef XmCAnsi4Color
#define XmCAnsi4Color             "Ansi4Color"
#endif
#ifndef XmNansi5Color
#define XmNansi5Color             "ansi5Color"
#endif
#ifndef XmCAnsi5Color
#define XmCAnsi5Color             "Ansi5Color"
#endif
#ifndef XmNansi6Color
#define XmNansi6Color             "ansi6Color"
#endif
#ifndef XmCAnsi6Color
#define XmCAnsi6Color             "Ansi6Color"
#endif
#ifndef XmNansi7Color
#define XmNansi7Color             "ansi7Color"
#endif
#ifndef XmCAnsi7Color
#define XmCAnsi7Color             "Ansi7Color"
#endif

#ifndef XmNansi8Color
#define XmNansi8Color             "ansi8Color"
#endif
#ifndef XmCAnsi8Color
#define XmCAnsi8Color             "Ansi8Color"
#endif
#ifndef XmNansi9Color
#define XmNansi9Color             "ansi9Color"
#endif
#ifndef XmCAnsi9Color
#define XmCAnsi9Color             "Ansi9Color"
#endif
#ifndef XmNansi10Color
#define XmNansi10Color             "ansi10Color"
#endif
#ifndef XmCAnsi10Color
#define XmCAnsi10Color             "Ansi10Color"
#endif
#ifndef XmNansi11Color
#define XmNansi11Color             "ansi11Color"
#endif
#ifndef XmCAnsi11Color
#define XmCAnsi11Color             "Ansi11Color"
#endif
#ifndef XmNansi12Color
#define XmNansi12Color             "ansi12Color"
#endif
#ifndef XmCAnsi12Color
#define XmCAnsi12Color             "Ansi12Color"
#endif
#ifndef XmNansi13Color
#define XmNansi13Color             "ansi13Color"
#endif
#ifndef XmCAnsi13Color
#define XmCAnsi13Color             "Ansi13Color"
#endif
#ifndef XmNansi14Color
#define XmNansi14Color             "ansi14Color"
#endif
#ifndef XmCAnsi14Color
#define XmCAnsi14Color             "Ansi14Color"
#endif
#ifndef XmNansi15Color
#define XmNansi15Color             "ansi15Color"
#endif
#ifndef XmCAnsi15Color
#define XmCAnsi15Color             "Ansi15Color"
#endif
#ifndef XmNfont
#define XmNfont                   "font"
#endif
#ifndef XmCFont
#define XmCFont                   "Font"
#endif
#ifndef XmNwideFont
#define XmNwideFont               "wideFont"
#endif
#ifndef XmCWideFont
#define XmCWideFont               "WideFont"
#endif
#ifndef XmNdoubleFont
#define XmNdoubleFont             "doubleFont"
#endif
#ifndef XmCDoubleFont
#define XmCDoubleFont             "DoubleFont"
#endif
#ifndef XmNspecialFont
#define XmNspecialFont            "specialFont"
#endif
#ifndef XmCSpecialFont
#define XmCSpecialFont            "SpecialFont"
#endif
#ifndef XmNuseHostname
#define XmNuseHostname            "useHostname"
#endif
#ifndef XmCUseHostname
#define XmCUseHostname            "UseHostname"
#endif
#ifndef XmNblinkCursor
#define XmNblinkCursor            "blinkCursor"
#endif
#ifndef XmCBlinkCursor
#define XmCBlinkCursor            "BlinkCursor"
#endif
#ifndef XmNuseShadow
#define XmNuseShadow              "useShadow"
#endif
#ifndef XmCUseShadow
#define XmCUseShadow              "UseShadow"
#endif
#ifndef XmNcursorMode
#define XmNcursorMode             "cursorMode"
#endif
#ifndef XmCCursorMode
#define XmCCursorMode             "CursorMode"
#endif
#ifndef XmNdelonBSMode
#define XmNdelonBSMode            "delonBSMode"
#endif
#ifndef XmCDelonBSMode
#define XmCDelonBSMode            "DelonBSMode"
#endif
#ifndef XmNonlcrMode
#define XmNonlcrMode              "onlcrMode"
#endif
#ifndef XmCOnlcrMode
#define XmCOnlcrMode              "OnlcrMode"
#endif
#ifndef XmNinsertMode
#define XmNinsertMode             "insertMode"
#endif
#ifndef XmCInsertMode
#define XmCInsertMode             "InsertMode"
#endif
#ifndef XmNcursorSpeed
#define XmNcursorSpeed            "cursorSpeed"
#endif
#ifndef XmCCursorSpeed
#define XmCCursorSpeed            "CursorSpeed"
#endif
#ifndef XmNattributes
#define XmNattributes             "attributes"
#endif
#ifndef XmCAttributes
#define XmCAttributes             "Attributes"
#endif
#ifndef XmNoutputCallback
#define XmNoutputCallback         "outputCallback"
#endif
#ifndef XmCOutputCallback
#define XmCOutputCallback         "OutputCallback"
#endif
#ifndef XmNadjustCallback
#define XmNadjustCallback         "adjustCallback"
#endif
#ifndef XmCAdjustCallback
#define XmCAdjustCallback         "AdjustCallback"
#endif
#ifndef XmNanswerBack
#define XmNanswerBack             "answerBack"
#endif
#ifndef XmCAnswerBack
#define XmCAnswerBack             "AnswerBack"
#endif
#ifndef XmNcursorAttribute
#define XmNcursorAttribute        "cursorAttribute"
#endif
#ifndef XmCCursorAttribute
#define XmCCursorAttribute        "CursorAttribute"
#endif
#ifndef XmNhyperAttribute
#define XmNhyperAttribute         "hyperAttribute"
#endif
#ifndef XmCHyperAttribute
#define XmCHyperAttribute         "HyperAttribute"
#endif
#ifndef XmNmonitorCallback
#define XmNmonitorCallback        "monitorCallback"
#endif
#ifndef XmCMonitorCallback
#define XmCMonitorCallback        "MonitorCallback"
#endif
#ifndef XmNactivateCallback
#define XmNactivateCallback       "activateCallback"
#endif
#ifndef XmCactivateCallback
#define XmCActivateCallback       "ActivateCallback"
#endif
#ifndef XmNmessageCallback
#define XmNmessageCallback        "messageCallback"
#endif
#ifndef XmCMessageCallback
#define XmCMessageCallback        "MessageCallback"
#endif

#define XmNnewFontCallback        XmNadjustCallback
#define XmCNewFontCallback        XmCAdjustCallback

#define XmCR_ACTIVATE            ( 1 )
#define XmCR_NEW_FONT            ( 2 )
#define XmCR_MONITOR_DONE        ( 3 )
#define XmCR_MONITOR_IOERR       ( 4 )
#define XmCR_MESSAGE_SENT        ( 5 )
#define XmCR_OUTPUT              ( 6 )
#define XmCR_MONITOR_ABORT       ( 7 )
#define XmCR_VT_NORMAL           ( 0 )
#define XmCR_VT_BOLD             ( 1 )
#define XmCR_VT_DIM              ( 2 )
#define XmCR_VT_UNDERSCORE       ( 4 )
#define XmCR_VT_BLINK            ( 5 )
#define XmCR_VT_INVERSE          ( 7 )
#define XmCR_VT_ANSI30           ( 30 )
#define XmCR_VT_ANSI31           ( 31 )
#define XmCR_VT_ANSI32           ( 32 )
#define XmCR_VT_ANSI33           ( 33 )
#define XmCR_VT_ANSI34           ( 34 )
#define XmCR_VT_ANSI35           ( 35 )
#define XmCR_VT_ANSI36           ( 36 )
#define XmCR_VT_ANSI37           ( 37 )
#define XmCR_VT_ANSI38           ( 38 )
#define XmCR_VT_ANSI39           ( 39 )
#define XmCR_VT_ANSI40           ( 40 )
#define XmCR_VT_ANSI41           ( 41 )
#define XmCR_VT_ANSI42           ( 42 )
#define XmCR_VT_ANSI43           ( 43 )
#define XmCR_VT_ANSI44           ( 44 )
#define XmCR_VT_ANSI45           ( 45 )
#define XmCR_VT_ANSI46           ( 46 )
#define XmCR_VT_ANSI47           ( 47 )
#define XmCR_VT_ANSI48           ( 48 )
#define XmCR_VT_CURSOR           ( 50 )
#define XmCR_VT_SELECT           ( 51 )
#define XmCR_VT_SPECIAL          ( 52 )
#define XmCR_VT_ARMED            ( 53 )
#define XmCR_VT_GRAPHICS         ( 54 )
#define XmCR_VT_WIDGET           ( 55 )
#define XmCR_VT_CURSOR2          ( 56 )
#define XmCR_VT_NOPID            ( -1 )
/**************************************************/
/* The Following are default values for resources */
/**************************************************/
#define XmDEFAULT_APPLICATION    ( "bterm" )
#define XmDEFAULT_ROOT_MENU      ( "VtRootMenu" )
#define XmDEFAULT_MENU_FILE      ( ".vtrc" )
#define XmDEFAULT_HYPER_FILTER   ( "\\s" )
#define XmDEFAULT_BUTTON_FILTER  ( "\\s" )
#define XmDEFAULT_UNDEFINED_ICON ( "xlogo32" )
#define XmDEFAULT_GRAPHICS_IDENTITY ( "a" )
#define XmDEFAULT_ANSWER_BACK    ( "# Answer back string.\n" )
#define XmDEFAULT_HYPER_ATTRIBUTE ( "Bold, UnderScore, Graphics, Ansi32" )
#define XmDEFAULT_CURSOR_ATTRIBUTE ( "Cursor" )
/**************************************************/
/* End of default resource values.                */
/**************************************************/
typedef struct
{
    int reason;
    int data_count;
    char *data_buffer;
}
XmVtCallbackStruct;
typedef struct
{
    char identity;
    char *hyper_data;
    int height;
    int width;
    Pixmap Pixmap;
}
XmVtImage;
typedef struct
{
    char identity;
    char *name;
    char *callback_data;
    int wtype;
    int height;
    int width;
    int row;
    int column;
    Boolean painted;
    Widget vtchild;
}
XmVtChild;
extern WidgetClass xmVtWidgetClass;
typedef struct _XmVtClassRec *XmVtWidgetClass;
typedef struct _XmVtRec *XmVtWidget;
#ifdef _NO_PROTO
void XmVtUnmonitor ();
void XmVtMonitor ();
int XmVtWrite ();
int XmVtRead ();
int XmVtSend ();
void XmVtFlush ();
int XmVtScrollBarSetValue ();
void XmVtSyncSize ();
Boolean XmVtPaste ();
Boolean XmVtCopy ();
void XmVtBlankWidgets ();
void XmVtChildSetValues ();
void XmVtLoadWidget ();
void XmVtLoadIcon ();
void XmVtLoadHyperData ();
void XmVtLoadButtonData ();
void XmVtAppendTextChild ();
void XmVtAppendListChild ();
#else
void XmVtUnmonitor (Widget cw);
void XmVtMonitor (Widget cw, int filedescriptor, int input_pid);
int XmVtWrite (Widget cw, char *buffer, int count);
int XmVtRead (Widget cw, char *buffer, int count);
int XmVtSend (Widget cw, char *buffer);
void XmVtFlush (Widget cw);
int XmVtScrollBarSetValue (Widget cw, int scroll_value);
void XmVtSyncSize (Widget cw, Widget vtw, int top, int bot, int lf, int rt);
void XmVtBlankWidgets (Widget wid);
void XmVtChildSetValues (Widget wid, char identity, char *res, char *val);
void XmVtLoadIcon (Widget wid, char identity, char *iname);
void XmVtLoadWidget
  (
      Widget wid,
      char identity,
      char *name,
      int wtype,
      int char_width,
      int char_height
);
void XmVtLoadHyperData (Widget wid, char identity, char *hyper_data);
void XmVtLoadButtonData (Widget wid, char identity, char *callback_data);
Boolean XmVtPaste (Widget wid);
Boolean XmVtCopy (Widget wid, Time time);
void XmVtAppendTextChild (Widget wid, char identity, char *extend);
void XmVtAppendListChild (Widget wid, char identity, char *extend);
#endif
#ifndef XmIsVt
#define XmIsVt(w)        XtIsSubclass(w, xmVtWidgetClass)
#endif /* XmIsVt */
#endif
