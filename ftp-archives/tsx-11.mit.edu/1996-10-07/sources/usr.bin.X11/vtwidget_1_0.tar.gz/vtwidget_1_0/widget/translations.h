/*+****************************************************************************/
/*+                                                                           */
/*+ Copyright (c) 1992-1996 Bruce M. Corwin                                   */
/*+                                                                           */
/*+****************************************************************************/
/*+****************************************************************************/
/*+                                                                           */
/*+ Module Name: translations.h                                               */
/*+                                                                           */
/*+ Program ID:  vtwidget                                                     */
/*+                                                                           */
/*+ Functions:  None                                                          */
/*+                                                                           */
/*+****************************************************************************/

/* Use the following translation to override the DelonBS resource */
/* <Key>osfBackSpace:   string(0x08)  \n\ */
static char defaultTranslations[] = "                                         \
Shift<Btn2Down>:     	PasteClipboard()                                    \n\
Shift<Btn1Down>:     	CopyClipboard()                                     \n\
Ctrl<Btn1Down>:     	SendMouse()                                     \n\
<Btn2Down>:          	Paste()                                             \n\
Button1<Motion>:     	SelectArea()                                        \n\
<Motion>:		Motion()                                            \n\
<Btn1Down>:          	BeginFunction()                                     \n\
<Btn1Up>:            	EndFunction()                                       \n\
<Key>osfBeginLine: 	string(0x7f)                                        \n\
<Key>osfActivate:  	string(0x0d)                                        \n\
<Key>osfNextField: 	string(0x09)                                        \n\
<Key>osfPrevField: 	string(0x09)                                        \n\
<Key>osfSelect: 	string(0x1b) string(0x5b) string(0x34) string(0x7e) \n\
<Key>osfUp:             string(0x1b) string(0x5b) string(0x41)              \n\
<Key>osfDown:	 	string(0x1b) string(0x5b) string(0x42)              \n\
<Key>osfLeft:  		string(0x1b) string(0x5b) string(0x44)              \n\
<Key>osfRight: 		string(0x1b) string(0x5b) string(0x43)              \n\
<Key>osfPageDown:       string(0x1b) string(0x5b) string(0x36) string(0x7e) \n\
<Key>osfPageUp:         string(0x1b) string(0x5b) string(0x35) string(0x7e) \n\
<Key>BackSpace:		string(0x7f)                                        \n\
<Key>Delete:            string(0x7f)                                        \n\
<Key>KP_Multiply:	string(0x1b) string(0x4f) string(0x50)              \n\
<Key>KP_Divide:		string(0x1b) string(0x4f) string(0x51)              \n\
<Key>KP_Add:		string(0x1b) string(0x4f) string(0x52)              \n\
<Key>KP_Subtract:	string(0x1b) string(0x4f) string(0x53)              \n\
<Key>KP_7:		string(0x1b) string(0x4f) string(0x77)              \n\
<Key>KP_8:		string(0x1b) string(0x4f) string(0x78)              \n\
<Key>KP_9:		string(0x1b) string(0x4f) string(0x79)              \n\
<Key>KP_4:		string(0x1b) string(0x4f) string(0x74)              \n\
<Key>KP_5:		string(0x1b) string(0x4f) string(0x75)              \n\
<Key>KP_6:		string(0x1b) string(0x4f) string(0x76)              \n\
<Key>KP_1:		string(0x1b) string(0x4f) string(0x71)              \n\
<Key>KP_2:		string(0x1b) string(0x4f) string(0x72)              \n\
<Key>KP_3:		string(0x1b) string(0x4f) string(0x73)              \n\
<Key>KP_0:		string(0x1b) string(0x4f) string(0x70)              \n\
<Key>KP_Decimal:	string(0x1b) string(0x4f) string(0x6e)              \n\
<Key>KP_Enter:		string(0x1b) string(0x4f) string(0x6d)              \n\
<Key>KP_Add:		string(0x1b) string(0x4f) string(0x6c)              \n\
<Key>KP_Tab:		string(0x1b) string(0x4f) string(0x4d)              \n\
<Key>Prior:             string(0x1b) string(0x5b) string(0x35) string(0x7e) \n\
<Key>Next:              string(0x1b) string(0x5b) string(0x36) string(0x7e) \n\
<Key>Up:                string(0x1b) string(0x5b) string(0x41)              \n\
<Key>Down:   		string(0x1b) string(0x5b) string(0x42)              \n\
<Key>Right:  		string(0x1b) string(0x5b) string(0x43)              \n\
<Key>Left:   		string(0x1b) string(0x5b) string(0x44)              \n\
<Key>:                  self-insert()                                       \
";
