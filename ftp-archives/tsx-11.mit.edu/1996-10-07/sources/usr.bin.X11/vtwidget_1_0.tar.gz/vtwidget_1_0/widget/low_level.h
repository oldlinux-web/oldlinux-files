/*+****************************************************************************/
/*+                                                                           */
/*+ Copyright (c) 1992-1996 Bruce M. Corwin                                   */
/*+                                                                           */
/*+****************************************************************************/
/*+****************************************************************************/
/*+                                                                           */
/*+ Module Name: low_level.h                                                  */
/*+                                                                           */
/*+ Program ID:  vtwidget                                                     */
/*+                                                                           */
/*+ Functions:  None                                                          */
/*+                                                                           */
/*+****************************************************************************/

#define DATA_TYPE           char **
#define ATTR_TYPE           attribute  **
#define FLAG_TYPE           char **
#define CSET_TYPE           char **
struct vt_line_struct
{
    int line_attribute;
    char *data;
    char *cset;
    char *flag;
    char *attrib0;
    char *attrib1;
    char *attrib2;
    char *attrib3;
    char *attrib4;
    char *attrib5;
    char *attrib6;
    char *attrib7;
};

typedef struct vt_line_struct VTLINE;
