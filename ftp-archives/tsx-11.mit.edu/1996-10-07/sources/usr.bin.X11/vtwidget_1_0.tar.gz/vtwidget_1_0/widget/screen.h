/*+****************************************************************************/
/*+                                                                           */
/*+ Copyright (c) 1992-1996 Bruce M. Corwin                                   */
/*+                                                                           */
/*+****************************************************************************/
/*+****************************************************************************/
/*+                                                                           */
/*+ Module Name: screen.h                                                     */
/*+                                                                           */
/*+ Program ID:  vtwidget                                                     */
/*+                                                                           */
/*+ Functions:  None                                                          */
/*+                                                                           */
/*+****************************************************************************/

#define BADCOMMAND             (-1)
#define EIGHT_BIT              (0)
#define SOFT_RESET             (1)
#define CLEAR                  (2)
#define CLEAR_DOWN             (3)
#define CLEAR_DOWN2            (4)
#define CLEAR_UP               (5)
#define CLEAR_EOL              (6)
#define CLEAR_EOL2             (7)
#define CLEAR_BOL              (8)
#define CLEAR_AOL              (9)
#define SEND_ID2               (10)
#define SEND_ID3               (11)
#define TABCLR                 (12)
#define TABCLR2                (13)
#define TABCLRALL              (14)
#define PRINTER_OFF            (15)
#define PRINTER_ON             (16)
#define GRAPHIC_OFF            (17)
#define GRAPHIC_ON             (18)
#define DSTREP                 (19)
#define REPORT                 (20)
#define DA0_X                  (21)
#define DA1_X                  (22)
#define DA2_X                  (23)
#define SAVE                   (24)
#define RESTORE                (25)
#define RESET                  (26)
#define SWITCH_G2              (27)
#define SWITCH_G3              (28)
#define INDEX                  (29)
#define DONEWLINE              (30)
#define TABSET                 (31)
#define REVERSE_IN             (32)
#define COLOR_LOAD             (33)
#define SEND_ID                (34)
#define NORMAL_KEY             (35)
#define APPLIC_KEY             (36)
#define EXIT_VT52              (37)
#define SPECMSG                (38)
#define REQUEST_7              (39)
#define REQUEST_8              (40)
#define MESSAGE                (41)
#define PRIVATE_MD             (42)
#define CURSOR_MV              (43)
#define BACK_SLASH             (44)
#define SELECTCS0A             (45)
#define SELECTCS0B             (46)
#define SELECTCS0C             (47)
#define SELECTCS0D             (48)
#define SELECTCS0E             (49)
#define SELECTCS1A             (50)
#define SELECTCS1B             (51)
#define SELECTCS1C             (52)
#define SELECTCS1D             (53)
#define SELECTCS1E             (54)
#define DECDHL_TP              (55)
#define DECDHL_BT              (56)
#define DECSWL                 (57)
#define DECDWL                 (58)
#define TEST                   (59)
#define NUMVT100               (61)

char *vt100[NUMVT100] =
{
    "[62\"p",
    "[!p",
    "[2J",
    "[J",
    "[0J",
    "[1J",
    "[K",
    "[0K",
    "[1K",
    "[2K",
    "[c",
    "[0c",
    "[g",
    "[0g",
    "[3g",
    "[4i",
    "[5i",
    "[34i",
    "[35i",
    "[5n",
    "[6n",
    "[0x",
    "[1x",
    "[2x",
    "7",
    "8",
    "c",
    "n",
    "o",
    "D",
    "E",
    "H",
    "M",
    "P",
    "Z",
    ">",
    "=",
    "<",
    "}",
    " F",
    " G",
    "]",
    "[?",
    "[",
    "\\",
    "(0",
    "(1",
    "(2",
    "(A",
    "(B",
    ")0",
    ")1",
    ")2",
    ")A",
    ")B",
    "#3",
    "#4",
    "#5",
    "#6",
    "#8",
    NULL
};
#ifndef True
#define True (1)
#endif
#ifndef False
#define False (0)
#endif
#ifdef NOTX
#define Boolean        int
#endif
