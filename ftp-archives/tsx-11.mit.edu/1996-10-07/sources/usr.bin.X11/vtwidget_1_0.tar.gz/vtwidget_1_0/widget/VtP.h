/*+****************************************************************************/
/*+                                                                           */
/*+ Copyright (c) 1992-1996 Bruce M. Corwin                                   */
/*+                                                                           */
/*+****************************************************************************/
/*+****************************************************************************/
/*+                                                                           */
/*+ Module Name: VtP.h                                                        */
/*+                                                                           */
/*+ Program ID:  vtwidget                                                     */
/*+                                                                           */
/*+ Functions:  None                                                          */
/*+                                                                           */
/*+****************************************************************************/

#ifndef _ORAXmVtP_h
#define _ORAXmVtP_h
#include <Xm/XmP.h>
#include "Vt.h"
#include <Xm/DrawingAP.h>
#include "attributes.h"
#include "low_level.h"
#define  MAXHIST              ( 1000 )
#define  ESCSIZ               ( 100 )
#define  NAMSIZ               ( 100 )
#define  COMSIZ               ( 100 )
#define  MSGSIZ               ( 512 )
#define  NUMLEV               ( 5 )
#define  NUMMAPS              ( 16 )
#define  MAXIMAGES            ( 256 )
#define  MAXCHILDREN          ( 256 )
#define	RES_CONVERT( res_name, res_value) \
	XtVaTypedArg, (res_name), XmRString, (res_value), strlen(res_value) + 1

struct dynamic_menu
{
    char *menu;
    char *description;
    int command;
    char *data;
};

typedef struct dynamic_menu MENU;

typedef struct
{
    int make_compiler_happy;
}
XmVtClassPart;
typedef struct _XmVtClassRec
{
    CoreClassPart core_class;
    CompositeClassPart composite_class;
    ConstraintClassPart constraint_class;
    XmManagerClassPart manager_class;
    XmDrawingAreaClassPart drawing_area_class;
    XmVtClassPart xmVt_class;
}
XmVtClassRec;
extern XmVtClassRec xmVtClassRec;
typedef struct
{
/**************************************************************************/
/*                                                                        */
/* This is the first section of XmVtClassRec.                             */
/* The following elements of the VT widget are concerned more with the    */
/* Graphical aspects of the display of information than the emulation of  */
/* VTXXX stuff.  Most of the X windows and Xt data is here.               */
/*                                                                        */
/**************************************************************************/
    XtCallbackList activate_callback;
    XtCallbackList adjust_callback;
    XtCallbackList monitor_callback;
    XtCallbackList message_callback;
    XtCallbackList output_callback;
    int blink_count;
    int repaint_count;
    int monitor_count;
    XtIntervalId monitor_id;
    int block_break_count;
    int hborder;
    int vborder;
    Dimension highlight_thickness;
    Dimension image_shadow_thickness;
    GC normal_GC;
    GC antinormal_GC;
    GC bold_GC;
    GC dim_GC;
    GC blink_GC;
    GC inverse_GC;
    GC cursor_GC;
    GC select_GC;
    GC special_GC;
    GC armed_special_GC;
    GC armed_normal_GC;
    GC ansi0_GC;
    GC ansi1_GC;
    GC ansi2_GC;
    GC ansi3_GC;
    GC ansi4_GC;
    GC ansi5_GC;
    GC ansi6_GC;
    GC ansi7_GC;
    GC ansi8_GC;
    GC ansi9_GC;
    GC ansi10_GC;
    GC ansi11_GC;
    GC ansi12_GC;
    GC ansi13_GC;
    GC ansi14_GC;
    GC ansi15_GC;
    XmFontList font;
    XmFontList wide_font;
    XmFontList double_font;
    XmFontList special_font;
    XFontStruct *active_font;
    XFontStruct *active_wide_font;
    XFontStruct *active_double_font;
    XFontStruct *active_special_font;
    Pixel cursor_pixel;
    Pixel bold_pixel;
    Pixel dim_pixel;
    Pixel blink_pixel;
    Pixel reverse_pixel;
    Pixel select_pixel;
    Pixel special_pixel;
    Pixel armed_pixel;
    Pixel icon_foreground_pixel;
    Pixel icon_background_pixel;
    Pixel ansi0_pixel;
    Pixel ansi1_pixel;
    Pixel ansi2_pixel;
    Pixel ansi3_pixel;
    Pixel ansi4_pixel;
    Pixel ansi5_pixel;
    Pixel ansi6_pixel;
    Pixel ansi7_pixel;
    Pixel ansi8_pixel;
    Pixel ansi9_pixel;
    Pixel ansi10_pixel;
    Pixel ansi11_pixel;
    Pixel ansi12_pixel;
    Pixel ansi13_pixel;
    Pixel ansi14_pixel;
    Pixel ansi15_pixel;
    XmVtImage images[MAXIMAGES];
    char *undefined_icon;
    int image_count;
    XmVtChild children[MAXCHILDREN];
    int child_count;
    int columns;
    int rows;
    int begin_cx;
    int begin_cy;
    int select_cx;
    int select_cy;
    int end_cx;
    int end_cy;
    char *hyper_attribute;
    char *cursor_attribute;
    attribute hyper_value;
    char *hyper_filter;
    char *button_filter;
    Boolean override_focus_out;
    Boolean hyper_started;
    Boolean selection_started;
    Boolean word_selection;
    Boolean use_shadow;
    Boolean cut_paste;
    Boolean blink_toggle;
    char *selection;
    int selection_bufsiz;
    Boolean cursor_count;
    int cursor_speed;
    Boolean blink_cursor;
    int use_hostname;
    Boolean monitoring;
    int child_stat;
    int pid;
    Boolean revive_all;
    Widget Vsbar;
    Boolean scrolled;
    Dimension scroll_bar_width;
    char *application;
    char *menu_file;
    char *root_menu;
    MENU *popup_menu;
    int menu_count;
    Widget *popup_destroy_list;
    int destroy_count;
    Widget dynamic_menu;
    Boolean menu_event_added;
/**************************************************************************/
/*                                                                        */
/* This is the second section of XmVtClassRec.                            */
/* The following elements of the VT widget are concerned more with the    */
/* emulation of the ANSI X64.1979 standards and extensions.               */
/*                                                                        */
/**************************************************************************/
/**************************************************************************/
/* This set is devoted to Boolean States                                  */
/**************************************************************************/
    Boolean update_screen;
    Boolean cursor_mode;
    Boolean delonBS_mode;
    Boolean autowrap_mode;
    Boolean column_mode;
    Boolean newline_mode;
    Boolean decom_mode;
    Boolean onlcr_mode;
    Boolean insert_mode;
    Boolean inverse_mode;
    Boolean application_key_mode;
    Boolean ansi_mode;
    Boolean smooth_mode;
    Boolean mouse_mode;
    Boolean autorepeat_mode;
/**************************************************************************/
/*                                                                        */
/**************************************************************************/
    int last_ansi_fg;
    int last_ansi_bg;
    int hues[NUMMAPS];
    int lums[NUMMAPS];
    int sats[NUMMAPS];
    int cwidth;
    int cheight;
    int cdescent;
    int cascent;
    char *report_message;
    char *keybuffer;
    int keybuffer_size;
    int keycount;
    int need_adjust;
    int char_set[NUMLEV];
    int gr_cset_level;
    int iofd;
    int first_row;
    int scroll_value;
    VTLINE *vtscreen;		/* A screen is an dynamic array of lines */
    char tabs[BUFSIZ];
    int pass_thru;
    char *data_name;
    FILE *data_fp;
    char *graphics_name;
    char *graphics_identity;
    int poundflag;
    int eflag;
    int bflag;
    int qflag;
    int fflag;
    int dflag;
    int sflag;
    int cflag;
    int pflag;
    int jflag;
    int aflag;
    int nflag;
    int color_flag;
    int spcflag;
    int leftcnt;
    int rightcnt;
    char esc_sequence[ESCSIZ];
    char message[MSGSIZ];
    char *answer_back;
    int screen_cx;
    int screen_cy;
    int minx;
    int miny;
    int maxx;
    int maxy;
    int real_miny;
    int real_maxy;
    int real_minx;
    int real_maxx;
    attribute attributes;
    int save_char_set[NUMLEV];
    int save_cset_level;
    int save_cx;
    int save_cy;
    int save_ansi_fg;
    int save_ansi_bg;
    attribute save_attributes;
    int scroll_line_count;
    int max_history;
    int prev_max_history;
    int stored_cx;
    int stored_cy;
}
XmVtPart;
typedef struct _XmVtRec
{
    CorePart core;
    CompositePart composite;
    ConstraintPart constraint;
    XmManagerPart manager;
    XmDrawingAreaPart drawing_area;
    XmVtPart vt;
}
XmVtRec;
#endif
