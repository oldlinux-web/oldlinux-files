/*+****************************************************************************/
/*+                                                                           */
/*+ Copyright (c) 1992-1996 Bruce M. Corwin                                   */
/*+                                                                           */
/*+****************************************************************************/
/*+****************************************************************************/
/*+                                                                           */
/*+ Module Name: keys_table.h                                                 */
/*+                                                                           */
/*+ Program ID:  vtwidget                                                     */
/*+                                                                           */
/*+ Functions:  None                                                          */
/*+                                                                           */
/*+****************************************************************************/

#include <X11/keysymdef.h>
#define  MAXKEY          ( 10 )
typedef struct keysym_table
{
    KeySym keysym;
    char value[MAXKEY];
}
KEYTAB;
static KEYTAB key_table[] =
{
    {XK_Escape, "\033"},
    {XK_Up, "\033OA"},
    {XK_Down, "\033OB"},
    {XK_Right, "\033OC"},
    {XK_Left, "\033OD"},
    {XK_Tab, "\t"},
    {XK_Return, ""},
    {0, ""},
};
