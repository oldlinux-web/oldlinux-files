/*+****************************************************************************/
/*+                                                                           */
/*+ Copyright (c) 1995-1996 Bruce M. Corwin                                   */
/*+                                                                           */
/*+****************************************************************************/
/*+****************************************************************************/
/*+                                                                           */
/*+ Module Name: vtclib.h                                                     */
/*+                                                                           */
/*+ Program ID:  vtclib                                                       */
/*+                                                                           */
/*+ Functions:  None                                                          */
/*+                                                                           */
/*+****************************************************************************/

#define VTcutPaste               "cutPaste"
#define VTimageShadowThickness   "imageShadowThickness"
#define VTscrolled               "scrolled"
#define VTmonitorCount           "monitorCount"
#define VTrepaintCount           "repaintCount"
#define VTblockBreakCount        "blockBreakCount"
#define VTscrollBarWidth         "scrollBarWidth"
#define VThighlightThickness     "highlightThickness"
#define VTselectColor            "selectColor"
#define VTcursorColor            "cursorColor"
#define VTreverseColor           "reverseColor"
#define VTboldColor              "boldColor"
#define VTblinkColor             "blinkColor"
#define VTspecialColor           "specialColor"
#define VTarmedColor             "armedColor"
#define VTfont                   "font"
#define VTspecialFont            "specialFont"
#define VTuseHostname            "useHostname"
#define VTblinkCursor            "blinkCursor"
#define VTuseShadow              "useShadow"
#define VTcursorMode             "cursorMode"
#define VTdelonBS                "delonBS"
#define VTonlcr                  "onlcr"
#define VTinsert                 "insert"
#define VTcursorSpeed            "cursorSpeed"
#define VTattributes             "attributes"
#define VTlpFilename             "lpFilename"
#define VTlpCommand              "lpCommand"
#define VThyperAttribute         "hyperAttribute"
/* Various defines.                    */
#define  READMODE                ( "r" )
/* Available widget codes for children */
#define  PUSHBUTTON              (  0 )
#define  LABEL                   (  1 )
#define  TEXT                    (  2 )
#define  SCROLLEDTEXT            (  3 )
#define  ARROWBUTTON             (  4 )
#define  LIST                    (  5 )
#define  SCROLLEDLIST            (  6 )
#define  TEXTFIELD               (  7 )
#define  SCROLLBAR               (  8 )
#define  SEPARATORV              (  9 )
#define  SEPARATORH              ( 10 )
#define  TOGGLEBUTTON            ( 11 )
#define  SEPARATORHGADGET        ( 12 )
#define  SEPARATORVGADGET        ( 13 )
#define  LABELGADGET             ( 15 )
#define  PUSHBUTTONGADGET        ( 16 )
#define  TOGGLEBUTTONGADGET      ( 17 )
#define  ARROWBUTTONGADGET       ( 18 )
#define  COMMAND                 ( 19 )
#define  FILESELECTIONBOX        ( 20 )
#define  SCROLLEDWINDOW          ( 21 )
#define  PANEDWINDOW             ( 22 )
#define  ROWCOLUMN               ( 23 )
#define  FRAME                   ( 24 )
#define  SCALE                   ( 25 )
#define  SELECTIONBOX            ( 26 )
#define  FORM                    ( 27 )
/* Two predefined actions            */
#define  RESIZE                  ( 1 )
#define  QUIT                    ( 2 )
void manage_mode ();
void normal_mode ();
void cls ();
void set_value (char *resource, char *value);
void child_set_value (char identity, char *resource, char *value);
void create_widget
  (int wtype, char identity, char *name, int width, int height);
void register_button (char identity);
void noecho ();
void echo ();
int vtinput (char *buffer);
void vtset ();
void find_size ();
void terminate ();
int wsize (int *rows, int *columns);
void resize_widget (char identity, int width, int height);
void append_text (char identity, char *ttext);
void append_text_raw (char identity, char *ttext);
void append_list (char identity, char *ttext);
void append_list_raw (char identity, char *ttext);
int append_file (char identity, char *filename);
