#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <Xm/XmAll.h>

#include "funexec.h" 

#define Nbsecond 200 
#define NbDialog 10
#define Nb_element 100

Widget  main_widget;
Widget dialog[Nb_element];
Widget dialogcurrent;
Widget Button[Nb_element];

int NbDtotal=0,NbTtotal=0;

char namesave[200];
Boolean knownamesave=False;

char second[Nbsecond][100];

char *PrendentreGuillemet(FILE *f)
{char s[100];
int n=0;char c;
s[n]=0;
while((c=fgetc(f))!=(int)'"')  
 {if (c==-1){fprintf(stderr,"error file format \n");exit(-1);}
  s[n]=c;n++;
 }
s[n]=0;
return s;
}
char DonneNextChar(FILE *f)
{char c;
do {c=fgetc(f);
 if (c==-1){fprintf(stderr,"error file format \n");exit(-1);}
   } while(c!='"' &&  c!='{');
return c;
}

/***********************************************/
/*   call back  
************************************************/

void action1(Widget w,XtPointer client,XtPointer appel)
{
Widget t=(Widget) client;
XtUnmanageChild(dialogcurrent);
XtManageChild(t);
dialogcurrent=t;
}

void action2(Widget w,XtPointer client,XtPointer appel)
{
int bit = (int) client;
char  tmp[200];
strcpy(tmp,second[bit]);
strcat(tmp," &");
system(tmp);
}

/********************************************/
/*	parse 	the ressource file 	    */
/********************************************/

void SetupButton(FILE *fichier)
{
char nom[100];
Widget bidon;
char c;
Widget mere=dialog[NbDtotal];
while(1)  /* boucle infinie sortie par } */
{
fscanf(fichier,"%s",nom);
if (nom[0]=='}') return;
Button[NbTtotal]= XmCreatePushButton(mere,nom,NULL,0);
c= DonneNextChar(fichier);
switch (c) {
case '{':
	NbDtotal++;
	dialog[NbDtotal]=XmCreateRowColumn(main_widget,"rowexec",NULL,0);
	XtAddCallback(Button[NbTtotal],XmNactivateCallback, action1,dialog[NbDtotal]);
	XtManageChild(Button[NbTtotal]);
	NbTtotal++;
	bidon = XmCreatePushButton(dialog[NbDtotal],"fleche",NULL,0);
	XtManageChild(bidon);
	XtAddCallback(bidon,XmNactivateCallback, action1,mere);
	SetupButton(fichier);
	break;
case  '"':
	strcpy( second[NbTtotal], PrendentreGuillemet(fichier));
	XtManageChild(Button[NbTtotal]);
	XtAddCallback(Button[NbTtotal],XmNactivateCallback, action2,NbTtotal);
	NbTtotal++;
	break;
default:
	fprintf(stderr,"erreur fichier %c ",c);
	exit(-1);
 	break;
  } 
 }
}

SetupDialog(FILE *f)
{int ac=0;
 Arg args[10];
char c;
ac=0;
dialog[NbDtotal]=XmCreateRowColumn(main_widget,"rowexec",args,ac);
dialogcurrent=dialog[NbDtotal];
c= DonneNextChar(f);
if (c!='{') {fprintf(stderr,"erreur debut fichier \n");exit(-1);}
SetupButton(f);
XtManageChild(dialogcurrent);
}
/* to destroy zombi process */
filappelpere(int n)
{
wait(0);
signal(SIGCLD,filappelpere);
}
main(int argc,char **argv)
{
char tmp[200];
char *home;
FILE *fichier;
Boolean std=False;
if ((home=getenv("HOME"))==NULL) {fprintf(stderr,"env HOME ?"); exit(1);}
strcpy(tmp,home);
strcat(tmp,"/.funexecrc");
if (argc>1) 
  {if (!strcmp(argv[1],"-h")) {printf("%s\n",help);exit(0);
                                }
   
  if (!strcmp(argv[1],"-rc")) {fichier=fopen(tmp,"w");
                                fprintf(fichier,"%s",ressourc);
                                fclose(fichier);
                                exit(0);
                                }
  if (!strcmp(argv[1],"-c")) std=True;

  }

signal(SIGCLD,filappelpere);
if (std==True) fichier=stdin;
 else 
if ((fichier=fopen(tmp,"r"))==NULL) {fprintf(stderr,"no .funexecrc \n%s",help );exit(1);}
main_widget = XtInitialize(argv[0],"funExec",NULL,0,&argc,argv);
SetupDialog(fichier);
XtRealizeWidget(main_widget);
XtMainLoop();
}
