$Id$

(C) COPYRIGHT 1991 Paul J Turner
All Rights Reserved

Sun Apr 19 19:44:12 PDT 1992

This directory contains a compiled binary for SPARC, some 
test data, and a script 'dotest' that will run things.
