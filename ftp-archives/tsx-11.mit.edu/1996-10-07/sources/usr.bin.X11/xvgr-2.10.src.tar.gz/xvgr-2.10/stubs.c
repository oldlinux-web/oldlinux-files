/*
 * stubs module
 */
void create_default_frame()
{
}

void define_colors_popup()
{
}

#ifdef XVIEW
#endif

#ifdef MOTIF
void update_editp_proc()
{
}

void set_right_footer()
{
}
#endif
