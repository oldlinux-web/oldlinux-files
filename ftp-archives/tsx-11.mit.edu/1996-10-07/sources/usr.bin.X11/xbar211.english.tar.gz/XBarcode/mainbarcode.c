/*************************************************************************************************/
/*  This is a quick and dirty undocumented code .... WE DO KNOW THIS ... so DO NOT FLAME US .... */
/*                 (c) by Martin Bauer, Jan Laitenberger in Stuttgart , Germany                  */
/*                                                                                               */
/*  Version 2.11: code still quick & undocumented - but less dirty                               */
/*************************************************************************************************/
/*               Just because you're paranoid doesn't mean they AREN'T after you                 */
/*************************************************************************************************/

#include <xview/xview.h>
#include <xview/frame.h>
#include <xview/panel.h>
#include <xview/defaults.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include <xview/canvas.h>
#include <xview/font.h>
#include <xview/xv_xrect.h>
#include <xview/win_input.h>
#include <xview/textsw.h>
#include <xview/notice.h>
#include <stdlib.h>
#include <xview/win_event.h>
#include <xview/scrollbar.h>
#include "german.h" 
#include "barcode.h"
#include "fileio.h"
#include "help.h"

Frame frame,helpframe,previewframe;
Canvas helpcanvas;
Panel panel,panel1,panel2,panel3;
Panel Dateiname,Ausgabe,Typ,BarcodeText;
Panel slider,sliderB,helppanel,previewpanel;
Panel_item help_message;

GC helpgc;
int oldformat,preview=0,preview_zoom=1;
int  BarcodeYWert, BarcodeXWert;
char *Ausgabedatei,*CodeText,*OutputString, *HelpText;


void HelpSubframe(text)
char *text;
{ int lines;

  HelpText = text;
  
  for (lines=0; *text!=0; text++) { if (*text == '\n') lines++; }
  xv_set(helpframe,XV_HEIGHT,35,NULL);
  xv_set(helppanel,XV_HEIGHT,35,NULL);
  xv_set(helpcanvas,XV_HEIGHT,lines*14,NULL);
  window_fit(helpframe);
  xv_set(helpframe, XV_SHOW, TRUE, NULL);
  xv_window_loop(helpframe);
}

void show_help(canvas,paint_window,dpy,xwin,xrects)
Canvas canvas;
Xv_Window paint_window;
Display *dpy;
Window xwin;
Xv_xrectlist *xrects;
{
  int ypos,spos,c;
  char *strg,*s,text[256];
  
  strg = HelpText;
  spos = 0; ypos=0;
  *text = '\0';

  while (spos < strlen(strg)) {
    while (strg[spos - 1] != '\n' && spos < strlen(strg)) {
      sprintf(text + strlen(text), "%c", strg[spos - 1]);
      spos++;
    }
    XDrawString(dpy,xwin,helpgc,10,ypos,text,strlen(text));
    ypos=ypos+14;
    *text='\0'; spos++;
  }
}


Xv_opaque help_quit()
{
  xv_window_return(0);
  xv_set(helpframe,XV_SHOW,FALSE,NULL);
}

Xv_opaque preview_quit()
{
  xv_window_return(0);
  xv_destroy_safe(previewframe);
}

void repaint_preview_window()
{
  int x,y,width;

  x = (int)xv_get(previewframe,XV_X);
  y = (int)xv_get(previewframe,XV_Y);
  width = BarcodeXWert * preview_zoom;
  if (width < 205) width = 205;
  xv_set(previewframe,
	XV_SHOW,FALSE,
	NULL);
  xv_set(previewframe,
	XV_X, x,
	XV_Y, y,
	XV_WIDTH, width+40,
	XV_SHOW,TRUE,
	NULL);
}

Xv_opaque preview_100(item,event)
Panel_item item;
Event *event;
{
  preview_zoom=1;
  repaint_preview_window();
}

Xv_opaque preview_200(item,event)
Panel_item item;
Event *event;
{
  preview_zoom=2;
  repaint_preview_window();
}

Xv_opaque preview_300(item,event)
Panel_item item;
Event *event;
{
  preview_zoom=3;
  repaint_preview_window();
}


main (argc,argv)
 int argc;
 char *argv[];
{ 
  Xv_opaque quit();
  Xv_opaque hilfe();
  Xv_opaque FormatWahl();
  Xv_opaque make_barcode();
  Xv_opaque preview_barcode();

  Xv_Font font;
  XGCValues gcvalues;
  Display *dpy;
  Menu helpmenu;
  
  Ausgabedatei  =(char *) malloc(1024); 
  CodeText      =(char *) malloc(1024);
  OutputString  =(char *) malloc(2048);


/*  init f�r xview */
  xv_init(XV_INIT_ARGS, argc,argv,NULL); 

/* erstelle das "Hauptframe" */
  frame = (Frame)xv_create (XV_NULL,FRAME,
	FRAME_LABEL,"XBarcode 2.11",
	NULL); 

  panel = (Panel)xv_create (frame,
	PANEL,
	PANEL_LAYOUT,PANEL_VERTICAL,
	XV_HEIGHT, 190,
	XV_WIDTH, 370,
	NULL);

 helpmenu = (Menu) xv_create (XV_NULL,MENU,
	MENU_ITEM,
	  MENU_STRING,"COPYRIGHT",
	  MENU_NOTIFY_PROC,HelpCopyright,
	  NULL,
	MENU_ITEM,
	  MENU_STRING,"Barcode EAN",
	  MENU_NOTIFY_PROC,HelpEan,
	  NULL,
	MENU_ITEM,
	  MENU_STRING,"Barcode Code 128 (A/B)",
	  MENU_NOTIFY_PROC,HelpCode128,
	  NULL,
	MENU_ITEM,
	  MENU_STRING,"Barcode UPC",
	  MENU_NOTIFY_PROC,HelpUpc,
	  NULL,
	MENU_ITEM,
	  MENU_STRING,"Barcode CodABar",
	  MENU_NOTIFY_PROC,HelpCodabar,
	  NULL,
	MENU_ITEM,
	  MENU_STRING,"Barcode 2 of 5",
	  MENU_NOTIFY_PROC,Help2of5,
	  NULL,
	MENU_ITEM,
	  MENU_STRING,"Barcode 3 of 9",
	  MENU_NOTIFY_PROC,Help3of9,
	  NULL, 
	NULL);

  (void) xv_create (panel,
	PANEL_BUTTON,
	PANEL_LABEL_STRING,ButtonLabelQuit,
	PANEL_NOTIFY_PROC,quit,
	XV_X, 20,
	XV_Y, 150,                     
	NULL);

   (void) xv_create (panel,
	PANEL_BUTTON,
	PANEL_LABEL_STRING,ButtonLabelSave,
	PANEL_NOTIFY_PROC,make_barcode,
	XV_X, 84,
	XV_Y,  150,
	NULL);

   (void) xv_create (panel,
	PANEL_BUTTON,
	PANEL_LABEL_STRING,ButtonLabelPreview,
	PANEL_NOTIFY_PROC,preview_barcode,
	XV_X, 180,
	XV_Y,  150,
	NULL);
                                                                                                                           
  (void) xv_create (panel,
	PANEL_BUTTON,
	PANEL_ITEM_MENU,helpmenu,
	PANEL_LABEL_STRING,ButtonLabelHelp,
	PANEL_NOTIFY_PROC,hilfe,
	XV_X, 290,
	XV_Y, 150,
	NULL);

  Ausgabe = (Panel) xv_create(panel,
	PANEL_CHOICE_STACK,
	PANEL_LABEL_STRING, MenuLabel1,
	PANEL_CHOICE_STRINGS, "PPM","GIF","PCX","PGM","LaTeX","Postscript",NULL,
	PANEL_NOTIFY_PROC,FormatWahl,
	PANEL_VALUE, 0,
	XV_X, 20,
	XV_Y, 10,
	NULL);
                                                                                                                                                
/* macht eine Checkbox mit buttons */
  Typ = (Panel) xv_create(panel,
	PANEL_CHOICE_STACK,
	PANEL_LABEL_STRING,MenuLabel2,
	PANEL_CHOICE_STRINGS, "EAN 13","EAN 12","EAN 8","Code 128 A","Code 128 B","Code 3/9","Code 2/5","Code 2/5 Interleaved","Code 2/5 Matrix","Codabar","UPC",
	NULL,
	PANEL_VALUE, 0,
	XV_X, 20,
	XV_Y, 30,
	NULL);

  sliderB = (Panel) xv_create(panel,
	PANEL_SLIDER,
	XV_SHOW,FALSE,
	PANEL_SHOW_RANGE,TRUE,
	PANEL_MAX_VALUE,1000,
	PANEL_MIN_VALUE,1,
	PANEL_VALUE,100,
	PANEL_LABEL_WIDTH,92,
	PANEL_LABEL_STRING,LabelBreite,
	XV_X,20,
	XV_Y,60,
	NULL);

  slider = (Panel) xv_create(panel,
	PANEL_SLIDER,
	PANEL_SHOW_RANGE,TRUE,
	PANEL_MAX_VALUE,1000,
	PANEL_MIN_VALUE,1,
	PANEL_VALUE,100,
	PANEL_LABEL_WIDTH,92,
	PANEL_LABEL_STRING,LabelHoehe,
	XV_X,20,
	XV_Y,80,
	NULL);

/* macht eine text-eingabe */
  BarcodeText = (Panel) xv_create(panel,
	PANEL_TEXT,
	PANEL_LABEL_WIDTH,89,
	PANEL_LABEL_STRING,LabelCode,
	PANEL_VALUE_DISPLAY_LENGTH, 30, 
	PANEL_VALUE, "",
	XV_X, 20,
	XV_Y, 100,                 
	NULL); 

/* macht eine text-eingabe */
  Dateiname = (Panel) xv_create(panel,
	PANEL_TEXT,
	PANEL_LABEL_WIDTH,89,
	PANEL_LABEL_STRING, LabelDatei,
	PANEL_VALUE_DISPLAY_LENGTH, 30, 
	PANEL_VALUE, "",
	XV_X, 20,
	XV_Y, 120,                 
	NULL);
	
/* Hilfe-Fenster definieren */

  helpframe = (Frame)xv_create(XV_NULL,FRAME,
	XV_WIDTH, 400,
	XV_HEIGHT, 35,
	FRAME_LABEL,LabelMenu3,
	NULL);
	
  helppanel = (Panel)xv_create(helpframe,PANEL,
	PANEL_LAYOUT,PANEL_VERTICAL,
	NULL); 
	
  helpcanvas = (Canvas)xv_create(helpframe,CANVAS,
	XV_WIDTH,400,
	XV_HEIGHT,100,
	CANVAS_WIDTH,1000,
	CANVAS_HEIGHT,1000,
	CANVAS_RETAINED, FALSE,
  	CANVAS_REPAINT_PROC, show_help,
  	CANVAS_X_PAINT_WINDOW, TRUE,
  	NULL);
  	
 (void)xv_create(helppanel,PANEL_BUTTON,
	XV_X, 8,
	XV_Y, 8,
	PANEL_LABEL_STRING,ButtonLabelQuit,
	PANEL_NOTIFY_PROC,help_quit,
	NULL);

  window_fit(helpframe);

/* GC erzeugen */

  dpy = (Display *)xv_get(helpframe,XV_DISPLAY);
  if (!(font = (Xv_Font)xv_find(helpcanvas,FONT,
	FONT_FAMILY, FONT_FAMILY_DEFAULT_FIXEDWIDTH,
	FONT_STYLE, FONT_STYLE_BOLD,
	FONT_SIZE, 12,
	NULL)))
  {
    /* font failed */
    font = (Xv_Font)xv_get(helpcanvas,XV_FONT);
  }

  gcvalues.font = (Font)xv_get(font, XV_XID);
  gcvalues.foreground = BlackPixel (dpy, DefaultScreen(dpy));
  gcvalues.background = WhitePixel (dpy, DefaultScreen(dpy));
  gcvalues.graphics_exposures = False;
  helpgc = XCreateGC(dpy,RootWindow(dpy,DefaultScreen(dpy)),
    GCForeground | GCBackground | GCFont | GCGraphicsExposures,
    &gcvalues);
	
  oldformat = (int)xv_get(Ausgabe,PANEL_VALUE);

  window_fit(frame); 
  xv_main_loop (frame);
  exit(0);
}

Xv_opaque quit(item,event)
Panel_item item;
Event *event;
{ 
  xv_destroy_safe(frame);
  exit(0);
}

Xv_opaque hilfe(item,event)
Panel_item item;
Event *event;
{
}

Xv_opaque FormatWahl(item,event)
Panel_item item;
Event *event;
{ 
  int format;
  format = (int)xv_get(Ausgabe,PANEL_VALUE);
  if ((oldformat>=4) && (format<4)) {
    xv_set(sliderB,XV_SHOW,FALSE,NULL);
  }
  if ((oldformat<4) && (format>=4)) {
    xv_set(sliderB,XV_SHOW,TRUE,NULL);
  }
  oldformat=format;
}

Xv_opaque preview_barcode(item,event)
Panel_item item;
Event *event;
{
  Xv_opaque make_barcode();
  
  preview=1;
  make_barcode(item,event);
}

void show_barcode(canvas,paint_window,dpy,xwin,xrects)
Canvas canvas;
Xv_Window paint_window;
Display *dpy;
Window xwin;
Xv_xrectlist *xrects;
{
  GC gc;
  int c,z,p;
  
  gc = DefaultGC(dpy,DefaultScreen(dpy));
  XClearWindow (dpy,xwin);
  for (z=0,p=0;OutputString[z]!=0;z++) {
    if (OutputString[z]==49) {
      for (c=0; c < preview_zoom; c++, p++) {
        XDrawLine(dpy,xwin,gc,p+20,10,p+20,BarcodeYWert+10);
      }
    }
    else p = preview_zoom+p;  
  }
}

Xv_opaque make_barcode(item,event)
Panel_item item;
Event *event;
{
  long BarcodeTyp;
  long BildTyp;
  int  xwert,ywert,ok,ok1;

  strcpy(Ausgabedatei, (char *) xv_get(Dateiname  ,PANEL_VALUE));
  strcpy(CodeText,     (char *) xv_get(BarcodeText,PANEL_VALUE));
  BarcodeTyp  =        (int   ) xv_get(Typ        ,PANEL_VALUE);
  xwert       =        (int   ) xv_get(sliderB    ,PANEL_VALUE);
  ywert       =        (int   ) xv_get(slider     ,PANEL_VALUE);
  BildTyp     =        (int   ) xv_get(Ausgabe    ,PANEL_VALUE);
  ok=0; ok1=-1;

  if (BarcodeTyp==0)  { ok=(boolean) EAN13    ((char *)CodeText,(char *)OutputString);   }
  if (BarcodeTyp==1)  { ok=(boolean) EAN12    ((char *)CodeText,(char *)OutputString);   }
  if (BarcodeTyp==2)  { ok=(boolean) EAN8     ((char *)CodeText,(char *)OutputString);   }
  if (BarcodeTyp==3)  { ok=(boolean) QCODE128 (1,(char *)CodeText,(char *)OutputString); }
  if (BarcodeTyp==4)  { ok=(boolean) QCODE128 (2,(char *)CodeText,(char *)OutputString); }
  if (BarcodeTyp==5)  { ok=(boolean) CODE39   ((char *)CodeText,(char *)OutputString);   }
  if (BarcodeTyp==6)  { ok=(boolean) CODE25   ((char *)CodeText,(char *)OutputString);   }
  if (BarcodeTyp==7)  { ok=(boolean) CODE25I  ((char *)CodeText,(char *)OutputString);   }
  if (BarcodeTyp==8)  { ok=(boolean) CODE25M  ((char *)CodeText,(char *)OutputString);   }
  if (BarcodeTyp==9)  { ok=(boolean) CODEA    ((char *)CodeText,(char *)OutputString);   }
  if (BarcodeTyp==10) { ok=(boolean) UPC      ((char *)CodeText,(char *)OutputString);   }

  if (ok==0) {  
    int result;
    xv_create(panel,NOTICE,
      XV_SHOW,TRUE,
      NOTICE_LOCK_SCREEN,TRUE,
      NOTICE_STATUS,&result,
      NOTICE_MESSAGE_STRINGS,ErrText1,ErrText2,NULL,
      NOTICE_BUTTON_YES,LabelButtonOK, 
      NOTICE_BUTTON_NO,ButtonLabelHelp,
      NULL);
    if (result==NOTICE_NO) 
    {
      switch (BarcodeTyp) {
      case 0:
      case 1:
      case 2:
        HelpEan();
        break;
      case 3:
      case 4:
        HelpCode128();
        break;
      case 5:
        Help3of9();
        break;
      case 6:
      case 7:
      case 8:
        Help2of5();
        break;
      case 9:
        HelpCodabar();
        break;
      case 10:
        HelpUpc();
        break;
      }  
    }
  }

  if (preview && (ok!=0)) {
    Canvas canvas;
    int xwidth;
    char *str;
    preview=0; preview_zoom=1;

    for (xwidth=0,str=OutputString; *str!=0; xwidth++,*str++);
    BarcodeYWert = ywert;
    BarcodeXWert = xwidth;
    if (xwidth < 205) xwidth=205;
    previewframe = (Frame)xv_create(XV_NULL,FRAME,
	XV_WIDTH, 205,
	XV_HEIGHT, 35,
	FRAME_LABEL,ButtonLabelPreview,
	NULL);
	
    previewpanel = (Panel)xv_create(previewframe,PANEL,
	PANEL_LAYOUT,PANEL_VERTICAL,
	NULL); 
	
    canvas = (Canvas)xv_create(previewframe,CANVAS,
	XV_WIDTH,xwidth+40,
	XV_HEIGHT,ywert+20,
	CANVAS_WIDTH,1000,
	CANVAS_HEIGHT,1000,
	CANVAS_RETAINED, FALSE,
  	CANVAS_REPAINT_PROC, show_barcode,
  	CANVAS_X_PAINT_WINDOW, TRUE,
  	NULL);
  	
  (void)xv_create(previewpanel,PANEL_BUTTON,
	XV_X, 8,
	XV_Y, 8,
	PANEL_LABEL_STRING,ButtonLabelQuit,
	PANEL_NOTIFY_PROC,preview_quit,
	NULL);

  (void)xv_create(previewpanel,PANEL_BUTTON,
	XV_X, 65,
	XV_Y, 8,
	PANEL_LABEL_STRING,"100%",
	PANEL_NOTIFY_PROC,preview_100,
	NULL);

  (void)xv_create(previewpanel,PANEL_BUTTON,
	XV_X, 125,
	XV_Y, 8,
	PANEL_LABEL_STRING,"200%",
	PANEL_NOTIFY_PROC,preview_200,
	NULL);

 (void)xv_create(previewpanel,PANEL_BUTTON,
	XV_X, 185,
	XV_Y, 8,
	PANEL_LABEL_STRING,"300%",
	PANEL_NOTIFY_PROC,preview_300,
	NULL);

  window_fit(previewframe);

  xv_window_loop(previewframe); 
  }
  
  else{
  preview=0;
  if ((ok!=0) && (BildTyp==0)){ ok1=create_ppm(Ausgabedatei ,OutputString,ywert); }
  if ((ok!=0) && (BildTyp==4)){ ok1=create_tex(Ausgabedatei, OutputString, xwert,ywert); }
  if ((ok!=0) && (BildTyp==5)){ ok1=create_ps (Ausgabedatei, OutputString, xwert,ywert); }
  if ((ok!=0) && (BildTyp!=0) && (BildTyp!=4))
                              { ok1=create_ppm("barcode.tmp",OutputString,ywert); }
  if ((ok1!=-1) && (BildTyp==1)) { char maches[200];
                                 strcpy(maches,"ppmtogif < barcode.tmp > ");  
                                 strcat(maches,Ausgabedatei); 
                                 strcat(maches," 2>/dev/null"); ok1=system(maches); }
  if ((ok1!=-1) && (BildTyp==2)) {  char maches[200];
                                 strcpy(maches,"ppmtopcx  < barcode.tmp > ");  
                                 strcat(maches,Ausgabedatei); 
                                 strcat(maches," 2>/dev/null"); ok1=system(maches); }                                      
  if ((ok1!=-1) && (BildTyp==3)) {  char maches[200];
                                 strcpy(maches,"ppmtopgm < barcode.tmp > ");  
                                 strcat(maches,Ausgabedatei); 
                                 strcat(maches," 2>/dev/null"); ok1=system(maches); }

  if ((ok1==-1) && (ok!=0)) 
  {
    xv_create(panel,NOTICE,
	XV_SHOW,TRUE,
	NOTICE_LOCK_SCREEN,TRUE,
	NOTICE_MESSAGE_STRINGS,ErrText3,NULL,
	NOTICE_BUTTON_YES,LabelButtonOK,
	NULL);
  }
  } 

}
