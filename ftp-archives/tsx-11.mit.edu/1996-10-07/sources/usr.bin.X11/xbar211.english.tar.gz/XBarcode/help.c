
#define HELP_G
#include "help.h"
#include "german.h"

void HelpCopyright()
{
HelpSubframe(MsgHelpCopyright);
}                                             

void HelpEan()
{
HelpSubframe(MsgEan);
}

void HelpUpc()
{
HelpSubframe(MsgUpc);
}

void Help2of5()
{
HelpSubframe(MsgCode25);
}

void HelpCodabar()
{
HelpSubframe(MsgCode);        
}

void Help3of9()
{
HelpSubframe(Msg39);
}

void HelpCode128()
{
HelpSubframe(MsgCode128);
}
