#define ButtonLabelQuit    "End"
#define ButtonLabelSave    "Save"
#define ButtonLabelPreview "Preview"
#define ButtonLabelHelp    "Help"
#define MenuLabel1         "Output as   "
#define MenuLabel2         "Barcode type"
#define LabelBreite        "Width"
#define LabelHoehe         "Height"
#define LabelCode          "Code"
#define LabelDatei         "File"
#define LabelMenu3         "Help"
#define ErrText1           "Barcode not identified"
#define ErrText2           "Please choose HELP"
#define LabelButtonOK      "OK"
#define ErrText3           "Barcode not saved"
#define MOptionen          "OPTION:"
#define MTypen             "Barcodes     "
#define MAusgabeTypn       "Output as    "
#define MBig		   "size         "
#define Copyright          "Copyright    "
#define Hilfen             "Help         "
#define ErrText4           "\n to little Parameters, -HELP to get further information \n "
#define ErrText5           "\nX-value not correct !\n"
#define ErrText6           "\nY-value not correct !\n"
#define ErrText7           "No input data from standart input"
#define ErrText8           "Code not identifed \n"
#define Bsp                "\neg: Barcodetext from standart input / PPM file will be sent to standart output"
#define Cpy                "P3 \n# Barcode erzeugt von XBarcode 2.11 \n# (c) by Martin Bauer & Jan Laitenberger \n"

#define MsgHelpCopyright   "
XBarcode 2.11

This program is FREEWARE. It is unsaleable.

The sourcecode is RESTRICTED to change !

If there are any more questions:

Martin Bauer
Zeppelinstr. 97
70193 Stuttgart
Tel. 0711 6362008

Jan Laitenberger
Hauptmannsreute 166
70193 Stuttgart

***********************************
Internet-Adresse:
Martin_Bauer@S2.MAUS.DE
***********************************
"
#define MsgEan "
EAN 13 - EAN 12 - EAN 8

Used in    : Europe
Chars      : 0..9
Codelength : 7+1,12+1 

EAN 12:  You have to enter 12 chars. The 13th char
         would automatically be added.

EAN 13:  You have to enter 13 chars. The 13th char
         (first position left hand) MUST be correct.
         Otherwise the barcode would be misinterpreted. 
         The barcode will be processed even if the 13th 
         char is false !
EAN 8:   You may enter 7 or 8 chars.
         If you entered 7 chars the 8th char
         would be calculated. If you enter 8 chars
         the 8th char MUST be correct. Otherwise the 
         barcode would be misinterpreted. The barcode 
         will be processed even if the 13th char is 
         false !
"
#define MsgUpc "
UPC

Used         : in the USA
Chars        : 0..9
Codelenght   : 11+1 

If you enter only 11 chars the proofsymbol
would be processed automatically. 

If you enter 12 chars the 12th char MUST be correct. 
Otherwise the barcode would be misinterpreted. 
The barcode will be processed even if the 12th char is  
false !
"

#define MsgCode "
Codabar

Char       : A..E 0..9 +-*/=$.TN
Codelength : 15 <= chars

There are known start/stopsymbols: A B C D
The whole code will be alterated !!
Please insure that the start/stopsymbols are in
the correct positions. 

e.g: A1234D      => Output: 1234
e.g: A4444D1111A => Output: 4444 (taken from the left  side)
                    Output: 1111 (taken from the right side)
"
#define Msg39 "
Code 3 of 9 (Barcode 39)

Chars      : A..Z 0..9 +-/.% Space $'
Codelength : 15 <= chars
"


#define MsgCode25 "
Code 2/5 (Non-/Interleaved, Matrix)

Chars      : 0..9
Codelength : 15 <= chars

Code 25 Interleaved: 
straight sum of chars, e.g. : 2,4,6,8,10,12,14
"
#define MsgCode128 "
Code 128
 
Chars      : Ascii-Code (0..127)
Codelength : 13 <= chars

Code 128 A  = starts with A-code-symbols
Code 128 B  = starts with B-code-symbols

When all the chars are not given there is always a 
chance to restore them through the ESCAPE-code button.

Escape-Codechar: #
Bsp:
##   => # is produced
#CR  => Ascii(13) is produced
#NUL => Ascii(0) is produced

List of all Symbols:
00=NUL  07=BEL  14=SO   21=NAK  28=FS
01=SOH  08=BS   15=SI   22=SYN  29=GS
02=STX  09=AT   16=DLE  23=ETB  30=RS
03=ETX  10=LF   17=DC1  24=CAN  31=US
04=EOT  11=VT   18=DC2  25=EM
05=ENQ  12=FF   19=DC3  26=SUB  FNC1...FNC4 are
06=ACK  13=CR   20=DC4  27=ESC  reserved keycodes
                                  
"

