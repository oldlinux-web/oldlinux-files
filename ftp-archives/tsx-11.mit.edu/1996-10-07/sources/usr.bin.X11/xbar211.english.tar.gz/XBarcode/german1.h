#define ButtonLabelQuit    "Ende"
#define ButtonLabelSave    "Sichern"
#define ButtonLabelPreview "Vorschau"
#define ButtonLabelHelp    "Hilfe"
#define MenuLabel1         "Ausgabe als"
#define MenuLabel2         "Barcode Typ"
#define LabelBreite        "Breite"
#define LabelHoehe         "Hoehe"
#define LabelCode          "Code"
#define LabelDatei         "Dateiname"
#define LabelMenu3         "Hilfe"
#define ErrText1           "Barcode konnte nicht erzeugt werden"
#define ErrText2           "Bitte HILFE anwaehlen"
#define LabelButtonOK      "OK"
#define ErrText3           "Barcode konnte nicht abgespeichert werden"
#define MOptionen          "OPTIONEN:"
#define MTypen             "Barcode-Typen"
#define MAusgabeTypn       "AusgabeTypen "
#define MBig		   "Groessen     "
#define Copyright          "Copyright    "
#define Hilfen             "Hilfen       "
#define ErrText4           "\n zuwenige Parameter, -HELP fuer Hilfe verwenden  \n "
#define ErrText5           "\nX-Wert nicht korrekt !\n"
#define ErrText6           "\nY-Wert nicht korrekt !\n"
#define ErrText7           "Keine Eingabedaten von Standart-Input vorhanden "
#define ErrText8           "Code konnte nicht umgewandelt werden , sorry \n"
#define Bsp                "\nBarcode-Text wird vom Standart-Input gelesen und nach Standart-Output geschrieben"
#define Cpy                "P3 \n# Barcode erzeugt von XBarcode 2.11 \n# (c) by Martin Bauer & Jan Laitenberger \n"

#define MsgHelpCopyright   "
XBarcode 2.11

Dieses Programm ist FREEWARE. Es kann
weitergegeben, jedoch nicht verkauft werden.

Der Source-Code darf nicht in veraenderter
Form weitergegeben werden.

Bei Fragen oder Anregungen:

Martin Bauer
Zeppelinstr. 97
70193 Stuttgart
Tel. 0711 6362008

Jan Laitenberger
Hauptmannsreute 166
70193 Stuttgart

***********************************
Internet-Adresse:
Martin_Bauer@S2.MAUS.DE
***********************************
"
#define MsgEan "
EAN 13 - EAN 12 - EAN 8

Verwendung: in Europa
Zeichenvorrat: 0..9
Codelaenge 7+1,12+1 Zeichen

EAN 12:  Es muessen 12 Zeichen eingegeben werden,
         wobei das erste als Pruefzeichen auto-
         matisch berechnet und eingefuegt wird.
EAN 13:  Es muessen 13 Zeichen eingegeben werden,
         wobei das erste Zeichen (Pruefzeichen)
         NICHT auf Korrektheit Ueberprueft wird.
         Einige Barcodeleser vermoegen auch Barcodes
         mit fehlerhaften Pruefzeichen zu lesen.
EAN 8:   Es koennen 7 oder 8 Zeichen angegeben
         werden.
         Werden 7 Zeichen angegeben, so wird das
         Pruefzeichen automatisch berechnet.
         Wenn 8 Zeichen angegeben werden, sollte
         das Pruefzeichen korrekt sein.
"
#define MsgUpc "
UPC

Verwendung: in den USA
Zeichenvorrat: 0..9
Codelaenge 11+1 Zeichen

Wenn nur 11 Zeichen angegeben werden, wird das
Pruefzeichen automatisch berechnet.

Wenn Sie 12 Zeichen angeben, muessen Sie dafuer
sorgen, dass das Pruefzeichen korrekt ist.
"
#define MsgCode "
Codabar

Zeichenvorrat: A..E 0..9 +-*/=$.TN
Codelaenge: maximal 15 Zeichen

Es gibt folgende Start/Stopsymbole: A B C D
Es wird der Ausdruck KOMPLETT umgewandelt.
Sie muessen dafuer sorgen, dass die
Start/Stopzeichen korrekt sitzen.

BSP: A1234D      => Zahl: 1234
BSP: A4444D1111A => Zahl: 4444 (von links  gelesen)
                    Zahl: 1111 (von rechts gelesen)
"
#define Msg39 "
Code 3 of 9 (Barcode 39)

Zeichenvorrat: A..Z 0..9 +-/.% Space $'
Codelaenge: maximal 15 Zeichen
"


#define MsgCode25 "
Code 2/5 (Non-/Interleaved, Matrix)

Zeichenvorrat: 0..9
Codelaenge: maximal 15 Zeichen

Code 25 Interleaved: GERADE Anzahl von Zeichen,
also moegliche Codelaengen: 2,4,6,8,10,12,14
"
#define MsgCode128 "
Code 128
 
Zeichenvorrat: kompletter Ascii-Code (0..127)
Codelaenge: maximal 13 Zeichen

Code 128 A = es wird mit dem Zeichensatz A begonnen
Code 128 B = es wird mit dem Zeichensatz B begonnen

Da nicht alle Zeichen eingegeben werden koennen gibt
es die Moeglichkeit ueber Escape-codes diese Zeichen
in Form von Symbolen einzugeben.

Escape-Codezeichen: #
Bsp:
##   => # wird erzeugt
#CR  => Ascii(13) wird erzeugt
#NUL => Ascii(0) wird erzeugt

Liste aller Symbole:
00=NUL  07=BEL  14=SO   21=NAK  28=FS
01=SOH  08=BS   15=SI   22=SYN  29=GS
02=STX  09=AT   16=DLE  23=ETB  30=RS
03=ETX  10=LF   17=DC1  24=CAN  31=US
04=EOT  11=VT   18=DC2  25=EM
05=ENQ  12=FF   19=DC3  26=SUB  FNC1...FNC4 sind
06=ACK  13=CR   20=DC4  27=ESC    reservierte
                                  Steuerzeichen
"

