/*
** xclk.c - X Mode Database calculator.
**
**	Satish Kumar Chittamuru
**	satishc@microsoft.com
**	25-Jun-1992
**
** This helper program is written based on the suggestions in Chin Fang's
** video tutorial. The tutorial gives various heuristic's i.e. rules of
** Le-Thumb. I have tried to be as close to these rules as possible. There
** is nothing really holy about the constants used. They are the values
** "normally" encountered. So we use them to determine an acceptable
** resolution. When in doubt, I have erred on the side of caution. So you
** might see that the resolution you get from this is lower than what you
** expect. But the intent of this program is to help you get-up-and-running
** rather than determine the best possible combination of values. It is
** ofcourse possible to generate perfectly absurd result since it relies
** on several thumb-rules and since it doesn' check for `proper' result.
**
** You want an ideal, max, perfect resolution? Then you shouldn't be
** bothering with this program. You should do the calcs manually and
** use your judgement in manipulating the values.
**
** The Video Tutorial doc says that the final H values have to be multiples
** of 8, which is why you will see some rounding up/down to the nearest
** multiple.
**
** If you compile this program without the -DDEBUG option, you will get
** a 2 line output on STDOUT that can directly be entered into the ModeDB
** section of Xconfig. You just need to edit the Modes line in Xconfig
** to add the resulting resolution and ensure that the clock value output
** is indeed one of the values on the Clocks line.
**
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define	MIN_H_SYNC	3.5	/* MicroSeconds */
#define MAX_H_SYNC	4.0	/* MicroSeconds */
#define AVG_H_SYNC	3.8	/* MicroSeconds */
#define H_SYNC_SEP	32	/* in ticks. Generally the sync seperation */
				/* is of the order of 30 clks. We choose   */
				/* the nearest multiple of 8 */

#define VF_2_VV		1.05	/* the VFrame to VView ratio */
#define MIN_V_SYNC	50.0e-6		/* seconds */
#define MAX_V_SYNC	300.0e-6	/* seconds */
#define AVG_V_SYNC	150.0e-6	/* seconds */

#define ROUND_UP8(x)	(((int)(x+7)/8)*8)
#define ROUND_DOWN8(x)	(((int)(x)/8)*8)


void Clk_HF_Calc( float Clock, int HFrame )
{
    int HView, VFrame, VView;
    int HSyncMin, HSyncAvg, HDiff, HNeed, HSyncBegin, HSyncEnd;
    int VSync, VSyncTicks;
    float Refresh, HLineTime;

/*    HFrame = (int)( (Clock*1.0e6) / (HFreq*1.0e3) ); */
	/* Since all the values will eventually be recalibrated, we won't*/
	/* bother about rounding the initial values to be multiples of 8 */

    	/* Viewable size is usually ~80% of total frame size */
    HView = ( HFrame * 8 )/10;
    	/* aspect ration is normally 4:3 */
    VView = ( HView * 3 )/4;
    VFrame = (int)( ((float)VView) * VF_2_VV + 0.5 );

    Refresh = (Clock * 1.0e6) / (HFrame * VFrame);  /* an initial estimate */

#ifdef DEBUG
    printf( "Initial:\t HV %d HF %d VV %d VF %d\n",
			 HView, HFrame, VView, VFrame );
    printf( "Initial refresh: %5.2f\n", Refresh );
#endif

    HSyncMin = (int)( Clock * MIN_H_SYNC );
    HSyncAvg = (int)( Clock * AVG_H_SYNC );

	/* The config docs suggests adjusting both HView and HFrame */
	/* However, since we are close to the max of the specified  */
	/* frequencies, we will play safe and reduce HView only */
    while( ( HDiff = (HFrame - HView) ) < HSyncAvg )
	HView -= 8;

#ifdef DEBUG
	printf( "HSyncAvg re-cal: HV %d HF %d HSAvg %d HSMin %d\n",
					 HView, HFrame, HSyncAvg, HSyncMin );
#endif

    if( (HSyncMin+2*H_SYNC_SEP) > HDiff ) { 
	    /* we have to allow for seperation on either side of the sync */
        HNeed = ROUND_UP8( (HSyncMin + 64 - HDiff) );
	if( Refresh > 72 )
		/* Since refresh is greater than 72Hz we can afford to */
		/* reduce it a little and maintain our resolution      */
	    HFrame += HNeed;
        else if( Refresh > 67 ) {
		/* Since refresh is greater than 67Hz we will tweak   */
		/* HFrame the most and we will tweak HView a li'l bit */
	    if( HNeed < 32 )
	    	HFrame += HNeed;
	    else {
	        HFrame  += 32;
	        HView   -= (HNeed - 32);
	    }		
        }
	else if( Refresh > 63 ) {
		/* Since refresh is less than 67Hz we will    */
		/* tweak HView the most and HFrame a li'l bit */
	    if( HNeed < 32 )
	    	HView -= HNeed;
	    else {
	        HView  -= 32;
	        HFrame += (HNeed - 32);
	    }		
	}
        else    /* Refresh is less than 60 so we should only tweak HView */
            HView -= HNeed;	
    }
	/* Now we make them multiples of 8 */
    HFrame = ROUND_UP8( HFrame );
    HView  = ROUND_DOWN8( HView );
    HSyncBegin = HView + 32;
    HSyncEnd   = HFrame - 32;

#ifdef DEBUG
	printf( "HSyncMin re-cal: HV %d HSB %d HSE %d HF %d\n",
				 HView, HSyncBegin, HSyncEnd, HFrame );
#endif

    if( (HSyncEnd - HSyncBegin) < HSyncMin ) {
    	    /* sanity check */
        fprintf( stderr, "Hmm!... Horizontal sync is too small... quiting\n" );
        exit( -1 );
    }
    
    VView = ( HView * 3 )/4;
    VFrame = ( (float)VView * VF_2_VV + 0.5 );
    HLineTime = HView / (Clock * 1.0e6);
    VSyncTicks = (int)( AVG_V_SYNC / HLineTime + 0.5 );
    VSync = VView + VSyncTicks;

#ifdef DEBUG
	printf( "VSync calibrate: HL-time %8.2e VV %d VF %d VS-ticks %d\n",
		 HLineTime, VView, VFrame, VSyncTicks );
#endif
    
    Refresh = (Clock * 1e6 ) / (HFrame * VFrame);

    printf( "  \"%1dx%1d\"\t%3d\t%4d %4d %4d %4d\t%4d %4d %4d %4d\n",
		HView, VView, (int)Clock,
    		HView, HSyncBegin, HSyncEnd, HFrame,
    		VView, VView, VSync, VFrame );
    printf( "  # Refresh rate = %5.2fHz ; Horizontal Frequency = %5.2fKHz\n",
            Refresh, (Clock * 1e3 / (float)HFrame) );
    
}


void Clk_HV_Calc( float Clock, int HView )
{
    int HFrame, VFrame, VView;
    int HSyncMin, HSyncAvg, HSync, HDiff, HNeed, HSyncBegin, HSyncEnd;
    int VSync, VSyncTicks;
    float Refresh, HLineTime;

    HView = ROUND_DOWN8( HView );
    VView = ( HView * 3 ) / 4;

    HSync = ROUND_DOWN8( (int)( Clock * AVG_H_SYNC ) );
    HSyncBegin = HView + 32;
    HSyncEnd = HSyncBegin + HSync;
    HFrame = HSyncEnd + 32;

    VFrame = (int)( VView * VF_2_VV + 0.5 );

    HSyncMin = (int)( Clock * MIN_H_SYNC );
    if( HSync < HSyncMin ) {
    	    /* sanity check */
        fprintf( stderr, "Hmm!... Horizontal sync is too small... quiting\n" );
        exit( -1 );
    }
    
    HLineTime = HView / (Clock * 1.0e6);
    VSyncTicks = (int)( AVG_V_SYNC / HLineTime + 0.5 );
    VSync = VView + VSyncTicks;

    Refresh = (Clock * 1e6 ) / (HFrame * VFrame);

    printf( "  \"%1dx%1d\"\t%3d\t%4d %4d %4d %4d\t%4d %4d %4d %4d\n",
		HView, VView, (int)Clock,
    		HView, HSyncBegin, HSyncEnd, HFrame,
    		VView, VView, VSync, VFrame );
    printf( "  # Refresh rate = %5.2fHz ; Horizontal Frequency = %5.2fKHz\n",
            Refresh, (Clock * 1e3 / (float)HFrame ) );
    
}

void Usage( char *PgName )
{
    fprintf( stderr, "Hmm!... Parameters incorrect. Rerun with correct parameters\n" );
    fprintf( stderr, "Usage:\n" );
    fprintf( stderr, "   %s <Clock_Freq> <Horz_Frequency>\n", PgName );
    fprintf( stderr, "   %s -h <Clock_Freq> <Horz_Pixels>\n", PgName );
    fprintf( stderr, "   %s -r <Clock_Freq> <Refresh_Rate>\n", PgName );
    exit(-1);
}


void main( int argc, char *argv[] )
{
    float   Clock, HFreq, Refresh;
    int     HFrame, HView, cParam;
    char   *Arg;
    
    if( argc < 3 || argc > 4 )
        Usage( argv[0] );

    if( argc == 3 ) {
	Clock = atof( argv[ 1 ] );
	HFreq = atof( argv[ 2 ] );
        HFrame = (int)( (Clock*1.0e6) / (HFreq*1.0e3) );
	Clk_HF_Calc( Clock, HFrame );
    }
    else {
        Clock = atof( argv[ 2 ] );
	if( *(Arg = argv[1]) != '-' )
	    Usage( argv[0] );

        if( *(++Arg) == 'h' ) {
	    HView = atof( argv[ 3 ] );
	    Clk_HV_Calc( Clock, HView );
	}
        else if( *Arg == 'r' ) {
            Refresh = atof( argv[ 3 ] );
	    HFrame = (int)sqrt( ( Clock*1e6/Refresh ) / 0.63 );
	    Clk_HF_Calc( Clock, HFrame );
	}
        else
	    Usage( argv[0] );
    }

}
