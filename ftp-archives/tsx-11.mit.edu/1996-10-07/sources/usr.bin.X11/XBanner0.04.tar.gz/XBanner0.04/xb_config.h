/* xb_config.h - some configuration things */

/* if your system does not have bzero uncomment the following line */
/* this is kind of cheating because I don't have any replacement */
#define HAS_BZERO

/* profiling... */
#define PRINT_TIMING
