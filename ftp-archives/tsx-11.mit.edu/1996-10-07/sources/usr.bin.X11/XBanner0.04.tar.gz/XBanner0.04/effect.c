/* our config file... */

#include "xb_config.h"

/* C library includes */
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <malloc.h>

/* X11 include(s) */
#include <X11/Xlib.h>
#include <X11/Xutil.h>

/* our include */
#include "xbanner.h"

/* global vars for this file */
static XImage *scrimg;
static unsigned char *ZImage;
static unsigned char *FImage;

static unsigned xi_x_orig,xi_y_orig,xi_width,xi_height;

void GetXImage(void)
{
  /*
     lbear can be negative. It is the distance along the X axis from the
     origin to the leftmost pixel in the charcter or in the font. For italics
     it is usually negative. I learned this on the letter L...
  */
  xi_x_orig = final_x-(Thickness+1)+lbear;
  xi_y_orig = final_y-fasc-(Thickness+1);
  xi_width  = bwid+2*Thickness+2;	/* bwid      + 2*(Thickness+1) */
  xi_height = fasc+fdsc+2*Thickness+2;	/* fasc+fdsc + 2*(Thickness+1) */

  scrimg = XGetImage(disp,rootwin,
  	xi_x_orig, xi_y_orig,
  	xi_width,  xi_height,
  	0xffffffff,ZPixmap);
  if(scrimg==NULL)
  {
    fprintf(stderr,"Could not get XImage of the screen\n");
    exit(1);
  }

  /* Allocate memory for the height map and filter area */

  ZImage = (unsigned char*)calloc(xi_width*xi_height,1);
  if(ZImage==NULL)
  {
    fprintf(stderr,"Could not allocate ZImage buffer\n");
    exit(1);
  }
  if(effect != POPART)		/* PopArt does not need it! */
  {
    FImage = (unsigned char*)calloc(xi_width*xi_height,1);
    if(FImage==NULL)
    {
      fprintf(stderr,"Could not allocate FImage buffer\n");
      exit(1);
    }
  }
}

void PutXImage(void)
{
  XPutImage(disp,rootwin,mgc,scrimg,0,0,xi_x_orig,xi_y_orig,xi_width,xi_height);
  /* we don't need it after we put it back... */
  XDestroyImage(scrimg);
  free(ZImage);
  free(FImage);
}

/* the type parameter chooses between 2 different effects */
void DoStandOut(void)
{
  int x,y;		/* iterators */
  Pixel fgc,shdc,lghtc;
  int swid = Thickness;
  int hgt=swid+1;	/* start at height Thickness + 1 for fgc */
  int n,khgt;
  int neighbors[8] = { -xi_width-1, -xi_width, -xi_width+1, -1, 1, xi_width-1, xi_width, xi_width+1 };
  int xsum,ysum,sum;

  fgc   = xfgc.pixel;	/* for ease of use */
  shdc  = xshdc.pixel;
  lghtc = xlghtc.pixel;
  
  khgt=hgt;	/* keep hgt */
  
  for(y=0 ; y < xi_height ; y++)
  {
    for(x=0 ; x < xi_width ; x++)
    {
      if(XGetPixel(scrimg,x,y)==fgc)
        ZImage[x+y*xi_width]=hgt;
      else
        ZImage[x+y*xi_width]=0;
    } /* x iter */
  } /* y iter */

  for(;swid>0;swid--)
  {
    for(y=0 ; y < xi_height ; y++)
    {
      for(x=0 ;	x < xi_width ; x++)
      {
	if (ZImage[x+xi_width*y] == hgt)
	{
          for(n=0;n<8;n++)
          {
            if( ZImage[x+xi_width*y+neighbors[n]] == 0 )
              ZImage[x+xi_width*y+neighbors[n]]=hgt-1;
          } /* n iter */
	}
      } /* x iter */
    } /* y iter */
    hgt--;
  } /* swid iter */

  for(y=0 ; y < xi_height ; y++)
  {
    for(x=0 ; x < xi_width ; x++)
    {
      if( ZImage[x+xi_width*y] == 0 )
        continue;
      sum=2*ZImage[x+xi_width*y];
      for(n=0;n<8;n++)
        sum+=ZImage[x+xi_width*y+neighbors[n]];
      FImage[x+xi_width*y]=sum;
    } /* x iter */
  } /* y iter */

  for(y=0 ; y < xi_height ; y++)
  {
    for(x=0 ; x < xi_width ; x++)
    {
      if( ZImage[x+xi_width*y] == khgt ||	/* !interesting pixel */
          ZImage[x+xi_width*y] == 0 )
        continue;
      /*
         note: xsum is done on left and right pixel while ysum on pixels
               in neighboring rows
      */
      xsum=FImage[x+(xi_width*y)-1]-FImage[x+(xi_width*y)+1];
      ysum=FImage[x+xi_width*(y-1)]-FImage[x+xi_width*(y+1)];
      if(xsum > (-ysum))
        XPutPixel(scrimg,x,y,shdc);
      else
        XPutPixel(scrimg,x,y,lghtc);
    } /* x iter */
  } /* y iter */
} /* StandOut Effect */

void DoCoinEffect(void)
{
  int x,y;		/* iterators */
  Pixel fgc,shdc,lghtc;
  int swid = Thickness;
  int hgt=swid+1;	/* start at height Thickness+1 */
  int n,khgt;
  int neighbors[8] = { -xi_width-1, -xi_width, -xi_width+1, -1, 1, xi_width-1, xi_width, xi_width+1 };
  int xsum,ysum,sum;

  fgc   = xfgc.pixel;	/* for ease of use */
  shdc  = xshdc.pixel;
  lghtc = xlghtc.pixel;
  
  khgt=hgt;	/* keep hgt */
  
  for(y=0 ; y < xi_height ; y++)
  {
    for(x=0 ; x < xi_width ; x++)
    {
      if(XGetPixel(scrimg,x,y)==fgc)
        ZImage[x+y*xi_width]=hgt;
      else
        ZImage[x+y*xi_width]=0;
    } /* x iter */
  } /* y iter */
  
  for(;swid>0;swid--)
  {
    for(y=0 ; y < xi_height ; y++)
    {
      for(x=0 ; x < xi_width ; x++)
      {
	if (ZImage[x+xi_width*y] == hgt)
	{
          for(n=0;n<8;n++)
          {
            if( ZImage[x+xi_width*y+neighbors[n]] == 0 )
              ZImage[x+xi_width*y+neighbors[n]]=hgt-1;
          } /* n iter */
	}
      } /* x iter */
    } /* y iter */
    hgt--;
  } /* swid iter */

  for(y=0 ; y < xi_height ; y++)
  {
    for(x=0 ; x < xi_width ; x++)
    {
      if( ZImage[x+xi_width*y] == khgt ||	/* !interesting pixel */
          ZImage[x+xi_width*y] == 0)	/* ZImage is initialized properly */
        continue;
      sum=ZImage[x+xi_width*y];
      for(n=0;n<8;n++)
        sum+=ZImage[x+xi_width*y+neighbors[n]];
      FImage[x+xi_width*y]=sum;
    } /* x iter */
  } /* y iter */

  for(y=0 ; y < xi_height ; y++)
  {
    for(x=0 ; x < xi_width ; x++)
    {
      if( ZImage[x+xi_width*y] == khgt ||	/* !interesting pixel */
          ZImage[x+xi_width*y] == 0 )
        continue;
      /*
         note: xsum is done on left and right pixel while ysum on pixels
               in neighboring rows
      */
      xsum=FImage[x+(xi_width*y)-1]-FImage[x+(xi_width*y)+1];
      ysum=FImage[x+xi_width*(y-1)]-FImage[x+xi_width*(y+1)];
      if(xsum > (-ysum))
        XPutPixel(scrimg,x,y,shdc);
      else
        XPutPixel(scrimg,x,y,lghtc);
    } /* x iter */
  } /* y iter */
} /* Coin Effect */

void DoPopArt(void)	/* wierd name for the effect eh? */
{
  int x,y;		/* iterators */
  Pixel fgc,shdc,lghtc;
  int hgt=Thickness+1;	/* start at height Thickness+1 */
  int swid = Thickness;
  int n;
  int neighbors[8] = { -xi_width-1, -xi_width, -xi_width+1, -1, 1, xi_width-1, xi_width, xi_width+1 };
  int xadd[8] = { -1,  0,  1, -1, 1, -1, 0, 1 };
  int yadd[8] = { -1, -1, -1,  0, 0,  1, 1, 1 };

  fgc   = xfgc.pixel;	/* for ease of use */
  shdc  = xshdc.pixel;
  lghtc = xlghtc.pixel;
  
  for(y=0 ; y < xi_height ; y++)
  {
    for(x=0 ; x < xi_width ; x++)
    {
      if(XGetPixel(scrimg,x,y)==fgc)
        ZImage[x+y*xi_width]=hgt;
      else
        ZImage[x+y*xi_width]=0;
    } /* x iter */
  } /* y iter */
  
  for(;swid>0;swid--)
  {
    for(y=0 ; y < xi_height ; y++)
    {
      for(x=0 ; x < xi_width ; x++)
      {
	if (ZImage[x+xi_width*y] == hgt)
	{
          for(n=0;n<8;n++)
          {
            if( ZImage[x+(xi_width*y)+neighbors[n]] == 0 )
            {
              ZImage[x+xi_width*y+neighbors[n]]=hgt-1;
	      XPutPixel(scrimg,x+xadd[n],y+yadd[n],(hgt&1?lghtc:shdc));
            }
          } /* n iter */
	}
      } /* x iter */
    } /* y iter */
    hgt--;
  } /* swid iter */
}

/* draw the main thing... the FG one - no shadows and stuff */
void DrawFG(void)
{
  XSetForeground(disp,mgc,xfgc.pixel);
  XDrawString(disp,rootwin,mgc,final_x,final_y,BANNER,strlen(BANNER));
}

void DrawIt(void)
{
  XColor tmp;
  
  switch(effect)
  {
    case NONE:
      DrawFG();
      break;
    case SHADOW:
      XSetForeground(disp,mgc,xshdc.pixel);
      XDrawString(disp,rootwin,mgc,
      			final_x+SHD_X_OFFSET,
      			final_y+SHD_Y_OFFSET,
      			BANNER,strlen(BANNER));
      DrawFG();
      break;
    case OUTLINE:
      XSetForeground(disp,mgc,xshdc.pixel);
      for(i=SUR_MIN;i<SUR_MAX+1;i++)
        for(j=SUR_MIN;j<SUR_MAX+1;j++)
          XDrawString(disp,rootwin,mgc,
          		final_x+i,final_y+j,BANNER,strlen(BANNER));
      DrawFG();
      break;
    case SHADOUTL:
      XSetForeground(disp,mgc,xshdc.pixel);
      for(i=SUR_MIN;i<SUR_MAX+1;i++)
        for(j=SUR_MIN;j<SUR_MAX+1;j++)
          XDrawString(disp,rootwin,mgc,
          		final_x+i+SHD_X_OFFSET,
          		final_y+j+SHD_Y_OFFSET,
          		BANNER,strlen(BANNER));
      XSetForeground(disp,mgc,xlghtc.pixel);
      for(i=SUR_MIN;i<SUR_MAX+1;i++)
        for(j=SUR_MIN;j<SUR_MAX+1;j++)
          XDrawString(disp,rootwin,mgc,
          		final_x+i,final_y+j,BANNER,strlen(BANNER));
      DrawFG();
      break;
    case SHD3D:
      for(t=SHD3D_SHADOWS ; t>0 ; t--)
      {
        XSetForeground(disp,mgc,xshdc.pixel);
        for(i=SUR_MIN;i<SUR_MAX+1;i++)
          for(j=SUR_MIN;j<SUR_MAX+1;j++)
            XDrawString(disp,rootwin,mgc,
            	final_x+i+(t*SHD_X_OFFSET),
            	final_y+j+(t*SHD_Y_OFFSET),
            	BANNER,strlen(BANNER));
        XSetForeground(disp,mgc,xfgc.pixel);
        XDrawString(disp,rootwin,mgc,
       		final_x+(t*SHD_X_OFFSET),
       		final_y+(t*SHD_Y_OFFSET),
       		BANNER,strlen(BANNER));
      }
      XSetForeground(disp,mgc,xlghtc.pixel);
      for(i=SUR_MIN;i<SUR_MAX+1;i++)
        for(j=SUR_MIN;j<SUR_MAX+1;j++)
          XDrawString(disp,rootwin,mgc,final_x+i,final_y+j,BANNER,strlen(BANNER));
      DrawFG();
      break;
    case SHD3D_FANCY:
      for(t=Thickness ; t>0 ; t-=1)
      {
        XSetForeground(disp,mgc,xshdc.pixel);
        XDrawString(disp,rootwin,mgc,
        	final_x+t+SUR_MIN,
        	final_y+t+SUR_MAX,
        	BANNER,strlen(BANNER));
        XDrawString(disp,rootwin,mgc,
        	final_x+t+SUR_MAX,
        	final_y+t+SUR_MIN,
        	BANNER,strlen(BANNER));
        XDrawString(disp,rootwin,mgc,
        	final_x+t+SUR_MIN,
        	final_y+t+SUR_MIN,
        	BANNER,strlen(BANNER));
        XDrawString(disp,rootwin,mgc,
        	final_x+t+SUR_MAX,
        	final_y+t+SUR_MAX,
        	BANNER,strlen(BANNER));
      }
      XSetForeground(disp,mgc,xlghtc.pixel);
      for(i=SUR_MIN;i<SUR_MAX+1;i++)
        for(j=SUR_MIN;j<SUR_MAX+1;j++)
          XDrawString(disp,rootwin,mgc,final_x+i,final_y+j,BANNER,strlen(BANNER));
      DrawFG();
      break;
    case STANDIN:	/* StandIn will be an opposite of StandOut by simply switching the colors... */
      tmp.pixel    = xlghtc.pixel;	/* swap pixel values */
      xlghtc.pixel = xshdc.pixel;
      xshdc.pixel  = tmp.pixel;
      /* notice that there is no break statement here on purpose! */
    case STANDOUT:
      DrawFG();		/* draw the FG so we can search what to do to it */
      GetXImage();
      DoStandOut();	/* scan the image and add the shadowed outline */
      PutXImage();
      break;
    case POPART:
      DrawFG();
      GetXImage();
      DoPopArt();
      PutXImage();
      break;
    case COIN:
      DrawFG();
      GetXImage();
      DoCoinEffect();
      PutXImage();
      break;
  }
}

void AllocColors(void)
{
  int status;
  /* start by allocating the colors */
  if(FGCOLOR[0]!='#')
  {
    status = XAllocNamedColor(disp,cmap,FGCOLOR,&xfgc,&xexact);
  }
  else	/* allocate by RGB! */
  {
    AtoXColor(FGCOLOR,&xfgc);
    status = XAllocColor(disp,cmap,&xfgc);
  }
  if(!status)
  {
    fprintf(stderr,"Could not get the fg color...\n");
    XCloseDisplay(disp);
    exit(1);
  }

  if(SHDCOLOR[0]!='#')
  {
    status = XAllocNamedColor(disp,cmap,SHDCOLOR,&xshdc,&xexact);
    if(!status)
    {
      fprintf(stderr,"Could not get the shadow color...\n");
      XCloseDisplay(disp);
      exit(1);
    }
  }
  else	/* allocate by RGB! */
  {
    AtoXColor(SHDCOLOR,&xshdc);
    status = XAllocColor(disp,cmap,&xshdc);
  }

  if(LGHTCOLOR[0]!='#')
  {
    status = XAllocNamedColor(disp,cmap,LGHTCOLOR,&xlghtc,&xexact);
    if(!status)
    {
      fprintf(stderr,"Could not get the highlight color...\n");
      XCloseDisplay(disp);
      exit(1);
    }
  }
  else	/* allocate by RGB! */
  {
    AtoXColor(LGHTCOLOR,&xlghtc);
    status = XAllocColor(disp,cmap,&xlghtc);
  }
}

