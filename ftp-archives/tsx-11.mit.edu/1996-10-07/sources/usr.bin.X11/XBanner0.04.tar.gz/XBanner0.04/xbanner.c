/* our config file */

#include "xb_config.h"

/* C library includes */
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

/* X11 include(s) */
#include <X11/Xlib.h>

#include "xbanner.h"

char BANNER[MAX_BANNER_LEN] = BANNER_DEFVAL;

int  XDEFOFFSET       = XOFFSET_DEFVAL;
int  YDEFOFFSET       = YOFFSET_DEFVAL;
int  SHD_X_OFFSET     = SHDXOFFS_DEFVAL;
int  SHD_Y_OFFSET     = SHDYOFFS_DEFVAL;
char FGCOLOR[CNLEN]   = FGCOL_DEFVAL;
char SHDCOLOR[CNLEN]  = SHDCOL_DEFVAL;
char LGHTCOLOR[CNLEN] = LGHTCOL_DEFVAL;

char FONTN[256] = FONT_DEFVAL;

int SUR_MIN = SURMIN_DEFVAL;
int SUR_MAX = SURMAX_DEFVAL;

int Thickness = THICKNESS_DEFVAL;

int SHD3D_SHADOWS = SHD3DSHADOWS_DEFVAL;

/* no more defines */

Display        *disp;
GC		mgc;
Colormap	cmap;
XColor		xfgc,xshdc,xlghtc,xexact;
Pixmap		rootwin;

int sc_w,sc_h;			/* screen width/height			*/
int dir,fasc,fdsc,lbear;	/* font ascent/descent/dir/lbearing	*/
int bwid;			/* banner pixel width			*/
int final_x,final_y;		/* where the text will finally appear	*/
Placement placement = PLACEMENT_DEFVAL;
Effect effect = EFFECT_DEFVAL;

int i,j,t;
char OPTFILE[128];

/* this will be our display string */
char *DISP = NULL;

/* no more global vars */

/* allowed options in config file */
char *option_keyword[] =
{
  "x", "y", "Placement", "Effect", "Font", "Foreground", "ShadowColor",
  "Label", "XdefOffset", "YdefOffset", "Shadows", "Surround_Min",
  "Surround_Max", "HiColor", "ShadowXoffset", "ShadowYoffset", "Thickness",
  NULL
};

/* effect names */
char *effect_keyword[] =
{
  "None", "Shadow", "Outline", "Shadowed-Outline", "3D-Shadow", "Fancy-3D",
  "StandOut", "StandIn", "PopArt", "Coin",
  NULL
};

/* placement names */
char *placement_keyword[] =
{
  "TopLeft", "TopRight", "BottomLeft", "BottomRight", "TopCenter",
  "BottomCenter", "XY", "Center",
  NULL
};

Bool emptyline(char *s)
{
  char *p=s;

  while(isspace(*p))
    p++;
  if(*p=='#' || *p=='\0' || *p=='\r' || *p=='\n')
    return True;
  return False;
}

void Parse_Optfile(void)
{
  FILE *fin;
  char line[256];
  char *p,opt[20];
  int i,val;

  if(OPTFILE[0]=='\0')
    strcpy(OPTFILE,"/usr/lib/X11/xdm/xbanner-config");

  fin = fopen(OPTFILE,"r");
  if(fin==NULL)
    return;	/* no options file */
  while(fgets(line,255,fin)!=NULL)
  {
    i=0;
    if(emptyline(line)==True)
      continue;
    line[strlen(line)-1]='\0';

    if(strncmpi(line,"Xbanner",7)==0)
      p = line+8;
    else
      p = line;
    while(*p!=':' && i<20)
      opt[i++] = *p++;
    opt[i]='\0';		/* add a null */
    for(i=0;option_keyword[i]!=NULL;i++)
      if(strcmpi(opt,option_keyword[i])==0)
        break;
    if(option_keyword[i]==NULL)
    {
      /* complain and continue */
      fprintf(stderr,"Unknown option '%s'.\n",opt);
      continue;		/* next line... */
    }
    p++;			/* skip the : */
    while(isspace(*p))	/* skip WS */
      p++;
 
    val = atoi(p);	/* convert to bin */

    switch(i)
    {
      case THICKNESS:
        Thickness = val;
        break;
      case X:
	final_x = val;
        break;
      case Y:
	final_y = val;
        break;
      case PLACE:
	for(i=0;placement_keyword[i]!=NULL;i++)
	  if(strcmpi(placement_keyword[i],p)==0)
	    break;
	if(placement_keyword[i]==NULL)
	{
	  fprintf(stderr,"Unknown placement '%s'\n",p);
	  continue;
	}
	placement = i;
        break;
      case EFFECT:
	for(i=0;effect_keyword[i]!=NULL;i++)
	  if(strcmpi(effect_keyword[i],p)==0)
	    break;
	if(effect_keyword[i]==NULL)
	{
	  fprintf(stderr,"Unknown effect '%s'\n",p);
	  continue;
	}
	effect = i;
        break;
      case FONT:
        strcpy(FONTN,p);
        break;
      case FGC:
        strcpy(FGCOLOR,p);
        break;
      case HICOLOR:
        strcpy(LGHTCOLOR,p);
        break;
      case SHDC:
        strcpy(SHDCOLOR,p);
        break;
      case LABEL:
        strcpy(BANNER,p);
        break;
      case XOFFS:
        XDEFOFFSET = val;
        break;
      case YOFFS:
        YDEFOFFSET = val;
        break;
      case SHADOWS:
        SHD3D_SHADOWS = val;
        break;
      case SURMIN:
	SUR_MIN = val;
        break;
      case SURMAX:
        SUR_MAX = val;
        break;
      case SHDXOFFS:
        SHD_X_OFFSET = val;
        break;
      case SHDYOFFS:
        SHD_Y_OFFSET = val;
        break;
    }
  }
  fclose(fin);	/* done! */
}

void CalcXY(void)
{
  if(dir == FontLeftToRight) {		/* left to right text 	*/
    switch(placement)
    {
      case TOPLEFT:
        final_x = XDEFOFFSET;			/* start with that	*/
        final_y = YDEFOFFSET + fasc;		/* make the X/Y thing	*/
        break;
      case TOPRIGHT:
	final_x = sc_w - XDEFOFFSET - bwid;	/* find the X		*/
	final_y = YDEFOFFSET + fasc;     	/* make the X/Y thing   */
        break;
      case BOTLEFT:
	final_x = XDEFOFFSET;
	final_y = sc_h - YDEFOFFSET - fdsc;	/* make sure descenders are OK */
        break;
      case BOTRIGHT:
	final_x = sc_w - XDEFOFFSET - bwid;	/* find the X		*/
	final_y = sc_h - YDEFOFFSET - fdsc;	/* make sure descenders are OK */
        break;
      case TOPCENT:
	final_x = (sc_w / 2) - (bwid / 2);
	final_y = YDEFOFFSET + fasc;     	/* make the X/Y thing   */
        break;
      case BOTCENT:
	final_x = (sc_w / 2) - (bwid / 2);
	final_y = sc_h - YDEFOFFSET - fdsc;	/* make sure descenders are OK */
        break;
      case CENTER:
	final_x = (sc_w / 2) - (bwid / 2);
	final_y = (sc_h / 2) - ( (fasc+fdsc) / 2 );
        break;
      default:
        ;		/* XY placement */
    }
  }
  else		/* direction */
  {
    switch(placement)
    {
      case TOPLEFT:
        final_x = XDEFOFFSET + bwid;		/* start with that	*/
        final_y = YDEFOFFSET + fasc;		/* make the X/Y thing	*/
        break;
      case TOPRIGHT:
	final_x = sc_w - XDEFOFFSET;		/* find the X		*/
	final_y = YDEFOFFSET + fasc;     	/* make the X/Y thing   */
        break;
      case BOTLEFT:
	final_x = XDEFOFFSET + bwid;
	final_y = sc_h - YDEFOFFSET - fdsc;	/* make sure descenders are OK */
        break;
      case BOTRIGHT:
	final_x = sc_w - XDEFOFFSET;		/* find the X		*/
	final_y = sc_h - YDEFOFFSET - fdsc;	/* make sure descenders are OK */
        break;
      case TOPCENT:
	final_x = (sc_w / 2) - (bwid / 2);
	final_y = YDEFOFFSET + fasc;     	/* make the X/Y thing   */
        break;
      case BOTCENT:
	final_x = (sc_w / 2) - (bwid / 2);
	final_y = sc_h - YDEFOFFSET - fdsc;	/* make sure descenders are OK */
        break;
      default:
        ;		/* XY placement */
    }
  }
}

void CmdLine(int argc, char *argv[])
{
  if((argc==2) && (strcmp(argv[1],"-v")==0))
  {
    fprintf(stderr,"XBanner V%s %s - by amitm@doronx.iso.dec.com (Amit Margalit)\n",
    		VERSION, DATE);
    exit(0);
  }
  if(argc==2 || argc==4 || argc > 5)
  {
    fprintf(stderr,"Usage: xbanner -display <disp> -file <file>\n");
    exit(0);
  }

  if(argc>=3)
  {
    if(strcmpi(argv[1],"-display")==0)
      DISP = argv[2];
    if(strcmpi(argv[1],"-file")==0)
      strcpy(OPTFILE,argv[2]);
  }
  if(argc==5)
  {
    if(strcmpi(argv[3],"-display")==0)
      DISP = argv[4];
    if(strcmpi(argv[3],"-file")==0)
      strcpy(OPTFILE,argv[4]);
  }
}

void AtoXColor(char *color, XColor *xcolor)
{
  int i;
  unsigned short red,green,blue;
  
  color++;		/* skip the # sign */

  for(i=0;color[i]!='\0';i++)
    color[i]=toupper(color[i]) - '0';

  if(i!=6 && i!=12)
  {
    fprintf(stderr,"Must use either of #rrggbb or #rrrrggggbbbb representations.\nYour representation is either too short or too long.\n");
    exit(1);
  }
  
  if(i==6) {	/* #rrggbb representation */
    red =   (color[0]>9?color[0]-7:color[0])*16+
	    (color[1]>9?color[1]-7:color[1]);
    green = (color[2]>9?color[2]-7:color[2])*16+
	    (color[3]>9?color[3]-7:color[3]);
    blue =  (color[4]>9?color[4]-7:color[4])*16+
	    (color[5]>9?color[5]-7:color[5]);
    xcolor->red   = ((red   << 8) | red  );
    xcolor->green = ((green << 8) | green);
    xcolor->blue  = ((blue  << 8) | blue );
  }

  if(i==12)	/* #rrrrggggbbbb representation */
  {
    red =   (color[0] > 9? color[0]-7  :color[0]) *4069+
	    (color[1] > 9? color[1]-7  :color[1]) *256+
	    (color[2] > 9? color[2]-7  :color[2]) *16+
	    (color[3] > 9? color[3]-7  :color[3]);
    green = (color[4] > 9? color[4]-7  :color[4]) *4069+
	    (color[5] > 9? color[5]-7  :color[5]) *256+
	    (color[6] > 9? color[6]-7  :color[6]) *16+
	    (color[7] > 9? color[7]-7  :color[7]);
    blue =  (color[8] > 9? color[8]-7  :color[8]) *4069+
	    (color[9] > 9? color[9]-7  :color[9]) *256+
	    (color[10]> 9? color[10]-7 :color[10])*16+
	    (color[11]> 9? color[11]-7 :color[11]);
    xcolor->red   = red;
    xcolor->green = green;
    xcolor->blue  = blue;
  }
}

int main(int argc, char *argv[])
{
  XFontStruct  *xfont;
  Screen       *scrn;
  int		scrn_no;
  Window	root;
  XCharStruct	xchrs;

  OPTFILE[0]='\0';		/* nullify the options file */

  /* do cmdline opts first */
  CmdLine(argc, argv);
  
  /* do options file... */
  Parse_Optfile();

  disp = XOpenDisplay(DISP);		/* start connection with the display */
  if (disp == NULL)
  {
    fprintf(stderr,"Could not open display...\n");
    exit(1);
  }
  
  scrn = XDefaultScreenOfDisplay(disp);	/* get the default screen	*/
  scrn_no = XDefaultScreen(disp);	/* get the default screen #	*/
  
  root = RootWindow(disp,scrn_no);	/* the root window		*/
  
  sc_w = DisplayWidth(disp,scrn_no);	/* get pixel width of screen	*/
  sc_h = DisplayHeight(disp,scrn_no);	/* get pixel height of screen	*/
  
  mgc = DefaultGC(disp,scrn_no);	/* get the root window GC	*/

  xfont = XLoadQueryFont(disp,FONTN);
  	   
  if(xfont == NULL)
  {
    XCloseDisplay(disp);
    fprintf(stderr,"Could not get the font...\n");
    exit(1);
  }

  cmap = XDefaultColormapOfScreen(scrn);		/* get the colormap */

  AllocColors();

  XSetFont(disp,mgc,xfont->fid);			/* set the font */

  XQueryTextExtents(disp,xfont->fid,BANNER,strlen(BANNER),
  			&dir,&fasc,&fdsc,&xchrs);

  /* set some important global varibles */
  lbear = xchrs.lbearing;
  bwid  = XTextWidth(xfont,BANNER,strlen(BANNER));

  /* make a pixmap */
  rootwin  = XCreatePixmap(disp,root,sc_w,sc_h,DefaultDepth(disp,scrn_no));

  /* copy into the pixmap */
  XCopyArea(disp,root,rootwin,mgc,0,0,sc_w,sc_h,0,0);

  /* now I have all info to put it at any corner of the screen, or if wanted
     also at the center...
  */

  /* calculate the desired X/Y location */
  CalcXY();

  /* draw the effect */
  DrawIt();
  
  /* copy back into the root window */
  XCopyArea(disp,rootwin,root,mgc,0,0,sc_w,sc_h,0,0);

  XFreeFont(disp,xfont);		/* done with this font.. */
  XFreePixmap(disp,rootwin);
  XSetCloseDownMode(disp,RetainTemporary);
  XCloseDisplay(disp);

  return 0;
}
