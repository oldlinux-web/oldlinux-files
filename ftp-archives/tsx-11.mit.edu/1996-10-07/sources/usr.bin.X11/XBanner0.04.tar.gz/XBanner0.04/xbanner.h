/* xbanner.h - header file for xbanner */

#define VERSION "0.04"
#define DATE	"16th March 1996"

/* easier for me to remember them like this */
#define strcmpi(ARG1,ARG2) strcasecmp(ARG1,ARG2)
#define strncmpi(ARG1,ARG2,ARG3) strncasecmp(ARG1,ARG2,ARG3)

/* default values in case no config file is present */

#define BANNER_DEFVAL		"L i n u x !"
#define XOFFSET_DEFVAL		30
#define YOFFSET_DEFVAL		0
#define FGCOL_DEFVAL		"blue"
#define SHDCOL_DEFVAL		"darkblue"
#define LGHTCOL_DEFVAL		"cyan"
#define FONT_DEFVAL		"-bitstream-charter-bold-i-normal--176-*-100-100-*-*-iso8859-1"
#define SURMIN_DEFVAL		-2
#define SURMAX_DEFVAL		2
#define PLACEMENT_DEFVAL	TOPCENT
#define EFFECT_DEFVAL		SHD3D_FANCY
#define SHDXOFFS_DEFVAL		5
#define SHDYOFFS_DEFVAL		5
#define SHD3DSHADOWS_DEFVAL	2
#define THICKNESS_DEFVAL	4

/* misc defines */
#define MAX_BANNER_LEN		256
/* ColorName Len */
#define CNLEN			40

typedef enum {	X, Y, PLACE, EFFECT, FONT, FGC, SHDC, LABEL, XOFFS,
		YOFFS, SHADOWS, SURMIN, SURMAX, HICOLOR, SHDXOFFS,
		SHDYOFFS, THICKNESS } Option;

typedef enum {	NONE, SHADOW, OUTLINE, SHADOUTL, SHD3D, SHD3D_FANCY,
		STANDOUT, STANDIN, POPART, COIN } Effect;

typedef enum {	TOPLEFT, TOPRIGHT, BOTLEFT, BOTRIGHT, 
		TOPCENT, BOTCENT, XY, CENTER }	Placement;

/* pixel definition */
typedef unsigned long Pixel;

/* function prototypes */
Bool emptyline(char *s);  /* if the line is empty */
void Parse_Optfile(void); /* parse the options file */
void CalcXY(void);	  /* calculate location of the text by placement */
void DrawIt(void);	  /* draw the text with the effect */
void DrawFG(void);	  /* draw the main text line */
void CmdLine(int argc, char *argv[]);	/* check for commandline switches */
void AtoXColor(char *color, XColor *xcolor);	/* #rrggbb -> binary repr. */
void AllocColors(void);				/* do the color allocation */

/* extern defines of global variables */
extern char BANNER[];

extern int  XDEFOFFSET;
extern int  YDEFOFFSETL;
extern int  SHD_X_OFFSET;
extern int  SHD_Y_OFFSET;
extern char FGCOLOR[];
extern char SHDCOLOR[];
extern char LGHTCOLOR[];

extern char FONTN[];

extern int SUR_MIN;
extern int SUR_MAX;

extern int Thickness;

extern int SHD3D_SHADOWS;

extern Display        *disp;
extern GC              mgc;
extern Colormap        cmap;
extern XColor          xfgc,xshdc,xlghtc,xexact;
extern Pixmap          rootwin;

extern int sc_w,sc_h;                  /* screen width/height                */
extern int dir,fasc,fdsc,lbear;        /* font ascent/descent/dir/lbearing   */
extern int bwid;                       /* banner pixel width                 */
extern int final_x,final_y;            /* where the text will finally appear */
extern Placement placement;
extern Effect effect;

extern int i,j,t;
extern char OPTFILE[];

extern char *DISP;
