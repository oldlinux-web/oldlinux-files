#include <X11/Xlib.h>

void main(void)
{
  Display *disp;
  disp = XOpenDisplay(NULL);
  XKillClient(disp,AllTemporary);
  XCloseDisplay(disp);
}
