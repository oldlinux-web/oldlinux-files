
#include <stdio.h>
#define FILEIO_G
#include "fileio.h"


int create_ppm(dateiname,text,Ywert)
char *dateiname;
char *text;
int Ywert;
{ int z,t,wert;
  FILE *datei;
  if (dateiname==NULL) { datei= stdout;}
  if (dateiname!=NULL) { datei= fopen(dateiname,"w"); }
  if (datei==NULL) return(-1);
  if (0==fprintf(datei,"P3 \n# Barcode erzeugt von XBarcode 2.11 \n# (c) by Martin Bauer & Jan Laitenberger \n")) return(-1);
  for (z=0;text[z]!=0;z++) {}
  if (0==fprintf(datei,"%d %d \n 1 \n",z,Ywert)) return(-1);
  for (t=1;t<=Ywert;t++) 
   {
    for (z=0;text[z]!=0;z++)
     { 
      if (text[z]==48) if (0==fprintf(datei,"1 1 1 \n")) return(-1);
      if (text[z]==49) if (0==fprintf(datei,"0 0 0 \n")) return(-1);
     }
   }
  fclose(datei);
  return(0);
}


int create_tex(dateiname,text,x,y)
char *dateiname;
char *text;
int x,y;
{ int i;
  FILE *datei;
  char S='\x05C';
  double strich_breite,pos;
  if (dateiname==NULL) { datei= stdout;}
  if (dateiname!=NULL) { datei= fopen(dateiname,"w"); }
  if (datei==NULL) return(-1);
  if (0==fprintf(datei,"%cdocumentstyle[a4]{article}\n",S)) return(-1);
  if (0==fprintf(datei,"%cbegin{document}\n\n\n",S)) return(-1);
  if (0==fprintf(datei,"%% ******************************************\n")) return(-1);
  if (0==fprintf(datei,"%% *   Barcode erzeugt von XBarcode 2.11    *\n")) return(-1);
  if (0==fprintf(datei,"%% * (c) by Martin Bauer & Jan Laitenberger *\n")) return(-1);
  if (0==fprintf(datei,"%% ******************************************\n\n")) return(-1);
  for (i=0;text[i]!=0;i++);
  strich_breite = (x / (1.0*i));
  if (0==fprintf(datei,"%cunitlength 1pt\n",S,x,y)) return(-1);
  if (0==fprintf(datei,"%cbegin{picture}(%d,%d)\n",S,x,y)) return(-1);
  for ( pos=0.0; *text!=0 ; ) {
    for (i=0; *text!='0' && *text!=0 ; *text++,i++);
    pos = pos + (i/2.0)*strich_breite;
    if (0==fprintf(datei,"  %clinethickness{%.3fpt}\n",S,strich_breite*i)) return(-1);
    if (0==fprintf(datei,"  %cput(%.3f,0){%cline(0,1){%d}}\n",S,pos,S,y)) return(-1);
    pos = pos + (i/2.0)*strich_breite;
    for (i=0; *text!='1' && *text!=0 ; *text++,i++);
    pos = pos + i*strich_breite;
  }
  if (0==fprintf(datei,"%cend{picture}\n",S)) return(-1);
  if (0==fprintf(datei,"\n\n%cend{document}\n",S)) return(-1);
  fclose(datei);
  return(0);
}


int create_ps(dateiname,text,x,y)
char *dateiname;
char *text;
int x,y;
{ int i;
  FILE *datei;
  double strich_breite,pos;
 if (dateiname==NULL) { datei= stdout;}
   if (dateiname!=NULL) { datei= fopen(dateiname,"w"); }
     
  if (datei==NULL) return(-1);
  if (0==fprintf(datei,"%%!PS-Adobe-2.0 EPSF-1.2\n")) return(-1);
  if (0==fprintf(datei,"%%%%Creator: XBarcode 2.11 (c) by Martin Bauer & Jan Laitenberger\n")) return(-1);
  if (0==fprintf(datei,"%%%%Title: %s\n",dateiname)) return(-1);
  if (0==fprintf(datei,"%%%%BoundingBox: 40 40 %d %d\n",x+60,y+60)) return(-1);
  if (0==fprintf(datei,"%%%%EndComments\n\n")) return(-1);
  for (i=0;text[i]!=0;i++); y=y+50;
  strich_breite = (x / (1.0*i));
  if (0==fprintf(datei,"newpath\n")) return(-1);
  for ( pos=50.0; *text!=0 ; ) {
    for (i=0; *text!='0' && *text!=0 ; *text++,i++);
    pos = pos + (i/2.0)*strich_breite;
    if (0==fprintf(datei,"%.3f setlinewidth ",i*strich_breite)) return(-1);
    if (0==fprintf(datei,"%.3f 50 moveto ",pos)) return(-1);
    if (0==fprintf(datei,"%.3f %d lineto stroke\n",pos,y)) return(-1);
    pos = pos + (i/2.0)*strich_breite;
    for (i=0; *text!='1' && *text!=0 ; *text++,i++);
    pos = pos + i*strich_breite;
  }
  if (0==fprintf(datei,"\nshowpage\n\n")) return(-1);
  fclose(datei);
  return(0);
}

