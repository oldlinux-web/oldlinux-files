#ifndef HELP_H
#define HELP_H


#ifdef HELP_G
# define vextern
#else
# define vextern extern
#endif

extern void HelpCopyright();
extern void HelpEan();
extern void HelpUpc();
extern void HelpCodabar();
extern void Help3of9();
extern void Help2of5();
extern void HelpCode128();
 

#undef vextern

#endif

