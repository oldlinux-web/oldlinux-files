#ifndef BARCODE_H
#define BARCODE_H

#define Static  static
#define Char    char
#define false   0
#define true    1
#define boolean int
#define uchar   unsigned char

#ifdef BARCODE_G
# define vextern
#else
# define vextern extern
#endif


extern boolean EAN13(Char *CharText, Char *CodeText);
extern boolean EAN12(Char *CharText, Char *CodeText);
extern boolean EAN8(Char *CharText, Char *CodeText);
extern boolean QCODE128(long beginner, Char *CharText, Char *CodeText);
extern boolean CODE25(Char *CharText, Char *CodeText);
extern boolean CODE39(Char *CharText, Char *CodeText);
extern boolean CODEA(Char *CharText, Char *CodeText);
extern boolean CODE25I(Char *CharText, Char *CodeText);
extern boolean UPC(Char *CharText, Char *CodeText);
extern boolean CODE25M(Char *CharText, Char *CodeText);


#undef vextern

#endif /*BARCODE_H*/

