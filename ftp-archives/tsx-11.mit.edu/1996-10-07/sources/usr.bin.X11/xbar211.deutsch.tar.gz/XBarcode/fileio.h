#ifndef FILEIO_H
#define FILEIO_H


#ifdef FILEIO_G
# define vextern
#else
# define vextern extern
#endif

extern int create_ppm(char *dateiname, char *text, int Ywert);
extern int create_tex(char *dateiname, char *text, int x, int y);
extern int create_ps(char *dateiname, char *text, int x, int y);


#undef vextern

#endif

