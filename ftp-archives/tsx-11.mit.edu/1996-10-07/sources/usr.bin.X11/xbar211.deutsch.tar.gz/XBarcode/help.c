
#define HELP_G
#include "help.h"


void HelpCopyright()
{
HelpSubframe(
"
XBarcode 2.11

Dieses Programm ist FREEWARE. Es kann
weitergegeben, jedoch nicht verkauft werden.

Der Source-Code darf nicht in ver�nderter 
Form weitergegeben werden.

Bei Fragen oder Anregungen:

Martin Bauer
Zeppelinstr. 97
70193 Stuttgart 
Tel. 0711 6362008

Jan Laitenberger
Hauptmannsreute 166
70193 Stuttgart

***********************************
Internet-Adresse:
Martin_Bauer@S2.MAUS.DE  
***********************************
");
}                                             

void HelpEan()
{
HelpSubframe(
"
EAN 13 - EAN 12 - EAN 8

Verwendung: in Europa
Zeichenvorrat: 0..9
Codel�nge 7+1,12+1 Zeichen 

EAN 12:  Es m�ssen 12 Zeichen eingegeben werden,
         wobei das erste als Pr�fzeichen auto-
         matisch berechnet und eingef�gt wird.
EAN 13:  Es m�ssen 13 Zeichen eingegeben werden, 
         wobei das erste Zeichen (Pr�fzeichen)
         NICHT auf Korrektheit �berpr�ft wird. 
         Einige Barcodeleser verm�gen auch Barcodes
         mit fehlerhaften Pr�fzeichen zu lesen.
EAN 8:   Es k�nnen 7 oder 8 Zeichen angegeben
         werden. 
         Werden 7 Zeichen angegeben, so wird das
         Pr�fzeichen automatisch berechnet. 
         Wenn 8 Zeichen angegeben werden, sollte
         das Pr�fzeichen korrekt sein.
");
}

void HelpUpc()
{
HelpSubframe(
"
UPC

Verwendung: in den USA
Zeichenvorrat: 0..9
Codel�nge 11+1 Zeichen

Wenn nur 11 Zeichen angegeben werden, wird das 
Pr�fzeichen automatisch berechnet.

Wenn Sie 12 Zeichen angeben, m�ssen Sie daf�r 
sorgen, da� das Pr�fzeichen korrekt ist.
");
}

void HelpCodabar()
{
HelpSubframe(
"
Codabar

Zeichenvorrat: A..E 0..9 +-*/=$.TN
Codel�nge: maximal 15 Zeichen

Es gibt folgende Start/Stopsymbole: A B C D
Es wird der Ausdruck KOMPLETT umgewandelt. 
Sie m�ssen daf�r sorgen, da� die
Start/Stopzeichen korrekt sitzen.

BSP: A1234D      => Zahl: 1234
BSP: A4444D1111A => Zahl: 4444 (von links) 
                    Zahl: 1111 (von rechts) 
");        
}

void Help3of9()
{
HelpSubframe(
"
Code 3 of 9 (Barcode 39)

Zeichenvorrat: A..Z 0..9 +-/.% Space $'
Codel�nge: maximal 15 Zeichen
");
}

void Help2of5()
{
HelpSubframe(
"
Code 2/5 (Non-/Interleaved, Matrix)

Zeichenvorrat: 0..9
Codel�nge: maximal 15 Zeichen

Code 25 Interleaved: GERADE Anzahl von Zeichen,
also m�gliche Codel�ngen: 2,4,6,8,10,12,14
");
}

void HelpCode128()
{
HelpSubframe(
"
Code 128

Zeichenvorrat: kompletter Ascii-Code (0..127)
Codel�nge: maximal 13 Zeichen

Code 128 A = es wird mit dem Zeichensatz A begonnen
Code 128 B = es wird mit dem Zeichensatz B begonnen

Da nicht alle Zeichen eingegeben werden k�nnen gibt
es die M�gilichkeit �ber Escape-codes diese Zeichen
in Form von Symbolen einzugeben.

Escape-Codezeichen: # 
Bsp: 
##   => # wird erzeugt
#CR  => Ascii(13) wird erzeugt
#NUL => Ascii(0) wird erzeugt

Liste aller Symbole:
00=NUL  07=BEL  14=SO   21=NAK  28=FS
01=SOH  08=BS   15=SI   22=SYN  29=GS
02=STX  09=AT   16=DLE  23=ETB  30=RS
03=ETX  10=LF   17=DC1  24=CAN  31=US
04=EOT  11=VT   18=DC2  25=EM   
05=ENQ  12=FF   19=DC3  26=SUB  FNC1...FNC4 sind
06=ACK  13=CR   20=DC4  27=ESC    reservierte
                                  Steuerzeichen
");
}
