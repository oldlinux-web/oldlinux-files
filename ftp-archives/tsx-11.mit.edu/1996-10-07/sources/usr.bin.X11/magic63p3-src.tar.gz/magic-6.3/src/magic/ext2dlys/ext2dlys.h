/* "depend" requires a .h file in each directory */
