#include "defs.h"

public	char    version[] = "version 8.6";

