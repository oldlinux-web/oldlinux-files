
#define         _doprnt(x,y,z)          vfprintf(z,x,y)

