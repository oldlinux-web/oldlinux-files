#define __LIBRARY__
#include <unistd.h>
#include <syscall.h>

#define SYS_sys_syslog SYS_syslog

_syscall3(int,sys_syslog,int, type, char *, but, int, len);


