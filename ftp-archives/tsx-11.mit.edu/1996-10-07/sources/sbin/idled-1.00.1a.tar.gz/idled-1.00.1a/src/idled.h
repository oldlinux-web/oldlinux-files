/*****************************************************************************
	         idledaemon - idle login killer for the Linux OS
	  (C)opyright 1994, Scott Burkett and Southeastern DataLINK
 ***************************************************************************** 
	MODULE: idledaemon.h
       HISTORY:	initial coding		12/18/94		bsb

 *****************************************************************************/

#define	 VERSION "1.00.1a"
#define  COPYRIGHT "(C)opyright 1994-1995, B. Scott Burkett, All Rights Reserved"
#define  WARNED_TABLE_SIZE	100
#ifndef TRUE
#define TRUE 	1
#define FALSE	!TRUE
#endif

void Init( int ac );
void Process(void);
time_t GetTimes(void);
void Guillotine(int cfgndx);
void be_daemon(void);
void err_sys(char *msg);
void Report(void);
void MessageKill(void);
void MessageWarn(void);
void ParseCmdLine(int ac, char *av[]);
void ReadCFGFile(void);
int CheckNoidleout(void);
int BeenWarned(int pid);
void MarkAsWarned(int pid);
void WarnNoMore( int ndx );
void SendFile(char *filename);
void SetSignals(void);
void cleanup(int signum);
int ProcActive(int pid);
int JudgementDay(int *cfgndx);

typedef struct	_warned { 
	int	pid;
	char	wflag;
} _WARNED;

typedef struct  _cfg {
	char	_username[12];
	char 	_ttydevice[20];
	int	_idle;
	int	_grace;
	char	_notifybymail;
	int 	_sessionlimit;
} _CFG;

struct utmp	*userrec;
FILE		*uf, *tty;
char		buf[80];
_WARNED 	warned[ WARNED_TABLE_SIZE ];  
_CFG    	cfg[ WARNED_TABLE_SIZE ];
_CFG		tmpcfg;
int		_maxidletime=300, _warnfirst, _debug, _sleepdelay=60;
int		highentry=0;

