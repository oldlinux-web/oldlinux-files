/*
 *  lde/nc_dir.h -- The Linux Disk Editor
 *
 *  Copyright (C) 1994  Scott D. Heavner
 *
 *  $Id: nc_dir.h,v 1.1 1994/09/05 23:06:27 sdh Exp $
 */

int directory_popup(unsigned long bnr);
