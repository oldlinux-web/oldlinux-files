/*
 *  lde/curses.h -- The Linux Disk Editor
 *
 *  Copyright (C) 1994  Scott D. Heavner
 *
 *  $Id: curses.h,v 1.1 1994/09/05 22:57:42 sdh Exp $
 */

#ifdef NC_HEADER
#include <ncurses.h>
#else
#include <curses.h>
#endif
