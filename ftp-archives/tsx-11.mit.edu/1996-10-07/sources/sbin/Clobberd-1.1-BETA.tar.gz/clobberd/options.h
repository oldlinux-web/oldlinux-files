/***************************************************************************
****************************************************************************
****************************************************************************
*
* Clobberd - By Jason Nunn - August 96
* FREEWARE. Authorship Reserved 1996
*
* "A user regulator with attitude.." (ANSI C)
*
* Snail: 32 Rothdale Road, Moil, Darwin, NT, 0810, Australia
*
* ==================================================================
*
* swaptions file..
*
****************************************************************************
****************************************************************************
***************************************************************************/
#define DEFAULT_RUN_LEVEL      0  /*0 = verbose,1  normal, 2 = no logging*/
#define DEFAULT_SLEEP_TIME     (60 * 5) /* in seconds*/
#define DEFAULT_NO_OF_WARNINGS 3 /*no of warnings after user has used up time,
                                  or abusing cpu etc*/

/*this is the email address the user will see when clobberd emails users*/
#define EMAIL_ADDR             "root@localhost"

/*i got this sig from one of those cheap desk calanders you get issued at
work... I think it's appropriate for me ;). change this to what ever you
like. It's the sig used by clobberd when it sends users email.*/

#define SIGATURE_STR \
"'a little inaccuracy can save tonnes of explanations' - Saki"

/*settings you need to talk to clobberd via telnet*/
#define NET_PORT               6669    /*i recommend you change this to something else*/
#define MAX_CONNECTIONS        4       /*if it gets hit by telnet alot, then increase*/
