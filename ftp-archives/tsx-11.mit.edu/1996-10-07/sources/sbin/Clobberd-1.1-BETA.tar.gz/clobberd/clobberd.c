/***************************************************************************
****************************************************************************
****************************************************************************
*
* Clobberd - By Jason Nunn - August 96
* FREEWARE. Authorship Reserved 1996
*
* "A user regulator with attitude.." (ANSI C)
*
* Snail: 32 Rothdale Road, Moil, Darwin, NT, 0810, Australia
*
* ==================================================================
*
* Purpose written for Mark Keogh of the Amiga Retreat. A bit of a hack job
* written over a couple of  weekends.. Will monitor users and clobber them
* according to the /etc/clobberd.conf file.
*
* Developed on a Linux 1.2.13 box ...then later 2.0.0
*
****************************************************************************
****************************************************************************
***************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <time.h>
#include <utmp.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <pwd.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <dirent.h>
#include <syslog.h>
#include "options.h"

#define VERSION  "1.1"
#define DATED    __DATE__
#define WELCOME \
"Welcome to Clobberd " VERSION ", Compiled: " DATED \
" by Jason Nunn. Authorship (R)1996\n" \
"Contact: 32 Rothdale Rd, Moil Darwin NT 0810, AUSTRALIA\n\n"
#define STR_LEN      256
#define STR_LEN2     80
#define STR_USER_LEN (UT_NAMESIZE + 1)
#define CONFIG_FILE  "/etc/clobberd.conf"
#define DATA_FILE    "/etc/clobberd.db"

/*************************************************/
typedef struct
{
  char   user[STR_USER_LEN];
  char   email[STR_LEN2];
  time_t total_time_limit;
  time_t daily_time_limit;
  int    nice_factor;
  int    cpu_limit;
  int    mem_limit;
} tusettings;

typedef struct _tusettings_ll
{
  tusettings *curr;
  struct _tusettings_ll *next;
} tusettings_ll;

/*************************************************/
typedef struct
{
  char         user[STR_USER_LEN];
  uid_t        uid;
  pid_t        pid;
  char         active;
  time_t       total_time_used;
  time_t       daily_time_used;
  int          no_ttime_warnings;
  int          no_dtime_warnings;
  int          old_jiffies;
  int          jiffies;
  unsigned int rss;
  int          no_cpu_warnings;
  int          no_mem_warnings;
  int          naughty;
} tutmp;

typedef struct _tutmp_ll
{
  tutmp *curr;
  struct _tutmp_ll *next;
} tutmp_ll;

typedef struct
{
  int                rootflag;
  char               user[STR_USER_LEN];
  char               addr[STR_LEN2];
  int                s;
} tKon_info;

/*************************************************/
int           daemon_mode = 1;
int           running = 1;
int           listen_loop;
int           run_level = DEFAULT_RUN_LEVEL;
FILE          *fp;
DIR           *dp;
struct dirent *dir_entry;
struct stat   statbuf;

unsigned int  sleep_time = DEFAULT_SLEEP_TIME;
int           no_of_warnings = DEFAULT_NO_OF_WARNINGS;
struct utmp   tmp_buf;
tusettings_ll usettings_ll_root;
tutmp_ll      utmp_ll_root = {NULL,NULL};

time_t        timer,old_timer,timer_used;
struct tm     *tblock;
int           old_tm_wday;

int           old_total_jiffies;
int           total_jiffies;
unsigned int  total_rss;

char           *our_hostname;
unsigned long  our_ip;
int            newaddrsize;
int            main_socket;
tKon_info      Kon_info[MAX_CONNECTIONS];

/*these are general strings used throughout this program, having
local. Declaring them in recursive functions is pretty fucked*/
char str[STR_LEN],substr[STR_LEN],substr2[STR_LEN2],*user;
int naughty_flag;

/***************************************************************************
*
***************************************************************************/
void log_msg(char *msg,int rl)
{
  if(run_level <= rl)
    if(daemon_mode)
    {
      openlog("clobberd",LOG_CONS,LOG_DAEMON);
      syslog(LOG_NOTICE,msg);
      closelog();
    }
    else
      printf("%s\n",msg);
}

/***************************************************************************
*
***************************************************************************/
void kill_daemon(int sig)
{
  running = 0;
  listen_loop = 0;
}

/***************************************************************************
*
***************************************************************************/
void get_agg_stats(int *tot_cpu_jiffies,unsigned int *tot_rss)
{
  if((fp = fopen("/proc/stat","r")) == NULL)
  {
    log_msg("Error: Couldn't open '/proc/stat' (get_agg_stats)",1);
    return;
  }
  do
  {
    fgets(str,STR_LEN,fp);
    if(strstr(str,"cpu") != NULL)
    {
      int a,b,c,d;

      sscanf(str,"cpu %d %d %d %d",&a,&b,&c,&d);
      *tot_cpu_jiffies = a + b + c + d;
    }
    if(strstr(str,"page") != NULL)
      sscanf(str,"page %u %*u",tot_rss);
  } while(!feof(fp));
  fclose(fp);
}

/***************************************************************************
*
***************************************************************************/
void init(void)
{
  register int x;
  struct hostent *dest;
  struct in_addr *ip;

  our_hostname = getenv("HOSTNAME");
  dest = gethostbyname(our_hostname);
  ip = (struct in_addr *)dest->h_addr;
  our_ip = ip->s_addr;
  timer = time(NULL);
  old_timer = timer;
  tblock = localtime(&timer);
  old_tm_wday = tblock->tm_wday;
  get_agg_stats(&total_jiffies,&total_rss);
  old_total_jiffies = 0;
  newaddrsize = sizeof(struct sockaddr_in);
  for(x = 0;x < MAX_CONNECTIONS;x++) Kon_info[x].s = -1;
  for(x = 1;x < NSIG;++x) signal(x,SIG_IGN);
  signal(SIGINT,kill_daemon);
  signal(SIGKILL,kill_daemon);
  signal(SIGTERM,kill_daemon);
  signal(SIGHUP,kill_daemon);
  if(daemon_mode)
  {
    if(fork() == 0)
    {
      for(x = 0;x <= FD_SETSIZE;++x) close(x);
      setsid();
    }
    else
      exit(0);
  }
}

/***************************************************************************
* Network Shit..
***************************************************************************/
/*routine from "Mail Flash" 1994 CHA0S All Rights Reserved*/
int tcpip_client_creat(char *server,int port)
{
  struct sockaddr_in sin;
  struct hostent *hp;
  register int thesock;
 
  hp = gethostbyname(server);
  if(hp == NULL) return -1;
  memset((char *)&sin,0,sizeof(sin));
  memcpy(hp->h_addr,(char *)&sin.sin_addr,hp->h_length);
  sin.sin_family = hp->h_addrtype;
  sin.sin_port = htons(port);
  thesock = socket(AF_INET,SOCK_STREAM,0);
  if(thesock != -1)
    if(connect(thesock,(struct sockaddr *)&sin,sizeof(sin)) == -1)
      return -1;
  return thesock;
}

int tcpip_serv_creat(void)
{
  int newsock,reuse_opt = 1;
  struct sockaddr_in addr = {0};

  newsock = socket(AF_INET,SOCK_STREAM,0);
  setsockopt(newsock,SOL_SOCKET,SO_REUSEADDR,&reuse_opt,sizeof(reuse_opt));
  addr.sin_family = AF_INET;
  addr.sin_port = htons(NET_PORT);
  addr.sin_addr.s_addr = htonl(INADDR_ANY);
  if(bind(newsock,(struct sockaddr *)&addr,sizeof(addr)) != 0)
  {
    printf("Error: Bind failed. Server is probably already running on"
           " this machine (tcpip_serv_creat)\n");
    return -1;
  }
  fcntl(newsock,F_SETFL,O_NONBLOCK);
  listen(newsock,MAX_CONNECTIONS);
  return newsock;
}

void kill_Kon(tKon_info *K)
{
  sprintf(str,"Info: Killing connection [%s@%s]",K->user,K->addr);
  log_msg(str,1);
  shutdown(K->s,2);
  close(K->s);
  K->s = -1;
}

void wtt(int fp2,char *text)
{
  write(fp2,text,strlen(text));
}

char *rtt(tKon_info *K)
{
  static char buf[STR_LEN];
  register int l;

  buf[0] = 0;
  l = read(K->s,&buf,STR_LEN);
  if(l <= -1)
  {
    if((errno != EWOULDBLOCK) && (errno != EAGAIN))
    {
      log_msg("Error: Network read error. (*rtt)",1);
      kill_Kon(K);
    }
    return NULL;
  }
  else
    if(l == 0)
    {
      kill_Kon(K);
      return NULL;
    }
  return buf;
}

void tcpip_serv_reaper(void)
{
  register int x;

  for(x = 0;x < MAX_CONNECTIONS;x++)
    if(Kon_info[x].s != -1)
      kill_Kon(&Kon_info[x]);
  shutdown(main_socket,2);
  close(main_socket);
}

/***************************************************************************
* READ clobberd.conf
***************************************************************************/
tusettings_ll *find_user_settings(tusettings_ll *entry)
{
  tusettings_ll *x = NULL;

  if(entry->curr != NULL)
    if(strncmp(entry->curr->user,user,UT_NAMESIZE) != 0)
    {
      if(entry->next != NULL)
        x = find_user_settings(entry->next);
    }
    else
      x = entry;
  return x;
}

void load_user_table(tusettings_ll *entry)
{
  register int f;

  do
  {
    fgets(str,STR_LEN,fp);
    if(feof(fp)) return;
    f = sscanf(str,"%s",substr);
  } while((substr[0] == '#') || (f == -1));
  entry->curr = malloc(sizeof(tusettings));
  if(entry->curr != NULL)
  {
    int x = 0,y = 0,x2 = 0,y2 = 0;

    sscanf(str,"%s %s %d:%d %d:%d %d %d %d",
      substr,
      (char *)&(entry->curr->email),
      &x,&y,
      &x2,&y2,
      &(entry->curr->nice_factor),
      &(entry->curr->cpu_limit),
      &(entry->curr->mem_limit));
    strncpy(entry->curr->user,substr,STR_USER_LEN);
    entry->curr->total_time_limit = ((x * 60) + y) * 60;
    entry->curr->daily_time_limit = ((x2 * 60) + y2) * 60;
    if(entry->curr->nice_factor < -20) entry->curr->nice_factor = -20;
    if(entry->curr->nice_factor > 19) entry->curr->nice_factor = 19;
    if(entry->curr->cpu_limit < 0) entry->curr->cpu_limit = 0;
    if(entry->curr->mem_limit < 0) entry->curr->mem_limit = 0;
    if(entry->curr->cpu_limit > 100) entry->curr->cpu_limit = 100;
    if(entry->curr->mem_limit > 100) entry->curr->mem_limit = 100;
    entry->next = malloc(sizeof(tusettings_ll));
    if(entry->curr != NULL)
    {
      entry->next->curr = NULL;
      entry->next->next = NULL;
      load_user_table(entry->next);
    }
    else
      log_msg("Error: Couldn't malloc 'entry->next' (load_user_table)",1);
  }
  else
    log_msg("Error: Couldn't malloc 'entry->curr' (load_user_table)",1);
}

int get_user_settings(void)
{
  int x = 0,y = 0;

  usettings_ll_root.curr = NULL;
  usettings_ll_root.next = NULL;

  if((fp = fopen(CONFIG_FILE,"r")) == NULL)
  {
    log_msg("Error: Couldn't open " CONFIG_FILE " (get_user_settings)",1);
    return 0;
  }
  do
  {
    fgets(str,STR_LEN,fp);
    sscanf(str,"%s",substr);
    if(substr[0] != '#')
    {
      if(!strcmp(substr,"run_level"))
      {
        sscanf(str,"run_level %d",&x);
        x &= 3;
        if(x != run_level)
        {
          run_level = x;
          sprintf(str,"Init: New 'run_level' set to: %d",run_level);
          log_msg(str,1);
        }
      }
      if(!strcmp(substr,"sleep_time"))
      {
        sscanf(str,"sleep_time %d:%d",&x,&y);
        y += x * 60;
        if(y != sleep_time)
        {
          sleep_time = y;
          sprintf(str,"Init: New 'sleep_time' set to %d seconds",sleep_time);
          log_msg(str,1);
        }
      }
      if(!strcmp(substr,"no_of_warnings"))
      {
        sscanf(str,"no_of_warnings %d",&x);
        if(x != no_of_warnings)
        {
          no_of_warnings = x;
          sprintf(str,"Init: New 'no_of_warnings' set to: %d",no_of_warnings);
          log_msg(str,1);
        }
      }
      if(!strcmp(substr,"user_table"))
      {
        load_user_table(&usettings_ll_root);
        break;
      }
    }
  } while(!feof(fp));

  fclose(fp);
  return 1;
}

void free_user_settings(tusettings_ll *entry)
{
  if(entry->next != NULL) free_user_settings(entry->next);
  free(entry->next);
  if(entry->curr != NULL) free(entry->curr);
}

/***************************************************************************
* load users (tutmp_ll) doc/clobberd.db
***************************************************************************/
void load_user(tutmp_ll *entry)
{
  entry->curr = malloc(sizeof(tutmp));
  if(entry->curr != NULL)
  {
    if(fread(entry->curr,sizeof(tutmp),1,fp) == 1)
    {
      sprintf(str,"Init: Recovering '%s' from '" DATA_FILE "'",entry->curr->user);
      log_msg(str,0);
      entry->next = malloc(sizeof(tutmp_ll));
      if(entry->next != NULL)
      {
        entry->next->curr = NULL;
        entry->next->next = NULL;
        load_user(entry->next);
      }
      else
        log_msg("Error: Couldn't malloc 'entry->next' (load_user)",1);
    }
    else
    {
      free(entry->curr);
      entry->curr = NULL;
    }
  }
  else
    log_msg("Error: Couldn't malloc 'entry->curr' (load_user)",1);
}

void load_users(void)
{
  if((fp = fopen(DATA_FILE,"rb")) == NULL)
  {
    log_msg("Warning: Couldn't open '" DATA_FILE "' (load_users). This is "
            "no big deal if first installed",1);
    return;
  }
  load_user(&utmp_ll_root);
  fclose(fp);
}

/***************************************************************************
* save users (tutmp_ll) doc/clobberd.db
***************************************************************************/
void save_user(tutmp_ll *entry)
{
  if(entry->curr != NULL)
  {
    if(fwrite(entry->curr,sizeof(tutmp),1,fp) == sizeof(tutmp))
    {
      log_msg("Error: writing '"DATA_FILE"' (save_user).. pretty serious shit."
              " Will forget user tracking if daemon dies",1);
      return;
    }
    if(entry->next != NULL) save_user(entry->next);
  }
}

void save_users(void)
{
  if((fp = fopen(DATA_FILE,"wb")) == NULL)
  {
    log_msg("Error: Couldn't save '" DATA_FILE "' (save_users)",1);
    return;
  }
  save_user(&utmp_ll_root);
  fclose(fp);
}

/***************************************************************************
* Reads /etc/utmp file, and loads new news into tutmp struct..
***************************************************************************/
tutmp_ll *find_user(tutmp_ll *entry)
{
  tutmp_ll *x = NULL;

  if(entry->curr != NULL)
    if(strncmp(entry->curr->user,user,UT_NAMESIZE) != 0)
    {
      if(entry->next != NULL)
        x = find_user(entry->next);
    }
    else
      x = entry;
  return x;
}

tutmp_ll *set_actives_gotoend(tutmp_ll *entry)
{
  tutmp_ll *x = NULL;

  if(entry->curr != NULL)
  {
    entry->curr->active = 0;
    rewind(fp);
    while(fread(&tmp_buf,sizeof(struct utmp),1,fp) == 1)
      if(!strncmp(entry->curr->user,tmp_buf.ut_user,UT_NAMESIZE) &&
         (tmp_buf.ut_type == USER_PROCESS))
      {
        entry->curr->pid = tmp_buf.ut_pid;
        entry->curr->active = 1;
        break;
      }
    if(entry->next != NULL) x = set_actives_gotoend(entry->next);
  }
  else
    x = entry;
  return x;
}

void get_user_entries(tutmp_ll *entry)
{
  register int exit_rl = 1;

  do
  {
    if(fread(&tmp_buf,sizeof(struct utmp),1,fp) == 1)
    {
      user = tmp_buf.ut_user;
      if((tmp_buf.ut_type == USER_PROCESS) &&
         (find_user(&utmp_ll_root) == NULL))
      {
        exit_rl = 0;
        entry->curr = malloc(sizeof(tutmp));
        if(entry->curr != NULL)
        {
          strncpy(entry->curr->user,tmp_buf.ut_user,STR_USER_LEN);
          entry->curr->user[STR_USER_LEN - 1] = 0;
          entry->curr->uid = getpwnam(entry->curr->user)->pw_uid;
          entry->curr->pid = tmp_buf.ut_pid;
          entry->curr->active = 1;
          entry->curr->total_time_used = (timer - tmp_buf.ut_time) - (timer - old_timer);
          entry->curr->daily_time_used = entry->curr->total_time_used;
          entry->curr->no_ttime_warnings = 1;
          entry->curr->no_dtime_warnings = 1;
          entry->curr->old_jiffies = 0;
          entry->curr->jiffies = 0;
          entry->curr->rss = 0;
          entry->curr->no_cpu_warnings = 1;
          entry->curr->no_mem_warnings = 1;
          entry->curr->naughty = 0;
          strncpy(substr2,ctime(&(tmp_buf.ut_time)) + 11,5);
          substr2[5] = 0;
          sprintf(str,"Logged: New user '%s' at %s",
            entry->curr->user,substr2);
          log_msg(str,1);

          entry->next = malloc(sizeof(tutmp_ll));
          if(entry->next != NULL)
          {
            entry->next->curr = NULL;
            entry->next->next = NULL;
            get_user_entries(entry->next);
          }
          else
            log_msg("Error: Couldn't malloc 'entry->next' (get_user_entries)",1);
        }
        else
          log_msg("Error: Couldn't malloc 'entry->curr' (get_user_entries)",1);
      }
    }
    else
      exit_rl = 0;
  } while(exit_rl);
}

int get_active_users(void)
{
  tutmp_ll *x = NULL;

  if((fp = fopen(UTMP_FILE,"rb")) == NULL)
  {
    log_msg("Error: Couldn't open" UTMP_FILE "(get_active_users)",1);
    return 0;
  }
  x = set_actives_gotoend(&utmp_ll_root);
  rewind(fp);
  get_user_entries(x);
  fclose(fp);
  return 1;
}

void free_user_entries(tutmp_ll *entry)
{
  if(entry->next != NULL) free_user_entries(entry->next);
  free(entry->next);
  if(entry->curr != NULL) free(entry->curr);
}

/***************************************************************************
* Midnight reset. purges all warnings, and daily time usage.
***************************************************************************/
void reset_daily_stuff(tutmp_ll *entry)
{
  if(entry->curr != NULL)
  {
    entry->curr->daily_time_used = 0;
    entry->curr->no_dtime_warnings = 1;
    entry->curr->no_cpu_warnings = 1;
    entry->curr->no_mem_warnings = 1;
    if(entry->next != NULL) reset_daily_stuff(entry->next);
  }
}

void reset_at_midnight(void)
{
  tblock = localtime(&timer);
  if(old_tm_wday != tblock->tm_wday)
  {
    old_tm_wday = tblock->tm_wday;
    reset_daily_stuff(&utmp_ll_root);
    log_msg("Resetting: Midnight reset... and it's a brand new day",1);
  }
}

/***************************************************************************
* Reset User../naughty/cool users
***************************************************************************/
int reset_user_stuff(tutmp_ll *entry)
{
  int x = 0;

  if(entry->curr != NULL)
    if(!strcmp(entry->curr->user,user))
    {
      entry->curr->total_time_used = 0;
      entry->curr->daily_time_used = 0;
      entry->curr->no_ttime_warnings = 1;
      entry->curr->no_dtime_warnings = 1;
      entry->curr->no_cpu_warnings = 1;
      entry->curr->no_mem_warnings = 1;
      entry->curr->naughty = 0;
      sprintf(str,"Resetting: '%s' has been reset",user);
      log_msg(str,1);
      x = 1;
    }
    else
      if(entry->next != NULL) x = reset_user_stuff(entry->next);
  return x;
}

int set_naughty_user(tutmp_ll *entry)
{
  int x = 0;

  if(entry->curr != NULL)
    if(!strcmp(entry->curr->user,user))
    {
      entry->curr->naughty = naughty_flag;
      sprintf(str,"Setting: '%s' is %s",
        user,(naughty_flag == 1) ? "naughty" : "cool");
      log_msg(str,1);
      x = 1;
    }
    else
      if(entry->next != NULL) x = set_naughty_user(entry->next);
  return x;
}

/***************************************************************************
* blows user tracking list out of the water... total reset
***************************************************************************/
void total_reset(void)
{
  free_user_entries(&utmp_ll_root);
  utmp_ll_root.curr = NULL;
  utmp_ll_root.next = NULL;
  log_msg("Resetting: a super mega astronomical reset. clobberd forgots everything",1);
}

/***************************************************************************
* warning stuff..
***************************************************************************/
void warn_user(tusettings_ll *entry,char *message)
{
  if(entry->curr->email[0] == '*') /*do tty*/
  {
    if((fp = fopen(UTMP_FILE,"rb")) == NULL)
    {
      sprintf(str,
              "Error: Couldn't open %s (warn_user). '%s' wasn't warned",
              UTMP_FILE,entry->curr->user);
      log_msg(str,1);
      return;
    }
    while(fread(&tmp_buf,sizeof(struct utmp),1,fp) == 1)
    {
      if(strncmp(tmp_buf.ut_user,entry->curr->user,UT_NAMESIZE) == 0)
      {
        register int fp2;

        strcpy(substr,"/dev/");
        strcat(substr,tmp_buf.ut_line);
        if((fp2 = open(substr,O_WRONLY | O_NOCTTY | O_APPEND | O_NONBLOCK)) != -1)
        {
          wtt(fp2,"\a\n");
          wtt(fp2,"--\n");
          wtt(fp2,"From: " EMAIL_ADDR "\n");
          sprintf(substr,"Mesg: %s\n",message);
          wtt(fp2,substr);
          close(fp2);
        }
        else
        {
          sprintf(str,
                  "Error: '%s' couldn't be opened. %s may not be warned",
                  substr,entry->curr->user);
          log_msg(str,1);
        }
      }
    }
    fclose(fp);
  }
  else /*if email*/
  {
    register int socket_d = tcpip_client_creat(our_hostname,25);
    if(socket_d != -1)
    {
      sprintf(substr,
        "helo\n"
        "mail from: %s\n"
        "rcpt to: %s\n"
        "data\n"
        "SUBJECT: Warning\n\n"
        "%s\n\n"
        "--\n"
        "%s\n"
        "\n.\nquit\n",
        EMAIL_ADDR,entry->curr->user,message,SIGATURE_STR);
      wtt(socket_d,substr);
      shutdown(socket_d,2);
    }
    else
    {
      sprintf(str,"Error: Unknown host '%s'. '%s' couldn't be warned\n",
        our_hostname,entry->curr->user);
      log_msg(str,1);
    }
  }
}

/***************************************************************************
* monitor user load..
*
* i have discovered that sweeping the /proc structure can become quite
* cpu intensive..
***************************************************************************/
int          l_jiffies;
unsigned int l_rss;

void clear_loads(tutmp_ll *entry)
{
  if(entry->curr != NULL)
  {
    entry->curr->old_jiffies = entry->curr->jiffies;
    entry->curr->jiffies = 0;
    entry->curr->rss = 0;
    if(entry->next != NULL) clear_loads(entry->next);
  }
}

void add_loads(tutmp_ll *entry)
{
  if(entry->curr != NULL)
    if(entry->curr->uid == statbuf.st_uid)
    {
      entry->curr->jiffies += l_jiffies;
      entry->curr->rss += l_rss;
    }
    else
      if(entry->next != NULL) add_loads(entry->next);
}

void get_user_loads(void)
{
  old_total_jiffies = total_jiffies;
  get_agg_stats(&total_jiffies,&total_rss);
  clear_loads(&utmp_ll_root);
  if((dp = opendir("/proc")) == NULL)
  {
    log_msg("Error: Couldn't open '/proc' (get_user_loads)",1);
    return;
  }
  while((dir_entry = readdir(dp)) != NULL)
  {
    int a;

    if(sscanf(dir_entry->d_name,"%d",&a))
    {
      strcpy(str,"/proc/");
      strcat(str,dir_entry->d_name);
      if(lstat(str,&statbuf) != -1)
      {
        strcpy(str,"/proc/");
        strcat(str,dir_entry->d_name);
        strcat(str,"/stat");
        if((fp = fopen(str,"r")) == NULL)
        {
          log_msg("Error: Couldn't open '/proc/[pid]/stat' (get_user_loads)",1);
          return;
        }
        fscanf(fp,
          "%*d %*s %*c %*d %*d %*d %*d %*d %*u %*u %*u %*u %*u"
      /*utime stime                             rss*/
          "%d %d %*d %*d %*d %*d %*u %*u %*d %*u %u",
          &l_jiffies,&a,&l_rss);
        fclose(fp);
        l_jiffies += a;
        add_loads(&utmp_ll_root);
      }
    }
  }
  closedir(dp);
}

/***************************************************************************
* User Clobbering routines
***************************************************************************/
void clobber_user(uid_t e_uid)
{
  if((dp = opendir("/proc")) == NULL)
  {
    log_msg("Error: Couldn't open '/proc' (get_user_loads)",1);
    return;
  }
  while((dir_entry = readdir(dp)) != NULL)
  {
    int e_pid;

    if(sscanf(dir_entry->d_name,"%d",&e_pid))
    {
      strcpy(str,"/proc/");
      strcat(str,dir_entry->d_name);
      if((lstat(str,&statbuf) != -1) &&
         (e_uid == statbuf.st_uid))
        kill(e_pid,SIGKILL);
    }
  }
  closedir(dp);
}

/***************************************************************************
* User monitoring routines
***************************************************************************/
void monitor_user(tutmp_ll *entry)
{
  if(entry->curr != NULL)
  {
    if(entry->curr->active)
    {
      tusettings_ll *us_entry;

      user = entry->curr->user;
      us_entry = find_user_settings(&usettings_ll_root);
      if(us_entry != NULL)
      {
        register int cpu_usage,mem_usage;
/*set nice*/
        if(us_entry->curr->nice_factor != getpriority(PRIO_USER,entry->curr->uid))
        {
          setpriority(PRIO_USER,entry->curr->uid,us_entry->curr->nice_factor);
          sprintf(str,"Monitor: Set '%s' to nice %d",
            entry->curr->user,us_entry->curr->nice_factor);
          log_msg(str,1);
        }
/*monitor naughty*/
        if(entry->curr->naughty)
        {
          warn_user(us_entry,
            "You have been kicked off for being naughty. For queries, ring Admin");
          clobber_user(entry->curr->uid);
          sprintf(str,"Notify: '%s' clobberd.. user is naughty",
            entry->curr->user);
          log_msg(str,1);
        }
/*monitor time*/
        entry->curr->total_time_used += timer_used;
        entry->curr->daily_time_used += timer_used;
        sprintf(str,"Monitor: Daily time for '%s' (Time used: T:%ds,D:%ds)",
          entry->curr->user,(int)entry->curr->total_time_used,
          (int)entry->curr->daily_time_used);
        log_msg(str,0);
/*total*/
        if(entry->curr->no_ttime_warnings > no_of_warnings)
        {
          warn_user(us_entry,
            "Total time limit expired. You have been Clobbered. "
            "Ring Admin to buy more time");
          clobber_user(entry->curr->uid);
          sprintf(str,"Notify: '%s' clobberd.. Total time limit expired",
            entry->curr->user);
          log_msg(str,1);
        }
        else
          if(entry->curr->total_time_used > us_entry->curr->total_time_limit)
          {
            sprintf(
              str,
              "Your total time limit has expired. Logg off ASAP. Warning No. %d/%d",
              entry->curr->no_ttime_warnings,no_of_warnings);
            warn_user(us_entry,str);
            sprintf(
              str,
              "Notify: '%s' Total time limit expired. Warning No. %d/%d",
              entry->curr->user,entry->curr->no_ttime_warnings,no_of_warnings);
            log_msg(str,1);
            entry->curr->no_ttime_warnings++;
          }
/*daily*/
        if(entry->curr->no_dtime_warnings > no_of_warnings)
        {
          warn_user(us_entry,"Daily time limit expired. You have been Clobbered..");
          clobber_user(entry->curr->uid);
          sprintf(str,"Notify: '%s' clobberd.. Daily time limit expired",entry->curr->user);
          log_msg(str,1);
        }
        else
          if(entry->curr->daily_time_used > us_entry->curr->daily_time_limit)
          {
            sprintf(
              str,
              "Your daily time limit has expired. Logg off ASAP. Warning No. %d/%d",
              entry->curr->no_dtime_warnings,no_of_warnings);
            warn_user(us_entry,str);
            sprintf(
              str,
              "Notify: '%s' Daily time limit expired. Warning No. %d/%d",
              entry->curr->user,entry->curr->no_dtime_warnings,no_of_warnings);
            log_msg(str,1);
            entry->curr->no_dtime_warnings++;
          }
/*monitor cpu load*/
        cpu_usage =
          ((entry->curr->jiffies - entry->curr->old_jiffies) * 100) /
          (total_jiffies - old_total_jiffies);
        if(cpu_usage < 0) cpu_usage = 0;
        sprintf(str,"Monitor: CPU usage for '%s' is at %d%%",
          entry->curr->user,cpu_usage);
        log_msg(str,0);
        if(entry->curr->no_cpu_warnings > no_of_warnings)
        {
          sprintf(str,
            "That's it!, you are now 'kill -9'ed for CPU abuse!!. Good bye"
            " (CPU usage: %d%%)",cpu_usage);
          warn_user(us_entry,str);
          clobber_user(entry->curr->uid);
          sprintf(str,"Notify: '%s' clobberd.. CPU abuse (CPU usage: %d%%)",
            entry->curr->user,cpu_usage);
          log_msg(str,1);
        }
        else
          if(cpu_usage > us_entry->curr->cpu_limit)
          {
            sprintf(
              str,
              "You are pounding the CPU. Please stop. Warning No. %d/%d"
              " (CPU usage: %d%%)",
              entry->curr->no_cpu_warnings,no_of_warnings,cpu_usage);
            warn_user(us_entry,str);
            sprintf(
              str,
              "Notify: '%s' pounding CPU. Warning No. %d/%d (CPU usage: %d%%)",
              entry->curr->user,entry->curr->no_cpu_warnings,no_of_warnings,
              cpu_usage);
            log_msg(str,1);
            entry->curr->no_cpu_warnings++;
          }
/*monitor mem load*/
        mem_usage = (entry->curr->rss * 100) / total_rss;
        if(mem_usage < 0) mem_usage = 0;
        sprintf(str,"Monitor: Memory usage for '%s' is at %d%%",
          entry->curr->user,mem_usage);
        log_msg(str,0);
        if(entry->curr->no_mem_warnings > no_of_warnings)
        {
          sprintf(str,
            "That's it!, you are now 'kill -9'ed for memory abuse!!. Good bye"
            " (Memory usage: %d%%)",mem_usage);
          warn_user(us_entry,str);
          clobber_user(entry->curr->uid);
          sprintf(str,"Notify: '%s' clobberd.. Memory abuse (Memory usage: %d%%)",
            entry->curr->user,mem_usage);
          log_msg(str,1);
        }
        else
          if(mem_usage > us_entry->curr->mem_limit)
          {
            sprintf(
              str,
              "You are using up too much memory. Please stop. Warning No. %d/%d"
              " (Memory usage: %d%%)",
              entry->curr->no_mem_warnings,no_of_warnings,mem_usage);
            warn_user(us_entry,str);
            sprintf(
              str,
              "Notify: '%s' pounding Memory. Warning No. %d/%d (Memory usage: %d%%)",
              entry->curr->user,entry->curr->no_mem_warnings,no_of_warnings,
              cpu_usage);
            log_msg(str,1);
            entry->curr->no_mem_warnings++;
          }
      }
      else
      {
        sprintf(str,"Monitor: '%s' is not marked. User ignored",entry->curr->user);
        log_msg(str,0);
      }
    }
    else
    {
      sprintf(str,"Monitor: '%s' is not logged. User ignored",entry->curr->user);
      log_msg(str,0);
    }
  }
  if(entry->next != NULL) monitor_user(entry->next);
}

void monitor_users(tutmp_ll *entry)
{
  timer_used = timer - old_timer;
  monitor_user(entry);
}

/***************************************************************************
*
***************************************************************************/
void print_header(tKon_info *K)
{
  sprintf(str,"\nHello %s!, welcome to Clobberd-%s at [%s]\n\n",
    K->user,VERSION,our_hostname);
  wtt(K->s,str);
  wtt(K->s,"Command options are:\n");
  if(K->rootflag)
  {
    wtt(K->s," o naughty <user>  Clobber/band user...Bad Doggy, Bad!\n");
    wtt(K->s," o cool <user>     Band user.. let them back on\n");
    wtt(K->s," o wipe <user>     Wipe user stats\n");
    wtt(K->s," o wipeall         Wipe all user stats\n");
    wtt(K->s," o die             Blow clobberd out of the water\n");
  }
  wtt(K->s," o stat            Display stats of all users\n");
  wtt(K->s," o help            Displays this shit\n");
  wtt(K->s," o seeya           Quit this session\n\n");
}

/***************************************************************************
*
***************************************************************************/
void print_user_entries(tKon_info *K,tutmp_ll *entry)
{
  if(entry->curr != NULL)
  {
    tusettings_ll *us_entry;

    user = entry->curr->user;
    us_entry = find_user_settings(&usettings_ll_root);
    if(us_entry != NULL)
    {
      register time_t ttl,dtl;
      register int cpu_usage,mem_usage;

      ttl = us_entry->curr->total_time_limit - entry->curr->total_time_used;
      if(ttl < 0) ttl = 0;
      dtl = us_entry->curr->daily_time_limit - entry->curr->daily_time_used;
      if(dtl < 0) dtl = 0;
      ttl /= 60;
      dtl /= 60;
      cpu_usage =
        ((entry->curr->jiffies - entry->curr->old_jiffies) * 100) /
        (total_jiffies - old_total_jiffies);
      if(cpu_usage < 0) cpu_usage = 0;
      mem_usage = (entry->curr->rss * 100) / total_rss;
      if(mem_usage < 0) mem_usage = 0;
      strcpy(str,"         Yes                                              No \n");
      memcpy(str + 0,entry->curr->user,strlen(entry->curr->user));
      if(!entry->curr->active) memcpy(str + 9,"No ",3);
      sprintf(substr,"%d:%d",(int)(ttl / 60),(int)(ttl % 60));
      memcpy(str + 13,substr,strlen(substr));
      sprintf(substr,"%d:%d",(int)(dtl / 60),(int)(dtl % 60));
      memcpy(str + 21,substr,strlen(substr));
      sprintf(substr,"%d",us_entry->curr->nice_factor);
      memcpy(str + 29,substr,strlen(substr));
      sprintf(substr,"%d",cpu_usage);
      memcpy(str + 33,substr,strlen(substr));
      sprintf(substr,"%d",mem_usage);
      memcpy(str + 37,substr,strlen(substr));
      sprintf(substr,"%d",entry->curr->no_ttime_warnings - 1);
      memcpy(str + 42,substr,strlen(substr));
      sprintf(substr,"%d",entry->curr->no_dtime_warnings - 1);
      memcpy(str + 46,substr,strlen(substr));
      sprintf(substr,"%d",entry->curr->no_cpu_warnings - 1);
      memcpy(str + 50,substr,strlen(substr));
      sprintf(substr,"%d",entry->curr->no_mem_warnings - 1);
      memcpy(str + 54,substr,strlen(substr));
      if(entry->curr->naughty) memcpy(str + 58,"Yes",3);
      wtt(K->s,str);
    }
    if(entry->next != NULL) print_user_entries(K,entry->next);
  }
}

void print_user_info(tKon_info *K)
{
  wtt(K->s,"         Act Total   Daily        %   %   No of Warnings\n");
  wtt(K->s,"Name     ive TimeL   TimeL   Nce CPU Mem  TT  DT  Cu  Mm  Naughty\n");
  wtt(K->s,"=================================================================\n");
  print_user_entries(K,&utmp_ll_root);
  wtt(K->s,"\n");
}

/***************************************************************************
*
***************************************************************************/
void get_new_Kons(void)
{
  register int x;
  struct timeval tv = {0,0};

  for(x = 0;x < MAX_CONNECTIONS;x++)
    if(Kon_info[x].s == -1)
    {
      fd_set fds;
      struct sockaddr_in sin;

      FD_ZERO(&fds);
      FD_SET(0,&fds);
      FD_SET(main_socket,&fds);
      select(main_socket + 1,&fds,NULL,NULL,&tv);
      if(FD_ISSET(main_socket,&fds))
      {
        Kon_info[x].s =
          accept(main_socket,(struct sockaddr *)&sin,&newaddrsize);
        fcntl(Kon_info[x].s,F_SETFL,O_NONBLOCK);
        if(Kon_info[x].s != -1)
        {
          struct hostent *newhost;
          register int socket_d;

          newhost = gethostbyaddr((char *)&(sin.sin_addr.s_addr),4,AF_INET);
          if(newhost != NULL)
            strcpy(Kon_info[x].addr,newhost->h_name);
          else
            strcpy(Kon_info[x].addr,"UNKNOWN");
/*Ident connection*/
          Kon_info[x].rootflag = 0;
          strcpy(Kon_info[x].user,"frednurk"); /*Fred Nurk is an australian
            version of 'John Doe' for those that don't know this*/
          socket_d = tcpip_client_creat(Kon_info[x].addr,113);
          if(socket_d != -1)
          {
            sprintf(substr,"%d, %d\n",ntohs(sin.sin_port),NET_PORT);
            wtt(socket_d,substr);
            memset(str,0,STR_LEN);
            if(read(socket_d,&str,STR_LEN) >= 0)
            {
              substr[0] = 0;
              if(strstr(str,"USERID"))
              {
                char *p = &(str[strlen(str)]);
                char *p2 = p;
                register int a = 0;

                while(!((*p == ':') || (*p == ' '))) p--;
                p++;
                while(p < (p2 - 2))
                {
                  if(a == 8) break;
                  Kon_info[x].user[a++] = *(p++);
                }
                Kon_info[x].user[a] = 0;
                if((our_ip == sin.sin_addr.s_addr) &&
                   (!strcmp(Kon_info[x].user,"root")))
                  Kon_info[x].rootflag = 1;
              }
            }
            shutdown(socket_d,2);
          }
          sprintf(str,"Info: New connection [%s@%s]",
            Kon_info[x].user,Kon_info[x].addr);
          log_msg(str,1);

          print_header(&Kon_info[x]);
          wtt(Kon_info[x].s,"> ");
        }
      }
    }
}

/***************************************************************************
*
***************************************************************************/
void monitor_Kons_uc(int x)
{
  if(strcmp(str,"stat") == 0)
    print_user_info(&Kon_info[x]);
  else if(strcmp(str,"help") == 0)
    print_header(&Kon_info[x]);
  else if(strcmp(str,"seeya") == 0)
  {
    wtt(Kon_info[x].s,"Bye Bye.\n");
    kill_Kon(&Kon_info[x]);
  }
  else
    wtt(Kon_info[x].s,"sorry?\n");
}

void monitor_Kons(void)
{
  register int x;

  for(x = 0;x < MAX_CONNECTIONS;x++)
    if(Kon_info[x].s != -1)
    {
      char *nstr = rtt(&Kon_info[x]);
      if((nstr != NULL) && (errno == EAGAIN))
      {
        sscanf(nstr,"%s",str);
        if(Kon_info[x].rootflag)
        {
          if(strcmp(str,"naughty") == 0)
          {
            sscanf(nstr,"naughty %s",substr);
            substr[8] = 0;
            user = substr;
            naughty_flag = 1;
            if(set_naughty_user(&utmp_ll_root))
              wtt(Kon_info[x].s,"Ok.\n");
            else
              wtt(Kon_info[x].s,"User not found.\n");
          }
          else if(strcmp(str,"cool") == 0)
          {
            sscanf(nstr,"cool %s",substr);
            substr[8] = 0;
            user = substr;
            naughty_flag = 0;
            if(set_naughty_user(&utmp_ll_root))
              wtt(Kon_info[x].s,"Ok.\n");
            else
              wtt(Kon_info[x].s,"User not found.\n");
          }
          else if(strcmp(str,"wipe") == 0)
          {
            sscanf(nstr,"wipe %s",substr);
            substr[8] = 0;
            user = substr;
            if(reset_user_stuff(&utmp_ll_root))
              wtt(Kon_info[x].s,"Ok.\n");
            else
              wtt(Kon_info[x].s,"User not found.\n");
          }
          else if(strcmp(str,"wipeall") == 0)
          {
            total_reset();
            wtt(Kon_info[x].s,"Ok.\n");
          }
          else if(strcmp(str,"die") == 0)
          {
            wtt(Kon_info[x].s,"Will die next wakeup.\n");
            log_msg("Info: Remote kill. Clobberd will die next wakeup",1);
            kill_Kon(&Kon_info[x]);
            running = 0;
          }
          else
           monitor_Kons_uc(x);
        }
        else
          monitor_Kons_uc(x);
        wtt(Kon_info[x].s,"> ");
      }
    }
}

/***************************************************************************
*
***************************************************************************/
void talk_to_Kons(void)
{
  time_t ltime = time(NULL);
  listen_loop = 1;
  while(listen_loop)
  {
    get_new_Kons();
    monitor_Kons();
    sleep(1);
    if((time(NULL) - ltime) > sleep_time) break;
  }
}

/***************************************************************************
*
***************************************************************************/
int main(int argc,char *argv[])
{
  register int x;

  printf(WELCOME);
  for(x = 0;x < argc;x++)
  {
    if(argv[x][0] == '-')
    {
      switch(argv[x][1])
      {
        case 'h':
          printf(
            "\nUsage: clobberd <options>\n"
             " -h        Display this help info\n"
             " -!        Run as normal process, logs sent to screen.\n"
             "\n"
          );
          return 1;
        case '!':
          daemon_mode = 0;
          break;
      }
    }
  }
  init();
  if((main_socket = tcpip_serv_creat()) != -1)
  {
    log_msg("-----Clobberd Fired Up-----",1);
    sprintf(str,"Init: Clobberd on [%s] listening on port %d "
                "and priming..",our_hostname,NET_PORT);
    log_msg(str,1);
    old_timer = timer;
    timer = time(NULL);
    if(get_user_settings())
    {
      load_users();
      if(get_active_users()) get_user_loads();
/*NB/ not required to save user file*/
      free_user_settings(&usettings_ll_root);
    }
    while(running)
    {
      log_msg("Init: -------Daemon Monitoring----",0);
      old_timer = timer;
      timer = time(NULL);
      if(get_user_settings())
      {
/*NB/ not required to load user file*/
        if(get_active_users())
        {
          reset_at_midnight();
          get_user_loads();
          monitor_users(&utmp_ll_root);
          log_msg("Init: -------Daemon Netting-------",0);
          talk_to_Kons();
        }
        else
          sleep(sleep_time);
        save_users();
        free_user_settings(&usettings_ll_root);
      }
      else
        sleep(sleep_time);
    }
    free_user_entries(&utmp_ll_root);
    log_msg("-----Clobberd End----------",1);
    tcpip_serv_reaper();
  }
  return 1;
}
