#!/bin/sh
echo "Module:        #pages:  Used by:"
cat /proc/modules
