#!/bin/sh
echo "Module:        #pages:  Used by:"
cat /proc/modules | if [ $# -ge 1 ]; then grep "^${1} ";else cat;fi
