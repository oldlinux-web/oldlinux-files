/* Kernel includes */
#define __NO_VERSION__
#include <linux/config.h>
#include <linux/errno.h>
#include <asm/segment.h>
#include <linux/kernel.h>
#include <linux/signal.h>
#include <linux/module.h>
#include <linux/version.h>

char kernel_version[] = UTS_RELEASE;

extern int base(int, char *);

static int level = 1;

int
init_module( void) {
	base(level, "hello");
	return 0;
}

void
cleanup_module( void) {
	if (MOD_IN_USE)
		printk("top: busy, remove delayed\n");
}
