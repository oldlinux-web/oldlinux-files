/*
 * This file defines the tokens used while parsing the gcc -E output
 *
 * Bjorn Ekwall <bj0rn@blox.se>, December 1994
 *
 */
#define STRUCT 257
#define UNION 258
#define ENUM 259
#define TYPEDEF 260
#define SEMI 261
#define LBRACE 262
#define RBRACE 263
#define LPAREN 264
#define RPAREN 265
#define S_TYPE 266
#define TYPE 267
#define IDENT 268
#define OTHER 269
#define FILENAME 270
#define STRING 271
