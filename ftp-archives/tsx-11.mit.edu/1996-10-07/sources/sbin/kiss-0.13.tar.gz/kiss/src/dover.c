#include "kiss.h"
#include "version.h"
#include "subversion.h" 

int dover (Stringstack s)
{
    printf ("KISS V" VERSION " [" SUBVERSION "]\n");

    return (0);
}
