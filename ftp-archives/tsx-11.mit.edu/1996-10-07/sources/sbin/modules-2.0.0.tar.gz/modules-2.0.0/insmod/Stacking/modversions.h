#ifdef MODVERSIONS
#undef  CONFIG_MODVERSIONS
#define CONFIG_MODVERSIONS
#ifndef _set_ver
#define _set_ver(sym,vers) sym ## _R ## vers
#endif
#include "base.ver"
#include <linux/modules/ksyms.ver>
#undef  CONFIG_MODVERSIONS
#endif
