/* Kernel includes */
#include <linux/config.h>
#include <linux/module.h>

void
base(int level, char *s)
{
	printk("in base, level %d, string='%s'\n", level, s);
}

static struct symbol_table base_syms = {
#include "symtab_begin.h"
	X(base),
#include "symtab_end.h"
};

int
init_module( void)
{
	register_symtab(&base_syms);
	return 0;
}

void
cleanup_module( void)
{
	return;
}
