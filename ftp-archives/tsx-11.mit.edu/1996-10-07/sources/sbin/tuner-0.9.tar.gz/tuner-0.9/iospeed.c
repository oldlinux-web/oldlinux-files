/*
 *	File IOSPEED.C		Created 19-APR-1992	Richard B. Johnson
 *	Purpose:
 *	Measures the I/O speed of a Unix-compatible file-system.
 *
 *      Note this is free software with no implied warranty and is not a
 *      Copyright work. It may be freely used/distributed/hacked, etc!
 *
 *      Version 1.00
 *
 *      Version 1.02                    26-APR-1992    Richard B. Johnson
 *      Changed the allocation of the filename buffer, FNAME[] from a global
 *      string to a pointer initiaized by malloc().
 *
 */

#define VERS "V1.02"                     /* Change version number here      */
#include <stdio.h>                       /* Used for FILE                   */
#include <fcntl.h>                       /* Used for O_BINARY, etc          */
#include <string.h>                      /* Used for _strchr(), etc         */
#include <sys/types.h>                   /* Used to make <sys/stat.h> work  */
#include <sys/stat.h>                    /* Used to get S_IWRITE S_IREAD    */
#include <time.h>
#include <malloc.h>
#ifdef MSDOS
#include <io.h>
#else
#include <unistd.h>
#endif

#ifndef O_BINARY
#define O_BINARY 0
#endif
#define FCREATE ( O_CREAT  | O_RDWR | O_BINARY)  /* Create new file         */
#define FACCESS ( S_IWRITE | S_IREAD )           /* File access mode        */
#define FOPENRD ( O_RDONLY | O_BINARY )          /* Open for read only      */

#define FAIL -1                                  /* Open close create fail  */
#define OKAY  0
#define OPEN_READ  0x50
#define CREATE     0x40
#define WRITE      0x30
#define READ       0x20
#define CLOSE      0x10
#define DELETE     0x00
#define BUFFER 0x7FFF
#define TIMES  0x200
#define FLEN   0x80
time_t start;
time_t stop;

short main(void);
short file_io(short, short * , unsigned char *, unsigned short);

char *fixup(unsigned char *, unsigned long);
char *fname;

short main()
{
    short i;
    short handle;
    short ret_val;
    unsigned char *buffer;
    unsigned long total;
    unsigned long speed;

    printf("IOSPEED  Version %s             Analogic Software Tools\n", VERS);
    puts("Testing disk I/O speed");
    buffer = (unsigned char *) malloc(BUFFER * sizeof(unsigned char));
    if (!buffer)
    {
        puts("Memory allocation failed!");
        return FAIL;
    }
    fname = (char *) malloc(FLEN * sizeof(char));
    if (!fname)
    {
        puts("Memory allocation failed!");
        free(buffer);
        return FAIL;
    }
    time(&start);
    sprintf(fname,"%08lX.TMP",start);
    ret_val = file_io(CREATE, &handle, (unsigned char*)fname, 0);
    if(ret_val)
    {
        puts("File creation failed!");
        free(buffer);
        free(fname);
        return FAIL;
    }
    for (i=0; i<BUFFER; i++)
        buffer[i] = (unsigned char) (i & 0xFF);
    time(&start);

    for (i=0; i<TIMES; i++)
    {
        ret_val = file_io(WRITE, &handle, buffer, BUFFER);
        if (ret_val != BUFFER)
        {
            puts("Write to file failed!");
            file_io(CLOSE, &handle, buffer, BUFFER);
            free(buffer);
            free(fname);
            return FAIL;
        }
    }
    time(&stop);
    speed = (unsigned long) (stop - start);     /* Speed is in seconds    */
    if(!speed) speed=1;                         /* Guard div/0            */
    total = ((unsigned long)BUFFER) * ((unsigned long)TIMES);
    printf("Wrote a %s byte file in %ld seconds\n",
          (fixup(buffer,total)), speed);
    total /= speed;
    printf("Disk I/O write was %s bytes/second\n", (fixup(buffer,total)));
    file_io(CLOSE, &handle, buffer, 0);

    ret_val = file_io(OPEN_READ, &handle, (unsigned char*)fname, 0);
    if(ret_val)
    {
        puts("File open failed!");
        free(buffer);
        free(fname);
        return FAIL;
    }
    time(&start);
    for (i=0; i<TIMES; i++)
    {
        ret_val = file_io(READ, &handle, buffer, BUFFER);
        if (ret_val != BUFFER)
        {
            puts("File read failed!");
            file_io(CLOSE, &handle, buffer, BUFFER);
            free(buffer);
            free(fname);
            return FAIL;
        }
    }
    time(&stop);
    speed = (unsigned long) (stop - start);     /* Speed is in seconds      */
    if(!speed) speed=1;                         /* Guard against div/0      */
    total = ((unsigned long)BUFFER) * ((unsigned long)TIMES);
    printf("Read a %s byte file in %ld seconds\n",
          (fixup(buffer,total)), speed);
    total /= speed;
    printf("Disk I/O read was %s bytes/second\n", (fixup(buffer,total)));
    file_io(CLOSE, &handle, buffer, 0);
    file_io(DELETE, &handle, (unsigned char*)fname, 0);
    free(buffer);
    free(fname);
    return OKAY;
}

/*
 *  Convert a longword to a comma-delimited ASCII decimal string. Return
 *  a pointer to the string.  It is assumed that the buffer contains enough
 *  room for 30 bytes more than the original ASCII string.
 */

char *fixup(unsigned char *buffer, unsigned long value)
{
    unsigned char *whereis;
    short i, j;

    sprintf((char*)buffer, "%ld", value);      /* Create the ASCII string   */
    j = strlen((char*)buffer);                 /* Find it's length          */
    whereis = buffer + 30;                     /* Make workspace            */
    *whereis = 0x00;                           /* NULL terminate            */
    i = 0; 
    do {
        *whereis-- = buffer[j];                /* Copy string backwards     */
        if ((i) && (j) && (!(i%3)))            /* Find every third byte     */
                                               /* but not the first or last */
            *whereis-- = ',';                  /* ... and put in a comma    */
        i++;                                   /* Keep outside the compare  */
    } while(j--);
    whereis++;                                 /* Back to first character   */
    return (char*)whereis;                     /* New comma-deliminated     */
}

/*
 *  All disk I/O is performed by this routine. It makes it easy to change
 *  for different kinds of operating systems
 */

short file_io(short command, short *handle,
                 unsigned char *buffer, unsigned short len)

{
    switch (command)                             /* GOTO in disguise        */
    {
        case OPEN_READ:
        {
            if ( (*handle = open((const char *)buffer,FOPENRD) ) != FAIL )
                return OKAY;
            else
                return FAIL;
        }
       case CREATE:
        {
            if  ( (*handle = open (              /* Open (create) new file  */
               (const char *)buffer ,            /* File name in buffer     */
                             FCREATE ,           /* Create new file         */
                             FACCESS ))          /* Define access mode      */
                               != FAIL)          /* If successful           */
                return OKAY;
            else
                return FAIL;
        }
        case WRITE:
            return (write (*handle, buffer, len));
        case READ:
            return (read (*handle, buffer, len));
        case CLOSE:
            return (close (*handle));
        case DELETE:
            return (remove ((char*)buffer));
    }
    return FAIL;                                            /* Bad function */
}
/****************************************************************************/
/************************ E N D  O F  M O D U L E  **************************/


