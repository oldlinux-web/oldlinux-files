/*
 *  File speed4.c         Created 20-JAN-1993  Richard B. Johnson
 *
 *  This is not a Copyright work and may be freely used for any purpose
 *  whatsoever.
 *
 *  This bench-marks important capabilites of various operating systems.
 *  It writes a string to a dumb terminal representing the length of
 *  time necesary to perform both CPU intensive and I/O intensive portions
 *  of typical programs.
 *
 *  Tunable system parameters (if any) may be adjusted to optimize the
 *  performance.
 */




#include <stdio.h>
#define SS$_NORMAL 1
#define SS$_ABORT  255
#ifndef VAX
#include <malloc.h>                     /* doesn't exist on a VAX           */
#endif
#include <math.h>
#include <string.h>
#include <time.h>
#ifndef SEEK_SET                        /* Does not seem to be on Sun       */
#define SEEK_SET 0
#endif

#define LARGE_BLOCK (32767 * sizeof(char))
#define SMALL_BLOCK (512 * sizeof(char))
#define PIK (LARGE_BLOCK / SMALL_BLOCK)
#define ARRAY_SIZE 4096 
#define MAX_FILE 40
#define MAX 512
#define pi 3.141592654

short main();
char fname[132];
char *spaces;
double *numbers;
FILE *file;

short main()
{
    unsigned char *small_buffer;
    unsigned char *large_buffer;
    unsigned short i,j,l;
    short    total;
    time_t   start;
    time_t   finish;


    time(&start);
    sprintf(fname,"%08lX",start);
    strcat(fname,".tmp");

    puts("Use ^\\ to quit");
    spaces = (char *)malloc(ARRAY_SIZE * sizeof(char));
    if (!spaces)
    {
        puts("No memory!");
        return SS$_ABORT;
    }
    numbers = (double *)malloc(ARRAY_SIZE * sizeof(double));
    if (!numbers)
    {
        puts("No memory!");
        return SS$_ABORT;
    }
    /* Memory intensive routines */
    for(;;)
    {
        time(&start);
        for (l=0; l<20; l++)
        {
            small_buffer = (unsigned char *) malloc(SMALL_BLOCK);
            if (!small_buffer)
            {
                puts("No memory!");
                return SS$_ABORT;
            }
            large_buffer = (unsigned char *) malloc (LARGE_BLOCK);
            if (!large_buffer)
            {
                puts("No memory!");
                return SS$_ABORT;
            }
            for (i=0; i< SMALL_BLOCK; i++)
            {
                small_buffer[i] = (unsigned char) (i & 0xFF);
                j = (unsigned short) small_buffer[i];
            }
            for (i=0; i< LARGE_BLOCK; i++)
            {
                large_buffer[i] = (unsigned char) (i & 0xFF);
                j = (unsigned short) large_buffer[i];
            }
            for (i=0; i< SMALL_BLOCK; i++)
            {
                small_buffer[i] = large_buffer[i];
                j = (unsigned short) small_buffer[i];
            }
            for (i=0; i< SMALL_BLOCK; i++)
            {
                large_buffer[i* PIK] = small_buffer[i];
                j = (unsigned short) small_buffer[i];
            }
            free(small_buffer);
            free(large_buffer);
            for (i=0; i<ARRAY_SIZE; i++)
                numbers[i] = (double) i+1;
            j = ARRAY_SIZE - 1;
            for (i=0; i<ARRAY_SIZE; i++)
                numbers[i] = pi;

            for (i=0; i<ARRAY_SIZE; i++)
            {
                /* Do some arithmetic  */
                numbers[i] = numbers[i] * numbers[j];
                numbers[i] = sin(numbers[j]);
                numbers[j] = numbers[j] + numbers[i];
                numbers[j] = numbers[j] + tan(numbers[i]);
                numbers[i] = numbers[i] * cos(numbers[j]);
                numbers[i] = numbers[i] + sqrt(numbers[j]);
                numbers[j] = pow(numbers[i],numbers[j]);
                /* Do some floating-point compares */
                if (numbers[i] != numbers[j])
                    numbers[j] = numbers[i];
                if (numbers[j] == (double) j)
                    numbers[j] = numbers[i];
                if (numbers[i] == (double) i)
                    numbers[i] = numbers[j];
                if (numbers[i] > 0.0)
                {
                    while (numbers[i] > 0.0)
                        numbers[i] *= -1.0;
                    while (numbers[i] < 0.0)
                        numbers[i] *= -1.0;
                }
                else 
                {
                    while (numbers[i] < 0.0)
                        numbers[i] *= -1.0;
                    while (numbers[i] > 0.0)
                        numbers[i] *= -1.0;
                }
                if (numbers[j] > 0.0)
                {
                    while (numbers[j] > 0.0)
                        numbers[j] *= -1.0;
                    while (numbers[j] < 0.0)
                        numbers[j] *= -1.0;
                }
                else 
                {
                    while (numbers[j] < 0.0)
                        numbers[j] *= -1.0;
                    while (numbers[j] > 0.0)
                        numbers[j] *= -1.0;
                }
            j--;
            }
        }
        time(&finish);
        total = (short) (finish - start);
        memset(spaces,'=',total);
        spaces[total] = 0x00;
        printf("CPU : %02d <%s>\n", total, spaces);
        if (feof(stdin)) break;
        time(&start);
        large_buffer = (unsigned char *) malloc (LARGE_BLOCK);
        if (!large_buffer)
        {
            puts("No memory!");
            return SS$_ABORT;
        }
        file = fopen(fname, "w+b");
        if(!file)
        {
            puts("Can't create a work file!");
            return SS$_ABORT;
        }
        for (i=0; i<LARGE_BLOCK; i++)
            large_buffer[i] =  (unsigned char) (i & 0xFF);

        for (i=0; i<MAX_FILE; i++)
        {
            j = fwrite(large_buffer, sizeof(char), LARGE_BLOCK, file);
            if (!j)
            {
                puts("Can't extend work file!");
                fclose(file);
                remove(fname);
                return SS$_ABORT;
            }
        }
        if ((fseek(file, 0, SEEK_SET))) perror("Seek failed");
        i = MAX_FILE;
        while (i--)
        {
            j = fread(large_buffer, sizeof(char), LARGE_BLOCK, file);
            if (!j)
            {
                printf("Error %d on file read\n", (ferror(file)));
                fclose(file);
                remove(fname);
                return SS$_ABORT;
            }
        }
        fclose(file);
        remove(fname);
        free(large_buffer);
        time(&finish);
        total = (short) (finish - start);
        i = (short) total;
        memset(spaces,'=',total);
        spaces[total] = 0x00;
        printf("IO  : %02d <%s>\n", total, spaces);
        if (feof(stdin)) break;                 /*  Does nothing on a VAX  */
  }
    return SS$_NORMAL;
}

