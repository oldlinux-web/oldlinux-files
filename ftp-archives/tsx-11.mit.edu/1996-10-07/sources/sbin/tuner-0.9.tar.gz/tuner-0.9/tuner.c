
/*
 *   File: tuner.c  Created 23-JUN-1995,  Richard B. Johnson
 *
 *   This program is not meant to be a Copyright work. It does things that
 *   are mostly Linux-specific and is therefore dedicated (given) to the
 *   Linux gurus world-wide. You may use this program for any purpose and
 *   may even chose to trash it. It is yours. You found it. It belongs to
 *   you.
 *
 *   That said, should you make any additions or improvements, please send
 *   revisions or patches to me at rjohnson@analogic.com.
 *
 *   Documentation is provided in the tuner.doc file included herewith.
 */  

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <sys/resource.h>
#include <malloc.h>
#include <string.h>
#include <syslog.h>
#include <signal.h>
#include <linux/tasks.h>
#include <time.h>

/* #define DEBUG */

#define STAT_LEN 1024
#define MAX_CPU  4                  /* 1/Nth available CPU to be allowed  */
#define MIN_CPU  2                  /* 1/Nth MAX_CPU to increase priority */
#define MAX_NICE 20
#define TIME_TO_ADJUST 2            /* Adjustment interval in seconds     */

#define TRUE 1
#define FALSE 0
#define ME argv[0]

typedef struct {
    pid_t pid;
    long last_time;
    long average;
    int  nice;
    int  active;
    } USAGE;

static const char *donot[]= {                      /* These will be ignored */ 
                   "(X)"           ,
                   "(update)"      ,
                   "(bdflush)"     ,
                   "(syslogd)"     ,
                   "(rpc.portmap)" ,
                   "(rpc.mountd)"  ,
                   "(rpc.nfsd)"    ,
                   "(rpc.pcnfsd)"  ,
                   "(inetd)"       ,
                   "(named)"       ,
                   "(crond)"       ,
                   "(klogd)"       ,
                   "" };

static const char fname[]="/proc";
static const char rundr[]="/var/run";
static const char pname[]="/var/run/tuner.pid";
static const char nomem[]="%s: Can't allocate memory!\n";
static const char sname[]="%s/%d/stat";
static const char logms[]="%s: setpriority: %m";
static const char setpr[]="setpriority";
static const char alrdy[]="%s: tuner daemon probably already running";
static int sig = 0;
static int alm = 0;
long get_cputime(char *);
void set_usage(USAGE *, char *);
void ticker(int);
void hup(int);

int main(int args, char *argv[])
{
    char dirname[0x20];
    DIR *dir;
    USAGE *usage;
    char *statbuf;
    long greatest;
    struct dirent *entry;
    pid_t *pids, pid, hog, my_pid;
    size_t i, j, num_pids, counter, new_high_water, cpu_lower,
           old_high_water, num_active, cpu_limit, ctime;
    time_t checker; 
    int fd;

#ifndef DEBUG
    if((fork()) !=0) return 0;
#endif 

    if ((statbuf = (char *) malloc(STAT_LEN * sizeof(char))) == NULL)
    {
        fprintf(stderr, nomem, ME);
        return 1; 
    }
    if ((pids = (pid_t *) malloc(NR_TASKS * sizeof(pid_t))) == NULL)
    {
        fprintf(stderr, nomem, ME);
        (void) free (statbuf);
        return 1;
    }
    if ((usage = (USAGE *) malloc(NR_TASKS * sizeof(USAGE))) == NULL)
    {
        fprintf(stderr, nomem, ME);
        (void) free (statbuf);
        (void) free (pids);
        return 1;
    }
#ifndef DEBUG
    my_pid = setsid();
/*
 *  This will assure that there is only one copy running if, and only if
 *  there is at least 3 seconds between attempted execution of multiple
 *  copies of the daemon.
 */ 
    pid = 0;
    if ((fd = open(pname, O_RDONLY, 0)) > 0)
    {
        syslog(LOG_ERR, alrdy, ME);
        if ((read(fd, statbuf, STAT_LEN)) > 0)
            pid = (pid_t) atoi(statbuf);
        (void)close(fd);
        if(pid)
        {
            (void) kill(pid, SIGHUP);
            (void) sleep(1);
        }
    }
/*
 *  This makes a file containing the daemon pid so it can be readily
 *  killed for a reasonable rundown. It file creation fails, we get
 *  the next available file discriptor anyway so we can close all files.
 *  The new "standard place" for these kinds of files is in /var/run.
 *  If the directory doesn't exist, it is created.
 */ 
    (void)mkdir(rundr, S_IXUSR|S_IWUSR|S_IRUSR|S_IRGRP|S_IROTH);
    if ((fd = open(pname, O_CREAT|O_WRONLY, 0)) > 0)
    {
        sprintf(statbuf, "%d", my_pid);
        (void) write(fd, statbuf, strlen(statbuf));
    }
    else
        fd = open("/", O_RDONLY, 0);
    do { (void)close(fd--); } while (fd);
#else
    my_pid = getpid();
#endif

/* 
 *  Calibrate to see how many ticks are available in a second. 
 */
#ifdef DEBUG
    puts("Calibrating.");
#endif
    ticker(0);
    for(alm=0; !alm; )
        ;
    checker = clock();
    for(alm=0; !alm; )
        ;
    ctime = (size_t) ((clock()) - checker);
    alarm(0);
#ifdef DEBUG
    printf("Max CPU is %d\n", ctime);
#endif
    bzero(usage, (NR_TASKS * sizeof(USAGE))); 
    (void)signal(SIGHUP,  hup);
    (void)signal(SIGINT,  hup);
    (void)signal(SIGTERM, hup);
    new_high_water = NR_TASKS; 
    old_high_water = 0;
    counter = 0;
    ticker(0);
    while(!sig)
    {
        for(i=0; i< new_high_water; i++) usage[i].active = FALSE;
        bzero(pids, (NR_TASKS * sizeof(pid_t))); 
        hog = 0; num_active = 0; num_pids = 0; greatest = 0L;
        if ((dir = opendir(fname)) == NULL)
        {
#ifdef DEBUG
            fprintf(stderr, "%s: Can't access directory %s\n", ME, fname);
#else
            syslog(LOG_ERR, "%s: Can't access %s, exiting.", ME, fname);
#endif
            (void) free (statbuf);
            (void) free (usage);
            (void) free(pids);
            return 1;
        }
        while ((entry = readdir(dir)) != NULL)
        {
            if ((pid = (pid_t) atoi(entry->d_name)) > 1)
            {
                if(pid != my_pid)
                    pids[num_pids++] = pid;
            }
        }
        (void)closedir(dir); 
        for(i=0; i< num_pids; i++)
        {
            sprintf(dirname, sname, fname, pids[i]);
            if ((fd = open(dirname, O_RDONLY, 0)) < 0)
                continue;                       /* Process exited */
#ifdef DEBUG
            printf("PID: %d, Average : ", pids[i]);
#endif
            if ((read(fd, statbuf, STAT_LEN)) > 0)
            {
                for(j=0; j< new_high_water; j++)
                {
                    if(usage[j].pid == pids[i]) /* Found old pid to use    */
                    {
                        set_usage(&usage[j], statbuf);
                        if(usage[j].average > 0)
                            num_active++;
                        if(usage[j].average > greatest)
                        {
                            greatest = usage[j].average;
                            hog = pids[i];
                        }
                        break;
                    }
                } 
                if(j == new_high_water)         /* New pid,  add an entry  */
                {
                    for(j=0; j< NR_TASKS; j++)
                    {
                        if(usage[j].pid == 0)
                        {
                            usage[j].pid = pids[i];
                            set_usage(&usage[j], statbuf);
                            usage[j].average = 0;
                            if(j >= old_high_water)
                                new_high_water = old_high_water = j;
                            break;
                        }
                    }
                }
            }
            (void)close(fd);
        }
        /*
         * Try to shrink the list if possible.
         */
        j = new_high_water;
        while (usage[--j].active != TRUE)
        {
             bzero(&usage[j], sizeof(USAGE));
             new_high_water = old_high_water = j;
        }
        /*
         *  Clear unused slots from dead processes.
         */
        for(j=0; j< new_high_water; j++)
        {
            if (usage[j].active != TRUE)
                bzero(&usage[j], sizeof(USAGE));
        }
#ifdef DEBUG
        printf("CPU hog: %d, time %ld\n", hog, greatest);
        printf("High water mark: %d\n", new_high_water);
#endif
        /*
         *  If it's time to adjust process quotas.
         */
        if(counter++ > TIME_TO_ADJUST)
        {
            counter = 0;
            cpu_limit = (ctime / MAX_CPU);
            if(num_active > 0)
                cpu_limit /= num_active;
            cpu_lower = (cpu_limit / MIN_CPU);

            for(j=0; j < new_high_water; j++)
            {
                if(usage[j].pid == 0)
                    continue;
                if(usage[j].average < cpu_lower)
                {
                    if (usage[j].nice > 0)
                        usage[j].nice--;
                }
                else if (usage[j].average > cpu_limit)
                {
                    if  (usage[j].nice < MAX_NICE)
                         usage[j].nice++;
                    if ((usage[j].pid == hog) && (usage[j].nice < MAX_NICE))
                         usage[j].nice++;
                }
                usage[j].nice |= ((rand()) & 1);
                if((setpriority(PRIO_PROCESS, usage[j].pid, usage[j].nice))<0)
                {
                    if(errno != ESRCH)
#ifdef DEBUG
                        perror(setpr);
#else
                        syslog(LOG_ERR, logms, ME);
#endif
                }
            }
        }
        (void)pause();
    }
/*
 *   We have been told to shut down. Therefore, we will set all active
 *   process "nice" values back to 0 before we exit.
 */
    for(j=0; j< new_high_water; j++)
    {
        if(usage[j].pid == 0)
            continue;
        if((setpriority(PRIO_PROCESS, usage[j].pid, 0)) < 0)
        { 
           if(errno != ESRCH)
#ifdef DEBUG
               perror(setpr);
#else
               syslog(LOG_ERR, logms, ME);
#endif
        }
    }

#ifndef DEBUG
    syslog(LOG_ERR, "%s: exit forced by signal %d", ME, sig);
#endif

    (void) free(usage);                         /* Professional do nothing */
    (void) free(statbuf);
    (void) free(pids);
    (void) remove(pname);
    return 0;
}
/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
/*
 *  One-second timer.
 */
void ticker(int asig)
{
    (void)signal(SIGALRM, ticker);
    alarm(1);
    alm = asig;
}
/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
/*
 *  Does something.
 */
void hup(int csig)
{
    sig = csig;
}
/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
/*
 *  This gets the process CPU time from the "stats" buffer. If the process
 *  name is in the "donot[]" list, return 0 for CPU usage.
 */
long get_cputime(char *buffer)
{
    int i;
    for(i=0; *donot[i]; i++)
    {
        if ((strstr(buffer, donot[i])) != NULL)
        {
#ifdef DEBUG
            printf("Ignoring %s ", donot[i]);
#endif
            return 0L;
        }
    }
    for(i=0; i< 13; i++)
        while (*buffer++ > 0x20);
    return(atol(buffer));
}
/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
/*
 *   This sets process resource usage into the "USAGE" array. We might
 *   also save other resources by adding entries into the USAGE
 *   structure. The CPU time is filtered with simple averaging at the
 *   present time.
 */
void set_usage(USAGE *usage, char *statbuf)
{
    long this_time;
    this_time = get_cputime(statbuf);
    usage->active = TRUE;
    usage->average += (this_time - usage->last_time);
    usage->average >>=1;
    usage->last_time = this_time;
#ifdef DEBUG
    printf("%ld\n", usage->average);
#endif
}
/*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
