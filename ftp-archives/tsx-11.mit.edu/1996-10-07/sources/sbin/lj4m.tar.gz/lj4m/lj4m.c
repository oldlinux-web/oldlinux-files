/* 
   lj4m.c -- Michael A. Covington and Mark L. Juric, 1994
   Pre-spooler filter for LaserJet 4M.
   Compile with gcc or ANSI C.
   Install with the "if=" (not "of=") option in /etc/printcap.
   Print jobs are logged as lpr.debug messages.

   Many small changes by Michael K. Johnson <johnsonm@sunsite.unc.edu>
   August 1994.  Should compile and work fine under Linux or most other
   operating systems.  Uses additional ANSI capability, including
   string pasting, in an attempt to make the source more readable.

   Now uses 90 character lines, which gives more room for error, and
   can waste less paper.

   Still doesn't deal with tabs, but I don't really care, so I'm
   not fixing it.

   Also doesn't even try to deal with DVI files.  There are larger
   packages that do this.

   Made it accept 6 arguments, since there can be one less argument
   if no accounting file is specified.  Otherwise it incorrectly
   decides that the username and hostname information was not
   provided.  I did not enhance the argument checking, since this
   is designed to be called by lpd, not be people...

   Also still doesn't check the line length or number lines per
   page that is passed in.
*/

#include <syslog.h>
#include <stdio.h>
#include <string.h>

#define CTRLD      "\004"
#define LINELENGTH 90

/***  HP LaserJet control sequences  ***/

#define RESET      "\033E"
#define LF_TO_CRLF "\033&k2G"
#define LMARGIN    "\033&a4L"
#define FONT       "\033(s0p(s12h(s4b(s4099T"
#define START_PJL  "\033%-12345X@PJL\n"
#define END_PJL    "\033%-12345X"
#define POSTSCRIPT "@PJL ENTER LANGUAGE = POSTSCRIPT\n"
#define PCL        "@PJL ENTER LANGUAGE = PCL\n"


/***  Global variables  ***/

int        c0, c;               /* first 2 chars of file      */
long int   bytes;               /* character count            */
char       userinfo[64] = "";   /* will be "username@machine" */


/*** Printer console display functions ***/

void DisplayOnPrinterConsole(char *s)
{
  fprintf(stdout,"%s@PJL RDYMSG DISPLAY = \"%s\"\n%s",
          RESET
          START_PJL,
          s,
          END_PJL
          RESET);
}

void ResetPrinterConsole()     /* to display "00 READY" */
{
  fprintf(stdout,"%s@PJL RDYMSG DISPLAY = \"\"\n%s",
          RESET
          START_PJL,
          END_PJL
          RESET);
}


/*** PostScript and HP file handling ***/

void PrintPostScriptFile()
{
  /* Choose language */
  fprintf(stdout,"%s",
	  RESET
	  START_PJL
	  POSTSCRIPT);

  /* Transmit file transparently */
  putc(c0,stdout);
  for (bytes=1; !feof(stdin); bytes++)
  {
     putc(c,stdout);
     c = getc(stdin);
  }

  /* Add newline, Ctrl-D, and reset at end */
  fprintf(stdout,"\n%s",
	  CTRLD
	  END_PJL
	  RESET);

  /* Log results */
  syslog(LOG_DEBUG,"%s, PostScript file, %d bytes",userinfo,bytes);
}


void PrintHPFile()
{
  /* Choose language */
  fprintf(stdout,"%s",
	  RESET
	  START_PJL
	  PCL);

  /* Transmit file transparently */
  putc(c0,stdout);
  for (bytes=1; !feof(stdin); bytes++)
  {
     putc(c,stdout);
     c = getc(stdin);
  }

  /* Reset printer at end */
  fprintf(stdout,"%s",
	  END_PJL
	  RESET);

  /* Log results */
  syslog(LOG_DEBUG,"%s, HP file, %d bytes",userinfo,bytes);
}


/*** ASCII and unprintable file handling ***/

#define PRINTABLE(c) (printable[(unsigned char) c])

char printable[256] =
   /* Table of which ASCII codes are printable characters */
       { 0,0,0,0,1,0,0,1,1,1,1,0,1,1,0,0,   /* NUL to ^O  */
         0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,   /* ^P to 31   */
         1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,   /* 32 to 47   */
         1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,   /* 48 to 63   */
         1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,   /* 64 to 79   */
         1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,   /* 80 to 95   */
         1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,   /* 96 to 112  */
         1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,   /* 113 to 127 */
         0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   /* 128 to 143 */
         0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   /* 144 to 159 */
         0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   /* 160 to 175 */
         0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   /* 176 to 191 */
         0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   /* 192 to 207 */
         0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   /* 208 to 223 */
         0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,   /* 224 to 239 */
         0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 }; /* 240 to 255 */
                                /* -1 (eof) maps onto 255 */


void RejectFileAsUnprintable()
{
  /* Set up printer again because it may have been disrupted */
  fprintf(stdout,"\n%s",
          RESET
          START_PJL
          PCL
          LF_TO_CRLF
          FONT
          LMARGIN);

  /* Dump 30 lines, printing '.' for unprintable characters */
  fprintf(stdout,
          "%s\nUnprintable data! Partial dump follows...\n",
          userinfo);

  for (bytes=1; bytes<LINELENGTH*30+1; bytes++)
  {
    if (feof(stdin)) break;
    if (c<32 || c>126) c = '.';
    fputc(c,stdout);
    if (bytes % LINELENGTH == 0) fputc('\n',stdout);
    c = getc(stdin);
  }

  /* Log the error */
  syslog(LOG_ERR,
         "LJ4M: %s: tried to print unprintable data\n",userinfo);

}


void PrintASCIIFile()
{
  int  position = 1;   /* where the next char on the line will be */
  int  ok_to_print;    /* true if no bad chars found */

  /* Set up printer */
  fprintf(stdout,"%s",
          RESET
          START_PJL
          PCL
          LF_TO_CRLF
          FONT
          LMARGIN);

  /* Deal with the first character already read */
  ok_to_print = PRINTABLE(c0) && PRINTABLE(c);
  if (ok_to_print && (c0 != EOF)) putc(c0,stdout);

  /* Process rest of file, breaking at column 90 and
     underlining last character if line continues beyond */

  for(bytes=1; ok_to_print && !feof(stdin); bytes++)
  {
    if (c==4 || c==26) break;       /* Skip UNIX or DOS EOF mark */

    /* Compute where c will print */
    if (c==10 || c==12 || c==13) position=0;    /* CR, FF, or LF */
    else if (c==8 && position>0) position--;    /* Backspace */
    else position++;

    /* If in a printable column, print it */
    if (position <= LINELENGTH) fputc(c,stdout);

    /* If we have just run past margin, underline last character */
    if (position == LINELENGTH+1) fputs("\b_",stdout);

    /* Obtain and check next character */
    c = getc(stdin);
    ok_to_print = PRINTABLE(c);
  }

  /* If a bad byte was found, print messages and dump */
  if(!ok_to_print) RejectFileAsUnprintable();

  /* Reset printer at end */
  fprintf(stdout,"%s",
	  END_PJL
	  RESET);

  /* If normal termination, report results */
  if (ok_to_print)
     syslog(LOG_DEBUG,"%s, ASCII file, %d bytes",userinfo,bytes);
}


/*** Main program ***/

main(int argc, char* argv[])
{
  /* Obtain machine name and user name from cmd line args */
  if (argc>7)
    sprintf(userinfo,"%s@%s",argv[5],argv[7]);
  else
    strcpy(userinfo,"Unknown username");

  DisplayOnPrinterConsole(userinfo);

  openlog("LaserJet 4M",0,LOG_LPR);

  /* Examine first 2 bytes, decide how to handle file */
  c0 = getc(stdin);
  c  = getc(stdin);

  if (c0=='%' && c=='!')
    PrintPostScriptFile();
  else if (c0==27 && (c=='E' || c=='%'))
    PrintHPFile();
  else
    PrintASCIIFile();

  /* Clean up */
  ResetPrinterConsole();
  closelog();
  return(0);       /* UNIX insists on return code 0. */
}
