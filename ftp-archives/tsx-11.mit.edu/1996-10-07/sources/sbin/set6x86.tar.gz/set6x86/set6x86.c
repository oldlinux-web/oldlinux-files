/*  get/set6x86: a tool for changing Cyrix 6x86 configuration registers
 *
 *  Copyright (C) 1996  Koen Gadeyne
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


/***
 *** This is just a hacking tool! Use at your own risk. It was NOT intended to be 
 *** idiot proof! If you don't understand all this, then don't bother trying to use it.
 ***
 ***/

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <asm/io.h>

typedef int bool;

#ifndef TRUE
#  define TRUE (1)
#endif
#ifndef FALSE
#  define FALSE (0)
#endif

char *CommandName;

void get_IO_range(int start, int len)
{
  if (ioperm(start, len, 1) != 0)
  {
    perror("I/O Permissions");
    fprintf(stderr,"Cannot get I/O permissions for hardware address range 0x%x-0x%x.\n\
             You must be superuser, or the program must be setuid root!\n", start, start+len-1);
    exit(1);
  }
}

void check_int_range(int cvalue, int lmin, int lmax, char* descstr)
{
  if (cvalue<lmin || cvalue>lmax)
    fprintf(stderr,"%s = %d (0x%x) out of range [%d..%d]!\n", descstr, cvalue, cvalue, lmin, lmax);
}

int getint(char* instring, char* descrstring, int lmin, int lmax)
  /* convert the int in 'instring' into an integer. Must be within specified limits 'lmin' and 'lmax' */
  /* 'descrstring' contains a description of the number to be parsed, used in error message */
{
  char** errstr=NULL;
  int readint;
  readint = strtol(instring,errstr,0);
  if (errstr)
    fprintf(stderr,"Illegal character '%s' in %s: '%s'\n", *errstr, descrstring, instring);
  check_int_range(readint, lmin, lmax, descrstring);
  return(readint);
}

char* int_to_bin(int num, int bits)
{
  static char binstr[sizeof(long int)+1];
  int i;
  
  for (i=0; i<bits; i++) binstr[i] = 0x30; /* char '0' */
  binstr[bits] = 0x00;
  
  for (i=0; i<bits; i++) binstr[bits-1-i] += ((num >> i) & 0x00000001);
  return(binstr);
}

void usage(int setreg)
{
     printf("%s 1.0 (c) 1996 Koen Gadeyne.\n"
     "\n"
     "  Usage: %s [options] register_index %s\n\n"
     "  Options: -h  print usage information\n"
     "           -s  silent mode: don't spread the news\n"
     "\n"
     "  register_index: An index to the specified Cyrix 6x86 config register,\n"
     "                  In decimal (e.g. '24'), hex ('0x18') or octal ('030').\n"
     "\n"
     "  %s\n",
     CommandName, CommandName,
     (setreg) ? "data" : "",
     (setreg) ? "data: the data to program into the specified register (dec|hex|oct).\n" : "");
}


/***********************************************************************************************************/
 
int main (int argc, char* argv[])
{
  int c;
  int tmpbyte=0;
  int regnum=0;
  bool setreg = FALSE;
  bool silent = FALSE;
  char* commandfilename;
  int data=0;
  
 /*
  * See what action is required: read or write
  */
    
  CommandName = argv[0];
  commandfilename = strrchr(CommandName, '/');
  if (commandfilename) commandfilename++;
  else commandfilename = CommandName;
  setreg = (!strncasecmp(commandfilename,"set",3));
  
 
 /*
  * command-line argument parsing
  */

  while ((c = getopt (argc, argv, "hs")) != EOF)
    switch (c)
    {
      case 'h': usage(setreg);
                exit(0);
                break;
      case 's': silent=TRUE;
                break;
      case '?': usage(setreg);
                printf("Bad option '-%c'\n",(char)optopt);
                exit(1);
                break;
      default: fprintf(stderr,"getopt returned unknown token '%c'.\n",c);
    }
    
  /* get register set from commandline */
  if (argc<optind+1) fprintf(stderr,"Missing register index on commandline\n");

  regnum = getint(argv[optind], "register index", 0, 255);

  /* get register data, if 'set'VGAreg command */
  if (setreg)
  {
    optind++;
    if (argc<optind+1) fprintf(stderr,"Missing register data\n");
    data = getint(argv[optind], "register data", 0, 255);
  }
  optind++;  
  if (argc>optind) fprintf(stderr,"Extra parameters (starting with '%s') ignored\n", argv[optind]); 
  

/*
 * start doing something useful
 */
 
  get_IO_range(0x22, 2);

  if (setreg)
  {
    outb(regnum, 0x22); outb(data, 0x23);
  }
  outb(regnum, 0x22); tmpbyte = inb(0x23);
  if (!silent)
  {
    printf("Cyrix 6x86 config register, index %d (=0x%x) contains %d (=0x%02x =b%s)\n",
            regnum, regnum, tmpbyte, tmpbyte, int_to_bin(tmpbyte,8));
  }
  return(0);
}
