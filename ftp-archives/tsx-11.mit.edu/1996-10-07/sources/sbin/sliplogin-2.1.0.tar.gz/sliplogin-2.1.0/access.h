
#define ACC_CONF "/etc/lines.conf"
#define ACC_PATH  "/var/access"
#define ACC_DAILY "/var/access/access.daily"
#define ACC_MONTH "/var/access/access.month"

/* Uhrzeit, bis zu der weitergehender Zugriff getestet wird. */
#define ACC_LHOUR 18

/* minimale Access-Zeit in Minuten, darunter gibt's keinen Zugriff */
#define MIN_ACCESS  0

/* max. Loginzeit bei Express-Lines pro Tag */
#define MAX_EXPRESS 30

#define UNKNOWN_TTY	-2
#define PSEUDO_TTY	-1
#define EXPRESS_LINE	1
#define NORMAL_LINE	2
#define OTHER_LINES	3

int access_init();

void set_wtmp(char prefix, char* host);
int get_access (char proto, char* host, void (*exit_fun)());
				/* setzt bei > 0 wtmp-entry */

				/* watch access after 'time' Minutes */
void watch_access(int ttynr, int time, void (*exit_fun)());
