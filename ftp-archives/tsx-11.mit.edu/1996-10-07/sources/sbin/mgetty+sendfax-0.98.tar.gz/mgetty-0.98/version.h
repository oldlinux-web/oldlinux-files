static char * mgetty_version = "official release 0.98";
