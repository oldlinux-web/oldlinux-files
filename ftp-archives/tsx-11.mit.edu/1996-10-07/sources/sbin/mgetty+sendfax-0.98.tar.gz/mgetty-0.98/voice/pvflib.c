/*
 * pvflib.c
 *
 */ 

char pvflib_c[] = "$Id: pvflib.c,v 1.7 1995/03/29 18:27:16 marc Exp $";

#include <stdio.h>
#include "../mgetty.h"
#include "pvflib.h"

int
zget _P1((f), FILE *f) {
    int d;
    d = (getc(f) & 0xff) <<8;
    d |= (getc(f) & 0xff);
    if (d >= 0x8000)	/* sign extend */
	d -= 0x10000;
    return d;
}

void
zput _P2((d, f), int d, FILE *f) {
    if(d >  0x7fff) d=  0x7fff;
    if(d < -0x8000) d= -0x8000;
    
    putc((d>>8)&0xff, f);
    putc( d    &0xff, f);
}
