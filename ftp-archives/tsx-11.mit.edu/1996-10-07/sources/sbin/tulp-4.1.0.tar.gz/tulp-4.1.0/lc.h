/* $Id: lc.h,v 1.1 94/07/11 18:34:48 listserv Exp $
 *
 *  Copyright (C) 1991-1994  Kimmo Suominen, Christophe Wolfhugel
 *
 *  Please read the files COPYRIGHT and AUTHORS for the extended
 *  copyrights refering to this file.
 *
 * $Log:	lc.h,v $
 * Revision 1.1  94/07/11  18:34:48  listserv
 * Initial revision
 * 
 * Revision 1.1  92/05/23  14:03:23  kim
 * External definitions from lc.c
 * 
 * External definitions from lc.c
 */

extern void listservCmd(char *file);
