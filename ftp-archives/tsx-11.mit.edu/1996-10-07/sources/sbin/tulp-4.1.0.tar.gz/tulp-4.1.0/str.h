/* $Id: str.h,v 1.1 94/07/11 18:34:53 listserv Exp $
 *
 *  Copyright (C) 1991-1994  Kimmo Suominen, Christophe Wolfhugel
 *
 *  Please read the files COPYRIGHT and AUTHORS for the extended
 *  copyrights refering to this file.
 *
 * $Log:	str.h,v $
 * Revision 1.1  94/07/11  18:34:53  listserv
 * Initial revision
 * 
 * Revision 1.1  92/05/23  14:06:53  kim
 * External definitions from str.c
 * 
 */

extern int strspacecmp(char*, char*);

#ifdef NEED_STRCASE
extern int strcasecmp(char*, char*);
extern int strncasecmp(char*, char*, int);
#endif
