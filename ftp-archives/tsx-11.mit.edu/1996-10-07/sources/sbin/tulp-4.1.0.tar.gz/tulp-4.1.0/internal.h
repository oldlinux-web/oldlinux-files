/* $Id: internal.h,v 1.1 94/07/11 18:34:46 listserv Exp $
 *
 *  Copyright (C) 1991,1992  Kimmo Suominen, Christophe Wolfhugel
 *
 *  Please read the files COPYRIGHT and AUTHORS for the extended
 *  copyrights refering to this file.
 *
 */

#if defined(USE_UNAME) || defined(USE_GETHOSTNAME)
# define HOST myname		/* Holds your name */
#endif
