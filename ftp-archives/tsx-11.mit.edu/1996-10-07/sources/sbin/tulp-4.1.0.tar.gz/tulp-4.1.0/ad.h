/* $Id: ad.h,v 1.1 94/07/11 18:34:42 listserv Exp $
 *
 *  Copyright (C) 1991,1992  Kimmo Suominen, Christophe Wolfhugel
 *
 *  Please read the files COPYRIGHT and AUTHORS for the extended
 *  copyrights refering to this file.
 *
 * $Log:	ad.h,v $
 * Revision 1.1  94/07/11  18:34:42  listserv
 * Initial revision
 * 
 * Revision 1.1  92/05/23  14:04:40  kim
 * External definitions from ad.c
 * 
 */

extern void adChange(char*);
