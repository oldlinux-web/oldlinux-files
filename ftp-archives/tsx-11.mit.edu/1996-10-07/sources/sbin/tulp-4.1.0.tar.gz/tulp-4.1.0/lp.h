/* $Id: lp.h,v 1.1 94/07/11 18:34:49 listserv Exp $
 *
 *  Copyright (C) 1991-1994  Kimmo Suominen, Christophe Wolfhugel
 *
 *  Please read the files COPYRIGHT and AUTHORS for the extended
 *  copyrights refering to this file.
 *
 * External definitions from lp.c
 */

extern int IsEditor(char *);
extern int IsOwner(char *);
extern int IsUser(char *);

extern void RewindUserList();
extern void RewindCommentList();
extern void RewindEditorList();
extern void RewindOwnerList();

extern int AddUser(char *);
extern int DelUser(char *);

extern void CloseUserList();
extern int ReadUserList(char *);
extern void WriteUserList();

extern char *GetUser(char *);
extern char *GetComment(char *);
extern char *GetEditor(char *);
extern char *GetOwner(char *);

extern char *GetErrorsTo();
extern char *GetReplyTo();
extern char *GetReview();
extern char *GetSend();
extern char *GetSubscription();
