/* $Id: l.h,v 1.1 94/07/11 18:34:46 listserv Exp $
 *
 *  Copyright (C) 1991,1992  Kimmo Suominen, Christophe Wolfhugel
 *
 *  Please read the files COPYRIGHT and AUTHORS for the extended
 *  copyrights refering to this file.
 *
 * $Log:	l.h,v $
 * Revision 1.1  94/07/11  18:34:46  listserv
 * Initial revision
 * 
 * Revision 1.1  92/05/23  14:05:45  kim
 * External definitions from l.c
 * 
 */

char *strlwr(char*), *strupr(char*);
void mailMsg(char*, char*);
