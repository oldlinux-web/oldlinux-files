/* $Id: popen.h,v 1.1 94/07/11 18:34:50 listserv Exp $
 *
 *  Copyright (C) 1991-1994  Kimmo Suominen, Christophe Wolfhugel
 *
 *  Please read the files COPYRIGHT and AUTHORS for the extended
 *  copyrights refering to this file.
 */

extern FILE *l_popen(char*, char*);
extern int l_pclose(FILE*);
extern void winInc(void);
