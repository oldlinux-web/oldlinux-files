/* $Id: ext.h,v 1.1 94/07/11 18:34:44 listserv Exp $
 *
 *  Copyright (C) 1991,1992  Kimmo Suominen, Christophe Wolfhugel
 *
 *  Please read the files COPYRIGHT and AUTHORS for the extended
 *  copyrights refering to this file.
 *
 */

/*
 * Extern definitions, don't touch!
 */

extern char vers[], buf[MAXLINE], rcpt[MAXFIELD];
extern char versFrom[],versHost[];
extern char From[],To[];
extern long msgSize;
extern void versInit();

extern int  Debug;

#ifdef ADD_SENDER
extern char versSender[];
#endif

#if defined(USE_UNAME) || defined(USE_GETHOSTNAME)
extern char myname[];
#endif
