/* HYPER Login (VER. 0.1.1 beta) by MiCRO^[[ of LiE */

/* TO DO:
   -=- improve input routines
   -=- catch harmful signals (CNTL-C, etc)
        -=- maybe even make a fake login for them, so that the user
            thinks that they are in long enough to track their ass
   -=- make more user-definable strings... (hack attempts, welcome-to
       -system message, etc...)
** -=- run .login
   -=- logging of all attempts, separate for false... also try to
       track the source of who did it...
   -=- good old forum-hack "lightbar mtrix" for login
   -=- new user voting team, password, application, etc system...
   -=- improve the imediate alarm for myself.. i want to know EXACTLY
       who is comming in and when!!
   -=- MAYBE include a leading "u want ANSi?" question, though, those
       w/o ANSi should die newayZ...
   -=- implement communication w/ utmp/wtmp and getty, etc...
                     [**=solved/improved]
*/

#define _POSIX_SOURCE 1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <termios.h>
#include <sys/types.h>


#include "ANSi.h"

#define BEEP "\x07"

char hyper_path[BUFSIZ];
int number_welcome_files;
char login_prompt[BUFSIZ];
int log_x,log_y;
char passwd_prompt[BUFSIZ];
int pas_x,pas_y;
char rnum[2];
int passed=0;
int done_passwd_entry=0;
char home_directory[80];
char shell_path[80];
char password[BUFSIZ]="";

/* ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: */

main ()
{
 int result;

 while (!passed)
 {
  read_configuration_file();
  choose_and_display_welcome_screen();
  display_prompt_and_login();
  gotoxy(1,25);
 }
 printf("\n\nWelcome to %s%sLiE WHQ%s%s...\n",BEEP,BEEP,BEEP,BEEP);
 printf("Informing %s%sMiCRO^[[%s%s of your login and logging your data\n",BEEP,BEEP,BEEP,BEEP);

 printf("HD:%s SP:%s xxx",home_directory,shell_path);

 if (result=chdir(home_directory)!=0) 
   {
    perror("HOMEDIR:");
    exit(1);
   }
 if (result=execl(shell_path,"tcsh","-l\0")!=0) /*cut end from path and put
                                                  into second arg, in case
                                                  tcsh isn't their shell!!*/
   {
    perror("SHELLPATH:");
    exit(1);
   } 	
 exit(0);
}

/* :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::: */
/* -------------------------------------------------------------------- */

read_configuration_file ()
{
 FILE *config_file;
 char line[BUFSIZ];

 if ((config_file=fopen("/etc/hyper.cfg","r"))==NULL)
   {
    perror("hyper.cfg");
    exit(1);
   }
 fgets(hyper_path,BUFSIZ,config_file);
 fgets(line,BUFSIZ,config_file); 
 number_welcome_files=atoi(line);
 fclose(config_file);
}

/* -------------------------------------------------------------------- */

choose_and_display_welcome_screen ()
{
 FILE *wel_file;
 FILE *wel_c_file;
 char line[BUFSIZ];
 char wel_filename[80];

 get_next_welcome_screen(number_welcome_files);

/*strcpy(wel_filename,hyper_path);*/
 strcpy(wel_filename,"/etc/");

 strcat(wel_filename,"wel.");
 strcat(wel_filename,rnum);
 strcat(wel_filename,".cfg");

 if ((wel_c_file=fopen(wel_filename,"r"))==NULL)
   {
    perror(wel_filename);
    exit(1);
   }
 fgets(login_prompt,BUFSIZ,wel_c_file); 
 fgets(line,BUFSIZ,wel_c_file);
 log_x=atoi(line);
 fgets(line,BUFSIZ,wel_c_file);
 log_y=atoi(line);
 fgets(passwd_prompt,BUFSIZ,wel_c_file);
 fgets(line,BUFSIZ,wel_c_file);
 pas_x=atoi(line);
 fgets(line,BUFSIZ,wel_c_file);
 pas_y=atoi(line);
 fclose(wel_c_file);

 clrscr();
 gotoxy(1,1);
 setforecolor(15);
 fprintf(stdout,"         ..ooOO) HYPER Login 0.1.1 (beta) by MiCRO^[[ of LiE (OOoo..\n");
 fflush(stdout);

/*strcpy(wel_filename,hyper_path);*/
 strcpy(wel_filename,"/etc/");


 strcat(wel_filename,"wel.");
 strcat(wel_filename,rnum);
 if ((wel_file=fopen(wel_filename,"r"))==NULL)
   {
    perror(wel_filename);
    exit(1);
   }
 while (fgets(line,BUFSIZ,wel_file)!=NULL) 
   {
    fprintf(stdout,"%s",line); 
    fflush(stdout);
   }
 fclose(wel_file);
}

/* -------------------------------------------------------------------- */

terminal_echo_off()
{ 
 struct termios attr;

 (void)fflush(stdout);
 tcgetattr(STDIN_FILENO,&attr);
 attr.c_lflag &= ~(ECHO);
 tcsetattr(STDIN_FILENO,TCSAFLUSH,&attr);
}

/* -------------------------------------------------------------------- */

terminal_echo_on()
{
 struct termios attr;

 tcgetattr(STDIN_FILENO,&attr);
 attr.c_lflag |= ECHO;
 tcsetattr(STDIN_FILENO,TCSANOW,&attr);
}

/* -------------------------------------------------------------------- */

get_passwurd(startx,starty)
{
 int next_char;
 char buff;
 unsigned size;
 int passwd_len;

 done_passwd_entry=0;
 gotoxy(startx,starty);printf("%s",passwd_prompt);
 gotoxy(startx,starty+1);
 terminal_echo_off;

/* while (!done_passwd_entry)
   { 
    next_char=fgetc(stdin);
    sprintf(*ch,"%c",next_char);
    strcpy(password,*ch);
   }*/

 passwd_len=read(STDIN_FILENO,password,20);

 terminal_echo_on;
}

/* -------------------------------------------------------------------- */

display_prompt_and_login ()
/* THIS FUNCTION IS UNDER MAJOR CONSTRUCTION...
   IT WILL BE TIGHTENED DOWN AND TWEAKED ONCE I FULLY UNDERSTAND]
   EVERY PIECE OF IT... */
{
 FILE *pfile;
 char login_name[BUFSIZ]="";
/* char password[BUFSIZ]="";*/
 char *p;
 char line[BUFSIZ]="";
 char tmp[20]="";
 char tmp2[20]="";
 char tmpsalt[2]="";
 char ctmp[11]="";
 char *crypt();
 char name[20]="";
 char pword[40]="";
 char dummy[40]="";
 char *getpass();

 gotoxy(log_x,log_y);printf("%s",login_prompt);
 gotoxy(log_x,log_y+1);fgets(login_name,BUFSIZ,stdin);
/* gotoxy(pas_x,pas_y);printf("%s",passwd_prompt);*/


/* gotoxy(pas_x,pas_y+1);*//*fgets(password,BUFSIZ,stdin);*/

get_passwurd(pas_x,pas_y);

/* the following worked, somewhat...*/
/* p=getpass();
 strcpy(password,*p);*/

 strncpy(tmp,login_name,strlen(login_name)-1);
 if ((pfile=fopen("/etc/passwd","r"))==NULL)
   {
    perror("/etc/passwd");
    exit(1);
   }
/*
  Ahhh.... 'bout fuXin' tyme...  ok, the next loop will validate
  or invalidate the 00zer...  the only thing left to do here is
  tweak the code and make my own routine for entering password
  which will not echo the charZ...  easy enough, but working on
  the other partZ, now....  
*/

 while (fgets(line,BUFSIZ,pfile)!=NULL)
 {
  /* Find user */
  
sscanf(line,"%[^:]:%[^:]:%[^:]:%[^:]:%[^:]:%[^:]:%s",&name,&pword,&dummy,&dummy,&dummy,&home_directory,&shell_path); 
  /*^^^^^^^^^^^^^^^^^^^^^^^^^ I'm a fuxin g0d.... */
  strcpy(tmp2,"");
  strncpy(tmp2,line,strlen(login_name)-1);
  if (strcmp(tmp2,tmp)!=0) continue;
  /* Found user, check passwd */
  strncpy(tmp,password,strlen(password)-1);
  strncpy(tmpsalt,pword,2);
  strcpy(ctmp,crypt(tmp,tmpsalt));
  if (strncmp(ctmp,pword,11)!=0) break;  
  passed=1;
  
  break;
 }
 fclose(pfile);
}

/* -------------------------------------------------------------------- */

get_next_welcome_screen(int max_num)
/* Fucking laYme GCC.... why doesn't Borland make a UNiX 'C' compiler?!? */
{
 FILE *wnext;
 char line[BUFSIZ];
 int next_wel;

 if ((wnext=fopen("/etc/wel.next","r"))==NULL)
   {
    perror("/etc/wel.next");
    exit(1);
   }
 fgets(line,BUFSIZ,wnext); 
 fclose(wnext);
 next_wel=atoi(line);
 next_wel=next_wel+1;
 if (next_wel>max_num) next_wel=1;
 if ((wnext=fopen("/etc/wel.next","w"))==NULL)
   {
    perror("/etc/wel.next");
    exit(1);
   }
 fprintf(wnext,"%d",next_wel); 
 fclose(wnext);

 switch (next_wel)
   { 
    case 1:strcpy(rnum,"1");break;
    case 2:strcpy(rnum,"2");break;
    case 3:strcpy(rnum,"3");break;
   }
}

/* -------------------------------------------------------------------- */

