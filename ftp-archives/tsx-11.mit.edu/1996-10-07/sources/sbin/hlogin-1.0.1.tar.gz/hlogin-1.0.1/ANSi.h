
setforecolor (int fore)
{
 char colorstr[10];

 
 if (fore>7) 
   {
     strcpy(colorstr,"1;3");
   }
 else strcpy(colorstr,"0;3");
 switch (fore)
   {
    case 0:strcat(colorstr,"0");break;
    case 1:strcat(colorstr,"1");break;
    case 2:strcat(colorstr,"2");break;
    case 3:strcat(colorstr,"3");break;
    case 4:strcat(colorstr,"4");break;
    case 5:strcat(colorstr,"5");break;
    case 6:strcat(colorstr,"6");break;
    case 7:strcat(colorstr,"7");break;
    case 8:strcat(colorstr,"0");break;
    case 9:strcat(colorstr,"1");break;
    case 10:strcat(colorstr,"2");break;
    case 11:strcat(colorstr,"3");break;
    case 12:strcat(colorstr,"4");break;
    case 13:strcat(colorstr,"5");break;
    case 14:strcat(colorstr,"6");break;
    case 15:strcat(colorstr,"7");break;
    default:strcat(colorstr,"7");break;
   }  
 printf("\x01B[%sm",colorstr);
}

setbackcolor (int back)
{
 char colorstr[10];

 
 strcpy(colorstr,"4");
 switch (back)
   {
    case 0:strcat(colorstr,"0");break;
    case 1:strcat(colorstr,"1");break;
    case 2:strcat(colorstr,"2");break;
    case 3:strcat(colorstr,"3");break;
    case 4:strcat(colorstr,"4");break;
    case 5:strcat(colorstr,"5");break;
    case 6:strcat(colorstr,"6");break;
    case 7:strcat(colorstr,"7");break;
    default:strcat(colorstr,"7");break;
   }  
 printf("\x01B[%sm",colorstr);
}

clrscr ()
{
 printf("\x01B[2J");
}

gotoxy (int x, int y)
{
 printf("\x01B[%d;%dH",y,x);
}


