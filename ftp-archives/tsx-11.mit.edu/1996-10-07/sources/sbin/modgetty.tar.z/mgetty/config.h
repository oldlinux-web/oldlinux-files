/*
 * $Id: config.h,v 1.2 1993/01/15 23:05:25 wcp Exp $
 *
 * Copyright (C) 1992	Walter Pelissero
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: config.h,v $
 * Revision 1.2  1993/01/15  23:05:25  wcp
 * Removed some garbage from comments.
 *
 * Revision 1.1  1993/01/06  17:59:35  wcp
 * Initial revision
 *
 */

#ifndef _config_h_INCLUDED
#define _config_h_INCLUDED

#define SIGH_VOID       /* define this if signal handlers return void */
                        /* I've changed this to accomodate gcc    -ot */

#ifdef SIGH_VOID
  #define SIGTYPE void
#else
  #define SIGTYPE int
#endif

			/* some common bits 'n pieces */

#define LOCK_DIR	"/usr/spool/uucp"
#define MAX_NAME_LEN	14	/* Maximum file name length. Define it if
				   your file system have such constraint.
				   Otherwise leave it undefined. */
#define NAP usleep      /* nap or usleep, depending on your lib  -ot */
#undef HAVE_DBMALLOC    /* define this if you have <dbmalloc.h>  -ot */
#define STDLIB          /* define this to use <stdlib.h> (Linux) -ot */




#ifdef STDLIB
#include <stdlib.h>
#endif
#include <unistd.h>
#include <termios.h>
#include <sys/ioctl.h>
#ifdef HAVE_DBMALLOC
#ifdef DEBUG
#include <dbmalloc.h>
#endif
#endif

#ifndef STDLIB
#ifdef __cplusplus
extern "C" {
#endif
# include <sys/types.h>
  volatile void abort(void);
  char *sys_errlist[];
  int errno;
  volatile void exit(int);
  int unlink(const char *);
  char *mktemp(char *);
  int system(const char *);
  void exit(int);
  int system(const char *);
  int atoi(const char *);
  char *regcmp(const char *, const char *, ...);
  char *regex(const char *, const char *, ...);
  extern int getpid(void);
  uid_t getuid(void);
  const char *getlogin(void);
  int defopen(const char *);
  const char *defread(const char *);
  const char *logname(void);
  char *getenv(const char *);
  char *ctime(long *);
#ifdef __cplusplus
}
#endif
#endif

#endif	/* _config_h_INCLUDED */
