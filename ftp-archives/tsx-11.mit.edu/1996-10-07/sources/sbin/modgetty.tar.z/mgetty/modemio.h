/*
 * $Id: modemio.h,v 1.1 1993/01/06 18:10:08 wcp Exp $
 *
 * Copyright (C) 1992	Walter Pelissero
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: modemio.h,v $
 * Revision 1.1  1993/01/06  18:10:08  wcp
 * Initial revision
 *
 */

extern unsigned mdverbosity;
extern int mdwrite(const char *, int);
extern char *mdread(unsigned, int, const char **, unsigned *);
extern bool mdhangup(int);
extern void mdflushin(int);
extern bool mdslowrite;
extern char mdread_buffer[];
