/*
 * @(#)$Id: zyxel.h,v 1.1 1993/01/06 18:18:07 wcp Exp $
 *
 * Copyright (C) 1993	Walter Pelissero
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: zyxel.h,v $
 * Revision 1.1  1993/01/06  18:18:07  wcp
 * Initial revision
 *
 */

#ifndef _zyxel_h_INCLUDED
#define _zyxel_h_INCLUDED

typedef enum {
  MDERROR,
  MDOK,
  MDRING,
  MDCONNECT1200,
  MDCONNECT2400,
  MDCONNECT4800,
  MDCONNECT9600,
  MDCONNECT19200,
  MDCONNECT7200,
  MDCONNECT12000,
  MDCONNECT14400,
  MDCONNECT16800,
  MDCONNECT38400,
  MDCONNECT57600,
  MDCONNECT76800,
  MDCONNECT,
  MDNOCARRIER,
  MDNODIALTONE,
  MDBUSY,
  MDNOANSWER,
  MDFCON,
  MDFDCS,
  MDFDIS,
  MDFCFR,
  MDFTSI,
  MDFCSI,
  MDFPTS,
  MDFET,
  MDFHNG,
  MDVCON,
  MDLAST_ANS = MDVCON
  } ModemReturnCode;

extern const char *ModemAnswers[];
extern ModemReturnCode receive(unsigned, int);
extern short C2_resolution, C2_eop, C2_baud, C2_width, C2_length;
extern short C2_compression, C2_errCorr;
extern char C2_caller[];

#endif /* _zyxel_h_INCLUDED */
