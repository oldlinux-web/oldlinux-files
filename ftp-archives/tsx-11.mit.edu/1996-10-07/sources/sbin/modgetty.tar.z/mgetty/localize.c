/*
 * $Id: localize.c,v 1.1 1993/01/06 18:02:00 wcp Exp $
 *
 * Copyright (C) 1992	Walter Pelissero
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * $Log: localize.c,v $
 * Revision 1.1  1993/01/06  18:02:00  wcp
 * Initial revision
 *
 */

extern int printf(const char *, ...);
extern volatile void exit(int);

int main()
{
  printf("s#%%LIB_DIR%%#%s#\n", LIB_DIR);
  printf("s#%%BIN_DIR%%#%s#\n", BIN_DIR);
  printf("s#%%PBMPLUS%%#%s#\n", PBMPLUS);
  return exit(0), 0;
}
