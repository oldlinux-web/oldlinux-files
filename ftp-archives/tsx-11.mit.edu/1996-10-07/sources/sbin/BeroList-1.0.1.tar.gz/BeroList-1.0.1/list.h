/*  BeroList Mailing List - Configuration file                    */
/*  (c) 1996 by Bernhard Rosenkraenzer, root@startrek.in-trier.de */

/* VERSION will be used in error messages */
#define VERSION "BeroList 1.0.1"

/* Comment out if you do not want BeroList to create log files */
#define LOG

/* Location of logfiles - must be writable by bin */
#define LOGDIR "/usr/bin/BeroList/logs"

/* Directory of list members, configs, etc. - must be read-writable by bin */
#define LISTDIR "/usr/bin/BeroList/lists"

/* Path to sendmail */
#define SENDMAIL "/usr/bin/sendmail"

/* Hostname for mailing list server */
/* If HOST is not defined, BeroList will try to determine it itself */
/* This is _NOT_ recommended. (see README) */
#define HOST "startrek.in-trier.de"

/* Maximum number of members for a list */
#define MAX_MEMBERS 1000

/* define TRUSTED if 'bin' may run sendmail -f - RECOMMENDED */
#define TRUSTED

/* Uncomment the following lines if you do not want sender and list addresses
   in your message */
/* #define NO_SENDER_ADDRESS */
/* #define NO_LIST_ADDRESS   */   

/* That's it. Go on and run make. (make 486 for 80486 processors) */
