/* pppmon-0.2/pppmon.h
 *
 * Description:
 *   Header file for the pppmon package
 *
 * This software is placed under the GNU Copyleft.
 *
 * Use this software at your own risk.
 *   The author is not responsible for any damages that may occur.
 *   Let's kill all the lawyers; let's kill 'em tonight.
 *
 * Please send bug reports (and fixes!) to:
 *   Kenneth J. Hendrickson, University of Southern California, kjh@usc.edu
 *
 * Version 0.1 for ppp-2.1.2 originally conceived and written by:
 *   Calle Karlsson, KaSH Software AB, calle@kash.se
 *
 * Version 0.2 for ppp-2.2.0c written by:
 *   Kenneth J. Hendrickson, University of Southern California, kjh@usc.edu
 *
 * History:
 * 25 May 95 ckn Initial coding
 *  6 Dec 95 kjh Rewrite for ppp-2.2.0c
 * EndHistory.
 */

#ifndef __PPPMON_H__
#define __PPPMON_H__

/* Lots of probably unneeded include files */

#include <ctype.h>
#include <errno.h>
#include <nlist.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/ioctl.h>

#include <arpa/inet.h>		/* must come before <net/ppp_defs.h> in linux */
#include <net/ppp_defs.h>

#ifdef __svr4__
#include <sys/stropts.h>
#include <net/pppio.h>		/* SVR4, Solaris 2, etc. */

#else
#include <sys/socket.h>
#include <net/if.h>

#ifndef STREAMS
#include <net/if_ppp.h>		/* BSD, Linux, NeXT, etc. */

#else				/* SunOS 4, AIX 4, OSF/1, etc. */
#define PPP_STATS	1	/* should be defined iff it is in ppp_if.c */
#include <sys/stream.h>
#include <net/ppp_str.h>
#endif	/* STREAMS */
#endif	/* __svr4__ */

#include <sys/time.h>
#include <unistd.h>

#include <netinet/in.h>
#include <netdb.h>

/*
#include <sys/socket.h>
#include <sys/signal.h>
#include <net/if.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
*/

typedef struct
{
   unsigned long UpTime;
   unsigned long RBytes, SBytes;
   unsigned long RTT;  /* Might come in handy later */
   unsigned long TimeSpent;
} DclPPPMonitorMsg;

#endif	/* __PPPMON_H__ */
