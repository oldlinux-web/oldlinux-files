/* pppmon-0.2/pppmond.c
 *
 * Description:
 *   Get stats from ppp layer and send it to connected clients.
 *
 * This software is placed under the GNU Copyleft.
 *   Thanx to Al Longyear and Brad Parker for initial ideas in the
 *   pppstats.c program.
 *
 * Use this software at your own risk.
 *   The author is not responsible for any damages that may occur.
 *   Let's kill all the lawyers; let's kill 'em tonight.
 *
 * Please send bug reports (and fixes!) to:
 *   Kenneth J. Hendrickson, University of Southern California, kjh@usc.edu
 *
 * Version 0.1 for ppp-2.1.2 originally conceived and written by:
 *   Calle Karlsson, KaSH Software AB, calle@kash.se
 *
 * Version 0.2 for ppp-2.2.0c written by:
 *   Kenneth J. Hendrickson, University of Southern California, kjh@usc.edu
 *
 * History:
 * 25 May 95 ckn Initial coding - version 0.1
 *  9 Jul 95 kjh Modified to use syslog(2) facility
 *  6 Dec 95 kjh Rewrite for ppp-2.2.0c
 * EndHistory.
 */

#include "pppmon.h"
#include <stdlib.h>
#include <syslog.h>
/*#include "/usr/src/linux/drivers/net/slhc.h"*/	/* Not used */

#define MAXCLIENTS	64
#define MAXSERVICENAME	80
#define FAKE_MODEM_BPS	3600		/* 28800 bits/sec / 8 bits/byte */

/* slcomp not used in DclPPPInfo */
/* typedef struct {
  struct ppp_stats  stats;
  struct slcompress slcomp;
} DclPPPInfo; */

static void Usage(void);
static void Arguments(int argc, char *argv[]);
static void SetupSocket(char *Service, char *Protocol, int Unit);
static long MilliTime(void);
static void MilliSleep(int MilliSecs);
static int AddClient(void);
static void RemoveClient(int fd);
static void SendToAllClients(DclPPPMonitorMsg *PMMP);
static void SendToClientsAndWait(long RBytes, long SBytes, long TimeSpent);
static void get_ppp_stats(struct ppp_stats *curp);
static void get_ppp_cstats(struct ppp_comp_stats *csp);
#ifdef __svr4__
static int strioctl(int fd, int cmd, char *ptr, int ilen, int olen);
#endif

static int Socket = -1;
static int Clients[MAXCLIENTS + 1];
static int Unit = 0, OrigInterval = 5000, Interval = 5000, Fake = 0;
static int cflag = 0, rflag = 0;	/* future use: compression */

int main(int argc, char *argv[]) {
    struct ppp_stats		PPPStat, LastPPPStat;
    struct ppp_comp_stats	PPPCompStat, LastPPPCompStat;
    long 			InfoTime, LastInfoTime = -1,
				RBytes, SBytes, UsedTime;
    char			Service[MAXSERVICENAME],
				UnitName[MAXSERVICENAME];

    /* Parse command line arguments. */
    Arguments(argc, argv);

    /* Ignore PIPE signals. */
    signal(SIGPIPE, SIG_IGN);

    /* Find Service name: ppp0mon, ppp1mon, etc. */
    Service[MAXSERVICENAME-1] = '\0';
    strncpy(Service, "ppp", MAXSERVICENAME-1);
    sprintf(UnitName, "%d", Unit);	/* There ought to be an snprintf() */
    strncat(Service, UnitName, MAXSERVICENAME-1-strlen(Service));
    strncat(Service, "mon", MAXSERVICENAME-1-strlen(Service));

    /* Prepare for logging. */
    openlog(Service, LOG_CONS, LOG_DAEMON);

    /* Prepare for clients. */
    SetupSocket(Service, "tcp", Unit);
    memset(Clients, 0, sizeof(Clients));
    memset(&LastPPPStat, 0, sizeof(LastPPPStat));
    memset(&LastPPPCompStat, 0, sizeof(LastPPPCompStat));

    while (1) {
	if (Fake) {
		int max_bytes = FAKE_MODEM_BPS * (Interval/1000);
		PPPStat.p.ppp_ibytes = max_bytes * random()/RAND_MAX;
		PPPStat.p.ppp_obytes = max_bytes * random()/RAND_MAX;
	} else {
		get_ppp_stats(&PPPStat);
		if (cflag || rflag)
			get_ppp_cstats(&PPPCompStat);
	}

	InfoTime = MilliTime();

	if (LastInfoTime != -1) {
		RBytes = PPPStat.p.ppp_ibytes - LastPPPStat.p.ppp_ibytes;
		SBytes = PPPStat.p.ppp_obytes - LastPPPStat.p.ppp_obytes;
		UsedTime = InfoTime - LastInfoTime;

		SendToClientsAndWait(RBytes, SBytes, UsedTime);
	} else
		MilliSleep (Interval/2);   /* No valid data first time around */

	memcpy(&LastPPPStat, &PPPStat, sizeof(LastPPPStat));
	if (cflag || rflag)
		memcpy(&LastPPPCompStat, &PPPCompStat, sizeof(LastPPPCompStat));

	LastInfoTime = InfoTime;
    }

    return 0;
}

static void
Arguments(int argc, char *argv[]) {
	for (argc--, argv++; argc; argc--, argv++) {
		if (*argv[0] != '-') {
			Usage();
		}

		switch (toupper(argv[0][1])) {
		case 'I':
			if (argc < 1) {
				fprintf(stderr,
					"pppmond: Missing interval argument\n");
				Usage();
			}
			if (!isdigit(argv[1][0]) ||
			    (Interval = OrigInterval = atoi(argv[1])) <= 0)
				Usage();
			argc--, argv++;
			break;

		case 'U':
			if (argc < 1) {
				fprintf(stderr,
					"pppmond: Missing unit argument\n");
				Usage();
			}
			if (!isdigit(argv[1][0]) ||
			    (Unit = atoi(argv[1])) <= 0)
				Usage();
			argc--, argv++;
			break;

		case 'F':   /* Undocumented Feature :) */
			Fake = 1;
			break;

		case 'H':
		default:
			Usage();
			break;
		}
	}
}

static void Usage(void) {
	fprintf(stderr, "Usage: pppmond [-i interval_in_ms] [-u unit]\n");
	exit(1);
}

static void SetupSocket (char *Service, char *Protocol, int Unit) {

#ifdef __svr4__
	if ((Socket = open("/dev/ppp", O_RDONLY)) < 0) {
		syslog(LOG_DEBUG, "Couldn't open /dev/ppp");
		exit(1);
	}
	if (strioctl(Socket, PPPIO_ATTACH, &Unit, sizeof(int), 0) < 0) {
		syslog(LOG_DEBUG,
			"strioctl(): ppp%d is not available\n", &Unit);
		exit(1);
	}
#else
	struct servent		*sp;
	struct sockaddr_in	Addr[1];
	int			Port;

	if (!(sp = getservbyname(Service, Protocol))) {
		syslog(LOG_WARNING,
			"getservbyname(%s, %s)\n", Service, Protocol);
		Port = 5676; /* Or any unused port.. */
	} else {
		Port = sp->s_port;
	}

	if ((Socket = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		syslog(LOG_DEBUG, "socket() failed\n");
		exit(1);
	}

	memset(&Addr->sin_addr, 0, sizeof(Addr->sin_addr));
	Addr->sin_port   = ntohs(Port);
	Addr->sin_family = AF_INET;

	if (bind(Socket, (struct sockaddr *) Addr, sizeof(Addr))) {
		syslog(LOG_DEBUG, "bind() failed\n");
		exit(1);
	}

	if (listen(Socket, 5) < 0) {
		syslog(LOG_DEBUG, "listen() failed\n");
		exit(1);
	}
#endif /* __svr4__ */
}

/*
 * Returns time in milliseconds since program started.
 */

static long MilliTime(void) {
	       struct timeval	tv;
	static struct timeval	start = {0, 0};

	if (gettimeofday(&tv, NULL) < 0) {
		perror("gettimeofday");
		exit (1);
	}

	if (start.tv_sec == 0 && start.tv_usec == 0) {
		start.tv_sec  = tv.tv_sec;
		start.tv_usec = tv.tv_usec;
	}

	return((tv.tv_sec - start.tv_sec) * 1000
		+ (tv.tv_usec - start.tv_usec) / 1000);
}

/*
 * Sleep a few milliseconds
 */

static void MilliSleep(int MilliSecs) {
	struct timeval		tv;

	tv.tv_sec  = MilliSecs / 1000;
	tv.tv_usec = (MilliSecs % 1000) * 1000;

	select(0, NULL, NULL, NULL, &tv);
}

/*
 * Incoming client that wants some data from us. Just accept the session.
 */

static int AddClient(void) {
	int	fd;

	if ((fd = accept(Socket, NULL, 0)) < 0) {
		syslog(LOG_DEBUG, "accept() failed\n");
		return -1;
	}

	if (fd > MAXCLIENTS) {
		syslog(LOG_DEBUG,
			"Too many clients connecting, max (%d)\n", MAXCLIENTS);
		return -1;
	}

	Clients[fd] = 1;

	syslog(LOG_INFO, "Accepted client at descriptor %d\n", fd);

	return fd;
}

/*
 * A client got tired of us
 */

static void RemoveClient(int fd) {
	close (fd);
	Clients[fd] = 0;
	syslog(LOG_INFO, "Client %d removed\n", fd);
}

/*
 * Send statistics to currently connected clients
 */

static void SendToAllClients(DclPPPMonitorMsg *PMMP) {
	int	fd;

	for (fd = 0; fd < MAXCLIENTS; fd++) {
		if (Clients[fd]) {
			int rc = write(fd, PMMP, sizeof(DclPPPMonitorMsg));

			/* Probably disconnected. */
			if (rc != sizeof(DclPPPMonitorMsg))
				RemoveClient (fd);
		}
	}
}

/*
 * Send statistics,
 * wait specified amount of time,
 * and handle incoming connections.
 */

static void
SendToClientsAndWait(long RBytes, long SBytes, long TimeSpent) {
	struct timeval		tv [1];
	DclPPPMonitorMsg	PPPMonitorMsg [1];
	fd_set			ReadSet [1];
	int			rc;
	unsigned long		UpTime;
	FILE			* fp;

	if (!(fp = fopen("/etc/ppp/UP", "r"))) {
		/* We're not connected. Chill out... */
		UpTime = 0;
		Interval = OrigInterval * 10;
	} else {
		/* We're connected. */
		fscanf(fp, "%ld", &UpTime);
		fclose(fp);
		UpTime = time(0) - UpTime;
		Interval = OrigInterval;
	}

	PPPMonitorMsg->UpTime    = htonl (UpTime);
	PPPMonitorMsg->RBytes    = htonl (RBytes);
	PPPMonitorMsg->SBytes    = htonl (SBytes);
	PPPMonitorMsg->TimeSpent = htonl (TimeSpent);
	PPPMonitorMsg->RTT       = htonl (0); /* For future use */

	SendToAllClients(PPPMonitorMsg);

	tv->tv_sec  = Interval / 1000;
	tv->tv_usec = (Interval % 1000) * 1000;

	while (1) {
		FD_ZERO(ReadSet);
		FD_SET(Socket, ReadSet);

/* printf ("Into select, Time %d.%06d\n", tv->tv_sec, tv->tv_usec); */

		/*
		 * Sleep the interval.
		 * A client might connect to us; handle that as well.
		 */

		rc = select(Socket+1, ReadSet, NULL, NULL, tv);

		if (rc == -1 && errno == EINTR)
			continue;

		else if (rc == 0) /* Timeout */
			break;

		else if (FD_ISSET(Socket, ReadSet))
			AddClient();
	}
}

#ifndef __svr4__
static void get_ppp_stats(struct ppp_stats *curp) {
    struct ifpppstatsreq req;

    memset (&req, 0, sizeof (req));

#ifdef __linux__
    req.stats_ptr = (caddr_t) &req.stats;
#undef ifr_name
#define ifr_name ifr__name
#endif

    sprintf(req.ifr_name, "ppp%d", Unit);
    if (ioctl(Socket, SIOCGPPPSTATS, &req) < 0) {
	switch (errno) {
	case ENOTTY:
		syslog(LOG_DEBUG, "kernel support missing\n");
		exit(1);
		break;
	case ENODEV:
		/* The link is down.  Return stats of 0 for everything. */
		memset(&req.stats, 0, sizeof(req.stats));
		break;
	default:
		syslog(LOG_DEBUG, "ioctl(SIOCGPPPSTATS)");
		exit(1);
	}
    }
    *curp = req.stats;
}

static void get_ppp_cstats(struct ppp_comp_stats *csp) {
    struct ifpppcstatsreq creq;

    memset (&creq, 0, sizeof (creq));

#ifdef __linux__
    creq.stats_ptr = (caddr_t) &creq.stats;
#undef  ifr_name
#define ifr_name ifr__name
#endif

    sprintf(creq.ifr_name, "ppp%d", Unit);
    if (ioctl(Socket, SIOCGPPPCSTATS, &creq) < 0) {
	if (errno == ENOTTY) {
	    syslog(LOG_DEBUG, "no kernel compression support\n");
	    if (cflag)
		exit(1);
	    rflag = 0;
	} else {
	    syslog(LOG_DEBUG, "ioctl(SIOCGPPPCSTATS)");
	    exit(1);
	}
    }

#ifdef __linux__
    if (creq.stats.c.bytes_out == 0)
	creq.stats.c.ratio = 0.0;
    else
	creq.stats.c.ratio = (double) creq.stats.c.in_count /
			     (double) creq.stats.c.bytes_out;

    if (creq.stats.d.bytes_out == 0)
	creq.stats.d.ratio = 0.0;
    else
	creq.stats.d.ratio = (double) creq.stats.d.in_count /
			     (double) creq.stats.d.bytes_out;
#endif

    *csp = creq.stats;
}

#else	/* __svr4__ */
static void get_ppp_stats(struct ppp_stats *curp) {
    if (strioctl(Socket, PPPIO_GETSTAT, curp, 0, sizeof(*curp)) < 0) {
	if (errno == EINVAL)
	    syslog(LOG_DEBUG, "kernel support missing");
	else
	    syslog(LOG_DEBUG, "Couldn't get statistics");
	exit(1);
    }
}

static void get_ppp_cstats(struct ppp_comp_stats *csp) {
    if (strioctl(Socket, PPPIO_GETCSTAT, csp, 0, sizeof(*csp)) < 0) {
	if (errno == ENOTTY) {
	    syslog(LOG_DEBUG, "no kernel compression support");
	    if (cflag)
		exit(1);
	    rflag = 0;
	} else {
	    syslog(LOG_DEBUG, "Couldn't get compression statistics");
	    exit(1);
	}
    }
}

static int strioctl(int fd, int cmd, char *ptr, int ilen, int olen) {
    struct strioctl str;

    str.ic_cmd = cmd;
    str.ic_timout = 0;
    str.ic_len = ilen;
    str.ic_dp = ptr;
    if (ioctl(fd, I_STR, &str) == -1)
	return -1;
    if (str.ic_len != olen)
	syslog(LOG_DEBUG,
		"strioctl: expected %d bytes, got %d for cmd %x\n",
		olen, str.ic_len, cmd);
    return 0;
}
#endif /* __svr4__ */
