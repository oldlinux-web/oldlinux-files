/* config.h: configuration file for cspawnd.
 * 
 * todd j. derr <tjd@haven.zets.org>
 *
 * 	This program is free software; you can redistribute it and/or
 *	modify it under the terms of the GNU General Public License
 *	as published by the Free Software Foundation; either version
 *	2 of the License, or (at your option) any later version.
 *
 * v1.0: 2 April 1995: please tune parameters below.
 */

/* VERY IMPORTANT!!! this is the command we use to start your getty. 
 * This works for my getty_ps, but you may have to change it.
 *
 * if you don't understand what do do with this, please see the README.
 */
#define EXEC_GETTY execl("/sbin/getty","getty",shortvtname,"VC","console",NULL)

/* if SHOW_VC is defined, we automiatically switch to the new VC */
#define SHOW_VC				

/* if CLEANUP is defined, the daemon will close all unused VC's, which seems
 * like a good idea, but you may not like this...
 */
#define CLEANUP

/* CLEANUP_INTERVAL specifies how often the daemon will wake up to clean.
 * Setting this to -1 will effectively disable the periodic cleanup, but
 * we still clean up whenever a getty exits and CLEANUP is defined.
 * This has no effect if CLEANUP is not defined.
 */
#define CLEANUP_INTERVAL	600	/* seconds */
