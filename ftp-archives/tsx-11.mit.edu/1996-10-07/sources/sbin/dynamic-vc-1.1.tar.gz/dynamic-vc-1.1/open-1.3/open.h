#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <getopt.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/vt.h>
#include <sys/types.h>
#include <sys/wait.h>

void usage(int);

/*
 * There must be a universal way to find these!
 */

#define TRUE (1)
#define FALSE (0)


/*
 * Where your VTs are hidden
 */
#ifdef __linux__
#define VTNAME "/dev/tty%d"
/* grumble. no nice way to get this stuff, but in case this ever changes... */
#include <linux/tty.h>
#ifndef MAX_NR_CONSOLES
#define MAX_NR_CONSOLES 63
#endif
#ifndef MAX_NR_USER_CONSOLES
#define MAX_NR_USER_CONSOLES 63
#endif
#endif

#ifdef ESIX_5_3_2_D
#define	VTBASE		"/dev/vt%02d"
#define MAX_NR_CONSOLES 63
#define MAX_NR_USER_CONSOLES MAX_NR_CONSOLES
#endif
