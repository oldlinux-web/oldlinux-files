#ifndef _configure_h_
#define _configure_h_

//  edit XD_CONF_PATH to suit your taste. It contains the name where your
//  xd.conf file is stored. Start the path by a /

#define XD_CONF_PATH "/.conf/xd/xd.conf"

#endif
