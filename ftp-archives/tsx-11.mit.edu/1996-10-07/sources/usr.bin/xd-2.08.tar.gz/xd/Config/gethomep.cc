#include "Config.h"

Config::ConfigHome Config::get_homeparam(void) const
{
	return(homeparam);
}

		
