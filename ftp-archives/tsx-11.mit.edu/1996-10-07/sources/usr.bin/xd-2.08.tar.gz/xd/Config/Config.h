#ifndef _Config_H_
#define _Config_H_

#include <stdlib.h>
#include <unistd.h> 
#include <ConfigFile.h>

#include "../configure.h" 

class Config
{
    public:
    	enum ConfigHome
	{
		from_the_root,
		from_HOME
	};
    	enum ConfigExtra
	{
		single_search,
		double_search,
		full_search
	};
    	Config();
	~Config();
	char const *get_home(void) const;
	ConfigHome get_homeparam(void) const;
	ConfigExtra get_extraparam(void) const;
    private:
	ConfigExtra
		extraparam;
    	ConfigHome
		homeparam;
    	char
		*home,
		*cdfile;
};
#endif
