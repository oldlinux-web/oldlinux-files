#include "Config.h"

Config::ConfigExtra Config::get_extraparam(void) const
{
	return(extraparam);
}

		
