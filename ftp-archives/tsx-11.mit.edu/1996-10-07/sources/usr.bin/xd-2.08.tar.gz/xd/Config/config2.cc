#include "Config.h"

Config::~Config()
{
	delete home;
}
