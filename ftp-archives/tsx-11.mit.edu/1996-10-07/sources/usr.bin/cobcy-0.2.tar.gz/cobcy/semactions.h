/* semactions.h
**
**	Prototypes them for C code.
*/

#ifndef __SEMACTIONS_H
#define __SEMACTIONS_H

#include "semfile.h"
#include "semarith.h"
#include "semdecl.h"
#include "seminfo.h"
#include "seminit.h"
#include "semtypes.h"
#include "semutil.h"
#include "semconio.h"
#include "semcontrol.h"

#endif

