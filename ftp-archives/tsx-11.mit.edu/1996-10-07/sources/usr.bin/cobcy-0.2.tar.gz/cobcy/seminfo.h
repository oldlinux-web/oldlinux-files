/* seminfo.cc
**
**	Defines informational semantic actions for COBOL compiler.
*/

#ifndef __SEMINFO_H
#define __SEMINFO_H

/*----------------------------------------*/
  void 	SetProgramName (void);
  void 	SetSourceComputer (void);
  void 	SetObjectComputer (void);
/*----------------------------------------*/

#endif

