/* semconio.h
**
*/

#ifndef __SEMCONIO_H
#define __SEMCONIO_H

/*----------------------------------------------------*/
  void 	GenAccept (void);
  void 	GenDisplay (void);
  void 	SetDisplayOutput (void);
  void	SetAcceptSource (AcceptSourceType NewSrc);
/*----------------------------------------------------*/

#endif

