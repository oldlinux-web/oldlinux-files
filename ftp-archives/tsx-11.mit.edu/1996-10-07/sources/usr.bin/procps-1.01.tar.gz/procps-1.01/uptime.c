#include "proc/whattime.h"
#include "proc/version.h"

void main(int argc, char *argv[]) {
  set_linux_version();
  if(argc == 1)
    print_uptime();
  if((argc == 2) && (!strcmp(argv[1], "-V")))
    display_version();
  exit(0);
}
