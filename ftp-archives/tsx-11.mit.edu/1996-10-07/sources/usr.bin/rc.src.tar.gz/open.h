extern int rc_open(const char *, enum redirtype);
