extern Node *parsetree;
extern int yyparse(void);
extern void initparse(void);
