static char *
#ifdef __STDC__
	  	volatile const 	/* a little ANSI joke... */
#endif
				id = "@(#) rc version 1.2, 9/22/91.";
