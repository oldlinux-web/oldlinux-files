extern boolean lmatch(List *, List *);
extern List *glob(List *);
