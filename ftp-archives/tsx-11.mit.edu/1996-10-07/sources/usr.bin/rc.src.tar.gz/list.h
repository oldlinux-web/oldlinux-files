extern void listfree(List *);
extern List *listcpy(List *);
extern SIZE_T listlen(List *);
extern int listnel(List *);
