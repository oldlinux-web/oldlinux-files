extern boolean match(char *, char *, char *);
