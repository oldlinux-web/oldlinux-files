extern void doredirs(void);
