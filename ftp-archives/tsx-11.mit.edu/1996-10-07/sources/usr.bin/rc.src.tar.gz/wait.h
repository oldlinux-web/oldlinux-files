extern int rc_fork(void);
extern int rc_wait4(int, int *);
extern List *sgetapids(void);
extern void waitforall(int *);
