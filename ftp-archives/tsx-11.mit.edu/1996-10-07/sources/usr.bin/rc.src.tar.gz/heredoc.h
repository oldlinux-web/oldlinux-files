extern int heredoc(int);
extern int qdoc(Node *, Node *);

typedef struct Hq Hq;

extern Hq *hq;
