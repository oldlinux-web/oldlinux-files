extern char *fun2str(char *, Node *);
extern char *ptree(Node *);
extern char *list2str(char *, List *);
extern char **list2array(List *, boolean);
extern char *get_name(char *);
extern List *parse_var(char *, char *);
extern Node *parse_fn(char *, char *);
