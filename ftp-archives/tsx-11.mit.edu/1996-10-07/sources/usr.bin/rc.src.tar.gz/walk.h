extern boolean walk(Node *, boolean);
extern boolean cond;
