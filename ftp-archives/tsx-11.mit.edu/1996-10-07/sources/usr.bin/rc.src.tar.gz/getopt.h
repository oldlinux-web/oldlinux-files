extern int getopt(int, char **, char *);

extern int optind, opterr, optopt;
extern char *optarg;
