extern int istrue(void);
extern int getstatus(void);
extern void set(boolean);
extern void setstatus(int);
extern List *sgetstatus(void);
extern void setpipestatus(int [], int);
extern void statprint(int);
extern void ssetstatus(char **);
