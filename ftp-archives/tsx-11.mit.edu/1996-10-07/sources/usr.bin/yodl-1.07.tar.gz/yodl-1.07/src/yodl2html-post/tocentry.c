
#include "yodl2html-post.h"

void tocentry (STRINGTAB tab)
{
    int
        i;

    if (! pass)                                 /* first pass: update */
    {                                           /* table of conents file */
        if (tab.nstr < 4)
            error ("incomplete tocentry tag");
            
        output (tocf, "<a href=\"%s#l%d\">", curfile, ++lastlabelnr);
        for (i = 3; i < tab.nstr; i++)
            fprintf (tocf, "%s", tab.str [i]);
        output (tocf, "</a>\n");
    }
    else                                        /* second pass: paste */
    {                                           /* internal label in output */
        output (outf, "<a name=\"l%d\">\n", 
                ++lastlabelnr);
    }
}

