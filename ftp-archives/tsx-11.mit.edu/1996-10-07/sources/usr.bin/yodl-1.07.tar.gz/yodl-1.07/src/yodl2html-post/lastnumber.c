
#include "yodl2html-post.h"

void lastnumber (STRINGTAB tab)
{
    int
        i;

    if (! pass)
    {
        if (tab.nstr < 4)
            error ("incomplete lastnumber tag");
            
        free (lastnum);
        lastnum = 0;
        for (i = 3; i < tab.nstr; i++)
            if (! isspace (*tab.str [i]))
                lastnum = str_concat (lastnum, tab.str [i]);
    }
}