
#include "yodl.h"

int subst_mightbe (char const *s)
{
    int 
        i,
	slen;
        
    slen = strlen (s);
        
    for (i = 0; i < nsubst; i++)
        if (! strncmp (subst [i], s, slen))
            return (1);
            
    return (0);
}