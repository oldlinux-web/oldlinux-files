
#include "yodl.h"

void gram_comment ()
{
    char
        *list = gram_parlist (builtin [mac_comment], 0);

    message (3, "%s %s\n", builtin [mac_comment], str_short (list));
    free (list);
}
