
#include "yodl.h"

void gram_newcounter ()
{
    char
        *name;
        
    name = gram_parlist (builtin [mac_newcounter], 0);
    gram_onename (name, builtin [mac_newcounter]);
    message (3, "%s %s\n", builtin [mac_newcounter], str_short (name));
    
    if (strtab_find (countername, ncountername, name) != -1)
        error_gram (builtin [mac_newcounter], 
                    "counter %s already exists", name);

    countername = strtab_add (countername, &ncountername, name);
    counterval = (int *) xrealloc (counterval, ncountername * sizeof (int));
    counterval [ncountername - 1] = 0;

    free (name);
}
