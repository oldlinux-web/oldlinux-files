
#include "yodlfixlabels.h"

void parseflags (int *ac, char ***av)
{
    while (*ac > 1)
    {
        if (! strcmp ((*av) [1], "-labels"))
        {
            act.labels = 1;
            (*ac)--;
            (*av)++;
        }
        else if (! strcmp ((*av) [1], "-tableofcontents"))
        {
            act.tableofcontents = 1;
            (*ac)--;
            (*av)++;
        }
        else if (! strcmp ((*av) [1], "-removeblank"))
        {
            act.removeblank = 1;
            (*ac)--;
            (*av)++;
            act.killblanks = 1;
        }
        else if (! strcmp ((*av) [1], "-onepass"))
        {
            act.onepass = 1;
            (*ac)--;
            (*av)++;
        }
        else if (! strcmp ((*av) [1], "-roff"))
        {
            act.roff = 1;
            (*ac)--;
            (*av)++;
        }
        else if (! strcmp ((*av) [1], "-protectdot"))
        {
            act.protectdot = 1;
            (*ac)--;
            (*av)++;
        }
        else
            break;
    }
    
    /* sanity check */
    if (act.onepass && (act.labels || act.tableofcontents))
        error ("single pass not compatible with other options");
}
