
#include "yodl.h"

void gram_atexit ()
{
    char
        *list = gram_parlist (builtin [mac_atexit], 0);

    message (3, "%s %s\n", builtin [mac_atexit], str_short (list));

    atexit_strings = strtab_add (atexit_strings, &natexit_strings, list);
    
    free (list);
}