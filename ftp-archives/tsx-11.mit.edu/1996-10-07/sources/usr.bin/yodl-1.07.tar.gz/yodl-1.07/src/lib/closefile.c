
#include "lib.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

void close_file (FILE *f)
{
    if (f && f != stdin && f != stdout && f != stderr)
        if (fclose (f))
            error ("failure while closing file\n"
	           "%s", strerror (errno));
}    
