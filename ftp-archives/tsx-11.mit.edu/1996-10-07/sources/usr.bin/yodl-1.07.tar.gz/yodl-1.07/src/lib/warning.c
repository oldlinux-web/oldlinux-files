
#include "lib.h"
#include <stdarg.h>
#include <unistd.h>

extern char
    *program_name;

void warning (char const *fmt, ...)
{
    va_list
        args;
        
    va_start (args, fmt);
    if (program_name)
        fprintf (stderr, "%s ", program_name);
    fputs ("warning: ", stderr);
    vfprintf (stderr, fmt, args);
    fputc ('\n', stderr);
}
