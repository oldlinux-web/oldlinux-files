
#include "yodl2html-post.h"

void solvelink (STRINGTAB t)
{
    int
        i;

    if (! pass)                             /* if first pass: ignore */
        return;
        
    if (t.nstr < 3)
        error ("incomplete solvelink tag");

    for (i = 0; i < nlab; i++)
        if (! strcmp (lab [i].label, t.str [3]))
        {
            output (outf, "%s#%s", 
                     lab [i].fname, 
                     lab [i].label);
            return;
        }
        
    warning ("unresolved label: %s", t.str [3]);
    output (outf, "??");
}
