
#include "lib.h"
#include <stdarg.h>
#include <errno.h>
#include <unistd.h>

void output (FILE *f, char const *fmt, ...)
{
    va_list
        args;


    va_start (args, fmt);
    if (vfprintf (f, fmt, args) <= 0)
        error ("write failure: %s", strerror (errno));
}
