
#include "yodl2html-post.h"

char *outputfilename (int count)                /* make "base01.html" etc. */
{
    static char
        namebuf [255];
    char
        numbuf [80],
        *cp;
        
    strcpy (namebuf, fname);                    /* start with bare name */

    if ( (cp = strstr (namebuf, ".html")) )     /* cut off .html */
        *cp = '\0';
        
    sprintf (numbuf, "%2.2d", count);           /* add 01 */
    strcat (namebuf, numbuf);
    
    strcat (namebuf, ".html");                  /* add extension */
    
    return (namebuf);                           /* done */
}