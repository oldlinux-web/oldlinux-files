
#include "yodl.h"

void gram_typeout ()
{
    char
        *msg;

    msg = gram_parlist (builtin [mac_typeout], 0);
    message (3, "%s %s\n", builtin [mac_typeout], str_short (msg));
    fprintf (stderr, "%s\n", msg);

    free (msg);
}
