
#include "yodl2html-post.h"

void label (STRINGTAB t)
{
    int
        i;

    if (t.nstr < 4)
        error ("incomplete label tag");

    if (! pass)                             /* first pass: enter label */
    {
        for (i = 0; i < nlab; i++)          /* check for duplicates */
            if (! strcmp (lab [i].label, t.str [3]))
            {
                warning ("label %s already defined, ignored", t.str [3]);
                return;
            }

                                            /* enter label in table */
        lab = (LABEL *) xrealloc (lab, (nlab + 1) * sizeof (LABEL));
        lab [nlab].label = xstrdup (t.str [3]);
        lab [nlab].value = xstrdup (lastnum);
        lab [nlab].fname = xstrdup (curfile);
        
        nlab++;
    }
    else                                    /* second pass: set anchor */
        output (outf, "<a name=\"%s\">", t.str [3]);

}
