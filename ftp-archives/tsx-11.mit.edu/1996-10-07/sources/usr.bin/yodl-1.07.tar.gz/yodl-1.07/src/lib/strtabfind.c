
#include "lib.h"

int strtab_find (char **tab, int ntab, char const *str)
{
    int
        i;

    if (! str || ! *str)                        /* sanity check */
        return (-1);
        
    for (i = 0; i < ntab; i++)
        if (! strcmp (tab [i], str))
            return (i);
            
    return (-1);
}