
#include "yodl.h"

void gram_usecounter ()
{
    char
        *name;
    int
        index;
    char
        buf [80];
        
    name = gram_parlist (builtin [mac_usecounter], 0);
    index = gram_findcounter (builtin [mac_usecounter], name);
    
    (counterval [index])++;
    
    message (3, "%s %s: now %d\n", 
            builtin [mac_usecounter], name, counterval [index]);
    
    lexer_pushstr (lexbuf);                     /* push back beyond parlist */
    sprintf (buf, "%d", counterval [index]);
    lexer_pushstr (buf);                        /* push back expansion */
    
    lexer ();                                   /* prepare next symbol */
    
    free (name);
}
