
#define EXTERN
#include "yodl2html-post.h"

int main (int argc, char **argv)
{
    if (argc != 2)                              /* check arguments */
        usage ();
        
    fname = argv [1];

    init ();                                    /* global initializations */
        
    lineno = 1;                                 /* pass one */
    yyparse ();                                
    close_file (tocf);
    
    lineno = 1;                                 /* pass two */
    outf_count = 0;
    lastlabelnr = 0;
    fseek (yyin, 0, SEEK_SET);
    yyrestart (yyin);
    pass++;
    yyparse ();

    chapterlinks ();                            /* add links to last chapter */
    
    cleanup (0);
    return (0);
}
