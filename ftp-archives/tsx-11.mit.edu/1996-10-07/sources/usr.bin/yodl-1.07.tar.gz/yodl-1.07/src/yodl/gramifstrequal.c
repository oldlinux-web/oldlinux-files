
#include "yodl.h"

void gram_ifstrequal ()
{
    char
        *str1,
        *str2,
        *truelist,
        *falselist;
    int
        res;
        
    str1 = gram_parlist (builtin [mac_ifstrequal], 0);
    message (3, "%s %s\n", builtin [mac_ifstrequal], str_short (str1));
    
    while (lextok == tok_space || lextok == tok_newline)
        lexer ();
    str2 = gram_parlist (builtin [mac_ifstrequal], 0);

    while (lextok == tok_space || lextok == tok_newline)
        lexer ();
    truelist = gram_parlist (builtin [mac_ifstrequal], 0);

    while (lextok == tok_space || lextok == tok_newline)
        lexer ();
    falselist = gram_parlist (builtin [mac_ifstrequal], 0);
    lexer_pushstr (lexbuf);
    
    if (! str1)
    {
        if (! str2 || ! *str2)
            res = 0;
        else
            res = 1;
    }
    else if (! str2)
        res = 1;
    else
        res = strcmp (str1, str2);

    if (res)
        lexer_pushstr (falselist);
    else
        lexer_pushstr (truelist);
        
    lexer ();
    
    free (str1);
    free (str2);
    free (truelist);
    free (falselist);
}

