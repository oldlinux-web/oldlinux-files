
#include "yodl.h"

void gram_chdir ()
{
    char
        *dirname;

    dirname = gram_parlist (builtin [mac_chdir], 0);
    gram_onename (builtin [mac_chdir], dirname);
    message (2, "changing to dir: %s\n", dirname);
    
    if (chdir (dirname))
        error_gram (builtin [mac_chdir], "cannot chdir to %s: %s",
                    dirname, strerror (errno));

    free (dirname);
}
