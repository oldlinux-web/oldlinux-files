
#include "yodl.h"

void gram_definesymbol ()
{
    char
        *sym;
        
    sym = gram_parlist (builtin [mac_definesymbol], 0);
    
    message (3, "%s %s\n", builtin [mac_definesymbol], sym);

    gram_onename (builtin [mac_definesymbol], sym);
            
    if (strtab_find (define, ndefine, sym) >= 0)
        error_gram (builtin [mac_definesymbol], 
                    "symbol %s already defined", sym);

    define = strtab_add (define, &ndefine, sym);
    
    free (sym);
}
