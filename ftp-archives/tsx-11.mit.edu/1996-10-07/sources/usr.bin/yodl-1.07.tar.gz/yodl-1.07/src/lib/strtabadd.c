
#include "lib.h"

char **strtab_add (char **table, int *ntable, char const *newstr)
{
    table = (char **) xrealloc (table, (*ntable + 1) * sizeof (char *));
    table [*ntable] = xstrdup (newstr);
    (*ntable)++;
    
    return (table);
}