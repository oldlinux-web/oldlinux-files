
#include "yodlfixlabels.h"

void tocentry (char **tab, int ntab, int pass)
{
    char
        **entry = 0;
    int
        nentry = 0,
        i;
        
    if (! pass)                         /* first pass: store toc entry */
    {
        if (ntab < 4)
            error ("near line %d: incomplete toc entry", lineno);

        for (i = 2; i < ntab - 1; i++)
            entry = strtab_add (entry, &nentry, tab [i]);

        toc = (char ***) xrealloc (toc, (ntoc + 1) * sizeof (char **));
        toc [ntoc] = entry;
        tocsize = (int *) xrealloc (tocsize, (ntoc + 1) * sizeof (int));
        tocsize [ntoc] = nentry;

        ntoc++;
    }
}
