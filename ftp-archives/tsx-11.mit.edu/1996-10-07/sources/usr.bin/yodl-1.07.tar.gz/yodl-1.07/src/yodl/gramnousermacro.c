
#include "yodl.h"

void gram_nousermacro ()
{
    char
        *cp,                                /* tmp var */
        *list;                              /* list of no-user macros */

    list = gram_parlist (builtin [mac_nousermacro], 0);
    message (3, "%s %s\n", builtin [mac_nousermacro], str_short (list));
    
    cp = strtok (list, " :,;\t\n");
    while (cp)
    {
        message (4, "%s %s\n", builtin [mac_nousermacro], cp);
        nousermacro = strtab_add (nousermacro, &nnousermacro, cp);
        cp = strtok (NULL, " :,;\t\n");
    }
}
