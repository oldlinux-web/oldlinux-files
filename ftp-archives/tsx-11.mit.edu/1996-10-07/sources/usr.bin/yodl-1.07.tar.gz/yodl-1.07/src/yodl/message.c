
#include "yodl.h"

void message (int lev, char const *fmt, ...)
{
    va_list
        args;
    int
        i;

    if (verbose >= lev)
    {
        for (i = 1; i < lev; i++)
            fputc (' ', stderr);
        va_start (args, fmt);
        vfprintf (stderr, fmt, args);
    }
}