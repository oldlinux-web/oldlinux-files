
#include "yodl.h"

void gram_undefinesymbol ()
{
    char
        *sym;

    sym = gram_parlist (builtin [mac_undefinesymbol], 0);
    gram_onename (builtin [mac_undefinesymbol], sym);
    
    message (3, "%s %s\n", builtin [mac_undefinesymbol], sym);
    
    strtab_del (define, &ndefine, sym);
    free (sym);
}
