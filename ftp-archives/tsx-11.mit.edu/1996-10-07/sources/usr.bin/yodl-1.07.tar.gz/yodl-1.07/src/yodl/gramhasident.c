
#include "yodl.h"

int gram_hasident (char const *s)
{
    char
        *id = 0;
    char const
        *cp;
    int
        res = 0;
        
    if (! isalpha (*s))
        return (0);
        
    for (cp = s; isalpha (*cp); cp++)
        id = str_addchar (id, *cp);
        
    if (strtab_find (builtin, nbuiltin, id) > -1 ||
        strtab_find (userdef, nuserdef, id) > -1
       )
        res = 1;
        
    free (id);
    return (res);
}
