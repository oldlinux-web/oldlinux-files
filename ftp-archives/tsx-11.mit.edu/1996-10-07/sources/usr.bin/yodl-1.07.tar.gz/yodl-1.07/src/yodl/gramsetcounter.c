
#include "yodl.h"

void gram_setcounter ()
{
    int
        index;
    char    
        *name,
	*value;
    
                                            /* read counter name */
    name = gram_parlist (builtin [mac_setcounter], 0);
    index = gram_findcounter (builtin [mac_setcounter], name);

    while (lextok == tok_space ||           /* skip spaces, newlines */
           lextok == tok_newline
	  )
        lexer ();
                                            /* read counter value */
    value = gram_parlist (builtin [mac_setcounter], 0);
    
    message (3, "%s %s to %s\n", builtin [mac_setcounter], name, value);
    counterval [index] = gram_onenumber (builtin [mac_setcounter], value);

    free (name);
    free (value);
}
