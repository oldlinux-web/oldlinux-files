
#include "yodl2html-post.h"

void bodytagopt (STRINGTAB t)
{
    int
        i;

    if (pass)                               /* store only during first pass */
        return;
        
    for (i = 3; i < t.nstr; i++)            /* store all */
        stringtab_addstr (&bodyopt, t.str [i]);
}
