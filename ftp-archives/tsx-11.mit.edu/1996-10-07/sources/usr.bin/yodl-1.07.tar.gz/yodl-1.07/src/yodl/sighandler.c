
#include "yodl.h"

void sighandler (int sig)
{
    fflush (outf);

    if (sig == SIGSEGV)
    {
        fprintf (stderr, 
"\n"
"Oops! YODL caused a segment violation. This is of course an internal bug.\n"
"Please send the following info to me, Karel, at karel@icce.rug.nl and I'll\n"
"look into it:\n"
"    - the version of your YODL package\n"
"    - all the sourcefiles that YODL parses, including macro definition files\n"
"\n"
);
    
        signal (SIGSEGV, SIG_DFL);
        kill (getpid (), SIGSEGV);
        exit (1);
    }

    error ("caught signal %d", sig);
}