
#include "yodl.h"

void gram_error ()
{
    char
        *msg;

    msg = gram_parlist (builtin [mac_error], 0);
    
    message (3, "%s %s\n", builtin [mac_error], str_short (msg));

    flags.warn = 1;                         /* make sure warnings printed */
    gram_warn ("ERROR ", "%s\n", msg);      /* output message */

    exit (1);                               /* failure */
}
