
#include "yodlfixlabels.h"

void label (char **tab, int ntab, int pass)
{
    if (ntab < 4)
        error ("near line %d: label tag incomplete", lineno);
    if (! lastnum)
        lastnum = xstrdup ("");

    if (pass == FIRSTPASS)
    {
        lab = strtab_add (lab, &nlab, tab [2]);
        num = strtab_add (num, &nnum, lastnum);
    }
}

