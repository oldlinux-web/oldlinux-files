
#include "lib.h"
#include <malloc.h>
#include <stdio.h>

char
    out_of_memory [] = "memory allocation failed";


void *xrealloc (void *mem, int newsz)
{
    if (! newsz)
    {
        if (mem)
            free (mem);
        return (0);
    }

    if (! mem)
        mem = malloc (newsz);
    else
        mem = realloc (mem, newsz);

    if (! mem)
        error (out_of_memory);
        
    return (mem);
}
