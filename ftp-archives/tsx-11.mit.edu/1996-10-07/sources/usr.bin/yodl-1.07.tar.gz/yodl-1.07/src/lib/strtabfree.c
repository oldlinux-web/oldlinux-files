
#include "lib.h"
#include <malloc.h>

void strtab_free (char **tab, int ntab)
{
    int
        i;
        
    for (i = 0; i < ntab; i++)
        free (tab [i]);
    free (tab);
}