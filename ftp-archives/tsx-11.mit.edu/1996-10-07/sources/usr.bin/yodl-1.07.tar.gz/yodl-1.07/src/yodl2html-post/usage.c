
#include "yodl2html-post.h"

#ifndef VER
#    define VER         "unknown"
#endif

#ifndef YEARS
#    define YEARS       "1912-2099"
#endif

void usage ()
{
    fprintf (stderr,
"\n"
"Yet Oneother Document Language: HTML Postprocessor V" VER "\n"
"Copyright (c) K. Kubat (ICCE) " YEARS ". All rights reserved.\n"
"Another MegaHard production!\n"
"\n"
"Usage: yodl2html-post inputfile\n"
"The special tags in yodl's output file are scanned and fixed for HTML usage.\n"
"This program shouldn't be run by hand, but e.g. from the yodl2html script.\n"
"\n");

    exit (1);
}
