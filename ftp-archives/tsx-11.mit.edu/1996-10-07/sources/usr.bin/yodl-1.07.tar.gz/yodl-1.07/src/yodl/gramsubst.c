
#include "yodl.h"

void gram_subst ()
{
    char
        *s,
        *r;
        
    s = gram_parlist (builtin [mac_subst], 1);  /* read source string */

    while (lextok == tok_space ||               /* skip spaces, newlines */
           lextok == tok_newline
	  )
        lexer ();

    r = gram_parlist (builtin [mac_subst], 0);  /* read redefinition */
    
    subst = strtab_add (subst, &nsubst, s);     /* add to tables */
    nsubst--;                                   /* (for next strtab_add) */
    subst_redef = strtab_add (subst_redef, 
        &nsubst, r);
    
    free (s);
    free (r);
}
