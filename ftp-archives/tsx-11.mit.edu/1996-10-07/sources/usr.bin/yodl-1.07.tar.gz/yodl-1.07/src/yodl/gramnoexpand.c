
#include "yodl.h"

void gram_noexpand ()
{
    char
        *list;

    list = gram_parlist (builtin [mac_noexpand], 1);
    message (3, "%s %s\n",  builtin [mac_noexpand], str_short (list));

    output_string (list);

    free (list);
}
