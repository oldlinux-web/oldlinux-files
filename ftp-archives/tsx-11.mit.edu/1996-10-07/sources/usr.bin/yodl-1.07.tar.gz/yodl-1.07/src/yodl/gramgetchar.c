
#include "yodl.h"

int gram_getchar ()                         /* return argument of CHAR() */
{
    static char
        buf [2];
    char
        *list = gram_parlist (builtin [mac_char], 0);

    if (isdigit (*list))
        buf [0] = (char) gram_onenumber (builtin [mac_char], list);
    else if (strlen (list) == 1)
        buf [0] = *list;
    else
        error_gram (builtin [mac_char], 
	            "argument must be either a number or a single character");

    message (3, "%s %s\n", builtin [mac_char], list);
    free (list);
    return (buf [0]);
}
