
#include "yodl.h"

void gram_undefinemacro ()
{
    char
        *sym;
    int
        i;

    sym = gram_parlist (builtin [mac_undefinemacro], 0);
    gram_onename (builtin [mac_undefinemacro], sym);
    
    message (3, "undefining macro: %s\n", sym);
    
    if ( (i = strtab_find (userdef, nuserdef, sym)) != -1 )
        *userdef [i] = ' ';
    
    free (sym);
}
