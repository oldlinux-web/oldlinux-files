
#include "yodl.h"

void lexer_pushchar (int ch)
{
    static char
        buf [2];
        
    if (lexer_pushedp)
    {
        lexer_pushedp--;
        *lexer_pushedp = (char) ch;
    }
    else
    {
        buf [0] = (char) ch;
        lexer_pushstr (buf);
    }
}
