
#include "yodl.h"
#include "../../config.h"

char *file_expandname (char const *name)
{
    char
        *bareext,
        *dirext;
        
    if (file_isfile (name))                             /* file as-is */
        return (xstrdup (name));
        
    bareext = xstrdup (name);
    bareext = str_concat (bareext, DEFAULT_EXT);        /* supply extension */
    if (file_isfile (bareext))
        return (bareext);
        
    free (bareext);                                     /* prefix with dir */
    dirext = xstrdup (stdinclude);
    dirext = str_addchar (dirext, '/');
    dirext = str_concat (dirext, name);
    if (file_isfile (dirext))
        return (dirext);
        
    dirext = str_concat (dirext, DEFAULT_EXT);          /* add extension */
    if (file_isfile (dirext))
        return (dirext);

    free (dirext);
    return (xstrdup (name));
}
