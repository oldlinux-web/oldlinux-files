
#include "yodlfixlabels.h"

#ifndef VER
#    define VER         "unknown"
#endif

#ifndef YEARS
#    define YEARS       "1912-2099"
#endif

void usage ()
{
    fprintf (stderr,
"\n"
"Yet Oneother Document Language: internal labels fixer V" VER "\n"
"Copyright (c) K. Kubat (ICCE) " YEARS ". All rights reserved.\n"
"Another MegaHard production!\n"
"\n"
"Usage: yodlfixlabels actions inputfile outputfile\n"
"Where:\n"
"    actions can be: -labels (fix labels, references, links)\n"
"                    -onepass (single pass over file only)\n"
"                    -protectdot (protect .XX lines with \\& prefix)\n"
"                    -removeblank (remove blank lines and leading spaces)\n"
"                    -roff (expand t/nroff commands)\n"
"                    -tableofcontents (handle toc entries, make toc)\n"
"The internal label tags in yodl's output file are scanned and fixed.\n"
"This program shouldn't be run by hand, but e.g. from the yodl2html script.\n"
"Inputfile must exist, outputfile may be \"-\" for stdout.\n"
"\n");

    exit (1);
}
