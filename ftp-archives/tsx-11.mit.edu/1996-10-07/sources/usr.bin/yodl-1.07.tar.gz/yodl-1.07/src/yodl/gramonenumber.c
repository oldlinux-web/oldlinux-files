
#include "yodl.h"

int gram_onenumber (char const *sym, char const *list)
{
    int
        ret;
        
    if (! list  || ! *list || 
        ! sscanf (list, "%d", &ret)
       )
        error_gram (sym, 
	            "exactly one number in parlist expected instead of %s",
		    list);

    return (ret);
}