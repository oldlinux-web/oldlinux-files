
#include "yodl2html-post.h"

void newfile (STRINGTAB t)
{
    int
        i;

    if (pass)
        chapterlinks ();                    /* links in postamble */

    outf_count++;                           /* set new file */
    free (curfile);
    curfile = xstrdup (outputfilename (outf_count));
    
    if (pass)                               /* only in second pass: */
    {
        close_file (outf);                  /* close old output file */

        outf = open_file (curfile, "w");    /* and.. open for writing */

        output (outf, "<body ");             /* print <body> tag */
        for (i = 0; i < bodyopt.nstr; i++)
            output (outf, "%s", bodyopt.str [i]);
        output (outf, " >\n");
        
        output (outf, "<title>");           /* print document title */
        for (i = 0; i < doctitle.nstr; i++)
            output (outf, "%s", doctitle.str [i]);
        output (outf, "</title>\n");

        chapterlinks ();                    /* put links in preamble */
    }
    else
        outf_max++;                         /* update max counter of passes */
}
