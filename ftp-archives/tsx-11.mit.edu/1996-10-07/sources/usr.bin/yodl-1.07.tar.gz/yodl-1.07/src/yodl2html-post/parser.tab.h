#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	tok_starttag	258
#define	tok_endtag	259
#define	tok_space	260
#define	tok_string	261


extern YYSTYPE yylval;
