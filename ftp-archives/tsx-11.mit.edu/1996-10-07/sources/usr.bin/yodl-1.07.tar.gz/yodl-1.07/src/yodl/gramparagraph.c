
#include "yodl.h"

void gram_paragraph (char const *lbuf)
{
    int
        slot;

    if ( (slot = strtab_find (userdef, nuserdef, "PARAGRAPH")) == -1 )
        output_string (lbuf);
    else
    {
        lexer_pushstr (lexbuf);                 /* push back last symbol */
        lexer_pushstr (definition [slot]);      /* push back par def */
        lexer ();                               /* prepare next sym */
    }
}
