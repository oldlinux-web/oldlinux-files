
#include "yodl2html-post.h"

void ref (STRINGTAB t)
{
    int
        i;

    if (! pass)                             /* if first pass: ignore */
        return;
        
    if (t.nstr < 3)
        error ("incomplete ref tag");

    for (i = 0; i < nlab; i++)
        if (! strcmp (lab [i].label, t.str [3]))
        {
            output (outf, "<a href=\"%s#%s\">%s</a>", 
                     lab [i].fname, 
                     lab [i].label,
                     lab [i].value);
            return;
        }
        
    warning ("unresolved label: %s", t.str [3]);
    output (outf, "??");
}
