
#include "yodl.h"

void gram_onename (char const *sym, char const *list)
{
    char const
        *cp;
    static char const
        allowed [] = "/:.-_[](){}";
        
    if (! list || ! *list)
        error_gram (sym, "empty parlist, while identifier expected");
        
    for (cp = list; *cp; cp++)
        if (! isalnum (*cp) && ! strchr (allowed, *cp))
            error_gram (sym, "exactly one identifier in parlist expected");

}