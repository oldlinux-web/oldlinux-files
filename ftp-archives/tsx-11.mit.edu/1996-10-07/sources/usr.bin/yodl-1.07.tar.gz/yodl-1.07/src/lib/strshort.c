
#include "lib.h"
#include <string.h>

char *str_short (char const *s)
{
    static char
        buf [30];
    char
        *cp;
        
    if (! s || ! *s)
        return ("");
        
    strncpy (buf, s, 28);
    buf [29] = '\0';
    
    if (strlen (buf) > 25)
        strcpy (buf + 25, "...");
        
    while ( (cp = strchr (buf, '\n')) )
        *cp = '/';
        
    return (buf);
}