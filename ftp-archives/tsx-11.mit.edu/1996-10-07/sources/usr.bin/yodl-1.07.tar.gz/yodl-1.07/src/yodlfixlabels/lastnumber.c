
#include "yodlfixlabels.h"

void lastnumber (char **table, int ntable, int pass)
{
    if (ntable < 4)
        error ("near line %d: last number tag incomplete", lineno);

    if (pass == FIRSTPASS)          /* store last number */
    {
        free (lastnum);
        lastnum = xstrdup (table [2]);
    }
}

