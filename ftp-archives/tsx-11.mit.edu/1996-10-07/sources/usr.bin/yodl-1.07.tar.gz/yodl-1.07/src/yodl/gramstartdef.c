
#include "yodl.h"

void gram_startdef ()
{
    char
        *arg;
        
    arg = gram_parlist (builtin [mac_startdef], 0);
    in_def++;
    
    message (3, "%s now DEF level %d\n", builtin [mac_startdef], in_def);

    free (arg);
}
