
#include "yodl.h"

void gram_countervalue ()
{
    int
        index;
    char
        *name,
        buf [80];
        
    name = gram_parlist (builtin [mac_countervalue], 0);
    index = gram_findcounter (builtin [mac_countervalue], name);
    
    message (3, "%s %s: %d\n", builtin [mac_countervalue], name, 
             counterval [index]);

    sprintf (buf, "%d", counterval [index]);
    
    lexer_pushstr (lexbuf);                 /* push back symbol beyond parl */
    lexer_pushstr (buf);                    /* push back expansion */
    lexer ();                               /* prepare next */
    
    free (name);                            /* return memory */
}
