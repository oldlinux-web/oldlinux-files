
#include "yodl.h"

void gram_addtocounter ()
{
    char
        *name,
	*addst;
    int
        addnr,
        index;
        
    name = gram_parlist (builtin [mac_addtocounter], 0);
    index = gram_findcounter (builtin [mac_addtocounter], name);
    addst = gram_parlist (builtin [mac_addtocounter], 0);
    addnr = gram_onenumber (builtin [mac_addtocounter], addst);
    
    message (3, "%s %s %s\n", builtin [mac_addtocounter], name,  addst);
    counterval [index] += addnr;
    
    free (name);
    free (addst);
}