
#include "yodl.h"

void gram_dummy ()
{
    char
        *list = gram_parlist (builtin [mac_dummy], 0);
        
    message (3, "%s\n", builtin [mac_dummy]);
    free (list);
}
