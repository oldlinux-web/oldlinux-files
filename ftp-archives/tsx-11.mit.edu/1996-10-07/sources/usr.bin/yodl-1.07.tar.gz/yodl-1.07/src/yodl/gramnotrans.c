
#include "yodl.h"

void gram_notrans ()
{
    char
        *list;
    CHARTAB
        *old_curchartab;

    list = gram_parlist (builtin [mac_notrans], 1);
    message (3, "%s %s\n",  builtin [mac_notrans], str_short (list));

    old_curchartab = curchartab;
    curchartab = 0;
    output_string (list);
    curchartab = old_curchartab;

    free (list);
}
