
#include "yodl2html-post.h"

void title (STRINGTAB t)
{
    int
        i;

    if (pass)                               /* store only during first pass */
        return;
        
    for (i = 3; i < t.nstr; i++)            /* store all */
        stringtab_addstr (&doctitle, t.str [i]);
}
