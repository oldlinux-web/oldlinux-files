
#include "yodl2html-post.h"

void init ()
{
    error_setprogname ("yodl2html-post");        /* for error msgs */

    tocfname = xstrdup (fname);                 /*file for table of cont */
    tocfname = str_concat (tocfname, ".toc");
    tocf = open_file (tocfname, "w");
    
                                                /* table of files to remove */
    tempfiles = strtab_add (tempfiles, &ntempfiles, tocfname);
    
    inputfile = xstrdup (fname);                /* new input file */
    inputfile = str_concat (inputfile, ".in");

    if (rename (fname, inputfile))
        error ("cannot rename %s to %s: %s",
               fname, inputfile, strerror (errno));

    yyin = open_file (inputfile, "r");

    outf = open_file (fname, "w");              /* output file */
    curfile = xstrdup (fname);
    
    tempfiles = strtab_add (tempfiles, &ntempfiles, inputfile);
}
