
#include "lib.h"

void strtab_del (char **tab, int *ntab, char const *what)
{
    int
        i,
	j;
        
    for (i = 0; i < *ntab;)
        if (! strcmp (tab [i], what))
        {
            for (j = i + 1; j < *ntab; j++)
                tab [j - 1] = tab [j];
            (*ntab)--;
        }
        else
            i++;
}
