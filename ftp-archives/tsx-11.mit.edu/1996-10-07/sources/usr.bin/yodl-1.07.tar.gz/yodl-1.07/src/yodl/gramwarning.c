
#include "yodl.h"

void gram_warning ()
{
    char
        *msg;                               /* message to print */
    int
        oldwarnflag;                        /* previous warning flag */

    msg = gram_parlist (builtin [mac_warning], 0);
    
    message (3, "%s %s\n", builtin [mac_warning], str_short (msg));

    oldwarnflag = flags.warn;               /* save old warning flag */
    flags.warn = 1;                         /* make sure warnings printed */
    gram_warn ("%s", msg);                  /* output message */
    flags.warn = oldwarnflag;               /* restore warning level */
}
