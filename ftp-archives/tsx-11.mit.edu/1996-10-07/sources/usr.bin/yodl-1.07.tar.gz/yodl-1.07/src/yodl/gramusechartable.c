
#include "yodl.h"

void gram_usechartable ()
{
    int
        index;
    char
        *tabname;

    tabname = gram_parlist (builtin [mac_usechartable], 0);
    
    message (3, "%s %s\n", builtin [mac_usechartable],
             tabname && *tabname ? tabname : "zero-state");
    
    if (! tabname || ! *tabname)                    /* activate char table */
        curchartab = 0;
    else
    {
        gram_onename (builtin [mac_usechartable], tabname);
        if ( (index = strtab_find (chartabname, nchartab, tabname)) == -1 )
            error_gram (builtin [mac_usechartable], "no table %s defined",
                        tabname);
        curchartab = chartab + index;
    }
    
    free (tabname);
}
