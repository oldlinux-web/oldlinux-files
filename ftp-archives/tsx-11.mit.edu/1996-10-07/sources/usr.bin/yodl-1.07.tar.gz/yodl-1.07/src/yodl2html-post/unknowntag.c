
#include "yodl2html-post.h"

void unknowntag (STRINGTAB tab)
{
    fprintf (stderr, "yodl2html-post warning: unknown tag %s\n",
             tab.str [0]);
}
