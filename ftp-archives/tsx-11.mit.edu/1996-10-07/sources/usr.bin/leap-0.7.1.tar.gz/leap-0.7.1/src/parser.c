/* 
 * Name: parser.c
 * Description: Parser module functions - Takes a string, and
 *		builds a parse tree, then executes it...
 * Version: $Id: parser.c,v 1.15 1996/09/08 22:39:14 rleyton Exp rleyton $
 *
 *   LEAP - An extensible and free RDBMS
 *   Copyright (C) 1996 Richard Leyton
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   See the file COPYING for more information.
 *
 *   Richard Leyton, c/o 3.Pelting Drove, Priddy, WELLS, 
 *   Somerset, BA5 3BA. E-Mail: richard_leyton@mail.amsinc.com
 *   and/or e0190404@brookes.ac.uk. http://www.brookes.ac.uk/~e0190404/leap.html
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "dtypes.h"
#include "parser.h"
#include "util.h"
#include "p_stack.h"
#include "relation.h"
#include "rtional.h"
#include "database.h"
#include "info.h"
#include "dbase.h"
#include "tuples.h"
#include "attributes.h"

boolean parse_error;	/* TRUE if an error occurs during ptable build */
boolean exec_error;	/* TRUE if an error occurs during ptable exec */

parse_tree new_parse_node( parse_tree parent,
			   char handed) {
/* new_parse_node
 * Create a new parse node
 */
	parse_tree pt;

	pt=(parse_tree_def *) malloc(sizeof(parse_tree_def));
	check_assign(pt,"parser.new_parse_node");
	
	pt->left=NULL;
	pt->ldone=FALSE;

	pt->right=NULL;
	pt->rdone=FALSE;

	strcpy(pt->expression,"");
	pt->result=NULL;
	pt->lresult=NULL;
	pt->rresult=NULL;
	pt->hand=handed;
	strcpy(pt->target,"");

	pt->parent=parent;

	return(pt);
}

void display_ptree(parse_tree ptree,
		   int depth) {
	char temp[MAXIMUM_EXPRESSION];

	switch (ptree->hand) {
		case NODE_LEFT:
			writeln("LEFT NODE");
			break;
		case NODE_RIGHT:
			writeln("RIGHT NODE");	
			break;
		case NODE_ROOT:
			writeln("ROOT NODE");
			break;
	}
	sprintf(temp,"Depth: %i",depth);
	do_trace(temp);
	sprintf(temp,"Expression: %s",ptree->expression);
	do_trace(temp);
	sprintf(temp,"Result: <NOT KNOWN>");
	do_trace(temp);
	
	if (ptree->left!=NULL) {
		display_ptree(ptree->left,depth+1);
		sprintf(temp,"Returned to depth: %i Expression: %s",depth,ptree->expression);
		do_trace(temp);
	} 
	if (ptree->right!=NULL) {
		display_ptree(ptree->right,depth+1);
		sprintf(temp,"Returned to depth: %i Expression: %s",depth,ptree->expression);
		do_trace(temp);
	}
}

relation process_parse_tree( database db,
			     parse_tree parsetree) {
/* process_parse_tree
 * This function takes a parse tree, and applies the operations
 * as appropriate, in the correct order, ITERATIVELY
 */
	boolean abort=FALSE;
	parse_tree ptree=parsetree,result_tree=NULL;
	pt_stack ptstack;
	char temp[MAXIMUM_INPUT_STRING];
	relation rtrel;
	word count;

	/* Set the execution error flag false */
	exec_error=FALSE;
	
	do_trace("Processing parse tree...");

	ptstack=pt_create_stack();
	
	count=0;

	while ( (result_tree==NULL) && (abort==FALSE) )	 {

		/* Locate the left most node */
		while (ptree->left!=NULL) {
			pt_push_stack(ptstack,ptree);
			ptree=ptree->left;
			do_trace("Done assignment");
		}

		/* TODO - I/O Tuple counts... */

		if (result_tree==NULL) {
	
			/* Reset the parse tree node result, to save
			 * doing this in each operation
			 * TODO - Check its not already NULL..
			 */
			sprintf(temp,"Operation (%u): %s",count++,ptree->expression);
			do_trace(temp);

			ptree->result=NULL;
			switch (ptree->operation) {

				/* No action */
				case C_COMMENT:
					break;

				/* Obsolete operations */
				case C_INFIX:
				case C_FLUSH:
				case C_HIGH:
				case C_PRINT_IDX:
				case C_IDX_STORE:
				case C_DISPLAY_INDEX:
				case C_PANIC:
					do_error(ERROR_OBSOLETE,ptree->command,NONFATAL);
					break;

				case C_LIST:
					list_source_code();
					break;

				/* One (non-relation) parameter */
				case C_USE:
					change_db(ptree->first);
					break;
	
				case C_LISTSRC:	
					print_source_code(ptree->first);
					break;	

				case C_RELATION:
					ptree->result=relation_find(db,ptree->command);
					if (ptree->result==NULL) {
						abort=TRUE;
						do_error(ERROR_CANNOT_FIND_REL,ptree->command,NONFATAL);
						exec_error=TRUE;
					}
					break;

				case C_SELECT:
					ptree->result=rl_select(db,ptree->lresult,ptree->second,ptree->target);
					break;

				case C_PRODUCT:
					ptree->result=rl_product(db,ptree->lresult,ptree->rresult,ptree->target);
					break;

				case C_JOIN:
					ptree->result=rl_join(db,ptree->lresult,ptree->rresult,ptree->third,ptree->target);
					break;
	
				case C_INTERSECT:
					ptree->result=rl_intersect(db,ptree->lresult,ptree->rresult,ptree->target);
					break;

				case C_DIFFERENCE:
					ptree->result=rl_difference(db,ptree->lresult,ptree->rresult,ptree->target);
					break;
	
				case C_UNION:
					ptree->result=rl_union(db,ptree->lresult,ptree->rresult,ptree->target);
					break;

				case C_PROJECT:
					ptree->result=rl_project(db,ptree->lresult,ptree->second,ptree->target);
					break;
	
				case C_DISPLAY:
					break;

				case C_RENAME:
					break;

				case C_DUPLICATE:
					break;

				case C_DISPLAY_REL:
					relation_display(current_db);
					break;

				case C_SRCFILE:
					if (strlen(ptree->first)>0) {
						sprintf(temp,"%s%s%s%s",database_dir(current_db),LEAP_SOURCE_DIR,ptree->first,LEAP_SOURCE_EXT);
					} else {
						strcpy(temp,"");
					}
					assign_input_stream(temp);
					break;	

				case C_PRINT:
					ptree->result=rl_display(ptree->lresult);
					break;
				case C_DESCRIBE:
					attribute_display(ptree->lresult);
					ptree->result=ptree->lresult;
					break;
				case C_VERSION:
					print_header();
					break;
				case C_INFO:
					print_header();
					print_info();
					break;
				case C_WARRANTY:
					do_warranty();
					break;

				case C_ADDRESSES:
					do_addresses();
					break;
					
				case C_EXIT:
					/* Terminate! */
					terminate=TRUE;
					break;

				default:
					do_error(ERROR_UNIMPLEMENTED,"Cannot determine operation",NONFATAL);
					exec_error=TRUE;
					break;
			}
			
			if (exec_error!=FALSE) {
				do_error(ERROR_PARSE_EXECUTION,ptree->expression,NONFATAL);
			}
			
			if (LTIMING==TRUE) {
				fprintf(stderr,"Timing not implemented yet\n");
			}

			/* If the parent node is assigned, ie. this is not the
			 * Root node of the parse tree 
			 */
			if (ptree->parent!=NULL) {
				switch (ptree->hand) {
					case NODE_LEFT:
						ptree->parent->lresult=ptree->result;
						ptree->parent->left=NULL;
						break;
					case NODE_RIGHT:
						ptree->parent->rresult=ptree->result;
						ptree->parent->right=NULL;
						break;
					case NODE_ROOT:
					default:
						parse_error=TRUE;
						do_error(ERROR_UNDEFINED,"Oooer",NONFATAL);
				}
	
				/* Free the memory used - TODO - Keep this for inspection
				 * of parse results after execution 
				 */
				free(ptree);
			
				if (pt_stack_empty(ptstack)==FALSE) {
					ptree=pt_pop_stack(ptstack);
				} else {
					exec_error=TRUE;
					do_error(ERROR_PARSE_EXECUTION,"Cannot determine next token.",NONFATAL);
					/* TODO - Sort out error messages - DONE 11.05.1996 */	
				}
			} else 
				result_tree=ptree;
		}
		/* Get the parent node off of the stack */

		if (ptree->right!=NULL) {
			/* Push the node back onto the stack (again) */
			pt_push_stack(ptstack,ptree);

			/* Goto the right hand node */
			ptree=ptree->right;
		}
	}

	do_trace("Finished processing.");

	if (exec_error==FALSE) {
		rtrel=result_tree->result;

		if (result_tree!=NULL) {
			free(result_tree);
			pt_stack_dispose(&ptstack);
		}
	} else {
		pt_flush_stack(&ptstack);
		rtrel=NULL;
		do_trace("Errors occured.");
	}


	do_trace("Completed parse tree execution.");

	return(rtrel);
}

relation process_query( database db,
			char *query) {
/* process_query
 * Takes a string, and processes it as an expression, returning
 * a relation, or NULL if nothing results, or an error occurs
 * check error codes in global vars for error.
 */
	parse_tree ptree,reftree;
	char result[MAXIMUM_EXPRESSION],*assignment,destination[RELATION_NAME_SIZE+1];
	char temp[255];
	int operation;
	relation rtrel;

#ifdef DEBUG
	report("Using Iterative parser");
	report("Building Parse Tree");
#endif	

	/* Create a new node */
	ptree=new_parse_node(NULL,NODE_ROOT);
	reftree=ptree;

	/* Put the main query in it */
	strcpy(ptree->expression,query);

	/* Reset the parse_error inicator */
	parse_error=FALSE;

	/* Whilst the ptree is assigned */
	while (ptree!=NULL) {

		/* Preserve the full expression (just in case) */
		/* TODO - Do we need to preserve the whole expression? */
		strcpy(ptree->work,ptree->expression);

		/* Cut out all of the bracketed items */
		/* Don't force brackets on a string */
		strcpy(ptree->first,cut_to_right_bracket(ptree->work,1,FALSE,result));
		strcpy(ptree->second,cut_to_right_bracket(ptree->work,1,FALSE,result));
		strcpy(ptree->third,cut_to_right_bracket(ptree->work,1,FALSE,result));

		/* Check to see if there is an assignment operation in effect */
		assignment=strstr(ptree->work,ASSIGNMENT);

		if (assignment!=NULL) {
			strncpy(ptree->target,ptree->work,RELATION_NAME_SIZE);
			strtok(ptree->target,ASSIGNMENT);
			strcpy(ptree->work,assignment+1);
		} else { 
			strcpy(ptree->target,generate_random_string(RELATION_NAME_SIZE,destination));
		}
		
		/* Get the command in operation - doesn't matter where its located */
		strcpy(ptree->command,cut_token(ptree->work,'\0',result));

		/* DONE 08.05.1996 - TODO - Use cut_token, and check the contents of first, second and
		 * third to see if there is anything that might be there, but not containing
		 * brackets... ie. "print p" rather than "print (p)"
		 */

		if (strlen(ptree->first)==0) {
			strcpy(ptree->first,cut_token(ptree->work,'\0',result));
			if (strlen(ptree->second)==0) {
				strcpy(ptree->second,cut_token(ptree->work,'\0',result));
				if (strlen(ptree->third)==0) {
					strcpy(ptree->third,cut_token(ptree->work,'\0',result));
				}
			}
	
		}
		

#ifdef FULL_DEBUG
 	printf("NEW: command==%s\n1st==%s\n2nd==%s\n3rd==%s\n",
		ptree->command,ptree->first,ptree->second,ptree->third);
#endif	

		/* Put the ultimate destination relation into the
		 * relation name field of the top node 
		if (!dest_done) {
			if (dest!=NULL) strcpy(ptree->target,dest);
			dest_done=TRUE;
		}
		 */


		/* Try to locate the command */
		operation=get_command(ptree->command);

		/* If its NOT found, then its a relation, (or invalid command) */	
		if (operation==-1) {
			/* Print what we think... */
			sprintf(temp,"Parser: (Leaf node) Relation: %s",ptree->command);
			do_trace(temp);

			/* Store our thoughts... */
			ptree->operation=C_RELATION;

		/* Ok, so its an operation of some sort... */
		} else {
			ptree->operation=operation;
			sprintf(temp,"Parser: (Branch node) Operation: %s",ptree->command);
			do_trace(temp);

			switch (ptree->operation) {
				/* What sort of operation is it... */

				/* Obsoleted (Treat the same as no args) */
				case C_INFIX:
				case C_FLUSH:
				case C_HIGH:
				case C_PRINT_IDX:
				case C_IDX_STORE:
				case C_DISPLAY_INDEX:
				case C_PANIC:

				/* No arguments */
				case C_COMMENT:
				case C_VERSION:
				case C_INFO:
				case C_EXIT:
				case C_DISPLAY_REL:
				case C_WARRANTY:
				case C_ADDRESSES:
				case C_LIST:
				/* Treated the same as one argument  */

				/* One argument */
				case C_USE:
				case C_SRCFILE:
				case C_LISTSRC:
					ptree->ldone=TRUE;
					ptree->rdone=TRUE;
					break;

				/* One relation */
				case C_PRINT:
				case C_DESCRIBE:
					ptree->left=new_parse_node(ptree,NODE_LEFT);
					ptree->rdone=TRUE;
					strcpy(ptree->left->expression,ptree->first);

					break;

				/* Two relations */
				case C_PRODUCT:
				case C_UNION:
				case C_INTERSECT:
				case C_DIFFERENCE:
					ptree->left=new_parse_node(ptree,NODE_LEFT);
					ptree->right=new_parse_node(ptree,NODE_RIGHT);
					strcpy(ptree->left->expression,ptree->first);
					strcpy(ptree->right->expression,ptree->second);
					break;

				/* One relation + One set of arguments */
				case C_SELECT:
				case C_PROJECT:
					ptree->left=new_parse_node(ptree,NODE_LEFT);
					/* Mark the right (empty) node as "done" */
					ptree->rdone=TRUE;

					strcpy(ptree->left->expression,ptree->first);

					break;

				/* Two relations + One set of arguments */
				case C_JOIN:
					ptree->left=new_parse_node(ptree,NODE_LEFT);
					ptree->right=new_parse_node(ptree,NODE_RIGHT);

					strcpy(ptree->left->expression,ptree->first);
					strcpy(ptree->right->expression,ptree->second);
					break;

				/* Anything else is probably a mess up. */
				default:
					ptree->ldone=TRUE;
					ptree->rdone=TRUE;
					parse_error=TRUE;
					do_error(ERROR_UNIMPLEMENTED,ptree->command,NONFATAL);

			}
		}

		/* OLD parse_tree build section in old_code */

		/* Determine where to go next */

		if ((ptree->left!=NULL) && (!ptree->ldone)) {
			ptree->ldone=TRUE;
			ptree=ptree->left;
		} else if ((ptree->right!=NULL) && (!ptree->rdone)) {
			ptree->rdone=TRUE;
			ptree=ptree->right;
		} else if (ptree->parent!=NULL) {
			ptree=ptree->parent;
			while ( (ptree->parent!=NULL) && (ptree->ldone) && (ptree->rdone) ) 
				ptree=ptree->parent;

			if (ptree->parent!=NULL) {
				if ( (ptree->right!=NULL) && (!ptree->rdone) ) {
					ptree->rdone=TRUE;
					ptree=ptree->right;
				}
			}
		}
		/* This is the root node */
		if (ptree->parent==NULL) {
			if ( (ptree->ldone) && (ptree->rdone) ) {
				ptree=NULL;
			} else {
				if ( (ptree->left!=NULL) && (!ptree->ldone) ){
					/* This shouldn't ever need to be executed */
					ptree->rdone=TRUE;
					ptree=ptree->left;
				} else if ( (ptree->right!=NULL) && (!ptree->rdone) ) {
					ptree->rdone=TRUE;
					ptree=ptree->right;
				} else {
					parse_error=TRUE;
					do_error(ERROR_PARSE_UNRECOGNISED_TOKEN,ptree->expression,NONFATAL);
					ptree=NULL;
				}
			}
		}
	}
	do_trace("Parse Tree build completed.");

	if (LTRACE) {
		/* display parse tree */
		do_trace("Parse Tree");
		do_trace("==========");
		display_ptree(reftree,0);
		do_trace("End Parse Tree");
		do_trace("==============");
	}

	/* If a parse error occured, then report it. 
	 */
	if (parse_error==TRUE) {
		do_trace("Error(s) occured during parse tree build.");
		rtrel=NULL;
	} else {
		do_trace("Parse tree built successfully.");
		/* Otherwise process parse tree */
		rtrel=process_parse_tree(db,reftree);
	}
	
	/* return relation */
	return(rtrel);

}


relation process_expression( database db,
							 char *query) {
/* process_expression
 * Takes a string, and processes it as an expression, returning
 * a tree, or NULL if nothing results, or an error occurs
 * This is currently a hacked version of process_query, hopefully
 * it will obsolete this, and be a general tree generator...
 */
	parse_tree ptree,reftree;
	char result[MAXIMUM_EXPRESSION],*assignment,destination[RELATION_NAME_SIZE+1];
	char *tmpstringptr,tmpstring[MAXIMUM_EXPRESSION];
	char temp[255];
	int operation,counter;
	relation rtrel;

#ifdef DEBUG
	report("Using Iterative parser");
	report("Building EXPRESSION Parse Tree");
#endif	

	/* Create a new node */
	ptree=new_parse_node(NULL,NODE_ROOT);
	reftree=ptree;

	/* Put the main query in it */
	strcpy(ptree->expression,query);

	/* Reset the parse_error inicator */
	parse_error=FALSE;

	/* Whilst the ptree is assigned */
	while (ptree!=NULL) {

		/* Preserve the full expression (just in case) */
		/* TODO - Do we need to preserve the whole expression? */
		strcpy(ptree->work,ptree->expression);

		/* Cut out all of the bracketed items */
		/* Don't force brackets on a string */
		/* strcpy(ptree->first,cut_to_right_bracket(ptree->work,1,FALSE,result));
		strcpy(ptree->second,cut_to_right_bracket(ptree->work,1,FALSE,result));
		strcpy(ptree->third,cut_to_right_bracket(ptree->work,1,FALSE,result));
		*/

		counter=0;
		strcpy(tmpstring,cut_to_right_bracket(ptree->work,1,FALSE,result));
		tmpstringptr=malloc(strlen(tmpstring));
		strcpy(tmpstringptr,tmpstring);
		while (strlen(tmpstring)!=0) {
			strcpy(tmpstring,cut_to_right_bracket(ptree->work,1,FALSE,result));
			tmpstringptr=malloc(strlen(tmpstring));
			strcpy(tmpstringptr,tmpstring);
			counter++;
		}

		/* Check to see if there is an assignment operation in effect */
		assignment=strstr(ptree->work,ASSIGNMENT);

		if (assignment!=NULL) {
			strncpy(ptree->target,ptree->work,RELATION_NAME_SIZE);
			strtok(ptree->target,ASSIGNMENT);
			strcpy(ptree->work,assignment+1);
		} else { 
			strcpy(ptree->target,generate_random_string(RELATION_NAME_SIZE,destination));
		}
		
		/* Get the command in operation - doesn't matter where its located */
		strcpy(ptree->command,cut_token(ptree->work,'\0',result));

		/* DONE 08.05.1996 - TODO - Use cut_token, and check the contents of first, second and
		 * third to see if there is anything that might be there, but not containing
		 * brackets... ie. "print p" rather than "print (p)"
		 */

		if (strlen(ptree->first)==0) {
			strcpy(ptree->first,cut_token(ptree->work,'\0',result));
			if (strlen(ptree->second)==0) {
				strcpy(ptree->second,cut_token(ptree->work,'\0',result));
				if (strlen(ptree->third)==0) {
					strcpy(ptree->third,cut_token(ptree->work,'\0',result));
				}
			}
	
		}
		

#ifdef FULL_DEBUG
 	printf("NEW: command==%s\n1st==%s\n2nd==%s\n3rd==%s\n",
		ptree->command,ptree->first,ptree->second,ptree->third);
#endif	

		/* Put the ultimate destination relation into the
		 * relation name field of the top node 
		if (!dest_done) {
			if (dest!=NULL) strcpy(ptree->target,dest);
			dest_done=TRUE;
		}
		 */


		/* Try to locate the command */
		operation=get_command(ptree->command);

		/* If its NOT found, then its a relation, (or invalid command) */	
		if (operation==-1) {
			/* Print what we think... */
			sprintf(temp,"Parser: (Leaf node) Relation: %s",ptree->command);
			do_trace(temp);

			/* Store our thoughts... */
			ptree->operation=C_RELATION;

		/* Ok, so its an operation of some sort... */
		} else {
			ptree->operation=operation;
			sprintf(temp,"Parser: (Branch node) Operation: %s",ptree->command);
			do_trace(temp);

			switch (ptree->operation) {
				/* What sort of operation is it... */

				/* Obsoleted (Treat the same as no args) */
				case C_INFIX:
				case C_FLUSH:
				case C_HIGH:
				case C_PRINT_IDX:
				case C_IDX_STORE:
				case C_DISPLAY_INDEX:
				case C_PANIC:

				/* No arguments */
				case C_COMMENT:
				case C_VERSION:
				case C_INFO:
				case C_EXIT:
				case C_DISPLAY_REL:
				case C_WARRANTY:
				case C_ADDRESSES:
					/* Treated the same as one argument  */

				/* One argument */
				case C_SRCFILE:
					ptree->ldone=TRUE;
					ptree->rdone=TRUE;
					break;

				/* One relation */
				case C_PRINT:
				case C_DESCRIBE:
					ptree->left=new_parse_node(ptree,NODE_LEFT);
					ptree->rdone=TRUE;
					strcpy(ptree->left->expression,ptree->first);

					break;

				/* Two relations */
				case C_PRODUCT:
				case C_UNION:
				case C_INTERSECT:
				case C_DIFFERENCE:
					ptree->left=new_parse_node(ptree,NODE_LEFT);
					ptree->right=new_parse_node(ptree,NODE_RIGHT);
					strcpy(ptree->left->expression,ptree->first);
					strcpy(ptree->right->expression,ptree->second);
					break;

				/* One relation + One set of arguments */
				case C_SELECT:
				case C_PROJECT:
					ptree->left=new_parse_node(ptree,NODE_LEFT);
					/* Mark the right (empty) node as "done" */
					ptree->rdone=TRUE;

					strcpy(ptree->left->expression,ptree->first);

					break;

				/* Two relations + One set of arguments */
				case C_JOIN:
					ptree->left=new_parse_node(ptree,NODE_LEFT);
					ptree->right=new_parse_node(ptree,NODE_RIGHT);

					strcpy(ptree->left->expression,ptree->first);
					strcpy(ptree->right->expression,ptree->second);
					break;

				/* Anything else is probably a mess up. */
				default:
					ptree->ldone=TRUE;
					ptree->rdone=TRUE;
					parse_error=TRUE;
					do_error(ERROR_UNIMPLEMENTED,ptree->command,NONFATAL);

			}
		}

		/* OLD parse_tree build section in old_code */

		/* Determine where to go next */

		if ((ptree->left!=NULL) && (!ptree->ldone)) {
			ptree->ldone=TRUE;
			ptree=ptree->left;
		} else if ((ptree->right!=NULL) && (!ptree->rdone)) {
			ptree->rdone=TRUE;
			ptree=ptree->right;
		} else if (ptree->parent!=NULL) {
			ptree=ptree->parent;
			while ( (ptree->parent!=NULL) && (ptree->ldone) && (ptree->rdone) ) 
				ptree=ptree->parent;

			if (ptree->parent!=NULL) {
				if ( (ptree->right!=NULL) && (!ptree->rdone) ) {
					ptree->rdone=TRUE;
					ptree=ptree->right;
				}
			}
		}
		/* This is the root node */
		if (ptree->parent==NULL) {
			if ( (ptree->ldone) && (ptree->rdone) ) {
				ptree=NULL;
			} else {
				if ( (ptree->left!=NULL) && (!ptree->ldone) ){
					/* This shouldn't ever need to be executed */
					ptree->rdone=TRUE;
					ptree=ptree->left;
				} else if ( (ptree->right!=NULL) && (!ptree->rdone) ) {
					ptree->rdone=TRUE;
					ptree=ptree->right;
				} else {
					parse_error=TRUE;
					do_error(ERROR_PARSE_UNRECOGNISED_TOKEN,ptree->expression,NONFATAL);
					ptree=NULL;
				}
			}
		}
	}
	do_trace("Parse Tree build completed.");

	if (LTRACE) {
		/* display parse tree */
		do_trace("Parse Tree");
		do_trace("==========");
		display_ptree(reftree,0);
		do_trace("End Parse Tree");
		do_trace("==============");
	}

	/* If a parse error occured, then report it. 
	 */
	if (parse_error==TRUE) {
		do_trace("Error(s) occured during parse tree build.");
		rtrel=NULL;
	} else {
		do_trace("Parse tree built successfully.");
		/* Otherwise process parse tree */
		rtrel=process_parse_tree(db,reftree);
	}
	
	/* return relation */
	return(rtrel);

}


