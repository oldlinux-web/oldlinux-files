/* 
 * Name: hashing.c
 * Description: Hashing functions
 * Version: $Id: hashing.c,v 1.12 1996/09/05 22:39:42 rleyton Exp $
 *
 *   LEAP - An extensible and free RDBMS
 *   Copyright (C) 1996 Richard Leyton
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   See the file COPYING for more information.
 *
 *   Richard Leyton, c/o 3.Pelting Drove, Priddy, WELLS, 
 *   Somerset, BA5 3BA. E-Mail: richard_leyton@mail.amsinc.com
 *   and/or e0190404@brookes.ac.uk. http://www.brookes.ac.uk/~e0190404/leap.html
 *
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "dtypes.h"
#include "hashing.h"
#include "util.h"
#include "tuples.h"

/* Useful macro for getting at the elements in a Hash Table */
#define element(htable,psn) (*htable)[psn]

position hash( char *key ) {
/* hash
 * Returns a hash key, using folding
 */
	unsigned int h,c,slen;

	/* Get the first value. Automatic conversion to number */
	h=key[0];

	/* Get the length to save hassle */
	slen=strlen(key);
#ifdef FULL_DEBUG
	fprintf(stderr,"Length of >%s< : %d\n",key,slen);
#endif

	/* Move through the string */
	for(c=0;c<slen;c++) {

#ifdef FULL_DEBUG
	fprintf(stderr,">%c:%d<",key[c],c);
#endif
		/* Do the calculation... */
		h=( (h*128)+(key[c]) ) % TABLESIZE;
	}

#ifdef FULL_DEBUG
	fprintf(stderr,"Hash Key (TABLESIZE==%i): %u\n",TABLESIZE,h);
#endif
	/* Return the result */

	return( h );
}



position rehash(    position p ) {
/* rehash
 * Rehash a value
 */

	/* Rehash and return the result */
	return( (p+1) % TABLESIZE );

}



chain chain_node_create( char *e ) {
/* chain_node_create
 * Create a chain node
 */
	chain rchain;

	/* Allocate the memory and check its ok */
	rchain=(chain_struct *) malloc(sizeof(chain_struct));
	check_assign(rchain,"hashing.chain_node_create");
	
	/* Reset the structure, and copy the data */
	rchain->next=NULL;
	strcpy(rchain->element,e);

	/* Return the new structure */
	return(rchain);
}

void hashing_insert( HashTable HT,
			char *e,
			word hk) {
/* hashing_insert
 * Insert a key into the specified hashing table
 */
	position psn;
	chain nchn,pchnn,cchnn;	

	if (hk>REQ_CALC) {
		do_error(ERROR_HASH_FILE_CORRUPT,"",FATAL);
	}

	/* If the hash key has not been provided */	
	if (hk==REQ_CALC) {
		/* Caclculate the hash key */
		psn=hash(e);
	} else {
		/* Otherwise use the value provided */
		psn=hk;
	}

	/* Create ourselves a new node */
	nchn=chain_node_create(e);

	/* If there is no chain node at the head */
	if ( (*HT)[psn]==NULL) {
		/* Put the node at the head of the chain */
		(*HT)[psn]=nchn;
	} else {
		/* Otherwise, find the right position */
		pchnn=NULL;
		/*cchnn=(element(HT,psn));*/
		/*cchnn=(element(HT,psn));*/
		cchnn=(*HT)[psn];

		/* Locate the node AFTER the destination */
		while ( (cchnn!=NULL) && (strcmp(e,cchnn->element)>0) ){
			pchnn=cchnn;
			cchnn=cchnn->next;
		}

		/* If the end of the list has been reached, then add
		 * the node at the end
		 */
		if ( cchnn==NULL ) {
			pchnn->next=nchn;

			/* If the node to be inserted should go before the
			 * first node, adjust the header information
			 */
		} else if ( strcmp(cchnn->element,(*HT)[psn]->element)==0) {
			nchn->next=(*HT)[psn];
			(*HT)[psn]=nchn;

			/* Otherwise insert the new node before the current 
			 * node
 			 */
		} else if ( strcmp(e, cchnn->element)<0 ) {
			nchn->next=cchnn;
			pchnn->next=nchn;	

			/* Unless its already in the list, in which case
			 * we may as well just dispose of the memory and report
			 * an error (of sorts!)
			 */
		} else {
			fprintf(stderr,"Duplicate Entry!");

			/* Free the memory */
			free(nchn);
		}	
	}	
}

void findposn( HashTable HT,
		char *tkey,
		position *posn,
		chain *chn,
		boolean *found) {
/* findposn
 * Results: If HT contains an element with key value tkey
 * 	    then found is true and posn is that element's
 *	    position. Otherwise found is false
 */

/* Locates a node in the specified hash table, and returns the
 * Position and boolean value for the search result
 */

	position home;
	boolean finished;
	chain cchnn;

	/* Reset the found indicator */
	*found=FALSE;

	/* Calculate the hash key for the node if it were
	 * being inserted 
	 */
	home=hash(tkey);

	(*posn)=home;
	finished=FALSE;

	cchnn=(*( HT ))[ *posn ];

	/* Locate the chain node on the specified hash table */
	while (!(finished)) {
		if ( (cchnn==NULL) || ( strcmp(cchnn->element,tkey)==0 ) ) {
			finished=TRUE;
		} else {
			cchnn=cchnn->next;
		}
	}
	
	*found=(cchnn!=NULL);
	*chn=cchnn;
}

void update ( HashTable HT,
		char *e,
		boolean *updated ) {
/* update
 * Locate a given node in the hash table, and update its
 * contents to those specified 
 */
	position posn;
	boolean found;
	chain chn;

	*updated=FALSE;

	/* Locate the node */
	findposn( HT, e, &posn, &chn, &found );

	/* If the search was successful */
	if (found) {

		/* Update the elements value */
		strcpy(chn->element,e);

		/* Return true for updating */
		*updated=TRUE;
	}
}

void hashing_retrieve(   HashTable HT,
			char *tkey,
			char *e,
			boolean *retrieved) {
/* hashing_retrieve
 * Retrieve a given node from the hash table 
 */
	position posn;
	boolean found;
	chain chn;

	*retrieved=FALSE;

	/* Locate the given node in the hash table */
	findposn ( HT, tkey, &posn, &chn, &found);

	/* If the node exists in the node */
	if (found) {
		/* Return the elements contents */
		strcpy(e,chn->element);

		/* And update the success flag */
		*retrieved=TRUE;
	}
}
	
HashTable hashing_create() {
/* hashing_create
 * Create a new hashing table, and return a pointer to it
 */
	unsigned int k;
	HashTable HT;

	/* Create the hash table, and check */
#ifdef FULL_DEBUG
	printf("sizeof==%i\n",sizeof(TableType));
#endif
	HT=(TableType *) malloc(sizeof(TableType));
	check_assign(HT,"hashing.hashing_create");
	
	/* Initialise its contents */
	for(k=0;k<TABLESIZE;k++) (*HT)[k]=NULL;

	return(HT);
}

void hashing_terminate( HashTable HT) {
/* hashing_terminate
 * Dispose of the chains associated with a hashing table,
 * and the hashing table itself 
 */

	unsigned int k;
	chain ochn,cchnn;

	/* Move through the hashing table */
	for(k=0;k<TABLESIZE;k++) {
#ifdef FULL_DEBUG
		printf("k==%i\t",k);
#endif
		cchnn=(*HT)[k];

		/* Whilst valid chaing node */	
		while (cchnn!=NULL) {
#ifdef FULL_DEBUG
			printf("item==>%s<\n",cchnn->element);
#endif
			/* Mark it */
			ochn=cchnn;

			/* Go to the next node */
			cchnn=cchnn->next;

			/* Dispose of the previous node */
#ifdef FULL_DEBUG
			printf("Disposing: %p\n",ochn);
#endif
			free(ochn);

		}
	}
#ifdef FULL_DEBUG
	printf("Done.\n");
#endif
	/* Dispose of the hashing table itself */
	free(HT);

	HT=NULL;
}

void hashing_save( HashTable HT,
		   char *filen) {
/* hashing_save
 * Saves the hashing table to the filename specified
 */
	FILE *fptr;
	char temp[100];
	unsigned int counter;	
	node_str node;
	chain cur_chain_node;

	/* Open the file for writing */
	fptr=fopen( filen, "w" );

	if (fptr==NULL) {
		sprintf(temp,"Saving Hash Table File:  %s",filen);
		do_error(ERROR_FILE_OPENING,temp,NONFATAL);
	} else {
		for (counter=0;counter<TABLESIZE;counter++) {
			/* Get the head chain node */
			node.hash_key=counter;

			cur_chain_node=(*HT)[counter];
			node.pos=0;

			while (cur_chain_node!=NULL) {
				/* Get the current node */
				strcpy(node.item,cur_chain_node->element);

				/* Increment the position */
				node.pos++;

				/* Write the node to the file */
				fprintf(fptr,"h=%c\ne=%s\np=%u\n",node.hash_key,node.item,node.pos);
				/* nwritten=fwrite(&node,sizeof(node_str),1,fptr);*/

				cur_chain_node=cur_chain_node->next;
			}
		}		

		fclose(fptr);
	}
	
}

void hashing_load( HashTable *HT,
		   char *filen) {
/* hashing_load
 * Create a table, and load the hash file specified. 
 */
	FILE *fptr;
	node_str node;
	int readerr;
	char *cptr,line[MAXIMUM_ALL_DATA];

	(*HT)=hashing_create();	

	fptr=fopen(filen,"r");

	if (fptr!=NULL) {
			do {
				readerr=fscanf(fptr,"h=%c\n",&node.hash_key);
				if (readerr!=EOF) {
					cptr=fgets(line,sizeof(line),fptr);
					if (cptr!=NULL) {	
						line[strlen(line)]='\0';
						/* cptr=strchr(line,'\n'); 
						if (cptr!=NULL) {
							*cptr='\0'; */
							cptr=strchr(line,'=');
							if (cptr!=NULL) {
								cptr++;
								strcpy(node.item,cptr);
							/* }*/
						}
						readerr=fscanf(fptr,"p=%u\n",&node.pos);	
					}
				}
				if ( (readerr!=EOF) && (cptr!=NULL) ) {
					hashing_insert(*HT,node.item,node.hash_key);
				}
			} while  ( (readerr!=EOF) && (cptr!=NULL) );
	} else {
		do_error(ERROR_FILE_OPENING,filen,NONFATAL);	
	}
}


HashTable build_hash_table( relation rel ) {
/* build_hash_table
 * Build a hash table from a relation, and return a ptr
 */

	HashTable htable;
	tuple ct;
	FILE *tuple_file;
	char tuple_string[MAXIMUM_ALL_DATA];
	word count;

	/* Create the hash table */
	htable=hashing_create();

	/* Read the first tuple from the relation */
	ct=readfirst_tuple(rel,&tuple_file,&rel->noattributes,TUPLE_BUILD,NULL);

	count=0;
	if (LDEBUG) printf("\nCount:\n------\n");

	/* Whilst the tuple is valid */
	while ( ct!=NULL ) {
		/* Convert the tuple to a string */
		tuple_to_string(ct,tuple_string);

		/* Insert the string into the tuple */
		hashing_insert(htable,tuple_string,REQ_CALC);

		count++;
		if (LDEBUG) {
			printf("%u\r",count);
			fflush(stdout);
		}
		/* Load the next tuple */
		(void) readnext_tuple(&ct,&tuple_file,&rel->noattributes,TUPLE_BUILD);
	}

	/*  Mark the relation as updated, to force the
	 *  Hash table to be written on shut down 
	 */
	rel->updated=TRUE;	

	return(htable);
}
