/* 
 * Name: tuples.c
 * Description: Tuple function for control of tuples.
 * Version: $Id: tuples.c,v 1.14 1996/09/05 22:39:42 rleyton Exp $
 *
 *   LEAP - An extensible and free RDBMS
 *   Copyright (C) 1996 Richard Leyton
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   See the file COPYING for more information.
 *
 *   Richard Leyton, c/o 3.Pelting Drove, Priddy, WELLS, 
 *   Somerset, BA5 3BA. E-Mail: richard_leyton@mail.amsinc.com
 *   and/or e0190404@brookes.ac.uk. http://www.brookes.ac.uk/~e0190404/leap.html
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "dtypes.h"
#include "tuples.h"
#include "dbase.h"
#include "relation.h"
#include "attributes.h"
#include "util.h"
#include "hashing.h"

void tuple_dispose(tuple *ntuple) {
word count;
	for (count=0;count<MAXIMUM_ATTRIBUTES;count++) {
		free ( tuple_item(*ntuple,count) );
		tuple_item(*ntuple,count)=NULL;
	}

	/* free(ntuple);*/
	/* *ntuple=NULL; */
}

tuple tuple_prepare() {
/* tuple_prepare
 * This function prepares a tuple for our use, by allocating
 * memory where necessary. The tuple is useless until populated.
 */
	word count;
	tuple newtuple;

	/* Create the array of pointers... */
	newtuple=(tuple_array *) malloc(sizeof(tuple_array));
	check_assign(newtuple,"tuples.tuple_prepare");	

	/* Move through the array of tuple node ptrs */
	for (count=0;count<MAXIMUM_ATTRIBUTES;count++) {
		/* Create an item */
		(*newtuple)[count]=(tuple_item_structure *) malloc(sizeof(tuple_item_structure));

		/* Reset the entries */
		((*newtuple)[count])->rel=NULL;
		((*newtuple)[count])->att=NULL;
		strcpy(((*newtuple)[count])->data,""); 
	}

	/* Return the new tuple */
	return(newtuple);
}

tuple tuple_prepare_attributes(relation rel) {
/* tuple_prepare_attributes
 * Prepare a tuple by taking all of the attributes from
 * the specified relation, and populating it accordingly
 */
	attribute att;
	tuple ntuple;
	word count;
	FILE *attribute_file;

	/* Create the new tuple */
	ntuple=tuple_prepare();

	/* Locate the first field in our relation */
	att=attribute_findfirst(rel,&attribute_file);

	count=0;
	/* Whilst the field is assigned */
	while (att!=NULL) {
		/* Set the relation */
		tuple_relation(ntuple,count)=rel;
	
		/* Set the attribute */
		tuple_attribute(ntuple,count)=att;

		/* Fetch the next attribute */
		att=attribute_findnext(rel,att,&attribute_file,TRUE,FALSE);

		/* Increment the counter */
		count++;
	}

	/* We've not necessarily populated the entire structure,
	 * but one look at tuple_prepare should show us that the
	 * structure is reset there, so no need to repeat the process
	 * (as in the Pascal version)
	 */

	/* Return the new tuple! */
	return(ntuple);
}	

/* NB
 * In the Pascal version, there was some unused stuff in the 
 * Tuple module. This has been completely removed. 
 */


relation get_relation(tuple t) {
/* get_relation
 * This routine fetches the relation from the tuple structure
 */
	return( ((*(t)[0])->rel) );
}


void populate_tuple(tuple ntuple,
			char buffer[ATTRIBUTE_MAXIMUM_SIZE*MAXIMUM_ATTRIBUTES],
			word *noattributes) {
/* populate_tuple
 * Takes the data in buffer, and populates the tuple ntuple 
 */

	char *str,*sptr;
	word counter,position;

/* This is a very simplistic implementation, as it does not cater
 * for the eventuality that the user may wish to use DATA_DELIMITER
 * in their data. This is a TODO. 
 */
	for (counter=0; counter<MAXIMUM_ATTRIBUTES; counter++) {
		tuple_data( ntuple, counter, "");		
	}

	sptr=strchr(buffer,DELIMETER_CHAR);
	while (sptr!=NULL) {
		if (*(sptr+1)==DELIMETER_CHAR) {
			*sptr=1;
			*(sptr+1)=1;
			sptr=sptr+2;
		} else if (*(sptr+1)==NULL_INDICATOR) {
			*sptr=2;
			*(sptr+1)=2;
			sptr=sptr+2;
		}
		sptr=strchr(sptr+1,DELIMETER_CHAR);
	}


	/* Locate the first delimiter in the string */
	str=strtok(buffer,DATA_DELIMITER);

	/* Reset the counter */	
	counter=0;

	/* Whilst we have a valid string */
	while (str!=NULL) {

		sptr=strchr(str,1);
		if (sptr!=NULL) {
			for (position=0;position<strlen(str);position++) {
				*(sptr+position)=*(sptr+position+1);
			}
			*sptr=DELIMETER_CHAR;
		}
		sptr=strchr(str,2);
		if (sptr!=NULL) {
			*sptr='\0';
		}

		/* Copy the data from str into the appropriate
		 * position (tuple_data is a macro)
 		 */
		tuple_data(ntuple,counter,str);

		/* Increment our counter */
		counter++;

		/* Locate the next delimiter in the string */
		str=strtok(NULL,DATA_DELIMITER);
	}

	*noattributes=counter;

}

			
tuple readfirst_tuple(relation rel,
			FILE **tfile,
			word *noattributes,
			boolean reuse,
			tuple old_tuple) {
/* readfirst_tuple
 * Read the first tuple from the relation
 */

	char fname[FILE_PATH_SIZE];
	char buffer[ATTRIBUTE_MAXIMUM_SIZE*MAXIMUM_ATTRIBUTES];
	tuple ntuple=NULL;

	relation_full_path(rel,fname);

	/* Tac the .REL Extension - This could be more efficent, if
	 * relation_full_path perhaps had an optional third parameter
	 */
	sprintf(fname,"%s%s",fname,LEAP_RELATION_EXT);

	*tfile=fopen(fname,"r");

	rel->current_pos=1;

	/* TODO Cache read? */

	if (fgets(buffer,sizeof(buffer),*tfile)==NULL) {
		/* Maybe this should be fatal? TODO */
		/* do_error(ERROR_FILE_OPENING,fname,NONFATAL);*/
#ifdef FULL_DEBUG
		fprintf(stderr,"Error reading file or empty string?\n");
#endif
		if (reuse==FALSE) {
			ntuple=tuple_prepare_attributes(rel);
		} else {
			ntuple=old_tuple;
		}

		populate_tuple(ntuple,"",noattributes);
	} else {
		if (strcmp(buffer,"")!=0) {
			/* Create the raw tuple */
			if (reuse==FALSE) {
				ntuple=tuple_prepare_attributes(rel);
			} else {
				ntuple=old_tuple;
			}
	
			populate_tuple(ntuple,buffer,noattributes);
		} else {
#ifdef FULL_DEBUG
	fprintf(stderr,"Empty string read\n");
#endif
		}
	}

	/* Return our (possibly) spanking new tuple all fresh and clean and
	 * pure and innocent.
	 */
	return(ntuple);	
}


int readnext_tuple(tuple *ntuple,
			FILE **tfile,
			word *noattributes,
			boolean reuse) {
/* readnext_tuple
 * Reads the next tuple from the file opened by readfirst_tuple.
 */

	char buffer[ATTRIBUTE_MAXIMUM_SIZE*MAXIMUM_ATTRIBUTES];

	
	if (fgets(buffer,sizeof(buffer),*tfile)==NULL) {
		/* End of file has been reached */
		fclose(*tfile);

		if (reuse!=TUPLE_REUSE) {
			/* TODO - Clean up the tuple memory etc. DONE 09.05.1996*/
			tuple_dispose(ntuple); 
			*ntuple=NULL;
		}

		return(EOF);
	} else {
		/* Process the next tuple */
		populate_tuple(*ntuple,buffer,noattributes);

		return(RETURN_SUCCESS);
	}

}

void tuple_print(tuple ntuple,
		 boolean print_header) {
/* tuple_print
 * Prints the tuple. Optionally prints the names of the attributes
 * (useful for the display operation)
 */
	word counter;

	counter=0;

	if (print_header) {
		printf("Header display not implemented at this time\n");
		/* TODO - Tuple header print */
	}

	while ( tuple_relation(ntuple,counter)!=NULL ) {
#ifdef FULL_DEBUG
	fprintf(stderr,"Pos[%d]: %s\n",counter,tuple_d(ntuple,counter));	
#endif
		printf("%s\t",tuple_d(ntuple,counter));	

		/* Increment the counter! */
		counter++;
	}
	printf("\n");
}

int write_tuple(tuple wtuple) {
/* write_tuple
 * This routine writes the specified tuple to the file, and
 * returns the position to which it was stored (negative if
 * an error occured)
 */

	relation rel;
	FILE *fl;
	char fname[FILE_PATH_SIZE];
	unsigned int index;
	char tuple_string[MAXIMUM_ALL_DATA],found_string[HASH_KEY_SIZE];
	boolean success;

	/* Get the relation to which this tuple relates */
	rel=get_relation(wtuple);

	/* Mark it updated. It'd be expensive to check as well (kind of) */
	rel->updated=TRUE;


	/* TODO - Hashing stuff - DONE 05.05.1996 */
	tuple_to_string(wtuple,tuple_string);
	hashing_retrieve( tuple_relation(wtuple,0)->hash_table, tuple_string, found_string, &success);

	if (!success) {	
		/* Determine the position at which the insert
		 * will take place - This is for the index
		 * structures - TODO 
		 */	

		/* Determine the filename */
		sprintf(fname,"%s%s",rel->filepath,rel->filename);

		/* Open the file for appending */
		fl=fopen(fname,"a");	

		/* Handle (well, die!) errors with the file open... */
		if (fl==NULL) {
			do_error(ERROR_FILE_OPENING,fname,FATAL);
		}

		index=0;

		while( index<rel->noattributes ) {
		/*while( (*(wtuple)[index]) != NULL ) */
#ifdef FULL_DEBUG
	fprintf(stderr,"Write: >%s\\<",tuple_d(wtuple,index));
#endif
			fprintf(fl,"%s\\",tuple_d(wtuple,index));
			index++;
		}
		fprintf(fl,"\n");

		/* Insert the tuple into the hash table */
		hashing_insert((tuple_relation(wtuple,0))->hash_table,tuple_string,REQ_CALC);

		/* Close the file */
		fclose(fl);		
	} else {
		do_trace("Trace> Attempt to write duplicate tuple");
	}

	return(0);
}

void tuple_to_string(tuple t,
		     char *tuple_string) {
/* tuple_to_string
 * Convert a tuple's data to a single string (for hashing
 * purposes)
 */
	unsigned int position;

	/* Initialise our position counter */
	position=0;

	/* Whilst the attribute ptr at this tuple node is not null */
	while (   tuple_attribute(t,position) != NULL  ) {

		/* If this is the first tuple node */
		if (position==0) {
			/* Copy the data into the string */
			strcpy( tuple_string, tuple_d(t,position) );
		} else {
			/* Otherwise, concatenate the data with the string */
			strcat( tuple_string, tuple_d(t,position) );
		}

		/* Increment the position counter */
		position++;
	}
}

attribute tuple_find_attribute( tuple ct,
				char *name) {
/* tuple_find_attribute
 * Locates an attribute within a tuple, and returns it.
 * Primarily of use for the condition evaluation, when building
 */
	word counter=0;
	boolean found=FALSE;

	/* Whilst the attribute has not been found, and the current item in the
	 * tuple is not NULL
     	*/
	while ( (found==FALSE) && ( tuple_relation(ct, counter ) != NULL ) ) {

		/* Compare the attribute name to the string we are after... */
		if ( strcmp(name, attribute_name( tuple_attribute(ct, counter) ) ) == 0 ) {
			/* It matches! */
			found=TRUE;	
		} else {
			/* It's not the one we are after */
			counter++;
		}
	}

	if ( found == TRUE ) {
		return( tuple_attribute(ct,counter) );
	} else {
		return( NULL );
	}
}

char *tuple_find_attribute_val( tuple ct,
				char *name ) {

	word counter=0;
	boolean found=FALSE;

	/* Whilst the attribute has not been found, and the current item in the
	 * tuple is not NULL
     	*/
	while ( (found==FALSE) && ( tuple_relation(ct, counter ) != NULL ) ) {

		/* Compare the attribute name to the string we are after... */
		if ( strcmp(name, attribute_name( tuple_attribute(ct, counter) ) ) == 0 ) {
			/* It matches! */
			found=TRUE;	
		} else {
			/* It's not the one we are after */
			counter++;
		}
	}

	if ( found == TRUE ) {
		return( tuple_d( ct, counter ) );
	} else {
		return( NULL );
	}
}
