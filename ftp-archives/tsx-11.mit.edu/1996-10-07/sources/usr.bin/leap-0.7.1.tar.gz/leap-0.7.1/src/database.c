/* 
 * Name: database.c
 * Description: Database management functions
 * Version: $Id: database.c,v 1.3 1996/09/05 22:39:42 rleyton Exp $
 *
 *   LEAP - An extensible and free RDBMS
 *   Copyright (C) 1996 Richard Leyton
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   See the file COPYING for more information.
 *
 *   Richard Leyton, c/o 3.Pelting Drove, Priddy, WELLS, 
 *   Somerset, BA5 3BA. E-Mail: richard_leyton@mail.amsinc.com
 *   and/or e0190404@brookes.ac.uk. http://www.brookes.ac.uk/~e0190404/leap.html
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "database.h"
#include "dtypes.h"
#include "rtional.h"
#include "relation.h"
#include "tuples.h"
#include "util.h"
#include "dbase.h"

int change_db( char *new_db ) {
/* change_db
 * Changes the current database to that specified in the parameter
 */
	char temp[80];
	relation selectr,projectr;
	tuple ctuple;
	FILE *tfile;
	word tnoattributes;

	if (strcmp(database_name(current_db),new_db)==0) {
		do_error(ERROR_ALREADY_OPEN,new_db,NONFATAL);
	} else {

		sprintf(temp,"(NAME=\"%s\")",new_db);

		/* Select the table from the DD_DATABASE (leapdata) table */
		selectr=rl_select( master_db, relation_find(master_db,LEAP_DD_DATABASE), temp, "");

		/* If that worked... */
		if (selectr!=NULL) {

			/* Project out the database */
			projectr=rl_project( master_db, selectr, "NAME", "");

			/* If no error occured  */
			if (projectr!=NULL) {

				/* Read the first tuple */
				ctuple=readfirst_tuple(projectr, &tfile, &tnoattributes, TUPLE_BUILD, NULL);

				/* Convert it to a string */
				tuple_to_string(ctuple,temp);
	
				/* Read the next tuple */
				(void) readnext_tuple( &ctuple, &tfile, &tnoattributes, TUPLE_BUILD);

				/* If the read did not get to the end of the relation */
				if (ctuple!=NULL) {
					/* Dispose of the tuple memory */
					tuple_dispose(&ctuple);

					/* Report the error */
					do_error(ERROR_UNDEFINED,"Multiple instances in a dd table!",NONFATAL);

					/* Return */
					return(RETURN_ERROR);
				} else {
					/* The read took us to the end of the tuple (and disposed
			     		* of the tuple
				 	*/
					if (strlen(temp)>0) {
						/* Dispose of old db */
						relations_dispose_all(current_db);

						/* Change the database */
						current_db=database_create(temp);
						relations_open(current_db);
	
						sprintf(temp,"Database changed to: %s",database_name(current_db));
						report(temp);	

					} else {
						do_error(ERROR_UNKNOWN_DATABASE,new_db,NONFATAL);
						return(RETURN_ERROR);
					}
				}
			} else {
				/* Can't access the Data dictionary relation in master database */
				sprintf(temp,"Access of %s",LEAP_DD_DATABASE);
				do_error(ERROR_DATA_DICTIONARY,temp,NONFATAL);
				return(RETURN_ERROR);
			}
		} else {
			/* Can't locate the data dictionary relation */
			sprintf(temp,"Location of %s",LEAP_DD_DATABASE);
			do_error(ERROR_DATA_DICTIONARY,temp,NONFATAL);
			return(RETURN_ERROR);
		}
	} 
	
	return(RETURN_SUCCESS);
}
