/* 
 * Name: relation.c
 * Description: Controls the baseic relation structure.
 * Version: $Id: relation.c,v 1.13 1996/09/08 22:39:14 rleyton Exp rleyton $
 *
 *   LEAP - An extensible and free RDBMS
 *   Copyright (C) 1996 Richard Leyton
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   See the file COPYING for more information.
 *
 *   Richard Leyton, c/o 3.Pelting Drove, Priddy, WELLS, 
 *   Somerset, BA5 3BA. E-Mail: richard_leyton@mail.amsinc.com
 *   and/or e0190404@brookes.ac.uk. http://www.brookes.ac.uk/~e0190404/leap.html
 *
 */

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

/* These are needed for directory access */
#include <sys/types.h>
#include <dirent.h>

#include "dtypes.h"
#include "relation.h"
#include "util.h"
#include "dbase.h"
#include "attributes.h"
#include "hashing.h"

char *relation_name(relation rel) {
/* relation_name
 * Returns a ptr to the relations name
 */
	return(rel->name);
}

void relation_insert( database db,
		      relation newrel) {
/* relation_insert
 * Insert the relation into the database relation structure 
 */
	relation currentRel,previousRel;
	
	/* Check if this is the first relation to be inserted. */
	if (db->first_relation==NULL) {

#ifdef FULL_DEBUG
	printf("This is the first relation in the database\n");
#endif

		/* It is, so we can put it at the head of the structure */
		db->first_relation=newrel;
	} else {
		/* This isn't the FIRST relation, but it may yet
	      	 *	go at the head of the structure 
		 */
		currentRel=db->first_relation;
		previousRel=NULL;

		/* Search the structure for the position at which
		 * to insert the relation
		 */			
		while ( (currentRel!=NULL) && (strcmp(currentRel->name,newrel->name)<0)) {
				previousRel=currentRel;
				currentRel=currentRel->next;			
		}

		/* We've found the right place in the structure */

		/* Insert at the start of the structure */
		if (previousRel==NULL) {
#ifdef FULL_DEBUG
	printf("This is to become the first relation in the database\n");
#endif
			db->first_relation->previous=newrel;
			newrel->next=db->first_relation;
			db->first_relation=newrel;

		} else if (currentRel==NULL) {
			/* Insert at the end of the structure */
			
#ifdef FULL_DEBUG
	printf("This is the last relation in the database \n");
#endif

			previousRel->next=newrel;
			newrel->previous=previousRel;
			db->last_relation=newrel;	
		} else {
			/* Insert it "normally" */

#ifdef FULL_DEBUG
	printf("This is a normal insert into the structure\n");
#endif
			previousRel->next=newrel;
			currentRel->previous=newrel;
			newrel->previous=previousRel;
			newrel->next=currentRel;
		}
	}
	
}

void create_tempfile( database db,
			char *relation_name) {
/* create_tempfile
 * Create a temporary "tag" file 
 */
	FILE *tempfile;
	char fname[FILE_PATH_SIZE];

	/* Create the filename */
	sprintf(fname,"%s%s%s%s",database_dir(db),LEAP_RELATION_DIR,relation_name,LEAP_TEMPORARY_EXT);

	tempfile=fopen(fname,"w");

	if (tempfile==NULL) {
		do_error(ERROR_FILE_OPENING,fname,FATAL);
	}

	fprintf(tempfile,"%s\nRelation: %s\n",LEAP_TEMPORARY_TXT,relation_name);
	fclose(tempfile);
}

relation_struct *relation_create( database db,
				  char *relation_name,
				  boolean temporary)
/* relation_create
 * Create the specified relation, and insert it into the
 * database structure
 */
{
	relation_struct *rel;
	FILE *relationfile,*attributefile;
	char fullname[FILE_PATH_SIZE];

	if ( !(strstr(relation_name,"*")==NULL) || !(strstr(relation_name,"?")==NULL) ) {
		do_error(ERROR_WILDCARD_IN_NAME,relation_name,NONFATAL);

		return NULL;
	} else {
		/* Create the relation structure */	
		rel=(relation_struct *) malloc(sizeof(relation_struct));
		check_assign(rel,"relation.relation_create");

		/* Populate the data */
	
		/* Copy the relation name */
		strcpy(rel->name,relation_name);

		/* Setup the paths */
		sprintf(rel->filepath,"%s%s",database_dir(db),LEAP_RELATION_DIR);

#ifdef FULL_DEBUG
		printf("Filepath (%i): %s\n",strlen(rel->filepath),rel->filepath);
#endif
		/* Setup the name */
		sprintf(rel->filename,"%s%s",relation_name,LEAP_RELATION_EXT);
		sprintf(rel->fieldname,"%s%s",relation_name,LEAP_FIELD_EXT);

		/* Reset the position counter */
		rel->current_pos=0;	

		/* Reset the number of attributes in the relation */
		rel->noattributes=0;

		/* Setup the cache */
		rel->rcache=NULL; /* Call cache_create TODO */

		/* Create the relation file */
		sprintf(fullname,"%s%s",rel->filepath,rel->filename);
#ifdef FULL_DEBUG
		printf("path:%s\nname:%s\n",rel->filepath,rel->filename);
#endif
		relationfile=fopen(fullname,"w");

		/* If there was an error creating the file */
		if (relationfile==NULL) {
			do_error(ERROR_FILE_OPENING,fullname,FATAL);
		}

		/* Create the attribute file */
		strcpy(fullname,rel->filepath);
		strcat(fullname,rel->fieldname);
		attributefile=fopen(fullname,"w");

		/* If there was an error creating the file */
		if (attributefile==NULL) {
			do_error(ERROR_FILE_OPENING,fullname,FATAL);
		}
	
		/* Close the files - We don't need the fd's */	
		fclose(relationfile);
		fclose(attributefile);					

		/* Reset the structural information */
		rel->next=NULL;
		rel->previous=NULL;

		/* Set the updated flag. If a relation is not
		 * updated, then no need to write it out, or its
		 * hash table, which can be expensive and slow 
		 */		
		rel->updated=FALSE;

		rel->temporary=temporary;
		if (temporary) {
			create_tempfile(db,relation_name);
		}

		/* Insert the relation into the db structure */
		relation_insert(db,rel);

		/* Build the hash structure */
		rel->hash_table=hashing_create();

		/* Return the relation ptr */
		return rel;
	}
} 

void relation_print( relation_struct *relation)
/* relation_print
 * Print out basic information about the relation
 */
{
	/* Print the relations name, and a tab */
	printf("%s\t",relation->name);

	/* Indicate if the relation is temporary or not */
	if (relation->temporary) {
		printf("(Temporary)\n");
	} else {
		printf("(Permanent)\n");
	}

}

relation relation_findfirst( database db ) {
/* relation_findfirst
 * Returns the first relation in the structure
 */
	return (db->first_relation);
}

relation relation_findnext( relation rel ) {
/* relation_findnext
 * Returnst the next relation in the structure,
 * or NULL if there are no more 
 */
	return (rel->next);
}


relation relation_find( database db,
			char *relname) {
/* relation_find
 * Locates the specified relation in the relation structure
 */
	relation rel;

	/* Locate the first relation in the structure */
	rel=relation_findfirst(db);

	/* Whilst the relation is not null (assigned), and the name
 	 * doesn't match, move through the structure 
	 */	
	while ( (rel!=NULL) && (strcmp(relname,relation_name(rel))!=0) ) {
		rel=relation_findnext(rel);
	}

	/* Return the contents of rel - Which will be NULL if a 
	 * relation was not found, or contain the relation we want
	 */	
	return(rel);
}

void relation_display( database db ) {
/* relation_display
 * Displays all of the relations in the database structure
 */
	relation currentRel;

	/* Get the first relation */
	currentRel=relation_findfirst(db);

	/* Whilst we have a valid relation */
	while (currentRel!=NULL) {
		/* Print the current relation */
		relation_print(currentRel);

		/* Fetch the next relation from the structure */	
		currentRel=relation_findnext(currentRel);
	}
}

boolean relation_temporary(relation rel) {
/* relation_temporary
 * Returns TRUE or FALSE if the relation is temporary or not
 */
	return(rel->temporary);
}

word relation_noattributes(relation rel) {
/* relation_noattributes
 * Returns the number of attributes in a relation
 */
	return(rel->noattributes);
}

void relation_full_path(relation rel,
 			 char *string) {
/* relation_full_path
 * Gets the relations full path (including the name,
 * BUT NOT THE EXTENSION
 */

	sprintf(string,"%s%s",rel->filepath,rel->name);
}

relation relation_read( char *path, char *name) {
/* relation_read
 * Read a specified relation into memory, and return
 * a ptr to it
 */
	relation rel;
	char relname[RELATION_NAME_SIZE+FILENAME_EXT_SIZE+1];
	FILE *tmp; /* Used to test if a file exists */
	char tstring[FILE_PATH_SIZE]; /* Used for test */
	attribute att; /* For calculating the number of fields */
	char temp[FILE_PATH_SIZE];	

	/* Create the relation and check its ok */	
	rel=(relation_struct *) malloc(sizeof(relation_struct));
	check_assign(rel,"relation.relation_read");

	/* Copy the relation filename into the "name" */
	strcpy(relname,name);		

	if (strtok(relname,".")==NULL) {
		/* This shouldn't ever happen, because its only
		 * through relations_open that we're called, and
		 * it checks for LEAP_RELATION_EXT in the name...
		 */
		do_error(ERROR_UNKNOWN,"Not a relation? Something strange has happened",FATAL);

		/* Return NULL. This is never reached (unless things really are going weird) */
		return(NULL);
	} else {
#ifdef FULL_DEBUG
	fprintf(stderr,"relname==%s\n",relname);
#endif
		strcpy(rel->name,relname);

		/* Populate with some information */	
		strcpy(rel->filepath,path);
		strcpy(rel->filename,name);

		/* Populate the field information */
		strcpy(rel->fieldname,relname);
		/* And add the field extension */
		strcat(rel->fieldname,LEAP_FIELD_EXT);

		/* Reset the structural information */	
		rel->next=NULL;
		rel->previous=NULL;	

		rel->rcache=NULL;

		/* Build the temporary file name */	
		strcpy(tstring,path);
		strcat(tstring,relname);
		strcat(tstring,LEAP_TEMPORARY_EXT);
		
		/* Try to open the temporary file */
		tmp=fopen(tstring,"r");

		/* If tmp is NULL, no file. (False)
		 * If tmp is NOT null, file (True)
 		 */
		if (tmp==NULL) {
			rel->temporary=FALSE;
		} else {
			rel->temporary=TRUE;
		}

		/* Close the file */
		fclose(tmp);

		relation_full_path(rel,temp);
		strcat(temp,LEAP_HASH_EXT);
		tmp=fopen(temp,"r");

		/* If the hash file exists... */
		if (tmp!=NULL) {
			/* Try to load it */

			if (LTRACE==TRUE) {
				printf("Loading hash table for relation %s...",name);
				fflush(stdout);
			}

			hashing_load(&rel->hash_table,temp);

			if (LTRACE==TRUE) {
				printf(" Done.\n");
			}
		} else {
			/* No table exists, so create it... */

			printf("No hash table exists for relation %s - Creating...",name);
			fflush(stdout);

			/* Generate the hash table */			
			rel->hash_table=build_hash_table(rel);

			/* Save the newly generated hash table */
			/* hashing_save(rel->hash_table,temp); */

			printf(" Done.\n");
		}
		
		/* Reset the Hash Table TODO - DONE 06.05.1996 */
		/* rel->hash_table=NULL; */

		/* Determine the number of attributes */
		/* IDEA - Store the number of attributes in the 
		 * .REL file...
		 */

		rel->noattributes=0;

		/* Locate the first attribute */
		att=attribute_findfirst(rel,&tmp);

		/* Whilst there are attributes... */
		while (att!=NULL) {

			/* Increment the counter */
			rel->noattributes++;

			/* Locate the next attribute */
			att=attribute_findnext(rel,att,&tmp,FALSE,TRUE);
		}
#ifdef FULL_DEBUG
	fprintf(stderr,"Read %d attributes\n",rel->noattributes);
#endif

		/* We've loaded the relation, so return the result */
		return(rel);
	}
}

void relations_open(database db) {
/* relations_open
 * Load all of the relations in the specified database
 */
	boolean masterdb;
	DIR *directory;
	char dirpath[FILE_PATH_SIZE];
	struct dirent *d;
	relation rel;

	masterdb=(strcmp(database_name(db),MASTER_DB_NAME));

	if (masterdb==0) {
		write(database_name(db));
		writeln(" - Master database");
	} else {
		write(database_name(db));
		writeln(" - User database");
	}

	writeln("---Retrieving Relations---");

	/* This whole section is going to get very OS Dependent
	 * The ultimate solution, is of course, to use the
 	 * data dictionary idea, so that we got to a file
	 * that SHOULD exist, and use THAT to get the names of
	 * other files. Then the whole process won't need
	 * to access a particular directory...
	 */

	sprintf(dirpath,"%s%s",database_dir(db),LEAP_RELATION_DIR);
#ifdef FULL_DEBUG
	printf("Directory to search: %s\n",dirpath);
#endif

#ifdef FULL_DEBUG
	printf("(Linux operations...)\n");
#endif
		directory=opendir(dirpath);
		d=readdir(directory);
		while (d!=NULL) {
#ifdef FULL_DEBUG
	fprintf(stderr,"%s\t",d->d_name);
	if (d->d_name[0]=='.') {
		fprintf(stderr,"(Directory)\n");
	}
#endif
			if (strstr(d->d_name,LEAP_RELATION_EXT)!=NULL) {
#ifdef FULL_DEBUG
	fprintf(stderr,"(Relation File)\n");
#endif


				if (masterdb==0) {
				/* TODO - Implement a check for relations that
				 * can be in the masterdb
				 */
				} else {
				}

				/* Read the relation from the disk */	
				rel=relation_read(dirpath,d->d_name);

				/* Insert the relation into the database */
				relation_insert(db,rel);
			}



			d=readdir(directory);
		}		
}

void delete_relation( relation rel) {
/* delete_relation
 * Delete the files associated with a given relation 
 */

	char bfilename[FILE_PATH_SIZE],filename[FILE_PATH_SIZE];
	int ret,count;

	/* Get the base directory to a relation */	
	relation_full_path(rel,bfilename);

	for (count=0;count<4;count++) {
		strcpy(filename,bfilename);

		/* Determine which file to delete */

		switch (count) {
			case 0:
				strcat(filename,LEAP_RELATION_EXT);
				break;
			case 1:
				strcat(filename,LEAP_FIELD_EXT);
				break;
			case 2:
				strcat(filename,LEAP_TEMPORARY_EXT);
				break;
			case 3:
				strcat(filename,LEAP_HASH_EXT);
				break;
			default:
				do_error(ERROR_UNKNOWN,"delete_relation: Something strange has happened",FATAL);
		}

		ret=remove(filename);	

		/* This section must be checked for return values on
		 * a failed remove. 
		 */

		if (ret!=0) {
#ifndef QFIX
			if ((errno)!=ENOENT) 
#endif
				/* TODO - Does this have to be fatal? - DONE. No. 12.05.1995*/
				do_error(ERROR_ERASE_FILE,filename,NONFATAL);
		}

	}
}


void relation_dispose( database db,
			relation *rel ) {
/* relation_dispose
 * Dispose of a relation
 */
	/* If the relation exists */
	if (*rel!=NULL) {

		/* If the relation is temporary */
		if (relation_temporary(*rel)) {

			/* If we're terminating, and this is the master database,
			 * or if its a user database... Delete the relation completely
			 * as its never needed - Temporary! 
			 */
			if ( ( (strcmp(database_name(db),MASTER_DB_NAME)==0) && (terminate==TRUE) )
			     || (strcmp(database_name(db),MASTER_DB_NAME)!=0) ) {

				delete_relation(*rel);
				/* TODO - Cache? */
			}
		}	

		/* Dispose of the relation's hash table */
		hashing_terminate((*rel)->hash_table);
	
		/* Dispose of the memory associated with the relation */
		free(*rel);
		rel=NULL;
	} else {
		/* The relation doesn't exist, so complain... Can't say
		 * what, as the relation doesn't exist! 
		 */
		do_error(ERROR_DELETE_NONEX_REL,"(relation_dispose)",NONFATAL);
	}
}
	
void relations_dispose_all( database db ) {
/* relations_dispose_all
 * Dispose of all relations in a relation structure 
 */

	relation crel,prel;
	char hashfile[FILE_PATH_SIZE];

	writeln("--- Updating Hash Tables ---");

	/* Locate the first relation */
	crel=relation_findfirst(db);

	/* Whilst the relation is valid */
	while (crel!=NULL) {

		write(relation_name(crel));
		write(" ");
		fflush(stdout);

		if (!relation_temporary(crel)) {
			relation_full_path(crel,hashfile);
			strcat(hashfile,LEAP_HASH_EXT);
			if (crel->updated==TRUE) {
				hashing_save(crel->hash_table,hashfile);
			}
		} else {
			write("(T) ");
		}

		/* Get the next relation */
		crel=relation_findnext(crel);
	}
	writeln("");

	writeln("--- Disposing relations ---");

	/* Locate the first relation */
	crel=relation_findfirst(db);

	/* Whilst the relation is assigned */
	while (crel!=NULL) {

		/* Make a copy */
		prel=crel;

		/* Get the next relation */
		crel=relation_findnext(crel);

		/* Dispose of the relation's memory */
		relation_dispose(db,&prel);
	}

	/* Set the header to NULL */
	db->first_relation=NULL;
}

void relation_remove( database db,
		      relation *rel ) {
/* relation_remove
 * Remove a relation from the relation structure 
 */

	if (*rel!=NULL) {
		do_error(ERROR_DELETE_NONEX_REL,"(relation_remove)",NONFATAL);
	} else {

		/* If the relation is the first relation */
		if (*rel==db->first_relation) {
			db->first_relation=(*rel)->next;
		} else {

			/* The relation is in the body somewhere */

			/* Point the relation before and after to each other 
			 * (After checking that we're not going to hit NULL's
			 */
			if ( (*rel)->previous!=NULL )
				(*rel)->previous->next=(*rel)->next;

			if ( (*rel)->next!=NULL )
				(*rel)->next->previous=(*rel)->previous;

			/* Remove the hashing table from memory */
			if ( (*rel)->hash_table != NULL )
				hashing_terminate((*rel)->hash_table);

			/* TODO - Cache? */

			if ( relation_temporary(*rel) )
				delete_relation(*rel);

			/* Dispose of the memory used */
			free(*rel);
			*rel=NULL;
		}
	}
}
