/* 
 * Name: dtypes.h
 * Description: Main LEAP data types and structure defs.
 * Version: $Id: dtypes.h,v 1.19 1996/09/08 22:39:14 rleyton Exp rleyton $
 *
 *   LEAP - An extensible and free RDBMS
 *   Copyright (C) 1996 Richard Leyton
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   See the file COPYING for more information.
 *
 *   Richard Leyton, c/o 3.Pelting Drove, Priddy, WELLS, 
 *   Somerset, BA5 3BA. E-Mail: richard_leyton@mail.amsinc.com
 *   and/or e0190404@brookes.ac.uk. http://www.brookes.ac.uk/~e0190404/leap.html
 *
 */

/* To prevent multiple definitions */
#ifndef LEAP_DTYPES
#define LEAP_DTYPES

/* Some important strings... */
#define LEAP_CORE_VERSION "0.11.1"
#define LEAP_VERSION "0.7.1"
#define LEAP_VERSION_TEXT "An extensible and free RDBMS"
#define LEAP_COPYRIGHT "Copyright (C) 1996 Richard Leyton."
#define LEAP_DISTRIBUTION_1 "LEAP comes with ABSOLUTELY NO WARRANTY; for details type \"warranty\"."
#define LEAP_DISTRIBUTION_2 "This is free software, and you are welcome to redistribute it"
#define LEAP_DISTRIBUTION_3 "under certain conditions; type \"copying\" for details."
 
/* This is the default directory - TO-DO: Make it independent of me! DONE - 0.7.1 - 5th September 1996 */
#define LEAP_DEFAULT_DIR "./"
#define LEAP_ERROR_DIR "errors/"
#define LEAP_ERROR_FILE "error.list"
#define LEAP_RELATION_DIR "relation/"
#define LEAP_RELATION_EXT ".rel"
#define LEAP_FIELD_EXT ".fld"
#define LEAP_TEMPORARY_EXT ".tmp"
#define LEAP_HASH_EXT ".hsh"
#define LEAP_SOURCE_EXT ".src"
#define LEAP_DATABASE_DIR "database/"
#define LEAP_SOURCE_DIR "source/"
#define LEAP_TEMPORARY_TXT "LEAP Temporary indicator file - Do not delete!"
#define LEAP_REPORT_DIR "report/"
#define LEAP_REPORT_FILE "report.txt"

/* Data dictionary definitions */

/* Database relation */
#define LEAP_DD_DATABASE "leapdata"

/* Define some symbols */
#define ASSIGNMENT "="

/* The master database */
#define MASTER_DB_NAME "master"

/* The default database */
#define DEFAULT_DB "user"


/* Some machine/OS dependant definitions */
#define DIR_SEPERATOR '/'
#define DIR_SEPERATOR_STRING "/"  /* MUST be the same as DIR_SEPERATOR */
				   /* But as a string, not a char       */


/* This is messy, as there are other defines. But for
 * now, it'll have to stay
 */
#define LINUX

/* Various maximums and sizes. Many of these 
 * are left as they were in the Pascal/DOS version
 * and can be changed in due course. There is nothing
 * to say they can't be higher, now we're free of
 * Bill..
 */

#define RELATION_NAME_SIZE 8
#define FILE_PATH_SIZE 127
#define FILENAME_EXT_SIZE 4
#define FILE_NAME_SIZE 8

/* Maximum size of an attribute name */
#define ATTRIBUTE_NAME_SIZE 25

/* Maximum size of a string describing the TYPE of relation
 * (String, number, etc) 
 */
#define ATTRIBUTE_TYPE_SIZE 15

/* Buffer size for reading the attributes from disk 
 * Should be no smaller than ATTRIBUTE_NAME_SIZE or TYPE_SIZE
 * (Whichever is bigger)
 */
#define ATTRIBUTE_BUFFER_SIZE 25

/* Maximum size for the attribute data - This is 255 for
 * compatibility with Pascal version, but can be set higher
 * when implementation has reached a safe level
 */
#define ATTRIBUTE_MAXIMUM_SIZE 255

/* Maximum number of attributes allowed. This is again small
 * for compatibility reasons. It should be set higher at a later
 * date, but memory might become an issue, depending on the
 * size of ATTRIBUTE_MAXIMUM_SIZE
 */
#define MAXIMUM_ATTRIBUTES 20

/* Maximum size needed to store the complete list of attributes
 * in a string, with a space seperating each attribute
 */
#define MAXIMUM_MAXIMUM_ATTRIBUTE (ATTRIBUTE_NAME_SIZE+1)*MAXIMUM_ATTRIBUTES

/* For hashing - The maximum size of all the data in a tuple */
#define MAXIMUM_ALL_DATA (ATTRIBUTE_MAXIMUM_SIZE * MAXIMUM_ATTRIBUTES)

#define DATABASE_NAME_SIZE 8

/* The maximum size allowable for an input string. Again, this
 * is set small in order to maintain compatibility with the 
 * pascal version, but can (and should) be set higher TODO
 */
#define MAXIMUM_INPUT_STRING 255

/* A better name for this is an "expression". But this implies
 * nesting... :)
 */
#define MAXIMUM_EXPRESSION MAXIMUM_INPUT_STRING

/* Define the maximum number of brackets allowed... */
#define MAXIMUM_BRACKETS 255

/* Define the maximum number of conditions in a condition */
#define MAXIMUM_CONDITIONS 20

/* Define the size of a condition */
/* This will never be higher than MAXIMUM_EXPRESSION */
#define MAXIMUM_CONDITION_SIZE MAXIMUM_EXPRESSION 

/* Define boolean flags */
#define BOOLEAN_UNDETERMINED 0
#define BOOLEAN_END_MARKER 99
#define BOOLEAN_AND 1
#define BOOLEAN_OR 2
#define BOOLEAN_XOR 3 /* TODO */
#define BOOLEAN_LESS_THAN 4
#define BOOLEAN_GREATER_THAN 5
#define BOOLEAN_EQUAL 6
#define BOOLEAN_LESS_EQUAL_THAN 7
#define BOOLEAN_GREATER_EQUAL_THAN 8
#define BOOLEAN_NOT_EQUAL 9

#define BOOLEAN_AND_STRING "and"
#define BOOLEAN_OR_STRING "or"
#define BOOLEAN_XOR_STRING "xor"

/* For comparison if specified */
#define TRUE_STRING "TRUE"
#define FALSE_STRING "FALSE"

/* Define some useful data types */
typedef unsigned int word;
typedef unsigned char boolean; /* Maybe this could be a bit or
				* something smaller...? 
				*/

/* Define some useful items for boolean type */
#define TRUE 1
#define FALSE 0

/* Couple of occasionally useful defs 
 * for match_tuples etc.
 */
#define DIR_UNKNOWN 0
#define DIR_LEFT 1
#define DIR_RIGHT 2

/* The various data types supported by LEAP */
#define DT_UNDEFINED 0
#define DTS_UNDEFINED "UNDEFINED"

#define DT_STRING 1
#define DTS_STRING "STRING"

#define DT_NUMBER 2
#define DTS_NUMBER "INTEGER"

#define DT_BOOLEAN 3
#define DTS_BOOLEAN "BOOLEAN"

#define DTS_UNSUPPORTED "UNSUPPORTED"

/* Define error fatality
 */
#define FATAL 1
#define NONFATAL 2

/* Delimiter character for tuple storage. Note that
 * there are two because otherwise its an escaped quote...
 * (Added the \n to make sure the end of line is a delimiter too!)
 */
#define DATA_DELIMITER "\\\n"

#define DELIMETER_CHAR '\\'

/* Define an indicator for an empty string in a record on disk */
#define NULL_INDICATOR '-'

/* An escaped delimeter - This is used to search for an escaped
 * delimeter - speeds up the whole process by working out if
 * anything special needs to be done
 */
#define ESCAPED_DELIMITER "\\\\"

/* The default prompt for LEAP */
#define PROMPT ">"

/* Define the seperators for a string (Used in seperating
 * a list of attributes 
 */
#define SEPERATORS " ,"

/* Define the seperators that seperate tokens, for get_token
 * and cut_token - Same as pascal, with NULL to end the string
 * \\ is escaped \
 */
#define TOKEN_SEPERATORS ", /\\:()\0"

/* Define the value for the character that defines if a 
 * condition contains a value rather than a field.
 */
#define VALUE '\"'

/* Define all possible values that could be used
 */
#define VALUES "\"\'`"

/* Define the component boolean operators */
#define L_OPERATORS "=<>!"

#define L_EQUAL '='
#define L_LESSTHAN '<'
#define L_GREATERTHAN '>'
#define L_PLING '!'	/* I call it "pling" */
#define L_BANG L_PLING	/* Some call it "bang" */
#define L_EXCLAMATION L_PLING /* Sane people call it an exclamation
			       * mark... Take your pick!
			       */	

/* Define the operators as strings */
#define L_BOOLEAN_EQUAL "="
#define L_BOOLEAN_LESSTHAN "<"
#define L_BOOLEAN_LESSTHAN_EQUAL "<="
#define L_BOOLEAN_GREATERTHAN ">"
#define L_BOOLEAN_GREATERTHAN_EQUAL ">="
#define L_BOOLEAN_NOTEQUAL "<>"

#define BOOLEAN_STRING_SIZE 2 /* Size to store a boolean op. as string(+1 for null) */

/* Define the maximum number of seperators that may exist, this
 * is used in get_token and cut_token to save time and stuff. 
 * Its never going to be bigger than TOKEN_SEPERATORS.
 */
#define MAX_SEPERATORS 15

#define ATTRIBUTE_SEPERATOR ','

/**************************************************
 * Cache structure definitions
 **************************************************/

typedef struct cache_struct {
	unsigned char pos;
	/* Blah Blah - This is TODO */
} cache_struct;

typedef cache_struct *cache;

/**************************************************
 * Hash Table structure definitions
 **************************************************/

#define TABLESIZE 53		/* This should be a prime */
#define TABLETOP TABLESIZE-1
#define REQ_CALC TABLESIZE+1	/* Value to request hash key
				 * is calculated, and NOT provided 
				 */

/* Maximum size of a hash key - all attributes contain data... */
#define HASH_KEY_SIZE MAXIMUM_ALL_DATA

/* Hash key */
/* typedef char hash_keytype[HASH_KEY_SIZE];*/

/* An entry in the structure */
typedef struct chain_struct{
		/* TODO - Set this to a ptr, and allocate the memory
		 * as necessary - writing will be difficult 
		 */
		char element[HASH_KEY_SIZE];
		struct chain_struct	*next;
} chain_struct;

typedef chain_struct *chain;

typedef chain TableType[TABLESIZE];

typedef TableType *HashTable; 

typedef struct node_str{
		char hash_key;
		char item[HASH_KEY_SIZE];
		unsigned int pos;
}node_str;

/**************************************************
 * Attribute structure definitions
 **************************************************/
typedef struct attribute_struct {
		/* The name of the attribute */
		char name[ATTRIBUTE_NAME_SIZE+1];

		/* Whether the attribute is part of primary key.
		 */
		boolean primary;

		/* Number of records held in attribute - is this
		 * really necessary, or just a hang-on from some
 		 * old system 
		 */
		word norecs;

		/* The type of data held in this attribute */
		/* See DTYPE_* defs */
		char data_type;

		/* The size of the attribute - Does this have
		 * a use? 
		 */
		word attribute_size;

		/* The navigational structures for the attribute
 		 * - next and previous attributes 
		 */
		struct attribute_struct *next,*previous;	
} attribute_struct;

/* The main attribute data type - ptr to a structure
 */
typedef attribute_struct *attribute;

/**************************************************
 * Relation structure definitions
 **************************************************/
typedef struct relation_struct {
	/* Add one for the terminating null! */
	char name[RELATION_NAME_SIZE+1];
	char filepath[FILE_PATH_SIZE+1];
	char filename[FILE_NAME_SIZE+FILENAME_EXT_SIZE+1];
	char fieldname[FILE_NAME_SIZE+FILENAME_EXT_SIZE+1];
	
	/* File structures not included here. This is a
	 * major divurgence from the Pascal version. This is
	 * because it seems inefficent to open file descriptors
	 * on every relation. So on an as needed basis from now
	 * on.
   	 */

	/* Navigational structures combined for simplicity */
	struct relation_struct *next,*previous;

	word noattributes;
	word current_pos;

	cache rcache;	/* Cache for the relation */
	boolean temporary;

	HashTable hash_table;

	boolean updated;
} relation_struct;

typedef relation_struct *relation;

/*
 * This is the main database structure - a pointer 
 * to this will allow access to any database object
 * (eventually after navigation!)
 */
/**************************************************
 * Database structure definitions
 **************************************************/
typedef struct database_struct {
	char name[DATABASE_NAME_SIZE];

	relation_struct *first_relation;
	relation_struct *last_relation;

	char basedir[FILE_PATH_SIZE+1];
} database_struct;

typedef database_struct *database;



/**************************************************
 * Tuple structure definitions
 **************************************************/

/* The main meat behind our tuple - Each tuple entry contains
 * a ptr to the relation, a ptr to the attribute definition, and
 * a character array with the data.
 */
typedef struct tuple_item_structure {
	/* This is a ptr to the relation to which the tuple relates */
	relation rel;

	/* This is a ptr to the attribute definition to which the
	 * tuple relates
	 */
	attribute att;

	/* This is the actual data! */
	char	data[ATTRIBUTE_MAXIMUM_SIZE];
} tuple_item_structure;

/* This is a pointer to the structure above. */
typedef tuple_item_structure *tuple_item_structure_ptr;

/* This is an array of pointers to the structure above. */
typedef tuple_item_structure_ptr tuple_array[MAXIMUM_ATTRIBUTES];

/* This is a pointer to the array of pointers to the structure! */
typedef tuple_array *tuple;

/* Define some macros to make accessing tuples easier - Otherwise
 * the statements get very confusing...
 */
#define tuple_item(var,pos) (*var)[pos]
#define tuple_relation(var,pos) ((*var)[pos])->rel
#define tuple_attribute(var,pos) ((*var)[pos])->att
#define tuple_d(var,pos) ((*var)[pos])->data
#define tuple_data(var,pos,string) strcpy(((*var)[pos])->data,string)

/* Defines for the rebuilding of a tuple structure. We might not
 * always want to rebuild a tuple (expensive)
 */
#define TUPLE_REUSE TRUE
#define TUPLE_BUILD FALSE

/**************************************************
 * Parse Tree node structure definitions
 **************************************************/

typedef struct parse_tree_def {
		char expression[MAXIMUM_EXPRESSION];
		char full_expression[MAXIMUM_EXPRESSION];
		
		struct parse_tree_def *left, *right, *parent;

		boolean ldone, rdone;

		relation lresult, rresult, result;
	
		char hand;

		/* Old parse structure - < 04.05.1996 */
/*
 *		char s1[MAXIMUM_EXPRESSION], s2[MAXIMUM_EXPRESSION];
 *		char s3[MAXIMUM_EXPRESSION], s4[MAXIMUM_EXPRESSION];
 *		char s5[MAXIMUM_EXPRESSION]; 
 */
		/* New parse structure - 04.05.1996 */
		char command[MAXIMUM_EXPRESSION],target[MAXIMUM_EXPRESSION];
		char first[MAXIMUM_EXPRESSION], second[MAXIMUM_EXPRESSION];
		char third[MAXIMUM_EXPRESSION], work[MAXIMUM_EXPRESSION];

		/* Newer parse structure - 12.08.1996 */
		char *expressions[255];
		
		char operation;
} parse_tree_def;

typedef parse_tree_def *parse_tree;

typedef struct pt_stack_node_struct {
	parse_tree data;
	struct pt_stack_node_struct *next;
} pt_stack_node_struct;

typedef struct pt_stack_struct {
	struct pt_stack_node_struct *head_node;
	unsigned int no_items;
} pt_stack_struct;

typedef struct pt_stack_node_struct *pt_stack_node;
typedef struct pt_stack_struct *pt_stack;

/**************************************************
 * Condition list structure definitions
 **************************************************/

/* TODO: Union with a reference to another condition list, in
 * order to support nested conditions.
 * TODO: Get rid of boolean flags, can check NULL on left_attr?
 */

#define ALWAYS_FALSE 0
#define ALWAYS_TRUE 1
#define ALWAYS_UNKNOWN -1


typedef struct ncond_struct {
	char	left[ATTRIBUTE_MAXIMUM_SIZE]; /* TODO: Check size of this */
	boolean	left_field; 				  /* TRUE if left is a field or FALSE if value */
	char *left_attribute_val;
	attribute left_attribute;
	short int left_always;		/* If condition is always TRUE or FALSE */

	char	bool[BOOLEAN_STRING_SIZE]; 	  /* String ver of field */
	int	boolval; 						  /* set to BOOLEAN_whatever */

	char	right[ATTRIBUTE_MAXIMUM_SIZE];
	boolean right_field; 				  /* TRUE If right is a field, FALSE if value */
	char *right_attribute_val;
	attribute right_attribute;
	short int right_always; 	/* If condition is always TRUE or FALSE */
	
	int     boolean_condition; 			  /* AND, OR, XOR, and so on... */
	struct ncond_struct *next_condition;  /* Points to the next condition */

	boolean eval_result;
} ncond_struct;

typedef struct ncond_struct *condp;




/* Hand definitions */
#define NODE_ROOT 0
#define NODE_LEFT 1
#define NODE_RIGHT 2

/* 
 * Internal Error numbers  (Some may be obsolete - TODO (Last)
 */
#define ERROR_FILE_NOT_FOUND 1
#define ERROR_FILE_OPENING 2
#define ERROR_UNKNOWN 3
#define ERROR_INSUFFICENT_MEMORY 4
#define ERROR_CANTFIND_ATTR 5
#define ERROR_EOF 6
#define ERROR_DISPOSE_UNALLOCMEM 7
#define ERROR_DUPLICATE_ITEM 8
#define ERROR_UNION_COMPATIBILITY 9
#define ERROR_ERASE_FILE 10
#define ERROR_CANNOT_PROCESS 11
#define ERROR_DISPLAY_NONEX_REL 12
#define ERROR_ATTEMPT_RELOAD 13
#define ERROR_CANNOT_FIND_REL 14
#define ERROR_DELETE_NONEX_REL 15
#define ERROR_EXCEEDED_ATTRIBUTE_LIMIT 16
#define ERROR_MISMATCHING_BRACKETS 17
#define ERROR_UNKNOWN_HELPPAGE 18
#define ERROR_NO_RELATION_CREATED 19
#define ERROR_INCORRECT_OPTION 20
#define ERROR_INTERNAL_STACK 21
#define ERROR_RECURSION_DEPTH 22
#define ERROR_UNEXPECTED_TERMINATION 23
#define ERROR_EVALUATING_EXPR 24
#define ERROR_EXPECTED_FILE_NOT_FOUND 25
#define ERROR_WILDCARD_IN_NAME 26
#define ERROR_NONAME 27
#define ERROR_INSUFFICENT_ATTRIBUTES 28
#define ERROR_UNKNOWN_DATABASE 29
#define ERROR_ALREADY_OPEN 30
#define ERROR_PANIC 31
#define ERROR_MASTER_ONLY 32
#define ERROR_CANNOT_CREATE_DB 33
#define ERROR_TYPE_INCOMPATIBLE 34
#define ERROR_TYPE_CONVERSION 35
#define ERROR_NO_TYPE 36
#define ERROR_CONNOT_CHDIR 37
#define ERROR_UNIMPLEMENTED 38
#define ERROR_COMMAND_LINE 39
#define ERROR_CLOSING_FILE 40
#define ERROR_UNSUPPORTED_DTYPE 41
#define ERROR_OS_FEATURE 42
#define ERROR_UNKNOWN_COMMAND 43
#define ERROR_TIME 44
#define ERROR_DURING_READ 45
#define ERROR_OBSOLETE 46
#define ERROR_HASH_FILE_CORRUPT 47
#define ERROR_PARSE_UNRECOGNISED_TOKEN 48
#define ERROR_PARSE_EXECUTION 49
#define ERROR_UNEXPECTED_CONDITION_CHAR 50
#define ERROR_UNSUPPORTED_BOOLEAN_OPERATOR 51
#define ERROR_NO_CLOSING_QUOTE 52
#define ERROR_NO_CONDITION 53
#define ERROR_DATA_DICTIONARY 54
#define ERROR_UNDEFINED 999

/* COMMAND LINE PARAMETERS */
/* The command line options must be defined */


/* Important global variables... */

/* The base directory for LEAP - Set as a parameter on
   calling the main program. */
char LEAP_BASE_DIR[FILE_PATH_SIZE+1];

/* This is just a holdall for impromptu sprintf calls. */
char temp_80_chars[80];

/* The master database  */
extern database master_db;

extern database user_db; 

#define C_UNKNOWN -1
#define C_HELP 1
#define C_LOAD 2
#define C_LIST 3
#define C_DISPLAY_REL 4
#define C_PRINT 5
#define C_DISPLAY 6
#define C_DELETE 7
#define C_DISPLAY_INDEX 8
#define C_PROJECT 9
#define C_DISPOSE 10
#define C_SRCFILE 11
#define C_DOS 12
#define C_UNION 13
#define C_JOIN 14
#define C_MEM 15
#define C_CHANGE 16
#define C_IDX 17
#define C_PRINT_IDX 18
#define C_IDX_STORE 19
#define C_INTERSECT 20
#define C_DIFFERENCE 21
#define C_PRODUCT 22
#define C_SELECT 23
#define C_DESCRIBE 24
#define C_NORMAL 25
#define C_HIGH 26
#define C_SMJOIN 27
#define C_FLUSH 28
#define C_CREATE 29
#define C_ADD 30
#define C_CLEAR 31
#define C_RMVTMP 32
#define C_PROMPT 33
#define C_INFO 34
#define C_STATUS 35
#define C_DEBUG 36
#define C_INFIX 37
#define C_VERSION 38
#define C_COMMENT 40
#define C_REPORT 41
#define C_TIMING 42
#define C_US 43
#define C_WHAT 44
#define C_USE 45
#define C_DIR 46
#define C_IOON 47
#define C_RENAME 48
#define C_PANIC 49
#define C_BREAK 50
#define C_CASE 51
#define C_DUPLICATE 52
#define C_CACHE 53
#define C_ITERATIVE 54
#define C_PARSE 55
#define C_EXIT 56
#define C_RELATION 57
#define C_WARRANTY 58
#define C_ADDRESSES 59
#define C_LISTSRC 60

extern struct commands_struct {
	char *text;
	int command;
} commands[] ;

/* Define the current and master database 
 * These will be defined in the main program 
 */
extern database current_db,master_db;

/* Define the termination flag - When this is
 * TRUE, termination has been requested.
 */
extern boolean terminate;

/* The input stream. This is normally assigned to
 * standard input, but then the user might want to 
 * source a file 
 */
extern FILE *input_stream;

/* Character for beeps - Either BELL or SPACE */
extern char BEEP;

#define L_DUPLICATE "duplicate"
#define L_JOIN "join"
#define L_EXIT "exit"


/* Generic function return codes */
#define RETURN_ERROR 0
#define RETURN_SUCCESS 1


/* Define special conditions */
extern char special_condition_true[];
extern char special_condition_false[];

#endif
/* End of ifndef */
