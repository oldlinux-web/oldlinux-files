/* 
 * Name: dbase.c
 * Description: Main database structure access/modification functions.
 * Version: $Id: dbase.c,v 1.7 1996/09/05 22:39:42 rleyton Exp $
 *
 *   LEAP - An extensible and free RDBMS
 *   Copyright (C) 1996 Richard Leyton
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   See the file COPYING for more information.
 *
 *   Richard Leyton, c/o 3.Pelting Drove, Priddy, WELLS, 
 *   Somerset, BA5 3BA. E-Mail: richard_leyton@mail.amsinc.com
 *   and/or e0190404@brookes.ac.uk. http://www.brookes.ac.uk/~e0190404/leap.html
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "dbase.h"
#include "dtypes.h"
#include "util.h"

database database_create(char name[DATABASE_NAME_SIZE]) {
/* database_create - This creates the master database structure,
 *	from which all other objects should be (indirectly)
 * 	linked.
 */
	database db;

	db=(database_struct *) malloc(sizeof(database_struct));
	check_assign(db,"dbase.database_create");

	strcpy(db->name,name);
	db->first_relation=NULL;
	db->last_relation=NULL;

	/* Populate the base directory - Not the right way
	   here - as the dd will be used to populate it... */
	sprintf(db->basedir,"%s%s%s%c",LEAP_BASE_DIR,LEAP_DATABASE_DIR,name,'/');

	return db;
}

void database_destroy(database *db) {
/* databse_destroy
 * This releases the memory of the database, and deallocates
 * the pointer - Should only be called at the end of the
 * database 'life' !
 */
	/* Dispose of the memory */
	free(*db);

	/* Deallocate ptr */
	(*db)=NULL;
}

void database_new(char *name,char *info) {
/* database_new
 * This creates a *NEW* database, and will build the structure
 * on the file system appropriately. It does NOT create a new
 * internal structure!
 */
	char	str[100];

	sprintf(str,"Creating Database %s...",name);
	writeln(str);

	/* TODO - Create the info file */
	fprintf(stderr,"Info: %s\n",info);	
}

char *database_name(database db) {
/* database_name
 * Returns ptr to the database name string
 */

	return(db->name);
}

char *database_dir(database db) {
/* database_dir
 * Returns ptr to string containing the database directory
 */
	
	return(db->basedir);
}

