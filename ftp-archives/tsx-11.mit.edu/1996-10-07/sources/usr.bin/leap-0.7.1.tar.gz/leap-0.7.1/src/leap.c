/* 
 * Name: $RCSfile: leap.c,v $
 * Description: Main LEAP loop and functions.
 * Version: $Id: leap.c,v 1.19 1996/09/08 22:39:14 rleyton Exp rleyton $
 *
 *   LEAP - An extensible and free RDBMS
 *   Copyright (C) 1996 Richard Leyton
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   See the file COPYING for more information.
 *
 *   Richard Leyton, c/o 3.Pelting Drove, Priddy, WELLS, 
 *   Somerset, BA5 3BA. E-Mail: richard_leyton@mail.amsinc.com
 *   and/or e0190404@brookes.ac.uk. http://www.brookes.ac.uk/~e0190404/leap.html
 *
 */

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "dtypes.h"
#include "dbase.h"
#include "util.h"
#include "parser.h"
#include "info.h"
#include "relation.h"

/* Actual database's (defined as extern in dtypes.h) */
database master_db, current_db;

/* TRUE When LEAP is on the way down... */
boolean terminate;

/* This is normally stdin, but the user might want to source a file */
FILE *input_stream;

char BEEP=7;

void do_leap() {
/* do_leap
 * Main LEAP routine - Contains user interface etc, and calls
 * things.
 */
	char buffer[MAXIMUM_INPUT_STRING],original[MAXIMUM_INPUT_STRING];
	char *result;
	relation result_relation;

	/* Open the master database */
	master_db=database_create(MASTER_DB_NAME);

	relations_open(master_db);

	/* Open up the default user database */
	current_db=database_create(DEFAULT_DB);

	relations_open(current_db);
#ifdef DEBUG
	printf("STARTING TEST AREA....\n");
	/* crel=rl_project(current_db,relation_find(current_db,"p"),"PNAME","rdest");*/
	/* relation_tuples_display(crel); */
	printf("END OF TEST AREA....\n");
#endif	
	writeln("Startup sequence initiated.");

	terminate=FALSE;

	/* Assign the input stream to stdin by calling function with empty string */
	assign_input_stream("");

	/* The MAIN program loop */
	while (!terminate) {

		/* Display the prompt */
		fprintf(stdout,"%s ",PROMPT);

		/* Flush the buffer (no CR printed, so nothing there,
		 * but we do want the prompt...)
		 */
		fflush(stdout);

		/* Make sure that we get something, rather than just
		 * a CR on its own */
		result=fgets(buffer,sizeof(buffer),input_stream);

		/* Reset the result relation ptr */	
		result_relation=NULL;
	
		if (result==NULL) {
			if (input_stream!=stdin) {
				/* EOF or such like was reached. */
				assign_input_stream("");
			} else {
				/* EOF from stdin was read, so terminate nicely */
				do_trace("EOF from stdin");	
	
				/* Do it normally, no short cuts setting terminate - this 
			 	* ensures that all the normal procedures are followed 
			 	*/
				strcpy(buffer,L_EXIT);	

				result_relation=process_query(current_db,buffer);
			}
		} else {
			if ( input_stream!=stdin ) {
				fprintf(stderr,"%s",buffer);
			}

			/* Make a copy of the string, just in case...
	 	 	* TODO - Remove this?
		 	*/
			strcpy(original,buffer);

			/* Strip out the carriage return */
			/* We might want to stretch over multiple lines
		 	* at some point though - in which case we'll
		 	* need a "end of command" statement, like "go"
		 	* in Sybase, or ; in Oracle. TODO
		 	*/
	
			/* Remove the cr at the end */
			original[(strlen(original))-1]='\0';
	
			result_relation=process_query(current_db,original);
		}

		/* If a relation has been returned */
		if (result_relation!=NULL) {
			/* We can use buffer as the string has been processed, and
			 * as a relation has been returned, we're not quitting or
			 * anything like that. 
			 */

			/* Produce a report string */
			sprintf(buffer,"Relation %s returned.",relation_name(result_relation));

			/* Print it out in the report file */
			report(buffer);

			/* And on the screen */
			printf("%s\n",buffer);
			fflush(stdout);
		}

	}

	fprintf(stdout,"Closing databases...\n");

	relations_dispose_all(current_db);

	database_destroy(&current_db);

	relations_dispose_all(master_db);
	
	database_destroy(&master_db);
}

int main(int argc, char *argv[]) {
/* main
 * The main LEAP program - This performs the display of the
 * title, and processes the command line. Clean termination
 * also should occur here. Everywhere else termination is
 * "unclean", and should return an error status. Define
 * error status' in the dtypes.h file
 */
#ifdef FULL_DEBUG
	/* Test vars */
	char source[50],result[50],*sptr;
#endif
	
	/* First things first, report what we are. */
	print_header();
	
	/* Do the initial configuration that is necessary */
	strcpy(LEAP_BASE_DIR,LEAP_DEFAULT_DIR);
	sprintf(ERROR_FILE,"%s%s%s",LEAP_DEFAULT_DIR,LEAP_ERROR_DIR,LEAP_ERROR_FILE);
#ifdef FULL_DEBUG
	printf("(%d)<%s>\n",strlen(ERROR_FILE),ERROR_FILE);
#endif

	/* Perform some configuration... */
	
	/* Set the random seed to the time in secs since 01.01.1970
	 * should be random enough!
	 */
	/* srand(time(NULL)); */

	/* Process the command line
		Stop if we run out of arguments
		or we get an argument without a dash */
	/* NB. This is based on O'Reilly & Associates "Practical
	  C Programming", by Steve Oualline, 2nd Ed. (pg 178) */

	while ((argc > 1) && (argv[1][0] == '-')) {
		/* 
		 * argv[1][1] is the actual option character
		 */
		switch (argv[1][1]) {
		case 'd':
		case 'D':
			/* The user wants debug information */
			writeln("Debug messages enabled");
			LDEBUG=TRUE;
			break;
		case 'i':
		case 'I':
			/* The user wants timing information */
			writeln("Timing information enabled");
			LTIMING=TRUE;
			break;
		case 'n':
		case 'N':
			/* Display warranty information */
			do_warranty();
			exit(0);
			break;
		case 'q':
		case 'Q':
			writeln("Quiet mode on");
			BEEP=' ';
			break;
		case 's':
		case 'S':
			/* The user wants status messages to be
			   displayed */
			writeln("Status messages enabled");
			status=TRUE;
			break;
		case 't':
		case 'T':
			/* The user wants tracing information */
			writeln("Tracing information enabled");
			LTRACE=TRUE;
			break;
		case 'h':
		case 'H':
			/* The user wants some help... */
			print_help();

			/* Exit without an error */
			exit(0);

			break;
		default:
			(void)do_error(ERROR_COMMAND_LINE,argv[1],NONFATAL);
		}

		/* Move the argument list up one and the count down one */
		argv++;
		argc--;
	}

	/* We have processed all of the options. The last remaining
	 * option is the path to LEAP (used to be DIR= in Pascal ver)
	 * so we can take this, or if none exists, then we can use
	 * the default.
 	 */

	if (argc>1) {
		strcpy(LEAP_BASE_DIR,argv[1]);

		/* Check that the directory specified contains a seperator
		 * at the end, because we mindlessly append directories to
		 * this, and that causes icky problems...
		 */
		if (LEAP_BASE_DIR[strlen(LEAP_BASE_DIR)-1]!=DIR_SEPERATOR) {
			strcat(LEAP_BASE_DIR,DIR_SEPERATOR_STRING);
		}

		sprintf(ERROR_FILE,"%s%s%s",LEAP_BASE_DIR,LEAP_ERROR_DIR,LEAP_ERROR_FILE);
	}

	if (status) {
		sprintf(temp_80_chars,"LEAP Base directory set to: %s",LEAP_BASE_DIR);
		writeln(temp_80_chars);
	}

	/* Call any initialisation routines... */
	util_init();

	/* Display some information */
	writeln("LEAP 0.11 offers:");
	writeln("");
	writeln("+ UNIX Support (Linux, Solaris, SunOS, NeXt)");
	writeln("+ Efficent, extensible parser");
 	writeln("+ Full source code (under GNU General Public License, type \"copying\" for info)");
	writeln("+ More supported datatypes (Boolean)");
	writeln("");

/* Do initial testing here */
#ifdef FULL_DEBUG
	printf("This string returned: >%s<\n",generate_random_string(5,NULL));

	strcpy(source,"This is a test");
	sptr=cut_token(source,'\0',result);
	printf("cut_token returned: >%s<\nAnd left: >%s<\n",sptr,source);
#endif

#ifdef DEBUG
	LDEBUG=TRUE;
	fprintf(stderr,"DEBUG: LEAP debug mode forced on\n");
#endif

	/* Do the main leap operation */
	(void) do_leap();

	/* Close the various files opened earlier */
	util_close();

	/* Inform the user of a clean termination */
	writeln("LEAP Terminated successfully!");

	/* Return success. Elsewhere, non-zero should be returned */
	return(0);
}
