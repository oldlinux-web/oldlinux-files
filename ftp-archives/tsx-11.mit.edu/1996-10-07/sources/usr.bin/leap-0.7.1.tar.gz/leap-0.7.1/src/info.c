/* 
 * Name: info.c
 * Description: Information routines.
 * Version: $Id: info.c,v 1.5 1996/09/05 22:39:42 rleyton Exp $
 *
 *   LEAP - An extensible and free RDBMS
 *   Copyright (C) 1996 Richard Leyton
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   See the file COPYING for more information.
 *
 *   Richard Leyton, c/o 3.Pelting Drove, Priddy, WELLS, 
 *   Somerset, BA5 3BA. E-Mail: richard_leyton@mail.amsinc.com
 *   and/or e0190404@brookes.ac.uk. http://www.brookes.ac.uk/~e0190404/leap.html
 *
 */

#include <stdio.h>
#include "info.h"
#include "dtypes.h"
#include "util.h"

void print_header() {
/* print_version
 * Prints the LEAP version header
 */
	/* First things first, report what we are. */
	printf("\nLEAP %s (%s) - %s\n%s\n\n%s\n%s\n%s\n\n",
		LEAP_CORE_VERSION,LEAP_VERSION,LEAP_VERSION_TEXT,
		LEAP_COPYRIGHT,LEAP_DISTRIBUTION_1,LEAP_DISTRIBUTION_2,LEAP_DISTRIBUTION_3);

#ifdef FULL_DEBUG
	fprintf(stderr,"FULL-DEBUG (VERY NOISY)\n\n");
	#define DEBUG
#endif
#ifdef DEBUG
	fprintf(stderr,"DEBUG VERSION!\n");
#endif

}

void do_addresses() {
/* do_addresses
 * displays contact information etc.
 */
    writeln("Addresses for comments/feedback etc.");
    writeln("");
    writeln("Author: Richard Leyton");
    writeln(" E-Mail: richard_leyton@mail.amsinc.com  and/or e0190404@brookes.ac.uk");
    writeln(" Snail: c/o 3.Pelting Drove, Priddy, WELLS, Somerset, BA5 3BA, UK");
    writeln("");
    writeln("Free Software Foundation");
    writeln(" Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.");
    writeln("");
    writeln("For a full list see the LEAP home page:");
    writeln(" http://www.brookes.ac.uk/~e0190404/leap.html");
    writeln("");
}

void print_info() {
/* print_info
 * displays the warranty and conditions blurb
 */
    writeln("This program is free software; you can redistribute it and/or modify");
    writeln("it under the terms of the GNU General Public License as published by");
    writeln("the Free Software Foundation; either version 2 of the License, or");
    writeln("(at your option) any later version.");
    writeln("");
    writeln("This program is distributed in the hope that it will be useful,");
    writeln("but WITHOUT ANY WARRANTY; without even the implied warranty of");
    writeln("MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the");
    writeln("GNU General Public License for more details.");
    writeln("");
    writeln("You should have received a copy of the GNU General Public License");
    writeln("along with this program; if not, write to the Free Software");
    writeln("Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.");
    writeln("");
    writeln("See the file COPYING for full details, or write to the address above.");
    writeln("Type \"addresses\" for a list of addresses");
    writeln("");
}

void print_help() {
/* print_help
 * Print command line help and so on
 */
	writeln("leap [switches] [directory]");
	writeln("");
	writeln("-d   Debug information");
	writeln("-h   This help page");
	writeln("-i   Timing information");
	writeln("-n   Warranty and conditions of use");
	writeln("-q   Quiet mode");
	writeln("-s   Status messages");
	writeln("-t   Tracing information");
	writeln("");
	writeln("directory should be base LEAP Directory, containing the following");
	writeln("directories: database/ report/ errors/ etc.");
	writeln("");
	writeln("Default directory is ~/leap/");
	writeln("");
}

void print_shutdown() {
/* print_shutdown
 * Print the shutdown message 
 */
	writeln("");
	writeln("Please send all comments, bugs, suggestions etc. to:");
	writeln("richard_leyton@mail.amsinc.com and/or e0190404@brookes.ac.uk");
	writeln("");
	writeln("Latest versions are available via anonymous ftp.");
	writeln("DOS   - ftp.demon.co.uk:/pub/compsci/databases/leap");
	writeln("Un*x  - leap_ux_linux.tar.gz leap_ux_solaris.tar.gz");
	writeln("");
	writeln("See the file location.txt for a list of the major sites archiving");
	writeln("LEAP.");
	writeln("");
	writeln("For upto date information, ftp sites, developments, take a look at");
	writeln("the LEAP Web Page at the following URL:");
	writeln("  http://www.brookes.ac.uk/~e0190404/leap.html");
	writeln("");
	writeln("Or see Yahoo - Computers, Software, Databases");
	writeln("");
	writeln("For warranty and conditions, start LEAP with -n parameter, or type <info>");
	writeln("at the LEAP prompt. Alternatively, see the accompanying documentation for");
	writeln("more details. Use of the program implies you have done and accepted this.");
	writeln("");
}

void do_warranty() {
/* do_warranty
 * Print the warrant information of LEAP
 */
writeln("                            NO WARRANTY");
writeln("");
writeln("  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY");
writeln("FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN");
writeln("OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES");
writeln("PROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED");
writeln("OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF");
writeln("MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS");
writeln("TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE");
writeln("PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,");
writeln("REPAIR OR CORRECTION.");
writeln("");
writeln("  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING");
writeln("WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR");
writeln("REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,");
writeln("INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING");
writeln("OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED");
writeln("TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY");
writeln("YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER");
writeln("PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE");
writeln("POSSIBILITY OF SUCH DAMAGES.");


}
