/* 
 * Name: attributes.c
 * Description: Attribute Functions - Access/Modification of
 *		attritbutes in a relation.
 * Version: $Id: attributes.c,v 1.11 1996/09/05 22:39:42 rleyton Exp $
 *
 *   LEAP - An extensible and free RDBMS
 *   Copyright (C) 1996 Richard Leyton
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   See the file COPYING for more information.
 *
 *   Richard Leyton, c/o 3.Pelting Drove, Priddy, WELLS, 
 *   Somerset, BA5 3BA. E-Mail: richard_leyton@mail.amsinc.com
 *   and/or e0190404@brookes.ac.uk. http://www.brookes.ac.uk/~e0190404/leap.html
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dtypes.h"
#include "util.h"
#include "relation.h"
#include "attributes.h"

FILE *open_attribute_file( FILE **attribute_file,
			   relation rel,
			   char *mode) {
/* open_attribute_file
 * Opens the attribute file, and returns a FILE ptr
 */
	char filename[FILE_PATH_SIZE+FILE_NAME_SIZE+FILENAME_EXT_SIZE];

	sprintf(filename,"%s%s",rel->filepath,rel->fieldname);
#ifdef FULL_DEBUG
	printf("Opening for %s file %s\n",filename,mode);
#endif
	*attribute_file=fopen(filename,mode);

	if (attribute_file==NULL) {
		do_error(ERROR_FILE_OPENING,filename,FATAL);
	}

	return *attribute_file;
}

void close_attribute_file( FILE **attribute_file ) {
/* close_attribute_file
 * Close the specified file
 */
	/* Close the file */
	(void) fclose(*attribute_file);
}

void attribute_create(	relation rel,
			char *attribute_name,
			char data_type ) {
/* attribute_create
 * (Same as field_create)
 * Create an attribute for a relation 
 */
	FILE *attribute_file;
	int nowritten;

	/* Open the file - This function will ensure that the
	 * file is opened. If not, then something strange is afoot
  	 * and it will abort LEAP. Its opened for appending.
	 */
	attribute_file=open_attribute_file(&attribute_file,rel,"a");

	/* Write the relation name to the file */
	nowritten=fprintf(attribute_file, "%s\n", attribute_name);

#ifdef FULL_DEBUG
	printf("nowritten==%i\n",nowritten);
#endif
	
	/* Depending on the data type */
	switch (data_type) {
		case DT_STRING : 
				/* It's a string */
				fprintf(attribute_file,"%s\n",DTS_STRING);
				break;
		case DT_NUMBER :
				/* It's a number/integer */
				fprintf(attribute_file,"%s\n",DTS_NUMBER);
				break;
		case DT_BOOLEAN :
				/* It's a Boolean */
				fprintf(attribute_file,"%s\n",DTS_BOOLEAN);
				break;
		default :
			/* Something strange has certainly happened
			 * if this point is reached. Nonetheless, just
			 * incase... 
			 */
			fprintf(attribute_file,"%s\n",DTS_UNSUPPORTED);
			do_error(ERROR_UNSUPPORTED_DTYPE,"",NONFATAL);
	}	
	/* Increment the number of fields in our relation
  	 */
	rel->noattributes++;

	/* Close the attribute file */
	close_attribute_file(&attribute_file);
}

int attribute_populate(relation rel,
			attribute att,
			FILE **attribute_file) {
/* attribute_populate
 * Reads from the specified file an attribute, and populates
 * the specified attribute with the data read. Returns the
 * result of the last read.
 */
	int readresult;
	char type[ATTRIBUTE_TYPE_SIZE];

	/* Read the entry (Attribute name, type) */
#ifdef FULL_DEBUG
	printf("feof returns: %i\n",feof(*attribute_file));
#endif

	readresult=fscanf(*attribute_file,"%s\n%s\n",att->name,type);

#ifdef FULL_DEBUG
	printf("Name read: >%s<\n",att->name);
	printf("Type: >%s<\n",type);
#endif

	/* Process the type, and populate the structure
	   appropriately */
	if (readresult>=0) {

		if (strcmp(type,DTS_STRING)==0) {
			/* Type is string */
			att->data_type=DT_STRING;

		} else if (strcmp(type,DTS_NUMBER)==0) {
			/* Type is a number */
			att->data_type=DT_NUMBER;
		
		} else if (strcmp(type,DTS_BOOLEAN)==0) {
			/* Type is a number */
			att->data_type=DT_BOOLEAN;

		} else {
			/* Type is not known, raise a nonfatal error */
			do_error(ERROR_UNSUPPORTED_DTYPE,type,NONFATAL);
			att->data_type=DT_UNDEFINED;
		}
	}

	/* Satisfy -Wall - TODO - Remove this */
	rel=rel;

	/* Return the result of the last read */
	return readresult;
}

attribute attribute_findfirst(relation rel,
			      FILE **attribute_file) {
/* attribute_findfirst
 * Return the first attribute in a relation
 */
	attribute att;

	/* Create a ptr to an attribute structure */
	att=(attribute_struct *) malloc(sizeof(attribute_struct));
	
	/* Check that the ptr was allocated. */
	check_assign(att,"attributes.attribute_findfirst");

	(void) open_attribute_file(attribute_file,rel,"r");

	/* We ought to handle the possibility of an error */
	(void) attribute_populate(rel,att,attribute_file);

	return(att);			
}	

attribute attribute_findnext(relation rel,
				attribute att,
				FILE **attribute_file,
				boolean newnode,
				boolean node_dispose) {
/* attribute_findnext
 * Locates the next attribute, and optionally creates
 * a new node for this. In addition, if the last node is
 * located, it is optional whether the node is disposed.
 * (This is all in order to populate a tuple structure
 */
	attribute natt;

	/* Check that the end of file hasn't been reached */
	if (feof(*attribute_file)==0) {

		/* A new node is required */
		if (newnode==TRUE) {
			/* Create a ptr to an attribute structure */
			natt=(attribute_struct *) malloc(sizeof(attribute_struct));
			check_assign(natt,"attribute.findnext");	
		
			/* Populate the attribute from the file */	
			attribute_populate(rel,natt,attribute_file);

			/* Return our new node */	
			return(natt);
		} else {
			/* Populate the attribute */
			attribute_populate(rel,att,attribute_file);
			/* Again, the likelyhood of an error should be handled */

			return(att);
		}
	} else {
		/* End of file encountered */

#ifdef FULL_DEBUG
	printf("Closing Attribute file");
#endif
		/* Close the attribute file */
		close_attribute_file(attribute_file); 

		if (node_dispose) {
			/* We want to deallocate the memory */
			free(att);
		}
		/* TODO - Investigate this - This means that the
		 * attributes can become dereferenced if we don't
		 * want to dispose of the node...
		 * Maybe we want to RETURN NULL, but not dispose
		 * of the option...., but this is a parameter...
		 */
		att=NULL; 
		return(NULL);
	}	

	/* Return the attribute */
	return(att);
		
}

char *attribute_name(attribute att) {
/* attribute_name
 * Returns a ptr to a string containing the attribute name
 */
	return(att->name);
}

char attribute_type(attribute att) {
/* attribute_type
 * Returns a ptr to a char containing the data type of 
 * the attribute
 */
	return(att->data_type);
}

void attribute_print(attribute att) {
/* attribute_print
 * Print out the information contained in the specified
 * attribute
 */
	/* Check that the ptr is assigned! */
	if (att!=NULL) {
		write(attribute_name(att));
		write("    (");
		switch (attribute_type(att)) {
			case DT_STRING:
				write(DTS_STRING);
				break;
			case DT_NUMBER:
				write(DTS_NUMBER);
				break;
			case DT_BOOLEAN:
				write(DTS_BOOLEAN);
				break;
			default:
				write(DTS_UNSUPPORTED);
		}
		writeln(")");
	}
}

void attribute_display(relation rel) {
/* attribute_display
 * Print out all of the attributes associated with
 * a relation
 */
	attribute att;
	FILE *attribute_file;

	/* Display the header for the list */
	writeln("Name     (Type)");

	/* Locate the first attribute */
	att=attribute_findfirst(rel,&attribute_file);

	/* Move through the attributes */
	while (att!=NULL) {
		/* Display the first attribute */
		attribute_print(att);
		
#ifdef FULL_DEBUG
	printf("feof returns %i\n",feof(attribute_file));
#endif	

		/* Locate the next attribute */
		att=attribute_findnext(rel,att,&attribute_file,FALSE,TRUE);	
	}
}
	
void attributes_print(relation rel) {
/* attribute_print
 * Print out all of the attributes associated with
 * a relation - For rl_display mainly.
 */
	attribute att;
	FILE *attribute_file;
	int counter;

	/* Locate the first attribute */
	att=attribute_findfirst(rel,&attribute_file);

	/* Move through the attributes */
	while (att!=NULL) {
		/* Display the first attribute */
		printf("%s\t",attribute_name(att));
		
		/* Locate the next attribute */
		att=attribute_findnext(rel,att,&attribute_file,FALSE,TRUE);	
	}
	printf("\n");
	for (counter=0;counter<80;counter++) printf("-");
	printf("\n");
}

attribute attribute_find ( relation rel, char *name) {
/* attribute_find
 * Locates the given attribute, and returns an attribute structure
 */
	attribute catt;
	FILE *attribute_file;

	/* Get the first attribute */
	catt=attribute_findfirst(rel,&attribute_file);

	/* Whilst the attribute is valid, and the attribute does
	 * not match the search criteria 
	 */
	while ( (catt!=NULL) && (name!=NULL) && (strcmp(attribute_name(catt),name)!=0) ) {

		/* Locate the next field */
		catt=attribute_findnext(rel,catt,&attribute_file,FALSE,TRUE);
	}

	/* Check to see if we actually found anything */
	if ( (catt!=NULL) && (name!=NULL) && (strcmp(attribute_name(catt),name)==0) ) {
		return(catt);
	} else {
		/* Oh dear, didn't find anything... */
		if (catt!=NULL) {
			free(catt);
		} 

		/* This isn't strictly necessary, but I'm a good boy... */
		catt=NULL;
		
		/* TODO - Search criteria errors? */
	
		/* Return nothing */	
		return(NULL);
	}
}

void attribute_dispose( attribute *attr ) {
/* attribute_dispose
 * Dispose of an attribute
 */
	if (attr!=NULL) {
		free(*attr);
		*attr=NULL;
	}
}
