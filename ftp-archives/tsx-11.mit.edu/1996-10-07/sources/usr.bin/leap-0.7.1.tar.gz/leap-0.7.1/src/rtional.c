/* 
 * Name: rtional.c
 * Description: Relational Operators
 * Version: $Id: rtional.c,v 1.19 1996/09/05 22:39:42 rleyton Exp $
 *
 *   LEAP - An extensible and free RDBMS
 *   Copyright (C) 1996 Richard Leyton
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   See the file COPYING for more information.
 *
 *   Richard Leyton, c/o 3.Pelting Drove, Priddy, WELLS, 
 *   Somerset, BA5 3BA, UK. E-Mail: richard_leyton@mail.amsinc.com
 *   and/or e0190404@brookes.ac.uk. http://www.brookes.ac.uk/~e0190404/leap.html
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dtypes.h"
#include "rtional.h"
#include "relation.h"
#include "attributes.h"
#include "tuples.h"
#include "hashing.h"
#include "util.h"
#include "condition.h"


char special_condition_true[]="(TRUE=TRUE)";
char special_condition_false[]="(TRUE=FALSE)";

char *generate_random_string(word size,
			     char *pstring) {
/* generate_random_string
 * Generates a string of 'size' random(ish) characters
 */
	char *string;
	int counter;

	/* Allocate the memory - +1 for null. */
#ifdef FULL_DEBUG
	fprintf(stderr,"size: %d\n",size);
#endif
	if (pstring==NULL) {
		/* If the string is not allocated, allocate some
		 * memory! */
		string=malloc(size+1);
	} else {
		string=pstring;
	}


	for(counter=0;( (unsigned int) counter)<size;counter++) {
		string[counter]=( (rand() % 26)+97);
#ifdef FULL_DEBUG
	fprintf(stderr,"counter: %d\nstring: %s\n",counter,string);
#endif
	}	

	string[size]='\0';

	/* Add an 'l' at the beginning to make it a little
	 * easier to find the LEAP temporary files...
	 */
	string[0]='l';
	
	return(string);
}

relation project_create_rtn_relation(database db,
				     relation rel,
				     char *attribute_list,
				     char *destname) {
/* project_create_rtn_relation
 * Creates an (empty) relation with the specified attributes only
 */
	relation return_rel;
	char *rname,rel_name[RELATION_NAME_SIZE+1],*cur_attribute;
	char attribs[MAXIMUM_MAXIMUM_ATTRIBUTE];
	attribute attrib;

	/* If the destination name is empty, a name should
	 * be generated
  	 */

	if (strlen(destname)==0) {
		rname=generate_random_string(RELATION_NAME_SIZE,rel_name);
#ifdef FULL_DEBUG
	fprintf(stderr,"Relation Name Generated: >%s<\n",rname);
#endif
	} else {
		rname=destname;
	}

	/* Create the relation */
	return_rel=relation_create(db,rname,TRUE);

	/* If something happened, and the relation is not created,
	 * then return NULL
	 */	
	if ( (return_rel==NULL) || (rel==NULL) ) {
		return NULL;
	} else {
		/* Reset the number of attributes */
		return_rel->noattributes=0;

		/* Copy the attribute list - we want to modify it */
		strcpy(attribs,attribute_list);
#ifdef FULL_DEBUG
	fprintf(stderr,"Attributes: %s\n",attribs);
#endif
		/* Get the first field from the list */
		cur_attribute=strtok(attribs,SEPERATORS);

		attrib=attribute_find(rel,cur_attribute);

		while (attrib!=NULL) {

#ifdef FULL_DEBUG
	fprintf(stderr,"Create: %s\n",cur_attribute);
#endif
			/* Create the attribute in the new relation */
			attribute_create(return_rel,cur_attribute,attribute_type(attrib));

			/* Get the next string */
			cur_attribute=strtok(NULL,SEPERATORS);

			/* Locate the attribute */
			attrib=attribute_find(rel,cur_attribute);
		}
	
		return(return_rel);
	}
}

relation create_duplicate_rtn_relation( database db,
					relation rel,
					char *destname) {
/* create_duplicate_rtn_relation
 * Create a relation with the same attribute names as specified relation
 */
	relation rtrel;
	char *rname,rel_name[RELATION_NAME_SIZE+1],temp[100];
	attribute attr;
	unsigned int count;
	FILE *a_file;

	if (strlen(destname)==0) {
		rname=generate_random_string(RELATION_NAME_SIZE,rel_name);
#ifdef FULL_DEBUG
	fprintf(stderr,"Relation Name Generated: >%s<\n",rname);
#endif
	} else {
		rname=destname;
	}
	rtrel=relation_create(db,rname,TRUE);

	if ( (rtrel==NULL) || (rel==NULL) ) {
		return(NULL);
	} else {
		/* Populate the values */
		rtrel->noattributes=0;

		/* Get the first attribute in the source relation */
		attr=attribute_findfirst(rel,&a_file);

		count=0;

		/* While the attribute is valid */				
		while (attr!=NULL) {

			/* Create a attribute in the new relation with
			 * the correct name and types
			 */
			attribute_create(rtrel,attribute_name(attr),attribute_type(attr));

			count++;

			if (count>=MAXIMUM_ATTRIBUTES) {
				/* Report an error */
				sprintf(temp,"Current limit set to %u.",MAXIMUM_ATTRIBUTES);
				do_error(ERROR_EXCEEDED_ATTRIBUTE_LIMIT,temp,NONFATAL);

				attribute_dispose(&attr);
			} else {
				attr=attribute_findnext(rtrel,attr,&a_file,FALSE,TRUE);
			}
		}
	}

	/* Return the new relation */
	return(rtrel);
}

relation rl_project(database db,
		    relation rel,
		    char *attribute_list,
		    char *destname) {
/* rl_project
 * Returns the result of performing a relation project 
 * operation on the specified relation, taking the attributes
 * specified in attribs
 */

	relation rtrel;
	HashTable HT;
	char att_list[MAXIMUM_MAXIMUM_ATTRIBUTE],*attrib,error_mess[ATTRIBUTE_NAME_SIZE+20];
	char tuple_string[MAXIMUM_ALL_DATA],*attribmkr;
	char found_string[HASH_KEY_SIZE];
	boolean success;
	attribute att;
	tuple ta,nt;
	FILE *tuple_file;
	unsigned int c,noattributes;
	unsigned int reference[MAXIMUM_ATTRIBUTES],reference_position;

	/* Create the return relation */
	rtrel=project_create_rtn_relation(db,rel,attribute_list,destname);

	/* If an error occured */
	if ( (rtrel==NULL) || (rel==NULL) ) {
		/* Return NULL */
		return(NULL);
	} else {
		/* Otherwise... */

		/* Initialise the reference array */
		for (c=0;c<MAXIMUM_ATTRIBUTES;c++) reference[c]=0;

		/* Create a hash table */
		HT=hashing_create();	

		/* Make a copy of the attribute list */
		/* strcpy(att_list,attribute_list); */

		/* Add an additional seperator to check make
		 * sure the last attribute is picked up 
		 */
		sprintf(att_list,"%c%s%c",ATTRIBUTE_SEPERATOR,attribute_list,ATTRIBUTE_SEPERATOR);

		/* TODO - What if there is an empty attribute, ie. ,, 
		 * or multiple spaces in the list! 
		 */
		/* Get the first attribute in the field list */
#ifdef FULL_DEBUG
	fprintf(stderr,"Attribute List: %s\n",att_list);
#endif
		attrib=strchr(att_list,ATTRIBUTE_SEPERATOR);		
		/* strchr will give us the first seperator, we want
	         * the next char 
		 */
		attrib++;

		/* Find the NEXT seperator, and put a null there */
		attribmkr=strchr(attrib,ATTRIBUTE_SEPERATOR);
		*attribmkr='\0';		
	
		att=attribute_find(rel,attrib);

		/* If we didn't find the attribute... */
		if (att!=NULL) {

			ta=readfirst_tuple(rel,&tuple_file,&rel->noattributes,TUPLE_BUILD,NULL);

			/* Ok, now we are going to move through the
 		 	* tuple and determine which attributes are necessary
 		 	* for the project operation. We're going to use
 	 	 	* an array of unsigned ints for this, so we can
		 	* determine the location of the attributes in the
		 	* tuple, and copy them out quickly
		 	*/

			/* Initialise the reference index */
			reference_position=0;

			/* Whilst we have a valid tuple (we might not have
		 	* anything) - TODO - What if the first tuple is empty?
		 	* move through and determine which fields are where.
		 	*/
			while ( (ta!=NULL) && (attrib!=NULL) ) {
#ifdef FULL_DEBUG
		fprintf(stderr,"Current Attribute: %s\n",attrib);
#endif
				/* No need to convert to upper case. This is Unix! */
		
				/* Start at the first attribute */	
				c=0;
	
				/* This needs some explanation! Whilst the current
			 	* attribute in the tuple is not null, AND the name of
		 	 	* the attribute in the tuple is not the one we're looking
			 	* for...
			 	*/
				/* TODO - What about if the tuple structure is fully
			 	* populated - c<MAX_ATTRIBUTES? 
			 	*/
				/* while ( ( (*(ta)[c]) !=NULL) && ( (*(ta)[c])->att != NULL ) && (strcmp(attrib,((*(ta)[c])->att)->name)!=0) )  */

				/* tattribute=tuple_attribute(ta,c);*/

				while ( ( tuple_item(ta,c) != NULL) 
 					 && (strcmp(attrib,(tuple_attribute(ta,c))->name)!=0) ) 
					/* Move to the next attribute in
				 	* the tuple
				 	*/
					c++;
	
				/* On exiting the above while loop, we'll
			 	* have found the attribute, or exhausted
			 	* the possibilities
			 	*/
		
					
				/* if ( (*(ta)[c])->att != NULL ) { */
				if ( tuple_attribute(ta,c) != NULL ) {
					/* We've found something */
		
					/* Store the position of the node */
					reference[reference_position]=c;
	
					/* Increment the positioning index */
					reference_position++;
				} else {
					sprintf(error_mess,"Project: %s",attrib);
					do_error(ERROR_CANTFIND_ATTR,error_mess,NONFATAL);
					return(NULL);
				}
	
				/* Get the next attribute from the list */
				attrib=attribmkr;
				attrib++;
	
				attribmkr=strchr(attrib,ATTRIBUTE_SEPERATOR);
				if (attribmkr!=NULL) { *attribmkr='\0'; }
				else { attrib=NULL; }
			} /* while */
	
			/* Create a tuple from the new return relation */
			nt=tuple_prepare_attributes(rtrel);

			noattributes=reference_position;
	
			/* Whilst we have a valid tuple */
			while (ta!=NULL) {
	
				reference_position=0;
	
				/* Move through our array of attributes */
				while (reference_position<noattributes) {
					/* Copy INTO the new tuple, the data from the old tuple. Take each
			 	 	* position one at a time...
				 	*/
					/* strcpy( (*(nt)[reference_position])->data, (*(ta)[reference[reference_position]])->data); */
					strcpy( tuple_d(nt,reference_position), tuple_d(ta,reference[reference_position]));
					reference_position++;
				} /*while*/	
	
				/* Convert the data in the tuple to a string */
				tuple_to_string( nt, tuple_string );
#ifdef FULL_DEBUG
	fprintf(stderr,"Tuple String: %s\n",tuple_string);
#endif
	
				/* Try and locate the string version of the tuple
			 	* in the hash table 
			 	*/
				hashing_retrieve(HT,tuple_string,found_string,&success);
	
				/* If the tuple was not located in the hash table */
				if (!success) {
					/* Insert the string version of the tuple into
				 	* the hash table */
	
					hashing_insert(HT,tuple_string,REQ_CALC);	
	
					/* Write the tuple out to disk */
					/* TODO - Handle return code of write_tuple */	
					(void) write_tuple(nt);
				} else {
					fprintf(stderr,"[project] Attempted to add duplicate tuple to hash table! (%s)\n",tuple_string);
				} /* if */
		
				(void) readnext_tuple(&ta,&tuple_file,&rel->noattributes,TUPLE_BUILD);
			} /* while */
		} /*if*/ else {
			do_error(ERROR_CANTFIND_ATTR,attrib,NONFATAL);
		}
	} /*if*/

	/* TODO - Disposal of tuple */

	hashing_terminate(HT);

	return(rtrel);
}

void populate( char string_array[MAXIMUM_ATTRIBUTES][ATTRIBUTE_MAXIMUM_SIZE],
	       relation rel ) {

	attribute attr;
	unsigned int count;
	FILE *attribute_file;

	count=0;

	/* Load the first attribute */	
	attr=attribute_findfirst( rel, &attribute_file );

	/* Whilst valid attribute */
	while (attr!=NULL) {
		strcpy(string_array[count],attribute_name(attr));

		/* Fetch the next attribute name */
		attr=attribute_findnext(rel,attr, &attribute_file, FALSE, TRUE);

		/* Increment the counter */
		count++;
	}
}
	
boolean rl_is_union_compatible( relation rel1,	
				relation rel2 ) {
/* rl_is_union_compatible
 * Checks if the specified relations are union compatible
 */
	boolean result=FALSE;
	unsigned int noattributes,idx1,idx2;
	char r1[MAXIMUM_ATTRIBUTES][ATTRIBUTE_MAXIMUM_SIZE];
	char r2[MAXIMUM_ATTRIBUTES][ATTRIBUTE_MAXIMUM_SIZE];

	/* Check the relations are valid, and that they
 	 * have the same number of attributes 
	 */
	if ( ( (rel1!=NULL) && (rel2!=NULL) )
	    &&  (rel1->noattributes==rel2->noattributes)
	   ) {
		noattributes=rel1->noattributes;	

		populate(r1,rel1);
		populate(r2,rel2);		

		idx1=0;

		/* Whilst nothing has happened to abort, and the index
		 * of the first relation is within bounds 
		 */
		while ( (result=FALSE) && (idx1<noattributes) ) {

			while ( (strcmp(r1[idx1],r2[idx2])!=0) && (idx2<noattributes) ) 
				idx2++;

			/* If we went over the number of attributes, then we've
			 * found a field that doesn't exist
			 */
			if (idx2>noattributes) 
				result=TRUE;
			else
				idx1++;

		}

		/* Negate the result, because for union compatibility
		 * post-requisite of loop will be result=FALSE 
		 */
		result=(!result);
	} 

	/* Return the contents of result */
	return(result);
}

relation rl_union( database db,
		   relation rel1, relation rel2,
		   char *destname) {
/* rl_union
 * Performs the algebraic operation UNION with the specified relations
 */
	relation rtrel;
	char temp[100];
	word counter,noattributes;
	tuple ct,nt;
	FILE *ct_file;

	/* Check that the source relations are union compatible */
	if ( rl_is_union_compatible(rel1,rel2) ) {

		rtrel=create_duplicate_rtn_relation(db,rel2,destname);

		/* If a relation has been returned */
		if (rtrel!=NULL) {
			/* Create an empty tuple based on the new relation */
			nt=tuple_prepare_attributes(rtrel);

			/* Read the first tuple from the first relation */
			ct=readfirst_tuple(rel1,&ct_file,&noattributes,TUPLE_BUILD,NULL);

			/* Whilst the tuple is valid */
			while (ct!=NULL) {
				counter=0;
				
				/* Whilst the current attribute datum is ok */
				while (counter<noattributes) {
					/* Copy the data from the source tuple into the dest. tuple */	
					strcpy( tuple_d(nt,counter),tuple_d(ct,counter));	

					/* Increment the counter */
					counter++;
				}

				/* TODO - handle return code of write_tuple */
				(void) write_tuple(nt);

				(void) readnext_tuple(&ct,&ct_file,&noattributes,TUPLE_BUILD);
			}

			/* Move onto the second relation, and write any
			 * tuples not in the first to disk.
			 * TODO - Check that the attributes are in the same order 
		 	 * this is done in Pascal version with tuple_to_string_order_by_relation
			 * or such like, where the tuple is converted to the string in the
			 * order of a specified relation known to be union compatible
			 */
			ct=readfirst_tuple(rel2,&ct_file,&noattributes,TUPLE_BUILD,NULL);
		
			while (ct!=NULL) {
				counter=0;
				
				/* Whilst the current attribute datum is ok */
				while (counter<noattributes) {
					/* Copy the data from the source tuple into the dest. tuple */	
					strcpy( tuple_d(nt,counter),tuple_d(ct,counter));	

					/* Increment the counter */
					counter++;
				}

				/* Write the tuple to disk */
				(void) write_tuple(nt);

				/* Load the next tuple from the second relation */	
				(void) readnext_tuple(&ct,&ct_file,&noattributes,TUPLE_BUILD);
			}
		} else {
			/* No relation was created */
			return(NULL);
		}

		tuple_dispose(&nt);

	} else {
		rtrel=NULL;
		sprintf(temp,"Union of %s and %s.",relation_name(rel1),relation_name(rel2));
		do_error(ERROR_UNION_COMPATIBILITY,temp,NONFATAL);
	}
	return(rtrel);
}

relation rl_intersect( database db,
		       relation rel1, 
		       relation rel2,
		       char *destname) {
/* rl_intersect
 * Intersection operator
 */
	relation rtrel;
	char temp[100],s[MAXIMUM_ALL_DATA],result[MAXIMUM_ALL_DATA];
	boolean success;
	word counter,noattributes;
	HashTable htable;
	tuple ct,nt;
	FILE *ct_file;


	/* Check that the source relations are union compatible */
	if ( rl_is_union_compatible(rel1,rel2) ) {

		rtrel=create_duplicate_rtn_relation(db,rel2,destname);

		/* If a relation has been returned */
		if (rtrel!=NULL) {
			/* Create an empty tuple based on the new relation */
			nt=tuple_prepare_attributes(rtrel);

			/* Create the hash table */
			htable=hashing_create();

			/* Read the first tuple from the first relation */
			ct=readfirst_tuple(rel1,&ct_file,&noattributes,TUPLE_BUILD,NULL);

			/* Whilst the tuple is valid */
			while (ct!=NULL) {
				counter=0;
				
				/* Whilst the current attribute datum is ok */
				while (counter<noattributes) {
					/* Copy the data from the source tuple into the dest. tuple */	
					strcpy( tuple_d(nt,counter),tuple_d(ct,counter));	

					/* Increment the counter */
					counter++;
				}
				
				/* Convert the tuple to a string - TODO - Order by attributes */
				tuple_to_string(nt,s);

				/* Insert the data into our hashing table */
				hashing_insert(htable,s,REQ_CALC);

				/* Read the next tuple from the disk */
				(void) readnext_tuple(&ct,&ct_file,&noattributes,TUPLE_BUILD);
			}

			/* Move onto the second relation, and write any
			 * tuples IN the first hash table (so its in both relations).
			 *
			 * TODO - Check that the attributes are in the same order 
		 	 * this is done in Pascal version with tuple_to_string_order_by_relation
			 * or such like, where the tuple is converted to the string in the
			 * order of a specified relation known to be union compatible
			 */
			ct=readfirst_tuple(rel2,&ct_file,&noattributes,TUPLE_BUILD,NULL);
		
			while (ct!=NULL) {
				counter=0;
		
				/* Convert the tuple to a string
				 * TODO - Order by relation's attributes 
				 */	
				tuple_to_string(ct,s);	

				/* Retrieve the entry in the hash table
				 * if it exists in the table, then its in
				 * both relations, so can be written to disl 
				 */	
				success=FALSE;
				hashing_retrieve(htable,s,result,&success);

				if (success) {
					/* Whilst the current attribute datum is ok */
					while (counter<noattributes) {
						/* Copy the data from the source tuple into the dest. tuple */	
						strcpy( tuple_d(nt,counter),tuple_d(ct,counter));	

						/* Increment the counter */
						counter++;
					}

					/* Write the tuple to disk */
					(void) write_tuple(nt);
				}

				/* Load the next tuple from the second relation */	
				(void) readnext_tuple(&ct,&ct_file,&noattributes,TUPLE_BUILD);
			}

			/* Dispose of the output tuple */
			tuple_dispose(&nt);

			/* Terminate the hashing table */
			hashing_terminate(htable);			
		} else {
			/* No relation was created */
			return(NULL);
		}
	} else {
		rtrel=NULL;
		sprintf(temp,"Union of %s and %s.",relation_name(rel1),relation_name(rel2));
		do_error(ERROR_UNION_COMPATIBILITY,temp,NONFATAL);
	}

	return(rtrel);
}


relation rl_difference( database db,
		       relation rel1, 
		       relation rel2,
		       char *destname) {
/* rl_difference
 * Difference operator - based extensively on intersect.
 * TODO (ONE DAY) - Combine difference and intersect. They're so
 * damn similair...
 */
	relation rtrel;
	char temp[100],s[MAXIMUM_ALL_DATA],result[MAXIMUM_ALL_DATA];
	boolean success;
	word counter,noattributes;
	HashTable htable;
	tuple ct,nt;
	FILE *ct_file;


	/* Check that the source relations are union compatible */
	if ( rl_is_union_compatible(rel1,rel2) ) {

		rtrel=create_duplicate_rtn_relation(db,rel2,destname);

		/* If a relation has been returned */
		if (rtrel!=NULL) {
			/* Create an empty tuple based on the new relation */
			nt=tuple_prepare_attributes(rtrel);

			/* Create the hash table */
			htable=hashing_create();

			/* Read the first tuple from the SECOND relation */
			ct=readfirst_tuple(rel2,&ct_file,&noattributes,TUPLE_BUILD,NULL);

			/* Whilst the tuple is valid */
			while (ct!=NULL) {
				counter=0;
				
				/* Whilst the current attribute datum is ok */
				while (counter<noattributes) {
					/* Copy the data from the source tuple into the dest. tuple */	
					strcpy( tuple_d(nt,counter),tuple_d(ct,counter));	

					/* Increment the counter */
					counter++;
				}
				
				/* Convert the tuple to a string - TODO - Order by attributes */
				tuple_to_string(nt,s);

				/* Insert the data into our hashing table */
				hashing_insert(htable,s,REQ_CALC);

				/* Read the next tuple from the disk */
				(void) readnext_tuple(&ct,&ct_file,&noattributes,TUPLE_BUILD);
			}

			/* Move onto the FIRST relation, and write any
			 * uniques to disk.
			 *
			 * TODO - Check that the attributes are in the same order 
		 	 * this is done in Pascal version with tuple_to_string_order_by_relation
			 * or such like, where the tuple is converted to the string in the
			 * order of a specified relation known to be union compatible
			 */
			ct=readfirst_tuple(rel1,&ct_file,&noattributes,TUPLE_BUILD,NULL);
		
			while (ct!=NULL) {
				counter=0;
		
				/* Convert the tuple to a string
				 * TODO - Order by relation's attributes 
				 */	
				tuple_to_string(ct,s);	

				/* Retrieve the entry in the hash table
				 * if it DOESN'T exist in the table, then its in
				 * the second, but not the first
				 */	
				success=FALSE;
				hashing_retrieve(htable,s,result,&success);

				if (!success) {
					/* Whilst the current attribute datum is ok */
					while (counter<noattributes) {
						/* Copy the data from the source tuple into the dest. tuple */	
						strcpy( tuple_d(nt,counter),tuple_d(ct,counter));	

						/* Increment the counter */
						counter++;
					}

					/* Write the tuple to disk */
					(void) write_tuple(nt);
				}

				/* Load the next tuple from the second relation */	
				(void) readnext_tuple(&ct,&ct_file,&noattributes,TUPLE_BUILD);
			}

			/* Dispose of the output tuple */
			tuple_dispose(&nt);

			/* Terminate the hashing table */
			hashing_terminate(htable);			
		} else {
			/* No relation was created */
			return(NULL);
		}
	} else {
		rtrel=NULL;
		sprintf(temp,"Union of %s and %s.",relation_name(rel1),relation_name(rel2));
		do_error(ERROR_UNION_COMPATIBILITY,temp,NONFATAL);
	}

	return(rtrel);
}

relation rl_display(relation rel) {
/* rl_display
 * Display the tuples in a relation
 * TODO Remove relation_tuples_display when rl_display is working - DONE 12.05.1996
 */
	tuple ntuple;
	FILE *tfile;
	word noattributes;

	if (rel!=NULL) {
		printf("Relation: %s\n",relation_name(rel));

		/* Load the first tuple */
		ntuple=readfirst_tuple(rel,&tfile,&noattributes,TUPLE_BUILD,NULL);

		attributes_print(rel);

		/* Whilst the tuple is valid */
		while (ntuple!=NULL) {
	
			/* Print out the information */
			tuple_print(ntuple,FALSE);
	
			/* Fetch the next tuple */
			(void) readnext_tuple(&ntuple,&tfile,&noattributes,TUPLE_BUILD);
		}
	}	

	/* Return the relation, so no garbled output on "Relation Returned" */
	return(rel);
}

/* This is a structure I used, because I got annoyed with 
 * C arrays and couldn't work it out for some reason. I wanted
 * to have an array of strings, but things weren't working quite
 * correctly...
 * TODO - Implement array of strings.
 */
struct attribute_list {
	char attribute[ATTRIBUTE_NAME_SIZE+1];
};

boolean attribute_used(struct attribute_list attrib_list[MAXIMUM_ATTRIBUTES],
			attribute attrib) {
/* attribute_used
 * Returns TRUE If the attribute specified in attrib is located in
 * the "string" array.
 */
	word counter;

	/* Reset the counter */
	counter=0;

	/* Whilst the string is not found in the array, and we're within the array bounds */
	while ( (strcmp(attrib_list[counter].attribute,attribute_name(attrib))!=0) 
	     && (counter<MAXIMUM_ATTRIBUTES) ) {
#ifdef FULL_DEBUG
	printf("attribute(%u): %s\n",counter,attrib_list[counter].attribute);
#endif
		counter++;
	}

	/* If the string is located, ie. counter isn't outside of the array */
	if ( (strlen(attrib_list[counter].attribute)!=0) && (counter<MAXIMUM_ATTRIBUTES) ) {

		/* We've found the attribute */
		return(TRUE);
	} else {
		
		/* We haven't found the attribute */
		return(FALSE);
	}
		
}


relation relation_create_both(database db,
				relation rel1, relation rel2,
				char *name) {
/* relation_create_both
 * Creates a new relation that contains the attributes from two
 * source relations - it is used by product & join 
 */
	char *rname,rel_name[RELATION_NAME_SIZE+1];
	relation rtrel;
	struct attribute_list attrib_names[MAXIMUM_ATTRIBUTES];
	char temp[100];
	word counter;
	attribute cattr;
	FILE *cattr_file;
	boolean exceeded_limit=FALSE;


	/* If the caller has not provided a relation name, then
	 * generate one. TODO - Is this really necessary? Prerequisite
	 * could be that a name is provided that doesn't exist...
	 */

	/* Check that the parameter relations are valid */
	if ( (rel1!=NULL) && (rel2!=NULL) ) {

		if (strlen(name)==0) {
			rname=generate_random_string(RELATION_NAME_SIZE,rel_name);
		} else {
			rname=name;
		}	

		/* Create a temporary relation with the specified name */
		rtrel=relation_create(db,rname,TRUE);	

		/* Check all is ok  */
		if (rtrel!=NULL) {
			/* Reset the number of attributes */
			rtrel->noattributes=0;

			/* Reset the array */
			for (counter=0;counter<MAXIMUM_ATTRIBUTES;counter++) {
				strcpy(attrib_names[counter].attribute,"");
			}

			/* Reset the counter for the name array */	
			counter=0;

			/* Locate the first attribute in the relation */
			cattr=attribute_findfirst(rel1,&cattr_file);

			/* Whilst we have a valid attribute */	
			while (cattr!=NULL) {

				/* Put a ptr to the attribute name into the name array */
				strcpy(attrib_names[counter].attribute,attribute_name(cattr));
	
				/* Increment the counter */
				counter++;

				/* Create the attribute in the destination relation */
				attribute_create(rtrel,attribute_name(cattr),attribute_type(cattr));

				/* Check that we are not now at the maximum number of attributes
				 * permitted in a relation 
				 */
				if (counter==MAXIMUM_ATTRIBUTES) {
	
					/* Report an error */
					sprintf(temp,"Current limit set to %d attributes.\n",MAXIMUM_ATTRIBUTES);
					do_error(ERROR_EXCEEDED_ATTRIBUTE_LIMIT,temp,NONFATAL);

					/* Dispose of the attribute to abort the while loop */
					attribute_dispose(&cattr);

					/* Set a flag so that the next section isn't executed. */
					exceeded_limit=TRUE;

				} else {

					/* Locate the next attribute */
					cattr=attribute_findnext(rel1,cattr,&cattr_file,FALSE,TRUE);
				}
			}	

			if (exceeded_limit==FALSE) {
			
				cattr=attribute_findfirst(rel2,&cattr_file);

				while (cattr!=NULL) {
					
					if (attribute_used(attrib_names,cattr)) {
#ifdef FULL_DEBUG
	printf("Duplicate attribute name!");
#endif		
						sprintf(attrib_names[counter].attribute,"%s.%s",relation_name(rel2),attribute_name(cattr));
					} else {
						/* Put a ptr to the attribute name into the name array */
						strcpy(attrib_names[counter].attribute,attribute_name(cattr));
					}

					attribute_create(rtrel,attrib_names[counter].attribute,attribute_type(cattr));

					counter++;

					/* Check that we are not now at the maximum number of attributes
				 	* permitted in a relation 
				 	*/
					if (counter==MAXIMUM_ATTRIBUTES) {
	
						/* Report an error */
						sprintf(temp,"Current limit set to %d attributes.\n",MAXIMUM_ATTRIBUTES);
						do_error(ERROR_EXCEEDED_ATTRIBUTE_LIMIT,temp,NONFATAL);

						/* Dispose of the attribute to abort the while loop */
						attribute_dispose(&cattr);
	
						/* Set a flag so that the next section isn't executed. */
						exceeded_limit=TRUE;

					} else {

						/* Locate the next attribute */
						cattr=attribute_findnext(rel1,cattr,&cattr_file,FALSE,TRUE);
					}
				}
			}
		}
		/* "else rtrel==NULL, so break out... */
	} else {
		/* One of our parameter relations was scwewy... */
		rtrel=NULL;	
	}

	return (rtrel);
}

relation rl_product(database db,
			relation rel1, relation rel2,
			char *destname) {
/* rl_product
 * Produces the cartesian product of the two specified relations
 */
	char *rname;
	relation return_rel;
	tuple ct1,ct2,nt;
	FILE *ct1_file,*ct2_file;
	word ct1_noattributes,ct2_noattributes,count;
	char rel_name[RELATION_NAME_SIZE+1];

	if (strlen(destname)==0) {
		rname=generate_random_string(RELATION_NAME_SIZE,rel_name);
	} else {
		rname=destname;
	}	

	/* Create the return relation */
	return_rel=relation_create_both(db,rel1,rel2,rname);

	/* If we have a valid relation! */
	if (return_rel!=NULL) {
		/* Prepare the output tuple */
		nt=tuple_prepare_attributes(return_rel);

		/* Read the first tuple */
		ct1=readfirst_tuple(rel1,&ct1_file,&ct1_noattributes,TUPLE_BUILD,NULL);

		/* Whilst the tuple is valid */
		while (ct1!=NULL) {

			/* Read the first tuple of the first relation */
			ct2=readfirst_tuple(rel2,&ct2_file,&ct2_noattributes,TUPLE_BUILD,NULL);

			/* Whilst the tuple is valid */
			while (ct2!=NULL) {

				count=0;
				while (count<ct1_noattributes) {
					strcpy( tuple_d(nt,count),tuple_d(ct1,count) );
					count++;
				}
				count=0;
				while (count<ct2_noattributes) {
					strcpy( tuple_d(nt,count+ct1_noattributes),tuple_d(ct2,count) );
					count++;
				}

				(void) write_tuple(nt);
		
				(void) readnext_tuple(&ct2,&ct2_file,&ct2_noattributes,TUPLE_BUILD);
			}	
			
			(void) readnext_tuple(&ct1,&ct1_file,&ct1_noattributes,TUPLE_BUILD);
		}

		tuple_dispose(&nt);
	}

	return(return_rel);
}

relation rl_select( database db,
			relation rel,
			char *qualification,
			char *dest) {
/* rl_select
 * The relational select/restrict operator
 */
	relation rtrel;
	tuple ct,nt; /* Current tuple, and new tuple */
	FILE *ctfile;
	word ctnoattributes;
	condp condition;
	int counter;
	char spare_qualification[MAXIMUM_EXPRESSION]; /* Incase a qual. is not provided! */


#ifdef FULL_DEBUG
	printf("Qualification: %s\n",qualification);
	printf("Destination  : %s\n",dest);
#endif

	if (strlen(qualification)==0) {
		do_error(ERROR_NO_CONDITION,"No condition specified. Defaulting to an always TRUE condition.",NONFATAL);
		strcpy(spare_qualification,special_condition_true);
		qualification=spare_qualification;
	}

	/* Create the result relation */
	rtrel=create_duplicate_rtn_relation(db,rel,dest);

	/* Check that a relation was created */
	if ( (rtrel!=NULL) && (rel!=NULL) ) {
		/* Relation is ok, and new relation is ok */

		/* Create our "input" tuple */
		ct=readfirst_tuple(rel,	&ctfile, &ctnoattributes,TUPLE_BUILD,NULL);

		/* Create the "output" tuple */
		nt=tuple_prepare_attributes(rtrel);

		/* Build the condition structure */
		condition=build_condition(qualification,ct,NULL);

		if (condition!=NULL) {

			/* If debug output is required */
			if (LDEBUG==TRUE) {
				/* Display the condition */
				print_condition(condition);	
			}
	
			/* Process the "input" tuples */
			while (ct!=NULL) {

#ifdef FULL_DEBUG
	tuple_print(ct,FALSE);
#endif
				/* Evaluate the condition on the current tuple */
				if (evaluate( condition, ct, NULL )==TRUE) {
#ifdef FULL_DEBUG
	fprintf(stderr,"Tuple will be written to disk\n");
#endif

					/* Reset the counter */
					counter=0;

					/* Whilst the current attribute datum is ok */
					while (counter<ctnoattributes) {
						/* Copy the data from the source tuple into the dest. tuple */	
						strcpy( tuple_d(nt,counter),tuple_d(ct,counter));	

						/* Increment the counter */
						counter++;
					}

					/* TODO - handle return code of write_tuple */
					(void) write_tuple(nt);
				} else {
					;
#ifdef FULL_DEBUG
	fprintf(stderr,"Tuple will **NOT** be written to disk\n");
#endif
				}

				/* Read the next tuple */
				(void) readnext_tuple(&ct,&ctfile,&ctnoattributes,TUPLE_BUILD);
			}

			destroy_condition(condition);
			condition=NULL;

			/* Return the resulting relation */
			return(rtrel);
		} else {
			/* Condition was messed up for some reason */
			return(NULL);
		}	
	} else {
		/* Relation created was null */
		/* Error is "handled" will be printed in above func. */
		return(NULL);
	}

}

relation rl_join( database db,
				relation lrel, relation rrel,
				char *qualification,
				char *destname) {
/* rl_join
 * The relational join operator. 
 * Returns NULL if fails, or ptr to a new relation 
 * IDEAS: Add parameter (or global var) to do join with natural or equi
 * join?
 * Uses nested loop algorithm, for now. Add additional operators,
 * and provide some system by which use can be determined by user.
 */

	relation rtrel;
	char *rname;
	char rel_name[RELATION_NAME_SIZE+1];
	tuple ltuple, rtuple, ntuple;
	FILE *ltfile, *rtfile;
	word lnoattributes, rnoattributes;
	condp condition=NULL;
	char spare_qualification[MAXIMUM_EXPRESSION]; /* Incase a qual. is not provided! */
	int lresult,rresult,count;

	/* Generate a relation name if one is not provided */
	if (strlen(destname)==0) {
		rname=generate_random_string(RELATION_NAME_SIZE,rel_name);
	} else {
		rname=destname;
	}	

	/* Create the relation */
	rtrel=relation_create_both( db, lrel, rrel, rname);

	/* Check the returned relation */
	if (rtrel!=NULL) {

		/* Build the default condition if appropriate */
		if (strlen(qualification)==0) {
			do_error(ERROR_NO_CONDITION,"No condition specified. Defaulting to an always TRUE condition.",NONFATAL);
			strcpy(spare_qualification,special_condition_true);
			qualification=spare_qualification;
		}

		/* Open the tuple in left source relation */
		ltuple=readfirst_tuple(lrel,&ltfile, &lnoattributes,TUPLE_BUILD,NULL);

		/* Open the right source relation */
		rtuple=readfirst_tuple(rrel,&rtfile, &rnoattributes,TUPLE_BUILD,NULL);

		/* Create the "output" tuple */
		ntuple=tuple_prepare_attributes(rtrel);
	
		/* Build the condition structure */
		condition=build_condition(qualification,ltuple,rtuple);

		lresult=0;

		/* Whilst there is a valid tuple in the left */
		while ( (condition!=NULL) && (ltuple!=NULL) && (lresult!=EOF) ) {

			/* Open the tuple in the right source relation */
			/* Note that the tuple must be REUSED, not BUILT, as this
			 * Would make the ptrs in the condition structure invald 
			 */
			rtuple=readfirst_tuple(rrel,&rtfile, &rnoattributes,TUPLE_REUSE,rtuple);
			rresult=0;

			/* Whilst there is a valid tuple in the right */
			while ( (rtuple!=NULL) && (rresult!=EOF) ) {


#ifdef FULL_DEBUG
	tuple_print(ltuple,FALSE);
	tuple_print(rtuple,FALSE);
#endif
				/* Evaluate the condition on the current tuple */
				if (evaluate( condition, ltuple, rtuple )==TRUE) {
#ifdef FULL_DEBUG
	fprintf(stderr,"Joined tuple will be written to disk\n");
#endif
						count=0;
						while (count<lnoattributes) {
							strcpy( tuple_d(ntuple,count),tuple_d(ltuple,count) );
							count++;
						}
						count=0;
						while (count<rnoattributes) {
							strcpy( tuple_d(ntuple,count+lnoattributes),tuple_d(rtuple,count) );
							count++;
						}
						(void) write_tuple(ntuple);
				} else {
#ifdef FULL_DEBUG
	fprintf(stderr,"Joined tuple will *NOT* be written to disk\n");
#endif
				}
				/* Whilst there is a valid tuple in the right */
				rresult=readnext_tuple(&rtuple,&rtfile,&rnoattributes,TUPLE_REUSE);
			}

			/* Whilst there is a valid tuple in the left */
			lresult=readnext_tuple(&ltuple,&ltfile,&lnoattributes,TUPLE_REUSE);
		}	

		return(rtrel);
	} else {
		return(NULL);	
	} 
}
