/* 
 * Name: util.c
 * Description: Utility Module - Contains all of the useful
 *		routines, and OS dependent stuff (where possible)
 * Version: $Id: util.c,v 1.19 1996/09/08 22:39:14 rleyton Exp rleyton $
 *
 *   LEAP - An extensible and free RDBMS
 *   Copyright (C) 1996 Richard Leyton
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   See the file COPYING for more information.
 *
 *   Richard Leyton, c/o 3.Pelting Drove, Priddy, WELLS, 
 *   Somerset, BA5 3BA. E-Mail: richard_leyton@mail.amsinc.com
 *   and/or e0190404@brookes.ac.uk. http://www.brookes.ac.uk/~e0190404/leap.html
 *
 */

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <signal.h>

/* These are needed for directory access */
#include <dirent.h>
#include <sys/types.h>

#include "dtypes.h"
#include "util.h"
#include "dbase.h"

/* The definitions that were declared in the header file */

/* Status flag */
boolean status=FALSE;

/* The error file */
char ERROR_FILE[FILE_PATH_SIZE];

/* The report file - for tracing */
FILE *REPORT_FILE;

/* LEAP Debug (different from compiler directive */
char LDEBUG=FALSE;

/* LEAP Trace */
char LTRACE=FALSE;

/* LEAP Timing */
char LTIMING=FALSE;

/*
 * Commands available - THEY MUST BE IN ALPHABETICAL ORDER
 * IN ORDER TO MAKE SEARCHING MORE EFFICENT (Binary chop
 * is used) (K&R again!)
 */
struct commands_struct commands[] = {
	{"!", C_DOS},
	{"#", C_COMMENT},
	{"?", C_HELP},
	{"@", C_SRCFILE},
	{"add", C_ADD},
	{"addresses", C_ADDRESSES},
	{"break", C_BREAK},
	{"cache", C_CACHE},
	{"case", C_CASE},
	{"change", C_CHANGE},
	{"clear", C_CLEAR},
	{"copying", C_INFO},
	{"create", C_CREATE},
	{"debug", C_DEBUG},	
	{"delete", C_DELETE},
	{"describe", C_DESCRIBE},
	{"difference", C_DIFFERENCE},
	{"dir", C_DIR},
	{"display", C_PRINT},
	{"dispose", C_DISPOSE},
	{"duplicate", C_DUPLICATE},
	{"erase", C_DELETE},
	{"exit", C_EXIT},
	{"flush", C_FLUSH},
	{"help", C_HELP},
	{"high", C_HIGH},
	{"idxprint", C_PRINT_IDX},
	{"idxstore", C_IDX_STORE},
	{"indexes", C_DISPLAY_INDEX},
	{"indices", C_DISPLAY_INDEX},
	{"infix", C_INFIX},
	{"intersect", C_INTERSECT},
	{"ioon", C_IOON},
	{"iterative", C_ITERATIVE},
	{"join", C_JOIN},
	{"l", C_LISTSRC},
	{"list", C_LIST},
	{"load", C_LOAD},
	{"mem", C_MEM},
	{"minus", C_DIFFERENCE},
	{"normal", C_NORMAL},
	{"panic", C_PANIC},
	{"parse", C_PARSE},
	{"print", C_PRINT},
	{"product", C_PRODUCT},
	{"project", C_PROJECT},
	{"prompt", C_PROMPT},
	{"quit", C_EXIT},
	{"rename", C_RENAME},
	{"report", C_REPORT},
	{"restrict", C_SELECT},
	{"rmvtmp", C_RMVTMP},
	{"select", C_SELECT},
	{"smjoin", C_SMJOIN},
	{"source", C_SRCFILE},
	{"sources", C_LIST},
	{"sp_help", C_DISPLAY_REL},
	{"specidx", C_IDX},
	{"status", C_STATUS},
	{"stop", C_EXIT},
	{"timing", C_TIMING},
	{"union", C_UNION},
	{"use", C_USE},
	{"ustime", C_US},
	{"ver", C_VERSION},
	{"version", C_VERSION},
	{"warranty", C_WARRANTY},
	{"what", C_WHAT}
};



/* Define the size of the above structure 
 * (See K&R 2nd Ed. pg 135 
 */
#define NKEYS (sizeof commands / sizeof commands[0])

void writeln(char *string) {
/* writeln
 * Writes a string to the output stream. Writes a newline.
 * Notes: Should call the output logger if this is to be
 *	run on DOS...?
 */
	printf("%s\n",string);
}

void write(char *string) {
/* write
 * Writes a string to the output stream. No newline.
 */
	printf("%s",string);
}

void util_close() {
/* util_close
 * Close files and stuff
 */
	int error;

	error=fclose(REPORT_FILE);

	/* If there was an error (unlikely), report it, but
 	 * carry on - we're shutting down anyway
	 */
	if (error==EOF) {
		do_error(ERROR_CLOSING_FILE,"Report file",NONFATAL);
	}
}

void special_error(short int error_num, char *string, short int fatality) {
/* special_error
 * Errors for which we don't have an error file, so these messages
 * are hardcoded, and this routine is generic to handle fatal and
 * non-fatal errors. 
 */
	char	error_message[80];

	switch(error_num) {
		case ERROR_FILE_NOT_FOUND:
			strcpy(error_message,"Cannot open error file");
			break;
		case ERROR_COMMAND_LINE:
			strcpy(error_message,"Command line contains unknown switch");
			break;
		default:
			strcpy(error_message,"An unknown error occured");
	}

	if (fatality==NONFATAL) {
		(void)fprintf(stderr,"NON-");
	}	

	(void)fprintf(stderr,"FATAL ERROR (%d): %s.\n%s%c\n",error_num,error_message,string,BEEP);

	if (fatality==FATAL) {
		(void)fprintf(stderr,"LEAP Terminated abnormally.\n");
#ifdef DEBUG
		raise(SIGTRAP);
#endif
		exit(1);
	}
}

void do_error(short int error_num, char *string, int fatality) {
/* do_error (13/04/1996)
 * This raises an error and possibly termiantes execution of
 * LEAP. 
 */

	FILE	*error_file;
	int 	file_error_number=0;
	char	error_line[90],*error_number_string,error_text[80],*read_status;
	char	*chptr,error_summary[170];

#ifdef FULL_DEBUG
	printf("DEBUG: Error file opened is: %s\n",ERROR_FILE);
#endif
	/* Open the error file for reading...*/
	error_file=fopen(ERROR_FILE,"r");

	/* Check it opened ok */
	if (error_file==NULL) {
		/* This is the only reason that the nonfatal 
		 * error handler will return a FATAL error... 
		 */
		special_error(ERROR_FILE_NOT_FOUND,ERROR_FILE,FATAL);
	} else {

		/* Read the first line from the file */
		read_status=fgets(error_line,sizeof(error_line),error_file);

		/* Whilst not at the end of the file, and we
		   haven't located our error yet */
		while ( (read_status!=NULL) && (file_error_number<error_num) ) {

#ifdef FULL_DEBUG
	/* This is for heavy debugs */
	printf("Read: %s",error_line);
#endif
		
			if (error_line[0]!='#') {	
				/* Get the error number */
				chptr=strchr(error_line,',');
				*chptr='\0';
				chptr++;

				error_number_string=error_line;

				/* We want to preserve the text */
				/* Gets the text ptr, and then copies it out */
				strcpy(error_text,chptr);

#ifdef FULL_DEBUG					
       	printf("This is error number %s\n",error_number_string);
	printf("With text: %s\n",error_text);	
#endif
	
				/* Convert it to an integer */
				sscanf(error_number_string,"%i",&file_error_number);
			}

			/* Get the next line */
			read_status=fgets(error_line,sizeof(error_line),error_file);
		}
	}

	/* If we've not been able to locate the error in the error
	 * file, then display a special message, with the same
	 * error number and text
	 */

	if (read_status==NULL) {
		strcpy(error_text,"Undefined Error\n");
	}

	/* Report the error */

	/* If its a nonfatal error, add the "non" prefix.*/
	if (fatality==NONFATAL) {
		fprintf(stderr,"NON-");
	}
	(void) fprintf(stderr,"FATAL ERROR (# %d):%s%s%c\n",error_num,error_text,string,BEEP);

	/* We don't want to log an error message about fetching the time
 	 * - this would occur every time, and recurse for ever...
	 * Make sure that any other errors raised by do_error are excluded
	 * in the same way! 
	 */
	if (error_num!=ERROR_TIME) {

		/* Strip out any carriage returns */

		/* Find the first one */
		chptr=strchr(error_text,'\n');

		/* Whilst there is a CR in the string */
		while (chptr!=NULL) {
			/* Replace it with a space */
			*chptr=' ';

			/* Find the next one in the string */
			chptr=strchr(error_text,'\n');
		}	

		sprintf(error_summary,"*** ERROR *** (%d): %s: %s",error_num,error_text,string);
		report(error_summary);
	}

	/* Close the error file */
	(void) fclose(error_file);

	/* If its a fatal error, die.*/
	if (fatality==FATAL) {
		fprintf(stderr,"LEAP terminated abnormally.\n");
		util_close();
#ifdef DEBUG
		/* Raise a signal to enable stack inspection */
		raise(SIGTRAP);
#endif

		/* Exit with a non-zero error. */
		/* 05.09.1996 - Changed to LEAP error code */
		exit(error_num);	
	}
}

void report(char *report_string) {
/* report
 * Report an accurance.
 * ANY ERRORS RAISED SHOULD BE EXCLUDED FROM DO_ERROR'S REPORTING
 * AS THIS WILL LEAD TO INFINITE RECURSION.
 */
	char atime[100];

	/* Fetch the time, and if something strange happens... */
	/* tp=time(NULL);
	if (&tp!=NULL) { */

		/* cptr=ctime(time(NULL));
		strcpy(atime,cptr);
		if (atime[strlen(atime)-1]=='\n') {
			atime[strlen(atime)-1]='\0';
		} */
		sprintf(atime,"TIME DISABLED");
		fprintf(REPORT_FILE,"%s\t%s\n",atime,report_string);
		fflush(REPORT_FILE);

	/* } else { */
		/* Something really strange has happened. This
		 * should never be reached in a working system,
		 * but you never know. Be graceful about it!
		 */
		/* do_error(ERROR_TIME,"util.report",FATAL);
	}*/
}

void util_init() {
/* util_init
 * This routine sets up any global variables for the utilities
 * unit, for example, the full path to the errors file, to
 * save work later.
 */
 char fname[FILE_PATH_SIZE];
 char counter;

 if (status) {
	write("LEAP Error file: ");
	writeln(ERROR_FILE);
 }
 /* Build the report file name */
 sprintf(fname,"%s%s%s",LEAP_BASE_DIR,LEAP_REPORT_DIR,LEAP_REPORT_FILE);
#ifdef FULL_DEBUG
 printf("(%d)<%s>\n",strlen(fname),fname);
#endif

 /* Attempt to open the file for appending */
 REPORT_FILE=fopen(fname,"a");

 /* If something stwange is afoot */
 if (REPORT_FILE==NULL) {
	/* Try again, but try to create it */
	REPORT_FILE=fopen(fname,"w");

	/* If that fails, then crash and die */
	if (REPORT_FILE==NULL) {
		do_error(ERROR_FILE_OPENING,fname,FATAL);
	} else {
		/* otherwise, put in a nice message */
		report("File Created.");
	}
 } else {
	/* Ok, start reporting again...*/
	for (counter=0;counter<80;counter++) fprintf(REPORT_FILE,"%c",'#');	

	fprintf(REPORT_FILE,"\n# File created\n");

	for (counter=0;counter<80;counter++) fprintf(REPORT_FILE,"%c",'#');	

	fprintf(REPORT_FILE,"\n");
	report("File appending started.");
 }

}

void upstring(char *string) {
/* upstring
 * Converts the string to an uppercase version
 */
	(*string)=(*string);
}

void check_assign(void *ptr, char *string) {
/* check_assign
 * Checks whether a pointer is assigned or not. If not, then
 * memory has probably run out.
 */
	if (ptr==NULL) {
		do_error(ERROR_INSUFFICENT_MEMORY,string,FATAL);
	} 
}


void do_trace(char *trace_string) {
/* do_trace
 * Reports something to the screen, and if set, to the report
 * file as well 
 */
	if (LTRACE) {
		if (LDEBUG) report(trace_string);
		fprintf(stderr,"%s\n",trace_string);
	}
}


char *cut_to_right_bracket( char *s,
			   int bdepth, int force,
			   char *result) {
/* cut_to_right_bracket
 * This should return a ptr to an expression contained
 * within the brackets of depth bdepth in *result and as result
 * new for new parser.
 * if force==TRUE then force brackets onto the string, else
 * don't - and return nothing if no brackets exist.
 */

	struct bracket {
		int pos,depth;
	} bracket[MAXIMUM_BRACKETS];

	boolean bexist=FALSE;
	int start,finish,counter,c,no,depth;
	char rstr[MAXIMUM_EXPRESSION],tstr[MAXIMUM_EXPRESSION];
	char *tstrp,*endstart,*beginning,*ostart;
	char removed[MAXIMUM_EXPRESSION];

	/* Check that the parameters are ok */
	if ( (s==NULL) || (strlen(s)==0) ) {
		strcpy(result,"");
		return(result);
	}

	/* Reset the data */		
	for (counter=0;counter<MAXIMUM_BRACKETS;counter++) bracket[counter].pos=bracket[counter].depth=0;
	
	bracket[0].pos=0;
	bracket[0].depth=1;
	bracket[1].pos=strlen(s)+1;
	bracket[1].depth=1;
	c=0;
	depth=1;
	no=0;

	while ( ((unsigned int) c) <=strlen(s)) {
		if (s[c]=='(') {
			bracket[no].pos=c;
			bracket[no].depth=depth;

			/* Increment the bracket 'depth' counter */
			depth++;

			/* Set the brackets-exist flag */
			bexist=TRUE;
			no++;
		}

		if (s[c]==')') {

			depth--;

			bracket[no].pos=c;
			bracket[no].depth=depth;
			no++;
		}

		c++;
	}

	/* If the specified depth is greater than the maximum depth
	 * of the brackets in the given string, then set the parameter
	 * to the maximum depth possible 
	 */
	if (bdepth>depth) {
		bdepth=depth;
	}

	/* If no brackets occur in the string */
	/* ...and they can be forced on */
	if ( (!bexist) && (force==TRUE) ) {
		/* Add 'em */
		/* sprintf(tstr,"(%s)",s); */

		/* Test... */
		strcpy(result,s);
		strcpy(s,"");

		return(result);
	
		/* And copy it back */
		strcpy(s,tstr);


	/* If no brackets occur in the string */
	/* ...but they cannot be forced on */
	} else if ( (!bexist) && (force==FALSE) ) {

		/* Return an empty string */
		strcpy(result,"\0");
		return(result);

	/* ELSE  brackets occur in the string, so
	 * carry on - brackets are there 
   	 */
	} else {
		strcpy(tstr,s);
	}

	ostart=tstr;

	strcpy(rstr,"");

	c=0;
	while (bracket[c].depth<bdepth) c++;
	
	start=c;

	c++;

	while (bracket[c].depth>bdepth) c++;
	finish=c;


	/* tstr still contains s - so it can be played with */	
	tstr[(bracket[finish].pos)]='\0';
	tstrp=&tstr[(bracket[start].pos)+1];
	strcpy(result,tstrp);

	/* This puts a null at bracket point */
	tstrp=&tstr[(bracket[start].pos)];
	*tstrp='\0';

	/* This gets the start of the string after the bracket */
	endstart=&tstr[(bracket[finish].pos)+1];
	beginning=ostart;

	/* And this puts the beginning and end bits together, to
	 * give a string without the bracketed bit
	 */
	sprintf(removed,"%s%s",beginning,endstart);
	strcpy(s,removed);
#ifdef DEBUG
	printf("Retrieved: >%s<\n",result);
#endif	
	return(result);	
}

char *get_token(char *string,
	        char seperator,
		char *result) {
/* get_token
 * Gets the first token from the string, and returns
 * it (in result, and as a result)
 */
	char seperator_list[MAX_SEPERATORS];
	char *rptr;

	/* If sepereator is NULL, then use the normal seperators */
	if (seperator=='\0') {
		strcpy(seperator_list,TOKEN_SEPERATORS);
	} else {
		/* Otherwise, use the character specified */
		sprintf(seperator_list,"%c",seperator);
	}
	/* Copy the original string into "result" */
	strcpy(result,string);

	/* Locate the first symbol - strtok puts a null at
 	 * the location of the seperator, so we can then return
	 * the string, with the first item located. strtok returns
	 * NULL if no seperator is found. 
	 */
	rptr=strtok(result,seperator_list);

	/* If there is no token, then make the string empty */
	/* (Can't return NULL, incase used in strcpy) */
	if (rptr==NULL) result[0]='\0';

	/* Return the result */
	return(result);

}	

char *cut_token(char *string,
	        char seperator,
		char *result) {
/* get_token
 * Cuts the first token from the string, and returns
 * it (in result, and as a result)
 */
	char seperator_list[MAX_SEPERATORS];
	char *rptr;
	size_t length;

	/* If sepereator is NULL, then use the normal seperators */
	if (seperator=='\0') {
		strcpy(seperator_list,TOKEN_SEPERATORS);
	} else {
		/* Otherwise, use the character specified */
		sprintf(seperator_list,"%c",seperator);
	}
	/* Copy the original string into "result" */
	strcpy(result,string);

	/* Locate the first symbol - strtok puts a null at
 	 * the location of the seperator, so we can then return
	 * the string, with the first item located. strtok returns
	 * NULL if no seperator is found. 
	 */
	rptr=strtok(result,seperator_list);

	/* If there is no token, then make the string empty */
	/* (Can't return NULL, incase used in strcpy) */
	if (rptr==NULL) {
		result[0]='\0';
	} else {
		/* Get the length of the first token, to 
		 * indicate where the seperator may be found 
		 */
		length=strlen(rptr);

		/* Copy into the source string the remainder,
		 * so that the string is "cut" out
		 */

		/* BUT first, skip over any spaces... They're never
		 * going to be any use */
		while (string[length]==' ') {
			length++;
		}

		strcpy(string,&string[length]);
	}

	/* Return the result */
	return(result);

}	

int binsearch(char *word, struct commands_struct commands[], int n) {
	int cond;
	int low, high, mid;

	low=0;
	high=n-1;

	while (low <= high) {
		mid=(low+high)/2;
		if ( (cond = strcmp(word, commands[mid].text)) < 0)
			high=mid-1;
		else if (cond>0)
			low=mid+1;
		else
			return mid;
	}
	return -1;
}

int get_command(char *word) {
	int result;
	int counter=0;

	/* skip over spaces */
	while (word[counter]==' ') counter++;
	word=&word[counter];

	result=binsearch(word,commands,NKEYS);

	if (result!=C_UNKNOWN) {
		return( commands[result].command );
	} else {
		return( C_UNKNOWN );
	}
}

void assign_input_stream( char *filen ) {
/* assign_input_stream
 * This is used to assign the input stream (input_stream)
 * declared as extern in dtypes, and in the main module, to
 * the specified file. If empty, then the file is reset to stdin.
 */
	char temp[100];


	if (strlen(filen)==0) {
		do_trace("Setting source file to stdin.");
		input_stream=stdin;
	} else {
		sprintf(temp,"Setting source file to %s.",filen);
		do_trace(temp);
		input_stream=fopen(filen,"r");
		if (input_stream==NULL) {
			input_stream=stdin;
			do_error(ERROR_FILE_OPENING,filen,NONFATAL);
			writeln("Resetting input file to stdin");
		}
	}
}

char *find_start_of_data( char *string) {
/* Scans over a string, and locates the first text. */
	char *sptr;

	/* Start at the start! */
	sptr=string;

	/* Whilst the string is not null, and
	 * not equal to a character 
	 */
	while ( (*sptr!='\0') &&
		(    ( (*sptr<'A') || (*sptr>'Z') )
                  && ( (*sptr<'a') || (*sptr>'z') )
		) ) {

		/* Skip over to the next pointer */
		sptr++;

	}

	/* If we have found the end of the string... */
	if (*sptr=='\0') {
		
		/* Return a NULL string */
		return(NULL);
	} else {

		/* Otherwise, return the start of the data */
		return(sptr);
	}

}

void list_source_code( ) {
/* list_source_code
 * Prints out the source files in a database.
 */

	struct dirent *d;
	DIR *directory;
	char dirpath[FILE_PATH_SIZE],filename[FILE_PATH_SIZE],*cptr;

	/* Build the directory path */
	sprintf(dirpath,"%s%s",database_dir(current_db),LEAP_SOURCE_DIR);

	/* Open the directory */
	directory=opendir(dirpath);

	/* Read the first entry */
	d=readdir(directory);

	writeln("Source files:");
	writeln("-------------");

	/* Whilst there are directory entries to process */	
	while (d!=NULL) {

		/* Check if the entry contains the extension signifying
		 * it's a source file 
		 */
		if (strstr(d->d_name,LEAP_SOURCE_EXT)!=NULL) {
			/* Make a copy of the filename, so we don't
			 * risk messing up things out of our control
			 */ 
			strcpy(filename,d->d_name);

			/* Terminate where the extension starts */
			cptr=strstr(filename,LEAP_SOURCE_EXT);
			*cptr='\0';

			writeln(filename);
		}

		/* Read the next directory entry */
		d=readdir(directory);
	}

	writeln("--------");
}

void print_source_code( char *file_name ) {
/* print_source_code
 * Prints the specified source file name. Assumes the .src extension
 * is not specified.
 */
	char dirpath[FILE_PATH_SIZE],source_line[MAXIMUM_EXPRESSION];
	char *read_status;
	FILE *fptr;
	int x;

	/* Build the directory path */
	sprintf(dirpath,"%s%s%s%s",database_dir(current_db),LEAP_SOURCE_DIR,file_name,LEAP_SOURCE_EXT);

	/* Open the file */
	fptr=fopen(dirpath,"r");

	/* If the file could not be found */
	if (fptr==NULL) {
			/* Report an error */
			do_error(ERROR_FILE_OPENING,file_name,NONFATAL);
	} else {

		/* No error occured - so read the first line */
		read_status=fgets(source_line,MAXIMUM_EXPRESSION,fptr);

		if (read_status!=NULL) {
			printf("Source File: %s\n",file_name);
			printf("-------------");
			for (x=0; x<strlen(file_name); x++) printf("-"); 		
			printf("\n");
		}

		/* Whilst no error occurs reading from the file */
		while( read_status!=NULL ) {
			
			/* Display the current line */
			/* Includes cr, so skip that and use write */
			write(source_line);

			/* Get the next line */
			read_status=fgets(source_line,MAXIMUM_EXPRESSION,fptr);
		}
		writeln("<EOF>");
	}
}
