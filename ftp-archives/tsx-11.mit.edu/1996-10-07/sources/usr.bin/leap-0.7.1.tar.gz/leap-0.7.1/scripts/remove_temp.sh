#!/bin/sh

cd /home/rleyton/leap/database/testdb/relation
rm l*

