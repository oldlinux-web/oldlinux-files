#!/bin/sh

# Run the LEAP regression tests.

function start_test() {
	echo "********************************************************************************">> $OUTFILE
	echo "* $1">> $OUTFILE
	echo "********************************************************************************">> $OUTFILE
}

if [ ! -f dtypes.h ]
then
	echo "The LEAP Regression tests need to be run in the"
	echo "LEAP source directory!"
	exit 1
fi
# Header info, so that maintainer knows where you are
# coming from.
OUTFILE=/tmp/regression.$$
echo "LEAP Regression tests - Output to $OUTFILE"
echo "LEAP Regression tests" >>$OUTFILE
echo "Run by: `whoami`" >>$OUTFILE
echo "On a  : `uname -a`" >>$OUTFILE
echo "On    : `date`" >>$OUTFILE
echo  >>$OUTFILE
echo "LEAP Version (dtypes): `grep "LEAP_VERSION " dtypes.h|awk '{print $3}'`">>$OUTFILE
echo>>$OUTFILE

# Perform start stop test.
start_test "Start: START/STOP"
echo "quit" | leap &> /dev/null >> $OUTFILE 
echo "*** Return Code: $?" >> $OUTFILE
start_test "End: START/STOP" 
