vi ~/leap/report/report.txt
