#!/bin/sh

./remove_temp.sh

cd /home/rleyton/leap/database/testdb/relation
rm *.hsh

