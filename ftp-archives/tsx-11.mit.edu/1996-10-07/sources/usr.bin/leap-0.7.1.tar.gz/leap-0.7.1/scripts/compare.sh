#!/bin/sh

for file in `ls RCS/*` 
do
	rcsdiff $file >& out.$$
	if [ $? != 0 ] 
	then
		echo "Differences in $file"
	else
		echo "No differences in $file"
	fi
done
rm out.$$
