#/bin/sh

while true do
	echo "quit" | ../leap
done
