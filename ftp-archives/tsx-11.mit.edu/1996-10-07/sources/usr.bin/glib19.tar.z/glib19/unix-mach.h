/* $Id: unix-mach.h,v 1.6 89/05/06 17:13:46 lee Exp $
 * GLIB - a Generic LIBrarian and editor for synths
 *
 * Machine dependent stuff.
 *
 * Unix version
 * Tim Thompson
 * $Log:	unix-mach.h,v $
 * Revision 1.6  89/05/06  17:13:46  lee
 * rel. to comp.sources.misc
 * 
 */

#define INT16 int

#define STATMIDI (statmidi())
#define UNIX
