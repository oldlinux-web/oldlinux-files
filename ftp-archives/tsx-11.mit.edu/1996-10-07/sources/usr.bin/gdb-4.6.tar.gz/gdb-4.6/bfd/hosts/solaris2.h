/* Solaris-2 host system */

#include "hosts/sysv4.h"

/* That's all... */
