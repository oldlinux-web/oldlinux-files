/* Definitions to make GDB run on a vax under Ultrix. */

#include "xm-vax.h"
extern char *strdup();
