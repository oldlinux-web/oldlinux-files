/* Output from p2c, the Pascal-to-C translator */
/* From input file "M2Search.md" */


#include <p2c/p2c.h>


#define M2SearchG
#include "M2Search.h"



/*
   Title:FileSystem, allows simple use of files.
   Version:V1.0
   Date:Wednesday 22/1/86
   LastEdit:Tue Oct 17 16:04:00 BST 1989
   Author:Gaius Mulley
                Reading University

   FileSystem - another layer above the UnixStdIO, hides
   streams and select streams etc. It allows the user to Open and
   Close a File. Also allows simple character IO to/from files
   as well as allowing Record Structures to be written and read
   to/from files and default IO.

   Could be improved by adding an EOF() function, thus allowing
   File to be implemented as a 'Hidden Type'.

   Tue Oct 17 16:04:23 BST 1989 - made the FileSystem compatible with
                                  Logitech FileSystem.
                                - prefer to take the aproach as above
                                  but this means that the Logitech version
                                  needs to be altered.
*/


#ifndef FileSystemH
#include "FileSystem.h"
#endif

#ifndef StrLibH
#include "StrLib.h"
#endif

#ifndef StdIOH
#include "StdIO.h"
#endif

#ifndef StrIOH
#include "StrIO.h"
#endif

#ifndef CmdArgsH
#include "CmdArgs.h"
#endif

#ifndef M2DefaultsH
#include "M2Defaults.h"
#endif


#define MaxStringLen    79

#define Directory       "/"


Static Char Main[MaxStringLen + 1];
Static Char SearchPath[1001];


/* %%%FORWARD%%% */

Static void WriteFileName(const long FileName_LOW, const long FileName_HIGH,
			  Char *FileName);

Static P2C_BOOLEAN Exists(const long FileName_LOW, const long FileName_HIGH,
			  Char *FileName);

Static void Init(void);


/* %%%FORWARD%%% */

/*
   FindSourceFile - attempts to locate the source file FileName.
                    If a file is found then TRUE is returned otherwise
                    FALSE is returned.
                    The parameter FullPath is set which indicates the
                    absolute location of source FileName.

*/

P2C_BOOLEAN M2Search_FindSourceFile(const long FileName_LOW,
  const long FileName_HIGH, Char *FileName, const long FullPath_LOW,
  const long FullPath_HIGH, Char *FullPath)
{
  unsigned long i, n;
  char CopyOfFileName[1000];

  strcpy(CopyOfFileName, FileName);
  n = CmdArgs_Narg(0L, 1000L, SearchPath);
  i = 0;
  while (i < n) {
    if (CmdArgs_GetArg(0L, 1000L, SearchPath, i, 0L,
		       FullPath_HIGH - FullPath_LOW, FullPath)) {
      if (StrLib_StrEqual(1L, 1L, ".", FullPath))
	StrLib_StrCopy(0L, FileName_HIGH - FileName_LOW, CopyOfFileName, 0L,
		       FullPath_HIGH - FullPath_LOW, FullPath);
      else {
	StrLib_StrConCat(0L, FullPath_HIGH - FullPath_LOW, FullPath,
			 Directory, 0L, FullPath_HIGH - FullPath_LOW,
			 FullPath);
	StrLib_StrConCat(0L, FullPath_HIGH - FullPath_LOW, FullPath, CopyOfFileName,
			 0L, FullPath_HIGH - FullPath_LOW, FullPath);
      }
      if (Exists(0L, FullPath_HIGH - FullPath_LOW, FullPath))
	return P2C_TRUE;
    }
    i++;
  }
  return P2C_FALSE;
}


#define MaxSpaces       20


/*
   WriteFileName - displays a file name, FileName, with formatted spaces
                   after the string.
*/

Static void WriteFileName(const long FileName_LOW, const long FileName_HIGH,
			  Char *FileName)
{
  unsigned long i, High;

  StrIO_WriteString(0L, FileName_HIGH - FileName_LOW, FileName);
  High = StrLib_StrLen(0L, FileName_HIGH - FileName_LOW, FileName);
  if (High >= MaxSpaces)
    return;
  High = MaxSpaces - High;
  i = 0;
  while (i < High) {
    StdIO_Write(' ');
    i++;
  }
}

#undef MaxSpaces


/*
   SetSearchPath - assigns the search path to Path.
                   The string Path may take the form:

                   Path           ::= IndividualPath { " " IndividualPath }
                   IndividualPath ::= "." | DirectoryPath
                   DirectoryPath  ::= Name { "/" Name }
                   Name           ::= Letter { (Letter | Number) }
                   Letter         ::= A..Z | a..z
                   Number         ::= 0..9
*/

void M2Search_SetSearchPath(const long Path_LOW, const long Path_HIGH,
			    Char *Path)
{
  StrLib_StrCopy(0L, Path_HIGH - Path_LOW, Path, 0L, 1000L, SearchPath);
}


/*
   Exists - returns true if file, FileName, exists.
*/

Static P2C_BOOLEAN Exists(const long FileName_LOW, const long FileName_HIGH,
			  Char *FileName)
{
  FileSystem_File f;

  FileSystem_Lookup(&f, 0L, FileName_HIGH - FileName_LOW, FileName, P2C_FALSE);
  if (f.res == FileSystem_done) {
    FileSystem_Close(&f);
    return P2C_TRUE;
  } else {
    FileSystem_Close(&f);
    return P2C_FALSE;
  }
}


/*
   Init - initializes the search path to '.'.
*/

Static void Init(void)
{
  M2Defaults_GetSearchPath(0L, 1000L, SearchPath);
  if (StrLib_StrLen(0L, 1000L, SearchPath) == 0)
	/* Default to current directory */
	  StrLib_StrCopy(1L, 1L, ".", 0L, 1000L, SearchPath);
}


void _M2_M2Search_init(void)
{
  static int _was_initialized = 0;
  if (_was_initialized++)
    return;
  Init();
}
/* p2c: Note: Remember to call _M2Search_init() in main program [215] */



/* End. */
