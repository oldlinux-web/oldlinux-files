/* Output from p2c, the Pascal-to-C translator */
/* From input file "Lists.md" */


/*
   Author     : Gaius Mulley
   Title      : Lists
   Date       : Tue Dec 12 20:53:36 EST 1989
   SYSTEM     : UNIX SUN and Logitech M2
   Description: Provides an unordered list manipulation package.
   Last update: $Date: 1996/07/26 11:48:19 $
   Version    : $Revision: 1.2 $
*/

/*
   Log        : $Log: Lists.c,v $
   Log        : Revision 1.2  1996/07/26 11:48:19  gaius
   Log        : error reporting improved and many bugfixes made. The compiler now
   Log        : generally points to the symbol in error. Many modules now use
   Log        : the WriteErrorFormat1 or its varient (pseudo printf style).
   Log        :
   Log        : Found a bug in the case handling, which was somehow was introduced..
   Log        :
   Log        : Added M2Constants which allow for constant comparison, really
   Log        : helps M2SubExp reduce the number of quadruples. 12%..15% on average code.
   Log        : Speed improvements of up to 25% on the compiler..
   Log        :
   Log        : Common subexpression elimiation is now included when -O is present.
   Log        : -Ocse turns it off.
   Log        :
   Log        : Revision 1.1.1.1  1996/05/28 10:13:05  gaius
   Log        : Modula-2 compiler sources imported
   Log        :
*/


#include <p2c/p2c.h>


#define ListsG
#include "Lists.h"


#ifndef StorageH
#include "Storage.h"
#endif

#ifndef SymbolKeyH
#include "SymbolKey.h"
#endif


#define MaxNoOfElements  5


typedef struct list {
  unsigned long NoOfElements;
  unsigned long Elements[MaxNoOfElements];
  struct list *Next;
} list;

/* %%%FORWARD%%% */


/* %%%FORWARD%%% */

/*
   InitList - creates a new list, l.
*/

void Lists_InitList(void **l)
{
  list *WITH;

  *l = Malloc(sizeof(list));
  if (*l == NULL)
    _OutMem();
  if (*l == NULL)
    _NilCheck();
  WITH = (list *)*l;
  WITH->NoOfElements = 0;
  WITH->Next = NULL;
}


/*
   KillList - deletes the complete list, l.
*/

void Lists_KillList(void **l)
{
  if (*l == NULL)
    _NilCheck();
  if (((list *)(*l))->Next != NULL) {
    if (*l == NULL)
      _NilCheck();
    Lists_KillList((void **)&(((list *)(*l))->Next));
  }
  Free(*l);
}


/*
   PutItemIntoList - places a CARDINAL, c, into list, l.
*/

void Lists_PutItemIntoList(void *l, unsigned long c)
{
  list *WITH;

  if (l == NULL)
    _NilCheck();
  WITH = (list *)l;
  if (WITH->NoOfElements < MaxNoOfElements) {
    WITH->Elements[WITH->NoOfElements] = c;
    WITH->NoOfElements++;
    return;
  }
  if (WITH->Next != NULL) {
    Lists_PutItemIntoList(WITH->Next, c);
  } else {
    Lists_InitList((void **)&WITH->Next);
    Lists_PutItemIntoList(WITH->Next, c);
  }
}


/*
   GetItemFromList - retrieves the nth CARDINAL from list, l.
*/

#if !defined(ITERATIVE)
/* prefered solution - recursive retrieve element algorithm */

unsigned long Lists_GetItemFromList(void *l, unsigned long n)
{
  list *WITH;

  if (n > Lists_NoOfItemsInList(l))
    return 0;
  else {
    if (l == NULL)
      _NilCheck();
    WITH = (list *)l;
    if (n <= WITH->NoOfElements) {
      return (WITH->Elements[n - 1]);
    } else {
      return (Lists_GetItemFromList(WITH->Next, n - WITH->NoOfElements));
    }
  }
}

#else
/* iterative solution */

unsigned long Lists_GetItemFromList(void *l, unsigned long n)
{
  list *WITH;

  while (l != NULL) {
     WITH = (list *)l;
     if (n <= WITH->NoOfElements) {
	 return (WITH->Elements[n - 1]);
     } else {
	 n -= WITH->NoOfElements;
     }
     l = WITH->Next;
  }
  return 0;
}
#endif


/*
   GetIndexOfList - returns the index for CARDINAL, c, in list, l.
                    If more than one CARDINAL, c, exists the index
                    for the first is returned.
*/

unsigned long Lists_GetIndexOfList(void *l, unsigned long c)
{
  unsigned long i;
  list *WITH;

  if (l == NULL)
    return 0;
  else {
    if (l == NULL)
      _NilCheck();
    WITH = (list *)l;
    i = 0;
    while (i < WITH->NoOfElements) {
      if (WITH->Elements[i] == c) {
	return i;
      }
      i++;
    }
    return (WITH->NoOfElements + Lists_GetIndexOfList(WITH->Next, c));
  }
}


/*
   NoOfItemsInList - returns the number of items in list, l.
*/

#if !defined(ITERATIVE)
/* prefered solution - a recusrive element count */

unsigned long Lists_NoOfItemsInList(void *l)
{
  list *WITH;

  if (l == NULL)
    return 0;
  else {
    if (l == NULL)
      _NilCheck();
    WITH = (list *)l;
    return (WITH->NoOfElements + Lists_NoOfItemsInList(WITH->Next));
  }
}

#else

/*
   NoOfItemsInList - returns the number of items in list, l.
                     (iterative solution of the above algorithm).
*/

unsigned long Lists_NoOfItemsInList(void *l)
{
  list *WITH;
  unsigned long t;

  if (l == NULL)
    return 0;
  else {
    t = 0;
    do {
       WITH = (list *)l;
       t += WITH->NoOfElements;
       l = WITH->Next;
    } while (l != NULL);
    return( t );
  }
}
#endif


/*
   IncludeItemIntoList - adds a CARDINAL, c, into a list providing
                         the value does not already exist.
*/

void Lists_IncludeItemIntoList(void *l, unsigned long c)
{
  if (!Lists_IsItemInList(l, c))
    Lists_PutItemIntoList(l, c);
}


/*
   IsItemInList - returns true if a CARDINAL, c, was found in list, l.
*/

P2C_BOOLEAN Lists_IsItemInList(void *l, unsigned long c)
{
  unsigned long i;
  list *WITH;

  do {
    if (l == NULL)
      _NilCheck();
    WITH = (list *)l;
    i = 0;
    while (i < WITH->NoOfElements) {
      if (WITH->Elements[i] == c) {
	return P2C_TRUE;
      }
      i++;
    }
    if (l == NULL)
      _NilCheck();
    l = (void *)((list *)l)->Next;
  } while (l != NULL);
  return P2C_FALSE;
}


/*
   RemoveItem - remove an element at index, i, from the list data type.
*/

Static void RemoveItem(list *p, list *l, unsigned long i)
{
  list *WITH;

  WITH = (list *)l;
  WITH->NoOfElements--;
  while (i < WITH->NoOfElements) {
    WITH->Elements[i] = WITH->Elements[i+1];
    i++;
  }
  if ((WITH->NoOfElements == 0) && (p != NULL)) {
    p->Next = l->Next;
    free(l);
  }
}


/*
   RemoveItemFromList - removes a CARDINAL, c, from a list.
                        It assumes that this value only appears once.
*/

void Lists_RemoveItemFromList(void *l, unsigned long c)
{
  unsigned long i;
  P2C_BOOLEAN Found;
  list *p;
  unsigned long j;
  list *WITH;

  if (l != NULL) {
    Found = P2C_FALSE;
    p = NULL;
    do {
      WITH = (list *)l;
      i = 0 ;
      while ((i<WITH->NoOfElements) && (WITH->Elements[i] != c)) {
	i++;
      }
      if ((i<WITH->NoOfElements) && (WITH->Elements[i] == c)) {
	Found = P2C_TRUE;
      } else {
	p = (list *)l;
	l = WITH->Next;
      }
    } while ((l != NULL) && (Found == P2C_FALSE));
    if (Found == P2C_TRUE) {
      RemoveItem(p, l, i);
    }
  }
}


/*
   ForeachItemInListDo - calls procedure, P, foreach item in list, l.
*/

void Lists_ForeachItemInListDo (void *l, void (*P)(unsigned long))
{
  unsigned long i, n;

  n = Lists_NoOfItemsInList(l);
  i = 1;
  while (i <= n) {
    P(Lists_GetItemFromList(l, i));
    i++;
  }
}


void _M2_Lists_init(void)
{
}
/* p2c: Note: Remember to call _Lists_init() in main program [215] */



/* End. */
