/* Output from p2c, the Pascal-to-C translator */
/* From input file "M2Alias.md" */


/*
    Title      : M2Alias
    Author     : Gaius Mulley
    System     : UNIX (gm2)
    Date       : Thu May 18 10:31:38 1995
    Last edit  : Thu May 18 10:31:38 1995
    Description: provides an alias mechanism for the Modula-2 symbols.
*/


/*
   Author     : Gaius Mulley
   Title      : SymbolTable
   Date       : 7/3/87
   Description: SymbolTable provides the higher level routines to
                maintain a symbol table for the Modula-2 Compiler.
   Last update: 23/5/87
*/


#include <p2c/p2c.h>


#define M2AliasG
#include "M2Alias.h"

#ifndef M2DebugH
#include "M2Debug.h"
#endif

#ifndef M2LexicalH
#include "M2Lexical.h"
#endif

#ifndef StorageH
#include "Storage.h"
#endif

#ifndef SymbolTableH
#include "SymbolTable.h"
#endif

#ifndef M2GenDyn486H
#include "M2GenDyn486.h"
#endif

#ifndef StdIOH
#include "StdIO.h"
#endif

#ifndef StrIOH
#include "StrIO.h"
#endif


#define NulSym          0
#define MaxSyms         100


/*
   AList has two main components: List and Syms.

         List is contains the alias through its pairing of indices in
              the To and From fields.

         Syms contains the actual symbols that the List indices reference
              together with their mode.
*/


typedef struct Alias {
  unsigned long From, To;   /* index into syms, showing the alias        */
} Alias;

typedef struct Symbol {
  SymbolTable_ModeOfAddr Mode;
      /* what mode of addressing does symbol use?  */
  unsigned long Id;   /* symbol value from SymbolTable.mod         */
  P2C_BOOLEAN Dirty;   /* have we written to this symbol yet?       */
  unsigned long Count;   /* number of times used (read and write)     */
} Symbol;

typedef struct AList {
  Alias List[M2Alias_MaxAlias];
  unsigned long AliasPtr;   /* points to the top of the List array       */
  Symbol Syms[MaxSyms];
  unsigned long SymPtr;   /* points to the top of the Syms array       */
  struct AList *Next;   /* used to store old lists on the free queue */
} AList;


Static AList *FreeList;


/* %%%FORWARD%%% */
Static void PutAlias(AList *a, unsigned long f, unsigned long t);

Static unsigned long GetSym(AList *a, unsigned long Sym,
			    SymbolTable_ModeOfAddr m);

Static void AddTo(const long a_LOW, const long a_HIGH, unsigned long *a,
		  unsigned long *High, unsigned long s);

Static void CollectAlias(AList *a, const long g_LOW, const long g_HIGH,
			 unsigned long *g, unsigned long *High,
			 unsigned long s);

Static void CombineAlias(AList *a, unsigned long f, unsigned long t);


/* %%%FORWARD%%% */


/*
   DumpAliases -
*/

void M2Alias_DumpAliases(AList *a)
{
  M2Alias_AliasType al[M2Alias_MaxAlias + 1];
  M2Alias_AliasType b[M2Alias_MaxAlias + 1];
  unsigned long i, j, n, m;

  StrIO_WriteLn();
  StrIO_WriteString(1L, 10L, "Alias dump");
  StrIO_WriteLn();
  n = M2Alias_CollectAllAliases(a, 0L, (long)M2Alias_MaxAlias, al);
  i = 0;
  while (i < n) {
    m = M2Alias_CollectAliases(a, 0L, (long)M2Alias_MaxAlias, b, al[i].Sym,
			       al[i].Mode);
    M2GenDyn486_WriteSymbol(al[i].Sym, al[i].Mode);
    if (M2Alias_IsDirty(a, al[i].Sym, al[i].Mode))
      StrIO_WriteString(1L, 5L, "{d}: ");
    else
      StrIO_WriteString(1L, 5L, "{c}: ");
    j = 0;
    while (j < m) {
      M2GenDyn486_WriteSymbol(b[j].Sym, b[j].Mode);
      if (M2Alias_IsDirty(a, b[j].Sym, b[j].Mode))
	StrIO_WriteString(1L, 4L, "{d} ");
      else
	StrIO_WriteString(1L, 4L, "{c} ");
      j++;
    }
    StrIO_WriteLn();
    i++;
  }
}


/*
   CheckConsistancy -
*/

Static void CheckConsistancy(AList *a)
{
  M2Alias_AliasType al[M2Alias_MaxAlias + 1];
  M2Alias_AliasType b[M2Alias_MaxAlias + 1];
  P2C_BOOLEAN found;
  unsigned long i, j, n, m;

  n = M2Alias_CollectAllAliases(a, 0L, (long)M2Alias_MaxAlias, al);
  i = 0;
  while (i < n) {
    if (M2Alias_IsDirty(a, al[i].Sym, al[i].Mode)) {
      m = M2Alias_CollectAliases(a, 0L, (long)M2Alias_MaxAlias, b, al[i].Sym,
				 al[i].Mode);
      j = 0;
      found = P2C_FALSE;
      while (j < m && !found) {
	if (M2Alias_IsClean(a, b[j].Sym, b[j].Mode))
	  found = P2C_TRUE;
	j++;
      }
      if (!found) {
	M2GenDyn486_WriteSymbol(al[i].Sym, al[i].Mode);
	StrIO_WriteString(1L, 18L, " cannot be cleaned");
	StrIO_WriteLn();
	M2Alias_DumpAliases(a);
/* p2c: M2Alias.md, line 139:
 * Warning: Symbol '__FILE__' is not defined [221] */
/* p2c: M2Alias.md, line 139:
 * Warning: Type mismatch for conformant array [298] */
/* p2c: M2Alias.md, line 139:
 * Warning: Symbol '__LINE__' is not defined [221] */
	M2Lexical_InternalError(1L, 28L, "problem with non clean alias", 0, 0,
				__FILE__, __LINE__);
      }
    }
    i++;
  }
}


/*
   Init - initializes module data structures.
*/

Static void Init(void)
{
  FreeList = NULL;
}


/*
   New - creates a new AliasList entity either from the heap or from the, FreeList.
*/

Static AList *New(void)
{
  AList *a;

  if (FreeList == NULL) {
    a = Malloc(sizeof(AList));
    if (a == NULL)
      _OutMem();
  } else {
    a = FreeList;
    FreeList = ((FreeList != NULL) ? FreeList : (AList *)_NilCheck())->Next;
  }
  M2Debug_Assert(a != NULL);
  return a;
}


/*
   InitAlias - creates a new empty AliasList and returns it.
*/

void *M2Alias_InitAlias(void)
{
  AList *a, *WITH;

  a = New();
  WITH = (a != NULL) ? a : (AList *)_NilCheck();
  WITH->AliasPtr = 0;
  WITH->SymPtr = 0;
  return a;
}


/*
   KillAlias - destroys an AliasList.
*/

void *M2Alias_KillAlias(void *a)
{
  struct AList *b = (struct AList *) a ;

  b->Next = FreeList ;
  FreeList = b;
  return NULL;
}


/*
   DuplicateAlias - duplicates an AliasList and returns the duplicate.
*/

void *M2Alias_DuplicateAlias(void *a)
{
  AList *b;
  unsigned long i;
  AList *aa= (AList *)a;

  b = New();
  /* it may well be faster simply to perform b^ := a^ ?? */
  i = ((aa != NULL) ? aa : (AList *)_NilCheck())->AliasPtr;
  ((b != NULL) ? b : (AList *)_NilCheck())->AliasPtr = i;
  while (i > 0) {
    memcpy(&((b != NULL) ? b : (AList *)_NilCheck())->List[i - 1],
	   &((aa != NULL) ? aa : (AList *)_NilCheck())->List[i], sizeof(Alias));
    i--;
  }
  i = ((aa != NULL) ? aa : (AList *)_NilCheck())->SymPtr;
  ((b != NULL) ? b : (AList *)_NilCheck())->SymPtr = i;
  while (i > 0) {
    memcpy(&((b != NULL) ? b : (AList *)_NilCheck())->Syms[i - 1],
	   &((aa != NULL) ? aa : (AList *)_NilCheck())->Syms[i], sizeof(Symbol));
    i--;
  }
  return b;
}


/*
   AliasSymbol - alias a symbol [FromSymbol, FromMode] -> [ToSymbol, ToMode]
*/

void M2Alias_AliasSymbol(void *a, unsigned long FromSymbol,
  SymbolTable_ModeOfAddr FromMode, unsigned long ToSymbol,
  SymbolTable_ModeOfAddr ToMode)
{
  unsigned long t, f;

  if (FromSymbol == ToSymbol && FromMode == ToMode)
    return;
  f = GetSym(a, FromSymbol, FromMode);
  t = GetSym(a, ToSymbol, ToMode);
  PutAlias(a, f, t);
}


/*
   PutAlias - places an alias between symbol id, f, to symbol id, t.
              f -> t
*/

Static void PutAlias(AList *a, unsigned long f, unsigned long t)
{
  unsigned long o, i;
  AList *WITH;
  Alias *WITH1;

  if (f == t)
    return;
  i = 1;
  o = 0;
  WITH = (a != NULL) ? a : (AList *)_NilCheck();
  while (i <= WITH->AliasPtr) {
    if (WITH->List[i - 1].From == f && WITH->List[i - 1].To == t) {
      /* found alias - we dont want another alias so we */
      return;
    }
    if (o == 0 && WITH->List[i - 1].From == NulSym &&
	WITH->List[i - 1].To == NulSym)
      o = i;
    i++;
  }
  /* alias not found - we will create a new one */
  if (o == 0) {
    WITH->AliasPtr++;
    if (WITH->AliasPtr > M2Alias_MaxAlias) {
/* p2c: M2Alias.md, line 285:
 * Warning: Symbol '__FILE__' is not defined [221] */
/* p2c: M2Alias.md, line 285:
 * Warning: Type mismatch for conformant array [298] */
/* p2c: M2Alias.md, line 285:
 * Warning: Symbol '__LINE__' is not defined [221] */
      M2Lexical_InternalError(1L, 49L,
	"limit reached in M2Alias - increase this constant", 0, 0, __FILE__,
	__LINE__);
      return;
    }
    WITH1 = &WITH->List[WITH->AliasPtr - 1];
    WITH1->From = f;
    WITH1->To = t;
    CombineAlias(a, f, t);
    return;
  }
  WITH1 = &WITH->List[o - 1];
  /* reuse an old alias */
  WITH1->From = f;
  WITH1->To = t;
  CombineAlias(a, f, t);
}


/*
   CombineAlias - combines all aliases between, f, and, t.
*/

Static void CombineAlias(AList *a, unsigned long f, unsigned long t)
{
  unsigned long gf[M2Alias_MaxAlias + 1], gt[M2Alias_MaxAlias + 1];
  unsigned long i, ht, hf;

  ht = 0;
  CollectAlias(a, 0L, (long)M2Alias_MaxAlias, gt, &ht, t);
  hf = 0;
  CollectAlias(a, 0L, (long)M2Alias_MaxAlias, gf, &hf, f);
  i = 0;
  while (i < ht) {
    PutAlias(a, gt[i], f);
    i++;
  }
  i = 0;
  while (i < hf) {
    PutAlias(a, gf[i], t);
    i++;
  }
}


/*
   GetSym - returns the SymIndex to a symbol, [Sym:m].
*/

Static unsigned long GetSym(AList *a, unsigned long Sym,
			    SymbolTable_ModeOfAddr m)
{
  unsigned long i;
  AList *WITH;
  Symbol *WITH1;

  WITH = (a != NULL) ? a : (AList *)_NilCheck();
  i = 1;
  while (i <= WITH->SymPtr) {
    if (WITH->Syms[i - 1].Id == Sym && WITH->Syms[i - 1].Mode == m) {
      /* found symbol - it was placed here before */
      return i;
    }
    i++;
  }
  /* have not found symbol, we will add it to our list */
  WITH->SymPtr++;
  if (WITH->SymPtr > MaxSyms) {
/* p2c: M2Alias.md, line 355:
 * Warning: Symbol '__FILE__' is not defined [221] */
/* p2c: M2Alias.md, line 355:
 * Warning: Type mismatch for conformant array [298] */
/* p2c: M2Alias.md, line 355:
 * Warning: Symbol '__LINE__' is not defined [221] */
    M2Lexical_InternalError(1L, 48L,
      "MaxSyms - limit reached - increase this constant", 0, 0, __FILE__,
      __LINE__);
    return (WITH->SymPtr);
  }
  WITH1 = &WITH->Syms[WITH->SymPtr - 1];
  WITH1->Mode = m;
  WITH1->Id = Sym;
  WITH1->Dirty = P2C_FALSE;
  WITH1->Count = 0;
  return (WITH->SymPtr);
}


/*
   RemoveAliasTo - removes all alias' to a symbol in the AliasList.
*/

void M2Alias_RemoveAliasTo(void *a, unsigned long Sym,
			   SymbolTable_ModeOfAddr Mode)
{
  unsigned long i, s;
  AList *WITH;
  AList *aa = (AList *)a;

  s = GetSym(a, Sym, Mode);
  WITH = (aa != NULL) ? aa : (AList *)_NilCheck();
  i = 1;
  while (i <= WITH->AliasPtr) {
    if (WITH->List[i].To == s || WITH->List[i].From == s) {
      WITH->List[i].To = NulSym;
      WITH->List[i].From = NulSym;
    }
    i++;
  }
}


/*
   CollectAliases - collect all aliases to Sym and Mode into the list, l.
*/

unsigned long M2Alias_CollectAliases(void *a, const long l_LOW,
  const long l_HIGH, M2Alias_AliasType *l, unsigned long Sym,
  SymbolTable_ModeOfAddr Mode)
{
  unsigned long s;
  unsigned long b[M2Alias_MaxAlias + 1];
  unsigned long i, h;
  AList *aa = (AList *) a;

  s = GetSym(a, Sym, Mode);
  h = 0;
  CollectAlias(a, 0L, (long)M2Alias_MaxAlias, b, &h, s);
  i = 0;
  while (i < h) {
    l[i].Sym = ((aa != NULL) ? aa : (AList *)_NilCheck())->Syms[b[i]-1].Id;
    l[i].Mode = ((aa != NULL) ? aa : (AList *)_NilCheck())->Syms[b[i]-1].Mode;
    CollectAlias(aa, 0, M2Alias_MaxAlias, b, &h, GetSym(aa, l[i].Sym, l[i].Mode));
    i++;
  }
  return h;
}


/*
   CollectAllAliases - collect all aliases in, a.
*/

unsigned long M2Alias_CollectAllAliases(void *a, const long l_LOW,
  const long l_HIGH, M2Alias_AliasType *l)
{
  unsigned long i, h;
  AList *WITH;
  AList *aa = (AList *)a;

  WITH = (aa != NULL) ? aa : (void *)_NilCheck();
  h = WITH->SymPtr;
  i = 0;
  while (i < h) {
    l[i].Sym = WITH->Syms[i + 1].Id;
    l[i].Mode = WITH->Syms[i + 1].Mode;
    i++;
  }
  return h;
}


/*
   CollectAlias - collects all aliases from, a, into array, g, for a symbol, s.
*/

Static void CollectAlias(AList *a, const long g_LOW, const long g_HIGH,
			 unsigned long *g, unsigned long *High,
			 unsigned long s)
{
  unsigned long i;
  AList *WITH;

  AddTo(0L, g_HIGH - g_LOW, g, High, s);
      /* s can always be an alias to itself */
  WITH = (a != NULL) ? (AList *)a : (AList *)_NilCheck();
  i = 1;
  while (i <= WITH->AliasPtr) {
    if (WITH->List[i - 1].To == s)
      AddTo(0L, g_HIGH - g_LOW, g, High, WITH->List[i - 1].From);
    else if (WITH->List[i - 1].From == s)
      AddTo(0L, g_HIGH - g_LOW, g, High, WITH->List[i - 1].To);
    i++;
  }
}


/*
   AddTo - add symbol index, s, to the array, a, incrementing the pointer, High.
*/

Static void AddTo(const long a_LOW, const long a_HIGH, unsigned long *a,
		  unsigned long *High, unsigned long s)
{
  unsigned long i;

  /* just check to make sure, s, is not already in the array */
  i = 0;
  while (i < *High) {
    if (a[i] == s) {
      /* yes it is here, we will return as we have nothing else to do */
      return;
    }
    i++;
  }
  /* no, s, is not currently inside, a */
  if (*High == a_HIGH - a_LOW) {
/* p2c: M2Alias.md, line 488:
 * Warning: Symbol '__FILE__' is not defined [221] */
/* p2c: M2Alias.md, line 488:
 * Warning: Type mismatch for conformant array [298] */
/* p2c: M2Alias.md, line 488:
 * Warning: Symbol '__LINE__' is not defined [221] */
    M2Lexical_InternalError(1L, 19L, "increase array size", 0, 0, __FILE__,
			    __LINE__);
  } else {
    a[*High] = s;
    (*High)++;
  }
}


/*
   IsAbleToBeCleaned - returns TRUE if a symbol [Sym:Mode] can be cleaned (if it is made dirty).
*/

P2C_BOOLEAN M2Alias_IsAbleToBeCleaned(void *a, unsigned long s,
				      SymbolTable_ModeOfAddr m)
{
  M2Alias_AliasType al[M2Alias_MaxAlias + 1];
  unsigned long i, n;

  i = 0;
  n = M2Alias_CollectAliases(a, 0L, (long)M2Alias_MaxAlias, al, s, m);
  while (i < n) {
    if ((al[i].Sym != s || al[i].Mode != m) &&
	M2Alias_IsClean(a, al[i].Sym, al[i].Mode))
      return P2C_TRUE;
    i++;
  }
  return P2C_FALSE;
}


/*
   IsAliased - returns TRUE whether there exists an alias in, a, which matches
               [FromSymbol, FromMode] -> [ToSymbol, ToMode]
*/

P2C_BOOLEAN M2Alias_IsAliased(void *a, unsigned long FromSymbol,
  SymbolTable_ModeOfAddr FromMode, unsigned long ToSymbol,
  SymbolTable_ModeOfAddr ToMode)
{
  unsigned long f, t, i;
  AList *WITH;

  f = GetSym(a, FromSymbol, FromMode);
  t = GetSym(a, ToSymbol, ToMode);
  WITH = (a != NULL) ? (AList *)a : (AList *)_NilCheck();
  i = 1;
  while (i <= WITH->AliasPtr) {
    if (WITH->List[i].From == f && WITH->List[i].To == t ||
	WITH->List[i].From == t && WITH->List[i].To == f) {
      return P2C_TRUE;
    }
    i++;
  }
  return P2C_FALSE;
}


/*
   MakeDirty - make the symbol, [s:m] dirty.
*/

void M2Alias_MakeDirty(void *a, unsigned long s, SymbolTable_ModeOfAddr m)
{
  ((a != NULL) ? (AList *)a : (AList *)_NilCheck())->Syms[GetSym(a, s, m)].Dirty = P2C_TRUE;
}


/*
   MakeClean - make the symbol, [s:m] clean.
*/

void M2Alias_MakeClean(void *a, unsigned long s, SymbolTable_ModeOfAddr m)
{
  ((a != NULL) ? (AList *)a : (AList *)_NilCheck())->Syms[GetSym(a, s, m)].Dirty = P2C_FALSE;
}


/*
   IsDirty - returns TRUE if the symbol, [s:m] is dirty.
*/

P2C_BOOLEAN M2Alias_IsDirty(void *a, unsigned long s, SymbolTable_ModeOfAddr m)
{
  unsigned long i;
  AList *WITH;

  WITH = (a != NULL) ? (AList *)a : (void *)_NilCheck();
  i = 1;
  while (i <= WITH->SymPtr) {
    if (WITH->Syms[i].Id == s && WITH->Syms[i].Mode == m) {
      /* found symbol */
      return (WITH->Syms[i].Dirty);
    }
    i++;
  }
  return P2C_FALSE;
}


/*
   IsClean - returns TRUE if the symbol, [s:m] is clean.
*/

P2C_BOOLEAN M2Alias_IsClean(void *a, unsigned long s, SymbolTable_ModeOfAddr m)
{
  unsigned long i;
  AList *WITH;

  WITH = (a != NULL) ? (AList *)a : (void *)_NilCheck();
  i = 1;
  while (i <= WITH->SymPtr) {
    if (WITH->Syms[i].Id == s && WITH->Syms[i].Mode == m) {
      /* found symbol */
      return (~WITH->Syms[i].Dirty);
    }
    i++;
  }
  return P2C_FALSE;
}


/*
   NoTimesUsed - returns the number of times a symbol, [s:m] was used (read and write).
*/

unsigned long M2Alias_NoOfTimesUsed(void *a, unsigned long s,
				    SymbolTable_ModeOfAddr m)
{
  unsigned long i;
  AList *WITH;

  WITH = (a != NULL) ? (AList *)a : (void *)_NilCheck();
  i = 1;
  while (i <= WITH->SymPtr) {
    if (WITH->Syms[i].Id == s && WITH->Syms[i].Mode == m) {
      /* found symbol */
      return (WITH->Syms[i].Count);
    }
    i++;
  }
  return 0;
}


void _M2_M2Alias_init(void)
{
}
/* p2c: Note: Remember to call _M2_M2Alias_init() in main program [215] */



/* End. */
