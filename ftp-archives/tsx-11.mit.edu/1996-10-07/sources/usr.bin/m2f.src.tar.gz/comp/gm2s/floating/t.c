main ()
{
    float a, b;

    a = 1.0;
    b = a * 2.0;
}
