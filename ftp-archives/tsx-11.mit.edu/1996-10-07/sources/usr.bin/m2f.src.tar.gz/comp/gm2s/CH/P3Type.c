/* Output from p2c, the Pascal-to-C translator */
/* From input file "P3Type.md" */


#include <p2c/p2c.h>


#define P3TypeG
#include "P3Type.h"


#ifndef M2DebugH
#include "M2Debug.h"
#endif

#ifndef StrIOH
#include "StrIO.h"
#endif

#ifndef NameKeyH
#include "NameKey.h"
#endif

#ifndef M2LexicalH
#include "M2Lexical.h"
#endif

#ifndef P3ExpressionH
#include "P3Expression.h"
#endif

#ifndef P2ExpressionH
#include "P2Expression.h"
#endif

#ifndef M2AtomH
#include "M2Atom.h"
#endif

#ifndef M2ReservedH
#include "M2Reserved.h"
#endif

#ifndef M2ReferenceH
#include "M2Reference.h"
#endif

#ifndef P3SymBuildH
#include "P3SymBuild.h"
#endif

#ifndef M2QuadsH
#include "M2Quads.h"
#endif


/* %%%FORWARD%%% */
Static P2C_BOOLEAN ArrayType(void);

Static P2C_BOOLEAN CaseLabelList(void);

Static P2C_BOOLEAN CaseLabels(void);

Static P2C_BOOLEAN Enumeration(void);

Static P2C_BOOLEAN FieldList(void);

Static P2C_BOOLEAN FieldListSequence(void);

Static P2C_BOOLEAN FormalType(void);

Static P2C_BOOLEAN FormalTypeList(void);

Static P2C_BOOLEAN PointerType(void);

Static P2C_BOOLEAN ProcedureParameters(void);

Static P2C_BOOLEAN ProcedureType(void);

Static P2C_BOOLEAN RecordType(void);

Static P2C_BOOLEAN SetType(void);

Static P2C_BOOLEAN SimpleType(void);

Static P2C_BOOLEAN SubrangeType(void);

Static P2C_BOOLEAN Varient(void);


/* %%%FORWARD%%% */


P2C_BOOLEAN P3Type_Type(void)
{
  P2C_BOOLEAN Success;
  unsigned long NewPtr, OldPtr;

  M2Quads_GetPtr(&OldPtr);
  M2Atom_PushAutoOff();
  if (SimpleType())
    Success = P2C_TRUE;
  else if (ArrayType())
    Success = P2C_TRUE;
  else if (RecordType())
    Success = P2C_TRUE;
  else if (SetType())
    Success = P2C_TRUE;
  else if (PointerType())
    Success = P2C_TRUE;
  else if (ProcedureType())
    Success = P2C_TRUE;
  else
    Success = P2C_FALSE;
  M2Atom_PopAuto();
  M2Quads_GetPtr(&NewPtr);
  M2Debug_Assert(OldPtr == NewPtr);
  return Success;
}


Static P2C_BOOLEAN SimpleType(void)
{
  P2C_BOOLEAN Success;

  if (M2Reference_Qualident()) {
    Success = P2C_TRUE;
    return Success;
  }
  if (Enumeration()) {
    Success = P2C_TRUE;
    return Success;
  }
  if (SubrangeType())
    Success = P2C_TRUE;
  else
    Success = P2C_FALSE;
  return Success;
}


Static P2C_BOOLEAN Enumeration(void)
{
  P2C_BOOLEAN Success;

  if (!M2Lexical_TokenIs(M2Reserved_LParaTok)) {
    Success = P2C_FALSE;
    return Success;
  }
  if (!M2Reference_IdentList()) {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 20L, "IdentList - expected");
    return Success;
  }
  if (M2Lexical_TokenIs(M2Reserved_RParaTok)) {
    /* BuildEnumeration ;   (* ********** *) */
    Success = P2C_TRUE;
  } else {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 12L, ") - expected");
  }
  return Success;
}


Static P2C_BOOLEAN SubrangeType(void)
{
  P2C_BOOLEAN Success;

  if (!M2Lexical_TokenIs(M2Reserved_LSBraTok)) {
    Success = P2C_FALSE;
    return Success;
  }
  if (!P3Expression_ConstExpression()) {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 26L, "ConstExpression - expected");
    return Success;
  }
  if (!M2Lexical_TokenIs(M2Reserved_PeriodPeriodTok)) {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 13L, ".. - expected");
    return Success;
  }
  if (!P3Expression_ConstExpression()) {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 26L, "ConstExpression - expected");
    return Success;
  }
  if (M2Lexical_TokenIs(M2Reserved_RSBraTok)) {  /* ******** */
    P3SymBuild_BuildSubrange();
    Success = P2C_TRUE;
  } else {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 12L, "] - expected");
  }
  return Success;
}


Static P2C_BOOLEAN ArrayType(void)
{
  P2C_BOOLEAN Success;

  if (!M2Lexical_TokenIs(M2Reserved_ArrayTok)) {
    Success = P2C_FALSE;
    return Success;
  }
  /* StartBuildArray ;  (* ******** *) */
  /* BuildNulName ;  (* ******** *) */
  if (!SimpleType()) {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 21L, "SimpleType - expected");
    return Success;
  }
  /* BuildFieldArray ;  (* ******** *) */
  while (M2Lexical_TokenIs(M2Reserved_CommaTok)) {
    /* BuildNulName ;  (* ******** *) */
    if (!SimpleType())
      M2Lexical_WriteError(1L, 21L, "SimpleType - expected");
    /* BuildFieldArray  (* ******** *) */
  }
  if (!M2Lexical_TokenIs(M2Reserved_OfTok)) {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 13L, "OF - expected");
    return Success;
  }
  /* BuildNulName ;  (* ******** *) */
  if (P3Type_Type()) {
    /* EndBuildArray ;  (* ******** *) */
    Success = P2C_TRUE;
  } else {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 15L, "Type - expected");
  }
  return Success;
}


Static P2C_BOOLEAN RecordType(void)
{
  P2C_BOOLEAN Success;

  if (!M2Lexical_TokenIs(M2Reserved_RecordTok)) {
    Success = P2C_FALSE;
    return Success;
  }
  /* BuildRecord ;  (* ******** SymbolTable *) */
  if (!FieldListSequence()) {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 28L, "FieldListSequence - expected");
    return Success;
  }
  if (M2Lexical_TokenIs(M2Reserved_EndTok))
    Success = P2C_TRUE;
  else {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 14L, "END - expected");
  }
  return Success;
}


Static P2C_BOOLEAN FieldListSequence(void)
{
  P2C_BOOLEAN Success;

  if (!FieldList()) {
    Success = P2C_FALSE;
    return Success;
  }
  while (M2Lexical_TokenIs(M2Reserved_SemiColonTok)) {
    if (!FieldList())
      M2Lexical_WriteError(1L, 20L, "FieldList - expected");
  }
  Success = P2C_TRUE;
  return Success;
}


Static P2C_BOOLEAN FieldList(void)
{
  if (M2Reference_IdentList()) {
    if (M2Lexical_TokenIs(M2Reserved_ColonTok)) {
      /* BuildNulName ;  (* ******** *) */
      if (!P3Type_Type())
	M2Lexical_WriteError(1L, 15L, "Type - expected");
      /* BuildFieldRecord  (* ******** Symbol Table *) */
    } else
      M2Lexical_WriteError(1L, 12L, ": - expected");
    return P2C_TRUE;
  }
  /* Massage the ambigious grammer */
  if (!M2Lexical_TokenIs(M2Reserved_CaseTok))
    return P2C_TRUE;
  if (M2Atom_Found(M2Reserved_ColonTok)) {
    if (M2Atom_Ident()) {
      if (M2Lexical_TokenIs(M2Reserved_ColonTok)) {
	if (!M2Reference_Qualident())
	  M2Lexical_WriteError(1L, 20L, "Qualident - expected");
      } else
	M2Lexical_WriteError(1L, 12L, ": - expected");
    } else
      M2Lexical_WriteError(1L, 16L, "Ident - expected");
  } else {
    if (!M2Reference_Qualident())
      M2Lexical_WriteError(1L, 20L, "Qualident - expected");
  }
  if (!M2Lexical_TokenIs(M2Reserved_OfTok)) {
    M2Lexical_WriteError(1L, 13L, "OF - expected");
    return P2C_TRUE;
  }
  if (!Varient()) {
    M2Lexical_WriteError(1L, 18L, "Varient - expected");
    return P2C_TRUE;
  }
  while (M2Lexical_TokenIs(M2Reserved_BarTok)) {
    if (!Varient())
      M2Lexical_WriteError(1L, 18L, "Varient - expected");
  }
  if (M2Lexical_TokenIs(M2Reserved_ElseTok)) {
    if (!FieldListSequence())
      M2Lexical_WriteError(1L, 28L, "FieldListSequence - expected");
  }
  if (!M2Lexical_TokenIs(M2Reserved_EndTok))
    M2Lexical_WriteError(1L, 14L, "END - expected");
  return P2C_TRUE;
}


Static P2C_BOOLEAN Varient(void)
{
  P2C_BOOLEAN Success;

  if (!CaseLabelList()) {
    Success = P2C_FALSE;
    return Success;
  }
  if (!M2Lexical_TokenIs(M2Reserved_ColonTok)) {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 12L, ": - expected");
    return Success;
  }
  if (FieldListSequence())
    Success = P2C_TRUE;
  else {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 28L, "FieldListSequence - expected");
  }
  return Success;
}


Static P2C_BOOLEAN CaseLabelList(void)
{
  P2C_BOOLEAN Success;

  if (!CaseLabels()) {
    Success = P2C_FALSE;
    return Success;
  }
  while (M2Lexical_TokenIs(M2Reserved_CommaTok)) {
    if (!CaseLabels())
      M2Lexical_WriteError(1L, 21L, "CaseLabels - expected");
  }
  Success = P2C_TRUE;
  return Success;
}


Static P2C_BOOLEAN CaseLabels(void)
{
  P2C_BOOLEAN Success;

  if (!P2Expression_ConstExpression()) {
    Success = P2C_FALSE;
    return Success;
  }
  if (M2Lexical_TokenIs(M2Reserved_PeriodPeriodTok)) {
    if (!P2Expression_ConstExpression())
      M2Lexical_WriteError(1L, 26L, "ConstExpression - expected");
  }
  Success = P2C_TRUE;
  return Success;
}


Static P2C_BOOLEAN SetType(void)
{
  P2C_BOOLEAN Success;

  if (!M2Lexical_TokenIs(M2Reserved_SetTok)) {
    Success = P2C_FALSE;
    return Success;
  }
  if (!M2Lexical_TokenIs(M2Reserved_OfTok)) {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 13L, "OF - expected");
    return Success;
  }
  /* BuildNulName ;  (* ******** *) */
  if (SimpleType()) {
    /* BuildSetType ; */
    Success = P2C_TRUE;
  } else {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 21L, "SimpleType - expected");
  }
  return Success;
}


Static P2C_BOOLEAN PointerType(void)
{
  P2C_BOOLEAN Success;

  if (!M2Lexical_TokenIs(M2Reserved_PointerTok)) {
    Success = P2C_FALSE;
    return Success;
  }
  if (!M2Lexical_TokenIs(M2Reserved_ToTok)) {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 13L, "TO - expected");
    return Success;
  }
  /* BuildNulName ;  (* ******** *) */
  if (P3Type_Type()) {
    /* BuildPointerType ;  (* ******** Build Symbol Table *) */
    Success = P2C_TRUE;
  } else {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 15L, "Type - expected");
  }
  return Success;
}


/*
   ProcedureType -
                   The Stack:


                   Entry                       Exit

                                                                <- Ptr
                                               +--------------+
            Ptr ->                             | ProcSym      |
                   +-------------+             |--------------|
                   | Name        |             | Name         |
                   |-------------|             |--------------|
*/

Static P2C_BOOLEAN ProcedureType(void)
{
  P2C_BOOLEAN Success;

  if (M2Lexical_TokenIs(M2Reserved_ProcedureTok)) {
    /* BuildProcedureType ; */
    FormalTypeList();
    Success = P2C_TRUE;
  } else
    Success = P2C_FALSE;
  return Success;
}


Static P2C_BOOLEAN FormalTypeList(void)
{
  P2C_BOOLEAN Success;

  if (!M2Lexical_TokenIs(M2Reserved_LParaTok)) {
    Success = P2C_FALSE;
    return Success;
  }
  ProcedureParameters();
  if (!M2Lexical_TokenIs(M2Reserved_RParaTok)) {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 12L, ") - expected");
    return Success;
  }
  if (M2Lexical_TokenIs(M2Reserved_ColonTok)) {
    if (!M2Reference_Qualident())
      M2Lexical_WriteError(1L, 20L, "Qualident - expected");
    /* BuildFunction  (* ******** Borrowed from procedure *) */
  }
  Success = P2C_TRUE;
  return Success;
}


/*
   ProcedureParameters -
                         The Stack:

                         Entry                    Exit

                  Ptr ->                                          <- Ptr
                         +-------------+          +-------------+
                         | n           |          | n           |
                         |-------------|          |-------------|
                         | ProcSym     |          | ProcSym     |
                         |-------------|          |-------------|
                         | Name        |          | Name        |
                         |-------------|          |-------------|
*/

Static P2C_BOOLEAN ProcedureParameters(void)
{
  P2C_BOOLEAN Success;

  M2Lexical_TokenIs(M2Reserved_VarTok);
  /* PushT(VarTok)  (* ******** *) */
  /* PushT(NulTok)  (* ******** *) */
  if (!FormalType()) {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 21L, "FormalType - expected");
    return Success;
  }
  /* BuildFormalType ;  (* ******** *) */
  while (M2Lexical_TokenIs(M2Reserved_CommaTok)) {
    M2Lexical_TokenIs(M2Reserved_VarTok);
    /* PushT(VarTok)  (* ******** *) */
    /* PushT(NulTok)  (* ******** *) */
    if (!FormalType())
      M2Lexical_WriteError(1L, 21L, "FormalType - expected");
    /* BuildFormalType  (* ******** *) */
  }
  Success = P2C_TRUE;
  return Success;
}


/*
   FormalType - parses the FormalType rule.
                The stack:


                         "ARRAY OF Sym"

                Entry                    Exit

                                                         <- Ptr
                                         +-------------+
                                         | Sym         |
                                         |-------------|
                                         | ArrayTok    |
                Empty                    |-------------|


                             OR

                            "Sym"

                                                         <- Ptr
                                         +-------------+
                                         | Sym         |
                                         |-------------|
                                         | NulTok      |
                Empty                    |-------------|
*/

Static P2C_BOOLEAN FormalType(void)
{
  P2C_BOOLEAN Success;

  if (M2Lexical_TokenIs(M2Reserved_ArrayTok)) {
    if (!M2Lexical_TokenIs(M2Reserved_OfTok)) {
      M2Lexical_WriteError(1L, 13L, "OF - expected");
      return Success;
    }
    /* PushT(ArrayTok) ;  (* ******** *) */
    if (M2Reference_Qualident())
      Success = P2C_TRUE;
    else
      Success = P2C_FALSE;
    return Success;
  }
  /* PushT(NulTok) ;  (* ******** *) */
  if (M2Reference_Qualident())
    Success = P2C_TRUE;
  else {
    Success = P2C_FALSE;
    M2Lexical_WriteError(1L, 20L, "Qualident - expected");
  }
  return Success;
}


void _M2_P3Type_init(void)
{
}
/* p2c: Note: Remember to call _P3Type_init() in main program [215] */



/* End. */
