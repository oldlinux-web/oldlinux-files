main(argc, argv)
int   argc ;
char  *argv[];
{
   _M2_M2RTS_init(argc, argv) ;
   _M2_libc_init(argc, argv) ;
   _M2_SYSTEM_init(argc, argv) ;
   _M2_StrLib_init(argc, argv) ;
   _M2_ASCII_init(argc, argv) ;
   _M2_IO_init(argc, argv) ;
   _M2_StdIO_init(argc, argv) ;
   _M2_StrIO_init(argc, argv) ;
   _M2_MATH_init(argc, argv) ;
   _M2_FpuIO_init(argc, argv) ;
   _M2_writepi_init(argc, argv) ;
   exit(0);
}
