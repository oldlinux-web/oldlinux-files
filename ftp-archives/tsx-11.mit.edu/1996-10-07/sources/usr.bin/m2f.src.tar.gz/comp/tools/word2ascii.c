#include <stdio.h>
#include <fcntl.h>


/*
 *  w2a - written by Gaius Mulley
 *        a very simple word 2 ascii filter mappings are:
 *
 *        CTRLG         ->  tab
 *        LF/CR         ->  \n
 *        visible ascii -> displayed
 */


#define TRUE  (1==1)
#define FALSE (1==0)
#define STDIN           0
#define LF    '\n'
#define CR    '\r'
#define CTRLG '\a'
#define TAB   '\t'


#define ERROR(X)   (fprintf(stderr, "%s:%d error %s\n", __FILE__, __LINE__, X) && \
		    (fflush(stderr)) && exit(1))

/*
 * prototypes
 */

static void parseArgs (int argc, char *argv[]);
static void parseWordFile (void);
static char charget (void);
static int isAscii (char ch);
static char processCtrl (char ch);


static int eof = FALSE;


/*
 * charget - a replacement for getchar, unfortunately word documents
 *           have (char)-1 inside them which makes getchar useless.
 */

static char charget (void)
{
  char ch;

  if (read(STDIN, &ch, 1) != 1) {
    eof = TRUE;
    ch = EOF;
  }
  return( ch );
}


/*
 * parseArgs - currently only one option available and that is the input filename.
 */

static void parseArgs (int argc, char *argv[])
{
  int inFd;

  if (argc == 2) {
    close(STDIN);
    inFd = open(argv[1], O_RDONLY);
    if (inFd < 0) {
      ERROR("unable to read input file");
    }
  }
}


/*
 * isAscii - returns TRUE if the character is printable.
 */

static int isAscii (char ch)
{
  return( (ch >= ' ') && (ch <= (char)0x79) );
}


/*
 * processCtrl - interpret the control character if possible.
 */

static char processCtrl (char ch)
{
  if ((ch == LF) || (ch == CR)) {
    while ((ch == LF) || (ch == CR)) {
      ch = charget();
    }
    putchar('\n');
    return( ch );
  } else if (ch == CTRLG) {
    putchar(TAB);
    return( charget() );
  } else {
    return( charget() );
  }
}


/*
 * parseWordFile - print all visable ASCII characters and try and interpret
 *                 some simple control characters.
 */

static void parseWordFile (void)
{
  char ch;

  ch = charget();
  while (! eof) {
    if (isAscii(ch)) {
      putchar(ch);
      ch = charget();
    } else {
      ch = processCtrl(ch);
    }
  }
}


/*
 * main - parse the arguments and then parse the word file.
 */

int main (int argc, char *argv[])
{
  parseArgs(argc, argv);
  parseWordFile();
}
