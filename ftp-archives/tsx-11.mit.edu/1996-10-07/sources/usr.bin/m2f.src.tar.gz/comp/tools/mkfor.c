/*
 * Author     : Gaius Mulley
 * Title      : mkfor
 * Description: creates prototypes for source file
 * Date       : 19/1/93
 *
 *
 * $Header: /usr/src/cvs/m2/comp/tools/mkfor.c,v 1.1.1.1 1996/05/28 10:13:09 gaius Exp $
 *
 * $Log: mkfor.c,v $
 * Revision 1.1.1.1  1996/05/28 10:13:09  gaius
 * Modula-2 compiler sources imported
 *
 *
 */

#define TRUE           (1==1)
#define FALSE          (1==0)
#define MAX_FILE_NAME  120
#define MAXSTACK       100
#define STDIN            0
#define STDOUT           1
#define ENDOFILE       ((char) -1)
#define ERROR(X)       (fprintf(stderr, "%s:%d error %s\n", __FILE__, __LINE__, X) && \
			(fflush(stderr)))
#define DEBUG(X)       ((Debug) && (fprintf(stderr, "%s\n", X) && (fflush(stderr))))


#include <stdio.h>
#include <fcntl.h>


/* Prototypes */

static void ParseFile (char *Name);
static void ParseComments (void);
static void CopyUntilEof (void) ;
static void CopyUntilEol (void) ;
static int  IsSym (char *s) ;
static int  SymIs (char *s) ;
static int  FindString (char *String) ;
static void GetNL (void) ;
static char GetChar (void) ;
static void ResetBuffer (void) ;
static int  GetSingleChar (char *ch) ;
static int  InRange (int Element, unsigned int Min, unsigned int Max) ;
static char PutChar (char ch) ;
static int  IsSpace (char ch) ;
static void SkipSpaces (void) ;
static void SkipText (void) ;
static void SilentSkipSpaces (void);
static void SilentSkipText (void);
static void PushBack (char *s) ;
static int  IsDigit (char ch) ;
static void GetName (char *Name) ;
static void OpenOutputFile (char *Name) ;
static void CloseFile (void);
static void FindSource (char *Name);
static void CopyUntilEolInto (char *Buffer);

/* Global variables */

static int       StackPtr          = 0;
static char      Stack[MAXSTACK];
static int       CurrentFile       = STDIN;
static int       OutputFile;
static int       CopyStdout;


main (int argc, char *argv[])
{
    if (argc == 2) {
	ParseFile(argv[1]);
    } else {
	fprintf(stderr, "Usage: mkfor <modulename>\n");
	exit(1);
    }
    exit(0);
}


static void ParseFile (char *Name)
{
    FindSource(Name);
    OpenOutputFile(Name);
    ParseComments();
    CloseFile();
}


static void ParseComments (void)
{
    while (PutChar(GetChar()) != ENDOFILE) {
	if (SymIs("(* %%%FORWARD%%%")) {
	    printf("(* %%%%%%FORWARD%%%%%% *)");
	} else if (SymIs("%%%FORWARD%%% *)")) {
	    printf("(* %%%%%%FORWARD%%%%%% *)");
	}
	putchar(GetChar());
    }
}


/*
   OpenOutputFile - shut down stdout and open the new Name.md
*/

static void OpenOutputFile (char *Name)
{
    char FileName[MAX_FILE_NAME];

    CopyStdout = dup(STDOUT);
    if (close(STDOUT) != 0) {
	ERROR("Unable to close stdout"); exit(1);
    }
    sprintf(FileName, "%s.md", Name);
    OutputFile = open(FileName, O_CREAT | O_RDWR, 0666);
    if (OutputFile != STDOUT) {
	ERROR("Expected that the file descriptor should be 1");
    }
}



/*
   CloseFile - flush and close the temporary par file.
*/

static void CloseFile (void)
{
    fflush(stdout);
    if (close(STDOUT) != 0) {
	ERROR("Unable to close our output file"); exit(1);
    }
    if (dup(CopyStdout) != STDOUT) {
	ERROR("Expected that dup should use Stdout");
    }
    if (close(CopyStdout) != 0) {
	ERROR("Unable to close CopyStdout"); exit(1);
    }
}


/*
   CopyUntilEof - copies from the current input marker
                  until ENDOFILE is reached.
*/

static void CopyUntilEof (void)
{
    char ch;

    while ((ch=GetChar()) != ENDOFILE) {
	putchar(ch);
    }
}


/*
   CopyUntilEol - copies from the current input marker
                  until '\n' is reached.
*/

static void CopyUntilEol (void)
{
    char ch;

    while (((ch=GetChar()) != '\n') && (ch != EOF)) {
	putchar(ch);
    }
    if (ch == '\n') {
	putchar(ch);
    }
}


/*
   CopyUntilEolInto - copies from the current input marker
                      until '\n' is reached into a Buffer.
*/

static void CopyUntilEolInto (char *Buffer)
{
    char ch;
    int  i=0;

    while (((ch=GetChar()) != '\n') && (ch != EOF)) {
	Buffer[i] = ch;
	i++;
    }
    if (ch == '\n') {
	Buffer[i] = (char)0;
    }
}


/*
   IsSym - returns true if string, s, was found in the input stream.
           The input stream is uneffected.
*/

static int IsSym (char *s)
{
    int i=0;

    while ((s[i] != (char)0) && (s[i] == PutChar(GetChar()))) {
	GetChar();
	i++;
    }
    if (s[i]==(char)0) {
	PushBack(s);
	/* found s in input string */
	return( TRUE );
    } else {
	/* push back the characters we have scanned */
	if (i>0) {
	    do {
		i--;
		PutChar(s[i]);
	    } while (i>0);
	}
	return( FALSE );
    }
}


/*
   SymIs - returns true if string, s, was found in the input stream.
           The token s is consumed from the input stream.
*/

static int SymIs (char *s)
{
    int i=0;

    while ((s[i] != (char)0) && (s[i] == PutChar(GetChar()))) {
	GetChar();
	i++;
    }
    if (s[i]==(char)0) {
	/* found s in input string */
	return( TRUE );
    } else {
	/* push back the characters we have scanned */
	if (i>0) {
	    do {
		i--;
		PutChar(s[i]);
	    } while (i>0);
	}
	return( FALSE );
    }
}


/*
   FindString - keeps on reading input until a string,
                String, is matched.
		If end of file is reached then FALSE is returned,
                otherwise TRUE is returned.
*/

static int FindString (char *String)
{
    int StringIndex=0;
    int Found      =FALSE;
    int eof        =FALSE;
    char ch;

    while ((! Found) && (!eof)) {
	if (String[StringIndex] == (char)0) {
	    /* must have found string */
	    Found = TRUE;
	} else {
	    ch = GetChar();
	    eof = (ch == ENDOFILE);
	    if (ch == String[StringIndex]) {
		StringIndex++;
	    } else {
		StringIndex = 0;
	    }
	}
    }
    return( Found );
}


/*
   GetNL - keeps on reading input from until
           a new line is found.
*/

static void GetNL (void)
{
    char ch;

    while ((ch=GetChar()) != '\n') {
	putchar(ch);
    }
    putchar('\n');
}


/*
   GetChar - returns the current character in input.
*/

static char GetChar (void)
{
    char ch;

    if (StackPtr > 0) {
	StackPtr--;
	return(Stack[StackPtr]);
    } else {
	if (GetSingleChar(&ch)) {
	    return( ch );
	} else {
	    return( ENDOFILE );
	}
    }
}


#define MAXBUF  0x1000
static int Pointer=0;
static int AmountRead=0;
static char Buffer[MAXBUF];


/*
   ResetBuffer - resets the buffer information to an initial state.
*/

static void ResetBuffer (void)
{
    StackPtr = 0;
    Pointer = 0;
    AmountRead = 0;
}


/*
   GetSingleChar - gets a single character from input.
                   TRUE is returned upon success.
*/

static int GetSingleChar (char *ch)
{
    if (Pointer == AmountRead) {
	AmountRead = read(CurrentFile, &Buffer, MAXBUF);
	if (AmountRead < 0) {
	    AmountRead = 0;
	}
	Pointer = 0;
    }
    if (Pointer == AmountRead) {
	*ch = ENDOFILE;
	return( FALSE );
    } else {
	*ch = Buffer[Pointer];
	Pointer++;
	return( TRUE );
    }

}

    
/*
   InRange - returns true if Element is within the range Min..Max.
*/

static int InRange (int Element, unsigned int Min, unsigned int Max)
{
    return( (Element >= Min) && (Element <= Max));
}

static int stop () {}

/*
   PutChar - pushes a character back onto input.
             This character is also returned.
*/

static char PutChar (char ch)
{
    if (StackPtr < MAXSTACK) {
	if (ch=='\n') {
	    stop();
	}
	Stack[StackPtr] = ch;
	StackPtr++;
    } else {
	ERROR("Stack overflow in PutChar");
    }
    return(ch);
}


/*
   IsSpace - returns true if character, ch, is a space.
*/

static int IsSpace (char ch)
{
    return( (ch == ' ') || (ch == '\t') );
}


/*
   SkipSpaces - eats up spaces in input.
*/

static void SkipSpaces (void)
{
    while (IsSpace(PutChar(GetChar()))) {
	putchar(GetChar());
    }
}


/*
   SilentSkipSpaces - eats up spaces in input.
*/

static void SilentSkipSpaces (void)
{
    char ch;

    while (IsSpace(PutChar(GetChar()))) {
	ch = GetChar();  /* throw away character */
    }
}


/*
   SkipText - skips ascii text, it does not skip white spaces.
*/

static void SkipText (void)
{
    while (! IsSpace(PutChar(GetChar()))) {
	putchar(GetChar());
    }
}


/*
   SilentSkipText - skips ascii text, it does not skip white spaces.
*/

static void SilentSkipText (void)
{
    char ch;

    while (! IsSpace(PutChar(GetChar()))) {
	ch = GetChar();  /* throw away character */
    }
}


/*
   PushBack - pushes a string, backwards onto the input stack.
*/

static void PushBack (char *s)
{
    int i;

    i = strlen(s);
    while (i > 0) {
	i--;
	PutChar(s[i]);
    }
}

/*
   IsDigit - returns true if a character, ch, is a decimal digit.
*/

static int IsDigit (char ch)
{
    return( ((ch >= '0') && (ch <= '9')) );
}


/*
   GetName - returns the next name found.
*/

static void GetName (char *Name)
{
    int i;
    char ch;

    SkipSpaces();
    ch = GetChar();
    i = 0;
    while (! IsSpace(ch)) {
	Name[i] = ch;
	i++;
	ch = GetChar();
    }
    Name[i]= '\0';
}


/*
   FindSource - open source file on StdIn.
*/

static void FindSource (char *Name)
{
    char FileName[MAX_FILE_NAME];

    if (close(STDIN) != 0) {
	ERROR("close on STDIN failed");
    }
    sprintf(FileName, "%s.mod", Name);
    CurrentFile = open(FileName, O_RDONLY);
    if (CurrentFile < 0) {
	perror("failed to open file");
	exit(1);
    }
    if (CurrentFile != STDIN) {
	ERROR("Expecting file descriptor value of 1");
    }
}
