#include <stdio.h>
#include <fcntl.h>


/*
 *  dar - written by Gaius Mulley
 *        A small tar replacement which has a -l (list) option.
 *
 */


#define TRUE  (1==1)
#define FALSE (1==0)

#define ERROR(X)   (fprintf(stderr, "%s:%d error %s\n", __FILE__, __LINE__, X) && \
		    (fflush(stderr)) && abort(1))


#define TBLOCK 512
#define NAMSIZ 100

union hblock {
    char dummy[TBLOCK];
    struct header {
	char name[NAMSIZ];
	char mode[8];
	char uid[8];
	char gid[8];
	char size[12];
	char mtime[12];
	char chksum[8];
	char linkflag;
	char linkname[NAMSIZ];
    } dbuf;
};


typedef union hblock tarHBlock;


static int  scanArgs            (int argc, char *argv[]);
static void parseArchive        (int argc, char *argv[]);
static void parseHBlock         (tarHBlock *b);
static int extractFile          (tarHBlock *b);
static unsigned int getFileSize (tarHBlock *b);
static int IsDigit              (char ch);
static int IsSpace              (char ch);
static int Min                  (int x, int y);
static void Init                (void);
static unsigned int getFileMode (tarHBlock *b);
static int IsSpecifiedFile      (char *fn, int argc, char *argv[]);
static int getBuffer            (void);
static char *modeToString       (int m);


static int noOfBlocks=20;
static tarHBlock *Buffer;
static tarHBlock *Extra=NULL;
static char FileName[0x1000];
static int  startOfFiles;
static int  Verbose;
static int  Extract;
static int  List;
static int  Create;
static int  Cat;
static FILE *inFile=NULL;


int main (int argc, char *argv[])
{
    Init();
    startOfFiles = scanArgs(argc, argv);
    Buffer = (tarHBlock *) malloc((noOfBlocks+1) * sizeof(tarHBlock));
    if (Create) {
    } else {
	parseArchive(argc, argv);
    }
}


static void Init (void)
{
    strcpy(FileName, "");
    Create  = FALSE;
    Verbose = FALSE;
    Extract = FALSE;
    List    = FALSE;
    Cat     = FALSE;
}


/*
   scanArgs - scans the arguments given on the command line and
              set various flags. It returns the arg number of the
	      start of the specified files.
*/

static int scanArgs (int argc, char *argv[])
{
    int i;
    int len;
    int j;

    if (argc > 1) {
	len = strlen(argv[1]);
    } else {
	fprintf(stderr, "Usage: %s flags { file }\n", argv[0]);
	fprintf(stderr, "       where flags = cvxtlfb\n");
	fprintf(stderr, "                 c = create archive  (not implemented)\n");
	fprintf(stderr, "                 x = extract archive\n");
	fprintf(stderr, "                 v = verbose\n");
	fprintf(stderr, "                 t = index of contents\n");
	fprintf(stderr, "                 l = list contents of file\n");
	fprintf(stderr, "                 f = archive file\n");
	fprintf(stderr, "                 b = block size\n");
	exit(1);
    }
    i = 0;
    j = 2;
    len = strlen(argv[1]);
    while (i<len) {
	if (argv[1][i] == '-') {
	} else if (argv[1][i] == 'c') {
	    Create = TRUE;
	} else if (argv[1][i] == 'v') {
	    Verbose = TRUE;
	} else if (argv[1][i] == 'x') {
	    Extract = TRUE;
	} else if (argv[1][i] == 't') {
	    List = TRUE;
	} else if (argv[1][i] == 'l') {
	    Cat = TRUE;
	} else if (argv[1][i] == 'f') {
	    strcpy(FileName, argv[j]);
	    j++;
	} else if (argv[1][i] == 'b') {
	    noOfBlocks = atoi(argv[j]);
	    j++;
	} else {
	    fprintf(stderr, "Unknown argument %c: known flags are -cvxtfb\n", argv[1][i]);
	    exit(1);
	}
	i++;
    }
    return( j );
}


/*
   IsSpecifiedFile - returns true if a file name, fn, was specified
                     on the command line. It returns true if no
		     files were specified on the command line.
*/

static int IsSpecifiedFile (char *fn, int argc, char *argv[])
{
    int i;

    /* printf("IsSpecifiedFile %s   argc = %d    startOfFiles = %d\n",
       fn, argc, startOfFiles);
       */
    if (argc == startOfFiles) {
	return( TRUE );
    } else {
	i = startOfFiles;
	while (i < argc) {
	    if (strcmp(fn, argv[i]) == 0) {
		return( TRUE );
	    } else {
		i++;
	    }
	}
	return( FALSE );
    }
}


/*
   IsEndOfArchive - returns true if the end of the archive has been found.
*/

static int IsEndOfArchive (tarHBlock *b, int n)
{
    char *p = (char *)b;
    int   i = 0;

    while (i<TBLOCK) {
	if (p[i] != (char)0) {
	    return( FALSE );
	}
	i++;
    }
    /* need to examine the next block - which might not be in Buffer */
    if (n==noOfBlocks) {
	if (Extra == NULL) {
	    Extra = (tarHBlock *) malloc(sizeof(tarHBlock));
	}
	if (fread(Extra, sizeof(char), sizeof(tarHBlock), inFile) != sizeof(tarHBlock)) {
	    return( TRUE );
	}
	p = (char *)Extra;
    } else {
	p = (char *) (b+1);
    }
    i = 0;
    while (i<TBLOCK) {
	if (p[i] != (char)0) {
	    return( FALSE );
	}
	i++;
    }
    return( TRUE );
}
    

/*
   getBuffer - reads data into Buffer, returning the amount of data actually
               read. It tests to see whether Extra contains any data, if so
               Extra forms the first HBlock.
*/

static int getBuffer (void)
{
    int Amount;

    if (Extra == NULL) {
	Amount = fread(Buffer, sizeof(char), sizeof(tarHBlock)*noOfBlocks, inFile);
    } else {
	memcpy(Buffer, Extra, sizeof(tarHBlock));
	Amount = fread(Buffer+1, sizeof(char), sizeof(tarHBlock)*(noOfBlocks-1), inFile) +
		 sizeof(tarHBlock);
	free(Extra);
	Extra = NULL;
    }
    return( Amount );
}


/*
   parseArchive - parse the archive.
*/

static void parseArchive (int argc, char *argv[])
{
    int i=0;
    int err;
    int Amount;
    int noOfBytesToWrite;
    int Size, Mode;
    int FoundFile;
    int fd=-1;

    if (strcmp(FileName, "") == 0) {
	fprintf(stderr, "missing archive filename\n");
	exit(1);
    }

    if (strcmp(FileName, "-") == 0) {
	inFile = stdin;
    } else {
	inFile = fopen(FileName, "r");
	if (inFile == NULL) {
	    fprintf(stderr, "error in opening file %s\n", FileName);
	    exit(1);
	}
    }
    
    Amount = getBuffer();
    while ((! IsEndOfArchive(Buffer+i, i)) && (i*sizeof(tarHBlock)<=Amount)) {
	FoundFile = IsSpecifiedFile((Buffer+i)->dbuf.name, argc, argv);
	parseHBlock(Buffer+i);
	Size = getFileSize(Buffer+i);
	Mode = getFileMode(Buffer+i);
	if (FoundFile) {
	    fd = extractFile(Buffer+i);
	}
	i++;
	if (i>=noOfBlocks) {
	    i = 0;
	    Amount = getBuffer();
	}
	while ((Size>0) && (i * sizeof(tarHBlock) <= Amount)) {
	    if ((noOfBlocks-i)*sizeof(tarHBlock) < Size) {
		noOfBytesToWrite = (noOfBlocks-i)*sizeof(tarHBlock);
	    } else {
		noOfBytesToWrite = Size;
	    }
	    if (FoundFile) {
		if (Cat) {
		    write(1, Buffer+i, noOfBytesToWrite);
		}
		if (Extract) {
		    err = write(fd, Buffer+i, noOfBytesToWrite);
		    if (err < 0) {
			perror("tar extract failed");
		    }
		}
	    }
	    i += ((noOfBytesToWrite+sizeof(tarHBlock)-1)/sizeof(tarHBlock));
	    Size -= noOfBytesToWrite;
	    if ((i>=noOfBlocks) || (i>=Amount)) {
		i = 0;
		Amount = getBuffer();
	    }
	}
	if ((Extract) && (fd>0)) {
	    close(fd);
	    fd = -1;
	}
    }
}


static int Min (int x, int y)
{
    if (x < y) {
	return( x );
    } else {
	return( y );
    }
}


/*
   modeToString - returns a string indicating the permission
                  value of m.
*/

static char *modeToString (int m)
{
    static char Mode[30];
    char *p = &Mode[0];
    char Octal[10];
    int  i=0;

    sprintf(Octal, "%o", m);
    while (Octal[i] != (char)0) {
	switch (Octal[i]) {
	  case '0': p[0] = '-'; p[1] = '-'; p[2] = '-'; break ;
	  case '1': p[0] = '-'; p[1] = '-'; p[2] = 'x'; break ;
	  case '2': p[0] = '-'; p[1] = 'w'; p[2] = '-'; break ;
	  case '3': p[0] = '-'; p[1] = 'w'; p[2] = 'x'; break ;
	  case '4': p[0] = 'r'; p[1] = '-'; p[2] = '-'; break ;
	  case '5': p[0] = 'r'; p[1] = '-'; p[2] = 'x'; break ;
	  case '6': p[0] = 'r'; p[1] = 'w'; p[2] = '-'; break ;
	  case '7': p[0] = 'r'; p[1] = 'w'; p[2] = 'x';
	}
	p[4] = (char)0;
	p = p+3;
	i++;
    }
    return( Mode );
}


/*
   extractFile - extracts a file from tape archive. It opens the file
                 and returns the file descriptor.
*/

static int extractFile (tarHBlock *b)
{
    int fd;
    int high;
    int res;

    if (Extract) {
	high = Min(strlen(b->dbuf.name), NAMSIZ);
	if (b->dbuf.name[high-1] == '/') {
	    b->dbuf.name[high-1] = (char)0;   /* remove trailing / */
	    res = mkdir(b->dbuf.name, (mode_t) getFileMode(b));
	    if (res < 0) {
		perror("creating tar directory");
	    }
	    return( -1 );
	} else {
	    fd = open(b->dbuf.name, O_CREAT | O_WRONLY, (mode_t) getFileMode(b));
	    if (fd < 0) {
		perror("tar create file");
	    }
	    return( fd );
	}
    } else {
	return( -1 );
    }
}


/*
   parseHBlock - parses a tape block and displays the size and name
                 if the command line flags were set.
*/

static void parseHBlock (tarHBlock *b)
{
    int i=0;

    if (Verbose) {
	printf("%s  %6d  ", modeToString(getFileMode(b)), getFileSize(b));
    }
    if ((List) || (Verbose)) {
	while ((b->dbuf.name[i] != (char)0) && (i<NAMSIZ)) {
	    putchar(b->dbuf.name[i]);
	    i++;
	}
	putchar('\n');
    }
}


/*
   getFileSize - returns the file size represented by block, b.
*/

static unsigned int getFileSize (tarHBlock *b)
{
    int i=0;
    unsigned int Size=0;
    
    while ((IsSpace(b->dbuf.size[i])) && (i<12)) {
	i++;
    }
    while ((! IsSpace(b->dbuf.size[i])) && (i<12)) {
	Size = Size * 8 + (b->dbuf.size[i] - (char)'0');
	i++;
    }
    return( Size );
}


/*
   getFileMode - returns the file mode represented by block, b.
*/

static unsigned int getFileMode (tarHBlock *b)
{
    int i=0;
    unsigned int Mode=0;
    
    while ((IsSpace(b->dbuf.mode[i])) && (i<8)) {
	i++;
    }
    while ((! IsSpace(b->dbuf.mode[i])) && (i<8)) {
	Mode = Mode * 8 + (b->dbuf.mode[i] - (char)'0');
	i++;
    }
    return( Mode );
}


/*
   IsDigit - returns true if a character, ch, is a decimal digit.
*/

static int IsDigit (char ch)
{
    return( ((ch >= '0') && (ch <= '9')) );
}


/*
   IsSpace - returns true if character, ch, is a space.
*/

static int IsSpace (char ch)
{
    return( (ch == ' ') || (ch == '\t') );
}
