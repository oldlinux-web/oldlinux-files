#include <stdio.h>
#include <time.h>
#include <pwd.h>

static void Prologue (void);
static float LabelFuncY (void);
static float LabelFuncX (void);
static void GenerateLabel (char *p);
static void PrintAdmin (void);
static void PrintDate (void);
static int  LabelIndex=0;

#define MAXNAME 1000
#define FONTSIZE     18
#define DEFAULTFONT  "/Times-Bold findfont %d scalefont setfont\n"
#define MAXLABEL     14
#define NOOFCOLUMNS   2
#define XOFFSET      1.5


static int DefaultFontSize = FONTSIZE;


static void Usage (int error);


int main (int argc, char *argv[])
{
    if (argc >= 3) {
	LabelIndex = atoi(argv[1]);
	if ((LabelIndex>=1) && (LabelIndex<=MAXLABEL)) {
	    LabelIndex--;
	    if (argc > 3) {
		DefaultFontSize = atoi(argv[3]);
		if (DefaultFontSize == 0) {
		    fprintf(stderr, "fontsize must be greater than zero!\n");
		    Usage(1);
		}
	    }
	    GenerateLabel(argv[2]);
	} else {
	    fprintf(stderr, "tape label index by be in range: 1..%d\n", MAXLABEL);
	    Usage(1);
	}
    } else {
	Usage(0);
    }
}


static void Usage (int error)
{
    fprintf(stderr, "Usage: tapelabel <position> name [fontsize]\n");
    if (error != 0) {
	exit(error);
    }
}


static void Prologue (void)
{
    printf("%%!PS-Adobe-3.0\n");
    printf("statusdict begin\n/manualfeed true def\nend\n");
    printf(DEFAULTFONT, DefaultFontSize);
    printf("\n/inch {72 mul} def\n\n");
}


static void Epilogue (void)
{
    PrintDate();
    PrintAdmin();
    printf("\nshowpage\n");
    printf("statusdict begin\n/manualfeed false def\nend\n");
}


/*
   PrintAdmin - prints the name of the person running this
                utility.
*/

static void PrintAdmin (void)
{
    printf("/Times-Roman findfont 10 scalefont setfont\n");    
    printf("%f %f add inch %f 0.5 add inch moveto ( Made by: %s ) show\n",
	   LabelFuncX(), XOFFSET, LabelFuncY(), getpwuid(getuid()) -> pw_gecos);
    printf(DEFAULTFONT, DefaultFontSize);
}


/*
   PrintDate - print the date at the correct position on the Meiko
               form.
*/

static void PrintDate (void)
{
    time_t clock;
    struct tm *tms;
    char   Buffer[MAXNAME];

    time(&clock);
    tms = localtime(&clock);
    strftime(Buffer, MAXNAME, "%a %d %h %Y  Time: %H:%M", tms);
    printf("/Times-Roman findfont 10 scalefont setfont\n");
    printf("%f %f add inch  %f 0.2 add inch moveto ( Date: %s ) show\n",
	   LabelFuncX(), XOFFSET, LabelFuncY(), Buffer);
    printf(DEFAULTFONT, DefaultFontSize);
}


static void GenerateLabel (char *p)
{
    Prologue();
    printf("%f inch %f 1 add inch moveto ( %s ) show\n",
	   LabelFuncX(), LabelFuncY(), p);
    Epilogue();
}


/*
   LabelFuncY - returns the number of inches up to the start
               of label, LabelIndex.
*/

static float LabelFuncY (void)
{
  int i;

  if (LabelIndex > (MAXLABEL / NOOFCOLUMNS)) {
    i = LabelIndex - (MAXLABEL / NOOFCOLUMNS);
  } else {
    i = LabelIndex;
  }
  return( (float) 13.0/16.0+i*(10.2/(((float) MAXLABEL)/ (float) NOOFCOLUMNS)) );
}


/*
   LabelFuncX - returns the number of inches up to the start
                of label, LabelIndex.
*/

static float LabelFuncX (void)
{
  int i;

  i = (MAXLABEL / NOOFCOLUMNS);
  return( ((float) (LabelIndex / i)) * (7.0 / (float) NOOFCOLUMNS) + 0.25 );
}
