

#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

/*
   strtime - returns the address of a string which describes the
             local time.
*/

char *wrapc_strtime (void)
{
  long clock   = time((long *)0) ;
  char *string = ctime(&clock);

  string[24] = (char) 0;

  return( string );
}


int wrapc_filesize (int f)
{
  struct stat s;

  if (fstat(f, (struct stat *) &s) == 0) {
    return( s.st_size );
  } else {
    return( -1 );
  }
}

/*
   getrand - returns a random number between 0..n-1
*/

int wrapc_getrand (int n)
{
  return( rand() % n );
}


#include <pwd.h>

char *wrapc_getusername (void)
{
  return( getpwuid(getuid()) -> pw_gecos );
}


/*
   init - init function for the module
*/

_M2_wrapc_init() {}
