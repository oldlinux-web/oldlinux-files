/* Output from p2c, the Pascal-to-C translator */
/* From input file "Tables.md" */


#include <p2c/p2c.h>


#define TablesG
#include "Tables.h"

#ifndef StorageH
#include "Storage.h"
#endif

#ifndef StdIOH
#include "StdIO.h"
#endif

#ifndef StrIOH
#include "StrIO.h"
#endif

#ifndef NumberIOH
#include "NumberIO.h"
#endif

#ifndef StrLibH
#include "StrLib.h"
#endif

#ifndef ASCIIH
#include "ASCII.h"
#endif


#define TableLength     6000
#define LineWidth       256
 

/* p2c: Tables.md, line 17:
 * Warning: Symbol 'Table' was already defined [220] */

typedef struct Word {
  unsigned long key;   /* Table Index */
  struct Word *left, *right;
  unsigned long val;
} Word;


typedef enum {
  less, equal, greater
} Relation;


Static Char asc[TableLength + LineWidth + 1];
Static unsigned long ascinx;


/* %%%FORWARD%%% */
Static Void PrintItem PP((Word *p));

Static Relation Rel PP((unsigned long k));

Static Void Search PP((Word *t, Word **id, Word **father, Relation *r));

Static Void TraverseTree PP((Word *p));


/* %%%FORWARD%%% */

Void Tables_InitTable(t)
Anyptr *t;
{
  *t = Malloc(sizeof(Void));
  if (*t == NULL)
    _OutMem();
  if (*t == NULL)
    _NilCheck();
  ((Word *)(*t))->left = NULL;
}


/*
   Compare asc[ascinx] with asc[k]
*/

Static Relation Rel(k)
unsigned long k;
{
  unsigned long i;
  Relation r;
  Char x, y;

  i = 0;
  x = asc[ascinx];
  y = asc[k];
  r = equal;
  do {
    if (x < y)
      r = less;
    else if (x > y)
      r = greater;
    else {
      i++;
      x = asc[ascinx + i];
      k++;
      y = asc[k];
      if (x == ASCII_nul && y != ASCII_nul)
	r = less;
      else if (x != ASCII_nul && y == ASCII_nul)
	r = greater;
    }
  } while (r == equal && x != ASCII_nul && y != ASCII_nul);
  return r;
}


/*
   Search table, t,with name equal to a. id is set to the node if
   an entry is found, father is set to the node above id.
*/

Static Void Search(t, id, father, r)
Word *t, **id, **father;
Relation *r;
{
  *father = t;
  if (t == NULL)
    _NilCheck();
  *id = t->left;
  if (*id == NULL) {
    *r = less;
    return;
  }
  do {
    if (*id == NULL)
      _NilCheck();
    *r = Rel((*id)->key);
    if (*r == less) {
      *father = *id;
      if (*id == NULL)
	_NilCheck();
      *id = (*id)->left;
    } else if (*r == greater) {
      *father = *id;
      if (*id == NULL)
	_NilCheck();
      *id = (*id)->right;
    }
  } while (*id != NULL && *r != equal);
}


Void Tables_Modify(t, a_LOW, a_HIGH, a, n, done)
Anyptr t;
long a_LOW, a_HIGH;
Char *a;
unsigned long n;
P2C_BOOLEAN *done;
{
  Word *id, *f;
  Relation r;

  Search((Word *)t, &id, &f, &r);
  if (id == NULL)
    *done = P2C_FALSE;
  else {
    if (id == NULL)
      _NilCheck();
    id->val = n;
    *done = P2C_TRUE;
  }
}


P2C_BOOLEAN Tables_Exist(t, a_LOW, a_HIGH, a)
Anyptr t;
long a_LOW, a_HIGH;
Char *a;
{
  Word *f, *c;
  unsigned long i, higha;
  Relation r;

  /* Psedo MACRO - place a[] into asc[] */
  i = 0;
  higha = StrLib_StrLen(0L, a_HIGH - a_LOW, a);
  while (i < higha) {
    asc[ascinx + i] = a[i];
    i++;
  }
  asc[ascinx + i] = ASCII_nul;
  /* END of MACRO */

  Search((Word *)t, &c, &f, &r);
  return (c != NULL);
}


Void Tables_Record(t, a_LOW, a_HIGH, a, n)
Anyptr t;
long a_LOW, a_HIGH;
Char *a;
unsigned long n;
{
  Relation r;
  Word *f, *c;
  unsigned long i, higha;
  Word *WITH;

  if (ascinx > TableLength) {
    /* Halt('Fatel Error --- Symbol Table Overflow') */
    StrIO_WriteString(1L, 44L, "Fatel Error - increase TableLength in Tables");
    StrIO_WriteLn();
    _Escape(0);
  }
  /* Psedo MACRO - place a[] into asc[] */
  i = 0;
  higha = StrLib_StrLen(0L, a_HIGH - a_LOW, a);
  while (i < higha) {
    asc[ascinx + i] = a[i];
    i++;
  }
  asc[ascinx + i] = ASCII_nul;
  /* END of MACRO */

  Search((Word *)t, &c, &f, &r);
  if (c != NULL) {
    if (c == NULL)
      _NilCheck();
    c->val = n;
    return;
  }
  if (r == less) {
    if (f == NULL)
      _NilCheck();
    f->left = (Word *)Malloc(sizeof(Word));
    if (f == NULL)
      _NilCheck();
    if (f->left == NULL)
      _OutMem();
    if (f == NULL)
      _NilCheck();
    c = f->left;
  } else if (r == greater) {
    if (f == NULL)
      _NilCheck();
    f->right = (Word *)Malloc(sizeof(Word));
    if (f == NULL)
      _NilCheck();
    if (f->right == NULL)
      _OutMem();
    if (f == NULL)
      _NilCheck();
    c = f->right;
  }
  if (c == NULL)
    _NilCheck();
  WITH = c;
  WITH->right = NULL;
  WITH->left = NULL;
  WITH->key = ascinx;
  WITH->val = n;
  ascinx += higha + 1;
}


Void Tables_Get(t, a_LOW, a_HIGH, a, n, done)
Anyptr t;
long a_LOW, a_HIGH;
Char *a;
unsigned long *n;
P2C_BOOLEAN *done;
{
  unsigned long i, higha;
  Word *c, *f;
  Relation r;

  /* Psedo MACRO - place a[] into asc[] */
  i = 0;
  higha = StrLib_StrLen(0L, a_HIGH - a_LOW, a);
  while (i < higha) {
    asc[ascinx + i] = a[i];
    i++;
  }
  asc[ascinx + i] = ASCII_nul;
  /* END of MACRO */
  Search((Word *)t, &c, &f, &r);
  if (c == NULL)
    *done = P2C_FALSE;
  else {
    *done = P2C_TRUE;
    if (c == NULL)
      _NilCheck();
    *n = c->val;
  }
}


Void Tables_Tabulate(t)
Anyptr t;
{
  StrIO_WriteLn();
  if (t == NULL)
    _NilCheck();
  TraverseTree(((Word *)t)->left);
}


Static Void TraverseTree(p)
Word *p;
{
  if (p == NULL)
    return;
  if (p == NULL)
    _NilCheck();
  TraverseTree(p->left);
  PrintItem(p);
  if (p == NULL)
    _NilCheck();
  TraverseTree(p->right);
}


Static Void PrintItem(p)
Word *p;
{
  Char ch;
  unsigned long k;

  if (p == NULL)
    _NilCheck();
  NumberIO_WriteCard(p->val, 6L);
  StrIO_WriteString(1L, 3L, "   ");
  if (p == NULL)
    _NilCheck();
  k = p->key;
  do {
    ch = asc[k];
    k++;
    StdIO_Write(ch);
  } while (ch != ASCII_nul);
  StrIO_WriteLn();
}


void _M2_Tables_init()
{
  static int _was_initialized = 0;
  if (_was_initialized++)
    return;
  ascinx = 0;
}
/* p2c: Note: Remember to call _Tables_init() in main program [215] */



/* End. */
