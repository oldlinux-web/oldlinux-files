/* Output from p2c, the Pascal-to-C translator */
/* From input file "M2RTS.mod" */


#include <p2c/p2c.h>


#define M2RTSG
#include "M2RTS.h"


#ifndef libcH
#include "libc.h"
#endif

/*
#ifndef SYSTEMH
#include "SYSTEM.h"
#endif
*/

/* was FROM SYSTEM IMPORT ADDRESS, PROC ; */

#define Max             10


Static unsigned long Ptr;
Static void (*List[Max + 1])(void);
Static long ExitValue;
Static P2C_BOOLEAN CallExit;


/*
   Terminate - calls each installed termination procedure in turn.
*/

void M2RTS_Terminate(void)
{
  unsigned long i;

  i = 0;
  while (i < Ptr) {
    List[i]();
    i++;
  }
}


/*
   HALT - terminate the current program calling creating a core dump.
          The procedure Terminate is called before the core dump is
          created.
*/

void _M2RTS_HALT(void)
{
  M2RTS_Terminate();
  if (CallExit)
    libc_exit(ExitValue);
  else
    libc_abort();
}


typedef struct {
  char *addr;
  int   len;
} _m2_unbounded_string;


/*
 * SubrangeAssignmentError - part of the runtime checking, called if a
 *                           subrange variable is just about to be assigned an illegal value.
*/

void SubrangeAssignmentError (_m2_unbounded_string a, int line)
{
  _M2RTS_HALT;
}


/*
 * ArraySubscriptError -  part of the runtime checking, called if an
 *                        array indice is out of range.
 */

void _M2RTS_ArraySubscriptError (_m2_unbounded_string a, int line)
{
  _M2RTS_HALT;
}


/*
   ExitOnHalt - if HALT is executed then call exit with the exit code, e.
*/

void M2RTS_ExitOnHalt(long e)
{
  ExitValue = e;
  CallExit = P2C_TRUE;
}


/*
   InstallTerminationProcedure - installs a procedure, p, which will
                                 be called when the procedure Terminate
                                 is ionvoked.
*/

void M2RTS_InstallTerminationProcedure(void (*p)(void))
{
  List[Ptr] = p;
  Ptr++;
}


void _M2_M2RTS_init(void)
{
  static int _was_initialized = 0;
  if (_was_initialized++)
    return;
  Ptr = 0;
  ExitValue = 0;
  CallExit = P2C_FALSE;   /* default by calling abort */
}
/* p2c: Note: Remember to call _M2RTS_init() in main program [215] */



/* End. */
