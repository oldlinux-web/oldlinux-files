/*
 *	My standard include file
 *
 ********* History:
 *
 *	Version	Who	Date		Comments
 *	=======	===	====		========
 *	1.3.5	dcw	7th July 1988	COPY_OF calls malloc & checks result
 *	1.3.4	dcw	16th June 1988	Corrected char malloc() to char *...
 *	1.3.3	dcw	6th June 1988	Made BOOL & BOOLEAN char, not int!!
 *	1.3.2	dcw	26th Apr 1988	Added NOC_ALLOC, NOC_NEW, made
 *					COPYOF call NOC_ALLOC !!!
 *	1.3.1	dcw	2nd Mar 1988	Changed name to dcw.h and dcwos.h
 *					included strings.h and ctype.h
 *					added extern calloc() decln
 *	1.3	dcw	9th Sep 1987	Included os.h
 *	1.2	dcw	19th July 1987	Made external 'extern' [was null]
 *					and added brackets in streq
 *	1.1	dcw	2nd July 1987	Added BOOLEAN as well as BOOL !
 *	1.0	dcw	10th June 1987	Wrote it.
 */


#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "dcwos.h"

extern char *calloc(), *malloc();

#define ASSERT(x,y) if(!(x)){printf y;exit(1);}
#define ABORT(y)    ASSERT(FALSE,y)
#define FORWARD
#define EXTERNAL    extern

#define ALLOC(n,t) (t *)calloc((n),sizeof(t))
#define NEW(t)     ALLOC(1,t)

/* make copy of old string into new: */
#define COPYOF(new,old)  {new=malloc(1+strlen(old));if(new)strcpy(new,old);}

#define NOC_ALLOC(n,t) (t *)malloc((n)*sizeof(t))
#define NOC_NEW(t)     NOC_ALLOC(1,t)

#define streq(x,y)  (strcmp((x),(y))==0)

#define BOOL    char
#define BOOLEAN char
#define TRUE    1
#define FALSE   0
