#include  <sys/time.h>


void GetTime (struct timeval *t)
{
  gettimeofday (t, NULL);
}


void _M2_TimeDate_init (void)
{
}
