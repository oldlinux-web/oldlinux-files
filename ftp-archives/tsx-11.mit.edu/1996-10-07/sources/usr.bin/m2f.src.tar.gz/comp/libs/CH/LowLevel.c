

void LowLevel_usleep (int n)
{
  usleep(n);
}

void _M2_LowLevel_init (void) {}  /* to keep Gaius' Modula-2 compiler happy */
