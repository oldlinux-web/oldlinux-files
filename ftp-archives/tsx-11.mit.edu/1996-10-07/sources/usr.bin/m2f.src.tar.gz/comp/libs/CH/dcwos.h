/*
 * Alter this to show which o/s you have
 */

#define UNIX
#define BSD
#undef ATARIST
#undef MSDOS

/*
 * Alter this to show which compiler you have:
 */

#define UNIXC
#undef LATTICE304
#undef MICROSOFT4

/*
 * Define this only if your compiler supports prototypes
 */

#undef HASPROTOS
