/* Output from p2c, the Pascal-to-C translator */
/* From input file "libc.def" */


#include <p2c/p2c.h>


#define libcG
#include "libc.h"
#include "stdio.h"
#include <sys/uio.h>


/*
   getenv - returns the value of an environment string.
*/

char *libc_getenv (char *p)
{
	return( getenv(p) );
}

/*
   isatty - returns true if the default input channel is the keyboard.
*/

int libc_isatty()
{
	return( !isatty(stdout) );
}


/*
   exit - returns an exit status to the process callee.
*/

void libc_exit (r)
int r;
{
	exit(r);
}


#if defined(STAGE1) || defined(LEFTTORIGHT)
long libc_write(d, buf, nbytes)
#else
long libc_write(nbytes, buf, d)
#endif
long nbytes;
Anyptr buf;
long d;
{
	return( write(d, buf, nbytes) );
}


#if defined(STAGE1) || defined(LEFTTORIGHT)
long libc_read(d, buf, nbytes)
#else
long libc_read(nbytes, buf, d)
#endif
long nbytes;
Anyptr buf;
long d;
{
	return( read(d, buf, nbytes) );
}


int libc_system (string)
Anyptr string;
{
    return( system( string ) );
}


/*
     abort - generate a fault

     abort() first closes all open files if possible, then sends
     an IOT signal to the process.  This signal usually results
     in termination with a core dump, which may be used for
     debugging.

     It is possible for abort() to return control if is caught or
     ignored, in which case the value returned is that of the
     kill(2V) system call.
*/

void libc_abort ()
{
	abort();
}


/*
   malloc and cfree.

DESCRIPTION
     These routines provide a general-purpose memory allocation
     package.  They maintain a table of free blocks for efficient
     allocation and coalescing of free storage.  When there is no
     suitable space already free, the allocation routines call
     sbrk() (see brk(2)) to get more memory from the system.
 
     Each of the allocation routines returns a pointer to space
     suitably aligned for storage of any type of object. Each
     returns a NULL pointer if the request cannot be completed.
*/


/*
     malloc - memory allocator.

     char *malloc(size)
     unsigned size;

     malloc() returns a pointer to a block of at least size
     bytes, which is appropriately aligned.  If size is zero,
     malloc() returns a non-NULL pointer, but this pointer should
     not be dereferenced.
*/

Anyptr libc_malloc (size)
unsigned long size;
{
	return( malloc(size) );
}


/*
     cfree - memory deallocator.
 
     cfree(ptr)
     char *ptr;

     free() releases a previously allocated block.  Its argument
     is a pointer to a block previously allocated by malloc, cal-
     loc, realloc, malloc, or memalign.
*/

void libc_cfree (ptr)
Anyptr ptr;
{
	cfree(ptr);
}


/*
   getpid - returns the process identification number.
*/

int libc_getpid (void)
{
  return( getpid() );
}


/*
   dup - duplicates the file descriptor, d.
*/

int libc_dup (int d)
{
  return( dup(d) );
}


/*
   close - closes the file descriptor, d.
*/

int libc_close (int d)
{
  return( close(d) );
}


/*
   open - opens the filename with flag and mode.
*/

#if defined(STAGE1) || defined(LEFTTORIGHT)
int libc_open (char *filename, int flag, int mode)
#else
int libc_open (int mode, int flag, char *filename)
#endif
{
  return( open(filename, flag, mode) );
}


/*
   readv - reads in an io vector of bytes.
*/

int libc_readv (int fd, struct iovec *v, int n)
{
  return( readv(fd, v, n) );
}


/*
   writev - writes an io vector of bytes.
*/

int libc_writev (int fd, struct iovec *v, int n)
{
  return( writev(fd, v, n) );
}


/*
   environ - returns the libc variable environ.
*/

char **libc_environ (void)
{
  return( environ );
}


void _M2_libc_init (void)
{
}


/* End. */
