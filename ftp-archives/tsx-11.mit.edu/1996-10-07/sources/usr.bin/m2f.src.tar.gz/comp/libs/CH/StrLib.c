/* Output from p2c, the Pascal-to-C translator */
/* From input file "StrLib.md" */


#include <p2c/p2c.h>


#define StrLibG
#include "StrLib.h"

#ifndef ASCIIH
#include "ASCII.h"
#endif

/* %%%FORWARD%%% */


/* %%%FORWARD%%% */


P2C_BOOLEAN StrLib_StrEqual(const long a_LOW, const long a_HIGH, Char *a,
			    Char *b)
{
  unsigned long i, Higha, Highb;
  P2C_BOOLEAN Equal;

  Higha = StrLib_StrLen(0L, a_HIGH - a_LOW, a);
  Highb = strlen(b);
  if (Higha != Highb) {
    Equal = P2C_FALSE;
    return Equal;
  }
  Equal = P2C_TRUE;
  i = 0;
  while (Equal && i < Higha) {
    Equal = (a[i] == b[i]);
    i++;
  }
  return Equal;
}


unsigned long StrLib_StrLen(const long a_LOW, const long a_HIGH, Char *a)
{
  unsigned long High, Len;

  Len = 0;
  High = a_HIGH - a_LOW;
  while (Len <= High && a[Len] != ASCII_nul)
    Len++;
  return Len;
}


void StrLib_StrCopy(const long a_LOW, const long a_HIGH, Char *a,
		    const long b_LOW, const long b_HIGH, Char *b)
{
  unsigned long Higha, Highb, n;

  n = 0;
  Higha = StrLib_StrLen(0L, a_HIGH - a_LOW, a);
  Highb = b_HIGH - b_LOW;
  while (n < Higha && n <= Highb) {
    b[n] = a[n];
    n++;
  }
  if (n <= Highb)
    b[n] = ASCII_nul;
}


void StrLib_StrConCat(const long a_LOW, const long a_HIGH, Char *a, Char *b,
		      const long c_LOW, const long c_HIGH, Char *c)
{
  unsigned long Highb, Highc, i, j;
  char OldA[10000];
  char OldB[10000];

  strcpy(OldA, a);
  strcpy(OldB, b);
  Highb = strlen(OldB);
  Highc = c_HIGH - c_LOW;
  StrLib_StrCopy(0L, a_HIGH - a_LOW, OldA, 0L, c_HIGH - c_LOW, c);
  i = StrLib_StrLen(0L, c_HIGH - c_LOW, c);
  j = 0;
  while (j < Highb && i <= Highc) {
    c[i] = OldB[j];
    i++;
    j++;
  }
  if (i <= Highc)
    c[i] = ASCII_nul;
}


/*
   IsSubString - returns true if b is a subcomponent of a.
*/

P2C_BOOLEAN StrLib_IsSubString(const long a_LOW, const long a_HIGH, Char *a,
			       Char *b)
{
  unsigned long i, j, LengthA, LengthB;

  LengthA = StrLib_StrLen(0L, a_HIGH - a_LOW, a);
  LengthB = StrLib_StrLen(0L, a_HIGH - a_LOW, b);
  i = 0;
  if (LengthA <= LengthB)
    return P2C_FALSE;
  while (i <= LengthA - LengthB) {
    j = 0;
    while (j < LengthB && a[i + j] == b[j])
      j++;
    if (j == LengthB)
      return P2C_TRUE;
    i++;
  }
  return P2C_FALSE;
}


void _M2_StrLib_init(void)
{
}
/* p2c: Note: Remember to call _StrLib_init() in main program [215] */



/* End. */
