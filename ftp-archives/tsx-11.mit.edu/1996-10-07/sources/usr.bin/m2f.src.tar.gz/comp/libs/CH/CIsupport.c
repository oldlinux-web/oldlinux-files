/* IMPLEMENTATION MODULE CIsupport WRITTEN IN C; */

/*
 *	This pseudo-module interfaces to the underlying C routines to
 *	do the actual work.
 *
 *	WARNING: This is the output of Create.sh for <TARTAN>
 *	do not modify this file - make changes to Create.sh
 *
 ****** History
 *
 *	Version	Who	Date		Comments
 *	=======	===	====		========
 *	1.0	dcw	4th Sep 1987	Created.
 *	1.1	dcw	15th July 1988	CHAR -> INT in unixgetc & unixungetc
 *	1.2	dcw	24th Aug 1988	Added unixexit here.
 *	1.3	dcw	30th Aug 1988	CHAR -> INT in unixputc
 *	1.4	dcw	14th Sep 1988	Merged in ifdef RTA stuff..
 *	1.5	dcw	10th Oct 1988	Fixed real passing once and for all :-)
 *	1.6	dcw	18th Jan 1989	Fixed unixfreadstr once and for all..
 *					lousy fscanf :-)
 *					also spotted and fixed minor bug in
 *					unixfreadcardinal: - was consumed in
 *					error case
 *	1.7	dcw	24th Jan 1989	Fixed the fix to unixfreadstr ....
 *					now it WILL WORK... honest
 *      2.0	gpcm	Mon Jun 11 15:40:56 BST 1990
 *					Swapped exported procedures to
 *					comply with gm2. Removed
 *					writecardinal etc. only have character
 *					based procedures at the moment.
 */


#include "dcw.h"


#define TABLESIZE 21

static FILE *files[ TABLESIZE ] = {
	stdin, stdout, stderr, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL,
	NULL
};


void CIsupport_unixexit( n ) int n;
{
	exit(n);
}


#if defined(STAGE1) || defined(LEFTTORIGHT)
int CIsupport_unixfopen( name, mode )
#else
int CIsupport_unixfopen( mode, name )
#endif
char *mode, *name ;
{
	FILE *f;
	int i;

/*	printf("filename = %s\n", name) ; */
/*	printf("mode     = %s\n", mode) ; */
	f = fopen( name, mode );
	if( f ) {
		i = firstnull();
		files[ i ] = f;
	} else
		i = -1;
	return i;
}

void CIsupport_unixfclose( file ) int file;
{
	fclose( files[ file ] );
	files[ file ] = NULL;
}

#if defined(STAGE1) || defined(LEFTTORIGHT)
int CIsupport_unixfseek( file, pos, offset )
#else
int CIsupport_unixfseek( offset, pos, file )
#endif
unsigned int pos;
int offset, file;
{
	return fseek( files[ file ], (long) pos, offset );
}

unsigned int CIsupport_unixftell( file ) int file;
{
	extern long ftell();
	return (unsigned int) ftell( files[ file ] );
}

#if defined(STAGE1) || defined(LEFTTORIGHT)
int CIsupport_unixfread( file, n, buf )
#else
int CIsupport_unixfread( buf, n, file )
#endif
char *buf;
unsigned int n;
int file;
{
	return fread( buf, 1, n, files[ file ] );
}


#if defined(STAGE1) || defined(LEFTTORIGHT)
int CIsupport_unixfwrite( file, n, buf )
#else
int CIsupport_unixfwrite( buf, n, file )
#endif
char *buf;
unsigned int n;
int file;
{
	return fwrite( buf, 1, n, files[ file ] );
}


int CIsupport_unixgetc( file ) int file;
{
	return getc( files[ file ] );
}

#if defined(STAGE1) || defined(LEFTTORIGHT)
void CIsupport_unixungetc( file, c )
#else
void CIsupport_unixungetc( c, file )
#endif
int c;
int file;
{
	ungetc( c, files[ file ] );
}

#if defined(STAGE1) || defined(LEFTTORIGHT)
int CIsupport_unixputc( file, c )
#else
int CIsupport_unixputc( c, file )
#endif
int c;
int file;
{
	return fputc( c, files[ file ] ) == EOF ? 1 : 0;
}

/* commented out by gpcm - dont need yet */
/*
int CIsupport_unixfreadcardinal( file, c ) int file; unsigned int *c;
{
	int ch;
	while( isspace(ch=getc(files[file])) );
	ungetc( ch, files[file] );
	if( ch=='-' ) return 1;
	return fscanf( files[ file ], "%u", c ) ? 0 : 1;
}


int CIsupport_unixfwritecardinal( file, c ) int file; unsigned int c;
{
	return fprintf( files[ file], "%u", c ) ? 0 : 1;
}


int CIsupport_unixfreadinteger( file, i ) int file; int *i;
{
	return fscanf( files[ file ], "%d", i ) ? 0 : 1;
}


int CIsupport_unixfwriteinteger( file, i ) int file; int i;
{
	return fprintf( files[ file], "%d", i ) ? 0 : 1;
}


int CIsupport_unixfreadreal( file, r ) int file; float *r;
{
	return fscanf( files[ file ], "%f", r ) ? 0 : 1;
}
*/

/* This procedure must take a float *, rather than the float you would
 * expect, because RTA M-2 and MOCKA M-2 both pass an M-2 'REAL' as a
 * C 'float' on the stack, whereas C always passes a double on the stack
 * even to a procedure which takes "float x" as a parameter!!!
 * float * works on all the compilers so far, however!!!
 */

/* gpcm
int CIsupport_unixfwritereal( file, r ) int file; float *r;
{
	return fprintf( files[ file], "%g", *r ) ? 0 : 1;
}
*/

#if defined(STAGE1) || defined(LEFTTORIGHT)
int CIsupport_unixfreadstr( file, s, m )
#else
int CIsupport_unixfreadstr( m, s, file )
#endif
int m;
char *s;
int file;
{
	int i;
	int c;

	for( i=0; i<=m; i++ ) s[i] = '\0';

	while( (c=getc(files[file])) == ' ' || c == '\t' || c == '\n' );
	ungetc( c, files[file] );
	if( c==EOF ) return 1;

	i = 0;
	for( ;; ) {
		c=getc(files[file]);
	if( c==' ' || c=='\t' || c=='\n' ) break;
		s[i++] = c;
		if( i>m ) return 0;
	}
	ungetc( c, files[file] );
	return 0;
}


#if defined(STAGE1) || defined(LEFTTORIGHT)
int CIsupport_unixfwritestr( file, s )
#else
int CIsupport_unixfwritestr( s, file )
#endif
char *s;
int file;
{
	return fprintf( files[ file], s ) ? 0 : 1;
}


/* --------------------- PRIVATE PROCEDURES -------------------- */


int firstnull()
{
	int i;

	for( i=3; i<TABLESIZE; i++ ) {
		if( files[ i ] == NULL ) return i;
	}
	ABORT( ("firstnull: complete cockup... kill the programmer\n") );
}


/* --------------------- INITIALISE PROCEDURE -------------------- */


_M2_CIsupport_init()
{
}
