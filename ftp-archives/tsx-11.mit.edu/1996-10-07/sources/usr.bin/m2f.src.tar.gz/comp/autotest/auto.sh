#!/bin/sh


M2OPTIONS="-O -g -bounds"

#
# parseArg - see if arg 1 exists if so then this is the directory where the auto.sh
#            script lives.
#

function parseArg () {
   if [ "$1" = "" ] ; then
       echo "testing gm2-i386-gas from " `type gm2-i386-gas`
       AUTODIR="."
   else
       AUTODIR="$1"
   fi
}


#
# checkRun - check whether we should link module $1 and test it's execution.
#

function checkRun () {
   if [ -f mustrunandfail ] ; then
       m2f $M2OPTIONS $1 > /dev/null
       m2f -l $M2OPTIONS $1
       if ./a.out >& /dev/null ; then
           echo "failed run"
       else
           echo -n "[r]"
       fi
   fi
   if [ -f mustrunandpass ] ; then
       m2f $M2OPTIONS $1 > /dev/null
       m2f -l $M2OPTIONS $1
       if ./a.out >& /dev/null ; then
           echo -n "[r]"
       else
           echo "failed run"
       fi
   fi
}


#
# compilePass - runs the compiler on all modules and expects it to succeed on all.
#

function compilePass () {
   j=0
   for i in *.mod ; do
        if [ -f $i ] ; then
           echo -n "$i"
           if gm2-i386-gas -quiet -M "$AUTODIR/../../os/m2mus/def $AUTODIR/../../os/m2mus/mod $AUTODIR/../../comp/libs ." -O `basename $i .mod` ; then
              checkRun $i
              echo -n "	"
              j=`expr $j + 1`
              if [ "`expr $j % 4`" = "0" ] ; then
                   echo ""
              fi
           else
              echo " x"
              echo "failed to compile $i" ;
              cat $i
              export DEBUGCSE=yes
              echo gm2-i386-gas -verbose -q -M \"$AUTODIR/../../os/m2mus/def $AUTODIR/../../os/m2mus/mod $AUTODIR/../../comp/libs .\" -O `basename $i .mod`
              gm2-i386-gas -verbose -q -M "$AUTODIR/../../os/m2mus/def $AUTODIR/../../os/m2mus/mod $AUTODIR/../../comp/libs ." -O `basename $i .mod`
           fi
        fi
    done
}


#
# compileFail - runs the compiler on all modules and expects it to fail on all.
#

function compileFail () {
   j=0
   echo "------------------------------------------------------------"
   echo "     compiling errant code tests                            "
   echo "------------------------------------------------------------"
   for i in *.mod ; do
        if [ -f $i ] ; then
           echo -n "$i"
           if gm2-i386-gas -quiet -M "$AUTODIR/../../os/m2mus/def $AUTODIR/../../os/m2mus/mod $AUTODIR/../../comp/libs ." -O `basename $i .mod` > /dev/null ; then
              echo " x"
              echo "failed to detect error in $i" ;
              cat $i
              export DEBUGCSE=yes
              echo gm2-i386-gas -verbose -q -M \"$AUTODIR/../../os/m2mus/def $AUTODIR/../../os/m2mus/mod $AUTODIR/../../comp/libs .\" -O `basename $i .mod`
              gm2-i386-gas -verbose -q -M "$AUTODIR/../../os/m2mus/def $AUTODIR/../../os/m2mus/mod $AUTODIR/../../comp/libs ." -O  `basename $i .mod`
           else
              echo -n "	"
              j=`expr $j + 1`
              if [ "`expr $j % 4`" = "0" ] ; then
                   echo ""
              fi
           fi
        fi
    done
    echo "------------------------------------------------------------"
}


#
# testModules - test all the modules
#

function testModules () {
   unset DEBUGCSE
   if [ -f mustfail ] ; then
       compileFail
   else
       compilePass
   fi
}


#
# runDirs - traverse subdirectories and execute the test programs.
#

function runDirs () {
   for i in * ; do
      if [ -d $i ] ; then
          echo "[$i]"
          ( cd $i ; ../$AUTODIR/auto.sh "../$AUTODIR" )
      fi
   done
}


#
# main
#

parseArg $1
testModules
runDirs
echo ""
