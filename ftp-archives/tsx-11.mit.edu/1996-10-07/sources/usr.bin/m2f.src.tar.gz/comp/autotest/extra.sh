#!/bin/sh


echo "testing gm2-i386-gas from " `type gm2-i386-gas`
unset DEBUGCSE
unset CSEDEBUG
j=0
for i in testcse*mod ; do
    echo -n "$i	"
    if gm2-i386-gas -quiet -M "../../os/m2mus/def ../../os/m2mus/mod ../libs ." -O -Ocse `basename $i .mod` ; then
       j=`expr $j + 1`
       if [ "`expr $j % 4`" = "0" ] ; then
            echo ""
       fi
    else
       echo "x"
       echo "failed to compile $i" ;
       cat $i
       export DEBUGCSE=yes
       export CSEDEBUG=yes
       gm2-i386-gas -q -M "../../os/m2mus/def ../../os/m2mus/mod ../libs ." -O -Ocse `basename $i .mod`
       exit 1
    fi
done

if gm2-i386-gas -M "../../os/rtp/ass3 ../../os/m2mus/def ../../os/m2mus/mod ../libs ." -O -Ocse Executive ; then
    echo Executive
else
    echo Executive x
fi

echo ""
echo "all cse tests passed"
