#ifdef SHORT_NAMES
#define write_macro_rc w_w_rc
#define add_keysequence a_k_seq
#define count_keynodes c_knodes
#define write_single_keynode w_s_kno
#define write_keynodes w_knode
#define write_break_rc wr_b_rc
#define abort_key ab_key
#endif
