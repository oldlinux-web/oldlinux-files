typedef enum {RC_ENDE,
              RC_DEFKEY,
              RC_DEFMACRO,
              RC_INITMACRO,
              RC_KEYNAME,
              RC_INTS,
              RC_MARKS,
              RC_BREAK,
              RC_AUTOM
             } readtags;
