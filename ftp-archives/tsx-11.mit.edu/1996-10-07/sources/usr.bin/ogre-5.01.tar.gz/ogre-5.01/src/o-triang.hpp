#ifndef OGRE_TRIANGLE
    #define OGRE_TRIANGLE 1

class OgreTriangle : public OgreObject {
public:
    OgreTriangle(float width, float height, float point3_x);
    ~OgreTriangle(void);
};

#endif

