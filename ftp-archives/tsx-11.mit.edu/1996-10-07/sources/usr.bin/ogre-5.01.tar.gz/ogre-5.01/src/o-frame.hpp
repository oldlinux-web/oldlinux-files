#ifndef OGRE_FRAMEWORK
    #define OGRE_FRAMEWORK 1

class OgreFramework : public OgreObject {
public:
    OgreFramework(float radius, int sides, int closed_flag, char *fname);
    ~OgreFramework(void);
};

#endif

