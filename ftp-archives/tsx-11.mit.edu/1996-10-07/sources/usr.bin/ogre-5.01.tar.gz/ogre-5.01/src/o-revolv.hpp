#ifndef OGRE_REVOLVE
    #define OGRE_REVOLVE 1

class OgreRevolution : public OgreObject {
public:
    OgreRevolution(float band_height, int bands_tall, int bands_around,
                   float threshold, float *data);
    ~OgreRevolution(void);
};

#endif

