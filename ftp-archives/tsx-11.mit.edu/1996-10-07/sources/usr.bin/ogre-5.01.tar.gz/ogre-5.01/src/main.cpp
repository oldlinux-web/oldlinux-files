#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "oscript.hpp"


int
main(int argc, char *argv[])
{
    char tempstr[128];
    int i, retval;
    OgreScript *os;

#ifdef MFX
#ifdef __EMX__
    _response(&argc,&argv);
    _wildcard(&argc,&argv);
#endif
    printf("OGRE Version 5.0.1\n");
    printf("Object GeneRator/Editor by David Boeren ");
    printf("<boeren@vsl.ist.ucf.edu>\n");
    printf("12119 Pepperdine Place, ");
    printf("Orlando, FL 32826-3901\n\n");
    printf("Changes by Markus F.X.J. Oberhumer <markus.oberhumer@jk.uni-linz.ac.at>\n\n");
#else
    printf("OGRE Version 5.0\n");
    printf("Object GeneRator/Editor by David Boeren\n");
    printf("407-381-2495\n");
    printf("boeren@vsl.ist.ucf.edu\n");
    printf("12119 Pepperdine Place\n");
    printf("Orlando, FL 32826-3901\n\n");
#endif

    retval = 2;

    if (argc <= 1) {
        printf("Usage: OGRE <fname1.osf> .. <fnameN.osf>\n");
    } else {
        os = new OgreScript();

        for (i=1; i < argc; i++) {
            strcpy(tempstr,argv[i]);
            os->Execute(tempstr);
        }

        retval = os->get_errflag();
        delete os;
    }

    return retval;
}

