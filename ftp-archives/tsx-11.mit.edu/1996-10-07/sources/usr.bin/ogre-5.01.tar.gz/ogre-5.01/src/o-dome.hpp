#ifndef OGRE_DOME
    #define OGRE_DOME 1

class OgreDome : public OgreObject {
public:
    OgreDome(float radius, int bands_tall, int bands_around);
    ~OgreDome(void);
};

#endif

