#ifndef OGRE_PANEL
    #define OGRE_PANEL 1

class OgrePanel : public OgreObject {
public:
    OgrePanel(int num_points, float band_width, float thickness,
              float threshold, float *data);
    ~OgrePanel(void);
};

#endif

