#ifndef OGRE_CHECKER
    #define OGRE_CHECKER 1

class OgreCheckerBoard : public OgreObject {
public:
    OgreCheckerBoard(int xdim, int ydim, float patch_xsize, float patch_ysize,
                     float thickness,
                     unsigned char r1, unsigned char g1, unsigned char b1,
                     unsigned char r2, unsigned char g2, unsigned char b2);
    ~OgreCheckerBoard(void);
};

#endif

