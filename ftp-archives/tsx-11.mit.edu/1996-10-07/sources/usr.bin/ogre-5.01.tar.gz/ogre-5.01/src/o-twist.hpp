#ifndef OGRE_TWIST
    #define OGRE_TWIST 1

class OgreTwist : public OgreObject {
public:
    OgreTwist(char *fname);
    ~OgreTwist(void);
};

#endif

