#ifndef OGRE_CYLINDER
    #define OGRE_CYLINDER 1

class OgreCylinder : public OgreObject {
public:
    OgreCylinder(float top_radius, float bottom_radius, float height, int sides);
    ~OgreCylinder(void);
};

#endif

