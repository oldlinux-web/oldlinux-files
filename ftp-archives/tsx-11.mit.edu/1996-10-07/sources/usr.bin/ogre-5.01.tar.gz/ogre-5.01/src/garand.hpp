/****************************************************************************
*  Module:  GA_rand.c                                                       *
*  Description:  A fast and effecive random number generation system using  *
*      as little of the standard library as possible to encourage maximum   *
*      portability across different computers and different compilers.      *
*      This library was originally developed to support work in Genetic     *
*      Algorithms, which may require tens of thousands of random numbers    *
*      per second.
****************************************************************************/


/* Function Prototypes */
void GArand_seed(unsigned int seed);
unsigned int GArand(void);

