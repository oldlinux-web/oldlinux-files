#ifndef OGRE_FUZZY
    #define OGRE_FUZZY 1

class OgreFuzzy : public OgreObject {
public:
    OgreFuzzy(float base_radius, int rand_radius,
              int bands_tall, int bands_around);
    OgreFuzzy(char *fname);
    ~OgreFuzzy(void);
};

#endif

