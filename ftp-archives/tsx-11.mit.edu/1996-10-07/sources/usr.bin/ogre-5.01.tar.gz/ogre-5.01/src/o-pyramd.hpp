#ifndef OGRE_PYRAMID
    #define OGRE_PYRAMID 1

class OgrePyramid : public OgreObject {
public:
    OgrePyramid(float radius, float height, int sides);
    ~OgrePyramid(void);
};

#endif

