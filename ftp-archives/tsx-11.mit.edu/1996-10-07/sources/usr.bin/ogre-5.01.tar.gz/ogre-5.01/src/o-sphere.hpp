#ifndef OGRE_SPHERE
    #define OGRE_SPHERE 1

class OgreSphere : public OgreObject {
public:
    OgreSphere(float radius, int bands_tall, int bands_around);
    ~OgreSphere(void);
};

#endif

