#ifndef OGRE_TORUS
    #define OGRE_TORUS 1

class OgreTorus : public OgreObject {
public:
    OgreTorus(float orbit_radius, float ring_radius, int orbit_around,
              int ring_around);
    ~OgreTorus(void);
};

#endif

