#ifndef OGRE_BICONE
    #define OGRE_BICONE 1

class OgreBiCone : public OgreObject {
public:
    OgreBiCone(float radius, float top_height, float bottom_height, int sides);
    ~OgreBiCone(void);
};

#endif

