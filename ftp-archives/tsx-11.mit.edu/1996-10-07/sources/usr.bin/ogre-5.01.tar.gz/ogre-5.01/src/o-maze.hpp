#ifndef OGRE_MAZE
    #define OGRE_MAZE 1

class OgreMaze : public OgreObject {
public:
    OgreMaze(char *fname);
    ~OgreMaze(void);
};

#endif

