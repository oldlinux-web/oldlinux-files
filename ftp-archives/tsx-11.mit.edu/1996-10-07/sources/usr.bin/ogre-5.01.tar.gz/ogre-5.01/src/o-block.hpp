#ifndef OGRE_BLOCK
    #define OGRE_BLOCK 1

class OgreBlock : public OgreObject {
public:
    OgreBlock(float xsize, float ysize, float zsize);
    ~OgreBlock(void);
};

#endif

