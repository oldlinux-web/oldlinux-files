#ifndef OGRE_POSTFIELD
    #define OGRE_POSTFIELD 1

class OgrePostField : public OgreObject {
public:
    OgrePostField(int xdim, int ydim, float patch_xsize, float patch_ysize,
                  int maxheight);
    OgrePostField(char *fname);
    ~OgrePostField(void);
};

#endif

