#ifndef OGRE_SOCCER
    #define OGRE_SOCCER 1

class OgreSoccer : public OgreObject {
public:
    OgreSoccer(float radius);
    ~OgreSoccer(void);
};

#endif

