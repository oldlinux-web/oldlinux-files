#ifndef OGRE_GEAR
    #define OGRE_GEAR 1

class OgreGear : public OgreObject {
public:
    OgreGear(float major_radius, float minor_radius, float height, int teeth);
    ~OgreGear(void);
};

#endif

