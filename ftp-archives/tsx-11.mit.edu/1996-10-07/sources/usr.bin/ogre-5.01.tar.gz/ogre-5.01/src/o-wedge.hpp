#ifndef OGRE_WEDGE
    #define OGRE_WEDGE 1

class OgreWedge : public OgreObject {
public:
    OgreWedge(float arc_angle, float radius, float rim_height, int rim_sides);
    ~OgreWedge(void);
};

#endif

