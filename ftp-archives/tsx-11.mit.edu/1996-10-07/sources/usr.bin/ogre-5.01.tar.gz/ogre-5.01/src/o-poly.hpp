#ifndef OGRE_POLYGON
    #define OGRE_POLYGON 1

class OgrePolygon : public OgreObject {
public:
    OgrePolygon(int sides, float radius);
    ~OgrePolygon(void);
};

#endif

