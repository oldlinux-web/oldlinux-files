#ifndef OGRE_RECTANGLE
    #define OGRE_RECTANGLE 1

class OgreRectangle : public OgreObject {
public:
    OgreRectangle(float x_size, float y_size);
    ~OgreRectangle(void);
};

#endif

