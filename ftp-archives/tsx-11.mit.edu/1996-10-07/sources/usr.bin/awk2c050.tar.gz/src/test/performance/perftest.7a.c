#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__a;
AWKNUM num__a = 0;
NODE *constnode1;
NODE *constnode2;
NODE *constnode3;
NODE *constnode4;
NODE *constnode5;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __a = setup_varnode();

  constnode5 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode4 = mk_number(100.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode8 = mk_number(0.9000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode7 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode6 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode2 = make_str_node("56", 2, (unsigned short) 0);
  constnode2->flags = 29;
  constnode3 = make_str_node("1", 1, (unsigned short) 0);
  constnode3->flags = 29;


}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  num__a = ((((pow((double) (force_number(access_fvar((int) (2.0000000000)))), (double) (56.0000000000))) * (cmp_nodes((access_fvar((int) ((2.0000000000) - (1.0000000000)))), constnode4) < 0)) * (((5.0000000000) / (100.0000000000)) - (3.0000000000))) + (fmod((double) (100.0000000000), (double) (5.0000000000)))) - (pow((double) (force_number(access_fvar((int) (1.0000000000)))), (double) (0.9000000000)));
}


/*********** END **********/

void 
awk2c_end(void)
{
}
