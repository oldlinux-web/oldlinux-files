#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__a;
AWKNUM num__a = 0;
NODE *constnode1;
NODE *__b;
AWKNUM num__b = 0;
NODE *constnode2;
NODE *__fff;
AWKNUM num__fff = 0;
NODE *constnode3;
NODE *__fff1;
AWKNUM num__fff1 = 0;
NODE *__fff2;
AWKNUM num__fff2 = 0;
NODE *__fff3;
AWKNUM num__fff3 = 0;
NODE *__fff4;
AWKNUM num__fff4 = 0;
NODE *__fff5;
AWKNUM num__fff5 = 0;
NODE *__fff6;
AWKNUM num__fff6 = 0;
NODE *constnode4;
NODE *constnode5;
NODE *constnode6;
NODE *constnode7;
NODE *__aaix;
AWKNUM num__aaix = 0;
NODE *__c;
AWKNUM num__c = 0;
NODE *constnode8;
NODE *__d;
AWKNUM num__d = 0;
NODE *constnode9;
NODE *__zz;
AWKNUM num__zz = 0;
NODE *constnode10;
NODE *constnode11;
NODE *__aa;
AWKNUM num__aa = 0;
NODE *constnode12;
NODE *constnode13;
NODE *constnode14;
NODE *constnode15;
NODE *constnode16;
NODE *__ggg;
AWKNUM num__ggg = 0;
NODE *__abcd;
AWKNUM num__abcd = 0;
NODE *constnode17;
NODE *constnode18;
NODE *constnode19;
NODE *constnode20;
NODE *__e;
AWKNUM num__e = 0;
NODE *__f;
AWKNUM num__f = 0;
NODE *__zz1;
AWKNUM num__zz1 = 0;
NODE *__zz2;
AWKNUM num__zz2 = 0;
NODE *__zz3;
AWKNUM num__zz3 = 0;
NODE *constnode21;
NODE *__zz4;
AWKNUM num__zz4 = 0;
NODE *__zz5;
AWKNUM num__zz5 = 0;
NODE *__zz6;
AWKNUM num__zz6 = 0;
NODE *__zz7;
AWKNUM num__zz7 = 0;
NODE *__zz8;
AWKNUM num__zz8 = 0;
NODE *constnode22;
NODE *constnode23;
NODE *constnode24;
NODE *__kkk;
AWKNUM num__kkk = 0;
NODE *constnode25;
NODE *constnode26;
NODE *constnode27;
NODE *constnode28;
NODE *constnode29;
NODE *constnode30;
NODE *__jj;
AWKNUM num__jj = 0;
NODE *constnode31;
NODE *constnode32;
NODE *constnode33;
NODE *constnode34;
NODE *constnode35;
NODE *__hh;
AWKNUM num__hh = 0;
NODE *constnode36;
NODE *constnode37;
NODE *__ii;
AWKNUM num__ii = 0;
NODE *constnode38;
NODE *constnode39;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __hh = setup_varnode();
  __kkk = setup_varnode();
  __a = setup_varnode();
  __b = setup_varnode();
  __c = setup_varnode();
  __d = setup_varnode();
  __e = setup_varnode();
  __f = setup_varnode();
  __aa = setup_varnode();
  __ii = setup_varnode();
  __zz1 = setup_varnode();
  __zz2 = setup_varnode();
  __zz3 = setup_varnode();
  __zz4 = setup_varnode();
  __zz5 = setup_varnode();
  __zz6 = setup_varnode();
  __zz7 = setup_varnode();
  __zz8 = setup_varnode();
  __aaix = setup_varnode();
  __jj = setup_varnode();
  __zz = setup_varnode();
  __abcd = setup_varnode();
  __fff1 = setup_varnode();
  __fff2 = setup_varnode();
  __fff3 = setup_varnode();
  __fff4 = setup_varnode();
  __fff5 = setup_varnode();
  __fff6 = setup_varnode();
  __ggg = setup_varnode();
  __fff = setup_varnode();

  constnode38 = mk_number(17.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode17 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode21 = mk_number(56.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode31 = mk_number(20.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode15 = mk_number(11.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode8 = mk_number(12.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(0.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode4 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode3 = mk_number(14.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode11 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode36 = mk_number(34.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode5 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode35 = make_str_node("aa[aaix] =", 10, (unsigned short) 0);
  constnode35->flags = 29;
  constnode26 = make_str_node("$2 =", 4, (unsigned short) 0);
  constnode26->flags = 29;
  constnode27 = make_str_node("$0 =", 4, (unsigned short) 0);
  constnode27->flags = 29;
  constnode18 = make_str_node("a++ =", 5, (unsigned short) 0);
  constnode18->flags = 29;
  constnode37 = make_str_node("hh =", 4, (unsigned short) 0);
  constnode37->flags = 29;
  constnode28 = make_str_node("d++", 3, (unsigned short) 0);
  constnode28->flags = 29;
  constnode19 = make_str_node("++a =", 5, (unsigned short) 0);
  constnode19->flags = 29;
  constnode6 = make_str_node("fff = ", 6, (unsigned short) 0);
  constnode6->flags = 29;
  constnode29 = make_str_node("f += f:", 7, (unsigned short) 0);
  constnode29->flags = 29;
  constnode7 = make_str_node("fff2 =", 6, (unsigned short) 0);
  constnode7->flags = 29;
  constnode39 = make_str_node("ii %= 5:", 8, (unsigned short) 0);
  constnode39->flags = 29;
  constnode9 = make_str_node("45.3", 4, (unsigned short) 0);
  constnode9->flags = 29;
  constnode10 = make_str_node("1.1", 3, (unsigned short) 0);
  constnode10->flags = 29;
  constnode20 = make_str_node("a = ", 4, (unsigned short) 0);
  constnode20->flags = 29;
  constnode30 = make_str_node("NF =", 4, (unsigned short) 0);
  constnode30->flags = 29;
  constnode12 = make_str_node("XX1", 3, (unsigned short) 0);
  constnode12->flags = 29;
  constnode22 = make_str_node("zz7 =", 5, (unsigned short) 0);
  constnode22->flags = 29;
  constnode13 = make_str_node("XX2", 3, (unsigned short) 0);
  constnode13->flags = 29;
  constnode32 = make_str_node("kkk =", 5, (unsigned short) 0);
  constnode32->flags = 29;
  constnode23 = make_str_node("zz5 =", 5, (unsigned short) 0);
  constnode23->flags = 29;
  constnode14 = make_str_node("XX3", 3, (unsigned short) 0);
  constnode14->flags = 29;
  constnode33 = make_str_node("jj =", 4, (unsigned short) 0);
  constnode33->flags = 29;
  constnode24 = make_str_node("zz8 =", 5, (unsigned short) 0);
  constnode24->flags = 29;
  constnode2 = make_str_node("abc", 3, (unsigned short) 0);
  constnode2->flags = 29;
  constnode34 = make_str_node("aa[aaix--] =", 12, (unsigned short) 0);
  constnode34->flags = 29;
  constnode25 = make_str_node("2", 1, (unsigned short) 0);
  constnode25->flags = 29;
  constnode16 = make_str_node("XX4", 3, (unsigned short) 0);
  constnode16->flags = 29;


  (assign_var_num(addr_var(__a), 0.0000000000));
  (assign_var_var(addr_var(__b), constnode2));
  (assign_var_num(addr_var(__fff), 14.0000000000));
  num__fff1 = peek_number(assign_var_num(addr_var(__fff2), num__fff3 = (tmp_numbr = peek_number(access_var(__fff)), (assign_var_num(addr_var(__fff), peek_number(access_var(__fff)) + 1)), tmp_numbr)));
  num__fff1 = peek_number(assign_var_num(addr_var(__fff2), num__fff3 = peek_number(assign_var_num(addr_var(__fff), peek_number(access_var(__fff)) - 1))));
  num__fff4 = num__fff5 = num__fff6 = (1.0000000000) + (3.0000000000);
  do_print2(constnode6, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__fff)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode7, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__fff2)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var_num(addr_var(__aaix), num__c = 12.0000000000));
  (assign_var_var(addr_var(__d), constnode9));
  (assign_var_var(addr_var(__zz), constnode10));
  (assign_var2_var(Node_subscript, __aa, 0, force_string2(constnode11), constnode12));
  (assign_var2_var(Node_subscript, __aa, 0, force_string2(constnode5), constnode13));
  (assign_var2_var(Node_subscript, __aa, 0, force_string2(constnode8), constnode14));
  (assign_var2_var(Node_subscript, __aa, 0, force_string2(constnode15), constnode16));
}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  (assign_var2_var(Node_subscript, __ggg, 0, (access_fvar((int) (1.0000000000))), (access_fvar((int) (1.0000000000)))));
  num__abcd = 5.0000000000;
  do_print2(constnode18, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((unref(tmp_node2), tmp_node2 = make_number(peek_number(access_var(__a))), (assign_var_num(addr_var(__a), peek_number(access_var(__a)) + 1)), tmp_node2), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode19, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((assign_var_num(addr_var(__a), peek_number(access_var(__a)) + 1)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode20, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__a)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  num__e = peek_number(assign_var_num(addr_var(__f), --num__c));
  num__zz1 = num__zz2 = num__zz3 = 56.0000000000;
  num__zz4 = peek_number(assign_var_num(addr_var(__zz5), num__zz6 = (1.0000000000) + (3.0000000000)));
  (assign_var_num(addr_var(__zz7), peek_number(assign_var_num(addr_var(__zz8), (tmp_numbr = peek_number(access_var(__zz5)), (assign_var_num(addr_var(__zz5), peek_number(access_var(__zz5)) + 1)), tmp_numbr)))));
  do_print2(constnode22, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__zz7)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode23, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__zz5)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var_num(addr_var(__zz7), peek_number(assign_var_num(addr_var(__zz8), peek_number(assign_var_num(addr_var(__zz5), peek_number(access_var(__zz5)) + 1))))));
  do_print2(constnode24, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__zz8)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var_num(addr_var(__kkk), num__c += 3.0000000000));
  num__c += force_number(access_var(__zz));
  num__c *= 2.0000000000;
  do_print2(constnode26, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_fvar((int) (2.0000000000))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var2_num(Node_field_spec, NULL, (int) (2.0000000000), NULL, force_number(access_fvar((int) (2.0000000000))) + 1));
  do_print2(constnode27, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_fvar((int) (0.0000000000))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode28, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((unref(tmp_node2), tmp_node2 = make_number(force_number(access_var(__d))), (assign_var_num(addr_var(__d), peek_number(access_var(__d)) + 1)), tmp_node2), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode29, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((assign_var_num(addr_var(__f), peek_number(access_var(__f)) + peek_number(access_var(__f)))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var2_num(Node_NF, NULL, 0, NULL, peek_number(access_spvar(Node_NF)) + 1.0000000000));
  (assign_var2_num(Node_NF, NULL, 0, NULL, peek_number(access_spvar(Node_NF)) - 1));
  do_print2(constnode30, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_spvar(Node_NF)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);


/* -------------------- Rule/Actions -------------------- */

  for ((assign_var_num(addr_var(__jj), 1.0000000000));
       (peek_number(access_var(__jj))) <= (20.0000000000);
       (assign_var_num(addr_var(__jj), peek_number(access_var(__jj)) + 1)))
    {
      (assign_var_num(addr_var(__jj), peek_number(access_var(__jj)) + 1.0000000000));
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
  do_print2(constnode32, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__kkk)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode33, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__jj)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode34, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, (unref(tmp_node2), tmp_node2 = make_number(peek_number(access_var(__aaix))), (assign_var_num(addr_var(__aaix), peek_number(access_var(__aaix)) - 1)), force_string2(tmp_node2)))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode35, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, force_string2(access_var(__aaix)))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var_num(addr_var(__hh), 34.0000000000));
  (assign_var_num(addr_var(__hh), peek_number(access_var(__hh)) / peek_number(access_var(__hh))));
  do_print2(constnode37, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__hh)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var_num(addr_var(__ii), 17.0000000000));
  (assign_var_num(addr_var(__ii), fmod((double) (peek_number(access_var(__ii))), (double) (5.0000000000))));
  do_print2(constnode39, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__ii)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
}
