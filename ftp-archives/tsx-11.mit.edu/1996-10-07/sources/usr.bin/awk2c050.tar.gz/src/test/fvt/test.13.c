#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__a;
AWKNUM num__a = 0;
NODE *constnode1;
NODE *__kk;
AWKNUM num__kk = 0;
NODE *constnode2;
NODE *__kk2;
AWKNUM num__kk2 = 0;
NODE *__oo;
AWKNUM num__oo = 0;
NODE *__oo1;
AWKNUM num__oo1 = 0;
NODE *__a_;
AWKNUM num__a_ = 0;
NODE *__b_;
AWKNUM num__b_ = 0;
NODE *__c_;
AWKNUM num__c_ = 0;
NODE *constnode3;
NODE *__d_;
AWKNUM num__d_ = 0;
NODE *__e_;
AWKNUM num__e_ = 0;
NODE *__f_;
AWKNUM num__f_ = 0;
NODE *__ff;
AWKNUM num__ff = 0;
NODE *__gg_;
AWKNUM num__gg_ = 0;
NODE *constnode4;
NODE *__hh;
AWKNUM num__hh = 0;
NODE *constnode5;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;
NODE *constnode9;
NODE *constnode10;
NODE *constnode11;
NODE *__b;
AWKNUM num__b = 0;
NODE *constnode12;
NODE *constnode13;
NODE *__gh;
AWKNUM num__gh = 0;
NODE *__i;
AWKNUM num__i = 0;
NODE *__aa;
AWKNUM num__aa = 0;
NODE *constnode14;
NODE *constnode15;
NODE *constnode16;
NODE *constnode17;
NODE *constnode18;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __kk2 = setup_varnode();
  __d_ = setup_varnode();
  __hh = setup_varnode();
  __a = setup_varnode();
  __b = setup_varnode();
  __i = setup_varnode();
  __e_ = setup_varnode();
  __a_ = setup_varnode();
  __aa = setup_varnode();
  __oo1 = setup_varnode();
  __f_ = setup_varnode();
  __b_ = setup_varnode();
  __ff = setup_varnode();
  __gg_ = setup_varnode();
  __c_ = setup_varnode();
  __gh = setup_varnode();
  __kk = setup_varnode();
  __oo = setup_varnode();

  constnode2 = mk_number(4.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode3 = mk_number(45.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode18 = mk_number(10.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode15 = mk_number(78.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode10 = mk_number(0.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode7 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode6 = mk_number(34.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode4 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode17 = make_str_node("b>1 is true", 11, (unsigned short) 0);
  constnode17->flags = 29;
  constnode5 = make_str_node("fsdhfkj", 7, (unsigned short) 0);
  constnode5->flags = 29;
  constnode8 = make_str_node("in block 3, hh=", 15, (unsigned short) 0);
  constnode8->flags = 29;
  constnode9 = make_str_node("kk<5 is true", 12, (unsigned short) 0);
  constnode9->flags = 29;
  constnode11 = make_str_node("dfsd", 4, (unsigned short) 0);
  constnode11->flags = 29;
  constnode12 = make_str_node("34", 2, (unsigned short) 0);
  constnode12->flags = 29;
  constnode13 = make_str_node("gdfg", 4, (unsigned short) 0);
  constnode13->flags = 29;
  constnode14 = make_str_node("abc", 3, (unsigned short) 0);
  constnode14->flags = 29;
  constnode16 = make_str_node("a<78 is true", 12, (unsigned short) 0);
  constnode16->flags = 29;


  (assign_var_num(addr_var(__a), 5.0000000000));
  (assign_var_num(addr_var(__kk), 4.0000000000));
  (assign_var_num(addr_var(__kk), 4.0000000000));
  num__kk2 = peek_number(access_var(__a));
  num__oo = num__oo1++;
  num__oo = num__oo1++;
  num__a_ = num__b_ = num__c_ = 45.0000000000;
}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  (assign_var_num(addr_var(__d_), peek_number(assign_var_num(addr_var(__e_), num__f_ = 45.0000000000))));
  (assign_var_num(addr_var(__d_), peek_number(assign_var_num(addr_var(__e_), num__f_))));
  (access_avar(__ff, force_string2(assign_var_num(addr_var(__a), 5.0000000000))));
  (peek_number(assign_var_num(addr_var(__a), 5.0000000000))) > (num__gg_ = 3.0000000000);
  (assign_var_var(addr_var(__hh), constnode5));
  (force_number(access_var(__hh))) + (3.0000000000);
  (assign_var_num(addr_var(__hh), 34.0000000000));


/* -------------------- Rule/Actions -------------------- */

  if ((1.0000000000) == (1.0000000000))
    {
      if (1.0000000000)
	{
	  (assign_var_num(addr_var(__hh), 3.0000000000));
	}
    }
  else
    {
    }


/* -------------------- Rule/Actions -------------------- */

  if ((peek_number(access_var(__hh))) > (3.0000000000))
    {
      do_print2(constnode8, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__hh)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      cmp_nodes((access_fvar((int) (1.0000000000))), (access_var(__hh))) > 0;
      cmp_nodes((access_fvar((int) (1.0000000000))), constnode7) > 0;
    }
  else
    {
    }


/* -------------------- Rule/Actions -------------------- */

  if (cmp_nodes((access_var(__kk)), constnode1) < 0)
    {
      do_print2(constnode9, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  while (((peek_number(access_spvar(Node_NF))) > (1.0000000000)) && (0.0000000000))
    {
      1.0000000000;
    }
  (assign_var2_var(Node_NF, NULL, 0, NULL, constnode11));


/* -------------------- Rule/Actions -------------------- */

  if (bool_var(access_fvar((int) (1.0000000000))))
    {
      (assign_var_var(addr_var(__b), constnode12));
      (assign_var_num(addr_var(__hh), 34.0000000000));
      if ((1.0000000000) > (0.0000000000))
	{
	  (assign_var_num(addr_var(__b), 45.0000000000));
	  (assign_var_var(addr_var(__hh), constnode13));
	}
      (assign_var_var(addr_var(__gh), (access_fvar((int) ((5.0000000000) - (4.0000000000))))));
      (assign_var_var(addr_var(__hh), (access_var(__gh))));
      num__i = 45.0000000000;
    }
  else
    {
    }


/* -------------------- Rule/Actions -------------------- */

  (assign_var2_num(Node_subscript, __aa, 0, force_string2(access_var(__hh)), 3.0000000000));
  (assign_var_var(addr_var(__kk), constnode14));
  do_print2((access_avar(__aa, (access_var(__hh)))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);


/* -------------------- Rule/Actions -------------------- */

  if ((peek_number(access_var(__a))) < (78.0000000000))
    {
      do_print2(constnode16, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  if (cmp_nodes((access_var(__b)), constnode7) > 0)
    {
      do_print2(constnode17, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  while (((num__i) > (5.0000000000)) && (0.0000000000))
    {
      1.0000000000;
      if ((5.0000000000) < (10.0000000000))
	{
	}
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
}
