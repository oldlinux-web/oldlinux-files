#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__a;
AWKNUM num__a = 0;
NODE *constnode1;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __a = setup_varnode();

  constnode1 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));



}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  (assign_var_num(addr_var(__a), (peek_number(access_var(__a))) + (force_number(access_fvar((int) (1.0000000000))))));
  do_print2((access_var(__a)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
}


/*********** END **********/

void 
awk2c_end(void)
{
}
