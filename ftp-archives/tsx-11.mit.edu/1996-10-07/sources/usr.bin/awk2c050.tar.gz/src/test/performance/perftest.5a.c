#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__a;
AWKNUM num__a = 0;
NODE *constnode1;
NODE *__c;
AWKNUM num__c = 0;
NODE *constnode2;
NODE *__d;
AWKNUM num__d = 0;
NODE *constnode3;
NODE *constnode4;
NODE *__gg;
AWKNUM num__gg = 0;
NODE *constnode5;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;
NODE *regnode1;
NODE *regnode2;
NODE *__g;
AWKNUM num__g = 0;
NODE *constnode9;
NODE *constnode10;
NODE *__h;
AWKNUM num__h = 0;
NODE *constnode11;
NODE *constnode12;
NODE *constnode13;
NODE *__l;
AWKNUM num__l = 0;
NODE *constnode14;
NODE *constnode15;
NODE *constnode16;
NODE *__i;
AWKNUM num__i = 0;
NODE *constnode17;
NODE *__b;
AWKNUM num__b = 0;
NODE *__hh;
AWKNUM num__hh = 0;
NODE *__strr;
AWKNUM num__strr = 0;
NODE *constnode18;
NODE *constnode19;
NODE *constnode20;
NODE *constnode21;
NODE *constnode22;
NODE *regnode3;
NODE *constnode23;
NODE *constnode24;
NODE *constnode25;
NODE *constnode26;
NODE *constnode27;
NODE *constnode28;
NODE *constnode29;
NODE *constnode30;
NODE *constnode31;
NODE *constnode32;
NODE *constnode33;
NODE *constnode34;
NODE *__fhjk;
AWKNUM num__fhjk = 0;
NODE *constnode35;
NODE *constnode36;
NODE *constnode37;
NODE *constnode38;
NODE *constnode39;
NODE *constnode40;
NODE *constnode41;
NODE *constnode42;
NODE *constnode43;
NODE *constnode44;
NODE *constnode45;
NODE *constnode46;
NODE *constnode47;
NODE *constnode48;
NODE *__RF;
AWKNUM num__RF = 0;
NODE *constnode49;
NODE *constnode50;
NODE *constnode51;
NODE *constnode52;
NODE *constnode53;
NODE *constnode54;
NODE *__zz1;
AWKNUM num__zz1 = 0;
NODE *__zz2;
AWKNUM num__zz2 = 0;
NODE *constnode55;
NODE *constnode56;
NODE *constnode57;
NODE *__j;
AWKNUM num__j = 0;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __hh = setup_varnode();
  __a = setup_varnode();
  __b = setup_varnode();
  __c = setup_varnode();
  __d = setup_varnode();
  __g = setup_varnode();
  __h = setup_varnode();
  __i = setup_varnode();
  __j = setup_varnode();
  __l = setup_varnode();
  __zz1 = setup_varnode();
  __zz2 = setup_varnode();
  __RF = setup_varnode();
  __gg = setup_varnode();
  __fhjk = setup_varnode();
  __strr = setup_varnode();

  constnode13 = mk_number(4.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode48 = mk_number(27.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode49 = mk_number(28.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode14 = mk_number(6.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode55 = mk_number(56.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode50 = mk_number(29.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode17 = mk_number(100.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode2 = mk_number(7.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode16 = mk_number(8.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode24 = mk_number(9.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode23 = mk_number(10.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode41 = mk_number(11.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode53 = mk_number(30.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode45 = mk_number(12.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode54 = mk_number(31.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode4 = mk_number(0.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode52 = mk_number(99.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode6 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode5 = mk_number(23.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode3 = mk_number(50.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode11 = mk_number(1.4342000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode10 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode12 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode44 = make_str_node("Match 11", 8, (unsigned short) 0);
  constnode44->flags = 29;
  constnode35 = make_str_node("4", 1, (unsigned short) 0);
  constnode35->flags = 29;
  constnode26 = make_str_node("5", 1, (unsigned short) 0);
  constnode26->flags = 29;
  constnode36 = make_str_node("Match 7", 7, (unsigned short) 0);
  constnode36->flags = 29;
  constnode27 = make_str_node("Match 2", 7, (unsigned short) 0);
  constnode27->flags = 29;
  constnode18 = make_str_node("fhdjhfjshskh", 12, (unsigned short) 0);
  constnode18->flags = 29;
  constnode46 = make_str_node("abcde", 5, (unsigned short) 0);
  constnode46->flags = 29;
  constnode37 = make_str_node("Match 8", 7, (unsigned short) 0);
  constnode37->flags = 29;
  constnode28 = make_str_node("ab", 2, (unsigned short) 0);
  constnode28->flags = 29;
  constnode19 = make_str_node("ab", 2, (unsigned short) 0);
  constnode19->flags = 29;
  constnode56 = make_str_node("i=", 2, (unsigned short) 0);
  constnode56->flags = 29;
  constnode47 = make_str_node("Match 12", 8, (unsigned short) 0);
  constnode47->flags = 29;
  constnode38 = make_str_node("Match 9", 7, (unsigned short) 0);
  constnode38->flags = 29;
  constnode29 = make_str_node("a", 1, (unsigned short) 0);
  constnode29->flags = 29;
  constnode7 = make_str_node("0.0e0", 5, (unsigned short) 0);
  constnode7->flags = 29;
  constnode57 = make_str_node(" j=", 3, (unsigned short) 0);
  constnode57->flags = 29;
  constnode39 = make_str_node("6.7", 3, (unsigned short) 0);
  constnode39->flags = 29;
  constnode8 = make_str_node("3a434fd", 7, (unsigned short) 0);
  constnode8->flags = 29;
  constnode9 = make_str_node("fdsfsdf", 7, (unsigned short) 0);
  constnode9->flags = 29;
  constnode20 = make_str_node("cc", 2, (unsigned short) 0);
  constnode20->flags = 29;
  constnode30 = make_str_node("Match 3", 7, (unsigned short) 0);
  constnode30->flags = 29;
  constnode21 = make_str_node("de", 2, (unsigned short) 0);
  constnode21->flags = 29;
  constnode40 = make_str_node("Match 10", 8, (unsigned short) 0);
  constnode40->flags = 29;
  constnode31 = make_str_node("Match 4", 7, (unsigned short) 0);
  constnode31->flags = 29;
  constnode22 = make_str_node("hhh", 3, (unsigned short) 0);
  constnode22->flags = 29;
  constnode32 = make_str_node("Match 5", 7, (unsigned short) 0);
  constnode32->flags = 29;
  constnode51 = make_str_node("56", 2, (unsigned short) 0);
  constnode51->flags = 29;
  constnode42 = make_str_node("3", 1, (unsigned short) 0);
  constnode42->flags = 29;
  constnode33 = make_str_node("4", 1, (unsigned short) 0);
  constnode33->flags = 29;
  constnode15 = make_str_node("4", 1, (unsigned short) 0);
  constnode15->flags = 29;
  constnode43 = make_str_node("zzzzz", 5, (unsigned short) 0);
  constnode43->flags = 29;
  constnode34 = make_str_node("Match 6", 7, (unsigned short) 0);
  constnode34->flags = 29;
  constnode25 = make_str_node("Match 1", 7, (unsigned short) 0);
  constnode25->flags = 29;

  regnode1 = setup_regnode("[a-z]", 5);
  regnode2 = setup_regnode("^(Asia|Europe)$", 15);
  regnode3 = setup_regnode("0", 1);

  (assign_var_num(addr_var(__a), 5.0000000000));
  num__c = 7.0000000000;
  num__d = 50.0000000000;
  (assign_var2_num(Node_subscript, __gg, 0, force_string2(constnode4), 23.0000000000));
}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  if ((regnode2->type = Node_match, match_op(regnode2, (access_fvar((int) (((1.0000000000) + (0.0000000000)) * ((regnode1->type = Node_match, match_op(regnode1, constnode8, regnode1->re_exp)))))), regnode2->re_exp)))
    {
      1.0000000000;
      (assign_var_var(addr_var(__g), constnode9));
      2.0000000000;
      (assign_var_num(addr_var(__h), 1.4342000000));
      3.0000000000;
      (assign_var_var(addr_var(__h), (access_var(__g))));
      4.0000000000;
      (assign_var_num(addr_var(__h), (force_number(access_var(__g))) + (peek_number(access_var(__g)))));
      5.0000000000;
      num__l = !(peek_number(assign_var_num(addr_var(__g), 5.0000000000)));
      6.0000000000;
      if (bool_var(assign_var_var(addr_var(__h), constnode15)))
	{
	}
      if ((((5.0000000000) > (7.0000000000)) || ((num__c) != (6.0000000000))) && ((8.0000000000) <= (num__d)))
	{
	  (assign_var_num(addr_var(__i), 1.0000000000));
	  while ((peek_number(access_var(__i))) < (100.0000000000))
	    {
	      (assign_var_num(addr_var(__i), (peek_number(access_var(__i))) + ((2.0000000000) * (8.0000000000))));
	      (assign_var_num(addr_var(__i), ((peek_number(access_var(__i))) - (5.0000000000)) + (-(pow((double) (((force_number(access_var(__a))) + ((force_number(access_var(__b))) * (force_number(access_fvar((int) (2.0000000000)))))) - (num__d)), (double) ((num__hh) / (5.0000000000)))))));
	    }
	}
      else
	{
	  if (((cmp_nodes((access_var(__strr)), constnode18) == 0) || (cmp_nodes(constnode19, constnode20) == 0)) || (cmp_nodes(constnode21, constnode22) != 0))
	    {
	      (assign_var_num(addr_var(__g), 5.0000000000));
	    }
	}
    }
  else
    {
    }


/* -------------------- Rule/Actions -------------------- */

  if (((match_op(regnode3, NULL, regnode3->re_exp)) || (bool_var(assign_var_var(addr_var(__a), (access_fvar((int) (0.0000000000))))))) || (bool_var(assign_var_var(addr_var(__b), (access_fvar((int) (1.0000000000)))))))
    {
      for ((assign_var_num(addr_var(__i), 1.0000000000));
	   (peek_number(access_var(__i))) <= ((peek_number(access_var(__i))) - (10.0000000000));
	   (assign_var_num(addr_var(__i), peek_number(access_var(__i)) + 1)))
	{
	  (assign_var_num(addr_var(__g), 5.0000000000));
	}
      1.0000000000;
      if ((5.0000000000) + (9.0000000000))
	{
	  constnode25;
	}
      2.0000000000;
      if ((9.0000000000) >= (((5.0000000000) + (force_number(access_fvar((int) (5.0000000000))))) - (force_number(access_fvar((int) (force_number(access_var(__a))))))))
	{
	  do_print2(constnode27, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      3.0000000000;
      if ((((cmp_nodes(constnode28, constnode29) >= 0) && ((6.0000000000) < (10.0000000000))) + (2.0000000000)) == (3.0000000000))
	{
	  constnode30;
	}
      4.0000000000;
      if (bool_var(access_var(__a)))
	{
	  constnode31;
	}
      5.0000000000;
      if (5.0000000000)
	{
	  constnode32;
	}
      6.0000000000;
      if (1)
	{
	  constnode34;
	}
      7.0000000000;
      if ((((1.0000000000) * (1.0000000000)) / (1.0000000000)) == (((num__fhjk) && (1)) || ((bool_var(access_var(__a))) && (3.0000000000))))
	{
	  constnode36;
	}
      8.0000000000;
      if (bool_var(access_fvar((int) (4.0000000000))))
	{
	  constnode37;
	}
      9.0000000000;
      if (bool_var(access_fvar((int) ((peek_number(access_var(__a))) + (1.0000000000)))))
	{
	  constnode38;
	}
      10.0000000000;
      if (bool_var(access_fvar((int) ((6.7000000000) + (2.0000000000)))))
	{
	  constnode40;
	}
      11.0000000000;
      if (cmp_nodes((access_fvar((int) (((100.0000000000) - (force_number(access_var(__b)))) + (3.0000000000)))), constnode43) <= 0)
	{
	  do_print2(constnode44, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      12.0000000000;
      if (cmp_nodes((access_var(__a)), constnode46) >= 0)
	{
	  constnode47;
	}
      27.0000000000;
      num__RF = (num__RF) - (1.0000000000);
      28.0000000000;
      (assign_var_var(addr_var(__a), (access_var(__a))));
      29.0000000000;
      (assign_var2_num(Node_field_spec, NULL, (int) ((1) && (bool_var(access_var(__b)))), NULL, 99.0000000000));
      30.0000000000;
      (assign_var2_var(Node_field_spec, NULL, (int) (1.0000000000), NULL, (assign_var2_var(Node_field_spec, NULL, (int) (2.0000000000), NULL, (assign_var2_var(Node_field_spec, NULL, (int) (3.0000000000), NULL, (access_var(__a))))))));
      31.0000000000;
      num__zz1 = num__zz2 = num__zz2 = 56.0000000000;
    }
  else
    {
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
  (assign_var_var(addr_var(__a), ((5.0000000000) + (5.0000000000)) ? ((tmp_node1->numbr = (8.0000000000) > (3.0000000000), tmp_node1)) : ((tmp_node1->numbr = (9.0000000000) - (1.0000000000), tmp_node1))));
  do_print2(constnode56, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__i)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2(constnode57, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__j)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
}
