#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__a;
AWKNUM num__a = 0;
NODE *constnode1;
NODE *__c;
AWKNUM num__c = 0;
NODE *constnode2;
NODE *__d;
AWKNUM num__d = 0;
NODE *constnode3;
NODE *constnode4;
NODE *__gg;
AWKNUM num__gg = 0;
NODE *constnode5;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;
NODE *regnode1;
NODE *regnode2;
NODE *__g;
AWKNUM num__g = 0;
NODE *constnode9;
NODE *constnode10;
NODE *__h;
AWKNUM num__h = 0;
NODE *constnode11;
NODE *constnode12;
NODE *constnode13;
NODE *__l;
AWKNUM num__l = 0;
NODE *constnode14;
NODE *constnode15;
NODE *constnode16;
NODE *__i;
AWKNUM num__i = 0;
NODE *constnode17;
NODE *__b;
AWKNUM num__b = 0;
NODE *__hh;
AWKNUM num__hh = 0;
NODE *constnode18;
NODE *__strr;
AWKNUM num__strr = 0;
NODE *constnode19;
NODE *constnode20;
NODE *constnode21;
NODE *constnode22;
NODE *constnode23;
NODE *regnode3;
NODE *constnode24;
NODE *constnode25;
NODE *constnode26;
NODE *constnode27;
NODE *constnode28;
NODE *constnode29;
NODE *constnode30;
NODE *constnode31;
NODE *constnode32;
NODE *constnode33;
NODE *constnode34;
NODE *constnode35;
NODE *__fhjk;
AWKNUM num__fhjk = 0;
NODE *constnode36;
NODE *constnode37;
NODE *constnode38;
NODE *constnode39;
NODE *constnode40;
NODE *constnode41;
NODE *constnode42;
NODE *constnode43;
NODE *constnode44;
NODE *constnode45;
NODE *constnode46;
NODE *constnode47;
NODE *constnode48;
NODE *constnode49;
NODE *constnode50;
NODE *constnode51;
NODE *constnode52;
NODE *constnode53;
NODE *constnode54;
NODE *constnode55;
NODE *constnode56;
NODE *constnode57;
NODE *constnode58;
NODE *constnode59;
NODE *constnode60;
NODE *constnode61;
NODE *constnode62;
NODE *constnode63;
NODE *constnode64;
NODE *constnode65;
NODE *constnode66;
NODE *constnode67;
NODE *constnode68;
NODE *constnode69;
NODE *constnode70;
NODE *constnode71;
NODE *constnode72;
NODE *constnode73;
NODE *constnode74;
NODE *constnode75;
NODE *constnode76;
NODE *constnode77;
NODE *__j;
AWKNUM num__j = 0;
NODE *constnode78;
NODE *constnode79;
NODE *constnode80;
NODE *constnode81;
NODE *constnode82;
NODE *constnode83;
NODE *constnode84;
NODE *constnode85;
NODE *constnode86;
NODE *constnode87;
NODE *constnode88;
NODE *constnode89;
NODE *constnode90;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __hh = setup_varnode();
  __a = setup_varnode();
  __b = setup_varnode();
  __c = setup_varnode();
  __d = setup_varnode();
  __g = setup_varnode();
  __h = setup_varnode();
  __i = setup_varnode();
  __j = setup_varnode();
  __l = setup_varnode();
  __gg = setup_varnode();
  __fhjk = setup_varnode();
  __strr = setup_varnode();

  constnode77 = mk_number(26.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode60 = mk_number(17.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode13 = mk_number(4.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode80 = mk_number(27.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode62 = mk_number(18.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode81 = mk_number(28.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode64 = mk_number(19.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode50 = mk_number(55.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode14 = mk_number(6.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode82 = mk_number(29.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode17 = mk_number(100.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode2 = mk_number(7.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode16 = mk_number(8.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode25 = mk_number(9.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode24 = mk_number(10.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode67 = mk_number(20.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode42 = mk_number(11.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode85 = mk_number(30.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode69 = mk_number(21.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode46 = mk_number(12.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode71 = mk_number(22.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode49 = mk_number(13.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode4 = mk_number(0.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode84 = mk_number(99.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode52 = mk_number(14.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode6 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode5 = mk_number(23.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode3 = mk_number(50.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode74 = mk_number(24.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode54 = mk_number(15.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode11 = mk_number(1.4342000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode10 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode76 = mk_number(25.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode57 = mk_number(16.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode12 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode53 = make_str_node("Match 14", 8, (unsigned short) 0);
  constnode53->flags = 29;
  constnode44 = make_str_node("zzzzz", 5, (unsigned short) 0);
  constnode44->flags = 29;
  constnode35 = make_str_node("Match 6", 7, (unsigned short) 0);
  constnode35->flags = 29;
  constnode26 = make_str_node("Match 1", 7, (unsigned short) 0);
  constnode26->flags = 29;
  constnode90 = make_str_node("END: a = ", 9, (unsigned short) 0);
  constnode90->flags = 29;
  constnode72 = make_str_node("Match 22", 8, (unsigned short) 0);
  constnode72->flags = 29;
  constnode63 = make_str_node("Match 18", 8, (unsigned short) 0);
  constnode63->flags = 29;
  constnode45 = make_str_node("Match 11", 8, (unsigned short) 0);
  constnode45->flags = 29;
  constnode36 = make_str_node("4", 1, (unsigned short) 0);
  constnode36->flags = 29;
  constnode27 = make_str_node("5", 1, (unsigned short) 0);
  constnode27->flags = 29;
  constnode18 = make_str_node("---------> Rule 1: i = ", 23, (unsigned short) 0);
  constnode18->flags = 29;
  constnode73 = make_str_node("Match 23", 8, (unsigned short) 0);
  constnode73->flags = 29;
  constnode55 = make_str_node("5.0", 3, (unsigned short) 0);
  constnode55->flags = 29;
  constnode37 = make_str_node("Match 7", 7, (unsigned short) 0);
  constnode37->flags = 29;
  constnode28 = make_str_node("Match 2", 7, (unsigned short) 0);
  constnode28->flags = 29;
  constnode19 = make_str_node("fhdjhfjshskh", 12, (unsigned short) 0);
  constnode19->flags = 29;
  constnode83 = make_str_node("56", 2, (unsigned short) 0);
  constnode83->flags = 29;
  constnode65 = make_str_node("3", 1, (unsigned short) 0);
  constnode65->flags = 29;
  constnode56 = make_str_node("Match 15", 8, (unsigned short) 0);
  constnode56->flags = 29;
  constnode47 = make_str_node("abcde", 5, (unsigned short) 0);
  constnode47->flags = 29;
  constnode38 = make_str_node("Match 8", 7, (unsigned short) 0);
  constnode38->flags = 29;
  constnode29 = make_str_node("ab", 2, (unsigned short) 0);
  constnode29->flags = 29;
  constnode7 = make_str_node("0.0e0", 5, (unsigned short) 0);
  constnode7->flags = 29;
  constnode75 = make_str_node("Match 24", 8, (unsigned short) 0);
  constnode75->flags = 29;
  constnode66 = make_str_node("Match 19", 8, (unsigned short) 0);
  constnode66->flags = 29;
  constnode48 = make_str_node("Match 12", 8, (unsigned short) 0);
  constnode48->flags = 29;
  constnode39 = make_str_node("Match 9", 7, (unsigned short) 0);
  constnode39->flags = 29;
  constnode8 = make_str_node("3a434fd", 7, (unsigned short) 0);
  constnode8->flags = 29;
  constnode58 = make_str_node("abc", 3, (unsigned short) 0);
  constnode58->flags = 29;
  constnode9 = make_str_node("fdsfsdf", 7, (unsigned short) 0);
  constnode9->flags = 29;
  constnode86 = make_str_node(" NF = ", 6, (unsigned short) 0);
  constnode86->flags = 29;
  constnode68 = make_str_node("Match 20", 8, (unsigned short) 0);
  constnode68->flags = 29;
  constnode59 = make_str_node("Match 16", 8, (unsigned short) 0);
  constnode59->flags = 29;
  constnode87 = make_str_node(" $2 = ", 6, (unsigned short) 0);
  constnode87->flags = 29;
  constnode78 = make_str_node("2", 1, (unsigned short) 0);
  constnode78->flags = 29;
  constnode20 = make_str_node("ab", 2, (unsigned short) 0);
  constnode20->flags = 29;
  constnode88 = make_str_node(", $0 = ", 7, (unsigned short) 0);
  constnode88->flags = 29;
  constnode79 = make_str_node("6", 1, (unsigned short) 0);
  constnode79->flags = 29;
  constnode30 = make_str_node("a", 1, (unsigned short) 0);
  constnode30->flags = 29;
  constnode21 = make_str_node("cc", 2, (unsigned short) 0);
  constnode21->flags = 29;
  constnode89 = make_str_node("j = ", 4, (unsigned short) 0);
  constnode89->flags = 29;
  constnode40 = make_str_node("6.7", 3, (unsigned short) 0);
  constnode40->flags = 29;
  constnode31 = make_str_node("Match 3", 7, (unsigned short) 0);
  constnode31->flags = 29;
  constnode22 = make_str_node("de", 2, (unsigned short) 0);
  constnode22->flags = 29;
  constnode41 = make_str_node("Match 10", 8, (unsigned short) 0);
  constnode41->flags = 29;
  constnode32 = make_str_node("Match 4", 7, (unsigned short) 0);
  constnode32->flags = 29;
  constnode23 = make_str_node("hhh", 3, (unsigned short) 0);
  constnode23->flags = 29;
  constnode51 = make_str_node("Match 13", 8, (unsigned short) 0);
  constnode51->flags = 29;
  constnode33 = make_str_node("Match 5", 7, (unsigned short) 0);
  constnode33->flags = 29;
  constnode15 = make_str_node("4", 1, (unsigned short) 0);
  constnode15->flags = 29;
  constnode70 = make_str_node("Match 21", 8, (unsigned short) 0);
  constnode70->flags = 29;
  constnode61 = make_str_node("Match 17", 8, (unsigned short) 0);
  constnode61->flags = 29;
  constnode43 = make_str_node("3", 1, (unsigned short) 0);
  constnode43->flags = 29;
  constnode34 = make_str_node("4", 1, (unsigned short) 0);
  constnode34->flags = 29;

  regnode1 = setup_regnode("[a-z]", 5);
  regnode2 = setup_regnode("^(Asia|Europe)$", 15);
  regnode3 = setup_regnode("0", 1);

  (assign_var_num(addr_var(__a), 5.0000000000));
  num__c = 7.0000000000;
  num__d = 50.0000000000;
  (assign_var2_num(Node_subscript, __gg, 0, force_string2(constnode4), 23.0000000000));
}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  if ((regnode2->type = Node_match, match_op(regnode2, (access_fvar((int) (((1.0000000000) + (0.0000000000)) * ((regnode1->type = Node_match, match_op(regnode1, constnode8, regnode1->re_exp)))))), regnode2->re_exp)))
    {
      1.0000000000;
      (assign_var_var(addr_var(__g), constnode9));
      2.0000000000;
      (assign_var_num(addr_var(__h), 1.4342000000));
      3.0000000000;
      (assign_var_var(addr_var(__h), (access_var(__g))));
      4.0000000000;
      (assign_var_num(addr_var(__h), (force_number(access_var(__g))) + (peek_number(access_var(__g)))));
      5.0000000000;
      num__l = !(peek_number(assign_var_num(addr_var(__g), 5.0000000000)));
      6.0000000000;
      if (bool_var(assign_var_var(addr_var(__h), constnode15)))
	{
	}
      if ((((5.0000000000) > (7.0000000000)) || ((num__c) != (6.0000000000))) && ((8.0000000000) <= (num__d)))
	{
	  (assign_var_num(addr_var(__i), 1.0000000000));
	  while ((peek_number(access_var(__i))) < (100.0000000000))
	    {
	      (assign_var_num(addr_var(__i), (peek_number(access_var(__i))) + ((2.0000000000) * (8.0000000000))));
	      (assign_var_num(addr_var(__i), ((peek_number(access_var(__i))) - (5.0000000000)) + (-(pow((double) (((force_number(access_var(__a))) + ((force_number(access_var(__b))) * (force_number(access_fvar((int) (2.0000000000)))))) - (num__d)), (double) ((num__hh) / (5.0000000000)))))));
	    }
	  do_print2(constnode18, 1, (struct redirect *) NULL, stdout, OFS);
	  do_print2((access_var(__i)), 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      else
	{
	  if (((cmp_nodes((access_var(__strr)), constnode19) == 0) || (cmp_nodes(constnode20, constnode21) == 0)) || (cmp_nodes(constnode22, constnode23) != 0))
	    {
	      (assign_var_num(addr_var(__g), 5.0000000000));
	    }
	}
    }
  else
    {
    }


/* -------------------- Rule/Actions -------------------- */

  if (((match_op(regnode3, NULL, regnode3->re_exp)) || (bool_var(assign_var_var(addr_var(__a), (access_fvar((int) (0.0000000000))))))) || (bool_var(assign_var_var(addr_var(__b), (access_fvar((int) (1.0000000000)))))))
    {
      for ((assign_var_num(addr_var(__i), 1.0000000000));
	   (peek_number(access_var(__i))) <= ((peek_number(access_var(__i))) - (10.0000000000));
	   (assign_var_num(addr_var(__i), peek_number(access_var(__i)) + 1)))
	{
	  (assign_var_num(addr_var(__g), 5.0000000000));
	}
      1.0000000000;
      if ((5.0000000000) + (9.0000000000))
	{
	  do_print2(constnode26, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      2.0000000000;
      if ((9.0000000000) >= (((5.0000000000) + (force_number(access_fvar((int) (5.0000000000))))) - (force_number(access_fvar((int) (force_number(access_var(__a))))))))
	{
	  do_print2(constnode28, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      3.0000000000;
      if ((((cmp_nodes(constnode29, constnode30) >= 0) && ((6.0000000000) < (10.0000000000))) + (2.0000000000)) == (3.0000000000))
	{
	  do_print2(constnode31, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      4.0000000000;
      if (bool_var(access_var(__a)))
	{
	  do_print2(constnode32, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      5.0000000000;
      if (5.0000000000)
	{
	  do_print2(constnode33, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      6.0000000000;
      if (1)
	{
	  do_print2(constnode35, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      7.0000000000;
      if ((((1.0000000000) * (1.0000000000)) / (1.0000000000)) == (((num__fhjk) && (1)) || ((bool_var(access_var(__a))) && (3.0000000000))))
	{
	  do_print2(constnode37, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      8.0000000000;
      if (bool_var(access_fvar((int) (4.0000000000))))
	{
	  do_print2(constnode38, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      9.0000000000;
      if (bool_var(access_fvar((int) ((peek_number(access_var(__a))) + (1.0000000000)))))
	{
	  do_print2(constnode39, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      10.0000000000;
      if (bool_var(access_fvar((int) ((6.7000000000) + (2.0000000000)))))
	{
	  do_print2(constnode41, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      11.0000000000;
      if (cmp_nodes((access_fvar((int) (((100.0000000000) - (force_number(access_var(__b)))) + (3.0000000000)))), constnode44) <= 0)
	{
	  do_print2(constnode45, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      12.0000000000;
      if (cmp_nodes((access_var(__a)), constnode47) >= 0)
	{
	  do_print2(constnode48, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      13.0000000000;
      if ((1.0000000000) == (!(cmp_nodes(constnode50, (access_var(__a))) > 0)))
	{
	  do_print2(constnode51, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      14.0000000000;
      if (cmp_nodes((access_var(__a)), constnode12) == 0)
	{
	  do_print2(constnode53, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      15.0000000000;
      if (cmp_nodes((access_var(__a)), constnode55) != 0)
	{
	  do_print2(constnode56, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      16.0000000000;
      if (cmp_nodes((access_var(__a)), constnode58) >= 0)
	{
	  do_print2(constnode59, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      17.0000000000;
      if (cmp_nodes((access_var(__a)), constnode12) < 0)
	{
	  do_print2(constnode61, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      18.0000000000;
      if (cmp_nodes((access_var(__b)), (access_var(__d))) > 0)
	{
	  do_print2(constnode63, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      19.0000000000;
      if (cmp_nodes(constnode12, constnode65) < 0)
	{
	  do_print2(constnode66, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      20.0000000000;
      if (cmp_nodes(constnode25, (access_var(__a))) == 0)
	{
	  do_print2(constnode68, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      21.0000000000;
      if (cmp_nodes((access_var(__a)), (access_var(__b))) == 0)
	{
	  do_print2(constnode70, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      22.0000000000;
      if (cmp_nodes((tmp_node1->numbr = (peek_number(access_var(__a))) + (0.0000000000), tmp_node1), (access_var(__b))) == 0)
	{
	  do_print2(constnode72, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      23.0000000000;
      if (((peek_number(access_var(__a))) + (0.0000000000)) == ((peek_number(access_var(__b))) + (0.0000000000)))
	{
	  do_print2(constnode73, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      24.0000000000;
      if (cmp_nodes((access_avar(__gg, (tmp_node1->numbr = !(5.0000000000), force_string2(tmp_node1)))), constnode5) == 0)
	{
	  do_print2(constnode75, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      25.0000000000;
      (assign_var_num(addr_var(__g), peek_number(assign_var_num(addr_var(__h), 5.0000000000))));
      26.0000000000;
      (assign_var_num(addr_var(__j), (bool_var(assign_var_var(addr_var(__h), constnode78))) && (cmp_nodes(constnode79, (access_var(__a))) < 0)));
      27.0000000000;
      (assign_var2_num(Node_NF, NULL, 0, NULL, (peek_number(access_spvar(Node_NF))) - (1.0000000000)));
      28.0000000000;
      (assign_var_var(addr_var(__a), (access_var(__a))));
      29.0000000000;
      (assign_var2_num(Node_field_spec, NULL, (int) ((1) && (bool_var(access_var(__b)))), NULL, 99.0000000000));
      30.0000000000;
      (assign_var2_var(Node_field_spec, NULL, (int) (1.0000000000), NULL, (assign_var2_var(Node_field_spec, NULL, (int) (2.0000000000), NULL, (assign_var2_var(Node_field_spec, NULL, (int) (3.0000000000), NULL, (access_var(__a))))))));
      do_print2(constnode86, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_spvar(Node_NF)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      do_print2(constnode87, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2(constnode88, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_fvar((int) (0.0000000000))), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      do_print2(constnode89, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__j)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  else
    {
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
  (assign_var_var(addr_var(__a), ((5.0000000000) + (5.0000000000)) ? ((tmp_node1->numbr = (8.0000000000) > (3.0000000000), tmp_node1)) : ((tmp_node1->numbr = (9.0000000000) - (1.0000000000), tmp_node1))));
  do_print2(constnode90, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__a)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
}
