#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *regnode1;
NODE *constnode1;
NODE *regnode2;
NODE *__a;
AWKNUM num__a = 0;
NODE *__b;
AWKNUM num__b = 0;
NODE *__c;
AWKNUM num__c = 0;
NODE *constnode2;
NODE *__d;
AWKNUM num__d = 0;
NODE *__e;
AWKNUM num__e = 0;
NODE *__f;
AWKNUM num__f = 0;
NODE *constnode3;
NODE *constnode4;
NODE *constnode5;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;
NODE *__g;
AWKNUM num__g = 0;
NODE *constnode9;
NODE *constnode10;
NODE *constnode11;
NODE *constnode12;
NODE *constnode13;
NODE *constnode14;
NODE *constnode15;
NODE *constnode16;
NODE *constnode17;
NODE *constnode18;
NODE *constnode19;
NODE *constnode20;
NODE *__aa;
AWKNUM num__aa = 0;
NODE *constnode21;
NODE *constnode22;
NODE *constnode23;
NODE *constnode24;
NODE *constnode25;
NODE *constnode26;
NODE *__bb;
AWKNUM num__bb = 0;
NODE *constnode27;
NODE *constnode28;
NODE *constnode29;
NODE *constnode30;
NODE *constnode31;
NODE *constnode32;
NODE *constnode33;
NODE *constnode34;
NODE *constnode35;
NODE *constnode36;
NODE *__lll;
AWKNUM num__lll = 0;
NODE *regnode3;
NODE *constnode37;
NODE *constnode38;
NODE *regnode4;
NODE *constnode39;
NODE *constnode40;
NODE *regnode5;
NODE *constnode41;
NODE *constnode42;
NODE *constnode43;
NODE *constnode44;
NODE *constnode45;
NODE *constnode46;
NODE *constnode47;
NODE *constnode48;
NODE *__kkk;
AWKNUM num__kkk = 0;
NODE *constnode49;
NODE *__kkk2;
AWKNUM num__kkk2 = 0;
NODE *constnode50;
NODE *__gg1;
AWKNUM num__gg1 = 0;
NODE *__gg2;
AWKNUM num__gg2 = 0;
NODE *constnode51;
NODE *constnode52;
NODE *constnode53;
NODE *constnode54;
NODE *constnode55;
NODE *constnode56;
NODE *constnode57;
NODE *constnode58;
NODE *constnode59;
NODE *constnode60;
NODE *constnode61;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __kkk = setup_varnode();
  __a = setup_varnode();
  __b = setup_varnode();
  __c = setup_varnode();
  __d = setup_varnode();
  __e = setup_varnode();
  __f = setup_varnode();
  __g = setup_varnode();
  __aa = setup_varnode();
  __bb = setup_varnode();
  __gg1 = setup_varnode();
  __gg2 = setup_varnode();
  __kkk2 = setup_varnode();
  __lll = setup_varnode();

  constnode3 = mk_number(4.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode50 = mk_number(18.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode9 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode7 = mk_number(45.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode23 = mk_number(6.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode19 = mk_number(7.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode28 = mk_number(8.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode61 = mk_number(9.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode38 = mk_number(0.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode17 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode4 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode53 = make_str_node("subs", 4, (unsigned short) 0);
  constnode53->flags = 29;
  constnode44 = make_str_node("c =", 3, (unsigned short) 0);
  constnode44->flags = 29;
  constnode35 = make_str_node("array calc3: ", 13, (unsigned short) 0);
  constnode35->flags = 29;
  constnode26 = make_str_node("9", 1, (unsigned short) 0);
  constnode26->flags = 29;
  constnode54 = make_str_node("--> 'subs' is in aa", 19, (unsigned short) 0);
  constnode54->flags = 29;
  constnode45 = make_str_node("d =", 3, (unsigned short) 0);
  constnode45->flags = 29;
  constnode36 = make_str_node("545", 3, (unsigned short) 0);
  constnode36->flags = 29;
  constnode27 = make_str_node("BB1", 3, (unsigned short) 0);
  constnode27->flags = 29;
  constnode18 = make_str_node("32", 2, (unsigned short) 0);
  constnode18->flags = 29;
  constnode5 = make_str_node("... d =", 7, (unsigned short) 0);
  constnode5->flags = 29;
  constnode55 = make_str_node("--> 3 is in aa", 14, (unsigned short) 0);
  constnode55->flags = 29;
  constnode46 = make_str_node("e =", 3, (unsigned short) 0);
  constnode46->flags = 29;
  constnode37 = make_str_node("Num expr matched a regexp!", 26, (unsigned short) 0);
  constnode37->flags = 29;
  constnode6 = make_str_node("fdjskfhdjk", 10, (unsigned short) 0);
  constnode6->flags = 29;
  constnode56 = make_str_node("bb[5] = ", 8, (unsigned short) 0);
  constnode56->flags = 29;
  constnode47 = make_str_node("f =", 3, (unsigned short) 0);
  constnode47->flags = 29;
  constnode29 = make_str_node("xc", 2, (unsigned short) 0);
  constnode29->flags = 29;
  constnode57 = make_str_node("bb['xc'] = ", 11, (unsigned short) 0);
  constnode57->flags = 29;
  constnode48 = make_str_node("aa[3] = ", 8, (unsigned short) 0);
  constnode48->flags = 29;
  constnode39 = make_str_node("2nd num-to-regexp matched!", 26, (unsigned short) 0);
  constnode39->flags = 29;
  constnode8 = make_str_node("vava", 4, (unsigned short) 0);
  constnode8->flags = 29;
  constnode58 = make_str_node("xc", 2, (unsigned short) 0);
  constnode58->flags = 29;
  constnode49 = make_str_node("aa[5] = ", 8, (unsigned short) 0);
  constnode49->flags = 29;
  constnode59 = make_str_node("aa[8] = ", 8, (unsigned short) 0);
  constnode59->flags = 29;
  constnode10 = make_str_node("5424", 4, (unsigned short) 0);
  constnode10->flags = 29;
  constnode20 = make_str_node(">>> e=", 6, (unsigned short) 0);
  constnode20->flags = 29;
  constnode11 = make_str_node("M1", 2, (unsigned short) 0);
  constnode11->flags = 29;
  constnode30 = make_str_node("BB2", 3, (unsigned short) 0);
  constnode30->flags = 29;
  constnode21 = make_str_node("M4", 2, (unsigned short) 0);
  constnode21->flags = 29;
  constnode12 = make_str_node("453", 3, (unsigned short) 0);
  constnode12->flags = 29;
  constnode40 = make_str_node("subs", 4, (unsigned short) 0);
  constnode40->flags = 29;
  constnode31 = make_str_node("aa[3]=", 6, (unsigned short) 0);
  constnode31->flags = 29;
  constnode22 = make_str_node("54543789", 8, (unsigned short) 0);
  constnode22->flags = 29;
  constnode13 = make_str_node("M2", 2, (unsigned short) 0);
  constnode13->flags = 29;
  constnode41 = make_str_node("3rd num-to-regexp matched!", 26, (unsigned short) 0);
  constnode41->flags = 29;
  constnode32 = make_str_node("aa[aa[3]*2/2]=", 14, (unsigned short) 0);
  constnode32->flags = 29;
  constnode14 = make_str_node("3454", 4, (unsigned short) 0);
  constnode14->flags = 29;
  constnode60 = make_str_node("aa[9] = ", 8, (unsigned short) 0);
  constnode60->flags = 29;
  constnode51 = make_str_node("abcdefgh", 8, (unsigned short) 0);
  constnode51->flags = 29;
  constnode42 = make_str_node("a = ", 4, (unsigned short) 0);
  constnode42->flags = 29;
  constnode33 = make_str_node("array calc: ", 12, (unsigned short) 0);
  constnode33->flags = 29;
  constnode24 = make_str_node("subs", 4, (unsigned short) 0);
  constnode24->flags = 29;
  constnode15 = make_str_node("zzzzz", 5, (unsigned short) 0);
  constnode15->flags = 29;
  constnode2 = make_str_node("453", 3, (unsigned short) 0);
  constnode2->flags = 29;
  constnode52 = make_str_node("aa[18] = ", 9, (unsigned short) 0);
  constnode52->flags = 29;
  constnode43 = make_str_node("b =", 3, (unsigned short) 0);
  constnode43->flags = 29;
  constnode34 = make_str_node("array calc2: ", 13, (unsigned short) 0);
  constnode34->flags = 29;
  constnode25 = make_str_node("45", 2, (unsigned short) 0);
  constnode25->flags = 29;
  constnode16 = make_str_node("M3", 2, (unsigned short) 0);
  constnode16->flags = 29;

  regnode4 = setup_regnode("[0-9]", 5);
  regnode5 = setup_regnode("[34][0-5]", 9);
  regnode1 = setup_regnode("e", 1);
  regnode2 = setup_regnode("[a-z]0[A-Z]*", 12);
  regnode3 = setup_regnode("[0-9]", 5);

}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  if ((match_op(regnode1, NULL, regnode1->re_exp)) || ((regnode2->type = Node_match, match_op(regnode2, (access_fvar((int) (1.0000000000))), regnode2->re_exp))))
    {
      (assign_var_var(addr_var(__a), (assign_var_var(addr_var(__b), (assign_var_var(addr_var(__c), constnode2))))));
      (assign_var_num(addr_var(__d), peek_number(assign_var_num(addr_var(__e), peek_number(assign_var_num(addr_var(__f), (1.0000000000) + (4.0000000000)))))));
      (assign_var_num(addr_var(__d), (peek_number(assign_var_num(addr_var(__e), peek_number(assign_var_num(addr_var(__f), (1.0000000000) + (4.0000000000)))))) + (3.0000000000)));
      do_print2(constnode5, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__d)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      (assign_var_var(addr_var(__d), constnode6));
      (assign_var_var(addr_var(__c), (access_var(__d))));
      (assign_var_num(addr_var(__d), 45.0000000000));
      (assign_var_var(addr_var(__d), constnode8));
      (assign_var_num(addr_var(__d), 45.0000000000));
      num__g = peek_number(assign_var_num(addr_var(__e), 5.0000000000));
      (assign_var_var(addr_var(__a), constnode10));
      if (((force_number(access_var(__a))) * (1.0000000000)) < ((5.0000000000) + (3.0000000000)))
	{
	  do_print2(constnode11, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      if (cmp_nodes((access_var(__a)), constnode12) > 0)
	{
	  do_print2(constnode13, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      if (cmp_nodes(constnode14, constnode15) < 0)
	{
	  do_print2(constnode16, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      if (cmp_nodes((access_var(__a)), (access_fvar((int) (2.0000000000)))) == 0)
	{
	}
      if (1)
	{
	}
      if (bool_var(access_fvar((int) (7.0000000000))))
	{
	}
      do_print2(constnode20, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__e)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      if (bool_var(access_avar(__aa, force_string2(access_var(__e)))))
	{
	  do_print2(constnode21, 0, (struct redirect *) NULL, stdout, OFS);
	  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
	}
      (assign_var2_var(Node_subscript, __aa, 0, force_string2(constnode1), constnode22));
      (assign_var2_num(Node_subscript, __aa, 0, force_string2(constnode4), 5.0000000000));
      (assign_var2_num(Node_subscript, __aa, 0, (tmp_node1->numbr = (3.0000000000) + (2.0000000000), force_string2(tmp_node1)), 6.0000000000));
      (assign_var2_var(Node_subscript, __aa, 0, constnode24, constnode25));
      (assign_var2_var(Node_subscript, __bb, 0, force_string2(assign_var2_num(Node_subscript, __aa, 0, constnode26, 5.0000000000)), constnode27));
      (assign_var2_var(Node_subscript, __bb, 0, (assign_var2_var(Node_subscript, __aa, 0, force_string2(constnode28), constnode29)), constnode30));
      do_print2(constnode31, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_avar(__aa, force_string2(constnode4))), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      do_print2(constnode32, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_avar(__aa, (tmp_node1->numbr = ((force_number(access_avar(__aa, force_string2(constnode4)))) * (2.0000000000)) / (2.0000000000), force_string2(tmp_node1)))), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      do_print2(constnode33, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((tmp_node1->numbr = (force_number(access_avar(__aa, force_string2(constnode4)))) + (force_number(access_avar(__aa, (tmp_node1->numbr = ((force_number(access_avar(__aa, force_string2(constnode4)))) * (2.0000000000)) / (2.0000000000), force_string2(tmp_node1))))), tmp_node1), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      do_print2(constnode34, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_avar(__aa, (tmp_node1->numbr = (6.0000000000) - (3.0000000000), force_string2(tmp_node1)))), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      do_print2(constnode35, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_avar(__aa, (tmp_node1->numbr = ((6.0000000000) > (3.0000000000)) && (1), force_string2(tmp_node1)))), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  else
    {
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
  if ((regnode3->type = Node_match, match_op(regnode3, force_string2(assign_var_num(addr_var(__lll), (1.0000000000) + (1.0000000000))), regnode3->re_exp)))
    {
      do_print2(constnode37, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  if ((regnode4->type = Node_match, match_op(regnode4, (tmp_node1->numbr = (3.0000000000) - (0.0000000000), force_string2(tmp_node1)), regnode4->re_exp)))
    {
      do_print2(constnode39, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  if ((regnode5->type = Node_match, match_op(regnode5, force_string2(access_avar(__aa, constnode40)), regnode5->re_exp)))
    {
      do_print2(constnode41, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  do_print2(constnode42, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__a)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode43, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__b)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode44, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__c)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode45, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__d)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode46, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__e)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode47, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__f)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode48, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, force_string2(assign_var_num(addr_var(__kkk), 3.0000000000)))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode49, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, force_string2(constnode9))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var2_var(Node_subscript, __aa, 0, force_string2(assign_var_num(addr_var(__kkk2), 18.0000000000)), (assign_var_var(addr_var(__gg1), (assign_var_var(addr_var(__gg2), constnode51))))));
  do_print2(constnode52, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, force_string2(constnode50))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  if (in_array2(__aa->lnode, constnode53))
    {
      do_print2(constnode54, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  if (in_array2(__aa->lnode, force_string2(constnode4)))
    {
      do_print2(constnode55, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  do_print2(constnode56, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__bb, force_string2(constnode9))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode57, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__bb, constnode58)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode59, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, force_string2(constnode28))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode60, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, force_string2(constnode61))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
}
