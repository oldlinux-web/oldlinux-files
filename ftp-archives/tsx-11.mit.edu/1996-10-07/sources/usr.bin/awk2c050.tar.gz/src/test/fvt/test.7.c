#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *constnode1;
NODE *__aa;
AWKNUM num__aa = 0;
NODE *constnode2;
NODE *constnode3;
NODE *constnode4;
NODE *constnode5;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;
NODE *constnode9;
NODE *constnode10;
NODE *constnode11;
NODE *constnode12;
NODE *constnode13;
NODE *constnode14;
NODE *constnode15;
NODE *constnode16;
NODE *constnode17;
NODE *constnode18;
NODE *constnode19;
NODE *constnode20;
NODE *constnode21;
NODE *constnode22;
NODE *constnode23;
NODE *constnode24;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __aa = setup_varnode();

  constnode11 = mk_number(4.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode9 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode10 = mk_number(6.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode8 = mk_number(0.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode3 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode5 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode7 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode17 = make_str_node("aa[0] = ", 8, (unsigned short) 0);
  constnode17->flags = 29;
  constnode4 = make_str_node("YY", 2, (unsigned short) 0);
  constnode4->flags = 29;
  constnode18 = make_str_node("2", 1, (unsigned short) 0);
  constnode18->flags = 29;
  constnode19 = make_str_node("--> '2' is in aa", 16, (unsigned short) 0);
  constnode19->flags = 29;
  constnode6 = make_str_node("ZZ", 2, (unsigned short) 0);
  constnode6->flags = 29;
  constnode20 = make_str_node("--> 5 is in aa", 14, (unsigned short) 0);
  constnode20->flags = 29;
  constnode21 = make_str_node("------ END ------", 17, (unsigned short) 0);
  constnode21->flags = 29;
  constnode12 = make_str_node("aa['1'] = ", 10, (unsigned short) 0);
  constnode12->flags = 29;
  constnode22 = make_str_node("aa[5] = ", 8, (unsigned short) 0);
  constnode22->flags = 29;
  constnode13 = make_str_node("1", 1, (unsigned short) 0);
  constnode13->flags = 29;
  constnode23 = make_str_node("aa[1] = ", 8, (unsigned short) 0);
  constnode23->flags = 29;
  constnode14 = make_str_node("aa[1] = ", 8, (unsigned short) 0);
  constnode14->flags = 29;
  constnode1 = make_str_node("1", 1, (unsigned short) 0);
  constnode1->flags = 29;
  constnode24 = make_str_node("aa[2] = ", 8, (unsigned short) 0);
  constnode24->flags = 29;
  constnode15 = make_str_node("aa[2+3] = ", 10, (unsigned short) 0);
  constnode15->flags = 29;
  constnode2 = make_str_node("XX", 2, (unsigned short) 0);
  constnode2->flags = 29;
  constnode16 = make_str_node("aa[5] = ", 8, (unsigned short) 0);
  constnode16->flags = 29;


  (assign_var2_var(Node_subscript, __aa, 0, constnode1, constnode2));
  (assign_var2_var(Node_subscript, __aa, 0, force_string2(constnode3), constnode4));
  (assign_var2_var(Node_subscript, __aa, 0, force_string2(constnode5), constnode6));
  (assign_var2_num(Node_subscript, __aa, 0, (tmp_node1->numbr = (2.0000000000) + (3.0000000000), force_string2(tmp_node1)), 0.0000000000));
  (assign_var2_num(Node_subscript, __aa, 0, (tmp_node1->numbr = ((5.0000000000) > (6.0000000000)) && ((5.0000000000) == (4.0000000000)), force_string2(tmp_node1)), 2.0000000000));
}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  do_print2(constnode12, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, constnode13)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode14, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, force_string2(constnode3))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode15, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, (tmp_node1->numbr = (2.0000000000) + (3.0000000000), force_string2(tmp_node1)))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode16, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, force_string2(constnode9))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode17, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, force_string2(constnode8))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  if (in_array2(__aa->lnode, constnode18))
    {
      do_print2(constnode19, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  if (in_array2(__aa->lnode, force_string2(constnode9)))
    {
      do_print2(constnode20, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
  do_print2(constnode21, 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode22, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, force_string2(constnode9))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode23, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, force_string2(constnode3))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  assoc_clear(__aa->lnode);
  do_print2(constnode24, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__aa, force_string2(constnode5))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
}
