#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__a;
AWKNUM num__a = 0;
NODE *constnode1;
NODE *__b;
AWKNUM num__b = 0;
NODE *constnode2;
NODE *__aaix;
AWKNUM num__aaix = 0;
NODE *__c;
AWKNUM num__c = 0;
NODE *constnode3;
NODE *__d;
AWKNUM num__d = 0;
NODE *constnode4;
NODE *__zz;
AWKNUM num__zz = 0;
NODE *constnode5;
NODE *__e;
AWKNUM num__e = 0;
NODE *__f;
AWKNUM num__f = 0;
NODE *__kkk;
AWKNUM num__kkk = 0;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;
NODE *constnode9;
NODE *__jj;
AWKNUM num__jj = 0;
NODE *constnode10;
NODE *__hh;
AWKNUM num__hh = 0;
NODE *constnode11;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __hh = setup_varnode();
  __kkk = setup_varnode();
  __a = setup_varnode();
  __b = setup_varnode();
  __c = setup_varnode();
  __d = setup_varnode();
  __e = setup_varnode();
  __f = setup_varnode();
  __aaix = setup_varnode();
  __jj = setup_varnode();
  __zz = setup_varnode();

  constnode10 = mk_number(20.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode3 = mk_number(12.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(0.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode9 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode8 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode11 = mk_number(34.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode6 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode4 = make_str_node("45.3", 4, (unsigned short) 0);
  constnode4->flags = 29;
  constnode5 = make_str_node("1.1", 3, (unsigned short) 0);
  constnode5->flags = 29;
  constnode7 = make_str_node("2", 1, (unsigned short) 0);
  constnode7->flags = 29;
  constnode2 = make_str_node("abc", 3, (unsigned short) 0);
  constnode2->flags = 29;


  num__a = 0.0000000000;
  (assign_var_var(addr_var(__b), constnode2));
  num__aaix = num__c = 12.0000000000;
  (assign_var_var(addr_var(__d), constnode4));
  (assign_var_var(addr_var(__zz), constnode5));
}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  num__a = num__c = peek_number(assign_var_num(addr_var(__d), 0.0000000000));
  num__a++;
  ++num__a;
  num__e = num__f = --num__c;
  num__kkk = num__c += 3.0000000000;
  num__c += force_number(access_var(__zz));
  num__c *= 2.0000000000;
  (assign_var2_num(Node_field_spec, NULL, (int) (2.0000000000), NULL, force_number(access_fvar((int) (2.0000000000))) + 1));
  (assign_var_num(addr_var(__d), peek_number(access_var(__d)) + 1));
  num__f += num__f;
  (assign_var2_num(Node_NF, NULL, 0, NULL, peek_number(access_spvar(Node_NF)) + 1.0000000000));
  (assign_var2_num(Node_NF, NULL, 0, NULL, peek_number(access_spvar(Node_NF)) - 1));


/* -------------------- Rule/Actions -------------------- */

  for (num__jj = 1.0000000000;
       (num__jj) <= (20.0000000000);
       num__jj++)
    {
      num__jj += 1.0000000000;
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
  num__hh = 34.0000000000;
  num__hh /= num__hh;
}
