#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__i;
AWKNUM num__i = 0;
NODE *constnode1;
NODE *constnode2;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __i = setup_varnode();

  constnode2 = mk_number(100.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));



}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  for (num__i = 1.0000000000;
       (num__i) <= (100.0000000000);
       num__i = (num__i) + (1.0000000000))
    {
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
}
