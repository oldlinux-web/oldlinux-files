#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__a;
AWKNUM num__a = 0;
NODE *constnode1;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __a = setup_varnode();

  constnode1 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));



}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  num__a = (num__a) + (force_number(access_fvar((int) (1.0000000000))));
}


/*********** END **********/

void 
awk2c_end(void)
{
}
