#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__a;
AWKNUM num__a = 0;
NODE *__b;
AWKNUM num__b = 0;
NODE *__c;
AWKNUM num__c = 0;
NODE *constnode1;
NODE *__d;
AWKNUM num__d = 0;
NODE *constnode2;
NODE *__f;
AWKNUM num__f = 0;
NODE *__e;
AWKNUM num__e = 0;
NODE *constnode3;
NODE *constnode4;
NODE *constnode5;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;
NODE *constnode9;
NODE *constnode10;
NODE *constnode11;
NODE *constnode12;
NODE *constnode13;
NODE *constnode14;
NODE *constnode15;
NODE *constnode16;
NODE *constnode17;
NODE *constnode18;
NODE *constnode19;
NODE *constnode20;
NODE *constnode21;
NODE *__old_OFS;
AWKNUM num__old_OFS = 0;
NODE *__old_ORS;
AWKNUM num__old_ORS = 0;
NODE *constnode22;
NODE *constnode23;
NODE *constnode24;
NODE *constnode25;
NODE *constnode26;
NODE *constnode27;
NODE *constnode28;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __a = setup_varnode();
  __b = setup_varnode();
  __c = setup_varnode();
  __d = setup_varnode();
  __e = setup_varnode();
  __f = setup_varnode();
  __old_ORS = setup_varnode();
  __old_OFS = setup_varnode();

  constnode14 = mk_number(4.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode10 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode3 = mk_number(10.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode2 = mk_number(11.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode16 = mk_number(0.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode7 = mk_number(40.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode9 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode6 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode26 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode17 = make_str_node("a = ", 4, (unsigned short) 0);
  constnode17->flags = 29;
  constnode4 = make_str_node("LEO", 3, (unsigned short) 0);
  constnode4->flags = 29;
  constnode27 = make_str_node("abc", 3, (unsigned short) 0);
  constnode27->flags = 29;
  constnode18 = make_str_node("b = ", 4, (unsigned short) 0);
  constnode18->flags = 29;
  constnode5 = make_str_node("--> In rule#1: $2 = ", 20, (unsigned short) 0);
  constnode5->flags = 29;
  constnode28 = make_str_node(" __ ", 4, (unsigned short) 0);
  constnode28->flags = 29;
  constnode19 = make_str_node("c = ", 4, (unsigned short) 0);
  constnode19->flags = 29;
  constnode8 = make_str_node("--> In rule#1: a =", 18, (unsigned short) 0);
  constnode8->flags = 29;
  constnode20 = make_str_node("d = ", 4, (unsigned short) 0);
  constnode20->flags = 29;
  constnode11 = make_str_node("---> In rule#2:  a =", 20, (unsigned short) 0);
  constnode11->flags = 29;
  constnode21 = make_str_node("e = ", 4, (unsigned short) 0);
  constnode21->flags = 29;
  constnode12 = make_str_node("$1 =", 4, (unsigned short) 0);
  constnode12->flags = 29;
  constnode22 = make_str_node(" ^^^^ ", 6, (unsigned short) 0);
  constnode22->flags = 29;
  constnode13 = make_str_node("999", 3, (unsigned short) 0);
  constnode13->flags = 29;
  constnode23 = make_str_node("##", 2, (unsigned short) 0);
  constnode23->flags = 29;
  constnode1 = make_str_node("45", 2, (unsigned short) 0);
  constnode1->flags = 29;
  constnode24 = make_str_node("abc", 3, (unsigned short) 0);
  constnode24->flags = 29;
  constnode15 = make_str_node("XXXXXXX", 7, (unsigned short) 0);
  constnode15->flags = 29;
  constnode25 = make_str_node(" __ ", 4, (unsigned short) 0);
  constnode25->flags = 29;


  (assign_var_var(addr_var(__a), (assign_var_var(addr_var(__b), (assign_var_var(addr_var(__c), constnode1))))));
  (assign_var_num(addr_var(__d), 11.0000000000));
  (assign_var_num(addr_var(__f), peek_number(assign_var_num(addr_var(__d), peek_number(assign_var_num(addr_var(__d), peek_number(assign_var_num(addr_var(__d), peek_number(access_var(__d))))))))));
  (assign_var_num(addr_var(__e), (force_number(access_var(__a))) + (force_number(access_var(__c)))));
}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  if (cmp_nodes((access_fvar((int) ((force_number(access_var(__f))) - (10.0000000000)))), constnode4) == 0)
    {
      do_print2(constnode5, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_fvar((int) (2.0000000000))), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      (assign_var_num(addr_var(__a), ((force_number(access_var(__a))) - (40.0000000000)) + (force_number(access_fvar((int) (2.0000000000))))));
      do_print2(constnode8, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__a)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      (assign_var_num(addr_var(__d), ((cmp_nodes((access_var(__d)), constnode2) >= 0) && (peek_number(assign_var2_num(Node_field_spec, NULL, (int) (1.0000000000), NULL, 5.0000000000)))) && (peek_number(assign_var_num(addr_var(__b), 1.0000000000)))));
    }
  else
    {
    }


/* -------------------- Rule/Actions -------------------- */

  if (cmp_nodes((access_fvar((int) (1.0000000000))), constnode10) > 0)
    {
      (assign_var_num(addr_var(__a), (force_number(access_var(__a))) * (2.0000000000)));
      do_print2(constnode11, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__a)), 1, (struct redirect *) NULL, stdout, OFS);
      do_print2(constnode12, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_fvar((int) (1.0000000000))), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  else
    {
    }


/* -------------------- Rule/Actions -------------------- */

  if (cmp_nodes((access_fvar((int) (2.0000000000))), constnode13) == 0)
    {
      (assign_var2_var(Node_field_spec, NULL, (int) (4.0000000000), NULL, constnode15));
      (assign_var_var(addr_var(__c), (access_fvar((int) (0.0000000000)))));
    }
  else
    {
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
  (assign_var_num(addr_var(__e), (peek_number(access_var(__e))) + (force_number(access_var(__d)))));
  do_print2(constnode17, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__a)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode18, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__b)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode19, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__c)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode20, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__d)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode21, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__e)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var_var(addr_var(__old_OFS), (access_spvar(Node_OFS))));
  (assign_var_var(addr_var(__old_ORS), (access_spvar(Node_ORS))));
  (assign_var2_var(Node_OFS, NULL, 0, NULL, constnode22));
  (assign_var2_var(Node_ORS, NULL, 0, NULL, constnode23));
  do_print2(constnode24, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__a)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2(constnode25, 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode9, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2(constnode6, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2(constnode26, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2(constnode14, 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2((access_var(__a)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var2_var(Node_OFS, NULL, 0, NULL, (access_var(__old_OFS))));
  (assign_var2_var(Node_ORS, NULL, 0, NULL, (access_var(__old_ORS))));
  do_print2(constnode27, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__a)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2(constnode28, 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode9, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2(constnode6, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2(constnode26, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2(constnode14, 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2((access_var(__a)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
}
