#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__e;
AWKNUM num__e = 0;
NODE *constnode1;
NODE *__aa;
AWKNUM num__aa = 0;
NODE *constnode2;
NODE *constnode3;
NODE *constnode4;
NODE *constnode5;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;
NODE *constnode9;
NODE *__bb;
AWKNUM num__bb = 0;
NODE *constnode10;
NODE *constnode11;
NODE *constnode12;
NODE *constnode13;
NODE *constnode14;
NODE *constnode15;
NODE *__zz;
AWKNUM num__zz = 0;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __e = setup_varnode();
  __aa = setup_varnode();
  __bb = setup_varnode();
  __zz = setup_varnode();

  constnode4 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode6 = mk_number(6.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode11 = mk_number(8.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode5 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode3 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode7 = make_str_node("subs", 4, (unsigned short) 0);
  constnode7->flags = 29;
  constnode8 = make_str_node("45", 2, (unsigned short) 0);
  constnode8->flags = 29;
  constnode9 = make_str_node("9", 1, (unsigned short) 0);
  constnode9->flags = 29;
  constnode10 = make_str_node("BB1", 3, (unsigned short) 0);
  constnode10->flags = 29;
  constnode12 = make_str_node("xc", 2, (unsigned short) 0);
  constnode12->flags = 29;
  constnode13 = make_str_node("BB2", 3, (unsigned short) 0);
  constnode13->flags = 29;
  constnode14 = make_str_node("fhdskjfhsj", 10, (unsigned short) 0);
  constnode14->flags = 29;
  constnode15 = make_str_node("3", 1, (unsigned short) 0);
  constnode15->flags = 29;
  constnode2 = make_str_node("54543789", 8, (unsigned short) 0);
  constnode2->flags = 29;


}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  (assign_var_var(addr_var(__e), (access_fvar((int) (1.0000000000)))));
  (assign_var2_var(Node_subscript, __aa, 0, force_string2(constnode1), constnode2));
  (assign_var2_num(Node_subscript, __aa, 0, force_string2(constnode3), 5.0000000000));
  (assign_var2_num(Node_subscript, __aa, 0, (tmp_node1->numbr = (3.0000000000) + (2.0000000000), force_string2(tmp_node1)), 6.0000000000));
  (assign_var2_var(Node_subscript, __aa, 0, constnode7, constnode8));
  (assign_var2_var(Node_subscript, __bb, 0, force_string2(assign_var2_num(Node_subscript, __aa, 0, constnode9, 5.0000000000)), constnode10));
  (assign_var2_var(Node_subscript, __bb, 0, (assign_var2_var(Node_subscript, __aa, 0, force_string2(constnode11), constnode12)), constnode13));
  (assign_var2_var(Node_subscript, __aa, 0, (tmp_node1->numbr = ((force_number(access_avar(__aa, force_string2(constnode3)))) * (2.0000000000)) / (2.0000000000), force_string2(tmp_node1)), constnode14));
  (access_avar(__aa, (tmp_node1->numbr = (6.0000000000) - (3.0000000000), force_string2(tmp_node1))));
  (assign_var2_var(Node_subscript, __bb, 0, (access_fvar((int) (1.0000000000))), (access_fvar((int) (1.0000000000)))));
  in_array2(__aa->lnode, constnode15);
  in_array2(__aa->lnode, (tmp_node1->numbr = ((5.0000000000) + (2.0000000000)) - ((2.0000000000) * (1.0000000000)), force_string2(tmp_node1)));
  (assign_var_num(addr_var(__zz), 1.0000000000));
  in_array2(__aa->lnode, force_string2(access_var(__zz)));
}


/*********** END **********/

void 
awk2c_end(void)
{
}
