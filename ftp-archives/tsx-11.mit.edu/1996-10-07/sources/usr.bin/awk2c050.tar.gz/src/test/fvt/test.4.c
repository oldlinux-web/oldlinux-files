#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__a;
AWKNUM num__a = 0;
NODE *constnode1;
NODE *__b;
AWKNUM num__b = 0;
NODE *constnode2;
NODE *__e;
AWKNUM num__e = 0;
NODE *constnode3;
NODE *__c;
AWKNUM num__c = 0;
NODE *constnode4;
NODE *constnode5;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;
NODE *constnode9;
NODE *constnode10;
NODE *regnode1;
NODE *__d;
AWKNUM num__d = 0;
NODE *__g;
AWKNUM num__g = 0;
NODE *constnode11;
NODE *constnode12;
NODE *constnode13;
NODE *constnode14;
NODE *constnode15;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __a = setup_varnode();
  __b = setup_varnode();
  __c = setup_varnode();
  __d = setup_varnode();
  __e = setup_varnode();
  __g = setup_varnode();

  constnode8 = mk_number(45.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode7 = mk_number(1234.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode4 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode6 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode5 = make_str_node("56", 2, (unsigned short) 0);
  constnode5->flags = 29;
  constnode9 = make_str_node("a =", 3, (unsigned short) 0);
  constnode9->flags = 29;
  constnode10 = make_str_node("e =", 3, (unsigned short) 0);
  constnode10->flags = 29;
  constnode11 = make_str_node("abc", 3, (unsigned short) 0);
  constnode11->flags = 29;
  constnode12 = make_str_node("------------------------------------", 36, (unsigned short) 0);
  constnode12->flags = 29;
  constnode13 = make_str_node("b =", 3, (unsigned short) 0);
  constnode13->flags = 29;
  constnode14 = make_str_node("c =", 3, (unsigned short) 0);
  constnode14->flags = 29;
  constnode15 = make_str_node("d =", 3, (unsigned short) 0);
  constnode15->flags = 29;
  constnode2 = make_str_node("abcdef", 6, (unsigned short) 0);
  constnode2->flags = 29;
  constnode3 = make_str_node("100e-1", 6, (unsigned short) 0);
  constnode3->flags = 29;

  regnode1 = setup_regnode("^[aA]bc", 7);

  (assign_var_num(addr_var(__a), 5.0000000000));
  (assign_var_var(addr_var(__b), constnode2));
  (assign_var_var(addr_var(__e), constnode3));
}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  if ((bool_var(assign_var_var(addr_var(__c), (access_fvar((int) (1.0000000000)))))) && (1))
    {
      (assign_var_num(addr_var(__a), peek_number(assign_var_num(addr_var(__a), (peek_number(access_var(__a))) + (1.0000000000)))));
      (assign_var_num(addr_var(__a), ((peek_number(access_var(__a))) + ((2.0000000000) * (force_number(access_var(__e))))) + (fmod((double) (1234.0000000000), (double) (45.0000000000)))));
      do_print2(constnode9, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__a)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      do_print2(constnode10, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__e)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  else
    {
    }


/* -------------------- Rule/Actions -------------------- */

  if (match_op(regnode1, NULL, regnode1->re_exp))
    {
      (assign_var_num(addr_var(__d), !(num__g = 5.0000000000)));
      (assign_var_num(addr_var(__c), (peek_number(access_spvar(Node_NF))) + (force_number2(assign_var_var(addr_var(__e), (access_var(__e)))))));
      (assign_var_num(addr_var(__b), ((bool_var(access_var(__b))) && (cmp_nodes(constnode11, (access_fvar((int) (2.0000000000)))) < 0)) && (bool_var(access_fvar((int) ((bool_var(access_fvar((int) (1.0000000000)))) && (bool_var(access_fvar((int) (2.0000000000))))))))));
      do_print2(constnode12, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      do_print2(constnode13, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__b)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      do_print2(constnode14, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__c)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      do_print2(constnode15, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__d)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  else
    {
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
}
