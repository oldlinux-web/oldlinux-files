#include "awk.h"

/********** AWK Program's variables and constants **********/



/*********** BEGIN **********/

void 
awk2c_begin(void)
{





}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

}


/*********** END **********/

void 
awk2c_end(void)
{
}
