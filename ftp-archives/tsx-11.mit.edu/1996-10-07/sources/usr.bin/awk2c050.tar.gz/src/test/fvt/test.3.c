#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__a;
AWKNUM num__a = 0;
NODE *constnode1;
NODE *__b;
AWKNUM num__b = 0;
NODE *constnode2;
NODE *constnode3;
NODE *__e;
AWKNUM num__e = 0;
NODE *constnode4;
NODE *constnode5;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;
NODE *__i;
AWKNUM num__i = 0;
NODE *__j;
AWKNUM num__j = 0;
NODE *constnode9;
NODE *constnode10;
NODE *constnode11;
NODE *constnode12;
NODE *__kk;
AWKNUM num__kk = 0;
NODE *constnode13;
NODE *constnode14;
NODE *__zzz;
AWKNUM num__zzz = 0;
NODE *constnode15;
NODE *constnode16;
NODE *constnode17;
NODE *__c;
AWKNUM num__c = 0;
NODE *constnode18;
NODE *constnode19;
NODE *constnode20;
NODE *constnode21;
NODE *constnode22;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __a = setup_varnode();
  __b = setup_varnode();
  __c = setup_varnode();
  __e = setup_varnode();
  __i = setup_varnode();
  __j = setup_varnode();
  __zzz = setup_varnode();
  __kk = setup_varnode();

  constnode3 = mk_number(45.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode16 = mk_number(100.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode4 = mk_number(56.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode15 = mk_number(4.3000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode10 = mk_number(10.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode9 = mk_number(0.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode8 = mk_number(40.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode7 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode11 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode21 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode17 = make_str_node("if is TRUE", 10, (unsigned short) 0);
  constnode17->flags = 29;
  constnode18 = make_str_node("a = ", 4, (unsigned short) 0);
  constnode18->flags = 29;
  constnode5 = make_str_node("ab", 2, (unsigned short) 0);
  constnode5->flags = 29;
  constnode19 = make_str_node("b = ", 4, (unsigned short) 0);
  constnode19->flags = 29;
  constnode6 = make_str_node("45", 2, (unsigned short) 0);
  constnode6->flags = 29;
  constnode20 = make_str_node("c = ", 4, (unsigned short) 0);
  constnode20->flags = 29;
  constnode12 = make_str_node("abc", 3, (unsigned short) 0);
  constnode12->flags = 29;
  constnode22 = make_str_node("CCCCCCCCCCC", 11, (unsigned short) 0);
  constnode22->flags = 29;
  constnode13 = make_str_node("i = ", 4, (unsigned short) 0);
  constnode13->flags = 29;
  constnode14 = make_str_node("j = ", 4, (unsigned short) 0);
  constnode14->flags = 29;
  constnode2 = make_str_node("45", 2, (unsigned short) 0);
  constnode2->flags = 29;


  (assign_var_num(addr_var(__a), 5.0000000000));
  (assign_var_var(addr_var(__b), constnode2));
  (assign_var2_num(Node_subscript, __e, 0, force_string2(constnode3), 56.0000000000));
  (assign_var2_var(Node_subscript, __e, 0, constnode5, constnode6));
}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  if (cmp_nodes((access_fvar((int) (1.0000000000))), constnode1) > 0)
    {
      (assign_var_num(addr_var(__a), (peek_number(access_var(__a))) + (5.0000000000)));
      (assign_var_num(addr_var(__b), (force_number(access_var(__b))) - (40.0000000000)));
    }
  else
    {
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
  (assign_var_num(addr_var(__i), 5.0000000000));
  (assign_var_num(addr_var(__j), 0.0000000000));
  while (((cmp_nodes((access_var(__i)), constnode10) < 0) && (peek_number(assign_var_num(addr_var(__a), (force_number(access_var(__i))) + (10.0000000000))))) && ((peek_number(access_var(__j))) < (2.0000000000)))
    {
      (assign_var_var(addr_var(__i), constnode12));
      (assign_var_num(addr_var(__j), (peek_number(access_var(__j))) + (1.0000000000)));
    }
  for (num__kk = 5.0000000000;
       (num__kk) <= (10.0000000000);
       num__kk = (num__kk) + (1.0000000000))
    {
    }
  do_print2(constnode13, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__i)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode14, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__j)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  if (((num__zzz = 4.3000000000) && (num__zzz = 2.0000000000)) && ((num__zzz) - (100.0000000000)))
    {
      do_print2(constnode17, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  (assign_var_num(addr_var(__c), (peek_number(access_var(__a))) + (force_number(access_var(__b)))));
  do_print2(constnode18, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__a)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode19, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__b)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode20, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__c)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2((tmp_node1->numbr = (peek_number(access_var(__c))) - (5.0000000000), tmp_node1), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((tmp_node1->numbr = (3.0000000000) / (2.0000000000), tmp_node1), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__a)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__b)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode7, 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode22, 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
}
