#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *regnode1;
NODE *constnode1;
NODE *regnode2;
NODE *constnode2;
NODE *regnode3;
NODE *constnode3;
NODE *regnode4;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{


  constnode3 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode1 = make_str_node("abcde0", 6, (unsigned short) 0);
  constnode1->flags = 29;
  constnode2 = make_str_node("A90", 3, (unsigned short) 0);
  constnode2->flags = 29;

  regnode4 = setup_regnode("__[a-zA-Z]*fdsjfh$", 18);
  regnode1 = setup_regnode("[a-z]", 5);
  regnode2 = setup_regnode("[a-c][bB]cde[0-9]+", 18);
  regnode3 = setup_regnode("^[aA]9(A|B)", 11);

}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  if (match_op(regnode1, NULL, regnode1->re_exp))
    {
      (regnode2->type = Node_match, match_op(regnode2, constnode1, regnode2->re_exp));
      (regnode3->type = Node_nomatch, match_op(regnode3, constnode2, regnode3->re_exp));
      (regnode4->type = Node_match, match_op(regnode4, (access_fvar((int) (2.0000000000))), regnode4->re_exp));
    }
  else
    {
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
}
