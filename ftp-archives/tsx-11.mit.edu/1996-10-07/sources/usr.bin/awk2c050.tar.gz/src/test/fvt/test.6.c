#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__i;
AWKNUM num__i = 0;
NODE *constnode1;
NODE *constnode2;
NODE *regnode1;
NODE *__a;
AWKNUM num__a = 0;
NODE *constnode3;
NODE *__k;
AWKNUM num__k = 0;
NODE *constnode4;
NODE *constnode5;
NODE *__d;
AWKNUM num__d = 0;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;
NODE *constnode9;
NODE *constnode10;
NODE *__b;
AWKNUM num__b = 0;
NODE *constnode11;
NODE *__j;
AWKNUM num__j = 0;
NODE *constnode12;
NODE *constnode13;
NODE *__c;
AWKNUM num__c = 0;
NODE *constnode14;
NODE *constnode15;
NODE *constnode16;
NODE *constnode17;
NODE *constnode18;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __a = setup_varnode();
  __b = setup_varnode();
  __c = setup_varnode();
  __d = setup_varnode();
  __i = setup_varnode();
  __j = setup_varnode();
  __k = setup_varnode();

  constnode6 = mk_number(4.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode7 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode11 = mk_number(100.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode8 = mk_number(8.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode5 = mk_number(1.5000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode2 = mk_number(10.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode4 = mk_number(0.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode3 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode14 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode17 = make_str_node("--> c =", 7, (unsigned short) 0);
  constnode17->flags = 29;
  constnode18 = make_str_node("--> d =", 7, (unsigned short) 0);
  constnode18->flags = 29;
  constnode9 = make_str_node("7", 1, (unsigned short) 0);
  constnode9->flags = 29;
  constnode10 = make_str_node("", 0, (unsigned short) 0);
  constnode10->flags = 29;
  constnode12 = make_str_node("1.0", 3, (unsigned short) 0);
  constnode12->flags = 29;
  constnode13 = make_str_node("5", 1, (unsigned short) 0);
  constnode13->flags = 29;
  constnode15 = make_str_node("--> a =", 7, (unsigned short) 0);
  constnode15->flags = 29;
  constnode16 = make_str_node("--> b =", 7, (unsigned short) 0);
  constnode16->flags = 29;

  regnode1 = setup_regnode("[a-z]00[A-B]", 12);

}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  for (num__i = 1.0000000000;
       (num__i) <= (10.0000000000);
       num__i = (num__i) + (1.0000000000))
    {
      if ((regnode1->type = Node_match, match_op(regnode1, (access_fvar((int) (1.0000000000))), regnode1->re_exp)))
	{
	  (assign_var_num(addr_var(__a), (peek_number(access_var(__a))) + (force_number(access_fvar((int) (2.0000000000))))));
	}
      for (num__k = 0.0000000000;
	   (num__k) <= (num__i);
	   num__k = (num__k) + (((((num__i) / (2.0000000000)) == (0.0000000000)) * (1.5000000000)) + ((((num__i) / (2.0000000000)) != (0.0000000000)) * (1.0000000000))))
	{
	  (assign_var_num(addr_var(__d), (force_number(access_var(__d))) + ((((((((4.0000000000) / (4.0000000000)) / (2.0000000000)) / (1.0000000000)) / (1.0000000000)) / (1.0000000000)) / (1.0000000000)) * (((5.0000000000) == (5.0000000000)) || (cmp_nodes(constnode8, constnode9) > 0)))));
	}
    }
  while (bool_var(access_fvar((int) (1.0000000000))))
    {
      (assign_var2_var(Node_field_spec, NULL, (int) (1.0000000000), NULL, constnode10));
    }
  while ((bool_var(access_fvar((int) (2.0000000000)))) && ((peek_number(access_var(__b))) <= (100.0000000000)))
    {
      (assign_var_num(addr_var(__b), (peek_number(access_var(__b))) + (2.0000000000)));
    }
  for (num__j = 0.0000000000;
       ((num__j) <= (100.0000000000)) && (bool_var(access_fvar((int) (1.0000000000))));
       num__j = (num__j) + ((1) && (bool_var(assign_var_var(addr_var(__d), constnode13)))))
    {
      (assign_var_num(addr_var(__c), (peek_number(access_var(__c))) + (3.0000000000)));
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
  do_print2(constnode15, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__a)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode16, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__b)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode17, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__c)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode18, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__d)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
}
