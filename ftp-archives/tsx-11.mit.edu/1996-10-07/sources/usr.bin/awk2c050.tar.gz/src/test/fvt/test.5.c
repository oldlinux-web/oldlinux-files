#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *regnode1;
NODE *__a;
AWKNUM num__a = 0;
NODE *constnode1;
NODE *__b;
AWKNUM num__b = 0;
NODE *__d;
AWKNUM num__d = 0;
NODE *__e;
AWKNUM num__e = 0;
NODE *constnode2;
NODE *constnode3;
NODE *constnode4;
NODE *constnode5;
NODE *regnode2;
NODE *regnode3;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;
NODE *regnode4;
NODE *__c;
AWKNUM num__c = 0;
NODE *constnode9;
NODE *constnode10;
NODE *__gg;
AWKNUM num__gg = 0;
NODE *constnode11;
NODE *constnode12;
NODE *constnode13;
NODE *constnode14;
NODE *constnode15;
NODE *regnode5;
NODE *constnode16;
NODE *constnode17;
NODE *constnode18;
NODE *constnode19;
NODE *constnode20;
NODE *constnode21;
NODE *constnode22;
NODE *constnode23;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __a = setup_varnode();
  __b = setup_varnode();
  __c = setup_varnode();
  __d = setup_varnode();
  __e = setup_varnode();
  __gg = setup_varnode();

  constnode9 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode17 = mk_number(8.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode23 = mk_number(10.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode12 = mk_number(0.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode8 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode4 = make_str_node("d =", 3, (unsigned short) 0);
  constnode4->flags = 29;
  constnode18 = make_str_node(":::::", 5, (unsigned short) 0);
  constnode18->flags = 29;
  constnode5 = make_str_node("e =", 3, (unsigned short) 0);
  constnode5->flags = 29;
  constnode19 = make_str_node("456", 3, (unsigned short) 0);
  constnode19->flags = 29;
  constnode6 = make_str_node("---> Rule 2", 11, (unsigned short) 0);
  constnode6->flags = 29;
  constnode7 = make_str_node("matched", 7, (unsigned short) 0);
  constnode7->flags = 29;
  constnode10 = make_str_node("c =", 3, (unsigned short) 0);
  constnode10->flags = 29;
  constnode20 = make_str_node(":::::", 5, (unsigned short) 0);
  constnode20->flags = 29;
  constnode11 = make_str_node("XX", 2, (unsigned short) 0);
  constnode11->flags = 29;
  constnode21 = make_str_node("0", 1, (unsigned short) 0);
  constnode21->flags = 29;
  constnode22 = make_str_node(":::::", 5, (unsigned short) 0);
  constnode22->flags = 29;
  constnode13 = make_str_node("YY", 2, (unsigned short) 0);
  constnode13->flags = 29;
  constnode14 = make_str_node(":::::", 5, (unsigned short) 0);
  constnode14->flags = 29;
  constnode15 = make_str_node("ab", 2, (unsigned short) 0);
  constnode15->flags = 29;
  constnode2 = make_str_node("a =", 3, (unsigned short) 0);
  constnode2->flags = 29;
  constnode16 = make_str_node(":::::", 5, (unsigned short) 0);
  constnode16->flags = 29;
  constnode3 = make_str_node("b =", 3, (unsigned short) 0);
  constnode3->flags = 29;

  regnode4 = setup_regnode("[a-z][A-Z]*0$", 13);
  regnode5 = setup_regnode("[a-z][bC]", 9);
  regnode1 = setup_regnode("^[0-9]*$", 8);
  regnode2 = setup_regnode("[aA][bB]", 8);
  regnode3 = setup_regnode("^[0-9]*$", 8);

}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  if (match_op(regnode1, NULL, regnode1->re_exp))
    {
      (assign_var_num(addr_var(__a), (peek_number(access_var(__a))) + (1.0000000000)));
      (assign_var_var(addr_var(__b), (assign_var_var(addr_var(__d), (assign_var_var(addr_var(__e), (access_fvar((int) (1.0000000000)))))))));
      do_print2(constnode2, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__a)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      do_print2(constnode3, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__b)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      do_print2(constnode4, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__d)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
      do_print2(constnode5, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__e)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  else
    {
    }


/* -------------------- Rule/Actions -------------------- */

  if (((regnode2->type = Node_match, match_op(regnode2, (access_fvar((int) (1.0000000000))), regnode2->re_exp))) || (0 /* >>> Non-const regexp <<< */ ))
    {
      do_print2(constnode6, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2(constnode7, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  else
    {
    }


/* -------------------- Rule/Actions -------------------- */

  if ((peek_number(access_spvar(Node_NF))) == (2.0000000000))
    {
      if ((regnode4->type = Node_match, match_op(regnode4, (access_fvar((int) (1.0000000000))), regnode4->re_exp)))
	{
	  (assign_var_num(addr_var(__c), 5.0000000000));
	}
      do_print2(constnode10, 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__c)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  else
    {
    }
}


/*********** END **********/

void 
awk2c_end(void)
{
  (assign_var2_var(Node_subscript, __gg, 0, force_string2(constnode1), constnode11));
  (assign_var2_var(Node_subscript, __gg, 0, force_string2(constnode12), constnode13));
  do_print2(constnode14, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__gg, (tmp_node1->numbr = (regnode5->type = Node_match, match_op(regnode5, constnode15, regnode5->re_exp)), force_string2(tmp_node1)))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode16, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__gg, (tmp_node1->numbr = (8.0000000000) > (5.0000000000), force_string2(tmp_node1)))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode18, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__gg, (tmp_node1->numbr = in_array2(__gg->lnode, constnode19), force_string2(tmp_node1)))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode20, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__gg, (tmp_node1->numbr = in_array2(__gg->lnode, constnode21), force_string2(tmp_node1)))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2(constnode22, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_avar(__gg, (tmp_node1->numbr = !((8.0000000000) < (10.0000000000)), force_string2(tmp_node1)))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
}
