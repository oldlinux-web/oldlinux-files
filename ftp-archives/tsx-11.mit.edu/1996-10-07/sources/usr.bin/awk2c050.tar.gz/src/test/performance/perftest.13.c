#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *constnode1;
NODE *__a;
AWKNUM num__a = 0;
NODE *constnode2;
NODE *constnode3;
NODE *constnode4;
NODE *constnode5;
NODE *constnode6;
NODE *constnode7;
NODE *constnode8;
NODE *__bb;
AWKNUM num__bb = 0;
NODE *constnode9;
NODE *constnode10;
NODE *constnode11;
NODE *constnode12;
NODE *constnode13;
NODE *constnode14;
NODE *constnode15;
NODE *constnode16;
NODE *constnode17;
NODE *constnode18;
NODE *constnode19;
NODE *constnode20;
NODE *constnode21;
NODE *__i1;
AWKNUM num__i1 = 0;
NODE *__i2;
AWKNUM num__i2 = 0;
NODE *__i3;
AWKNUM num__i3 = 0;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __a = setup_varnode();
  __i1 = setup_varnode();
  __i2 = setup_varnode();
  __i3 = setup_varnode();
  __bb = setup_varnode();

  constnode9 = mk_number(4.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode3 = mk_number(4324.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode16 = mk_number(11111.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode2 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode4 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode6 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode17 = make_str_node("bb4", 3, (unsigned short) 0);
  constnode17->flags = 29;
  constnode18 = make_str_node("aa4", 3, (unsigned short) 0);
  constnode18->flags = 29;
  constnode5 = make_str_node("cv", 2, (unsigned short) 0);
  constnode5->flags = 29;
  constnode19 = make_str_node("bb5", 3, (unsigned short) 0);
  constnode19->flags = 29;
  constnode7 = make_str_node("NULL", 4, (unsigned short) 0);
  constnode7->flags = 29;
  constnode8 = make_str_node("", 0, (unsigned short) 0);
  constnode8->flags = 29;
  constnode10 = make_str_node("aa1", 3, (unsigned short) 0);
  constnode10->flags = 29;
  constnode20 = make_str_node("NULL", 4, (unsigned short) 0);
  constnode20->flags = 29;
  constnode11 = make_str_node("bb1", 3, (unsigned short) 0);
  constnode11->flags = 29;
  constnode21 = make_str_node("", 0, (unsigned short) 0);
  constnode21->flags = 29;
  constnode12 = make_str_node("aa2", 3, (unsigned short) 0);
  constnode12->flags = 29;
  constnode13 = make_str_node("bb2", 3, (unsigned short) 0);
  constnode13->flags = 29;
  constnode14 = make_str_node("aa3", 3, (unsigned short) 0);
  constnode14->flags = 29;
  constnode1 = make_str_node("abc", 3, (unsigned short) 0);
  constnode1->flags = 29;
  constnode15 = make_str_node("bb3", 3, (unsigned short) 0);
  constnode15->flags = 29;


  (assign_var2_num(Node_subscript, __a, 0, constnode1, 1.0000000000));
  (assign_var2_num(Node_subscript, __a, 0, force_string2(constnode3), 2.0000000000));
  (assign_var2_num(Node_subscript, __a, 0, constnode5, 3.0000000000));
  (assign_var2_var(Node_subscript, __a, 0, constnode7, constnode8));
  (assign_var2_num(Node_subscript, __bb, 0, force_string2(constnode2), 4.0000000000));
  (assign_var2_var(Node_subscript, __bb, 0, constnode10, constnode11));
  (assign_var2_var(Node_subscript, __bb, 0, constnode12, constnode13));
  (assign_var2_var(Node_subscript, __bb, 0, constnode14, constnode15));
  (assign_var2_var(Node_subscript, __bb, 0, force_string2(constnode16), constnode17));
  (assign_var2_var(Node_subscript, __bb, 0, constnode18, constnode19));
  (assign_var2_var(Node_subscript, __bb, 0, constnode20, constnode21));
}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

/* >>> Node_K_arrayfor <<< */
/* >>> Node_K_arrayfor <<< */
/* >>> Node_K_arrayfor <<< */
/* >>> Node_K_arrayfor <<< */
/* >>> Node_K_arrayfor <<< */
}


/*********** END **********/

void 
awk2c_end(void)
{
}
