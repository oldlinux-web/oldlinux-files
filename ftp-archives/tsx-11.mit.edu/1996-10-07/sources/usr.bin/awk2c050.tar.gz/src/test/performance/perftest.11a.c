#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__a;
AWKNUM num__a = 0;
NODE *constnode1;
NODE *constnode2;
NODE *constnode3;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __a = setup_varnode();

  constnode1 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode2 = make_str_node("afsdfs", 6, (unsigned short) 0);
  constnode2->flags = 29;
  constnode3 = make_str_node("fjklfjskl", 9, (unsigned short) 0);
  constnode3->flags = 29;


  (assign_var_num(addr_var(__a), 5.0000000000));
}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  do_print2(constnode2, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__a)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2(constnode3, 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
}


/*********** END **********/

void 
awk2c_end(void)
{
}
