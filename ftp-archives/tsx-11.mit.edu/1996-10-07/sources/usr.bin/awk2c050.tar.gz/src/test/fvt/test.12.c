#include "awk.h"

/********** AWK Program's variables and constants **********/

NODE *__a;
AWKNUM num__a = 0;
NODE *constnode1;
NODE *__b;
AWKNUM num__b = 0;
NODE *constnode2;
NODE *constnode3;
NODE *__ss1;
AWKNUM num__ss1 = 0;
NODE *__ss3;
AWKNUM num__ss3 = 0;
NODE *constnode4;
NODE *__ss4;
AWKNUM num__ss4 = 0;
NODE *__ss5;
AWKNUM num__ss5 = 0;
NODE *__i;
AWKNUM num__i = 0;
NODE *__oo;
AWKNUM num__oo = 0;
NODE *constnode5;
NODE *__oo3;
AWKNUM num__oo3 = 0;
NODE *constnode6;
NODE *__oo4;
AWKNUM num__oo4 = 0;
NODE *__oo5;
AWKNUM num__oo5 = 0;
NODE *constnode7;
NODE *__y6;
AWKNUM num__y6 = 0;
NODE *constnode8;
NODE *__l8;
AWKNUM num__l8 = 0;
NODE *constnode9;
NODE *constnode10;
NODE *__hii;
AWKNUM num__hii = 0;
NODE *constnode11;
NODE *__hii2;
AWKNUM num__hii2 = 0;
NODE *constnode12;
NODE *__nmm;
AWKNUM num__nmm = 0;
NODE *__nmo;
AWKNUM num__nmo = 0;
NODE *constnode13;
NODE *__hj1;
AWKNUM num__hj1 = 0;
NODE *constnode14;
NODE *__aa;
AWKNUM num__aa = 0;
NODE *__y7;
AWKNUM num__y7 = 0;
NODE *__y8;
AWKNUM num__y8 = 0;
NODE *constnode15;
NODE *__ss2;
AWKNUM num__ss2 = 0;
NODE *__non;
AWKNUM num__non = 0;
NODE *constnode16;
NODE *__fjdlkfj;
AWKNUM num__fjdlkfj = 0;
NODE *constnode17;
NODE *__aaa;
AWKNUM num__aaa = 0;
NODE *constnode18;
NODE *constnode19;
NODE *constnode20;
NODE *__wl2;
AWKNUM num__wl2 = 0;
NODE *__wl3;
AWKNUM num__wl3 = 0;
NODE *constnode21;
NODE *constnode22;
NODE *constnode23;
NODE *__i9;
AWKNUM num__i9 = 0;
NODE *__kkkk;
AWKNUM num__kkkk = 0;
NODE *__llll;
AWKNUM num__llll = 0;
NODE *__kk2;
AWKNUM num__kk2 = 0;
NODE *__kk3;
AWKNUM num__kk3 = 0;
NODE *__gggg;
AWKNUM num__gggg = 0;
NODE *__gg5;
AWKNUM num__gg5 = 0;
NODE *__lop;
AWKNUM num__lop = 0;
NODE *constnode24;
NODE *__jkl;
AWKNUM num__jkl = 0;
NODE *constnode25;
NODE *__gg;
AWKNUM num__gg = 0;
NODE *__hh;
AWKNUM num__hh = 0;
NODE *constnode26;
NODE *__jj;
AWKNUM num__jj = 0;
NODE *constnode27;
NODE *__kk;
AWKNUM num__kk = 0;
NODE *constnode28;
NODE *__inn;
AWKNUM num__inn = 0;
NODE *__uu;
AWKNUM num__uu = 0;
NODE *constnode29;
NODE *constnode30;
NODE *constnode31;
NODE *__ggg;
AWKNUM num__ggg = 0;
NODE *constnode32;


/*********** BEGIN **********/

void 
awk2c_begin(void)
{

  __kk2 = setup_varnode();
  __kk3 = setup_varnode();
  __hj1 = setup_varnode();
  __l8 = setup_varnode();
  __hh = setup_varnode();
  __a = setup_varnode();
  __b = setup_varnode();
  __hii2 = setup_varnode();
  __i = setup_varnode();
  __wl2 = setup_varnode();
  __wl3 = setup_varnode();
  __y6 = setup_varnode();
  __y7 = setup_varnode();
  __y8 = setup_varnode();
  __i9 = setup_varnode();
  __aa = setup_varnode();
  __nmm = setup_varnode();
  __nmo = setup_varnode();
  __uu = setup_varnode();
  __oo3 = setup_varnode();
  __oo4 = setup_varnode();
  __oo5 = setup_varnode();
  __fjdlkfj = setup_varnode();
  __jkl = setup_varnode();
  __gggg = setup_varnode();
  __jj = setup_varnode();
  __lop = setup_varnode();
  __inn = setup_varnode();
  __ss1 = setup_varnode();
  __ss2 = setup_varnode();
  __ss3 = setup_varnode();
  __ss4 = setup_varnode();
  __ss5 = setup_varnode();
  __gg5 = setup_varnode();
  __ggg = setup_varnode();
  __aaa = setup_varnode();
  __llll = setup_varnode();
  __gg = setup_varnode();
  __non = setup_varnode();
  __kk = setup_varnode();
  __oo = setup_varnode();
  __hii = setup_varnode();
  __kkkk = setup_varnode();

  constnode7 = mk_number(4.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode19 = mk_number(3.3000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode8 = mk_number(45.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode1 = mk_number(5.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode27 = mk_number(6.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode21 = mk_number(7.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode13 = mk_number(56.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode10 = mk_number(10.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode16 = mk_number(0.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode26 = mk_number(32.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode12 = mk_number(1.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode9 = mk_number(2.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode14 = mk_number(34.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));
  constnode5 = mk_number(3.0000000000, (unsigned int) (MALLOC | PERM | NUM | NUMBER));

  constnode17 = make_str_node("ss5 =", 5, (unsigned short) 0);
  constnode17->flags = 29;
  constnode4 = make_str_node("fhjskhfksjhj", 12, (unsigned short) 0);
  constnode4->flags = 29;
  constnode18 = make_str_node("v+v+v", 5, (unsigned short) 0);
  constnode18->flags = 29;
  constnode28 = make_str_node("abc", 3, (unsigned short) 0);
  constnode28->flags = 29;
  constnode6 = make_str_node("kk", 2, (unsigned short) 0);
  constnode6->flags = 29;
  constnode29 = make_str_node("abc", 3, (unsigned short) 0);
  constnode29->flags = 29;
  constnode20 = make_str_node("fdshjk", 6, (unsigned short) 0);
  constnode20->flags = 29;
  constnode11 = make_str_node("abc", 3, (unsigned short) 0);
  constnode11->flags = 29;
  constnode30 = make_str_node("abcfdf", 6, (unsigned short) 0);
  constnode30->flags = 29;
  constnode31 = make_str_node("in while", 8, (unsigned short) 0);
  constnode31->flags = 29;
  constnode22 = make_str_node("abc", 3, (unsigned short) 0);
  constnode22->flags = 29;
  constnode32 = make_str_node("abc", 3, (unsigned short) 0);
  constnode32->flags = 29;
  constnode23 = make_str_node("def", 3, (unsigned short) 0);
  constnode23->flags = 29;
  constnode24 = make_str_node("dfs", 3, (unsigned short) 0);
  constnode24->flags = 29;
  constnode15 = make_str_node("aaa", 3, (unsigned short) 0);
  constnode15->flags = 29;
  constnode2 = make_str_node("abc", 3, (unsigned short) 0);
  constnode2->flags = 29;
  constnode25 = make_str_node("3423", 4, (unsigned short) 0);
  constnode25->flags = 29;
  constnode3 = make_str_node("abc", 3, (unsigned short) 0);
  constnode3->flags = 29;


  (assign_var_num(addr_var(__a), 5.0000000000));
  (assign_var_var(addr_var(__b), constnode2));
  (assign_var_var(addr_var(__b), constnode3));
  (assign_var_var(addr_var(__ss1), (access_var(__b))));
  (assign_var_var(addr_var(__ss3), constnode4));
  (assign_var_var(addr_var(__ss4), (access_var(__ss1))));
  (assign_var_var(addr_var(__ss5), (access_var(__ss4))));
  (assign_var_num(addr_var(__i), 5.0000000000));
  (assign_var_num(addr_var(__oo), 3.0000000000));
  (assign_var_var(addr_var(__oo3), constnode6));
  (assign_var_num(addr_var(__oo4), peek_number(access_var(__a))));
  (assign_var_num(addr_var(__oo5), (peek_number(access_var(__i))) * (4.0000000000)));
  do_print2((access_var(__a)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__b)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__i)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__oo)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__oo3)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__oo4)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__oo5)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (peek_number(access_var(__a))) < (peek_number(access_var(__oo)));
  (assign_var_num(addr_var(__y6), 45.0000000000));
  for (num__l8 = 2.0000000000;
       (num__l8) <= (10.0000000000);
       num__l8++)
    {
    }
  (assign_var_var(addr_var(__hii), constnode11));
  (assign_var_var(addr_var(__hii2), (access_var(__hii))));
}


/********** C function for converted AWK program rules **********/

void 
awk2c_rules(void)
{


/* -------------------- Rule/Actions -------------------- */

  if (cmp_nodes((access_fvar((int) (1.0000000000))), constnode12) > 0)
    {
      (assign_var_num(addr_var(__hii), 1.0000000000));
    }
  else
    {
    }


/* -------------------- Rule/Actions -------------------- */

  (assign_var_num(addr_var(__hii2), 45.0000000000));


/* -------------------- Rule/Actions -------------------- */

  if ((5.0000000000) > (4.0000000000))
    {
      if ((force_number(access_var(__hii))) + (peek_number(access_var(__hii2))))
	{
	  if (1.0000000000)
	    {
	      cmp_nodes((access_var(__hii)), (access_var(__hii2))) < 0;
	    }
	}
    }
  else
    {
    }


/* -------------------- Rule/Actions -------------------- */

  (assign_var_num(addr_var(__nmm), (num__nmo) + (num__nmo)));
  do_print2((access_var(__nmm)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (56.0000000000) < (num__hj1 = 45.0000000000);
  (56.0000000000) < (num__hj1++);
  cmp_nodes((access_var(__y6)), constnode8) < 0;
  (assign_var_var(addr_var(__y6), (access_avar(__aa, force_string2(constnode14)))));
  (num__y7) + (3.0000000000);
  (num__y7) + (3.0000000000);
  (force_number(access_var(__y8))) + (3.0000000000);
  (assign_var_var(addr_var(__y8), constnode15));
  do_print2((access_var(__ss1)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2((access_var(__ss2)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2((access_var(__ss3)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2((access_var(__ss4)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var_var(addr_var(__ss4), (access_fvar((int) ((peek_number(access_var(__a))) - (force_number(access_var(__b))))))));
  do_print2((access_var(__ss5)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var2_num(Node_subscript, __non, 0, (access_var(__ss4)), 0.0000000000));
  (assign_var_var(addr_var(__ss5), (access_var(__fjdlkfj))));
  do_print2(constnode17, 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__ss5)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var2_var(Node_subscript, __aaa, 0, force_string2(access_var(__ss3)), constnode18));
  do_print2((access_fvar((int) (1.0000000000))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var2_num(Node_subscript, __aaa, 0, (access_fvar((int) ((4.0000000000) - (3.0000000000)))), 45.0000000000));
  (assign_var2_num(Node_subscript, __aaa, 0, force_string2(access_var(__oo5)), 34.0000000000));
  do_print2((access_avar(__aaa, (access_fvar((int) ((4.0000000000) - (3.0000000000)))))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2((access_avar(__aaa, (access_var(__oo5)))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  do_print2((access_avar(__aaa, (access_var(__ss3)))), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  while ((bool_var(access_avar(__aa, force_string2(access_var(__ss3))))) && (0.0000000000))
    {
      (assign_var_num(addr_var(__ss3), 3.3000000000));
    }
  (assign_var_var(addr_var(__ss3), constnode20));
  (assign_var_num(addr_var(__wl2), 4.0000000000));
  (assign_var_num(addr_var(__wl3), 5.0000000000));
  while ((cmp_nodes((access_var(__wl2)), constnode1) < 0) && (0.0000000000))
    {
      while ((cmp_nodes((access_var(__wl3)), constnode21) >= 0) && (0.0000000000))
	{
	  (assign_var_var(addr_var(__wl3), constnode22));
	}
      (assign_var_var(addr_var(__wl2), constnode23));
    }
  do
    {
      num__i9 = 1.0000000000;
    }
  while ((num__i9) > (2.0000000000));
  (assign_var_num(addr_var(__kkkk), peek_number(access_var(__kkkk)) + 1));
  (assign_var_num(addr_var(__kkkk), peek_number(access_var(__kkkk)) + 1));
  ++num__llll;
  ++num__llll;
  (assign_var_num(addr_var(__kk2), (tmp_numbr = peek_number(access_var(__kk3)), (assign_var_num(addr_var(__kk3), peek_number(access_var(__kk3)) + 1)), tmp_numbr)));
  (assign_var_num(addr_var(__kk2), (tmp_numbr = peek_number(access_var(__kk3)), (assign_var_num(addr_var(__kk3), peek_number(access_var(__kk3)) + 1)), tmp_numbr)));
  num__gggg += 3.0000000000;
  (num__gggg) - (2.0000000000);
  num__gg5 = peek_number(assign_var_num(addr_var(__kk2), peek_number(access_var(__kk2)) + 1));
  num__gg5 = ++num__lop;
  do_print2((access_var(__kkkk)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__kk2)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__kk3)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  cmp_nodes((access_var(__a)), (access_var(__b))) > 0;
  (assign_var_var(addr_var(__b), constnode24));
  (peek_number(access_var(__a))) < (peek_number(access_var(__oo)));
  (peek_number(access_spvar(Node_NF))) < (2.0000000000);
  (peek_number(access_spvar(Node_FNR))) < (2.0000000000);
  (peek_number(access_spvar(Node_NR))) < (2.0000000000);
  (peek_number(access_spvar(Node_NR))) < (2.0000000000);
  (assign_var2_var(Node_NR, NULL, 0, NULL, (access_var(__jkl))));
  (assign_var2_var(Node_NR, NULL, 0, NULL, constnode25));
  cmp_nodes((access_spvar(Node_NR)), constnode9) < 0;
  (assign_var_num(addr_var(__gg), 7.0000000000));
  if (peek_number(access_var(__gg)))
    {
    }
  if (((peek_number(access_var(__gg))) > (7.0000000000)) && ((peek_number(access_var(__hh))) <= (32.0000000000)))
    {
    }
  (assign_var_num(addr_var(__hh), peek_number(access_var(__gg))));
  (assign_var_num(addr_var(__jj), (peek_number(access_var(__hh))) + (2.0000000000)));
  do_print2((access_var(__a)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__b)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_spvar(Node_NF)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_spvar(Node_NR)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_spvar(Node_FNR)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__gg)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__hh)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__jj)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  for ((assign_var_num(addr_var(__i), 2.0000000000));
       (peek_number(access_var(__i))) <= (5.0000000000);
       (assign_var_num(addr_var(__i), peek_number(access_var(__i)) + 1)))
    {
      (5.0000000000) + (6.0000000000);
      (assign_var_num(addr_var(__kk), 3.0000000000));
      (6.0000000000) - (7.0000000000);
      (peek_number(access_var(__kk))) - (3.0000000000);
      (assign_var_var(addr_var(__kk), constnode28));
      cmp_nodes((access_var(__kk)), constnode9) <= 0;
      do_print2((access_var(__i)), 1, (struct redirect *) NULL, stdout, OFS);
      do_print2((access_var(__kk)), 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }
  for ((assign_var_num(addr_var(__i), 2.0000000000));
       (peek_number(access_var(__i))) <= (5.0000000000);
       (assign_var_num(addr_var(__i), peek_number(access_var(__i)) + 1)))
    {
      for (num__inn = 1.0000000000;
	   (num__inn) <= (10.0000000000);
	   num__inn++)
	{
	}
    }
  for ((assign_var_num(addr_var(__uu), 1.0000000000));
       cmp_nodes((access_var(__uu)), constnode12) <= 0;
       (access_var(__uu)))
    {
      (assign_var_var(addr_var(__uu), constnode29));
    }
  while ((cmp_nodes((access_var(__i)), constnode1) > 0) && (0.0000000000))
    {
      5.0000000000;
      (assign_var_var(addr_var(__i), constnode30));
      do_print2(constnode31, 0, (struct redirect *) NULL, stdout, OFS);
      do_print2_ORS((struct redirect *) NULL, stdout, ORS);
    }


/* -------------------- Rule/Actions -------------------- */

  (assign_var_var(addr_var(__ggg), constnode32));
  (assign_var_var(addr_var(__oo3), (access_var(__ggg))));
  do_print2((access_var(__oo3)), 1, (struct redirect *) NULL, stdout, OFS);
  do_print2((access_var(__ggg)), 0, (struct redirect *) NULL, stdout, OFS);
  do_print2_ORS((struct redirect *) NULL, stdout, ORS);
  (assign_var_num(addr_var(__ss1), 34.0000000000));
  (assign_var_num(addr_var(__ss2), peek_number(access_var(__ss1))));
}


/*********** END **********/

void 
awk2c_end(void)
{
}
