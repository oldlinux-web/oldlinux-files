/*
 * This file is part of uudeview, the simple and friendly multi-part multi-
 * file uudecoder  program  (c)  1994 by Frank Pilhofer. The author may be
 * contacted by his email address,          fp@informatik.uni-frankfurt.de
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef SYSTEM_WINDLL
#include <windows.h>
#endif
#ifdef SYSTEM_OS2
#include <os2.h>
#endif

/*
 * Main function for standalone uuenview
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <stdio.h>
#include <time.h>

#ifdef STDC_HEADERS
#include <stdlib.h>
#include <string.h>
#endif
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#ifdef HAVE_ERRNO_H
#include <errno.h>
#endif


#include <uudeview.h>
#include <fptools.h>
#include <uufnflt.h>


char * uuenview_id = "$Id: uuenview.c,v 1.10 1996/07/23 19:41:17 fp Exp $";

/*
 * mail and news software
 */

#ifdef PROG_INEWS
char *  uue_inewsprog = PROG_INEWS;
#else
char *  uue_inewsprog = NULL;
#endif
#ifdef PROG_MAILER
char *  uue_mailprog  = PROG_MAILER;
#else
char *  uue_mailprog  = NULL;
#endif
#ifdef MAILER_NEEDS_SUBJECT
int     uue_mpsubject = 1;
#else
int     uue_mpsubject = 0;
#endif

/*
 * defines
 */

#define UUE_TOFILE	1
#define UUE_MAILTO	2
#define UUE_POSTTO	3

/*
 * the progress meter is only displayed if stderr is a terminal.
 * take care of systems where we can't check this condition.
 */

#ifdef HAVE_ISATTY
#define UUISATTY(f)	(isatty(fileno(f)))
#else
#define UUISATTY(f)	(1)
#endif

/*
 * Message Callback
 */

static void
MessageCallback (void *param, char *message, int level)
{
#if 0
  if (UUGetOption (UUOPT_VERBOSE, NULL, NULL, 0) || level >= UUMSG_WARNING) {
    fprintf (stderr, "%70s\r", "");
    fprintf (stderr, "%s\n", message);
  }
#else
  if (level >= UUMSG_WARNING) {
    fprintf (stderr, "%70s\r", "");
    fprintf (stderr, "%s\n", message);
  }
#endif
}

static int
BusyCallback (void *param, uuprogress *progress)
{
  char stuff[26];
  int count, pcts;
  char *ptr;

  /*
   * Display progress meter only if stderr is a terminal
   */

  if (!UUISATTY(stderr))
    return 0;

  if ((ptr = _FP_strrchr (progress->curfile, DIRSEPARATOR[0])) == NULL)
    ptr = progress->curfile;
  else
    ptr++;

  if (progress->action == 4 && UUGetOption (UUOPT_VERBOSE, NULL, NULL, 0)) {
    pcts = (int)((100*progress->partno+progress->percent-100) /
		 progress->numparts);
    for (count=0, stuff[25]='\0'; count<25; count++)
      stuff[count] = (count<pcts/4)?'#':'.';
    fprintf (stderr, "encoding part%3d of%3d %s\r",
	     progress->partno, progress->numparts,
	     stuff);
    fflush  (stderr);
  }
  return 0;
}

/*
 * usage
 */

static void
usage (char *argv0)
{
  if (_FP_stristr (argv0, "uuencode") != NULL) {
    printf ("\n\
  uuencode -- a simple encoder (w) 1995 Frank Pilhofer\n\n\
  usage:\n\
    %s [infile] remotefile\n\n\
",
	    argv0);
    printf ("\
\tinfile      the local file, where to read data from. If no infile\n\
\t            is given, or infile is a single hyphen, the standard\n\
\t            input is used instead.\n\
\tremotefile  the name as which the recepient will receive the file\n\
\n\
  For much more powerful encoding facilities, try calling this program\n\
  as 'uuenview'.\n\
\n\
");
    return;
  }
  printf ("\n\
  UUENVIEW %spl%s -- a simple encoder (w) 1995 Frank Pilhofer\n\n\
  usage:\n\
    %s [-type] [-lines] ", VERSION, PATCH, argv0);
#ifndef SYSTEM_DOS
  printf ("[-m address] ");
  printf ("[-p newsgroup] ");
  printf ("\n\t\t");
  printf ("[-s subject] ");
  printf ("[-o[d path]] ");
#else
  printf ("[-od path] ");
#endif
  printf ("file(s)\n\n");
  printf ("\
\ttype      one of 'u', 'x', 'b' for UUencoding, XXencoding or Base64\n\
\t          encoding, respectively. Defaults to uuencoding.\n\
\tlines     sets the number of encoded lines per file. Values smaller\n\
\t          than 200 are ignored. 1000 lines encode 45kb UU/XX and 57kb\n\
\t          Base64 data. Default is unlimited.\n\
");
#ifndef SYSTEM_DOS
  printf ("\
\taddress   comma-separated list of email recepients.\n\
\tnewsgroup comma-separated list of newsgroups to post the file to.\n\
\tsubject   used on the subject line for emailing and posting.\n\
");
#endif
  printf ("\
\tfile(s)   one or more files to be encoded.\n\
");
#ifdef SYSTEM_DOS
  printf ("\
\t          The encoded files are saved to files with the same base\n\
\t          name as the original but with an extension of .001, .002\n\
\t          etc. If you give a pathname with the -od parameter, the\n\
\t          files are written to that directory, otherwise the're\n\
\t          written to the current working directory.\n\
");
#else
  printf ("\
\t          If -o is used, the encoded files will be saved to files\n\
\t          with the same base name as the original but an extension\n\
\t          of .001, .002 etc. If you use -od and give an existing\n\
\t          pathname, the encoded files are written to that directory\n\
\t          instead of the current working directory.\n\
");
  printf ("\
\t          If neither of -o, -m, -p is specified, output is sent to\n\
\t          standard output, and the maximum line count is ignored.\n\
");
#endif
  printf ("\n\
  example:\n\
");
#ifdef SYSTEM_DOS
  printf ("\
    %s -b -2000 -o uuenview.exe\n\
\tEncodes 'uuenview.exe' as Base64 into 2000-line chunks, and writes\n\
\tthe result to uuenview.001 and uuenview.002.\n\
\n\
",
	  argv0);
#else
  printf ("\
    %s -b -2000 -m root -o uudeview.tar.gz\n\
\tEncodes 'uudeview.tar.gz' as Base64 into 2000-line chunks. It is\n\
\tboth mailed to your system administrator and written to the files\n\
\tuudeview.001 and uudeview.002\n\
\n\
",
	  argv0);
#endif

  return;
}

/*
 * Mail or Post a file. Remember to keep in sync with uutcl.c
 */

static int
SendAFile (FILE *infile,   char *infname,
	   int encoding,   int linperfile,
	   char *outfname, char *towhom,
	   char *subject,  int isemail)
{
  char *command, *rcptlist, *ptr;
  FILE *thepipe, *theifile;
  int len, res, count, part;

  if (towhom==NULL ||
      (outfname==NULL&&infname==NULL) || (infile==NULL&&infname==NULL) ||
      (encoding!=UU_ENCODED&&encoding!=XX_ENCODED&&encoding!=B64ENCODED)) {
    fprintf (stderr, "oops: Parameter check failed in SendAFile()\n");
    return UURET_ILLVAL;
  }

#ifndef HAVE_POPEN
  fprintf (stderr, "error: Your system does not support %s of files\n",
	   (isemail)?"mailing":"posting");
  return UURET_ILLVAL;
#else
  if (isemail && (uue_mailprog == NULL || *uue_mailprog == '\0')) {
    fprintf (stderr, "error: Cannot Email file: option not configured\n");
    return UURET_ILLVAL;
  }
  else if (!isemail && (uue_inewsprog == NULL || *uue_inewsprog == '\0')) {
    fprintf (stderr, "error: Cannot Post file: option not configured\n");
    return UURET_ILLVAL;
  }

  len = strlen ((isemail)?uue_mailprog:uue_inewsprog) + 
    ((uue_mpsubject)?strlen(subject):0) +
      ((isemail)?0:strlen(towhom)) + 32;

  if ((command = (char *) malloc (len)) == NULL) {
    fprintf (stderr, "error: Out of memory allocating %d bytes\n", len);
    return UURET_NOMEM;
  }

  if ((rcptlist = (char *) malloc (strlen (towhom) + 16)) == NULL) {
    fprintf (stderr, "error: Out of memory allocating %d bytes\n",
	     strlen (towhom)+16);
    _FP_free (command);
    return UURET_NOMEM;
  }

  if (isemail) {
    if (uue_mpsubject)
      sprintf (command, "%s -s \"%s\"", uue_mailprog, subject);
    else
      sprintf (command, "%s", uue_mailprog);

    /*
     * Attach list of recipients to mailer command and compose another list
     * of recipients
     */

    count = 0;
    rcptlist[0] = '\0';
    ptr = _FP_strtok (towhom, ",; ");

    while (ptr) {
      strcat (command, " ");
      strcat (command, ptr);

      if (count++)
	strcat (rcptlist, ",");
      strcat (rcptlist, ptr);

      ptr = _FP_strtok (NULL, ",; ");
    }
  }
  else {
    sprintf (command, "%s", uue_inewsprog);

    count = 0;
    rcptlist[0] = '\0';
    ptr = _FP_strtok (towhom, ";, ");

    while (ptr) {
      if (count++)
	strcat (rcptlist, ",");
      strcat (rcptlist, ptr);
      ptr = _FP_strtok (NULL, ";, ");
    }
  }

  /*
   * Get going ...
   */

  if (infile == NULL) {
    if ((theifile = fopen (infname, "rb")) == NULL) {
      fprintf (stderr, "error: Could not open input file %s: %s\n",
	       infname, strerror (errno));
      _FP_free (rcptlist);
      _FP_free (command);
      return UURET_IOERR;
    }
  }
  else {
    theifile = infile;
  }

  for (part=1; !feof (theifile); part++) {
    if ((thepipe = popen (command, "w")) == NULL) {
      fprintf (stderr, "error: could not open pipe %s\n", command);
      if (infile==NULL) fclose (theifile);
      _FP_free (rcptlist);
      _FP_free (command);
      return UURET_IOERR;
    }

#if 0
    if (UUGetOption(UUOPT_VERBOSE, NULL, NULL, 0)) {
      fprintf (stderr, "%s part %03d of %s to %s ... ",
	       (isemail)?"mailing":"posting",
	       part, (infname)?infname:outfname,
	       rcptlist);
      fflush  (stderr);
    }
#endif

    res = UUE_PrepPartial (thepipe, theifile, infname, encoding,
			   outfname, 0, part, linperfile, 0,
			   rcptlist, NULL, subject, isemail);

#if 0
    if (UUGetOption (UUOPT_VERBOSE, NULL, NULL, 0)) {
      if (res == UURET_OK)
	fprintf (stderr, "ok.\n");
      else
	fprintf (stderr, "%s\n", UUstrerror (res));
    }
#endif

    pclose (thepipe);

    if (res != UURET_OK) {
      if (infile == NULL) fclose (theifile);
      _FP_free (rcptlist);
      _FP_free (command);
      return res;
    }
  }

  if (infile == NULL) fclose (theifile);
  _FP_free (rcptlist);
  _FP_free (command);
  return UURET_OK;
#endif
}

/*
 * main function from uuenview
 */

int
main (int argc, char *argv[])
{
  int outflags[5], tostdout, linperfile, uuencode, encoding;
  int index, introfile, subject, count, fileflag, stdinused;
  char filename[512], usename[512], outdir[512];
  int iskipflag;
  FILE *testit;

  /*
   * set defaults
   */
  outflags[UUE_TOFILE] = -1;
  outflags[UUE_MAILTO] = -1;
  outflags[UUE_POSTTO] = -1;
  subject              = -1;
  introfile            = -1;
  tostdout             =  1;
  linperfile           =  0;
  uuencode             =  0;
  encoding             =  UU_ENCODED;
  count                =  0;
  stdinused            =  0;

  if (UUInitialize () != UURET_OK) {
    fprintf (stderr, "oops: could not initialize decoding library\n");
    return 2;
  }
  UUSetOption (UUOPT_VERBOSE, 0, NULL);

#if defined(SYSTEM_DOS) || defined(SYSTEM_QUICKWIN)
  UUSetFNameFilter (NULL, UUFNameFilterDOS);
#else
  UUSetFNameFilter (NULL, UUFNameFilterUnix);
#endif
  /*
   * Setup Callback
   */
  UUSetMsgCallback  (NULL, MessageCallback);
  UUSetBusyCallback (NULL, BusyCallback, 100);

  /*
   * OK to overwrite target files
   */

  UUSetOption (UUOPT_OVERWRITE, 1, NULL);

  if (argc < 2) {
    usage (argv[0]);
    return 1;
  }
  if (_FP_stristr (argv[0], "uuencode") != NULL)
    uuencode = 1; /* uuencode compatibility */

  /*
   * In DOS, the default is to create files, not to send it to stdout
   */

#ifdef SYSTEM_DOS
  outflags[UUE_TOFILE] = -42; /* MAGIC */
  tostdout             =  0;
#endif  

  /*
   * Check for environment variable called INEWS and override
   * compile-time option if present
   */
  if (getenv ("INEWS") && *(char *)getenv ("INEWS")) {
    uue_inewsprog = getenv ("INEWS");
  }

  /*
   * browse command line flags
   */
  for (index=1; index<argc; index++) {
    if (*argv[index] == '-') {
      switch (argv[index][1]) {
      case '\0':/* this is a file name */break;
      case 'b': encoding = B64ENCODED; break;
      case 'u': encoding = UU_ENCODED; break;
      case 'x': encoding = XX_ENCODED; break;
#ifndef SYSTEM_DOS
      case 'm': 
	if (index+1<argc && argv[index+1][0] != '-') {
	  outflags[UUE_MAILTO] = ++index; 
	  tostdout             = 0;
	}
	else
	  fprintf (stderr, "error: -m requires a parameter\n");
	break;
      case 'p':
	if (index+1<argc && argv[index+1][0] != '-') {
	  outflags[UUE_POSTTO] = ++index;
	  tostdout             = 0;
	}
	else
	  fprintf (stderr, "error: -p requires a parameter\n");
	break;
#endif
      case 'o':
	if (argv[index][2] == 'd') {
	  if (index+1<argc && argv[index+1][0] != '-') {
	    strcpy (outdir, argv[++index]);
	    outflags[UUE_TOFILE] = index;
	    tostdout             = 0;
	    if (strlen(outdir)>0) {
	      if (outdir[strlen(outdir)-1]!=DIRSEPARATOR[0]) {
		strcat (outdir, DIRSEPARATOR);
	      }
	    }
	    UUSetOption (UUOPT_SAVEPATH, 0, outdir);
	  }
	  else {
	    fprintf (stderr, "error: -od requires a parameter\n");
	  }
	}
	else {
	  outflags[UUE_TOFILE] = index;
	  tostdout             = 0;
	}
	break;
      case 'i':
	if (index+1<argc && argv[index+1][0] != '-') {
	  introfile = ++index;
	}
	else
	  fprintf (stderr, "error: -i requires a parameter\n");
	break;
      case 's':
	if (index+1<argc && argv[index+1][0] != '-') {
	  subject   = ++index;
	}
	else
	  fprintf (stderr, "error: -s requires a parameter\n");
	break;
      case 'v':
	UUSetOption (UUOPT_VERBOSE, 1, NULL);
	break;
      case 'h':
      case '?':
	usage(argv[0]);
	return 0;
      case 'V':
	fprintf (stdout, "uuenview %spl%s compiled on %s\n",
		 VERSION, PATCH, __DATE__);
	return 0;
      default:
	/* should be a line count of the form -1000 or a forced line count
	 * like --100 which disables the sanity check
	 */
	if (argv[index][1]>='0' && argv[index][1]<='9') {
	  linperfile = atoi (argv[index] + 1);
	  if (linperfile != 0 && linperfile < 200) {
	    fprintf (stderr,
		     "warning: lines per file must be >= 200 (ignored).\n");
	    linperfile=0;
	  }
	}
	else if (argv[index][1]=='-' &&
		 argv[index][2]>='0' && argv[index][2]<='9') {
	  linperfile = atoi (argv[index] + 2);
	}
	else if (argv[index][1]=='-') {
	  usage(argv[0]);
	  return 0;
	}
	else {
	  fprintf (stderr, "warning: unknown option '%s' ignored.\n",
		   argv[index]);
	}
      }
    }
  }
  /*
   * check integrity
   */

  if (linperfile != 0 && tostdout) {
    fprintf (stderr, "warning: cannot split file on standard output (use -o)\n");
    linperfile=0;
  }
  if (introfile>0 && tostdout) {
    fprintf (stderr, "warning: -i not possible on standard output (use -m or -p)\n");
    introfile = -1;
  }
  if (introfile>0) {
    if ((testit = fopen (argv[introfile], "r")) == NULL) {
      fprintf (stderr, "warning: introfile %s not readable.\n",
	       argv[introfile]);
      introfile = -1;
    }
    else
      fclose (testit);
  }
  if (subject>0 && tostdout) {
    fprintf (stderr, "warning: -s not possible on standard output\n");
    subject = -1;
  }
  if (encoding!=UU_ENCODED && encoding!=XX_ENCODED &&
      encoding!=B64ENCODED) {
    fprintf (stderr, "warning: unknown encoding method (%d)?\n",
	     encoding);
    encoding=UU_ENCODED;
  }

#ifdef SYSTEM_DOS
  if (tostdout==0 && outflags[UUE_TOFILE] == -1) {
    fprintf (stderr, "error: no output defined?\n");
    exit    (2);
  }
#endif

  /*
   * okay, now process the files
   */

  for (index=1, iskipflag=0; index<argc; index+=iskipflag+1) {
    iskipflag = 0;

    if (*argv[index] == '-' && argv[index][1] != '\0') {
      switch (argv[index][1]) {
      case 'm': /* skip parameters of options */
      case 'p':
      case 's':
      case 'i':
	if (index+1 < argc && argv[index+1][0] != '-')
	  index++;
	break;
      case 'o': /* may or may have not a parameter */
	if (argv[index][2]=='d' && index+1<argc && argv[index+1][0]!='-')
	  index++;
	break;
      default:  /* parameter without option */
	break;
      }
    }
    else /* this is a filename */ {
      if (uuencode) {
	/*
	 * we're in uuencode compatibility mode. This means the actual
	 * parameter is the file name on disk, the next parameter, if
	 * it exists and is not an option, is the name for the encoded
	 * file. If there is no next parameter, we shall read from stdin
	 * and use the given name as output filename
	 */
	if (index+1<argc && argv[index+1][0] != '-') {
	  strcpy (filename, argv[index]);
	  strcpy (usename,  argv[index+1]);
	  iskipflag = 1; /* ignore next argument */
	}
	else {
	  filename[0] = '\0';
	  strcpy (usename, argv[index]);
	}
      }
      else if (argv[index][0]=='-' && argv[index][1]=='\0') {
	/*
	 * supposed to read from stdin. we expect the next parameter to be
	 * the name to be used
	 */
	if (index+1<argc && argv[index+1][0] != '-') {
	  strcpy (usename, argv[index+1]);
	  filename[0] = '\0';
	  iskipflag = 1; /* ignore next argument */
	}
	else {
	  fprintf (stderr, "error: need additional name for file from standard input\n");
	  continue;
	}
      }
      else {
	strcpy (filename, argv[index]);
	strcpy (usename,  filename);
      }

      if (filename[0] == '\0') {
	if (stdinused) {
	  fprintf (stderr, "error: standard input used more than once\n");
	  continue;
	}
	stdinused++;

	if (((outflags[UUE_POSTTO] > 0) ? 1 : 0) +
	    ((outflags[UUE_MAILTO] > 0) ? 1 : 0) +
	    ((outflags[UUE_TOFILE] > 0) ? 1 : 0) > 1) {
	  fprintf (stderr, "error: can use standard input only once\n");
	  continue;
	}
      }
      else if ((testit = fopen (argv[index], "r")) == NULL) {
	fprintf (stderr, "error: '%s' unreadable.\n", argv[index]);
	continue;
      }
      else
	fclose (testit);

      fileflag = 0;

#ifndef SYSTEM_DOS
      /*
       * post it
       */

      if (outflags[UUE_POSTTO] > 0) {
	if (SendAFile ((filename[0])?NULL:stdin,
		       (filename[0])?filename:NULL,
		       encoding, linperfile, usename,
		       argv[outflags[UUE_POSTTO]],
		       (subject>0)?argv[subject]:NULL, 0) == UURET_OK)
	  fileflag++;
      }

      /*
       * mail it separately to each recepient
       */

      if (outflags[UUE_MAILTO] > 0) {
	if (SendAFile ((filename[0])?NULL:stdin,
		       (filename[0])?filename:NULL,
		       encoding, linperfile, usename,
		       argv[outflags[UUE_MAILTO]],
		       (subject>0)?argv[subject]:NULL, 1) == UURET_OK)
	  fileflag++;
      }
#endif

      /*
       * store output into a file
       */
      if (outflags[UUE_TOFILE] > 0 || outflags[UUE_TOFILE] == -42) {
	if (UUEncodeToFile ((filename[0])?NULL:stdin,
			    (filename[0])?filename:NULL,
			    encoding, usename,
			    usename, linperfile) == UURET_OK)
	  fileflag++;
      }

      /*
       * send it to stdout
       */
      if (tostdout) {
	if (UUEncodeToStream (stdout,
			      (filename[0])?NULL:stdin,
			      (filename[0])?filename:NULL,
			      encoding, usename, 0) == UURET_OK)
	  fileflag++;
      }

      if (fileflag > 0)
	count++;

    } /* end file processing */
  } /* end loop */

  if (UUISATTY(stderr)) {
    fprintf (stderr, "%70s\r", "");
    fflush  (stderr);
  }

  if (count==0) {
    fprintf (stderr, "error: no files.\n");
  }

  UUCleanUp ();

  return 0;
}


