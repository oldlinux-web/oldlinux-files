/*
 * Definitions for NNTP client routines.
 *
 * @(#)clientlib.h	1.1	(Berkeley) 1/9/88
 */

extern	char	*getserverbyfile();
extern	int	server_init();
extern	void	put_server();
extern	int	get_server();
extern	void	close_server();
