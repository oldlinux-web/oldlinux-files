#include "log.p"                
         
static char
    *lt[] =
    {
        "only errors",
        "warnings",
        "process monitoring",
        "heavy process monitoring",
    };

char *get_logtypestring()
{
    return (lt[log_type]);
}

