
#include "mem.p"

void *xmalloc(unsigned size)
{
    void
        *ret;

    if (!(ret = malloc(size)))
        error(out_of_memory);

    return (ret);
}
