
#include "config.p"

void checkconfig()
{
    if (logdefaults())                      /* are we logging defaults ? */
    {
	if (cb_mode == mode_callback)       /* if so, different for callback */
	    log                             /* and dial-in modes             */
	    (
		log_off,                    /* not severe, but asked for */
		"\n"
		"\tmode:                        callback\n"
		"\tthe default modem-ttyline:   %s\n"
		"\tauxiliary callback files in: %s\n"
		"\tlogfilename:                 %s\n"
		"\tdial-logfilename:            %s\n"
		"\tpanic logfilename:           %s\n"
		"\tlog type:                    %s\n"
		"\tmgetty configuration file:   %s\n"
		"\tlogin program:               %s\n"
		"\temail address:               %s\n"
		"\tnumber of callback retries:  %d\n"
		"\tmaximum callback time:       %d sec.\n"
		"\tusing 'cb %swho where' to call users.\n"
		"\t'cb list' %s show phonenumbers.\n"
		, get_ttyline(0)
		, base_path
 		, get_logfilename()
		, get_diallogfilename()
		, get_panicfilename()
                , get_logtypestring()
		, mgetty_path
		, login_program
		, email_address ? email_address : "not used"
		, ntries
                , get_maxage()
		, call ? "call " : ""
                , show_phonenumbers ? "will" : "won't"
	    );
	else
	    log
	    (
		log_off,
		"\n"
		"\tmode:                        dial-in\n"
		"\tthe default modem-ttyline:   %s\n"
		"\tauxiliary callback files in: %s\n"
		"\tlogfilename:                 %s\n"
		"\tpanic logfilename:           %s\n"
		"\tlog type:                    %s\n"
		"\tmgetty configuration file:   %s\n"
		"\temail address:               %s\n"
		, get_ttyline(0)
		, base_path
		, get_logfilename()
		, get_panicfilename()
                , get_logtypestring()
		, mgetty_path
		, email_address ? email_address : "not used"
	    );
    }

    if (!get_ttyline(0))
	error("default tty-line missing");
}
