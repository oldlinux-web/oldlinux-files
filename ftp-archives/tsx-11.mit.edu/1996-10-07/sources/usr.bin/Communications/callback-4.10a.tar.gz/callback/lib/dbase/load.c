
#include "dbase.p"

void load(THE_FILE_ENUM_ the_source)
{                                  
    char
        *line;

    while ((line = get_active_tty()))
    {
        assign_filenames(line);
        copyfile(filename[the_source], filename[the_activefile]);
        unlink(filename[the_statefile]);
        unlink(filename[the_disablefile]);
        log(log_on, "Line %s enabled: %s removed", line, 
                                         getfile(the_disablefile));
    }
    make_configfile();
}

