
#include "cblogin.h"

unsigned validate (char *username)
{
    unsigned
    	uid;

    if ((uid = lookuser(username)) > lastuser())
    {
	puts("No permission.");
	log(log_default, "Illegal attempt by '%s' to use callback", username);
        enable_state();                     /* reset to ok to dial-in */
	exit (1);
    }

                                            /* something must be showable */
    if (givedestinations() || givedirect() || giveextra())    
        printf("%s cleared for callback.\n"    
	"Please select a callback destination from the following list:\n", 
	username);

    return (uid);
}
