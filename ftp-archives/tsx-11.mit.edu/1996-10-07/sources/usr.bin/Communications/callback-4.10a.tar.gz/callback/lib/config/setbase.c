
#include "config.p"

void setbase(char *base)
{
    int
        len = strlen(base);
                                            /* extend basepath 2 chars */
    base_path = xrealloc(xstrdup(base), len + 2);
                                                        
                                            /* no / at the end ? */
    if (base_path[len - 1] != '/')
        strcat(base_path, "/");             /* then append it */
}