
#include "config.p"

void showextra()
{
    show_extra = 1;
}