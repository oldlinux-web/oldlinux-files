
#include "user.p"

void define_user(char *username)
{
    if (lookuser(username) < nusers)	/* username already defined ? */
    {
	log(log_off, "User %s multiply defined", username);
	parse_error();                  /* semantic error */
    }
    else
    {
	nusers++;			/* add a new user */

	user = xrealloc(user, nusers * sizeof(USER_));

						/* store the username */
	user[nusers - 1].name = xstrdup(username);
			
	user[nusers - 1].groups = NULL;		/* empty group */
	user[nusers - 1].ngroups = 0;

	init_dnames();
    }
}
