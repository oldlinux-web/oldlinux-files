
#include "dbase.p"

char *linename(char *name, char *line)
{
    char
	*ret;

					    /* base_path/name.line	    */
					    /*          ^    1    2	    */
					    /*          already in 'path'   */
    ret = xmalloc(strlen(getbase()) + strlen(name) + strlen (line) + 3);
    sprintf(ret, "%s%s.%s", getbase(), name, line);
    return (ret);
}
