
#include "config.p"

void setemailaddress(char *name)
{
    email_address = xstrdup(name);
}
