
char
    version[] = "4.10a",
    year[]    = "1993--1996";
    
