
#include "config.p"

char *getmodembase()
{
    return (modembase);
}
