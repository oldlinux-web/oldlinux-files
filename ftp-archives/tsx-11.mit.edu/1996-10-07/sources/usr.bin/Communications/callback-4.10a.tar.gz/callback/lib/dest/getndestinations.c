
#include "dest.p"

unsigned get_ndestinations()
{
    return (ndestinations);
}
