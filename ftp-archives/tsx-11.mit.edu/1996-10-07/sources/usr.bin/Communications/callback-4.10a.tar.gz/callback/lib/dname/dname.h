#ifndef _dname_H_
#define _dname_H_

int look_dname(char *dname);                /* -1: not found */
unsigned dname_index(char *dname);
void init_dnames();
char *get_dname(unsigned index);

#endif  _dname_H_
