
#include "config.p"

int givephonenumbers()
{
    return (show_phonenumbers);
}
