
#include "dbase.p"

void cpfile(FILE *inf, FILE *outf)
{
    register int
    	ch;
    unsigned
        insize = 0;

    while (1)
    {
    	ch = fgetc(inf);			/* read char */

    	if (feof(inf))				/* at EOF? */
    	    break;				/* yes.. done */

        insize++;

    	if (fputc(ch, outf) != ch)             /* no.. write to outfile */
            log(log_off, "File write '%c' (0x%x) failed\n", ch, ch);
    }

    if (!insize)
    	log(log_off, "Zero bytes in file to read");
}
