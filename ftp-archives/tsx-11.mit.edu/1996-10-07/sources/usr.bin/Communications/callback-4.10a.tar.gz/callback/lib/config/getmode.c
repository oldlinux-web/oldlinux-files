
#include "config.p"

CB_MODE_ getmode()
{
    return (cb_mode);
}
