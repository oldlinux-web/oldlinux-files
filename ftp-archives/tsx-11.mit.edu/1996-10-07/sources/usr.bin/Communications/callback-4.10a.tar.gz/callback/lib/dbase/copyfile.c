
#include "dbase.p"

void copyfile (char *in, char *out)
{
    FILE
    	*inf,
    	*outf;
    	
    inf = xfopen (in, "r");                     /* open IO files */
    outf = xfopen (out, "w");

    log(log_max, "copy %s to %s", in, out);

    cpfile(inf, outf);	                        /* copy the file */
    
    fclose (inf);				/* close IO files */
    fclose (outf);
}    
