
#include "cb.h"

void need_cbmode()
{
    if (getmode() != mode_callback)
        usage();
}
