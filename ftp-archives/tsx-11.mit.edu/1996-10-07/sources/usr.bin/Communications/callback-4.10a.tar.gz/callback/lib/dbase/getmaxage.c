
#include "dbase.p"

unsigned get_maxage()
{
    return (maxage);
}
