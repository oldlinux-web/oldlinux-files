
#include "dname.p"

void init_dnames()
{
    unsigned
	index;

    for (index = 0; index < ndnames; index++)
	dname_vector[index].usergroup = ndnames;
}
