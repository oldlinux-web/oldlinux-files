
#include "dbase.p"
#include "../../configure.h"

unsigned
    maxage = MAXAGE;
char
    *filename[sizeof_the_file_enum];
    

