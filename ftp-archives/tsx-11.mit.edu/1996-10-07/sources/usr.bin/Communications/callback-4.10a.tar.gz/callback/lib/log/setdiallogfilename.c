
#include "log.p" 

void setdiallogfilename(char *name)
{
    diallog_filename = xstrdup(name);
}
