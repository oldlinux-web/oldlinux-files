
#include "dgroup.p"

char
    **dgroupvector;
unsigned
    ndgroupnames;

