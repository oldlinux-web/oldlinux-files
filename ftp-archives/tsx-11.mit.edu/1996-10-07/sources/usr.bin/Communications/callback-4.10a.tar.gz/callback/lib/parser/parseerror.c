
#include "parser.p"

void parse_error()
{
    parse_errors++;
}
