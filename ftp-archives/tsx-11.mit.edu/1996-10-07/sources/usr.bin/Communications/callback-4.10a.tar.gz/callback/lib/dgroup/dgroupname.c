
#include "dgroup.p"

char *dgroupname(unsigned index)
{
    return (dgroupvector[index]);
}