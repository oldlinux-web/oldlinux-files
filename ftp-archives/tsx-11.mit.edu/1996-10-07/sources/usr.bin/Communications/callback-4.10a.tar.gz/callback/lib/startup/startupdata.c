
#include "startup.p"

char
    *progname;
    
