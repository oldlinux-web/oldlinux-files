#include "dbase.p"

char *nologin(char *line)
{
    char
	*ret;

					    /* base_path/name.line	    */
					    /*          ^    1    2	    */
					    /*          already in 'path'   */
    ret = xmalloc(strlen(NOLOGIN_FILE) + strlen (line));
    sprintf(ret, NOLOGIN_FILE, line);
    return (ret);
}
