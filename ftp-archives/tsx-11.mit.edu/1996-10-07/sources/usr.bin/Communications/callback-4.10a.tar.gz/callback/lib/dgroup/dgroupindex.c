
#include "dgroup.p"

unsigned dgroup_index(char *dgroup)
{
    unsigned
	index;

    for (index = 0; index < ndgroupnames; index++)  /* look for the group */
    {
	if (!strcmp(dgroupvector[index], dgroup))	/* group found */
	    return (index);		    /* ok */
    }
    ndgroupnames++;                         /* new dgroupname */
    dgroupvector = xrealloc(dgroupvector, ndgroupnames * sizeof(char *));
    dgroupvector[index] = xstrdup(dgroup);    /* fill in the new dgroupname */  
    return (index);
}
