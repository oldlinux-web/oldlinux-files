
#include "ttyline.p"

void reset_active_tty()
{
    active_index =    
        active_line == -1 ?         /* all lines are used ? */    
            0                       /* then use index 0 next time */    
        :    
            active_line;            /* or use the active line */    
}