
#include "dbase.p"

void make_filenames(char *line)
{    
    int
        index;

    if ((index = lookup_tty(line)) < 0)
    {
        log(log_off, "Invalid tty line '%s' received", line);
        exit (1);
    }

    assign_filenames(line);
}
