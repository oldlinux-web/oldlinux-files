#ifndef _dbase_H_
#define _dbase_H_

#include <stdio.h>

typedef enum
{
    the_statefile,
    the_enablefile,
    the_callbackfile,
    the_disablefile,
    the_activefile,
    the_modemfile,
    sizeof_the_file_enum,
} THE_FILE_ENUM_;

FILE *xfopen(char *name, char *mode);
int getstate(int *state, unsigned *userid); /* -2: expiry, force enable     */
                                            /* -1: no state file, waiting   */
                                            /*  0: states exhaused  */
                                            /* >0: retry            */
unsigned get_maxage();
void set_maxage(char *max);
void make_filenames(char *ttyline);
char *modemfile();
void update_cbstate(char *line);
void enable_state();
void make_configfile();
void setcallback(int uid, int dest);
void load(THE_FILE_ENUM_ the_source);
char *getfile(THE_FILE_ENUM_ ftype);
void active_files();
void states();
void assign_filenames(char *line);

#endif  _dbase_H_
