
#include "user.p"

unsigned
    nusers;
USER_				/* array of users */
    *user;
