

#include "dest.p"

void set_file(char *filename)
{					    /* set the destinationfile */
    destination[ndestinations - 1].filename = xstrdup(filename);
}
