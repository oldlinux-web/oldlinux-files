
#include "cb.h"

void list()
{
    char
        *who = gargv[2];

    register int
    	uid;
        
    need_cbmode();

    showdestinations();
    showextra();
    showdirect();

    if (who)
    {
	if ((uid = lookuser(who)) <= lastuser())  /* specific user requested */
	    listdestinations(uid, givephonenumbers());
	else
	    error("No info about %s", who);
    }
    else
    {
	printf
	(
	    "\n"
	    "Default tty-line:\n"
	    "-----------------\n"
	    "%s\n"
	    "\n"
	    "Callback users:\n"
	    "---------------\n",
	    get_ttyline(0)
	);

	for (uid = 0; uid <= lastuser(); uid++)
	    listdestinations(uid, 1);		/* list the destinations */
    }

    putchar('\n');
}
