
#include "config.p"

void showphonenumbers()
{
    show_phonenumbers = 1;
}