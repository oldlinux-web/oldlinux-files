
#include "dest.p"

void tag_dnames()
{
    unsigned
	groupindex;		/* last parsed group of a user */
    int
	dindex;			/* index along the destinations */

				/* the group-index of the group added last */
    groupindex = lastuser_groupindex();

				/* walk all destinations */
    for (dindex = 0; dindex < ndestinations; dindex++)	
    {
                                /* a possible user destination */
	if (destination[dindex].dgroup == groupindex)
            check_dname(destination[dindex].dname,  /* index of the name */
                        groupindex);                /* index of the group */
    }
}
      
