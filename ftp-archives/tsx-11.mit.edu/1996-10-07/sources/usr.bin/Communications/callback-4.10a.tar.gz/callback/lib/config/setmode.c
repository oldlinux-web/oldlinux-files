
#include "config.p"

void setmode(CB_MODE_ type)
{
    cb_mode = type;
}

