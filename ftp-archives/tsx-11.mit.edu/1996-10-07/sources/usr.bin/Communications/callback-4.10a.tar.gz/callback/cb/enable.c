
#include "cb.h"

void enable()
{
    load(the_enablefile);
}
