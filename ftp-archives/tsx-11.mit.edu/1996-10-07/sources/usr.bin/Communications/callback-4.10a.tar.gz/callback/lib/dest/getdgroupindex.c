
#include "dest.p"

unsigned get_dgroupindex(unsigned destindex)
{
    return (destination[destindex].dgroup);
}
