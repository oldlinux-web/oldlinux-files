
#include "dbase.p"

char *getfile(THE_FILE_ENUM_ ftype)
{
    return (filename[ftype]);
}
