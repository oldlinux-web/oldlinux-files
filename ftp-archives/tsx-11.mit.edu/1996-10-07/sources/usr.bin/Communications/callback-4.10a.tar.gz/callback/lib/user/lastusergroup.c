#include "user.p"

int lastusergroup(int gi)
{
    USER_
	*up;
    unsigned
	idx;

    up = &user[nusers - 1];                 /* points to last user */

    for (idx = 0; idx < up->ngroups; idx++)
    {
	if (up->groups[idx] == gi)	    /* group already exists ? */
	    return (0);			    /* then done */
    }
					    /* store the new group-index */
    up->groups = xrealloc(up->groups, (++up->ngroups) * sizeof(unsigned));
    up->groups[idx] = gi;		    /* store the new groupindex */

    return (1);				    /* its's a new group */
}
