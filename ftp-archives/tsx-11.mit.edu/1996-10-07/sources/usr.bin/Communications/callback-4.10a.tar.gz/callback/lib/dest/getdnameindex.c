
#include "dest.p"

unsigned get_dnameindex(unsigned destindex)
{
    return (destination[destindex].dname);
}
