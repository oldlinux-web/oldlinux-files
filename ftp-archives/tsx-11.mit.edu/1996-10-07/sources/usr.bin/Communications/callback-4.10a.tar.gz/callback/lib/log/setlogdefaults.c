
#include "log.p"

void set_logdefaults()
{
    log_defaults = 1;
}