
#include "dest.p"

void define_dest(char *groupname)
{
    ndestinations++;			/* add a new destination */
    destination = xrealloc(destination, ndestinations * sizeof(DESTINATION_));

					/* clear the destination-struct */
    memset(destination + ndestinations - 1, 0, sizeof(DESTINATION_));

					/* store the destname-index */
    destination[ndestinations - 1].dgroup = dgroup_index(groupname);
}
