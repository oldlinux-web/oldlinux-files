
#include "dbase.p"

int getstate(int *state, unsigned *userid)
{
    register FILE
    	*inf;
    int
        x;

    *state = -1;                        /* assume no statefile */

    if ((inf = fopen(filename[the_statefile], "r")))
    {
        if ((x = fscanf(inf, "%d %d", state, userid)) != 2)
       	    log(log_off, "invalid state file \"%s\": %d items read, "
	                 "state: %d, username: %s", 
                         filename[the_statefile], x, *state, username(*userid));
        fclose (inf);

	if (x != 2 || ageof(filename[the_activefile]) > maxage)
            *state = -2;                    /* force enable: too old/invalid */
    }

    return (*state);                        /* return the state */
                                            /* -2: expiry, force enable     */
                                            /* -1: no state file, waiting   */
                                            /*  0: states exhaused  */
                                            /* >0: retry state      */
}
