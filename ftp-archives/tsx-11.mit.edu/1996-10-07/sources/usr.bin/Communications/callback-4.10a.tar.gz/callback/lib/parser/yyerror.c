
#include "parser.p" 

int yyerror(char *s)
{
    parse_errors++;
    printf("Line %d at %s: %s expected\n", yylineno, yytext, expect);
    expect = "??";
    return (0);
}
