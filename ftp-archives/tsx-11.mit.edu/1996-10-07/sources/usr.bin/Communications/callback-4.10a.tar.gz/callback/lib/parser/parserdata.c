
#include "parser.p"

unsigned
    parse_errors = 0;
char
    *expect;
