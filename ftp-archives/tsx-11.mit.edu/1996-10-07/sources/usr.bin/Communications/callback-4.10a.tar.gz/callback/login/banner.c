
#include "cblogin.h"

void banner()
{
    printf ("\n"
    	    "ICCE %s Callback Login Facility  V %s\n"
    	    "Copyright (c) ICCE %s. All rights reserved.\n"
    	    "\n",
	    getprogname(), 
	    version,
	    year);
}
