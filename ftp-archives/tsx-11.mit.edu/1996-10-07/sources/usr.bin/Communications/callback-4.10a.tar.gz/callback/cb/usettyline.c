
#include "cb.h"

void use_ttyline(char *request)
{
    if (!request)			    /* nothing requested */
        log(log_on, "Requesting default ttyline '%s'", get_ttyline(0));

    else if (!strcmp(request, "+"))	    /* all requested ? */
    {
        log(log_on, "Requesting all ttylines");
	activate_ttylines();		    /* acticate all lines */
    }   
                                            /* check validity of the line */
    else if (!activate_ttyline(lookup_tty(request)))
        log(log_on, "Requesting ttyline '%s'", request);
}
