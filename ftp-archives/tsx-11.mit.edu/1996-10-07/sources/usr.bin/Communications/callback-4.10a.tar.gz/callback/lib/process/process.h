#ifndef _process_H_
#define _process_H_
                        
void modem_respawn();
void killinit();

#endif  _process_H_
