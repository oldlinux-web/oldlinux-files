
#include "log.p"

void setlogfilename(char *name)
{
    log_filename = xstrdup(name);
}
