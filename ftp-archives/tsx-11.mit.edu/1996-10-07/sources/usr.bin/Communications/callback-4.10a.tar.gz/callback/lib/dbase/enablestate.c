
#include "dbase.p"

void enable_state()
{
    unlink(filename[the_statefile]);
    unlink(filename[the_disablefile]);
    copyfile(filename[the_enablefile], filename[the_activefile]);
    make_configfile();
}
