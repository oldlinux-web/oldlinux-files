
#include "config.p"

int getcall()
{
    return (call);
}
