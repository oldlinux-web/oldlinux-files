
#include "config.p"

void hidedestinations()
{
    show_destinations = 0;
}