
#include "dest.p"

void ask_extra_number(unsigned uid, unsigned dest)
{
    char
	buf[30];

    printf("What's the number to call %s ? ",	/* read in phone number */
			username(uid));    

    if (!getbuf(buf, 30))			/* nothing entered ? */
	error("No number entered: %s not called.", username(uid));

    set_phonenr(dest, buf);                     /* ok: set new phone number */
}
