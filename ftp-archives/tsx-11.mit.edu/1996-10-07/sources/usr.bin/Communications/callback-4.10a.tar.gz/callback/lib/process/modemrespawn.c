
#include "process.p"
#include "../../configure.h"

void modem_respawn()
{
    FILE
    	*pslist;
    char    
    	buf[500];
    int
	kills;

    if (!(pslist = popen(PSCMD, "r")))
    	error("Can't get processes list");
               
    kills = 0;                                  /* no process killed yet */

    log(log_max, "Looking for %s-processes", getmodembase());

    while (fgets(buf, 499, pslist))             /* walk all processes */
        kills += modemkill(buf);                /* kill if a modem process */

    if (!kills)
	log(log_on, "No modem process(es) killed");

    pclose(pslist);
}
