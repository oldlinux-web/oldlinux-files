
#include "cb.h"

TASK_
    taskarr[] =
    { 
        {
            "enable",
            enable,
        },
        {
            "disable",
            disable,
        },
        {
            "file",
            active_files,
        },
        {
            "init",
            killinit,
        },                      /* index >= 4: only callback modes */
        {
            "state",
            state,
        },
        {
            "list",
            list,
        },
        {
            NULL,
            maybe_force,
        },
    };

unsigned      
    sizeof_taskarr = sizeof(taskarr) / sizeof(TASK_),
    argv1len,
    log_request;
int
    gargc;
char
    **gargv;

