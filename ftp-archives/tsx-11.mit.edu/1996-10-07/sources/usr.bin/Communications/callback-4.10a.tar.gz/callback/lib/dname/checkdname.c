
#include "dname.p"                       

void check_dname(unsigned dnameindex, unsigned groupindex) 
{
                                /* name not yet used ? */
    if (dname_vector[dnameindex].usergroup == ndnames) 
        dname_vector[dnameindex].usergroup = groupindex;       /* grab it */

    else if (dname_vector[dnameindex].usergroup != groupindex) /* not this group  ? */
    {                                                         /* then error */
        log
	(
	    log_off,
	    "User %s: ambiguous dname %s: groups %s and %s",
            username(lastuser()),
            dname_vector[dnameindex].name,
	    dgroupname(groupindex),
            dgroupname(dname_vector[dnameindex].usergroup)
	);
	parse_error();
    }
}
