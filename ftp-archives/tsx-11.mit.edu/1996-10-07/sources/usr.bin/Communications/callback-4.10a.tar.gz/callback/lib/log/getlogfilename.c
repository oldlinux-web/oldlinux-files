
#include "log.p"

char *get_logfilename()
{
    return (log_filename);
}
