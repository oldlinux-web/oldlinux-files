    
#include "dbase.p"

void assign_filenames(char *line)
{
    filename[the_enablefile]    = linename("enable", line);
    filename[the_callbackfile]  = linename("callback", line);
    filename[the_statefile]     = linename("state", line);
    filename[the_disablefile]   = nologin(line);
    filename[the_activefile]    = linename("active", line);
    filename[the_modemfile]     = append_line(getmodembase(), line);
}

    
