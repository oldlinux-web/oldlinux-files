
#include "ttyline.p"

int activate_ttyline(unsigned index)
{
    if (index >= n_lines)
        return (1);
        
    active_line = index;
    return (0);
}