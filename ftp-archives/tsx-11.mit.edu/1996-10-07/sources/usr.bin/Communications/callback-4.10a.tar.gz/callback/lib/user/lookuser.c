
#include "user.p"

unsigned lookuser(char *name)
{
    int
	index;

    for (index = 0; index < nusers; index++)
    {
	if (!strcmp(name, user[index].name))	/* names match ? */
	    return (index);			/* then return its index */
    }
    return (index);				/* user not found */
}
