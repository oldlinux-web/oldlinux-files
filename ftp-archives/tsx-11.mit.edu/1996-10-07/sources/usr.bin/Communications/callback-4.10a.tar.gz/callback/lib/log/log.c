
#include "log.p"

void log(LOG_TYPE_ minimum, char *fmt, ...)	/* local log function, */
{
    va_list
    	args;

    if (log_type < minimum)
	return;				/* no logging unless minimum passed */

    va_start (args, fmt);
    logv(fmt, args);			/* log message. to panicfile if no */
					/* logfile */
}
    
