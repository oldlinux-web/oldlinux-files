
#include "config.p"

int giveextra()
{
    return (show_extra);
}
