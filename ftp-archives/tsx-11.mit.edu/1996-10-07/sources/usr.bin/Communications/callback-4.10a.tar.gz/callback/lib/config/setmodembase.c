
#include "config.p"

void setmodembase(char *base)
{
    modembase = xstrdup(base);
}

