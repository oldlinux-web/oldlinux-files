
#include "parser.p" 

void yysemantic(char *s)
{
    parse_errors++;
    printf("Line %d at %s: %s\n", yylineno, yytext, s);
}
