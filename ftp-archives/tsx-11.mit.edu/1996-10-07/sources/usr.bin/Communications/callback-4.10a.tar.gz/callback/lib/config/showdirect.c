
#include "config.p"

void showdirect()
{
    show_direct = 1;
}