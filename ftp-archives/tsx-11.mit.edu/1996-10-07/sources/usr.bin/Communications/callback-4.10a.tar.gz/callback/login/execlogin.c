
#include "cblogin.h"

static char
    *login_argv[3] =
    {
	NULL,
	NULL,
	NULL,
    };

void exec_login(int uid)
{
    log(log_on, "starting exec_login()");

    enable_state();			/* load the enable-file. */

    login_argv[0] = getlogin();
    login_argv[1] = username(uid);      /* set the username */

    log(log_on, "Executing '%s' for '%s'", getlogin(), login_argv[1]);

    execv(getlogin(), login_argv);	/* continue execution with login */
    	
    error("Can't exec %s", getlogin());	/* should never get here */
}
