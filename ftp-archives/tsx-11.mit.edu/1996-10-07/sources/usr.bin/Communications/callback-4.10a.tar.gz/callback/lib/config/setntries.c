
#include "config.p"

void setntries(char *nr)
{
    ntries = atoi(nr);
}
