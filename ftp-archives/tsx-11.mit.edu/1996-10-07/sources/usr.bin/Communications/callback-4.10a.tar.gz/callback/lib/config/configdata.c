
#include "config.p"
#include "../../configure.h"

CB_MODE_
    cb_mode;
unsigned       
    call,
    ntries = NTRIES,
    show_phonenumbers,
    show_destinations = 1,
    show_extra,
    show_direct;

char        
    *modembase = MODEMPROCESS,
    *email_address = EMAIL_ADDRESS,
    *login_program = LOGIN_PROGRAM,
    *mgetty_path = MGETTY_PATH,
    *base_path = BASE_PATH;