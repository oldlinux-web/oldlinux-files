
#include "config.p"

char *getlogin()
{
    return (login_program);
}