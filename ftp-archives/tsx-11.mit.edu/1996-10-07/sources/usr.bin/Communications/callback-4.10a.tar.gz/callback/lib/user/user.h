#ifndef _user_H_
#define _user_H_

#include "../log/log.h"

void define_user(char *username);
int lastusergroup(int gi);
unsigned lastuser_groupindex();
char *username(unsigned index);
unsigned lastuser();
unsigned user_ngroups(unsigned uid);
unsigned usergroup(unsigned uid, unsigned gindex);
unsigned lookuser(char *username);
int combine(int uid, char *where);


#endif  _user_H_
