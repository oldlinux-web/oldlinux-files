#include "user.p"

unsigned lastuser_groupindex()
{
    return
    (
        user[nusers - 1].groups[user[nusers - 1].ngroups - 1]
    );
}

