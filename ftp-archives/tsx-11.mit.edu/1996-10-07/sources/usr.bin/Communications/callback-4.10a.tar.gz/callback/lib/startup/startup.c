
#include "startup.p"

void startup(int argc, char **argv)
{
    setprogname(argv[0]);                   /* determine the programname */

    parse_setupfile();			    /* parse the setupfile,
                                               may exit
					     */
}
