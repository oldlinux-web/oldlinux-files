
#include "dbase.p"

void set_maxage(char *max)
{
    maxage = atoi(max);
}
