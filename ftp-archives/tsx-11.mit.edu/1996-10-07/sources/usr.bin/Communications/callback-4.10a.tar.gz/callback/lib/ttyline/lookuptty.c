
#include "ttyline.p"

int lookup_tty(char *line)
{
    int
        index;
    char
        buffer[10];

    if (!line)
        return (-1);

    if (isdigit(*line))                     /* digit requested */
    {
        sprintf(buffer, "ttyS%s", line);    /* make it a ttyS line */
        line = buffer;
    }
    
    for (index = n_lines; index--; )        /* walk all lines */
    {
        if (!strcmp(ttyline[index], line)) /* match found ? */
            break;                          /* then break the loop */
    }
    
    return (index);                         /* return the index */
}
