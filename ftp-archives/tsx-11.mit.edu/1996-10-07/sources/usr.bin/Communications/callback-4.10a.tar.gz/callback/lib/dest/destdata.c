
#include "dest.p"

unsigned
    ndestinations;

DESTINATION_			/* array of destinations */
    *destination;

