
#include "ttyline.p"

void activate_ttylines()
{
    active_line = -1;           /* -1 indicates all lines active */
    active_index = 0;
}