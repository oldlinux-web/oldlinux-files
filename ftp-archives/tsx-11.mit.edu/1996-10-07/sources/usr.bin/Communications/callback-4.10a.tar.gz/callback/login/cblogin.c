
#include "cblogin.h"

int main(int argc, char **argv)
{
    startup(argc, argv);                /* start up, read setup file */

    log(log_default, "'%s %s' started", getprogname(), argv[1]);

    banner();				/* print banner of this program */

    determine_tty();                    /* determine the tty-name from  */
                                        /* stdin                        */

    login(argv[1]);                     /* and do the login */
    
    return (0);                         /* won't get here when the login  */
                                        /* program is execed from login() */
}
