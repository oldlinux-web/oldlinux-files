#ifndef _dgroup_H_
#define _dgroup_H_

#include "../mem/mem.h"
#include "../log/log.h"

unsigned dgroup_index(char *groupname);
void addgroup(char *group);
char *dgroupname(unsigned index);


#endif  _dgroup_H_
