/* conf.h */
/* Set MAIL_PROGRAM to a program which takes a user name as an argument and accepts a mail message to send to that user on stdin. */
#define MAIL_PROGRAM "rmail"
/* Set ECHO_PROGRAM to a program which echoes its arguments; if echo is a shell builtin you can just use "echo". */
#define ECHO_PROGRAM "echo"
/* Set PWD_PROGRAM to a program which prints the name of the current working directory; this is used only on old systems. */
#define PWD_PROGRAM "pwd"
/* Set HAVE_STRING_H to 1 if you have <string.h>. */
#define HAVE_STRING_H 1
/* Set HAVE_STRINGS_H to 1 if you have <strings.h>. */
#define HAVE_STRINGS_H 0
/* Set HAVE_UNISTD_H to 1 if you have <unistd.h>. */
#define HAVE_UNISTD_H 1
/* Set HAVE_STDLIB_H to 1 if you have <stdlib.h>. */
#define HAVE_STDLIB_H 1
/* Set HAVE_LIMITS_H to 1 if you have <limits.h>. */
#define HAVE_LIMITS_H 1
/* Set HAVE_TIME_H to 1 if you have <time.h>. */
#define HAVE_TIME_H 1
/* Set HAVE_SYS_WAIT_H to 1 if you have <sys/wait.h>. */
#define HAVE_SYS_WAIT_H 0
/* Set HAVE_SYS_IOCTL_H to 1 if you have <sys/ioctl.h>. */
#define HAVE_SYS_IOCTL_H 0
/* Set HAVE_DIRENT_H to 1 if you have <dirent.h>. */
#define HAVE_DIRENT_H 1
/* Set HAVE_MEMORY_H to 1 if you have <memory.h>. */
#define HAVE_MEMORY_H 0
/* Set HAVE_SYS_PARAM_H to 1 if you have <sys/param.h>. */
#define HAVE_SYS_PARAM_H 1
/* Set HAVE_UTIME_H to 1 if you have <utime.h>. */
#define HAVE_UTIME_H 1
/* Set HAVE_FCNTL_H to 1 if you have <fcntl.h>. */
#define HAVE_FCNTL_H 1
/* Set HAVE_SYS_FILE_H to 1 if you have <sys/file.h>. */
#define HAVE_SYS_FILE_H 1
/* Set HAVE_LIBC_H to 1 if you have <libc.h>. */
#define HAVE_LIBC_H 0
/* Set HAVE_SYSEXITS_H to 1 if you have <sysexits.h>. */
#define HAVE_SYSEXITS_H 0
/* Set SIGtype to the return type of signal handlers. */
#define SIGtype void
/* Define HAVE_TIME_T if time_t is defined in <time.h>. */
#define HAVE_TIME_T 1
/* Set HAVE_SYS_TIME_T to 1 if time_t is defined in <sys/types.h>. */
#define HAVE_SYS_TIME_T 1
/* Set HAVE_SYS_TIME_AND_TIME_H to 1 if <time.h> and <sys/time.h> can both be included in a single source file. */
#define HAVE_SYS_TIME_AND_TIME_H 1
/* Set HAVE_TERMIOS_AND_SYS_IOCTL_H to 1 if <termios.h> and <sys/ioctl.h> can both be included in a single source file. */
#define HAVE_TERMIOS_AND_SYS_IOCTL_H 0
/* HAVE_CBREAK is just used if you don't set one of the terminal driver options in policy.h. */
#define HAVE_CBREAK 0
/* If pid_t is not defined in <sys/types.h>, give it a definition here. */
/* If uid_t is not defined in <sys/types.h>, give it a definition here. */
/* If gid_t is not defined in <sys/types.h>, give it a definition here. */
/* If off_t is not defined in <sys/types.h>, give it a definition here. */
/* Set HAVE_SIG_ATOMIC_T_IN_SIGNAL_H if sig_atomic_t is defined in <signal.h> as required by ANSI C. */
#define HAVE_SIG_ATOMIC_T_IN_SIGNAL_H 1
/* Set HAVE_SIG_ATOMIC_T_IN_TYPES_H if sig_atomic_t is defined in <sys/types.h>. */
#define HAVE_SIG_ATOMIC_T_IN_TYPES_H 0
/* If sig_atomic_t is not defined in <signal.h> or <sys/types.h>, you can give it a definition here. */
/* Define one of the following:
	FS_STATVFS for statvfs
	FS_USG_STATFS for the four argument statfs
	FS_MNTENT for the two argument statfs with 1K blocks and no f_fsize field
	FS_GETMNT for statfs with fd_req field
	FS_STATFS for statfs with f_fsize field
	FS_USTAT for ustat with 512 byte blocks. */
#define FS_USTAT
/* Set HAVE_VOID to 1 if the compiler supports the type void. */
#define HAVE_VOID 1
/* Set HAVE_UNSIGNED_CHAR to 1 if the compiler supports the type unsigned char. */
#define HAVE_UNSIGNED_CHAR 1
/* Set HAVE_ERRNO_DECLARATION to 1 if errno is declared in <errno.h>. */
#define HAVE_ERRNO_DECLARATION 1
/* Set COMBINED_UNBLOCK to 1 if O_NONBLOCK and O_NDELAY can both be specified at once on a file descriptor. */
#define COMBINED_UNBLOCK 1
/* Set HAVE_VFPRINTF to 1 if you have vfprintf. */
#define HAVE_VFPRINTF 1
/* Set HAVE_REMOVE to 1 if you have remove. */
#define HAVE_REMOVE 0
/* Set HAVE_STRDUP to 1 if you have strdup. */
#define HAVE_STRDUP 0
/* Set HAVE_STRSTR to 1 if you have strstr. */
#define HAVE_STRSTR 0
/* Set HAVE_STRCASECMP to 1 if you have strcasecmp. */
#define HAVE_STRCASECMP 0
/* Set HAVE_STRICMP to 1 if you have stricmp. */
#define HAVE_STRICMP 0
/* Set HAVE_STRLWR to 1 if you have strlwr. */
#define HAVE_STRLWR 0
/* Set HAVE_STRERROR to 1 if you have strerror. */
#define HAVE_STRERROR 1
/* Set HAVE_MEMSET to 1 if you have memset. */
#define HAVE_MEMSET 1
/* Set HAVE_MEMCMP to 1 if you have memcmp. */
#define HAVE_MEMCMP 1
/* Set HAVE_MEMCHR to 1 if you have memchr. */
#define HAVE_MEMCHR 1
/* Set HAVE_MEMCPY to 1 if you have memcpy. */
#define HAVE_MEMCPY 1
/* Set HAVE_MEMMOVE to 1 if you have memmove. */
#define HAVE_MEMMOVE 1
/* Set HAVE_BCOPY to 1 if you have bcopy. */
#define HAVE_BCOPY 0
/* Set HAVE_BCMP to 1 if you have bcmp. */
#define HAVE_BCMP 0
/* Set HAVE_BZERO to 1 if you have bzero. */
#define HAVE_BZERO 0
/* Set HAVE_STRCHR to 1 if you have strchr. */
#define HAVE_STRCHR 1
/* Set HAVE_STRRCHR to 1 if you have strrchr. */
#define HAVE_STRRCHR 1
/* Set HAVE_INDEX to 1 if you have index. */
#define HAVE_INDEX 0
/* Set HAVE_RINDEX to 1 if you have rindex. */
#define HAVE_RINDEX 0
/* Set HAVE_STRTOL to 1 if you have strtol. */
#define HAVE_STRTOL 1
/* Set HAVE_BSEARCH to 1 if you have bsearch. */
#define HAVE_BSEARCH 1
/* Set HAVE_GETGRENT to 1 if you have getgrent. */
#define HAVE_GETGRENT 1
/* Set HAVE_GETHOSTNAME to 1 if you have gethostname. */
#define HAVE_GETHOSTNAME 1
/* Set HAVE_UNAME to 1 if you have uname. */
#define HAVE_UNAME 1
/* Set HAVE_NAPMS to 1 if you have napms. */
#define HAVE_NAPMS 0
/* Set HAVE_NAP to 1 if you have nap. */
#define HAVE_NAP 0
/* Set HAVE_USLEEP to 1 if you have usleep. */
#define HAVE_USLEEP 0
/* Set HAVE_POLL to 1 if you have poll. */
#define HAVE_POLL 0
/* Set HAVE_SELECT to 1 if you have select. */
#define HAVE_SELECT 1
/* Set HAVE_SIGSETJMP to 1 if you have sigsetjmp. */
#define HAVE_SIGSETJMP 0
/* Set HAVE_SETRET to 1 if you have setret. */
#define HAVE_SETRET 0
/* Set HAVE_GETCWD to 1 if you have getcwd. */
#define HAVE_GETCWD 1
/* Set HAVE_GETWD to 1 if you have getwd. */
#define HAVE_GETWD 0
/* Set HAVE_WAITPID to 1 if you have waitpid. */
#define HAVE_WAITPID 1
/* Set HAVE_WAIT4 to 1 if you have wait4. */
#define HAVE_WAIT4 0
/* Set HAVE_SOCKET to 1 if you have socket. */
#define HAVE_SOCKET 0
/* Set HAVE_GETDTABLESIZE to 1 if you have getdtablesize. */
#define HAVE_GETDTABLESIZE 0
/* Set HAVE_SYSCONF to 1 if you have sysconf. */
#define HAVE_SYSCONF 1
/* Set HAVE_SETSID to 1 if you have setsid. */
#define HAVE_SETSID 1
/* Set HAVE_SETPGRP to 1 if you have setpgrp. */
#define HAVE_SETPGRP 1
/* Set HAVE_SIGACTION to 1 if you have sigaction. */
#define HAVE_SIGACTION 1
/* Set HAVE_SIGVEC to 1 if you have sigvec. */
#define HAVE_SIGVEC 0
/* Set HAVE_SIGSET to 1 if you have sigset. */
#define HAVE_SIGSET 0
/* Set HAVE_SIGHOLD to 1 if you have sighold. */
#define HAVE_SIGHOLD 0
/* Set HAVE_SIGPROCMASK to 1 if you have sigprocmask. */
#define HAVE_SIGPROCMASK 1
/* Set HAVE_SIGBLOCK to 1 if you have sigblock. */
#define HAVE_SIGBLOCK 0
/* Set HAVE_FTRUNCATE to 1 if you have ftruncate. */
#define HAVE_FTRUNCATE 0
/* Set HAVE_LTRUNC to 1 if you have ltrunc. */
#define HAVE_LTRUNC 0
/* Set HAVE_RENAME to 1 if you have rename. */
#define HAVE_RENAME 1
/* Set HAVE_OPENDIR to 1 if you have opendir. */
#define HAVE_OPENDIR 1
/* Set HAVE_DUP2 to 1 if you have dup2. */
#define HAVE_DUP2 1
/* Set HAVE_GETTIMEOFDAY to 1 if you have gettimeofday. */
#define HAVE_GETTIMEOFDAY 1
/* Set HAVE_FTIME to 1 if you have ftime. */
#define HAVE_FTIME 0
/* Set HAVE_TIMES to 1 if you have times. */
#define HAVE_TIMES 1
/* Set TIMES_DECLARATION_OK to 1 if times can be safely declared as returning long. */
#define TIMES_DECLARATION_OK 1
/* Set HAVE_BSD_PGRP to 1 if you can compile getpgrp with 1 argument and setpgrp with 2 arguments rather than none. */
#define HAVE_BSD_PGRP 0
/* Set HAVE_MKDIR to 1 if you have mkdir. If you don't have it, set MKDIR_PROGRAM to the name of the program which will create a directory named on the command line. */
#define HAVE_MKDIR 1
/* Set HAVE_UNION_WAIT to 1 if union wait is defined in <sys/wait.h>. */
#define HAVE_UNION_WAIT 0
/* Define UTIME_NULL_MISSING if utime with a NULL second argument does not set the file times to the current time. */
/* Set HAVE_LONG_NAMES to 1 if the system supports long file names. */
#define HAVE_LONG_NAMES 0
/* Set HAVE_RESTARTABLE_SYSCALLS to 1 if system calls are restarted after interrupts (this is ignored if HAVE_SIGACTION is 1). */
#define HAVE_RESTARTABLE_SYSCALLS 1
