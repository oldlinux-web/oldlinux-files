#include <stdio.h>
#include <pwd.h>
#include <string.h>
main()
{
   struct passwd *getpwent();
   struct passwd *pwd;

   while(NULL != (pwd=getpwent()))
   {
      if(strchr(pwd->pw_gecos, ',') != NULL) *(strchr(pwd->pw_gecos, ',')) = 0;
      printf("%s\t%s\n", pwd->pw_gecos, pwd->pw_name);
   }
}
