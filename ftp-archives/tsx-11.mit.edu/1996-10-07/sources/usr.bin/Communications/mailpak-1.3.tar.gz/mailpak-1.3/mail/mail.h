#ifdef NULL
#undef NULL
#define NULL (0)
#endif

#define MAILDIR		"/usr/spool/mail/" /* default mail directory */
#define MAILCFG         "/.mailrc"
#define DEFPATHS        "/usr/lib/uucp/paths" /* pathalias file */
#define ALTPATHS        "/usr/lib/uucp/alt.paths" /* alternate pathalias file */
#define equal		!strcmp
#define equaln		!strncmp
#define	isdaemon(s)	(sindex(s, "uucp") != -1)
#define	SHOW(n)		((n)+1)
#define	ismail(n)	((n) >= 0 && (n) < nlet)

#define	EX_UNIQ	01	/* expand() requires single token in expansion */
#define	EX_ANY	02	/* expand() allows multiple tokens in expansion */

#define	SAME	0
#define	TRUE	1
#define	FALSE	0

#define CERROR		-1
#define CSUCCESS	0

#define A_OK		0		/* return value for access */
#define A_EXIST		0		/* access check for existence */
#define A_WRITE		2		/* access check for write permission */
#define A_READ		4		/* access check for read permission */
#define	REMOTE		1		/* remote mail, add rmtmsg */
#define ORDINARY	2
#define ZAP		3		/* zap header and trailing empty line */
#define FORWARD		4
#define DEAD		5
#define	LSIZE		256
#define	TOSIZE		512		/* size of buffer to hold dests */
#define	MAXLET		300		/* maximum number of letters */

#define	MFMODE		0660		/* create mode for `/usr/mail' files */
#define MASK		077

struct	let	{
	long	adr;
	char	change;
	int	llns;			/* lines in letter */
	char	*sender;		/* sender (e.g., sys1!sys2!login) */
	char	*subject;		/* subject of letter */
	char	*postmark;		/* date letter was received */
} let[MAXLET];

char M_change;
int  M_llns;
char *M_postmark, *unalias();

struct	{
	int	r_lines;		/* number of lines */
	int	r_nlcnt;		/* number of trailing empty lines */
	long	r_size;			/* number of bytes in letter */
} Readio;
char rsvp[MAXLET];
int realid;

#define putsf(s) /* puts(s);fflush(stdout) */
