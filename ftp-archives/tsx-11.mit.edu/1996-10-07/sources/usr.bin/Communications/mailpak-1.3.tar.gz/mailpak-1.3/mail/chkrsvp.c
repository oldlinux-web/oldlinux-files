void chkrsvp(l, j)
char *l;
int j;
{
   char buf[256];

   if(strncmp(l, "Return-Receipt-To: ", 19) != NULL) return;
   sprintf(buf, "echo \"The mail regarding \'%s\' of %s has been received.\"|%s -s \"RSVP to your mail\" \"%s\"&",
       let[j].subject, let[j].postmark, Mailpgm, /* let[j].sender */ l[19]);
   /* printf("%s\n", buf); */
   system(buf);
}
