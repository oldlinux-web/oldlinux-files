char *sccsid = "uustatus, version 1.3   08/28/92  Copyright 1989 by Edwin R. Carp";
