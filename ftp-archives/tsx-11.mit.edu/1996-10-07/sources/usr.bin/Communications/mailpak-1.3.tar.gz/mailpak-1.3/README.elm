Compiling elm 2.3 patch level 11 under Linux (but should work under
any version of elm):

NOTE: This is not necessary if you use the version of elm that came
with mailpak.

0.	Get the source distribution from your local ftp server.

1.	I used gcc 2.2.2, with shared libraries from the 0.96c mcc-
	interim release off of tsx-11.mit.edu.  Your mileage may
	differ.

2.	Comment out line 253 in "Configure" (the one that uses awk).

3.	Run "sh Configure".  When it complains about termlib, tell
	it "n", and "-ltermcap".  At the end of the script, it will
	give you a chance to edit config.sh.  Do it.  At the bottom
	of config.sh, there is a line that reads "d_bsd='define'".
	Change it to read "d_bsd='undef'".

	If you are running smail3 with the /bin/lmail I include,
	tell it that rmail doesn't add "From:" headers.  The shell
	script is pretty simple-minded. :)

4.	At line 220 in src/init.c, SIGBUS is defined.  Currently,
	SIGBUS isn't defined in signal.h.  Comment out the line
	or massage signal.h (which would probably make H. J. unhappy).
	At line 292 in /usr/include/unistd.h, comment out the
	declaration for ulimit().  This will prevent gcc from barfing
	when it compiles filter/actions.c.

5.	Now you can do a "make all ..." as usual.  To build just elm
	takes 20-30 minutes on my 386SX/4MB testbed system.  To build
	the entire binary distribution would take almost twice as long.

6.	I had to do a "ln -s /usr /var", despite the fact that I
	told elm that mail was in /usr/spool/mail.  <sigh>  I later found
	out that $MAIL is set that way in /etc/profile and/or .bashrc.

Note: I haven't done a whole lot of testing - I just wanted to make sure that
elm could read my mailbox and do the right thing with outgoing mail.  Buyer
beware.  It works for me, but then again, I like to ride motorcycles, too. :)

If you like these hints on how to get elm running on your system, you can do
one of two things: (1) congratulate Linus for fixing the used-to-be-broken
serial drivers, or (2) aim a cute-looking blonde woman with blue eyes my
way.  (1) would probably be easier than (2) for most, though... :)
