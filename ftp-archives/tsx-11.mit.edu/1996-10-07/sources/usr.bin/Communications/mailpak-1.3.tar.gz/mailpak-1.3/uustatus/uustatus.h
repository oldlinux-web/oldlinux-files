/*
*
* tuneable parameters
*
*/

/* #define WTTC */
#ifdef SVR4
#define STATUS "/var/spool/uucp/.Status"
#define SYSTEMS "/etc/uucp/Systems"
#define UUCICO "/var/spool/uucp/.Log/uucico/%s"
#define LOCKFILE "/var/spool/locks/LCK..%s"
#define WORKFILE "/var/spool/uucp/%s/%c"
#define XFERSTATS "/var/spool/uucp/.Admin/xferstats"
char *grades = "ZabcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXY";
#else
#define STATUS "/usr/spool/uucp/.Status"
#
#
#
#ifdef SUN
#	define SYSTEMS "/etc/uucp/Systems"
#	define NUMSYS 50
#else
#	define SYSTEMS "/usr/lib/uucp/Systems"
#endif
#
#
#

#define UUCICO "/usr/spool/uucp/.Log/uucico/%s"
#define LOCKFILE "/usr/spool/uucp/LCK..%s"
#define WORKFILE "/usr/spool/uucp/%s"
#define XFERSTATS "/usr/spool/uucp/.Admin/xferstats"
#endif
#define XFERTIME 3.0 /* transfer times less than this are ignored */
#define EXPDAYS 999 /* connections older than X days will not be displayed */
#define LOGON NO /* log expired systems? */
#define LOGFILE "/tmp/uuexp.log"
#define WAITMSG "WAIT"
#define BWAITMSG "    " /* blank wait msg string */
#define LLIMIT LINES-7
#define FLIMIT 999 /* over this many files for site, we quit; should be < 100 */
#define SLEEPTIME 5 /* time to sleep between samples */
#define UUCPOWN "uucp" /* uucp owner */
#define UUCPGRP "uucp" /* uucp group */
#define TABCHAR '	' /* should be a TAB */

/*
*
* end of tuneable parameters
*
*/

char *errortext[] =
{
   "SUCCESSFUL",
   "NO DEVICES AVAILABLE",
   "WRONG TIME TO CALL",
   "CALL IN PROGRESS",
   "CONVERSATION FAILED",
   "BAD SEQUENCE CHECK",
   "LOGIN FAILED",
   "DIAL FAILED",
   "BAD LOGIN/MACHINE COMBINATION",
   "DEVICE LOCKED",
   "ASSERT ERROR",
   "SYSTEM NOT IN Systems FILE",
   "CAN'T ACCESS DEVICE",
   "DEVICE FAILED",
   "WRONG MACHINE NAME",
   "CALLBACK REQUIRED",
   "REMOTE HAS A LCK FILE FOR ME",
   "REMOTE DOES NOT KNOW ME",
   "REMOTE REJECT AFTER LOGIN",
   "REMOTE REJECT, UNKNOWN MESSAGE",
   "STARTUP FAILED",
   "BUSY OR NO ANSWER",
/* #ifdef M_XENIX */
   /* "EXECDIAL LOCAL FAILURE", */
   /* "EXECDIAL REMOTE FAILURE", */
   /* "STATUS UNKNOWN", */
/* #else */
   "TALKING",
   "", /* dummy */
   "STATUS UNKNOWN",
/* #endif */
};
