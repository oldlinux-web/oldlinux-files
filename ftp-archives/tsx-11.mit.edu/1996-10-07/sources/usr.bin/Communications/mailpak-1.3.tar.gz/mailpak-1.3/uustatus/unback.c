static char *sccsid = "%Z% %M% %I%    %G% %U%";
/*
*
* unback <input >output
*
* unback will make the output of nroff readable from a file
*
* written 05/14/87 by Ed Carp
*
*/
#define BACKSPACE 8
#define EOF (-1)
main()
{
   char in[3], c;
   int i;

   in[0] = in[1] = in[2] = '\0';
   while((c=getchar()) != EOF)
   {
      if(in[0] != '\0') putchar(in[0]);
      in[0] = in[1];
      in[1] = in[2];
      in[2] = c;
      if(in[0] == '_' && in[1] == BACKSPACE)
      {
         in[0] = in[1] = '\0';
         continue;
      }
      if(in[0] != '_' && in[1] == BACKSPACE)
      {
         in[1] = in[2] = '\0';
         continue;
      }
   }
   for(i=0; i<3; i++)
      if(in[i] != '\0') putchar(in[i]);
}

