/* : sysdefs.SH,v 4.1.1.3 90/10/10 12:45:21 syd Exp $ */
/*******************************************************************************
 *  The Elm Mail System  -  : 4.1.1.3 $   : Exp $
 *
 * 			Copyright (c) 1986, 1987 Dave Taylor
 * 			Copyright (c) 1988, 1989, 1990 USENET Community Trust
 *******************************************************************************
 * Bug reports, patches, comments, suggestions should be sent to:
 *
 *	Syd Weinstein, Elm Coordinator
 *	elm@DSI.COM			dsinc!elm
 *
 *******************************************************************************
 * $Log:	sysdefs.SH,v $
 * Revision 4.1.1.3  90/10/10  12:45:21  syd
 * Make the symbol look less like a typo, its real
 * From: Syd
 * 
 * Revision 4.1.1.2  90/10/07  19:48:17  syd
 * fix the bounce problem reported earlier when using MMDF submit as the MTA.
 * From: Jim Clausing <jac%brahms.tinton.ccur.com@RELAY.CS.NET>
 * 
 * Revision 4.1.1.1  90/06/09  22:28:42  syd
 * Allow use of submit with mmdf instead of sendmail stub
 * From: martin <martin@hppcmart.grenoble.hp.com>
 * 
 * Revision 4.1  90/04/28  22:42:14  syd
 * checkin of Elm 2.3 as of Release PL0
 * 
 *
 ******************************************************************************/

/**  System level, configurable, defines for the ELM mail system.  **/


#define FIND_DELTA	10		/* byte region where the binary search
					   on the path alias file is fruitless 
                                           (can't be within this boundary)    */

#define MAX_IN_WEEDLIST 150	/* max headers to weed out               */

#define MAX_HOPS	35	/* max hops in return addr to E)veryone  */

#define DEFAULT_BATCH_SUBJECT  "no subject (file transmission)"

#define DEFAULT_DOMAIN  ".UUCP"  /* if mydomain file is missing */

/** If you want to implement 'site hiding' in the mail, then you'll need to
    uncomment the following lines and set them to reasonable values.  See 
    the configuration guide for more details....(actually these are undoc-
    umented because they're fairly dangerous to use.  Just ignore 'em and
    perhaps one day you'll find out what they do, ok?)
**/

/****************************************************************************

#define   SITE_HIDING
#define   HIDDEN_SITE_NAME	"fake-machine-name"
#define   HIDDEN_SITE_USERS	"/usr/mail/lists/hidden_site_users"

****************************************************************************/

#define system_text_file        "/usr/lib/aliases.text"
#define system_hash_file        "/usr/lib/aliases.hash"
#define system_data_file        "/usr/lib/aliases.data"

#define ALIAS_TEXT		".elm/aliases.text"
#define ALIAS_HASH		".elm/aliases.hash"
#define ALIAS_DATA		".elm/aliases.data"

#define pathfile		"/usr/lib/uucp/paths"
#define domains			"/usr/lib/domains"
#define hostdomfile             "/usr/lib/domain"

/** where to put the output of the elm -d command... (in home dir) **/
#define DEBUGFILE	"ELM:debug.info"
#define OLDEBUG		"ELM:debug.last"

#define	default_temp   	"/tmp/"
#define temp_file	"snd."
#define temp_form_file	"form."
#define temp_mbox	"mbox."
#define temp_print      "print."
#define temp_edit	"elm-edit"
#define temp_uuname	"uuname."
#define readmsg_file	".elm/readmsg"

#define emacs_editor	"emacs"

#define default_editor	"/usr/bin/vi"
#define mailhome	"/usr/spool/mail/"

#define default_shell	"/bin/sh"
#define default_pager	"builtin+"
#define default_printout	"cat %s | /bin/lp"

#define sendmail	""
#define smflags		"-oi -oem"	/* ignore dots and mail back errors */
#define smflagsv      	"-oi -oem -v"   /* Verbose voyuer mode */
#define submitmail     	""
#define submitflags     "-mlrnxto,cc*"
#define submitflags_s	"-mlrn"
#define mailer		"/bin/rmail"

#define mailx		"mailx"

#define helphome	"/usr/lib"
#define helpfile	"elm-help"

#define ELMRC_INFO	"/usr/lib/elmrc-info"

#define elmrcfile	".elm/elmrc"
#define old_elmrcfile	".elm/elmrc.old"
#define mailheaders	".elm/elmheaders"
#define dead_letter	"Cancelled.mail"

#define unedited_mail	"emergency.mbox"

#define newalias	"newalias 1>&2 > /dev/null"
#define readmsg		"readmsg"

#define remove_cmd	"rm -f"	/* how to remove a file */
#define cat		"cat"		/* how to display files */
#define sed_cmd		"sed"		/* how to access sed */
#define move_cmd	"mv"		/* how to access sed */
#define uuname		"/usr/bin/uuname"	/* how to get a uuname  */

#define MSG_SEPERATOR	"\001\001\001\001\n"	/* mmdf message seperator */
