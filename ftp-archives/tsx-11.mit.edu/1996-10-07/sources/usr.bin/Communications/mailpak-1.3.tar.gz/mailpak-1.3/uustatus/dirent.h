/*
*
* /usr/include/dirent.h for SYS V (AT&T)
*
* Copyright 1989 by Edwin R. Carp
*
* kludgy, but it works...
*
*/

#define DIR FILE
#define dirent direct
#include <sys/dir.h>
static struct direct wdp;

DIR *opendir(name)
char *name;
{
   return(fopen(name, "r"));
}

struct direct *readdir(dp)
DIR *dp;
{
int ret;

   while(1)
   {
      ret=fread(&wdp, 1, sizeof(struct direct), dp);
      if(ret < sizeof(struct dirent)) return((struct direct *)NULL);
      if(wdp.d_ino == 0) continue;
      return(&wdp);
   }
}

closedir(dp)
DIR *dp;
{
   fclose(dp);
}
