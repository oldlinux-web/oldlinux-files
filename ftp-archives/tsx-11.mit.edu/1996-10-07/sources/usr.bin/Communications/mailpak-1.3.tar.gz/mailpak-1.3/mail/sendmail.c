/*
 * sendmail
 */

#include <stdio.h>
#include <signal.h>
#include <grp.h>
#include "mail.h"

extern char *Mailpgm, from[], *my_name, tz[16], *lettmp, dead[], **alias();
extern char subject[70];
extern char *getarg(), *unalias();
extern int DestSub, error, (*saveint)(), savdead(), nlet, sflag;
extern int (*setsig())();
extern FILE *tmpf, *logf, *readinput();
extern long iop;

struct group *getgrnam();

sendmail(argc, argv)
char **argv;
{
   struct group *pgrp;
   char *gp, hbuf[256], tobuf[TOSIZE], *tp;
   register int i, start;
   register char **pal, *p, *q;
   char   dst[64];      /* buffer for one destination */
   FILE   *textfp;

   putsf("DEBUG: sendmail start");
   start = 1;
   if(argv[1][0] == '-' && argv[1][1] == 's')
   {
      strcpy(subject, argv[2]);
      sflag = 1;
      start = 3;
   }
   time(&iop);
/*
   sprintf(hbuf, "%s%s (%s) %24.24s%s\n",
       from, my_name, unalias(my_name, 0), ctime(&iop), tz);
*/
   sprintf(hbuf, "%s%s %24.24s%s\n",
       from, my_name, ctime(&iop), tz);
   putsf("DEBUG: sendmail checkpoint 1");
   hbuf[255] = 0;
   tobuf[0] = 0;
   DestSub = 0;
   if (1 || argc > 2) {      /* (Always) send Copy to message */
      p = tobuf;
      for (i = start; i < argc; i++) {
         q = argv[i];
         q = *(alias(q, 0)); /* junky way to resolve aliases */
         *p++ = ' ';
         while (*p++ = *q++)
            if (p >= &tobuf[sizeof(tobuf)-1]) {
               fprintf(stderr, "%s: Too many addressees\n", Mailpgm);
               error = 2;
               return;
            }
         p--;
      }
   putsf("DEBUG: sendmail checkpoint 2");
      tobuf[TOSIZE - 1] = '\0';
      strcpy(tobuf, finddest(tobuf, ""));
   }

   putsf("DEBUG: sendmail checkpoint 3");
   /* Get text of letter from standard input */
   saveint = setsig(SIGINT, savdead);
   textfp = readinput(stdin, tobuf);
   setsig(SIGINT, saveint);
   putsf("DEBUG: sendmail checkpoint 4");
   if (textfp == (FILE *)NULL)
      return;

   putsf("DEBUG: sendmail checkpoint 5");
   envelope(tmpf, hbuf, tobuf, textfp);
   putsf("DEBUG: sendmail checkpoint 5a");
   nlet = 1;
   let[0].adr = 0;
   let[0].llns = Readio.r_lines;
   let[1].adr = Readio.r_size;

   putsf("DEBUG: sendmail checkpoint 6");
   tmpf = fopen(lettmp, "r");
   if (tmpf == NULL) {
      fprintf(stderr, "%s: cannot reopen %s for reading\n",
          Mailpgm, lettmp);
      error = 2;
      return;
   }
   putsf("DEBUG: sendmail checkpoint 7");
   if (error == 0) {
      /* Write log entry */
      if (logf != NULL)
         copylet(0, logf, ORDINARY, "");

      /* if (DestSub)
         fprintf(stderr, "Sending to: %s\n\n", tobuf, 0); */

   putsf("DEBUG: sendmail checkpoint 8");
      for (tp = tobuf; tp = getarg(dst, tp); ) {
         if (equal(dst, "-g")) {
            if ((tp = getarg(dst, tobuf)) == NULL)
               break;
            if ((pgrp=getgrnam(gp = dst)) == NULL) {
               error++;
               fprintf(stderr, "Unknown group %s\n",
                   gp);
               continue;
            }
   putsf("DEBUG: sendmail checkpoint 9");
            for (i = 0; pgrp->gr_mem[i] && pgrp->gr_mem[i][0]; i++) {
               if (!send(0, pgrp->gr_mem[i], 0))
                  error++;
               else
                  fprintf(stdout, "\t%s group: %s\n",
                      gp, pgrp->gr_mem[i]);
            }
            continue;
         }
   putsf("DEBUG: sendmail checkpoint 10");
         for (pal = alias(dst, 1); *pal; pal++)
            if (!send(0, *pal, 0))
               error++;
      }
   }
   if (error) {
      if (storedead(0, dead)) {
         fprintf(stdout, "%s: cannot create %s\n", Mailpgm, dead);
         error = 2;
         return;
      }
   }
   putsf("DEBUG: sendmail checkpoint 11");
   fclose(tmpf);
   putsf("DEBUG: sendmail return");
}

savdead()
{
   setsig(SIGINT, saveint);
   error++;
}
