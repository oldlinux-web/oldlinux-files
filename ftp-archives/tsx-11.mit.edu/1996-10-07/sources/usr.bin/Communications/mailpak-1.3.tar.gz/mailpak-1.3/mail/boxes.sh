: "shell to create the appropriate mail boxes for the extended mail program"
: "ONLY NEEDS TO BE RUN ONCE!!!"
: "obviously must be run as root..."
MDIR=/usr/spool/mail
chmod 775 $MDIR
chgrp mail $MDIR
for uid in `cut -d: -f1 /etc/passwd`
do
	touch $MDIR/$uid
	chown $uid $MDIR/$uid
done
chmod 660 $MDIR/*
chgrp mail $MDIR/*
