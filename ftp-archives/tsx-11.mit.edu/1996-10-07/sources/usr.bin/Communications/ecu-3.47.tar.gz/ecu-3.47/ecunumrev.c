/* #define ALPHA */
/* #define BETA */

char *numeric_revision = "3";

#if defined(WHT) || defined(ALPHA) || defined(BETA)
char *numeric_devrev = "17";

#else
char *numeric_devrev = "";

#endif

/*+-----------------------------------------------------------------------
	ecunumrev.c - revision numbers
	wht@n4hgf.atl.ga.us

  Defined functions:
	build_revision_string()

------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:07-31-1996-17:19-wht@kepler-3-43-3.44 rapid fire Solaris/FreeBSD fixes */
/*:06-13-1996-13:25-wht@kepler-3.42-fix GCC/CC discrep in config */
/*:02-28-1996-21:31-wht@kepler-3.39.01-fix ">" shell cmd to use /bin/sh */
/*:01-27-1996-21:28-wht@kepler-bump for primary release - not BETA */
/*:12-12-1995-14:22-wht@kepler-3.38.05-notify [no line attached] on keystroke */
/*:12-10-1995-09:55-wht@kepler-3.38.04-tty1A is default on SCO */
/*:12-09-1995-12:00-wht@kepler-3.38.03-fix stdin /dev/null operation */
/*:12-03-1995-19:19-wht@kepler-3.38.02-work on SunOS version */
/*:11-24-1995-14:18-wht@kepler-3.37.90-zmodem xfer fixed */
/*:11-23-1995-11:20-wht@kepler-source control 3.37 for tsx-11 */
/*:11-20-1995-12:24-wht@n4hgf-3.37.82-misc cleanup for SCO 32v4 */
/*:11-14-1995-17:44-wht@kepler-3.37.81-more cleanup */
/*:11-14-1995-10:23-wht@kepler-3.37.80-source control point: SOCKETS */
/*:11-04-1995-15:10-wht@wwtp1-3.37.78-working MUCH better */
/*:11-03-1995-18:05-wht@kepler-3.37.77-clean up OS5 port */
/*:11-03-1995-16:08-wht@wwtp1-3.37.76-refine port to OS5 */
/*:10-19-1995-14:41-wht@kepler-3.37.75-telnet almost working */
/*:10-15-1995-15:22-wht@calvin-3.37.74-SVR4 and SunOS cleanup */
/*:10-14-1995-14:38-wht@kepler-3.37.73-baud values extension */
/*:10-09-1995-16:42-wht@kepler-3.37-72-fix SU */
/*:09-16-1995-17:01-wht@kepler-3.37.71-tcap execution debug/investigation */
/*:09-04-1995-19:03-wht@n4hgf-3.37.70-fix 32v5 lock file naming */
/*:09-01-1995-17:37-wht@n4hgf-3.37.69-32v5 lock file naming */
/*:06-05-1995-02:23-wht@n4hgf-moving toward Everest and ECU 3.40 */
/*:01-15-1995-01:44-wht@n4hgf-clean up port rot */
/*:01-12-1995-15:19-wht@n4hgf-apply Andrew Chernov 8-bit clean+FreeBSD patch */
/*:05-04-1994-04:38-wht@n4hgf-ECU release 3.30 */
/*:12-12-1993-13:28-wht@n4hgf-support MOTSVR3 */
/*:11-14-1993-12:33-wht@n4hgf-HP-UX port by Carl Wuebker at HP */
/*:09-16-1992-14:13-wht@n4hgf-add M and F version qualifiers */
/*:09-10-1992-13:58-wht@n4hgf-ECU release 3.20 */
/*:08-22-1992-15:38-wht@n4hgf-ECU release 3.20 BETA */
/*:11-16-1991-17:05-wht@n4hgf-better development "x" rev numbering */
/*:08-28-1991-14:07-wht@n4hgf2-SVR4 cleanup by aega84!lh */
/*:08-25-1991-14:39-wht@n4hgf-SVR4 port thanks to aega84!lh */
/*:07-25-1991-12:56-wht@n4hgf-ECU release 3.10 */
/*:07-12-1991-14:14-wht@n4hgf-GCC140 differentiation */
/*:04-27-1991-01:52-wht@n4hgf-overhaul revision numbers */
/*:08-14-1990-20:40-wht@n4hgf-ecu3.00-flush old edit history */

#include <stdio.h>
#include <string.h>
#ifdef __FreeBSD__
#include <stdlib.h>
#else
#include <malloc.h>
#endif
#include "patchlevel.h"

#if defined(M_UNIX)
#undef M_XENIX
#endif

char *revstr = "";

/*+-------------------------------------------------------------------------
	build_revision_string()
--------------------------------------------------------------------------*/
void
build_revision_string()
{
	int itmp;
	char s128[128];

	sprintf(s128, "%s%s.%02d", (itmp = strlen(numeric_devrev)) ?
#ifdef ALPHA
		"ALPHA-"
#else
#ifdef BETA
		"BETA-"
#else
		"x"
#endif
#endif
		: "",
		numeric_revision, PATCHLEVEL);

	if (itmp)
	{
		strcat(s128, ".");
		strcat(s128, numeric_devrev);
	}

#ifdef WHT
	strcat(s128, "*");
#endif

#ifndef CONFIG
	strcat(s128, " wht@n4hgf");
#endif

	if (!(revstr = malloc(strlen(s128) + 1)))
	{
		fprintf(stderr, "out of memory so early!?\n");
		exit(255);
	}
	strcpy(revstr, s128);

}							 /* end of build_revision_string */

/* vi: set tabstop=4 shiftwidth=4: */
