/*+-------------------------------------------------------------------------
	feval.h
	wht@n4hgf.atl.ga.us
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:11-23-1995-11:20-wht@kepler-source control 3.37 for tsx-11 */
/*:11-14-1995-10:23-wht@kepler-3.37.80-source control point: SOCKETS */
/*:05-04-1994-04:39-wht@n4hgf-ECU release 3.30 */
/*:09-10-1992-13:59-wht@n4hgf-ECU release 3.20 */
/*:08-22-1992-15:38-wht@n4hgf-ECU release 3.20 BETA */
/*:03-27-1992-16:21-wht@n4hgf-re-include protection for all .h files */
/*:07-25-1991-12:58-wht@n4hgf-ECU release 3.10 */
/*:08-14-1990-20:40-wht@n4hgf-ecu3.00-flush old edit history */

#ifndef _feval_h
#define _feval_h

#define FIinstr		1
#define FIlen		2
#define FIstoi		3
#define FIctoi		4
#define FIbaud		5
#define FIconn		6
#define FIcsec		7
#define FIpid		8
#define FIrchr		9
#define FIrchrc		10
#define FIxchr		11
#define FIxchrc		12
#define FIlgetc		13
#define FIargc		14
#define FIftell		15
#define FIfmode		16
#define FIisdir		17
#define FIisreg		18
#define FIischr		19
#define FIfatime	20
#define FIfmtime	21
#define FIfsize		22
#define FIcolors	23

KEYTAB feval_int_tbl[] =
{
	{"argc", FIargc},
	{"baud", FIbaud},
	{"colors", FIcolors},
	{"conn", FIconn},
	{"csec", FIcsec},
	{"ctoi", FIctoi},
	{"fatime", FIfatime},
	{"fmode", FIfmode},
	{"fmtime", FIfmtime},
	{"fsize", FIfsize},
	{"ftell", FIftell},
	{"instr", FIinstr},
	{"ischr", FIischr},
	{"isdir", FIisdir},
	{"isreg", FIisreg},
	{"len", FIlen},
	{"lgetc", FIlgetc},
	{"pid", FIpid},
	{"rchr", FIrchr},
	{"rchrc", FIrchrc},
	{"stoi", FIstoi},
	{"xchr", FIxchr},
	{"xchrc", FIxchrc},
	{(char *)0, 0}
};

#define FSleft		2
#define FSright		3
#define FSmid		4
#define FSdate		5
#define FSmonth		6
#define FSday		7
#define FScgets		9
#define FScgetc		10
#define FSitos		11
#define FSchr		12
#define FSdir		13
#define FStty		14
#define FSrdesc		15
#define FSrname		16
#define FSline		17
#define FSrtel		18
#define FSargv		19
#define FStime		20
#define FStimes		21
#define FSedate		22
#define FSetime		23
#define FSgetenv	24
#define FSgetlogin	25

KEYTAB feval_str_tbl[] =
{
	{"argv", FSargv},
	{"cgetc", FScgetc},
	{"cgets", FScgets},
	{"chr", FSchr},
	{"date", FSdate},
	{"day", FSday},
	{"dir", FSdir},
	{"edate", FSedate},
	{"etime", FSetime},
	{"getenv", FSgetenv},
	{"getlogin", FSgetlogin},
	{"itos", FSitos},
	{"left", FSleft},
	{"line", FSline},
	{"mid", FSmid},
	{"month", FSmonth},
	{"rdesc", FSrdesc},
	{"right", FSright},
	{"rname", FSrname},
	{"rtelno", FSrtel},
	{"time", FStime},
	{"times", FStimes},
	{"tty", FStty},
	{(char *)0, 0}
};

#endif /* _feval_h */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of feval.h */
