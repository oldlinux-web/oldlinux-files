/* see zcurses.c report_lasthdr() */
/*+:EDITS:*/
/*:11-14-1995-10:23-wht@kepler-3.37.80-source control point: SOCKETS */
/*:05-04-1994-04:40-wht@n4hgf-ECU release 3.30 */
/*:09-10-1992-14:00-wht@n4hgf-ECU release 3.20 */
/*:08-22-1992-15:39-wht@n4hgf-ECU release 3.20 BETA */
/*:07-25-1991-12:59-wht@n4hgf-ECU release 3.10 */
/*:08-14-1990-20:41-wht@n4hgf-ecu3.00-flush old edit history */
int header_debug = 0;

/* vi: set tabstop=4 shiftwidth=4: */
