/*+-------------------------------------------------------------------------
	zrdchk.c - rdchk clone for CFG_FionrdRdchk
--------------------------------------------------------------------------*/
/*+:EDITS:*/
/*:11-14-1995-10:23-wht@kepler-3.37.80-source control point: SOCKETS */
/*:05-04-1994-04:40-wht@n4hgf-ECU release 3.30 */
/*:01-12-1994-06:02-wht@gyro-creation */

#if defined(CFG_FionrdRdchk)
#include <sys/ioctl.h>
#if defined (sun) && defined (SVR4)	/* Solaris 2.x */
#include <sys/filio.h>
#endif
#endif /* CFG_FionrdRdchk */

/*+-------------------------------------------------------------------------
	rdchk(f)
--------------------------------------------------------------------------*/
#if defined(CFG_FionrdRdchk)
int
rdchk(fd)
int fd;
{
	int waiting = 0;

	ioctl(fd, FIONREAD, &waiting);
	return (!!waiting);

}							 /* end of rdchk */
#endif /* CFG_FionrdRdchk */

/* vi: set tabstop=4 shiftwidth=4: */
/* end of zrdchk.c */
