
/*
     ATP QWK MAIL READER FOR READING AND REPLYING TO QWK MAIL PACKETS.
     Copyright (C) 1992  Thomas McWilliams 
	 Copyright (C) 1990  Rene Cougnenc
	 
     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 1, or (at your option)
     any later version.
     
     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.
     
     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/*
 * Change Log: $Log: read.c,v $
 * Revision 1.400  1992/11/28  09:54:05  root
 * second release of ATP, first use of this module
 *
 */
 
#define TLMX 60     /* maximum length for tagline */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifdef unix
#include <unistd.h>
#else
#include <dir.h> /* turbo c */
#endif
#include "reader.h"

#define FN_TMP_TEMPLATE "chXXXXXX"

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#ifdef BSD
#define rand() random() 
#endif

extern int fido ;
extern char CurTag[] ;
extern const char *const FidoTag ;
extern const char *const TagLine ;

int ChooseTag(void);
void TagSeek(const unsigned int tagchoice);
static  void  Bye( void ) ;
static	char *FnTmp;
static	FILE *FpTmp;
static  void  InitRandom(void);
static   int  DupCount( FILE *from , FILE *to);

int
ChooseTag ( void )
{
    char ttbuf[30];
	unsigned int NToChoose = 1 ;
	unsigned int NSample ;
	unsigned int toffset ;
	static int flag1st = TRUE ;
	FILE *Fp = NULL ;
	char ttagpath[MAXPATHS] ;

	strcpy( ttbuf, FN_TMP_TEMPLATE);
	FnTmp = mktemp( ttbuf );
	if ((FpTmp = fopen(FnTmp, "w+b" )) == NULL){  /* open tagline file */
		fprintf(stderr, "Can't open file %s mode %s\n", FnTmp, "write" );
		return(1) ;
	}
	
  	sprintf(ttagpath, "%s%s", HomePath, TAGFILE);   

	if ((Fp = fopen(ttagpath, "rb" )) == NULL){  /* open tagline file */
		Bye();
		fprintf(stderr, "Can't open file %s mode %s\n", ttagpath, "read only" );
		return(1) ;
	}

	NSample = 0;
	NSample += DupCount(Fp, FpTmp);
	Bye();
	fclose(Fp);

	if (NToChoose > NSample) {
		fprintf(stderr, "%s: Can't choose %d from %d.\n",
				ttagpath, NToChoose, NSample);
		return(1);
	}

	if(flag1st) {  
		InitRandom();
		flag1st = FALSE ;
	}

	toffset = (unsigned int) ( (rand() ) % NSample ) ;
	TagSeek( toffset );
	return(0);
}

static void
Bye( void ) /* get rid of temp file and exit */
{	
	fclose(FpTmp);
	unlink(FnTmp);
}


/* duplicate file and count lines */
static int 
DupCount( FILE *FpFrom, FILE *FpTo)
{
	char Ch;
	int NLn = 0;

	while ((Ch = getc(FpFrom)) != EOF) {
		if (Ch == '\n')
			NLn++;
        if (Ch ==  '\r')
			continue;
		putc(Ch, FpTo);
	}

	return NLn;
}

static void
InitRandom()	/* initialize random sequence  */
{
#ifdef BSD
	struct timeval tv;
	struct timezone tz;
	gettimeofday(&tv, &tz);
	srandom((int) tv.tv_sec);
#else
	srand( (unsigned int) time(NULL) );
/*	srand(getpid()); <- use this as a last resort */
#endif
	return;
}

void
TagSeek ( const unsigned int tagchoice )
{
	unsigned int  charct = 0, NLn = 0 , TagOff = 0 ;
	char ttagpath[MAXPATHS], *crtag , Ch = '\040' ;
	char tmptagbuf[TLMX+50] ; /* temporary work buffer */
	FILE *Fp = NULL ;

	crtag = tmptagbuf ;
  	sprintf(ttagpath, "%s%s", HomePath, TAGFILE);   

	if ((Fp = fopen(ttagpath, "rb" )) == NULL){  /* open tagline file */
		fprintf(stderr, "Can't open file %s mode %s\n", ttagpath, "read only" );
		return ;
	}
	Ch = (char) 0 ;
	while( NLn != tagchoice && Ch != EOF ) {  /* seek to chosen tagline */
		Ch = getc(Fp) ;
		TagOff++;
		if (Ch == '\n') NLn++;
	}
	if( Ch == EOF ) {
		printf("unexpected end of file\n");
		fclose(Fp);
		return;
	}
	Ch = (char) 0 ;
	while (Ch != EOF && Ch != '\n' && charct < TLMX ) {  /* build new tag line */	
		Ch = getc(Fp) ;
		if(Ch == '\r') continue ;
		*crtag = Ch ;
		crtag++ ;
		charct++;
	}
	if( Ch == EOF ) {
		printf("unexpected end of file\n");
		fclose(Fp);
		return;
	}
	crtag-- ;
	if( *crtag != '\n' )
		*crtag = '\n' ;
	crtag++ ;
	*crtag = '\0' ;
	if (fido)
		strcpy(CurTag, FidoTag);	/* setup the default TagLines */
	else
		strcpy(CurTag, TagLine);
	strcat(CurTag, tmptagbuf);
	fclose(Fp) ;
	return;
	}

