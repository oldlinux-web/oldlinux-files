
/*
     ATP QWK MAIL READER FOR READING AND REPLYING TO QWK MAIL PACKETS.
     Copyright (C) 1992  Thomas McWilliams 
	 Copyright (C) 1990  Rene Cougnenc
	 
     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 1, or (at your option)
     any later version.
     
     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.
     
     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/	 

/*
 * Change Log: $Log: system.c,v $
 * Revision 1.400  1992/11/28  09:57:36  root
 * second release
 * Revision 1.310  1992/07/08  23:15:14  root
 * first release -- minor bug fix in read.c
 * 
 * Revision 1.30  1992/07/05  15:36:19  root first release of ATP
 * 
 * Revision 1.2  1992/04/19  12:51:47  root 1st semifunctional UNIX version.
 * 
 */


/*
 * DOS System-Dependant functions for Read.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "system.h"
#include "ansi.h"

#ifdef DJD
#include <pc.h>
#endif

#ifdef __TURBOC__
#include <alloc.h>
#include <dos.h>
#include <conio.h>
#endif

#ifdef __MSDOS__
#include <dir.h>  /* this defines structure "ffblk" */
#endif

/*
 * Deletes ALL files in a directory pointed by PathName. This is
 * system-dependant.
 */

void 
Erase(const char *PathName)
{
	char            Pattern[127] ;

#ifdef unix
#ifndef DJD
	sprintf(Pattern, "rm -f %s/*", PathName);
	system(Pattern);
#endif
#endif

#ifdef __MSDOS__  /* for dos, this method saves you from an annoying prompt */

	int             ok;
	char            tmp[130];
    char            cwd[130];
	struct	ffblk 	FileDoc ;

	getcwd(cwd, 128);
	sprintf( (char *) Pattern, "%s\\*.*", PathName);

	if ( (ok = findfirst( (char *) Pattern, &FileDoc, 0)) != 0 ) return ;
	while (!ok) {
		sprintf(tmp, "%s\\%s", PathName, FileDoc.ff_name);
		unlink(tmp);
		ok = findnext( &FileDoc );
	}
	chdir(cwd);
#endif
}
/*-------------------------------------------------------------------------*/

#ifdef unix


int 
strnicmp(const char *s1, const char *s2, unsigned int n)
{
	while (n && *s1 && *s2) {
		if (tolower(*s1) != tolower(*s2))
			return (tolower(*s1) > tolower(*s2) ? 1 : -1);
		s1++;
		s2++;
		n--;
	}
	if (n) {
		if (*s1)
			return (1);
		if (*s2)
			return (-1);
	}
	return (0);
}

int 
stricmp(const char *s1, const char *s2)
{
	while (*s1 != '\0' && *s2 != '\0') {
		if (tolower(*s1) != tolower(*s2))
			return (tolower(*s1) > tolower(*s2) ? 1 : -1);
		s1++;
		s2++;
	}
	if (*s1)
		return (1);
	if (*s2)
		return (-1);
	return (0);
}


char           *
strlwr(char *s)
{
	char           *s1;

	s1 = s;
	while (*s1) {
		*s1 = tolower(*s1);
		s1++;
	}
	return (s);
}

char           *
strupr(char *s)
{
	char           *s1;

	s1 = s;
	while (*s1) {
		*s1 = toupper(*s1);
		s1++;
	}
	return (s);
}

#endif

#ifdef NEEDREADLINE

#ifdef __MSDOS__
#define STOPIT (int)'\r'
#else 
#define STOPIT (int)'\n'
#endif

char * readline( char *prmt ) {

	static char rdlnbuf[128] ;
    extern char *luxptr ;
	char *buf, *tempr ;
	int cin = 0, idx = 0 , i, firsthere = TRUE ;

    buf = (char *) malloc( 128 ) ; /* inialize buffers */
    rdlnbuf[0] = buf[0] = 0 ;
    
	printf("%s",prmt);             /* display prompt */
 	if(luxptr != NULL){
        strcpy (rdlnbuf, luxptr);
		printf("%s\n", luxptr );
        up(1);
        right(14);
        buf[0] = 1 ;
	}
	fflush(stdout);
	while( ( cin = getch())!=STOPIT) {
		if( firsthere ) {
    		for(i=idx; i < 25 ; i++ ) printf(" "); /* clear line */
			for(i=idx; i < 25 ; i++ ) printf("\b"); buf[0] = 1 ;
            firsthere = FALSE ;
        }
    	if( cin > 31 ) {
			printf("%c", cin); buf[idx] = (char) cin ; idx++ ;
       		buf[idx] = 0 ;
			if ( idx  > 24 ) { idx-- ; printf("\b") ; } ;
    	} else if ( cin == '\b' && idx > 0 ) {  /* do backspace */
			printf("\b \b");
			buf[--idx] = 0 ;
		} else if ( cin == 0 ) { 
			buf[idx] = 0 ;
#ifdef __TURBOC__  /* check for special keys */
			tempr = NULL ; 
			if(luxptr == NULL) {
           switch ( cin = getch()){
				case 0x3b : tempr =  "help" ; break ;
				case 0x3c : tempr =  "tag help" ; break ;
				case 0x3d : tempr =  "tag list" ; break ;
				case 0x3e : tempr =  "qlist" ; break ;
				case 0x49 : tempr =  "-" ; break ;
				case 0x51 : tempr =  "+" ; break ;
                case 0x4f : tempr =  "last" ; break ;
				case 0x47 : tempr =  "1" ; break ;
                case 0x3f : tempr =  "show terms" ; break ;
				case 0x4c : tempr =  "N" ; break ;
				default: 
				break ;
			}
			if( tempr != NULL ) {
				strcpy ( buf, tempr);
				printf("\n");
				return buf ;
			}
			}
#endif
		} else {
            buf[idx] = 0 ; 
		}
        fflush(stdout);
	} 	
    printf("\n");
    if( buf[0] == 1 ) strcpy (buf, rdlnbuf);     
    return  buf ;

} ;
#endif

#ifdef NEEDTEMPNAM
char *mytempnam( char *workpath, char *rep ) {

    char *tp1, *tp2 ;
    static char    tbuf[150] ;
    char buffy[15] ;

    strcpy(buffy,"XXXXXX");
    tp2 = tbuf ;
    tp1 = mktemp( buffy ) ;
    if( tp1 != NULL ) {
    	strcpy( tbuf, workpath ); 
        while( *tp2 ) tp2++ ;
		tp2--  ;
		if( *tp2 != SEP ){
        	tp2++ ;
			*tp2 = SEP ;
            tp2++ ;
            *tp2 = '\0' ;
       }
       strcat(tbuf,rep) ;
   	   strcat(tbuf, tp1 ) ;
       tp1 = tbuf ;
   } 
   return  tp1 ;
} 

#endif 


