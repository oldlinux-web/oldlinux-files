/*

     ATP QWK MAIL READER FOR READING AND REPLYING TO QWK MAIL PACKETS.
     Copyright (C) 1992  Thomas McWilliams 
	 Copyright (C) 1990  Rene Cougnenc
	 
     This program is free software; you can redistribute it and/or modify
     it under the terms of the GNU General Public License as published by
     the Free Software Foundation; either version 1, or (at your option)
     any later version.
     
     This program is distributed in the hope that it will be useful,
     but WITHOUT ANY WARRANTY; without even the implied warranty of
     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     GNU General Public License for more details.
     
     You should have received a copy of the GNU General Public License
     along with this program; if not, write to the Free Software
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

*/

/*
Checksum: 3037271238 for use by Brik.
*/

/* Change Log:
$Log: ansi.c,v $
 * Revision 1.400  1992/11/28  09:56:28  root
 * second release
 *
 * Revision 1.310  1992/07/08  23:15:14  root
 * first release -- minor bug fix in read.c
 *
 * Revision 1.30  1992/07/05  15:36:19  root
 * first release of ATP
 *
 * Revision 1.2  1992/04/19  12:46:31  root
 * 1st semifunctional UNIX version.
 *
 */


#include <stdio.h>
#include "ansi.h"
extern int ansi ;            /* Will just return on ansi=0 */

#define ESC 27


void cls()               /* Clear screen & home cursor */
{
    if( ansi )
	printf("%c[2J%c[H",ESC,ESC);
}
void deleol()            /* del to end of line        */
{
    if( ansi )
	printf("%c[K",ESC);
}
void clear()             /* Reset Attributes          */
{
    if( ansi )
	printf("%c[0m",ESC );
}
void high()              /* HigLitht  (or BoldFace )  */
{
    if( ansi )
	printf("%c[1m",ESC);
}
void blink()             /* blink mode                */
{
    if( ansi )
	printf("%c[5m",ESC);
}
void reverse()           /* Revers video mode         */
{
    if( ansi )
	printf("%c[7m",ESC);
}

/*------------- Foreground colors ---------------------*/
void black()
{
    if( ansi )
	printf("%c[30m",ESC);
}
void red()
{
    if( ansi )
	printf("%c[31m",ESC);
}
void green()
{
    if( ansi )
	printf("%c[32m",ESC);
}
void yellow()
{
    if( ansi )
	printf("%c[33m",ESC);
}
void blue()
{
    if( ansi )
	printf("%c[34m",ESC);
}
void magenta()
{
    if( ansi )
	printf("%c[35m",ESC);
}
void cyan()
{
    if( ansi )
	printf("%c[36m",ESC);
}
void white()
{
    if( ansi )
	printf("%c[37m",ESC);
}

/*------------- BackGround colors ---------------------*/
void bblack()
{
    if( ansi )
	printf("%c[40m",ESC);
}
void bred()
{
    if( ansi )
	printf("%c[41m",ESC);
}
void bgreen()
{
    if( ansi )
	printf("%c[42m",ESC);
}
void byellow()
{
    if( ansi )
	printf("%c[43m",ESC);
}
void bblue()
{
    if( ansi )
	printf("%c[44m",ESC);
}
void bmagenta()
{
    if( ansi )
	printf("%c[45m",ESC);
}
void bcyan()
{
    if( ansi )
	printf("%c[46m",ESC);
}
void bwhite()
{
    if( ansi )
	printf("%c[47m",ESC);
}

/*----------- Cursor position ---------------------------*/

void locate( x , y )
int x, y;
{
    if(ansi)
	printf("%c[%d;%dH",ESC,y,x);
}

void up(nb)          /* Cursor Up default 1 */
int nb;
{
    if ( ansi )
    {
        if( ! nb ) nb = 1 ;
        printf("%c[%dA",ESC,nb);
    }
}

void dn(nb)        /* Cursor down default 1 */
int nb;
{
    if ( ansi )
    {
        if( ! nb ) nb = 1 ;
        printf("%c[%dB",ESC,nb);
    }
}

void right(nb)        /* Cursor right default 1 */
int nb;
{
    if ( ansi )
    {
        if( ! nb ) nb = 1 ;
        printf("%c[%dC",ESC,nb);
    }
}

void left(nb)        /* Cursor left default 1 */
int nb;
{
    if ( ansi )
    {
        if( ! nb ) nb = 1 ;
        printf("%c[%dD",ESC,nb);
    }
}
/*-----------------------------------------------------------------------*/
