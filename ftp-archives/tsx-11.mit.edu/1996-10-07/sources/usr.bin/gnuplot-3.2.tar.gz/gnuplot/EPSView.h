/*
 * $Id: EPSView.h,v 3.24 1992/02/29 16:29:37 woo Exp woo $
 *
 * $Log: EPSView.h,v $
 * Revision 3.24  1992/02/29  16:29:37  woo
 * gnuplot3.2, beta 4
 *
 */

#import <appkit/View.h>

@interface EPSView:View {}

+ new;

@end

