#ifndef lint
static char *RCSid = "$Id: EPSView.m,v 3.24 1992/02/29 16:23:41 woo Exp woo $";
#endif

/*
 * $Log: EPSView.m,v $
# Revision 3.24  1992/02/29  16:23:41  woo
# gnuplot3.2, beta 4
#
 * Revision 3.23  1992/02/21  20:18:16  woo
 * gnuplot3.2, beta 3
 *
 */

#import "EPSView.h"

@implementation EPSView

+ new
{
	self = [super new];
	return self;
}

@end
