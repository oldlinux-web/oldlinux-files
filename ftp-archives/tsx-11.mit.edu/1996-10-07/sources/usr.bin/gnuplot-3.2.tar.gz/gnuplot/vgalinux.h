#ifndef VGALINUX_H
#define VGALINUX_H

#define TEXT 	     0
#define G320x200x16  1
#define G640x200x16  2
#define G640x350x16  3
#define G640x480x16  4
#define G320x200x256 5
#define G320x240x256 6
#define G320x400x256 7
#define G360x480x256 8

int vga_setmode(int mode);
int vga_clear();
int vga_getxdim();
int vga_getydim();
int vga_getcolors();

int vga_screenoff();
int vga_screenon();

int vga_setcolor(int color);
int vga_setpalette(int index, int red, int green, int blue);
int vga_drawpixel(int x, int y);
int vga_drawline(int x1, int y1, int x2, int y2);
int vga_drawscanline(int line, char* colors);

int vga_getch();

#endif /* VGALINUX_H */

