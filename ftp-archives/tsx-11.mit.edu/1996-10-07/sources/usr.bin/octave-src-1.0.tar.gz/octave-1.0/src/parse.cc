
/*  A Bison parser, made from parse.y with Bison version GNU Bison version 1.22
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	EXPR_AND	258
#define	EXPR_OR	259
#define	EXPR_NOT	260
#define	EXPR_LT	261
#define	EXPR_LE	262
#define	EXPR_EQ	263
#define	EXPR_NE	264
#define	EXPR_GE	265
#define	EXPR_GT	266
#define	LEFTDIV	267
#define	EMUL	268
#define	EDIV	269
#define	ELEFTDIV	270
#define	QUOTE	271
#define	TRANSPOSE	272
#define	PLUS_PLUS	273
#define	MINUS_MINUS	274
#define	POW	275
#define	EPOW	276
#define	NUM	277
#define	IMAG_NUM	278
#define	NAME	279
#define	SCREW	280
#define	END	281
#define	PLOT	282
#define	TEXT	283
#define	STYLE	284
#define	FOR	285
#define	WHILE	286
#define	IF	287
#define	ELSEIF	288
#define	ELSE	289
#define	BREAK	290
#define	CONTINUE	291
#define	FUNC_RET	292
#define	FCN	293
#define	SCREW_TWO	294
#define	GLOBAL	295
#define	ELLIPSIS	296
#define	END_OF_INPUT	297
#define	USING	298
#define	TITLE	299
#define	WITH	300
#define	COLON	301
#define	OPEN_BRACE	302
#define	CLOSE_BRACE	303
#define	UNARY	304

#line 28 "parse.y"

#define YYDEBUG 1

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "SLStack.h"

#include "Matrix.h"

#include "error.h"
#include "variables.h"
#include "octave-hist.h"
#include "user-prefs.h"
#include "input.h"
#include "utils.h"
#include "tree.h"
#include "symtab.h"
#include "builtins.h"
#include "octave.h"
#include "parse.h"
#include "lex.h"
#include "token.h"

// Nonzero means we're in the middle of defining a function.
int defining_func = 0;

// Nonzero means we're in the middle of defining a loop.
int looping = 0;

// Nonzero means we're in the middle of defining a conditional expression.
int iffing = 0;

// Nonzero means we need to do some extra lookahead to avoid being
// screwed by bogus function syntax.
int maybe_screwed = 0;

// Nonzero means we need to do some extra lookahead to avoid being
// screwed by bogus function syntax.
int maybe_screwed_again = 0;

// Temporary symbol table pointer used to cope with bogus function syntax.
symbol_table *tmp_local_sym_tab = (symbol_table *) NULL;

// Stack to hold list of literal matrices.
SLStack <tree_matrix *> ml;

// A nonzero element corresponding to an element of ml means we just
// started reading a new matrix.  This should probably be part of a
// new struct for matrix lists... 
SLStack <int> mlnm;

// The current input line number.
int input_line_number = 0;

// The column of the current token.
int current_input_column = 1;

// Buffer for help text snagged from function files.
// Probably shouldn't be a fixed size...
char help_buf [HELP_BUF_LENGTH];

// Nonzero means we're working on a plot command.
int plotting = 0;

// Nonzero means we've seen something that means we must be past the
// range part of a plot command.
int past_plot_range = 0;

// Nonzero means we're looking at the range part of a plot command.
int in_plot_range = 0;

// Nonzero means we're looking at the using part of a plot command.
int in_plot_using = 0;

// Nonzero means we're looking at the style part of a plot command.
int in_plot_style = 0;

// Check to see that end statements are properly matched.
static int check_end (token *tok, token::end_tok_type expected);

// Error mesages for mismatched end statements.
static void end_error (char *type, token::end_tok_type ettype, int l, int c);

// Generic error messages.
static void yyerror (char *s);

static tree *maybe_convert_to_ans_assign (tree *expr);
static void maybe_warn_assign_as_truth_value (tree *expr);

#define ABORT_PARSE \
  do \
    { \
      global_command = NULL_TREE; \
      reset_parser (); \
      yyerrok; \
      if (interactive) \
	YYACCEPT; \
      else \
	YYABORT; \
    } \
  while (0)


#line 137 "parse.y"
typedef union
{
// The type of the basic tokens returned by the lexer.
  token *tok_val;

// Types for the nonterminals we generate.
  tree *tree_type;
  tree_constant *tree_constant_type;
  tree_matrix *tree_matrix_type;
  tree_identifier *tree_identifier_type;
  tree_function *tree_function_type;
  tree_index_expression *tree_index_expression_type;
  tree_colon_expression *tree_colon_expression_type;
  tree_argument_list *tree_argument_list_type;
  tree_parameter_list *tree_parameter_list_type;
  tree_word_list *tree_word_list_type;
  tree_command *tree_command_type;
  tree_if_command *tree_if_command_type;
  tree_global_command *tree_global_command_type;
  tree_command_list *tree_command_list_type;
  tree_word_list_command *tree_word_list_command_type;
  tree_plot_command *tree_plot_command_type;
  tree_subplot_list *tree_subplot_list_type;
  tree_plot_limits *tree_plot_limits_type;
  tree_plot_range *tree_plot_range_type;
  tree_subplot_using *tree_subplot_using_type;
  tree_subplot_style *tree_subplot_style_type;
} YYSTYPE;

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		310
#define	YYFLAG		-32768
#define	YYNTBASE	63

#define YYTRANSLATE(x) ((unsigned)(x) <= 304 ? yytranslate[x] : 120)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,    57,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,    60,
    61,     7,     6,    56,     5,     2,     8,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     4,    55,     2,
     3,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
    59,     2,    62,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     9,    10,    11,
    12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
    22,    23,    24,    25,    26,    27,    28,    29,    30,    31,
    32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
    42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
    52,    53,    54,    58
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     2,     4,     6,     9,    12,    14,    17,    20,    23,
    27,    31,    33,    35,    37,    40,    43,    45,    48,    51,
    55,    59,    61,    64,    67,    69,    72,    75,    77,    79,
    82,    84,    87,    88,    90,    92,    95,    98,   100,   104,
   108,   110,   112,   114,   116,   118,   121,   125,   127,   130,
   134,   140,   145,   150,   154,   157,   159,   163,   165,   168,
   170,   172,   174,   177,   180,   183,   186,   189,   192,   196,
   200,   204,   208,   212,   216,   218,   221,   224,   228,   231,
   234,   238,   244,   245,   247,   250,   254,   256,   260,   264,
   270,   271,   273,   279,   287,   293,   302,   309,   319,   321,
   323,   325,   331,   338,   339,   341,   343,   345,   347,   350,
   353,   356,   357,   361,   368,   372,   374,   376,   379,   382,
   385,   388,   392,   396,   400,   404,   408,   412,   416,   420,
   424,   428,   432,   436,   440,   444,   448,   452,   456,   460,
   462,   464,   466,   468,   472,   474,   476,   479,   483,   485,
   488,   491,   494,   497,   500,   504,   508,   511,   513,   515,
   518,   519,   520,   521,   522,   527,   532,   538,   544,   549,
   553,   558,   563,   567,   569,   571,   573,   578,   582,   585,
   588,   591,   596,   599,   603,   606,   610,   612,   614,   616,
   620,   622,   626,   631,   633,   636,   640,   642,   645
};

static const short yyrhs[] = {    57,
     0,    48,     0,    64,     0,    64,    57,     0,    64,    48,
     0,     1,     0,     1,    57,     0,     1,    48,     0,    64,
     1,     0,    64,     1,    57,     0,    64,     1,    48,     0,
    66,     0,    67,     0,    65,     0,    65,    66,     0,    65,
    67,     0,    73,     0,    66,    73,     0,    67,    73,     0,
    65,    66,    73,     0,    65,    67,    73,     0,    55,     0,
    66,    56,     0,    66,    55,     0,    56,     0,    67,    55,
     0,    67,    56,     0,    56,     0,    57,     0,    68,    92,
     0,    55,     0,    69,    92,     0,     0,    71,     0,    72,
     0,    72,    68,     0,    72,    69,     0,    73,     0,    72,
    68,    73,     0,    72,    69,    73,     0,    74,     0,    89,
     0,    85,     0,   105,     0,    86,     0,    33,    77,     0,
    33,    75,    77,     0,    76,     0,    76,    76,     0,    76,
    76,    76,     0,    53,    94,    52,    94,    54,     0,    53,
    52,    94,    54,     0,    53,    94,    52,    54,     0,    53,
    52,    54,     0,    53,    54,     0,    78,     0,    77,    56,
    78,     0,    94,     0,    94,    79,     0,    80,     0,    82,
     0,    83,     0,    80,    82,     0,    82,    80,     0,    80,
    83,     0,    83,    80,     0,    82,    83,     0,    83,    82,
     0,    80,    82,    83,     0,    80,    83,    82,     0,    82,
    80,    83,     0,    82,    83,    80,     0,    83,    80,    82,
     0,    83,    82,    80,     0,    81,     0,    81,    94,     0,
    49,    94,     0,    81,    52,    94,     0,    50,    94,     0,
    51,    35,     0,    51,    35,    94,     0,    51,    35,    94,
    84,    94,     0,     0,    94,     0,    46,    87,     0,    46,
    87,    56,     0,    30,     0,    30,     3,    94,     0,    87,
    88,    30,     0,    87,    88,    30,     3,    94,     0,     0,
    56,     0,    37,    94,    91,    70,    32,     0,    36,   111,
     3,    94,    91,    70,    32,     0,    38,    94,    91,    70,
    32,     0,    38,    94,    91,    70,    40,    91,    70,    32,
     0,    38,    94,    91,    70,    90,    32,     0,    38,    94,
    91,    70,    90,    40,    91,    70,    32,     0,    41,     0,
    42,     0,    43,     0,    39,    91,    94,    91,    70,     0,
    90,    39,    91,    94,    91,    70,     0,     0,    92,     0,
    56,     0,    55,     0,    57,     0,    92,    56,     0,    92,
    55,     0,    92,    57,     0,     0,   111,     3,    94,     0,
    59,    93,   119,    45,     3,    94,     0,    28,     3,    94,
     0,    95,     0,    96,     0,   114,    24,     0,   114,    25,
     0,    95,    22,     0,    95,    23,     0,    95,    26,    95,
     0,    95,    27,    95,     0,    95,     6,    95,     0,    95,
     5,    95,     0,    95,     7,    95,     0,    95,     8,    95,
     0,    95,    19,    95,     0,    95,    20,    95,     0,    95,
    18,    95,     0,    95,    21,    95,     0,    95,    12,    95,
     0,    95,    13,    95,     0,    95,    14,    95,     0,    95,
    16,    95,     0,    95,    17,    95,     0,    95,    15,    95,
     0,    95,     9,    95,     0,    95,    10,    95,     0,    28,
     0,    29,     0,    34,     0,    98,     0,    60,    94,    61,
     0,   111,     0,   117,     0,    59,    62,     0,    59,    55,
    62,     0,    97,     0,    24,   114,     0,    25,   114,     0,
    11,    95,     0,     6,    95,     0,     5,    95,     0,    95,
     4,    95,     0,    97,     4,    95,     0,   114,    99,     0,
   100,     0,    34,     0,   100,    34,     0,     0,     0,     0,
     0,    44,   101,   104,   106,     0,    44,   101,   104,   108,
     0,    31,   103,   101,     3,   108,     0,   107,    62,   101,
     3,   108,     0,    59,   103,   102,   114,     0,   107,    56,
   114,     0,   114,   103,   102,   109,     0,   112,    91,    70,
   110,     0,    91,    70,   110,     0,    32,     0,    48,     0,
   114,     0,   114,    60,   115,    61,     0,   114,    60,    61,
     0,   114,    59,     0,    60,    61,     0,   113,    61,     0,
   113,    56,    47,    61,     0,    60,   114,     0,   113,    56,
   114,     0,    60,     1,     0,   113,    56,     1,     0,    30,
     0,   116,     0,     4,     0,   116,    56,     4,     0,    94,
     0,   116,    56,    94,     0,    59,    93,   118,    62,     0,
   119,     0,   118,    55,     0,   118,    55,   119,     0,    94,
     0,   119,    56,     0,   119,    56,    94,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   233,   239,   245,   251,   257,   263,   265,   267,   269,   271,
   273,   277,   279,   281,   283,   288,   292,   294,   296,   298,
   303,   307,   308,   309,   312,   313,   314,   317,   318,   319,
   322,   323,   326,   328,   331,   333,   335,   342,   344,   346,
   353,   355,   357,   359,   361,   365,   375,   387,   389,   391,
   395,   397,   399,   401,   403,   407,   409,   413,   415,   419,
   421,   423,   425,   427,   429,   431,   433,   435,   437,   439,
   441,   443,   445,   447,   451,   456,   463,   468,   472,   476,
   478,   480,   484,   487,   491,   493,   497,   502,   507,   512,
   519,   520,   528,   537,   545,   554,   564,   575,   590,   601,
   613,   625,   631,   638,   639,   642,   643,   644,   645,   646,
   647,   650,   654,   657,   681,   688,   692,   694,   697,   700,
   703,   706,   709,   712,   715,   718,   721,   724,   727,   730,
   733,   736,   739,   742,   745,   748,   751,   754,   757,   762,
   764,   766,   768,   770,   776,   778,   780,   785,   790,   792,
   795,   798,   801,   803,   808,   811,   822,   826,   830,   832,
   838,   842,   846,   850,   854,   860,   868,   877,   885,   887,
   891,   940,   945,   949,   957,   964,   969,   974,   980,   990,
   995,  1002,  1011,  1013,  1015,  1021,  1029,  1033,  1037,  1043,
  1054,  1056,  1067,  1076,  1077,  1078,  1081,  1097,  1098
};

static const char * const yytname[] = {   "$","error","$illegal.","'='","':'",
"'-'","'+'","'*'","'/'","EXPR_AND","EXPR_OR","EXPR_NOT","EXPR_LT","EXPR_LE",
"EXPR_EQ","EXPR_NE","EXPR_GE","EXPR_GT","LEFTDIV","EMUL","EDIV","ELEFTDIV","QUOTE",
"TRANSPOSE","PLUS_PLUS","MINUS_MINUS","POW","EPOW","NUM","IMAG_NUM","NAME","SCREW",
"END","PLOT","TEXT","STYLE","FOR","WHILE","IF","ELSEIF","ELSE","BREAK","CONTINUE",
"FUNC_RET","FCN","SCREW_TWO","GLOBAL","ELLIPSIS","END_OF_INPUT","USING","TITLE",
"WITH","COLON","OPEN_BRACE","CLOSE_BRACE","';'","','","'\\n'","UNARY","'['",
"'('","')'","']'","input","simple_list","simple_list1","semi_comma","comma_semi",
"comma_nl_sep","semi_sep","opt_list","list","list1","command","plot_command",
"ranges","ranges1","plot_command1","plot_command2","plot_options","using","using1",
"title","style","bogus_syntax","ans_expression","global_decl","global_decl1",
"optcomma","statement","elseif","optsep","sep","screwed_again","expression",
"simple_expr","simple_expr1","colon_expr","word_list_cmd","word_list","word_list1",
"g_symtab","local_symtab","safe","are_we_screwed","func_def","func_def1","func_def1a",
"func_def2","func_def3","fcn_end_or_eof","variable","param_list","param_list1",
"identifier","arg_list","arg_list1","matrix","rows","matrix_row",""
};
#endif

static const short yyr1[] = {     0,
    63,    63,    63,    63,    63,    63,    63,    63,    63,    63,
    63,    64,    64,    64,    64,    64,    65,    65,    65,    65,
    65,    66,    66,    66,    67,    67,    67,    68,    68,    68,
    69,    69,    70,    70,    71,    71,    71,    72,    72,    72,
    73,    73,    73,    73,    73,    74,    74,    75,    75,    75,
    76,    76,    76,    76,    76,    77,    77,    78,    78,    79,
    79,    79,    79,    79,    79,    79,    79,    79,    79,    79,
    79,    79,    79,    79,    80,    80,    81,    81,    82,    83,
    83,    83,    84,    85,    86,    86,    87,    87,    87,    87,
    88,    88,    89,    89,    89,    89,    89,    89,    89,    89,
    89,    90,    90,    91,    91,    92,    92,    92,    92,    92,
    92,    93,    94,    94,    94,    94,    95,    95,    95,    95,
    95,    95,    95,    95,    95,    95,    95,    95,    95,    95,
    95,    95,    95,    95,    95,    95,    95,    95,    95,    96,
    96,    96,    96,    96,    96,    96,    96,    96,    96,    96,
    96,    96,    96,    96,    97,    97,    98,    99,   100,   100,
   101,   102,   103,   104,   105,   105,   106,   106,   107,   107,
   108,   109,   109,   110,   110,   111,   111,   111,   111,   112,
   112,   112,   113,   113,   113,   113,   114,   115,   116,   116,
   116,   116,   117,   118,   118,   118,   119,   119,   119
};

static const short yyr2[] = {     0,
     1,     1,     1,     2,     2,     1,     2,     2,     2,     3,
     3,     1,     1,     1,     2,     2,     1,     2,     2,     3,
     3,     1,     2,     2,     1,     2,     2,     1,     1,     2,
     1,     2,     0,     1,     1,     2,     2,     1,     3,     3,
     1,     1,     1,     1,     1,     2,     3,     1,     2,     3,
     5,     4,     4,     3,     2,     1,     3,     1,     2,     1,
     1,     1,     2,     2,     2,     2,     2,     2,     3,     3,
     3,     3,     3,     3,     1,     2,     2,     3,     2,     2,
     3,     5,     0,     1,     2,     3,     1,     3,     3,     5,
     0,     1,     5,     7,     5,     8,     6,     9,     1,     1,
     1,     5,     6,     0,     1,     1,     1,     1,     2,     2,
     2,     0,     3,     6,     3,     1,     1,     2,     2,     2,
     2,     3,     3,     3,     3,     3,     3,     3,     3,     3,
     3,     3,     3,     3,     3,     3,     3,     3,     3,     1,
     1,     1,     1,     3,     1,     1,     2,     3,     1,     2,
     2,     2,     2,     2,     3,     3,     2,     1,     1,     2,
     0,     0,     0,     0,     4,     4,     5,     5,     4,     3,
     4,     4,     3,     1,     1,     1,     4,     3,     2,     2,
     2,     4,     2,     3,     2,     3,     1,     1,     1,     3,
     1,     3,     4,     1,     2,     3,     1,     2,     3
};

static const short yydefact[] = {     0,
     6,     0,     0,     0,     0,     0,   140,   141,   187,     0,
   142,     0,     0,     0,    99,   100,   101,   161,     0,     2,
    22,    25,     1,   112,     0,     0,    14,    12,    13,    17,
    41,    43,    45,    42,    84,   116,   117,   149,   143,    44,
   145,   176,   146,     8,     7,   140,   112,   154,   145,   153,
   152,   150,   151,     0,     0,     0,    48,    46,    56,    58,
     0,   176,   104,   104,   164,    87,    85,     0,   147,     0,
     0,     9,     5,     4,    15,    16,    24,    23,    18,    26,
    27,    19,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,   120,
   121,     0,     0,     0,     0,   118,   119,   159,   179,     0,
   157,   158,     0,   115,     0,    55,     0,    47,    49,     0,
     0,     0,     0,    59,    60,    75,    61,    62,     0,   107,
   106,   108,    33,   105,    33,     0,     0,    86,     0,   148,
   197,     0,   194,   144,    11,    10,    20,    21,   155,   125,
   124,   126,   127,   138,   139,   132,   133,   134,   137,   135,
   136,   130,   128,   129,   131,   122,   123,   156,   113,   189,
   178,   191,     0,   188,   160,   194,    54,     0,     0,    50,
    57,    77,    79,    80,    63,    65,     0,    76,    64,    67,
    66,    68,   104,     0,    34,    35,    38,   110,   109,   111,
     0,   163,   163,   165,     0,   166,   163,    88,    89,   195,
   193,     0,   198,   177,     0,    52,    53,     0,    81,    69,
    70,    78,    71,    72,    73,    74,    33,    93,    31,    28,
    29,    36,    37,    95,   104,   104,     0,   161,   162,     0,
   161,   162,     0,   196,     0,   199,   190,   192,    51,     0,
     0,    39,    30,    40,    32,     0,    33,    97,   104,   104,
     0,     0,   170,     0,   104,    90,   114,    82,    94,   104,
     0,     0,    33,     0,   169,     0,     0,    33,   171,   104,
     0,    33,    96,   104,     0,   167,   168,   185,   180,   183,
     0,    33,     0,   181,   102,    33,    98,   174,   175,   173,
     0,   186,     0,   184,   103,   172,   182,     0,     0,     0
};

static const short yydefgoto[] = {   308,
    26,    27,    28,    29,   232,   233,   194,   195,   196,   197,
    31,    56,    57,    58,    59,   124,   125,   126,   127,   128,
   250,    32,    33,    67,   139,    34,   237,   133,   134,    70,
    35,    36,    37,    38,    39,   111,   112,    65,   262,   238,
   136,    40,   204,   205,   206,   279,   300,    41,   280,   281,
    42,   173,   174,    43,   142,   143
};

static const short yypact[] = {   340,
     8,   615,   615,   615,    -1,    -1,    40,-32768,-32768,   173,
-32768,    -1,   652,   652,-32768,-32768,-32768,-32768,    27,-32768,
-32768,-32768,-32768,     6,   652,    14,    79,   429,   471,-32768,
-32768,-32768,-32768,-32768,-32768,   716,-32768,    49,-32768,-32768,
    67,    13,-32768,-32768,-32768,-32768,     6,   115,-32768,   115,
   115,-32768,-32768,   652,   555,   652,    28,    31,-32768,    64,
    81,   105,    95,    95,-32768,    90,    -7,    58,-32768,   652,
    62,    35,-32768,-32768,   429,   471,-32768,-32768,-32768,-32768,
-32768,-32768,   615,   615,   615,   615,   615,   615,   615,   615,
   615,   615,   615,   615,   615,   615,   615,   615,   615,-32768,
-32768,   615,   615,   615,   652,-32768,-32768,-32768,-32768,    30,
-32768,    92,   652,-32768,   563,-32768,    78,    31,    28,   652,
   652,   652,   104,-32768,   120,   600,    59,   123,   652,-32768,
-32768,-32768,   513,    98,   513,   -11,   652,   114,   116,-32768,
-32768,    23,   -17,-32768,-32768,-32768,-32768,-32768,   763,   383,
   383,    76,    76,   740,   740,   255,   255,   255,   255,   255,
   255,    76,    76,    76,    76,   115,   115,   763,-32768,-32768,
-32768,-32768,    87,   102,-32768,   118,-32768,   127,   607,-32768,
-32768,-32768,-32768,   652,   131,   135,   652,-32768,   131,   137,
   135,   137,    95,   155,-32768,   112,-32768,-32768,-32768,-32768,
    56,-32768,-32768,-32768,   -31,-32768,-32768,-32768,   185,   652,
-32768,   190,   652,-32768,   132,-32768,-32768,   140,   659,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,   513,-32768,-32768,-32768,
-32768,   387,   387,-32768,    95,    95,    65,-32768,-32768,    -1,
-32768,-32768,   652,   118,   652,-32768,-32768,-32768,-32768,   652,
   163,-32768,    98,-32768,    98,   652,   513,-32768,    95,    95,
   193,    -1,-32768,   196,    72,-32768,-32768,-32768,-32768,    95,
   168,   652,   513,    -1,-32768,    -1,    15,   513,-32768,    95,
    51,   513,-32768,    95,   172,-32768,-32768,-32768,-32768,-32768,
    -6,   513,    16,-32768,-32768,   513,-32768,-32768,-32768,-32768,
    -6,-32768,   144,-32768,-32768,-32768,-32768,   208,   210,-32768
};

static const short yypgoto[] = {-32768,
-32768,-32768,   191,   194,-32768,-32768,  -133,-32768,-32768,     4,
-32768,-32768,   -52,   156,   100,-32768,  -115,-32768,  -117,  -103,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,   -46,   -56,   175,
    -4,   240,-32768,-32768,-32768,-32768,-32768,  -211,   -19,  -163,
-32768,-32768,-32768,-32768,  -155,-32768,   -74,   213,-32768,-32768,
    -5,-32768,-32768,-32768,-32768,  -110
};


#define	YYLAST		790


static const short yytable[] = {    52,
    53,   201,   176,    30,   119,    60,    62,   185,    63,    64,
   192,   189,   191,    -3,    72,   288,   302,   135,     9,   202,
    71,   186,   -91,   190,   240,   298,   261,   212,     9,   264,
   241,    79,    82,   170,     2,     3,   106,   107,   213,   239,
     4,   299,    54,   242,     9,     9,   108,   203,   138,   114,
   117,    60,   104,     5,     6,    44,    66,     7,     8,     9,
    68,    73,   303,    11,    45,   141,   180,    69,   221,   105,
    74,   109,   110,   225,   224,   289,   226,   210,   147,   148,
    55,   220,   145,   129,   211,   223,   120,   234,    24,    25,
   171,   146,   137,   251,   235,   236,   258,   100,   101,   244,
   169,   102,   103,   259,   260,   172,   293,   121,   141,   123,
   178,   294,   121,   122,   123,    60,   182,   183,   286,   140,
   287,   188,   144,   271,   193,   175,   130,   131,   132,   179,
   207,   277,   208,    21,    22,   247,     2,     3,   184,   285,
   102,   103,     4,   -92,   291,   209,   227,   214,   295,   130,
   131,   132,   198,   199,   200,     5,     6,   215,   301,     7,
     8,     9,   305,   109,   110,    11,   229,   230,   231,   122,
   123,   121,   122,   213,   218,   253,   255,     2,     3,   219,
   216,   123,   222,     4,   122,   121,   228,   243,   256,   257,
    24,    25,   245,   249,   269,   274,     5,     6,   276,   283,
     7,     8,     9,   297,   307,   141,    11,   309,   246,   310,
   248,   118,   272,   273,    49,    49,    49,    75,   278,   181,
    76,   113,   265,   282,    61,    55,   306,     0,     0,     0,
     0,    24,    25,   292,   263,   252,   254,   296,   266,     0,
   267,    48,    50,    51,     0,   268,     0,     0,     0,     0,
     0,   270,     0,     0,     0,     0,   275,     0,    83,    84,
    85,    86,    87,     0,     0,     0,     0,   284,   207,     0,
   207,   290,    96,    97,    98,    99,   100,   101,     0,     0,
   102,   103,     0,     0,     0,     0,     0,   304,     0,     0,
     0,     0,     0,     0,     0,    49,    49,    49,    49,    49,
    49,    49,    49,    49,    49,    49,    49,    49,    49,    49,
    49,    49,     0,     0,    49,    49,    49,     0,     0,     0,
     0,     0,   149,   150,   151,   152,   153,   154,   155,   156,
   157,   158,   159,   160,   161,   162,   163,   164,   165,     0,
     1,   166,   167,   168,     2,     3,     0,     0,     0,     0,
     4,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     5,     6,     0,     0,     7,     8,     9,
     0,     0,    10,    11,     0,    12,    13,    14,     0,     0,
    15,    16,    17,    18,     0,    19,     0,    20,     0,    86,
    87,     2,     3,     0,    21,    22,    23,     4,    24,    25,
    96,    97,    98,    99,   100,   101,     0,     0,   102,   103,
     5,     6,     0,     0,     7,     8,     9,     0,     0,    10,
    11,     0,    12,    13,    14,     0,     0,    15,    16,    17,
    18,     0,    19,     2,     3,     0,     0,     0,     0,     4,
     0,   130,   131,   132,     0,    24,    25,     0,     0,     0,
     0,     0,     5,     6,     0,     0,     7,     8,     9,     0,
     0,    10,    11,     0,    12,    13,    14,     0,     0,    15,
    16,    17,    18,     0,    19,     2,     3,     0,     0,     0,
     0,     4,     0,    77,    78,     0,     0,    24,    25,     0,
     0,     0,     0,     0,     5,     6,     0,     0,     7,     8,
     9,     0,     0,    10,    11,     0,    12,    13,    14,     0,
     0,    15,    16,    17,    18,     0,    19,     2,     3,     0,
     0,     0,     0,     4,     0,    80,    81,     0,     0,    24,
    25,     0,     0,     0,     0,     0,     5,     6,     0,     0,
     7,     8,     9,     0,     0,    10,    11,     0,    12,    13,
    14,     0,     0,    15,    16,    17,    18,     0,    19,     2,
     3,     0,     0,     0,     0,     4,     0,     2,     3,     0,
     0,    24,    25,     4,     0,     0,     0,     0,     5,     6,
     0,     0,     7,     8,     9,     0,     5,     6,    11,     0,
     7,     8,     9,     0,     0,     0,    11,     0,     0,     0,
     0,     0,     0,     0,     2,     3,   115,     0,   116,     0,
     4,     2,     3,    24,    25,     0,   177,     4,     0,     2,
     3,    24,    25,     5,     6,     4,     0,     7,     8,     9,
     5,     6,     0,    11,     7,     8,     9,     0,     5,     6,
    11,     0,    46,     8,     9,     0,     0,     0,    11,     0,
     0,   187,     0,     0,     0,     0,     2,     3,    24,    25,
   217,     0,     4,   -83,   -83,    24,    25,     0,     0,   -83,
     0,     0,     0,    47,    25,     5,     6,     0,     0,     7,
     8,     9,   -83,   -83,     0,    11,   -83,   -83,   -83,     0,
     0,     0,   -83,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    24,    25,     0,     0,     0,     0,     0,   -83,   -83,    83,
    84,    85,    86,    87,    88,    89,     0,    90,    91,    92,
    93,    94,    95,    96,    97,    98,    99,   100,   101,     0,
     0,   102,   103,    83,    84,    85,    86,    87,     0,     0,
     0,    90,    91,    92,    93,    94,    95,    96,    97,    98,
    99,   100,   101,     0,     0,   102,   103,    84,    85,    86,
    87,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    96,    97,    98,    99,   100,   101,     0,     0,   102,   103
};

static const short yycheck[] = {     5,
     6,   135,   113,     0,    57,    10,    12,   125,    13,    14,
   128,   127,   128,     0,     1,     1,     1,    64,    30,    31,
    25,   125,    30,   127,    56,    32,   238,    45,    30,   241,
    62,    28,    29,     4,     5,     6,    24,    25,    56,   203,
    11,    48,     3,   207,    30,    30,    34,    59,    56,    54,
    55,    56,     4,    24,    25,    48,    30,    28,    29,    30,
    55,    48,    47,    34,    57,    70,   119,    62,   186,     3,
    57,    59,    60,   191,   190,    61,   192,    55,    75,    76,
    53,   185,    48,     3,    62,   189,    56,    32,    59,    60,
    61,    57,     3,   227,    39,    40,    32,    22,    23,   210,
   105,    26,    27,    39,    40,   110,    56,    49,   113,    51,
   115,    61,    49,    50,    51,   120,   121,   122,   274,    62,
   276,   126,    61,   257,   129,    34,    55,    56,    57,    52,
   136,    60,   137,    55,    56,     4,     5,     6,    35,   273,
    26,    27,    11,    30,   278,    30,   193,    61,   282,    55,
    56,    57,    55,    56,    57,    24,    25,    56,   292,    28,
    29,    30,   296,    59,    60,    34,    55,    56,    57,    50,
    51,    49,    50,    56,   179,   232,   233,     5,     6,   184,
    54,    51,   187,    11,    50,    49,    32,     3,   235,   236,
    59,    60,     3,    54,    32,     3,    24,    25,     3,    32,
    28,    29,    30,    32,    61,   210,    34,     0,   213,     0,
   215,    56,   259,   260,     2,     3,     4,    27,   265,   120,
    27,    47,   242,   270,    12,    53,   301,    -1,    -1,    -1,
    -1,    59,    60,   280,   240,   232,   233,   284,   243,    -1,
   245,     2,     3,     4,    -1,   250,    -1,    -1,    -1,    -1,
    -1,   256,    -1,    -1,    -1,    -1,   262,    -1,     4,     5,
     6,     7,     8,    -1,    -1,    -1,    -1,   272,   274,    -1,
   276,   277,    18,    19,    20,    21,    22,    23,    -1,    -1,
    26,    27,    -1,    -1,    -1,    -1,    -1,   293,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    83,    84,    85,    86,    87,
    88,    89,    90,    91,    92,    93,    94,    95,    96,    97,
    98,    99,    -1,    -1,   102,   103,   104,    -1,    -1,    -1,
    -1,    -1,    83,    84,    85,    86,    87,    88,    89,    90,
    91,    92,    93,    94,    95,    96,    97,    98,    99,    -1,
     1,   102,   103,   104,     5,     6,    -1,    -1,    -1,    -1,
    11,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    24,    25,    -1,    -1,    28,    29,    30,
    -1,    -1,    33,    34,    -1,    36,    37,    38,    -1,    -1,
    41,    42,    43,    44,    -1,    46,    -1,    48,    -1,     7,
     8,     5,     6,    -1,    55,    56,    57,    11,    59,    60,
    18,    19,    20,    21,    22,    23,    -1,    -1,    26,    27,
    24,    25,    -1,    -1,    28,    29,    30,    -1,    -1,    33,
    34,    -1,    36,    37,    38,    -1,    -1,    41,    42,    43,
    44,    -1,    46,     5,     6,    -1,    -1,    -1,    -1,    11,
    -1,    55,    56,    57,    -1,    59,    60,    -1,    -1,    -1,
    -1,    -1,    24,    25,    -1,    -1,    28,    29,    30,    -1,
    -1,    33,    34,    -1,    36,    37,    38,    -1,    -1,    41,
    42,    43,    44,    -1,    46,     5,     6,    -1,    -1,    -1,
    -1,    11,    -1,    55,    56,    -1,    -1,    59,    60,    -1,
    -1,    -1,    -1,    -1,    24,    25,    -1,    -1,    28,    29,
    30,    -1,    -1,    33,    34,    -1,    36,    37,    38,    -1,
    -1,    41,    42,    43,    44,    -1,    46,     5,     6,    -1,
    -1,    -1,    -1,    11,    -1,    55,    56,    -1,    -1,    59,
    60,    -1,    -1,    -1,    -1,    -1,    24,    25,    -1,    -1,
    28,    29,    30,    -1,    -1,    33,    34,    -1,    36,    37,
    38,    -1,    -1,    41,    42,    43,    44,    -1,    46,     5,
     6,    -1,    -1,    -1,    -1,    11,    -1,     5,     6,    -1,
    -1,    59,    60,    11,    -1,    -1,    -1,    -1,    24,    25,
    -1,    -1,    28,    29,    30,    -1,    24,    25,    34,    -1,
    28,    29,    30,    -1,    -1,    -1,    34,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,     5,     6,    52,    -1,    54,    -1,
    11,     5,     6,    59,    60,    -1,    54,    11,    -1,     5,
     6,    59,    60,    24,    25,    11,    -1,    28,    29,    30,
    24,    25,    -1,    34,    28,    29,    30,    -1,    24,    25,
    34,    -1,    28,    29,    30,    -1,    -1,    -1,    34,    -1,
    -1,    52,    -1,    -1,    -1,    -1,     5,     6,    59,    60,
    54,    -1,    11,     5,     6,    59,    60,    -1,    -1,    11,
    -1,    -1,    -1,    59,    60,    24,    25,    -1,    -1,    28,
    29,    30,    24,    25,    -1,    34,    28,    29,    30,    -1,
    -1,    -1,    34,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    59,    60,    -1,    -1,    -1,    -1,    -1,    59,    60,     4,
     5,     6,     7,     8,     9,    10,    -1,    12,    13,    14,
    15,    16,    17,    18,    19,    20,    21,    22,    23,    -1,
    -1,    26,    27,     4,     5,     6,     7,     8,    -1,    -1,
    -1,    12,    13,    14,    15,    16,    17,    18,    19,    20,
    21,    22,    23,    -1,    -1,    26,    27,     5,     6,     7,
     8,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    18,    19,    20,    21,    22,    23,    -1,    -1,    26,    27
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/local/gnu/lib/bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#define YYLEX		yylex(&yylval, &yylloc)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_bcopy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 184 "/usr/local/gnu/lib/bison.simple"
int
yyparse()
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_bcopy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_bcopy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_bcopy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
#line 234 "parse.y"
{
		    global_command = NULL_TREE;
		    promptflag = 1;
		    YYACCEPT;
		  ;
    break;}
case 2:
#line 240 "parse.y"
{
		    global_command = NULL_TREE;
		    promptflag = 1;
		    YYABORT;
		  ;
    break;}
case 3:
#line 246 "parse.y"
{
		    global_command = yyvsp[0].tree_command_list_type;
		    promptflag = 1;
		    YYACCEPT;
		  ;
    break;}
case 4:
#line 252 "parse.y"
{
		    global_command = yyvsp[-1].tree_command_list_type;
		    promptflag = 1;
		    YYACCEPT;
		  ;
    break;}
case 5:
#line 258 "parse.y"
{
		    global_command = yyvsp[-1].tree_command_list_type;
		    promptflag = 1;
		    YYACCEPT;
		  ;
    break;}
case 6:
#line 264 "parse.y"
{ ABORT_PARSE; ;
    break;}
case 7:
#line 266 "parse.y"
{ ABORT_PARSE; ;
    break;}
case 8:
#line 268 "parse.y"
{ ABORT_PARSE; ;
    break;}
case 9:
#line 270 "parse.y"
{ ABORT_PARSE; ;
    break;}
case 10:
#line 272 "parse.y"
{ ABORT_PARSE; ;
    break;}
case 11:
#line 274 "parse.y"
{ ABORT_PARSE; ;
    break;}
case 12:
#line 278 "parse.y"
{ yyval.tree_command_list_type = (tree_command_list *) NULL; ;
    break;}
case 13:
#line 280 "parse.y"
{ yyval.tree_command_list_type = (tree_command_list *) NULL; ;
    break;}
case 14:
#line 282 "parse.y"
{ yyval.tree_command_list_type = yyvsp[0].tree_command_list_type->reverse (); ;
    break;}
case 15:
#line 284 "parse.y"
{
		    yyvsp[-1].tree_command_list_type->set_print_flag (0);
		    yyval.tree_command_list_type = yyvsp[-1].tree_command_list_type->reverse ();
		  ;
    break;}
case 16:
#line 289 "parse.y"
{ yyval.tree_command_list_type = yyvsp[-1].tree_command_list_type->reverse (); ;
    break;}
case 17:
#line 293 "parse.y"
{ yyval.tree_command_list_type = new tree_command_list (yyvsp[0].tree_type); ;
    break;}
case 18:
#line 295 "parse.y"
{ yyval.tree_command_list_type = new tree_command_list (yyvsp[0].tree_type); ;
    break;}
case 19:
#line 297 "parse.y"
{ yyval.tree_command_list_type = new tree_command_list (yyvsp[0].tree_type); ;
    break;}
case 20:
#line 299 "parse.y"
{
		    yyvsp[-2].tree_command_list_type->set_print_flag (0);
		    yyval.tree_command_list_type = yyvsp[-2].tree_command_list_type->chain (yyvsp[0].tree_type);
		  ;
    break;}
case 21:
#line 304 "parse.y"
{ yyval.tree_command_list_type = yyvsp[-2].tree_command_list_type->chain (yyvsp[0].tree_type); ;
    break;}
case 33:
#line 327 "parse.y"
{ yyval.tree_command_list_type = new tree_command_list (); ;
    break;}
case 34:
#line 329 "parse.y"
{ yyval.tree_command_list_type = yyvsp[0].tree_command_list_type; ;
    break;}
case 35:
#line 332 "parse.y"
{ yyval.tree_command_list_type = yyvsp[0].tree_command_list_type->reverse (); ;
    break;}
case 36:
#line 334 "parse.y"
{ yyval.tree_command_list_type = yyvsp[-1].tree_command_list_type->reverse (); ;
    break;}
case 37:
#line 336 "parse.y"
{
		    yyvsp[-1].tree_command_list_type->set_print_flag (0);
		    yyval.tree_command_list_type = yyvsp[-1].tree_command_list_type->reverse ();
		  ;
    break;}
case 38:
#line 343 "parse.y"
{ yyval.tree_command_list_type = new tree_command_list (yyvsp[0].tree_type); ;
    break;}
case 39:
#line 345 "parse.y"
{ yyval.tree_command_list_type = yyvsp[-2].tree_command_list_type->chain (yyvsp[0].tree_type); ;
    break;}
case 40:
#line 347 "parse.y"
{
		    yyvsp[-2].tree_command_list_type->set_print_flag (0);
		    yyval.tree_command_list_type = yyvsp[-2].tree_command_list_type->chain (yyvsp[0].tree_type);
		  ;
    break;}
case 41:
#line 354 "parse.y"
{ yyval.tree_type = yyvsp[0].tree_plot_command_type; ;
    break;}
case 42:
#line 356 "parse.y"
{ yyval.tree_type = yyvsp[0].tree_command_type; ;
    break;}
case 43:
#line 358 "parse.y"
{ yyval.tree_type = yyvsp[0].tree_type; ;
    break;}
case 44:
#line 360 "parse.y"
{ yyval.tree_type = yyvsp[0].tree_function_type; ;
    break;}
case 45:
#line 362 "parse.y"
{ yyval.tree_type = yyvsp[0].tree_global_command_type; ;
    break;}
case 46:
#line 366 "parse.y"
{
		    tree_subplot_list *tmp = yyvsp[0].tree_subplot_list_type->reverse ();
		    yyval.tree_plot_command_type = new tree_plot_command (tmp, yyvsp[-1].tok_val->pttype ());
		    plotting = 0;
		    past_plot_range = 0;
		    in_plot_range = 0;
		    in_plot_using = 0;
		    in_plot_style = 0;
		  ;
    break;}
case 47:
#line 376 "parse.y"
{
		    tree_subplot_list *tmp = yyvsp[0].tree_subplot_list_type->reverse ();
		    yyval.tree_plot_command_type = new tree_plot_command (tmp, yyvsp[-1].tree_plot_limits_type, yyvsp[-2].tok_val->pttype ());
		    plotting = 0;
		    past_plot_range = 0;
		    in_plot_range = 0;
		    in_plot_using = 0;
		    in_plot_style = 0;
		  ;
    break;}
case 48:
#line 388 "parse.y"
{ yyval.tree_plot_limits_type = new tree_plot_limits (yyvsp[0].tree_plot_range_type); ;
    break;}
case 49:
#line 390 "parse.y"
{ yyval.tree_plot_limits_type = new tree_plot_limits (yyvsp[-1].tree_plot_range_type, yyvsp[0].tree_plot_range_type); ;
    break;}
case 50:
#line 392 "parse.y"
{ yyval.tree_plot_limits_type = new tree_plot_limits (yyvsp[-2].tree_plot_range_type, yyvsp[-1].tree_plot_range_type, yyvsp[0].tree_plot_range_type); ;
    break;}
case 51:
#line 396 "parse.y"
{ yyval.tree_plot_range_type = new tree_plot_range (yyvsp[-3].tree_type, yyvsp[-1].tree_type); ;
    break;}
case 52:
#line 398 "parse.y"
{ yyval.tree_plot_range_type = new tree_plot_range (NULL, yyvsp[-1].tree_type); ;
    break;}
case 53:
#line 400 "parse.y"
{ yyval.tree_plot_range_type = new tree_plot_range (yyvsp[-2].tree_type, NULL); ;
    break;}
case 54:
#line 402 "parse.y"
{ yyval.tree_plot_range_type = new tree_plot_range (); ;
    break;}
case 55:
#line 404 "parse.y"
{ yyval.tree_plot_range_type = new tree_plot_range (); ;
    break;}
case 56:
#line 408 "parse.y"
{ yyval.tree_subplot_list_type = yyvsp[0].tree_subplot_list_type; ;
    break;}
case 57:
#line 410 "parse.y"
{ yyval.tree_subplot_list_type = yyvsp[-2].tree_subplot_list_type->chain (yyvsp[0].tree_subplot_list_type); ;
    break;}
case 58:
#line 414 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (yyvsp[0].tree_type); ;
    break;}
case 59:
#line 416 "parse.y"
{ yyval.tree_subplot_list_type = yyvsp[0].tree_subplot_list_type->set_data (yyvsp[-1].tree_type); ;
    break;}
case 60:
#line 420 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (yyvsp[0].tree_subplot_using_type, NULL, NULL); ;
    break;}
case 61:
#line 422 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (NULL, yyvsp[0].tree_type, NULL); ;
    break;}
case 62:
#line 424 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (NULL, NULL, yyvsp[0].tree_subplot_style_type); ;
    break;}
case 63:
#line 426 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (yyvsp[-1].tree_subplot_using_type, yyvsp[0].tree_type, NULL); ;
    break;}
case 64:
#line 428 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (yyvsp[0].tree_subplot_using_type, yyvsp[-1].tree_type, NULL); ;
    break;}
case 65:
#line 430 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (yyvsp[-1].tree_subplot_using_type, NULL, yyvsp[0].tree_subplot_style_type); ;
    break;}
case 66:
#line 432 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (yyvsp[0].tree_subplot_using_type, NULL, yyvsp[-1].tree_subplot_style_type); ;
    break;}
case 67:
#line 434 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (NULL, yyvsp[-1].tree_type, yyvsp[0].tree_subplot_style_type); ;
    break;}
case 68:
#line 436 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (NULL, yyvsp[0].tree_type, yyvsp[-1].tree_subplot_style_type); ;
    break;}
case 69:
#line 438 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (yyvsp[-2].tree_subplot_using_type, yyvsp[-1].tree_type, yyvsp[0].tree_subplot_style_type); ;
    break;}
case 70:
#line 440 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (yyvsp[-2].tree_subplot_using_type, yyvsp[0].tree_type, yyvsp[-1].tree_subplot_style_type); ;
    break;}
case 71:
#line 442 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (yyvsp[-1].tree_subplot_using_type, yyvsp[-2].tree_type, yyvsp[0].tree_subplot_style_type); ;
    break;}
case 72:
#line 444 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (yyvsp[0].tree_subplot_using_type, yyvsp[-2].tree_type, yyvsp[-1].tree_subplot_style_type); ;
    break;}
case 73:
#line 446 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (yyvsp[-1].tree_subplot_using_type, yyvsp[0].tree_type, yyvsp[-2].tree_subplot_style_type); ;
    break;}
case 74:
#line 448 "parse.y"
{ yyval.tree_subplot_list_type = new tree_subplot_list (yyvsp[0].tree_subplot_using_type, yyvsp[-1].tree_type, yyvsp[-2].tree_subplot_style_type); ;
    break;}
case 75:
#line 452 "parse.y"
{
		    yyval.tree_subplot_using_type = yyvsp[0].tree_subplot_using_type;
		    in_plot_using = 0;
		  ;
    break;}
case 76:
#line 457 "parse.y"
{
		    yyval.tree_subplot_using_type = yyvsp[-1].tree_subplot_using_type->set_format (yyvsp[0].tree_type);
		    in_plot_using = 0;
		  ;
    break;}
case 77:
#line 464 "parse.y"
{
		    tree_subplot_using *tmp = new tree_subplot_using ();
		    yyval.tree_subplot_using_type = tmp->add_qualifier (yyvsp[0].tree_type);
		  ;
    break;}
case 78:
#line 469 "parse.y"
{ yyval.tree_subplot_using_type = yyvsp[-2].tree_subplot_using_type->add_qualifier (yyvsp[0].tree_type); ;
    break;}
case 79:
#line 473 "parse.y"
{ yyval.tree_type = yyvsp[0].tree_type; ;
    break;}
case 80:
#line 477 "parse.y"
{ yyval.tree_subplot_style_type = new tree_subplot_style (yyvsp[0].tok_val->string ()); ;
    break;}
case 81:
#line 479 "parse.y"
{ yyval.tree_subplot_style_type = new tree_subplot_style (yyvsp[-1].tok_val->string (), yyvsp[0].tree_type); ;
    break;}
case 82:
#line 481 "parse.y"
{ yyval.tree_subplot_style_type = new tree_subplot_style (yyvsp[-3].tok_val->string (), yyvsp[-2].tree_type, yyvsp[0].tree_type); ;
    break;}
case 84:
#line 488 "parse.y"
{ yyval.tree_type = maybe_convert_to_ans_assign (yyvsp[0].tree_type); ;
    break;}
case 85:
#line 492 "parse.y"
{ yyval.tree_global_command_type = yyvsp[0].tree_global_command_type->reverse (); ;
    break;}
case 86:
#line 494 "parse.y"
{ yyval.tree_global_command_type = yyvsp[-1].tree_global_command_type->reverse (); ;
    break;}
case 87:
#line 498 "parse.y"
{
		    yyval.tree_global_command_type = new tree_global_command
			   (yyvsp[0].tok_val->sym_rec (), yyvsp[0].tok_val->line (), yyvsp[0].tok_val->column ());
		  ;
    break;}
case 88:
#line 503 "parse.y"
{
		    yyval.tree_global_command_type = new tree_global_command
			   (yyvsp[-2].tok_val->sym_rec (), yyvsp[0].tree_type, yyvsp[-2].tok_val->line (), yyvsp[-2].tok_val->column ());
		  ;
    break;}
case 89:
#line 508 "parse.y"
{
		    yyval.tree_global_command_type = yyvsp[-2].tree_global_command_type->chain (yyvsp[0].tok_val->sym_rec (), yyvsp[0].tok_val->line (),
				    yyvsp[0].tok_val->column ());
		  ;
    break;}
case 90:
#line 513 "parse.y"
{
		    yyval.tree_global_command_type = yyvsp[-4].tree_global_command_type->chain (yyvsp[-2].tok_val->sym_rec (), yyvsp[0].tree_type, yyvsp[-2].tok_val->line (),
				    yyvsp[-2].tok_val->column ());
		  ;
    break;}
case 92:
#line 521 "parse.y"
{
		    if (user_pref.warn_comma_in_global_decl)
		      warning ("comma in global declaration not\
 interpreted as a command separator");
		  ;
    break;}
case 93:
#line 529 "parse.y"
{
		    maybe_warn_assign_as_truth_value (yyvsp[-3].tree_type);
		    if (check_end (yyvsp[0].tok_val, token::while_end))
		      ABORT_PARSE;
		    looping--;
		    yyval.tree_command_type = new tree_while_command (yyvsp[-3].tree_type, yyvsp[-1].tree_command_list_type, yyvsp[-4].tok_val->line (),
						 yyvsp[-4].tok_val->column ());
		  ;
    break;}
case 94:
#line 538 "parse.y"
{
		    if (check_end (yyvsp[0].tok_val, token::for_end))
		      ABORT_PARSE;
		    looping--;
		    yyval.tree_command_type = new tree_for_command (yyvsp[-5].tree_index_expression_type, yyvsp[-3].tree_type, yyvsp[-1].tree_command_list_type,
					       yyvsp[-6].tok_val->line (), yyvsp[-6].tok_val->column ());
		  ;
    break;}
case 95:
#line 546 "parse.y"
{
		    maybe_warn_assign_as_truth_value (yyvsp[-3].tree_type);
		    if (check_end (yyvsp[0].tok_val, token::if_end))
		      ABORT_PARSE;
		    iffing--;
		    yyval.tree_command_type = new tree_if_command (yyvsp[-3].tree_type, yyvsp[-1].tree_command_list_type,
					      yyvsp[-4].tok_val->line (), yyvsp[-4].tok_val->column ());
		  ;
    break;}
case 96:
#line 555 "parse.y"
{
		    maybe_warn_assign_as_truth_value (yyvsp[-6].tree_type);
		    if (check_end (yyvsp[0].tok_val, token::if_end))
		      ABORT_PARSE;
		    iffing--;
		    tree_if_command *t1 = new tree_if_command
					    (yyvsp[-1].tree_command_list_type, yyvsp[-3].tok_val->line (), yyvsp[-3].tok_val->column ());
		    yyval.tree_command_type = t1->chain (yyvsp[-6].tree_type, yyvsp[-4].tree_command_list_type, yyvsp[-7].tok_val->line (), yyvsp[-7].tok_val->column ());
		  ;
    break;}
case 97:
#line 565 "parse.y"
{
		    maybe_warn_assign_as_truth_value (yyvsp[-4].tree_type);
		    if (check_end (yyvsp[0].tok_val, token::if_end))
		      ABORT_PARSE;
		    iffing--;
		    tree_if_command *t1 = yyvsp[-1].tree_if_command_type->reverse ();
		    // Add the if list to the new head of the elseif
		    // list, and return the list.
		    yyval.tree_command_type = t1->chain (yyvsp[-4].tree_type, yyvsp[-2].tree_command_list_type, yyvsp[-5].tok_val->line (), yyvsp[-5].tok_val->column ());
		  ;
    break;}
case 98:
#line 576 "parse.y"
{
		    maybe_warn_assign_as_truth_value (yyvsp[-7].tree_type);
		    if (check_end (yyvsp[0].tok_val, token::if_end))
		      ABORT_PARSE;
		    iffing--;
		    // Add the else list to the head of the elseif list,
		    // then reverse the list.
		    tree_if_command *t1 = yyvsp[-4].tree_if_command_type->chain (yyvsp[-1].tree_command_list_type, yyvsp[-3].tok_val->line (),
						     yyvsp[-3].tok_val->column ());
		    t1 = t1->reverse ();
		    // Add the if list to the new head of the elseif
		    // list, and return the list.
		    yyval.tree_command_type = t1->chain (yyvsp[-7].tree_type, yyvsp[-5].tree_command_list_type, yyvsp[-8].tok_val->line (), yyvsp[-8].tok_val->column ());
		  ;
    break;}
case 99:
#line 591 "parse.y"
{
		    if (!looping)
		      {
			yyerror ("parse error");
			error ("break: only meaningful within a `for'\
 or `while' loop");
			ABORT_PARSE;
		      }
		    yyval.tree_command_type = new tree_break_command (yyvsp[0].tok_val->line (), yyvsp[0].tok_val->column ());
		  ;
    break;}
case 100:
#line 602 "parse.y"
{
		    if (!looping)
		      {
			yyerror ("parse error");
			error ("continue: only meaningful within a\
 `for' or `while' loop");
			ABORT_PARSE;
		      }
		    yyval.tree_command_type = new tree_continue_command (yyvsp[0].tok_val->line (),
						    yyvsp[0].tok_val->column ());
		  ;
    break;}
case 101:
#line 614 "parse.y"
{
		    if (!defining_func)
		      {
			yyerror ("parse error");
			error ("return: only meaningful within a function");
			ABORT_PARSE;
		      }
		    yyval.tree_command_type = new tree_return_command (yyvsp[0].tok_val->line (), yyvsp[0].tok_val->column ());
		  ;
    break;}
case 102:
#line 626 "parse.y"
{
		    maybe_warn_assign_as_truth_value (yyvsp[-2].tree_type);
		    yyval.tree_if_command_type = new tree_if_command (yyvsp[-2].tree_type, yyvsp[0].tree_command_list_type, yyvsp[-4].tok_val->line (),
					      yyvsp[-4].tok_val->column ());
		  ;
    break;}
case 103:
#line 632 "parse.y"
{
		    maybe_warn_assign_as_truth_value (yyvsp[-2].tree_type);
		    yyval.tree_if_command_type = yyvsp[-5].tree_if_command_type->chain (yyvsp[-2].tree_type, yyvsp[0].tree_command_list_type, yyvsp[-4].tok_val->line (), yyvsp[-4].tok_val->column ());
		  ;
    break;}
case 112:
#line 651 "parse.y"
{ maybe_screwed_again++; ;
    break;}
case 113:
#line 655 "parse.y"
{ yyval.tree_type = new tree_simple_assignment_expression
		      (yyvsp[-2].tree_index_expression_type, yyvsp[0].tree_type, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 114:
#line 658 "parse.y"
{

// Will need a way to convert the matrix list to a list of
// identifiers.	 If that fails, we can abort here, without losing
// anything -- no other possible syntax is valid if we've seen the
// equals sign as the next token after the `]'.

		    yyval.tree_type = (tree_multi_assignment_expression *) NULL;
		    maybe_screwed_again--;
		    tree_matrix *tmp = ml.pop ();
		    tmp = tmp->reverse ();
		    tree_return_list *id_list = tmp->to_return_list ();
		    if (id_list == NULL_TREE)
		      {
			yyerror ("parse error");
			error ("invalid identifier list for assignment");
			yyval.tree_type = (tree_multi_assignment_expression *) NULL;
			ABORT_PARSE;
		      }
		    else
		      yyval.tree_type = new tree_multi_assignment_expression
			(id_list, yyvsp[0].tree_type, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ());
		  ;
    break;}
case 115:
#line 682 "parse.y"
{
		    yyerror ("parse error");
		    error ("invalid assignment to a number");
		    yyval.tree_type = (tree_simple_assignment_expression *) NULL;
		    ABORT_PARSE;
		  ;
    break;}
case 116:
#line 689 "parse.y"
{ yyval.tree_type = yyvsp[0].tree_type; ;
    break;}
case 117:
#line 693 "parse.y"
{ yyval.tree_type = yyvsp[0].tree_type; ;
    break;}
case 118:
#line 695 "parse.y"
{ yyval.tree_type = new tree_postfix_expression
		      (yyvsp[-1].tree_identifier_type, tree::increment, yyvsp[0].tok_val->line (), yyvsp[0].tok_val->column ()); ;
    break;}
case 119:
#line 698 "parse.y"
{ yyval.tree_type = new tree_postfix_expression
		      (yyvsp[-1].tree_identifier_type, tree::decrement, yyvsp[0].tok_val->line (), yyvsp[0].tok_val->column ()); ;
    break;}
case 120:
#line 701 "parse.y"
{ yyval.tree_type = new tree_unary_expression
		      (yyvsp[-1].tree_type, tree::hermitian, yyvsp[0].tok_val->line (), yyvsp[0].tok_val->column ()); ;
    break;}
case 121:
#line 704 "parse.y"
{ yyval.tree_type = new tree_unary_expression
		      (yyvsp[-1].tree_type, tree::transpose, yyvsp[0].tok_val->line (), yyvsp[0].tok_val->column ()); ;
    break;}
case 122:
#line 707 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::power, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 123:
#line 710 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::elem_pow, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 124:
#line 713 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::add, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 125:
#line 716 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::subtract, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 126:
#line 719 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::multiply, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 127:
#line 722 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::divide, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 128:
#line 725 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::el_mul, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 129:
#line 728 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::el_div, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 130:
#line 731 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::leftdiv, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 131:
#line 734 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::el_leftdiv, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 132:
#line 737 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::cmp_lt, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 133:
#line 740 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::cmp_le, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 134:
#line 743 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::cmp_eq, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 135:
#line 746 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::cmp_ge, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 136:
#line 749 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::cmp_gt, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 137:
#line 752 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::cmp_ne, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 138:
#line 755 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::and, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 139:
#line 758 "parse.y"
{ yyval.tree_type = new tree_binary_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, tree::or, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 140:
#line 763 "parse.y"
{ yyval.tree_type = new tree_constant (yyvsp[0].tok_val->number ()); ;
    break;}
case 141:
#line 765 "parse.y"
{ yyval.tree_type = new tree_constant (Complex (0.0, yyvsp[0].tok_val->number ())); ;
    break;}
case 142:
#line 767 "parse.y"
{ yyval.tree_type = new tree_constant (yyvsp[0].tok_val->string ()); ;
    break;}
case 143:
#line 769 "parse.y"
{ yyval.tree_type = yyvsp[0].tree_word_list_command_type; ;
    break;}
case 144:
#line 771 "parse.y"
{
		    if (yyvsp[-1].tree_type->is_assignment_expression ())
		      ((tree_assignment_expression *) yyvsp[-1].tree_type) -> in_parens++;
		    yyval.tree_type = yyvsp[-1].tree_type;
		  ;
    break;}
case 145:
#line 777 "parse.y"
{ yyval.tree_type = yyvsp[0].tree_index_expression_type; ;
    break;}
case 146:
#line 779 "parse.y"
{ yyval.tree_type = yyvsp[0].tree_matrix_type; ;
    break;}
case 147:
#line 781 "parse.y"
{
		    mlnm.pop ();
		    yyval.tree_type = new tree_constant (Matrix ());
		  ;
    break;}
case 148:
#line 786 "parse.y"
{
		    mlnm.pop ();
		    yyval.tree_type = new tree_constant (Matrix ());
		  ;
    break;}
case 149:
#line 791 "parse.y"
{ yyval.tree_type = yyvsp[0].tree_colon_expression_type; ;
    break;}
case 150:
#line 793 "parse.y"
{ yyval.tree_type = new tree_prefix_expression
		      (yyvsp[0].tree_identifier_type, tree::increment, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 151:
#line 796 "parse.y"
{ yyval.tree_type = new tree_prefix_expression
		      (yyvsp[0].tree_identifier_type, tree::decrement, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 152:
#line 799 "parse.y"
{ yyval.tree_type = new tree_unary_expression
		      (yyvsp[0].tree_type, tree::not, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 153:
#line 802 "parse.y"
{ yyval.tree_type = yyvsp[0].tree_type; ;
    break;}
case 154:
#line 804 "parse.y"
{ yyval.tree_type = new tree_unary_expression
		      (yyvsp[0].tree_type, tree::uminus, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 155:
#line 809 "parse.y"
{ yyval.tree_colon_expression_type = new tree_colon_expression
		      (yyvsp[-2].tree_type, yyvsp[0].tree_type, yyvsp[-1].tok_val->line (), yyvsp[-1].tok_val->column ()); ;
    break;}
case 156:
#line 812 "parse.y"
{
		    yyval.tree_colon_expression_type = yyvsp[-2].tree_colon_expression_type->chain (yyvsp[0].tree_type);
		    if (yyval.tree_colon_expression_type == (tree_colon_expression *) NULL)
		      {
			yyerror ("parse error");
			ABORT_PARSE;
		      }
		  ;
    break;}
case 157:
#line 823 "parse.y"
{ yyval.tree_word_list_command_type = new tree_word_list_command (yyvsp[-1].tree_identifier_type, yyvsp[0].tree_word_list_type); ;
    break;}
case 158:
#line 827 "parse.y"
{ yyval.tree_word_list_type = yyvsp[0].tree_word_list_type->reverse (); ;
    break;}
case 159:
#line 831 "parse.y"
{ yyval.tree_word_list_type = new tree_word_list (yyvsp[0].tok_val->string ()); ;
    break;}
case 160:
#line 833 "parse.y"
{ yyval.tree_word_list_type = yyvsp[-1].tree_word_list_type->chain (yyvsp[0].tok_val->string ()); ;
    break;}
case 161:
#line 839 "parse.y"
{ curr_sym_tab = global_sym_tab; ;
    break;}
case 162:
#line 843 "parse.y"
{ curr_sym_tab = tmp_local_sym_tab; ;
    break;}
case 163:
#line 847 "parse.y"
{ maybe_screwed = 0; ;
    break;}
case 164:
#line 851 "parse.y"
{ maybe_screwed = 1; ;
    break;}
case 165:
#line 855 "parse.y"
{
		    curr_sym_tab = top_level_sym_tab;
		    defining_func = 0;
		    yyval.tree_function_type = (tree_function *) NULL;
		  ;
    break;}
case 166:
#line 861 "parse.y"
{
		    curr_sym_tab = top_level_sym_tab;
		    defining_func = 0;
		    yyval.tree_function_type = (tree_function *) NULL;
		  ;
    break;}
case 167:
#line 869 "parse.y"
{
		    tree_identifier *tmp = new tree_identifier
		      (yyvsp[-4].tok_val->sym_rec (), yyvsp[-4].tok_val->line (), yyvsp[-4].tok_val->column ());
		    tree_parameter_list *tpl = new tree_parameter_list (tmp);
		    tpl = tpl->reverse ();
		    tpl->mark_as_formal_parameters ();
		    yyval.tree_function_type = yyvsp[0].tree_function_type->define_ret_list (tpl);
		  ;
    break;}
case 168:
#line 878 "parse.y"
{
		    tree_parameter_list *tpl = yyvsp[-4].tree_parameter_list_type->reverse ();
		    tpl->mark_as_formal_parameters ();
		    yyval.tree_function_type = yyvsp[0].tree_function_type->define_ret_list (tpl);
		  ;
    break;}
case 169:
#line 886 "parse.y"
{ yyval.tree_parameter_list_type = new tree_parameter_list (yyvsp[0].tree_identifier_type); ;
    break;}
case 170:
#line 888 "parse.y"
{ yyval.tree_parameter_list_type = yyvsp[-2].tree_parameter_list_type->chain (yyvsp[0].tree_identifier_type); ;
    break;}
case 171:
#line 892 "parse.y"
{
		    char *id_name = yyvsp[-3].tree_identifier_type->name ();
//		    if (is_text_function_name (id_name))
//		      {
//			yyerror ("parse error");
//			error ("invalid use of reserved word %s", id_name);
//			ABORT_PARSE;
//		      }

// If input is coming from a file, issue a warning if the name of the
// file does not match the name of the function stated in the file.
// Matlab doesn't provide a diagnostic (it ignores the stated name).

		    if (reading_fcn_file)
		      {
			if (strcmp (curr_fcn_file_name, id_name) != 0)
			  {
			    warning ("function name `%s' does not agree\
 with function file name `%s.m'", id_name, curr_fcn_file_name);

			    yyvsp[-3].tree_identifier_type->rename (curr_fcn_file_name);
			    id_name = yyvsp[-3].tree_identifier_type->name ();
			  }

			yyvsp[0].tree_function_type->stash_fcn_file_name (curr_fcn_file_name);
			yyvsp[0].tree_function_type->stash_fcn_file_time (time ((time_t *) NULL));
			yyvsp[0].tree_function_type->mark_as_system_fcn_file ();
		      }
		    else if (! (input_from_tmp_history_file
				|| input_from_startup_file)
			     && reading_script_file
			     && strcmp (curr_fcn_file_name, id_name) == 0)
		      {
			warning ("function `%s' defined within\
 script file `%s.m'", id_name, curr_fcn_file_name);
		      }

		    top_level_sym_tab->clear (id_name);

		    yyvsp[0].tree_function_type->stash_function_name (id_name);

		    yyvsp[-3].tree_identifier_type->define (yyvsp[0].tree_function_type);
		    yyvsp[-3].tree_identifier_type->document (help_buf);

		    yyval.tree_function_type = yyvsp[0].tree_function_type;
		  ;
    break;}
case 172:
#line 941 "parse.y"
{
		    tree_function *fcn = new tree_function (yyvsp[-1].tree_command_list_type, curr_sym_tab);
		    yyval.tree_function_type = fcn->define_param_list (yyvsp[-3].tree_parameter_list_type);
		  ;
    break;}
case 173:
#line 946 "parse.y"
{ yyval.tree_function_type = new tree_function (yyvsp[-1].tree_command_list_type, curr_sym_tab); ;
    break;}
case 174:
#line 950 "parse.y"
{
		    if (check_end (yyvsp[0].tok_val, token::function_end))
			ABORT_PARSE;

		    if (reading_fcn_file)
		      check_for_garbage_after_fcn_def ();
		  ;
    break;}
case 175:
#line 958 "parse.y"
{
		    if (! (reading_fcn_file || reading_script_file))
		      YYABORT;
		  ;
    break;}
case 176:
#line 965 "parse.y"
{
		    yyval.tree_index_expression_type = new tree_index_expression
			   (yyvsp[0].tree_identifier_type, yyvsp[0].tree_identifier_type->line (), yyvsp[0].tree_identifier_type->column ());
		  ;
    break;}
case 177:
#line 970 "parse.y"
{
		    yyval.tree_index_expression_type = new tree_index_expression
			   (yyvsp[-3].tree_identifier_type, yyvsp[-1].tree_argument_list_type, yyvsp[-3].tree_identifier_type->line (), yyvsp[-3].tree_identifier_type->column ());
		  ;
    break;}
case 178:
#line 975 "parse.y"
{
		    yyval.tree_index_expression_type = new tree_index_expression
		           (yyvsp[-2].tree_identifier_type, (tree_argument_list *) NULL,
			    yyvsp[-2].tree_identifier_type->line (), yyvsp[-2].tree_identifier_type->column ());
		  ;
    break;}
case 179:
#line 981 "parse.y"
{
		    yyerror ("parse error");
		    error ("use `(\' and `)\' as index operators, not\
 `[\' and `]\'"); 
		    yyval.tree_index_expression_type = (tree_index_expression *) NULL;
		    ABORT_PARSE;
		  ;
    break;}
case 180:
#line 991 "parse.y"
{
		    quote_is_transpose = 0;
		    yyval.tree_parameter_list_type = (tree_parameter_list *) NULL;
		  ;
    break;}
case 181:
#line 996 "parse.y"
{
		    quote_is_transpose = 0;
		    tree_parameter_list *tmp = yyvsp[-1].tree_parameter_list_type->reverse ();
		    tmp->mark_as_formal_parameters ();
		    yyval.tree_parameter_list_type = tmp;
		  ;
    break;}
case 182:
#line 1003 "parse.y"
{
		    quote_is_transpose = 0;
		    tree_parameter_list *tmp = yyvsp[-3].tree_parameter_list_type->reverse ();
		    tmp->mark_as_formal_parameters ();
		    tmp->mark_varargs ();
		    yyval.tree_parameter_list_type = tmp;
		  ;
    break;}
case 183:
#line 1012 "parse.y"
{ yyval.tree_parameter_list_type = new tree_parameter_list (yyvsp[0].tree_identifier_type); ;
    break;}
case 184:
#line 1014 "parse.y"
{ yyval.tree_parameter_list_type = yyvsp[-2].tree_parameter_list_type->chain (yyvsp[0].tree_identifier_type); ;
    break;}
case 185:
#line 1016 "parse.y"
{
		    yyerror ("parse error");
		    error ("invalid parameter list");
		    ABORT_PARSE;
		  ;
    break;}
case 186:
#line 1022 "parse.y"
{
		    yyerror ("parse error");
		    error ("invalid parameter list");
		    ABORT_PARSE;
		  ;
    break;}
case 187:
#line 1030 "parse.y"
{ yyval.tree_identifier_type = new tree_identifier
		      (yyvsp[0].tok_val->sym_rec (), yyvsp[0].tok_val->line (), yyvsp[0].tok_val->column ()); ;
    break;}
case 188:
#line 1034 "parse.y"
{ yyval.tree_argument_list_type = yyvsp[0].tree_argument_list_type->reverse (); ;
    break;}
case 189:
#line 1038 "parse.y"
{
		    tree_constant *colon;
		    colon = new tree_constant (tree_constant_rep::magic_colon);
		    yyval.tree_argument_list_type = new tree_argument_list (colon);
		  ;
    break;}
case 190:
#line 1044 "parse.y"
{
		    tree_constant *colon;
		    colon = new tree_constant (tree_constant_rep::magic_colon);
		    yyval.tree_argument_list_type = yyvsp[-2].tree_argument_list_type->chain (colon);
		    if (yyval.tree_argument_list_type == NULL_TREE)
		      {
			yyerror ("parse error");
			ABORT_PARSE;
		      }
		  ;
    break;}
case 191:
#line 1055 "parse.y"
{ yyval.tree_argument_list_type = new tree_argument_list (yyvsp[0].tree_type); ;
    break;}
case 192:
#line 1057 "parse.y"
{
		    yyval.tree_argument_list_type = yyvsp[-2].tree_argument_list_type->chain (yyvsp[0].tree_type);
		    if (yyval.tree_argument_list_type == NULL_TREE)
		      {
			yyerror ("parse error");
			ABORT_PARSE;
		      }
		  ;
    break;}
case 193:
#line 1068 "parse.y"
{
		    mlnm.pop ();
		    maybe_screwed_again--;
		    tree_matrix *tmp = ml.pop ();
		    yyval.tree_matrix_type = tmp->reverse ();
		  ;
    break;}
case 197:
#line 1082 "parse.y"
{
		    if (mlnm.top ())
		      {
			mlnm.pop ();
			mlnm.push (0);
			tree_matrix *tmp = new tree_matrix (yyvsp[0].tree_type, tree::md_none);
			ml.push (tmp);
		      }
		    else
		      {
			tree_matrix *tmp = ml.pop ();
			tmp = tmp->chain (yyvsp[0].tree_type, tree::md_down);
			ml.push (tmp);
		      }
		  ;
    break;}
case 199:
#line 1099 "parse.y"
{
		    tree_matrix *tmp = ml.pop ();
		    tmp = tmp->chain (yyvsp[0].tree_type, tree::md_right);
		    ml.push (tmp);
		  ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 465 "/usr/local/gnu/lib/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 1106 "parse.y"


static void
yyerror (char *s)
{
  char *line = current_input_line;
  int err_col = current_input_column - 1;
  if (err_col == 0 && line != (char *) NULL)
    err_col = strlen (line) + 1;

// Print a message like `parse error'.
  fprintf (stderr, "\n%s", s);

// Maybe print the line number and file name.
  if (reading_fcn_file || reading_script_file)
    fprintf (stderr, " near line %d of file %s.m", input_line_number,
	     curr_fcn_file_name);

  if (line != (char *) NULL)
    {
      int len = strlen (line);
      if (line[len-1] == '\n')
        {
          len--;
          line[len] = '\0';
        }
// Print the line, maybe with a pointer near the error token.
      if (err_col > len)
        fprintf (stderr, ":\n\n  %s\n\n", line);
      else
        fprintf (stderr, ":\n\n  %s\n  %*s\n\n", line, err_col, "^");
    }
  else
    fprintf (stderr, "\n\n");
}

static int
check_end (token *tok, token::end_tok_type expected)
{
  token::end_tok_type ettype = tok->ettype ();
  if (ettype != expected && ettype != token::simple_end)
    {
      yyerror ("parse error");

      int l = tok->line ();
      int c = tok->column ();

      switch (expected)
	{
	case token::for_end:
	  end_error ("for", ettype, l, c);
	  break;
	case token::function_end:
	  end_error ("function", ettype, l, c);
	  break;
	case token::if_end:
	  end_error ("if", ettype, l, c);
	  break;
	case token::while_end:
	  end_error ("while", ettype, l, c);
	  break;
	default:
	  panic_impossible ();
	  break;
	}
      return 1;
    }
  else
    return 0;
}

static void
end_error (char *type, token::end_tok_type ettype, int l, int c)
{
  static char *fmt = "%s command matched by `%s' near line %d column %d";

  switch (ettype)
    {
    case token::simple_end:
      error (fmt, type, "end", l, c);
      break;
    case token::for_end:
      error (fmt, type, "endfor", l, c);
      break;
    case token::function_end:
      error (fmt, type, "endfunction", l, c);
      break;
    case token::if_end:
      error (fmt, type, "endif", l, c);
      break;
    case token::while_end:
      error (fmt, type, "endwhile", l, c); 
      break;
    default:
      panic_impossible ();
      break;
    }
}

/*
 * Need to make sure that the expression isn't already an identifier
 * that has a name, or an assignment expression.
 *
 * Note that an expression can't be just an identifier anymore -- it
 * must at least be an index expression (see the definition of the
 * non-terminal `variable' above).
 *
 * XXX FIXME XXX.  This isn't quite sufficient.  For example, try the
 * command `x = 4, x' for `x' previously undefined.
 *
 * XXX FIXME XXX -- we should probably delay doing this until eval-time.
 */
tree *
maybe_convert_to_ans_assign (tree *expr)
{
  if (expr->is_index_expression ())
    {
      expr->mark_for_possible_ans_assign ();
      return expr;
    }
  else if (expr->is_assignment_expression ()
	   || expr->is_prefix_expression ())
    {
      return expr;
    }
  else
    {
      symbol_record *sr = global_sym_tab->lookup ("ans", 1, 0);

      assert (sr != (symbol_record *) NULL);
      
      tree_identifier *ans = new tree_identifier (sr);

      return new tree_simple_assignment_expression (ans, expr);
    }
}

void
maybe_warn_assign_as_truth_value (tree *expr)
{
  if (user_pref.warn_assign_as_truth_value
      && expr->is_assignment_expression ()
      && ((tree_assignment_expression *) expr) -> in_parens < 2)
    {
      warning ("suggest parenthesis around assignment used as truth value");
    }
}
