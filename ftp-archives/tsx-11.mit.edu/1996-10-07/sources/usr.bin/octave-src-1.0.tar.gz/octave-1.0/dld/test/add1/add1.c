extern int x;

add1() {
    x++;
}
