extern int x;

void
add2 (void)
{
  printf ("in add2\n");
  x++;
}
