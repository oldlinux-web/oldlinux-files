
// uncomment the following if compiling for unix

/* #define MSDOS */
