// Output created by HTML2CPP, written by Scott W. Griffith, 1995

#define HTML_   cout << "<HTML>" << LF;