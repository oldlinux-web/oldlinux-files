#include <ctype.h>
#include <stdio.h>
#include "config.h"
#ifdef MSDOS
        #include <conio.h>
#else
        #include <curses.h>
#endif
#include "prototypes.h"

#ifndef MSDOS

int curses_on;
WINDOW *savescr;

void clrscr()
{
  clear();
  refresh();
}

void init_curses()
{
  if (initscr()==ERR)
  {
    (void)printf("Error allocating screen in curses package.\n");
    exit(1);
  }
  if ((savescr=newwin(0,0,0,0)) == NULL)
  {
    printf("out of memory while trying to invoke curses.\n");
    exit(1);
  }
  clrscr();
  curses_on=TRUE;
}

#endif

void pauseit()
{
    printf("\n\x1b[0;31mPlease press '\x1b[1;31menter\x1b[0;31m' to continue\x1b[0m");
    getch();
    printf("\n");
}

void clrln()
{
register int i;
  for (i = 0 ; i < 80 ; i++) printf ( " " );
  for (i = 79 ; i > 0 ; i--) printf ( "\b" );
}

char hotk()
{
char hotk;
  hotk = getch();
  printf("\n");
  return hotk;
}
