#define LF char(10)

#define GET	1
#define POST	2

//defines for filling structure
#define AUTHOR		0
#define DOCUMENT	1
#define OUTPUT		2
#define ROUTINE		3
#define METHOD		4
#define PROGRAMNAME	5
#define DATADIRECTORY	6

typedef struct
{
	char AuthorName [80];
	char DocumentName [80];
	char OutputName [80];
	char RoutineName [80];
	char Method [5];
	char ProgramName [80];
	char DataDirectory [255];
} HTMLConversion;

extern HTMLConversion Convert;
