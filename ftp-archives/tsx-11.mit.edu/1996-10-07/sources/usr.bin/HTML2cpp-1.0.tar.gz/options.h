typedef struct
{
        int Counter,
            LogFile,
            GenerateFiles,
            OperatingSystem;
        int VisibleCounter;             // Not yet implemented
} options;

typedef struct
{
        int Name,
            IPAddr,
            HostName,
            UserID,
            RequestMethod,
            Protocol,
            QueryString;
        char Path[255];
} logfile;

extern options Options;
extern logfile LogFile;
