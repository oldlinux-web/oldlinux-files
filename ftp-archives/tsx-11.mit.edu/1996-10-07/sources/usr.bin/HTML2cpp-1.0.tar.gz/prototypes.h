/* common.cpp */
char hotk();
void clrscr();
void clrln();
void init_curses();
void pauseit();

/* html2cpp.cpp */
void PrepareModule (char *FunctionName);
void finish_module ();
void convert (char *buffer);
void GetConvertInfo ( char *DocumentName, char *OutputName, char *RoutineName);

/* createfiles.cpp */
void MakeLogFileCPP ();
void MakeLogFileHeader ();
void MakeCounterCPP ();
void MakeTags ();
void MakeDefaults ();
void MakeMakefile (int type);
void MakeCGIget ();

/* process_query.cpp */
void process_query (char *query);

/* options.cpp */
void CounterOptions ();
void set_options ();

