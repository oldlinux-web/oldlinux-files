#include <iostream.h>
#include <stdio.h>
#include <string.h>
#include "config.h"
#ifdef MSDOS
        #include <conio.h>
#else
        #include <curses.h>
#endif
#include "prototypes.h"
#include "options.h"
#include "color.h"

options Options;
logfile LogFile;

void LogOptions ()
{
int ok = 0;
char szTemp[255];
        do
        {
                clrscr();
                cout << "\n";
                cout << "What would you like to log?\n\n";
                cout << LightBlue << "A" << LightBlack << "]" << Normal << " Name           : "; LogFile.Name ? cout << "ON" : cout << "OFF"; cout << endl;
                cout << LightBlue << "B" << LightBlack << "]" << Normal << " IP Address     : "; LogFile.IPAddr ? cout << "ON" : cout << "OFF"; cout << endl;
                cout << LightBlue << "C" << LightBlack << "]" << Normal << " Host Name      : "; LogFile.HostName ? cout << "ON" : cout << "OFF"; cout << endl;
                cout << LightBlue << "D" << LightBlack << "]" << Normal << " User ID        : "; LogFile.UserID ? cout << "ON" : cout << "OFF"; cout << endl;
                cout << LightBlue << "E" << LightBlack << "]" << Normal << " Request Method : "; LogFile.RequestMethod ? cout << "ON" : cout << "OFF"; cout << endl;
                cout << LightBlue << "F" << LightBlack << "]" << Normal << " Server Protocol: "; LogFile.Protocol ? cout << "ON" : cout << "OFF"; cout << endl;
                cout << LightBlue << "G" << LightBlack << "]" << Normal << " Query String   : "; LogFile.QueryString ? cout << "ON" : cout << "OFF"; cout << endl;
                cout << LightBlue << "H" << LightBlack << "]" << Normal << " Log File Path  : " << LogFile.Path << endl << endl;
                cout << LightBlue << "X" << LightBlack << "]" << Normal << " Exit to previous menu" << endl << endl;
                cout << LightBlue << ":" << LightBlack << "] " << Normal;
                switch (hotk())
                {
                        case 'A':
                        case 'a':
                                if (LogFile.Name)
                                        LogFile.Name = 0;
                                else
                                        LogFile.Name = 1;
                                break;
                        case 'B':
                        case 'b':
                                if (LogFile.IPAddr)
                                        LogFile.IPAddr = 0;
                                else
                                        LogFile.IPAddr = 1;
                                break;
                        case 'C':
                        case 'c':
                                if (LogFile.HostName)
                                        LogFile.HostName = 0;
                                else
                                        LogFile.HostName = 1;
                                break;
                        case 'D':
                        case 'd':
                                if (LogFile.UserID)
                                        LogFile.UserID = 0;
                                else
                                        LogFile.UserID = 1;
                                break;
                        case 'E':
                        case 'e':
                                if (LogFile.RequestMethod)
                                        LogFile.RequestMethod = 0;
                                else
                                        LogFile.RequestMethod = 1;
                                break;                                
                        case 'F':
                        case 'f':
                                if (LogFile.Protocol)
                                        LogFile.Protocol = 0;
                                else
                                        LogFile.Protocol = 1;
                                break;

                        case 'G':
                        case 'g':
                                if (LogFile.QueryString)
                                        LogFile.QueryString = 0;
                                else
                                        LogFile.QueryString = 1;
                                break;
                        case 'H':
                        case 'h':
                                cout << "Path and filename of log file: ";
                                gets (szTemp);
                                strcpy (LogFile.Path, szTemp);
                                break;
                        case 'X':
                        case 'x':
                                ok = 1;
                        default:
                                break;
                }
        } while (!ok);
}


void CounterOptions ()
{
int ok = 0;
        do
        {
                clrscr ();
                cout << "\n";
                cout << "Include Which Data Items?" << endl << endl;
                cout << LightBlue << "A" << LightBlack << "]" << Normal << " Visible Counter    : "; Options.VisibleCounter ? cout << "YES" : cout << "NO"; cout << endl; 
                cout << LightBlue << "X" << LightBlack << "]" << Normal << " Exit to previous menu" << endl << endl;
                cout << LightBlue << ":" << LightBlack << "] " << Normal;
                switch (hotk())
                {
                        case 'A':
                        case 'a':
                                if (Options.VisibleCounter)
                                        Options.VisibleCounter = 0;
                                else
                                        Options.VisibleCounter = 1;
                                break;
                        case 'X':
                        case 'x':
                                ok = 1;
                        default:
                                break;
                }
        } while (!ok);
}

void set_options ()
{
int ok = 0;

	Options.GenerateFiles = 1;
	Options.OperatingSystem = 1;
        do
        {
                clrscr ();
                cout << "\n";
                cout << LightBlue << "C" << LightBlack << "]" << Normal << " Counter            : "; Options.Counter ? cout << "ON" : cout << "OFF"; cout << endl;
                cout << LightBlue << "G" << LightBlack << "]" << Normal << " Generate C++ Files : "; Options.GenerateFiles ? cout << "YES" : cout << "NO"; cout << endl;
                cout << LightBlue << "L" << LightBlack << "]" << Normal << " Log File           : "; Options.LogFile ? cout << "ON" : cout << "OFF"; cout << endl;
                cout << LightBlue << "O" << LightBlack << "]" << Normal << " Operating System   : "; Options.OperatingSystem ? cout << "UNIX" : cout << "MSDOS"; cout << endl;
                cout << LightBlue << "X" << LightBlack << "]" << Normal << " Exit to Main Menu" << endl << endl;
                cout << LightBlue << ":" << LightBlack << "] " << Normal;
                switch (hotk())
                {
                        case 'C':
                        case 'c':
                                if (Options.Counter)
                                        Options.Counter = 0;
                                else
                                        Options.Counter = 1;
                                break;
                        case 'G':
                        case 'g':
                                if (Options.GenerateFiles)
                                        Options.GenerateFiles = 0;
                                else
                                        Options.GenerateFiles = 1;
                                break;
                        case 'L':
                        case 'l':
                                if (Options.LogFile)
                                        Options.LogFile = 0;
                                else
                                {
                                        Options.LogFile = 1;
                                        LogOptions ();
                                }
                                break;
                        case 'O':
                        case 'o':
                                if (Options.OperatingSystem)
                                        Options.OperatingSystem = 0;
                                else
                                        Options.OperatingSystem = 1;
                                break;
                        case 'X':
                        case 'x':
                                ok = 1;
                                break;
                        default:
                                break;
                }
        } while (!ok);
}
