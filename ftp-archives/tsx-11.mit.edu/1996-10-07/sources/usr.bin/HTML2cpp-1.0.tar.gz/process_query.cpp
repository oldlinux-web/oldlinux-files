#include <stdio.h>
#include <string.h>
#include <iostream.h>
#include "prototypes.h"
#include "convert.h"
#include "config.h"

void process_query (char *query)
{
int i, j;
char s1[80][80];

 
	
	for (i = 0; i < 80; i++)
		for (j=0; j < 80; j++)
			s1 [i][j] = '\0';
	i = 0;
	j = 0;
	do
	{
		if ((*query == '=') || (*query == '&'))
		{
			i++;
			query++;
			j=0;
		}

		if (*query == '+')
		{
			s1 [i][j] = ' ';
			j++;
			query++;
		}

		s1 [i][j] = *query;
		j++;
		query++;

	} while (*query!='\0');

//  Only change below this line:
	strcpy ( Convert.AuthorName,	s1[1] );
	strcpy ( Convert.DocumentName,	s1[3] );
	strcpy ( Convert.OutputName,	s1[5] );
	strcpy ( Convert.RoutineName,	s1[7] );
	strcpy ( Convert.Method,	s1[9] );
	strcpy ( Convert.ProgramName,	s1[11] );
	strcpy ( Convert.DataDirectory,	s1[13] );

}
