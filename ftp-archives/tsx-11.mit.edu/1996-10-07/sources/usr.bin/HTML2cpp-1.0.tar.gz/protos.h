// Output created by HTML2CPP, written by Scott W. Griffith, 1995

#define LF   char(10)

void increment ();
void index ();
