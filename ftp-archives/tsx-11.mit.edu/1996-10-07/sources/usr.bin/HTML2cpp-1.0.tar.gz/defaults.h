// Output created by HTML2CPP, written by Scott W. Griffith, 1995

#define AUTHOR     "lifestlr@straightup.znet.com"
#define LF         char(10)
