// Output created by HTML2CPP, written by Scott W. Griffith, 1995

#include <stdio.h>

extern char *datapath;

FILE *datafile;

typedef struct
{
unsigned int     accessed,
                 last_accessed;
} times;

void increment ()
{

unsigned long accessed = 0;

        if (!(datafile = fopen ( datapath , "rb" )))
        {
                datafile = fopen ( datapath, "wb" );
                accessed = 0;
                fwrite ( &accessed, sizeof (accessed), 1, datafile );
                printf ("File was created\n");
                fclose (datafile);
        }
        fread ( &accessed, sizeof (accessed), 1, datafile );
        fclose (datafile);
        accessed += 1;
        printf ( "this page has been accessed %ld\n", accessed );
        datafile = fopen ( datapath, "wb" );
        fwrite ( &accessed, sizeof (accessed), 1, datafile );
        fclose (datafile);
}
