#define DEFINITION_Semantics

#ifndef DEFINITION_Tree
#include "Tree.h"
#endif

extern void Semantics_Eval ARGS((Tree_tTree yyt));
extern void Semantics_BeginSemantics ARGS(());
extern void Semantics_CloseSemantics ARGS(());
extern void BEGIN_Semantics();
