DEFINITION MODULE Semantics;

IMPORT Tree;

PROCEDURE Eval (yyt: Tree.tTree);
PROCEDURE BeginSemantics;
PROCEDURE CloseSemantics;

END Semantics.
