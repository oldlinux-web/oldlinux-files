exec LIB/mtc/mtc -lLIB/mtc $*
