#define DEFINITION_Checks

extern void Checks_ErrorCheck ARGS((CHAR s[], LONGCARD , INTEGER n));
extern void BEGIN_Checks();
