(* $Id: Checks.md,v 1.1 1991/11/21 14:33:17 grosch rel $ *)

(* $Log: Checks.md,v $
 * Revision 1.1  1991/11/21  14:33:17  grosch
 * new version of RCS on SPARC
 *
 * Revision 1.0  88/10/04  11:46:49  grosch
 * Initial revision
 * 
 *)

(* Ich, Doktor Josef Grosch, Informatiker, Sept. 1987 *)

DEFINITION MODULE Checks;

PROCEDURE ErrorCheck (s: ARRAY OF CHAR; n: INTEGER);

END Checks.
