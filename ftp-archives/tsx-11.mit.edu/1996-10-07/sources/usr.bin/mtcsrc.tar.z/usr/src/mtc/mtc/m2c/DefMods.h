#define DEFINITION_DefMods

#ifndef DEFINITION_Tree
#include "Tree.h"
#endif

extern void DefMods_GetDefinitionModules ARGS((Tree_tTree CompUnit, Tree_tTree *Root));
extern void BEGIN_DefMods();
