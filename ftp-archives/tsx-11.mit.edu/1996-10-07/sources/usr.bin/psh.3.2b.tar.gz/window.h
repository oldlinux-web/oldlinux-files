/*
 * Window header file
 * Pink House Systems, 2nd October 1993
 */

#ifndef __WINDOW_H
#define __WINDOW_H


class window
{
    int startx, starty;
    int rows, columns;
    int cursorx, cursory;

   public:
   
    window::window(int startx, int starty, int rows, int columns);
    int  window::write(char *str, int length);
    int  window::putch(char c);
    void window::cursormove(int y, int x);
};


#endif
