/* Remote reset/restart server definitions */

#define	REMOTE_PORT	1234	/* Default UDP port */

/* Commands */
#define	SYS_RESET	1
#define	SYS_EXIT	2

