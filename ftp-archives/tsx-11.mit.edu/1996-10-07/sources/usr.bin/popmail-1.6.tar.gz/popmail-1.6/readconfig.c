#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stddef.h>
#include <sys/types.h>

#include "config.h"

int read_config(const char *config, const char *pop)
{
extern int ex_child();
int i, lineno = 0;
char line[MAX_LINE_LEN];
static char hostname[MAX_HOSTNAME_LEN], localuser[MAX_USERNAME_LEN], remoteuser[MAX_USERNAME_LEN], pw[MAX_USERNAME_LEN], pt[MAX_PORT_LEN], tmp[1];
FILE *cfg;
cfg = fopen(config, "r");
if (cfg == NULL)
	{
	 return -1;
	}
while (fgets(line, MAX_LINE_LEN - 1, cfg) != NULL)
	{
	 lineno++;
	 i = sscanf(line, "%s%s%s%s%s", hostname, localuser, remoteuser, pw, pt);
	 if (sscanf(line, "\t#%s", tmp) == 0)
		{
		 switch(i)
			{
			 case 4: sprintf(line, "%s %s %s %s %s %d", pop, hostname, localuser, remoteuser, pw, POP3_PORT); ex_child(line); break;
			 case 5: sprintf(line, "%s %s %s %s %s %d", pop, hostname, localuser, remoteuser, pw, atoi(pt)); ex_child(line); break;
			 default: if (i > 0) fprintf(stderr, "config file: error at line %d\n", lineno);
			}
		}
	}
fclose(cfg);
return 0;
}
