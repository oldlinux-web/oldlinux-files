#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>

#include "config.h"

#define FROMLINE	"From Popmail "

int verify_end(FILE *spool, FILE *str)
{
int g;
g = getc(str);

if (g == '\n') return 1;
else
	{
	 putc(g, spool);
	 return 0;
	}	
}

int verify_point(FILE *spool, FILE *str)
{
extern verify_lf();
int e, f, end;
e = getc(str);
if (e == '.')
	{
	 f = getc(str);
	 if (f == '\r')
		{
		 end = verify_end(spool, str);
		 return end;
		}
	 else
		{
		 putc(e, spool);
		 putc(f, spool);
		 return 0;
		}
	}
else
	{
	 if (e != '\r')
		{
		 putc(e, spool);
		 return 0;
		}
	 else
		{
		 end = verify_lf(spool, str);
		 return end;
		}
	}
}

int verify_lf(FILE *spool, FILE *str)
{
int d, end;
d = getc(str);
if (d == '\n')
	{
	 putc(d, spool);
	 end = verify_point(spool, str);
	 return end;
	}
else
	{
	 putc(d, spool);
	 return 0;
	}
}
 
void retrieve_message(FILE *str, char *spoolfile)
{
int fd, c, end;
char *rtime;
time_t curtime;
FILE *spool;
fd = open(spoolfile, (O_WRONLY | O_APPEND | O_CREAT), (S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP));
if (fd == -1)
        {
         perror("opening spool file");
         exit(EXIT_FAILURE);
        }
curtime = time(NULL);
rtime = asctime(localtime(&curtime));
write(fd, FROMLINE, strlen(FROMLINE));
write(fd, rtime, strlen(rtime));
spool = fdopen(fd, "a");
do
	{
	 end = 0;
	 c = getc(str);
	 if (c == '\r')
		{
		 end = verify_lf(spool, str);
		}
	 else
		putc(c, spool);
	}
while (end != 1);
fclose(spool);
}
