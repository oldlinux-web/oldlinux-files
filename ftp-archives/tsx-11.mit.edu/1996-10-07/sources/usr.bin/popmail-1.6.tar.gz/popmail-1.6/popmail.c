#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <pwd.h>

#include "config.h"

const char ok[3] = "+OK";
struct in_addr saddr;
static char line[MAX_LINE_LEN];

struct hostent *get_hostent(const char *host)
{
int c;
struct hostent *hostinfo;
c = *host;
if (isdigit(c))
	{
	 saddr.s_addr = inet_addr(host);
	 hostinfo = gethostbyaddr((char *)&saddr, sizeof(struct in_addr), AF_INET);
	 if (hostinfo == NULL)
		{
		 fprintf(stderr, "Network is unreachable\n");
		 exit(EXIT_FAILURE);
		}
	}
else
	{
	 hostinfo = gethostbyname(host);
	 if (hostinfo == NULL)
		{
		 fprintf(stderr, "%s: Unknown host\n", host);
		 exit(EXIT_FAILURE);
		}
	}
return hostinfo;
}

int start_connection(const char *host, unsigned short int port)
{
struct hostent *hostinfo;
struct sockaddr_in addr;
int sfd = socket(AF_INET, SOCK_STREAM, 0);
if (sfd == -1)
	{
	 perror("socket: creating socket");
	 exit(EXIT_FAILURE);
	}

hostinfo = get_hostent(host);
addr.sin_family = AF_INET;
addr.sin_port = htons(port);
addr.sin_addr = saddr;
if (connect(sfd, (struct sockaddr *)&addr, sizeof addr) == -1)
	{
	 perror(NULL);
	 exit(EXIT_FAILURE);
	}
printf("Connected to %s.\n", hostinfo->h_name);
return sfd;
}

char *get_data(FILE *str)
{
if (fgets(line, MAX_LINE_LEN - 1, str) == NULL)
	{
	 perror("socket: reading data");
	 exit(EXIT_FAILURE);
	}
return line;
}

void send_data(FILE *str, const char *buffer)
{
int err;
err = fputs(buffer, str); 
if (err == EOF)
	{
	 perror("socket: writing data");
	 exit(EXIT_FAILURE);
	}
}

void pop_ok(const char *buffer)
{
if (strcmp(ok, buffer) < 0)
	{
	 fprintf(stderr, "POP server: error\n");
	 exit(EXIT_FAILURE);
	}
}

int hwmany(const char *buffer)
{
int err, hm = 0;
err = sscanf(buffer, "+OK %d", &hm);
if (err == -1) 
	{
	 fprintf(stderr, "popmail: error 1\n");
	 exit(EXIT_FAILURE);
	}
return hm;
}

int hwlong(const char *buffer)
{
int err, hl = 0;
err = sscanf(buffer, "+OK %*d %d", &hl);
if (err == -1) 
	{
	 fprintf(stderr, "popmail: error 2\n");
	 exit(EXIT_FAILURE);
	}
return hl;
}

void close_connection(FILE *str)
{
send_data(str, "QUIT\n");
fclose(str);
}

void main(int argc, char **argv)
{
extern int read_config();
extern void retrieve_message();
int i, n, sockfd;
char *buffer;
char k[MAX_LINE_LEN];
char spoolfile[MAX_LINE_LEN];
FILE *str;
struct passwd *userinfo;
if (argc < 5)
	{
	 if (argc != 1)
		{
		 printf(BANNER);
	 	 printf("usage: %s hostname localusercode remoteusercode password [port]\n", argv[0]);
		 exit(EXIT_FAILURE);
		}
	 if (read_config(CONFIG, argv[0]) == -1)
		{
		 printf(BANNER);
		 printf("usage: %s hostname localusercode remoteusercode password [port]\n", argv[0]);
		 fprintf(stderr, "config file %s: ", CONFIG);
		 perror(NULL);
		 exit(EXIT_FAILURE);
		}
	 else exit(0);
	}
printf(BANNER);
sockfd = start_connection(argv[1], argc < 6 ? POP3_PORT : atoi(argv[5]));
str = fdopen(sockfd, "r+");
buffer = get_data(str);
if (strcmp(ok, buffer) < 0)
	{
	 fprintf(stderr, "POP server unavailable\n");
	 exit(EXIT_FAILURE);
	}
send_data(str, "USER ");
send_data(str, argv[3]);
send_data(str, "\n");
buffer = get_data(str);
pop_ok(buffer);
send_data(str, "PASS ");
send_data(str, argv[4]);
send_data(str, "\n");
buffer = get_data(str);
if (strcmp(ok, buffer) < 0)
	{
	 fprintf(stderr, "POP server: invalid usercode or password\n");
	 exit(EXIT_FAILURE);
	}
send_data(str, "STAT\n");
buffer = get_data(str);
pop_ok(buffer);
n = hwmany(buffer);
if (n == 0)
	{
	 printf("No mail.\n");
	 exit(0);
	}
sprintf(spoolfile, "%s/%s", SPOOL, argv[2]);
i = 0;
while (i < n)
	{
	 i++;
	 sprintf(k, "%d", i);
	 send_data(str, "RETR ");
	 send_data(str, k);
	 send_data(str, "\n");
	 buffer = get_data(str);
	 pop_ok(buffer);
	 retrieve_message(str, spoolfile);
#ifdef DELETION
	 send_data(str, "DELE ");
	 send_data(str, k);
	 send_data(str, "\n");
	 buffer = get_data(str);
	 pop_ok(buffer);
#endif
	}
close_connection(str);
userinfo = getpwnam(argv[2]);
if (!userinfo) fprintf(stderr, "couldn't find out %s's uid\n", argv[2]);
else chown(spoolfile, userinfo->pw_uid, MAIL_GRP);
if (n > 0) printf("Done. (%d new message%s)\n", n, n == 1 ? "" : "s");
exit(0);
}
