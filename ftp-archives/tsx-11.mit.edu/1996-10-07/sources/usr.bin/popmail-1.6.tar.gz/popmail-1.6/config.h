#define VERSION		"1.6"
#define BANNER		"Popmail version " VERSION " - Copyright (C) 1995, 1996 Guido Trentalancia\n" 

/*
 *	config file
 */
#define CONFIG		"/etc/popcfg"

/*
 *	tcp port of the pop server 
 */
#define POP3_PORT	110		/* rfc 1225 */

/*
 *	mail spool directory 
 */
#define SPOOL		"/usr/spool/mail"

/*
 *	shell
 */
#define SHELL		"/bin/sh"

/*
 *	uid of the mail group
 */
#define MAIL_GRP	12

/*
 *	mark message as deleted on the server once they have been retrieved
 */
#undef DELETION

/*************************************************************************
 *
 * no user-serviceable parts beyond this point
 *
 *************************************************************************/

#define OK			"+OK"
#define POP_OK			"+OK"
#define MAX_LINE_LEN		1024
#define MAX_HOSTNAME_LEN	256
#define MAX_PORT_LEN		5
#define MAX_USERNAME_LEN	65
