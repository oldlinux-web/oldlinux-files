main()
{
	char string[50];
   sprintf(string,"man `basename %s .1`", "ar.1");
puts(string);
}
