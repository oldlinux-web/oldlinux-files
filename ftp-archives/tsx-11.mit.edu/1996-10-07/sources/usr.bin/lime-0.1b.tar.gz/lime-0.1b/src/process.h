/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/


extern  void	Process(void);
extern	int	Dispatch(char key);
extern	void	MenuJump(int ndx);
extern	void	MenuReturn(void);
extern	void	ExternalProcess(int ndx);
extern	void	ExecuteHook(int hook);
extern  int	CheckGroupAccess(char *groups);
extern  int     CheckPassword(char *password);
