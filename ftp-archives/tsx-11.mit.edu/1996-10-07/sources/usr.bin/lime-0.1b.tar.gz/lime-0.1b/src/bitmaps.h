/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

#define TITLE  		"LIME"
#define VERSION		"v.01b"
#define COPYRIGHT	"(C)opyright 1994-1995, B. Scott Burkett, All Rights Reserved"

#ifndef TRUE
	#define TRUE	1
	#define FALSE	!TRUE
#endif

/*****************************************************************************
			    Global System Limits
 *****************************************************************************/
#define MAXRETRIES	30

/*****************************************************************************
		            Menu type definitions
 *****************************************************************************/

#define	MENU_JUMP		1		/* Jump to another menu */
#define	MENU_QUIT   		2		/* Goodbye - log off    */
#define	MENU_RETURN     	3		/* Return to prev. menu */
#define	MENU_EXTERN     	4		/* External Process     */
#define MENU_DISPFILE   	10		/* Display text file    */
#define MENU_BLANK      	11		/* Blank menu item      */
#define MENU_SCREENSET  	16		/* Display a screen set */
#define MENU_SHOWFILE   	17		/* Display a single file*/
#define MENU_SHOWAFILE  	18		/* Display any file     */
#define MENU_DISPLAY    	19		/* Display a single line*/

/*****************************************************************************
 		               Interface Hooks
 *****************************************************************************/

#define	HOOK_MAIN	1
#define	HOOK_LOGOFF	2

/*****************************************************************************
 		               Input Types
 *****************************************************************************/

#define	ALPHA		0
#define	NUMERIC		1
#define ALPHACAPS	2

/*****************************************************************************
 		             Registration Types
 *****************************************************************************/

#define HOBBYIST     0x01
#define COMMERCIAL1  0x02
#define COMMERCIAL2  0x04

/*****************************************************************************
 		            File List Search Types
 *****************************************************************************/

#define LIST_NORMAL  1
#define LIST_NEW     2

/*****************************************************************************
 		           Client/Server Definitions
 *****************************************************************************/

#define LIME_CLIENT 	0
#define LIME_SERVER	1
#define LIME_MONITOR	2
#define LIME_CONF    3

