/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <ncurses.h>

#define XTERNDATA 1
#include "lime.h"

int _badopt;

int ShowMenu(char *menufile)
{
	char *ptr;
	char buf[100];

	if((mnu = fopen(menufile, "rt")) == NULL)
	{
		SystemMessage("Unable to open menu file!", TRUE);
		if(!currmenu)
			Shutdown();
		else
		{
			currmenu--;
			return(FALSE);
		}
	}

	sflag=0;
	menu.prompt[0] = '\0';

	/* Process each section block of the menu file */
	do {
		fgets(buf, 250, mnu);
		if(feof(mnu)) break;

		if(!strncmp(buf, ".externalmenucolor", 17)) {
			ptr = strtok(buf, " "); 
			ptr = strtok(NULL, "\n\x0"); 
			strcpy(menu.externcol, ptr);
			continue;
		}

		/* Handle external menus */
		if(!strncmp(buf, ".externalmenu", 13))
		{
			ptr = strtok(buf, " ");	
			ptr = strtok(NULL, " ");
			if(ptr)
			{
				_internal_menus=FALSE;
				strcpy(menu.file, ptr);
				strichg(menu.file, '\n', '\0');
				ColorStr(menu.externcol);
				ScreenSet(menu.file, FALSE);
				/* ShowFile(menu.file, FALSE, FALSE); */
			}
			continue;
		}


		/* Handle internal menus */
		if(!strncmp(buf, ".menutitle", 9))
		{
			/* Get the name of the screen file here */
			/* For now, let's just do internal menus */

			_internal_menus=TRUE;	
			ptr = strtok(buf, "\""); 
			ptr = strtok(NULL, "\""); 
			if(ptr)
			{
				strcpy(menu.title, ptr);
				strichg(menu.title, '\"', ' ');
			}	
			continue;
				
		}

		/* Load up option structure */
		if(!strncmp(buf, ".options", 8))
		{
			if(_internal_menus)
				DisplayTitle();
			ReadOptions();
			continue;
		}

		/* Load up prompt field */
		if(!strncmp(buf, ".prompt", 7))
		{
			ptr = strtok(buf, " "); 
			ptr = strtok(NULL, "\n\x0"); 
			Macros((char *)&menu.prompt);
			strcpy(menu.prompt, ptr);
			continue;
		}
	
		if(!strncmp(buf, ".color_prompt", 13))
		{		
			ptr = strtok(buf, " ");
			ptr = strtok(NULL, "\n\x0");
			strcpy(menu.promptcol, ptr);
			continue;
		}
	
		if(!strncmp(buf, ".color_brackets", 15))
		{		
			ptr = strtok(buf, " ");
			ptr = strtok(NULL, "\n\x0");
			strcpy(menu.bracketcol, ptr);
			continue;
		}

		if(!strncmp(buf, ".color_hotkeys", 14))
		{		
			ptr = strtok(buf, " ");
			ptr = strtok(NULL, "\n\x0");
			strcpy(menu.hotkeycol, ptr);
			continue;
		}

		if(!strncmp(buf, ".color_passwd_prompt", 21))
		{		
			ptr = strtok(buf, " ");
			ptr = strtok(NULL, "\n\x0");
			strcpy(menu.pwdpromptcol, ptr);
			continue;
		}

	} while(!feof(mnu));		

	fclose(mnu);

	if(menu.prompt[0] == '\0')
		DisplayPrompt();
	else
	{
		Macros((char *)&menu.prompt);
		ColorStr(menu.promptcol);
		printf(menu.prompt);
		SetColor(ANSI_NORMAL, ANSI_NORMAL, ANSI_NORMAL); 
		printf("[ ]\b\b");
		fflush(stdout);
		
	}

	return(TRUE);
}

void DisplayLine(int firsttime)
{
	char *ptr;

	if(!firsttime)
 	{
		waddch(desktop, '\n');
		waddch(desktop, '\r');
	}

	wattron(desktop, COLOR_PAIR(2));
	ptr = (char *)&buf;

	while(*ptr != '\n')
	{
		/* Check for embedded color codes */
		if(*ptr == '@')
		{
			switch (*(ptr+1))
			{
				case '1':	color_value=1; break;
				case '2':	color_value=2; break;
				case '3':	color_value=3; break;
				case '4':	color_value=4; break;
				case '5':	color_value=5; break;
				case '6':	color_value=6; break;
				case '7':	color_value=7; break;
				case 'S':	if(sflag) 
							sflag=0;
						else
							sflag=1;
						break;
				case 'U':	wprintw(desktop, "%s", username); break;
				 default:       color_value=2; break;
			}

			if (sflag) {
				wattron(desktop, COLOR_PAIR(color_value)|A_STANDOUT);
			}
			else 
			{
				wattroff(desktop, COLOR_PAIR(color_value)|A_STANDOUT);
				wattron(desktop, COLOR_PAIR(color_value));
			}
			ptr = ptr+2;
			continue;
		}
		
		waddch(desktop, *ptr);
		ptr++;
	}
	
}

void ReadOptions(void)
{
	int cntr=0;

	do {
		fgets(buf, 250, mnu);
		if(feof(mnu)) break;

		if ( buf[0] == ';' ) continue; 
		if ( buf[0] == '#' ) continue; 
		if ( buf[0] == '%' ) continue; 
		if ( buf[0] == '\n' ) continue; 
		if ( buf[0] == '\r' ) continue; 
	
		if(!strncmp(buf, ".end", 4))
			break;
	
		ParseOption(cntr);
		if(_badopt)
	 	{
			_badopt = FALSE;
			continue;
		}

/* FIX */
		/* if(_internal_menus && menu.options[cntr].security <= profilebuf.security) */
		if(_internal_menus && CheckGroupAccess(menu.options[cntr].groups) )
		{
			if(menu.options[cntr].type == MENU_BLANK)
			{
				printf("\n\r");
			}
			else
			if(menu.options[cntr].type == MENU_DISPLAY)
			{
				strcpy(buf, menu.options[cntr].desc);	
				Macros((char *)&buf);
				if(menu.options[cntr].color[0] == '\0')
					SetColor(ANSI_NORMAL, ANSI_FWHITE, ANSI_BBLACK);
				else
					ColorStr((char *)&menu.options[cntr].color);	
				
				printf("%s\n\r", buf);		
			}
			else
			{
				if(menu.bracketcol[0] == '\0')
					SetColor(ANSI_NORMAL, ANSI_FCYAN, ANSI_BBLACK);
				else
					ColorStr((char *)&menu.bracketcol);
				printf("[");
		
				if(menu.hotkeycol[0] == '\0')
					SetColor(ANSI_BRIGHT, ANSI_FCYAN, ANSI_BBLACK);
				else
					ColorStr((char *)&menu.hotkeycol);
				printf("%c", menu.options[cntr].key);

				if(menu.bracketcol[0] == '\0')
					SetColor(ANSI_NORMAL, ANSI_FCYAN, ANSI_BBLACK);
				else
					ColorStr((char *)&menu.bracketcol);
				printf("] ");
	
				if(menu.options[cntr].color[0] == '\0')	
					SetColor(ANSI_NORMAL, ANSI_FWHITE, ANSI_BBLACK);
				else
					ColorStr((char *)&menu.options[cntr].color);	
				printf("%s\n\r", menu.options[cntr].desc);
			}
		}
	
		cntr++;
		highoption=cntr;

	} while(!feof(mnu));
} 

void ParseOption(int cntr)
{
	char *ptr;

	ptr = (char *)strtok(buf, ",");
 	menu.options[cntr].key = toupper(*ptr);

	ptr = (char *)strtok(NULL, ",");
	if(!strncmp(ptr, "jump", 4)) {
		menu.options[cntr].type=MENU_JUMP;
	} else
	if(!strncmp(ptr, "goodbye", 6)) {
		menu.options[cntr].type=MENU_QUIT;
	} else
	if(!strncmp(ptr, "return", 6)) {
		menu.options[cntr].type=MENU_RETURN;
	} else
	if(!strncmp(ptr, "extern", 6)) {
		menu.options[cntr].type=MENU_EXTERN;
	} else
	if(!strncmp(ptr, "blank", 5)) {
		menu.options[cntr].type=MENU_BLANK;
	} else
	if(!strncmp(ptr, "screenset", 9)) {
		menu.options[cntr].type=MENU_SCREENSET;
	} else
	if(!strncmp(ptr, "showfile", 8)) {
		menu.options[cntr].type=MENU_SHOWFILE;
	} else
	if(!strncmp(ptr, "display", 7)) {
		menu.options[cntr].type=MENU_DISPLAY;
	} else
	if(!strncmp(ptr, "showanyfile", 11)) {
		menu.options[cntr].type=MENU_SHOWAFILE;
	} else
		_badopt=TRUE;

	ptr = (char *)strtok(NULL, ",");
	strcpy(menu.options[cntr].desc, ptr);

	ptr = (char *)strtok(NULL, ",");
/* FIX */
	/* menu.options[cntr].security = atol( ptr ); */
	strcpy(menu.options[cntr].groups,ptr);

	ptr = (char *)strtok(NULL, ",");
	if(ptr) {
		strcpy(menu.options[cntr].secondary, ptr);
		strichg(menu.options[cntr].secondary, '\n', '\0');
		strbtrim(menu.options[cntr].secondary);
	}
		else
			menu.options[cntr].secondary[0]='\0';

	ptr = (char *)strtok(NULL, ",");
	if(ptr) {
		if(*ptr=='*')
			menu.options[cntr].password[0] = '\0';	
		else
		{			
			strcpy(menu.options[cntr].password, ptr);
			strichg(menu.options[cntr].password, '\n', '\0');
			strbtrim(menu.options[cntr].password);
		}
	}
	  	else
			menu.options[cntr].password[0]='\0';

	ptr = (char *)strtok(NULL, ",");
	if(ptr) {
		strcpy(menu.options[cntr].color, ptr);
		strichg(menu.options[cntr].color, '\n', '\0');
		strbtrim(menu.options[cntr].color);
	}
	  	else
			menu.options[cntr].color[0]='\0';
}

void DisplayTitle(void)
{
	int len, x;
	int offset;

	ClearScreen();

	SetColor(ANSI_NORMAL, ANSI_FBLUE, ANSI_BWHITE);
	len = strlen(menu.title);	
	
	offset = (80-len) /2;
	for(x=0; x<offset; x++)
		printf(" ");
	printf(menu.title);
	for(x=offset+len; x<80; x++)
		printf(" ");

	printf("\n\r\n\r"); 
}

void DisplayPrompt(void)
{
	kernel(); 
	SetColor(ANSI_NORMAL, ANSI_FBLUE, ANSI_BWHITE);
	printf("\n\r[%s -> Select]:", getenv("LOGNAME"));
	SetColor(ANSI_NORMAL, ANSI_NORMAL, ANSI_NORMAL);
	printf("[ ]\b\b");
	fflush(stdout);
}

