/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

extern  void	Init(void);
extern  void	GetTerminalSettings(void);
extern  void	ConnectMessage(void);	  
extern  void	ReadCTLFile(void);
extern  void    ReadLine(void);
extern  void	ModifyString(char *key, char *val);

