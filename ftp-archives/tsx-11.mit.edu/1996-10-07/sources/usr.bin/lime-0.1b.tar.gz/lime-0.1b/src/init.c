/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <ncurses/ncurses.h>
#include <unistd.h>
#include <regex.h>

#include "lime.h"

#include "protos.h"

void ConnectMessage();

void Init(void)
{
	char *ptr;

	/* Try to get LIME environment variable */
	ptr = getenv("LIME");

	/* If LIME isn't set, bitch loudly */
	if(!ptr)
	{
		fprintf(stderr, "ERROR:  LIME shell variable not set!");
		Shutdown();
	}

	strcpy(home, ptr);

	SetAlarm();
	SetTraps();

	ReadCTLFile();
	InitializeLog();

	SetAlarm();
	SetTraps();

	/* if(!_ansi) */
		GetTerminalSettings();

	initscr();
	raw();
	noecho();
	desktop = stdscr;

	GetUserInfo(); 
	ConnectMessage();

	/* Get user information from environment */
	PressEnter();

	ScreenSet("welcome", TRUE);
	return;
}

void GetTerminalSettings(void)
{
	char *envset; 
	TTYCFG ttycfg;
	FILE *tcfg;

	/* Is TERM set? */
	envset = getenv("TERM");

	sprintf(buf, "%s/data/limeterm.conf", home);

	if((tcfg = fopen(buf, "r")) == NULL)
	{
		fprintf(stderr, "ERROR: Unable to open %s!\n", buf);
		Shutdown();
	}

	do {
		fgets(buf, 80, tcfg);
		if(feof(tcfg)) break;

		/* Skip any comments */
		if(buf[0] == ';') continue; 
		if(buf[0] == '%') continue; 
		if(buf[0] == '#') continue; 
		if(buf[0] == '\n') continue; 

		/* Parse into fields */
		sscanf(buf, "%s %c", &ttycfg._ttydevice, &ttycfg._ansi);
		ttycfg._ansi = toupper(ttycfg._ansi);

		/* Construct regular expression pattern */
		re_comp( ttycfg._ttydevice );

		/* Check for match against current TERM setting */
		if( re_exec( envset ) )
		{
			if(ttycfg._ansi == 'Y')
			{
				_ansi = TRUE;
				break;
			}
			else
			{
				_ansi = FALSE;
				break;
			}
		}
	
	} while(!feof(tcfg));

	fclose(tcfg);
}

void ConnectMessage(void)
{
	ClearScreen();
	SetColor(ANSI_BRIGHT, ANSI_BBLACK, ANSI_FWHITE);
	printf(TITLE " " VERSION "\n\r");
	SetColor(ANSI_BRIGHT, ANSI_BBLACK, ANSI_FCYAN);
	printf("The Definitive Interactive Menu System for Linux\n\r");
	SetColor(ANSI_BRIGHT, ANSI_BBLACK, ANSI_FBLUE);
	printf(COPYRIGHT "\n\r\n\r");
	fflush(stdout);
	sleep(1);

	SetColor(ANSI_NORMAL, ANSI_NORMAL, ANSI_NORMAL);
	printf("\n\rWelcome back: ");
	SetColor(ANSI_BRIGHT, ANSI_FWHITE, ANSI_BBLACK);
	printf("%s\n\r", getenv("LOGNAME"));

	sprintf(logbuf, "User logging in: %s", getenv("LOGNAME"));
	Log(logbuf);
}

void ReadCTLFile(void)
{
	char *ptr, *ptr2;

	/* Open up control file for reading */

	if(ctlfile[0] == '\0')
		strcpy(ctlfile, "lime.ctl");	/* default, for rubes */

	sprintf(buf, "%s/data/%s", home, ctlfile);
	if((ctl = fopen(buf, "rt")) == NULL)
	{
		perror("ReadCTLFile(lime.ctl)");
		exit(1);
	}

	do {

		ReadLine();
		if(feof(ctl)) break;

		ptr2 = ptr = (char *)strtok(buf, "\t ");
		ptr2 += strlen(ptr) + 1;

		ModifyString(ptr, ptr2);

	} while(!feof(ctl));	

	/* Close control file */
	fclose(ctl);

}

void ReadLine(void)
{
	
	do {
		fgets(buf, 80, ctl);
		if(feof(ctl)) break;

		if(buf[0] == '\n') continue;
		if(buf[0] == '\r') continue;
		if(buf[0] == ';') continue;
		if(buf[0] == '#') continue;
		if(buf[0] == '%') continue;

		break; 

	} while(!feof(ctl));

}

void ModifyString(char *key, char *val)
{

	strbtrim(key);
	strbtrim(val);

	if(!strncmp(key, "SYSOPNAME", 9))
	{
		strcpy(sysopname, val);
		return;
	}

	if(!strncmp(key, "SYSTEMNAME", 10))
	{
		strcpy(systemname, val);
		return;
	}
	
	if(!strncmp(key, "LOCATION", 8))
	{
		strcpy(location, val);
		return;
	}
	
	if(!strncmp(key, "MENUPATH", 8))
	{
		strcpy(menupath, val);
		return;
	}

	if(!strncmp(key, "SCREENPATH", 6))
	{
		strcpy(screenpath, val);
		return;
	}

	if(!strncmp(key, "LOGFILEPATH", 11))
	{
		strcpy(logpath, val);
		return;
	}

	if(!strncmp(key, "MAINMENUHOOK", 12))
	{
		strcpy(hook_main, val);
		return;
	}

	if(!strncmp(key, "NEWUSERMENUHOOK", 15))
	{
		strcpy(hook_newuser, val);
		return;
	}

	if(!strncmp(key, "LOGOFFHOOK", 10))
	{
		strcpy(hook_logoff, val);
		return;
	}

	if(!strncmp(key, "PAGER", 5))
	{
		strcpy(pager, val);
		return;
	}

	if(!strncmp(key, "NEWUSERLOGIN", 12))
	{
		strcpy(newuserlogin, val);
		return;
	}

	if(!strncmp(key, "TIMEOUT", 7))
	{
		timeoutval=atol(val);
		return;
	}

	if(!strncmp(key, "TIMELIMIT", 9))
	{
		timelimit=atol(val);
		return;
	}

	if(!strncmp(key, "NEWUSERPROFILE", 14))
	{
		newuserprofile=atol(val);
		return;
	}

	if(!strncmp(key, "STARTFILEAREA", 13))
	{
		startfilearea=atol(val);
		return;
	}

	if(!strncmp(key, "ASCIICOL", 8))
	{
		strcpy(ASCIICOL, val);
		return;
	}

	if(!strncmp(key, "FLISTBRACKETCOL", 15))
	{
		strcpy(FLISTBRACKETCOL, val);
		return;
	}

	if(!strncmp(key, "FLISTAREANUMCOL", 15))
	{
		strcpy(FLISTAREANUMCOL, val);
		return;
	}

	if(!strncmp(key, "FLISTAREADESCCOL", 16))
	{
		strcpy(FLISTAREADESCCOL, val);
		return;
	}

	if(!strncmp(key, "FILEFREECOL", 11))
	{
		strcpy(FILEFREECOL, val);
		return;
	}

	if(!strncmp(key, "FILEBRACKETCOL", 14))
	{
		strcpy(FILEBRACKETCOL, val);
		return;
	}

	if(!strncmp(key, "FILENUMCOL", 10))
	{
		strcpy(FILENUMCOL, val);
		return;
	}

	if(!strncmp(key, "FILENAMECOL", 11))
	{
		strcpy(FILENAMECOL, val);
		return;
	}

	if(!strncmp(key, "FILETEXTCOL", 11))
	{
		strcpy(FILETEXTCOL, val);
		return;
	}

	if(!strncmp(key, "FILEULDATECOL", 13))
	{
		strcpy(FILEULDATECOL, val);
		return;
	}

	if(!strncmp(key, "FILESIZECOL", 11))
	{
		strcpy(FILESIZECOL, val);
		return;
	}

	if(!strncmp(key, "FILEDESCCOL", 11))
	{
		strcpy(FILEDESCCOL, val);
		return;
	}

	if(!strncmp(key, "FILETAGCOL", 10))
	{
		strcpy(FILETAGCOL, val);
		return;
	}

	if(!strncmp(key, "INPUTBRACKETCOL", 15))
	{
		strcpy(INPUTBRACKETCOL, val);
		return;
	}

	if(!strncmp(key, "USERINPUTCOL", 12))
	{
		strcpy(USERINPUTCOL, val);
		return;
	}
}
