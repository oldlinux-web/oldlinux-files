/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>
#include <unistd.h>
#include <time.h>
#include <sys/signal.h>

#include "lime.h"

time_t next_minute;

void kernel(void)
{
	/* Reset inactivity alarm */
	SetAlarm();
}

void TimeExpired(void)
{
	SystemMessage("Time limit expired!", FALSE);
	ScreenSet("timelimit", FALSE);
	Log("Time limit expired!  Logging user off ...");
	Shutdown();
}

