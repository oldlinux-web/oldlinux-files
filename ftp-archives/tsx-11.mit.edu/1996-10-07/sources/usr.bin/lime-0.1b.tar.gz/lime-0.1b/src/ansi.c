/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ncurses.h>
#include <unistd.h>

#include "ansi.h"
#include "lime.h"

void SetColor(int attr, int bg, int fg)
{
	if(!_ansi)
		return;
	else
		printf("\033[%u;%u;%um", attr, bg, fg);
}

void ClearScreen(void)
{
	if(_ansi) 
		printf("\033[2J\033[0;0H");
	else 
	{
		/* printf("\n\r\n\r\n\r"); */
		wclear(stdscr);
		wrefresh(stdscr);
	}
	fflush(stdout);	
	return;

}

int ShowFile(char *filename, int pause, int any)
{
	FILE *in;
	int _ok=FALSE, _exitflag=FALSE;
	int  cntr=1;
	char key;

	/* Try for the ANSI version */
	if(_ansi && !any)
	{
		sprintf(buf, "%s/%s", screenpath, filename);

		strcat(buf, ".ans");
		if(!access(buf, F_OK))
			_ok = TRUE;	
	}

	/* Try for the ASCII version */
	if(!_ok && !any)	
	{	
		sprintf(buf, "%s/%s", screenpath, filename);
		strcat(buf, ".asc");
		if(!access(buf, F_OK))
			_ok=TRUE;

		ColorStr("white on black");
	}

	
	if(!_ok && !any)	
		return(FALSE);	

	if(any)
		strcpy(buf, filename);

	if((in = fopen(buf, "rt")) == NULL)
		return(FALSE);

	ClearScreen();

	do
	{
		fgets(buf, 250, in);
		if(feof(in)) 
		{
			cntr=99;
		}
		else
		{
			Macros((char *)&buf);

			printf(buf);
	
			if(!strocc(buf, '\r'))
				printf("\r");
	
			cntr++;
		}

		if(cntr == 99)
		{
			if(pause)
				PressEnter();
			break;
		}

		if(cntr >= 23)
		{
			key = PagePrompt("YN ", "More? [Y(es)/n(o)]");
	
			switch(key)
			{
				case 'N': _exitflag = TRUE; cntr=0; break;
				case 'Y':
				 default: _exitflag = FALSE; cntr=0; 
					  ClearScreen(); 
					  break;
			}
		}

		if(_exitflag)
			break;

	} while(!feof(in));
	
	fclose(in);

	fflush(stdout);

	return(TRUE);
}

/* Function to run through a set of screens */

void ScreenSet(char *basename, int pause)
{
	int cntr=1;

	/* Do the ones that have security levels attached to them */
	do 
	{
		sprintf(buf2, "%s.%d.%d", basename, egid, cntr);
		cntr++;
		if(ShowFile(buf2, pause, FALSE))
			continue;
		break;			

	} while(TRUE);

	cntr=1;

	/* Now make a run through any normal members of a screen set */
	do 
	{
		sprintf(buf2, "%s%d", basename, cntr);
		cntr++;
		if(ShowFile(buf2, pause, FALSE))
			continue;
		break;			
	} while(TRUE);
}

void Macros( char *buf)
{
	char tmp[20];

	strsrep(buf, "@U", getenv("LOGNAME"));
	strsrep(buf, "@L", getenv("LOGNAME"));

	strsrep(buf, "@N", tmp);

	sprintf(tmp, "%d", egid);
 	strsrep(buf, "@S", tmp);

	sprintf(tmp, "%lu", timeleft);
	strsrep(buf, "@M", tmp);	
}

void ColorStr(char *color_string)
{
	char *start=(char *)color_string;
	char *end;
	int  length;
	int  identifier;
	char foreground=TRUE;
	char token[50];
	int  _fg=0, _bg=0, _attr1=0, _attr2=0;

	if(!_ansi)
		return;

	while( *start && *start != '\0')
	{
		if( *start == ' ' || *start == '\t')
			start++;
		else
		{
			length=0;
			end=(char *)start;

			while(*end && *end!='\0' && *end != ' ' && *end != '\t')
			{
				++length;	
				++end;
			}
		
			if(length>39) length=39;
			strncpy(token, start, length);			
			token[length]='\0';
			strupper(token);			

			start = end;

			for(identifier=0; identifier<10; identifier++)
			{
				if(!strcmp(colors[identifier], token))
				{
					if(identifier <= 7)
					{
						if(foreground)
						{
							foreground=FALSE;	
							_fg=identifier+30;
						}   
						else
						{
							_bg=identifier+40;
						}
					}

					if(identifier == 8)
						_attr1 = ANSI_BRIGHT;
	
					if(identifier == 9)
						_attr2 = ANSI_BLINK;
				}
			}
		}
	}

	/* Must at least have these two set! */

	if(_fg && _bg)
	{
		if(_attr1 && !_attr2)
			printf("\033[%u;%u;%um", _attr1, _bg, _fg);
		else
		if(_attr2 && !_attr1)
			printf("\033[%u;%u;%um", _attr2, _bg, _fg);
		else
		if(_attr1 && _attr2)
			printf("\033[%u;%u;%u;%um", _attr1, _attr2, _bg, _fg);
		else
			printf("\033[0;%u;%um", _bg, _fg);

	}
}

