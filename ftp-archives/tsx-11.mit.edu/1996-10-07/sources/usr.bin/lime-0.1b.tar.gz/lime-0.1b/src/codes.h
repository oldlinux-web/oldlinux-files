/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

/*****************************************************************************
 		            Server Request Codes
 *****************************************************************************/

#define NODEREQUEST		1         	/* Request for node number */
#define UPDATEUSERLOGIN   	2		/* Pass user login to server */
#define UPDATEUSERNAME		3		/* Pass user name to server */
#define UPDATEUSERCITY		4		/* Pass user city to server */
#define UPDATEUSERTASK		5		/* Updated user status line */
#define USERLOGOFF		6		/* User logging out */

