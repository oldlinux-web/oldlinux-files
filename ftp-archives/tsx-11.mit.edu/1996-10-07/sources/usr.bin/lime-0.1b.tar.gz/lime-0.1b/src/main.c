/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <ncurses.h>

#include "bitmaps.h"
#include "ansi.h"
#include "bitmaps.h"
#include "structs.h"
#include "dsect.h"
#include "strlib.h"

#include "protos.h"

int main(int argc, char *argv[])
{
	ParseCmdLine(argc, argv);
	Init();
	Process();
	Shutdown();
	exit(0);
}

/***************************************************************************
 *                                                                         *
 * void ParseCmdLine(int ac, char *av[]);                                  *
 *                                                                         *
 * This function is responsible for parsing the command line and      	   *
 * setting any parameters wihch are configurable from the command line.    *
 *                                                                         *
 ***************************************************************************/

void ParseCmdLine(int ac, char *av[])
{
	int i, j;
	char	*p;

	if(ac==1) {
		printf("\n\rLIME " VERSION " the Definitive LInux MEnuing System\n\r");
		printf("(C)opyright 1994-1995, B. Scott Burkett, All Rights Reserved\n\r\n\r");

		printf("USAGE: ");
		printf("lime: [any combo of the following:]\n\r");
		printf("       -a(ANSI mode (force))\n\r");
		printf("       -c(control file name (in data dir))\n\r");
		printf("       -m(menu file name (in menu dir))\n\r");
		printf("       -d(Enable debug logging)\n\r\n\r");
		exit(255);
	}

	for(i = 1; i < ac; i++)
	{
		p = av[i];
		if(*p == '-' || *p == '/')
		{
			for(j = 1; *(p + j); j+=strlen(p + 1))
			{
				switch(tolower(*(p + j)))
				{

					case 'a': _ansi = TRUE; 
						  break;

					case 'd': _debug = TRUE; 
						  break;
           					  
            				case 'm': strsrep(p, "-m", "  ");
                      				  strbtrim(p);
                      				  strcpy(menuname, p);
                      			  	  break;

            				case 'c': strsrep(p, "-c", "  ");
                      				  strbtrim(p);
                      				  strcpy(ctlfile, p);
                      			  	  break;
						  
						  
				}
			}
		}
		else			     /* unknown parameter	     */
			return;
	}

return;
}
