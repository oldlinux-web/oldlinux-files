/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <curses.h>
#include <signal.h>

#include "lime.h"
#include "protos.h"

/* This function is provided to allow limed to share source with lime */
void err_sys(char *msg)
{
	SystemMessage(msg, TRUE);
	Shutdown();
}

void Shutdown(void)
{
	if(_active_conf)
		unlink(conffile);

	CloseLog();

	noraw();

	if(stdscr)
		endwin();

	RemoveTraps();
	TurnOffAlarm();

/* Ignore this crap for now...

	signal(SIGHUP, SIG_IGN); 

	kill(-(getpgrp()), SIGHUP);
*/
	/* killpg(0, SIGTERM); */
	exit(0);
}

