/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/un.h>

#ifdef XTERNDATA
#define	DEFSEG	extern
#endif

#ifndef XTERNDATA 
#define	DEFSEG	
#endif

#ifndef XTERNDATA

char *colors[12]={
	"BLACK", "RED", "GREEN", "YELLOW", "BLUE", "MAGENTA", "CYAN",     
	"WHITE", "BRIGHT", "FLASHING"
};

#else
extern char *colors[];
#endif 

DEFSEG	char username[15];			/* User's name */
DEFSEG	WINDOW *desktop;			/* Main desktop window */
DEFSEG  int  _colors;
DEFSEG  char buf[255];
DEFSEG  char buf2[255];
DEFSEG  char logbuf[255];
DEFSEG  gid_t egid;
DEFSEG  int _debug;
DEFSEG  int _internal_menus;
DEFSEG  int _ansi;
DEFSEG  int highoption;
DEFSEG  int areanum;
DEFSEG  int _newuser;
DEFSEG  int currfilearea;
DEFSEG  int tagcount;
DEFSEG  int dl_bytecount;
DEFSEG  int _showscreens;
DEFSEG  int node;
DEFSEG  long timeoutval;
DEFSEG  long timelimit, timeleft;
DEFSEG  long newuserprofile;
DEFSEG  long startfilearea;

DEFSEG  char socketbuf[80];

DEFSEG  char sysopname[60];			/* Name of system operator */
DEFSEG  char systemname[60];			/* Name of system */
DEFSEG  char location[60];			/* Location of site */
DEFSEG  char menuname[80];

/*************** File Handles */
DEFSEG  FILE *ctl;
DEFSEG  FILE *mnu;
DEFSEG  FILE *log;

/*************** Misc. Paths  */
DEFSEG	char ctlfile[UNIX_PATH_MAX];		/* .ctl file to use */
DEFSEG	char screenpath[UNIX_PATH_MAX];	  	/* Path to textfiles */
DEFSEG	char menupath[UNIX_PATH_MAX];		/* Path to .mnu files */
DEFSEG  char logpath[UNIX_PATH_MAX];		/* Path to logfiles */
DEFSEG  char client_socket_path[UNIX_PATH_MAX]; /* Client socket path */

/*************** Interface hooks */
DEFSEG	char hook_main[80];
DEFSEG	char hook_newuser[80];
DEFSEG	char hook_logoff[80];

/*************** Global data objects */
DEFSEG  _MENU	menu;				/* Global menu object */
DEFSEG  char    menustack[10][30];		/* Menu stack (10 max) */
DEFSEG	int	currmenu;			/* Current menu stack index */
DEFSEG  int	sflag;				/* Standout video mode */
DEFSEG  int	color_value;			/* Current color */
DEFSEG  char	home[60];			/* LIME home directory */
DEFSEG  char	pager[60];			/* Designated pager util */
DEFSEG  char    newuserlogin[20];		/* New user login */

DEFSEG  char  *ptrs[64];			/* Generic pointers */

/*************** Custom Colors */
DEFSEG  char 	ASCIICOL[40];			/* ASCII in ANSI mode color */
DEFSEG  char	FLISTBRACKETCOL[40];		/* File area list brackets  */
DEFSEG  char    FLISTAREANUMCOL[40];		/* File area numbers        */
DEFSEG  char    FLISTAREADESCCOL[40];		/* File area descriptions   */
DEFSEG  char    FILEBRACKETCOL[40];		/* File bracket color       */
DEFSEG  char    FILENUMCOL[40];			/* File number color 	    */
DEFSEG  char    FILENAMECOL[40];		/* Filename color     	    */
DEFSEG  char	FILEFREECOL[40];		/* File area free color     */
DEFSEG  char    FILETEXTCOL[40];		/* File static text color   */
DEFSEG  char    FILEULDATECOL[40];		/* File UL date color	    */
DEFSEG  char    FILESIZECOL[40];		/* File size colors         */
DEFSEG  char    FILEDESCCOL[40];		/* File description color   */
DEFSEG  char    FILETAGCOL[40];			/* File tag color	    */
DEFSEG  char    INPUTBRACKETCOL[40];		/* Input bracket color      */
DEFSEG  char    USERINPUTCOL[40];		/* User input color 	    */
DEFSEG  char    PROTOBRACKETCOL[40];		/* Protocol bracket color   */
DEFSEG  char    PROTONUMCOL[40];    		/* Protocol number color    */
DEFSEG  char    PROTONAMECOL[40];   		/* Protocol name color      */

/************** Registration data */
DEFSEG  char    RegMsg[80];
DEFSEG  int     maxnodes;
DEFSEG  char    RegName[80];
DEFSEG  char    RegLevel[80];
DEFSEG  unsigned long    regcode;
DEFSEG  unsigned long    RegType;
DEFSEG  char	asciinode[10];

DEFSEG  int	confid;
DEFSEG  key_t	confkey;

DEFSEG	char	conffile[80];			/* Path of IPC key file       */
DEFSEG  int	_active_conf;			/* T/F is user has a conf     */
DEFSEG  char	*confptr;			/* Offset of conf shm segment */

