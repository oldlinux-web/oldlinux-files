/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <ncurses.h>
#include <unistd.h>
#include <time.h>

#include "lime.h"

void InitializeLog(void)
{
	time_t timer;

	if(logpath[0] == '\0')
		return;

	sprintf(buf, "%s/lime.%s.log", logpath, getenv("LOGNAME"));
	if((log = fopen(buf, "at")) == NULL)
	{
		SystemMessage("Unable to open log file!", TRUE);
		Shutdown();
	}
  
	/* Print logfile tear line */
	timer=time(NULL);
   
	fprintf(log,"\n----------  [LIME %s] %s", VERSION, ctime(&timer));

        fflush(log);        
}

void CloseLog(void)
{
	if(logpath[0] == '\0')
		return;

	Log("Shutting down...");
	fflush(log);
	fclose(log);
}

void Log(char *msg)
{
	time_t timer;
	struct tm *tblock;
	char *string;
		
	if(logpath[0] == '\0')
		return;

 	timer=time(NULL);
	tblock=localtime(&timer);

	/* Determine which logfile format string to use */
	if(tblock->tm_hour<10)
		string=(char *)">  %1.1d:%02.2d:%02.2d  %s\n";
	else
		string=(char *)"> %2.2d:%02.2d:%02.2d  %s\n";

	/* Write a line to the logfile */
	fprintf(log,string,tblock->tm_hour,tblock->tm_min,tblock->tm_sec,msg);

	fflush(log);
}

