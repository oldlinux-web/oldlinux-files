/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

extern	void	SetColor(int attr, int fg, int bg);
extern	void	ClearScreen(void);
extern	int	ShowFile(char *filename, int pause, int any);
extern	void	ScreenSet(char *basename, int pause);
extern	void	Macros(char *buf);
extern	void	ColorStr(char *color_string);

/*********************************** attributes */
#define ANSI_NORMAL			0
#define ANSI_BRIGHT			1
#define ANSI_UNDERLINE			4
#define ANSI_BLINK			5
#define ANSI_INVERSE			7
#define ANSI_INVISIBLE			8

/*********************************** foreground */
#define ANSI_FBLACK			30
#define ANSI_FRED			31
#define ANSI_FGREEN			32
#define ANSI_FYELLOW			33
#define ANSI_FBLUE 			34
#define ANSI_FMAGENTA			35
#define ANSI_FCYAN			36
#define ANSI_FWHITE			37

/*********************************** background */
#define ANSI_BBLACK			40
#define ANSI_BRED			41
#define ANSI_BGREEN			42
#define ANSI_BYELLOW			43
#define ANSI_BBLUE 			44
#define ANSI_BMAGENTA			45
#define ANSI_BCYAN			46
#define ANSI_BWHITE			47

