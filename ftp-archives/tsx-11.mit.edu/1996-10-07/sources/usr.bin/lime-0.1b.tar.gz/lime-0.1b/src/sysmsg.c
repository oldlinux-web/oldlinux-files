/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

#include <stdio.h>
#include <ncurses.h>

#include "lime.h"

void SystemMessage(char *msg, int pause)
{
	SetColor(ANSI_NORMAL, ANSI_FCYAN, ANSI_BBLACK);
	printf("\n\r[");
	SetColor(ANSI_BRIGHT, ANSI_FCYAN, ANSI_BBLACK);
	printf(" %s ", msg);
	SetColor(ANSI_NORMAL, ANSI_FCYAN, ANSI_BBLACK);
	printf("] ");

	fflush(stdin);
	fflush(stdout);

	if(pause)
		PressEnter();
}
