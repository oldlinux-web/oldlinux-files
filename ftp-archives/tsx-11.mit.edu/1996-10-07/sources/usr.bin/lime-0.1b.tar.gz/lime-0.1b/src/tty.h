/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

extern  char	*GetString(int type, int mode, int _forced, int maxlen);
extern	void	PressEnter(void);
extern  char	PagePrompt(char *keylist, char *keydisp);


