/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

/* Header file for string functions */

#define  strbtrim(s)    strtrim(strltrim(s))
#define  strleft(s,n)   strmid(s,0,n)
#define  strright(s,n)  strmid(s,strlen(s)-n,n)
#define  strrtrim(s)    strtrim(s)

#ifdef XTERNDATA
#  define DEFSEG extern
#else
#  define DEFSEG
#endif

DEFSEG int strchg(char *s, char a, char b);
DEFSEG char *strsrep(char *s, char *a, char *b);
DEFSEG char *strtrim(char *s);
DEFSEG char *strdel(char *a, char *s);
DEFSEG char *strins(char *a, char *s, int p);
DEFSEG char *strinc(char *a, char *s);
DEFSEG char *strcode(char *s, char *k);
DEFSEG char *strltrim(char *s);
DEFSEG char *strschg(char *s, char *a, char *b);
DEFSEG char *strischg(char *s, char *a, char *b);
DEFSEG char *strisrep(char *s, char *a, char *b);
DEFSEG char *stridel(char *a, char *s);
DEFSEG char *striinc(char *a, char *s);
DEFSEG char *struplow(char *s);
DEFSEG char *strupper(char *s);
DEFSEG char *strlower(char *s);
DEFSEG char touplow(char *s, char *p, char c);
DEFSEG char *strsetsz(char *s, int n);
DEFSEG int strichg(char *s, char a, char b);
DEFSEG char *strischg(char *s, char *a, char *b);
DEFSEG char *strrol(char *s, int n);
DEFSEG char *strshl(char *s, int n);
DEFSEG int  strocc(char *s, char c);
DEFSEG int  strblank(char *s);
