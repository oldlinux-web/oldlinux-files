/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/


extern	int	ShowMenu(char *menufile);
extern	void	DisplayLine(int firsttime);
extern	void	ReadOptions(void);
extern	void	ParseOption(int cntr);
extern	void	DisplayTitle(void);
extern	void	DisplayPrompt(void);
 
