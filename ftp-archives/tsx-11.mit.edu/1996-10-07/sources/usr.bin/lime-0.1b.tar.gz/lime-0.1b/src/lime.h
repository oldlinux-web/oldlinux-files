/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

#define XTERNDATA 1

#include <ncurses.h>

#include "ansi.h"
#include "bitmaps.h"
#include "structs.h"

#include "codes.h"

#include "strlib.h"
#include "dsect.h"

#include "protos.h"
