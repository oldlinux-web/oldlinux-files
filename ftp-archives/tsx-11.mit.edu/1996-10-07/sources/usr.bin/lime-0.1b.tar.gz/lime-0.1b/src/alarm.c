/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <ncurses.h>
#include <unistd.h>
#include <signal.h>

#include "lime.h"

void AlarmIsRinging(int sig);
void WoofWoof(int sig);
void Hangup(int sig);
void SigQuit(int sig);
void SigInt(int sig);

int _warned;

void SetAlarm(void)
{
	struct sigaction sa;

	_warned = FALSE;

	sa.sa_handler = AlarmIsRinging;
	sa.sa_flags = 0;
	/* signal(SIGALRM, AlarmIsRinging); */
	sigaction(SIGALRM, &sa, NULL);
	alarm(timeoutval);
}

void SetWatchDog(void)
{
	/* Set an alarm to watch over the user while in any subprocesses */
	alarm(timeleft * 60);
	signal(SIGALRM, WoofWoof);
}

void TurnOffAlarm(void)
{
	_warned=FALSE;
	alarm(0);
}

void AlarmIsRinging(int sig)
{
	if(_warned)
	{
		SystemMessage("Inactivity Timeout!  Logging you off!", FALSE);
		Log("Inactivity timeout!  Logging user off");
		Shutdown();
	}
	else
	{
		SystemMessage("You still there?", FALSE);
		Log("Warning user of pending inactivity");
		alarm(timeoutval);
		signal(SIGALRM, AlarmIsRinging);
		_warned=TRUE;
	}
}

void WoofWoof(int sig)
{ 
	timeleft=0;
	kernel();
}

void SetTraps(void)
{
	signal(SIGKILL, SigKill);
	/* signal(SIGINT, SigInt); */
	signal(SIGQUIT, SigQuit);
	signal(SIGHUP, Hangup);
	signal(SIGSEGV, SigSegv);
}

void SigSegv(int sig)
{
	Log("Received SIGSEGV - shutting down");
	Shutdown();
}

void SigKill(int sig)
{
	Log("Received SIGKILL - shutting down");
	Shutdown();
}

void SigInt(int sig)
{
	Log("Received SIGINT - shutting down");
	Shutdown();
}

void SigQuit(int sig)
{
	Log("Received SIGQUIT - shutting down");
	Shutdown();
}

void Hangup(int sig)
{
	Log("User dropped carrier!");
	Shutdown();
}

void RemoveTraps(void)
{
	signal(SIGINT, SIG_DFL);
	signal(SIGQUIT, SIG_DFL);
}
