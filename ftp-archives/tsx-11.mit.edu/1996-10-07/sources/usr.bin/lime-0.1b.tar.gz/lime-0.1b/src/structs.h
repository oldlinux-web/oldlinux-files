/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

typedef struct _mnuopt {

	char key;
	int  type;
	char groups[80];			/* Group access string */
	char secondary[80];
	char password[21];			/* password */
	char desc[80];
	char color[40];

} _MNUOPT;

typedef struct _menu {

	char title[80];				/* Title of menu */
 	char file[20];				/* Base name of menu file */
	char prompt[80];			/* Prompt */
	char promptcol[40];			/* Prompt color string */
	char bracketcol[40];			/* Bracket color string */
	char pwdpromptcol[40];			/* Password prompt color */
	char hotkeycol[40];			/* Hotkey color string */
	char externcol[40];			/* External menu color */
	_MNUOPT options[25];			/* Array of type _MNUOPT */
	
} _MENU;

typedef	struct _conf {	
	
	char name[9];				/* Name of the conference */
	char desc[60];				/* Short description      */

	char creator[15];			/* Creator's account name */
	int  usage;				/* # of users currently   */

	time_t created;				/* Time/date of creation  */

} _CONF;

typedef struct _ttycfg {

	char _ttydevice[20];
	char _ansi;
} TTYCFG;
