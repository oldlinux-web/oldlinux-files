/*----------------------------------------------------------------------------
 LIME - The definitive LInux MEnuing system
 (C)opyright 1994-1995, Scott Burkett, All Rights Reserved
 ----------------------------------------------------------------------------- 
 $Header$
 ----------------------------------------------------------------------------- 
 $Log$
 ----------------------------------------------------------------------------*/

extern	void	SetAlarm(void);
extern	void	SetWatchDog(void);
extern	void	TurnOffAlarm(void);
extern	void	AlarmIsRinging(int sig);
extern	void	WoofWoof(int sig);
extern	void	SetTraps(void);
extern	void	SigSegv(int sig); 
extern	void	SigInt(int sig); 
extern	void	SigQuit(int sig); 
extern	void	SigKill(int sig); 
extern	void	Hangup(int sig); 
extern	void	RemoveTraps(void);

