#ifndef FTSCPROD_H
#define FTSCPROD_H

extern struct _ftscprod {
	unsigned char code;
	char *name;
} ftscprod[];

#endif
