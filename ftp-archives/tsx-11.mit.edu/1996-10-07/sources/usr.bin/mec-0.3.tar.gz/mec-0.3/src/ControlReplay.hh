// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: ControlReplay.hh
//   Event filter.
//
// File Created:	12 Nov 1995		Michael Chastain
// Last Edited:		12 Nov 1995		Michael Chastain

#if !defined(CONTROL_REPLAY_HH)
#define CONTROL_REPLAY_HH

#include <WhLap.hh>

class	CxStore;

void	replay_aw	( CxStore &, WhLap <CxStore> & );
void	replay_bc	( CxStore &, WhLap <CxStore> & );

#endif
