// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: CxFetch.cc
//   Context for fetch.
//   This is a reference class.
//
// File Created:	22 Oct 1995		Michael Chastain
// Last Edited:		16 Nov 1995		Michael Chastain

#include <CxFetch.hh>
#include <ErPtr.hh>



// Constructor.
CxFetch::CxFetch( PrProc * & pproc )
    : pproc_		( pproc	)
    , map_		(	)
    , dir_		(	)
    , pevSciArg_	( 0	)
    , pevScoScr_	( 0	)
    , iseqDs_		( 0	)
{
    // Initialize process.
    if ( pproc == 0 )
	ErPtr( );
    pproc = 0;
}



// Destructor.
CxFetch::~CxFetch( )
{
    if ( pproc_ != 0 )
	delete pproc_;
    pproc_ = 0;
}
