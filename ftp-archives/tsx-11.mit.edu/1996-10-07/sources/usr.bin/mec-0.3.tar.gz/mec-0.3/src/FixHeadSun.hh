// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: FixHeadSun.hh
//   Include this file to fix problems in Sun system header files.
//
// File Created:	20 Jun 1995		Michael Chastain
// Last Edited:		31 Oct 1995		Michael Chastain

#if !defined(FIX_HEAD_SUN_HH)
#define FIX_HEAD_SUN_HH

#include <sys/types.h>
#include <sys/ptrace.h>



// SunOS 4.1.3: missing prototypes.
extern "C" int	gettimeofday	( struct timeval *, struct timezone * );
extern "C" int	ptrace		( enum ptracereq, int, unsigned char *, int,
				  unsigned char * );
extern "C" int	wait4		( int, int *, int, struct rusage * );



#endif
