// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiListInsn.cc
//   Template instantiation.
//
// File Created:	14 Nov 1995		Michael Chastain
// Last Edited:		14 Nov 1995		Michael Chastain

#include <MmType.hh>
#include <WhList.hh>
#include <WhList.cc>

template class WhList <MmInsn>;
