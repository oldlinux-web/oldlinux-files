// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: ErRange.hh
//   Abort due to index out of range.
//
// File Created:	28 Oct 1995		Michael Chastain
// Last Edited:		28 Oct 1995		Michael Chastain

#if !defined(ER_RANGE_HH)
#define ER_RANGE_HH

void	ErRange		( );

#endif
