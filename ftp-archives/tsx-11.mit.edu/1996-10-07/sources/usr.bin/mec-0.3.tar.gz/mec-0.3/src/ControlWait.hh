// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: ControlWait.hh
//   Wait handler.
//
// File Created:	02 Nov 1995		Michael Chastain
// Last Edited:		02 Nov 1995		Michael Chastain

#if !defined(CONTROL_WAIT_HH)
#define CONTROL_WAIT_HH

#include <WhLap.hh>

class	CxStore;

void	control_wait	( CxStore &, WhLap <CxStore> & );

#endif
