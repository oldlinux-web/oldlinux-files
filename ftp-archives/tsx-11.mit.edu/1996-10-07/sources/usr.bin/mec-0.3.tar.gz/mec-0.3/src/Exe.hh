// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: Exe.hh
//   Interpret exe and lib files.
//
// File Created:	06 May 1995		Michael Chastain
// Last Edited:		07 Nov 1995		Michael Chastain

#if !defined(EXE_HH)
#define EXE_HH

class	CxFetch;
class	EvBase;
class	MmDs;

void	ExeToArea	( const MmDs &, CxFetch &, EvBase & );
void	LibToArea	( const MmDs &, CxFetch &, EvBase & );

#endif
