// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: EvSignal.hh
//   An event, type 'signal'.
//
// File Created:	31 Oct 1995		Michael Chastain
// Last Edited:		12 Nov 1995		Michael Chastain

#if !defined(EV_SIGNAL_HH)
#define EV_SIGNAL_HH

#include <EvBase.hh>



class	EvSignal		: public EvBase
{
    // Life cycle methods.
    public:
				EvSignal	(		   );
				~EvSignal	(		   );

    // Flat interface (combiner).
    private:
	void			fromFlatEv	( WhFlatIn  &	   );
	void			toFlatEv	( WhFlatOut &	   ) const;

    // String interface (combiner).
    private:
	void			fmtStrEv	( WhString &	   ) const;

    // Process interface.
    public:
	void			fetch		( CxFetch &	   );
	void			storeAw		( CxStore &	   ) const;
	void			storeBc		( CxStore &	   ) const;

    // Instance data.
    private:
	bool			fFetched_;	// Has been fetched.
	int			isig_;		// Signal #
};



#endif
