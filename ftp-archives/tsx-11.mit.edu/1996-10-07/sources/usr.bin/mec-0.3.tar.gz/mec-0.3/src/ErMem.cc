// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: ErMem.cc.
//   Abort due to memory exhaustion.
//
// File Created:	22 Oct 1995		Michael Chastain
// Last Edited:		22 Oct 1995		Michael Chastain

#include <ErAbort.hh>
#include <ErMem.hh>



// Use low-level calls and no more dynamic memory.
void ErMem( )
{
    ErAbort( "ErMem: out of memory." );
}
