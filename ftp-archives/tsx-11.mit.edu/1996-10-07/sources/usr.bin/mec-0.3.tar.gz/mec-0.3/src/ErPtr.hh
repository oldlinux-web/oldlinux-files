// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: ErPtr.hh
//   Abort due to zero pointer.
//
// File Created:	01 Nov 1995		Michael Chastain
// Last Edited:		01 Nov 1995		Michael Chastain

#if !defined(ER_PTR_HH)
#define ER_PTR_HH

void	ErPtr		( );

#endif
