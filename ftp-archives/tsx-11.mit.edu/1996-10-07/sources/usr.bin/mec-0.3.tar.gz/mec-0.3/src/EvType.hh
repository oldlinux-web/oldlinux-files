// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: EvType.hh
//   Event types.
//   This is an enumeration.
//   These values are stored into files.
//
// File Created:	02 Nov 1995		Michael Chastain
// Last Edited:		03 Nov 1995		Michael Chastain

#if !defined(EV_TYPE_HH)
#define EV_TYPE_HH

enum	TyEvent
{
	// System call path.
	tyEvBlank,
	tyEvFirst,
	tyEvSci,
	tyEvExec,
	tyEvSco,
	tyEvExit,

	// Transient.
	tyEvSignal,

	// Injected by viewer.
	tyEvBpt,
	tyEvStep
};

class	EvBase;

EvBase*	TyEventCreateBase	( TyEvent		);

#endif
