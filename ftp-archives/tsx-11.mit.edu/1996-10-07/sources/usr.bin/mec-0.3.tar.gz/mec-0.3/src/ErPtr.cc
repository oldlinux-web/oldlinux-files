// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: ErPtr.cc.
//   Abort due to zero pointer.
//
// File Created:	01 Nov 1995		Michael Chastain
// Last Edited:		01 Nov 1995		Michael Chastain

#include <ErAbort.hh>
#include <ErPtr.hh>



// Use low-level calls and no more dynamic memory.
void ErPtr( )
{
    ErAbort( "ErPtr: zero pointer." );
}
