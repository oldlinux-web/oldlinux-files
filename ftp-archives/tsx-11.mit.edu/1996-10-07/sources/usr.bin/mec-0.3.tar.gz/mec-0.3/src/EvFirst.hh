// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: EvFirst.hh
//   An event, type 'first event'.
//
// File Created:	31 May 1995		Michael Chastain
// Last Edited:		12 Nov 1995		Michael Chastain

#if !defined(EV_FIRST_HH)
#define EV_FIRST_HH

#include <EvBase.hh>
#include <WhString.hh>



class	EvFirst			: public EvBase
{
    // Constructor and destructor.
    public:
    				EvFirst		(		   );
				~EvFirst	(		   );

    // Flat interface (combiner).
    private:
	void			fromFlatEv	( WhFlatIn  &	   );
	void			toFlatEv	( WhFlatOut &	   ) const;

    // String interface (combiner).
    private:
	void			fmtStrEv	( WhString &	   ) const;

    // Process interface.
    public:
	void			fetch		( CxFetch &	   );
	void			storeAw		( CxStore &	   ) const;
	void			storeBc		( CxStore &	   ) const;

    // Instance data.
    private:
	WhString		strFqdnTarget_;	// Target machine name.
	int			ipidTrace_;	// Pid of tracer.
};



#endif
