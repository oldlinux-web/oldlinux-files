// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: TiListInt.cc
//   This is a template instantiation class.
//
// File Created:	11 Nov 1995		Michael Chastain
// Last Edited:		11 Nov 1995		Michael Chastain

#include <WhList.hh>
#include <WhList.cc>

template class WhList <int>;
