// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: ControlExecer.hh
//   Event filter.
//
// File Created:	12 Nov 1995		Michael Chastain
// Last Edited:		12 Nov 1995		Michael Chastain

#if !defined(CONTROL_EXECER_HH)
#define CONTROL_EXECER_HH

#include <WhLap.hh>

class	CxStore;

void	execer_aw	( CxStore &, WhLap <CxStore> & );
void	execer_bc	( CxStore &, WhLap <CxStore> & );

#endif
