// Copyright 1995 Michael Chastain
// Licensed under the Gnu Public License, Version 2
//
// File: MmInsnLix.cc
//   Machine instructions.
//
// File Created:	16 Oct 1995		Michael Chastain
// Last Edited:		15 Nov 1995		Michael Chastain

#include <MmInsn.hh>

const MmInsn	insnBpt		[ ] =
{
    0x01,
    0xCC	// int 3
};

const MmInsn	insnJumpDot	[ ] =
{
    0x02,
    0xEB, 0xFE	// jmp .
};

const MmInsn	insnSysTrap	[ ] =
{
    0x02,
    0xCD, 0x80	// int 0x80
};
