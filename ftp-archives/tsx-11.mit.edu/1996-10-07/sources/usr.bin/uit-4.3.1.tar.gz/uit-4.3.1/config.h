/*
    Configuration management header file
    Copyright (c) 1993, 1994 Tudor Hulubei & Andrei Pitis

This file is part of UIT (UNIX Interactive Tools)

UIT is free software; you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free Software
Foundation; either version 2, or (at your option) any later version.

UIT is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
details .

You should have received a copy of the GNU General Public License along with
UIT; see the file COPYING.  If not, write to the Free Software Foundation,
675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef _CONFIG_H
#define _CONFIG_H


#define MAXLINE		1024


#define NO_SEEK		0
#define DO_SEEK		1


#define IFS  		';'	/* internal field separator */
#define ICS		'#'	/* internal comment separator */
#define IAS		'='	/* internal assignment operator */


int  configuration_init(char *file_name);
void configuration_end(void);
int  configuration_section(char *section_name);
void configuration_getvarinfo(char *var_name, char **dest,
			      int fields, int seek);


#endif	/* _CONFIG_H */
