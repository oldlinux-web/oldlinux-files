#include "stdlib.h"

#include "PROTO.h"
#include "BitMap.h"

BitMapRow::
BitMapRow ()
{
  if ((Bits = new char[HBytes]) == 0)
    GripeOutOfMemory (HBytes, "BitMap");
  Printed = Length = 0;
}

void BitMapRow::
Clear ()
{
  memset (Bits, 0, HBytes);
  Printed = Length = 0;
}

BitMap::
BitMap ()
{
  if ((Rows = new BitMapRow *[BitMapRows]) == NULL)
    GripeOutOfMemory (sizeof (BitMapRow *) * (BitMapRows),
		      "BitMap");
  for (int i = 0; i < (BitMapRows); i++)
    {
      if ((Rows[i] = new BitMapRow) == NULL)
	GripeOutOfMemory (sizeof (BitMapRow), "BitMap");
    }
}

void BitMap::
Clear ()
{
  for (int i = 0; i < (BitMapRows); i++)
    Rows[i]->Clear ();
}

void
ReportMem ()
{
}

