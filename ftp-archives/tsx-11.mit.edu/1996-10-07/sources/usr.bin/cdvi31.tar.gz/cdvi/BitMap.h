/* epson.h,v 1.3 1993/10/02 03:23:13 neal Exp */

#include <stdio.h>
#include <stdlib.h>		/* for getenv, exit */
#include <limits.h>
#include "Bset.h"

#define MaxImFamily	128	/* hardware limitation on font family index */
#define DefaultMaxDrift	3	/* default value for MaxDrift */

#ifdef MAIN
#define EXTERN
#else
#define EXTERN extern
#endif

EXTERN int HPixels;

EXTERN int VPixels;

EXTERN int HBytes;

EXTERN int BitMapRows;

const int SpacesPerInch = 10;

inline int 
max (int a, int b)
{
  return (a > b) ? a : b;
}

inline int 
min (int a, int b)
{
  return (a < b) ? a : b;
}

struct BitMapRow
{
  int Length;			/* last bit pos used */
  unsigned char Printed;
  char *Bits;
  BitMapRow ();
  void Clear ();
  void Set (char *S, int Slen, int Pos)
  {
    Bset (S, Slen, Bits, HBytes, Pos);
    Length = max( Length, min( HPixels - 1, Pos + ( 8 * Slen ) ) );
  };

  void SetBits (int Slen, int Pos)
  {
    ::SetBits (Slen, Bits, HPixels, Pos);
    Length = max (Length, min (HPixels - 1, Pos + Slen));
  };

  int NeedToPrint ()
  {
    return !Printed && Length != 0;
  };

  void Mark ()
  {
    Printed = 1;
  };
};

struct BitMap
  {
    BitMapRow **Rows;

    BitMap ();

    void Clear ();

    int NeedToPrint (int Row)
    {
      return Rows[Row]->NeedToPrint ();
    };

    int FindLength (int Row, int VPins, int VInterleave, int VInc);

    int FindFirst (int Row, int VPins, int VInterleave, int VInc);

    void Mark (int Row)
    {
      Rows[Row]->Mark ();
    };

    void Set (char *S, int Slen, int Row, int Pos)
    {
      Rows[Row]->Set (S, Slen, Pos);
    };

    void SetBits (int Slen, int Row, int Pos)
    {
      Rows[Row]->SetBits (Slen, Pos);
    };
    
    BitMapRow * Row( int theRow) 
    {
      return Rows[theRow];
    }
  };

static const char BitMask[] =
{0x1, 0x2, 0x4, 0x8,
 0x10, 0x20, 0x40, 0x80
};

void ReportMem ();
