/* Copyright (c) 1995 Lode Leroy
 * svgalib 'printer' device 
 * All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

#include "screen.h"
#include "vga.h"
#include "vgagl.h"

extern "C" { 
#include "pbm.h" 
};

#include <stdlib.h>
#include "PROTO.h"

const char screen::BitMask[] =
{0x80, 0x40, 0x20, 0x10,
 0x08, 0x04, 0x02, 0x01
};

screen::
screen()
{
  DPIh=300;
  DPIv=300;
  
  width = int(DPIh * 8.25);
  height = int(DPIv * 11.7);

  HPixels = width;
  VPixels = height;
  
  xoffset = 0;
  yoffset = 0;

  xinc = 64;
  yinc = 64;
  
  HBytes = (width + 7) / 8;
  BitMapRows = height;

  scale = 3;
  step = 2;
}

screen::
~screen()
{
  if (graphic)
  {
    vga_setmode(TEXT);
  }
}

char screen::
DrawBitMap (BitMap* theBitMap)
{
  if (graphic==1)
  {
    graphic++;
    vga_init();
    int mode=vga_getdefaultmode();
    if (!vga_hasmode(mode))
    {
      mode=G640x480x256;
    }
    vga_setmode(mode);
    gl_setcontextvga(mode);
  }
  
  return DoKeys(theBitMap);
}

char screen::
DoKeys(BitMap* theBitMap)
{
  
  int redraw = 1;
  int dx;
  int dy;
  
  for(;;)
  {
    if (redraw)
    {
      DrawRect(theBitMap, 0, 0, vga_getxdim(), vga_getydim());
      redraw = 0;
    }
    char c = vga_getch();

redo_key:
    switch (c)
    {
     case 'q': 
     case 'n':
     case 'p':
      return c;
      break;
     case 'h':
      if (xoffset >= xinc * scale)
      {
	dx = xinc;
      }
      else
      {
	dx = xoffset / scale;
      }
      if (dx > 0)
      {
	gl_copybox(0, 0, vga_getxdim() - dx, vga_getydim(), dx, 0);
	xoffset -= dx * scale;
	DrawRect(theBitMap, 0, 0, dx, vga_getydim());
      }
      break;
     case 'k':
      if (yoffset >= yinc * scale)
      {
	dy = yinc;
      }
      else
      {
	dy = yoffset / scale;
      }
      if (dy > 0)
      {
	gl_copybox(0, 0, vga_getxdim(), vga_getydim() - dy, 0, dy);
	yoffset -= dy * scale;
	DrawRect(theBitMap, 0, 0, vga_getxdim(), dy);
      }
      break;
     case 'l':
      if (xoffset < width - xinc * scale - vga_getxdim() * scale)
      {
	dx = xinc;
      }
      else
      {
	dx = (width - xoffset) / scale - vga_getxdim();
      }
      if (dx > 0)
      {
	gl_copybox(dx, 0, vga_getxdim() - dx, vga_getydim(), 0, 0);
	xoffset += dx * scale;
	DrawRect(theBitMap, vga_getxdim() - dx, 0, vga_getxdim(), vga_getydim());
      }
      break;
     case 'j':
      if (yoffset < height - yinc * scale - vga_getydim() * scale )
      {
	dy = yinc;
      }
      else
      {
	dy = (height - yoffset) / scale - vga_getydim();
      }
      if (dy > 0)
      {
	gl_copybox(0, dy, vga_getxdim(), vga_getydim() - dy, 0, 0);
	yoffset += dy * scale;
	DrawRect(theBitMap, 0, vga_getydim() - dy, vga_getxdim(), vga_getydim());
      }
      break;
     case '-':
      if (scale < 5) 
      {
	xoffset = xoffset - (vga_getxdim() / 4) * scale;
	yoffset = yoffset - (vga_getydim() / 4) * scale;
	scale++;
	redraw = 1;
      }
      break;
     case '+':
      if (scale > 1) 
      {
	scale--;
	xoffset = xoffset + (vga_getxdim() / 4) * scale;
	yoffset = yoffset + (vga_getydim() / 4) * scale;
	redraw = 1;
      }
      break;
     case 'f':
      if (step>0)
      {
	step--;
	xinc /= 2;
	yinc /= 2;
      }
      break;
     case 'F':
      if (step<6)
      {
	step++;
	xinc *= 2;
	yinc *= 2;
      }
      break;
     case '': // ESC
      c = vga_getch();
      switch (c)
      {
       case '[': // ESC '['
	c = vga_getch();
	// cursor keys & page-up / page-down
	// not termcap compatible ...
	// I guess such a small program isnt worth going through all
	// the fuzz of incorporating termcap support
	switch (c) 
	{
	 case 'A': // up
	  c = 'k';
	  goto redo_key;
	 case 'B': // down
	  c = 'j';
	  goto redo_key;
	 case 'C': // right
	  c = 'l';
	  goto redo_key;
	 case 'D': // left
	  c = 'h';
	  goto redo_key;
	 case '5': // pgup
	  c = vga_getch();
	  if (c == '~')
	  {
	    c = 'p';
	    goto redo_key;
	  }
	  break;
	 case '6': // pgdn
	  c = vga_getch();
	  if (c == '~')
	  {
	    c = 'n';
	    goto redo_key;
	  }
	  break;
	}
      }
    }
  }
}

int COLOR[5][26]= 
{
  {16,31},
  {16,20,24,28,31},
  {16,17,19,21,23,24,26,28,30,31},
  {16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,31},
  {16,16,17,17,18,19,19,20,21,21,22,23,23,24,24,25,26,26,27,28,28,29,30,30,31,31},
};

void screen::
DrawRect(BitMap* theBitMap, int left, int top, int right, int bottom)
{
  int xPos;
  int yPos;
  unsigned char byte;
  int idx;
  int gray;

#if 0
  if (left < 0) left = 0;
  if (top  < 0) top  = 0;
  if (right  > vga_getxdim()) right  = vga_getxdim();
  if (bottom > vga_getydim()) bottom = vga_getydim();
#endif
  
  for (yPos = top; yPos < bottom; yPos++)
  {
    if (yoffset + yPos * scale < 0 
	|| yoffset + yPos * scale > height - scale)
    {
      gl_line(left, yPos, right, yPos, vga_white());
    }
    else
    {
      for (xPos = left; xPos < right; xPos++)
      {
	if (xoffset + xPos * scale < 0 
	    || xoffset + xPos * scale > width - scale)
	{
	  gl_setpixel(xPos, yPos, vga_white());
	}
	else
	{
	  gray = 0;
	  for (int dy=0; dy<scale; dy++)
	  {
	    for (int dx=0; dx<scale; dx++)
	    {
	      idx = xoffset + xPos*scale + dx;
	      byte = theBitMap->Rows[yoffset + yPos*scale + dy]->Bits[idx/8];
	      {
		if ((byte & BitMask[idx&7]) == 0)
		{
		  gray++;
		}
	      }
	    }
	  }
	  gl_setpixel(xPos, yPos, COLOR[scale-1][gray]);
	}
      }
    }
  }
}

void screen::
WriteBitMap(BitMap* theBitMap, char* filename, int pageno)
{
  int xPos;
  int yPos;

  char* str = new char[strlen(filename)+10];
  // allow pageno to occur in filename
  sprintf(str, filename, pageno);
  
  FILE* fp = fopen(str, "w");
  if (fp == 0)
  {
    fprintf(stderr, "Error creating file %s\n", str);
    return;
  }
  delete[] str;

  bit* bitrow = pbm_allocrow(width);
  pbm_writepbminit(fp, width, height, 0);
  
  for (yPos = 0; yPos < height; yPos++)
  {
    BitMapRow * theRow = theBitMap->Row(yPos);
	  
    for (xPos=0; xPos < width; xPos+=8)
    {
      unsigned char byte = theRow->Bits[xPos / 8];
      for (int BIT=0; BIT<((xPos+7<width)?8:(width&7+1)); BIT++)
      {
	  bitrow[xPos+BIT]=(byte & BitMask[BIT])!=0 ? 0 : 1;
      }
    }
    pbm_writepbmrow(fp, bitrow, width, 0);
  }
  
  fclose(fp);
  pbm_freerow(bitrow);
}
