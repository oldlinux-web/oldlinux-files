#ifndef screen_h
#define screen_h

/* Copyright (c) 1995 Lode Leroy
 * svgalib 'printer' device for eps skeleton driver program 
 * (now called cdvi)
 * All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

#include "BitMap.h"

extern int graphic;

class screen
{

 private:
  int DPIh;                       /* Horizontal resolution of selected graphics mode */
  int DPIv;                       /* Vertical resolution of selected graphics mode */
  
  int width;
  int height;
  
  int xoffset;
  int yoffset;
  
  int scale;
  int step;
  int xinc;
  int yinc;
  
public:

  screen();

  ~screen();
  
  char *Engine () const
  {
    return ("localfont");
  }

  int GetDPIh() const { return DPIh; }

  int GetDPIv() const { return DPIv; }
  void Reset () {}
  void Eol () {}
  void EoP () {}
  void FF () {}
  
  char DrawBitMap(BitMap* theBitMap);
  char DoKeys(BitMap* theBitMap);
  void WriteBitMap(BitMap* theBitMap, char* filename, int pageno);
  void DrawRect(BitMap* theBitMap, int left, int top, int right, int bottom);
  static const char BitMask[];
};

#endif
