static const char rcsid[] = "Bset.c,v 1.3 1993/10/02 03:23:04 neal Exp";

/* Copyright (c) 1993 Neal Becker
 * All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

static const int BitMask[8] =
{0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};

inline int 
min (int a, int b)
{
  return (a > b) ? b : a;
}

inline unsigned char 
TopPart (char S, int Pos)
{
  return ((unsigned char) S) >> Pos;
}

inline unsigned char 
BottomPart (char S, int Pos)
{
  return S << (8 - Pos);
}

static void 
MemOr (char *D, char *S, int count)
{
  for (; count != 0; count--, D++, S++)
    *D |= *S;
}

void 
Bset (char *S, int Slen, char *D, int Dlen, int Pos)
{
  char *Dest = D + (Pos / 8);
  int BitPos = Pos % 8;
  char *Dend = D + Dlen - 1;
  int BytesToMove = min (Slen, Dlen - (Pos / 8));
  if( BytesToMove > 0 ) {
    if (BitPos == 0)
      MemOr (Dest, S, BytesToMove);
    else {
      for (; BytesToMove > 0; BytesToMove--, Dest++, S++) {
	*Dest |= TopPart (*S, BitPos);
	if (Dest + 1 > Dend)
	  break;
	*(Dest + 1) |= BottomPart (*S, BitPos);
      }
    }
  }
}

void 
SetBits (int Slen, char *D, int Dlen, int Pos)
{
  char *Dest = D + (Pos / 8);
  int BitPos = 7 - (Pos % 8);
  int BitsToMove = min (Slen, Dlen - Pos);
  for (; BitsToMove > 0; BitsToMove--)
    {
      *Dest |= BitMask[BitPos--];
      if (BitPos < 0)
	{
	  Dest++;
	  BitPos = 7;
	}
    }
}
