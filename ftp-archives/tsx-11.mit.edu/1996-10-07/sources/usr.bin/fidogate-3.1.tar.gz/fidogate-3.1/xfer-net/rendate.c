/*
 * Rename file to name base on current UNIX time
 */

#include <stdio.h>
#include <sys/types.h>
#include <time.h>



main(argc, argv)
int argc;
char *argv[];
{
    char buf[128];

    if(argc != 3)
    {
	fprintf(stderr, "usage: rendate name ext\n");
	exit(1);
    }
    
    sprintf(buf, "%lx%s", time(NULL), argv[2]);
    if(rename(argv[1], buf))
    {
	fprintf(stderr, "rendate: rename %s -> %s failed: ", argv[1], buf);
	perror("");
	exit(1);
    }
    
    exit(0);
}


