/*
 * Create lock file using open() system call
 */

#include <stdio.h>
#include <fcntl.h>



main(argc, argv)
int argc;
char *argv[];
{
    int fd;

    if(argc != 2) 
    {
	fprintf(stderr, "usage: lockit file\n");
	exit(1);
    }
    
    fd = open(argv[1], O_RDWR | O_CREAT | O_EXCL, 0666);
    
    return fd==-1 ? 1 : 0;
}
