/*:ts=8*/
/*****************************************************************************
 * FIDOGATE --- Gateway UNIX Mail/News <-> FIDO NetMail/EchoMail
 *
 * $Id: declare.h,v 3.1 1993/09/14 07:44:29 mj Exp mj $
 *
 * Declaration header for not-so-ANSI systems
 *
 *****************************************************************************
 * Copyright (C) 1990, 1993
 *  _____ _____
 * |     |___  |   Martin Junius             FIDO:      2:242/6.1
 * | | | |   | |   Republikplatz 3           Internet:  mj@sungate.fido.de
 * |_|_|_|@home|   D-52072 Aachen, Germany   Phone:     ++49-241-86931 (voice)
 *
 * This file is part of FIDOGATE.
 *
 * FIDOGATE is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * FIDOGATE is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with FIDOGATE; see the file COPYING.  If not, write to the Free
 * Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************/

/*
 * SUNOS 4.1.3
 */
#ifdef sun

/*
 * Non-standard functions
 */
int    lockf	P((int, int, long));


/*
 * Standard-C functions undeclared in header files
 */

/* stdio.h */
int    _filbuf	P(());			/* Internal, no standard */
int    _flsbuf	P(());			/* Internal, no standard */

int    fclose	P((FILE *));
int    fflush	P((FILE *));
int    fprintf	P((FILE *, const char *, ...));
int    fputs	P((const char *, FILE *));
size_t fread	P((void *, size_t, size_t, FILE *));
int    fseek	P((FILE *, long, int));
size_t fwrite	P((const void *, size_t, size_t, FILE *));
void   perror	P((const char *));
int    printf	P((const char *, ...));
int    puts	P((const char *));
int    rename	P((const char *, const char *));
void   rewind	P((FILE *));
int    sscanf	P((char *, const char *, ...));
int    ungetc	P((int, FILE *));
int    vfprintf	P((FILE *, const char *, va_list));
int    vsprintf	P((char *, const char *, va_list));

#endif /**sun**/
