/*:ts=8*/
/*****************************************************************************
 * FIDOGATE --- Gateway UNIX Mail/News <-> FIDO NetMail/EchoMail
 *
 * $Id: config.c,v 3.1 1993/09/14 07:40:04 mj beta mj $
 *
 * Configuration data and functions
 *
 *****************************************************************************
 * Copyright (C) 1990, 1993
 *  _____ _____
 * |     |___  |   Martin Junius             FIDO:      2:242/6.1
 * | | | |   | |   Republikplatz 3           Internet:  mj@sungate.fido.de
 * |_|_|_|@home|   D-52072 Aachen, Germany   Phone:     ++49-241-86931 (voice)
 *
 * This file is part of FIDOGATE.
 *
 * FIDOGATE is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * FIDOGATE is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with FIDOGATE; see the file COPYING.  If not, write to the Free
 * Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************/

#include "fidogate.h"



struct st_config Config;



/*
 * Init configuration
 */
void config_init()
{
    /**FIXME: this should be read from a config file**/
    Config.myaddr    .zone  = REAL_ZONE;
    Config.myaddr    .net   = REAL_NET;
    Config.myaddr    .node  = REAL_NODE;
    Config.myaddr    .point = REAL_POINT;
    
    Config.myfakeaddr.zone  = MY_ZONE;
    Config.myfakeaddr.net   = MY_NET;
    Config.myfakeaddr.node  = MY_NODE;
    Config.myfakeaddr.point = MY_POINT;
    
    Config.remoteaddr.zone  = REM_ZONE;
    Config.remoteaddr.net   = REM_NET;
    Config.remoteaddr.node  = REM_NODE;
    Config.remoteaddr.point = REM_POINT;
}



/*
 * Set FIDO address
 */
void config_myaddr(addr)
char *addr;
{
    Node node;
    
    if( asc_to_node(addr, &node, FALSE) == ERROR )
    {
	fprintf(stderr, "Illegal FIDO address %s\n", addr);
	exit(EX_USAGE);
    }
    
    Config.myaddr     = node;
    Config.myfakeaddr = node;
}



/*
 * Set FIDO fakenet address
 */
void config_myfakeaddr(addr)
char *addr;
{
    Node node;
    
    if( asc_to_node(addr, &node, FALSE) == ERROR )
    {
	fprintf(stderr, "Illegal FIDO address %s\n", addr);
	exit(EX_USAGE);
    }
    
    Config.myfakeaddr = node;
}



/*
 * Set remote FIDO address
 */
void config_remoteaddr(addr)
char *addr;
{
    Node node;
    
    if( asc_to_node(addr, &node, FALSE) == ERROR )
    {
	fprintf(stderr, "Illegal FIDO address %s\n", addr);
	exit(EX_USAGE);
    }
    
    Config.remoteaddr = node;
}
