/*:ts=8*/
/*****************************************************************************
 * FIDOGATE --- Gateway UNIX Mail/News <-> FIDO NetMail/EchoMail
 *
 * $Id: fido2rfc.c,v 3.1 1993/09/14 07:40:04 mj beta mj $
 *
 * Unpack FIDO mail packets in INBOUND directory and convert to RFC mails
 * and news batches (directories INBOUND_MAIL / INBOUND_NEWS)
 *
 *****************************************************************************
 * Copyright (C) 1990, 1993
 *  _____ _____
 * |     |___  |   Martin Junius             FIDO:      2:242/6.1
 * | | | |   | |   Republikplatz 3           Internet:  mj@sungate.fido.de
 * |_|_|_|@home|   D-52072 Aachen, Germany   Phone:     ++49-241-86931 (voice)
 *
 * This file is part of FIDOGATE.
 *
 * FIDOGATE is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * FIDOGATE is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with FIDOGATE; see the file COPYING.  If not, write to the Free
 * Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************/

#include "fidogate.h"
#include "getopt.h"

#include <pwd.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>



#define PROGRAM "fido2rfc"
#define VERSION "$Revision: 3.1 $"



#define SEPARATORS " ,;\015\012\011"
#define WHITESPACE " \015\012\011"



extern time_t time();
extern char *tzname[];
extern int getopt();
extern int optind;
extern char *optarg;
extern void exit(), perror();
extern time_t dateconv();
extern void swab();


int verbose = INIT_VERBOSE;

/* FIDO mail packet header */
Packet header;


/*
 * For recognizing `^AINTL', `^AFMPT x', `^AMSGID ...' and `^AREPLY ...'
 */
#define SAVEBUFSIZ 256

static int  msgbody_fmpt = 0;
static char msgbody_area[SAVEBUFSIZ];
static char msgbody_msgid[SAVEBUFSIZ];
static char msgbody_reply[SAVEBUFSIZ];
static char msgbody_intl[SAVEBUFSIZ];
static char msgbody_origid[SAVEBUFSIZ];
static char msgbody_origref[SAVEBUFSIZ];


/*
 * For grabbing addresses from RFC822 header lines at start of message
 */

static char *msgbody_rfc_from;
static char *msgbody_rfc_to;


/*
 * Command line options
 */
int u_flag = FALSE;
int p_flag = FALSE;

char in_dir[BUFSIZ];
char mail_dir[BUFSIZ];
char mail_name[BUFSIZ];
char mail_tmp[BUFSIZ];
FILE *mail_file;
char news_dir[BUFSIZ];
char news_name[BUFSIZ];
char news_tmp[BUFSIZ];
FILE *news_file;
char pkt_name[BUFSIZ];
FILE *pkt_file;



/*
 * check_origin() --- Analyse ` * Origin: ...' line in FIDO message
 *		      body and parse address in ()s into Node structure
 *
 * Origin line is checked for the rightmost occurence of
 * ([text] z:n/n.p). If origin line get splitted across
 * two lines you're out of luck.
 */

int check_origin(buffer, node, text)
char *buffer;
Node *node;
char *text;
{
char *left, *right;
char *buf;

    if(!strncmp(" * Origin:", buffer, 10)) {
	debug(3, "Checking origin line for FIDO address");
	buf   = strsave(buffer);
	right = strrchr(buf, ')');
	if(!right) {
	    free(buf);
	    return(FALSE);
	}
	left  = strrchr(buf, '(');
	if(!left) {
	    free(buf);
	    return(FALSE);
	}
	*right = 0;
	*left++ = 0;
	/*
	 * Copy info text for Organization: header
	 */
	strcpy(text, buf + strlen(" * Origin: "));
	/*
	 * Parse node info
	 */
	if(asc_to_node(left, node, FALSE) != OK) {
	    /* Not a valid FIDO address */
	    debug(3, "Could not parse %s", left);
	    node->zone = node->net = node->node = node->point = -1;
	    free(buf);
	    return(FALSE);
	}
	else {
	    /* Valid FIDO address */
	    debug(3, "Parsed %s to %s", left, node_to_asc(node, FALSE));
	}
	free(buf);
	return(TRUE);
    }
    return(FALSE);
}



/*
 * check_ctrl_a() --- Check for various ^A kludges
 */
void check_ctrl_a(buffer)
char *buffer;
{
    char *p;

    if(buffer[strlen(buffer) - 1] == '\n')
	buffer[strlen(buffer) - 1] = 0;		/* Strip trailing \n */
    
    /*
     * Look for `^AINTL ...'
     */
    if(!strncmp(buffer+1, "INTL", 4)) {
	buffer += 5;
	while(*buffer==':' || *buffer==' ')
	    buffer++;
	strcpy(msgbody_intl, buffer);
    }

    /*
     * Look for `^AFMPT x'
     */
    if(!strncmp(buffer+1, "FMPT", 4)) {
	for(p=buffer+5; *p && !isdigit(*p); p++);
	if(*p)
	    msgbody_fmpt = atoi(p);
    }
    
    /*
     * Look for `^AMSGID: ...'
     */
    if(!strncmp(buffer+1, "MSGID: ", 7))
	strcpy(msgbody_msgid, buffer+8);
    
    /*
     * Look for `^AREPLY: ...'
     */
    if(!strncmp(buffer+1, "REPLY: ", 7))
	strcpy(msgbody_reply, buffer+8);

    /*
     * Look for `^AORIGID: ...'
     */
    if(!strncmp(buffer+1, "ORIGID: ", 8))
	strcpy(msgbody_origid, buffer+9);

    /*
     * Look for `^AORIGREF: ...'
     */
    if(!strncmp(buffer+1, "ORIGREF: ", 9))
	strcpy(msgbody_origref, buffer+10);

    /*
     * Look for `^ACHARSET ...' or `^ACHRS ...'
     */
    if(!strncmp(buffer+1, "CHARSET:", 8))
	charset_set(buffer + 9);
    if(!strncmp(buffer+1, "CHRS:", 5))
	charset_set(buffer + 6);
}



/*
 * check_rfc_header() --- Check for RFC822 like header lines at
 *			  the beginning of the FIDO message body
 */

int check_rfc_header(buffer)
char *buffer;
{
    if(!strnicmp(buffer, "From: ", 6)) {
	msgbody_rfc_from = strsaveline(buffer + 6);
	return(1);
    }
    if(!strnicmp(buffer, "Reply-To: ", 10)) {
	msgbody_rfc_from = strsaveline(buffer + 10);
	return(1);
    }
    if(!strncmp(buffer, "UUCPFROM:", 9)) {
	msgbody_rfc_from = strsaveline(buffer + 9);
	return(1);
    }
    if(!strnicmp(buffer, "To: ", 4)) {
	msgbody_rfc_to = strsaveline(buffer + 4);
	return(1);
    }
    if(!strnicmp(buffer, "To:", 3)) {
	msgbody_rfc_to = strsaveline(buffer + 3);
	return(1);
    }
    return(0);
}



/*
 * Read lines from text body of FIDO message.
 */

char *msg_getline(buffer, size, fp)
char *buffer;
int size;
FILE *fp;
{
    int c=0;
    char *cp;
    char *xl;

    /*
     * Read lines from message body. Lines are terminated by \r, \n and
     * 0x8d (soft \r) are ignored. High bit characters are converted according
     * to the active character set, control character are converted to ^X.
     * (Except ^A at the beginning of a line)
     */
    cp = buffer;

    while (--size>1 && (c = getc(fp)) != EOF)
    {
	if(c==1 && cp==buffer)		/* ^A at beginning of line */
	{
	    *cp++ = c;
	    continue;
	}
	
#if 1
	/*
	 * Special handling for a bug in SQUISH 1.01
	 * KLUDGE!!!
	 */
	if(c == 2)
	{
	    c = getc(fp);
	    if(c == 0)
	    {
		long pos = ftell(fp);
		
		fseek(fp, pos-2, 0);
		log("Bad packet: SQUISH bug!");
		fprintf(stderr, "Bad packet: SQUISH bug!\n");
		break;
	    }
	}
#endif	    
	
	/*
	 * Check for orphan 0-Byte in message, next Byte must be 0 or 2
	 */
	if(c == 0) 
	{
	    c = getc(fp);
	    ungetc(c, fp);
	    if(c==2 || c==0)
	    {
		c = 0;
		break;
	    }
	    c = 0;
	}
	
	if(c=='\n' || c==0x8d)		/* Ignore \n and soft \r */
	    continue;
	if(c == '\r')
	    c = '\n';
	else if(c < ' ') {
	    /*
	     * Substitute control chars with '^X'
	     */
	    if(c != '\t')
	    {
		size--;
		*cp++ = '^';
		c = c + '@';
	    }
	}
	else if(c & 0x80)
	{
	    /*
	     * Translate special characters according to character set
	     */
	    xl = charset_xlate(c);
	    if(!xl || !*xl)
		continue;
	    while(xl[1])
	    {
		size--;
		*cp++ = *xl++;
	    }
	    c = *xl;
	}
	
	*cp++ = c;
	if (c == '\n')			/* End of line */
	    break;
    }

    /*
     * 0 byte == end of message
     * Put it back, if it occurred in the middle of a line
     */
    if(c==0 && cp!=buffer)
    {
	*cp++ = '\n';			/* Add newline */
	ungetc(0, fp);
    }

    *cp = 0;

    return (c==0 || c==EOF) && cp==buffer ? NULL : buffer;
}



/*
 * Read FIDO message header from input file
 */

int read_header(fp)
FILE *fp;
{
    header.orig_node = read_int(fp);
    header.dest_node = read_int(fp);
    header.year	     = read_int(fp);
    header.month     = read_int(fp);
    header.day	     = read_int(fp);
    header.hour	     = read_int(fp);
    header.minute    = read_int(fp);
    header.second    = read_int(fp);
    header.rate	     = read_int(fp);
    header.ver	     = read_int(fp);
    header.orig_net  = read_int(fp);
    header.dest_net  = read_int(fp);
    header.product   = getc(fp);
    header.x1	     = getc(fp);
    fread(header.pwd_kludge, 8, 1, fp);
    header.orig_zone = read_int(fp);
    if (header.orig_zone == 0)
	header.orig_zone = Config.myfakeaddr.zone;
    header.dest_zone = read_int(fp);
    if (header.dest_zone == 0)
	header.dest_zone = Config.myfakeaddr.zone;
    fread(header.B_fill2, 16, 1, fp);
    fread((char *) &header.B_fill3, 4, 1, fp);
    return(ferror(fp) || feof(fp));
}



/*
 * Read 16-bit integer in 80x86 format, i.e. low byte first,
 * then high byte. Machine independent function.
 */

int read_int(fp)
FILE *fp;
{
register int c;
register int val;

    if((c = getc(fp)) == EOF) {
	log("$Can't read file (EOF)");
	return(0);
    }
    val	 = c;
    if((c = getc(fp)) == EOF) {
	log("$Can't read file (EOF)");
	return(0);
    }
    val |= c << 8;
    return(val);
}



/* Read null-terminated string from file. Ensure that buffer is also
   null-terminated. Remove possible \n:s from end, they are generated by
   some buggy mailers. */

void
get_string(buffer, fp, nbytes)
char *buffer;
FILE *fp;
int nbytes;
{
    register int n;
    char *p;

    debug(8, "get string start %ld", ftell(fp));

    for (n = 0, *buffer = 0; n < nbytes; n++)
	if ((buffer[n] = getc(fp)) == 0)
	    break;
	else
	    debug(8, "<%d %c>", buffer[n], buffer[n]);

    /* If still more chars in buffer, skip them until null char found */
    if (n >= nbytes) {
	debug(8, "Skipping rest");
	while (getc(fp)) ;
    }

    buffer[nbytes] = 0;

    /* Remove \n from end if its there, its a bug */
    if ((p = strchr(buffer, '\n')))
	*p = 0;

    debug(8, "Getstring at %ld %s", ftell(fp), buffer);
}



/*
 * Like strtok but returns empty string instead of null if no more thigns
 * found
 */

char *
estrtok(s, sep)
char *s, *sep;
{
    char *p;

    if ((p = strtok(s, sep)))
	return p;
    return "";
}



/*
 * Get matching newsgroup for FIDO area from `AREAS' file
 */

char *get_ng(config, echo)
FILE *config;
char *echo;
{
static char conv[BUFLEN];
char *gr;

    debug(3, "Searching area %s", echo);

    while (getcl(conv, BUFLEN, config)) {
	debug(9, "area file line '%s'", conv);

	gr = estrtok(conv, SEPARATORS);
	if (!strcmp(gr, echo)) {
	    /* Matched, take distribution and return newsgroup */

	    gr = estrtok(NULL, SEPARATORS);

	    debug(3, "Found: newsgroup %s", gr);
	    return gr;
	}
    }
    log("No newsgroup for '%s' found.", echo);
    return "fido.junk";
}



/*
 * Test for news article and returns newsgroup for FIDO area in msgbody_area[]
 */
char *news_msg(fp)
FILE *fp;
{
    FILE *config;
    char *p;
    static char buffer[128];
    
    if(msgbody_area[0])
    {
	/* Message is FIDO EchoMail */
	msgbody_area[strlen(msgbody_area) - 1] = 0;
	for(p=msgbody_area+strlen("AREA:"); *p && isspace(*p); p++);
	debug(3, "FIDO Area   : %s", p);

	config = libfopen(AREAS, R_MODE);

	strncpy0(buffer, get_ng(config, p), sizeof(buffer));
	fclose(config);

	/* Return newsgroup */
	return buffer;
    }

    /* Message is FIDO NetMail */
    return NULL;
}



/*
 * Return date of message in UNIX format (secs after the epoche)
 *
 * Understood formats: see getdate.y
 */

time_t lgetdate(packet)
FILE *packet;
{
char buffer[20];
time_t timevar;
int n;

    /*
     * Some FIDO message packers do it wrong! Regarding FTS-0001, the
     * message date is a fixed 20 bytes long string. But some programs,
     * e.g. QMail under certain circumstances, produce 19 bytes dates.
     */
    /* read date from packet */
    for (n = 0; n < 20; n++)
	if ((buffer[n] = getc(packet)) == 0)
	    break;
    buffer[19] = 0;

    debug(8, "Getdate %s at %ld", buffer, ftell(packet));

    /* try to get date */
    timevar = get_date(buffer, NULL);
    return timevar;
}



/*
 * Capitalize string
 */

char *strcap(s)
char *s;
{
    if(!s || !*s)
	return(s);
    if(islower(*s))
	*s = toupper(*s);
    for(s++; *s; s++)
	if(isupper(*s))
	    *s = tolower(*s);
    return(s);
}



/*
 * Convert name in FIDO from or to field to real name
 * for use in () in RFC822 header. Everything after
 * `%' or `Of' is thrown away. The result is capitalized.
 */

void realname_convert(name, realname)
char *name;
char *realname;
{
char *p, *string;
int cat_flag = 0;

    string = strsave(name);
    *realname = 0;
    for(p=strtok(string, " \t"); p; p=strtok(NULL, " \t")) {
	if(!strcmp (p, "%" )  || !stricmp(p, "of") ||
	   !stricmp(p, "on")  || !strcmp(p, "-")	)
	    break;
	strcap(p);
	if(cat_flag)
	    strcat(realname, " ");
	strcat(realname, p);
	cat_flag = 1;
    }
    free(string);
}



#ifdef MAUS_DE
/*
 * Convert MAUS<->FIDO gateway addresses to Internet format
 */

char *maus_de_convert(name)
char *name;
{
char *p, *ret;
int len, n;

    /*
     * Test for "_%_MAUS_" within name
     */
    p = strchr(name, '%');
    if(!p || p==name)
	return NULL;
    p--;
    len = strlen(MAUS_STRING);
    if(strnicmp(p, MAUS_STRING, len))
	return NULL;

    /*
     * Found it. Now copy name before '%' and append Internet address
     */
    ret = xmalloc(strlen(name) + len);		/* Be safe */
    n	= p - name;
    strncpy(ret, name, n);			/* Copy name */
    ret[n++] = '@';
    p += len;
    while(*p) {
	ret[n++] = isupper(*p) ? tolower(*p) : *p;
	p++;
    }
    ret[n] = 0;
    strcat(ret, MAUS_DOMAIN);

    return ret;
}
#endif /**MAUS_DE**/



/*
 * Format buffer line and put it into Textlist. Returns number of
 * lines.
 */
int msg_format_buffer(buffer, tlist)
char *buffer;
Textlist *tlist;
{
    /*
     * Remark: MAX_LINELEN+16 and MAX_LINELEN+8, the numbers +16 and +8
     *         are just arbitrary values to be safe.
     */
    char *p, *np;
    char localbuffer[MAX_LINELEN + 16];
    int i;
    int lines;
    
    if(strlen(buffer) <= MAX_LINELEN)		/* Nothing to do */
    {
	Textlist_append(tlist, buffer);
	return 1;
    }
    else
    {
	/*
	 * Break line with word wrap
	 */
	lines = 0;
	p     = buffer;

	while(TRUE)
	{
	    /*
	     * Search backward for a whitespace to break line. If no proper
	     * point is found, the line will not be splitted.
	     */
	    for(i=MAX_LINELEN-1; i>=0; i--)
		if(isspace(p[i]))	/* Found a white space */
		    break;
	    if(i == -1)				/* Not found, put line as is */
	    {
		Textlist_append(tlist, p);
		lines++;
		return lines;
	    }
	    for(; i>=0 && isspace(p[i]); i--);	/* Skip more white space */
	    i++;				/* Return to last white sp. */

	    /*
	     * Cut here and put into textlist
	     */
	    np = p + i;
	    *np++ = 0;
	    strncpy0(localbuffer, p, MAX_LINELEN+8);
	    strcat(localbuffer, "\n");
	    Textlist_append(tlist, localbuffer);
	    lines++;
	    
	    /*
	     * Advance buffer pointer and test length of remaining line
	     */
	    p = np;
	    for(; *p && isspace(*p); p++);	/* Skip white space */
	    if(*p == 0)				/* The end */
		return lines;
	    if(strlen(p) <= MAX_LINELEN)	/* No more wrappin' */
	    {
		Textlist_append(tlist, p);
		lines++;
		return lines;
	    }

	    /* Play it again, Sam! */
	}
    }
    /**NOT REACHED**/
    return 0;
}



/*
 * Unpack FIDO mail packet. Each message header und some information in
 * the message body (^A kludges and some RFC like lines) ist converted
 * to an RFC compatible message header. If the first line of the message
 * starts with `AREA:' then message is processed as a news article, else
 * as a mail message.
 */

int unpack(packet)
FILE *packet;
{
    /*
     * Variables for header info
     */
    Node msg_orignode, msg_destnode;	/* Origin/destination address */
    int msg_attributes;			/* Attributes of message */
    time_t msg_date;			/* Date of message */
    char msg_to[36];			/* To name */
    char msg_from[36];			/* From name */
    char msg_subject[72];		/* Subject */
    char orig_to[36];			/* Original To name */
    char orig_from[36];			/* Original From name */
    char orig_subject[72];		/* Original subject */
    /*
     * Variables for info from FIDO kludges
     */
    Node origin_node;			/* Address in origin line */
    char origin_text[128];		/* Organization taken from * Origin */
    
    int lines;				/* Lines in message body */

    char *area;				/* Area / newsgroup (NULL = mail) */
    char *p;
    int count, messagetype;
    char realto[40], realfrom[40];
    char buffer[BUFSIZ];
    int c;
    Node node;
    char mail_to[128];			/* Addressee of mail */
    char x_orig_to[128];
    int rfc_header_flag, area_header_flag;
    char *fromdomain, *thisdomain;
    static Textlist theaderlist, tbodylist; /* Textlist structs header/body */
    Textlist *theader=&theaderlist, *tbody=&tbodylist;
    char *from_line, *to_line=NULL;	/* From:/To: for output */
    char *id_line, *ref_line;		/* Message-ID:/References: */
    int this_is_mail, this_is_news;	/* Flags */


    Textlist_init(theader);
    Textlist_init(tbody);

    /*
     * Output file for news batch
     */
    {
	long n = sequencer(SEQ_NEWS);

	sprintf(news_tmp,  "%s/%08ld.tmp", news_dir, n);
	sprintf(news_name, "%s/%08ld.msg", news_dir, n);
	news_file = fopen(news_tmp, W_MODE);
	if(!news_file)
	{
	    log("$Can't create output file %s", news_tmp);
	    return -1;
	}
    }
    

    while ((messagetype = read_int(packet)) == MSGTYPE) {
	/*
	 * Clear stuff set by parsing message body
	 */
	origin_node.zone   = -1;
	origin_text[0]	   = 0;
	msgbody_area[0]    = 0;
	msgbody_fmpt	   = 0;
	msgbody_msgid[0]   = 0;
	msgbody_reply[0]   = 0;
	msgbody_intl[0]	   = 0;
	msgbody_origid[0]  = 0;
	msgbody_origref[0] = 0;
	if(msgbody_rfc_from) {
	    free(msgbody_rfc_from);
	    msgbody_rfc_from = NULL;
	}
	if(msgbody_rfc_to) {
	    free(msgbody_rfc_to);
	    msgbody_rfc_to = NULL;
	}
	lines = 0;
	Textlist_clear(theader);
	Textlist_clear(tbody);
	charset_reset();
	x_orig_to[0] = 0;


	/*
	 * Initialize some stuff
	 */
	msg_orignode.zone       = header.orig_zone;
	msg_orignode.point     = 0 /**FIXME**/;
	msg_orignode.domain[0] = 0;
	msg_destnode.zone      = header.dest_zone;
	msg_destnode.point     = 0 /**FIXME**/;
	msg_destnode.domain[0] = 0;
	
	/*
	 * Read FIDO message header and save information
	 */
	/***** Origin/destination node *****/
	msg_orignode.node = read_int(packet);
	msg_destnode.node = read_int(packet);
	/***** Origin/destination net *****/
	msg_orignode.net = read_int(packet);
	msg_destnode.net = read_int(packet);
	debug(2, "Origin:      %s", node_to_asc(&msg_orignode, FALSE));
	debug(2, "Destination: %s", node_to_asc(&msg_destnode, FALSE));
	/***** Message attributes *****/
	msg_attributes = read_int(packet);
	/***** Cost (thrown away) *****/
	read_int(packet);
	/***** Date *****/
	msg_date = lgetdate(packet);
	/***** To name *****/
	get_string(msg_to, packet, 35);
	debug(2, "To:	   %s", msg_to);
	strncpy(orig_to, msg_to, 36);
	/***** From name *****/
	get_string(msg_from, packet, 35);
	debug(2, "From:	   %s", msg_from);
	strncpy(orig_from, msg_from, 36);
	/***** Subject *****/
	get_string(msg_subject, packet, 71);
	strncpy(orig_subject, msg_subject, 72);
	/* Remove trailing blanks */
	for(count = strlen(msg_subject) - 1;
	    count >= 0 && isspace(msg_subject[count]);
	    count--				    )
	    msg_subject[count] = 0;
	if (!*msg_subject)
	    strcpy(msg_subject, "(no subject)");
	debug(2, "Subject: %s", msg_subject);

	/*
	 * Strip bad chars from header fields
	 */
	stripbad(msg_from);
	stripbad(msg_to);
	/*
	 * Convert to real names for use in ()
	 */
	realname_convert(msg_from, realfrom);
	realname_convert(msg_to, realto);
	/*
	 * We don't want `UUCP' and `GATEWAY' as names
	 */
	if(!stricmp(realto, "UUCP"))
	    *realto = 0;
	if(!stricmp(realto, "GATEWAY"))
	    *realto = 0;
	/*
	 * Convert spaces to `_'
	 */
	for(p=msg_from; *p; p++)
	    *p = *p==' ' ? '_' : *p;
	for(p=msg_to; *p; p++)
	    *p = *p==' ' ? '_' : *p;

	/*
	 * Read entire FIDO message body and store it in Textlist tbody
	 * for later output. (Must read message body first because we need
	 * some information from it.)
	 * Some special treatment for origin line and ^A
	 * kludges is done.
	 */
	rfc_header_flag  = TRUE;
	area_header_flag = TRUE;
	while(msg_getline(buffer, BUFSIZ, packet))
	{
	    if(area_header_flag && !strncmp("AREA:", buffer, 5))
	    {					/* AREA:TAG EchoMail */
		area_header_flag = FALSE;
		strncpy0(msgbody_area, buffer, sizeof(msgbody_area));
		continue;
	    }		
		
	    if(buffer[0] == 1) {		/* ^A kludge line */
		check_ctrl_a(buffer);
		continue;
	    }

	    area_header_flag = FALSE;

	    if(rfc_header_flag) {		/* RFC header line */
		if((rfc_header_flag = check_rfc_header(buffer)))
		    continue;
	    }
	    if(!strncmp(" * Origin:", buffer, 10)) {
		check_origin(buffer, &origin_node, origin_text);
		continue;
	    }
	    if(!strncmp("SEEN-BY:", buffer, 8) ||
	       !strncmp("--- ", buffer, 4)	    )
		continue;

	    lines += msg_format_buffer(buffer, tbody);

#if 0
	    lines++;
	    Textlist_append(tbody, buffer);
#endif
	}

	/*
	 * Check for mail or news.
	 * Read first line from FIDO message body. If it starts with
	 * `AREA:...' then it is news, else it is mail. area is newsgroup
	 * name or NULL for mail.
	 */
	if((area = news_msg(msgbody_area)))
	{
	    /*
	     * This is a news article.
	     */
	    debug(1, "Message is news article");
	    this_is_news = TRUE;
	    this_is_mail = FALSE;
	}
	else
	{
	    long n = sequencer(SEQ_MAIL);
	    
	    /*
	     * This is personal mail
	     */
	    debug(1, "Message is mail");
	    sprintf(mail_tmp,  "%s/%08ld.tmp", mail_dir, n);
	    sprintf(mail_name, "%s/%08ld.msg", mail_dir, n);
	    mail_file = fopen(mail_tmp, W_MODE);
	    if(!mail_file) {
		log("$Can't create output file %s", mail_tmp);
		return -1;
	    }
	    this_is_mail = TRUE;
	    this_is_news = FALSE;
	}

	/*
	 * Construct real from address, using information from
	 * header, origin line and ^A kludges.
	 */
	if(this_is_news && origin_node.zone != -1) {
	    debug(1, "Using address from ` * Origin: ...'");
	    msg_orignode = origin_node;
	}
	else {
	    debug(1, "Using address in message header");

	    if(*msgbody_intl) {
		p = strtok(msgbody_intl, " \n");    /* Destination */
		p = strtok(NULL	   , " \n");	    /* Source */
		if(p)
		    if(asc_to_node(p, &node, FALSE) == OK) {
			debug(1, "Using address from ^AINTL");
			msg_orignode = node;
		    }
	    }
	    if(msgbody_fmpt) {
		debug(1, "Point address %d", msgbody_fmpt);
		msg_orignode.point = msgbody_fmpt;
	    }
	}
	
	debug(1, "New from address %s", node_to_asc(&msg_orignode, FALSE));


	/*
	 * Do mail alias checking on both from and to names
	 */
	if(!msgbody_rfc_from)
	{
	    Alias *a;

	    debug(3, "Checking for alias: %s @ %s",
		  realfrom, node_to_asc(&msg_orignode, FALSE));
	    a = alias_by_fullname(realfrom, &msg_orignode);
	    if(a)
	    {
		debug(3, "Alias found: %s %s %s", a->username,
		      node_to_asc(&a->node, FALSE), a->fullname);
		strncpy(msg_from, a->username, SIZE_NAME);
		msg_from[MAX_NAME] = 0;
	    }
	}
	if(this_is_mail && !msgbody_rfc_to)
	{
	    Alias *a;
	    
	    debug(3, "Checking for alias: %s @ %s",
		  realto, node_to_asc(&Config.myaddr, FALSE));
	    a = alias_by_fullname(realto, &Config.myaddr);
	    if(a)
	    {
		debug(3, "Alias found: %s %s %s", a->username,
		      node_to_asc(&a->node, FALSE), a->fullname);
		strcpy(mail_to, a->username);
	    }
	    else
		strcpy(mail_to, msg_to);
	}

	/*
	 * Special handling for -u flag (unsecure):
	 *   Messages with To line in message body are send to postmaster
	 */
	if(this_is_mail && u_flag && msgbody_rfc_to)
	{
	    strncpy0(x_orig_to, msgbody_rfc_to, sizeof(x_orig_to));
	    strcpy(mail_to, POSTMASTER);
	    free(msgbody_rfc_to);
	    msgbody_rfc_to = NULL;
	}
	    
	/*
	 * There are message trackers out there in FIDONET. Obviously
	 * they can't handling addressing the gateway so we send mail
	 * from "MsgTrack..." etc. to postmaster.
	 */
	if(    !strnicmp(msg_from, "MsgTrack", 8)
	    || !strnicmp(msg_from, "Reflex_Netmail_Policeman", 24)
	    || !strnicmp(msg_from, "TrackM", 6)
	    || !strnicmp(msg_from, "ITrack", 6)
	    || !strnicmp(msg_from, "O/T-Track", 9)
	 /* || whatever ... */		    )
	{
	    strcpy(x_orig_to, mail_to);
	    strcpy(mail_to, POSTMASTER);
	}

#ifdef FIDO_DE
	/*
	 * Get domain name for FIDO address in msg_orignode, either
	 * xxx.fido.de or xxx.fidonet.org.
	 */
	thisdomain = get_fido_de_host(&Config.myaddr, TRUE );
	fromdomain = get_fido_de_host(&msg_orignode,  FALSE);

# ifdef FIDO_DE_RESTRICTED

	/*
	 * Bounce mail from nodes not within domain .fido.de
	 */
	if(this_is_mail && msgbody_rfc_to)
	    if(!msg_orignode.fido_de)
	    {
		/*
		 * Not a Fido.DE node
		 */
		debug(1, "Not a Fido.DE node: %s",
		      node_to_asc(&msg_orignode, FALSE));
		log("Bouncing mail from %s @ %s", msg_from,
		      node_to_asc(&msg_orignode, FALSE));

		fprintf(mail_file,
			"From daemon %s\n", date("%a %h %d %T 19%y", NULL) );
		fprintf(mail_file,
			"Date: %s\n", date("%a, %d %h %y %T %o", NULL));
		fprintf(mail_file,
			"From: daemon@%s%s (Mail Delivery Subsystem)\n",
			MY_HOSTNAME, MY_DOMAIN );
		fprintf(mail_file,
			"Subject: Returned mail: not a registered Fido.DE node\n");
/*
		fprintf(mail_file, "Message-Id: <%s.AA%05d@%s>\n",
			     date("%y%m%q%H%M", (long *) 0), getpid(),
			     thisdomain					);
 */
		fprintf(mail_file,
			"To: %s@%s\n",
			msg_from, node_to_domain(&msg_orignode));
		fprintf(mail_file,
			"Cc: postmaster@%s%s\n", MY_HOSTNAME, MY_DOMAIN);
		fprintf(mail_file, "\n");
		fprintf(mail_file, "	----- Transcript of session follows -----\n\n");
		fprintf(mail_file,
			"Your mail\n\n");
		fprintf(mail_file,
			"  From: %-36.36s @ FIDO %s\n",
			orig_from, node_to_asc(&msg_orignode, FALSE) );
		fprintf(mail_file,
			"  To:   %-36.36s @ FIDO %s\n",
			orig_to,   node_to_asc(&msg_destnode, FALSE) );
		fprintf(mail_file,
			"\naddressed to Internet\n\n" );
		fprintf(mail_file,
			"  To:   %s\n", msgbody_rfc_to );
		fprintf(mail_file,
			"\ncould not be delivered.\n\n" );		
		fprintf(mail_file, "\
Usage of this gateway is restricted to users and points of German\n\
FIDO nodes registered for the Internet domain %s.\n\n", FIDO_DE_DOMAIN);
		fprintf(mail_file,
			"For more information about FidoGate send a message to\n\n");
		fprintf(mail_file, "  %s\n", FIDO_DE_POSTMASTER);
		goto output_close;
		
/*
		fprintf(mail_file, "	----- Unsent message follows -----\n");
		goto output_msgbody;
 */
	    }
		
# endif /**FIDO_DE_RESTRICTED**/

#else
	thisdomain = node_to_domain(&Config.myaddr);
	fromdomain = node_to_domain(&msg_orignode);
#endif /**FIDO_DE**/

	/*
	 * Check mail messages' user name
	 */
	if(this_is_mail && !msgbody_rfc_to &&
	   !strchr(mail_to, '@') && !strchr(mail_to, '%') &&
	   !strchr(mail_to, '!')			    )
	{
#ifdef RETURN_FAILED_MAIL
	    /*
	     * If mail_to is a local user name, check for existence.
	     * If user does not exist, bounce message.
	     */
	    struct passwd *pw, *getpwnam();
	    
	    pw = getpwnam(mail_to);
	    if(!pw) {				/* Doesn't exist -> bounce */
		fprintf(mail_file, "From funpack %s\n",
			      date("%a %h %d %T 19%y", NULL) );
		fprintf(mail_file, "Date: %s\n", date("%a, %d %h %y %T %o", NULL));
		fprintf(mail_file, "From: Gateway to FIDONet <%s@%s>\n",
			     "rfmail", thisdomain		    );
		fprintf(mail_file, "Subject: Returned mail: user unknown\n");
		fprintf(mail_file, "Message-Id: <%s.AA%05d@%s>\n",
			     date("%y%m%q%H%M", (long *) 0), getpid(),
			     thisdomain					);
		fprintf(mail_file, "To: %s@%s\n",
			msg_from, node_to_domain(&msg_orignode));
		fprintf(mail_file, "\n  ----- Transcript of session follows -----\n");
		fprintf(mail_file, "User %s is unknown at %s%s.\n\n",
			     mail_to, MY_HOSTNAME, MY_DOMAIN	);
		fprintf(mail_file, "If you want to send mail to a user on the Internet/Usenet/DNet/EUNET\n");
		fprintf(mail_file, "via this gateway, your message must start with a `To:' line containing\n");
		fprintf(mail_file, "the address, e.g.\n");
		fprintf(mail_file, "	  To: mj@dfv.rwth-aachen.de\n\n");
		fprintf(mail_file, "	----- Unsent message follows -----\n");

		log("Mail from %s at %s to %s bounced", msg_from,
		    node_to_asc(&msg_orignode, FALSE), mail_to		    );

		goto output_msgbody;
	    }
#endif

#ifdef ADD_DOMAIN
	    /*
	     * Add `@host.domain' to local address
	     */
	    strcat(mail_to, "@");
	    strcat(mail_to, MY_HOSTNAME);
	    strcat(mail_to, MY_DOMAIN);
#endif
	}

#ifdef MAUS_DE
	/*
	 * Special handling for addresses generated by the MAUS<->FIDO
	 * gateway. Convert them to the Internet format, e.g.
	 *     `User_Name_%_MAUS_AC@p.f.n.z...'	 -->  `user_name@ac.maus.de'
	 */
	p = maus_de_convert(msg_from);
	if(p)
	    msgbody_rfc_from = p;
	p = maus_de_convert(msg_to);
	if(p)
	    msgbody_rfc_to = p;
#endif /**MAUS_DE**/

	/*
	 * Construct string for From: header line
	 */
	if(msgbody_rfc_from) {
	    if(strchr(msgbody_rfc_from, '(') || strchr(msgbody_rfc_from, '<'))
		from_line = buf_sprintf("%s", msgbody_rfc_from);
	    else
		from_line = buf_sprintf("%s (%s)", msgbody_rfc_from, realfrom);
	}
	else
	    from_line = buf_sprintf(
#ifdef LOCAL_FROM
				    /* user@p.f.n.z.host.domain */
				    /* "%s@%s.%s%s (%s)",       */
				    /* user%p.f.n.z@host.domain */
				    "%s%%%s@%s%s (%s)",	    /****/
				    msg_from,
				    node_to_pfnz(&msg_orignode, FALSE),
				    MY_HOSTNAME, MY_DOMAIN, realfrom
#else /**!LOCAL_FROM**/
				    "%s@%s (%s)", msg_from, fromdomain,
				    realfrom
#endif /**LOCAL_FROM**/
				    );

	/*
	 * Construct string for To:/X-Comment-To: header line
	 */
	if(msgbody_rfc_to) {
	    if(strchr(msgbody_rfc_to, '(') ||
	       strchr(msgbody_rfc_to, '<') || !*realto)
		to_line = buf_sprintf("%s", msgbody_rfc_to);
	    else
		to_line = buf_sprintf("%s (%s)", msgbody_rfc_to, realto);
	}
	else {
	    if(this_is_news)
	    {
		if(!strcmp(msg_to, "All") || !strcmp(msg_to, "Alle") ||
		   !strcmp(msg_to, "*.*") || !strcmp(msg_to, "*"))
		    to_line = NULL;
		else
		    to_line = buf_sprintf("(%s)", realto);
	    }
	    
	    if(this_is_mail)
		to_line = buf_sprintf("%s", mail_to);
	}

	/*
	 * Construct Message-ID and References header lines
	 */
	if(*msgbody_origid)
	    id_line = msgid_convert_origid(msgbody_origid, TRUE);
	else
	{
	    id_line = msgid_fido_to_rfc(msgbody_msgid);
	    if(id_line == NULL)
		id_line = msgid_default(&msg_orignode, orig_from, orig_to,
					orig_subject, msg_date);
	}
	if(*msgbody_origref)
	    ref_line = msgid_convert_origid(msgbody_origref, FALSE);
	else
	    ref_line = msgid_fido_to_rfc(msgbody_reply);

	/*
	 * Output RFC mail/news header
	 *
	 * Mail
	 */
	if(this_is_mail) {
	    /*
	     * Log it
	     */
	    log("%-13s >  [ %s -> %s ]", node_to_asc(&msg_orignode, FALSE),
		realfrom, msgbody_rfc_to ? msgbody_rfc_to : mail_to	);
	    
#if 0
	    Textlist_appendf(theader,
		"From %s %s remote from %s\n",
		msg_from, date("%a %h %d %T 19%y", NULL), fromdomain	);
#endif
	    Textlist_appendf(theader,
		"From %s@%s %s\n",
		msg_from, fromdomain, date("%a %h %d %T 19%y", NULL)	);
	    Textlist_appendf(theader,
		"Received: by %s (FIDOGATE %s)\n",
		thisdomain, version_global()                            );
	    Textlist_appendf(theader,
		"\tid AA%05d; %s\n",
		getpid(), date("%a, %d %h %y %T %o (%z)", (long *)NULL) );
	    Textlist_appendf(theader,
		"Date: %s\n",
		date("%a, %d %h %y %T %o", &msg_date)			);
	    Textlist_appendf(theader,
		"From: %s\n",
		from_line						);
	    Textlist_appendf(theader,
		"Subject: %s\n",
		msg_subject						);
	    Textlist_appendf(theader,
		"Message-ID: %s\n",
		id_line							);
	    Textlist_appendf(theader,
		"To: %s\n",
		to_line							);
	    if(*x_orig_to)
	    Textlist_appendf(theader,
		"X-Orig-To: %s\n",
		x_orig_to						);
#ifdef ERRORS_TO
	    Textlist_appendf(theader,
		"Errors-To: %s\n",
		ERRORS_TO						);
#endif
	    Textlist_appendf(theader,
		"Lines: %d\n",
		lines							);
	    Textlist_appendf(theader,
		"X-Gateway: FIDOGATE %s\n", version_global()		);
	}

	/*
	 * News
	 */
	if(this_is_news) {
	    Textlist_appendf(theader,
		"Path: %s!%s!%s\n",
		thisdomain, fromdomain, msg_from			);
	    Textlist_appendf(theader,
		"Date: %s\n",
		date("%a, %d %h %y %T %o", &msg_date)			);
	    Textlist_appendf(theader,
		"From: %s\n",
		from_line						);
	    Textlist_appendf(theader,
		"Subject: %s\n",
		msg_subject						);
	    Textlist_appendf(theader,
		"Message-ID: %s\n",
		id_line							);
	    if(ref_line)
	    Textlist_appendf(theader,
		"References: %s\n",
		ref_line						);
	    Textlist_appendf(theader,
		"Newsgroups: %s\n",
		area							);
	    if(to_line)
	    Textlist_appendf(theader,
		"X-Comment-To: %s\n",
		to_line							);
	    if(*origin_text)
	    Textlist_appendf(theader,
		"Organization: %s\n",
		origin_text						);
	    Textlist_appendf(theader,
		"Lines: %d\n",
		lines							);
	    Textlist_appendf(theader,
		"X-Gateway: FIDOGATE %s\n", version_global()		);
	}

	Textlist_appendf(theader, "\n");

	/*
	 * Write header and message body to output file
	 */
	if(this_is_news) {
	    /* News batch */
	    fprintf(news_file, "#! rnews %ld\n", Textlist_size(theader) +
						Textlist_size(tbody)	);
	    Textlist_print(theader, news_file);
	    Textlist_print(tbody,   news_file);
	}
	if(this_is_mail) {
	    /* Mail message */
	    Textlist_print(theader, mail_file);
	    Textlist_print(tbody,   mail_file);
output_close:
	    /* Close mail file */
	    fclose(mail_file);
	    /* Rename .tmp -> .msg */
	    if(rename(mail_tmp, mail_name) == -1)
		log("$Can't rename %s to %s", mail_tmp, mail_name);
	}

	/*
	 * Dome with this message.
	 */
	debug(1, "Done with message");
	continue;

	/*
	 * In case of error skip text of message
	 */
	while((c = getc(packet)) && c != EOF);
    }

    /* Close news file */
    fclose(news_file);
    /* Rename .tmp -> .msg */
    if(rename(news_tmp, news_name) == -1)
	log("$Can't rename %s to %s", news_tmp, news_name);

    if (messagetype != MSGTYPE && messagetype != EOF && messagetype != 0) {
	log("Strange ending: %d", messagetype);
	return -1;
    }

    debug(1, "Done with packet");

    return 0;
}



/*
 * spawn_process() --- call external program
 */

void spawn_process(progname)
char *progname;
{
int pid;

    pid = fork();			/* Neuen Prozess erzeugen */
    if(pid == 0) {			/* Child-Prozess */
	if(execl(progname,progname,NULL)) 
	{
	    debug(1, "execl %s failed", progname);
	    exit(1);
	}
    }
    else				/* Parent-Prozess */
	wait((int *)0);
}



/*
 * Usage messages
 */
void short_usage()
{
    fprintf(stderr, "usage: %s [-options] [user ...]\n", PROGRAM);
    fprintf(stderr, "       %s --help  for more information\n", PROGRAM);
}


void usage()
{
    fprintf(stderr, "FIDOGATE %s  %s %s\n\n",
	    version_global(), PROGRAM, version_local(VERSION) );
    
    fprintf(stderr, "usage:   %s [-options]\n\n", PROGRAM);
    fprintf(stderr, "\
options: -u --unsecure                toss unsecure packets\n\
         -I --inbound-dir name        set inbound packets directory\n\
         -l --lock-file name          create lock file while processing\n\
         -x --exec-program name       exec program after processing\n\
	 -L --lib-dir name            set FIDOGATE lib directory\n\
	 -S --spool-dir name          set FIDOGATE spool directory\n\
	 -v --verbose                 more verbose\n\
	 -h --help                    this help\n\
	 -m --my-addr Z:N/F.P         set FIDO address\n\
	 -M --my-fake-addr Z:N/F.P    set FIDO fakenet address\n\
	 -r --remote-addr Z:N/F.P     set FIDO remote address\n"  );
}



/***** main() ****************************************************************/

int main(argc, argv)
int argc;
char *argv[];
{
    struct dirent *dir;
    DIR *dp;
    int c;
    char *lockname = NULL;
    char *execprog = NULL;
    int fd;

    int option_index;
    static struct option long_options[] =
    {
	{ "spool-dir",    1, 0, 'S'},	/* Set FIDOGATE spool directory */
	{ "lib-dir",      1, 0, 'L'},	/* Set FIDOGATE lib directory */
	{ "verbose",      0, 0, 'v'},	/* More verbose */
	{ "help",         0, 0, 'h'},	/* Help */
	{ "my-addr",      1, 0, 'm'},	/* Set FIDO address */
	{ "my-fake-addr", 1, 0, 'M'},	/* Set FIDO fakenet address */
	{ "remote-addr",  1, 0, 'r'},	/* Set FIDO remote address */

	{ "unsecure",     0, 0, 'u'},	/* Toss unsecure packets */
	{ "inbound-dir",  1, 0, 'I'},	/* Set inbound packets directory */
	{ "lock-file",    1, 0, 'l'},	/* Create lock file while processing */
	{ "exec-program", 1, 0, 'x'},	/* Exec program after processing */

	{ 0,              0, 0, 0  }
    };

    /* Init configuration */
    config_init();

    /* Default inbound directory */
    sprintf(in_dir, "%s/%s", SPOOLDIR, INBOUND);
    sprintf(mail_dir, "%s/%s/%s", SPOOLDIR, INBOUND, INBOUND_MAIL);
    sprintf(news_dir, "%s/%s/%s", SPOOLDIR, INBOUND, INBOUND_NEWS);

    while ((c = getopt_long(argc, argv, "S:L:vhm:M:r:uI:l:x:",
			    long_options, &option_index     )) != EOF)
	switch (c) {
	case 'u':
	    /* Unsecure */
	    sprintf(in_dir, "%s/%s", SPOOLDIR, UNSECURE);
	    u_flag = TRUE;
	    break;
	case 'I':
	    /* Inbound packets directory */
	    strncpy0(in_dir, optarg, sizeof(in_dir));
	    sprintf(mail_dir, "%s/%s", in_dir, INBOUND_MAIL);
	    sprintf(news_dir, "%s/%s", in_dir, INBOUND_NEWS);
	    p_flag = TRUE;
	    break;
	case 'L':
	    /* Set lib directory */
	    set_libdir(optarg);
	    break;
	case 'l':
	    /* Lock file */
	    lockname = optarg;
	    break;
	case 'x':
	    /* Exec program after unpack */
	    execprog = optarg;
	    break;
	case 'v':
	    verbose++;
	    break;
	case 'm':
	    config_myaddr(optarg);
	    break;
	case 'M':
	    config_myfakeaddr(optarg);
	    break;
	case 'r':
	    config_remoteaddr(optarg);
	    break;
	case 'h':
	    usage();
	    exit(0);
	    break;
	default:
	    short_usage();
	    exit(EX_USAGE);
	    break;
	}

    
    /*
     * If called with -l lock option, try to create lock FILE
     */
    if(lockname)
    {
	/*
	 * Use open() with flag O_EXCL, this will fail if the
	 * lock file already exists
	 */
	fd = open(buf_sprintf("%s/%s", SPOOLDIR, lockname),
		  O_RDWR | O_CREAT | O_EXCL, 0600);
	debug(1, "lock %s", fd==-1 ? "failed" : "succeeded");
	if(fd == -1)			    /* Failed */
	    exit(2);
	close(fd);
    }
	
    dp = opendir(in_dir);

    if(!dp)
    {
	log("$Unable to open inbound directory %s", in_dir);
	if(lockname)
	    unlink(lockname);
	exit(EX_OSERR);
    }
    
    while((dir = readdir(dp)))
    {
	if(wildmat(dir->d_name, "*.pkt"))
	{
	    sprintf(pkt_name, "%s/%s", in_dir, dir->d_name);
	    debug(1, "Unpacking %s", pkt_name);

	    /*
	     * Open packet
	     */
	    pkt_file = fopen(pkt_name, R_MODE);
	    if(!pkt_file) {
		log("$Unable open packet %s", pkt_name);
	    /*	if(lockname)
		    unlink(lockname);  */
		exit(EX_OSERR);
	    }
	    if (read_header(pkt_file)) {
		if (feof(pkt_file))
		    log("Missing packet header");
		else
		    log("$Error reading header");
	    /*	if(lockname)
		    unlink(lockname);  */
		exit(EX_OSERR);
	    }

	    debug(1, "Packet from: %d:%d/%d", header.orig_zone,
		  header.orig_net, header.orig_node);
	    debug(1, "Packet to:   %d:%d/%d", header.dest_zone,
		  header.dest_net, header.dest_node		);
	    debug(1, "Time/date:   %02d:%02d:%02d %d.%d.%d",
		  header.hour, header.minute, header.second,
		  header.day, header.month+1, header.year   );
	    debug(1, "Version %d, product code %02x",
		     header.ver, header.product);
	    debug(1, "Password \"%s\"", header.pwd_kludge);

	    /*
	     * Unpack it
	     */
	    if(unpack(pkt_file) == -1) 
	    {
		log("Error unpacking %s", pkt_name);
		exit(EX_OSERR);
	    }

	    fclose(pkt_file);

	    if (unlink(pkt_name)) {
		log("$Could not unlink packet %s", dir->d_name);
	    /*	if(lockname)
		    unlink(lockname);  */
		exit(EX_OSERR);
	    }
	}
    }
    
    closedir(dp);

    /*
     * Execute given command, if option -e set.
     */
    if(execprog)
    {
	char buf[128];
	
	sprintf(buf, "%s/%s", LIBDIR, execprog);
	spawn_process(buf);
    }
    
    if(lockname)
	if(unlink(buf_sprintf("%s/%s", SPOOLDIR, lockname)))
	    log("$Error removing lockfile");
    
    exit(EX_OK);
}
