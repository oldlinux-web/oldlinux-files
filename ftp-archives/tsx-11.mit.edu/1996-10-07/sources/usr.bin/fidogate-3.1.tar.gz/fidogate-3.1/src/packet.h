/*:ts=8*/
/*****************************************************************************
 * FIDOGATE --- Gateway UNIX Mail/News <-> FIDO NetMail/EchoMail
 *
 * $Id: packet.h,v 3.1 1993/09/14 07:40:04 mj beta mj $
 *
 * Packet structure
 *
 *****************************************************************************
 * Copyright (C) 1990, 1993
 *  _____ _____
 * |     |___  |   Martin Junius             FIDO:      2:242/6.1
 * | | | |   | |   Republikplatz 3           Internet:  mj@sungate.fido.de
 * |_|_|_|@home|   D-52072 Aachen, Germany   Phone:     ++49-241-86931 (voice)
 *
 * This file is part of FIDOGATE.
 *
 * FIDOGATE is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * FIDOGATE is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with FIDOGATE; see the file COPYING.  If not, write to the Free
 * Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************/

/* Structure for packet header. */

typedef struct _packet {
    short orig_node;                /* originating node */
    short dest_node;                /* destinating mode */
    short year;                     /* packing year (e.g. 1986) */
    short month;                    /* 0-11 for Jan - Dec */
    short day;                      /* 1-31 */
    short hour;                     /* 0-23 */
    short minute;                   /* 0-59 */
    short second;                   /* 0-59 */
    short rate;                     /* maximum baud rate */
    short ver;                      /* header version */
    short orig_net;                 /* originating net */
    short dest_net;                 /* destination net */
    char product;                   /* product */
    char x1;                        /* Extra byte */
#ifdef FIDO_V11w
    short fill[16];                 /* extra space */
#else
    char pwd_kludge[8];
    short orig_zone;
    short dest_zone;
    char B_fill2[16];
    long B_fill3;
#endif
} Packet;

/* Attributes tranferred via mail. */

#define ATTR_PRIVATE    0000001     /* private msg */
#define ATTR_CRASH      0000002     /* crash mail */
#define ATTR_FILE       0000020     /* files attached */
#define ATTR_UNUSED     0002000     /* unused */
#define ATTR_RRR        0010000     /* SEAdog only */
#define ATTR_IRR        0020000     /* SEAdog only */
#define ATTR_AUDREQ     0040000     /* SEAdog only */

/* Packet and message types. */

#define HDRVER          2
#define MSGTYPE         2

/* Sizes of to/from/subject/date field */
#define SIZE_NAME       36
#define SIZE_FROM       SIZE_NAME
#define SIZE_TO         SIZE_NAME
#define SIZE_SUBJECT    72
#define SIZE_DATE       20
#define MAX_NAME        35
