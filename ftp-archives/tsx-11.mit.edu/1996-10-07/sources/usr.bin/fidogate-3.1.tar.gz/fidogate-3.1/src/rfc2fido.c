/*:ts=8*/
/*****************************************************************************
 * FIDOGATE --- Gateway software UNIX <-> FIDO
 *
 * $Id: rfc2fido.c,v 3.1 1993/09/14 07:40:04 mj beta mj $
 *
 * Read mail or news from standard input and convert it to a FIDO packet.
 *
 *****************************************************************************
 * Copyright (C) 1990, 1993
 *  _____ _____
 * |     |___  |   Martin Junius             FIDO:      2:242/6.1
 * | | | |   | |   Republikplatz 3           Internet:  mj@sungate.fido.de
 * |_|_|_|@home|   D-52072 Aachen, Germany   Phone:     ++49-241-86931 (voice)
 *
 * This file is part of FIDOGATE.
 *
 * FIDOGATE is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * FIDOGATE is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with FIDOGATE; see the file COPYING.  If not, write to the Free
 * Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************/

#include "fidogate.h"
#include "getopt.h"

#include <pwd.h>
#include <sys/stat.h>



#define PROGRAM "rfc2fido"
#define VERSION "$Revision: 3.1 $"


/*
 * Prototypes
 */
int put_string		P((FILE *, char *));
int put_line		P((FILE *, char *));
int write_int		P((int, FILE *));
int write_msg_hdr	P((FILE *, char *, char *, char *, char *, char *,
			   Node *));
int write_pkt_hdr	P((FILE *));
void get_return_address	P((char *));
void sendback		P((const char *, ...));
char *mail_sender	P((void));
char *receiver		P((char *, Node *));
char *mail_receiver	P((char *, Node *));
char *fido_date		P((void));
char *estrtok		P((char *, char *));
int snd_mail		P((char *, int));
int snd_message		P((Node, char **, char *, char *, char *, int));
int print_tear_line	P((FILE *));
int print_origin	P((FILE *));
int print_local_msgid	P((FILE *));
int print_via		P((FILE *));
char *new_packet_name	P((void));

void short_usage	P((void));
void usage		P((void));



/*
 * Max. message size for FIDO. Due to some more brain damage in FIDONET
 * programs we have to split larger messages into several smaller ones.
 * We use 13000 bytes as the max. message size, this leaves enough room for
 * headers and other things.
 */
#define MAXMSGSIZE	13000



extern struct passwd *getpwuid();
extern int getopt();
extern char *optarg;
extern int optind;
extern void exit();
extern char *regex();
extern time_t time();
extern FILE *popen();


/* Created FIDO packets */
char  packet_dir[BUFSIZ];
char  packet_name[BUFSIZ];
char  packet_tmp[BUFSIZ];
FILE *packet_file;
#ifdef BINKLEY_FLO
char  flo_name[BUFSIZ];
FILE *flo_file;
#endif

/* Verbosity */
int verbose = INIT_VERBOSE;

/* Private mail (default) */
bool private = TRUE;

/* News-article */
int newsmode = FALSE;

/* Append -a flag */
int a_flag = FALSE;
/* Batch -b flag */
int b_flag = FALSE;
/* Packet file name -f flag */
int f_flag = FALSE;
char *f_arg = NULL;

/*
 * Global Textlist to save message body
 */
Textlist body = { NULL, NULL };



/*
 * Put string to file in null-terminated format.
 */
int put_string(fp, s)
FILE *fp;
char *s;
{
    fputs(s, fp);
    putc(0, fp);
    
    return ferror(fp);
}



/*
 * Put line to FIDO packet, replacing \n with \r\n
 */
int put_line(fp, s)
FILE *fp;
char *s;
{
    for(; *s; s++)
    {
	if(*s == '\n')
	    putc('\r', fp);
	putc(*s, fp);
    }

    return ferror(fp);
}
    


/*
 * Write 16-bit integer in 80x86 format, i.e. low byte first,
 * then high byte. Machine independent function.
 */
int write_int(value, fp)
int value;
FILE *fp;
{
    putc(value & 0xff, fp);
    putc((value >> 8) & 0xff, fp);

    return ferror(fp);
}



/*
 * Write FIDO message header to mail packet.
 */

int write_msg_hdr(pkt, from, to, subject, date, flags, node)
FILE *pkt;
char *from, *to, *subject, *date, *flags;
Node *node;
{
    int attr = 0;
    int private_flag = private;

    /* Flags */
    for(; *flags; flags++)
	switch(*flags) {
	case 'P':
	    attr |= ATTR_PRIVATE;
	    private_flag = TRUE;
	    break;
	case 'C':
	    attr |= ATTR_CRASH;
	    break;
	}

    /* Write header to packet */
    write_int(MSGTYPE, pkt);
    write_int(private_flag ? Config.myaddr.node : Config.myfakeaddr.node, pkt);
    write_int(node->node, pkt);
    write_int(private_flag ? Config.myaddr.net  : Config.myfakeaddr.net , pkt);
    write_int(node->net, pkt);
    write_int(attr, pkt);
    write_int(0, pkt);
    put_string(pkt, date);
    put_string(pkt, to);
    put_string(pkt, from);
    put_string(pkt, subject);

    return ferror(pkt);
}



/*
 *  Write packet header for new packet.
 */

int write_pkt_hdr(packet)
FILE *packet;
{
    struct tm *tm;
    time_t clock;

    debug(1, "Packet:  %s  ->  %s",
	  node_to_asc(&Config.myfakeaddr, TRUE),
	  node_to_asc(&Config.remoteaddr, TRUE) );
    
    clock = time(0);
    tm    = localtime(&clock);

#ifdef PACKET_2PLUS

    /* write header to file */
    write_int(Config.myfakeaddr.node, packet); /* from node */
    write_int(Config.remoteaddr.node, packet); /* to node */
    write_int(tm->tm_year + 1900,     packet); /* year */
    write_int(tm->tm_mon,             packet); /* month */
    write_int(tm->tm_mday,            packet); /* day */
    write_int(tm->tm_hour + 1,        packet); /* hour */
    write_int(tm->tm_min,             packet); /* minute */
    write_int(tm->tm_sec,             packet); /* second */
    write_int(0,                      packet); /* Baud rate */
    write_int(2,                      packet); /* Packet version */
    write_int(Config.myfakeaddr.net,  packet); /* from net */
    write_int(Config.remoteaddr.net,  packet); /* to net */
    putc(PRODUCT_CODE,                packet); /* FTSC Product-code Low */
    putc(version_major(),             packet); /* FTSC Product-rev Major */
    fwrite(PACKET_PASSWD,8,1,         packet); /* packet password */
    write_int(Config.myfakeaddr.zone, packet); /* from zone */
    write_int(Config.remoteaddr.zone, packet); /* to zone */
    write_int(0xF8,                   packet); /* ??? */
    write_int(0x0100,                 packet); /* ??? */
    putc(0,                           packet); /* FTSC Product-code Hi */
    putc(version_minor(),             packet); /* FTSC Product-rev Minor */
    write_int(1,                      packet); /* Capability word */
    write_int(Config.myfakeaddr.zone, packet); /* from zone again */
    write_int(Config.remoteaddr.zone, packet); /* to zone again */
    write_int(Config.myfakeaddr.point,packet); /* from point */
    write_int(Config.remoteaddr.point,packet); /* to point */
    fputs("XPKT", packet); /* Produkt specific data */

#else /**!PACKET_2PLUS**/

    /* write header to file */
    write_int(Config.myfakeaddr.node, packet); /* from node */
    write_int(Config.remoteaddr.node, packet); /* to node */
    write_int(tm->tm_year + 1900,     packet); /* year */
    write_int(tm->tm_mon,             packet); /* month */
    write_int(tm->tm_mday,            packet); /* day */
    write_int(tm->tm_hour + 1,        packet); /* hour */
    write_int(tm->tm_min,             packet); /* minute */
    write_int(tm->tm_sec,             packet); /* seconds */
    write_int(0,                      packet); /* baud rate */
    write_int(HDRVER,                 packet); /* packet version */
    write_int(Config.myfakeaddr.net,  packet); /* from net */
    write_int(Config.remoteaddr.net,  packet); /* to net */
    putc(0,                           packet); /* product code */
    putc(0,                           packet); /* filler */
    fwrite(PACKET_PASSWD,8,1,         packet); /* packet password */
    write_int(Config.myfakeaddr.zone, packet); /* from zone */
    write_int(Config.remoteaddr.zone, packet); /* to zone */
    {
	int count;
	for(count = 0; count < 20; count++)
	    putc(0, packet);                   /* some silly stuff */
    }
    
#endif /**PACKET_2PLUS**/

    if(ferror(packet) || feof(packet)) {
      log("$Write error on packet header");
      return FALSE;
    }

    return TRUE;
}


/*
 * Get return address for returning undeliverable mail to sender.
 * Extract it from Reply-To: or From: fields.
 */

void get_return_address(address)
char *address;
{
    char *field;

    *address = 0;

    /* check is there is Reply-To: field */
    if((field = header_get("Reply-To"))) {
	addr_from_rfcaddr(field, address);
	return;
    }

    /* no Reply-To:, check for From: */
    if((field = header_get("From"))) {
	addr_from_rfcaddr(field, address);
	return;
    }

    /* not found, send it to postmaster */
    strcpy(address, POSTMASTER);
}



/*
 * In case of error print message (mail returned by MTA)
 */

#ifdef __STDC__
void sendback(const char *fmt, ...)
{
    va_list args;
    
    va_start(args, fmt);
#else /**!__STDC__**/    
void sendback(va_alist)
va_dcl
{
    va_list args;
    char *fmt;

    va_start(args);
    fmt = va_arg(args, char *);
#endif /**__STDC__**/


    fprintf(stderr, "Internet -> FIDO gateway / FIDOGATE %s\n",
	    version_global()                                   );
    fprintf(stderr, "   ----- ERROR -----\n");
    vfprintf(stderr, fmt, args);
    fprintf(stderr, "\n");
}



/*
 * Return sender's full name. This is taken from
 *   - Reply-To header
 *   - From header
 *   - user id and password file
 *   - environment LOGNAME or USER
 */

char *mail_sender()
{
    struct passwd *pwd;
    static char buffer[BUFSIZ];
    char *from;
    char *p;
    
    /*
     * Look up name in Reply-To or From header of message
     */
    if((from = header_get("Reply-To")) == NULL)
	from = header_get("From");

    if(from)
    {
	/*
	 * Found Reply-To or From header
	 */
	debug(3, "RFC From: %s", from);
	if(!name_from_rfcaddr(from, buffer))
	    username_from_rfcaddr(from, buffer);
	debug(3, "RFC Full name: %s", buffer);
	return buffer;
    }

    /*
     * Try user id and passwort file entry
     */
    if((pwd = getpwuid(getuid())))
    {
	strcpy(buffer, pwd->pw_gecos);
	if((p = strchr(buffer, ',')))
	    /*
	     * Kill stuff after ','
	     */
	    *p = 0;
	if(!*buffer)
	    /*
	     * Empty, use user name
	     */
	    strcpy(buffer, pwd->pw_name);
	debug(3, "passwd Full name: %s", buffer);
	return buffer;
    }

    /*
     * Use user name from environment as a last resort
     */
    if((p = getenv("LOGNAME")))
    {
	strcpy(buffer, p);
	debug(3, "Env LOGNAME Full name: %s", buffer);
	return buffer;
    }
    if((p = getenv("USER")))
    {
	strcpy(buffer, p);
	debug(3, "Env USER Full name: %s", buffer);
	return buffer;
    }

    debug(5, "No name for sender found");
    strcpy(buffer, "Unknown User");
    return buffer;
}



/*
 * receiver() --- Check for aliases and beautify name
 */

char *receiver(to, node)
char *to;
Node *node;
{
    static char name[SIZE_NAME];
    int i, c, convert_flag;
    Alias *alias;

    /*
     * Check for name alias
     */
    debug(5, "Name for alias checking: %s", to);

    if((alias = alias_by_username(to, node)))
    {
	debug(5, "Alias found: %s %s %s", alias->username,
	      node_to_asc(&alias->node, FALSE), alias->fullname);

	strcpy(name, alias->fullname);
	return name;
    }
    
    /*
     * Alias not found. Return the the original receiver with all
     * '_' characters replaced by space and all words capitalized.
     */
    convert_flag = isupper(*to) ? -1 : 1;
    for(i=0; *to && i<35; i++, to++) {
	c = *to;
	switch(c) {
	    case '_':
		name[i] = ' ';
		if(!convert_flag)
		    convert_flag = 1;
		break;
	    case '%':
		if(convert_flag != -1)
		    convert_flag = 2;
		/**Fall thru**/
	    default:
		if(convert_flag > 0) {
		    name[i] = islower(c) ? toupper(c) : c;
		    if(convert_flag == 1)
			convert_flag = 0;
		}
		else
		    name[i] = c;
		break;
	}
    }
    name[i] = 0;

    debug(5, "No alias found: return %s", name);

    return name;
}



/*
 * Return from field for FIDO message.
 * Alias checking is done via receiver().
 */

char *mail_receiver(address, node)
char *address;
Node *node;
{
    char *p, *to;
    int found = 0;
    char name[SIZE_NAME];
    char realname[128];
    char addr[128], myaddr[128];
    Node dummy;

    realname[0] = 0;

    if(address) {
	/*
	 * Address is argument
	 */
	debug(3, "RFC To: %s", address);
	if(parse_address(address, name, node)) {
	    log("Parse of address %s failed", address);
	    return NULL;
	}
    }
    else {
	/*
	 * News/EchoMail: address is echo feed
	 */
	*node = Config.remoteaddr;
	strcpy(name, "All");
    
	/*
	 * User-defined header line X-Comment-To for gateway software
	 * (can be patched into news reader)
	 */
	if( (to = header_get("X-Comment-To")) )
	    if(name_from_rfcaddr(to, realname) && *name)
		strncpy0(name, realname, sizeof(name));
    }

#if 0 /* Disabled checking of headers for real names */
    /*
     * Try to look up a better real name in header fields
     *
     * Standard RFC822 header line
     */
    if(to = header_get("To")) {
	debug(5, "Checking To: field");
	addr_from_rfcaddr(to, addr);
	if(!address || !strcmp(address, addr)) {
	    name_from_rfcaddr(to, realname);
	    found = 1;
	}
    }

    /*
     * User-defined header line for gateway software
     * (can be patched into news reader)
     */
    if(!found && (to = header_get("X-Comment-To"))) {
	debug(5, "Checking X-Comment-To: field");
	addr_from_rfcaddr(to, addr);
	if(!address || !strcmp(address, addr)) {
	    name_from_rfcaddr(to, realname);
	    found = 1;
	}
    }
    
    /*
     * Header generated by nn's `r' command
     */
    if(!found && (to = header_get("Orig-To"))) {
	debug(5, "Checking Orig-To: field");
	addr_from_rfcaddr(to, addr);
	if(!address || !strcmp(address, addr)) {
	    name_from_rfcaddr(to, realname);
	    found = 1;
	}
    }
#endif /**0**/
    
    /*
     * News message: get name from address taken out of header line
     */
    if(found && !address) {
	/*
	 * If we've got `user%p.f.n.z@HOST.DOMAIN' address, strip
	 * of `@HOST.DOMAIN' part.
	 */
	if((p = strrchr(addr, '@'))) {
	    strcpy(myaddr, MY_HOSTNAME);
	    if(!stricmp(p+1, myaddr))
		*p = 0;
	    strcat(myaddr, MY_DOMAIN);
	    if(!stricmp(p+1, myaddr))
		*p = 0;
	}
	    
	parse_address(addr, name, &dummy);
    }
	
    /*
     * Use real name from header line, if no special addressing with '%'
     */
    if(found && !strchr(name, '%') && *realname)
	strncpy0(name, realname, SIZE_NAME);
    
    return receiver(name, node);
}



/*
 * Get date field for FIDO message. Look for `Date:' header or use
 * current time.
 */

char *fido_date()
{
    time_t timevar;
    struct tm *localtime();
    struct tm *mtime;
    static char timebuf[20];
    /* literal months */
    static char *months[] = {
	"Jan", "Feb", "Mar", "Apr", "May", "Jun",
	"Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
	(char *) 0,
    };
    char *header_date;

    timevar = -1;
    
    if((header_date = header_get("Date"))) {
	/* try to extract date and other information from it */
	debug(3, "RFC Date: %s", header_date);
	timevar = get_date(header_date, NULL);
	if(timevar == -1)
	    log("Can't parse Date: %s", header_date);
    }
    
    if(timevar == -1)
    {
	/* No valid time, use local time */
	debug(3, "Invalid time - using local time");
	timevar = time(0);
    }
    
    debug(5, "timevar %ld", timevar);
    mtime = localtime(&timevar);
    /* Save date in FTS-0001 format ! */
    sprintf(timebuf, "%02d %3s %02d  %02d:%02d:%02d",
		     mtime->tm_mday, months[mtime->tm_mon], mtime->tm_year,
		     mtime->tm_hour, mtime->tm_min, mtime->tm_sec	    );

    return timebuf;
}



char *estrtok(s, sep)
char *s, *sep;
{
    char *p;

    if ((p = strtok(s, sep)))
	return p;
    return "";
}



/*
 * Output mail/news messages into spool file(s) for fpack
 */

#define NGROUPS		10
#define NFIDO		6

#define FIDO_NODE	0
#define FIDO_TO		1
#define FIDO_FROM	2
#define FIDO_SUBJECT	3
#define FIDO_DATE	4
#define FIDO_FLAGS	5

int snd_mail(to, split)
char *to;				/* Adress to send to (news = NULL) */
int split;				/* Split message into several parts */
{
    char buffer[BUFSIZ];
    char groups[BUFSIZ];
    char *group[NGROUPS];
    Node node;
    char *p;
    char *fido_header[NFIDO];
    char *area=NULL;
    char *newsgroup=NULL;
    FILE *fpareas;
    int status;
    int i;

    node.domain[0] = 0;
    
    if(to)
	debug(3, "RFC To: %s", to);

    /*
     * Get to/from/node/subject/date
     */
    fido_header[FIDO_TO]      = mail_receiver(to, &node);
    if(!fido_header[FIDO_TO]) {
	if(address_error)
	    sendback("Address %s: %s", to, address_error);
	else
	    sendback("Address %s: illegal", to);
	return(EX_NOHOST);
    }

    fido_header[FIDO_FROM]    = mail_sender();
    if(!fido_header[FIDO_FROM])
	fido_header[FIDO_FROM] = "Gateway to FIDONET";

    fido_header[FIDO_NODE]    = node_to_asc(&node, FALSE);

    fido_header[FIDO_SUBJECT] = header_get("Subject");
    if(!fido_header[FIDO_SUBJECT])
	fido_header[FIDO_SUBJECT] = "Mail from Gateway to FIDONET";
    
    fido_header[FIDO_DATE]    = fido_date();
    
    fido_header[FIDO_FLAGS]   = header_get("X-Flags");
    if(!fido_header[FIDO_FLAGS])
	fido_header[FIDO_FLAGS] = "";

    if(newsmode) {
	/*
	 * News message: get newsgroups and convert to FIDO areas
	 */
	p = header_get("Newsgroups");
	if(!p) {
	    sendback("No Newsgroups header in news message");
	    return(EX_DATAERR);
	}
	strcpy(groups, p);
	debug(3, "RFC Newsgroups: %s", groups);

	for(i=0, p=strtok(groups, ",");
	    p && i<NGROUPS; p=strtok(NULL, ","),
	    i++)
	    group[i] = p;
	for(; i<NGROUPS; i++)
	    group[i] = NULL;

	fpareas = libfopen(AREAS, R_MODE);

	for(i=0; i<NGROUPS && group[i]; i++) {
	    p = group[i];
	    debug(5, "Look up newsgroup %s", p);
	    rewind(fpareas);
	    while(getcl(buffer, BUFSIZ, fpareas)) {
		area	  = estrtok(buffer, " \t");
		newsgroup = estrtok(NULL,   " \t");
		debug(9, "Checking newsgroup %s", newsgroup);
		if(!strcmp(newsgroup, p)) {	/* Found */
		    debug(5, "Found area %s", area);
		    break;
		}
		area = NULL;
	    }

	    if(!area) {
		debug(1, "No FIDO Area");
/*		log("No EchoMail area found for newsgroup '%s'", p); */
/*		area = "JUNK"; */
	    }

	    if(area) {
		debug(1, "FIDO Area:    %s", area);
		status = snd_message(node, fido_header,
				     newsgroup, area, NULL, split);
		if(status)
		    return status;
	    }
	}

	fclose(fpareas);
    }
    else {
	/*
	 * NetMail message
	 */
	p = header_get("From");
	log("%-13s <  [ %s -> %s ]", fido_header[FIDO_NODE],
	    p ? p : fido_header[FIDO_FROM], fido_header[FIDO_TO]);
	
	return snd_message(node, fido_header, NULL, NULL, to, split);
    }
    
    return EX_OK;
}


int snd_message(node, fido_header, newsgroup, area, to, split)
Node node;
char *fido_header[];
char *newsgroup;
char *area;
char *to;
int split;
{
    char buffer[BUFSIZ];
    FILE *sf;
    char *header;
    int part = 1, line = 1;
    long size;
    Textline *p;
    char *id;
    int flag;
    
    /*
     * Set pointer to first line in message body
     */
    p = body.first;
    
    /*
     * Output packet
     */
    sf = packet_file;

 again:

    /* Subject with splitted part indication */
    if(split)
	sprintf(buffer, "%c: %s", part + '@', fido_header[FIDO_SUBJECT]);
    else
	sprintf(buffer, "%s", fido_header[FIDO_SUBJECT]);

    /* Check sizes */
    if(strlen(fido_header[FIDO_FROM]) >= SIZE_FROM)
	fido_header[FIDO_FROM][SIZE_FROM - 1] = 0;
    if(strlen(fido_header[FIDO_TO]) >= SIZE_TO)
	fido_header[FIDO_TO][SIZE_TO - 1] = 0;
    if(strlen(buffer) >= SIZE_SUBJECT)
	buffer[SIZE_SUBJECT - 1] = 0;

    /* Header */
    write_msg_hdr(sf,
		  fido_header[FIDO_FROM], fido_header[FIDO_TO], buffer,
		  fido_header[FIDO_DATE], fido_header[FIDO_FLAGS], &node);

    debug(2, "FIDO Node:    %s", fido_header[FIDO_NODE]);
    debug(2, "FIDO To:      %s", fido_header[FIDO_TO]);
    debug(2, "FIDO From:    %s", fido_header[FIDO_FROM]);
    debug(2, "FIDO Subject: %s", buffer);
    debug(2, "FIDO Date:    %s", fido_header[FIDO_DATE]);
    debug(2, "FIDO Flags:   %s", fido_header[FIDO_FLAGS]);

    if(newsmode) {
	/*
	 * Add AREA:... line for echo mail
	 */
	fprintf(sf, "AREA:%s\r\n", area);
    }
    else {
	/*
	 * Add IFNA kludges for zone/point addressing
	 */
	if(private && (node.zone != Config.myaddr.zone))
	{
	    Node tmpm, tmpn;
	    
	    tmpm = Config.myaddr;
	    tmpm.point = 0; tmpm.domain[0] = 0;
	    tmpn = node;
	    tmpn.point = 0; tmpn.domain[0] = 0;
	    fprintf(sf, "\001INTL %s %s\r\n",
		    node_to_asc(&tmpn, FALSE), node_to_asc(&tmpm, FALSE));
	}
	if(private && Config.myaddr.point)
	    fprintf(sf, "\001FMPT %d\r\n", Config.myaddr.point);
	if(node.point)
	    fprintf(sf, "\001TOPT %d\r\n", node.point);
    }
    
    /*
     * Add kludges for MSGID / REPLY and ORIGID / ORIGREF
     */
    if((header = header_get("Message-ID")))
    {
	if((id = msgid_rfc_to_fido(&flag, header, part, split)))
	{
	    fprintf(sf, "\001MSGID: %s\r\n", id);
	    if(flag && (id = msgid_rfc_to_origid(header, part, split)))
		fprintf(sf, "\001ORIGID: %s\r\n", id);
	}
	else
	    print_local_msgid(sf);
    }	
    else
	print_local_msgid(sf);

    if((header = header_get("References")) ||
       (header = header_get("In-Reply-To")))
    {
	if((id = msgid_rfc_to_fido(&flag, header, 0, 0)))
	{
	    fprintf(sf, "\001REPLY: %s\r\n", id);
	    if(flag && (id = msgid_rfc_to_origid(header, 0, 0)))
		fprintf(sf, "\001ORIGREF: %s\r\n", id);
	}
    }	


#ifdef FIDO_GATE
    /*
     * Add To line for addressing FIDO<->Internet gateway
     */
    if(to && !isfido())
	fprintf(sf, "To: %s\r\n\r\n", to);

#else /**!FIDO_GATE**/

    if(!strchr(fido_header[FIDO_FLAGS], 'N'))
    {
	/*
	 * Add some header lines
	 */
	if((header = header_get("From")))
	    fprintf(sf, "From: %s\r\n", header);
	if((header = header_get("Reply-To")))
	    fprintf(sf, "Reply-To: %s\r\n", header);
	if((header = header_get("To"))) {
	    fprintf(sf, " * To: %s\r\n", header);
	    while((header = header_getnext()))
		fprintf(sf, "%s\r\n", header);
	}
	if((header = header_get("Cc"))) {
	    fprintf(sf, " * Cc: %s\r\n", header);
	    while((header = header_getnext()))
		fprintf(sf, "%s\r\n", header);
	}
	if((header = header_get("Newsgroups")))
	    if(strchr(header, ','))	    /* Posted to multiple groups */
		fprintf(sf, " * Newsgroups: %s\r\n", header);
	fprintf(sf, "\r\n");
    }
	
#endif /**FIDO_GATE**/

    /*
     * Add line indicating splitted message
     */
    if(split)
	fprintf(sf,
		" * Large message splitted by rfmail: part %02d/%02d\r\n\r\n",
		part, split						    );

    /*
     * Copy message body
     */
    size = 0;
    debug(5, "Copying message body");
    while(p)
    {
#if 0 /**DISABLED**/
	/*
	 * BEWARE! This is a kludge!
	 * The stripping of signatures should be configurable in the
	 * `areas' file. Currently it is applied for all fido.ger.* groups.
	 * Also the max length of a signature is somewhat arbitrary.
	 *
	 * ----- CHANGE ME !!! -----
	 */
	if(newsgroup && !strncmp(newsgroup, "fido.ger.", 9)
	   /* Only for fido.ger.* groups */
	   && ( !strcmp(p->line, "--\n") || !strcmp(p->line, "-- \n") )
	   /* Signature marks */
	   && (body.n - line) < 15
	   /* Assumed max length of a signature, avoid deleting real text */)
	{
	    debug(4, "Deleting signature");
/*	    put_line(sf, "-- SIGNATURE DELETED --\n"); */
	    break;
	}
#endif
	
	put_line(sf, p->line);
	size += strlen(p->line) + 1;
	if(size > MAXMSGSIZE) {
	    print_tear_line(sf);
	    if(newsmode)
		print_origin(sf);
	    /* End of message */
	    putc(0, sf);
	    part++;
	    p = p->next;
	    goto again;
	}
	p = p->next;
	line++;
    }

    /*
     * If message is for echo mail (-n flag) then add
     * tear, origin, seen-by and path line.
     */
    print_tear_line(sf);
    if(newsmode)
	print_origin(sf);
    else
	print_via(sf);

    /*
     * Done
     */
    /* End of message */
    putc(0, sf);
    return EX_OK;
}



/*
 * Output tear line
 */
int print_tear_line(fp)
FILE *fp;
{
    fprintf(fp, "\r\n--- FIDOGATE %s\r\n", version_global());

    return ferror(fp);
}



/*
 * Generate origin, seen-by and path line
 */
int print_origin(fp)
FILE *fp;
{
    /* Origin */
    fprintf(fp, " * Origin: %s (%s)\r\n",
	    ORIGIN, node_to_asc(&Config.myaddr, TRUE) );

    if(Config.myfakeaddr.point)		/* Generate 4D addresses */
    {
	/* SEEN-BY */
	fprintf(fp, "SEEN-BY: %d/%d",
		Config.myfakeaddr.net, Config.myfakeaddr.node);
	if(Config.myfakeaddr.point != 0)
	    fprintf(fp, ".%d", Config.myfakeaddr.point);
	/* PATH */
	fprintf(fp, "\r\n\001PATH: %d/%d",
		Config.myfakeaddr.net, Config.myfakeaddr.node);
	if(Config.myfakeaddr.point != 0)
	    fprintf(fp, ".%d", Config.myfakeaddr.point);
	fputs("\r\n", fp);
    }
    else				/* Generate 3D addresses */
    {
	/* SEEN-BY */
	fprintf(fp, "SEEN-BY: %d/%d ",
		Config.myfakeaddr.net, Config.myfakeaddr.node );
	if(Config.remoteaddr.net != Config.myfakeaddr.net)
	    fprintf(fp, "%d/", Config.remoteaddr.net);
	fprintf(fp,"%d\r\n", Config.remoteaddr.node);
	/* PATH */
	fprintf(fp, "\001PATH: %d/%d\r\n",
		Config.myfakeaddr.net, Config.myfakeaddr.node);
    }
    
    return ferror(fp);
}



/*
 * Generate local `^AMSGID:' if none is found in message header
 */
int print_local_msgid(fp)
FILE *fp;
{
    long msgid;

    msgid = sequencer(SEQ_MSGID);
    fprintf(fp, "\001MSGID: %s %08ld\r\n",
	    node_to_asc(&Config.myaddr, FALSE), msgid);

    return ferror(fp);
}



/*
 * Generate "^AVia" line for NetMail
 */
int print_via(fp)
FILE *fp;
{
    fprintf(fp, "\001Via FIDOGATE %s, %s\r\n",
	    node_to_asc(&Config.myaddr, TRUE),
	    date("%a, %d %h %y %T %o", NULL)  );

    return ferror(fp);
}



/*
 * Get name for new packet
 */
char *new_packet_name()
{
    if(f_flag)
    {
	strncpy0(packet_name, f_arg, sizeof(packet_name));
	strncpy0(packet_tmp , f_arg, sizeof(packet_tmp ));
    }
    else
    {
	long n;
	
	n = sequencer(SEQ_PKT);
	sprintf(packet_name, "%s/%08ld.pkt", packet_dir, n);
	sprintf(packet_tmp , "%s/%08ld.tmp", packet_dir, n);
    }

#ifdef BINKLEY_FLO
    sprintf(flo_name, "%s/%04x%04x%s", packet_dir, Config.remoteaddr.net,
	    Config.remoteaddr.node, BINKLEY_FLO);
#endif

    return packet_name;
}



/*
 * Usage messages
 */
void short_usage()
{
    fprintf(stderr, "usage: %s [-options] [user ...]\n", PROGRAM);
    fprintf(stderr, "       %s --help  for more information\n", PROGRAM);
}


void usage()
{
    fprintf(stderr, "FIDOGATE %s  %s %s\n\n",
	    version_global(), PROGRAM, version_local(VERSION) );
    
    fprintf(stderr, "usage:   %s [-options] [user ...]\n\n", PROGRAM);
    fprintf(stderr, "\
options: -a --append                  append to packet\n\
         -b --news-batch              process news batch\n\
	 -o --out-packet-file name    set outbound packet file name\n\
	 -n --news-mode               set news mode\n\
	 -O --out-packet-dir name     set outbound packet directory\n\
	 -S --spool-dir name          set FIDOGATE spool directory\n\
	 -L --lib-dir name            set FIDOGATE lib directory\n\
	 -v --verbose                 more verbose\n\
	 -h --help                    this help\n\
	 -m --my-addr Z:N/F.P         set FIDO address\n\
	 -M --my-fake-addr Z:N/F.P    set FIDO fakenet address\n\
	 -r --remote-addr Z:N/F.P     set FIDO remote address\n"  );
}



/***** main ******************************************************************/
int main(argc, argv)
int argc;
char *argv[];
{
    int cnt, c;
    char buffer[BUFSIZ];
    int status = EX_OK;
    long size, nmsg;
    int split;

    int option_index;
    static struct option long_options[] =
    {
	{ "append",       0, 0, 'a'},	/* Append to packet */
	{ "news-batch",   0, 0, 'b'},	/* Process news batch */
	{ "out-packet-file",1,0,'o'},	/* Set packet file name */
	{ "news-mode",    0, 0, 'n'},	/* Set news mode */
	{ "out-packet-dir",1,0, 'O'},	/* Set packet directory */

	{ "spool-dir",    1, 0, 'S'},	/* Set FIDOGATE spool directory */
	{ "lib-dir",      1, 0, 'L'},	/* Set FIDOGATE lib directory */
	{ "verbose",      0, 0, 'v'},	/* More verbose */
	{ "help",         0, 0, 'h'},	/* Help */
	{ "my-addr",      1, 0, 'm'},	/* Set FIDO address */
	{ "my-fake-addr", 1, 0, 'M'},	/* Set FIDO fakenet address */
	{ "remote-addr",  1, 0, 'r'},	/* Set FIDO remote address */
	{ 0,              0, 0, 0  }
    };

    /* Init configuration */
    config_init();
    
    newsmode = FALSE;

    /* Default packet dir */
    strcpy(packet_dir, SPOOLDIR);
    strcat(packet_dir, "/");
    strcat(packet_dir, OUTBOUND);
    

    while ((c = getopt_long(argc, argv, "abo:nO:L:vhm:M:r:",
			    long_options, &option_index     )) != EOF)
	switch (c) {
	case 'a':
	    /* Set append flag */
	    a_flag = TRUE;
	    break;
	case 'b':
	    /* News batch flag */
	    b_flag   = TRUE;
	    newsmode = TRUE;
	    private  = FALSE;
	    break;
	case 'o':
	    /* Set packet file name */
	    f_flag = TRUE;
	    f_arg  = optarg;
	    break;
	case 'n':
	    /* Set news-mode */
	    newsmode = TRUE;
	    private  = FALSE;
	    break;
	case 'O':
	    /* Set packet dir */
	    strncpy0(packet_dir, optarg, sizeof(packet_dir));
	    break;
	case 'L':
	    /* Set lib dir */
	    set_libdir(optarg);
	    break;
	case 'v':
	    /* set more verbosity */
	    verbose++;
	    break;
	case 'm':
	    config_myaddr(optarg);
	    break;
	case 'M':
	    config_myfakeaddr(optarg);
	    break;
	case 'r':
	    config_remoteaddr(optarg);
	    break;
	case 'h':
	    usage();
	    exit(0);
	    break;
	default:
	    short_usage();
	    exit(EX_USAGE);
	    break;
	}

    /*
     * Open file for output packet and write packet header
     */
    new_packet_name();
    if((packet_file = fopen(packet_tmp, W_MODE)) == NULL)
    {
	fprintf(stderr, "%s: can't create packet %s: ", PROGRAM, packet_tmp);
	perror("");
	log("$%s: can't create packet %s: ", PROGRAM, packet_tmp);
	exit(EX_CANTCREAT);
    }
    /*
     * Change mode to PACKET_MODE
     */
    chmod(packet_tmp, PACKET_MODE);

    write_pkt_hdr(packet_file);

    /**
     ** Main loop: read message(s) from stdin, batches if -b
     **/
    nmsg = 0;
    while(TRUE)
    {
	if(b_flag)
	{
	    size = read_rnews_size(stdin);
	    if(size == -1)
		log("%s: error reading news batch", PROGRAM);
	    if(size <= 0)
		break;
	    nmsg++;

	    debug(1, "Batch: message #%ld size %ld", nmsg, size);
	}
	
	/*
	 * Read message header from stdin
	 */
	header_delete();
	header_read(stdin);
    
	/*
	 * Read message body from stdin and count size
	 */
	size = 0;
	Textlist_clear(&body);
	while(read_line(buffer, BUFSIZ, stdin)) {
	    Textlist_append(&body, buffer);
	    size += strlen(buffer) + 1;	    /* `+1' for additional CR */
	}
	split = size>MAXMSGSIZE ? size/MAXMSGSIZE + 1 : 0;
	debug(1, "Message body size %ld", size);
	if(split)
	    debug(1, "Must split message, %d parts", split);

	if(newsmode)
	    /*
	     * Send mail to echo feed for news messages
	     */
	    status = snd_mail(NULL, split);
	else
	    /*
	     * Send mail to addresses from command line args
	     */
	    for(cnt = optind; cnt < argc; cnt++)
		if((status = snd_mail(argv[cnt], split)) != EX_OK)
		    break;

	if(!b_flag)
	    break;
    }
    
    /* End of packet */
    write_int(0, packet_file);
    fclose(packet_file);

    /* Rename .tmp -> .pkt */
    if(!f_flag)
	if(rename(packet_tmp, packet_name) == ERROR)
	    log("$Can't rename %s to %s", packet_tmp, packet_name);
#ifdef BINKLEY_FLO
	else
	{
	    flo_file = fopen(flo_name, A_MODE);
	    chmod(flo_name, PACKET_MODE);
	    fprintf(flo_file, "^%s\n", packet_name);
	    fclose(flo_file);
	}
#endif
    
    exit(status);
}
