/*:ts=8*/
/*****************************************************************************
 * FIDOGATE --- Gateway UNIX Mail/News <-> FIDO NetMail/EchoMail
 *
 * $Id: misc.c,v 3.1 1993/09/14 07:40:04 mj beta mj $
 *
 * Miscellaneous functions
 *
 *****************************************************************************
 * Copyright (C) 1990, 1993
 *  _____ _____
 * |	 |___  |   Martin Junius	     FIDO:	2:242/6.1
 * | | | |   | |   Republikplatz 3	     Internet:	mj@sungate.fido.de
 * |_|_|_|@home|   D-52072 Aachen, Germany   Phone:	++49-241-86931 (voice)
 *
 * This file is part of FIDOGATE.
 *
 * FIDOGATE is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * FIDOGATE is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with FIDOGATE; see the file COPYING.  If not, write to the Free
 * Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************/

#include "fidogate.h"

#ifdef LOCK_LOCKF
# include <unistd.h>
#else
# include <sys/file.h>
#endif



#if !defined(__linux__)
#define labs(n) (((n) < 0l) ? (-(n)) : (n))
#endif

extern void exit(), perror();
extern time_t time();



/*
 * Lib directory for FIDOGATE software
 */
static char lib_dir[BUFSIZ] = LIBDIR;

void set_libdir(char *dir)
{
    strncpy0(lib_dir, dir, sizeof(lib_dir));
}



/*
 * Strip bad chars from FIDO names, i.e. chars not allowed in
 * RFC822 `atoms'. One execption is ' ' (space), which is converted
 * to '_' later on.
 */

void stripbad(name)
char *name;
{
char *d;

    for(d=name; *d; d++)
	if( !iscntrl(*d) && !strchr("()<>@,;:\\\"[]", *d) )
	    *name++ = *d;
    *name = 0;
}



/*
 * strncpy0() --- strncpy() with terminating '\0' char
 */

char *strncpy0(d, s, n)
char *d, *s;
int n;
{
    strncpy(d, s, n);
    d[n-1] = 0;
    return d;
}


    
/***** strnicmp() --- compare n chars of strings ignoring case ***************/

int strnicmp(sa, sb, len)
register char *sa, *sb;
int len;
{
    while(len--)
	if(tolower(*sa) == tolower(*sb)) {
	    sa++;
	    sb++;
	}
	else if(tolower(*sa) < tolower(*sb))
	    return(-1);
	else
	    return(1);
    return(0);
}



/***** stricmp() --- compare strings ignoring case ***************************/

int stricmp(sa, sb)
register char *sa, *sb;
{
    while(tolower(*sa) == tolower(*sb)) {
	if(!*sa)
	    return(0);
	sa++;
	sb++;
    }
    return(tolower(*sa) - tolower(*sb));
}



/***** xtol() --- convert hex string to long *********************************/

long xtol(s)
char *s;
{
long val = 0;
int n;

    while(*s) {
	n = toupper(*s) - (isalpha(*s) ? 'A'-10 : '0');
	val = val*16 + n;
	s++;
    }
    return(val);
}



FILE *logfp = NULL;

/* Lock file descriptor up to the end. If yur system doesn't have lockf()
   (also known as locking()), or other region or file locking function
   or system call, this should be done with lock-files. */

int
lock(fd)
     int fd;
{
#ifdef LOCK_LOCKF
  return lockf(fd, F_LOCK, 0l);
#else
  return flock(fd, LOCK_EX);
#endif
}

/* Unlock file descriptor up to the end. Routine which calls this should
   first seek to original position. */

int
unlock(fd)
     int fd;
{
#ifdef LOCK_LOCKF
  return lockf(fd, F_ULOCK, 0l);
#else
  return flock(fd, LOCK_UN);
#endif
}

/* Return ascii-date in specified format. If format string is null, return
   date as date(1) returns it. Format is same than date(1) has, in addition
   %z, which means timezone name. Clock is the time to convert, if NULL,
   we'll use current time. */

char *date(fmt, clock)
char *fmt;
time_t *clock;
{
/* names for weekdays */
static char *weekdays[] = {
    "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat",
};

/* names for months */
static char *months[] = {
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
};

static char buffer[80];
char *bp = buffer;
time_t _clock;
struct tm *tm;
#ifdef BSD
long timezone;
#endif

  if (!clock)
    _clock = time((long *) 0);
  tm = localtime(clock ? clock : &_clock);

#ifdef BSD
    timezone = - tm->tm_gmtoff;
#endif

  /* if no format string, this is default */
  if (!fmt)
    fmt = "%a %h %d %T %z 19%y";

  for (*bp = 0; *fmt; fmt++)
    switch (*fmt)
      {
      case '%':
	switch (*++fmt)
	  {
	    /* newline */
	  case 'n':
	    *bp++ = '\n';
	    break;
	    /* tabulator */
	  case 't':
	    *bp++ = '\t';
	    break;
	    /* month number 1-12 */
	  case 'm':
	    (void) sprintf(bp, "%02d", tm->tm_mon + 1);
	    while (*bp)
	      bp++;
	    break;
	    /* day of month 1-31 */
	  case 'd':
	    (void) sprintf(bp, "%02d", tm->tm_mday);
	    while (*bp)
	      bp++;
	    break;
	  case 'q':
	    (void) sprintf(bp, "%02d", tm->tm_mday);
	    while (*bp)
	      bp++;
	    break;
	    /* year 00-99 */
	  case 'y':
	    (void) sprintf(bp, "%02d", tm->tm_year);
	    while (*bp)
	      bp++;
	    break;
	    /* date in format YY/MM/DD */
	  case 'D':
	    (void) sprintf(bp, "%02d/%02d/%02d", tm->tm_year,
			   tm->tm_mon + 1, tm->tm_mday);
	    while (*bp)
	      bp++;
	    break;
	    /* hour 0-23 */
	  case 'H':
	    (void) sprintf(bp, "%02d", tm->tm_hour);
	    while (*bp)
	      bp++;
	    break;
	    /* minutes 0-59 */
	  case 'M':
	    (void) sprintf(bp, "%02d", tm->tm_min);
	    while (*bp)
	      bp++;
	    break;
	    /* seconds 0-59 */
	  case 'S':
	    (void) sprintf(bp, "%02d", tm->tm_sec);
	    while (*bp)
	      bp++;
	    break;
	    /* time in format HH:MM:SS */
	  case 'T':
	    (void) sprintf(bp, "%02d:%02d:%02d", tm->tm_hour, tm->tm_min,
			   tm->tm_sec);
	    while (*bp)
	      bp++;
	    break;
	    /* day of year 1-356 */
	  case 'j':
	    (void) sprintf(bp, "%03d", tm->tm_yday + 1);
	    while (*bp)
	      bp++;
	    break;
	    /* weekday 0-6 */
	  case 'w':
	    (void) sprintf(bp, "%d", tm->tm_wday);
	    while (*bp)
	      bp++;
	    break;
	    /* name of weekday 'Mon', 'Tue', ... , 'Sun' */
	  case 'a':
	    (void) strcpy(bp, weekdays[tm->tm_wday]);
	    while (*bp)
	      bp++;
	    break;
	    /* name of month 'Jan', 'Feb', ... , 'Dec' */
	  case 'h':
	    (void) strcpy(bp, months[tm->tm_mon]);
	    while (*bp)
	      bp++;
	    break;
	    /* name of timezone, e.g. EST */
	  case 'z':
#ifdef BSD
	    strcpy(bp, tm->tm_zone);
#endif
#ifdef USG
	    strcpy(bp, *tzname);
#endif
	    while (*bp)
	      bp++;
	    break;
	    /* numeric time zone, e.g. +0200 */
	  case 'o':
	    (void) sprintf(bp, "%c%02ld%02ld", (timezone <= 0l) ? '+' : '-',
			   (labs(timezone) / (60l * 60l)),
			   (labs(timezone) % (60l * 60l)));
	    while (*bp)
	      bp++;
	    break;
	  case 'l':
	    /* military time zone, Z = UT, A = -1, M = -12, (J not used),
	       N = +1, Y = +12.. */
	    *bp = (timezone == 0l) ? 'Z' : ((int) (labs(timezone) /
						   (60l * 60l)) +
					    ((timezone < 0l) ? 'M' : '@'));
	    if (timezone > 0l && *bp >= 'J')
	      (*bp)++;
	    *++bp = 0;
	    break;
	  default:
	    *bp++ = *fmt;
	    break;
	  }
	break;
      default:
	*bp++ = *fmt;
	break;
      }

  *bp = 0;
  return buffer;
}



/*
 * strerror()  ---  get string from sys_errlist[]
 */

char *
strerror(errnum)
int errnum;
{
extern int sys_nerr;
extern char *sys_errlist[];

    if (errnum > 0 && errnum < sys_nerr)
	return sys_errlist[errnum];
    return "";
}



/*
 * Log to logfile. If logfile is not open, open it.
 *
 * If first character in format string is '$', print also errno. If external
 * variable verbose is set, logging will be done also to stderr.
 */

#ifdef __STDC__
void log(const char *fmt, ...)
{
    va_list args;
    char buffer[128];

    va_start(args, fmt);
#else /**!__STDC__**/
void log(va_alist)
va_dcl
{
    va_list args;
    char *fmt;

    va_start(args);
    fmt = va_arg(args, char *);
#endif /**__STDC__*/

    if(!logfp) {
	strcpy(buffer, lib_dir);
	strcat(buffer, "/"   );
	strcat(buffer, LOG   );
	logfp = fopen(buffer, A_MODE);
	if(!logfp)
	    goto out_stderr;
    }

    fprintf(logfp, "%s: ", date("%d %h %y %H:%M", (long *) 0));
    vfprintf(logfp, *fmt == '$' ? fmt + 1 : fmt, args);
    if (*fmt == '$')
	fprintf(logfp, "\n\t\terrno = %d (%s)\n", errno, strerror(errno));
    else
	fprintf(logfp, "\n");
    fflush(logfp);

    /*
     * if verbose is set, print also to stderr (without date)
     */
    if (verbose) {
out_stderr:
	vfprintf(stderr, *fmt == '$' ? fmt + 1 : fmt, args);
	if (*fmt == '$')
	    fprintf(stderr, "\n\t\terrno = %d (%s)\n", errno, strerror(errno));
	else
	    fprintf(stderr, "\n");
	fflush(stderr);
    }
}



/*
 * Debug output. First argument should be number, rest are used arguments
 * for vfprintf(3S). If external variable verbose has equal or greater
 * value than first number, vfprintf(3S) will be used to print other
 * arguments to stderr.
 */

#ifdef __STDC__
void debug(int debug_level, const char *fmt, ...)
{
    va_list args;

    va_start(args, fmt);
#else /**!__STDC__**/
void debug(va_alist)
va_dcl
{
    va_list args;
    char *fmt;
    int debug_level;

    va_start(args);
    debug_level = va_arg(args, int);
    fmt         = va_arg(args, char *);
#endif /**__STDC__*/

    if (debug_level <= verbose) {
	vfprintf(stderr, fmt, args);
	fprintf(stderr, "\n");
    }
}



/*
 * Sequencer: read number from file and increment it
 */
long sequencer(filename)
char *filename;
{
char buffer[128];
FILE *fp;
long seqn;

    strcpy(buffer, lib_dir);
    strcat(buffer, "/");
    strcat(buffer, filename);

    /*
     * Open file, create if necessary
     */
    if((fp = fopen(buffer, RP_MODE)) == NULL)
	if(errno == ENOENT) {
	    /* Create */
	    if((fp = fopen(buffer, WP_MODE)) == NULL) {
		log("$Can't create seq file %s", buffer);
		exit(EX_OSFILE);
	    }
	    fprintf(fp, "0\n");
	    fclose(fp);
	    /* Reopen */
	    if((fp = fopen(buffer, RP_MODE)) == NULL) {
		log("$Can't open seq file %s", buffer);
		exit(EX_OSFILE);
	    }
	}
	else {
	    log("$Can't open seq file %s", buffer);
	    exit(EX_OSFILE);
	}

    /*
     * Lock file, get number and increment it
     */
    lock(fileno(fp));
    if(fgets(buffer, sizeof(buffer), fp))
	seqn = atol(buffer);
    else
	seqn = 0;
    seqn++;
    rewind(fp);
    fprintf(fp, "%ld\n", seqn);
    rewind(fp);
    unlock(fileno(fp));
    fclose(fp);

    return seqn;
}		



/*
 * libfopen() --- open file in LIBDIR, check for error
 */

FILE *libfopen(name, mode)
char *name, *mode;
{
char filename[256];
FILE *fp;

    strcpy(filename, lib_dir);
    strcat(filename, "/");
    strcat(filename, name);

    if((fp = fopen(filename, mode)) == NULL) {
	log("$Can't open file '%s'", filename);
	exit(EX_OSFILE);
    }
    return(fp);
}



/*
 * spoolfopen() --- open file in SPOOLDIR, check for error
 */

FILE *spoolfopen(name, mode)
char *name, *mode;
{
char filename[256];
FILE *fp;

    strcpy(filename, SPOOLDIR);
    strcat(filename, "/");
    strcat(filename, name);

    if((fp = fopen(filename, mode)) == NULL) {
	log("$Can't open file '%s'", filename);
	exit(EX_OSFILE);
    }
    return(fp);
}



/*
 * Read line from some config file. Strip comments starting with a '#'
 * and empty lines.
 */

char *getcl(buffer, len, fp)
char *buffer;
int len;
FILE *fp;
{
char *cp;

    while (fgets(buffer, len, fp)) {
	buffer[strlen(buffer) - 1] = 0;
	/* everything after #-sign is comment */
	if ((cp = strchr(buffer, '#')))
	    *cp = 0;
	/* if there's something left, return it */
	if (*buffer)
	    return buffer;
    }
    return (char *) NULL;
}
