/*:ts=8*/
/*****************************************************************************
 * FIDOGATE --- Gateway software UNIX <-> FIDO
 *
 * $Id: address.c,v 3.1 1993/09/14 07:38:47 mj beta mj $
 *
 * Parsing and conversion for FIDO and RFC addresses
 *
 *****************************************************************************
 * Copyright (C) 1990, 1993
 *  _____ _____
 * |	 |___  |   Martin Junius	     FIDO:	2:242/6.1
 * | | | |   | |   Republikplatz 3	     Internet:	mj@sungate.fido.de
 * |_|_|_|@home|   D-52072 Aachen, Germany   Phone:	++49-241-86931 (voice)
 *
 * This file is part of FIDOGATE.
 *
 * FIDOGATE is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * FIDOGATE is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with FIDOGATE; see the file COPYING.  If not, write to the Free
 * Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************/

#include "fidogate.h"
#include "shuffle.h"


char *address_error = NULL;		    /* Error msg from address func. */



/*
 * Array of supported zones and associated domain names
 */
#define MAXDOMAINS    10
#define MAXDOMAINNAME 64

static struct st_domain
{
    int zone;				/* Zone number */
    char domain[MAXDOMAINNAME];
}
domains[MAXDOMAINS];

static int domain_init_flag = FALSE;



/***** init_domain() --- read domain table from config file ******************/
void init_domain()
{
    FILE *fp;
    static char buffer[BUFSIZ];
    char *bp, *p;
    int i, zone;
    char *domain;
    
    /*
     * Init zone<->domain table from file `domains'
     */
    domain_init_flag = TRUE;
    
    fp = libfopen(DOMAINS, R_MODE);
    i  = 1;
    
    while(getcl(buffer, BUFSIZ, fp)) {
	for(bp=buffer; *bp && isspace(*bp); bp++);	/* Skip white space */
	    if(!*bp)
		continue;
	/*
	 * FTN zone
	 */
	p = strtok(bp, " \t");
	if(!p || !*p)
	    continue;
	/*
	 * Domain name
	 */
	domain = strtok(NULL, " \t");
	if(!domain || !*domain)
	    continue;
	
	if(!stricmp(p, "default"))
	{
	    domains[0].zone = 0;
	    strncpy0(domains[0].domain, domain, MAXDOMAINNAME);
	}
	else if(i < MAXDOMAINS)
	{
	    if(!(zone = atoi(p)))
		continue;
	    domains[i].zone = zone;
	    strncpy0(domains[i].domain, domain, MAXDOMAINNAME);
	    i++;
	}
    }
    
    fclose(fp);
}



/***** get_domain() --- return Internet domain for FTN zone ******************/

char *get_domain(zone)
int zone;
{
    int i;
    
    if(!domain_init_flag)
	init_domain();

    /*
     * Search zone
     */
    for(i=1; i<MAXDOMAINS && domains[i].zone; i++)
	if(domains[i].zone == zone)
	    return domains[i].domain;

    return domains[0].domain;    
}



/***** check_domain() --- check zone *****************************************/

int check_domain(zone)
int zone;
{
    int i;
    
    if(!domain_init_flag)
	init_domain();

    /*
     * Search zone
     */
    for(i=1; i<MAXDOMAINS && domains[i].zone; i++)
	if(domains[i].zone == zone)
	    return TRUE;

    return FALSE;    
}
    


/*
 * int parse_address()	---  parse fidonet address to name, net/node
 *
 * Parameters:	char *address	--- address string
 *		char *name	--- pointer to return name
 *		Node *node	--- pointer to return node address
 *
 * Return:	0 = o.k., -1 = error
 *
 * Two types of addresses are understood:
 *  Domain:	name@p.f.n.z[.FIDODOMAIN]
 *		name%p.f.n.z[.FIDODOMAIN]
 *  Bang:	p.f.n.z[.FIDODOMAIN]!name
 */

static int is_fido_flag;

int parse_address(address, name, node)
char *address, *name;
Node *node;
{
    char *cp;
    int cnt;
    char *p;
    int len, dlen, diff;
    int ret;

    is_fido_flag = FALSE;
    
    /* make address to lowercase */
    for (cp = address; *cp; cp++)
	if (isupper(*cp))
	    *cp = tolower(*cp);

    /* Get name. We assume that name has space at least 36 charcers (maximum
       length of name in fido). First check whether format is name@domain
       of domain!name format. */
    if((cp = strchr(address, '!'))) {
	debug(2, "Fidonet address domain!name");
	for (cp++, cnt = 0; *cp && cnt<MAX_NAME; cnt++, cp++)
	    name[cnt] = *cp;
	name[cnt] = 0;
	cp = address;
	debug(3, "Name %s", name);
    }
    else {
	p = strrchr(address, '@');
	if(!p)
	    p = strrchr(address, '%');
	if(!p)
	    return ERROR;
	    
	debug(2, "Fidonet address name[@%%]domain");
	for (cp = address, cnt = 0; *cp && cnt<MAX_NAME && cp!=p; cp++, cnt++)
	    name[cnt] = *cp;
	name[cnt] = 0;
	debug(3, "Name %s", name);

	cp = p + 1;
    }

    debug(2, "Address %s", cp);

#ifdef MAUS_DE
    /*
     * Special handling for addresses `*.maus.de'. These adresses are
     * converted to the form suitable for the FIDO<->MAUS gateway.
     */
    len	 = strlen(cp);
    dlen = strlen(MAUS_DOMAIN);
    diff = len - dlen;
    if(len>dlen && !strcmp(cp+diff, MAUS_DOMAIN)) {	/* Got it */
	debug(2, "MAUS address %s", cp);

	len  = strlen(name);
	dlen = len + strlen(MAUS_STRING) + diff;
	if(dlen > MAX_NAME) {
	    len -= dlen - MAX_NAME;
	    name[len] = 0;
	}
	strcat(name, MAUS_STRING);
	len = strlen(name);
	for(; len<MAX_NAME && *cp!='.'; len++, cp++)
	    name[len] = toupper(*cp);
	name[len] = 0;
	debug(2, "Name converted to %s", name);

	node->zone  = MAUS_ZONE;
	node->net   = MAUS_NET;
	node->node  = MAUS_NODE;
	node->point = MAUS_POINT;

	is_fido_flag = TRUE;
	return OK;
    }
#endif /**MAUS_DE**/

    ret = parseinternode(cp, node);
    if(ret == OK)
	is_fido_flag = TRUE;
    
#ifdef FIDO_GATE
    /*
     * Insert address of FIDO<->Internet gateway for non-FIDO addresses
     */
    if(ret == ERROR)
    {
	node->zone  = FIDO_GATE_ZONE;
	node->net   = FIDO_GATE_NET;
	node->node  = FIDO_GATE_NODE;
	node->point = FIDO_GATE_POINT;
	strcpy(name,  FIDO_GATE_NAME);
	
	ret = OK;
    }
#endif /**FIDO_GATE**/

    return ret;
}



/***** isfido() --- Check for FIDO Internet address **************************/

int isfido()
{
    return is_fido_flag;
}



/***** pfnz_to_node() --- Convert p.f.n.z domain address to Node struct ******/

int pfnz_to_node(pfnz, node, point_flag)
char *pfnz;
Node *node;
int point_flag;
{
    char *p, *q, *s;
    
    node->zone = node->net = node->node = node->point = -1;
    address_error = NULL;
    
    s = strsave(pfnz);

    debug(5, "pfnz_to_node(): %s", s);
    
    for(p=strtok(s, "."); p; p = strtok(NULL, "."))
	switch(*p) {
	case 'p':
	case 'P':
	    for(q=p+1; *q; q++)
		if(!isdigit(*q)) {
		    free(s);
		    return -1;
		}
	    node->point = atoi(p+1);
	    break;
	case 'f':
	case 'F':
	    for(q=p+1; *q; q++)
		if(!isdigit(*q)) {
		    free(s);
		    return -1;
		}
	    node->node	= atoi(p+1);
	    break;
	case 'n':
	case 'N':
	    for(q=p+1; *q; q++)
		if(!isdigit(*q)) {
		    free(s);
		    return -1;
		}
	    node->net	= atoi(p+1);
	    break;
	case 'z':
	case 'Z':
	    for(q=p+1; *q; q++)
		if(!isdigit(*q)) {
		    free(s);
		    return -1;
		}
	    node->zone	= atoi(p+1);
	    break;
	default:
	    free(s);
	    return -1;
	    break;
	}

    free(s);

    /*
     * Check address
     */
    if(node->zone == -1)
	node->zone = Config.myaddr.zone;
    if(node->net == -1)
    {
	address_error = "Missing net in FIDO address";
	return -1;
    }
    if(node->node == -1)
    {
	address_error = "Missing node in FIDO address";
	return -1;
    }
    if(node->point == -1 && !point_flag)
	node->point = 0;

    debug(5, "pfnz_to_node(): %d:%d/%d.%d", node->zone, node->net,
	  node->node, node->point );
    
    return OK;
}



/***** asc_to_node() --- Convert Z:N/F.P address to Node struct **************/

static int get_number	P((char **));

static int get_number(ps)
char **ps;
{
    char *s = *ps;
    int val = 0;

    if(!isdigit(*s))
	return -1;

    while(isdigit(*s))
	val = val*10 + *s++ - '0';

    *ps = s;
    
    return val;
}


int asc_to_node(asc, node, point_flag)
char *asc;
Node *node;
int point_flag;
{
    Node n;
    char *s = asc;
    int val, i;
    
    n.zone  = -1;
    n.net   = -1;
    n.node  = -1;
    n.point = -1;
    n.domain[0] = 0;
#ifdef FIDO_DE
    n.fido_de = 0;
    n.point_flag = 0;
#endif

    if( (val = get_number(&s)) == -1)
	return -1;

    if(*s == ':')			/* Number is zone address part */
    {
	s++;
	n.zone = val;			/* Zone address */
	if( (val = get_number(&s)) == -1 )
	    return -1;
    }

    if(*s != '/')			/* Number must be net part */
	return -1;
    s++;
    n.net = val;			/* Net address */
    if( (val = get_number(&s)) == -1 )
	return -1;
    n.node = val;			/* Node address */

    if(*s == '.')			/* Point addresse follows */
    {
	s++;
	if( (val = get_number(&s)) == -1 )
	    return -1;
	n.point = val;			/* Point address */
    }
    
    if(*s == '@')			/* Domain address follows */
    {
	s++;
	for(i=0; i<MAX_DOMAIN-1 && *s; n.domain[i++] = *s++) ;
	n.domain[i] = 0;
    }
    else if(*s)
	return -1;

    if(n.zone == -1)
	n.zone = Config.myaddr.zone;
    if(n.point == -1 && !point_flag)
	n.point = 0;

    *node = n;
    return 0;
}



/***** node_to_asc() --- Convert Node struct to Z:N/F.P address string *******/

char *node_to_asc(node, point_flag)
Node *node;
int point_flag;
{
    SHUFFLEBUFFERS;

    if(node->point!=-1 && (node->point!=0 || point_flag))
	sprintf(tcharp, 
		"%d:%d/%d.%d", node->zone, node->net, node->node, node->point);
    else
	sprintf(tcharp,
		"%d:%d/%d",    node->zone, node->net, node->node);

    if(node->domain[0])
    {
	strcat(tcharp, "@");
	strcat(tcharp, node->domain);
    }

    return tcharp;
}



/***** node_to_pfnz() --- Convert Node struct to p.f.n.z notation ************/

char *node_to_pfnz(node, point_flag)
Node *node;
int point_flag;
{
    SHUFFLEBUFFERS;

    if(node->point!=-1 && (node->point!=0 || point_flag))
	sprintf(tcharp,
		"p%d.f%d.n%d.z%d",
		node->point, node->node, node->net, node->zone );
    else
	sprintf(tcharp, "f%d.n%d.z%d", node->node, node->net, node->zone);

    return tcharp;
}



/***** node_to_domain() --- Convert Node struct to p.f.n.z.fidonet.org *******/

char *node_to_domain(node)
Node *node;
{
    SHUFFLEBUFFERS;
    
    sprintf(tcharp, "%s%s", node_to_pfnz(node, FALSE), get_domain(node->zone));

    return tcharp;
}



/***** parseinternode() --- Convert FIDO Internet address to Node struct *****/

int parseinternode(address, node)
char *address;
Node *node;
{
    char *p, *s;
    char domain[128];
    int len, dlen, ret;

    s = strsave(address);

    /* Remove `!...' */
    if((p = strrchr(s, '!')))
	*p = 0;

    /*
     * Check for possible domains and remove them.
     * Currently the following domains are recognized:
     *	       FIDODOMAIN
     * e.g.    ".fidonet.org"
     *	       .MY_HOSTNAME
     * e.g.    ".hippo"
     *	       .MY_HOSTNAME.MY_DOMAIN
     * e.g.    ".hippo.dfv.rwth-aachen.de"
     * FIDO_DE also enables:
     *	       .FIDO_DE_DOMAIN
     * e.g.    ".fido.de"
     */
    len	 = strlen(s);
    while(1) {
	strcpy(domain, FIDODOMAIN);
	dlen = strlen(domain);
	if(len > dlen  &&  !stricmp(s + len - dlen, domain)) {
	    s[len - dlen] = 0;
	    break;
	}

	strcpy(domain, ".");
	strcat(domain, MY_HOSTNAME);
	dlen = strlen(domain);
	if(len > dlen  &&  !stricmp(s + len - dlen, domain)) {
	    s[len - dlen] = 0;
	    break;
	}

	strcat(domain, MY_DOMAIN);
	dlen = strlen(domain);
	if(len > dlen  &&  !stricmp(s + len - dlen, domain)) {
	    s[len - dlen] = 0;
	    break;
	}

#ifdef EXTRA_DOMAIN_1
	strcpy(domain, EXTRA_DOMAIN_1);
	dlen = strlen(domain);
	if(len > dlen  &&  !stricmp(s + len - dlen, domain)) {
	    s[len - dlen] = 0;
	    break;
	}
#endif

#ifdef EXTRA_DOMAIN_2
	strcpy(domain, EXTRA_DOMAIN_2);
	dlen = strlen(domain);
	if(len > dlen  &&  !stricmp(s + len - dlen, domain)) {
	    s[len - dlen] = 0;
	    break;
	}
#endif

#ifdef FIDO_DE
	strcpy(domain, FIDO_DE_DOMAIN);
	dlen = strlen(domain);
	if(len > dlen  &&  !stricmp(s + len - dlen, domain)) {
	    /*
	     * Special handling for Fido.DE addresses
	     */
	    ret = get_fido_de_node(s, node);
	    free(s);
	    return ret;
	    break;
	}
#endif /**FIDO_DE**/

	break;
    }

    ret = pfnz_to_node(s, node, FALSE);
    if(!check_domain(node->zone))
    {
	/* Zone not supported */
	address_error = "zone not supported by this gateway";
	ret = ERROR;
    }

    free(s);
    return ret;
}
