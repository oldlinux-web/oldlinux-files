/*:ts=8*/
/*****************************************************************************
 * FIDOGATE --- Gateway UNIX Mail/News <-> FIDO NetMail/EchoMail
 *
 * $Id: aliases.c,v 3.1 1993/09/14 07:38:47 mj beta mj $
 *
 * Read user name aliases from file. The alias.users format is as follows:
 *	username    Z:N/F.P    Full Name
 *
 *****************************************************************************
 * Copyright (C) 1990, 1993
 *  _____ _____
 * |	 |___  |   Martin Junius	     FIDO:	2:242/6.1
 * | | | |   | |   Republikplatz 3	     Internet:	mj@sungate.fido.de
 * |_|_|_|@home|   D-52072 Aachen, Germany   Phone:	++49-241-86931 (voice)
 *
 * This file is part of FIDOGATE.
 *
 * FIDOGATE is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * FIDOGATE is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with FIDOGATE; see the file COPYING.  If not, write to the Free
 * Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA. 
 *****************************************************************************/

#include "fidogate.h"



static Alias aliasbuf;

static Alias *getalias	    P((FILE *));
static int nodeeq	    P((Node *, Node *));



/*
 * alias_by_username() --- get alias record using username as key
 */

Alias *alias_by_username(name, node)
char *name;
Node *node;
{
    FILE *fp;
    Alias *a;
    
    fp = libfopen(ALIASES, R_MODE);

    while((a = getalias(fp)))
    {
	if(!stricmp(a->username, name) && nodeeq(&a->node, node))
	{
	    fclose(fp);
	    return a;
	}
    }
    
    fclose(fp);
    return NULL;
}



/*
 * alias_by_fullname() --- get alias record using fullname as key
 */

Alias *alias_by_fullname(name, node)
char *name;
Node *node;
{
    FILE *fp;
    Alias *a;
    
    fp = libfopen(ALIASES, R_MODE);

    while((a = getalias(fp)))
    {
	if(!stricmp(a->fullname, name) && nodeeq(&a->node, node))
	{
	    fclose(fp);
	    return a;
	}
    }
    
    fclose(fp);
    return NULL;
}



/*
 * getalias() --- read one alias record from file
 */

static Alias *getalias(fp)
FILE *fp;
{
    static char buf[BUFSIZ];
    char *p, *s;
    int i;
    
    while(1)
    {
	if(!fgets(buf, BUFSIZ, fp))
	{
	    return NULL;
	}
    
	for(p=buf; *p && isspace(*p); p++) ;
	if(!*p)
	    continue;
	
	for(i = 0;
	    i<MAXUSERNAME-1 && *p && !isspace(*p);
	    aliasbuf.username[i++] = *p++) ;
	aliasbuf.username[i] = 0;
	
	for(; *p && isspace(*p); p++) ;
	if(!*p)
	    continue;

	for(s=p; *p && !isspace(*p); p++) ;
	if(!*p)
	    continue;
	*p++ = 0;

	if(asc_to_node(s, &aliasbuf.node, FALSE) != OK)
	    continue;

	for(; *p && isspace(*p); p++) ;
	if(!*p)
	    continue;
	for(i = 0;
	    i<MAXFULLNAME-1 && *p && *p!='\n';
	    aliasbuf.fullname[i++] = *p++) ;
	aliasbuf.fullname[i] = 0;

	return &aliasbuf;
    }
}



/*
 * nodeeq() --- compare node adresses, special point treatment
 */

static int nodeeq(a, b)
Node *a, *b;
{
    return a->point
	   ?
	   a->zone==b->zone && a->net==b->net && a->node==b->node &&
	   a->point==b->point
	   :
	   a->zone==b->zone && a->net==b->net && a->node==b->node
	   ;
}
