/*:ts=8*/
/*****************************************************************************
 * FIDOGATE --- Gateway UNIX Mail/News <-> FIDO NetMail/EchoMail
 *
 * $Id: textlist.c,v 3.1 1993/09/14 07:40:04 mj beta mj $
 *
 * Store text file as chain of linked text lines in memory
 *
 *****************************************************************************
 * Copyright (C) 1990, 1993
 *  _____ _____
 * |     |___  |   Martin Junius             FIDO:      2:242/6.1
 * | | | |   | |   Republikplatz 3           Internet:  mj@sungate.fido.de
 * |_|_|_|@home|   D-52072 Aachen, Germany   Phone:     ++49-241-86931 (voice)
 *
 * This file is part of FIDOGATE.
 *
 * FIDOGATE is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * FIDOGATE is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with FIDOGATE; see the file COPYING.  If not, write to the Free
 * Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************/

#include "fidogate.h"



/***** Textlist_init() --- Initialize structure ******************************/

void Textlist_init(list)
Textlist *list;
{
    list->first = NULL;
    list->last	= NULL;
    list->n     = 0;
}



/***** Textlist_clear() --- Delete text lines and chain **********************/

void Textlist_clear(list)
Textlist *list;
{
    Textline *p, *pn;

    for(p=list->first; p;) {
	pn = p->next;
	free(p->line);
	free(p);
	p  = pn;
    }
    
    list->first = NULL;
    list->last	= NULL;
    list->n     = 0;
}



/***** Textlist_append() --- Append string to text line chain ****************/

void Textlist_append(list, s)
Textlist *list;
char *s;
{
    Textline *p;

    s = strsave(s);
    p	    = (Textline *)xmalloc(sizeof(Textline));
    p->line = s;
    p->next = NULL;
    
    if(list->last)
	list->last->next = p;
    else
	list->first = p;
    list->last	     = p;
    list->n++;
}



/***** Textlist_appendf() --- Append text to chain, printf like formatting ***/

#ifdef __STDC__

void Textlist_appendf(Textlist *list, char *fmt, ...)
{
va_list args;

    va_start(args, fmt);

#else /**!__STDC__**/

void Textlist_appendf(va_alist)
{
va_list args;
Textlist *list;
char *fmt;

    va_start(args);
    list = va_arg(args, Textlist *);
    fmt	 = va_arg(args, char *);

#endif /**__STDC__**/

    vsprintf((char*)buffer, fmt, args);
    Textlist_append(list, (char *)buffer);
}



/***** Textlist_print() --- Write text line chain to file ********************/

void Textlist_print(list, fp)
Textlist *list;
FILE *fp;
{
Textline *p;

    for(p=list->first; p; p=p->next)
	fputs(p->line, fp);
}



/***** Textlist_size() --- Compute size of text in chain *********************/

long Textlist_size(list)
Textlist *list;
{
Textline *p;
long n=0;

    for(p=list->first; p; p=p->next)
	n += strlen(p->line);

    return n;
}
