/*:ts=8*/
/*****************************************************************************
 * FIDOGATE --- Gateway UNIX Mail/News <-> FIDO NetMail/EchoMail
 *
 * $Id: hosts.c,v 3.1 1993/09/14 07:40:04 mj beta mj $
 *
 * Process hostname <-> node aliases from hosts file
 *
 *****************************************************************************
 * Copyright (C) 1990, 1993
 *  _____ _____
 * |     |___  |   Martin Junius             FIDO:      2:242/6.1
 * | | | |   | |   Republikplatz 3           Internet:  mj@sungate.fido.de
 * |_|_|_|@home|   D-52072 Aachen, Germany   Phone:     ++49-241-86931 (voice)
 *
 * This file is part of FIDOGATE.
 *
 * FIDOGATE is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * FIDOGATE is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with FIDOGATE; see the file COPYING.  If not, write to the Free
 * Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************/

#include "fidogate.h"

#include "shuffle.h"


#ifdef FIDO_DE

static int lookup_by_node	P((char *, Node *));
#if 0 /**CURRENTLY NOT USED**/
static int lookup_by_name	P((char *, Node *));


/*
 * lookup_by_name() --- Lookup Fido.DE host in alias file by name
 */
static int lookup_by_name(name, node)
char *name;
Node *node;
{
    return 0;
}
#endif



/*
 * lookup_by_node() --- Lookup Fido.DE host in alias file by node address
 */
static int lookup_by_node(name, node)
char *name;
Node *node;
{
    static char buffer[BUFSIZ];
    Node addr;
    FILE *fp;
    char *bp, *p;
    char *host = NULL;
    int point_flag = -1;
    int found = FALSE;

    fp = libfopen(HOSTS, R_MODE);

    while(getcl(buffer, BUFSIZ, fp)) {
	for(bp=buffer; *bp && isspace(*bp); bp++);	/* Skip white space */
	if(!*bp)
	    continue;
	/*
	 * FIDO address
	 */
	p = strtok(bp, " \t");
	if(!*p)
	    continue;
	if(asc_to_node(p, &addr, FALSE) != OK)
	    continue;
	/*
	 * Host name
	 */
	host = strtok(NULL, " \t");
	if(!*host)
	    continue;
	/*
	 * Point handling
	 */
	p = strtok(NULL, " \t");
	if(!*p)
	    continue;
	point_flag = *p == 'y' || *p == 'Y';

	/*
	 * Compare with address node
	 */
	if(node->zone==addr.zone &&
	   node->net ==addr.net  &&
	   node->node==addr.node &&
	   (node->point==addr.point || addr.point==0) )
	{
	    found = TRUE;
	    if(addr.point)
		point_flag = -1;
	    break;
	}
    }

    fclose(fp);

    if(found)
    {
	if(name)
	    strcpy(name, host);
	node->fido_de	 = TRUE;
	node->point_flag = point_flag;
    }

    return found;
}   




/*
 * get_fido_de_host() --- return host name for FIDO node address
 */

char *get_fido_de_host(node, force_flag)
Node *node;
int force_flag;
{
    static char name[BUFSIZ];
    int point_flag;
    int found;

    node->fido_de    = FALSE;
    node->point_flag = TRUE;
    found = lookup_by_node(name, node);
    if(node->point_flag == -1)
	point_flag = node->point_flag = 0;
    else
	point_flag = force_flag ? TRUE : node->point_flag;
    
    /*
     * Convert to Internet address
     */
    if(found) {
	SHUFFLEBUFFERS;
	if(point_flag && node->point)
	    sprintf(tcharp, "p%d.%s%s", node->point, name, FIDO_DE_DOMAIN);
	else
	    sprintf(tcharp, "%s%s", name, FIDO_DE_DOMAIN);
	return tcharp;
    }
    else
	return node_to_domain(node);
}



/*
 * get_fido_de_node() --- return FIDO node for host.fido.de
 */

int get_fido_de_node(address, node)
char *address;
Node *node;
{
    char *p, *s, *pn, *bp;
    char domain[128];
    int len, dlen;
    int point = 0;
    static char buffer[BUFSIZ];
    Node addr;
    FILE *fp;
    char *name;
    int found = FALSE;

    s = address;

    /*
     * Check for FIDO_DE_DOMAIN at end of string
     */
    len	 = strlen(s);
    strcpy(domain, FIDO_DE_DOMAIN);
    dlen = strlen(domain);
    if(len > dlen  &&  !stricmp(s + len - dlen, domain))
	s[len - dlen] = 0;
    else
	return -1;				/* Not a .fido.de address */

    /*
     * First check for p.f.n.z addressing
     */
    if(!pfnz_to_node(s, node, FALSE))
    {
	/* p.f.n.z */
	if(lookup_by_node(NULL, node))		/* Found it! */
	    return 0;
	else					/* Not a Fido.DE node */
	{
	    address_error = "Not a registered Fido.DE node";
	    return -1;
	}
    }

    /*
     * Look for optional point addressing in front of host name
     */
    p = s;
    if(*p=='p' || *p=='P') {
	p++;
	pn = p;
	while(*p && isdigit(*p))
	    p++;
	if(*p == '.') {				/* Must end with '.' */
	    *p++  = 0;
	    point = atoi(pn);			/* Point number */
	}
	else
	    p = s;
    }
    pn	  = p;
    
    /*
     * Now p points to the host name, look it up in host alias file
     */
    fp = libfopen(HOSTS, R_MODE);

    while(getcl(buffer, BUFSIZ, fp)) {
	for(bp=buffer; *bp && isspace(*bp); bp++);	/* Skip white space */
	if(!*bp)
	    continue;
	/*
	 * FIDO address
	 */
	p = strtok(bp, " \t");
	if(!*p)
	    continue;
	if(asc_to_node(p, &addr, FALSE) != OK)
	    continue;
	/*
	 * Host name
	 */
	name = strtok(NULL, " \t");
	if(!*name)
	    continue;
	if(!strcmp(name, "-"))
	    name = NULL;

	/*
	 * Compare with host name from address
	 */
	if(name && !stricmp(name, pn)) {
	    found = TRUE;
	    break;
	}
    }

    fclose(fp);
    
    /*
     * If found return FIDO node address
     */
    if(found) {
	*node = addr;
	if(!node->point)
	    node->point = point;
	return 0;
    }

    address_error = "No such host in domain Fido.DE";
    return -1;
}


#endif /**FIDO_DE**/
