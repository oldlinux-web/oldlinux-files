/*
 * Automatically generated --- do not edit!
 */
#define LIBDIR   "/usr/local/lib/fidonet"
#define SPOOLDIR "/usr/spool/fidonet"
