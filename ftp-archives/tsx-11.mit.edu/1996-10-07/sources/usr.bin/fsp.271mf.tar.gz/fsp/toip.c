#include <stdio.h>
void
main(argc,argv,envp)
int argc;char **argv;
{
   int output[4];
   sscanf(argv[1],"%2X%2X%2X%2X",&output[0],&output[1],&output[2],&output[3]);
   (void) printf("%d.%d.%d.%d\n", output[0],output[1],output[2],output[3]);
  return;
}
 
