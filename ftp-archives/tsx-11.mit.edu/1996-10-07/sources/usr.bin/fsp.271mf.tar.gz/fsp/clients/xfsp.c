/*****************************************************************************\
 *       Written by Patrick Nguyen ( MegaFork ), 14th Nov. 1993.	     *
 *  Xt Motif Graphic User Interface oriented File Service Protocol Client    *

 *    Version: 0.01, under motif 1.2.1, XFree 1.3 (X11R5 port)		     *
 *		Last Modified 24th November 1993			     *

 *  WARNING: The author will not be held responsible for any damage this     *
 *   package may cause.							     *
 *  This program is under no copyright notice. It is meant to be free for    *
 * copying, modifying, distributing, etc... 				     *
\*****************************************************************************/

/* The Main loop: init app and its context + does the main window layout */
#include <Xm/Xm.h>
#include <Xm/XmStrDefs.h>
#include <Xm/PushB.h>
#include <Xm/RowColumn.h>
#include <Xm/Label.h>
#include <Xm/List.h>
#include <Xm/MainW.h>

#include "xfsp.h"		/* Callbacks declarations and global widgets */

#define DEBUG		/* Undef this if you don't want the proggie to 
			   echo debug info to stdout. */
/* This global variables list is getting too long */
Widget msg_w;
Widget list_w;
Widget xfer_b; /* This needs to be declared here, we will have to change its
		  XmNlabelString dynamically */
int lwposition = 0;
char **envp;
BOOL local_mode;

XtAppContext app; /* For the double-clicks */

void
main( argc, argv, ep ) int argc; char **argv; char **ep;
{
   Widget main_w, toplevel, menubar, cd_b, refresh_b, view_b, mkdir_b,
	  rmdir_b, ver_b, del_b, rowcol, button_rc;
   /* xx_b are the buttons. managers are main_w, rowcol, button_rc */
   /* Note that xfer_b is missing. I declared it as global so as to be able
	to change its XmNlabelString (it's a pushbutton) from the menu 
	callbacks */
   XmString file, options, mode, help;
   toplevel = XtVaAppInitialize( &app, "XFSP", NULL, 0,
			&argc, argv, NULL, NULL, NULL,
			NULL);
   XtSetLanguageProc( NULL, NULL, NULL );
   envp = ep;
#ifdef DEBUG
   (void)printf( "Creating Main Window now\n");
#endif /* DEBUG */
   main_w = XtVaCreateWidget( "main_w", 
		xmMainWindowWidgetClass, toplevel, NULL);

#ifdef DEBUG
   (void)printf( "Creating the Menubar now\n");
#endif /* DEBUG */

   file     =  XmStringCreateSimple( "File"    );
   options  =  XmStringCreateSimple( "Options" );
   mode     =  XmStringCreateSimple( "Mode"    );
   help     =  XmStringCreateSimple( "Help"    );

   menubar = XmVaCreateSimpleMenuBar( main_w, "menubar",
		XmVaCASCADEBUTTON, file,    'F',
		XmVaCASCADEBUTTON, options, 'O',
		XmVaCASCADEBUTTON, mode,    'M',
		XmVaCASCADEBUTTON, help,    'H',
		NULL);
#ifdef DEBUG
   (void)printf("Menubar Created, now for its children (pulldowns)\n");
#endif /* DEBUG */
   { /* Pulldown menus */
	XmString quit, host, port, pass, remote, local, remote_acc, local_acc,
		 about;
	Widget mode_sub_m, w;

	quit = XmStringCreateSimple( "Quit" );
	host = XmStringCreateSimple( "Host" );
	port = XmStringCreateSimple( "Port" );
	pass = XmStringCreateSimple( "Password" );
	remote = XmStringCreateSimple( "Remote" );
	local = XmStringCreateSimple( "Local" );
	remote_acc = XmStringCreateSimple( "Ctrl-X" );
	local_acc = XmStringCreateSimple( "Ctrl-L" );
	about = XmStringCreateSimple( "About Xm FSP Client" );

	(void)XmVaCreateSimplePulldownMenu( menubar, "file_m", 0, file_cb,
			XmVaPUSHBUTTON, quit, 'Q',NULL, NULL,
			NULL);
	(void)XmVaCreateSimplePulldownMenu( menubar, "options_m", 1, options_cb,
			XmVaPUSHBUTTON, host, 'H', NULL, NULL,
			XmVaPUSHBUTTON, port, 'P', NULL, NULL,
			XmVaPUSHBUTTON, pass, 'w', NULL, NULL,
			NULL);
	mode_sub_m =XmVaCreateSimplePulldownMenu( menubar, "mode_m", 2, mode_cb,
			XmVaRADIOBUTTON, remote, 'R', "Ctrl<Key>x", remote_acc,
			XmVaRADIOBUTTON, local, 'L', "Ctrl<Key>l", local_acc,
			XmNradioBehavior, True,
			XmNradioAlwaysOne, True,
			NULL);
        (void)XmVaCreateSimplePulldownMenu( menubar, "help_m", 3, help_cb,
			XmVaPUSHBUTTON, help, 'H', NULL, NULL,
			XmVaSEPARATOR,
			XmVaPUSHBUTTON, about, 'A', NULL, NULL,
			NULL );
        if( w = XtNameToWidget( menubar, "button_3" ) )
                XtVaSetValues( w, XmNmenuHelpWidget, w, NULL );
#ifdef DEBUG
	else (void)printf("Couldn't get widget from Name.\n");
#endif
	if( w = XtNameToWidget( mode_sub_m, "button_0" ) ) 
		XtVaSetValues( w, XmNset, True, NULL );
	XmStringFree( quit );
	XmStringFree( host );
	XmStringFree( port );
	XmStringFree( pass );
	XmStringFree( remote );
	XmStringFree( remote_acc );
	XmStringFree( local );
	XmStringFree( local_acc );
	XmStringFree( about );
   } /* Menubar subs done */
   XtManageChild( menubar );
   XmStringFree( file );
   XmStringFree( options );
   XmStringFree( mode );
   XmStringFree( help );
#ifdef DEBUG
   (void)printf("Done with the menubar..\n");
#endif /* DEBUG */
   rowcol = XtVaCreateWidget( "rowcol",
		xmRowColumnWidgetClass, main_w,
		XmNorientation, XmVERTICAL,
		NULL);
#ifdef DEBUG
   (void)printf("Creating the list_w\n");
#endif /* DEBUG */
   list_w = XmCreateScrolledList( rowcol, "dirlist", NULL, 0 );
   XtVaSetValues( list_w,
		XmNvisibleItemCount, 20,
		XmNscrollingPolicy, XmAS_NEEDED,
		XmNselectionPolicy, XmEXTENDED_SELECT,
		NULL);
   XtAddCallback( list_w, XmNextendedSelectionCallback, select_cb, NULL );
   XtAddCallback( list_w, XmNdefaultActionCallback, pickone_cb, NULL );
   XtManageChild( list_w );

#ifdef DEBUG
   (void)printf("The buttons Bar now..\n");
#endif /* DEBUG */
   button_rc = XtVaCreateWidget( "button_rc",
		xmRowColumnWidgetClass, rowcol,
		XmNorientation, XmHORIZONTAL,
		XmNpacking, XmPACK_COLUMN,
		NULL);
   { /* Create the buttons of the button bar( button_rc ) */
	XmString xfer, view, mkd, rmd, cd, ver, rm, refresh;
	xfer    =   XmStringCreateSimple(   "GET"   );/* We're remote by default */
	view    =   XmStringCreateSimple(  "VIEW"   );
	mkd     =   XmStringCreateSimple(  "MKDIR"  );
	rmd     =   XmStringCreateSimple(  "RMDIR"  );
	cd      =   XmStringCreateSimple(   "CD"    );
	ver     =   XmStringCreateSimple( "VERSION" );
	rm      =   XmStringCreateSimple(   "DEL"   );
        refresh =   XmStringCreateSimple( "Refresh" );
	
	xfer_b = XtVaCreateManagedWidget( "xfer", 
			xmPushButtonWidgetClass, button_rc,
			XmNlabelString, xfer, /* Takes either PUT or GET value*/
			NULL);
	view_b = XtVaCreateManagedWidget( "view",
			xmPushButtonWidgetClass, button_rc,
			XmNlabelString, view,
			NULL);
	mkdir_b = XtVaCreateManagedWidget( "mkdir",
			xmPushButtonWidgetClass, button_rc,
			XmNlabelString, mkd,
			NULL);
	rmdir_b = XtVaCreateManagedWidget( "rmdir",
			xmPushButtonWidgetClass, button_rc,
			XmNlabelString, rmd,
			NULL);
        del_b = XtVaCreateManagedWidget( "del",
                        xmPushButtonWidgetClass, button_rc,
                        XmNlabelString, rm,
                        NULL);
	cd_b = XtVaCreateManagedWidget( "cd",
			xmPushButtonWidgetClass, button_rc,
			XmNlabelString, cd,
			NULL);
	ver_b = XtVaCreateManagedWidget( "ver",
			xmPushButtonWidgetClass, button_rc,
			XmNlabelString, ver,
			NULL);
	refresh_b = XtVaCreateManagedWidget( "refresh",
			xmPushButtonWidgetClass, button_rc,
			XmNlabelString, refresh,
			NULL);
	
	XtAddCallback( xfer_b, XmNactivateCallback, xfer_cb, NULL );
	XtAddCallback( cd_b,  XmNactivateCallback, cd_cb,  NULL );
	XtAddCallback( ver_b, XmNactivateCallback, ver_cb, NULL );
	XtAddCallback( del_b, XmNactivateCallback,  rm_cb, NULL );
	XtAddCallback( refresh_b, XmNactivateCallback, refresh_cb, NULL );
	XtAddCallback( view_b, XmNactivateCallback, view_cb, NULL );
	XtAddCallback( mkdir_b, XmNactivateCallback, mkdir_cb, NULL );
	XtAddCallback( rmdir_b, XmNactivateCallback, rmdir_cb, NULL );
	
	XmStringFree( xfer );
	XmStringFree( cd  );
	XmStringFree( ver );
	XmStringFree( rm  );
	XmStringFree( refresh );
   } /* Done with button_rc children */
   XtManageChild( button_rc );

#ifdef DEBUG
   (void)printf("Create-Manageing msg_w ...\n");
#endif /* DEBUG */   
   { /* Message Window */
	XmString ready = 
		XmStringCreateSimple( "X FSP client written by Patrick Nguyen"\
				      " ( MegaFork ) Ready!");
        msg_w = XtVaCreateManagedWidget( "msg_w",
		  xmLabelWidgetClass, rowcol,
		  XmNlabelString, ready,
		  NULL);
	XmStringFree( ready );
   }
   XtManageChild( rowcol );

#ifdef DEBUG
   (void)printf("Last thing about the main window: Setting what is what.\n");
#endif /* DEBUG */
   XtVaSetValues( main_w,
	XmNmenuBar, menubar,
	XmNworkWindow, rowcol,
	NULL);
   XtManageChild( main_w );
   local_mode = 0; /* Remote by default */ 
   XtRealizeWidget( toplevel );
   /* The init function */
   start_fsp();
   XtAppMainLoop( app );
  
} /* main */
