    /*********************************************************************\
    *  Copyright (c) 1991 by Wen-King Su (wen-king@vlsi.cs.caltech.edu)   *
    *                                                                     *
    *  You may copy or modify this file in any manner you wish, provided  *
    *  that this notice is always included, and that you hold the author  *
    *  harmless for any loss or damage resulting from the installation or *
    *  use of this software.                                              *
    \*********************************************************************/

#include "tweak.h"
#include "client_def.h"
#include "c_extern.h"
#include "bsd_extern.h"

extern char *env_passwd;

static int remove_it PROTO1(char *, p)
{
  char *op;
  UBUF *ub;
  char *ptr;

  op = util_abs_path(p);
  
  ub = client_interact(CC_DEL_FILE,0L, strlen(op), (unsigned char *)op+1, 0,
		       (unsigned char *)NULLP);
  
  if(ub->cmd == CC_ERR) {
    if( ptr = strchr(p, ' ') )
	*ptr++ = 0;
    fprintf(stderr,"Can't remove %s: %s\n",p,ub->buf);
    free(op); return(-1);
  }
  return(0);
}

int 
#ifdef X_CLIENT
do_frm
#else
main 
#endif /* X_CLIENT */
PROTO3(int, argc, char **, argv, char **, envp)
{
  char **av, *av2[2];
  
  env_client();
  
  while(*++argv) {
    if(!(av = glob(*argv))) {
      av = av2;
      av2[0] = *argv;
      av2[1] = 0;
    }
    while(*av) {
	if(*env_passwd) {
	    char *bah;
	    bah = (char *)malloc(strlen( *av )+ strlen(env_passwd)+2);
	    (void)strcpy(bah, *av++);
	    (void)strcat(bah, "\n");
	    (void)strcat(bah, env_passwd);
	    (void)remove_it(bah);
	    free( bah );
        }
        else remove_it(*av++);
    }
  }
  
  client_done();
  
  exit(0);
}
