/* Written by Patrick Nguyen ( MegaFork ), 28th Nov 1993 */
/* The Callback Routines ! , part two */

#include <Xm/Xm.h> 
#include <Xm/XmStrDefs.h>

#include "xfsp.h"

#define DEBUG		/* produce debug info to stdout! */

#define EchoList(aaa) { int u; for( u = 0; aaa[u]; u++ ) (void)printf\
			("%s ", aaa[u]);(void)printf(": %d items\n", u); }
/* a few things from xfsp.c */
extern Widget msg_w;
extern Widget list_w;
extern Widget xfer_b;
extern int lwposition;
extern char **envp;

/* a thing from callbacks.c */
extern szString *szSelectedFiles;

/* a few things from util.c */
extern char * env_port;
extern char * env_passwd;
extern char * env_host;
extern char * env_dir;

/* local or remote ? */
extern BOOL local_mode;

/* The core follows... will add more more comments when it'll work */

/* The Help Menu callback */
void help_cb( w, item_no, cbs )
Widget w;
int item_no;
XmAnyCallbackStruct *cbs;
{
   switch( item_no ) {
	case 0: /* The Help */
		 XpnPopupMsg( list_w, "Sorry\nNo Help Available Yet, man.",
				NULL );
		 break;
	case 1: /* The About Message Popup */
		 XpnPopupMsg( list_w, ABOUT_STR, NULL );
		 break;
	default: break;
   }
}

/* When user dbl-trbl-click'ed on an item, or hit the return key when list_w had
   focus */
void 
pickone_cb( w, client_data, cbs )
Widget w;
XtPointer client_data;
XmListCallbackStruct *cbs;
{
   char *choice;
   (void)XmStringGetLtoR( cbs->item, XmSTRING_DEFAULT_CHARSET, &choice );
   if( *choice == 'd' ) /* User chose a directory */
	change_d( strrchr( choice, ' ' ) + 1 );
   else /* It's a file then. */
	xfer_cb( w, NULL, NULL );
   XtFree( choice );
   return;
}
