/* Written by Patrick Nguyen ( MegaFork ), 14th Nov 1993 */
/* Last modified 21st Nov 1993 */
/* The Callback Routines ! */

#include <Xm/Text.h>
#include <Xm/RowColumn.h>
#include <Xm/PushB.h>
#include <Xm/Label.h>
#include <Xm/LabelG.h>
#include <stdio.h>
#include <ctype.h>
#include <strings.h>
/* Might have to change it to string.h */

#include "xfsp.h"

#define DEBUG		/* produce debug info to stdout! */

#define EchoList(aaa) { int u; for( u = 0; aaa[u]; u++ ) (void)printf\
			("%s ", aaa[u]);(void)printf(": %d items\n", u); }
/* a few things from xfsp.c */
extern Widget msg_w;
extern Widget list_w;
extern Widget xfer_b;
extern int lwposition;
extern char **envp;
extern XtAppContext app;

/* a few things from util.c */
extern char * env_port;
extern char * env_passwd;
extern char * env_host;
extern char * env_dir;

/* the selected list */
szString szSelectedFiles[64]; /* who would select more that 64 files??! */
   /* Yes, they're malloc-ed from strdup. System that don't have malloc()
      can just go to hell for what I care. */

/* local or remote ? */
extern BOOL local_mode;

/* The core follows... will add more more comments when it'll work */

/* The init function */
void start_fsp() 
{
   return; /* Don't do anything */
}

/* The file menu callback: Quit. */
void file_cb( w, item_no, cbs )
Widget w;
int item_no;
XmAnyCallbackStruct *cbs;
{
   exit(0);
}

/* The 'Options' menu callback */
void options_cb( w, item_no, cbs )
Widget w;
int item_no; /* The item that triggered the callback:
		0 : host
		1 : port
		2 : passwd
	      */
XmAnyCallbackStruct *cbs; /* unused */
{
   extern void set_host();
   extern void set_port();

   switch( item_no ) {
	case 0 : /* Host */
	   { 
		Arg args[2];char *host = env_host?env_host:getenv("FSP_HOST");
		char szPrompt[BUFSIZ]; /* some hungarian notation, i'd like */
		XmString xmsPrompt; /* to be precise about the types */
		static Widget dialog;
		(void)sprintf(szPrompt, 
			"Enter Host Name [%s]", host?host:"localhost" );
		xmsPrompt = XmStringCreateSimple( szPrompt );
		XtSetArg( *args, XmNautoUnmanage, False );
		XtSetArg( args[1], XmNselectionLabelString, xmsPrompt );
		dialog = XmCreatePromptDialog( list_w, "prompt", args, 2 );
		XmStringFree( xmsPrompt );
		XtAddCallback( dialog, XmNokCallback, set_host, NULL );
		XtAddCallback( dialog, XmNcancelCallback, XtDestroyWidget, NULL);
		XtUnmanageChild( 
			XmSelectionBoxGetChild( dialog,
							XmDIALOG_HELP_BUTTON ));
		XtManageChild( dialog );
		XtPopup( XtParent( dialog ), XtGrabNone );
	    } break;
	case 1 : /* Port */
	   {
		Arg args[2]; char *port = env_port? env_port:getenv("FSP_PORT");
		char szPrompt[BUFSIZ];
		XmString xmsPrompt;
		static Widget dialog;
		(void)sprintf( szPrompt,
			"Enter Port Number [%s]", port? port:"21" );
		xmsPrompt = XmStringCreateSimple ( szPrompt ) ;
		XtSetArg( *args, XmNautoUnmanage, False );
		XtSetArg( args[1], XmNselectionLabelString, xmsPrompt );
		dialog = XmCreatePromptDialog( list_w, "prompt", args, 2 );
		XmStringFree( xmsPrompt );
		XtAddCallback( dialog, XmNokCallback, set_port, NULL );
		XtAddCallback( dialog, XmNcancelCallback, XtDestroyWidget, NULL);
		XtUnmanageChild( XmSelectionBoxGetChild( dialog,
				XmDIALOG_HELP_BUTTON ));
		XtManageChild( dialog );
		XtPopup( XtParent( dialog ), XtGrabNone );
	    } break;
	case 2 : /* Passwd */
	   {
    		Widget bb_shell, text_w, rowcol;
		Arg args[1]; XmString strTitle;
		extern void check_passwd();
		strTitle = XmStringCreateSimple( "Enter Password" );
		XtSetArg( *args, XmNdialogTitle, strTitle );
		bb_shell = XmCreateBulletinBoardDialog( list_w, "BBShell",
							args, 1);
		XmStringFree( strTitle );
    		rowcol = XtVaCreateWidget("pswd_rc",
    		    xmRowColumnWidgetClass, bb_shell,
    		    XmNorientation, XmHORIZONTAL,
   		    NULL);

    		XtVaCreateManagedWidget("Password:",
    		    xmLabelGadgetClass, rowcol, NULL);
    		text_w = XtVaCreateManagedWidget("text_w",
    		    xmTextWidgetClass, rowcol, NULL);

    		XtAddCallback(text_w, XmNmodifyVerifyCallback, check_passwd, NULL);
    		XtAddCallback(text_w, XmNactivateCallback, check_passwd, NULL);

    		XtManageChild(rowcol);
		XtManageChild( bb_shell );
		XtPopup( XtParent( bb_shell ), XtGrabNone );
	   } break;
	default :
	   {
		XmString msg ;
		XtVaSetValues( msg_w,
		   XmNlabelString, msg = XmStringCreateSimple("Internal Error"),
		   NULL);
	        XmStringFree( msg );
	   }
	   break;
   }
   return;
}

/* The 'Mode' menu callback: set mode local / remote and refresh */
void mode_cb( w, item_no, cbs )
Widget w;
int item_no;
XmAnyCallbackStruct *cbs;
{
   XmString msg;
   char szMsg[80], *ptr;

   switch( item_no ) {
	case 0 : /* Remote */
	   (void)sprintf(szMsg, "On server %s (%s): %s",
			env_host? env_host: (( ptr = getenv("FSP_HOST") )? ptr: "<nowhere>"),
			env_port? env_port: (( ptr = getenv("FSP_PORT") )? ptr: "<no port>"),
			env_dir ? env_dir : (( ptr = getenv("FSP_DIR" ) )? ptr: "<no dir>" )
			);
	   msg = XmStringCreateSimple( szMsg );
	   XtVaSetValues( msg_w, 
		XmNlabelString, msg,
		NULL);
	   XmStringFree( msg );
	   XtVaSetValues( xfer_b, 
		XmNlabelString, msg = XmStringCreateSimple("GET"), NULL );
	   if( local_mode ) {
		local_mode = 0;
		refresh_cb(w, NULL, NULL);
	   }
	   break;
	case 1 : /* Local */
	   ptr = (char *)malloc(80);
	   (void)sprintf(szMsg, "Local Mode, dir: %s",
			  getcwd( ptr, 80 )? ptr: "<Dunno where!>");
	   free(ptr);
	   msg = XmStringCreateSimple( szMsg );
	   XtVaSetValues( msg_w,
		XmNlabelString, msg,
		NULL);
	   XmStringFree( msg );
	   XtVaSetValues( xfer_b, 
		XmNlabelString, msg = XmStringCreateSimple("PUT"), NULL);
	   if( local_mode != 1 ) {
		local_mode = 1;
		refresh_cb( w, NULL, NULL );
	   }
	   break;
	default : /* No other items */
	   XtVaSetValues( msg_w,
		XmNlabelString, msg = XmStringCreateSimple("Internal Error"),
		NULL);
	   break;
   }
   XmStringFree( msg );
   return;
}

/* The transfer files button (either GET or PUT) callback */
void xfer_cb( w, client_data, cbs )
Widget w;
int client_data;
XmAnyCallbackStruct *cbs;
{
  XmString msg ;
  if( *szSelectedFiles ) {
   msg = XmStringCreateSimple( local_mode? 
		"Putting selected files": "Getting selected files");
   XtVaSetValues( msg_w, XmNlabelString, msg, NULL );
   XmStringFree( msg );
   switch( fork() ) {
	case -1: (void)fprintf(stderr, "Fork Failed");
		 XtVaSetValues( msg_w, XmNlabelString,
			msg = XmStringCreateSimple( "Fork failed" ), NULL );
		 XmStringFree( msg );
	case 0: /* Child */
	   { 
		szString av[64]; int argcount;
#ifdef DEBUG
		(void)printf("szSelectedFiles: ");
		EchoList( szSelectedFiles );
		{ char *ptr;(void)printf("on %s, port %s, dir %s\n",
			env_host?env_host:(ptr = getenv("FSP_HOST") ? ptr: "<none>"),
			env_port?env_port:(ptr = getenv("FSP_PORT") ? ptr: "<none>"),
			env_dir?env_dir:(ptr = getenv("FSP_DIR") ? ptr: "<none>") );}
#endif
		*av = local_mode?"fput":"fget";
		for( argcount = 0; szSelectedFiles[argcount]; argcount++ )
			av[argcount+1] = strdup(szSelectedFiles[argcount]);
		av[argcount+1] = NULL;
#ifdef DEBUG
		(void)printf("Argv: ");EchoList( av );
		if(envp) {(void)printf("Envp: ");EchoList(envp);}
		else (void)printf("No envp!\n");
#endif
		( local_mode ?
			(void)do_fput(++argcount, av, envp ):
			(void)do_fget(++argcount, av, envp ) );
		(void) close( 2 ); /* Shut off stderr */
		(void)kill( getpid(), 9 ); /* Commit suicide rather than exit() */
 	   }
		  break;
	default: /* Parent */ break;
   }
  } else { 
   msg = XmStringCreateSimple( "No Selection!");
   XtVaSetValues( msg_w, XmNlabelString, msg, NULL );
   XmStringFree( msg );
  }
  return;
}

void view_cb( w, client_data, cbs )
Widget w;
int client_data;
XmAnyCallbackStruct *cbs;
{
   int fd[2], pid;
   if( * szSelectedFiles ) {
	(void)pipe( fd );
	switch( pid = fork() ) {
		case -1: /* Fork failed */
			(void)fprintf( stderr, "Fork failed\n" );
			break;
		case 0: /* Child */
		  {
			char *av[64]; int argcount;
			(void)close( 0 ); (void)close( 1 ); (void)close( fd[0] );
			for( argcount = 0; szSelectedFiles[ argcount ]; argcount++ )
				av[argcount+1] = szSelectedFiles[ argcount ];
			av[ argcount + 1 ] = NULL;
#ifdef DEBUG
			(void)printf("About to go in xxxxcat: %d args.\nav:", argcount+1);
			EchoList( av );
			(void)printf("End of List.\n");
#endif
                        (void)dup2( fd[1], 1 );
			if( local_mode ) (void)execv( "/bin/cat", av );
			else		 (void)do_fcat( ++argcount, av, envp );
			exit( 0 );
		   } break;
		default: /* Parent */
		   {
			char buf[80]; char *szMsg;
			FILE *fp = fdopen( fd[0], "r" );
			(void)close( fd[1] );
			szMsg = (char *)malloc(2);
			(void)strcpy( szMsg, "\0");
			while( fgets( buf, 80, fp ) ) {
				szMsg = (char *)realloc( szMsg, strlen( szMsg ) + strlen(buf) + 1 );
				(void)strcat( szMsg, buf );
			}
#ifdef DEBUG
			(void)printf("buf is: %s\n============\n", szMsg );
#endif
			(void)close( fd[0] );
			(void)XpnPopupMsg( list_w, szMsg, "View" );
			XtFree( szMsg );
			kill( pid, 9 );
		   } break;
	}
   }
   else { 
	   XmString msg = XmStringCreateSimple( "No Current Selection !" );
	   XtVaSetValues( msg_w, XmNlabelString, msg, NULL );
	   XmStringFree( msg );
   }
}

void mkdir_cb( w, client_data, cbs )
Widget w;
int client_data;
XmAnyCallbackStruct *cbs;
{
   static Widget dialog;
   extern void make_d();
   XmString prompt = XmStringCreateSimple( "Enter Directory Name" );
   XmString xmsOkLabel = XmStringCreateSimple( "MKDIR" );
   Arg args[3];
   XtSetArg( args[0], XmNokLabelString, xmsOkLabel );
   XtSetArg( args[1], XmNautoUnmanage, False );
   XtSetArg( args[2], XmNselectionLabelString, prompt );
   dialog = XmCreatePromptDialog( list_w, "mkdir", args, 3 );
   XtAddCallback( dialog, XmNokCallback, make_d, local_mode );
   XtAddCallback( dialog, XmNcancelCallback, XtDestroyWidget, NULL );
   XtUnmanageChild( XmSelectionBoxGetChild( dialog, XmDIALOG_HELP_BUTTON ) );
   XmStringFree( prompt ); XmStringFree( xmsOkLabel );
   XtManageChild( dialog );
   XtPopup( XtParent( dialog ), XtGrabNone );
}
void rmdir_cb( w, client_data, cbs )
Widget w;
int client_data;
XmAnyCallbackStruct *cbs;
{
   XmString msg;
   if(*szSelectedFiles)
   {
        if( local_mode ) {
		(void)rmdir( *szSelectedFiles );
		msg = XmStringCreateSimple( "Removing Local Directory" );
		refresh_cb( list_w, NULL, NULL );
	}
	else {
		char *av[3];
		*av = "frmdir"; av[1] = *szSelectedFiles; av[2] = NULL;
		if( !fork() ) { (void)do_frmdir( 2, av, envp );exit(0); }
		msg = XmStringCreateSimple( "Removing Remote Directory" );
		refresh_cb( list_w, NULL, NULL );
	}
    } else
	msg = XmStringCreateSimple( "No Current Selection !" );
    XmStringFree( msg );
    return;
}

/* The CD button callback : double-click or not? call ask_dir */
void
cd_cb( w, client_data, cbs )
Widget w;
int client_data;
XmPushButtonCallbackStruct *cbs;
{
   static XtIntervalId id;
   extern void ask_dir();
   if( cbs->click_count == 1 )
	id = XtAppAddTimeOut( app, 200, ask_dir, False );
   if( cbs->click_count == 2 ) {
	XtRemoveTimeOut( id );
	ask_dir( True ); /* change_d ( *szSelectedFiles ) */
   }
   return;
}

/* Ask for a directory( popup a PromptDialog ) */
void ask_dir( double_click )
int double_click;
{
   extern void call_cd();
   if( ! double_click ) /* single click */
	change_d( *szSelectedFiles );
   else {	/* Double Click: We want to ask for an absolute directory */
	XmString prompt = XmStringCreateSimple( "Change to Directory:" );
	Arg arg;
	static Widget dialog;

	XtSetArg( arg, XmNselectionLabelString, prompt );
	dialog = XmCreatePromptDialog( list_w, "ChangeDir", &arg, 1 );
	XtAddCallback( dialog, XmNokCallback, call_cd, NULL );
	XtUnmanageChild( XmSelectionBoxGetChild( dialog, 
				XmDIALOG_HELP_BUTTON ));
	XtManageChild( dialog );
	XtPopup( XtParent(dialog), XtGrabNone );
   }
   return;
}

void call_cd( w, client_data, cbs )
Widget w;
int client_data;
XmSelectionBoxCallbackStruct *cbs;
{
   char *text;
   XmStringGetLtoR( cbs->value, XmSTRING_DEFAULT_CHARSET, &text );
   if( strcmp( text, "\0" ) ) change_d( text );
   XtFree( text );
   return;
}

/* perform a chdir() or set env_dir */
void change_d ( text )
char *text;
{
  XmString msg;
  char dummy[80], szMsg[80];
  if( text ) {
   if( local_mode ) { 
	if( chdir( text ) ) /* Attempt to chdir to last selected item,
					which is first on the list */
		(void)sprintf( szMsg, "Change dir to %s failed, staying at %s",
				text , getcwd( dummy, 80 ) );
	else
		(void)sprintf( szMsg, "Changing dir to %s", getcwd( dummy, 80));

    } else /* remote */ 
    {
	if( env_dir && *env_dir ) {
#ifdef DEBUG
		(void)printf("Remote Directory:\n");
#endif
		if( !strcmp( text, "." ) ) return;
		if( !strcmp( text, ".." ) ) {
			char *ptr = strrchr( env_dir, '/' );
#ifdef DEBUG
			(void)printf("cd up from %s, ptr is %s\n", env_dir, ptr);
#endif
			if( ptr )
			   *ptr = 0;
			if( !strcmp( env_dir, "\0" ) ) (void)strcpy( env_dir, "/" );
#ifdef DEBUG
			(void)printf("Env dir is now %s\n", env_dir );
#endif
		}
		else {
#ifdef DEBUG
			(void)printf("Dir is neither \".\" nor \"..\"\n");
#endif
			env_dir = realloc( env_dir, strlen(env_dir) + strlen( text ) +2 );
			if(strcmp(env_dir, "/")) (void)strcat( env_dir, "/" );
			(void)strcat( env_dir, text );
		}
	}
	else {
		env_dir = (char *) malloc( strlen( text ) + 2 );
		(void)strcpy( env_dir, "/" );
		(void)strcat( env_dir, text );
#ifdef DEBUG
		(void)printf("No envdir yet.. Setting it to %s\n", env_dir);
#endif
	}
	(void)sprintf( szMsg, "Changing dir to %s", env_dir );
    }
  } else
	(void)sprintf( szMsg, "No Current Selection!" );
  msg = XmStringCreateSimple( szMsg );
  XtVaSetValues( msg_w, XmNlabelString, msg, NULL );
  XmStringFree( msg );
  refresh_cb( list_w, NULL, NULL );
  return;
}

/* VERSION Button Callback: popup a Message Dialog showin local/remote vers */
void ver_cb( w, client_data, cbs )
Widget w;
int client_data;
XmAnyCallbackStruct *cbs;
{
   int pid;
   int fd[2];
   
   (void)pipe( fd ); /* Why did I poor fool lose a whole f***** hr for that? */
   switch( pid = fork() ) {
	case -1: /* Fork Failed */
		(void)fprintf(stderr,"Fork Failed\n");
		break;
	case 0: /* Child process */
		(void)close( fd[0] ); /* close read */
		(void)close ( 0 );
		(void)dup2( fd[1], 1 );
		(void)do_fver( 1, NULL, envp ); /* 1 is for remote */
		for(;;); /* wait till we get killed, that's fun */
		break;
	default: /* Parent */
	   {
		char buf[BUFSIZ]; char line[BUFSIZ];
		XmString msg; XmString cont;
		Arg args[3]; static Widget msg_d;
		FILE *fp;
		(void)close ( fd[1] );
		fp = fdopen( fd[0], "r" );
		(void)strcpy( buf, X_VERSION_STR );
		(void)strcat( buf, "\n" );
		while( fgets( line, BUFSIZ, fp ) ) {
			char *ptr;
			for(ptr = line; ptr = strchr(ptr, '\t'); *ptr = ' ');
			(void)strcat( buf, line );
		}
		(void)kill( pid, 9 );
#		ifdef DEBUG
		(void)printf("Buf is: %s\n", buf);
		(void)printf("=========\n");
#		endif /* DEBUG */
	 	buf[strlen( buf ) +1] = 0;
		msg = XmStringCreateLtoR( buf , XmSTRING_DEFAULT_CHARSET );
		cont = XmStringCreateSimple( "Continue" );
		XtSetArg( args[0], XmNokLabelString, cont );
		XtSetArg( args[1], XmNautoUnmanage, False );
		XtSetArg( args[2], XmNmessageString, msg );
		msg_d = XmCreateMessageDialog( list_w, "version", args, 3 );
		XtAddCallback( msg_d, XmNokCallback, XtDestroyWidget, NULL );
		XtUnmanageChild(XmMessageBoxGetChild(msg_d, XmDIALOG_HELP_BUTTON));
		XtUnmanageChild(XmMessageBoxGetChild(msg_d,XmDIALOG_CANCEL_BUTTON));
		XtManageChild( msg_d );
		XtPopup( XtParent( msg_d ), XtGrabNone );
		XmStringFree( cont );
		XmStringFree( msg );
		close(fd[0]);
	   } break;
    }
}

/* DEL button callback: remove local / remote server files */
void rm_cb (w, client_data, cbs )
Widget w;
int client_data;
XmPushButtonCallbackStruct *cbs;
{
   static XtIntervalId id;
   void ru_sure();
   if( cbs->click_count == 1 )
	id = XtAppAddTimeOut( app, 200, ru_sure, False );
   else if( cbs->click_count == 2 ) {
	XtRemoveTimeOut ( id );
	ru_sure( True );
   }
}

void ru_sure( double_click )
int double_click;
{
 extern void del_it();
 if( *szSelectedFiles) {
  if( double_click ) del_it();
  else { /* That's where the trouble comes. User single clicked. */
    static Widget dialog;
    int i;
    Arg args[4];
    XmString nuke = XmStringCreateSimple( "Nuke It All" );
    XmString dont_nuke = XmStringCreateSimple( "Don't Even Think About It" );
    XmString question; char szQuestion[BUFSIZ];

    (void)sprintf( szQuestion, "Do You Want To Nuke The Follwing Files:" );
    for( i = 0; szSelectedFiles[i]; i++ ) {
	(void)strcat( szQuestion, "\n" );
	(void)strcat( szQuestion, szSelectedFiles[i] );
    }
    question = XmStringCreateLtoR( szQuestion, XmSTRING_DEFAULT_CHARSET );

    XtSetArg( args[0], XmNokLabelString, nuke );
    XtSetArg( args[1], XmNcancelLabelString, dont_nuke );
    XtSetArg( args[2], XmNmessageString, question );
    XtSetArg( args[3], XmNautoUnmanage, True );

    dialog = XmCreateMessageDialog( list_w, "delete", args, 4 );

    XtAddCallback( dialog, XmNokCallback, del_it, NULL );
    /*XtAddCallback( dialog, XmNcancelCallback, XtDestroyWidget, NULL ); */

    XtUnmanageChild( XmMessageBoxGetChild( dialog , XmDIALOG_HELP_BUTTON ) );

    XtManageChild( dialog );
    XtPopup( XtParent( dialog ), XtGrabNone );

    XmStringFree( nuke );
    XmStringFree( dont_nuke );
    XmStringFree( question );
  }
 } else { XmString msg = XmStringCreateSimple( "No Selection" );
	  XtVaSetValues( msg_w, XmNlabelString, msg );
	  XmStringFree( msg );
 }
 return;
}
   

/* User Double-clicked / chose OK from AreYouSure? dialog */
void del_it( )
{
   XmString msg = XmStringCreateSimple( "Deleting selected files" );
      /* Are You Sure? YES! */
   XtVaSetValues( msg_w, XmNlabelString, msg, NULL );
   XmStringFree( msg );
   switch( fork() ) {
	case -1: (void)fprintf(stderr, "Fork failed!\n"); break;
	case 0: /* Child */
	  {
	    szString av[64];int i;
	    close(0); /* close stdin */
#ifdef DEBUG
	    (void)printf("Deleting ");
	    EchoList( szSelectedFiles );
#endif
	    for( i = 0; szSelectedFiles[i]; i++ )
		av[i+1] = strdup(szSelectedFiles[i]);
	    av[i+1] = NULL;
#ifdef DEBUG
	    *av = "?rm";
	    (void)printf("argv: ");EchoList(av);
	    if(envp) {(void)printf("envp: ");EchoList( envp );}
	    else (void)printf("No envp!\n");
#endif
	    if( local_mode ) { *av = "rm";
		(void)execv( "/bin/rm", av );
	    } else { *av = "frmcmd";
		(void)do_frm( ++i, av, envp );
	    }
	    (void)kill( getpid(), 9 );
	    break;
	  }
	default: refresh_cb( list_w, NULL, NULL ); break;
   }
   return;
}

/* REFRESH Button Callback( called from almost everywhere ): 
	update the list_w */
void refresh_cb ( w, client_data, cbs )
Widget w; 
int client_data;
XmAnyCallbackStruct *cbs;
{
   int fd[2];
   int pid;
   { 
	char *ptr;
	if( !env_host) {
		if(ptr = getenv("FSP_HOST")) env_host = strdup(ptr);
		else {
			XmString msg = XmStringCreateSimple( "No env_host !" );
			XtVaSetValues( msg_w, XmNlabelString, msg );
			XmStringFree( msg );
			return;
		}
	}
        if( !env_port) {
                if(ptr = getenv("FSP_PORT")) env_port = strdup( ptr );
                else {
                        XmString msg = XmStringCreateSimple( "No env_port !" );
                        XtVaSetValues( msg_w, XmNlabelString, msg );
                        XmStringFree( msg );
			return;
                }
	}
        if( !env_dir) {
                if(ptr = getenv("FSP_DIR")) env_dir = strdup( ptr );
                else env_dir = strdup("/");
        }
   }

   (void)pipe( fd );
   switch( pid = fork() ) {
	case -1: /* Fork failed */
	      (void)fprintf(stderr,"Fork Failed.\n");
	      break;
	case 0: /* Child process */
	      (void)close(fd[0]); /* close read side of pipe */
	      (void)close(0); /* close stdin */
	      (void)dup2( fd[1], 1 ); /* copy write side of pipe to stdout */
	      if( local_mode ) 
		(void)execl("/bin/ls", "ls", "-la", NULL);
	      else {
		szString av[3]; *av = strdup("fls"); av[1] = strdup("-la"); av[2] = NULL; 
		do_fls( 2, av, envp );
	      }
	      exit( 0 );
	      break;
	default: /* Parent process */
	      {
		char buf[BUFSIZ];
		XmString line;
		FILE *in;
		XmListDeleteAllItems( list_w ); lwposition = 0; /* empty list */
		(void)close( fd[1] ); /* close the read side */
		in = fdopen( fd[0], "r" ); /* make a stream off file descr */
		(void)fgets(buf, BUFSIZ, in); /* strip off the 1st line */
		while( fgets(buf, BUFSIZ, in) ) {
			buf[strlen(buf) -1] = 0; /* strip off the last char,
						   which should be '\n' */
			line = XmStringCreateSimple( buf );
			(void)XmListAddItem( list_w, line, lwposition++ );
			XmStringFree( line );
		}
		(void)fclose( in );
		(void)close( fd[0] );
		(void)kill( pid, 9 ); /* Clean up our process table */
	      } break;
   }
   return;
}

/* Extended Select Callback: called every single time the user clicks on the
   scrolled list widget */
   
/* Now this is a little bit lame: we're updataing the list everytime the
   user selects/deselects something on/from the Scrolled list. */
void select_cb(list_w, client_data, cbs) 
Widget list_w;
XtPointer client_data;
XmListCallbackStruct *cbs; /* CallBack Structure */
{
    int   i;char *buf;
    for ( i = 0; szSelectedFiles[i]; i++ ) /* Free the array */
	free( szSelectedFiles[i] );
    for (i = 0; i < cbs->selected_item_count; i++) {
          XmStringGetLtoR(cbs->selected_items[i], 
		XmSTRING_DEFAULT_CHARSET, &buf);
	  szSelectedFiles[i] = strdup( strrchr(buf, ' ')+1 );/* last word */
	  szSelectedFiles[i+1] = NULL;
	  XtFree( buf );
    }
#ifdef DEBUG
    for (i = 0; szSelectedFiles[i]; i++ ) 
	(void)printf("Selected File %d is %s.\n", i, szSelectedFiles[i]);
#endif
}

void make_d( w, loc_mode, cbs )
Widget w;
int loc_mode;
XmSelectionBoxCallbackStruct *cbs;
{
   XmString txt;
   char *dirname, szMsg[80];
   char *av[3];

   XmStringGetLtoR( cbs->value, XmSTRING_DEFAULT_CHARSET, &dirname );
   (void)sprintf( szMsg, "Making directory %s (%s)", dirname, 
			loc_mode?"local":"remote");
   if(!loc_mode) { *av = "fmkdir"; av[1] = dirname; av[2] = NULL; }
#ifdef DEBUG
   (void)printf("Making directory %s (%s).\n", dirname, loc_mode?"loc":"rem");
#endif
   if(loc_mode)
	(void)mkdir( dirname );
   else if( ! fork() )
	{ (void)do_fmkdir( 2, av, envp ) ; exit(0); }
   XtFree( dirname );
   XtVaSetValues( msg_w, XmNlabelString,
		txt = XmStringCreateSimple( szMsg ), NULL );
   XmStringFree( txt );
   XtDestroyWidget( w );
   return;
}

/* The callback that's called when user selectes OK from the Prompt Dialog 
   that's popped up when user selects Option-Host */
void set_host( w, client_data, cbs )
Widget w; /* our popup */
int client_data;
XmSelectionBoxCallbackStruct *cbs;
{
    XmString msg; /* entered line */
    char *host;
    char szMsg[80];
    /* Read what's written in TextField widget */
    XmStringGetLtoR( cbs->value, XmSTRING_DEFAULT_CHARSET, &host );
    (void)sprintf( szMsg, "Changing to server %s", host );
    if(env_host && env_host ) free( env_host );
    env_host = strdup( host );
#ifdef DEBUG
    (void)printf("Host is now %s.\n", host );
#endif
    XtFree( host );
    msg = XmStringCreateSimple( szMsg );
    XtVaSetValues( msg_w, XmNlabelString, msg, NULL );
    XmStringFree( msg );
    XtDestroyWidget( w );
    return;
}
void set_port( w, client_data, cbs )
Widget w; int client_data; XmSelectionBoxCallbackStruct *cbs;
{
    XmString msg; /* entered line */
    char *port;
    char szMsg[80];
    /* Read what's written in TextField widget */
    XmStringGetLtoR( cbs->value, XmSTRING_DEFAULT_CHARSET, &port );
    (void)sprintf( szMsg, "Changing to port %s", port );
    if( env_port && *env_port ) free( env_port );
    env_port = strdup( port );
    XtFree( port );
    msg = XmStringCreateSimple( szMsg );
    XtVaSetValues( msg_w, XmNlabelString, msg, NULL );
    XmStringFree( msg );
    XtDestroyWidget( w );
    return; /* Note that I don't check (yet?) if port is really an int */
}

void
XpnPopupMsg( w, szMsg, title )
Widget w;
char *szMsg;
char *title;
{
   XmString msg, cont;
   static Widget msg_d;
   Arg args[3];
   { char *ptr; for( ptr = szMsg; ptr = strchr( ptr+1, '\t' ); *ptr = ' '); }
   msg = XmStringCreateLtoR( szMsg , XmSTRING_DEFAULT_CHARSET );
   cont = XmStringCreateSimple( "Continue" );
   XtSetArg( args[0], XmNokLabelString, cont );
   XtSetArg( args[1], XmNautoUnmanage, False );
   XtSetArg( args[2], XmNmessageString, msg );
   msg_d = XmCreateMessageDialog( list_w, title?title:"message", args, 3 );
   XtAddCallback( msg_d, XmNokCallback, XtDestroyWidget, NULL );
   XtUnmanageChild(XmMessageBoxGetChild(msg_d, XmDIALOG_HELP_BUTTON));
   XtUnmanageChild(XmMessageBoxGetChild(msg_d,XmDIALOG_CANCEL_BUTTON));
   XtManageChild( msg_d );
   XtPopup( XtParent( msg_d ), XtGrabNone );
   XmStringFree( cont );
   XmStringFree( msg );
}

/* Little bit of code from Dan Heller's excellent book: O'Reilly Defnintive
   Guides to X Windows, Volume 6: Motif Programming, ch 15 i think( passwd.c )
*/
void
check_passwd(w, unused, cbs)
Widget        w;
XtPointer     unused;
XmTextVerifyCallbackStruct *cbs;
{
    char *new;
    static char *passwd;
    int len;

    if (cbs->reason == XmCR_ACTIVATE) {
	env_passwd = strdup( passwd );
	XtFree( passwd );
	XtDestroyWidget( XtParent(XtParent(w)) );
        return;
    }

    if (cbs->text->ptr == NULL) { /* backspace */
        cbs->endPos = strlen(passwd); /* delete from here to end */
        passwd[cbs->startPos] = 0; /* backspace--terminate */
        return;
    }

    if (cbs->text->length > 1) {
        cbs->doit = False; /* don't allow "paste" operations */
        return; /* make the user *type* the password! */
    }

    new = XtMalloc(cbs->endPos + 2); /* new char + NULL terminator */
    if (passwd) {
        strcpy(new, passwd);
        XtFree(passwd);
    } else
        new[0] = NULL;
    passwd = new;
    strncat(passwd, cbs->text->ptr, cbs->text->length);
    passwd[cbs->endPos + cbs->text->length] = 0;

    for (len = 0; len < cbs->text->length; len++)
        cbs->text->ptr[len] = '*';
}
