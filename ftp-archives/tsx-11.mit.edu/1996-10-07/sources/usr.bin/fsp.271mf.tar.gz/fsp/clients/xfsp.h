/* Written by Patrick Nguyen ( MegaFork ). 14th Nov. 1993. */
/* Last modified 24.11.93 */
#ifndef _XFSP_H
#define _XFSP_H
#include <Xm/Xm.h>

#define X_VERSION_STR "Local Version: Xm Motif FSP Client, written by Patrick Nguyen"
#define ABOUT_STR "X Motif FSP Client, written by Patrick Nguyen (MegaFork)"\
		  "\nLast Modified 28th November 1993.\nPlease read"\
		  " XmFSP.README."
typedef unsigned char BOOL; /* in Xmd.h ( X machine dependant include */
typedef char * szString;

/* The XFSP init function */
extern void start_fsp();

/* The menu callbacks */
extern void file_cb();
extern void options_cb();
extern void mode_cb();
extern void help_cb();

/* The Scrolled List widget selection callback + user `picked one' callback */
extern void select_cb();
extern void pickone_cb();

/* The buttons callbacks */
extern void xfer_cb();
extern void view_cb();
extern void mkdir_cb();
extern void rmdir_cb();
extern void rm_cb();
extern void change_d();	/* the function that chdir()'s or sets env_dir */
extern void  cd_cb();   /* the CD button's callback */
extern void ver_cb();
extern void refresh_cb();

/* The Convenience routine(s) written by Patrick Nguyen */
extern void XpnPopupMsg(); /* popup a msg dialog, given a msg ( Widget w, char *szMsg ) */


#endif /* _XFSP_H */ 
