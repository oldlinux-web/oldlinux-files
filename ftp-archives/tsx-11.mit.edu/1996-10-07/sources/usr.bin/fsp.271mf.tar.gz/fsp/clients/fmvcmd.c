    /*********************************************************************\
    *  Copyright (c) 1991 by Wen-King Su (wen-king@vlsi.cs.caltech.edu)   *
    *                                                                     *
    *  You may copy or modify this file in any manner you wish, provided  *
    *  that this notice is always included, and that you hold the author  *
    *  harmless for any loss or damage resulting from the installation or *
    *  use of this software.                                              *
    \*********************************************************************/
/*****************************************************************************\
 *	This hack has been written by Patrick Nguyen ( MegaFork )	     *
 *					<pnguyen@elde.epfl.ch>		     *
\*****************************************************************************/
#include "tweak.h"
#include "client_def.h"
#include "c_extern.h"
#include "bsd_extern.h"

extern char *env_passwd;

static int move_it PROTO2(char *, from,  char *,to)
{
  char *op1, *op2;
  UBUF *ub;
  char *ptr;

  op1 = util_abs_path(from);
  op2 = util_abs_path(to);
 
  ub = client_interact(CC_RNFR,0L, strlen(op1), (unsigned char *)op1+1, 0,
		       (unsigned char *)NULLP);
  if(ub->cmd == CC_ERR) {
    if( ptr = strrchr(from, '\n') )
	*ptr++ = 0;
    fprintf(stderr,"Can't move %s to %s: %s\n",from,to,ub->buf);
    free(op1);free(op2); return(-1);
  }
  ub = client_interact(CC_RNTO,0L, strlen(op2), (unsigned char *)op2+1, 0,
                       (unsigned char *)NULLP);
  if(ub->cmd == CC_ERR) {
    if( ptr = strrchr(to, '\n') )
        *ptr++ = 0;
    fprintf(stderr,"Can't move %s to %s: %s\n",from,to,ub->buf);
    free(op1);free(op2); return(-1);
  }
  free(op1);free(op2);
  return(0);
}

int 
#ifdef X_CLIENT
do_fmv
#else
main 
#endif /* X_CLIENT */
PROTO3(int, argc, char **, argv, char **, envp)
{
  int i;char to[BUFSIZ];
  env_client();
  if( argc-- <= 2 ) {(void)fprintf(stderr,
		   "usage: %s <source> <dest file>.\n"
		   "       %s <source> [file2] [..] <dest dir>.\n",
			*argv);
		    exit(1);}
  if(*env_passwd)
   (void)sprintf(to, "%s\n", argv[argc] );
  else (void)strcpy(to, argv[argc]);
  for(i=1; i< argc; ++i)
	move_it( argv[i] , to );

  client_done();
  
  exit(0);
}
