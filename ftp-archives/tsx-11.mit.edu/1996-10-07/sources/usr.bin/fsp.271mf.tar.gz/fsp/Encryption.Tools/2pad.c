/* Written by Patrick Nguyen 21st Oct 1993 */
/* Double pad encryption */
/* Unix stdin/stdout are opened in binary mode. */
/* Eats up 20 seconds for encr&&decr / meg on my linux box */
/* fgetc/putc shouldn't be the fastest part of the code ;) but it keeps the 
   code small and readable for almost ne1 */
#include <stdio.h>
#include <string.h>

void main(argc, argv) int argc;char **argv;
{
   int x,i=0,j=0;
   char *pad1 = (argv[1] ? argv[1] :"MegaFork is a Happy Forky");
   char *pad2 = (getenv("FSP_PORT")? getenv("FSP_PORT"):"* grmpf *");
   int len1 = strlen(pad1);
   int len2 = strlen(pad2);
   if(argc > 2) {
      (void)fprintf(stderr,"Usage: %s <key_one>\n",*argv);
      exit(1);
   }
   while( (x=fgetc( stdin ) ) != EOF ) {
     (void) putc( x ^ pad1[i] ^ pad2[j], stdout );
     i++;j++ ;
     i %= len1;j %=len2;
   }
   return;
}
