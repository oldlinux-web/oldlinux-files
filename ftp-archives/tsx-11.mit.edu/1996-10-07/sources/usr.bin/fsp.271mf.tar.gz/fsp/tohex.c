#include <stdio.h>
#include <ctype.h>
void
main (argc,argv,envp) char **argv; {
  (void)printf("%02X",atoi(*(argv+1)));
  return;
}
