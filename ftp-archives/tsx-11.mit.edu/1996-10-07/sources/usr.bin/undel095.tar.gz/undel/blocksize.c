#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>

int main(void)
{
  struct stat st;
  char *tmpfile, s[1024];
  FILE *f;
  int i;

  /* Make & open temporary file */
  tmpfile = tmpnam(NULL);
  if (tmpfile && (f = fopen(tmpfile, "w"))) {
    /* Make temporary file, 1K in size */
    for (i=0; i < 1024; i++) s[i]=1;
    fwrite((void *)s, 1, 1023, f);
    
    /* get stats */
    fflush(f);
    fstat(fileno(f), &st);
    fclose(f);
    unlink(tmpfile);

    printf("%d",(int) st.st_blocks);
  }
  else
    printf("1");
 
  return 0;
}
