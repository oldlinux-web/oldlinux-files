/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "global.h"
#include "editQ.h"
#include "lowlevel.h"
#include "settings.h"
#include "blocksize.h"

struct UserStruc proto;


/*
   Check if Userstruc `u' is already initialised, reset of not
   */
void UCheck(int i, struct UserStruc *u, int flag)
{
  int k;

  if (i != U_SIZE || u->check != 1)
    {
      u->q_blocks    = (flag == USER  ) ? STD_BQUOTA  : 
	               (flag == GLOBAL) ? GLOB_BQUOTA : 0;
      u->q_files     = (flag == USER  ) ? STD_FQUOTA  :
	               (flag == GLOBAL) ? GLOB_FQUOTA : 0;
      u->used_blocks = 0;
      u->used_files  = 0;
      for (k=0; k < CNUM; k++) { 
	u->first[k]  = 0;
	u->last[k]   = 0;
      }
      u->check       = 1;
    }
} /* UCheck */




/*
   Build temporary file, containing something like this :

   Quotas for user vdborght:
          blocks in use: 3269, limits: (14000)
          inodes in use: 500, limits: (1400)
	  
   Then invoke editor and update database.
   */
int EditQuota(uid_t uid, char *name, int flag)
{
  struct UserStruc user;
  char *tmpfile, s[255], *e;
  u_long blocks, files;
  FILE *f;
  int i=0, j=0;


  /* Get stats */
  switch (flag) {
  case (USER):
    {
      sprintf(s, "%s/DELD.userquota", DELDIR);
      f = OpenLock(s);
      i = FRead(f, &user, U_SIZE, OFFSET+(U_SIZE*(uid+1)));
      CloseUnlock(f);
      break;
    }
  case (GROUP):
    {
      sprintf(s, "%s/DELD.groupquota", DELDIR);
      f = OpenLock(s);
      i = FRead(f, &user, U_SIZE, U_SIZE*uid);
      CloseUnlock(f);
      break;
    }
  case (GLOBAL):
    {
      sprintf(s, "%s/DELD.userquota", DELDIR);
      f = OpenLock(s);
      i = FRead(f, &user, U_SIZE, OFFSET);
      CloseUnlock(f);
      break;
    }
  default:
  }

  /* Check for uninitialised struct if file doesn't exist */
  UCheck(i, &user, flag);

  if (PROTO == 0) {
    /* Make & open temporary file */
    tmpfile = tmpnam(NULL);
    f = fopen(tmpfile, "w");

    /* Write text to temporary file */
    switch (flag) {
    case (USER):    fprintf(f, "Quotas for user %s:\n", name);  break;
    case (GROUP):   fprintf(f, "Quotas for group %s:\n", name); break;
    case (GLOBAL):  fprintf(f, "Global quotas:\n");             break;
    default:
    }
    fprintf(f, "\tblocks in use: %ld, limits: (%ld)\n",  
	    user.used_blocks / BLOCK_ADJUST, user.q_blocks / BLOCK_ADJUST);
    fprintf(f, "\tinodes in use: %ld, limits: (%ld)\n",
	    user.used_files, user.q_files);
    fclose(f);
    
    /* Get `EDITOR' environment variable, call `EDITOR' or `vi' */
    e = getenv("EDITOR");
    if (e != NULL) {
      sprintf(s, "%s %s", e, tmpfile);
    }
    else {
      sprintf(s, "vi %s", tmpfile);
    }
    system(s);
    

    /* Get info from temporary file */
    i=j=0;
    f = fopen(tmpfile, "r");
    if (f != NULL)
      {
	fgets(s, 256, f);
	if (fgets(s, 256, f) != 0) i = sscanf(strchr(s,'('), "(%ld", &blocks);
	if (fgets(s, 256, f) != 0) j = sscanf(strchr(s,'('), "(%ld", &files);
	fclose(f);
	
	unlink(tmpfile);
      }
  }
  else {
    /* Copy proto_user data to user data */
    blocks = proto.q_blocks;
    files  = proto.q_files;
  }


  /* If all went OK, write data to database */
  if ((i>0 && j>0) || (PROTO==1))
    {
      switch (flag) {
      case (USER):
	{
	  sprintf(s, "%s/DELD.userquota", DELDIR);
	  f = OpenLock(s);
	  i = FRead(f, &user, U_SIZE, OFFSET+(U_SIZE*(uid+1)));
	  user.q_blocks = blocks * BLOCK_ADJUST;
	  user.q_files  = files;
	  user.check    = 1;
	  i = FWrite(f, &user, U_SIZE, OFFSET+(U_SIZE*(uid+1)));
	  CloseUnlock(f);
	  break;
	}
      case (GROUP):
	{
	  sprintf(s, "%s/DELD.groupquota", DELDIR);
	  f = OpenLock(s);
	  i = FRead(f, &user, U_SIZE, U_SIZE*uid);
	  user.q_blocks = blocks * BLOCK_ADJUST;
	  user.q_files  = files;
	  user.check    = 1;
	  i = FWrite(f, &user, U_SIZE, U_SIZE*uid);
	  CloseUnlock(f);
	  break;
	}
      case (GLOBAL):
	{
	  sprintf(s, "%s/DELD.userquota", DELDIR);
	  f = OpenLock(s);
	  i = FRead(f, &user, U_SIZE, OFFSET);
	  user.q_blocks = blocks * BLOCK_ADJUST;
	  user.q_files  = files;
	  user.check    = 1;
	  i = FWrite(f, &user, U_SIZE, OFFSET);
	  CloseUnlock(f);
	  break;
	}
      default:
      }
      return 0;
  }
  else {
    fprintf(stderr, "\n%s: Error while parsing temporary file, database NOT updated !\n\n", progname);
    return -1;
  }
}









