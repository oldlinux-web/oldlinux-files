/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include <grp.h>
#include <pwd.h>
#include <errno.h>

#include "global.h"
#include "getopt.h"
#include "call_handler.h"
#include "lowlevel.h"
#include "editQ.h"
#include "settings.h"

#ifndef EDDQUOTA_TIMER
#define EDDQUOTA_TIMER 0
#endif

extern int ALARM;
void ClientTimedOut();

int inQ=-1, outQ=-1;

int PROTO  = 0;
int ED_WHO = USER;

/* Name this program was called with */
char *progname = NULL;

/* Name of proto-user */
char *proto_user = NULL;


void ShowHelp()
{
  printf("\
The Undelete System, Version %s \n\
(C)1995, Peter Vanderborght\n\
\n\
Usage: %s [OPTION]... USER...\n\
\n\
  -p, --proto-user <user>   duplicate quotas of <user> for each username\n\
  -u, --user                edit user quotas (default)\n\
  -g, --group               edit group quotas\n\
      --global              edit global quotas\n\
      --help                display this help and exit\n\
      --version             output version information and exit\n\n",
VERSION, progname);
}


int ParseOptions(int argc, char **argv)
{
  int c,l;

  while (1)
    {
      int option_index = 0;
      static struct option long_options[] =
	{
	  {"proto-user", 1, 0, 'p'}, {"global", 0, 0, 'G'},
	  {"user", 0, 0, 'u'},       {"group", 0, 0, 'g'},
	  {"version", 0, 0, 'V'},    {"help", 0, 0, 'h'},
	  {0, 0, 0, 0}
	};
      
      c = getopt_long(argc, argv, "p:ug", long_options, &option_index);
      if (c == -1) break;
	
      switch (c)
	{
	case ('p'): PROTO=1;       
	  l = STRLEN(optarg);
          proto_user = (char *) malloc(l*sizeof(char));
          strcpy(proto_user, optarg);
	  break;
	case ('u'):
	  break;
	case ('g'): ED_WHO=GROUP; 
	  break;
	case ('G'): ED_WHO=GLOBAL; PROTO=0;
	  break;

	case ('V'): printf("The Undelete System, Version %s \n", VERSION);
	  return -1;
	case ('h'): ShowHelp();
	  return -1;	  
	
	default: printf("Try `%s --help' for more information.\n",progname);
	  return -1;
	}
    }
  
  return optind;
}



int SendRefresh(uid_t uid)
{
  struct msgtype msg;
  int i;

  msg.mtype = 30;
  sprintf(msg.mtext, "%ld,%d", (u_long) uid, ED_WHO);
  i = STRLEN(msg.mtext);

  i = SendMsg(outQ, &msg, i, IPC_NOWAIT); 

  return i;
}



int main(int argc, char *argv[])
{
  FILE *f;
  char s[255];
  int i=0, opt=0;
  uid_t uid=0;

  progname = basename(argv[0]);
  opt = ParseOptions(argc, argv);

  if (opt >= 0 && ((argc-opt > 0) || (ED_WHO==GLOBAL))) {
#ifndef DEBUG
    if (getuid()) {
      fprintf(stderr, "%s: permission denied\n", progname);
      exit(1);
    }
#endif

    ReadSettings();

    if (EDDQUOTA_TIMER) {
      signal(SIGALRM, ClientTimedOut);
      ALARM=EDDQUOTA_TIMER;
    }

    if (PROTO == 1) 
      {
	switch (ED_WHO) {
	case (USER): 
	  { 
	    struct passwd *pwd;
	    
	    pwd = getpwnam(proto_user);
	    if (pwd == NULL) {
	      fprintf(stderr, "%s: no such proto-user.\n", progname);
	      exit(1);
	    }
	    uid = pwd->pw_uid;
	    sprintf(s, "%s/DELD.userquota", DELDIR);
	    f = OpenLock(s);
	    i = FRead(f, &proto, U_SIZE, OFFSET+(U_SIZE*(uid+1)));
	    CloseUnlock(f);
	    break;
	  }
	case (GROUP): 
	  {
	    struct group *pwd;

	    pwd = getgrnam(argv[opt]);
	    if (pwd == NULL) {
	      fprintf(stderr, "%s: no such proto-group.\n", progname);
	      exit(1);
	    }
	    uid = pwd->gr_gid;
	    sprintf(s, "%s/DELD.groupquota", DELDIR);
	    f = OpenLock(s);
	    i = FRead(f, &proto, U_SIZE, U_SIZE*uid);
	    CloseUnlock(f);
	    break;
	  }
	}
	if (proto.check != 1 || i != U_SIZE) {
	  fprintf(stderr, 
		  "%s: proto-user not defined in database.\n", progname);
	  exit(1);
	}
      }
    	
    for (; (opt < argc) || (ED_WHO==GLOBAL); opt++)
      {
	switch (ED_WHO) {
	case (USER): 
	  { 
	    struct passwd *pwd;

	    pwd = getpwnam(argv[opt]);
	    if (pwd == NULL) {
	      fprintf(stderr, "%s: no such user.\n", progname);
	      exit(1);
	    }
	    uid = pwd->pw_uid;
	    break;
	  }
	case (GROUP): 
	  {
	    struct group *pwd;

	    pwd = getgrnam(argv[opt]);
	    if (pwd == NULL) {
	      fprintf(stderr, "%s: no such group.\n", progname);
	      exit(1);
	    }
	    uid = pwd->gr_gid;
	    break;
	  }
	}
	EditQuota(uid, argv[opt], ED_WHO);

	i = ContactHandler();
	if (i>=0) i = SendRefresh(uid);
	if (i>=0) i = EndInteraction(0);

	if (ED_WHO == GLOBAL) return abs(i);
      }
  }
  if (argc == 1) printf("Try `%s --help' for more information.\n",progname);

  return abs(i);
}








