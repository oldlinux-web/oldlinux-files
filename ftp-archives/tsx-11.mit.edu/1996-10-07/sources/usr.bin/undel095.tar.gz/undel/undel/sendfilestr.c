/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include <ctype.h>

#include "globundel.h"
#include "call_handler.h"
#include "checkpath.h"

int QUERY=0;

/*
   Check if path exists, create if not.
   Ask user for permission if INTERACT=1 and FORCE=0
   */
int CreatePath(char *s)
{
  struct msgtype msg;
  struct stat st;
  char dir[255], c[255];
  int i,k=0;

  strcpy(dir, s);
  i = strlen(dir);
  while (dir[i] !='/' && i>0) i--;
  if (i>0) {
    dir[i]=0;
    i = stat(dir, &st);
    if (i!=0) {
      if (FAST) return -1;
      if (QUERY<0) QUERY++;
      k = CreatePath(dir);
      if (k==0) {
	if (k==0)  k = mkdir(dir, 0777);
	if (k==-1 && !FAST)
	  fprintf(stderr, "%s: Cannot create directory %s, access denied.\n",
		  progname, dir);
      }
    }
    else {
	if (!QUERY && !RECONSTRUCT && !FORCE && !FAST) {
	  QUERY++;

	  /* Stop interacting with handler. This way there is no problem when
	     the user presses '^C'.
	     */
	  EndInteraction(FORCE | FAST);
	  printf("%s: %s does not exist !\n", progname, s);
	  printf("(C)reate, (U)ndelete to %s, (S)kip ? ", dir);
	  fflush(stdin); fscanf(stdin, "%s", c);
	  
	  /* Re-establish contact with the handler */
	  ContactHandler();
	  switch (tolower(c[0])) 
	    {
	    case ('c'):
	      break;
	    case ('u'):
	      msg.mtype = 12;
	      strcpy(msg.mtext, dir);
	      SendMsg(outQ, &msg, STRLEN(msg.mtext), IPC_NOWAIT);
	      return 1;
	      break;
	    default: 
	      return -2;
	    }
	}
	if (!QUERY && !RECONSTRUCT && FORCE && !FAST) {
	  msg.mtype = 12;
	  strcpy(msg.mtext, dir);
	  SendMsg(outQ, &msg, STRLEN(msg.mtext), IPC_NOWAIT);
	  return 1;
	}
      }
  }

  return k;
} /* CreatePath */



/*
   Send filename to deamon
   */
int SendFileStr(long type, char *cwd, char *str)
{
  struct msgtype msg;
  int l=0;

  QUERY=-1;

  if (str != NULL) {
    if (str[0] != '/') {
      sprintf(msg.mtext,"%s/%s",cwd,str);
    }
    else {
      strcpy(msg.mtext,str);
    }
  }
  else {
    strcpy(msg.mtext, cwd);
  }

  CheckPath(msg.mtext);
  if (CURRENT==0 || type==11) l = CreatePath(msg.mtext);

  if (l<0) return 0;

  msg.mtype = type;
  l = STRLEN(msg.mtext);
 
  return SendMsg(outQ, &msg, l, IPC_NOWAIT);
} /* SendFileStr */
