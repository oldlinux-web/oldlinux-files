/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "getopt.h"
#include "globundel.h"
#include "call_handler.h"

#ifndef UNDEL_TIMER
#define UNDEL_TIMER 0
#endif

extern int ALARM;
void ClientTimedOut();

int inQ=-1, outQ=-1;

int RENAME      = 0;
int FORCE       = 0;
int INTERACT    = 0;
int RECONSTRUCT = 0;
int CURRENT     = 0;
int ALL         = 0;
int FAST        = 0;

/* Name to rename to */
char *rename_string =NULL;

/* Name this program was called with */
char *progname;



void ShowHelp()
{
  printf("\
The Undelete System, Version %s \n\
(C)1995, Peter Vanderborght\n\
\n\
Usage: %s [OPTION]... PATH...\n\
\n\
  -f, --force           ignore nonexistent files, never prompt\n\
  -i, --interactive     prompt before any undelete\n\
  -r, --reconstruct     reconstruct nonexistent directories\n\
  -c, --current         undelete to current directory\n\
      --rename <fname>  undelete to alternative filename <fname>\n\
      --fast            speed it up, never prompt, no output\n\
      --help            display this help and exit\n\
      --version         output version information and exit\n\
\n\
  NOTE : Specifying `-f' AND `-i' will undelete all files that where deleted\n\
         from the current directory or any subdirectories.\n\n",
VERSION, progname);
}



int ParseOptions(int argc, char **argv)
{
  int c,l;

  while (1)
    {
      int option_index = 0;
      static struct option long_options[] =
	{
	  {"force", 0, 0, 'f'},
	  {"interactive", 0, 0, 'i'},
	  {"reconstruct", 0, 0, 'r'},
	  {"current", 0, 0, 'c'},
	  {"rename", 1, 0, 'R'},
	  {"version", 0, 0, 'V'},
	  {"help", 0, 0, 'h'},
#ifdef ENABLE_FAST
	  {"fast", 0, 0, 'F'},
#endif
	  {0, 0, 0, 0}
	};
      
      c = getopt_long(argc, argv, "rcfi", long_options, &option_index);
      if (c == -1) break;
	
      switch (c)
	{
	case ('f'): FORCE=1;
	  break;
	case ('i'): INTERACT=1;
	  break;
	case ('r'): RECONSTRUCT=1; 
	  break;
	case ('c'): CURRENT=1;
	  break;
	case ('R'): RENAME=1;
	  l = STRLEN(optarg);
	  rename_string = (char *) malloc(l*sizeof(char));
	  strcpy(rename_string, optarg);
	  break;
#ifdef ENABLE_FAST
	case ('F'): FAST=1;
	  break;
#endif
	  
	case ('V'): printf("The Undelete System, Version %s \n", VERSION);
	  return -1;
	case ('h'): ShowHelp();
	  return -1;	  
	
	default: fprintf(stderr, "Try `%s --help' for more information.\n",
			 progname);
	  return -1;
	}
    }
  
  return optind;
}



int main(int argc, char *argv[])
{
  int i=0, opt=0;
  pid_t p;

  progname = basename(argv[0]);
  opt = ParseOptions(argc, argv);

#ifdef ENABLE_FAST
  if (FAST && opt >= 0) {
    p = fork();
    if (p != 0) opt = -1;
  }
#endif

  if (UNDEL_TIMER) {
    signal(SIGALRM, ClientTimedOut);
    ALARM=UNDEL_TIMER;
  }

  if (opt >= 0 && (argc-opt > 0 || INTERACT==1)) 
    {
      i = ContactHandler();

      /* Check wether to undelete all files or override '-i' */
      if (INTERACT==1) 
	{
	  if (FORCE==1 && argc-opt > 0) {
	    INTERACT=0;
	  }
	  if (argc-opt==0) ALL=1;
	}

      if (i>=0) 
	i = (ALL) ? UndeleteAll() : UndeleteFiles(argc-opt,&argv[opt]);
      else
	fprintf(stderr, "%s: No deamon present.\n", progname);

      if (i>=0) i = EndInteraction(FAST);
    }
  
  if (argc == 1) {
    i = ContactHandler();
    if (i>=0) 
      i = StatFiles();
    else
      fprintf(stderr, "%s: No deamon present.\n", progname);
    
    fprintf(stderr, "Try `%s --help' for more information.\n",progname);
  }

  return (abs(i)%10);
}









