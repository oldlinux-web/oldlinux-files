/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globundel.h"
#include "call_handler.h"

#include <ctype.h>
#include <pwd.h>
#include <sys/shm.h>

/*
   Process input when user specified `-i' and no files
   */
int GetInput(char *cwd, char *shm, u_long n)
{
  u_long i, chk=0;
  char c[255];

  /* Close channel to deamon for safety */
  EndInteraction(0);

  c[0]=0;
  /* Ask user which files to undelete */
  for (i=0; (i < n && c[0] != 'a'); i++) {
    fprintf(stderr, "Undelete %s ? (Y)es, (N)o, (A)bort : ", &shm[256*i]);
    fscanf(stdin, "%s", c);
    c[0] = tolower(c[0]);
    if (c[0] != 'y') shm[256*i]=0;
    else          chk++;
  }

  if (chk == 0) return -1;

  /* Open channel to deamon */
  ContactHandler();
  i=0;
  while (chk > 0) {
    chk--;
    while (shm[256*i] == 0) i++;
    SendFileStr(10, cwd, &shm[256*i]);
  } 

  return 0;
}



/*
   Undelete all deleted files (when user specified `-i' (+ evt. `-f' and no 
   filenames)
   */
int UndeleteAll(void)
{
  struct msgtype msg;
  int shm_id, i;
  u_long n;
  char *shm, cwd[255];

  msg.mtype=15;
  SendMsg(outQ, &msg, 0, IPC_NOWAIT);

  i = RcvMsg(inQ, &msg, 256, 15, 0);
  if (i > 0) {
    i=0;
    sscanf(msg.mtext, "%d,%ld", &shm_id, &n);
    if (shm_id > 0) 
      {
	shm_id--;
	shm = shmat(shm_id, 0, 0);

	/* Get current working directory */
	getcwd(cwd, 255);

	/* Notify deamon if the file is to be undeleted to some other name */
	if (RENAME==1 || CURRENT==1)
	  SendFileStr(11, cwd, rename_string);
  
	if (!FORCE) {
	  if (!FAST) i=GetInput(cwd, shm, n);
	}
	else {
	  msg.mtype=21;
	  SendMsg(outQ, &msg, 0, IPC_NOWAIT);
	  SendFileStr(10, cwd, "*");
	}

	shmdt(shm);
      }
     else if (!FORCE && !FAST) {
      struct passwd *pwd;

      pwd = getpwuid(getuid());
      printf("%s: No files to undelete for user %s.\n\n", 
	     progname, pwd->pw_name);
    }
  }
  else if (!FAST) {
    i=0;
    printf("%s: Invalid response from deamon !\n", progname);
  }

  return i;
}
