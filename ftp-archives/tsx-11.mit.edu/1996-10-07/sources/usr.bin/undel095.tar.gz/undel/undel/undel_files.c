/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globundel.h"
#include "call_handler.h"
#include "checkpath.h"
#include "fnmatch.h"


#include <sys/shm.h>
#include <pwd.h>

int yesno();
extern int ABORT;

int shm_id;
char *shm, cwd[255];


/*
   Query deamon for list of deleted files
   */
int GetStat(void)
{
  struct msgtype msg;
#ifndef __USE_BSD
  char *mem;
#endif;
  int i, n;

  msg.mtype=15;
  SendMsg(outQ, &msg, 0, IPC_NOWAIT);

  i = RcvMsg(inQ, &msg, 256, 15, 0);

  if (i > 0) {
    sscanf(msg.mtext, "%d,%d", &shm_id, &n);
    if (shm_id > 0) 
      {
	shm_id--;
#ifndef __USE_BSD
	mem = shmat(shm_id, 0, 0);
	shm = (char *) malloc(256*n);
	memcpy(shm, mem, 256*n);

	msg.mtype = 16;
	SendMsg(outQ, &msg, 1, IPC_NOWAIT);
#else
	shm = shmat(shm_id, 0, 0);
#endif
      }
    i=n;
  }

  EndInteraction(FORCE | FAST);

  return i;
} /* GetStat */


/*
   Get rid of the shared memory block
   */
void EndStat(void)
{
  shmdt(shm);
} /* EndStat */



/*
   Display a list of deleted files
   */
int StatFiles(void)
{
  struct passwd *pwd;
  int i, n;
  
  if ((n = GetStat()) > 0)
    {
      pwd = getpwuid(getuid());
      if (n) {
	printf("Undeletable files for user %s :\n", pwd->pw_name);
	for (i=0; i < n; i++) printf("\t%s\n", &shm[i*256]);
	printf("\n");

	EndStat();
      }
      else
	fprintf(stderr, "%s: No files to undelete for user %s.\n\n", 
		progname, pwd->pw_name);
  }
  else
    fprintf(stderr, "%s: Invalid response from deamon !\n", progname);

  return 0;
} /* StatFiles */



/*
   Check for existence of given file, query for removal
   */
int CheckExist(char *s)
{
  struct stat st;

  if (!stat(s, &st)) 
    {
      fprintf(stderr,"%s: %s: File already exists, overwrite ? ", 
	      progname, basename(s));
      if (!yesno()) {
	s[0] = 0;
	return 0;
      }
      else
	unlink(s);
    }

  return 1;
} /* CheckExist */



/*
   Interact with user when `-i' specified
   */
int Interact(int c, char **argv)
{
  char *s;
  int check=0;
  int i,j,n;
  
  /* get list of deleted files from deamon */
  if ((n = GetStat()) >= 0) {
    if (n > 0)
      {
	s = malloc(c*256);
	
	/* Get full path for user specified files */
	for (i=0; i < c; i++) 
	  {
	    if (argv[i] != NULL) {
	      if (argv[i][0] != '/')
		sprintf(&s[256*i], "%s/%s", cwd, argv[i]);
	      else 
		strcpy(&s[256*i], argv[i]);
	      
	      CheckPath(&s[256*i]);
	    }
	  }	

	/* Check user specified filenames against list gotten from deamon */
	/* Prompt for every file, check if it already exists              */
	/* Set shm[256*i] (first char of filename ('/') to 0 if file isn't*/
	/* to be undeleted, set it to 1 if file is to be recovered        */
	for (i=0; (i<n) && (!ABORT); i++) {
	  if (shm[256*i] > 1)
	    for (j=0; (j<c) && (!ABORT); j++)
	      if (fnmatch(&s[256*j], &shm[256*i], 0)==0)
		{
		  fprintf(stderr,"%s: Undelete %s ? ", 
			  progname, basename(&shm[256*i]));
		  if (yesno() && CheckExist(&shm[256*i])) {
		    shm[256*i] = 1;
		    check++;
		  }
		  else 
		    shm[256*i] = 0;
		}
	}

	/* Open channel to deamon, transmit filenames of files to undelete */
	/* Close channel again */
	i=0;
	if (check && (ContactHandler() >= 0)) {
	  while (check) {
	    while (i<n && shm[256*i] != 1) i++;
	    shm[256*i]='/';
	    SendFileStr(10, cwd, &shm[256*i]);
	    check--;
	  }
	  EndInteraction(0);
	}

	EndStat();
	free(s);
      }
    else
      fprintf(stderr, "%s: No files to undelete for user.\n\n", progname);
  }
  else
    fprintf(stderr, "%s: Invalid response from deamon !\n", progname);

  return -10;
} /* Interact */



/*
   Undelete files ... (this procedure is called when at least 1 filename is
   specified on the command line
   */
int UndeleteFiles(int c, char **s)
{
  struct msgtype msg;
  int i;

  /* Get current working directory */
  getcwd(cwd, 255);
  
  /* Notify deamon if the file is to be undeleted to some other name */
  if (RENAME==1 || CURRENT==1)
    SendFileStr(11, cwd, rename_string);
  
  /* Do interaction with user */
  if (INTERACT) {
    if (FAST) return 0;
    return Interact(c, s);
  }
  else {
    if (FORCE) {
      msg.mtype = 23;
      SendMsg(outQ, &msg, 1, IPC_NOWAIT);
    }

    /* Transmit names of files to undelete */
    for (i=0; i<c; i++)
      if (s[i][0]) SendFileStr(10, cwd, s[i]);
  }

  return 0;
}






