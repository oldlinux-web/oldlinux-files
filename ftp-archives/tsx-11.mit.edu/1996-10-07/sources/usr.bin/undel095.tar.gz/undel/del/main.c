/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globdel.h"
#include "call_handler.h"
#include "filestack.h"

char *xmalloc();
int rm ();

extern char *pathname;
extern int pnsize;

extern void ReadPreferences();
extern int  GetCategory(char *);

char cwd[255];
int MAX_SIZE=0;

/*
   Push given file on stack or delete when `--nosave' was specified on 
   comand line
   */
int DelFile(char *s, struct stat *st)
{
  if (!NOSAVE && (!MAX_SIZE || st->st_blocks < MAX_SIZE) 
              && !S_ISLNK(st->st_mode))
    FPush(s);
  else
    return unlink(s);

  return 0;
} /* DelFile */



/*
   Pop files from stack and send them to deamon for `deletion'
   */
int RemoveDeletedFiles(void)
{
  char *str;
  int i=0,l, c;

  if (!NOSAVE && (l = FStackSize()) && ((i=ContactHandler()) >= 0)) {
    for (i=0; i < l; i++)
    {
      str = FPop();
      c = GetCategory(str);
      if (c)      
	SendFileStr(3, cwd, str, c);
      else
	unlink(str);
    }
    ClearFStack();
    EndInteraction(FORCE | FAST);
    return 0;
  }
  
  if (i<0) fprintf(stderr, "%s: No deamon present.\n", progname);

  return -1;
} /* RemoveDeletedFiles */



/*
   Delete `c' files given specified in array `s'
   */
int DeleteFiles(int c, char **s)
{
  int i,l;

  getcwd(cwd, 255);

  ReadPreferences();

  for (i=0; i<c; i++) {
    l = strlen(s[i]) - 1;
    while (l > 0 && s[i][l] == '/')
      s[i][l--] = '\0';

    l = strlen(s[i]);
    if (l + 1 > pnsize)
      {
	free(pathname);
	pnsize = 2 * (l + 1);
	pathname = xmalloc(pnsize);
      }
    strcpy (pathname, s[i]);
    rm();
  }

  return RemoveDeletedFiles();
} /* DeleteFiles */





