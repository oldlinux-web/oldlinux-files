/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "getopt.h"
#include "globdel.h"
#include "call_handler.h"

#ifndef DEL_TIMER
#define DEL_TIMER 0
#endif

extern int ALARM;
void ClientTimedOut(int);

int inQ=-1, outQ=-1;

int VERBOSE   = 0;
int NOSAVE    = 0;
int FORCE     = 0;
int INTERACT  = 0;
int RECURSIVE = 0;
int FAST      = 0;

/* Name this program was called with */
char *progname;


void ShowHelp()
{
  printf("\
The Undelete System, Version %s \n\
(C)1995, Peter Vanderborght\n\
\n\
Usage: %s [OPTION]... PATH...\n\
\n\
  -f, --force           ignore nonexistent files, never prompt\n\
  -i, --interactive     prompt before any removal\n\
  -v, --verbose         explain what is being done\n\
  -r, -R, --recursive   remove the contents of directories recursively\n\
      --nosave          delete without saving for undelete\n\
      --fast            speed it up, never prompt, no output\n\
      --help            display this help and exit\n\
      --version         output version information and exit\n\n",
VERSION, progname);
}


int ParseOptions(int argc, char **argv)
{
  int c;

  while (1)
    {
      int option_index = 0;
      static struct option long_options[] =
	{
	  {"force", 0, 0, 'f'},
	  {"interactive", 0, 0, 'i'},
	  {"recursive", 0, 0, 'r'},
	  {"nosave", 0, 0, 'n'},
	  {"verbose", 0, 0, 'v'},
	  {"version", 0, 0, 'V'},
	  {"help", 0, 0, 'h'},
#ifdef ENABLE_FAST
	  {"fast", 0, 0, 'F'},
#endif
	  {0, 0, 0, 0}
	};
      
      c = getopt_long(argc, argv, "vfiRr", long_options, &option_index);
      if (c == -1) break;
	
      switch (c)
	{
	case ('f'): FORCE=1; 
	  break;
	case ('i'): if (FORCE==0) INTERACT=1; 
	  break;
	case ('R'):
	case ('r'): RECURSIVE=1; 
	  break;
	  
	case ('n'): NOSAVE=1;
	  break;
	case ('v'): VERBOSE=1;
	  break;
	case ('V'): printf("The Undelete System, Version %s \n", VERSION);
	  return -1;
	case ('h'): ShowHelp();
	  return -1;	  
	
#ifdef ENABLE_FAST
	case ('F'): FAST=1;
	  break;
#endif

	default: printf("Try `%s --help' for more information.\n",progname);
	  return -1;
	}
    }
  
  return optind;
}



int main(int argc, char *argv[])
{
  int i=0, opt=0;
  pid_t p;

  progname = basename(argv[0]);
  opt = ParseOptions(argc, argv);

#ifdef ENABLE_FAST
  if (FAST && opt >= 0) {
    p = fork();
    if (p != 0) opt = -1;
  }
#endif

  if (DEL_TIMER) {
    signal(SIGALRM, ClientTimedOut);
    ALARM=DEL_TIMER;
  }

  if (opt >= 0 && argc-opt > 0) {
    i = DeleteFiles(argc-opt,&argv[opt]);
  }
  
  if (argc == 1) printf("Try `%s --help' for more information.\n",progname);

  return abs(i);
}








