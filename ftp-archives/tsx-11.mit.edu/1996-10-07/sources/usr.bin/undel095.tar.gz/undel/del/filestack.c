/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include <stdio.h>
#include <stdlib.h>
char *xrealloc();

#define STRLEN(x)        (strlen(x)+1)
extern char *progname;

char *Stack   =0;
unsigned int StackSize=0;
unsigned int StackBuf =0;


void ClearFStack(void)
{
  free(Stack);
  StackSize=0;
  StackBuf =0;
}


int FStackSize(void)
{
  return StackSize;
}



void FPush(char *s)
{
  int l;

  l = STRLEN(s);
  if (l > 256) {
    fprintf(stderr, "%s: %s: Path too long.\n", progname, s);
    return;
  }

  if (StackSize == StackBuf) {
    StackBuf += 10;
    Stack = xrealloc(Stack, 256*StackBuf);
  }

  strcpy(&Stack[256*StackSize], s);
  StackSize++;
}



char *FPop()
{
  if (StackSize) {
    StackSize--;
    return &Stack[256*StackSize];
  }

  return 0;
}





