/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "global.h"
#include "fnmatch.h"
#include "blocksize.h"

#include <pwd.h>

extern int MAX_SIZE;
extern char *progname;
char preference[CNUM+1][MAX_PREF_NUMBER][MAX_PREF_LENGTH];

int DEFAULT=1;

/*
   Process preferences file `~/.dpref' 
   */
void ReadPreferences()
{
  struct passwd *pwd;
  char *home, str[256];
  FILE *f;
  int i, j, c, n[CNUM+1];
  
  for (i=0; i <= CNUM; i++)
    for (j=0; j < MAX_PREF_NUMBER; j++)
      preference[i][j][0] = 0;

  home = getenv("HOME");
  if (!home) {  
    pwd = getpwuid(getuid());
    if (!pwd) {
      fprintf(stderr, "%s: Couldn't locate home directory.\n", progname);
      exit(1);
    }
    home = pwd->pw_dir;
  }

  for (i=0; i <= CNUM; i++) n[i]=0;
  sprintf(str, "%s/.dpref", home);
  f = fopen(str, "r");
  if (f)
    while (fgets(str, 256, f))
      if (str[0] != '#')
	if ((home = strchr(str,':'))) {
	  sscanf(str, "%d", &c);
	  if (c <= CNUM) {
	    i=0;
	    while (home[i] && n[c] < MAX_PREF_NUMBER) {
	      j=0;
	      i++;
	      while (home[i] && (home[i] != ';') && j < MAX_PREF_LENGTH) {
		if (home[i] != ' ' && home[i] != '\t' && home[i] != '\n')
		  preference[c][n[c]][j++] = home[i];
		i++;
	      }
	      preference[c][n[c]][j] = 0;
	      n[c]++;
	    }
	  }
	}
	else if (strstr(str,"MAX_SIZE") != NULL) {
	  char *c;
	  
	  c = strchr(str,'=');
	  sscanf(&c[1], "%d", &MAX_SIZE);
	  MAX_SIZE *= BLOCK_ADJUST;
	}
	else if (strstr(str,"DEFAULT") != NULL) {
	  char *c;
	  
	  c = strchr(str,'=');
	  sscanf(&c[1], "%d", &DEFAULT);
	}

  fclose(f);
} /* ReadPreferences */



/*
   Return category of given filespec `s'
   */
int GetCategory(char *s)
{
  int c=CNUM, i=0;

  while (c >= 0 && fnmatch(preference[c][i], s, 0))
    if (preference[c][i][0] && i < MAX_PREF_NUMBER)
      i++;
    else {
      i=0;
      c--;
    }

  if (c < 0) c=DEFAULT;

  return c;
}
