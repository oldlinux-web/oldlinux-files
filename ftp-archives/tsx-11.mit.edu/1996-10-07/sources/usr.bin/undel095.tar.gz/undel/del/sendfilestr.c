/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globdel.h"
#include "checkpath.h"


/*
   Add current working directory `cwd' to file `str' if necessary and send 
   this to deamon
   */
int SendFileStr(long type, char *cwd, char *str, int cat)
{
  struct msgtype msg;
  int l;

  if (str != NULL) {
    if (str[0] != '/') {
      sprintf(msg.mtext,"%s/%s",cwd,str);
    }
    else {
      strcpy(msg.mtext,str);
    }
  }
  else {
    strcpy(msg.mtext, cwd);
  }

  CheckPath(msg.mtext);
  
  msg.mtext[0] = cat;
  msg.mtype = type;
  l = STRLEN(msg.mtext);
  
  return SendMsg(outQ, &msg, l, IPC_NOWAIT);
} /* SendFileStr */




