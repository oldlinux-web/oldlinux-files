/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globrepq.h"
#include "lowlevel.h"
#include "settings.h"
#include "blocksize.h"

#include <grp.h>
#include <pwd.h>


/*
   Check if given UserStruc `u' is already initialised, reset it if not
   */
void UCheck(int i, struct UserStruc *u, int flag)
{
  int k;

  if (i != U_SIZE)
    {
      u->q_blocks    = (flag == USER  ) ? STD_BQUOTA  :
                       (flag == GLOBAL) ? GLOB_BQUOTA : 0;
      u->q_files     = (flag == USER  ) ? STD_FQUOTA  :
                       (flag == GLOBAL) ? GLOB_FQUOTA : 0;
      u->used_blocks = 0;
      u->used_files  = 0;
      for (k=0; k < CNUM; k++) {
	u->first[k]  = 0;
	u->last[k]   = 0;
      }
      u->check       = 0;
    }
} /* UCheck */



/*
   Read quota information from database
   */
int GetQuota(void)
{
  struct UserStruc global, *user=NULL, *group=NULL;
  struct passwd *pwd;
  struct group *grp;
  struct stat st;
  char s[255];
  off_t u_size=0, g_size=0;
  FILE *f;
  int i;

  ReadSettings();

  sprintf(s, "%s/DELD.userquota", DELDIR);
  stat(s, &st);
  f = OpenLock(s);

  i = FRead(f, &global, U_SIZE, OFFSET);
  UCheck(i, &global, GLOBAL);

  if (USER_Q || !GROUP_Q) {
    u_size  = st.st_size - OFFSET - U_SIZE;
    if (u_size > 0)
      {
	user = (struct UserStruc *) malloc(u_size);
	FRead(f, user, u_size, OFFSET+U_SIZE);

	u_size /= U_SIZE;
      }
    CloseUnlock(f);
  }


  if (GROUP_Q || !USER_Q) {
    sprintf(s, "%s/DELD.groupquota", DELDIR);
    stat(s, &st);
    f = OpenLock(s);
    
    g_size  = st.st_size;
    if (g_size > 0)
      {
	group = (struct UserStruc *) malloc(g_size);
	FRead(f, group, g_size, 0);
	
	g_size /= U_SIZE;
      }
    CloseUnlock(f);
  }

  if (u_size > 0) {
    printf("\
*** Report for user delete base quotas\n\
                Block limits\t             File limits\n\
User            used    hard\t            used    hard\n");
    for (i=0; i < u_size; i++)
      if (user[i].check==1 && 
	  (VERBOSE || user[i].used_files || user[i].q_files))
	{
	  pwd = getpwuid(i);
	  if (pwd)
	    printf("%-10s--%8ld%8ld\t\t%8ld%8ld\n", pwd->pw_name,
		   ( user[i].used_blocks / BLOCK_ADJUST) +
		   ((user[i].used_blocks % BLOCK_ADJUST) ? 1:0),
		   ( user[i].q_blocks    / BLOCK_ADJUST) +
		   ((user[i].q_blocks    % BLOCK_ADJUST) ? 1:0),
		   user[i].used_files,	user[i].q_files);
	  
	}
    printf("\n");
  }

  if (g_size > 0) {
    printf("\
*** Report for group delete base quotas\n\
                Block limits\t             File limits\n\
Group           used    hard\t            used    hard\n");
    for (i=0; i < g_size; i++)
      if (group[i].check==1 && 
	  (VERBOSE || group[i].used_files || group[i].q_files))
	{
	  grp = getgrgid(i);
	  if (grp)
	    printf("%-10s--%8ld%8ld\t\t%8ld%8ld\n", grp->gr_name,
		   ( group[i].used_blocks / BLOCK_ADJUST) +
		   ((group[i].used_blocks % BLOCK_ADJUST) ? 1:0),
		   ( group[i].q_blocks    / BLOCK_ADJUST) +
		   ((group[i].q_blocks    % BLOCK_ADJUST) ? 1:0),
		   group[i].used_files,	 group[i].q_files);
	}
    printf("\n");
  }

  printf("\
*** Report for global delete base quotas\n\
                Block limits\t             File limits\n\
                used    hard\t            used    hard\n\
            %8ld%8ld\t\t%8ld%8ld\n",
	 ( global.used_blocks / BLOCK_ADJUST) +	
	 ((global.used_blocks % BLOCK_ADJUST) ? 1:0),
	 ( global.q_blocks    / BLOCK_ADJUST) +
	 ((global.q_blocks    % BLOCK_ADJUST) ? 1:0),
	 global.used_files,	global.q_files);

  return 0;
}





