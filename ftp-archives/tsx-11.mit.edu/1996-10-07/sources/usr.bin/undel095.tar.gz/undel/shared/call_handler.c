/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "global.h"

extern int inQ, outQ;
extern char *progname;

void ClientTimedOut();

/*
   Read message queue id from file.
   */
int ReadQID(void)
{
  FILE *file;
  int qid;
  
  file = fopen(QIDFILE,"r");
  if (file != NULL) 
    {  
      fscanf(file,"%d\n",&qid);
      fclose(file);
    }
  else 
    {  
      fprintf(stderr,"%s : No deamon present.\n", progname);
      exit(1);  
    }
  
  return qid^12345;
}




/* 
   This is just a procedure to does nothing ...
   */
void EmptyProc(int sig)
{}

/*
   Contact the deamon, establish message queues and disable dangerous
   signals
   */
int ContactHandler(void)
{
  struct msqid_ds buf;
  struct msgtype msg;
  int i;

  signal(SIGINT,  EmptyProc);
  signal(SIGQUIT, ClientTimedOut);
  signal(SIGTSTP, ClientTimedOut);
  signal(SIGCONT, SIG_IGN);
  
  inQ = ReadQID();
  i = Connect(&inQ, &outQ);
  if (i == 0)
    {
      msg.mtype = 1;
      sprintf(msg.mtext, "%d", outQ);
      i = STRLEN(msg.mtext);
      i = SendMsg(inQ, &msg, i, IPC_NOWAIT);

      do {                               /* Wait for deamon to receive msg */
	msgctl(inQ, IPC_STAT, &buf);
      } while (buf.msg_qnum > 0);
    }

  return i;
}



/*
   Tell the deamon we're all done, re-enable dangerous signals
   */
int EndInteraction(int FORCE)
{
  struct msgtype msg;
  int i;
  
  msg.mtype = 2;
  i = SendMsg(outQ, &msg, 1, IPC_NOWAIT);
  
  do 
    {
      i = RcvMsg(inQ, &msg, 255, 0, 0);

      if (msg.mtype == 29 && i > 0 && !FORCE)
	fprintf(stderr, "%s: %s", progname, msg.mtext);
    }
  while (msg.mtype == 29 && i > 0);

  signal(SIGINT,  SIG_DFL);
  signal(SIGQUIT, SIG_DFL);
  signal(SIGTSTP, SIG_DFL);
  signal(SIGCONT, SIG_DFL);

  if (msg.mtype == 2 && i > 0) return 0;
  return -1;
}
