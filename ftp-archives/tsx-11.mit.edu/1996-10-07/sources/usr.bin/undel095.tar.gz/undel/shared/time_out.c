/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "global.h"
extern char *progname;

int PROGRAM_ID=0;

/*
   This function is called if the time period of a client expires.
   It will remove existing message queues.
   */
void ClientTimedOut(int sig)
{
  struct msqid_ds buf;

  if (inQ >= 0) msgctl(inQ,  IPC_RMID, &buf);
  if (outQ>= 0) msgctl(outQ, IPC_RMID, &buf);

  if (sig == SIGTSTP) {
    fprintf(stderr, "\n\
%s: This program does not support background switching%s ... exiting\n", 
	    progname, 
	    (PROGRAM_ID==DEL || PROGRAM_ID==UNDEL) ? ",\n\tuse `--fast'" : "");
  }
  else if (sig == SIGALRM)
    fprintf(stderr, "\n\
%s: Deamon timed out ! (Contact your system administrator)\n", 
	    progname);

  exit(0);
}
