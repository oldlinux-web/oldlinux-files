/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include <errno.h>
#include "global.h"

int ALARM=0;


/*
   Send message `msg' of size `size' over message queue `Q' and assert `flag'
   Also set alarm if necessary
   */
int SendMsg(int Q, struct msgtype *msg, int size , int flag)
{
  int i;

  if (ALARM) alarm(ALARM);
  i = msgsnd(Q, msg, size, flag);
  if (ALARM) alarm(0);

  return 1;
} /* SendMsg */



/*
   Read message `msg' of max. size `size' and message type `type' from message
   queue `Q' and assert `flag'
   Also set alarm if necessary and emulate MSG_EXCEPT if needed.
   */
int RcvMsg(int Q, struct msgtype *msg, int size, long type, int flag)
{
  int i=0;

  if (ALARM) alarm(ALARM);

#ifndef __USE_BSD
  if ((flag & MSG_EXCEPT) == MSG_EXCEPT)
    {
      flag ^= MSG_EXCEPT;
      
      do {
	i = msgrcv(Q, msg, size, 0, flag);
	if (msg->mtype == type) msgsnd(Q, msg, size, IPC_NOWAIT);
      } while (msg->mtype == type && i >= 0);
    }
  else 
#endif
    {
      i = msgrcv(Q, msg, size, type, flag);
    }

  if (ALARM) alarm(0);

  return i;
} /* ReceiveMsg */


/*
   Create message queue `Q2' to client/deamon if `Q1' is given.
   Also do basic handshaking.
   */
int Connect(int *Q1, int *Q2)
{
  int l;
  struct msgtype msg;
  struct msqid_ds buf;

  if (*Q1 == -1) return -1;

  *Q2 = msgget(IPC_PRIVATE, 00666);
  if (*Q2 == -1) return -1;

  msg.mtype = 1;
  sprintf(msg.mtext, "%d", *Q2);
  l = STRLEN(msg.mtext);
  l = SendMsg(*Q1, &msg, l, IPC_NOWAIT);

  if (l == -1)
    {
      msgctl(*Q2, IPC_RMID, &buf);
      return -1;
    }

  l = RcvMsg(*Q2, &msg, 255, 1, 0);

  if (msg.mtype == 1 && l >= 0) {
    sscanf(msg.mtext, "%d", Q1);
    return 0;
  }

  return -1;
} /* Connect */





  






