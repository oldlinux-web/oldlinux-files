/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "global.h"
#include "blocksize.h"

char *DELDIR =NULL;                /* Main directory, for quota files, ...   */
char *FILEDIR=NULL;                /* Where 'deleted' files will reside      */
int  COMPRESS=C_COMPRESS;          /* Compression level                      */
                                   /* Standard block quota for users.        */
int  STD_BQUOTA=(C_STD_BQUOTA * BLOCK_ADJUST); 
int  STD_FQUOTA=C_STD_FQUOTA;      /* Standard file quota for users.         */
                                   /* Standard global block quota.           */
int  GLOB_BQUOTA=(C_GLOB_BQUOTA * BLOCK_ADJUST);    
int  GLOB_FQUOTA=C_GLOB_FQUOTA;    /* Standard global file quota.            */

#define CHECK(x,y)      while ((x[y] == '\n') || (x[y] == '/')) \
			   {  x[y] = 0; y--;  }


/*
   Read settings from config file (if it exists)
   */
void ReadSettings(void)
{
  FILE *f;
  char str[255], *c;
  int i;

  f = fopen(CONFIGFILE,"r");
  if (f != NULL)
    while (fgets(str, 256, f) != NULL) {
      if (str[0] != '#')
	{
	  if (strstr(str,"DELDIR") != NULL) {
	    c = strchr(str,'=');
	    DELDIR = (char *) malloc(sizeof(char) * strlen(c));
	    sprintf(DELDIR, "%s", &c[1]);
	  }
	  else if (strstr(str,"FILEDIR") != NULL) {
	    c = strchr(str,'=');
	    FILEDIR = (char *) malloc(sizeof(char) * strlen(c));
	    sprintf(FILEDIR, "%s", &c[1]);
	  }
	  else if (strstr(str,"COMPRESS") != NULL) {
	    c = strchr(str,'=');
	    sscanf(&c[1], "%d", &COMPRESS);
	  }
	  else if (strstr(str,"STD_BQUOTA") != NULL) {
	    c = strchr(str,'=');
	    sscanf(&c[1], "%d", &STD_BQUOTA);
	    STD_BQUOTA *= BLOCK_ADJUST;
	  }
	  else if (strstr(str,"STD_FQUOTA") != NULL) {
	    c = strchr(str,'=');
	    sscanf(&c[1], "%d", &STD_FQUOTA);
	  }
	  else if (strstr(str,"GLOB_BQUOTA") != NULL) {
	    c = strchr(str,'=');
	    sscanf(&c[1], "%d", &GLOB_BQUOTA);
	    GLOB_BQUOTA *= BLOCK_ADJUST;
	  }
	  else if (strstr(str,"GLOB_FQUOTA") != NULL) {
	    c = strchr(str,'=');
	    sscanf(&c[1], "%d", &GLOB_FQUOTA);
	  }
	}
    }
  if (f != NULL) fclose(f);

  if (DELDIR == NULL) {
    DELDIR = (char *) malloc(sizeof(char) * STRLEN(C_DELDIR));
    strcpy(DELDIR, C_DELDIR);
  }
  if (FILEDIR == NULL) {
    FILEDIR = (char *) malloc(sizeof(char) * STRLEN(C_FILEDIR));
    strcpy(FILEDIR, C_FILEDIR);
  }

  i = strlen(DELDIR);  i--; CHECK(DELDIR, i);
  i = strlen(FILEDIR); i--; CHECK(FILEDIR,i);
}







