/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "global.h"


/*
   Remove `../' and `~/' from path, so we'll have a clean path
   */
void CheckPath(char *path)
{
  char str[255], *home;
  int l, pos=0, strpos=0;


  if (path[0] == '~' && (path[1] == '/' || path[1]==0)) {
    home = getenv("HOME");
    if (home && chdir(home)==0) {
      strcpy(str, getcwd(0,0));
      strpos = strlen(str);
      pos=2;
    }
  }


  l = strlen(path);
  while (pos <= l)
    {
      if (path[pos]=='/' && path[pos+1]=='.' && 
	  path[pos+2]=='.' &&path[pos+3]=='/')
	{
	  pos += 3;
	  while ((strpos > 0) && (str[strpos] != '/')) strpos--;
	  if (str[strpos] == '/') str[strpos]=0;
	}
      else if (path[pos]=='.' && path[pos+1]=='/') 
	{ 
	  pos +=2; 
	}
      else
	{
	  str[strpos] = path[pos];
	  strpos++;
	  pos++;
	}
    }

  while ((strpos > 0) && (str[strpos] == '/')) {
    str[strpos]=0;
    strpos--;
  }
  strcpy(path, str);  
} /* CheckPath */









