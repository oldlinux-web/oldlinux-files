/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "global.h"


#ifndef __USE_BSD
/*
   Emulate flock() as given by Linux
   */
int flock(int filedes, int flag)
{
  struct stat st;
  int i=0;

  switch (flag)
    {
    case (LOCK_EX): i = F_LOCK;  break;
    case (LOCK_UN): i = F_ULOCK;
    }

  fstat(filedes, &st);
  i = lockf(filedes, i, st.st_size); 

  return i;
}
#endif



/*
   Open & lock the file, given by the specified string
   */
FILE *OpenLock(char *s)
{
  FILE *f;

  f = fopen(s, "r+");
  if (f == NULL) f = fopen(s, "w+");
  flock(fileno(f), LOCK_EX);

  return f;
} /* OpenLock */



/*
   Unlock and close the file given by FILE *f
   */
void CloseUnlock(FILE *f)
{
  flock(fileno(f), LOCK_UN);
  fclose(f);
} /* CloseUnlock */



/*
   Read `n' bytes at position `offset' in file `f' and place them at
   memory location `ptr'
   */
int FRead(FILE *f, void *ptr, size_t n, long offset)
{
  int i;

  fseek(f, offset, SEEK_SET);
  i = fread(ptr, 1, n, f);
  if (i != n) 
    {
      /* CORRUPTED DATABASE !!! */
      return 0;
    }

  return i;
} /* Fread */



/*
   Write `n' bytes from memory location `ptr' into file `f' at position
   `offset'
   */
int FWrite(FILE *f, void *ptr, size_t n, long offset)
{
  int i;

  fseek(f, offset, SEEK_SET);
  i = fwrite(ptr, 1, n, f);

  return i;
} /* FWrite */




