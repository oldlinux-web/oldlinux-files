/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "global.h"
#include "getopt.h"
#include "call_handler.h"

#ifndef DQUOTA_TIMER
#define DQUOTA_TIMER 0
#endif

extern int ALARM;
void ClientTimedOut();

int GROUP_Q = 0;
int GetQuota(int, char **);

/* Name this program was called with */
char *progname;


void ShowHelp()
{
  printf("\
The Undelete System, Version %s \n\
(C)1995, Peter Vanderborght\n\
\n\
Usage: %s [OPTION]... [user|group]...\n\
\n\
  -u, --user            display user quota (default)\n\
  -g, --group           display group quota\n\
      --help            display this help and exit\n\
      --version         output version information and exit\n\n",
VERSION, progname);
}



int ParseOptions(int argc, char **argv)
{
  int c;

  while (1)
    {
      int option_index = 0;
      static struct option long_options[] =
	{
	  {"user", 0, 0, 'u'},
	  {"group", 0, 0, 'g'},
	  {"version", 0, 0, 'V'},
	  {"help", 0, 0, 'h'},
	  {0, 0, 0, 0}
	};
      
      c = getopt_long(argc, argv, "ugv", long_options, &option_index);
      if (c == -1) break;
	
      switch (c)
	{
	case ('g'): GROUP_Q=1;
	case ('u'):
	  break;
	  
	case ('V'): printf("The Undelete System, Version %s \n", VERSION);
	  return -1;
	case ('h'): ShowHelp();
	  return -1;	  
	
	default: printf("Try `%s --help' for more information.\n",progname);
	  return -1;
	}
    }
  
  return optind;
}



int main(int argc, char *argv[])
{
  int i=0, opt=0;

  progname = basename(argv[0]);
  opt = ParseOptions(argc, argv);

  if (DQUOTA_TIMER) {
    signal(SIGALRM, ClientTimedOut);
    ALARM=DQUOTA_TIMER;
  }

  if (opt >= 0) {
    if (ContactHandler() < 0) {
      fprintf(stderr, "%s: No deamon present.\n", progname);
      exit(1);
    }
    i = GetQuota(argc-opt, &argv[opt]);
    EndInteraction(0);
  }
  
  return abs(i);
}








