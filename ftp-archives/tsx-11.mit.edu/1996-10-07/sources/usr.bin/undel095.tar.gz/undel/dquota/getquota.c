/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "global.h"
#include "call_handler.h"

#include <errno.h>
#include <ctype.h>
#include <grp.h>
#include <pwd.h>

int inQ=-1, outQ=-1;
extern int GROUP_Q;
extern char *progname;


/*
   Determine if given string is strictly numeric, return 1 on success
   */
int Numeric(char *s)
{
  int i=0;

  while (s[i]) {
    if (!isdigit(s[i])) return 0;
    i++;
  }

  return 1;
}


/*
   Get quota information from deamon and display it.
   */
int GetQuota(int n, char **s)
{
  struct group *grp;
  struct passwd *pwd;
  struct msgtype msg;
  long q[4];
  gid_t gid;
  int i=0;
  char *uid_name, name[15];

  uid_name=(char *) malloc(256*n);

  msg.mtype = 20;
  if (n==0) {
    sprintf(msg.mtext, "%d,-1", GROUP_Q);
    SendMsg(outQ, &msg, STRLEN(msg.mtext), IPC_NOWAIT);
  }
  else {
    for (i=0; i < n; i++)
      {
	/* If user specified numeric uid or gid */
	if (Numeric(s[i])) {
	  /* Send info to deamon */
	  sprintf(msg.mtext, "%d,%s", GROUP_Q, s[i]);
	  SendMsg(outQ, &msg, STRLEN(msg.mtext), IPC_NOWAIT);
	  
	  /* Prepare output */
	  if (GROUP_Q) 
	    {
	      grp = getgrgid(atol(s[i]));
	      if (!grp)
		sprintf(&uid_name[256*i], "(no account) (gid %s): ", s[i]);
	      else
		sprintf(&uid_name[256*i], "%s (gid %s): ", grp->gr_name, s[i]);
	    }
	  else
	    {
	      pwd = getpwuid(atol(s[i]));
	      if (!pwd)
		sprintf(&uid_name[256*i], "(no account) (uid %s): ", s[i]);
	      else
		sprintf(&uid_name[256*i], "%s (uid %s): ", pwd->pw_name, s[i]);
	    }
	}
	/* If user specified username or groupname */
	else {
	  if (GROUP_Q) 
	    {
	      /* Get group struct */
	      grp = getgrnam(s[i]);
	      if (!grp) {
		fprintf(stderr, "%s: %s: Unknown group.\n", progname, s[i]);
		uid_name[256*i]=0;
	      }
	      else {
		/* Prepare output */
		sprintf(&uid_name[256*i], "%s (gid %ld): ",
			grp->gr_name, (long) grp->gr_gid);

		/* Send info to deamon */
	    	sprintf(msg.mtext, "%d,%ld", GROUP_Q, (long) grp->gr_gid);
		SendMsg(outQ, &msg, STRLEN(msg.mtext), IPC_NOWAIT);
	      }
	    }
	  else 
	    {
	      /* Get user struct */
	      pwd = getpwnam(s[i]);
	      if (!pwd) {
		fprintf(stderr, "%s: %s: Unknown user.\n", progname, s[i]);
		uid_name[256*i]=0;
	      }
	      else {
		/* Prepare output */
		sprintf(&uid_name[256*i], "%s (gid %ld): ",
			pwd->pw_name, (long) pwd->pw_uid);

		/* Send info to deamon */
	    	sprintf(msg.mtext, "%d,%ld", GROUP_Q, (long) pwd->pw_uid);
		SendMsg(outQ, &msg, STRLEN(msg.mtext), IPC_NOWAIT);
	      }
	    }
	}
      }
  }


  /* Display user's own quotas */
  if (n==0) {
    if (RcvMsg(inQ, &msg, 255, 0, 0) < 0) {
      fprintf(stderr, "%s: Deamon error : %s\n", progname, strerror(errno));
      return 1;
    }
    if (GROUP_Q) {
      if (msg.mtype == 20)
	i = sscanf(msg.mtext, "%ld,%ld,%ld,%ld,%ld", 
		   (long *) &gid, &q[0], &q[1], &q[2], &q[3]);
      while (i == 5 && (q[0] >= 0 || msg.mtype == 29)) {
	for (i=14; i>0 && name[i]=='/'; i--) name[i]=0;
	if (msg.mtype == 29) 
	  printf("%s: %s\n", progname, msg.mtext);
	else {
	  grp = getgrgid(gid);
	  if (grp) strcpy(name, grp->gr_name);
	  else     strcpy(name, "(no entry)");
	  printf("\
Delete base quotas for group %s (gid %ld):\n\
     blocks     quota     files     quota\n\
     %6ld    %6ld    %6ld    %6ld\n\
", name, (long) gid, q[0], q[1], q[2], q[3]);
	RcvMsg(inQ, &msg, 255, 0, 0);
	if (msg.mtype == 20) 
	  i = sscanf(msg.mtext, "%ld,%ld,%ld,%ld,%ld", 
		     (long *) &gid, &q[0], &q[1], &q[2], &q[3]);
	}
      }
    }
    else {
      if (msg.mtype == 29) 
	printf("%s: %s\n", progname, msg.mtext);
      else {
	gid = getuid();
	pwd = getpwuid(gid);
	if (!pwd) {
	  fprintf(stderr, 
		  "%s: SECURITY BREACH !!! User %ld not in passwd file !!!\n",
		  progname, (long) gid);
	  return 1;
	}
	i = sscanf(msg.mtext, "%ld,%ld,%ld,%ld", &q[0], &q[1], &q[2], &q[3]);
	printf("\
Delete base quotas for user %s (uid %ld):\n\
     blocks     quota     files     quota\n\
     %6ld    %6ld    %6ld    %6ld\n\
", pwd->pw_name, (long) gid, q[0], q[1], q[2], q[3]);
      }
    }
  }
  else
    /* n > 0 : User specified user(s) / group(s) */
    {
      for (i=0; i < n; i++)
	if (uid_name[256*i] != 0) {
	  RcvMsg(inQ, &msg, 255, 0, 0);
	  if (msg.mtype == 29) 
	    printf("%s: %s\n", progname, msg.mtext);
	  else {
	    sscanf(msg.mtext, "%ld,%ld,%ld,%ld", 
		       &q[0], &q[1], &q[2], &q[3]);
	    if (GROUP_Q)
	      printf("\
Delete base quotas for group %s\n\
     blocks     quota     files     quota\n\
     %6ld    %6ld    %6ld    %6ld\n\
", &uid_name[256*i], q[0], q[1], q[2], q[3]);
	    else
	      printf("\
Delete base quotas for user %s\n\
     blocks     quota     files     quota\n\
     %6ld    %6ld    %6ld    %6ld\n\
", &uid_name[256*i], q[0], q[1], q[2], q[3]);
	  }
	}
    }

  return 0;
}



