#ifndef _CONFIG_H_
#define _CONFIG_H_

/*
 * Special define for debugging ... compiling with `#define DEBUG' will
 * cause `deld' to produce status output and will also lightly change the
 * operation of the other programs.
 * NOTE: Using this define will cause `deld' to terminate after 3 calls.
 */
/*#define DEBUG*/


/* 
 * Compiling this with `#define ENABLE_FAST' will allow the user to use
 * `del --fast ...' what will cause `del' to fork and return control to the 
 * terminal immediately. All questions that would normally be asked will
 * now be answered with `No'.
 */
#define ENABLE_FAST


/*
 * If some error occurs in one of the client programs (more specifically, if
 * a client program crashes or gets killed at the wrong moment) the instance of
 * the deamon that interacts with that client will wait forever for a message 
 * from the client ... 
 * To resolve this problem, we will send an alarm signal after a certain amount
 * of time. This signal will be caught by the deamon and `free' the deamon from
 * it's wait state and allow it to exit normally.
 * DELD_TIMER specifies the number of seconds before an alarm will be delivered
 * (don't make this number too small, because you might risk terminating a 
 * deamon that is still working correctly)
 */
#define DELD_TIMER 100

/*
 * The problem explained in previous section may (it shouldn't but it may) also
 * occur in the other programs. If you want to enable the timers there also, 
 * set the corresponding define to non-zero.
 */
#define DEL_TIMER      0
#define UNDEL_TIMER    0
#define DQUOTA_TIMER   0
#define EDDQUOTA_TIMER 0


/*
 * Global settings, defined at compile-time.
 * Modify these for them to work correctly with your system.
 * CONFIGFILE = File containing all settings.
 * QIDFILE    = File containing queue id of deamon process.
 * C_DELDIR   = Default setting as where to put working files. (Quota file,...)
 * C_TMPDIR   = Default setting as where to put temporary files.
 * C_FILEDIR  = Default setting as where to put `deleted' files.
 * C_COMPRESS = Default setting as whether or not to compress files.
 *              0 = No Compression, 1-9 = Compress Gzip-level
 * REMARK : All C_* settings may be overridden in the CONFIGFILE.
 */
#define CONFIGFILE "/etc/config.deld"
#define QIDFILE    "/etc/DELD.qid"
#define C_DELDIR   "/var/undelete"
#define C_FILEDIR  "/var/undelete/files"
#define C_COMPRESS 3


/*
 * These defines will determine the owner,group and permissions of the 
 * `deleted' files.
 * D_OWNER     = numeric user id of the owner for the `deleted' files.
 * D_GROUP     = numeric group id of the group for the `deleted' files.
 * D_MODE      = mode_t that will determine the permissions on `deleted' files.
 * STD_BQUOTA  = Standard block quota for every user that hasn't got one yet.
 * STD_FQUOTA  = Standard file quota for every user that hasn't got one yet.
 * GLOB_BQUOTA = Standard global block quota.
 * GLOB_FQUOTA = Standard global file quota.
 * REMARK : All C_* settings may be overridden in the CONFIGFILE.
 */
#define D_OWNER  0
#define D_GROUP  0
#define D_MODE   00400

#define C_STD_BQUOTA  50
#define C_STD_FQUOTA  20
#define C_GLOB_BQUOTA 200
#define C_GLOB_FQUOTA 30


/*
 * Here, we will define the number and length of the filenames specified in
 * `~./dpref'
 *       MAX_PREF_NUMBER = Maximum number of filespecs for every category
 *       MAX_PREF_LENGTH = Maximum length of every filespec
 */
#define MAX_PREF_NUMBER 20
#define MAX_PREF_LENGTH 20

#endif



