/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globhand.h"
#include "db_ops.h"
#include "lowlevel.h"

extern u_long zipped_size;
extern FILE *u_f, *g_f, *f_f;

#define PTR(x,y)   (*((u_long *) &(x)+(y%2)))

/*
   Free disk space while user / group / global quota is exceeded
   */
void FreeSomeSpace(uid_t id, struct UserStruc *tmp, struct UserStruc *global, 
		   u_long *firstE, u_long *lastE, int f)
{
  struct stat st;
  struct UserStruc link;
  struct DelStruc  file;
  u_long ptr;
  char s[255];
  int i,c=0;

  while (((f/4==0) && (PTR(tmp->q_blocks,f) != 0) && 
		      (PTR(tmp->q_blocks,f) < PTR(tmp->used_blocks,f))) ||
	 ((f/4!=0) && (PTR(global->q_blocks,f) != 0) &&
		      (PTR(global->q_blocks,f) < PTR(global->used_blocks,f))))
    {
      if (!f && !tmp->first && c < CNUM)
	c++;

      ptr = (f / 4 == 0) ? tmp->first[c] : global->first[0];
      FRead(f_f, &file, D_SIZE, D_SIZE*(ptr-1));

      /* Unlink file when user given */
      if (f/2==0) {
	UnlinkStruct(f_f, tmp,    &file, 0, c);

	FRead(g_f, &link, U_SIZE, U_SIZE*file.gid);
	UnlinkStruct(f_f, &link,  &file, 2, 0);
	FWrite(g_f, &link, U_SIZE, U_SIZE*file.gid);
      }
      /* Unlink file when group given */
      else if (f/2==1) {
	FRead(u_f, &link, U_SIZE, OFFSET+(U_SIZE*(file.uid+1)));
	UnlinkStruct(f_f, &link,  &file, 0, c);
	FWrite(u_f, &link, U_SIZE, OFFSET+(U_SIZE*(file.uid+1)));

	UnlinkStruct(f_f, tmp,    &file, 2, 0);
      }
      /* Unlink file when global given */
      else if (f/2==2) {
	FRead(u_f, &link, U_SIZE, OFFSET+(U_SIZE*(file.uid+1)));
	UnlinkStruct(f_f, &link,  &file, 0, c);
	FWrite(u_f, &link, U_SIZE, OFFSET+(U_SIZE*(file.uid+1)));

	FRead(g_f, &link, U_SIZE, U_SIZE*file.gid);
	UnlinkStruct(f_f, &link,  &file, 2, 0);
	FWrite(g_f, &link, U_SIZE, U_SIZE*file.gid);
      }
      if (file.fname[0] & 0x0F)
	sprintf(s, "%s/%010ld.DELETED.gz", FILEDIR, file.dname);
      else
	sprintf(s, "%s/%010ld.DELETED", FILEDIR, file.dname);
      stat(s, &st);
      zipped_size = st.st_blocks;
      UnlinkStruct(f_f, global, &file, 4, 0);

      /*
	 Physically remove file from disk / DB
	 */
      i = unlink(s);
      file.fname[0] =0;
      file.uid      =0;
      file.gid      =0;
      file.prev_uid =0;
      file.next_gid =0;
      file.prev_gid =0;
      file.next_uid =0;
      file.next_file=0;
      file.prev_file=0;

      FWrite(f_f, &file, D_SIZE, D_SIZE*(ptr-1));

      if (*lastE > 0) { 
	FRead(f_f, &file, D_SIZE, D_SIZE*(*lastE-1));
	file.next_uid = ptr; 
	FWrite(f_f, &file, D_SIZE, D_SIZE*(*lastE-1));
      }
      else {
	*firstE   = ptr; 
      }
      *lastE = ptr;
    }

  if (f/2==0) {
    FWrite(u_f, tmp, U_SIZE, OFFSET+(U_SIZE*(id+1)));
  }
  else if (f/2==1) {
    FWrite(g_f, tmp, U_SIZE, U_SIZE*id);
  }
} /* FreeSomeSpace */



