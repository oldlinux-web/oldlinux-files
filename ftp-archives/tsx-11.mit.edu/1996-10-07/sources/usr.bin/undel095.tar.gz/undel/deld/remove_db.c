/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globhand.h"
#include "lowlevel.h"
#include "db_ops.h"

extern struct DelStruc *DFile;
extern struct UserStruc user;

extern FILE *u_f, *g_f, *f_f;


/*
   Remove file described by `DFile[n]' from category `cat' in filebase
   */
void RemoveDB(int n, int cat)
{
  struct UserStruc  user, global;
  struct GroupStruc group;
  struct DelStruc   empty;
  uid_t uid=DFile[n].uid;
  gid_t gid=DFile[n].gid;
  u_long Dnum, firstE, lastE;
  int i;

  /* Read necessary structures     */
  i = FRead(u_f, &firstE,  L_SIZE, L_SIZE);
  i = FRead(u_f, &lastE,   L_SIZE, L_SIZE*2);
  i = FRead(u_f, &global,  U_SIZE, OFFSET);
  UCheck(i, &global, GLOBAL);
  i = FRead(u_f, &user,    U_SIZE, OFFSET + U_SIZE*(DFile[n].uid+1));
  UCheck(i, &user, USER);
  i = FRead(g_f, &group,   U_SIZE, U_SIZE*(DFile[n].gid));
  UCheck(i, &group, GROUP);
  if (lastE > 0)
    i = FRead(f_f, &empty, D_SIZE, D_SIZE*(lastE-1));

  /* `Unlink' structure from user queue */
  if (n > 0) {
    Dnum = DFile[n-1].next_uid;
  }
  else {
    Dnum = user.first[0];
  }
  UnlinkStruct(f_f, &user, &DFile[n], 0, cat); 

  /* `Unlink' structure from group queue */
  UnlinkStruct(f_f, &group, &DFile[n], 2, 0); 

  /* `Unlink' structure from global queue */
  UnlinkStruct(f_f, &global, &DFile[n], 4, 0);

  if (lastE > 0) { 
    empty.next_uid = Dnum; 
    FWrite(f_f, &empty, D_SIZE, D_SIZE*(lastE-1));
  }
  else {
    firstE   = Dnum; 
  }
  lastE = Dnum;

  
  /* Write all structures back to the DB */
  FWrite(u_f, &firstE, L_SIZE, L_SIZE);
  FWrite(u_f, &lastE,  L_SIZE, L_SIZE*2);
  FWrite(u_f, &global, U_SIZE, OFFSET);
  FWrite(u_f, &user,   U_SIZE, OFFSET + U_SIZE*(uid+1));
  FWrite(g_f, &group,  U_SIZE, U_SIZE*gid);
  
  FWrite(f_f, &DFile[n],   D_SIZE, D_SIZE*(Dnum-1));
}

