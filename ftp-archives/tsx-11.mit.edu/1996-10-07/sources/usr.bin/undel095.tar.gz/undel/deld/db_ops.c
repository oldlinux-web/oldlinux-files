/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globhand.h"
#include "lowlevel.h"

extern u_long zipped_size;


/*
   Check if Userstruc `u' is already initialised, reset of not
   */
void UCheck(int i, struct UserStruc *u, int flag)
{
  int k;

  if (i != U_SIZE || u->check != 1)
    {
      u->q_blocks    = (flag == USER  ) ? STD_BQUOTA  : 
	               (flag == GLOBAL) ? GLOB_BQUOTA : 0;
      u->q_files     = (flag == USER  ) ? STD_FQUOTA  :
	               (flag == GLOBAL) ? GLOB_FQUOTA : 0;
      u->used_blocks = 0;
      u->used_files  = 0;
      for (k=0; k < CNUM; k++) { 
	u->first[k]  = 0;
	u->last[k]   = 0;
      }
      u->check       = 1;
    }
} /* UCheck */



/*
   Unlink structure 'link' from given queue
*/
#define DFprev(x)      (*((u_long *) (&(file->prev_uid)+x)))
#define DFnext(x)      (*((u_long *) (&(file->next_uid)+x)))

void UnlinkStruct(FILE *f, struct UserStruc *link, 
		  struct DelStruc *file, u_int c, u_int cat)
{
  struct DelStruc tmp;
  int k;

  if (DFprev(c) > 0) {
    FRead(f, &tmp, D_SIZE, D_SIZE*(DFprev(c)-1));
    *((u_long *) (&(tmp.next_uid)+c)) = DFnext(c);
    if (DFnext(c) == 0) link->last[cat] = DFprev(c);
    FWrite(f, &tmp, D_SIZE, D_SIZE*(DFprev(c)-1));
  } else {
    link->first[cat] = DFnext(c);
  }
  if (DFnext(c) > 0) {
    FRead(f, &tmp, D_SIZE, D_SIZE*(DFnext(c)-1));
    *((u_long *) (&(tmp.prev_uid)+c)) = DFprev(c);
    FWrite(f, &tmp, D_SIZE, D_SIZE*(DFnext(c)-1));
  }
  link->used_files--;

  if (c < 4) 
    link->used_blocks -= file->size;
  else
    link->used_blocks -= zipped_size;

  if (link->first[cat] == 0) link->last [cat] = 0;
  if (link->last [cat] == 0) link->first[cat] = 0;

  if (!link->used_files) {
    link->used_blocks = 0;
    for (k=0; k < CNUM; k++)
      {
	link->first[k]=0;
	link->last[k]=0;
      }
  }

  link->check=1;
} /* UnlinkStruct */



/*
   Construct filename to `delete' file to from DELD.counter and
   DELDIR.
   */
u_long GetFileName(char *fname)
{
  FILE *f;
  u_long count;

  sprintf(fname, "%s/DELD.counter", DELDIR);
  f = fopen(fname, "r+");

  if (f != NULL) 
    {
      flock(fileno(f), LOCK_EX);
      fread(&count, L_SIZE, 1, f);
      rewind(f);
      count++;
      fwrite(&count, L_SIZE, 1, f);
    }
  else 
    {
      count = (u_long) 1;
      f = fopen(fname, "w");
      flock(fileno(f), LOCK_EX);
      fwrite(&count, L_SIZE, 1, f);
    }
  flock(fileno(f), LOCK_UN);
  fclose(f);

  sprintf(fname, "%s/%010ld.DELETED", FILEDIR, count);
  return count;
} /* GetFileName */



