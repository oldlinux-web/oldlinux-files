/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globhand.h"
#include "lowlevel.h"
#include "fnmatch.h"
#include <sys/shm.h>

extern FILE *u_f, *f_f;

struct DelStruc *DFile = NULL;
struct UserStruc user;


/*
   Make a list of files owned by `Fowner' that are in the filebase
   */
void BuildFileList(int Fowner)
{
  int i,c,k=-1;

  i = FRead(u_f, &user, U_SIZE, OFFSET+(U_SIZE*(Fowner+1))); /*Get user stats*/
  if (i != U_SIZE || user.check != 1) 
    {
      /* CORRUPTED DATABASE OR INVALID UNDELETE OPERATION !!! */
      user.check = 1;
      return;
    }

  DFile = (struct DelStruc *) malloc(D_SIZE * user.used_files);

  /*Build file list*/
  for (c=0; c < CNUM, k+1 < user.used_files; c++)
    {
      while (user.first[c] == 0 && c < CNUM) c++;
      k++;

      i = FRead(f_f, &DFile[k], D_SIZE, (user.first[c]-1)*D_SIZE); 

      if (i != D_SIZE) 
	{
	  /* CORRUPTED DATABASE !!! */
	  free(DFile);
	  user.check = 0;
	}

      while ((DFile[k].next_uid > 0) && (k+1 < user.used_files))
	{
	  k++;
	  i = FRead(f_f, &DFile[k], D_SIZE, (DFile[k-1].next_uid-1)*D_SIZE);

	  if (i != D_SIZE) 
	    {
	      /* CORRUPTED DATABASE !!! */
	      user.check = 0;
	      free(DFile);
	      return;
	    }
	}
    }

  if (DFile[k].next_uid > 0)
    {
      /* WRONG NUMBER OF FILES IN DATABASE !!! */
    }

} /* BuildFileList */



/*
   Match file `s' to a file in our file list, return index in `F'
   */
int FindFile(char *s, u_long *F)
{
  char c;

  while (*F < user.used_files) { 
    c = DFile[*F].fname[0];
    DFile[*F].fname[0] = '/';

    if (fnmatch(s,DFile[*F].fname,0) != 0) {
      DFile[*F].fname[0] = c;
      *F += 1;
    }
    else {
      DFile[*F].fname[0] = c;
      return 1;
    }
  }

  return 0;
}


/*
   Build filelist, put it in a shared memory block, send shared memory id to
   client. 
   (undel uses this to get a list of deleted files)
   */
void StatFiles(void)
{
  struct shmid_ds buf;
  struct msgtype msg;
  int shm_id, i;
  char *shm, s[255];

  /*
     Open & lock needed files
     */
  sprintf(s, "%s/DELD.userquota", DELDIR);  /* Open & lock `DELD.userquota'  */
  u_f = OpenLock(s);
  sprintf(s, "%s/DELD.filebase", DELDIR);   /* Open & lock `DELD.filebase'   */
  f_f = OpenLock(s);


  if (user.check != 1) BuildFileList(Qowner);

  msg.mtype = 15;
  if (user.check == 1 && user.used_files > 0)
    {
      shm_id = shmget(IPC_PRIVATE, 256*user.used_files, 0666);
      shm    = shmat(shm_id, 0, 0);
      
      for (i=0; i < user.used_files; i++) {
	strcpy((&shm[i*256]+1), &(DFile[i].fname[1]));
	shm[256*i] = '/';
      }

      sprintf(msg.mtext, "%d,%ld", shm_id+1, user.used_files);
      SendMsg(outQ, &msg, STRLEN(msg.mtext), IPC_NOWAIT);
#ifndef __USE_BSD
      RcvMsg(inQ, &msg, 255, 16, 0);
#endif
      shmctl(shm_id, IPC_RMID, &buf);
    }
  else
    {
      strcpy(msg.mtext, "0,0");
      SendMsg(outQ, &msg, 4, IPC_NOWAIT);
    }


  CloseUnlock(u_f);
  CloseUnlock(f_f);
}
      





