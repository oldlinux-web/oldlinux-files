/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globhand.h"
#include "db_ops.h"
#include "lowlevel.h"
#include "freesomespace.h"

extern FILE *u_f, *g_f, *f_f;


/* Used for QSort in QuotaCheck */
int Comp(const void *a, const void *b)
{
  return (int)(*((uid_t *) a) - *((uid_t *) b));
} /* Comp */


/*
   Checks user / group / global quota.
   */
void QuotaCheck(struct UserStruc *global, u_long *firstE, u_long *lastE)
{
  struct UserStruc tmp;
  uid_t uid[DCount+1];
  gid_t gid[DCount+1];
  uid_t id;
  int i,k;

  /* Sort uid's and gid's so we don't double check anything */
  for (i=0; i <= DCount; i++) 
    {
      uid[i] = DelFile[i]->uid;
      gid[i] = DelFile[i]->gid;
    }
  qsort(&uid[0], DCount, sizeof(uid_t), &Comp);
  qsort(&gid[0], DCount, sizeof(uid_t), &Comp);
  
  /* Check quota's of all users involved in this call */
  id = uid[0]+1;
  for (i=0; i <= DCount; i++) 
    {
      if (id != uid[i])
	{
	  k=FRead(u_f, &tmp, U_SIZE, OFFSET+(U_SIZE*(uid[i]+1)));
	  UCheck(k, &tmp, USER);
	  if ((tmp.q_blocks > 0) && (tmp.used_blocks > tmp.q_blocks)) 
	      FreeSomeSpace(uid[i], &tmp, global, firstE, lastE, 0);
	  if ((tmp.q_files > 0) && (tmp.used_files > tmp.q_files)) 
	      FreeSomeSpace(uid[i], &tmp, global, firstE, lastE, 1);
	}
      id = uid[i];
    }

  /* Check quota's of all groups involved in this call */
  id = gid[0]+1;
  for (i=0; i <= DCount; i++) 
    {
      if (id != gid[i])
	{
	  k=FRead(g_f, &tmp, U_SIZE, U_SIZE*gid[i]);
	  UCheck(k, &tmp, GROUP);
	  if ((tmp.q_blocks > 0) && (tmp.used_blocks > tmp.q_blocks)) 
	      FreeSomeSpace(gid[i], &tmp, global, firstE, lastE, 2);
	  if ((tmp.q_files > 0) && (tmp.used_files > tmp.q_files)) 
	      FreeSomeSpace(gid[i], &tmp, global, firstE, lastE, 3);
	}
      id = gid[i];
    }
    
  /* Check global quota */
  if ((global->q_blocks > 0) && (global->used_blocks > global->q_blocks)) 
    FreeSomeSpace(0, &tmp, global, firstE, lastE, 4);
  if ((global->q_files > 0) && (global->used_files > global->q_files)) 
    FreeSomeSpace(0, &tmp, global, firstE, lastE, 5);
} /* QuotaCheck */



/*
   Check if quota of given user/group (or global) is within limits
   */
void RefreshQuota(char *msg)
{
  struct UserStruc global, tmp;
  u_long firstE, lastE;
  uid_t uid;
  char s[255];
  int t,k;

  /* Get uid & type from msg */
  sscanf(msg, "%lu,%d", (u_long *) &uid, &t);
  
  sprintf(s, "%s/DELD.userquota", DELDIR);  /* Open & lock `DELD.userquota'  */
  u_f = OpenLock(s);
  sprintf(s, "%s/DELD.filebase", DELDIR);   /* Open & lock `DELD.filebase'   */
  f_f = OpenLock(s);

  FRead(u_f, &firstE, L_SIZE, L_SIZE);
  FRead(u_f, &lastE,  L_SIZE, 2*L_SIZE);
  k=FRead(u_f, &global, U_SIZE, OFFSET);
  UCheck(k, &tmp, GLOBAL);

  if (t == USER) {
    k=FRead(u_f, &tmp, U_SIZE, OFFSET+(U_SIZE*(uid+1)));
    UCheck(k, &tmp, USER);
    if ((tmp.q_blocks > 0) && (tmp.used_blocks > tmp.q_blocks)) 
      FreeSomeSpace(uid, &tmp, &global, &firstE, &lastE, 0);
    if ((tmp.q_files > 0) && (tmp.used_files > tmp.q_files)) 
      FreeSomeSpace(uid, &tmp, &global, &firstE, &lastE, 1);
  }
  else if (t == GROUP) {
    sprintf(s, "%s/DELD.groupquota", DELDIR);
    g_f = OpenLock(s);
    
    k=FRead(g_f, &tmp, U_SIZE, U_SIZE*uid);
    UCheck(k, &tmp, GROUP);
    if ((tmp.q_blocks > 0) && (tmp.used_blocks > tmp.q_blocks)) 
      FreeSomeSpace(uid, &tmp, &global, &firstE, &lastE, 2);
    if ((tmp.q_files > 0) && (tmp.used_files > tmp.q_files)) 
      FreeSomeSpace(uid, &tmp, &global, &firstE, &lastE, 3);

    CloseUnlock(g_f);
  } 
  else {
    if ((global.q_blocks > 0) && (global.used_blocks > global.q_blocks)) 
      FreeSomeSpace(0, &tmp, &global, &firstE, &lastE, 4);
    if ((global.q_files > 0) && (global.used_files > global.q_files)) 
      FreeSomeSpace(0, &tmp, &global, &firstE, &lastE, 5);
  }

  FWrite(u_f, &firstE, L_SIZE, L_SIZE);
  FWrite(u_f, &lastE,  L_SIZE, 2*L_SIZE);
  FWrite(u_f, &global, U_SIZE, OFFSET);

  CloseUnlock(u_f);
  CloseUnlock(f_f);
}



