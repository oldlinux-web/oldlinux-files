/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include <errno.h>
#include "globhand.h"
#include "getopt.h"
#include "settings.h"
#include "call_handler.h"

/* Name this program was called with */
char *progname;

/* To determine if alarm() should be set */
extern int ALARM;

pid_t LAST_CHILD=0;
int inQ=-1, outQ=-1;
int CREATE=0;
int OVERWRITE=0;

#ifndef DEBUG
int VERBOSE=0;
#else
int VERBOSE=1;
#endif
int FORCE     = 0;
int INTERACT  = 0;

extern void TimedOut(int);


void DoLoop(void)
{
  int bytes;
#ifdef DEBUG
  int count=0;
#endif
  struct msgtype msg;

#ifndef DEBUG
  while (1)
#else
  while (count < 3) 
#endif
    {
#ifdef DEBUG
      count++;
#endif     
      bytes = RcvMsg(inQ, &msg, 255, 0, 0);
      if ((bytes >= 0) && (msg.mtype == 1)) 
	{
	  LAST_CHILD = fork();

#ifndef DEBUG
	  if (LAST_CHILD == 0)
#else
	  if (LAST_CHILD != 0) 
#endif
	    {
	      signal(SIGALRM, TimedOut);
	      ALARM=DELD_TIMER;

	      HandleCall(msg);
	      _exit(0);
	    }
	}
#ifdef __USE_BSD
      /*  
	 Linux will NOT ignore the SIGCHLD signal, even when set to SIG_IGN, 
	 therefore RcvMsg() will stop waiting for a message to arrive every 
	 time a child exits ... since this is not what we want, we will use 
	 signal() to cancel the signal, so we can return to the wait state.
	 */
      else 
	if ((bytes == -1) && (errno == 4)) 
	  {
	    signal(SIGCHLD, SIG_IGN);
	    if (VERBOSE) fprintf(stderr,"DELD - Canceled SIGCHLD ...\n");
#ifdef DEBUG
	    count--;
#endif
	  }
#endif
	else if (bytes >=0 && msg.mtype == 28)
	  {
	    struct msqid_ds buf;
	    int Qowner, Qgroup;

	    sscanf(msg.mtext, "%d", &outQ);
	    bytes = msgctl(inQ, IPC_STAT, &buf); /* Get owner id for         */
	    if (!bytes) {
	      Qowner = buf.msg_perm.cuid;        /* caller verification      */
	      Qgroup = buf.msg_perm.cgid;
	      
	      if (!Qowner || !Qgroup || Qowner == getuid()) return;
	    }
	  }
    }
} /* DoLoop */



void RemoveHandler(void)
{
  struct msqid_ds buf;
  struct msgtype msg;
  int l;

  outQ = ReadQID();
  msg.mtype = 28;

  ALARM=1;

  printf("%s: Removing deamon ...", progname);
  fflush(stdout);

  inQ = msgget(IPC_PRIVATE, 00666);
  if (inQ == -1) 
    {
      fprintf(stderr,"%s: Couldn't create message queue ...\n", progname);
      exit(1);
    }
  sprintf(msg.mtext, "%d", inQ);
  l = STRLEN(msg.mtext);
  SendMsg(outQ, &msg, l, IPC_NOWAIT);

  do {                                          /* Wait for deamon to exit */
    l = msgctl(outQ, IPC_STAT, &buf);
  } while (!l);

  msgctl(inQ, IPC_RMID, &buf);

  ALARM=0;
  printf(" done\n"); fflush(stdout);
} /* RemoveHandler */



void WriteQID(int qid)
{
  FILE *file;
  
  unlink(QIDFILE);
  file = fopen(QIDFILE,"w");
  if (file != NULL) 
    {  
      fprintf(file,"%d\n",qid^12345);
      fclose(file);
      chmod(QIDFILE, 00644);
    }
  else 
    {  
      fprintf(stderr,"%s: Unable to create QID file in /tmp ...\n", progname);
      exit(1);  
    }
} /* WriteQID */



void ShowHelp()
{
  printf("\
\n\
Usage: %s [OPTION]...\n\
\n\
  -f, --force           ignore errors, create non-existent directories\n\
  -i, --interactive     prompt for errors\n\
  -k, --kill            remove running deamon (root only)\n\
      --reload          restart deamon (root only)\n\
      --help            display this help and exit\n\
      --version         output version information and exit\n\n",
progname);
}



int ParseOptions(int argc, char **argv)
{
  int c;

  while (1)
    {
      int option_index = 0;
      static struct option long_options[] =
	{
	  {"force", 0, 0, 'f'},
	  {"interactive", 0, 0, 'i'},
	  {"kill", 0, 0, 'k'},
	  {"reload", 0, 0, 'r'},
	  {"version", 0, 0, 'V'},
	  {"help", 0, 0, 'h'},
	  {0, 0, 0, 0}
	};
      
      c = getopt_long(argc, argv, "kfi", long_options, &option_index);
      if (c == -1) break;
	
      switch (c)
	{
	case ('f'): FORCE=1; 
	  break;
	case ('i'): if (FORCE==0) INTERACT=1; 
	  break;

	case ('r'): 
#ifndef DEBUG
	  if (!getuid())
#endif
	    {
	      RemoveHandler();
	      printf("%s: Restarting deamon ...\n", progname);
	    }
	  break;
	case ('k'): RemoveHandler();
	  return -1;
	  
	case ('V'): printf("The Undelete System, Version %s \n", VERSION);
	  return -1;
	case ('h'): ShowHelp();
	  return -1;	  
	
	default: printf("Try `%s --help' for more information.\n",progname);
	  return -1;
	}
    }
  
  return optind;
}


void ShowBanner(void)
{
  printf("\
The Undelete System version %s, Copyright (C) 1995 Peter Vanderborght\n\
The Undelete System comes with ABSOLUTELY NO WARRANTY.\n\
This is free software, and you are welcome to redistribute it\n\
under certain conditions; see COPYING for details.\n\n", VERSION);

  fflush(stdout);
}


int main(int argc, char *argv[])
{
  int c=0;

  ShowBanner();
  progname = basename(argv[0]);

#ifndef DEBUG
  if (getuid()) {
    printf("%s: Must be super-user.\n", progname);
    exit(1);
  }
#endif

  if (ParseOptions(argc, argv) < 0) exit(0);

  ReadSettings();
#ifdef DEBUG
  if (CheckSettings()) {
#else
  if ((c=CheckSettings()) && !fork()) {
#endif
    inQ = msgget(IPC_PRIVATE, 00666);
    if (inQ == -1) 
      {
	fprintf(stderr,"%s: Couldn't create message queue ...\n", progname);
	exit(1);
      }
  
    WriteQID(inQ);
    
    signal(SIGCHLD, SIG_IGN);
    DoLoop();
    
    exitproc(0);
  }

  if (c) printf("%s: Deamon is now activated.\n", progname);
  return 0;
} /* main */







