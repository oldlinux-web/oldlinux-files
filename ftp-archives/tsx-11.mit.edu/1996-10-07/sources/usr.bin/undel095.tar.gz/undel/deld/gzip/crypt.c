/* crypt.c (dummy version) -- do not perform encryption
 * Hardly worth copyrighting :-)
 */
#ifdef RCSID
static char rcsid[] = "$Id: undel.tar,v 1.15 1995/04/11 20:00:42 vdborght Exp $";
#endif
