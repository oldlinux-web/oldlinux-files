/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include <ctype.h>
#include "globhand.h"
#include "copy_access.h"

int CreatePath(char *);


#define CHECK(x,y)      while ((x[y] == '\n') || (x[y] == '/')) \
			   {  x[y] = 0; y--;  }


/*
   Create given directory, prompt for input if required
   */
int MakeDir(char s[256])
{
  char c,a;
  int i;

  i = strlen(s)-1; CHECK(s,i); s[i+1]='/';

  if (INTERACT) {
    fprintf(stderr, 
	    "%s: Directory %s doesn't exist, create ? (Y/N) : ", progname, s);
    fflush (stderr);
    c = a = tolower(getchar());
    
    while (c != EOF && c != '\n')
      c = getchar ();
    
    if (a == 'y') {
      if (CreatePath(s) != 0) {
	fprintf(stderr, 
		"%s: Couldn't create: Access Denied\n", progname);
	return 0;
      }
    }
    else
      return 0;
    
    return 1;
  }
  else if (FORCE) {
    if (CreatePath(s) != 0) {
      fprintf(stderr, 
	      "%s: Couldn't create: Access Denied\n", progname);
      return 0;
    }
    return 1;
  }
  else {
    fprintf(stderr, 
	    "%s: Directory %s doesn't exist, exiting ...\n", progname, s);
    return 0;
  }
}



/*
   Check if settings are within normal parameters, correct errors
   */
int CheckSettings(void)
{
  struct stat st;
  int i=1;

  if (COMPRESS < 0) COMPRESS=0;
  if (COMPRESS > 9) COMPRESS=9;
  STD_BQUOTA  = abs(STD_BQUOTA);
  STD_FQUOTA  = abs(STD_FQUOTA);
  GLOB_BQUOTA = abs(GLOB_BQUOTA);
  GLOB_FQUOTA = abs(GLOB_FQUOTA);

  Qowner = getuid();
  Qgroup = getgid();

  if (!(stat(DELDIR, &st)==0))       i=MakeDir(DELDIR);
  stat(DELDIR, &st);
  if (i && !AccessOK(&st)) {
    i=0;
    fprintf(stderr, "%s: %s: Access Denied\n", progname, DELDIR);
  }

  if (i && !(stat(FILEDIR, &st)==0)) i=MakeDir(FILEDIR);
  stat(FILEDIR, &st);
  if (i && !AccessOK(&st)) {
    i=0;
    fprintf(stderr, "%s: %s: Access Denied\n", progname, FILEDIR);
  }

  Qowner = -1;
  Qgroup = -1;

  return i;
}



