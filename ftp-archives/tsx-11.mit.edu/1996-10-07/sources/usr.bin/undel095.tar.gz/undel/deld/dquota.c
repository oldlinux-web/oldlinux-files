/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globhand.h"
#include "copy_access.h"
#include "lowlevel.h"
#include "db_ops.h"
#include "blocksize.h"


/*
   Read quota information from database and send it to client 
   (used by dquota)
   */
void GetQuota(char *s)
{
  struct UserStruc struc;
  struct msgtype msg;
  int GROUP_Q;
  long uid;
  FILE *f;
  int i,k;

  sscanf(s, "%d,%ld", &GROUP_Q, (long *) &uid);

  msg.mtype = 20;
  if (GROUP_Q) 
    {
      sprintf(s, "%s/DELD.groupquota", DELDIR);
      f = OpenLock(s);
      if (uid < 0) {
	free(groups);
	nr_of_groups=0;
	in_group(0);
	if (nr_of_groups > 0) {
	  for (i=0; i < nr_of_groups; i++) {
	    k = FRead(f, &struc, U_SIZE, U_SIZE*groups[i]);
	    UCheck(k, &struc, GROUP);

	    sprintf(msg.mtext, "%ld,%ld,%ld,%ld,%ld", (long) groups[i], 
		    struc.used_blocks / BLOCK_ADJUST, 
		    struc.q_blocks    / BLOCK_ADJUST, 
		    struc.used_files,  struc.q_files);
	    SendMsg(outQ, &msg, STRLEN(msg.mtext), IPC_NOWAIT);
	  }
	}
	strcpy(msg.mtext, "0,-1,0,0,0");
	SendMsg(outQ, &msg, STRLEN(msg.mtext), IPC_NOWAIT);
      }
      else {
	if (!in_group(uid)) {
	  SendError("Permission denied.");
	  CloseUnlock(f);
	  return;
	}

	k = FRead(f, &struc, U_SIZE, U_SIZE*uid);
	UCheck(k, &struc, GROUP);
	
	sprintf(msg.mtext, "%ld,%ld,%ld,%ld", 
		struc.used_blocks / BLOCK_ADJUST, 
		struc.q_blocks    / BLOCK_ADJUST, 
		struc.used_files,  struc.q_files);
	SendMsg(outQ, &msg, STRLEN(msg.mtext), IPC_NOWAIT);
      }
    }
  else 
    {
      if (uid < 0) uid = Qowner;
      else if (!in_group(0)) {
	SendError("Permission denied.");
	return;
      }

      sprintf(s, "%s/DELD.userquota", DELDIR);
      f = OpenLock(s);

      k = FRead(f, &struc, U_SIZE, OFFSET+(U_SIZE*(uid+1)));
      UCheck(k, &struc, USER);
      
      sprintf(msg.mtext, "%ld,%ld,%ld,%ld",
	      struc.used_blocks / BLOCK_ADJUST, 
	      struc.q_blocks    / BLOCK_ADJUST, 
	      struc.used_files,  struc.q_files);
      SendMsg(outQ, &msg, STRLEN(msg.mtext), IPC_NOWAIT);
    }

  CloseUnlock(f);
}




