/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globhand.h"
#include "copy_access.h"
#include "filelist.h"
#include "lowlevel.h"

extern struct DelStruc *DFile;
extern struct UserStruc user;
int RemoveDB(int, int);
int Gzip(int, char *, int);

FILE *u_f, *g_f, *f_f;
char *rename_string = NULL;
u_long zipped_size=0;
int FIRSTERROR=1;
int RENAME_DIR=0;
int SCOPE=0;


/*
   Check if path exists, create if not.
   */
int CreatePath(char *s)
{
  struct stat st;
  char dir[255];
  int i,k=0;
  
  strcpy(dir, s);
  i = strlen(dir);
  while (dir[i] !='/' && i>0) i--;
  if (i>0 || dir[i]=='/') {
    if (i) 
      dir[i]=0;
    else
      dir[1]=0;
    i = stat(dir, &st);
    if (i!=0) {
      k = CreatePath(dir);
      if (k==0) {
	k = mkdir(dir, 0777);
	chown(dir, Qowner, Qgroup);
      }
    }
  }

  return k;
} /* CreatePath */



/*
   Rename `source' to `destination', first try rename(), if it fails try
   copy_reg()
   */
int Rename(char *source, char *dest)
{
  struct stat st;
  int i;

  if (CREATE) i=CreatePath(dest);

  i = rename(source, dest);
  if (i == -1)
    {
      stat(source, &st);
      i = copy_reg(source, dest, st);
    }

  return i;
}



/*
   If file is to be undeleted to another name, set the name.
   */
void SetUndelFile(long n, char *str)
{
  struct stat buf;
  int i;

  i = STRLEN(str);
  rename_string = (char *) malloc(i);
  strcpy(rename_string, str);
  if (rename_string[i-1] == '/') rename_string[i-1] = 0;

  if (n==12) SCOPE=1;
  i = stat(str, &buf);
  RENAME_DIR = ((i==0) && S_ISDIR(buf.st_mode)) ? 1 : 0;
} /* SetUndelFile */



/*
   See if file already exists, optionally remove the existing file
   */
int CheckFile(char *to_file)
{
  struct stat st;

  if (stat(to_file, &st) < 0) return 1;
  if (OVERWRITE)
    if (!unlink(to_file))     return 1;

  return 0;
}



/*
   Undelete file given by filespec `str'
   */
void UndeleteFile(char *str)
{
  struct stat st;
  u_long F=0;
  char tmp[255], from_file[255], to_file[255], *c, *tmpnames=0;
  int i, compr, cat;

  /*
     Open & lock needed files
     */
  sprintf(tmp, "%s/DELD.userquota", DELDIR);  /* Open & lock `DELD.userquota'*/
  u_f = OpenLock(tmp);
  sprintf(tmp, "%s/DELD.groupquota", DELDIR);/* Open & lock `DELD.groupquota'*/
  g_f = OpenLock(tmp);
  sprintf(tmp, "%s/DELD.filebase", DELDIR);   /* Open & lock `DELD.filebase' */
  f_f = OpenLock(tmp);

  /*
     Make a list of files deleted by `Qowner'
     */
  if (user.check != 1) BuildFileList(Qowner);

  if (user.check == 1) 
    {
      tmpnames = (char *) malloc(256*user.used_files);

      /*
	 Search list of deleted files for the specified file
	 */
      if (!FindFile(str, &F)) 
	{
	  /* SPECIFIED FILE NOT FOUND */

	  sprintf(tmp, "%s: No such file to undelete.\n", str);
	  if (VERBOSE) 
	    fprintf(stderr, "DChild: %s", tmp);
	  SendError(tmp);

	  CloseUnlock(u_f);
	  CloseUnlock(g_f);
	  CloseUnlock(f_f);
	  return;
	}

      /* Undelete file */
      do {
	compr = DFile[F].fname[0] & 0x0F;
	cat   = DFile[F].fname[0] & 0xF0;	
	DFile[F].fname[0] = '/';
	
	if (VERBOSE) 
	  fprintf(stderr, "DChild - Undeleting file %s\n", DFile[F].fname);
	
	sprintf(from_file, "%s/%010ld.DELETED%s", FILEDIR, DFile[F].dname,
		(compr) ? ".gz" : "");

	/*
	   If `rename_string != NULL' the parameter `--rename' was specified
	   on the `undel' command line.
	   */
	if (rename_string != NULL)
	  {
	    if (RENAME_DIR==0) {
	      strcpy(to_file, rename_string); 
	    }
	    else {
	      i = strlen(DFile[F].fname);
	      while ((DFile[F].fname[i] != '/') && (i > 0)) i--;
	      sprintf(to_file, "%s/%s", rename_string, &(DFile[F].fname[i+1]));
	    }
	    if (SCOPE==1) {
	      SCOPE=0;
	      free(rename_string);
	    }
	    strcpy(DFile[F].fname, to_file);
	  }

	if (CheckFile(DFile[F].fname))
	  {
	    c = tmpnam(0);
	    strcpy(&tmpnames[256*F], c);

	    if (compr) 
	      sprintf(tmp, "%s.gz", c);
	    else
	      strcpy(tmp, c);
	    
	    i = Rename(from_file, tmp);
	    
	    /* If rename worked, remove from database */
	    if (i==0) {
	      /* Write Database */
	      stat(tmp, &st);
	      zipped_size = st.st_blocks;
	      RemoveDB(F, cat);
	      
	      DFile[F].fname[0] = (compr << 4) | 0x0F;
	    }
	    else {
	      sprintf(to_file,"Unable to rename %s to %s.\n", 
		      from_file, tmp);
	      SendError(to_file);
	    }
	  }
	else {
	  sprintf(tmp, "%s: File exists.\n", to_file);
	  SendError(tmp);
	}

	F++;
	/* While there are files to match `str' */
      } while (FindFile(str, &F));
    }
  else 
    {
      /* NO FILES TO UNDELETE !!! */
      if (VERBOSE) fprintf(stderr, "DChild - User %lu has no deleted files\n",
			   (u_long) Qowner);
      if (FIRSTERROR) SendError("No files to undelete.\n");
      FIRSTERROR=0;
    }

  if (CREATE) CREATE=0;

  CloseUnlock(u_f);
  CloseUnlock(g_f);
  CloseUnlock(f_f);

  if (user.check == 1)
    for (i=0; i < user.used_files; i++)
      if (DFile[i].fname[0] & 0x0F == 0x0F)
	{
	  compr = ((DFile[i].fname[0] & 0xF0) >> 4);
	  DFile[i].fname[0]='/';
	  
	  if (compr) 
	    sprintf(tmp, "%s.gz", &tmpnames[256*i]);
	  else
	    strcpy(tmp, &tmpnames[256*i]);
	  if (compr) Gzip(compr, tmp, 1);
	  
	  Rename(&tmpnames[256*i], DFile[i].fname);
	  chown(DFile[i].fname, DFile[i].uid, DFile[i].gid);
	  chmod(DFile[i].fname, DFile[i].mode);

	  /* `Empty' structure */
	  DFile[i].fname[0] =0;
	  DFile[i].uid      =0;
	  DFile[i].gid      =0;
	  DFile[i].prev_uid =0;
	  DFile[i].next_gid =0;
	  DFile[i].prev_gid =0;
	  DFile[i].next_uid =0;
	  DFile[i].next_file=0;
	  DFile[i].prev_file=0;
	}
} /* UndeleteFile */





