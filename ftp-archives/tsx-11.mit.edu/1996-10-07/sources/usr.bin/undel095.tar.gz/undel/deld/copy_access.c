/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include <fcntl.h>
#include <utime.h>

#include "globhand.h"
#include "copy_access.h"


/*
   See if current Qowner has access to group gid
   */
int in_group(int gid)
{
  int i=-1; 
  struct passwd *pwd;
  char name[255];

  if (groups == NULL) 
    {
      pwd = getpwuid((uid_t)Qowner);
      strcpy(name,pwd->pw_name);
      i = initgroups(name, Qgroup);
      
      if (i >= 0) {
	groups = (GTYPE *) malloc (GSIZE * sizeof (GTYPE));
	nr_of_groups = getgroups (GSIZE, groups);
      }    
    }

  if (groups != NULL)
    for (i = 0; i < nr_of_groups; i++)
      if (gid == groups[i]) return 1;

  return 0;
} /* in_group */


/*
   See if Qowner.Qgroup has access to file or directory whose stats are in
   the structure pointed to by 'st'
   */
int AccessOK(struct stat *st)
{
  int i=0;

  if (Qowner == 0) return 1;
  
  if (Qowner == st->st_uid) {
    if ((st->st_mode & 0300) == 0300) i=1;
  } 
  else if (Qgroup == st->st_gid) {
    if ((st->st_mode & 0030) == 0030) i=1;
  } 
  else if (in_group(st->st_gid)) {
    if ((st->st_mode & 0030) == 0030) i=1;
  }
  else if ((st->st_mode & 0003) == 0003) i=1;

  return i;
} /* AccessOK */




/* 
   Copy regular file SOURCE onto file DEST.
   Return 1 if an error occurred, 0 if successful.
   This function was copied from `GNU Fileutils 3.9, src/mv.c'
   */
int copy_reg(char *source, char *dest, struct stat source_stats)
{
  int ifd;
  int ofd;
  char buf[1024 * 8];
  int len;			         /* Number of bytes read into `buf'. */


  if (!S_ISREG(source_stats.st_mode)) return -1;   /* Not a regular file    */
  if (unlink(dest) && errno != ENOENT) return -1;  /* Can't remove dest     */

  ifd = open(source, O_RDONLY, 0);                 
  if (ifd < 0) return -1;                           /* Can't open source     */

  ofd = open(dest, O_WRONLY | O_CREAT | O_TRUNC, 0600);
  if (ofd < 0) {                                    /* Can't create dest     */
      close(ifd);
      return -1;
    }

  while ((len = read(ifd, buf, sizeof(buf))) > 0)
    {
      int wrote = 0;
      char *bp = buf;

      do
	{
	  wrote = write(ofd, bp, len);             
	  if (wrote < 0)                            /* Error writing dest    */
	    {
	      close(ifd);
	      close(ofd);
	      unlink(dest);
	      return -1;
	    }
	  bp += wrote;
	  len -= wrote;
	} while (len > 0);
    }
  if (len < 0)                                      /* Error reading source  */
    {
      close(ifd);
      close(ofd);
      unlink(dest);
      return -1;
    }

  if (close (ifd) < 0)                              /* Error closing source ?*/
    {
      close(ofd);
      return 1;
    }
  if (close (ofd) < 0) return 1;                    /* Error closing dest ?  */

  /* Try to copy the old file's modtime and access time.  */
  {
    struct utimbuf tv;

    tv.actime = source_stats.st_atime;
    tv.modtime = source_stats.st_mtime;
    if (utime(dest, &tv)) return 1;                /* Failed to set time    */
  }

  unlink(source);
  return 0;
}
