/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globhand.h"
#include "copy_access.h"
#include "db_ops.h"


/*
   Delete file given by `s' 
   (compression and update of database is done at end of session)
   */
void DeleteFile(char *s)
{
  int i,j, cat;
  char fname[255], fdir[255];
  struct stat st;

  cat  = s[0];
  s[0] = '/';

  i = strlen(s)-1;              
  j = i;
  while ((s[i] != '/') && (i > 0)) i--;
  strncpy(fdir, s,i);
  fdir[i]=0;
  stat(fdir, &st);

  if (AccessOK(&st) && (stat(s,&st) == 0)) {
    if (VERBOSE) fprintf(stderr, "DChild - Deleting file : %s\n", &s[i+1]);

    if (DMAX > 0) DCount++;          /* Create structure to hold transaction */
    if (DMAX <= DCount)
      {
	DMAX += 20;
	if (DMAX == 20) {
	  DelFile = 
	    (struct DelStruc **) malloc(sizeof(struct DelStruc *) * 20);
	} else {
	  DelFile = 
	    (struct DelStruc **) realloc(DelFile, 
					 sizeof(struct DelStruc *)* DMAX);
	}
      }
    DelFile[DCount] = (struct DelStruc *) malloc(D_SIZE);

    strcpy(DelFile[DCount]->fname, s);    
    DelFile[DCount]->dname = GetFileName(fname);

    i = rename(s, fname);
    if (i == -1)
      switch (errno) 
	{
	case (EPERM):
	case (EXDEV): i = copy_reg(s, fname, st);
	  break;
	  
	default: 
	}
    if (i >= 0) 
      {
	DelFile[DCount]->fname[0] = cat; 
	DelFile[DCount]->uid      = st.st_uid; /* save file settings, so we  */
	DelFile[DCount]->gid      = st.st_gid; /* can write them to disk l8r */
	DelFile[DCount]->mode     = st.st_mode;
	DelFile[DCount]->size     = st.st_blocks;

	/* Chown() / Chmod() */
	chown(fname, D_OWNER, D_GROUP);
	chmod(fname, D_MODE);
      }
    else 
      {
	free(DelFile[DCount]);                 /* Failure ... free struct   */
	DCount--;
      }
  } else {
    sprintf(fname, "%s: Permission denied.\n", s);
    SendError(fname);
    if (VERBOSE) fprintf(stderr, "DChild: %s", fname);
  }
} /* DeleteFile */








