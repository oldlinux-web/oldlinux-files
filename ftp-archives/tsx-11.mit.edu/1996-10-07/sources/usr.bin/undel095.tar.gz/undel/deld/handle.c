/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globhand.h"
#include "del_undel.h"
#include "dquota.h"
#include "filelist.h"

struct DelStruc **DelFile;
uint DCount=0, DMAX=0;

GTYPE *groups   = NULL;
int nr_of_groups;

int Qowner=-1;
int Qgroup=-1;
FILE *tempfile;


/*
   This is the heart of the deamon.
   Connect to client, get messages, perform operations
   */
void HandleCall(struct msgtype msg)
{
  int l;
  struct msqid_ds buf;

  sscanf(msg.mtext, "%d", &inQ);                 /* Get inQ number, linkup   */
  l = Connect(&inQ, &outQ);                      /* with calling process     */

  if (l==0) {
    if (VERBOSE) fprintf(stderr, "DChild - Connected ...\n");
  }
  else {                                         /* Something went wrong,    */
    exitproc(12);                                /* terminate ...            */
  }

  msgctl(inQ, IPC_STAT, &buf);                   /* Get owner id for         */
  Qowner = buf.msg_perm.cuid;                    /* caller verification      */
  Qgroup = buf.msg_perm.cgid;

  while (1) {                                    /* Loop until exit          */
    l = RcvMsg(inQ, &msg, 255, 1, MSG_EXCEPT);   /* Receive incoming msg     */
    switch (msg.mtype)                           /* Do what has to be done   */
      {
      case (2)  : exitproc(10);                       break;
      case (3)  : DeleteFile(msg.mtext);              break;

      case (10) : UndeleteFile(msg.mtext);            break;
      case (11) : SetUndelFile(msg.mtype, msg.mtext); break;
      case (12) : SetUndelFile(msg.mtype, msg.mtext); break;

      case (15) : StatFiles();                        break;
      case (21) : CREATE=1;                           break;
      case (23) : OVERWRITE=1;                        break;

      case (20) : GetQuota(msg.mtext);                break;
      case (30) : RefreshQuota(msg.mtext);            break;

      default   : 
	if (VERBOSE) 
	  fprintf(stderr, "%ld\t%s\n", msg.mtype, msg.mtext); 
	exitproc(11); 
      }
  }
} /* HandleCall */














