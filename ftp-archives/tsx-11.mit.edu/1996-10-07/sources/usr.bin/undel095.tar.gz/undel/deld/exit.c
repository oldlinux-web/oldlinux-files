/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#include "globhand.h"
#include "db_ops.h"
#include "lowlevel.h"
#include "dquota.h"

#include <sys/wait.h>

extern FILE *u_f, *g_f, *f_f;
extern pid_t LAST_CHILD;

extern int Gzip(int, char *, int);


/*
   Adjust links in database when adding files
   */
void AdjustLink(FILE *f, struct UserStruc *link, u_long Count, int c, int cat)
{
  struct DelStruc tmp;

  if (link->last[cat] > 0)
    {
      FRead(f, &tmp, D_SIZE, D_SIZE*(link->last[cat]-1));
      
      *((u_long *) (&(tmp.next_uid)+c)) = Count;
      FWrite(f, &tmp, D_SIZE, D_SIZE*(link->last[cat]-1));
    } 
  else 
    {
      link->first[cat] = Count;
    }
} /* AdjustLink */



/*
   Write list of files deleted in this session to database, 
   also compress these files
   */
void WriteDB()
{
  struct stat st;
  struct UserStruc  user, global;
  struct GroupStruc group;
  struct DelStruc   tmp;
  char s[255], open=0;
  uid_t uid;
  gid_t gid;
  u_long Count, DBSize, firstE, lastE, FCount=0, FSize=0;
  int i,j, cat;


  for (j=0; j <= DCount; j++) 
    {
      if (!open) {
	sprintf(s, "%s/DELD.userquota", DELDIR);  u_f = OpenLock(s);
	sprintf(s, "%s/DELD.groupquota", DELDIR); g_f = OpenLock(s);
	open=1;

	i = FRead(u_f, &global, U_SIZE, OFFSET);   /* Read database settings */
	UCheck(i, &global, GLOBAL);
      }

      uid = DelFile[j]->uid;
      gid = DelFile[j]->gid;

      i = FRead(u_f, &user, U_SIZE, OFFSET+(U_SIZE*(uid+1)));     /*User data*/
      UCheck(i, &user, USER);
      i = FRead(g_f, &group, U_SIZE, U_SIZE*gid);          /* Get group data */
      UCheck(i, &group, GROUP);

      if ((!user.q_blocks   || (DelFile[j]->size <= user.q_blocks))  && 
	  (!group.q_blocks  || (DelFile[j]->size <  group.q_blocks)) &&
	  (!global.q_blocks || (DelFile[j]->size <  global.q_blocks)))
	{
	  if (DelFile[j]->fname[0] || DelFile[j]->fname[0] <= CNUM)
	    cat = DelFile[j]->fname[0] - 1;
	  else
	    cat = 0;
	  DelFile[j]->fname[0] = '/';

	  CloseUnlock(u_f);
	  CloseUnlock(g_f);
	  open=0;

	  sprintf(s, "%s/%010ld.DELETED", FILEDIR, DelFile[j]->dname);
	  /* Compress file if compression is requested */
	  if (COMPRESS && !Gzip(COMPRESS, s, 0)) {
	    sprintf(s, "%s.gz", s);
	    if (!stat(s, &st))
	      FSize += st.st_blocks;
	    
	    /* Store compression level and category for this file */
	    DelFile[j]->fname[0] = COMPRESS | (cat << 4);
	  }
	  else {
	    FSize += DelFile[j]->size;
	    
	    /* Store category */
	    DelFile[j]->fname[0] = (cat << 4);
	  }

	  FCount++;
	}
      else
	{
	  sprintf(s, "%s/%010ld.DELETED", FILEDIR, DelFile[j]->dname);
	  DelFile[j]->fname[1]=0;
	  unlink(s);
	}
    }

  if (!open) {
    sprintf(s, "%s/DELD.userquota", DELDIR); /* Open & lock `DELD.userquota' */
    u_f = OpenLock(s);
    sprintf(s, "%s/DELD.groupquota", DELDIR); /*Open & lock `DELD.groupquota'*/
    g_f = OpenLock(s);
  }
  sprintf(s, "%s/DELD.filebase", DELDIR);   /* Open & lock `DELD.filebase'   */
  f_f = OpenLock(s);

  /* Global input */
  if (!FRead(u_f, &DBSize, L_SIZE, 0)) DBSize=0;    /* Read size of filebase */
  if (!FRead(u_f, &firstE, L_SIZE, L_SIZE)) firstE=0;    /* Read first empty */
  if (!FRead(u_f, &lastE,  L_SIZE, 2*L_SIZE)) lastE=0;    /* Read last empty */
  i = FRead(u_f, &global, U_SIZE, OFFSET);         /* Read database settings */
  UCheck(i, &global, GLOBAL);
  
  global.used_files    += FCount;
  global.used_blocks   += FSize;

  for (j=0; j <= DCount; j++) 
    if (DelFile[j]->fname[1])
      {
	uid = DelFile[j]->uid;
	gid = DelFile[j]->gid;

	cat = (DelFile[j]->fname[0] >> 4);
	
	/* Determine next free record number */
	if (firstE > 0) {
	  FRead(f_f, &tmp, D_SIZE, D_SIZE*(firstE-1));
	  Count        = firstE;
	  firstE = tmp.next_uid;
	  if (firstE == 0) lastE = 0;
	}
	else {
	  Count = ++DBSize;
	}

	/* Instance input */
	i = FRead(u_f, &user, U_SIZE, OFFSET+(U_SIZE*(uid+1)));/*User data*/
	UCheck(i, &user, USER);
	i = FRead(g_f, &group, U_SIZE, U_SIZE*gid);     /* Get group data */
	UCheck(i, &group, GROUP);
	
	/* Make Database links */
	AdjustLink(f_f, &user,  Count, 0, cat);   /* Adjust user.last link */
	AdjustLink(f_f, &group, Count, 2, 0);    /* Adjust group.last link */
	AdjustLink(f_f, &global,Count, 4, 0);   /* Adjust global.last link */
	
	/* Adjusting variables */
	DelFile[j]->prev_uid = user.last[cat];
	user.used_blocks    += DelFile[j]->size;
	user.used_files++;
	user.last[cat]       = Count;
	user.check           = 1;
	DelFile[j]->prev_gid = group.last[0];
	group.used_blocks   += DelFile[j]->size;
	group.used_files++;
	group.last[0]        = Count;
	group.check          = 1;
      
	/* Adjust global settings with sizes returned by compression algo */
	DelFile[j]->prev_file = global.last[0];
	global.last[0]        = Count;
	  
	/* Instance output */
	FWrite(u_f, &user, U_SIZE, OFFSET+(U_SIZE*(uid+1)));
	FWrite(g_f, &group, U_SIZE, U_SIZE*gid);
	FWrite(f_f, DelFile[j], D_SIZE, D_SIZE*(Count-1));      
      }
  QuotaCheck(&global, &firstE, &lastE);

  for (j=0; j <= DCount; j++) free(DelFile[j]);
  free(DelFile);
  
  /* Global output */
  global.check = 1;
  FWrite(u_f, &DBSize, L_SIZE, 0);
  FWrite(u_f, &firstE, L_SIZE, L_SIZE);
  FWrite(u_f, &lastE,  L_SIZE, L_SIZE*2);
  FWrite(u_f, &global, U_SIZE, OFFSET);
  
  
  CloseUnlock(u_f);                      /* Unlock & close `DELD.userquota'  */
  CloseUnlock(g_f);                      /* Unlock & close `DELD.groupquota' */
  CloseUnlock(f_f);                      /* Unlock & close `DELD.filebase'   */
}



/*
   Exit of deamon, removes all queues, updates database if needed.

   err % 10 = 0  -->  Normal exit, no error condition.
   err % 10 = x  -->  Exit with status x.
   err < 10      -->  Exit of master deamon.
   err >=10      -->  Exit of Child process.
   */
void exitproc(int err)
{
  struct msgtype msg;
  struct msqid_ds buf;


  if (VERBOSE) {
    if (err % 10 == 0) {
      (err < 10) ? fprintf(stderr,"DELD") : fprintf(stderr,"DChild");
      fprintf(stderr," - Exiting (Normal status).\n");
    }
    else {
      (err < 10) ? fprintf(stderr,"DELD") : fprintf(stderr,"DChild");
      fprintf(stderr," - Exiting (Error status %d). \n", err%10);
    }
  }


  if (err < 10) {                        /* Master deamon going down       */
    /* To avoid problems when DELD is started by someone else then `root' */
    unlink(QIDFILE);

#ifdef DEBUG
    sleep(2);
#else
    if (LAST_CHILD) waitpid(LAST_CHILD, 0, WNOHANG);
#endif
    msgctl(inQ, IPC_RMID, &buf);         /* Only existing Queue = inQ      */
  } 
  else {                                 /* Child process exiting          */
    msg.mtype = 2;                       /* Send EOT to calling process    */
    SendMsg(outQ, &msg, 1, IPC_NOWAIT);

    if (err % 10 == 0)                   /* If there is a valid connection */
      do {                               /* Wait for caller to receive EOT */
	msgctl(outQ, IPC_STAT, &buf);
      } while (buf.msg_qnum > 0);

    msgctl(outQ, IPC_RMID, &buf);        /* Destroy 'inQ' and 'outQ'       */
    msgctl(inQ, IPC_RMID, &buf);
  }

  alarm(0);

  if (DMAX > 0) WriteDB();

  (err < 10) ? exit(err%10) : _exit(err%10);
}
