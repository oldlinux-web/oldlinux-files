/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#ifndef _DELTYPES_H_
#define _DELTYPES_H_


/*
   This structure is used by the Message IPC functions
   */
struct msgtype
{
  long mtype;
  char mtext[255];
};



/*
   This structure will be written to the database. (DELD.filebase)
   It is quite large and not very space-efficient, but does enable us to access
   the database quickly and does not induce fragmentation of the database. 
   (If you'd happen to have a better idea, please let me know.)

   (!) fname[0] contains some status info
        - on the compression level : compr = fname[0] & 0x0F
	- on the category          :   cat = fname[0] & 0xF0 


   (!) Numbering of the structures will start at 1 and not at 0.
       next_uid = 0 or next_gid = 0 -> No next structure
       prev_gid = 0                 -> No previous structure
   */
struct DelStruc {
  /* Filled in when `deleting' file */
  char     fname[218];          /* Original Filename              */
  uid_t    uid;                 /* Uid of owner                   */ 
  gid_t    gid;                 /* Gid of owner                   */
  mode_t   mode;                /* Access mode of file            */
  u_long   size;                /* Number of blocks allocated     */
  u_long   dname;               /* Number of `deleted' file       */
  
  /* Filled in when updating database */
  u_long   next_uid;            /* Next file of same owner  (!)   */
  u_long   prev_uid;            /* Previous file of owner   (!)   */
  u_long   next_gid;            /* Next file of same group  (!)   */
  u_long   prev_gid;            /* Allows fast DB updating  (!)   */
  u_long   next_file;           /* Next file deleted        (!)   */
  u_long   prev_file;           /* Allows fast DB updating  (!)   */
};


/* Defines how many deletion categories are available (MUST BE < 16) */
#define CNUM 3

/*
   This structure will be written to the quota file. (DELD.userquota)
   The first block in `DELD.userquota' will contain data about the whole 
   filebase. 
   (Max. number of diskblocks that may be allocated, Max. allowed size of 
   filebase, Diskblocks allocated by all files together, Number of deleted 
   files, first & last free DelStruc item in filebase)
   */
struct UserStruc {
  u_long q_blocks;              /* DQuota (in blocks) for user    */
  u_long q_files;               /* DQuota (in files)  for user    */
  u_long used_blocks;           /* Number of used blocks for user */
  u_long used_files;            /* Number of used files  for user */
  u_long first[CNUM];           /* First & last DelStruc for user */
  u_long last[CNUM];
  char   check;                 /* See if struct is initialised   */
};
#define U_SIZE   (sizeof(struct UserStruc))
#define D_SIZE   (sizeof(struct DelStruc))
#define OFFSET   (3*sizeof(u_long))
#define L_SIZE   (sizeof(u_long))



/*
   This structure will be written to the quota file. (DELD.groupquota)
   */
#define GroupStruc  UserStruc         /* Same thing for groups           */

#endif
