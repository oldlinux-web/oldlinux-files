/*
   This file is part of `The Undelete System'
   Copyright (C) 1995 Peter Vanderborght

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
   */

#ifndef _GLOBAL_H_
#define _GLOBAL_H_

/* 
   _KMEMUSER is needed to compile correctly, please do not remove it. 
   */
#define _KMEMUSER

/* 
   STRLEN is equal to strlen() + 1, this is so msgsnd() will include the
   null-character at the end of the string
   */
#define STRLEN(x)          (strlen(x) + 1)


/*
   Rest of global.h
   */
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/file.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "deltypes.h"
#include "config.h"

/*
   This allows us to determine which program is running.
   */
#define DELD      1
#define DEL       2
#define UNDEL     3
#define DQUOTA    4
#define EDDQUOTA  5
#define REPDQUOTA 6
extern int PROGRAM_ID;


/*
   Some defines used by `eddquota' and `deld'
   */
#define USER     1
#define GROUP    2
#define GLOBAL   3

/*
   BSD Unix has a `flock()' function, System V Unix has a `lockf()' function.
   Therefore, if we're not compiling on a BSD system, emulate `flock()'.
   */
#ifndef __USE_BSD
#define MSG_EXCEPT 020000
#define LOCK_EX 1
#define LOCK_UN 2

int flock(int filedes, int flag); 
#endif

/*
   Current version of `The Undelete System'
   */
#define VERSION "0.95"


extern int inQ, outQ;
extern int VERBOSE;

int Connect(int *, int *);
int SendMsg(int Q, struct msgtype *msg, int size, int flag);
int RcvMsg(int Q, struct msgtype *msg, int size, long type, int flag);

char *basename(const char *);

#endif


