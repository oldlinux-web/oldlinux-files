/*
 * pnmshow.c - displays a portable anymap on a Trident VGA under Linux.
 *
 * Copyright (C) 1993 by David Frey.
 * Copyright (C) 1989 by Jef Poskanzer.
 *
 * based on the TVGALib from Toomas Losin, which again is 
 * based on the  VGALib from Tommy Frandsen.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted, 
 * provided that the above copyright notice appear in all copies and that 
 * both that copyright notice and this permission notice appear in 
 * supporting documentation. This software is provided "as is" without 
 * express or implied warranty.
 *
 * And the TVGALib-Copyright:
 *
 * VGAlib version 1.0 - (c) 1992 Tommy Frandsen 		   
 *								   
 * This library is free software; you can redistribute it and/or   
 * modify it without any restrictions. This library is distributed 
 * in the hope that it will be useful, but without any warranty;   
 * without even the implied warranty of merchantability or fitness 
 * for a particular purpose.					   
 *
 * TVGAlib version 1.0.0					   
 *								   
 * VGAlib modified by Toomas Losin to support the Trident 8900C    
 * SVGA modes.  I wanted to annotate my modifications, but there   
 * were just too many.  If there are any problems, blame my code   
 * first, just remember that my code is offered without warranty   
 * as well.							   
 */

#include <stdio.h>
#include <vga.h>
#include "pnm.h"
#include "ppmcmap.h"

#define MAXCOLORS 256
#define MAXCOLOR  MAXCOLORS-1

#define MAXXSIZE  1024

#define FALSE 0
#define TRUE 1

#define MAX(x, y) ((x) > (y)) ? (x) : (y)
#define MIN(x, y) ((x) < (y)) ? (x) : (y)

enum
{
  NOMOVE, LEFT, RIGHT, UP, DOWN, HOME, END, PGUP, PGDOWN
};

static int Red[MAXCOLORS], Green[MAXCOLORS], Blue[MAXCOLORS];
static pixel **pixels;
static colorhash_table cht;

/*
 * The color map will be processed in the following way:
 * 1. build a histogram of the picture.
 * 2. squeeze original colormap into VGA color space.
 * 3. make a hash table.
 *
 * The number of used colors will be returned.
 */
int ProcessColormap(pixel **pixels, int cols, int rows,int maxval)
{
  int i;  
  colorhist_vector chv;
  int colors;
  
  /*
   * 1st step:
   * Build a histogram of the PPM picture and extract the PPM color map 
   * out of the histogram.
   * 
   */
  
  pm_message("computing colormap...");

  chv = ppm_computecolorhist(pixels, cols, rows, MAXCOLORS, &colors);
  if (chv == (colorhist_vector) NULL)
    pm_error("too many colors - try doing a 'ppmquant %d'", MAXCOLORS);
  pm_message("%d colors found.", colors);

  if (maxval > MAXCOLOR)
    pm_message("more than %d colors - automatically rescaling colors.\n", 
	       MAXCOLOR);

  for (i = 0; i < colors; i++)
  {
    if (maxval <= MAXCOLOR)
    {
      Red[i] = PPM_GETR(chv[i].color);
      Green[i] = PPM_GETG(chv[i].color);
      Blue[i] = PPM_GETB(chv[i].color);
    }
    else
    {
      Red[i] = (int)PPM_GETR(chv[i].color) * MAXCOLOR / maxval;
      Green[i] = (int)PPM_GETG(chv[i].color) * MAXCOLOR / maxval;
      Blue[i] = (int)PPM_GETB(chv[i].color) * MAXCOLOR / maxval;
    }
  }
  
  /*
   * 2nd step:
   * Squeeze the original color map with 256 colors (8 bit depth for red,
   * green or blue) into the "standard" VGA color map with a depth of 6 bits.
   * This is done by linear scaling of the colors.
   *
   */
  for (i = 0; i < colors; i++)
  {
    Red[i] = Red[i] * 63 / maxval;
    Green[i] = Green[i] * 63 / maxval;
    Blue[i] = Blue[i] * 63 / maxval;
  }
  
  /* 
   * 3rd step:
   * Make a hash table for fast lookup. 
   *
   */
  cht = ppm_colorhisttocolorhash(chv, colors);
  ppm_freecolorhist(chv);
  
  return colors;
}

/* 
 * Set the VGA color map.
 */ 
void SetVGAColormap(int colors, int Red[], int Green[], int Blue[])
{
  int i;

  for (i = 0; i < colors; i++)
    vga_setpalette(i, Red[i], Green[i], Blue[i]);
}

/*
 * Choose the appropriate video mode for our image.
 * This procedure tries to choose a video mode which avoids panning.
 *
 */
int ChooseVideomode(int rows, int cols, int colors)
{
  int vidmode;

  vidmode = G1024x768x256; 
  /* 
   * is there a smaller video mode available ? 
   */
  if (cols <= 320)
  {
    if (rows <= 200)
    {
      if (colors <= 16)     vidmode = G320x200x16;
      else                  vidmode = G320x200x256;
    }
    else if (rows <= 240)   vidmode = G320x240x256;
    else if (rows <= 400)   vidmode = G320x400x256;
  }
  else if ((cols <= 360) && (rows <= 480)) vidmode = G360x480x256;
  else if (cols <= 640)
  {
    if (colors <= 16)
    {
      if (rows <= 200)      vidmode = G640x200x16;
      else if (rows <= 350) vidmode = G640x350x16;
      else if (rows <= 480) vidmode = G640x480x16;
    }
    else
    {
      if (rows <= 400)      vidmode = G640x400x256;
      else if (rows <= 480) vidmode = G640x480x256;
    }
  }
  else if (cols <= 800)
  {
    if (colors <= 16)       vidmode = G800x600x16;   /* Trident SVGA mode */
    else                    vidmode = G800x600x256;  /* Trident SVGA mode */
  }
  else if (cols <= 1024)
  {
    if (colors <= 16)       vidmode = G1024x768x16;  /* Trident SVGA mode */
    else                    vidmode = G1024x768x256; /* Trident SVGA mode */
  }
  
  return vidmode;
}
		     
int main(int argc, char *argv[])
{
  FILE *ifp;

  int rows, cols, colors;      /* picture size, # of colors */
  int format;   
  pixval maxval;
  
  int x, y, xmax, ymax;	       /* x,y coordinate, max. screen size       */
  int xs, ys;                  /* x,y offset for centering               */
  int xo, yo;	               /* x,y origin when panning,               */
  int oxo, oyo;                /* previous x,y origin                    */
  int color;	               /* pixel color */

  int filter;		       /* flag, true when run as filter */
  char ch;
  int move;		       /* LEFT, RIGHT ... */
  
  char scanline[MAXXSIZE];     /* a single row, ready to be put into VGA
 				  memory by vga_drawscanline              */

  /* 
   * initialize the pnm stuff and evaluate the command line argument 
   */
  pnm_init(&argc, argv);

  if (argc > 3) pm_usage("[-f] [pnmfile]");

  if (argc == 3)
  {
    filter = TRUE;  ifp = pm_openr(argv[2]);
  }
  else if (argc == 2)
  {

    filter = (strcmp(argv[1], "-f") == 0);
    if (!filter) ifp = pm_openr(argv[1]);
    else         ifp = stdin;
  }
  else
  {
    filter = FALSE; ifp = stdin;
  }

  /* 
   * read the image 
   */
  pixels = pnm_readpnm(ifp, &cols, &rows, &maxval, &format);
  if (filter) pnm_writepnm(stdout, pixels, cols, rows, maxval, format, 0);
  
  pm_message("picture size is %dx%d pixels.", cols, rows);

  /* 
   * promote the to the ppm format, if necessary 
   */
  if (PNM_FORMAT_TYPE(format) != PPM_TYPE)
  {
    pm_message("promoting to PPM");
    pnm_promoteformat(pixels, cols, rows, maxval, format, maxval, PPM_TYPE);
  }

  colors = ProcessColormap(pixels,cols,rows,maxval);
  
  pm_message("Use <TAB> to flip between graphics and text mode.");
 
  /*
   * Set the graphics mode
   */ 
    
  vga_setmode(ChooseVideomode(rows,cols,colors)); 
  SetVGAColormap(colors,Red,Green,Blue); 
  vga_clear();

  /* Get maximum screen size */
  xmax = vga_getxdim();
  ymax = vga_getydim();
  
  vga_setflipchar('\t');
  
  /*
   * Our image is smaller than the screen size:
   * Center picture.
   *
   */
  if ((cols < xmax) && (rows < ymax))
  {
    do
    {
      xs = (xmax - cols) / 2; ys = (ymax - rows) / 2;
      
      memset(&scanline,0,MAXXSIZE);
      for (y = 0; y < ys; y++) vga_drawscanline(y,scanline);
      
      for (y = ys; y < ys+rows; y++)
      {
	/* assemble a scan line */
	for (x = 0; x < xs; x++) scanline[x] = 0;
	
	for (x = xs; x < xs+cols; x++)
	{	        
          color = ppm_lookupcolor(cht, &pixels[y-ys][x-xs]);
          if (color == -1)
          {
   	    vga_setmode(TEXT);
	    pm_error("color not found?!?  x=%d y=%d  r=%d g=%d b=%d",
		     x-xs, y-xs, 
		     PPM_GETR(pixels[y-ys][x-xs]), 
		     PPM_GETG(pixels[y-ys][x-xs]),
		     PPM_GETB(pixels[y-ys][x-xs]));
          }
	  scanline[x] = (char )color;
	}
	
	for (x = xs+cols; x < xmax; x++) scanline[x] = 0;

	vga_drawscanline(y,scanline);
      }
      
      memset(&scanline,0,MAXXSIZE);
      for (y = ys+rows; y < ymax; y++) vga_drawscanline(y,scanline); 
      
      ch = tolower(vga_getch());
    }
    while (!((ch == 'q') || (ch == '\n')));
  }
  else
  {
    xo  =  0;  yo =  0;
    oxo = -1; oyo = -1;  /* force a redisplay at first call */

    if (cols < xmax)
    {
      xs = (xmax - cols) / 2;
    }
    else
      xs = 0; 
    
    if (rows < ymax)
    {
      ys = (ymax - rows) / 2;
    }
    else 
      ys = 0; 
    
    /* 
     * This is the pan loop 
     */  
    do
    {
      if ((xo != oxo) || (yo != oyo))
      {
	if (ys > 0)
	{
	  memset(&scanline,0,MAXXSIZE);
	  for (y = 0; y < ys; y++) vga_drawscanline(y,scanline);
	}
	
        for (y = ys+yo; y < ys+yo+ymax; y++)
        {
	  if (xs > 0)
	  {
	    for (x = 0; x < xs; x++) scanline[x] = 0;
	  }
	  	  
	  for (x = xs+xo; x < xs+xo+xmax; x++)
	  {	        
	    if (((x-xs) < cols) && ((y-ys) < rows))
	    {
	      color = ppm_lookupcolor(cht, &pixels[y-ys][x-xs]);
	      if (color == -1)
	      {
		vga_setmode(TEXT);
		pm_error("color not found?!?  x=%d y=%d  r=%d g=%d b=%d",
			 x-xs, y-ys, 
			 PPM_GETR(pixels[y-ys][x-xs]), 
			 PPM_GETG(pixels[y-ys][x-xs]),
			 PPM_GETB(pixels[y-ys][x-xs]));
	      }
	    }
	    else
	    {
	      color = 0;
	    }
	    
	    scanline[x-xo] = (char )color;
	  }
	  
	  if (ys > 0)
	  {
	    memset(&scanline,0,MAXXSIZE);
	    for (y = ys+yo+ymax; y < ymax; y++) vga_drawscanline(y,scanline); 
	  }
	         
	  vga_drawscanline(y-yo,scanline);
	}
	oxo = xo; oyo = yo;
      }
      
      ch = vga_getch();
      move = NOMOVE;
      if (ch == '\033')
      {
	ch = vga_getch();
	if (ch == '[')
	{
	  ch = vga_getch();
	  switch (ch)
	  {
	    case 'A': move = UP;     break;
	    case 'B': move = DOWN;   break;
	    case 'C': move = RIGHT;  break;
	    case 'D': move = LEFT;   break;
	    case '1': move = HOME;   break;
	    case '4': move = END;    break;
	    case '5': move = PGUP;   break;
	    case '6': move = PGDOWN; break;
	    default : break;
	  }
	}
      }
      else
      {
	ch = tolower(ch);
	switch (ch)
	{
	  case 'k': move = UP;      break;
	  case 'j': move = DOWN;    break;
	  case 'l': move = RIGHT;   break;
	  case 'h': move = LEFT;    break;
	  default : break;
	}
      }
      
      switch (move)
      {
	case LEFT  : xo = MAX(xo - xmax / 2, 0);                  break;
	case RIGHT : xo = MAX(MIN(xo + xmax / 2, cols - xmax),0); break;
	case UP    : yo = MAX(yo - ymax / 2, 0);                  break;
	case DOWN  : yo = MAX(MIN(yo + ymax / 2, rows - ymax),0); break;
	case HOME  : xo = 0;                                      break;
	case END   : xo = MAX(cols - xmax,0);                     break;
	case PGUP  : yo = 0;                                      break;
	case PGDOWN: yo = MAX(rows - ymax,0);                     break;
	case NOMOVE: break;
      }
    }   
    while (!((ch == 'q') || (ch == '\n')));
  }
  
  /* restore video mode, and free the memory */

  vga_setmode(TEXT);

  pnm_freearray(pixels, rows);

  pm_close(ifp);
  if (filter) pm_close(stdout);
 
  exit(0);
}
