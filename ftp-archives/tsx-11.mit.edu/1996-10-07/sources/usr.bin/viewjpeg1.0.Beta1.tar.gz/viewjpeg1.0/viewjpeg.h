
#include <stdlib.h>
#include <stdio.h>
#include <jconfig.h>
#include <jpegdata.h>

typedef struct OPTS {
	int 	opt_greyscale;
	int 	opt_onepass;
	int 	opt_quantize;
	int 	opt_verbose;
	int 	opt_forcemode;
	int		opt_widthonly;
	double 	opt_fuzz;
	char 	graphtoread[128];
	} opts;

struct BEST_MODE {
	struct BEST_MODE	*nextentry;
	struct BEST_MODE	*preventry;
    int 				min_width;
    int 				min_height;
    int 				mode;
    int 				mode_width;
    int					mode_height;
    int 				mode_depth;
};

typedef struct BEST_MODE bmode;

#define CTRL_X 0x18
#define ESC    0x1b
#define ADD	   0x2b
#define SUB	   0x2d

#define RETURN_KEY  3
#define ESC_KEY	    5
#define CTRL_X_KEY  7 
#define SPACE_KEY	9
#define BACK_KEY	11
#define ADD_KEY		1
#define SUB_KEY	   -1

/* jpegview.c and front.c */
void  getmodeinfo(void);
void  clearmode(void);
void  checkmodes(int force_mode);
char* set_opts(opts options);
int   set_it_all_running(opts options);
void  addtostruct(int min_width2, int min_height2, int mode2, int mode_width2,
				  int mode_height2, int mode_depth2);
void  killmodelist(bmode *tokill);

/* display.c */
void display_init(int image_width, int image_height, int components);
void display_set_palette(int num_colors, JSAMPARRAY colormap, int components);
void display_set_greyscale_palette(void);
void display_rows(int num_rows, JSAMPIMAGE pixel_data, int image_width, int components);
void std_rows(int num_rows, JSAMPIMAGE pixel_data, int image_width, int components);
void display_shutdown(void);
int  scroll_until_end(void);
void set_custom_palette(int cmap_length, int c_map[3][256]);

/* newfunct.c */
int  setfixdisplay(int addsub);
int  best_mode(int width, int height, int components);
int  find_best_mode(int width, int height, int components);
void writefont(char *s);
void initfont();
void set_custom_palette(int cmap_length, int c_map[3][256]);
void greyscale_colormap(int cmap_length, int c_map[3][256]);
int  convert_to_int(char c);

/* image.c */
int  read_image_file (char *filename);

/* jpeg.c */
int read_JPEG_file (char *filename);
void error_exit (const char *msgtext);
void trace_message (const char *msgtext);

/* cmap.c */
void translate_init(void);
void translate_row(int width, JSAMPARRAY rgb_row, JSAMPARRAY cmap_row);

/* bmp.c */
int  read_bmp_file(char *filename); /* main used to read BITMAPS */

/* pixmap.c */
int read_pixmap_file(char *image_name); /* main used to read PIXMAPS *

/* external defines */
extern struct vga_mode_avaliblity mode;
extern int opt_greyscale, opt_onepass, opt_quantize, opt_verbose;
extern int opt_forcemode, opt_widthonly, opt_scale;
extern double opt_fuzz;

extern int  mode_width, mode_height, mode_depth;
extern int  start_row, mode_linewidth;
extern int  con_col, con_row, modetype;
extern int  logical_width, logical_height;
extern int  logical_byte_width, bytesperpixel;
extern char graphtoread[128];

extern bmode *best_mode_256_head;
extern bmode *best_mode_256_tail;
extern bmode *best_mode_32k16m_head;
extern bmode *best_mode_32k16m_tail;
extern bmode *best_mode_temp;

extern FILE *dfd; /* debug */

#ifndef TESTMODE
#define TESTMODE G640x480x32K
#endif
