
/*
 * display.c
 *
 * Copyright (C) 1993, 1994 Evan Harris
 *
 * Permission is granted to freely redistribute and modify this code,
 * providing the author(s) get credit for having written it.
 */

/*
 * (Evan) PIX_ALIGN changes inspired by Michael Weller, who patched against
 * version 1.1:
 *
 * Patched to not depend on illegal assumptions (xbytes==bytesperpixel*xdim),
 *         to obey logical_width a multiple of 8 pixels (not bytes)
 *         to let logical_width be an even higher multiple of a power of two
 *         for spike free video signal on Mach32
 * 16. 3. 94 Michael Weller (eowmob@exp-math.uni-essen.de or
 * eowmob@pollux.exp-math.uni-essen.de or mat42b@vm.hrz.uni-essen.de or
 * mat42b@de0hrz1a.bitnet) (svgalib, mach32-driver)
 */


#include "viewjpeg.h"
#include <string.h>
#include <unistd.h>
#include <vga.h>
#include <stdlib.h>

#ifdef USE_NCURSES
#include <ncurses.h>
#include "keydef.h"
#endif

#include <vgagl.h>

/*
 * Set PIX_ALIGN to be 64 because it seems to be a nice safe value.
 * Some cards can handle values much lower (which is desirable).
 * If your card can I would recommend trying values of 8, 16 or 32
 * before 64 (in the Makefile).
 * My CLGD5426 works correctly with a value of 8. 
 */

#ifndef PIX_ALIGN
#define PIX_ALIGN 8
#endif

/* the conext for the physical, and refresh screens */
GraphicsContext *physicalscreen;
GraphicsContext *backscreen;

/* define string used in writing stuff to screen */
char out[128];
char modeout[128];


/* get image data for local use */
struct IMAGE_DAT {
	int height;
	int width;
}; 
struct IMAGE_DAT image_data;

/*
 * Select the best video mode for the current video card.
 *
 * components: 3 for RGB, 1 for grayscale or colourmapped
 */
	

void
display_init(int image_width, int image_height, int components)
{
    int width, height;
    vga_modeinfo *vgainfo;

    width  = image_data.width  = image_width;
    height = image_data.height = image_height;

    modetype = best_mode(width, height, components);

    vgainfo = vga_getmodeinfo(modetype);

    bytesperpixel = vgainfo->bytesperpixel;
    mode_linewidth = vgainfo->linewidth;
  
    logical_byte_width = MAX(mode_linewidth, width * bytesperpixel);
    if (logical_byte_width % PIX_ALIGN != 0) {
	logical_byte_width += PIX_ALIGN - logical_byte_width % PIX_ALIGN;
    }

    /*
     * I don't really understand why we need this.
     * I wonder if it's documented somewhere...
     * 
     * (Michael, Mach32): well some cards want multiples of 8pixels in a row..
     * it is that easy.. 
     */
    if (logical_byte_width % (bytesperpixel * PIX_ALIGN) != 0) {
	logical_byte_width += (bytesperpixel * PIX_ALIGN)
	    - logical_byte_width % (bytesperpixel * PIX_ALIGN);
    }
    while (logical_byte_width / bytesperpixel
	   > vgainfo->maxpixels / mode_height) {
	logical_byte_width -= bytesperpixel * PIX_ALIGN;
    }

    logical_width  = logical_byte_width / bytesperpixel;
    logical_height = MIN(vgainfo->maxpixels * bytesperpixel / logical_byte_width, height);

#ifdef BUG_WORKAROUND
    vga_setmode(TEXT);
#endif	

    if (vga_getcurrentmode() != modetype) {
		vga_setmode(modetype);
    }
	
	/* set up the space on the screen as backscreen */
	gl_setcontextvgavirtual(modetype);
	backscreen = gl_allocatecontext();
	gl_getcontext(backscreen);

	/* set up the space on the screen as physicalscreen */
	gl_setcontextvga(modetype);
	physicalscreen = gl_allocatecontext();
	gl_getcontext(physicalscreen);

	/* set up the font for this screen size */
	initfont();
 
    vga_setdisplaystart(0);
    vga_setlogicalwidth(logical_byte_width);

    start_row = 0;


	gl_clearscreen(0); /* second replaces clearscreen */

    switch (mode_depth) {
	case 32768 : 
	   sprintf(modeout, " Mode is %dx%dx32K ", mode_width, mode_height);
       sprintf(out, "%s %dx%dx32K", graphtoread, image_width, image_height);
	   break;
	case 256 :
	   sprintf(modeout, " Mode is %dx%dx256 ", mode_width, mode_height);
        sprintf(out, "%s %dx%dx256", graphtoread, image_width, image_height);
	   break;
	case 16777216 :
 	   sprintf(modeout, " Mode is %dx%dx16M ", mode_width, mode_height);
       sprintf(out, "%s %dx%dx16M", graphtoread, image_width, image_height);
	   break;
	default :
 	   sprintf(modeout, " Mode is %dx%dx64K ", mode_width, mode_height);
       sprintf(out, "%s %dx%dx64K", graphtoread, image_width, image_height);
	   break;
	}
}


void
display_set_palette(int num_colors, JSAMPARRAY colormap, int components)
{
  int i;

  for (i = 0; i < num_colors; i++) {
    /* we should put these in an array so there's only one syscall */
    if (components == 1) {
      vga_setpalette(i, GETJSAMPLE(colormap[0][i]) >> 2,
		     GETJSAMPLE(colormap[0][i]) >> 2,
		     GETJSAMPLE(colormap[0][i]) >> 2);
    } else if (components == 3) {
      vga_setpalette(i, GETJSAMPLE(colormap[0][i]) >> 2,
		     GETJSAMPLE(colormap[1][i]) >> 2,
		     GETJSAMPLE(colormap[2][i]) >> 2);
    } else {
      error_exit("Cannot cope with number of colour components");
    }
  }
}


void
display_set_greyscale_palette()
{
  int i;

  for (i = 0; i < 256; i++) {
    vga_setpalette(i, i >> 2, i >> 2, i >> 2);
  }
}


void
display_rows(int num_rows, JSAMPIMAGE pixel_data, int image_width, int components) {
    JSAMPROW ptr0, ptr1, ptr2;
    int row, col;
    int width, height;
    int mode_row, mode_col;

    con_row = (mode_height-logical_height)/2;
    con_col = (mode_width-image_width)/2;

    width = MIN(image_width, logical_width);

    if (start_row < logical_height) {
	if (logical_height < start_row + num_rows) {
	    height = logical_height - start_row;
	} else {
	    height = num_rows;
	}
    } else {
	start_row += num_rows;
	return;
    }
  
    if (components == 1) {
	for (row = 0; row < height; row++) {
	    if(con_row > 0) {
	    	mode_row = (((start_row+con_row+row) * logical_byte_width)
			/ mode_linewidth);
	    }
	    else {
	    	mode_row = (((start_row+row) * logical_byte_width)
			/ mode_linewidth); 
	    }
	    if(con_col > 0) {
	        mode_col = con_col + ((((start_row+con_row+row) * logical_byte_width)
			% mode_linewidth) / bytesperpixel);
	    }
	    else {
	        mode_col = ((((start_row+row) * logical_byte_width)
			% mode_linewidth) / bytesperpixel);
	    }
	    ptr0 = pixel_data[0][row];
     
 
		for (col = 0; col < width; col++) {
		    vga_setcolor(GETJSAMPLE(*ptr0++));
		    vga_drawpixel(mode_col++, mode_row);
		    if (mode_col == mode_width) {
			mode_col = 0;
			mode_row++;
		    }
		}
	    }
    } else {
	for (row = 0; row < height; row++) {
	    if(con_row > 0) {
	    	mode_row = (((start_row+con_row+row) * logical_byte_width)
			/ mode_linewidth);
	    }
	    else {
	    	mode_row = (((start_row+row) * logical_byte_width)
			/ mode_linewidth); 
	    }
	    if(con_col > 0) {
	        mode_col = con_col + ((((start_row+con_row+row) * logical_byte_width)
			% mode_linewidth) / bytesperpixel);
	    }
	    else {
	        mode_col = ((((start_row+row) * logical_byte_width)
			% mode_linewidth) / bytesperpixel);
	    }

	    ptr0 = pixel_data[0][row];
	    ptr1 = pixel_data[1][row];
	    ptr2 = pixel_data[2][row];

		for (col = 0; col < width; col++) {
		    /* the slowest known solution... */
		    if (mode_depth == 32768) {
			vga_setcolor(((GETJSAMPLE(*ptr0++) & 0xf8) << 7)
				     | ((GETJSAMPLE(*ptr1++) & 0xf8) << 2)
				     | (GETJSAMPLE(*ptr2++) >> 3));
		    } else {
			vga_setcolor((GETJSAMPLE(*ptr0++) << 16)
				     | (GETJSAMPLE(*ptr1++) << 8)
				     | GETJSAMPLE(*ptr2++));
		    }
		    vga_drawpixel(mode_col++, mode_row);
		    if (mode_col == mode_width) {
			mode_col = 0;
			mode_row++;
		    }
		}
	    }
    }
    start_row += num_rows;
}


#define OFFSET_ROWS 8
#define OFFSET_COLS PIX_ALIGN	/* a high PIX_ALIGN is a pain here */


int
scroll_until_end()
{
    int c, done = 0, offset = 0, i = 0;
	int con_row, con_col;

	/* include ncurses scrolling options */
	#ifdef USE_NCURSES
	initscr();
	keypad(stdscr, TRUE);
	#endif
	
	/* copy the physical screen to the virtual screen */
	gl_copyscreen(backscreen);

    while (!done) {
	#ifdef USE_NCURSES
	  raw();
	  noecho();
	  c = getch();
	  noraw();
	  echo();
	#else
	  c = vga_getch();
	#endif
	switch (c) {
	  #ifdef USE_NCURSES
	    case KEY_ESC :
	  #else
	    case 0x1b:		/* ESC */
	  #endif
		    return ESC_KEY;
		    break;
	  #ifdef USE_NCURSES
	    case KEY_K :
	    case KEY_k :
	    case KEY_UP :
	  #else
	    case 'K' :	/* up */
	    case 'k' :	/* up */
	  #endif
		    if (offset > 0) {
			offset -= OFFSET_ROWS * logical_byte_width;
			while (offset < 0) {
			    offset += logical_byte_width;
			}
			vga_setdisplaystart(offset);
		    }
		    break;
	  #ifdef USE_NCURSES
	    case KEY_J :
        case KEY_j :
	    case KEY_DOWN :
	  #else
	    case 'J' :	/* down */
	    case 'j' :	/* down */
	  #endif
		    if (offset / logical_byte_width
			< logical_height - mode_height) {
			offset += MIN(OFFSET_ROWS,
				      logical_height - mode_height
				      - offset / logical_byte_width)
			    * logical_byte_width;
			vga_setdisplaystart(offset);
		    }
	    	break;
	  #ifdef USE_NCURSES
	    case KEY_L :
	    case KEY_l :
	  case KEY_RIGHT :
	  #else
	    case 'L' :	/* left */
	    case 'l' :	/* left */
	  #endif
		    if ((offset % logical_byte_width) / bytesperpixel
			+ mode_width
			< logical_width) {
			offset += MIN(OFFSET_COLS * bytesperpixel,
				      (logical_width - mode_width)
				      * bytesperpixel
				      - offset % logical_byte_width);
			vga_setdisplaystart(offset);
		    }
		    break;
	  #ifdef USE_NCURSES
	    case KEY_H :
	    case KEY_h :
	    case KEY_LEFT :
	  #else
	    case 'H' :	/* right */
	    case 'h' :	/* right */
	  #endif
		    if (offset % logical_byte_width > 0) {
			offset -= MIN(OFFSET_COLS * bytesperpixel,
				      offset % logical_byte_width);
			vga_setdisplaystart(offset);
		    }
		    break;
	  #ifdef USE_NCURSES
	    case KEY_ENTER :
		case KEY_N :
		case KEY_n :
	  #else
	    case '\n' : /* Enter */
		case 'N' :
		case 'n' :
	  #endif
			gl_freecontext(backscreen);
			gl_freecontext(physicalscreen);
			return RETURN_KEY;
		    break;
	  #ifdef USE_NCURSES
	    case KEY_BACK :
		case KEY_P :
		case KEY_p :
	  #else
		case '\b' :
		case 'P' :
		case 'p' :
	  #endif
		return BACK_KEY;
		break;
	  #ifdef USE_NCURSES
	    case KEY_CTRL_X :
	  #else
	    case CTRL_X : /* CTRL-X */
	  #endif
			gl_freecontext(backscreen);
			gl_freecontext(physicalscreen);
			return CTRL_X_KEY;
		    break;
	  #ifdef USE_NCURSES
	    case KEY_I :
	    case KEY_i :
	  #else
	    case 'I' :
	    case 'i' :
	  #endif
			gl_setcontext(backscreen);
			gl_copyscreen(physicalscreen);
			gl_setcontext(physicalscreen);
			writefont(out);
		    break;
	  #ifdef USE_NCURSES
		case KEY_M :
		case KEY_m :
	  #else
		case 'M' :
		case 'm' :
	  #endif
			gl_setcontext(backscreen);
			gl_copyscreen(physicalscreen);
			gl_setcontext(physicalscreen);
			writefont(modeout);
		    break;
	  #ifdef USE_NCURSES
	    case KEY_ADD :
	  #else
	    case ADD : /* add */
	  #endif
		    i = setfixdisplay(1);
			if(i != -1) { 
				opt_forcemode = i; 
				gl_freecontext(backscreen);
				gl_freecontext(physicalscreen);
		    return ADD_KEY;
			}
			else {
				done = 0;
			}	
		    break;
	  #ifdef USE_NCURSES
	    case KEY_SUB :
	  #else
	    case SUB : /* sub */
	  #endif
		    i = setfixdisplay(-1);
			if(i != -1) { 
				opt_forcemode = i; 
				gl_freecontext(backscreen);
				gl_freecontext(physicalscreen);
			    return SUB_KEY;
			}
			else {
				done = 0;
			}	
		    break;
	  #ifdef USE_NCURSES
	    case KEY_SPACE :
	  #else
	    case ' ' :
	  #endif
			gl_freecontext(backscreen);
			gl_freecontext(physicalscreen);
			return SPACE_KEY;
	  #ifdef USE_NCURSES
	    case KEY_R :
	    case KEY_r :
	  #else
	    case 'r' :
	    case 'R' :	
	  #endif
			gl_setcontext(backscreen);
			gl_copyscreen(physicalscreen);
			gl_setcontext(physicalscreen);
			done = 0;
			break;
	  default:
		    done = 0;
		    break;
      }
   }
}


void
display_shutdown()
{
    vga_setmode(TEXT);
}
