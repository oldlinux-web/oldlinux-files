/* define keys for keypad */
#define KEY_CTRL_X 	24 
#define KEY_ESC 	27 
#undef  KEY_HELP /* previusly defined by ncurses.h */
#define KEY_HELP    63
#define KEY_D		68
#define KEY_d		100
#define KEY_J		74
#define KEY_j		106
#define KEY_L		76
#define KEY_l		108
#define KEY_H		72
#define KEY_h		104
#define KEY_K		75
#define KEY_k		107
#define KEY_I		73
#define KEY_i		105
#undef  KEY_ENTER /* previusly defined by ncurses.h */
#define KEY_ENTER	10
#define KEY_SPACE	32
#define KEY_R		82
#define KEY_r		114
#define KEY_Q		81
#define KEY_q		113
#undef  KEY_F /* previusly defined by ncurses.h */
#define KEY_F		70
#define KEY_f		102
#define KEY_W		87
#define KEY_w		119
#define KEY_O		79
#define KEY_o		111
#define KEY_U		85
#define KEY_u		117
#define KEY_M		77
#define KEY_m		109
#define KEY_G		71
#define KEY_g		103
#define KEY_V		86
#define KEY_v		118
#define KEY_SUB		45
#define KEY_ADD		43
#define KEY_P		80
#define KEY_p		112
#define KEY_N		78
#define KEY_n		110
#define KEY_S		83
#define KEY_s		115
#define KEY_BACK	127
