/* information for bitmaps were taken from the independent jpeg group's
   rdbmp.c as well microsoft's bitmap.doc */

#include "viewjpeg.h"
#include <vga.h>
#include <vgagl.h>

#define red_color   0
#define green_color 1
#define blue_color  2

#define COMPRESSED_RGB  0
#define COMPRESSED_RLE8 1
#define COMPRESSED_RLE4 2

#define MICROSOFT 0
#define OS2 1

struct image_data {
	int  image_type; /* type mircosoft or os2 */
	int  image_size; /* image size in bytes */
	int  image_height; /* image height */
	int  image_width; /* image width */
	int  image_planes; 
	int  number_of_colors; /* number of color 0 means ma for mode */
	int  bit_count; /* color depth 1 to 24bits */
	int  components; /* components used ie color depth */
	int  colormap[3][256]; /* color table for 8 bit bmp's */
	int  colormap_switch;
	int  image_compression; /* compression type */
	FILE *bitmap;
};

struct image_data image;


void
error_exit_bmp(char *text) { /* deal with error messages */
	fprintf(stderr, "%s\n", text);
	display_shutdown();
}


/* read in the color map */
void
read_colormap(int *cmap_read_size) { /* works */

	int i, cmap_length;
	cmap_length = (image.number_of_colors) ? image.number_of_colors : 1 << image.bit_count;
    for (i = 0; i < cmap_length; i++) {
	   	image.colormap[blue_color][i]  = getc(image.bitmap);
		image.colormap[green_color][i] = getc(image.bitmap);
	   	image.colormap[red_color][i]   = getc(image.bitmap);
		if(image.image_type == MICROSOFT) { /* os2 images have no blanks */
	    	(void) getc(image.bitmap);
			*cmap_read_size -= 4;
		}
		else { *cmap_read_size -= 3; } /* os2 2.X formated colormap */
   	}

	for(i = 0; i < cmap_length; i++) {
		if(image.colormap[red_color][i] == 0 && image.colormap[green_color][i] == 0 && image.colormap[blue_color][i] == 0) {
			image.colormap_switch = i;
			image.colormap[red_color][i] = image.colormap[red_color][0];
			image.colormap[red_color][0] = 0;
			image.colormap[green_color][i] = image.colormap[green_color][0];
			image.colormap[green_color][0] = 0;
			image.colormap[blue_color][i] = image.colormap[blue_color][0];
			image.colormap[blue_color][0] = 0;
			break;
		}
	}

	/* if greyscale then greyscale the colormap */
	if(opt_greyscale == 1) { greyscale_colormap(cmap_length, image.colormap); } 
}


void
display_256_bmp(int saved_image[image.image_height+1][image.image_width+1]) {

  	int row, col, offset_height, offset_width, color_number;
	int blue, green, red; /* for use with 24bit displays */

	/* find the offsets for writing to the screen */
	if(image.image_height > mode_height || image.image_width > mode_width) {
		offset_height = 0;
		offset_width = 0;
	}
	else { /* if to lage for screen then offsets are 0,0 */
		offset_height = (mode_height - image.image_height)/2;
		offset_width = (mode_width - image.image_width)/2;
	}

	/* setup the display palette and view bitmap */
	if(mode_depth == 256) { /* display in 8bit mode */
		set_custom_palette(image.number_of_colors, image.colormap); /* set up palette */
		for(row = 0; row < image.image_height; row++) {
			for(col = 0; col < image.image_width; col++) {
				color_number = saved_image[col][row];
				if(color_number == image.colormap_switch) { gl_setpixel(col+offset_width, row+offset_height, 0); }
				if(color_number == 0) { gl_setpixel(col+offset_width, row+offset_height, image.colormap_switch); }
				else { gl_setpixel(col+offset_width, row+offset_height, color_number); }
			}
		}
	}
	else { /* display in true color mode */
		for(row = 0; row < image.image_height; row++) {
			for(col = 0; col < image.image_width; col++) {
				red   = image.colormap[red_color]  [ saved_image[col][row] ];
				green = image.colormap[green_color][ saved_image[col][row] ];
				blue  = image.colormap[blue_color] [ saved_image[col][row] ];
				gl_setpixelrgb(col+offset_width, row+offset_height, red, green, blue); 
			}
		}
	}
}


void
display_8bit_bmp() { /* read in bitmap information */

	int saved_image[image.image_height+1][image.image_width+1];
	int c, c1, i, row, col;

	if(image.image_compression == COMPRESSED_RGB) { /* std uncompressed bitmaps */
    	for (row = (image.image_height - 1); row >= 0; row--) {
   			for (col = 0; col < image.image_width; col++) {
				c = getc(image.bitmap);  
				if (c==EOF) { fprintf(stderr, "error reading bmp\n"); col++; }
				else { saved_image[col][row] = c; }
			}
   		}
	}

	/* if compressed then decompress the bmp */
	else { 
		row = image.image_height;
		col = 0;
		while(row > 0) { 
			c = getc(image.bitmap);
			if(c == 0x00) { /* escape codes */
				c1 = getc(image.bitmap);
				switch (c1) {  
					case 0x00 : /* end of a row */
						row--;
						col = 0;
						break;
 					case 0x01 : /* end of the bitmap */
						row = 0; /* end of bitmap then quit */
						break;
					case 0x02 : /* movemove in x then y order */
						c1 = getc(image.bitmap);
						col += c1;
						c1 = getc(image.bitmap);
						row -= c1;
						break;
					default :
						for(i = 0; i < c1; i++, col++) { saved_image[col][row] = getc(image.bitmap); }
						if(c1 & 1) { getc(image.bitmap); } /* if odd number make it even */
						break;
				}
			}
			else if (c == EOF) { fprintf(stderr, "error reading bmp\n"); } /* error message */
			else { /* ecoded mode */
				c1 = getc(image.bitmap);
				for(i = 0; i < c; i++, col++) {
					saved_image[col][row] = c1;
				 }		
			}
		} /* while */
	} /* else */

	display_256_bmp(saved_image); /* display 256 color bitmap */
}


void
display_16m_bmp() { /* diplay hires bitmaps ie 24bit ones */

	int   c, row, col, blue, green, red, offset_width, offset_height;

	if(image.image_height > mode_height || image.image_width > mode_width) {
		offset_height = 0;
		offset_width = 0;
	}
	else {
		offset_height = (mode_height - image.image_height)/2;
		offset_width = (mode_width - image.image_width)/2;
	}

	/* read each set of 3 number standing for the color and use it for that pixel */
    for (row = ((image.image_height+offset_height) - 1); row >= offset_height; row--) {
   		for (col = offset_width; col < (image.image_width+offset_width); col++) {
			blue  = getc(image.bitmap);
			green = getc(image.bitmap);
			red   = getc(image.bitmap);
			if (blue == EOF)  { fprintf(stderr, "error reading bmp blue\n"); }
			if (green == EOF) { fprintf(stderr, "error reading bmp green\n"); }
			if (red == EOF)   { fprintf(stderr, "error reading bmp red\n"); }
			gl_setpixelrgb(col, row, red, green, blue); 
    	}
	}
}  


void
display_24bit_bmp() { /* read 24bit bitmaps information */

	int saved_image[image.image_height+1][image.image_width+1]; /* image array */
	int i, blue, green, red, cmap_value_last = 1;
	int col, row;

	if(opt_quantize == 0) { display_16m_bmp(); } /* if still full color just read it in */
	/* does not work but I do not know how to do it so this will work for 256 colors or less */
	else {
	   	for (row = image.image_height; row > 0; row--) {
			for (col = 0; col < image.image_width; col++) {
				blue  = getc(image.bitmap);
				green = getc(image.bitmap);
				red   = getc(image.bitmap);
				for(i = 0; i <= cmap_value_last; i++) {
					if(blue == image.colormap[blue_color][i]  &&
					  green == image.colormap[green_color][i] &&
					  red   == image.colormap[red_color][i]) {
						saved_image[col][row] = i;
						break;
					}
				}
				if(i > cmap_value_last && cmap_value_last < 255) {
					image.colormap[red_color]  [cmap_value_last] = red;
					image.colormap[green_color][cmap_value_last] = green;
					image.colormap[blue_color] [cmap_value_last] = blue;
					saved_image[col][row] = cmap_value_last;
					cmap_value_last++;
				}
			} /* for col */
		} /* for row */

		image.number_of_colors = cmap_value_last;
		display_256_bmp(saved_image); /* view it as a 256 color bitmap */
	} /* end else */
}


int
read_bmp_file(char *image_name) {

	int  i, bytes_off, header_size, cmap_offset, padding;
	int  bmp_header[54];

	#define BYTES_PER_COLOR 4
	#define UCH(x)	((int) (x))
	#define GET_2B(array,offset)  ((unsigned int) UCH(array[offset]) + \
			       (((unsigned int) UCH(array[offset+1])) << 8))
	#define GET_4B(array,offset)  ((int) UCH(array[offset]) + \
			       (((int) UCH(array[offset+1])) << 8) + \
			       (((int) UCH(array[offset+2])) << 16) + \
			       (((int) UCH(array[offset+3])) << 24))

	image.bitmap = fopen(image_name, "rb"); 

	for(i = 0; i < 54; i++) {
		bmp_header[i] = getc(image.bitmap);
	}

	/* get bmp data */
	bytes_off 		      = (int) GET_4B(bmp_header,10);
	header_size 		      = (int) GET_4B(bmp_header,14);
	image.image_width             = (int) GET_4B(bmp_header,18);
   	image.image_height            = (int) GET_4B(bmp_header,22);
	image.image_planes	      = (int) GET_2B(bmp_header,26); 
  	image.bit_count		      = (int) GET_2B(bmp_header,28);
	image.image_compression	      = (int) GET_4B(bmp_header,30);
	image.image_size              = (int) GET_4B(bmp_header,34);
	image.number_of_colors        = (int) GET_4B(bmp_header,46);
	/* OFFSET TO 54 PALECES IN FILE */

	/* check for format errors */
	if(image.image_compression == COMPRESSED_RLE4) { error_exit_bmp("4bit compressed format bitmap"); }
	if(header_size == 12) { error_exit_bmp("os2 1.X or windows 2.X bitmap"); }

	if(image.bit_count < 8) { error_exit_bmp("1 or 4bit bitmap type not supported"); }

	/* only big difference should be in the color map wether it is 3 or 4 bits long per color */
	if(header_size == 64) { image.image_type = OS2; } 
	else { image.image_type = MICROSOFT; }

	cmap_offset = header_size-40;
	for(i = 0; i < cmap_offset; i++) { (void) getc(image.bitmap); } /* make up the extra spaces */

	padding = bytes_off - (header_size -14); /* setup buffer of colormap */

	/* get colormaps and setup compoents for video mode */
	if(opt_forcemode == 0) { /* 8bit bitmaps should have 1 component ie 256 colors if not forced */
		if(image.bit_count == 8) { 
			image.components = 1;
			read_colormap(&padding);
		}
		/* if quantizing or greyscaling components must be 1 */
		else if(opt_quantize == 1 || opt_greyscale == 1) { image.components = 1; } 
		else { image.components = 3; } /* 24bit bitmaps should have 3 components unless forced */
	}
	else { /* if a mode is forced set the componets to that modetype */
		switch (opt_forcemode) {
			case 12:
			case 11:
		  	case 10:
		  	case 5:
				image.components = 1;
				if(image.bit_count == 8) { read_colormap(&padding); }
		    	break;
		  	default :
				image.components = 3;
				if(image.bit_count == 8) { read_colormap(&padding); }
		    	break;
		}
    }

	display_init(image.image_height, image.image_width, image.components);

	while (--padding > 0) { /* may not be needed */
    	(void) getc(image.bitmap);
  	}

	/* reset the bitmap and move to correct position */
	rewind(image.bitmap);
	for(i = 0; i < bytes_off; i++) { (void) getc(image.bitmap); }

	if (image.bit_count == 24) { display_24bit_bmp(); }
	else { display_8bit_bmp(); }

	fclose(image.bitmap);

	return scroll_until_end();
}

