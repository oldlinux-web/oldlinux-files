
#include "viewjpeg.h"
#include <vga.h>
#include <vgagl.h>

#define red_color   0
#define green_color 1
#define blue_color  2

void
convert_to_bin(char c, int *ret0, int *ret1, int *ret2, int *ret3) {

	switch(c) {
		case '0' : 
			*ret0 = 0; *ret1 = 0; *ret2 = 0; *ret3 = 0; 
			break;
		case '1' :
			*ret0 = 0; *ret1 = 0; *ret2 = 0; *ret3 = 1;
			break;
		case '2' :
			*ret0 = 0; *ret1 = 0; *ret2 = 1; *ret3 = 0;
			break;
		case '3' :
			*ret0 = 0; *ret1 = 0; *ret2 = 1; *ret3 = 1;
			break;
		case '4' : 
			*ret0 = 0; *ret1 = 1; *ret2 = 0; *ret0 = 0;
			break;
		case '5' :
			*ret0 = 0; *ret1 = 1; *ret2 = 0; *ret3 = 1; 
			break;
		case '6' :
			*ret0 = 0; *ret1 = 1; *ret2 = 1; *ret3 = 0;
			break;
		case '7' :
			*ret0 = 0; *ret1 = 1; *ret2 = 1; *ret3 = 1;
			break;
		case '8':
			*ret0 = 1; *ret1 = 0; *ret2 = 0; *ret3 = 0;
			break;
		case '9' :
			*ret0 = 1; *ret1 = 0; *ret2 = 0; *ret3 = 1;
			break;
		case 'A' : case 'a' :
			*ret0 = 1; *ret1 = 0; *ret2 = 1; *ret3 = 0;
			break;
		case 'B' : case 'b' :
			*ret0 = 1; *ret1 = 0; *ret2 = 1; *ret3 = 1;
			break;
		case 'C' : case 'c' : 
			*ret0 = 1; *ret1 = 1; *ret2 = 0; *ret3 = 0;
			break;
		case 'D' : case 'd' :
			*ret0 = 1; *ret1 = 1; *ret2 = 0; *ret3 = 1;
			break;
		case 'E' : case 'e' :
			*ret0 = 1; *ret1 = 1; *ret2 = 1; *ret3 = 0;
			break;
		case 'F' : case 'f' :
			*ret0 = 1; *ret1 = 1; *ret2 = 1; *ret3 = 1;
			break;
	}
}	


void
display_256_xbitmap(int width, int height, FILE *xbitmap) {

	int offset_width, offset_height, pic1[4], pic2[4], row_display;
	int row, col, pos, picture[height * width * 2], i, j = 0, k;
	int finished = 0, colormap[3][256], saved_image[height + 1][width + 1];
	char c;

	while(!finished) {
		c = getc(xbitmap);
		for (; c != 'x' && c != '}'; c = getc(xbitmap));
		if(c !='}') {
			c = getc(xbitmap);
			convert_to_bin( c, &picture[j+7], &picture[j+6], &picture[j+5], &picture[j+4]);
			c = getc(xbitmap);
			convert_to_bin( c, &picture[j+3], &picture[j+2], &picture[j+1], &picture[j]);
			j += 8;
			picture[j] = 3; /* test */
			j++;
		} else { finished = 1; }
	}

	/* find the offsets for writing to the screen */
	/* if to lage for screen then offsets are 0,0 */
	if( (height * 2) > mode_height || (width * 2) > mode_width) { 
		offset_height = 0;
		offset_width = 0;
	}
	else { 
		offset_height = (mode_height - (height * 2) )/2;
		offset_width = (mode_width - (width * 2) )/2;
	}

	for(row = 0, pos = 0; row < height; row++) {
		for(col = 0; col < width; col++, pos++) {
			if(picture[pos] == 3) pos++;
			saved_image[row][col] = picture[pos];
		}
		while (picture[pos] != 3) {
			pos++;
			}
		++pos;
	}

	if(mode_depth == 256) { /* display in 8bit mode */
		colormap[red_color][0] = colormap[green_color][0] = colormap[blue_color][0] = 0;
		colormap[red_color][1] = colormap[green_color][1] = colormap[blue_color][1] = 255;
		colormap[red_color][2] = colormap[green_color][2] = colormap[blue_color][2] = 60;
		set_custom_palette(3, colormap); /* set up palette */
	
		for(row = 1, row_display = 0; row < height + 1; row++) { 
			for(k = 0; k < 2; k++) {
				col = j = 0; 
				for(col = 0, j = 0; col < width; col++) {
					gl_setpixel(j+offset_width, row_display+offset_height, saved_image[row][col] + 1);
					j++;
					gl_setpixel(j+offset_width, row_display+offset_height, saved_image[row][col] + 1);
					j++;
				}
				row_display++;
			}
		}
	}
	else {
		for(row = 1, row_display = 0; row < height + 1; row++) { 
			for(k = 0; k < 2; k++) {
				col = j = 0; 
				for(col = 0, j = 0; col < width; col++) {
					if(saved_image[row][col] == 0) {
						gl_setpixelrgb(j+offset_width, row_display+offset_height, 255, 255, 255);
						j++;
						gl_setpixelrgb(j+offset_width, row_display+offset_height, 255, 255, 255);
						j++;
					}
					else {
						gl_setpixelrgb(j+offset_width, row_display+offset_height, 60, 60, 60);
						j++;
						gl_setpixelrgb(j+offset_width, row_display+offset_height, 60, 60, 60);
						j++;
					}
				}
				row_display++;
			}
		}
	}
}


int
read_xbitmap_file(char *image_name) {
	
	FILE *xbitmap;
	char *line, *name;
	int width, height;
	int components, i;

	xbitmap = fopen(image_name, "r");

	fgets(line, 256, xbitmap);
	for(i = 0; line[i] != ' '; i++);
	i++;
	for(; line[i] != ' '; i++);
	i++;
	width  =  convert_to_int(line[i++]) * 10;
	width += convert_to_int(line[i]);

	fgets(line, 256, xbitmap);
	for(i = 0; line[i] != ' '; i++);
	i++;
	for(; line[i] != ' '; i++);
	i++;
	height  =  convert_to_int(line[i++]) * 10;
	height += convert_to_int(line[i]);

	do {
		fgets(line, 256, xbitmap);
	} while(strncmp(line, "static", 6) != 0);

	if(opt_forcemode == 0) { components = 1; }
	else {
		switch (opt_forcemode) {
			case 12:
			case 11:
		  	case 10:
		  	case 5:
				components = 1;
				break;
		  	default :
				components = 3;
				break;
		}
	}

	display_init( (height * 2), (width * 2), components);

	display_256_xbitmap(width, height, xbitmap);
	fclose(xbitmap);
	return scroll_until_end();
}
