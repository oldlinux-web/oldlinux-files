#include "frontend.h"
#include "keydef.h"

void
runexit(int d) {

	WINDOW	*exitwin;
	int 	i;

	/* free up the screen windows */
	for(i = 0; i < (LINES-5); i++) {
		delwin(window[i] );
		delwin(window[i+(LINES-4)] );
		delwin(window[i+((LINES-4)*2)] );
	}

	if(d == ON) { 
    	exitwin = newwin(3, 25, (LINES/2-1), (COLS-COLS/2-13) );
	    wborder(exitwin, ACS_VLINE, ACS_VLINE, ACS_HLINE, ACS_HLINE,
    	                 ACS_ULCORNER, ACS_URCORNER, ACS_LLCORNER, ACS_LRCORNER); 
		wattron(exitwin, A_BLINK);
    	mvwprintw(exitwin, 1, 2, "Press any key to exit");
	    wrefresh(exitwin);
	    wgetch(exitwin);
	}
    clear();
    refresh();
    exit(0);
}


int
runvideo(int forcemode) {


	WINDOW	*videowin[12], *videowin_gobal;
	char	*info_for_mode[] = {
		"Mode 5  :  320x200x256",
		"Mode 10 :  640x480x256",
		"Mode 11 :  800x600x256",
		"Mode 12 : 1024x768x256",
		"Mode 17 :  640x480x32K",
		"Mode 20 :  800x600x32K",
		"Mode 23 : 1024x768x32K",
		"Mode 33 :  320x200x16M",
		"Mode 34 :  640x480x16M",
		"Mode 35 :  800x600x16M",
		"Mode 0  :force no mode", 
		" ",
	};
		
	int 	get_mode, i = 0, curwin;
	
	/* create video window */

	videowin_gobal = newwin(15, 24, (LINES/2-7), (COLS-COLS/2-12) );
	keypad(videowin_gobal, TRUE);
	for(i = 1; i < 12; i++) {
		videowin[i] = derwin(videowin_gobal, 1, 22, i, 1);
	}
    werase(videowin_gobal); 

    wborder(videowin_gobal, ACS_VLINE, ACS_VLINE, ACS_HLINE, ACS_HLINE,
                       ACS_ULCORNER, ACS_URCORNER, ACS_LLCORNER, ACS_LRCORNER); 

  	switch(forcemode) {
		case 0 :
			curwin = 10;
			break;
		case 5 :
			curwin = 0;
			break;
		case 10 :
			curwin = 1;
			break;
		case 11 :
			curwin = 2;
			break;
		case 12 :
			curwin = 3;
			break;
		case 17 :
			curwin = 4;
			break;
		case 20 :
			curwin = 5;
			break;
		case 23 :
			curwin = 6;
			break;
		case 33 :
			curwin = 7;
			break;
		case 34 :
			curwin = 8;
			break;
		case 35 :
			curwin = 9;
			break;
	}
	wattron(videowin[curwin], A_BOLD);
	for(i = 0; i < 11; i++) {
		wprintw(videowin[i], "%s", info_for_mode[i]);
	}
	wattroff(videowin[curwin], A_BOLD);
	mvwprintw(videowin_gobal, 11, 4, "use JK and the ");
	mvwprintw(videowin_gobal, 12, 2, "arrow keys to choice");

	/* update all the windows */
	wrefresh(videowin_gobal);

	do {
	  raw();
	  noecho();
	  get_mode = wgetch(videowin_gobal);
	  echo();
	  noraw();
	
	  switch(get_mode) {
		case KEY_J :	/* down */
		case KEY_j :	
		case KEY_DOWN :	
			werase(videowin[curwin]);
			wprintw(videowin[curwin], "%s", info_for_mode[curwin]);
		    wrefresh(videowin[curwin]);
			if(curwin < 10) {
				curwin++;
				wattron(videowin[curwin], A_BOLD);
			}
			else {
				curwin = 1;
				wattron(videowin[curwin], A_BOLD);
			}
			wprintw(videowin[curwin], "%s", info_for_mode[curwin]);
			wattroff(videowin[curwin], A_BOLD);
			wrefresh(videowin[curwin]);
			break;
		case KEY_K :	
		case KEY_k :	
		case KEY_UP :	
			werase(videowin[curwin]);
			wprintw(videowin[curwin], "%s", info_for_mode[curwin]);
		    wrefresh(videowin[curwin]);
			if(curwin > 1) {
				curwin--;
				wattron(videowin[curwin], A_BOLD);
			}
			else {
				curwin = 10;
				wattron(videowin[curwin], A_BOLD);
			}
			wprintw(videowin[curwin], "%s", info_for_mode[curwin]);
			wattroff(videowin[curwin], A_BOLD);
			wrefresh(videowin[curwin]);
			break;
		case KEY_ENTER :	
			switch(curwin) {
				case 10 :
					curwin = 0;
					break;
				case 0 :
					curwin = 5;
					break;
				case 1 :
					curwin = 10;
					break;
				case 2 :
					curwin = 11;
					break;
				case 3 :
					curwin = 12;
					break;
				case 4 :
					curwin = 17;
					break;
				case 5 :
					curwin = 20;
					break;
				case 6 :
					curwin = 23;
					break;
				case 7 :
					curwin = 33;
					break;
				case 8 :
					curwin = 34;
					break;
				case 9 :
					curwin = 35;
					break;
			}
			forcemode = curwin;		
			break;
		case KEY_CTRL_X :
				for(i = 0; i < 10; i++) {
					delwin(videowin[i]);
				}
				delwin(videowin_gobal);
				runexit(ON);
				break; 
	  }
	} while (get_mode != KEY_ENTER); 

	/* clean up the screen delete windows and the such */
	for(i = 0; i < 10; i++) {
		delwin(videowin[i]);
	}
	delwin(videowin_gobal);
	dorefreshwindows();
	return forcemode;
}


void
changeopts(opts *options) {

  WINDOW 	*infowin;
  char		chopt;
  float		fuzz;
  int		i = 0;
  opts 		temp;

	temp = *options;
	
	/* create options menu and alow changes to it */
	infowin = newwin(15, 40, (LINES/2-7), (COLS-COLS/2-20) );
	keypad(infowin, TRUE);
	while(i != 1) {
        werase(infowin); 
        wborder(infowin,   ACS_VLINE, ACS_VLINE, ACS_HLINE, ACS_HLINE,
                           ACS_ULCORNER, ACS_URCORNER, ACS_LLCORNER,
		      			   ACS_LRCORNER); 
		mvwprintw(infowin, 1, 13, "Viewjpeg 1.0");
		mvwprintw(infowin, 2, 7, "GreyScale/Onepass  : ");
		if (temp.opt_greyscale == OFF) { wprintw(infowin, "off"); }
		else { wprintw(infowin, "on"); }
		mvwprintw(infowin, 3, 7, "qUatize            : ");
		if (temp.opt_quantize == OFF) { wprintw(infowin, "off"); }
		else { wprintw(infowin, "on"); }
		mvwprintw(infowin, 4, 7, "Onepass/Quatize    : ");
		if (temp.opt_onepass == OFF) { wprintw(infowin, "off"); }
		else { wprintw(infowin, "on"); }
		mvwprintw(infowin, 5, 7, "use Width only     : ");
		if (temp.opt_widthonly == OFF) { wprintw(infowin, "off"); }
		else { wprintw(infowin, "on"); }
		mvwprintw(infowin, 6, 7, "Fuzz factor        : %1.1f", temp.opt_fuzz);
		mvwprintw(infowin, 7, 7, "Video mode forcing : ");
		if (temp.opt_forcemode == OFF) { wprintw(infowin, "off"); }
		else { wprintw(infowin, "on"); }
		mvwprintw(infowin, 8, 7, "view Marked files  : ");
		if (dirwininfo.viewmarked == OFF) { wprintw(infowin, "off"); }
		else { wprintw(infowin, "on"); }		
		mvwprintw(infowin, 10, 13, "use q to Quit");
		chopt = mvwgetch(infowin, 11, 19);
		wrefresh(infowin);
		switch (chopt) {
			case KEY_V :
			case KEY_v :
				temp.opt_forcemode = runvideo(temp.opt_forcemode);
				break;
			case KEY_G :
			case KEY_g : 
				if (temp.opt_greyscale == OFF) { 
					temp.opt_greyscale = ON;
					temp.opt_onepass   = ON; 
					temp.opt_quantize  = ON; 
				}
				else { 
					temp.opt_greyscale = OFF; 
					temp.opt_onepass   = OFF; 
					temp.opt_quantize  = OFF;
				}
				break;
			case KEY_M :
			case KEY_m :
				if (dirwininfo.viewmarked == OFF) { dirwininfo.viewmarked = ON; }
				else { dirwininfo.viewmarked = OFF; }
				break;
			case KEY_U : 
			case KEY_u :
				if (temp.opt_quantize == OFF) { temp.opt_quantize = ON; }
				else { temp.opt_quantize = OFF; }
				break;
			case KEY_O : 
			case KEY_o :
				if (temp.opt_onepass == OFF) { 
					temp.opt_onepass  = ON;
					temp.opt_quantize = ON;
				}
				else { 
					temp.opt_onepass  = OFF;
					temp.opt_quantize = OFF; 
				}
				break;
			case KEY_W : 
			case KEY_w :
				if (temp.opt_widthonly == OFF) { temp.opt_widthonly = ON; }
				else {  temp.opt_widthonly = OFF; }
				break;
			case KEY_F : 
			case KEY_f :
				mvwprintw(infowin, 11, 10, "Current fuzz is %1.1f", temp.opt_fuzz);
				mvwprintw(infowin, 13, 7, "Enter new fuzz [.5, 1] ");
				wscanw(infowin, "%f", &fuzz);
				temp.opt_fuzz = fuzz;
				if (temp.opt_fuzz < .5 || temp.opt_fuzz > 1.0) { temp.opt_fuzz = 1.0; }
				break;
			case KEY_Q :
			case KEY_q :
				i = 1;
				break;
			case KEY_CTRL_X :
				delwin(infowin);
				runexit(ON);
				break; 
			case KEY_HELP :
				runopthelp();
				wrefresh(infowin);
				break;
			default :
				break;
		}			
	}
	delwin(infowin);
    writeoutlist(dirwininfo.writeoffset); 
	dorefreshwindows();
	*options = temp;
}


void
runhelp() {

	WINDOW  *helpwin;

	/* create window options */
	helpwin = newwin(17, 36, (LINES/2-8), (COLS-COLS/2-18) );
	werase(helpwin);
	mvwprintw(helpwin, 1, 13, "HelpMenu\n");
	mvwprintw(helpwin, 2, 13, "--------\n");
	wprintw(helpwin, "  H Scroll one colmn to the left\n");
	wprintw(helpwin, "  L Scroll one colmn to the right\n");
	wprintw(helpwin, "  J Scroll up one line\n");
	wprintw(helpwin, "  K Scroll down one line\n");
	wprintw(helpwin, "  D Enter a new directory\n");
	wprintw(helpwin, "  I change view options\n");
	wprintw(helpwin, "  R Refresh the screen\n");
	wprintw(helpwin, "  U Go to prevous directory\n");
	wprintw(helpwin, "  ENTER  current view image\n");
	wprintw(helpwin, "  SPACE  mark current image\n");
	wprintw(helpwin, "  CTRL_X to exit program\n"); 
	wprintw(helpwin, "\n"); 
	mvwprintw(helpwin, 15, 5, "Press enter to continue\n");
	wborder(helpwin, ACS_VLINE, ACS_VLINE, ACS_HLINE, ACS_HLINE,
    	             ACS_ULCORNER, ACS_URCORNER, ACS_LLCORNER, ACS_LRCORNER); 
	wrefresh(helpwin);
	getchar();
	delwin(helpwin);
    writeoutlist(dirwininfo.writeoffset);
	dorefreshwindows();
}


void
runopthelp() {

	WINDOW  *helpwin;

	/* create window options */
	helpwin = newwin(12, 26, (LINES/2-6), (COLS-COLS/2-13) );
	werase(helpwin);
	mvwprintw(helpwin, 1, 8, "HelpMenu\n");
	mvwprintw(helpwin, 2, 8, "--------\n");
	wprintw(helpwin, "  V change video mode\n");
	wprintw(helpwin, "  G grey scale images\n");
	wprintw(helpwin, "  F change fuzz factor\n");
	wprintw(helpwin, "  U Quatize to 256 colors\n");
	wprintw(helpwin, "  M View marked files\n");
	wprintw(helpwin, "  Q Quit menu\n");
	mvwprintw(helpwin, 10, 1, "Press enter to continue\n");
	wborder(helpwin, ACS_VLINE, ACS_VLINE, ACS_HLINE, ACS_HLINE,
    	             ACS_ULCORNER, ACS_URCORNER, ACS_LLCORNER, ACS_LRCORNER); 
	wrefresh(helpwin);
	getchar();
	delwin(helpwin);
}

void
enternewdir(int p) {	

  WINDOW	*movetowin;
  int		doesnotexist = 0, v;
  char		dirpathtemp[128];


	/* deal with want to change directories */
	if (p == 0) { /* not given by enter */
		movetowin = newwin(4, 50, (LINES/2-2), (COLS-COLS/2-25) ); 
		strcpy(dirwininfo.prevdir, dirwininfo.dirpath); /* back up current directory */
		do {
           werase(movetowin); 
           wborder(movetowin, ACS_VLINE, ACS_VLINE, ACS_HLINE, ACS_HLINE,
                              ACS_ULCORNER, ACS_URCORNER, ACS_LLCORNER,
			      			  ACS_LRCORNER); 
	   	   mvwprintw(movetowin, 1, 8, "Enter the directory to move to :");
		   wrefresh(movetowin);
	   	   mvwgetstr(movetowin, 2, 1, dirpathtemp);
		   if(strncmp(dirpathtemp, "/", 1) == 0) {
				strcpy(dirwininfo.dirpath, dirpathtemp);
	   		}
	   		else {
				getcwd(dirwininfo.dirpath, 127); 
				strcat(dirwininfo.dirpath, "/");
				strcat(dirwininfo.dirpath, dirpathtemp);
	   		}
       		doesnotexist = chdir(dirwininfo.dirpath);
		} while (doesnotexist == -1);
		/* make sure the path exist while it does not loop */
	}
	else { 
		if(p == 1) {
			/* given by enter ie up or down one directory */
			strcpy(dirwininfo.prevdir, dirwininfo.dirpath); /* backup current directory */
			linked_directory->itemname[--linked_directory->itemlength] = '\0';
			getcwd(dirwininfo.dirpath, 127);
			strcpy(dirwininfo.prevdir, dirwininfo.dirpath); /* back up the current dir to temp */
			if(strcmp(dirwininfo.dirpath, "/") != 0) { strcat(dirwininfo.dirpath, "/"); } /* if not root case */
			strcat(dirwininfo.dirpath, linked_directory->itemname);
		}
		else if (p == 2) { 
			strcpy(dirpathtemp, dirwininfo.prevdir);
			strcpy(dirwininfo.prevdir, dirwininfo.dirpath); 
			strcpy(dirwininfo.dirpath, dirpathtemp); 
		}
		chdir(dirwininfo.dirpath);
		getcwd(dirwininfo.dirpath, 127); /* gets rid of trailing crap */

		/* create the cool window */
	   	movetowin = newwin(3, 28, (LINES/2-2), (COLS-COLS/2-14) ); 
        werase(movetowin); 
        wborder(movetowin, ACS_VLINE, ACS_VLINE, ACS_HLINE, ACS_HLINE,
                           ACS_ULCORNER, ACS_URCORNER, ACS_LLCORNER,
		     			   ACS_LRCORNER); 
	   	mvwprintw(movetowin, 1, 2, "Press Enter to Continue");
		wrefresh(movetowin);
		wgetch(movetowin);
	}
   	delwin(movetowin);
	dirwininfo.writeoffset = 0;
	doesnotexist = strlen(dirwininfo.dirpath);

    /* read directories */
    dirwininfo.totalentries = readdirectories();
	linked_directory = linked_directory_head;
	writeoutlist(dirwininfo.writeoffset);
	dorefreshwindows();
}
