/* include golobal libaries */
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <ncurses.h>

/* posible return values for set_it_all_running */
#define ERROR_KEY	1
#define RETURN_KEY  3
#define ESC_KEY	    5
#define CTRL_X_KEY  7 
#define SPACE_KEY	9
#define BACK_KEY 	11

/* defines for mark types */
#define BOLD 	1
#define NORMAL	3
#define REVERSE	5

/* define yes and no */
#define OFF 0
#define ON  1

/* defines down and up */
#define DOWN  -1
#define UP    1

typedef struct OPTS {
	int 	opt_greyscale;
	int 	opt_onepass;
	int 	opt_quantize;
	int 	opt_verbose;
	int 	opt_forcemode;
	int		opt_widthonly;
	double 	opt_fuzz;
	char 	graphtoread[128];
	} opts;

typedef struct {
    int     writeoffset; /* off set for writing entries to windows */
	int		totalentries; /* total entries read in */
	int		viewmarked;  /* OFF if not ON if yes */
	char	dirpath[128]; /* the current directory path */
	char 	prevdir[128]; /* prevous dirctory */
	}  DIRINFO; /* structure for windows */

 struct LINKDIR_PROTO {
        struct LINKDIR_PROTO  *nextentry; /* next entry */
        struct LINKDIR_PROTO  *preventry; /* prevous entry */
        int                   itemlength;  /* length of element's name */
		char	 		      itemtype; /* entry type file or dircetory */
        char                  itemname[128]; /* enrty name */
		off_t		  		  itemsize; /* file size info */
		int					  itemmarked; /* is it marked for viewing? */
		int					  itemwindow; /* window in which the item occures */
		int					  itemplacement; /* where the item is in the list 0 being the first */
        }; /* LINKDIR prototype */

typedef struct LINKDIR_PROTO LINKDIR; /* define LINKDIR */

extern LINKDIR *linked_directory_head; /* the linked list head */
extern LINKDIR *linked_directory_tail; /* the linked list head */
extern LINKDIR *linked_directory_temp; /* a linked list element used in presort */
extern LINKDIR *linked_directory; /* a linked list element */
extern DIRINFO dirwininfo; /* global struct for windows and position info */
extern WINDOW  *window[]; /* golbal decloration for the window array */ 
extern FILE *dfd;

/* functions in frontend.c */
void dorefreshwindows(void); /* refreah the windows */
void dealwithscroll(void); /* deal with input from user */
void start_up_windows(void); /* called from main */
void redrawscreen(void); /* refresh the screen */
void markcurrent(void); /* current element to mark */
void scroll_and_view(opts options, int which_way); /* run the grphics rutines */

/* functions in movement.c */
void moverightwin(void);  /* move right a window */
void moveleftwin(void);  /* move left onw window */
void movedown(void);  /* move down one position */
void moveup(void);  /* move up one position */
void moveend(void); /* move to the begining of the list */
void movehome(void); /* move to the end of the list */
void clear_itemwindow(void); /* clear all itemwindows to -1 */
void mark_window(int ewin, int opts); /* make marked window's text look cool */

/* functions in windows.c */
void runhelp(void); /* pop up the help main window */
void runopthelp(void); /* pop up the help options window */
void enternewdir(int p); /* getting path info window and operations */
void runexit(int d); /* exit the program and deallicate memory */
void changeopts(opts *options); /* change the jpeg options */

/* external functions in dirfunct.c */
int      readdirectories(void); /* read directories and make linked list */
void     writeoutlist(int writeoffset); /* write the list to windows */


