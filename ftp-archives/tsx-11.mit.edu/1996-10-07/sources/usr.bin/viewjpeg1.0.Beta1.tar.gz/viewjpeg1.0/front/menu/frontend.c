#include "frontend.h"
#include "keydef.h"

#define MAX_WINDOWS 300 

DIRINFO dirwininfo;

LINKDIR *linked_directory;
LINKDIR *linked_directory_head;
LINKDIR *linked_directory_tail;
LINKDIR *linked_directory_temp;

FILE *dfd;

WINDOW *window[MAX_WINDOWS];

void
main(int argc, char *argv[]) {

char 	*termvalue;

/*
dfd = fopen("debug", "w");
setlinebuf(dfd);
fprintf(dfd, "top\n");
*/

  linked_directory_temp = malloc(sizeof(LINKDIR)); 
  linked_directory_head = NULL;

  termvalue = getenv("TERM");
  if(strncmp(termvalue, "xterm", 5) == 0) {
	printf("Sorry running in xterm can not run graphics exiting\n");
  }
	initscr();
	clear();
	if(argc != 1) { chdir(argv[1]); } /* if a command argument exists attempt to change directory to it */
	getcwd(dirwininfo.dirpath, 127); /* get current directory */
	start_up_windows();
}


void
start_up_windows() {

	int 	win_start_position, i;
	int 	win_end_position,   j;


	j		 = ((LINES-4)*3)+1;
	for (i=0; i < j; i++)
	{
		window[i]  = (WINDOW*)malloc(sizeof(WINDOW));
	}



	/* check position of first window on a no even screen 
	   it will need to be one larger than the rest */
	win_end_position = COLS/3;
	win_start_position = COLS-(COLS/3)*2;
	while(win_end_position != win_start_position) { 
		win_end_position++; 
	}

	/* set up windows */
	for(i = 0; i < LINES-4; i++) {
		window[i] 				= newwin(1, win_end_position, i+3, 0);
		window[i+(LINES-4)] 	= newwin(1, COLS/3, i+3, (COLS-(COLS/3)*2) );
		window[i+((LINES-4)*2)] = newwin(1, COLS/3, i+3, COLS-(COLS/3) );
	}

    dirwininfo.writeoffset = 0;

	/* read entries */
    dirwininfo.totalentries = readdirectories();
	linked_directory = linked_directory_head; 

	writeoutlist(dirwininfo.writeoffset);

	strcpy(dirwininfo.prevdir, "?");

    dorefreshwindows();
	dealwithscroll();
}


void
dorefreshwindows() {
	int i;

	/* for every window redraw it */
	for(i = 0; i < LINES-4; i++) {
		wnoutrefresh(window[i] );
		wnoutrefresh(window[i+(LINES-4)] ); 
		wnoutrefresh(window[i+((LINES-4)*2)] ); 
	}
	doupdate();
}


void
dealwithscroll() {

    int  	j = 0, v = 0;
    int 	response;
	double	big_item_size;
    WINDOW	*entrywin;
	opts	options;
	
	/* set options for viewing */
	options.opt_greyscale  = OFF;
	options.opt_onepass    = OFF;
	options.opt_quantize   = OFF;
	options.opt_forcemode  = OFF;
	options.opt_widthonly  = OFF;
	options.opt_fuzz       = 1.0;
	dirwininfo.viewmarked  = OFF;

    entrywin = newwin(3, COLS, 0, 0);
	keypad(entrywin, TRUE);

	/* if there is no path prompt to set one */
    if(linked_directory_head != NULL) {
		linked_directory = linked_directory_head;
    }
    else {
		enternewdir(0);
    }
    
    while (1)  {

		/* set up window and write out usefull information */
   		wborder(entrywin, ACS_VLINE, ACS_VLINE, ACS_HLINE, ACS_HLINE,
    	               	  ACS_ULCORNER, ACS_URCORNER, ACS_LLCORNER,
						  ACS_LRCORNER); 
	
		if (linked_directory->itemlength > COLS/3) {
    	    mvwprintw(entrywin, 1, (COLS-(COLS/3)*2), "File: ");
		    for(j = 0; j < COLS/3 && j < linked_directory->itemlength; j++) {
        	   	wprintw(entrywin, "%c", linked_directory->itemname[j]); 	
	    	}
		}
		else {
    	    mvwprintw(entrywin, 1, (COLS-(COLS/3)*2)+11, "File: %s", linked_directory->itemname);
		}
	
		/* print the item size if larger than 1 meg print in megs */
		if(linked_directory->itemsize/1000 < 1000) { mvwprintw(entrywin, 1, (COLS-COLS/3)+13, "File Size: %dK", linked_directory->itemsize/1000); }
		else { 
			big_item_size = linked_directory->itemsize;
			big_item_size = big_item_size/1000000; 
			mvwprintw(entrywin, 1, (COLS-COLS/3)+13, "File Size: %.1fM", big_item_size); 
		}

/*  this could be used to show marked or not instead of file size 
		if(linked_directory->itemmarked == ON) { mvwprintw(entrywin, 1, (COLS-COLS/3)+13, "Marked: Yes"); }
		else { mvwprintw(entrywin, 1, (COLS-COLS/3)+13, "Marked: No"); }
*/
		
		v = strlen(dirwininfo.dirpath);
		if(v > (COLS/3)+5 ) {
			mvwprintw(entrywin, 1, 1, "Dir: ^");
		    for (j = (v-(COLS/3)+6); j < v; j++) { wprintw(entrywin, "%c", dirwininfo.dirpath[j]); }
		}
		else {	mvwprintw(entrywin, 1, 1, "Dir: %s", dirwininfo.dirpath); }
		
		/* keeps the char for being echoed to the screen */
		raw();
		noecho();
  		response = wgetch(entrywin);
		echo();
		noraw();

   		wrefresh(entrywin);

   	switch (response) {
	   case KEY_UP :
	   case KEY_K :
	   case KEY_k : /* up */
			moveup();
			break;
	   case KEY_DOWN :
	   case KEY_J :
	   case KEY_j :  /* down */
    	    movedown();
			break;
	   case KEY_NPAGE :
	   case KEY_RIGHT :
	   case KEY_L :
	   case KEY_l :  /* right */
			moverightwin();
			break;
	   case KEY_PPAGE :
	   case KEY_LEFT  :
	   case KEY_H :
	   case KEY_h :  /* left */
			moveleftwin();
			break;
	   case KEY_I :
	   case KEY_i : /* change view options */
			changeopts(&options);
			dorefreshwindows();
			break;
	   case	KEY_HELP : /* run help */
			runhelp();
		    dorefreshwindows();
			break; 
   	   case KEY_CTRL_X : /* quit the program */	
     		delwin(entrywin);
			runexit(ON); 
			break;
	   case KEY_ENTER : /* view current */
	   case KEY_N :
	   case KEY_n :
			scroll_and_view(options, DOWN);
			break;
	   case KEY_BACK : /* view prevous */
	   case KEY_P :
	   case KEY_p :
			scroll_and_view(options, UP);
			break;
       case KEY_D :
       case KEY_d : /* change directories */
			enternewdir(0); 
			break;
	   case KEY_R :
	   case KEY_r : /* refresh the screen  */
			redrawscreen();
			break;
	   case KEY_U :
	   case KEY_u :
			if(strcmp(dirwininfo.prevdir, "?") != 0) {
				enternewdir(2);
			}
			break;
	   case KEY_SPACE : /* mark the current */
			markcurrent();
			movedown();
			break;
	   case KEY_HOME :
			movehome();
			break;
	   case KEY_END :
			moveend();
			break;
	   default :
			break;
	}	    
	werase(entrywin);
    }	    
}


void
markcurrent() {

	if(linked_directory->itemname[linked_directory->itemlength-1] != '/') {
		if(linked_directory->itemmarked == ON) {
			linked_directory->itemmarked = OFF;
			mark_window(linked_directory->itemwindow, NORMAL);
		}
		else {
			linked_directory->itemmarked = ON;
			mark_window(linked_directory->itemwindow, BOLD);
		}
	}
}


void
scroll_and_view(opts options, int which_way) {

	int 	givenvalue;
	LINKDIR *temp;

	if(which_way == DOWN) { /* view next */
	  if (linked_directory->itemtype == 'F') { /* if not a directory */
		if (dirwininfo.viewmarked == ON && linked_directory->itemmarked == ON) { /* marked case */
			temp = linked_directory;
			linked_directory = linked_directory_head;
			do {
				if(linked_directory->itemmarked == ON) { /* if marked view */
					strcpy(options.graphtoread, linked_directory->itemname);
					givenvalue = set_it_all_running(options); 
					if(givenvalue == SPACE_KEY) { 
						markcurrent(); 
						movedown();
					}
					else { movedown(); }
				}
				else { /*  else go down one */
				movedown(); 
				}
			} while(linked_directory->nextentry != NULL && givenvalue != ESC_KEY); /* if escape exit */

			if(linked_directory->itemmarked == ON) { /* check last element */
				strcpy(options.graphtoread, linked_directory->itemname);
				givenvalue = set_it_all_running(options); 
				if(givenvalue == SPACE_KEY) { 
					markcurrent(); 
					movedown();
				}
				else { movedown(); }
			} /* check last element */

			if(givenvalue != ESC_KEY) {
				linked_directory = temp; 
			} /* on correct exit  move back to first place */
		}
		else { /* unmarked case */
			do { /* just view the next one until ctrl-x or escape is pressed */
				if(linked_directory->nextentry != NULL) {
					strcpy(options.graphtoread, linked_directory->itemname);
					givenvalue = set_it_all_running(options); 
					if(givenvalue == SPACE_KEY) { 
						markcurrent(); 
						movedown();
					}
					else if (givenvalue == BACK_KEY) { scroll_and_view(options, UP); }
			    	else { movedown(); }
				}
				else { /* check last one in list but do not scroll down */
					strcpy(options.graphtoread, linked_directory->itemname);
					givenvalue = set_it_all_running(options); 
					if(givenvalue == SPACE_KEY) { markcurrent(); } 
					givenvalue = ERROR_KEY; 
				}
			} while(givenvalue == RETURN_KEY || givenvalue == SPACE_KEY && givenvalue != ERROR_KEY);
		}
	  }
	  else { enternewdir(1); } /* move to directory */
	}
	else {	/* view prevous */
		do { /* just view the prevous one until ctrl-x or escape is pressed */
			if(linked_directory->itemplacement > 0 && linked_directory->preventry->itemtype == 'F') {
				moveup();
				strcpy(options.graphtoread, linked_directory->itemname);
				givenvalue = set_it_all_running(options); 
				if(givenvalue == SPACE_KEY) { 
					markcurrent(); 
					moveup();
				}
				else if (givenvalue == RETURN_KEY) {
					movedown();
					scroll_and_view(options, DOWN);
				}
			}
			else { givenvalue = ERROR_KEY; }
		} while(givenvalue == BACK_KEY || givenvalue != ERROR_KEY);
	}
	redrawscreen(); /* after which every part refesh the entire screen */
	if (givenvalue == CTRL_X_KEY) { /* if ctrl_x  exit which out prompt */
		runexit(OFF);
	}
}


void
redrawscreen() {

	/* clear and redraw the entire screen cleaning up left over crap */
	erase();
	refresh();
	writeoutlist(dirwininfo.writeoffset);	
	dorefreshwindows();
}

	
