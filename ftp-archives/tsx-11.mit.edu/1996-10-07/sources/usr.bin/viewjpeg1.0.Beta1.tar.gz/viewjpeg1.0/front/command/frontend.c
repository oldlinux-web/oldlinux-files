#include <getopt.h>
#include "viewjpeg.h"

#define VERSION "viewjpeg command line 1.0"

bmode *best_mode_256_head;
bmode *best_mode_256_tail;
bmode *best_mode_32k16m_head;
bmode *best_mode_32k16m_tail;
bmode *best_mode_temp;

FILE *dfd;


void
main(int argc, char **argv)
{
    int c, arg, reset = 0;
    char *errstr = NULL;
    char *ch;
	opts options;
 
	best_mode_256_tail		= malloc(sizeof(bmode)); 
	best_mode_256_head		= malloc(sizeof(bmode)); 
	best_mode_32k16m_tail	= malloc(sizeof(bmode));
	best_mode_32k16m_head	= malloc(sizeof(bmode));
	best_mode_temp			= malloc(sizeof(bmode));
	best_mode_256_head		= NULL;
	best_mode_256_tail		= NULL;
	best_mode_32k16m_head	= NULL;
	best_mode_32k16m_tail	= NULL;

/*
dfd = fopen("debug", "w");
setlinebuf(dfd);
fprintf(dfd, "top\n");
*/
	options.opt_greyscale = 0;
	options.opt_onepass   = 0; 
	options.opt_quantize  = 0;
	options.opt_forcemode = 0;
	options.opt_widthonly = 0;
	options.opt_fuzz      = 1.0;;

    while ((c = getopt(argc, argv, "1f:gqs:vwCF:")) != -1) {
	switch (c) {
	 case '1':
	    options.opt_onepass = 1;
	    break;
	  case 'f':
	    options.opt_fuzz = atof(optarg);
	    if (options.opt_fuzz < 0.5 || options.opt_fuzz > 1.0) {
			errstr = "fuzz factor must be in range [0.5,1.0]";
	    }
	    break;
	  case 'g':
	    options.opt_greyscale = 1;
	    break;
	  case 'q':
	    options.opt_quantize = 1;
	    break;
	  case 'w':
	    options.opt_widthonly = 1;
	    break;
	  case 'F':
	    options.opt_forcemode = atoi(optarg);
	    break;
	  case '?':
	    reset++;
	    break;
	}
    }
  
    if (errstr != NULL) {
	fprintf(stderr, "Error: %s\n", errstr);
	exit(1);
	}

    if (reset || argc - optind == 0) {
	fprintf(stderr, VERSION"\n");
	fprintf(stderr,
		"Usage: %s [-1gqw] [-f fuzz] [-F mode] {file} ...\n",
		argv[0]);
	fprintf(stderr, "\t-1   one pass quantization (-q implicit)\n");
	fprintf(stderr, "\t-f   set fuzz factor to determine video mode\n");
	fprintf(stderr, "\t-g   force greyscale mode (-1 implicit)\n");
	fprintf(stderr, "\t-q   force syetm to use 256 color mode\n");
	fprintf(stderr, "\t-w   only use width to determine video mode\n");
	fprintf(stderr, "\t-F   force the use of {mode} video mode ie -F 10\n");
	fprintf(stderr, "\t		modes are as follows\n");
	fprintf(stderr, "\t		5	320x200x256\n");
	fprintf(stderr, "\t		10	640x480x256\n");
	fprintf(stderr, "\t		11	800x600x256\n");
	fprintf(stderr, "\t		12	1024x768x256\n");
	fprintf(stderr, "\t		17	640x480x32k\n");
	fprintf(stderr, "\t		20	800x600x32k\n");
	fprintf(stderr, "\t		23	1024x768x32k 2megs\n");
	fprintf(stderr, "\t		33	320x200x16m\n");
	fprintf(stderr, "\t		34	640x480x16m\n");
	fprintf(stderr, "\t		35	800x600x16m  2megs\n");
	fprintf(stderr, "\n\t For multiple images use enter to continue on\n\t\t and ESC or CTRL X to quit\n");
	fprintf(stderr, "\n\tFile types supported: JPEG, GIF, PPM, BMP, XPM and TARGA\n");
	exit(1);
    }

	for (arg = optind; arg < argc; arg++) {
	    strcpy(options.graphtoread, argv[arg]);
		reset = set_it_all_running(options);
		if (reset == CTRL_X_KEY || reset == ESC_KEY) { exit(0); }
	}    

	exit(0);
}

