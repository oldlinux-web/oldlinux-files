#include "frontend.h"

void
moveend() {

	int i = 0;

	clear_itemwindow();
	linked_directory = linked_directory_head;
	while(linked_directory->itemplacement < linked_directory_tail->itemplacement) {
		linked_directory = linked_directory->nextentry;
		i++;
		if(i == ((LINES-4)*3) ) {
			dirwininfo.writeoffset++;
			i = 0;
		}
	}
	writeoutlist(dirwininfo.writeoffset);
	dorefreshwindows();
}


void
movehome() {

	clear_itemwindow();	
	dirwininfo.writeoffset = 0;
	linked_directory = linked_directory_head;
	writeoutlist(dirwininfo.writeoffset);
	dorefreshwindows();
}


void
clear_itemwindow() {

	LINKDIR *temp;

	temp = linked_directory;
	while (linked_directory != NULL && linked_directory->itemwindow != -1 && 
	       linked_directory->itemplacement >= 0) {
		linked_directory->itemwindow = -1;
		linked_directory = linked_directory->preventry;
	}

	linked_directory = temp->nextentry;
	while (linked_directory != NULL && linked_directory->itemwindow != -1 && 
		   linked_directory->itemplacement <= linked_directory_tail->itemplacement) {
		linked_directory->itemwindow = -1;
		linked_directory = linked_directory->nextentry;
	}
	/* linked_directory ends at the last item that was used */

}


void 
moverightwin() { 

	int i = 0, posend = linked_directory->itemplacement+(LINES-4); /* what then would be the window placement*/
	LINKDIR *temp;

	if(linked_directory->nextentry != NULL) { /* if not last entry */
	/* mark according to how current is set */
		if(linked_directory->itemmarked == OFF) { mark_window(linked_directory->itemwindow, NORMAL); }
		else { mark_window(linked_directory->itemwindow, BOLD); }
	}

	/* move over a row */
	if(linked_directory->itemplacement < linked_directory_tail->itemplacement) {
		if(posend < dirwininfo.totalentries) {
			linked_directory_temp = linked_directory;
			while(linked_directory->itemplacement < linked_directory_tail->itemplacement &&
				  linked_directory->itemplacement < posend) {
				linked_directory = linked_directory->nextentry;
				if(linked_directory->itemwindow == -1) { i++; }
			}
		}
		else { /* if there are not enoigh to scroll a full colmn then go until end */
			moveend();
			i = 0;
		}
	}
	if(i > 0) { /* if it is a new screen to be drawn */
		temp = linked_directory; /* save where we are now */
		linked_directory = linked_directory_temp; /* send it back to where it began */
		clear_itemwindow(); /* clear the window types */
		linked_directory = temp; /* set it back to where we are now */
		dirwininfo.writeoffset++; /* increase the outset for writing */
		writeoutlist(dirwininfo.writeoffset); /* writeout the list */
		mark_window(linked_directory->itemwindow, REVERSE); /* mark the current window */
		dorefreshwindows(); /* refresh the windows on the screen */
	}
	else { mark_window(linked_directory->itemwindow, REVERSE); }
}


void
moveleftwin() { 

	int i = 0, posend = linked_directory->itemplacement-(LINES-4); /* what then would be the window placement*/
	LINKDIR *temp;

	if(linked_directory->preventry != NULL) { /* if not first entry */
	/* mark according to how current is set */
		if(linked_directory->itemmarked == OFF) { mark_window(linked_directory->itemwindow, NORMAL); }
		else { mark_window(linked_directory->itemwindow, BOLD); }
	}

	/* move over a row */
	if(linked_directory->preventry->itemplacement > 0) {
		if(posend > 0) {
			linked_directory_temp = linked_directory;
			while(linked_directory->itemplacement > 0 &&
				  linked_directory->itemplacement > posend) {
				linked_directory = linked_directory->preventry;
				if(linked_directory->itemwindow == -1) { i++; }
			}
		}
		else { /* if there are not enoigh to scroll a full colmn then go until end */
			movehome();
			i = 0;
		}
	}
	if(i > 0) { /* if it is a new screen to be drawn */
		temp = linked_directory; /* save where we are now */
		linked_directory = linked_directory_temp; /* send it back to where it began */
		clear_itemwindow(); /* clear the window types */
		linked_directory = temp; /* set it back to where we are now */
		dirwininfo.writeoffset--; /* increase the outset for writing */
		writeoutlist(dirwininfo.writeoffset); /* writeout the list */
		mark_window(linked_directory->itemwindow, REVERSE); /* mark the current window */
		dorefreshwindows(); /* refresh the windows on the screen */
	}
	else { mark_window(linked_directory->itemwindow, REVERSE); }
}


void 
movedown() { 

	LINKDIR *temp;

	/* move down one row */
	if(linked_directory->nextentry != NULL) { /* set current window back to what it is */
		if(linked_directory->itemmarked == OFF) { mark_window(linked_directory->itemwindow, NORMAL); }
		else { mark_window(linked_directory->itemwindow, BOLD); }
	}

	/* if not the end of screen just go to next window */
  	if (linked_directory->itemplacement < linked_directory_tail->itemplacement &&
		linked_directory->nextentry->itemwindow != -1 && linked_directory->nextentry != NULL) { 
			linked_directory = linked_directory->nextentry;
	 }
	else if (linked_directory->nextentry->itemwindow == -1) { /* end of row call move window */
		temp = linked_directory; /* save where we are now */
		linked_directory = linked_directory->preventry; /* send it back to where it began */
		clear_itemwindow(); /* clear the window types */
		linked_directory = temp->nextentry; /* set it back to where we are now */
		dirwininfo.writeoffset++; /* increase the outset for writing */
		writeoutlist(dirwininfo.writeoffset); /* writeout the list */
		dorefreshwindows(); /* refresh the windows on the screen */
	}
	if(linked_directory->itemplacement > 0) { wrefresh(window[linked_directory->preventry->itemwindow]); }
	mark_window(linked_directory->itemwindow, REVERSE);
}


void 
moveup() { 

	LINKDIR *temp;

	/* move up one row */
	if(linked_directory->preventry != NULL) { /* set current window back to what it is */
		if(linked_directory->itemmarked == OFF) { mark_window(linked_directory->itemwindow, NORMAL); }
		else { mark_window(linked_directory->itemwindow, BOLD); }
	}

	/* if not the end of screen just go to prev window */
  	if (linked_directory->itemplacement > 0 &&
		linked_directory->preventry->itemwindow != -1 ) { 
		linked_directory = linked_directory->preventry;
	}
	else if (linked_directory->preventry->itemwindow == -1) { /* end of row call move window */
		temp = linked_directory; /* save where we are now */
		linked_directory = linked_directory->preventry;
		clear_itemwindow(); /* clear the window types */
		linked_directory = temp->preventry; /* set it back to where we are now */
		dirwininfo.writeoffset--; /* increase the outset for writing */
		writeoutlist(dirwininfo.writeoffset); /* writeout the list */
		mark_window(linked_directory->itemwindow, REVERSE); /* mark the current window */
		dorefreshwindows(); /* refresh the windows on the screen */
	}
	if(linked_directory->itemplacement > 0) { wrefresh(window[linked_directory->nextentry->itemwindow]); }
	mark_window(linked_directory->itemwindow, REVERSE);
}


void
mark_window(int ewin, int opt) {
		
	int v;
	
	/* what type of marking */
	switch (opt)  {
		case BOLD    :
			wattron(window[ewin], A_BOLD);
			break;
		case REVERSE :
			wattron(window[ewin], A_REVERSE);
			break;
		case NORMAL  :
			wattron(window[ewin], A_NORMAL);
			break;
	}

	/* if greter than length do */
	if(linked_directory->itemlength > COLS/3) { 
		for(v = 0; v < COLS/3-1; v++) {
			wprintw(window[ewin], "%c", linked_directory->itemname[v]);
		}
		wprintw(window[ewin], "\n");
	}
	else {
		wprintw(window[ewin], "%s\n", linked_directory->itemname); 
	}
	/* reset the options */
	switch (opt) {
		case BOLD :
			wattroff(window[ewin], A_BOLD);
			break;
		case REVERSE :
			wattroff(window[ewin], A_REVERSE);
			break;
		case NORMAL :
			wattroff(window[ewin], A_NORMAL);
			break;
	}
	wrefresh(window[ewin]);
}

