
#include "frontend.h"
#include <sys/stat.h>
#include <dirent.h>


void
dellistobj(LINKDIR **head, LINKDIR **tail, LINKDIR *current) {

   if(current->preventry != NULL && current->nextentry != NULL) {
        current->preventry->nextentry = current->nextentry;
        current->nextentry->preventry = current->preventry; 
   }
   else if (current->nextentry == NULL) { /* tail case */
		*tail = current->preventry;
        current->preventry->nextentry = NULL;
   }
   else { /* head case */
        current->nextentry->preventry = NULL;
        *head = current->nextentry;  /* set the new head to fillin */
   }
   free(current); /* free the deleted element */
}


void
transinfo(LINKDIR *new, LINKDIR *old) {

	/* copy info from old to new */
	strcpy(new->itemname, old->itemname);
	new->itemtype 	= old->itemtype;
	new->itemsize 	= old->itemsize;
	new->itemlength = old->itemlength;
}


void
partitionlist(int j)  {

  LINKDIR 	*directory;
  int 		i = 0;

  linked_directory = linked_directory_tail;

  /* if the entery is a directory move it to the head */
  while(j > 0) {	
    if (linked_directory->itemtype == 'D') {
		directory = malloc(sizeof(LINKDIR));
		directory->preventry = NULL;
		directory->nextentry = NULL;
		transinfo(directory, linked_directory);
		linked_directory_head->preventry = directory;
		directory->nextentry = linked_directory_head;
		linked_directory_head = directory;
		linked_directory = linked_directory->preventry;
		dellistobj(&linked_directory_head, &linked_directory_tail,
				    linked_directory->nextentry);
		j--;
		i++;
  	}
	/* else go up one */
	else if (linked_directory->itemtype == 'F') {
  		linked_directory = linked_directory->preventry;
		j--;
		i++;
	}

  }

  /* forulate where the lines end */
  j = 0; /* clear j */
  for(linked_directory = linked_directory_head; linked_directory->nextentry != NULL; 
	  linked_directory = linked_directory->nextentry) { 
	linked_directory->itemplacement = j;
	j++;
  }
linked_directory_tail->itemplacement = j;
}


LINKDIR* 
dirinfo_preordersort(LINKDIR *head, LINKDIR *tobeadded) {

	/* haed case */
   if (strcmp(tobeadded->itemname, head->itemname) < 0) {
   	head->preventry = tobeadded;
   	tobeadded->nextentry = head;
	tobeadded->preventry = NULL;
	return tobeadded;
   }
   else {
	linked_directory_temp = head;
	while(strcmp(tobeadded->itemname, linked_directory_temp->itemname) > 0 && linked_directory_temp->nextentry != NULL) {
	   linked_directory_temp = linked_directory_temp->nextentry; 
	}
	
	/* greater than last entry */
	if (strcmp(tobeadded->itemname, linked_directory_temp->itemname) == 1) {
	   tobeadded->preventry = linked_directory_temp;
	   if(linked_directory_temp->nextentry != NULL) { 
	     linked_directory_temp->nextentry->preventry = tobeadded;
	     tobeadded->nextentry = linked_directory_temp->nextentry;
	   }
	   else {
	     tobeadded->nextentry = NULL;
		 linked_directory_tail = tobeadded;
	   } 
	   linked_directory_temp->nextentry = tobeadded;
           return head;
   	}
	else { /* less than last entry */
	   tobeadded->nextentry = linked_directory_temp;
	   linked_directory_temp->preventry->nextentry = tobeadded;
	   tobeadded->preventry = linked_directory_temp->preventry;
	   linked_directory_temp->preventry = tobeadded;
	   return head;
	}
   }
}
	
   

void
killdirlist(LINKDIR *listtype) {

 int i = 0; 

 /* starting with the tail and going till head free up the list */
 if (listtype != NULL) {
   while(listtype->nextentry != NULL) {
		listtype = listtype->nextentry;
		free(listtype->preventry); 
   }
 free(listtype);
 }
}


void
writeoutlist(int writeoffset) {
    
   LINKDIR *temp;
   int     i = 0;	

	for(i = 0; i < LINES-4; i++) {   /* needed to clear the screen portions not in use */
		werase(window[i] );
		werase(window[i+(LINES-4)] );
		werase(window[i+((LINES-4)*2)] );
	}

   temp = linked_directory;
   linked_directory = linked_directory_head;

   /* move x files before writing */
   i = 0;
   while (i < writeoffset*((LINES-4)*3) && linked_directory->nextentry != NULL) {
		linked_directory = linked_directory->nextentry;
		i++;
   }

   /* if the list exists then write it */
   i = 0;
   if(linked_directory != NULL) {
      do {
		/* if its marked deal with it */
		if(linked_directory->itemmarked == OFF) {
			linked_directory->itemwindow = i;
			mark_window(linked_directory->itemwindow, NORMAL);
			i++;
		}
		else {
			linked_directory->itemwindow = i;
			mark_window(linked_directory->itemwindow, BOLD);
			i++;
		}
        linked_directory = linked_directory->nextentry;
	  } while(linked_directory != NULL && i < ((LINES-4)*3) );
	  linked_directory = temp;
	  mark_window(linked_directory->itemwindow, REVERSE);
   }
}


int
readdirectories() {

	int i = 0;

	struct dirent *dirset;
	struct stat	  *fileinfo;
	DIR           *dirlist;
	char		  dirtemp[128];

	/* if its not the first directory read then clear the list */
	if(linked_directory_head != NULL) {
		killdirlist(linked_directory_head);
		linked_directory_head = NULL;
	}		

	strcpy(dirtemp, dirwininfo.prevdir);

    dirlist = opendir(dirwininfo.dirpath);
    dirset  = readdir(dirlist);

	/* do the following for each entry */
	do {
        if(dirset->d_name[0] != '.') { 

			/* read file charictoristics */
            stat(dirset->d_name, fileinfo); 
	    	linked_directory = malloc(sizeof(LINKDIR));
            strncpy(linked_directory->itemname, dirset->d_name, 127); 
	    	/* check if a directory */
        	if (S_ISDIR(fileinfo->st_mode)) {
	       		linked_directory->itemtype = 'D';
                strcat(linked_directory->itemname, "/");
	    	}
	    	else {
	       		linked_directory->itemtype = 'F';
	    	}

			linked_directory->itemsize   = fileinfo->st_size;
            linked_directory->itemlength = strlen(linked_directory->itemname);
			linked_directory->itemmarked = OFF;
			linked_directory->itemwindow = -1;
            linked_directory->nextentry  = NULL;
	    	linked_directory->preventry  = NULL;

	    	if(i != 0) {
				linked_directory_head = dirinfo_preordersort(linked_directory_head, linked_directory); 
	    	}
	    	else { linked_directory_head = linked_directory; }
		    i++;
		} 
        dirset = readdir(dirlist);
    } while (dirset != NULL);

	/* include .. as an entry in the list */
	if(strcmp(dirwininfo.dirpath, "/") != 0) { /* if current directory is not the root directory */
		linked_directory = malloc(sizeof(LINKDIR));
		strcpy(linked_directory->itemname, "..");
		linked_directory->itemtype = 'D';
		strcat(linked_directory->itemname, "/");
		linked_directory->itemsize   = 1000;
		linked_directory->itemlength = strlen(linked_directory->itemname);
		linked_directory->itemmarked = OFF;
		linked_directory->itemwindow = -1;
		linked_directory->nextentry  = NULL;
		linked_directory->preventry  = NULL;
		linked_directory_head = dirinfo_preordersort(linked_directory_head, linked_directory); 
		i++;
	}
	/* include .. as an entry in the list */
 
closedir(dirlist); /* close the directory for reading */

partitionlist(i); /* seperate the directories and put them first */

strcpy(dirwininfo.prevdir, dirtemp);
getcwd(dirwininfo.dirpath, 127); /* sometime dirpath becomes crap if this happend then this should restore it */
return i; /* return the number of entries */
}
