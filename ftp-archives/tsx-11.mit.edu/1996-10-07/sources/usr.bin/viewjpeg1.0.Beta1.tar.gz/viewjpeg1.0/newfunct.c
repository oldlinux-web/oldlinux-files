
#include "viewjpeg.h"
#include <string.h>
#include <unistd.h>
#include <vga.h>
#include <stdlib.h>
#include <vgagl.h>

int  mode_width, mode_height, mode_depth;
int  start_row, mode_linewidth;
int  con_col, con_row, modetype;
int  logical_width, logical_height;
int  logical_byte_width, bytesperpixel;
void *font = NULL;


int
best_mode(int width, int height, int components)
{
	int mode;
	#ifndef NO_32K_CASCADE
    	vga_modeinfo *vgainfo;
	    int bytesperpixel, logical_byte_width, logical_width, logical_height;
	#endif  

    if (opt_forcemode == 0) {
		mode = find_best_mode(width, height, components);
	}
	else {
		if(components == 1) {
			best_mode_temp = best_mode_256_tail;
		}
		else {
			best_mode_temp = best_mode_32k16m_tail;
		}
	
		while(best_mode_temp->preventry != NULL && best_mode_temp->mode != opt_forcemode) {
			best_mode_temp = best_mode_temp->preventry;
		}

		if(best_mode_temp == NULL) {
			opt_forcemode = 0;
			mode = find_best_mode(width, height, components);
		}
		else {
			mode		= best_mode_temp->mode;
			mode_width  = best_mode_temp->mode_width;
			mode_height = best_mode_temp->mode_height;
			mode_depth  = best_mode_temp->mode_depth;
		}
	}

	if(components == 3) { /* if hi-res check for cascade */
		#ifndef NO_32K_CASCADE
			vgainfo = vga_getmodeinfo(mode);

			bytesperpixel = vgainfo->bytesperpixel;
			mode_linewidth = vgainfo->linewidth;
	
			logical_byte_width = MAX(mode_linewidth, width * bytesperpixel);
			if (logical_byte_width % PIX_ALIGN != 0) {
			    logical_byte_width += PIX_ALIGN - logical_byte_width % PIX_ALIGN;
			}
			if (logical_byte_width % (bytesperpixel * PIX_ALIGN) != 0) {
			    logical_byte_width += (bytesperpixel * PIX_ALIGN) - logical_byte_width % (bytesperpixel * PIX_ALIGN);
			}
			logical_width = logical_byte_width / bytesperpixel;
			logical_height = MIN(vgainfo->maxpixels * bytesperpixel / logical_byte_width, height);
		#endif
	}

	return mode;
}

int
find_best_mode(int width, int height, int components) {
	
	int mode;

    if (components == 1) {
		best_mode_temp = best_mode_256_tail; 
	}
	else if (components == 3) {
		best_mode_temp = best_mode_32k16m_tail;
	}
	
	if(!opt_widthonly) {
		while(best_mode_temp->preventry != NULL &&  (opt_fuzz * width < best_mode_temp->min_width &&
			  opt_fuzz * height < best_mode_temp->min_height)) {
			best_mode_temp = best_mode_temp->preventry;
		}
	}
	else { 
		while(best_mode_temp != NULL &&  opt_fuzz * width < best_mode_temp->min_width) {
			best_mode_temp = best_mode_temp->preventry;
		}
	}

	/* solve the mode 5 error */
	if(best_mode_temp->mode == 5 && (best_mode_temp->mode_width < width ||
	   best_mode_temp->mode_height < height) ) {
		if(best_mode_temp->nextentry != NULL) { best_mode_temp = best_mode_temp->nextentry; }
	}

	mode		 = best_mode_temp->mode;
	mode_width  = best_mode_temp->mode_width;
	mode_height = best_mode_temp->mode_height;
	mode_depth  = best_mode_temp->mode_depth;
	return mode;
}


void initfont() {

	if(font != NULL) { free(font); }
	font = malloc(256 * 8 * 8 * BYTESPERPIXEL);
	if(mode_depth == 256) { gl_expandfont(8, 8, 2, gl_font8x8, font); }
	else { gl_expandfont(8, 8, 255, gl_font8x8, font); }
	gl_setfont(8, 8, font);
	gl_setcontextvga(modetype);
	gl_setwritemode(WRITEMODE_OVERWRITE);
}


void writefont(char *s) {
	gl_write( ( WIDTH/2-((strlen(s)*8)/2) ) , HEIGHT-12, s);
}


int
setfixdisplay(int addsub)
{
    int  components;
	char *out_err;

    switch (modetype) {
	case 5 : case 6 : case 7 : case 8 : case 10 : case 11 : case 12 :
	   components = 1;
	   break;
	case 17 : case 20 : case 23 : case 33 : case 34 : case 35 :
	   components = 3;
	   break;
	default :
	   components = 2;
	   break;
    }

	if(addsub == -1) {
		if(components == 1) { best_mode_temp = best_mode_256_tail; }
		else { best_mode_temp = best_mode_32k16m_tail; } 
		if(best_mode_temp != NULL) {
	 		while (best_mode_temp->mode != modetype && best_mode_temp->preventry != NULL) {
				best_mode_temp = best_mode_temp->preventry;
			}
		}

		if(best_mode_temp->preventry != NULL) { 
			modetype = best_mode_temp->preventry->mode; 
			return modetype;
		}
		else { 
			sprintf(out_err, "Smallest possible video mode"); 
			writefont(out_err);
		}
	}
	else {
		if(components == 1){ best_mode_temp = best_mode_256_tail; }
		else { best_mode_temp = best_mode_32k16m_tail;  }
		if(best_mode_temp != NULL) {
	 		while (best_mode_temp->preventry != NULL && best_mode_temp->mode != modetype) {
				best_mode_temp = best_mode_temp->preventry;
			}
		}
		if(best_mode_temp->nextentry != NULL) { 
			modetype = best_mode_temp->nextentry->mode; 
			return modetype;
			}
		else { 
			sprintf(out_err, "Largest possible video mode"); 
			writefont(out_err); 
		}
	}			
return -1;
}


/* set the palette from the colormap */
void 
set_custom_palette(int cmap_length, int c_map[3][256]) {
 
#define red_color   0
#define green_color 1
#define blue_color  2

char j;
	Palette palette; /* create the palette */
	int i;
    for (i = 0; i < cmap_length; i++) { /* save each color to palette array as a value of 0 to 63 */
		palette.color[i].red = c_map[red_color][i]/4;
		palette.color[i].green = c_map[green_color][i]/4;
		palette.color[i].blue = c_map[blue_color][i]/4;
	}
    gl_setpalette(&palette); /* set the palette to maped colors */
}


/* note this does infact work but I know there has to be a better way I just do not know it */
void
greyscale_colormap(int cmap_length, int c_map[3][256]) { /* works to setup the greyscale palette for 8bit color bmps */

	int i, color_value;
	
    for (i = 0; i < cmap_length; i++) {
		/* check if grey if grey aready do nothing should use != and no if but does not work WHY? */
		if(c_map[red_color][i]   == c_map[green_color][i] && 
		   c_map[red_color][i]   == c_map[blue_color][i]  &&
 		   c_map[green_color][i] == c_map[blue_color][i]) { ; }
		/* else get brightest color and use it as the grey scale */
		else { 
			 /* if red is the brightest use it */
			if(c_map[red_color][i] <= c_map[green_color][i] && 
			   c_map[red_color][i] <= c_map[blue_color][i]) {
				color_value = c_map[red_color][i];
			}
			/* if green is the brightest use it */
			else if(c_map[green_color][i] < c_map[red_color][i] && 
			   c_map[green_color][i] < c_map[blue_color][i]) {
				color_value = c_map[green_color][i];
			}
			/* else use blue */
			else { color_value = c_map[blue_color][i]; } 
			c_map[red_color][i]   = color_value;
			c_map[green_color][i] = color_value;
			c_map[blue_color][i]  = color_value;
		}
	}

}


int
convert_to_int(char c) {

	switch(c) {
		case 48 : return 0;
		case 49 : return 1;
		case 50 : return 2;
		case 51 : return 3;
		case 52 : return 4;
		case 53 : return 5;
		case 54 : return 6;
		case 55 : return 7;
		case 56 : return 8;
		case 57 : return 9;
	}
}

