
#include "viewjpeg.h"
#include <string.h>
#include <vga.h>

bmode *best_mode_256_head;
bmode *best_mode_256_tail;
bmode *best_mode_32k16m_head;
bmode *best_mode_32k16m_tail;
bmode *best_mode_temp;

int opt_greyscale, opt_onepass, opt_quantize, opt_verbose;
int opt_forcemode, opt_widthonly;
char graphtoread[128];
double opt_fuzz;

FILE *dfd;


int
set_it_all_running(opts options) {

	int  reset;
	best_mode_256_head		= NULL;
	best_mode_256_tail		= NULL;
	best_mode_32k16m_head	= NULL;
	best_mode_32k16m_tail	= NULL;

	getmodeinfo();
	vga_disabledriverreport();

	vga_init(); /* set up vga display */
	
	strcpy(graphtoread, set_opts(options));

	do {
		reset = read_image_file(graphtoread);
	} while (reset == ADD_KEY || reset == SUB_KEY);

	display_shutdown();
	killmodelist(best_mode_256_head);
	killmodelist(best_mode_32k16m_head);
	
fprintf(dfd, "reset is %d\n", reset);
	return reset;
}


void
killmodelist(bmode *tokill) {
	
	if(tokill != NULL) {
		while(tokill->nextentry != NULL) {
			tokill = tokill->nextentry;
			free(tokill->preventry);
		}
	free(tokill);
	}
}


void
getmodeinfo() {

	int i, v = 0, j = 0;

	vga_init();

	for(i = 1; i <= GLASTMODE; i++) {
		if(vga_hasmode(i)) {
			switch (i) {
				case 5 : 
					addtostruct(0, 0, 5, 320, 200, 256);
					break;

	/* not supported as of yet
				case 6 :
					addtostruct(320, 240, 6, 320, 400, 256);
					break;
				case 7 :
					addtostruct(320, 400, 7, 360, 480, 256);
					break;
	not supported as of yet */

				case 10 : 
					addtostruct(360, 480, 10, 640, 480, 256);
					break;
				case 11 : 
					addtostruct(640, 480, 11, 800, 600, 256);
					break;
				case 12 : 
					addtostruct(800, 600, 12, 1024, 768, 256);
					break;
				case 17 : 
					addtostruct(320, 200, 17, 640, 480, 32768);
					break;
				case 20 : 
					addtostruct(640, 480, 20, 800, 600, 32768);
					break;
				case 23 : 
					addtostruct(800, 600, 23, 1024, 768, 32768);
					break;
				case 33 : 
					addtostruct(1, 1, 33, 320, 200, 16777216);
					break;
				case 34 : 
					addtostruct(320, 200, 34, 640, 480, 16777216);
					break;
				case 35 : 
					addtostruct(640, 480, 35, 800, 600, 16777216);
					break;
			}
		}
	}
}


char*
set_opts(opts options) {

	opt_greyscale  = options.opt_greyscale;
	opt_onepass    = options.opt_onepass; 
	opt_quantize   = options.opt_quantize;
	opt_forcemode  = options.opt_forcemode;
	opt_widthonly  = options.opt_widthonly;
	opt_fuzz	   = options.opt_fuzz;
	return options.graphtoread;	
}



void
addtostruct(int min_width2, int min_height2, int mode2,	int mode_width2, int mode_height2,
			int mode_depth2) {

	bmode *current;

	current = malloc(sizeof(bmode));

	current->min_width   = min_width2;
	current->min_height  = min_height2;
	current->mode 		 = mode2;
	current->mode_width  = mode_width2;
	current->mode_height = mode_height2;
	current->mode_depth	 = mode_depth2;
	current->nextentry   = NULL;	
	
	if(current->mode_depth == 256) {
		if(best_mode_256_head != NULL) {
			best_mode_temp = best_mode_256_head;
			while(best_mode_temp->nextentry != NULL) {
				best_mode_temp = best_mode_temp->nextentry;
			}
			best_mode_temp->nextentry = current;
			current->preventry = best_mode_temp;
			best_mode_256_tail = current;
		}
		else  {
			best_mode_256_head = current;
			current->preventry = NULL;
			best_mode_256_tail = current;
		}
	}
	else {
		if(best_mode_32k16m_head != NULL) {
			best_mode_temp = best_mode_32k16m_head;
			if(best_mode_temp->nextentry != NULL) {
				while(best_mode_temp->nextentry != NULL) {
					best_mode_temp = best_mode_temp->nextentry;
				}
			}
			best_mode_temp->nextentry = current;
			current->preventry = best_mode_temp;
			best_mode_32k16m_tail = current;
		}
		else  {
			best_mode_32k16m_head = current;
			current->preventry = NULL;
			best_mode_32k16m_tail = current;
		}
	}
}

