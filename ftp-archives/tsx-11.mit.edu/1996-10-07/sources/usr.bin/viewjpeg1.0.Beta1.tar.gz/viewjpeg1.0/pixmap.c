
#include "viewjpeg.h"
#include <vga.h>
#include <vgagl.h>

#define red_color   0
#define green_color 1
#define blue_color  2

struct XCOLOR_PROTO {
	struct XCOLOR_PROTO  *nextentry; /* next entry */
	struct XCOLOR_PROTO  *preventry; /* prevous entry */
	int		   			 red; /* amount of red */
	int		 		     green; /* amount of green */
	int		  			 blue; /* amount of blue */
	char		     	 name[128]; /* colors name */
}; /* XCOLOR map prototype */

typedef struct XCOLOR_PROTO XCOLOR; /* define XCOLOR */

XCOLOR *linked_xcolor_head; /* the xcolor list head */
XCOLOR *linked_xcolor_tail; /* the xcolor list tail */
XCOLOR *linked_xcolor_temp; /* a xcolor list element */
XCOLOR *linked_xcolor; /* a xcolor list element */
struct COLOR { int color_info[3][256]; char type[256]; };
struct COLOR color;

XCOLOR* 
xcolor_preordersort(XCOLOR *head, XCOLOR *tobeadded) {

	/* haed case */
   if (strcmp(tobeadded->name, head->name) < 0) {
   	head->preventry = tobeadded;
   	tobeadded->nextentry = head;
	tobeadded->preventry = NULL;
	return tobeadded;
   }
   else {
	linked_xcolor_temp = head;
	while(strcmp(tobeadded->name, linked_xcolor_temp->name) > 0 && linked_xcolor_temp->nextentry != NULL) {
	   linked_xcolor_temp = linked_xcolor_temp->nextentry; 
	}
	
	/* greater than last entry */
	if (strcmp(tobeadded->name, linked_xcolor_temp->name) == 1) {
	   tobeadded->preventry = linked_xcolor_temp;
	   if(linked_xcolor_temp->nextentry != NULL) { /* not tail */
	     linked_xcolor_temp->nextentry->preventry = tobeadded;
	     tobeadded->nextentry = linked_xcolor_temp->nextentry;
	   }
	   else {
	     tobeadded->nextentry = NULL;
		 linked_xcolor_tail = tobeadded;
	   } 
	   linked_xcolor_temp->nextentry = tobeadded;
       return head;
   	}
	else { /* less than last entry */
	   tobeadded->nextentry = linked_xcolor_temp;
	   linked_xcolor_temp->preventry->nextentry = tobeadded;
	   tobeadded->preventry = linked_xcolor_temp->preventry;
	   linked_xcolor_temp->preventry = tobeadded;
	   return head;
	}
   }
}


void
killcolorlist(XCOLOR *listtype) {

 int i = 0; 

 /* starting with the head and going till tail free up the list */
 if (listtype != NULL) {
   while(listtype->nextentry != NULL) {
		listtype = listtype->nextentry;
		free(listtype->preventry); 
   }
 free(listtype);
 }
}


void
get_xcolor_table() {

	int i = 0, j, v;
	char c, *line;
	FILE *rgb;

	if((rgb = fopen("/usr/X11/lib/X11/rgb.txt", "r")) == NULL) { 
		fprintf(dfd, "could not open text file for reading\n"); 
		exit(0);
	}
	/* skip fist line */
	for( ; c != '\n'; c = getc(rgb) );
	c = getc(rgb);

	i = 0;
	do {
		linked_xcolor = malloc( sizeof(XCOLOR) );
		linked_xcolor->preventry = NULL;
		linked_xcolor->nextentry = NULL;

		/* read in each line */
		for(j = -1; c != '\n'; c = getc(rgb) ) { j++; line[j] = c; }
		line[++j] = c;
		c = getc(rgb);
		
		linked_xcolor->red = 0;
		for(j = 0; j < 3; j++) {			
			if(line[j] != ' ') {
				if(j == 0) { linked_xcolor->red = ((convert_to_int(line[j]))*100); }
				else if(j == 1) { linked_xcolor->red += ((convert_to_int(line[j]))*10); }
				else { linked_xcolor->red += (convert_to_int(line[j])); }
			}
		}

		for(j = 4; j < 8; j++) {			
			if(line[j] != ' ') {
				if(j == 4) { linked_xcolor->green = ((convert_to_int(line[j]))*100); }
				else if(j == 5) { linked_xcolor->green += ((convert_to_int(line[j]))*10); }
				else { linked_xcolor->green += (convert_to_int(line[j])); }
			}
		}

		for(j = 8; j < 11; j++) {			
			if(line[j] != ' ') {
				if(j == 8) { linked_xcolor->blue = ((convert_to_int(line[j]))*100); }
				else if(j == 9) { linked_xcolor->blue += ((convert_to_int(line[j]))*10); }
				else { linked_xcolor->blue += (convert_to_int(line[j])); }
			}
		}

		v = 0;
		for(j = 13; line[j] != '\n'; j++) {
			if(line[j] != '\t') {
				linked_xcolor->name[v] = line[j];
				v++;
			}
		}

	   	if(i != 0) {
			linked_xcolor_head  = xcolor_preordersort(linked_xcolor_head, linked_xcolor); 
	   	}
	   	else { 
			linked_xcolor_head   = linked_xcolor;
 		}
    	i++;
	} while(c != EOF);

}


void
guess_color_codes(char *three_values,  int *red, int *green, int *blue) {

	int i, num[7], remove_value;
	char c;

	c = '1';
	remove_value = c - 1;
	
	for(i = 1; i < 7; i++) {
		switch(three_values[i]) {
			case '1': case '2': case '3': case '4': case '5': case '6':
			case '7': case '8':	case '9': case '0':
				num[i] = three_values[i] - remove_value;
				break;
			case 'a':
				num[i] = 10;
				break;
			case 'b':
				num[i] = 11;
				break;
			case 'c':
				num[i] = 12;
				break;
			case 'd':
				num[i] = 13;
				break;
			case 'e':
				num[i] = 14;
				break;
			case 'f':
				num[i] = 15;
				break;
		};
	}
	*red   = (num[1] * 16) + num[2];
	*green = (num[3] * 16) + num[4];
	*blue  = (num[5] * 16) + num[6];
}


void
check_for_name(char *color_name, int *red, int *green, int *blue) {
	
linked_xcolor = linked_xcolor_head;
	while( strcmp(color_name, linked_xcolor->name) != 0) {
		if(strcmp(linked_xcolor->name, linked_xcolor_tail->name) == 0) { break; }
		else { linked_xcolor = linked_xcolor->nextentry; }
	}
	*red   = linked_xcolor->red;
	*green = linked_xcolor->green;
	*blue  = linked_xcolor->blue;
}


char*
get_line(FILE *pixmap) {

	char *line, c;
	int i;
	
	for(; c != '"' && c != '}'; c = getc(pixmap) );
	if(c != EOF) {
		c = getc(pixmap);
		for(i = 0; c != '"' && c != EOF; c = getc(pixmap) ) { line[i] = c; i++; }
		line[i] = '\0';
		return line;
	}
	else { return "EOF"; }
}


char*
patch_line(FILE *pixmap) {

	char *line, c;
	int i;
	
	for(i = 0; c != '"' && c != EOF; c = getc(pixmap) ) { line[i] = c; i++; }
	line[i] = '\0';
	return line;
}

void
pixmap_display(FILE *pixmap, int width, int height, int cmap_length) {

	int red, green, blue, row, col, i, j, k;
	int offset_height, offset_width, current_number;
	char current_type, line[width+2], c;

	/* find the offsets for writing to the screen */
	/* if to lage for screen then offsets are 0,0 */
	if(( height * 2 ) > mode_height || (width * 2) > mode_width) { 
		offset_height = 0;
		offset_width = 0;
	}
	else { 
		offset_height = (mode_height - (height * 2) )/2;
		offset_width = (mode_width - (width * 2) )/2;
	}

	/* read in the full pixmap data */
	if(mode_depth == 256) { 
		if(opt_greyscale == 1) { greyscale_colormap(cmap_length, color.color_info); } /* greyscale pic */
		set_custom_palette(cmap_length, color.color_info); /* set up palette */
		row = 0;
		while(row < (height * 2)) { 
			strcpy(line, get_line(pixmap) );
		 	if(line[0] ==  ',') { strcpy(line, patch_line(pixmap) ); }
			current_number = 0;
			current_type = color.type[current_number];
			for(k = 0; k < 2; k++) {
				col = j = 0; 
				while(col < width) {
					if(line[col] == current_type) { 
						gl_setpixel(j+offset_width, row+offset_height, current_number); 
						j++;
						gl_setpixel(j+offset_width, row+offset_height, current_number);
						j++;
					}
					else { 
						for(current_number = 0; line[col] != color.type[current_number]; current_number++);
						current_type = color.type[i];
						gl_setpixel(j+offset_width, row+offset_height, current_number);
						j++;
						gl_setpixel(j+offset_width, row+offset_height, current_number);
						j++;
					}
					col++;
				}
				row++;
			}
		}
	}
	else { 
		row = 0;
		while(row < (height * 2)) { 
			strcpy(line, get_line(pixmap) );
		 	if(line[0] ==  ',') { strcpy(line, patch_line(pixmap) ); }
			current_number = 0;
			current_type = color.type[current_number];
			for(k = 0; k < 2; k++) {
				col = j = 0; 
				while(col < width) {
					if(line[col] == current_type) { 
						red   = color.color_info[red_color]  [current_number];
						green = color.color_info[green_color][current_number];
						blue  = color.color_info[blue_color] [current_number];
						gl_setpixelrgb(j+offset_width, row+offset_height, red, green, blue); 
						j++;
						gl_setpixelrgb(j+offset_width, row+offset_height, red, green, blue); 
						j++;
					}
					else { 
						for(current_number = 0; line[col] != color.type[current_number]; current_number++);
						current_type = color.type[i];
						red   = color.color_info[red_color]  [current_number];
						green = color.color_info[green_color][current_number];
						blue  = color.color_info[blue_color] [current_number];
						gl_setpixelrgb(j+offset_width, row+offset_height, red, green, blue); 
						j++;
						gl_setpixelrgb(j+offset_width, row+offset_height, red, green, blue); 
						j++;
					}
					col++;
				}
				row++;
			}
		}
	}
}


void
display_256_pixmap(int height, int width, int cmap_length, FILE *pixmap) {

	char *line, name[80], c; /* good size? */
  	int row, col, red, green, blue;
	int components, i, j, k;

	color.type[0] = '~';
	color.color_info[red_color][0] = color.color_info[green_color][0] = color.color_info[blue_color][0] = 0;

	for(i = 1; i < cmap_length; i++) {
		line = get_line(pixmap);
		if(line[0] == ',') { line = patch_line(pixmap); }

		color.type[i] = line[0];

		for(j = 0; line[j] != 'c' ; j++); j += 2; /* find color starting point */
		for(k = 0; line[j] != '\0'; name[k++] = line[j++]); name[k] = '\0'; /* save remainder of string to name */
		if(name[0] == '#') { 
			guess_color_codes(name, &red, &green, &blue); 
			color.color_info[red_color][i]   = red;
			color.color_info[green_color][i] = green;
			color.color_info[blue_color][i]  = blue;
		}
		else { 
			if(strcasecmp(name, "none") != 0) { 
				check_for_name(name, &red, &green, &blue); 
				color.color_info[red_color][i]   = red;
				color.color_info[green_color][i] = green;
				color.color_info[blue_color][i]  = blue;
			}
			else { color.color_info[red_color][i] = color.color_info[green_color][i] = color.color_info[blue_color][i] = 255; }
		}
	}

	if(opt_forcemode == 0) { components = 1; }
	else {
		switch (opt_forcemode) {
			case 12:
			case 11:
		  	case 10:
		  	case 5:
				components = 1;
				break;
		  	default :
				components = 3;
				break;
		}
	}

	display_init( (height * 2), (width * 2), components);

	pixmap_display(pixmap, width, height, cmap_length);
}


int
read_pixmap_file(char *image_name) {

	int i, j, width, height, cmap_length;
	FILE *pixmap;
	char *line;

	pixmap = fopen(image_name, "r");
	
	line = get_line(pixmap);
	if(line[0] == ',') { line = patch_line(pixmap); }

	width       =  convert_to_int(line[0]) * 10;
	width       += convert_to_int(line[1]);
	height      =  convert_to_int(line[3]) * 10;
	height      += convert_to_int(line[4]);
	cmap_length =  convert_to_int(line[6]) + 1;

	get_xcolor_table();

	display_256_pixmap(height, width, cmap_length, pixmap);

	killcolorlist(linked_xcolor_head); /* clear the list */
	fclose(pixmap);

	return scroll_until_end(); 
}
