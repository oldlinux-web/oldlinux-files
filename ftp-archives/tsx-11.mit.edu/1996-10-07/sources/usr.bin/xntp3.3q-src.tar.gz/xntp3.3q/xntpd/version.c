/*
 * version file for xntpd
 */
char * Version = "xntpd version=3.3q (beta); Mon Apr 11 12:46:02 MET DST 1994 (1)";
