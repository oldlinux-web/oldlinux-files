/*
 * version file for xntpres
 */
char * Version = "xntpres version=3.3q (beta); Mon Apr 11 12:49:33 MET DST 1994 (1)";
