/*
 * version file for xntpdc
 */
char * Version = "xntpdc version=3.3q (beta); Mon Apr 11 12:47:19 MET DST 1994 (1)";
