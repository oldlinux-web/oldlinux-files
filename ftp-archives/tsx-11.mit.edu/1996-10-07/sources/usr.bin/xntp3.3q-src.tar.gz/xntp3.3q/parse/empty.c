/*
 * Well, some ranlibs, ar's or compilers react funny
 * if asked to do nothing but build empty valid files
 * I would have preferred to a no or at least a static
 * symbol here...
 */
char * _____empty__ = "empty .o file";
