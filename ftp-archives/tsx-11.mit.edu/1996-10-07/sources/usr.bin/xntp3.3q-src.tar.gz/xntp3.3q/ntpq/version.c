/*
 * version file for ntpq
 */
char * Version = "ntpq version=3.3q (beta); Mon Apr 11 12:48:22 MET DST 1994 (1)";
