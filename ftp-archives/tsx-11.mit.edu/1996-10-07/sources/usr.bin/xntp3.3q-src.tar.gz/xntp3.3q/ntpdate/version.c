/*
 * version file for ntpdate
 */
char * Version = "ntpdate version=3.3q (beta); Mon Apr 11 12:48:52 MET DST 1994 (1)";
