/*
 * version file for ntptrace
 */
char * Version = "ntptrace version=3.3q (beta); Mon Apr 11 12:49:12 MET DST 1994 (1)";
