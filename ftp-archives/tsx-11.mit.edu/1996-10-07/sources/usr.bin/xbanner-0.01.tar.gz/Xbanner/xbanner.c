#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include <X11/Xlib.h>

enum { X, Y, PLACE, EFFECT, FONT, FGC, SHDC, LABEL, XOFFS, YOFFS,
	SHADOWS, SURMIN, SURMAX };

enum { NONE, SHADOW, SURROUND, SHADSUR, SHD3D, SHD3D_FANCY };

enum { TOPLEFT, TOPRIGHT, BOTLEFT, BOTRIGHT, TOPCENT, BOTCENT, XY };

char BANNER[128] = "L i n u x !";

int  XDEFOFFSET   = 30;
int  YDEFOFFSET   = 0;
char FGCOLOR[20]  = "yellow";
char SHDCOLOR[20] = "darkblue";

char *DISP = NULL;

char FONTN[256] = "-bitstream-charter-bold-i-normal--176-*-100-100-*-*-iso8859-1";

int SUR_MIN = -2;
int SUR_MAX = 2;

int SHD3D_SHADOWS = 2;

/* no more defines */

Display        *disp;
GC		mgc;
XGCValues	gcv;
XFontStruct    *xfont;
Screen         *scrn;
int		scrn_no;
Window		root;
XCharStruct	xchrs;
Colormap	cmap;
XColor		xfgc,xshdc,xexact;
Pixmap		rootwin;

int sc_w,sc_h;			/* screen width/height		*/
int dir,fasc,fdsc;		/* font ascent/descent and dir	*/
int bwid;			/* banner pixel width		*/
int final_x,final_y;		/* where the text will finally appear */
int placement = TOPCENT;
int effect = SHD3D_FANCY;

int i,j,t;

char OPTFILE[128];

#define strcmpi(ARG1,ARG2) strcasecmp(ARG1,ARG2)
#define strncmpi(ARG1,ARG2,ARG3) strncasecmp(ARG1,ARG2,ARG3)

/* no more global vars */

char *option_keyword[] =
{
  "x", "y", "Placement", "Effect", "Font", "Foreground", "ShadowColor",
  "Label", "XdefOffset", "YdefOffset", "Shadows", "Surround_Min",
  "Surround_Max",
  NULL
};

char *effect_keyword[] =
{
  "None", "Shadow", "Surround", "Shadowed-Surround", "3D-Shadow", "Fancy-3D",
  NULL
};

char *placement_keyword[] =
{
  "TopLeft", "TopRight", "BottomLeft", "BottomRight", "TopCenter",
  "BottomCenter", "XY",
  NULL
};

void Parse_Optfile(void)
{
  FILE *fin;
  char line[256];
  char *p,opt[20];
  int i,val;

  if(OPTFILE[0]=='\0')
    strcpy(OPTFILE,"/usr/lib/X11/xdm/xbanner-config");

  fin = fopen(OPTFILE,"r");
  if(fin==NULL)
    return;	/* no options file */
  while(fgets(line,255,fin)!=NULL)
  {
    i=0;

    line[strlen(line)-1]='\0';

    if(line[0]=='#')
      continue;		/* remark */
    if(strncmpi(line,"Xbanner",7)==0)
      p = line+8;
    else
      p = line;
    while(*p!=':' && i<20)
      opt[i++] = *p++;
    opt[i]='\0';		/* add a null */
    for(i=0;option_keyword[i]!=NULL;i++)
      if(strcmpi(opt,option_keyword[i])==0)
        break;
    if(option_keyword[i]==NULL)
    {
      /* complain and continue */
      fprintf(stderr,"Unknown option '%s'.\n",opt);
      continue;		/* next line... */
    }
    p++;			/* skip the : */
    while(isspace(*p))	/* skip WS */
      p++;
 
    val = atoi(p);	/* convert to bin */

    switch(i)
    {
      case X:
	final_x = val;
        break;
      case Y:
	final_y = val;
        break;
      case PLACE:
	for(i=0;placement_keyword[i]!=NULL;i++)
	  if(strcmpi(placement_keyword[i],p)==0)
	    break;
	if(placement_keyword[i]==NULL)
	{
	  fprintf(stderr,"Unknown placement '%s'\n",p);
	  continue;
	}
	placement = i;
        break;
      case EFFECT:
	for(i=0;effect_keyword[i]!=NULL;i++)
	  if(strcmpi(effect_keyword[i],p)==0)
	    break;
	if(effect_keyword[i]==NULL)
	{
	  fprintf(stderr,"Unknown effect '%s'\n",p);
	  continue;
	}
	effect = i;
        break;
      case FONT:
        strcpy(FONTN,p);
        break;
      case FGC:
        strcpy(FGCOLOR,p);
        break;
      case SHDC:
        strcpy(SHDCOLOR,p);
        break;
      case LABEL:
        strcpy(BANNER,p);
        break;
      case XOFFS:
        XDEFOFFSET = val;
        break;
      case YOFFS:
        YDEFOFFSET = val;
        break;
      case SHADOWS:
        SHD3D_SHADOWS = val;
        break;
      case SURMIN:
	SUR_MIN = val;
        break;
      case SURMAX:
        SUR_MAX = val;
        break;
    }
  }
  fclose(fin);	/* done! */
}

void CalcXY(void)
{
  if(dir == FontLeftToRight) {		/* left to right text 	*/
    switch(placement)
    {
      case TOPLEFT:
        final_x = XDEFOFFSET;			/* start with that	*/
        final_y = YDEFOFFSET + fasc;		/* make the X/Y thing	*/
        break;
      case TOPRIGHT:
	final_x = sc_w - XDEFOFFSET - bwid;	/* find the X		*/
	final_y = YDEFOFFSET + fasc;     	/* make the X/Y thing   */
        break;
      case BOTLEFT:
	final_x = XDEFOFFSET;
	final_y = sc_h - YDEFOFFSET - fdsc;	/* make sure descenders are OK */
        break;
      case BOTRIGHT:
	final_x = sc_w - XDEFOFFSET - bwid;	/* find the X		*/
	final_y = sc_h - YDEFOFFSET - fdsc;	/* make sure descenders are OK */
        break;
      case TOPCENT:
	final_x = (sc_w / 2) - (bwid / 2);
	final_y = YDEFOFFSET + fasc;     	/* make the X/Y thing   */
        break;
      case BOTCENT:
	final_x = (sc_w / 2) - (bwid / 2);
	final_y = sc_h - YDEFOFFSET - fdsc;	/* make sure descenders are OK */
        break;
      default:
        ;		/* XY placement */
    }
  }
  else		/* direction */
  {
    switch(placement)
    {
      case TOPLEFT:
        final_x = XDEFOFFSET + bwid;		/* start with that	*/
        final_y = YDEFOFFSET + fasc;		/* make the X/Y thing	*/
        break;
      case TOPRIGHT:
	final_x = sc_w - XDEFOFFSET;		/* find the X		*/
	final_y = YDEFOFFSET + fasc;     	/* make the X/Y thing   */
        break;
      case BOTLEFT:
	final_x = XDEFOFFSET + bwid;
	final_y = sc_h - YDEFOFFSET - fdsc;	/* make sure descenders are OK */
        break;
      case BOTRIGHT:
	final_x = sc_w - XDEFOFFSET;		/* find the X		*/
	final_y = sc_h - YDEFOFFSET - fdsc;	/* make sure descenders are OK */
        break;
      case TOPCENT:
	final_x = (sc_w / 2) - (bwid / 2);
	final_y = YDEFOFFSET + fasc;     	/* make the X/Y thing   */
        break;
      case BOTCENT:
	final_x = (sc_w / 2) - (bwid / 2);
	final_y = sc_h - YDEFOFFSET - fdsc;	/* make sure descenders are OK */
        break;
      default:
        ;		/* XY placement */
    }
  }
}

void DrawIt(void)
{
  switch(effect)
  {
    case NONE:
      XSetForeground(disp,mgc,xfgc.pixel);
      XDrawString(disp,rootwin,mgc,final_x,final_y,BANNER,strlen(BANNER));
      break;
    case SHADOW:
      XSetForeground(disp,mgc,xshdc.pixel);
      XDrawString(disp,rootwin,mgc,final_x+5,final_y+5,BANNER,strlen(BANNER));
      XSetForeground(disp,mgc,xfgc.pixel);
      XDrawString(disp,rootwin,mgc,final_x,final_y,BANNER,strlen(BANNER));
      break;
    case SURROUND:
      XSetForeground(disp,mgc,xshdc.pixel);
      for(i=SUR_MIN;i<SUR_MAX+1;i++)
        for(j=SUR_MIN;j<SUR_MAX+1;j++)
          XDrawString(disp,rootwin,mgc,final_x+i,final_y+j,BANNER,strlen(BANNER));
      XSetForeground(disp,mgc,xfgc.pixel);
      XDrawString(disp,rootwin,mgc,final_x,final_y,BANNER,strlen(BANNER));
      break;
    case SHADSUR:
      XSetForeground(disp,mgc,xshdc.pixel);
      XDrawString(disp,rootwin,mgc,final_x+5,final_y+5,BANNER,strlen(BANNER));
      for(i=SUR_MIN;i<SUR_MAX+1;i++)
        for(j=SUR_MIN;j<SUR_MAX+1;j++)
          XDrawString(disp,rootwin,mgc,final_x+i,final_y+j,BANNER,strlen(BANNER));
      XSetForeground(disp,mgc,xfgc.pixel);
      XDrawString(disp,rootwin,mgc,final_x,final_y,BANNER,strlen(BANNER));
      break;
    case SHD3D:
      for(t=5*SHD3D_SHADOWS ; t>0 ; t-=5)
      {
        XSetForeground(disp,mgc,xshdc.pixel);
        for(i=SUR_MIN;i<SUR_MAX+1;i++)
          for(j=SUR_MIN;j<SUR_MAX+1;j++)
            XDrawString(disp,rootwin,mgc,final_x+i+t,final_y+j+t,BANNER,strlen(BANNER));
        XSetForeground(disp,mgc,xfgc.pixel);
        XDrawString(disp,rootwin,mgc,final_x+t,final_y+t,BANNER,strlen(BANNER));
      }
      XSetForeground(disp,mgc,xshdc.pixel);
      for(i=SUR_MIN;i<SUR_MAX+1;i++)
        for(j=SUR_MIN;j<SUR_MAX+1;j++)
          XDrawString(disp,rootwin,mgc,final_x+i,final_y+j,BANNER,strlen(BANNER));
      XSetForeground(disp,mgc,xfgc.pixel);
      XDrawString(disp,rootwin,mgc,final_x,final_y,BANNER,strlen(BANNER));
      break;
    case SHD3D_FANCY:
      for(t=5*SHD3D_SHADOWS ; t>0 ; t-=1)
      {
        XSetForeground(disp,mgc,xshdc.pixel);
        XDrawString(disp,rootwin,mgc,
        	final_x+t+SUR_MIN,
        	final_y+t+SUR_MAX,
        	BANNER,strlen(BANNER));
        XDrawString(disp,rootwin,mgc,
        	final_x+t+SUR_MAX,
        	final_y+t+SUR_MIN,
        	BANNER,strlen(BANNER));
        XDrawString(disp,rootwin,mgc,
        	final_x+t+SUR_MIN,
        	final_y+t+SUR_MIN,
        	BANNER,strlen(BANNER));
        XDrawString(disp,rootwin,mgc,
        	final_x+t+SUR_MAX,
        	final_y+t+SUR_MAX,
        	BANNER,strlen(BANNER));
      }
      for(i=SUR_MIN;i<SUR_MAX+1;i++)
        for(j=SUR_MIN;j<SUR_MAX+1;j++)
          XDrawString(disp,rootwin,mgc,final_x+i,final_y+j,BANNER,strlen(BANNER));
      XSetForeground(disp,mgc,xfgc.pixel);
      XDrawString(disp,rootwin,mgc,final_x,final_y,BANNER,strlen(BANNER));
      break;
  }
}

void CmdLine(int argc, char *argv[])
{
  if(argc==2 || argc==4 || argc > 5)
  {
    fprintf(stderr,"Usage: xbanner -display <disp> -file <file>\n");
    exit(0);
  }

  if(argc>=3)
  {
    if(strcmpi(argv[1],"-display")==0)
      DISP = argv[2];
    if(strcmpi(argv[1],"-file")==0)
      strcpy(OPTFILE,argv[2]);
  }
  if(argc==5)
  {
    if(strcmpi(argv[3],"-display")==0)
      DISP = argv[4];
    if(strcmpi(argv[3],"-file")==0)
      strcpy(OPTFILE,argv[4]);
  }
}

int main(int argc, char *argv[])
{
  /* all vars are global - yuck! */

  OPTFILE[0]='\0';		/* nullify the options file */

  /* do cmdline opts first */
  CmdLine(argc, argv);
  
  /* do options file... */
  Parse_Optfile();

  disp = XOpenDisplay(NULL);		/* start connection with the display */
  if (disp == NULL)
  {
    fprintf(stderr,"Could not open display...\n");
    exit(1);
  }
  
  scrn = XDefaultScreenOfDisplay(disp);	/* get the default screen	*/
  scrn_no = XDefaultScreen(disp);	/* get the default screen #	*/
  
  root = RootWindow(disp,scrn_no);	/* the root window		*/
  
  sc_w = DisplayWidth(disp,scrn_no);	/* get pixel width of screen	*/
  sc_h = DisplayHeight(disp,scrn_no);	/* get pixel height of screen	*/
  
  mgc = DefaultGC(disp,scrn_no);	/* get the root window GC	*/

  xfont = XLoadQueryFont(disp,FONTN);
  	   
  if(xfont == NULL)
  {
    XCloseDisplay(disp);
    fprintf(stderr,"Could not get the font...\n");
    exit(1);
  }

  cmap = XDefaultColormapOfScreen(scrn);		/* get the colormap */

  /* start by allocating the colors */
  dir = XAllocNamedColor(disp,cmap,FGCOLOR,&xfgc,&xexact);
  if(!dir)
  {
    fprintf(stderr,"Could not get the fg color...\n");
    XCloseDisplay(disp);
    exit(1);
  }
  dir = XAllocNamedColor(disp,cmap,SHDCOLOR,&xshdc,&xexact);
  if(!dir)
  {
    fprintf(stderr,"Could not get the shadow color...\n");
    XCloseDisplay(disp);
    exit(1);
  }

  XSetFont(disp,mgc,xfont->fid);			/* set the font */

  XQueryTextExtents(disp,xfont->fid,BANNER,strlen(BANNER),
  			&dir,&fasc,&fdsc,&xchrs);

  bwid = XTextWidth(xfont,BANNER,strlen(BANNER));

  /* make a pixmap */
  rootwin = XCreatePixmap(disp,root,sc_w,sc_h,DefaultDepth(disp,scrn_no));

  /* copy into the pixmap */
  XCopyArea(disp,root,rootwin,mgc,0,0,sc_w,sc_h,0,0);

  /* now I have all info to put it at any corner of the screen, or if wanted
     also at the center...
  */

  CalcXY();

  DrawIt();

  XCopyArea(disp,rootwin,root,mgc,0,0,sc_w,sc_h,0,0);
  XFreeFont(disp,xfont);		/* done with this font.. */

  /* make this pixmap be the background pixmap */
  XSetWindowBackgroundPixmap(disp,root,rootwin);
/*  XClearWindow(disp,root);	/* make it show... */

  XSetCloseDownMode(disp,RetainTemporary);
  XCloseDisplay(disp);
  return 0;
}
