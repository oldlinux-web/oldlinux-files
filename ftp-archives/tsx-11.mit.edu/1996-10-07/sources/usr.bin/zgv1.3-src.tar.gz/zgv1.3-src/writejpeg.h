/* ZGV v1.3 - (c) 1993 Russell Marks for improbabledesigns.
 * See README for license details.
 *
 * writejpeg.h - external prototypes for writejpeg.c
 */
 
extern int write_JPEG_file(char *);
