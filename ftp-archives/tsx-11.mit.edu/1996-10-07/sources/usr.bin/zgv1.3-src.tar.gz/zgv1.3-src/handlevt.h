extern int handlevt(int ttyfd,int newvc);
