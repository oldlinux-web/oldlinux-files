/* ZGV v1.3 - (c) 1993 Russell Marks for improbabledesigns.
 * See README for license details.
 *
 * zgvlogopack.h - header for object containing header.
 *                 are we sufficiently confused yet?
 */

extern unsigned char zgvlogo[];
extern int logow,logoh;
