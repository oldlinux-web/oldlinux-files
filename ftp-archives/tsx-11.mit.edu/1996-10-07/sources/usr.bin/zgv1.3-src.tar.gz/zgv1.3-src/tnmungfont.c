#include <stdio.h>



main()
{
FILE *in,*out;
char buf[80];
int f;

if((in=fopen("tnpicfont.dat","r"))==NULL)
  printf("Can't open font definition file.\n");
else
  {
  if((out=fopen("tnpicfont.h","w"))==NULL)
    printf("Can't open font include file.\n");
  else
    {
    fprintf(out,
      "/* tnpic font charmap - automatically generated from tnpicfont.dat,\n"
      " * edits will be lost.\n"
      " */\n\n"
      "#define LETTERSIZ (8*5+1)\n\n"
      "char tnpicfont[95*LETTERSIZ+1]={\n");
    while(fgets(buf,sizeof(buf),in)!=NULL)
      {
      fprintf(out,"  %c,\n",buf[0]);
      for(f=0;f<5;f++)
        {
        fgets(buf,sizeof(buf),in);
        buf[8]=0;
        fprintf(out,"  '%c','%c','%c','%c','%c','%c','%c','%c',\n",
                      buf[0],buf[1],buf[2],buf[3],buf[4],buf[5],buf[6],buf[7]);
        }
      }
    fprintf(out,"  0};");
    fclose(out);
    }
  fclose(in);
  }
}
