/* ZGV v1.3 - (c) 1993 Russell Marks for improbabledesigns.
 * See README for license details.
 *
 * rc_config.h - Defined! the zgv_config structure.
 *                       photographic evidence on page 2. :)
 */

struct zgv_config {
  int videomode,zoom,vkludge,modesel;
  int brightness;
  double contrast;
  };
