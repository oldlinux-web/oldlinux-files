/* ZGV v1.3 - (c) 1993 Russell Marks for improbabledesigns.
 * See README for license details.
 *
 * font.h - external prototypes for font.c
 */
 
extern int vgadrawtext(int,int,int,char *);
extern int vgatextsize(int,char *);
