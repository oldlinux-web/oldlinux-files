/* ZGV v1.3 - (c) 1993 Russell Marks for improbabledesigns.
 * See README for license details.
 *
 * vgadisp.h - prototypes for vgadisp.c
 */

/* required for config reading/writing by zgv.c (or is it rc_config.c?) */
extern int curvgamode,zoom,virtual,vkludge,modesel,brightness;
extern double contrast;

extern int readgiforjpg(char *,hffunc);
extern int is_this_file_jpeg();

