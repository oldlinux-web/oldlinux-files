/* ZGV v1.3 - (c) 1993 Russell Marks for improbabledesigns.
 * See README for license details.
 *
 * usejpeg.h - external prototypes for usejpeg.c
 */
 
extern int read_JPEG_file(char *,hffunc,byte **);
extern int aborted_file_jpeg_cleanup();
