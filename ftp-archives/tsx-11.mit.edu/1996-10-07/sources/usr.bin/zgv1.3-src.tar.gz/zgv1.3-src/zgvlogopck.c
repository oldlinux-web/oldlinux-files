/* ZGV v1.3 - (c) 1993 Russell Marks for improbabledesigns.
 * See README for license details.
 *
 * zgvlogopack.c - puts the logo file (zgvlogo.h) into an object file.
 *                 makes makes quicker. :)
 */

#include "zgvlogo.h"
