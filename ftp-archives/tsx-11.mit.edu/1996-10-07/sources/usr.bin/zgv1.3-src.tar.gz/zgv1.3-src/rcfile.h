/* ZGV v1.3 - (c) 1993 Russell Marks for improbabledesigns.
 * See README for license details.
 *
 * rcfile.h - protos for rcfile.c
 */

extern struct zgv_config cfg;

/* rcfile.c */
extern int getconfig(void);
extern int saveconfig(void);
