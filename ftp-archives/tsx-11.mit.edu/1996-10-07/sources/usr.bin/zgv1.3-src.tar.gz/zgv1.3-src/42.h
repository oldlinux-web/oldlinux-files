/* ZGV v1.3 - (c) 1993 Russell Marks for improbabledesigns.
 * See README for license details.
 *
 * 42.h - simple header to define commonly used typedef
 */

#ifndef __ZGV_42H
#define __ZGV_42H
typedef unsigned char byte;
#endif
