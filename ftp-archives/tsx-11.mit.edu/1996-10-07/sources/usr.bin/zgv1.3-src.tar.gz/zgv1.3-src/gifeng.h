/* ZGV v1.3 - (c) 1993 Russell Marks for improbabledesigns.
 * See README for license details.
 *
 * gifeng.h - constants, prototypes etc. to do with gifeng.c
 */

#include "42.h"

#define _GIF_OK 0
#define _GIFERR_NOFILE -1
#define _GIFERR_NOMEM -2
#define _GIFERR_NOTGIFFILE -3
#define _GIFERR_NOCOLOURMAP -4
#define _GIFERR_NOIMAGE -5
#define _GIFERR_LOCALMAP -6
#define _GIFERR_CORRUPT -7
#define _GIFERR_SHOWN_ALREADY  -8


struct _gifinfo {
  int width,height;
  int bpp,numcols;
  char type[4];
  };

typedef struct _gifinfo GIFINFO;
typedef void (*hffunc)(int,int);

extern int readgif(char *,byte **,byte **,hffunc);
extern void getgifinfo(GIFINFO *);
extern int aborted_file_gif_cleanup();
