/* ZGV v1.3 - (c) 1993 Russell Marks for improbabledesigns.
 * See README for license details.
 *
 * texterrors.c - provides a fake 'msgbox' routine which printf()'s instead.
 */


int msgbox(ttyfd,message,replytype,lite,dark,txt)
int ttyfd;
char *message;
int replytype,lite,dark,txt;
{
puts(message);
exit(1);     /* always fatal */
}
