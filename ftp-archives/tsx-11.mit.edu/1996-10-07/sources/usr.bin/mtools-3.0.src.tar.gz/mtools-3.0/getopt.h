     int getopt();
     extern char *optarg;
     extern int optind, opterr;
