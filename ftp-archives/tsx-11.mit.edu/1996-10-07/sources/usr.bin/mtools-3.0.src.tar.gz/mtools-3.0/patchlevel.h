#define VERSION	"3.0 "
#define DATE	"12 May 96"
