/* this file is created automatically by buildzsh */
/* if all this is wrong, blame csh ;-) */

#define SIGCOUNT       1

#ifdef GLOBALS

char *sigmsg[SIGCOUNT+2] = {
	"done",
	"SIG",
	NULL
};

char *sigs[SIGCOUNT+4] = {
	"EXIT",
	"",
	"ERR",
	"DEBUG",
	NULL
};

#else

extern char *sigs[SIGCOUNT+4],*sigmsg[SIGCOUNT+2];

#endif
