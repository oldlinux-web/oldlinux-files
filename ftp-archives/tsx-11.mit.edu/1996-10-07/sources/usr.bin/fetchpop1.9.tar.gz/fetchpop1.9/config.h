/*
 * $Id: config.h,v 1.9 1996/06/25 01:37:33 oh Exp $
 */

#define POP_PORT 110

  /* If you want 180 or 600 seconds, put "180" or "600" here. Don't put too 
   * low value.
   */
#define MINSLEEPSECOND	"300" 

  /* This is used only if the environment variable $MAIL is not defined.
   * Under HP-UX, it might be "/usr/mail" and under SUN, it might be "/var/mail"
   */
#define MAILSPOOLDIR "/var/spool/mail"

  /* If you want to compile fetchpop with -DHAVEMDA (-m flag support), 
   * change this to one of MDAs, such as deliver, sendmail, mail. 
   * Using mail is not recommended under Linux. 
   * Best of all, if you have the procmail package, 
   * don't worry about this and edit FORMAIL below. On most systems,
   * deliver is /usr/bin/deliver, sendmail is /usr/lib/sendmail, and
   * mail is /bin/mail
   */
#define DefaultMDA "/usr/lib/sendmail" 

  /* If you want to complie fetchpop with -DHAVEPROCMAIL  
   * (-p flag procmail support),
   * edit the FORMAIL to where the formail is. (Formail is the mail
   * (re)formatter that comes with the procmail package)
   */
#define FORMAIL "/usr/bin/formail" 

