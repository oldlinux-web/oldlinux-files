/*
 * $Id: pop.h,v 1.9 1996/06/26 01:27:19 oh Exp $
 *
 *  Copyright (C) 1996	seung-hong oh
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; version 2 of the License.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define whoami (getpwuid(getuid())->pw_name)

int pop(struct optrep *options);
int get_reply(int sockfd, char *argbuf);
int pop_auth(int sockfd, char *userid, char *passwd, short int logging, short int daemon, FILE *fd);
int pop_quit(int sockfd );
int pop_stat(int sockfd, int *howmany);
int pop_retr(int sockfd, int msgnum);
int openmbox(signed char deliver, char *output);
int closembox(int fd );
int pop_dele(int sockfd, int msgnum);
int pop_top(int sockfd, int num, int lines);
int pop_last(int sockfd, int *lastread);
void printmsg(char *msg, signed char logging, signed char daemon, FILE *logfd, unsigned short int err, short int tostdout);
int pop_rset(int sockfd);

