#ifdef __50SERIES

#  include <stdio.h>

Schar
*getenv(const Schar *env_var)
/*
   Emulate getenv()-function for PRIME/Primos machines
*/
{
  static Schar  buf[256];
  extern Schar *gvget();


  buf[0] = '.';
  strcpy(buf+1, env_var);

  return(gvget(buf));
}
#endif /* __50SERIES */

