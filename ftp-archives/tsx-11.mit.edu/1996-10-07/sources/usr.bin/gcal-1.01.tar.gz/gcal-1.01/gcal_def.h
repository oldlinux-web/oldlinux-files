#ifndef __GCAL_DEF_H
#  define __GCAL_DEF_H
/*
*  gcal_def.h:  Program name, release number and modification symbols.
*
*
*  Copyright (C) 1994, 1995, 1996 Thomas Esken
*
*  This software doesn't claim completeness, correctness or usability.
*  On principle I will not be liable for ANY damages or losses (implicit
*  or explicit), which result from using or handling my software.
*  If you use this software, you agree without any exception to this
*  agreement, which binds you LEGALLY !!
*
*  This program is free software; you can redistribute it and/or modify
*  it under the terms of the `GNU General Public License' as published by
*  the `Free Software Foundation'; either version 2, or (at your option)
*  any later version.
*
*  You should have received a copy of the `GNU General Public License'
*  along with this program; if not, write to the:
*
*    Free Software Foundation, Inc.
*    59 Temple Place - Suite 330
*    Boston, MA 02111-1307,  USA
*/



/*
*  $Id: gcal_def.h 1.01 1996/03/20 01:00:01 tom Exp $
*/



/*
*  Define the program name and version.
*/
#define  PRGR_NAME     "gcal"      /* Actual program name, 6 places maximum */
#define  VERSION_NO    "1.01"      /* Actual version number */



/*
*
*  BEGIN: General program modification symbols,
*           which may be changed by the user !!
*
*/

/*
*  To adapt this program, EITHER define/activate the following symbols in
*    this file OR add the following symbols in Makefile (-D`symbol=value'...)
*    (this all isn't necessary if the GNU Autoconf(igure) technology is used):
*
*  a)  - Define `DEBUG 1' for performing some assertations when program starts.
*      - Delete the symbol DEBUG or write `DEBUG 0' if you don't want this
*          feature...
*
*  b)  - Define `USE_CATH 1' for showing some specific Catholic holidays
*          in eternal holiday list, too.
*      - Delete the symbol USE_CATH or write `USE_CATH 0' if you don't
*          need them...
*
*  c)  - Define `USE_EASC 1' for using the extended IBM-ASCII character set.
*      - Delete the symbol USE_EASC or write `USE_EASC 0' for using the
*          ISO-ASCII/EBCDIC character set...
*
*  d)  - Define `USE_GER 1' for using German messages and holidays.
*      - Delete the symbol USE_GER or write `USE_GER 0' for using
*          English messages and holidays...
*
*  e)  - Define `USE_HLS 1' to run this program using control sequences
*          for highlighting the current day/holidays/text (MS/PC-DOS will
*          use the [n]ansi.sys driver for emitting ANSI Escape highlighting
*          sequences; OS2/Linux/UN*X-like systems will use `termcap' for
*          emitting the terminal specific highlighting sequences.  If this
*          fails, default (generic) ANSI highlighting sequences will be used).
*      - Delete the symbol USE_HLS or write `USE_HLS 0' to run this program
*          without highlighting...
*
*  f)  - Define `USE_PAGER 1' for using an external pager (availabe only
*          on UN*X-like systems) or for using the simple, internal pager
*          (if external pager fails).
*      - Delete the symbol USE_PAGER or write `USE_PAGER 0' if you don't
*          like this feature...
*
*  g)  - Define `USE_RC 1' for using the special month dates functions
*          (print daily/weekly/monthly/yearly/eternal/special fixed dates
*          texts which are stated in the resource file(s)).
*      - Delete the symbol USE_RC or write `USE_RC 0' if you don't
*          like this feature...
*
*  h)  - Define `USE_USHDY 1' for showing the specific U.S. holidays in
*          eternal holiday list, too (active only in case symbol USE_GER
*          is set to 0)
*      - Delete the symbol USE_USHDY or write `USE_USHDY 0' if you
*          don't need them...
*
*  i)  - Define EXIT_STAT_HLP 127 if you want the exit status 127 on
*          --help, --long-help[=ARG], --license and --version.
*      - Delete the symbol EXIT_STAT_HLP or define EXIT_STAT_HLP 0
*          if you want the exit status 0 on --help, --long-help[=ARG],
*          --license and --version...
*
*  j)  - Either define `GREG_1582 1' if you want the Gregorian reformation
*          have occured in 1582 or define `GREG_1752 1' if you want the
*          Gregorian reformation have occured in 1752.  Using this is not
*          necessary in most cases, because this year is set correctly
*          depending on selected language to use (see USE_GER); this means
*          to the year 1582 for German users and to the year 1752 for
*          English users by default.
*/

/*
#  define  DEBUG 0
#  define  USE_CATH 1
#  define  USE_EASC 0
#  define  USE_GER 0
#  define  USE_HLS 1
#  define  USE_PAGER 1
#  define  USE_RC 1
#  define  USE_USHDY 0
#  define  EXIT_STAT_HLP 0
#  define  GREG_1582 0
#  define  GREG_1752 0
*/

/*
*
*  END: General program modification symbols,
*         which may be changed by the user !!
*
*/
#endif /* __GCAL_DEF_H */
