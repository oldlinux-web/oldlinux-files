/*
 * get.cs 
 * 
 * By Ross Ridge
 * Public Domain
 *
 * This file was generated automatically.
 *
 */

/* @(#) MySC make-cs.mm 1.2 93/11/09 18:43:41 */
/* @(#) MySC mf-inc.mm 1.4 93/11/09 23:15:38 */

#pragma implementation "fileiter.h"
#pragma implementation "getopt.h"
#pragma implementation "linebuf.h"
#pragma implementation "mystring.h"
#pragma implementation "pipe.h"
#pragma implementation "quit.h"
#pragma implementation "sccsdate.h"
#pragma implementation "sccsname.h"
#pragma implementation "seqstate.h"
#pragma implementation "sid.h"
#pragma implementation "sid_list.h"
#pragma implementation "sid_list.c"
#pragma implementation "filelock.h"
 
#include "get.c" 
#include "quit.c" 
#include "xalloc.c" 
#include "mystring.c" 
#include "sccsname.c" 
#include "sid.c" 
#include "sccsdate.c" 
#include "linebuf.c" 
#include "file.c" 
#include "split.c" 
#include "getopt.c" 
#include "fileiter.c" 
#include "sccsfile.c" 
#include "sf-get.c" 
#include "sf-get2.c" 
#include "sf-get3.c" 
#include "sf-chkid.c" 
#include "pfile.c" 
#include "pf-add.c"
