/*
 * sact.cs 
 * 
 * By Ross Ridge
 * Public Domain
 *
 * This file was generated automatically.
 *
 */

/* @(#) MySC make-cs.mm 1.2 93/11/09 18:43:41 */
/* @(#) MySC mf-inc.mm 1.4 93/11/09 23:15:38 */

#pragma implementation "fileiter.h"
#pragma implementation "getopt.h"
#pragma implementation "linebuf.h"
#pragma implementation "mystring.h"
#pragma implementation "pipe.h"
#pragma implementation "quit.h"
#pragma implementation "sccsdate.h"
#pragma implementation "sccsname.h"
#pragma implementation "seqstate.h"
#pragma implementation "sid.h"
#pragma implementation "sid_list.h"
#pragma implementation "sid_list.c"
#pragma implementation "filelock.h"
 
#include "sact.c" 
#include "quit.c" 
#include "xalloc.c" 
#include "mystring.c" 
#include "sccsname.c" 
#include "sid.c" 
#include "sccsdate.c" 
#include "linebuf.c" 
#include "file.c" 
#include "split.c" 
#include "getopt.c" 
#include "fileiter.c" 
#include "pfile.c"
