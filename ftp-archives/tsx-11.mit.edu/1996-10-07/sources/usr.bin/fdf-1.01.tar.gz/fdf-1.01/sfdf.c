/*
 * sfdf.c
 *
 * find duplicates.  searches a given path and its sub-directories for
 * duplicate files.  Duplicate files have the same name, size, date and
 * contents.  However, the definition used by this program can be any
 * user-specified combination of the above.
 *
 * Roy Bixler (original development and Atari ST version)
 * Ayman Barakat (idea)
 * David Oertel (MS-DOS version)
 *
 * Version 1.0: March 11, 1991
 * Version 1.01: April 12, 1992
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


#include <ctype.h>
#ifdef MSDOS
#include <dir.h>
#include <dos.h>
#endif
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "fdfcomm.h"
#include "fdfstat.h"
#include "elib.h"
#include "sfdf.h"



/*
 * print_help
 *
 * prints out the help message for the program
 */
void print_help()

{
    printf(SFDF_USAGE, PROG_NAME, PROG_NAME);
}



/*
 * show_doc
 *
 * show full documentation
 */
void show_doc()

{
    printf(SFDF_SCHPIEL1);
    printf(SFDF_SCHPIEL2);
}



/*
 * sort_eq_match
 *
 * returns non-zero if the sort criteria is also one of the match criteria.
 */
int sort_eq_match()

{
    return (((has_sort_crit(cmp_flist_name)) &&
	     (Match_criteria & NAMES_MATCH)) ||
	    ((has_sort_crit(cmp_flist_size)) &&
	     (Match_criteria & SIZES_MATCH)) ||
	    ((has_sort_crit(cmp_flist_time)) &&
	     (Match_criteria & TIMES_MATCH)));
}



/*
 * print_dups
 *
 * given a pointer to a name which has been determined to be duplicated, print
 * all the names and their path's out.  Return where a mismatch is found.
 */
void print_dups(FILE_LIST *start)

{
#ifdef FDF
    int n_found = 0;
    long n_bytes = 0L;
    FILE_LIST *cur;

    for (cur = start->next;
	 ((cur != NULL) && ((!sort_eq_match()) || (cmpflist_eq(start, cur))));
	 cur = cur->next)
#ifdef MSDOS
	if ((!cur->printed) && (!(cur->dta.ff_attrib & FA_DIREC)) &&
	    (files_match(start, cur))) {
#else /* unix */
	if ((!cur->printed) && (!S_ISDIR(cur->dta.st_buf.st_mode)) &&
	    (files_match(start, cur))) {
#endif
	    if (!n_found++) {
		n_found++;
		if (v_flag)
#ifdef MSDOS
		    n_bytes += start->dta.ff_fsize;
#else
		    n_bytes += start->dta.st_buf.st_size;
#endif
		print_match_header(start);
		print_next_match(start, -1);
	    }
	    if (v_flag)
#ifdef MSDOS
		n_bytes += cur->dta.ff_fsize;
#else
		n_bytes += cur->dta.st_buf.st_size;
#endif
	    print_next_match(cur, -1);
	}

    if (n_found) {
	if (v_flag) {
	    update_num_dups(n_found, n_bytes);
	    update_num_which_dupd();
	}
	printf("\n");
    }
#else
    int n_found = 0;
    long n_bytes = 0L;

#ifdef MSDOS
    if (v_flag)
	n_bytes += start->dta.ff_fsize;
#else
    if (v_flag)
	n_bytes += start->dta.st_buf.st_size;
#endif
    print_next_match(start, -1);

    if (v_flag) {
	update_num_dups(n_found, n_bytes);
	update_num_which_dupd();
    }
#endif
}



#ifdef FDF
/*
 * gen_id_menu
 *
 * given a starting point in the file list, generate an interactive delete
 * menu.  Return number of items put into the menu.
 */
int gen_id_menu(FILE_LIST *start, FILE_LIST **menu, int max_items)

{
    int n_found = 0;
    long n_bytes = 0L;
    FILE_LIST *cur;

    for (cur = start->next;
	 ((cur != NULL) && (cmpflist_eq(start, cur)) && (n_found < max_items));
	 cur = cur->next)
	if ((!cur->printed) && (files_match(start, cur))) {
	    if (n_found == 0) {
		if (v_flag)
#ifdef MSDOS
		    n_bytes += start->dta.ff_fsize;
#else
		    n_bytes += start->dta.st_buf.st_size;
#endif
		menu[n_found++] = start;
	    }
	    if (v_flag)
#ifdef MSDOS
		n_bytes += cur->dta.ff_fsize;
#else
		n_bytes += cur->dta.st_buf.st_size;
#endif
	    menu[n_found++] = cur;
	}

    if ((n_found) && (v_flag)) {
	update_num_which_dupd();
	update_num_dups(n_found, n_bytes);
    }
    
    return n_found;
}



/*
 * id_dups
 *
 * given a pointer to a name which has been determined to be duplicated, print
 * all the names and their path's out and ask the user which ones to delete.
 */
void id_dups(FILE_LIST *start)
     
{
    int n_found, i, n_del;
    FILE_LIST *cur, *menu[N_INTERACTIVE];
    char menu_sel[MAX_STR], which_del[N_INTERACTIVE];
    
    if (!(n_found = gen_id_menu(start, menu, N_INTERACTIVE)))
	return;
    while (1) {
	print_id_menu(menu, n_found);
	printf("\nEnter list of files to delete (hit CR for none)\n");
	fgets(menu_sel, MAX_STR-1, stdin);
	zap_trailing_nl(menu_sel, MAX_STR-1, stdin);
	if (!mark_list(menu_sel, which_del, n_found)) {
	    for (n_del=0, i=0; i < n_found; i++)
		if (which_del[i])
#ifdef MSDOS
		    if (!delete_path_name_file(menu[i]->path,
					       menu[i]->dta.ff_name, '\0')) {
#else
		    if (!delete_path_name_file(menu[i]->path,
					       menu[i]->dta.name, '\0')) {
#endif
			n_del++;
			if (v_flag) {
#ifdef MSDOS
			    update_total_del_bytes(menu[i]->dta.ff_fsize);
#else
			    update_total_del_bytes(menu[i]->dta.st_buf.st_size);
#endif
			    if (v_flag > 1) {
				printf("Deleted ");
#ifdef MSDOS
				print_fpath(menu[i]->path,
					    menu[i]->dta.ff_name);
#else
				print_fpath(menu[i]->path,
					    menu[i]->dta.name);
#endif
				printf("\n");
			    }
			}
		    }
	    break;
	}
    }
    
    if (n_del)
	printf("\n");
}
#endif


/*
 * find_non_printed
 *
 * given a pointer to a FILE_LIST, return the pointer to the next element which
 * has not been printed yet.
 */
FILE_LIST *find_non_printed(FILE_LIST *file)
     
{
    for (; ((file != NULL) && (file->printed)); file = file->next);
    return file;
}



/*
 * find_dups
 *
 * given a path, find the duplicate files and dump them to the standard output.
 */
void find_dups(FILE_LIST *f_list)
     
{
    FILE_LIST *f_found;
    
#ifdef FDF
    for (f_found = f_list; (f_found != NULL);
	 f_found = find_non_printed(f_found->next))
	if (i_flag)
	    id_dups(f_found);
	else
	    print_dups(f_found);
#else
    for (f_found = f_list; (f_found != NULL); f_found=f_found->next)
	print_dups(f_found);
#endif
}



/*
 * count_total_stats
 *
 * go back over the linked list and count the number of files and the total
 * bytes in the files
 */
void count_total_stats(FILE_LIST *f_list)
     
{
    FILE_LIST *cur;
    
    for (cur = f_list; cur != NULL; cur = cur->next) {
	update_num_files();
#ifdef MSDOS
	update_total_bytes(cur->dta.ff_fsize);
#else
	update_total_bytes(cur->dta.st_buf.st_size);
#endif
    }
}



/*
 * get_options
 *
 * get the command-line options, check for consistency and set the appropriate
 * variables.
 */
int get_options(int argc, char **argv)

{
    extern int Optind;
    extern char *optarg;
    int optchar;
    char a_flag = 0, c_flag = 0, d_flag = 0, n_flag = 0, s_flag = 0;

    if (argc < 2) {
	print_help();
	exit(-1);
    }

    while ((optchar = getopt(argc, argv, GETOPT_LIST)) != EOF) {
	if (isupper(optchar))
	    optchar = tolower(optchar);
	switch (optchar) {
	  case 'i':
	    i_flag = 1;
	    break;
	  case 'l':
	    l_flag = 1;
	    break;
	  case 'm':
	    if ((optarg == NULL) || (strpbrk(optarg, "AaCcDdNnSs") != optarg)) {
		printf("%s: must specify 'a' or 'c', 'd', 'n' and/or 's' after -m\n",
		       PROG_NAME);
		print_help();
		exit(-1);
	    }
	    for (;*optarg != '\0'; optarg++) {
		if (isupper(*optarg))
		    *optarg = tolower(*optarg);
		switch (*optarg) {
		  case 'a':
		    a_flag = 1;
		    break;
		  case 'c':
		    c_flag = 1;
		    Match_criteria |= CONTENTS_MATCH;
		    break;
		  case 'd':
		    d_flag = 1;
		    Match_criteria |= TIMES_MATCH;
		    break;
		  case 'n':
		    n_flag = 1;
		    Match_criteria |= NAMES_MATCH;
		    break;
		  case 's':
		    s_flag = 1;
		    Match_criteria |= SIZES_MATCH;
		    break;
		  default:
		    printf("%s: invalid match criteria '%c' specified\n",
			   PROG_NAME, *optarg);
		    print_help();
		    exit(-1);
		}
	    }
	    break;
	  case 'o':
	    if ((optarg == NULL) || (strpbrk(optarg, "AaDd") != optarg)) {
		printf("%s: must specify 'a' or 'd' after -o\n", PROG_NAME);
		print_help();
		exit(-1);
	    }
	    if (isupper(*optarg))
		*optarg = tolower(*optarg);
	    if (*optarg == 'a')
		ins_sort_order(ASCENDING);
	    else if (*optarg == 'd')
		ins_sort_order(DESCENDING);
	    break;
	  case 's':
	    if ((optarg == NULL) || (strpbrk(optarg, "DdNnSsTt") != optarg)) {
		printf("%s: must specify 'd', 'n', 's' or 't' after -s\n",
		       PROG_NAME);
		print_help();
		exit(-1);
	    }
	    if (isupper(*optarg))
		*optarg = tolower(*optarg);
	    switch (*optarg) {
	      case 'd':
		ins_sort_criteria(cmp_flist_date);
		break;
	      case 'n':
		ins_sort_criteria(cmp_flist_name);
		break;
	      case 's':
		ins_sort_criteria(cmp_flist_size);
		break;
	      case 't':
		ins_sort_criteria(cmp_flist_time);
		break;
	    }
	    break;
	  case 'v':
	    v_flag++;
	    break;
	  case '?':
	    show_doc();
	    exit(0);
	  default:
	    print_help();
	    exit(-1);
	}
    }

    if (argc == Optind) {
	printf("%s: at least one path specification required\n", PROG_NAME);
	print_help();
	exit(-1);
    }
    else if (a_flag)
	if ((c_flag) || (d_flag) || (n_flag) || (s_flag)) {
	    printf("%s: -ma option conflicts with -mc, -md, -mn or -ms\n",
		   PROG_NAME);
	    print_help();
	    exit(-1);
	}
	else
	    Match_criteria = ALL_MATCH;
    else if (!Match_criteria)
	Match_criteria = (TIMES_MATCH|SIZES_MATCH|NAMES_MATCH);
    else if (Match_criteria & CONTENTS_MATCH)
	Match_criteria |= SIZES_MATCH;
    if (Sort_criteria[0] == NULL) {
	ins_sort_criteria(cmp_flist_name);
	ins_sort_order(ASCENDING);
    }

    return Optind;
}



int main(int argc, char **argv)

{
    int i;
    char form_path[MAXPATH];
    FILE_LIST *dir_list = NULL;
  
    for (i = get_options(argc, argv); i < argc; i++) {
	format_dir(argv[i], '\0', form_path);
	if (v_flag > 1)
	    printf("finding duplicates under %s:\n\n", form_path);
	list_files(&dir_list, PROG_NAME, form_path, (char) 1, (char) 1);

    }

    find_dups(dir_list);
    if (v_flag) {
	count_total_stats(dir_list);
	print_stats();
    }

    return(0);
}
