/*
 * cmp.h
 *
 * prototypes for cmp.c, file comparison and auxiliary memory allocation
 * functions.
 *
 * Roy Bixler
 * March 16, 1991
 */



/* cmp.c */
unsigned int alloc_file_buffers(char **buf1, char **buf2, long file_size);
int do_compare_files(int file1, int file2, struct stat *stat1,
		     struct stat *stat2);
#ifdef unix
int is_linked(char *file1, struct stat *stat1,
	      char *file2, struct stat *stat2);
#endif
int compare_files(char *file1, char *file2);
