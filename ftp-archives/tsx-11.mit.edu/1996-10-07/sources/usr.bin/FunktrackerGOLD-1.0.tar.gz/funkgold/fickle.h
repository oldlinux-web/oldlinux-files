/**************************************************************************
*
* FunktrackerGOLD - By Jason Nunn
*
* due to my past experiences, this h file is for fickle muso's with their
* fickle keyboard arrangments, and other minor things that they will
* ask to be changed (to annoy me).
*
* ..Fiddle, play, design, rearrange.. experiment as necessary.
*
**************************************************************************/
/*global keys*/
#define FC_SCREEN_ESCAPE 'Q'
#define FC_ARROW_UP      KEY_UP
#define FC_ARROW_DN      KEY_DOWN
#define FC_ARROW_LEFT    KEY_LEFT
#define FC_ARROW_RIGHT   KEY_RIGHT
#define FC_ENTER         10
#define FC_SPACE         ' '
#define FC_INS_ENTRY     'I'
#define FC_DEL_ENTRY     'D'

#define FC_TRAC_PAT      'P'
#define FC_TRAC_DGB      'O'
#define FC_TRAC_PTY      'L'

/*editor only keys (not used in playback)*/
#define FC_NOTE_C        'z'
#define FC_NOTE_CS       's'
#define FC_NOTE_D        'x'
#define FC_NOTE_DS       'd'
#define FC_NOTE_E        'c'
#define FC_NOTE_F        'v'
#define FC_NOTE_FS       'g'
#define FC_NOTE_G        'b'
#define FC_NOTE_GS       'h'
#define FC_NOTE_A        'n'
#define FC_NOTE_AS       'j'
#define FC_NOTE_B        'm'

#define FC_GOTO_SAM_EDIT '!'
#define FC_GOTO_SEQ_EDIT '@'
#define FC_GOTO_PAT_EDIT '#'

#define FC_SAVE_SONG     'S'
#define FC_SAVE_MOD      'A'

#define FC_DEC_OCT       ';'
#define FC_INC_OCT       '\''

/*sample editor specific*/
#define FC_SM_ED_ATTR    FC_ENTER
#define FC_SM_LOAD_SAM   FC_SPACE

/*sequence editor specific*/
#define FC_SE_EDIT_ENTRY '['
#define FC_SE_SET_LOOP   FC_ENTER
#define FC_SE_SET_BPM    'T'

/*pattern editor specific*/
#define FC_PE_DEC_PAT_NO '-'
#define FC_PE_INC_PAT_NO '='
#define FC_PE_DEC_SAM_NO ','
#define FC_PE_INC_SAM_NO '.'
#define FC_PE_CLR_SLOT   FC_SPACE
#define FC_PE_SET_BLK    FC_ENTER
#define FC_PE_ED_SAM_NO  '['
#define FC_PE_ED_CMD     ']'
#define FC_PE_ADD_RLO    '`'
#define FC_PE_MBEGIN     'B'
#define FC_PE_MEND       'E'
#define FC_PE_MDELETE    'Z'
#define FC_PE_MCOPY      'C'
#define FC_PE_MPASTE     'V'
#define FC_PE_CHANTOGG   'T'
#define FC_PE_CMD_ASSIST 'M'

/*trac playback specific*/
/*somebody is bound to ask for this to be changed*/
#define FC_TRAC_VOLBAR   '='

/*funkgold_dir specific*/
#define FC_DIR_RENAME    'R'
