/**************************************************************************
*
* FunktrackerGOLD - By Jason Nunn
*
* Snail: 32 Rothdale Road, Moil, Darwin, NT, 0810, Australia
* Email: jsno@darwin.topend.com.au
*
**************************************************************************/
#define FERR_OK         0
#define FERR_MALLOC     1
#define FERR_FOPEN      2
#define FERR_FREAD      3
#define FERR_FUNK_SIG   4
#define FERR_FCORRUPT   5
#define FERR_PAT_LIM    6
#define FERR_OLD_FK     7
#define FERR_FCREATE    8
#define FERR_FWRITE     9
#define FERR_ESEQTABLE  10
#define FERR_SAMUNKNOWN 11
#define FERR_MODCOMPLEX 12
#define FERR_SNGUNKNOWN 13
#define FERR_PREC_NN    14
