/***************************************************************************
*
* FunktrackerGOLD - By Jason Nunn
*
* Using Curses (ANSI C) NON-preemptive Processing
*
* Snail: 32 Rothdale Road, Moil, Darwin, NT, 0810, Australia
*
***************************************************************************/
#include "fickle.h"

#define EM_SAMPLE   0
#define EM_SEQUENCE 1
#define EM_PATTERN  2
#define EM_MAIN     3
#define EM_QUIT     4
