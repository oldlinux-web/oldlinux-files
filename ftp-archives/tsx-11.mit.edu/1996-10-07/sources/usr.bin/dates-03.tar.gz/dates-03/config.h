/*---------------------------------------------------------------------------
  Name:		config.h
  Version:	0.3
  Internal:	7
  Date:		29-jul-96
  Author:	Marco Rivellino

  Description:	this file contains the program global constants and
		definitions

---------------------------------------------------------------------------*/
/*
    Copyright (C) 1996  Marco Rivellino & Fabio Menegoni

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef DA_CONFIG_H
#define DA_CONFIG_H


/* program defaults */
#define DEFAULT_LOOK_DISTANCE	7
#define MAX_LOOK_DISTANCE	365
#define DEFAULT_PAGE_LENGTH	16
#define MAXROW			128


/* program major & minor version numbers */
#define DA_MAJVERSION	"0"
#define DA_MINVERSION	"3"


#define TRUE	1
#define FALSE	0


/* file I/O buffer size */
#define CBUFSIZE	256


/* edit modes */
#define EDIT_NONE	0
#define EDIT_ALL	1
#define EDIT_DATE	2
#define EDIT_RECU	4
#define EDIT_INVALID	8


#ifdef __TURBOC__
#define STRCASECMP	stricmp
#define STRNCASECMP	strnicmp
#else
#define STRCASECMP	strcasecmp
#define STRNCASECMP	strncasecmp
#endif


/* set debug mode
#define __DEBUG
*/


#endif
