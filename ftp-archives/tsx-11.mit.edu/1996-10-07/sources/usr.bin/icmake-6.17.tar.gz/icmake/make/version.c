/*
                                V E R S I O N . C
*/

char
    version[] = "6.10",
    release[] = "1992-1994";
