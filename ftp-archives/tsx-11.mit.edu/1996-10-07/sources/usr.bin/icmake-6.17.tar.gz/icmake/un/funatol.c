#include "icmun.h"

void fun_atol ()
{
    puts ("        atol");
}
