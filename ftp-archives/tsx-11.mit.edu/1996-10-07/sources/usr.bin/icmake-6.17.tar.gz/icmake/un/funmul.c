#include "icmun.h"

void fun_mul ()
{
    puts ("        mul");
}
