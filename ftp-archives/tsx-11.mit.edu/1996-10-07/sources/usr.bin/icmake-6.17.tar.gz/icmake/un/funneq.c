#include "icmun.h"

void fun_neq ()
{
    puts ("        neq");
}
