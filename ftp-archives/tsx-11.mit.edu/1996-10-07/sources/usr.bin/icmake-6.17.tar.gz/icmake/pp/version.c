/*
                                V E R S I O N . C
*/
char
    version[] = "6.11",
    release[] = "1992-1994";
