/* cal.h by R.W.W. Hooft (hooft@chem.ruu.nl) */

extern volatile void usage(void);
extern void center(const char *, int, int);
extern void trim_trailing_spaces(char *);
extern void ascii_day(char *, int);
extern int day_in_week(int, int, int);
extern int day_in_year(int, int, int);
extern void day_array(int, int, int *);
extern void yearly(int);
extern void j_yearly(int);
extern void monthly(int, int);
