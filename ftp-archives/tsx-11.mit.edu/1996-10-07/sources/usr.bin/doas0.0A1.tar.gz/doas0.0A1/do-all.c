/* this file is part of doas */
/* do - utility program to do a command by searching the path */

/* uasge:
do command parms ...
setenv [var=val] command 
setuid -s command                
setuid -r user command           
setuid -e user command           
setuid -a ruid euid command
setuid -R command                      - set real=eff
setuid -E command                      - set eff=real
*/

#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <pwd.h>
#include <limits.h>

void doCommand (char * command, char ** argv)
{
    struct stat buf;
    if (!stat (command, &buf))
	{
	    execv (command, argv);  /* exec the command*/
	    fprintf (stderr, "exec %s: parmission denied\n", command);
	    exit (1);
	}
}

#ifdef SETUID
int uidFromString (char * login)
{
    struct passwd * info = getpwnam (login);
    if (!info)
	{
	    fprintf (stderr, "Who the heck is: %s\n",login);
	    exit (1);
	}
    return info->pw_uid;
}

#endif /* SETUID */

void main (int argc, char ** argv, char ** env)
{
    char * path;
    char * nextpath;
    char * cmd=argv[1];
#ifndef SETUID
    int index=1;
#else /* SETUID */
    int index=2;
    int ruid;
    int euid;
#endif /* SETUID */

    path = strdup (getenv ("PATH"));
    
#ifdef SETENV
        while (argv[index] && strchr(argv[index], '='))
	{
	    putenv (argv[index]);
	    index++;
	}
    cmd = argv[index];
    if (index >= argc)
	{
	    fprintf (stderr, "usage: setenv var=value ... command\n");
	    exit (1);
	}
#elif !defined (SETUID)
    if (argc < 2)
	{
	    fprintf (stderr, "usage: do command\n");
	    exit (1);
	}
#else /* SETUID */
    if (*argv[1] != '-')
	{
	    fprintf (stderr, "usage: uid command\n");
	    exit (1);
	}
#endif /* SETUID */

#ifdef SETUID
    switch (argv[1][1])
	{
	  case 's':
	    ruid = geteuid();
	    euid = getuid();
	    break;
	  case 'r':
	    ruid = uidFromString (argv[2]);
	    euid = geteuid();
	    index++;
	    break;
	  case 'e':
	    euid = uidFromString (argv[2]);
	    ruid = getuid();
	    index++;
	    break;
	  case 'a':
	    ruid = uidFromString (argv[2]);
	    euid = uidFromString (argv[3]);
	    index +=2;
	    break;
	  case 'R':
	    ruid = geteuid ();
	    euid = geteuid ();
	    break;
	  case 'E':
	    ruid = getuid ();
	    euid = getuid ();
	    break;
	}

    if (-1 == setreuid (ruid, euid))
	{
	    fprintf (stderr, "cannot switch uid\n");
	    exit (1);
	}
    
    cmd = argv[index];

#endif /* SETUID */

    if (strchr (cmd, '/'))
	{
#ifndef RDO
	    doCommand (cmd, argv+index);
#else /* RDO */
	    fprintf (stderr, "no slashes allowd in restricted do\n");
	    exit (1);
#endif
	}
    else
	{
	    nextpath = strtok (path, ":");   /* parse the path */
	    while (nextpath)
		{
		    if (strlen(nextpath) + strlen(cmd) + 1 >= PATH_MAX)
			fprintf (stderr, "warning: PATH element %s too long, not searched\n", nextpath);
		    else if ( *nextpath != '/')
			fprintf (stderr, "warning: PATH element %s does not start with /, not searched\n", nextpath);
		    else
			{
			    struct stat buf;
			    char command [PATH_MAX];
			    strcpy (command, nextpath);
			    strcat (command, "/");
			    strcat (command, cmd);
	 		    doCommand (command, argv+index);
			}
		    nextpath = strtok (NULL, ":");
		}
	}
    fprintf (stderr, "%s: command not found\n", cmd);
    exit (1);
}    
    
