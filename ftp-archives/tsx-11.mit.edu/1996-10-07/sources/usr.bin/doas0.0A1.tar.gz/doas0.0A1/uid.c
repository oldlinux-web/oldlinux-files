/* uid - display user ID's.  
* uasge -
*   uid                     - get read and eff uid
*   uid -r                  - get real uid
*   uid -e                  -get effective user id
*/

#include <stdio.h>
#include <unistd.h>
#include <pwd.h>

void usage ()
{
    fprintf (stderr, "uasge: uid [-re]\n");
}

void printuid (int uid)
{
    struct passwd * info = getpwuid (uid);
    printf ("%s", info->pw_name);
}

void queryReal ()
/* get the real UID, and print it on stdout */
{
    printuid (getuid());
}

void queryEff ()
{
    printuid (geteuid());
}

int uidFromString (char * login)
{
    struct passwd * info = getpwnam (login);
    if (!info)
	{
	    fprintf (stderr, "Who the heck is: %s\n",login);
	    exit (1);
	}
    return info->pw_uid;
}

void main (int argc, char ** argv)
{
    if (argc == 1)
	{
	    queryReal ();
	    printf ("\t");
	    queryEff ();
	    printf ("\n");
	}

    else if (argc == 2)
	{
	    if (*argv[1] != '-')
		usage();
	    switch (argv[1][1])
		{
		  case 'r':
		    queryReal();
		    printf ("\n");
		    break;
		  case 'e':
		    queryEff ();
		    printf ("\n");
		    break;
		  default:
		    usage ();
		}
	}

    exit (0);
}
