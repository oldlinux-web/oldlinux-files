/* doas -- allow one user to be authorized to do an action as another user */

#include <pwd.h>
#include <grp.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/param.h>

/* globals for command line flags */
int RFLAG;
int QFLAG;
char * USER;
char * COMMAND;

void fail (char * msg)
{
    fprintf (stderr, "doas: error: %s\n", msg);
    exit(3);
}

int getGroups (char ** groupList)
/* fill the groupslist vector with names of groups the user is in*/
{
    gid_t gids[NGROUPS];
    int numgroups = getgroups (NGROUPS, gids);
    int i;

    for (i=0; i<numgroups; i++)
	{
	    struct group * gr = getgrgid  (gids[i]);
	    strcpy (groupList[i] ,gr->gr_name);
	}
    groupList[i] = NULL;
}

void safestrcpy (char * s1, char * s2, char * msg)
/* perform strcpy, but bail out on error with msg*/
{
    if (!s1 || !s2)
	fail (msg);
    strcpy (s1,s2);
}

int readDoasEntry (FILE * rcfile, char * cmdName, char * userList, char * commandLine)
/* this function will read a line from the .doas file, and parse the line. The parameters
* must be allocated, and will be filled by this routine.  They are all guarenteed to be
* Less than 1024 bytes all together
*/
{
    char inputLine [1024];  /* allow a really long line */
    char * tmpstr;
    do
	if (!fgets (inputLine, 1024, rcfile))
	    return 0;
    while (*inputLine != '#' && !strchr (inputLine, ':'));

    tmpstr = strtok (inputLine, ":");
    safestrcpy (cmdName, tmpstr, "parsing user's .doas file");
    tmpstr = strtok (NULL, ":");
    safestrcpy (userList, tmpstr, "parsing user's .doas file");
    tmpstr = strtok (NULL, "\n");
    safestrcpy (commandLine, tmpstr, "parsing user's .doas file");
    return 1;
}

int isIn (char * entry, char * uid, char ** groups)
/* this will tell us if the user is in the group
* entry: the user entry (includes prefix of $% or !)
* uid, the user's login
* groups, the null teminated list of groups
*/
{
    int group=1;  /* boolean flags to tell to check user or group*/
    int user=1;   /* ditto */

    switch (*entry)
	{
	  case '$': /* require it be a user */
	    entry++;
	    group=0;
	    break;
	  case '%': /* require it be a group */
	    entry++;
	    user=0;
	    break;
	  case '*':  /* true for all */
	    return 1;
	}

    if (user)
	if (!strcmp (entry, uid))
	    return 1;

    if (group)
	{
	    int i;
	    for (i=0; groups[i]; i++)
		if (!strcmp (entry, groups[i]))
		    return 1;
	}
    return 0;
}


int canExec (char * userList, char * myuid, char ** mygroups)
/* this function will tell us if the caller can execute a given command line.
* userList: the ACL given int the .doas file.
* myuid: the string representing the user's ID
* mygroups: the groups a user is part of (again, textual form)
*/
{
    int isAllowed = 0;   /* is the user allowed*/
    char * currentUid;

    currentUid = strtok (userList, " ");
    while (currentUid)
	{
	    switch (*currentUid)
		{
		  case '!': /* negate the current user */
		    if (isIn (currentUid+1, myuid, mygroups))
			return 0;
		  default:
		    if (!isAllowed)
			isAllowed = isIn (currentUid, myuid, mygroups);
		}
		    
	    currentUid = strtok (NULL, " ");
	}
    return isAllowed;
}

void query (char * myuid, char ** mygroups, FILE * rc)
/* query the commands you can execute as a user.  The rc file should be rewound before the call is made.*/
{
    char commandLine [1024];
    char command [1024];
    char userList [1024];

    while (readDoasEntry (rc, command, userList, commandLine))
	if (canExec (userList, myuid, mygroups))
	    printf ("%s\t%s\n", command, commandLine);
}

void execute (char * myuid, int uid, char ** mygroups, FILE * rc, char ** argv)
/* this is the function which will do the execution of the command */
{
    char key [1024];
    char acl [1024];
    char command [1024];
    while (readDoasEntry (rc, key, acl, command))
	{
	    if (!strcmp(COMMAND, key) && canExec (acl, myuid, mygroups))
		{
		    char * cmdArgv[1024];
		    int i;
		    
		    /* assemble a command line */
		    cmdArgv[0] = strtok (command, " ");
		    for (i=1   ; cmdArgv[i] = strtok (NULL, " "); i++);
		    for (argv++; cmdArgv[i] = *argv             ; argv++, i++);
		    cmdArgv[i] = NULL;
		    
		    /* we are now about ready to exec, but need to switch user*/
		    if (RFLAG)
			{
#ifdef DEBUG
			    printf ("setting real+eff UID to: %d\n", uid);
#else
			    if (-1 == setreuid (uid, uid))  /* becme the user completely */
				fail ("could change uid");
#endif
			}
			else
			    {
#ifdef DEBUG
				printf ("setting ONLY real UID to %d\n", uid);
#else
				if (-1 == setreuid (getuid(), uid))   /* set only the effective uid*/
				    fail ("couldn't change uid");
#endif
			    }
#ifndef DEBUG
		    execv (cmdArgv[0], cmdArgv);
		    fail ("after exec");
#else
		    printf ("Execing:Argv = ");
		    {
			int i;
			for (i=0; cmdArgv[i]; i++)
			    printf ("%d:\"%s\" \n", i, cmdArgv[i]);
			exit (0);
		    }
#endif
		    
		    return;
		}
	}
    fail ("permission denied");
}

void main (int argc, char ** argv)
{
    int i;
    FILE * rcfile;
    struct passwd * mypw;
    struct passwd * usrpw;
    char * myuid;
    char rcfilename[1024];
    char grouplist [8][NGROUPS];
    char *(mygroups[NGROUPS]);
    struct stat statb;
    
    /* initialize the mygroups array*/
    for (i=0; i<NGROUPS; i++)
	mygroups[i] = grouplist[i];
    
    /* here we parse the command line as doas [-r] [-q] user command */
    for (i=1; argv[i] && *(argv[i]) == '-'; i++)
	{
	    switch ( *(argv[i]+1) )
		{
		  case 'r':
		    RFLAG = 1;
		    break;
		  case 'q':
		    QFLAG = 1;
		    break;
		  default:
		    fail ("invalid flag");
		}
	}
    /* now, we have the parsed flags, and will read the username, and the command*/
    if (!(USER = argv[i]))
	fail ("usage: doas [-q] [-r] user command");

    usrpw = getpwnam (USER);
    mypw = getpwuid (getuid());
    if (!usrpw)
	fail ("no such user");
    if (!mypw)
	fail ("cannot find your uid");
    myuid = mypw->pw_name;

    strcpy (rcfilename, usrpw->pw_dir);
    strcat (rcfilename, "/.doas_");
    strcat (rcfilename, USER);
    rcfile = fopen (rcfilename, "r");
    if (!rcfile)
	{
	    strcpy (rcfilename, usrpw->pw_dir);
	    strcat (rcfilename, "/.doas");
	    rcfile = fopen (rcfilename, "r");
	    if (!rcfile)
		fail ("cannot open user's .doas file");
	}

    if (-1 == stat (rcfilename, &statb))
	{
	    fprintf (stderr, "aaarrrrggggg,  cannot stat a file i've already opened!\n");
	    exit (1);
	}

    if (statb.st_uid != usrpw->pw_uid && usrpw->pw_uid ) /* file must be owned by root or owner*/
	{
	    fprintf (stderr, ".doas file must be owned by by user or root.  It is not.\n");
	    exit (1);
	}

    if (statb.st_mode & 022)  /* the file must not be writable*/
	{
	    fprintf (stderr, ".doas file can be written by goup or others,  I refuse to honor that!\n");
	    exit (1);
	}
    
    getGroups (mygroups);
    
    if (QFLAG)
	{
	    query(myuid, mygroups, rcfile);
	    exit (0);
	}
    if (!(COMMAND = argv[i+1]))
	fail ("usage: doas [-q] [-r] user command");
    execute(myuid, usrpw->pw_uid, mygroups, rcfile, argv+i+1);
    exit(0);
}
