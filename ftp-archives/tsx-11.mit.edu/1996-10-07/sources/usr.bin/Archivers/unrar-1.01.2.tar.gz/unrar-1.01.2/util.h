
/* this file was added by 
 * Markus F.X.J. Oberhumer <markus.oberhumer@jk.uni-linz.ac.at>
 */

/***********************************************************************
// a generic SETFILETIME definition using utime().
// Assumes DosTime is local timezone.
************************************************************************/

#if defined(__GO32__)
#include <sys/types.h>
#include <sys/stat.h>
#if !defined(SETFILETIME)
#define SETFILETIME(FPtr,DosTimePtr)  setftime(fileno(FPtr),DosTimePtr)
#endif
#endif


#if defined(UNIX) || !defined(SETFILETIME)

#include <sys/types.h>
#include <sys/stat.h>

#include <time.h>
#if defined(__WATCOMC__)
#include <sys/utime.h>
#else
#include <utime.h>
#endif

#define SETFILETIME_UTIME(name,time)   unrar_utime(name,time)

int unrar_utime( /* const */ char *FileName, unsigned long *DosTimePtr)
{
	struct utimbuf u;
	struct tm t;
	time_t gm_time;
	unsigned long FileTime = *DosTimePtr;

	t.tm_year  = ((FileTime >> 25) & 0x7f) + 80;
	t.tm_mon   = ((FileTime >> 21) & 0x0f) - 1;
	t.tm_mday  =  (FileTime >> 16) & 0x1f; 
	t.tm_hour  =  (FileTime >> 11) & 0x1f;
	t.tm_min   =  (FileTime >>  5) & 0x3f;
	t.tm_sec   =  (FileTime & 0x1f) * 2;
	t.tm_isdst = 0;

	gm_time = mktime(&t);               /* from local time to UTC */
	gm_time += timezone;                /* back to local time */
	u.actime = u.modtime = gm_time;
	/* fprintf(stderr,"%10d + %6d = %10d\n",gm_time,timezone,u.actime); */
	return utime(FileName,&u);
}

#endif


/* define this after all includes */
#if defined(__EMX__) || defined(__GO32__)
#define mkdir(Name)     mkdir(Name,0777)
#endif


/***********************************************************************
//
************************************************************************/

int tflush();
int tseek();
long ttell();

int tflush(FPtr)
FILE *FPtr;
{
  int r;
  if ((r = fflush(FPtr)) != 0)
    ErrExit(EWRITE,WRITE_ERROR);               /* should add EFLUSH */
  return r;
}

int tseek(FPtr,offset,whence)
FILE *FPtr;
long offset;
int whence;
{
  int r;
  if ((r = fseek(FPtr,offset,whence)) != 0)
    ErrExit(ESEEK,FATAL_ERROR);
  return r;
}

long ttell(FPtr)
FILE *FPtr;
{
  long r;
  if ((r = ftell(FPtr)) == -1)
    ErrExit(EREAD,FATAL_ERROR);                /* should add ETELL */
  return r;
}

#undef fflush
#define fflush tflush
#undef fseek
#define fseek tseek
#undef ftell
#define ftell ttell


