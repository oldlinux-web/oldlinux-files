/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: DBIndex.c
 *            DESCRIPTION: index file routines
 *      DEFINED CONSTANTS: defined in db.h
 *       TYPE DEFINITIONS: defined in db.h
 *      MACRO DEFINITIONS: defined in db.h
 *       GLOBAL VARIABLES: defined in db.h
 *       PUBLIC FUNCTIONS: DBGetIndexRecord, DBPutIndexRecord
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/DB, no underscores, mixed case		DBPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/DB, underscores, mixed case			DB_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		prefixed w/DB, underscores and all caps		DB_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBINDEX_C
#define DBINDEX_C

/* === System Headers === */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

/* === Project Headers === */
#include "db.h"
#include "debug.h"


/*========================================================================
 *	Name:			DBGetIndexRecord
 *	Prototype:	DBGetIndexRecord( HASH_REC *hash, INDEX_REC *index )
 *
 *	Description:
 *		retrieve the index record pointed to by the hash record pointer from 
 *		the index file and fill in the index record.  Assumes a valid pointer
 *		into the index file.
 *
 *	Input Arguments:
 *		HASH_REC		hash		pointer to hash record which contains offset
 *									into index file for the requested index record
 *
 *	Output Arguments:
 *		INDEX_REC	index		place to put record read from index file
 *
 *	Return Values:
 *		DB_SUCCESS				index record read and saved
 *		OPENINDEXFAIL			failed to open the index file
 *		INDEXLSEEKFAIL			failed to seek to location specified in hash
 *									record
 *		INDEXREADFAIL			failed to read the record from index file
 *		
 *	Global Variables:
 *		None.
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		The string is converted in place.
 *		
 *========================================================================*/
int
DBGetIndexRecord(
	HASH_REC		*hash,		/* pointer to hash record */
	INDEX_REC	*index		/* pointer to index record */
)
{

#ifdef DEBUG
	char		fname[]="DBGetIndexRecord()";
#endif

	int		indexfd;			/* file descriptor for index file */
	int		bytes_read;		/* number of bytes read from file */

	DBGEnter();

	/*
	 * open the index file
	 */
	if ( ( indexfd = open ( 
				DB_Index_Filename, O_RDONLY | O_CREAT, 0644 ) ) == -1 )
	{
		DBGPrint ( DBG_INFO, "Error opening index file\n" );
		DBGExit();
		return ( OPENINDEXFAIL );
	}
	DBGPrintf ( DBG_INFO, ("Hash pointer: 0x%08x\n", hash->ptr) );

	/*
	 * set the file pointer to the place pointed to by the hash record
	 */
	if ( lseek ( indexfd, hash->ptr, SEEK_SET ) == -1 )
	{
		DBGPrint ( DBG_INFO, "Error setting file pointer in index file\n");
		close ( indexfd );
		DBGExit();
		return ( INDEXLSEEKFAIL );
	}

	/*
	 * read in the index record
	 */
	bytes_read = read ( indexfd, index, sizeof ( INDEX_REC ) );
	close ( indexfd );

	/*
	 * return either DB_SUCCESS for all ok or an error code
	 */
	if ( bytes_read == sizeof ( INDEX_REC ) ) 
	{
		DBGPrintf(DBG_INFO,
			("Index record read:\n"
			 "\tindex->active: %d\n"
			 "\tindex->prev  : %d\n"
			 "\tindex->next  : %d\n"
			 "\tindex->ptr   : %d\n"
			 "\tindex->length: %d\n",
			index->active, index->prev, index->next, 
			index->ptr, index->length) );

		DBGExit();
		return ( DB_SUCCESS );
	}
	else
	{
		DBGExit();
		return ( INDEXREADFAIL );
	}
}



/*========================================================================
 *	Name:			DBPutIndexRecord
 *	Prototype:	DBPutIndexRecord( HASH_REC *hash, INDEX_REC *index )
 *
 *	Description:
 *		write an Index record to the index file
 *
 *	Input Arguments:
 *		HASH_REC		hash		pointer to hash record which contains offset
 *									into index file for the requested index record
 *
 *	Output Arguments:
 *		INDEX_REC	index		place to put record read from index file
 *
 *	Return Values:
 *		DB_SUCCESS				index record read and saved
 *		OPENINDEXFAIL			failed to open the index file
 *		INDEXLSEEKFAIL			failed to seek to location specified in hash
 *									record
 *		INDEXREADFAIL			failed to read the record from index file
 *		
 *	Global Variables:
 *		None.
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		The string is converted in place.
 *		
 *========================================================================*/
int
DBPutIndexRecord(
	HASH_REC		*hash,		/* points to index to update */
	INDEX_REC	*index		/* pointer to index record */
)
{

#ifdef DEBUG
	char		fname[]="DBPutIndexRecord()";
#endif

	int		indexfd;				/* file descriptor for index file */
	int		bytes_written;		/* number of bytes read from file */

	DBGEnter();

	/*
	 * open the index file
	 */
	if ( ( indexfd = open ( 
		DB_Index_Filename, O_WRONLY | O_CREAT, 0644 ) ) == -1 )
	{
		DBGPrint ( DBG_INFO, "Error opening index file\n");
		DBGExit();
		return ( OPENINDEXFAIL );
	}
	DBGPrintf ( DBG_INFO, ("Hash pointer: %d\n", hash->ptr) );

	/*
	 * set the file pointer to the place pointed to by the hash record
	 */
	if ( lseek ( indexfd, hash->ptr, SEEK_SET ) == -1 )
	{
		DBGPrint ( DBG_INFO, "Error setting file pointer in index file\n");
		close ( indexfd );
		DBGExit();
		return ( INDEXLSEEKFAIL );
	}

	DBGPrintf ( DBG_INFO, 
		("New index record:\n"
			"\tactive: %d\n" 
			"\tnext  : %d\n" 
			"\tprev  : %d\n" 
			"\tptr   : %d\n"
			"\tlength: %d\n",
		index->active, index->next, index->prev, index->ptr, index->length) );

	/*
	 * write the index record
	 */
	bytes_written = write ( indexfd, index, sizeof ( INDEX_REC ) );
	close ( indexfd );

	/*
	 * return either DB_SUCCESS for all ok or an error code
	 */
	if ( bytes_written == sizeof ( INDEX_REC ) ) 
	{
		DBGExit();
		return ( DB_SUCCESS );
	}
	else 
	{
		DBGExit();
		return ( INDEXWRITEFAIL );
	}
}

#endif /* DBINDEX_C */
