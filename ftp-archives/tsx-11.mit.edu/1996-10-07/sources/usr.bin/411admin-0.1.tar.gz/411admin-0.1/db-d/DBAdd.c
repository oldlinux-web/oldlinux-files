/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: DBAdd.c
 *            DESCRIPTION: add a record to the database
 *      DEFINED CONSTANTS: defined in db.h
 *       TYPE DEFINITIONS: defined in db.h
 *      MACRO DEFINITIONS: defined in db.h
 *       GLOBAL VARIABLES: defined in db.h
 *       PUBLIC FUNCTIONS: DBAddRecord
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/DB, no underscores, mixed case		DBPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/DB, underscores, mixed case			DB_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		prefixed w/DB, underscores and all caps		DB_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBADD_C
#define DBADD_C

/* === System Headers === */
#include <stdio.h>
#include <stdlib.h>

/* === Project Headers === */
#include "db.h"
#include "debug.h"

/* === external routines === */
extern int	DBParseBuf();
extern int	DBInsertRecord();
extern void	DBBuildHash();
extern int	DBGetHashRecord();
extern int	DBSearchDB();

/* === Global Variables === */
extern char		*DB_Fields[DB_MAX_FIELDS];	/* the fields from the record */


/*========================================================================
 *	Name:			DBAddRecord
 *	Prototype:	int DBAddRecord(char *string)
 *					
 *	Description:
 *		Add a record to the database, if possible.
 *
 *	Input Arguments:
 *		char	*string			character string containing all the data
 *									using semicolons (;) as field delimeters
 *		
 *	Output Arguments:
 *		None.
 *
 *	Return Values:
 *		DB_SUCCESS				record successfully added to the databae
 *		DB_EXIST					record already exists
 *		DB_CANT_PARSE			can't parse the record
 *		DB_TOO_MANY_FIELDS	record contains too many fields
 *		DB_NO_DELIMITER		can't find the FIELD delimiter
 *		others					return codes from the following are also valid:
 *										DBInsertRecord()
 *										DBSearchDB()
 *									
 *
 *	Global Variables:
 *		None
 *
 *	External Routines:
 *		DBGetHashRecord, DBBuildHash, DBParseBuf, DBInsertRecord
 *		DBSearchDB
 *
 *	Method:
 * 1. Parse the record into its components fields
 * 2. build a hash record from the original
 * 3. check to see if the hash already exists
 * 	3.1 it does
 * 		 3.1.1 search the db to see if the record exists
 * 				 3.1.1.1 No, it doesn't
 * 							3.1.1.1.1 insert the new record
 * 		 					3.1.1.1.2 return status of add
 * 				 3.1.1.2 Yes, it does
 * 							3.1.1.2.1 return DB_EXIST
 * 	3.2 it doesn't
 * 		 3.2.1 insert the new record
 * 		 3.2.2 return status of add
 * 
 *	Restrictions:
 *		None
 *
 *	Notes:
 *		This routine is part of the API, and thus is called by applications
 *		making use of the database.
 *		
 *========================================================================*/
int
DBAddRecord(
	char	*string
)
{

#ifdef DEBUG
	char		fname[]="DBAddRecord()";
#endif

	char		*stringcopy;				/* a copy of the original string */
	int		i, count;					/* how many fields parsed from string */
	HASH_REC	hash_rec;					/* hash record */
	int		rc;							/* return codes */


	DBGEnter();
	DBGPrintf(DBG_INFO,("record to add:\n%s\n", string));

	/*
	 * initialize the array of character pointers which will be the fields
	 * of the record
	 */
	for ( i=0; i < DB_MAX_FIELDS; i++ )
	{
		if ( DB_Fields[i] != NULL )
		{
			free ( DB_Fields[i] );
			DB_Fields[i]=NULL;
		}
	}

	/*
	 * copy the original to a working copy
	 */
	stringcopy = (char *) malloc ( strlen ( string ) + 1);
	strcpy ( stringcopy, string );

	/*
	 * try to parse the record into component fields
	 */
	count = 0;
	while ( ( strlen (stringcopy) > 0 ) && ( count < DB_MAX_FIELDS ) )
	{
		rc = DBParseBuf( stringcopy, (char **)&(DB_Fields[count]), 
					FIELD, NULL );

		switch ( rc )
		{
			case DB_SUCCESS:
			case DB_EMPTY_FIELD:
				DBGPrintf(DBG_INFO, ("DBParseBuf() returned ok: rc=%d\n", rc) );
            break;

			case DB_NO_DELIMITER:
				/*
				 * if DBParseBuf() says the FIELD delimiter is not there then
				 * we have the last field, so copy it directly into the last field
				 */
				DB_Fields[count] = (char *) malloc ( strlen ( stringcopy ) + 1 );
				strcpy ( DB_Fields[count], stringcopy );

				DBGPrintf( DBG_INFO, ("field %d: %s\n", count, DB_Fields[count]) );
				break;

			default:
				/*
				 * clean up storage allocated, if any
				 */
				free ( stringcopy );
				for ( i=0; i < count; i++ )
				{
					if ( DB_Fields[i] != NULL )
					{
						free ( DB_Fields[i] );
						DB_Fields[i] = NULL;
					}
				}

				/*
				 * tell the caller we can't parse the string they passed us
				 */
				DBGExit();
				return (DB_CANT_PARSE);
				break;
		
		}
		count++;
	}

	/*
	 * We dont' need the copy any more, so free up its storage
	 */
	free( stringcopy );

	/*
	 * make sure we didn't exit last loop because we have too many fields
	 */
	if ( count > DB_MAX_FIELDS )
	{
		/*
		 * clean up storage allocated, if any
		 */
		for ( i=0; i < count; i++ )
		{
			if ( DB_Fields[i] != NULL )
			{
				free ( DB_Fields[i] );
				DB_Fields[i] = NULL;
			}
		}

		/*
		 * tell caller the string they passed has too many fields in it
		 */
		DBGExit();
		return ( DB_TOO_MANY_FIELDS );
	}


	/*
	 * first field is used as hash
	 */
	DBBuildHash( DB_Fields[0], &hash_rec );


	/*
	 * check if there is an existing hash record for this record
	 */
	switch ( DBGetHashRecord( &hash_rec ) )
	{

		case DB_SUCCESS:

			/*
			 * There is a hash record;  check if it leads to any records
			 * that match the record we want to add
			 */
			switch ( ( rc = DBSearchDB( DB_MATCH_EXACT | DB_MATCH_INDEX,
							NULL, NULL, NULL ) ) )
			{

				/*
				 * no records match; go ahead and try to add the record to the db
				 */
				case DB_NOMATCH:
					DBGPrint ( DBG_INFO, "DBSearchDB() returned DB_NOMATCH\n");
					rc = DBInsertRecord( string );
					for ( i=0; i < count; i++ )
					{
						if ( DB_Fields[i] != NULL )
						{
							free ( DB_Fields[i] );
							DB_Fields[i] = NULL;
						}
					}
					DBGExit();
					return ( rc );
					break;

				/*
				 * a matching record was found - tell the caller the record
				 * already exists
				 */
				case DB_EXIST:
					DBGPrint ( DBG_INFO, "DBSearchDB() returned DB_EXIST\n");
					for ( i=0; i < count; i++ )
					{
						if ( DB_Fields[i] != NULL )
						{
							free ( DB_Fields[i] );
							DB_Fields[i] = NULL;
						}
					}
					DBGExit();
					return ( DB_EXIST );
					break;

				/*
				 * any others are trouble; report it
				 */
				default:
					DBGPrint ( DBG_INFO, "DBSearchDB() returned default\n");
					for ( i=0; i < count; i++ )
					{
						if ( DB_Fields[i] != NULL )
						{
							free ( DB_Fields[i] );
							DB_Fields[i] = NULL;
						}
					}
					DBGExit();
					return ( rc );
			}
			break;


		case NULLHASHTABLE:
		case HASHNOTFOUND:

			/*
			 * there is no hash for this record so its safe to try to 
			 * add it to the db.
			 */
			DBGPrint(DBG_INFO, "Calling DBInsertRecord()\n");
			rc = DBInsertRecord( string );

			DBGPrintf(DBG_INFO, ("DBInsertRecord() returned: rc=%d\n", rc) );

			for ( i=0; i < count; i++ )
			{
				if ( DB_Fields[i] != NULL )
				{
					free ( DB_Fields[i] );
					DB_Fields[i] = NULL;
				}
			}
			DBGExit();
			return ( rc );
			break;
	}


	/*
	 * clean up storage
	 */
	for ( i=0; i < count; i++ )
	{
		if ( DB_Fields[i] != NULL )
		{
			free ( DB_Fields[i] );
			DB_Fields[i] = NULL;
		}
	}

	DBGExit();
	return ( DB_SUCCESS );

}

#endif /* DBADD_C */
