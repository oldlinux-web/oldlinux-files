/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: DBGet.c
 *            DESCRIPTION: retrieve a record for viewing from the database
 *      DEFINED CONSTANTS: defined in db.h
 *       TYPE DEFINITIONS: defined in db.h
 *      MACRO DEFINITIONS: defined in db.h
 *       GLOBAL VARIABLES: defined in db.h
 *       PUBLIC FUNCTIONS: DBGetRecord
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/DB, no underscores, mixed case		DBPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/DB, underscores, mixed case			DB_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		prefixed w/DB, underscores and all caps		DB_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBGET_C
#define DBGET_C

/* === System Headers === */
#include <stdio.h>
#include <stdlib.h>

/* === Project Headers === */
#include "db.h"
#include "debug.h"

/* === external routines === */
extern int	DBParseBuf();
extern void	DBBuildHash();
extern int	DBGetHashRecord();
extern int	DBGetHashLink();
extern int	DBGetIndexRecord();
extern int	DBSearchDB();

/* === Global Variables === */
extern char		*DB_Fields[DB_MAX_FIELDS];	/* the fields from the record */

static INDEX_REC	*static_index=NULL;		/* index record */


/*========================================================================
 *	Name:			DBGetRecord
 *	Prototype:	int DBGetRecord(int type, char *string, 
 *								**return_record, flags)
 *					
 *	Description:
 *		Get a record to the database, if possible.
 *
 *	Input Arguments:
 *		int	type				One of DB_GET_NEXT, DB_GET_PREVIOUS, DB_GET_ANY,
 *									DB_GET_FIRST, or NULL
 *		char	*string			if type is NULL, then this must be a character
 *									string containing the search data using semicolons
 *									(;) as field delimeters
 *		int	flags				Currently can only be DB_HAS_SUBFIELDS
 *		
 *	Output Arguments:
 *		char	**return_record	record retrieved from the database
 *
 *	Return Values:
 *		DB_FAILURE				errors occured during search for record
 *		DB_MATCH					found a record
 *		DB_NOMATCH				no matching record found
 *		DB_CANT_PARSE			can't parse the record
 *		DB_TOO_MANY_FIELDS	record contains too many fields
 *		DB_NO_DELIMITER		can't find the FIELD delimiter
 *		DB_NULL_STRING			string is NULL and type is NULL
 *		DB_BAD_TYPE				caller passed a bad type value
 *
 *	Global Variables:
 *		None
 *
 *	External Routines:
 *		DBGetHashRecord, DBBuildHash, DBParseBuf, DBSearchDB
 *
 *	Method:
 *	1. if type is NULL or DB_GET_ANY
 *		1.1. clear static index
 *		1.2. if type is NULL
 *			1.2.1. validate the string
 *			1.2.2. parse the string to get a hash entry
 *			1.2.3. get the index record associated with hash entry
 *			1.2.4. call DBSearchDB
 *			1.2.5. if DBSearchDB returns a record, return it to the caller
 *			  		otherwise return an error
 *		1.3. if type is DB_GET_ANY
 *			1.3.1. call DBSearchSequential
 *			1.3.2. if DBSearchSequential returns a record, return it to the caller
 *			  		otherwise return an error
 *	2. if type is DB_GET_NEXT
 *		2.1. use the static index to get the next index record
 *		2.2. call DBSearchDB
 *		2.3. if DBSearchDB returns a record, return it to the caller
 *			  otherwise return an error
 *	3. if type is DB_GET_PREVIOUS
 *		3.1. use the static index to get the previous index record
 *		3.2. call DBSearchDB
 *		3.3. if DBSearchDB returns a record, return it to the caller
 *			  otherwise return an error
 *	4. if type is DB_GET_FIRST
 *		4.1. clear static index
 *		4.2. get the hash table head
 *		4.3. get the index the hash table head points to
 *		4.4. if DBSearchDB returns a record, return it to the caller
 *			  otherwise return an error
 *
 *	Restr3ctions:
 *		None
 *
 *	Notes:
 *		This routine is part of the API, and thus is called by applications
 *		making use of the database.
 *
 *		DBGetRecord() keeps a static index record so that subsequent
 *		invokations with types of DB_GET_NEXT or DB_GET_PREVIOUS don't
 *		require hash's or complete records from the caller.  Each call
 *		to DBGetRecord() with a NULL type will reset this index to be
 *		NULL.  This should prevent the caller from accidently making a next
 *		or previous call when the index is already set to an index of a
 *		a record the caller isn't interested in.
 *
 *		DB_GET_ANY is not yet implemented.  There is something inherently evil
 *		about doing a sequential search through the db for a record which
 *		can match *any* field.  I'm not sure I want to deal with that 
 *		scenario.  mjh
 *		
 *========================================================================*/
int
DBGetRecord(
	int	type,
	char	*string,
	char	**return_record,
	int	flags
)
{

#ifdef DEBUG
	char			fname[]="DBGetRecord()";
#endif

	HASH_REC		hash_rec, *tmp_hash_rec;
	HASH_LINK	hash_link, *hash_link_ptr;
	char			*stringcopy, *indexfield;
	int			rc, count, i;


	DBGEnter();
	DBGPrintf(DBG_INFO, ("string passed from caller:\n%s\n", string) );

	/*
	 * initialize the array of character pointers which will be the fields
	 * of the record
	 */
	for ( i=0; i < DB_MAX_FIELDS; i++ )
	{
		if ( DB_Fields[i] != NULL )
		{
			free ( DB_Fields[i] );
			DB_Fields[i]=NULL;
		}
	}

	/*
	 * If type is NULL or DB_GET_ANY, we must use the index field to find a
	 * record.
	 */
	if ( ( type == (int)NULL ) || ( type == DB_GET_ANY ) )
	{
		/*
		 * Make sure the static index doesn't point to a previous
		 * record.
		 */
		if ( static_index != NULL )
		{
			free ( static_index );
			static_index = NULL;
		}

		/*
		 * Validate the string
		 */
		if ( string == NULL )
		{
			DBGExit();
			return (DB_NULL_STRING);
		}

		/*
		 * Allocate storage for a copy of the string
		 */
		stringcopy = (char *) malloc ( strlen ( string ) + 1);
		strcpy ( stringcopy, string );

		/*
		 * Parse the string copy to get the index field
		 */
		indexfield = NULL;
		rc = DBParseBuf( stringcopy, (char **)(&indexfield), FIELD, NULL );

		switch ( rc )
		{
			case DB_SUCCESS:
			case DB_EMPTY_FIELD:
				DBGPrintf(DBG_INFO, ("DBParseBuf() returned ok: rc=%d\n", rc) );
				break;

			default:
				DBGPrintf(DBG_INFO, ("DBParseBuf returned error: rc=%d\n", rc) );

				/*
				 * clean up storage allocated, if any
				 */
				if ( stringcopy != NULL )
					free ( stringcopy );
				if ( indexfield != NULL )
					free( indexfield );
	
				/*
				 * tell the caller we can't parse the string they passed us
				 */
				DBGExit();
				return (DB_CANT_PARSE);
				break;
		}

		/*
		 * There must be an index field or this won't work
		 */
		if ( indexfield == NULL )
		{
			DBGPrint(DBG_INFO, 
				"There is no index field in the callers record");

			free ( stringcopy );
			DBGExit();
			return ( DB_MISSING_INDEX );
		}

		/*
		 * Get another copy for parsing into the DB_Fields[] array
		 */
		bzero ( stringcopy, strlen(string) );
		strcpy ( stringcopy, string );


		/*
		 * try to parse the record into component fields
		 */
		count = 0;
		while ( ( strlen (stringcopy) > 0 ) && ( count < DB_MAX_FIELDS ) )
		{
			rc = DBParseBuf( stringcopy, (char **)&(DB_Fields[count]), 
						FIELD, NULL );

			switch( rc )
			{
				/*
				 * these are ok, we either parsed out a field or the field was
				 * empty.
				 */
				case DB_SUCCESS:
					DBGPrintf(DBG_INFO, 
						("DB_Fields[%d]= \"%s\"\n", count, DB_Fields[count] ));
					break;

				case DB_EMPTY_FIELD:
					DBGPrintf(DBG_INFO, ("DB_Fields[%d] is empty\n", count ));
					break;

				/*
				 * Last field - DBParseBuf() won't find a delimiter
				 */
				case DB_NO_DELIMITER:
					/*
					 * if DBParseBuf() says the FIELD delimiter is not there then
					 * we have the last field, so copy it directly into the last field
					 */
					DB_Fields[count] = (char *) malloc ( strlen ( stringcopy ) + 1);
					strcpy ( DB_Fields[count], stringcopy );
		
					DBGPrintf( DBG_INFO, ("DB_Fields[%d]: \"%s\"\n", 
							count, DB_Fields[count]) );

					/*
					 * Clean out the string copy; this breakks us out of while()
					 * loop
					 */
					bzero(stringcopy, strlen (string) );
					break;

				/*
				 * All other return codes are errors
				 */
				default:
					DBGPrintf(DBG_INFO, ("DBParseBuf returned error: rc=%d\n", rc) );

					/*
					 * clean up storage allocated, if any
					 */
					if ( stringcopy != NULL )
					{
						free ( stringcopy );
						stringcopy = NULL;
					}
					if ( indexfield != NULL )
					{
						free ( indexfield );
						indexfield = NULL;
					}
					for ( i=0; i < count; i++ )
					{
						if ( DB_Fields[i] != NULL )
						{
							free ( DB_Fields[i] );
							DB_Fields[i] = NULL;
						}
					}
		
					/*
					 * tell the caller we can't parse the string they passed us
					 */
					DBGExit();
					return (DB_CANT_PARSE);
					break;

			}
			count++;
		}
	
		/*
		 * We dont' need the copy any more, so free up its storage
		 */
		if ( stringcopy != NULL )
		{
			free( stringcopy );
			stringcopy = NULL;
		}
	
		/*
		 * make sure we didn't exit last loop because we have too many fields
		 */
		if ( count > DB_MAX_FIELDS )
		{
			/*
			 * clean up storage allocated, if any
			 */
			for ( i=0; i < count; i++ )
			{
				if ( DB_Fields[i] != NULL )
				{
					free ( DB_Fields[i] );
					DB_Fields[i] = NULL;
				}
			}
			if ( indexfield != NULL )
			{
				free ( indexfield );
				indexfield = NULL;
			}
	
			/*
			 * tell caller the string they passed has too many fields in it
			 */
			DBGExit();
			return ( DB_TOO_MANY_FIELDS );
		}


		/*
		 * Now get a copy of the index record - we need this in case future
		 * calls to this routine ask for the "Next" or "Previous" records
		 * and DBSearchDB() doesn't return the index field.
		 */


		/*
		 * Build a hash based on the index field
		 */
		DBBuildHash( indexfield, &hash_rec );
		free ( indexfield );


		/*
		 * Get the hash link and its associated hash record
		 */
		if ( DBGetHashLink ( &hash_rec, &hash_link_ptr ) != DB_MATCH )
		{
			DBGExit();
			return ( DB_NOMATCH );
		}

		/*
		 * grab a copy of the hash record pointed to by the hash link
		 */
		tmp_hash_rec = (HASH_REC *)hash_link_ptr->hash;
		strcpy ( hash_rec.name, tmp_hash_rec->name );
		hash_rec.ptr = tmp_hash_rec->ptr;

		/*
		 * Allocate an index record
		 */
		static_index = (INDEX_REC *) malloc ( sizeof ( INDEX_REC ) );

		/*
		 * Get the index record associated with the hash record
		 */
		if ( (rc = DBGetIndexRecord ( &hash_rec, static_index ) ) != DB_SUCCESS )
		{
			DBGPrintf(DBG_INFO, 
				("DBGetIndexRecord() returned failure; rc=%d\n", rc) );
			free ( static_index);
			DBGExit();
			return ( INDEXERR );
		}
		
		/*
		 * We have the index record.  We now need to search the database
		 * for a record that matches the request passed in to us.
		 */
		if ( flags & DB_HAS_SUBFIELDS )
		{
			if ( (rc = DBSearchDB( DB_HAS_SUBFIELDS | DB_MATCH_ALL | DB_MATCH_RETURN,
						NULL, NULL, return_record )) != DB_EXIST )
			{
				DBGPrintf(DBG_INFO, 
					("DBSearchDB() returned failure; rc=%d\n", rc) );
				free ( static_index );
				static_index = NULL;
				DBGExit();
				return ( DB_NOMATCH );
			}
		}
		else
		{
			if ( (rc = DBSearchDB( DB_MATCH_ALL | DB_MATCH_RETURN,
						NULL, NULL, return_record )) != DB_EXIST )
			{
				DBGPrintf(DBG_INFO, 
					("DBSearchDB() returned failure; rc=%d\n", rc) );
				free ( static_index );
				static_index = NULL;
				DBGExit();
				return ( DB_NOMATCH );
			}
		}

		/*
		 * Found a record
		 */
		DBGExit();
		return ( DB_MATCH );

	}


	/*
	 * If caller requests the next db record...
	 */
	if ( type == DB_GET_NEXT )
	{

		/*
		 * First make sure the static index record has been allocated.
		 */
		if ( static_index == NULL ) 
		{
			DBGPrint(DBG_INFO, "static_index is NULL\n");
			DBGExit();
			return ( DB_NULL_STATIC_INDEX );
		}

		/*
		 * Get the next index record
		 */
		if ( (hash_rec.ptr = static_index->next) == -1 )
		{
			/*
			 * there isn't a next record
			 */
			DBGExit();
			return ( DB_NOMATCH );
		}

		if ( (rc = DBGetIndexRecord ( &hash_rec, static_index ) ) != DB_SUCCESS )
		{
			DBGPrintf(DBG_INFO, 
				("DBGetIndexRecord() returned failure; rc=%d\n", rc) );
			free ( static_index);
			DBGExit();
			return ( INDEXERR );
		}
		
		/*
		 * Call DBSearchDB to get the record
		 */
		if ( DBSearchDB( DB_MATCH_ANY | DB_MATCH_RETURN,
					NULL, static_index, return_record ) != DB_EXIST )
		{
			DBGPrintf(DBG_INFO, 
				("DBSearchDB() returned failure; rc=%d\n", rc) );
			free ( static_index );
			static_index = NULL;
			DBGExit();
			return ( DB_NOMATCH );
		}

		/*
		 * Found the record
		 */
		DBGExit();
		return ( DB_MATCH );

	}


	/*
	 * If caller requests the previous db record...
	 */
	if ( type == DB_GET_PREVIOUS )
	{
		/*
		 * First make sure the static index record has been allocated.
		 */
		if ( static_index == NULL ) 
		{
			DBGPrint(DBG_INFO, "static_index is NULL\n");
			DBGExit();
			return ( DB_NULL_STATIC_INDEX );
		}

		/*
		 * Get the previous index record
		 */
		if ( ( hash_rec.ptr = static_index->prev ) == -1 )
		{
			/*
			 * there isn't a previous record
			 */
			DBGExit();
			return ( DB_NOMATCH );
		}

		if ( (rc = DBGetIndexRecord ( &hash_rec, static_index ) ) != DB_SUCCESS )
		{
			DBGPrintf(DBG_INFO, 
				("DBGetIndexRecord() returned failure; rc=%d\n", rc) );
			free ( static_index);
			DBGExit();
			return ( INDEXERR );
		}
		
		/*
		 * Call DBSearchDB to get the record
		 */
		if ( DBSearchDB( DB_MATCH_ANY | DB_MATCH_RETURN,
					NULL, static_index, return_record ) != DB_EXIST )
		{
			DBGPrintf(DBG_INFO, 
				("DBSearchDB() returned failure; rc=%d\n", rc) );
			free ( static_index );
			static_index = NULL;
			DBGExit();
			return ( DB_NOMATCH );
		}

		/*
		 * Found the record
		 */
		DBGExit();
		return ( DB_MATCH );
	}


	if ( type == DB_GET_FIRST )
	{
		/*
		 * Make sure the static index doesn't point to a previous
		 * record.
		 */
		if ( static_index != NULL )
		{
			free ( static_index );
			static_index = NULL;
		}

		/*
		 * Get the first link in the hash table
		 */
		if ( DB_Hash_Head == (int)NULL )
		{
			DBGPrint(DBG_INFO, "Hash is empty - no first record to get!\n");
			DBGExit();
			return ( NULLHASHTABLE );
		}
		bcopy ( (char *)(DB_Hash_Head), (char *)&hash_link, sizeof (HASH_LINK) );

		/*
		 * Get a copy of the hash record for that hash table entry
		 */
		bcopy ( (char *)(hash_link.hash), (char *)&hash_rec, sizeof (HASH_REC) );


		/*
		 * Allocate an index record
		 */
		static_index = (INDEX_REC *) malloc ( sizeof ( INDEX_REC ) );

		/*
		 * Get the index record
		 */
		if ( (rc = DBGetIndexRecord ( &hash_rec, static_index ) ) != DB_SUCCESS )
		{
			DBGPrintf(DBG_INFO, 
				("DBGetIndexRecord() returned failure; rc=%d", rc) );
			free ( static_index);
			DBGExit();
			return ( INDEXERR );
		}
		
		/*
		 * Call DBSearchDB to get the record
		 */
		if ( DBSearchDB( DB_MATCH_ANY | DB_MATCH_RETURN,
					NULL, static_index, return_record ) != DB_EXIST )
		{
			DBGPrintf(DBG_INFO, 
				("DBSearchDB() returned failure; rc=%d", rc) );
			free ( static_index );
			static_index = NULL;
			DBGExit();
			return ( DB_NOMATCH );
		}

		/*
		 * Found the record
		 */
		DBGExit();
		return ( DB_MATCH );
	}


	/*
	 * if we got this far, the caller passed some bogus type
	 */
	DBGExit();
	return (DB_BAD_TYPE);
}


#endif /* DBGET_C */
