/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: DBDelete.c
 *            DESCRIPTION: delete a record from the database, if possible
 *      DEFINED CONSTANTS: defined in db.h
 *       TYPE DEFINITIONS: defined in db.h
 *      MACRO DEFINITIONS: defined in db.h
 *       GLOBAL VARIABLES: defined in db.h
 *       PUBLIC FUNCTIONS: DBDeleteRecord
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/DB, no underscores, mixed case		DBPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/DB, underscores, mixed case			DB_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		prefixed w/DB, underscores and all caps		DB_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBDELETE_C
#define DBDELETE_C

/* === System Headers === */
#include <stdio.h>
#include <stdlib.h>

/* === Project Headers === */
#include "db.h"
#include "debug.h"

/* === external routines === */
extern int	DBParseBuf();
extern void	DBBuildHash();
extern int	DBGetHashRecord();
extern int	DBGetHashLink();
extern int	DBGetIndexRecord();
extern int	DBPutIndexRecord();
extern int	DBGetDBRecord();
extern int	DBCompare();

/* === Global Variables === */
extern char		*DB_Fields[DB_MAX_FIELDS];	/* the fields from the record */


/*========================================================================
 *	Name:			DBDeleteRecord
 *	Prototype:	int DBDeleteRecord(char *string)
 *					
 *	Description:
 *		Delete a record from the database, if possible.
 *
 *	Input Arguments:
 *		char	*string			character string containing all the data
 *									using semicolons (;) as field delimeters
 *		
 *	Output Arguments:
 *		None.
 *
 *	Return Values:
 *		DB_SUCCESS				record successfully deleted
 *		DB_NOMATCH				can't find record to delete in database
 *		DB_NOMATCH_HASH		can't find record to delete in database
 *		DB_CANT_PARSE			can't parse the record
 *		DB_TOO_MANY_FIELDS	record contains too many fields
 *		DB_NULL_STRING		   string argument is null
 *									
 *
 *	Global Variables:
 *		None
 *
 *	External Routines:
 *		DBGetHashRecord, DBBuildHash, DBParseBuf, DBGetHashLink
 *
 *	Method:
 * 1 parse string into DB_Fields[] (DBParseBuf)
 * 2 build a hash entry (DBBuildHash)
 * 3 find the matching hash table entry, if any (DBGetHashRecord)
 * 4 get the index record for that hash entry (DBGetIndex)
 * 5 get the db record the index points to (DBGetDBRecord)
 * 6 while ( (DB_Fields, fields) != DB_MATCH ) - (DBCompare)
 * 	6.2 get next index record (DBGEtIndex)
 * 	6.1 get the db record pointed to by that index (DBGetDBRecord)
 * 	6.2 build a hash entry for that record (DBBuildHash)
 * 	6.3 compare hash entries, return failure if not matching
 * 7 if no match, return failure
 * 8 else delete index, and hash if necessary
 * 	8.1 build a hash entry for record (DBBuildHash)
 *		8.2 find the matching hash table entry, if any (DBGetHashRecord)
 *		8.3 get "previous" index from "current" index
 *		8.4 if hash record points to "current" index
 *			8.4.1 get "next" index from "current" index
 *			8.4.2 get db record the "next" index points to
 *			8.4.3 build hash entry from db record
 *			8.4.4 if hash entry match current hash
 *				8.4.4.1 current hash points to "next" index
 *				8.4.4.2 set global for updating hash on exit
 *		8.5 update "previous" index to point to "currents" next.
 *		8.6 get "current" index next.
 *		8.7 update "next" index to point to "currents" prev.
 *		8.8 mark current index as inactive.
 * 
 *	Restrictions:
 *		None
 *
 *	Notes:
 *		This routine is part of the API, and thus is called by applications
 *		making use of the database.
 *		
 *========================================================================*/
int
DBDeleteRecord(
	char	*string
)
{

#ifdef DEBUG
	char			fname[]="DBDeleteRecord()";
#endif

	INDEX_REC	index_rec, tmp_index_rec;
	HASH_REC		hash_rec, tmp_hash_rec, *tmp_hash_rec_ptr;
	HASH_LINK	*hash_link, *prev_hash_link, *next_hash_link;
	int			master_hash_ptr;
	char			*stringcopy, *db, *indexfield;
	int			count, rc, i;


	DBGEnter();
	DBGPrintf(DBG_INFO,("record to add:\n%s\n", string));

	/*
	 * Initialize the array of character pointers which will be the fields
	 * of the record
	 */
	DBGPrint(DBG_INFO, "Cleaning up DB_Fields[]\n");
	for ( i=0; i < DB_MAX_FIELDS; i++ )
	{
		if ( DB_Fields[i] != NULL )
		{
			free ( DB_Fields[i] );
			DB_Fields[i]=NULL;
		}
	}


	/*
	 * Make sure the callers request is not null
	 */
	if ( string == NULL )
		return (DB_NULL_STRING);


	/*
	 * Copy the original to a working copy
	 */
	DBGPrint(DBG_INFO, "Allocating stringcopy\n");
	stringcopy = (char *) malloc ( strlen ( string ) + 1);
	strcpy ( stringcopy, string );

	/*
	 * Try to parse the record into component fields
	 */
	count = 0;
	while ( ( strlen (stringcopy) > 0 ) && ( count < DB_MAX_FIELDS ) )
	{
		DBGPrintf(DBG_INFO, ("Parsing field %d\n", count) );
		rc = DBParseBuf( stringcopy, (char **)&(DB_Fields[count]), 
					FIELD, NULL );

		switch ( rc )
		{
			case DB_SUCCESS:
			case DB_EMPTY_FIELD:
				DBGPrintf(DBG_INFO, ("DBParseBuf() returned ok: rc=%d\n", rc) );
            break;

			case DB_NO_DELIMITER:
				/*
				 * if DBParseBuf() says the FIELD delimiter is not there then
				 * we have the last field, so copy it directly into the last field
				 */
				DB_Fields[count] = (char *) malloc ( strlen ( stringcopy ) + 1 );
				strcpy ( DB_Fields[count], stringcopy );

				DBGPrintf( DBG_INFO, ("field %d: %s\n", count, DB_Fields[count]) );
				break;

			default:
				/*
				 * clean up storage allocated, if any
				 */
				free ( stringcopy );
				for ( i=0; i < count; i++ )
				{
					if ( DB_Fields[i] != NULL )
					{
						free ( DB_Fields[i] );
						DB_Fields[i] = NULL;
					}
				}

				/*
				 * tell the caller we can't parse the string they passed us
				 */
				DBGExit();
				return (DB_CANT_PARSE);
				break;
		
		}
		count++;
	}

	/*
	 * We dont' need the copy any more, so free up its storage
	 */
	free( stringcopy );

	/*
	 * Make sure we didn't exit last loop because we have too many fields
	 */
	if ( count > DB_MAX_FIELDS )
	{
		/*
		 * Clean up storage allocated, if any
		 */
		for ( i=0; i < count; i++ )
		{
			if ( DB_Fields[i] != NULL )
			{
				free ( DB_Fields[i] );
				DB_Fields[i] = NULL;
			}
		}

		/*
		 * Tell caller the string they passed has too many fields in it
		 */
		DBGExit();
		return ( DB_TOO_MANY_FIELDS );
	}


	/*
	 * First field is used as hash
	 */
	DBGPrint(DBG_INFO, "Building hash\n" );
	(void) DBBuildHash( DB_Fields[0], &hash_rec );


	/*
	 * Get the matching hash table entry
	 */
	DBGPrint(DBG_INFO, "getting hash table entry\n" );
	(void) DBGetHashRecord( &hash_rec );


	/*
	 * Get the index record pointed to by the hash
	 */
	DBGPrint(DBG_INFO, "getting index record\n" );
	if ( (rc = DBGetIndexRecord( &hash_rec, &index_rec ) ) != DB_SUCCESS )
	{
		/*
		 * No index record for this hash!
		 * Thats bad, but let the caller deal with it.
		 */
		for ( i=0; i < count; i++ )
		{
			if ( DB_Fields[i] != NULL )
			{
				free ( DB_Fields[i] );
				DB_Fields[i] = NULL;
			}
		}

		DBGExit();
		return ( rc );
	}
	

	/*
	 * Get the db record the index points to
	 */
	DBGPrint(DBG_INFO, "getting db record\n" );
	if ( ( rc = DBGetDBRecord ( &index_rec, &db ) ) != DB_SUCCESS )
	{
		/*
		 * No record found, which is bad if hash_rec pointed
		 * to a valid hash record.  Again, let
		 * the caller deal with it.
		 */
		for ( i=0; i < count; i++ )
		{
			if ( DB_Fields[i] != NULL )
			{
				free ( DB_Fields[i] );
				DB_Fields[i] = NULL;
			}
		}

		DBGExit();
		return ( rc );
	}


	/*
	 * Find a matching record, just to be sure there is one
	 */
	DBGPrint(DBG_INFO, "searching for matching record in db\n" );
	while ( DBCompare ( DB_MATCH_EXACT | DB_MATCH_ALL, db ) != DB_MATCH )
	{
		
		/*
		 * Get the next index record pointer, if any
		 */
		if ( index_rec.next != -1 )
			hash_rec.ptr = index_rec.next;
		else
		{
			/*
			 * We've gone through all the indexes that match the hash
			 * so there must not be any records that match the request.
			 * Cleanup and return to the caller a no match result.
			 */
			DBGPrint(DBG_INFO, "did not find record\n" );

			free ( db );
			for ( i=0; i < count; i++ )
			{
				if ( DB_Fields[i] != NULL )
				{
					free ( DB_Fields[i] );
					DB_Fields[i] = NULL;
				}
			}

			DBGExit();
			return( DB_NOMATCH );
		}


		/*
		 * Get the index record
		 */
		DBGPrint(DBG_INFO, "getting index record\n" );
		if ( ( rc = DBGetIndexRecord ( &hash_rec, &index_rec ) ) != DB_SUCCESS )
		{
			DBGPrint(DBG_INFO, "DBGetIndexRecord() did not return DB_SUCCESS\n");
			free ( db );
			for ( i=0; i < count; i++ )
			{
				if ( DB_Fields[i] != NULL )
				{
					free ( DB_Fields[i] );
					DB_Fields[i] = NULL;
				}
			}
			DBGExit();
			return ( rc );
		}

		/*
		 * Cleanup up the old db record storage
		 */
		free ( db );

		/*
		 * get the database record associated with that index
		 */
		DBGPrint(DBG_INFO, "getting db record\n" );
		if ( ( rc = DBGetDBRecord ( &index_rec, &db ) ) != DB_SUCCESS )
		{
			DBGPrint(DBG_INFO, "DBGetDBRecord() did not return DB_SUCCESS\n");
			free ( db );
			for ( i=0; i < count; i++ )
			{
				if ( DB_Fields[i] != NULL )
				{
					free ( DB_Fields[i] );
					DB_Fields[i] = NULL;
				}
			}
			DBGExit();
			return ( rc );
		}

		/*
		 * We need a copy of this to pull out the index field
		 */
		DBGPrint(DBG_INFO, "allocating stringcopy\n" );
		stringcopy = (char *) malloc ( strlen ( db ) + 1 );
		strcpy ( stringcopy, db );

		/*
		 * Parse out the index field from the copy
		 */
		DBGPrint(DBG_INFO, "parsing for stringcopy\n" );
		rc = DBParseBuf( stringcopy, (char **)&indexfield, FIELD, NULL );
		switch ( rc )
		{
			case DB_SUCCESS:
            break;

			default:
				DBGPrintf(DBG_INFO, 
					("DBParseBuf() returned error: rc=%d\n", rc) );

				/*
				 * clean up storage allocated, if any
				 */
				free ( db );
				free ( stringcopy );
				for ( i=0; i < count; i++ )
				{
					if ( DB_Fields[i] != NULL )
					{
						free ( DB_Fields[i] );
						DB_Fields[i] = NULL;
					}
				}

				/*
				 * tell the caller we can't parse the string they passed us
				 */
				DBGExit();
				return (DB_CANT_PARSE);
				break;
		}
		free ( stringcopy );

		/*
		 * Build a hash entry for that record
		 */
		DBGPrint(DBG_INFO, "building hash from record\n" );
		(void) DBBuildHash( indexfield, &tmp_hash_rec );
		free ( indexfield );

		/*
		 * Make sure the new hash matches the original, if not theres
		 * no point continuing.
		 */
		DBGPrint(DBG_INFO, "comparing records hash to original hash\n" );
		if ( (int) strcmp ( tmp_hash_rec.name, hash_rec.name ) != 0 )
		{
			DBGPrint( DBG_INFO, "Hashes don't match\n");
	
			free ( db );
			for ( i=0; i < count; i++ )
			{
				if ( DB_Fields[i] != NULL )
				{
					free ( DB_Fields[i] );
					DB_Fields[i] = NULL;
				}
			}
			DBGExit();
			return( DB_NOMATCH_HASH );
		}
	}

	/*
	 * Save hash pointer;  we'll need it later when updating the hash
	 * table.
	 */
	master_hash_ptr = hash_rec.ptr;


	/*
	 * Clean up the DB_Fields[] array;  we don't need it anymore
	 */
	DBGPrint(DBG_INFO, "cleaning up DB_Fields[]\n" );
	for ( i=0; i < count; i++ )
	{
		if ( DB_Fields[i] != NULL )
		{
			free ( DB_Fields[i] );
			DB_Fields[i] = NULL;
		}
	}


	/*
	 * Found a matching record.  First, update the hash table if
	 * necessary.
	 */

	/*
	 * We need a copy of this to pull out the index field
	 */
	DBGPrint(DBG_INFO, "allocating stringcopy\n" );
	stringcopy = (char *) malloc ( strlen ( db ) + 1 );
	strcpy ( stringcopy, db );

	/*
	 * Parse out the index field from the copy
	 */
	DBGPrint(DBG_INFO, "parsing for index field\n" );
	rc = DBParseBuf( stringcopy, (char **)&indexfield, FIELD, NULL );
	switch ( rc )
	{
		case DB_SUCCESS:
            break;

		default:
			DBGPrintf(DBG_INFO, 
					("DBParseBuf() returned error: rc=%d\n", rc) );

			/*
			 * clean up storage allocated, if any
			 */
			free ( db );
			free ( stringcopy );

			/*
			 * tell the caller we can't parse the string they passed us
			 */
			DBGExit();
			return (DB_CANT_PARSE);
			break;
	}
	free ( stringcopy );

	/*
	 * build a hash entry for record
	 */
	DBGPrint(DBG_INFO, "building hash entry\n" );
	(void) DBBuildHash( indexfield, &hash_rec );
	free ( indexfield );
	
	/*
	 * Get the matching hash table entry
	 */
	DBGPrint(DBG_INFO, "getting hash table entry\n" );
	(void) DBGetHashRecord( &hash_rec );


	/*
	 * If the hash table entries pointer matches the one that points
	 * to the record being deleted, then we need to update the
	 * hash table entry.
	 */
	if ( hash_rec.ptr == master_hash_ptr )
	{

		/*
		 * Get "next" index from "current" index, if possible
		 */
		if ( index_rec.next != -1 )
		{
			/*
			 * Get next link in hash table
			 */
			DBGPrint(DBG_INFO, "getting next index field\n" );
			DBGetHashLink ( &hash_rec, &hash_link );
			if ( ( hash_link = hash_link->next ) == 0 )
			{
				/*
				 * There are no more hash links after the current one but there
				 * are more records, so the current hash needs to point to the
				 * index after the current index.
				 */
				DBGPrint(DBG_INFO, "pointing hash to next record with same hash\n");
				tmp_hash_rec_ptr = (HASH_REC *)hash_link->hash;
				tmp_hash_rec_ptr->ptr = index_rec.next;
	
				free ( db );
				goto remove_index;
	
			}
	
			/*
			 * Get the pointer to the hash record
			 */
			tmp_hash_rec_ptr = (HASH_REC *)hash_link->hash;
	
			/*
			 * if this hash's pointer doesn't match index_rec.next, then
			 * the current hash will now point to index_rec.next
			 */
			if ( tmp_hash_rec_ptr->ptr != index_rec.next )
			{
				DBGPrint(DBG_INFO, "pointing hash to next record with same hash\n");
				(void) DBGetHashLink ( &hash_rec, &hash_link );
				tmp_hash_rec_ptr = (HASH_REC *)hash_link->hash;
				tmp_hash_rec_ptr->ptr = index_rec.next;
	
				free ( db );
				goto remove_index;
			}
			else
			{
				/*
				 * The current hash pointed to an index record that was the
				 * only index which matched the hash.  So we can remove
				 * the hash completely.
				 */
				
				DBGPrint(DBG_INFO, "pointing hash to next record with same hash\n");
				(void) DBGetHashLink ( &hash_rec, &hash_link );
				prev_hash_link = hash_link->prev;
				next_hash_link = hash_link->next;

				if ( prev_hash_link == 0 )
					DB_Hash_Head = (int)hash_link->next;
				else
					prev_hash_link->next = hash_link->next;

				if ( next_hash_link != 0 )
					next_hash_link->prev = hash_link->prev;
	
				DB_Hash_Modified = True;
				free ( (void *)hash_link->hash );
				free ( hash_link );
				free ( db );
				goto remove_index;

			}
		}
		else
		{
			/*
			 * In this case there are no more records in the index after the
			 * current one.  This means the hash pointed to the current index
			 * and no matching index followed, so the hash is no longer
			 * needed.
			 */
			DBGPrint(DBG_INFO, "pointing hash to next record with same hash\n");
			(void) DBGetHashLink ( &hash_rec, &hash_link );

			if ( hash_link->prev == 0 )
				DB_Hash_Head = (int)hash_link->next;
			else
			{
				prev_hash_link = hash_link->prev;
				prev_hash_link->next = hash_link->next;
			}

			DB_Hash_Modified = True;
			free ( (void *)hash_link->hash );
			free ( hash_link );
			free ( db );
			goto remove_index;

		}
	}

remove_index:

	/*
	 * Now remove the index record;  we make the horrible assumptiont that
	 * the db is not corrupt since we don't check for return codes from
	 * DB{Get,Put}IndexRecord().  Students:  don't try this at home!
	 */

	/*
	 * mark the current index as inactive
	 */
	DBGPrint(DBG_INFO, "marking current index as inactive\n" );
	index_rec.active = -1;
	hash_rec.ptr = master_hash_ptr;

	DBGPrintf ( DBG_INFO, 
				("rewriting current index:\n"
				"\thash-ptr: %d\n"
				"\tactive: %d\n"
				"\tnext: %d\n"
				"\tprev: %d\n"
				"\tptr: %d\n"
				"\tlength: %d\n",
				hash_rec.ptr, index_rec.active, index_rec.next, index_rec.prev,
				index_rec.ptr, index_rec.length ));
	DBPutIndexRecord(&hash_rec, &index_rec);

	/*
	 * If there is a previous index, point its next field to the
	 * current index's next.
	 */
	if ( index_rec.prev != -1 )
	{
		DBGPrint(DBG_INFO, "updating prev index field\n" );
		hash_rec.ptr = index_rec.prev;
		DBGetIndexRecord( &hash_rec, &tmp_index_rec );
		tmp_index_rec.next = index_rec.next;
		DBPutIndexRecord(&hash_rec, &tmp_index_rec);
	}

	/*
	 * If there is a next index, point its prev field to the
	 * current index's prev.
	 */
	if ( index_rec.next != -1 )
	{
		DBGPrint(DBG_INFO, "updating next index field\n" );
		hash_rec.ptr = index_rec.next;
		DBGetIndexRecord( &hash_rec, &tmp_index_rec );
		tmp_index_rec.prev = index_rec.prev;
		DBPutIndexRecord(&hash_rec, &tmp_index_rec);
	}


	DBGExit();
	return ( DB_SUCCESS );

}

#endif /* DBDELETE_C */
