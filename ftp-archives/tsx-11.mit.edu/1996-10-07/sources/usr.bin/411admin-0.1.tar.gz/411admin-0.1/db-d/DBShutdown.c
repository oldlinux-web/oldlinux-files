/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: DBShutdown.c
 *            DESCRIPTION: shutdown flat file database
 *      DEFINED CONSTANTS: defined in db.h
 *       TYPE DEFINITIONS: defined in db.h
 *      MACRO DEFINITIONS: defined in db.h
 *       GLOBAL VARIABLES: defined in db.h
 *       PUBLIC FUNCTIONS: DBShutdown
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/DB, no underscores, mixed case		DBPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/DB, underscores, mixed case			DB_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		prefixed w/DB, underscores and all caps		DB_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBSHUTDOWN_C
#define DBSHUTDOWN_C

/* === System Headers === */

/* === Project Headers === */
#include "db.h"
#include "debug.h"

/* === external routines === */
extern int	DBWriteHash();
extern int	DBFreeHashTable();


/*========================================================================
 *	Name:			DBShutdown
 *	Prototype:	DBShutdown
 *					
 *	Description:
 *		shutdown the database
 *
 *	Input Arguments:
 *	Output Arguments:
 *		None.
 *
 *	Return Values:
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
DBShutdown()
{
	/*
	 * save the hash table to file, then free up its storage
	 */
	DBWriteHash();
	DBFreeHashTable();

	/* is this necessary???
	free_db_Record ( &request );
	free_db_Record ( &req );
	free_db_Record ( &record );
	*/

	/*
	 * database no longer ready for use
	 */
	DB_Init = False;
}

#endif /* DBSHUTDOWN_C */
