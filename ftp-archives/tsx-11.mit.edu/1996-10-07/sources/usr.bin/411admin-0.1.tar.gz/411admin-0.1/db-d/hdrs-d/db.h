/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: db.h
 *            DESCRIPTION: database specific definitions, typdefs, storage,
 *								 : structures, etc.
 *                  NOTES: set tabstops=3 for readability
 *
 * SPECIAL CONSIDERATIONS:
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DB_H
#define DB_H

/*
 * Generic buffer size
 */
#define MAXBUFSIZE		1024

/*
 * Maximum number of fields we'll deal with.
 * This is bad - there shouldn't be a hardcoded value for number of
 * fields, but I got stuck on this while debugging and never went back
 * to fix it.  Bummer.  What should happen is the application tells
 * the db library how many fields it has and the library maintains this
 *	for the length of the execution.  That part is easy to implement
 * but I'm not sure just how embedded this value is - just how many places
 * would be affected by such a change.  Potentially many.
 */
#define DB_MAX_FIELDS		11		


/*
 * FLAGS - these are bit fields because they can be OR'd together
 * for processing by various routines
 */

/*
 * Search types
 */
#define DB_MATCH_ANY					0x00000001
#define DB_MATCH_EXACT				0x00000002
#define DB_MATCH_ALL					0x00000004
#define DB_MATCH_RETURN				0x00000008
#define DB_MATCH_INDEX				0x00000010	/* index field is first field */
#define DB_MATCH_FIELD1				0x00000010
#define DB_MATCH_FIELD2				0x00000020
#define DB_MATCH_FIELD3				0x00000040
#define DB_MATCH_FIELD4				0x00000080
#define DB_MATCH_FIELD5				0x00000100
#define DB_MATCH_FIELD6				0x00000200
#define DB_MATCH_FIELD7				0x00000400
#define DB_MATCH_FIELD8				0x00000800
#define DB_MATCH_FIELD9				0x00001000
#define DB_MATCH_FIELD10			0x00002000
#define DB_MATCH_FIELD11			0x00004000

/*
 * other flags
 */
#define DB_HAS_SUBFIELDS			0x00100000	/* field contains subfields */


/*
 * Field delimeter identifiers - these are not the actual characters
 * used as the delimeters so that minimal recompilation is required to
 * change them, if so desired
 */
#define FIELD			0	/* parser uses semicolon as delimiter */
#define SUBFIELD		1	/* parser uses comma as delimiter */
#define ENDFIELD		2	/* parser uses newline as delimiter */
#define SINGLEFIELD	3	/* parser uses space or newline as delimiter */
#define WORD			4	/* parser pulls a word from a line */
#define USERFIELD		5	/* parser uses user specified delimiter */


/*
 * "Get" types
 */
#define DB_GET_NEXT			1	/* get the next record in the db */
#define DB_GET_PREVIOUS		2	/* get the previous record in the db */
#define DB_GET_FIRST			3	/* get the first record in the db */
#define DB_GET_ANY			4	/* get any matching record in the db */


/*
 * Minimum number of characters required to build a hash name
 */
#define MIN_HASH_LENGTH		4	


/*
 * Global Variables
 */
#ifdef DBINIT_C
char		DB_Name[]="MJDB";			/* name used for DB error reporting */
char		*DB_Filename=NULL;		/* name of flat file */
char		*DB_Hash_Filename=NULL;	/* name of hash file */
char		*DB_Index_Filename=NULL;/* name of index file */
int		DB_Hash_Head;				/* head of hash table link list */
int		DB_Init;						/* True means database ready for use */
int		DB_Hash_Modified;			/* if true, rewrite hash to file */
#else
extern char		*DB_Name;					/* name used for DB error reporting */
extern char		*DB_Filename;           /* name of flat file */
extern char		*DB_Hash_Filename;      /* name of hash file */
extern char		*DB_Index_Filename;     /* name of index file */
extern int		DB_Hash_Head;				/* head of hash table link list */
extern int		DB_Init;						/* True means database ready for use */
extern int		DB_Hash_Modified;			/* if true, rewrite hash to file */
#endif /* DBINIT_C */


/*
 * MACROS
 */

/*
 * Add a Hash Link
 *
 * DB_ADD_HASH_LINK(link, record, rec_ptr, newname, nx, pr)
 * where
 *		link		hash link pointer
 *		record	hash record pointer
 *		rec_ptr	what to put in the record->ptr field
 *		newname	new hash name to be put in record->name
 *		nx			next field for hash link
 *		pr			prev field for hash link
 */
#define DB_ADD_HASH_LINK(link, record, rec_ptr, newname, nx, pr)	\
{																						\
	link = ( HASH_LINK * ) malloc ( sizeof ( HASH_LINK ) );			\
	record = ( HASH_REC * ) malloc ( sizeof ( HASH_REC ) );			\
																						\
	(record)->ptr = rec_ptr;													\
	strcpy ( (record)->name, newname );										\
																						\
	(link)->next = nx;															\
	(link)->prev = pr;															\
	(link)->hash = (int) record;												\
}


/*
 * Fill in an Index Record
 *
 * DB_FILL_INDEX_RECORD(link, dbact, dbnx, dbpr, dbptr, dbbuf)
 * where
 *		link		pointer to an index link
 *		dbact		active field of index record
 *		dbnx		next field of index record
 *		dbpr		prev field of index record
 *		dbptr		ptr field of index record
 *		dbbuf		buffer holding the record that the index record will point
 *					to
 */
#define DB_FILL_INDEX_RECORD(link, dbact, dbnx, dbpr, dbptr, dbbuf)	\
{																							\
	(link)->active = dbact;															\
	(link)->next = dbnx;																\
	(link)->prev = dbpr;																\
	(link)->ptr = dbptr;																\
	(link)->length = strlen(dbbuf);												\
}


/*
 * TYPEDEFS
 */

/*
 * define a structure to hold the index records
 */
typedef struct index_rec {
	int		active;				/* 0=active; 1=deleted */
	int		next;					/* offset into index file for next index */
	int		prev;					/* offset into index file for prev index */
	int		ptr;					/* offset into db file for db record */
	int		length;				/* length of db record */
} INDEX_REC;

/*
 * define a structure to hold a hash record
 */
typedef struct hash_rec {
	char		name[MIN_HASH_LENGTH+1];/* 4 characters plus "\0" */
	int		ptr;							/* offset into index file for index rec */
} HASH_REC;

/*
 * hash table link structure
 */
typedef struct hash_link {
	struct hash_link	*next;			/* next link in list */
	struct hash_link	*prev;			/* previous link in list */
	int					hash;				/* the associated hash record */
} HASH_LINK;


/*
 * Statistics structure
 */
typedef struct db_stat {
	int	ff_length;        /* length, in bytes, of database flat file */
	int	i_length;         /* length, in bytes, of index file */
	int	tot_num_recs;     /* total records in database */
	int	num_act_recs;     /* number of active records in database */
	int	num_inact_recs;   /* number of inactive records */
	int	num_hash;         /* number of hash entries */
	int	perc;             /* percentage of inactive to total records */
} DB_STAT;


/*
 * RETURN CODES FROM DATABASE ROUTINES
 */


/*
 * generic return codes start at 0
 */
#define DB_SUCCESS			0					/* things are ok */
#define DB_FAILURE			DB_SUCCESS+1	/* things are not ok */
#define DB_NOT_INITIALIZED	DB_SUCCESS+2	/* db not initialized */
#define DB_EXIST				DB_SUCCESS+3	/* record already exists */
#define DB_CANT_PARSE		DB_SUCCESS+4	/* can't parse a record */
#define DB_BAD_TYPE			DB_SUCCESS+5	/* an unknown type was specified
														 * by the calling routine
														 */
#define DB_EMPTY_FIELD		DB_SUCCESS+6	/* empty field found during parse */

/*
 * utility related return codes start at 50
 */
#define UTILRC							DB_SUCCESS+50
#define DB_NO_DELIMITER				UTILRC+0		/* no delimeter found in string */
#define DB_UNKNOWN_DELIMITER		UTILRC+1		/* unknown delimeter in request */
#define DB_TOO_MANY_FIELDS			UTILRC+2		/* too many fields in string */
#define DB_MISSING_FIELD			UTILRC+3		/* one of DB_Fields[] is NULL */
#define DB_MISSING_IFIELD			UTILRC+4		/* DB_Fields[0] (index) is NULL */
#define DB_MATCH						UTILRC+5		/* records match compare */
#define DB_NOMATCH					UTILRC+6		/* records do not match compare */
#define DB_NOMATCH_HASH				UTILRC+7		/* records hashes do not match */
#define DB_NULL_STRING				UTILRC+8		/* null string passed as
															 * parameter
															 */
#define DB_NULL_STAT					UTILRC+9		/* NULL ptr to DB_STAT struct */


#define DB_MATCH_ANY_INVALID_REQUEST	UTILRC+49
													/* search request specified
													 * DB_MATCH_ANY as a type, but no
													 * hash or index was supplied
													 */

/*
 * Hash related return codes start at 100
 */
#define HASHRC					DB_SUCCESS+100
#define HASHNOTFOUND			HASHRC+0		/* hash record not found */
#define ENDOFHASHLIST		HASHRC+1		/* the link returned is the last
													 * one in the link list
													 */
#define NEWHEAD				HASHRC+2		/* adding a new head to hash table */
#define NULLHASHTABLE		HASHRC+3		/* no entries in hash table */
#define HASHNULL				HASHRC+4		/* hash head is null, but shouldn't 
													 * be
													 */
#define CORRUPTHASH			HASHRC+5		/* hash table is corrupt */

/*
 * Index related return codes start at 200
 */
#define INDEXRC					DB_SUCCESS+200
#define OPENINDEXFAIL			INDEXRC+0	/* failed to open index file */
#define INDEXLSEEKFAIL			INDEXRC+1	/* seek failed on index file */
#define INDEXREADFAIL			INDEXRC+2	/* failed to read record from index
														 * file
														 */
#define INDEXWRITEFAIL			INDEXRC+3	/* failed to write index record */
#define DB_NULL_STATIC_INDEX	INDEXRC+4	/* static index is NULL */
#define DB_MISSING_INDEX		INDEXRC+5	/* missing an index field */
#define INDEXFAIL					INDEXRC+6	/* general index-related failure */
#define INDEXERR					INDEXRC+7	/* general index-related failure */

#define DB_CANT_STAT_INDEXFILE	INDEXRC+50
														/* stat() of index file failed */

/*
 * Flat file related return codes start at 300
 */
#define FLATFILERC			DB_SUCCESS+300
#define DBOPENFAIL			FLATFILERC+0	/* successful read of record from
														 * flat file
														 */
#define DBLSEEKFAIL			FLATFILERC+1	/* failed to open the flat file */
#define DBREADFAIL			FLATFILERC+2	/* failed to read correct # of
														 * bytes from file
														 */
#define DBWRITEFAIL			FLATFILERC+3	/* failed to write db record */
#define DBFETCHERR			FLATFILERC+4	/* failed to fetch db record */
#define STATDBERR				FLATFILERC+5	/* failed to stat() flat file */


#define DB_CANT_STAT_FLATFILE	FLATFILERC+50
														/* stat() of flat file failed */


#endif /* DB_H */
