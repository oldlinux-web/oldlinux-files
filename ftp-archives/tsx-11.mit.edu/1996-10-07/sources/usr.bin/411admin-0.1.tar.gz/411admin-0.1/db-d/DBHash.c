/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: DBHash.c
 *            DESCRIPTION: hash table routines
 *      DEFINED CONSTANTS: db.h
 *       TYPE DEFINITIONS: db.h
 *      MACRO DEFINITIONS: db.h
 *       PUBLIC FUNCTIONS: DBFreeHashTable, DBBuildHashTable
 *       					 : DBGetHashLink, DBRemoveHashLink
 *       					 : DBGetHashRecord, DBBuildHash
 *      PRIVATE FUNCTIONS: 
 *                  NOTES: set tabstops=3 for readability
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/DB, no underscores, mixed case		DBPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/DB, underscores, mixed case			DB_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBHASH_C
#define DBHASH_C
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>

/* === System Headers === */

/* === Project Headers === */
#include "db.h"
#include "debug.h"

/* === external routines === */
extern void DBMakeLower();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */



/*========================================================================
 *	Name:			DBWriteHash
 *	Prototype:	DBWriteHash()
 *
 *	Description:
 *		write out the hash table to file
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *		int		DB_Hash_Head			head of hash table link list
 *		Boolean	DB_Hash_Modified		if true, hash has been modified
 *		char		*DB_Hash_Filename		name of hash file
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
DBWriteHash ()
{

#ifdef DEBUG
	char			fname[]="DBWriteHash()";
#endif

	HASH_LINK	*current;
	HASH_REC		*hash;
	int			fd;


	DBGEnter();


	if ( ( DB_Hash_Modified == True ) && ( DB_Init == True ) )
	{

		current = (HASH_LINK *) DB_Hash_Head;

		/*
		 * remove the old hash file
		 */
		unlink ( DB_Hash_Filename );

		DBGPrintf ( DBG_INFO, ("opening %s\n", DB_Hash_Filename));

		fd = open ( DB_Hash_Filename, O_WRONLY | O_CREAT | O_APPEND, 0644 );

		DBGPrint( DBG_INFO, "rewriting database hash file\n");

		while ( current != 0 )
		{
			hash = ( HASH_REC * ) current->hash;
			write ( fd, (char *)hash->name, 4 );	/* hash name */
			write ( fd, &hash->ptr, 4 );				/* hash pointer */
			current = current->next;					/* get next link in chain */
		}

		DBGPrint ( DBG_INFO, "closing file\n" );
		close ( fd );
	}

	DBGExit();
}



/*========================================================================
 *	Name:			DBFreeHashTable
 *	Prototype:	DBFreeHashTable()
 *
 *	Description:
 *		free the memory allocated for the hash tables
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *		int	DB_Hash_Head		head of hash table link list
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
DBFreeHashTable ( )
{

#ifdef DEBUG
	char				fname[]="DBFreeHashTable()";
#endif

	HASH_LINK		*current;
	HASH_LINK		*next;
	int				hash;

	DBGEnter();

	current = (HASH_LINK *) DB_Hash_Head;
	
	if ( current != NULL )
	{
		while ( current != 0 )
		{
			hash = current->hash;
			free ( ( HASH_REC * ) hash );	/* free the hash record */ 
			next = current->next;			/* save the next link in chain */
			free ( current );					/* free the current link */
			current = next;
		}
	}

	DBGExit();
}



/*========================================================================
 *	Name:			DBBuildHashTable
 *	Prototype:	int DBBuildHashTable()
 *
 *	Description:
 *		read in the hash files and put them into double linked lists.
 *		"DB_Hash_Head" is a globally defined variable which points to the first
 *		link in the hash table chain.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		DB_SUCCES		successful build of hash table
 *		DB_FAILURE		failure to build hash table
 *							error messages are written to stdout
 *
 *	Global Variables:
 *		int	DB_Hash_Head			head of hash table link list
 *		char	*DB_Hash_Filename		name of hash file
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		This routine is only called by DBInit().
 *		Its arguable if this needs to sort the entries in the hash file
 *		when the hash file is read in, since this file should be guaranteed
 *		to be written in sorted order.
 *		
 *========================================================================*/

int
DBBuildHashTable()
{

#ifdef DEBUG
	char			fname[]="DBBuildHashTable()";
#endif

	int			bytes_read;		/* number of bytes read */
	int			fd;				/* file descriptor for hash file */
	int			last_entry;		/* flag if past last link */
	char			buf[255];		/* place to read into from file */
	char			name[255];		/* current name */
	char			rname[255];		/* name already in table */
	HASH_REC		*hash;			/* hash record */
	HASH_REC		*c_hash;			/* hash record */
	HASH_LINK	*link;			/* a link in the hash table chain */
	HASH_LINK	*tmplink;		/* a link in the hash table chain */
	HASH_LINK	*current;		/* used to search link list */

	DBGEnter();

	/*
	 * open the database hash file
	 */
	if ( ( fd = open ( DB_Hash_Filename, O_RDONLY ) ) == -1 )
	{
		printf(	"%s: Error opening hash file %s: errno= %d\n" 
					"Aborting.\n", DB_Name, DB_Hash_Filename, errno );
		DBGExit();
		return ( DB_FAILURE );
	}


	/*
	 * read in first hash table entry
	 */
	bytes_read = read ( fd, buf, 8 );

	/*
	 * if the hash file is empty then theres not hash table to build
	 */
	if ( bytes_read == 0 )
	{
		DB_Hash_Head = (int) NULL;
		close ( fd );
		DBGExit();
		return ( DB_SUCCESS );

	}
	else
	{
		/*
		 * if the hash table has a blank name (all spaces) then we
		 * don't have to build the hash table - this would be the
		 * entry added when the file was created.
		 */
		if ( bytes_read == 8 )
		{
			bcopy ( buf, name, 4 );
			bcopy ( "\0", name+4, 4 );
			if ( strcmp ( name, "    " ) == 0 )
			{
				DB_Hash_Head = (int) NULL;
				DBGExit();
				return ( DB_SUCCESS );
			}
		}

		/*
		 * improperly formed entry - this should never happen
		 */
		else
		{
			printf ( 
				"%s: Error reading in initial hash file record\n"
				"to build database hash table. "
				"Aborting.\n", DB_Name );
			DBGExit();
			return ( DB_FAILURE );
		}
	}


	/*
	 * If we've gotten this far then we have valid entries in the
	 * hash file so we've got to build the hash table link list
	 */


	/*
	 * alocate a hash table structure
	 */
	link = ( HASH_LINK * ) malloc ( sizeof ( HASH_LINK ) );
	link->hash = (int) malloc ( sizeof ( HASH_REC ) );
	hash = ( HASH_REC * ) link->hash;

	/*
	 * initialize link pointers to 0
	 */
	link->next = 0;
	link->prev = 0;

	/*
	 * stuff hash file entry into hash table link
	 */
	bcopy ( buf, (char *) hash->name, 4 );
	bcopy ( "\0", (char *) ( hash->name + 4 ), 1 );
	bcopy ( (char *) ( buf + 4 ), (char *) &(hash->ptr), 4 );

	/*
	 * set chain head to point to this first link
	 */
	DB_Hash_Head = (int) link;

	/*
	 * get next hash entry from file
	 */

	/* while not end of file */
	while ( (bytes_read = read ( fd, buf, 8 ) ) > 0 )
	{

		/*
		 * alocate a hash table structure
		 */
		link = ( HASH_LINK * ) malloc ( sizeof ( HASH_LINK ) );
		link->hash = (int)  malloc ( sizeof ( HASH_REC ) );
		hash = ( HASH_REC * ) link->hash;

		/*
		 * stuff hash file entry into hash table link
		 */
		bcopy ( buf, (char *) hash->name, 4 );
		bcopy ( "\0", (char *) ( hash->name + 4 ), 1 );
		bcopy ( (char *) ( buf + 4 ), (char *) &(hash->ptr), 4 );

		/*
		 * start at head of link list
		 */
		current = ( HASH_LINK * )DB_Hash_Head;
		c_hash = ( HASH_REC *) current->hash;

		/*
		 * get copy of name we can use to convert to lowercase
		 */
		strcpy ( rname, c_hash->name );
		DBMakeLower ( rname );

		/*
		 * get copy of name we can use to convert to lowercase
		 */
		strcpy ( name, hash->name );
		DBMakeLower ( name );

		/*
		 * set last_entry flag to 0 (ie we're not at end of list)
		 */
		last_entry = 0;

		/*
		 * run through link list until we find a name that is 
		 * alphabetically greater than the current name or we run 
		 * past the end of the list
		 */
		while ( strcmp ( name, rname ) > 0 )
		{
			if ( current->next != 0 )
			{
				current = current->next;
				c_hash = ( HASH_REC *) current->hash;
				strcpy ( rname, c_hash->name );
				DBMakeLower ( rname );
			}
			else
			{
				last_entry = 1;
				break;
			}
		}

		/*
		 * if we went past end of list, add the new link at end
		 */
		if ( last_entry == 1 )
		{
			current->next = link;
			link->prev = current;
			link->next = 0;
		}
		else
		{
			link->next = current;
			link->prev = current->prev;
			if ( current->prev != 0 )
			{
				tmplink = current->prev;
				tmplink->next = link;
			}
			else
				DB_Hash_Head = (int) link;

			current->prev = link;
		}

	}

	DBGExit();
	return ( DB_SUCCESS );

}



/*========================================================================
 *	Name:			DBBuildHash
 *	Prototype:	DBBuildHash( char *last, HASH_REC *hash )
 *
 *	Description:
 *		build a hash entry (4 character name)
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
DBBuildHash ( 
	char		*last,	/* last name used to build hash */
	HASH_REC	*hash 	/* hash record to be filled */
)	
{

#ifdef DEBUG
	char	fname[]="DBBuildHash()";
#endif

	int	l_length;		/* length of last name */

	DBGEnter();
	DBGPrintf(DBG_INFO, ("index field: \"%s\"\n", last) );

	/*
	 * get the hash portion of the name
	 */
	l_length = strlen ( last );
	if ( l_length > MIN_HASH_LENGTH-1 )
		bcopy ( last, (char *)hash->name, MIN_HASH_LENGTH );
	else
	{
		strcpy ( hash->name, last );
		strncat ( hash->name, "     ", MIN_HASH_LENGTH - l_length );
	}

	bcopy ( "\0", (char *)((hash->name)+MIN_HASH_LENGTH), 1 );

	DBGExit();
}



/*========================================================================
 *	Name:			DBGetHashRecord
 *	Prototype:	int DBGetHashRecord( HASH_REC *hash )
 *
 *	Description:
 *		retrieve the specified hash record from the hash table and fill in 
 *		the index pointer value in the hash record structure
 *
 *	Input Arguments:
 *		HASH_REC *hash			hash->name is name to look up in the tables
 *
 *	Output Arguments:
 *		HASH_REC *hash			hash->ptr is offset into index for this hash
 *
 *	Return Values:
 *		DB_SUCCESS				found record
 *		DB_HASHNOTFOUND		record not found				
 *
 *	Global Variables:
 *		int	DB_Hash_Head		head of hash table link list
 *
 *	External Routines:
 *		void DBMakeLower();
 *
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
int
DBGetHashRecord ( 
	HASH_REC	*hash 		/* pointer to hash record */
)
{

#ifdef DEBUG
	char			fname[]="DBGetHashRecord()";
#endif

	char			name[15];		/* name from hash record read in */
	char			req_name[15];	/* copy of requests hash name */
	HASH_LINK	*current;		/* current hash table link */
	HASH_REC		*hash_rec;		/* hash record in hash table link */

	DBGEnter();

	/*
	 * get a lowercase copy of the requested name
	 */
	strcpy ( req_name, hash->name );
	DBMakeLower ( req_name );

	/*
	 * get the first link in the hash table
	 */
	current = (HASH_LINK *) DB_Hash_Head;

	if ( current == NULL )
	{
		DBGExit();
		return ( NULLHASHTABLE );
	}

	while ( current != 0 ) {

		/*
		 * grab the hash record in the hash table link
		 */
		hash_rec = ( HASH_REC * ) current->hash;

		/*
		 * copy the name portion of the record to temporary storage 
		 */
		strcpy ( name, hash_rec->name );
		DBMakeLower ( name );

		DBGPrintf ( DBG_INFO, 
			("record hash: %s\trequest hash: %s\n", name, req_name) );

		/*
		 * compare hash record to requested hash
		 */
		if ( (int) strcmp ( name, req_name ) == 0 ) {

			/*
			 * if they match, save hash records pointer back to caller
			 */
			hash->ptr = hash_rec->ptr;

			/*
			 * and return DB_SUCCESS, so user knows all went well
			 */
			DBGExit();
			return ( DB_SUCCESS );
		}
		else
			current = current->next;
	}

	/*
	 * no matching entry found
	 */
	DBGPrintf ( DBG_INFO, 
		(	"\n\tEnd of hash file reached\n"
			"\tNo hash record found to match request string\n") );

	DBGExit();
	return ( HASHNOTFOUND );

}



/*========================================================================
 *	Name:			DBGetHashLink
 *	Prototype:	int DBGetHashLink( HASH_REC *hash, HASH_LINK **link )
 *
 *	Description:
 *		retrieve the specified hash link from the hash table 
 *
 *	Input Arguments:
 *		HASH_REC *hash			hash->name is name to look up in the tables
 *
 *	Output Arguments:
 *		HASH_LINK **link	 	The value of link depends on the return code
 *
 *	Return Values:
 *		Value:											Link is:
 * 	DB_MATCH (hash->name already exists)	index of matching hash entry
 *		DB_NOMATCH ( but not head of list )		index of hash record that is
 *															lexicographically greatest but
 *															less than hash->name
 *		ENDOFHASHLIST 									index of last hash rec
 *		NEWHEAD											index of first hash rec
 *		NULLHASHTABLE									there aren't any entries in
 *															the hash table
 *
 *	Global Variables:
 *		int	DB_Hash_Head		head of hash table link list
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
int
DBGetHashLink(
	HASH_REC		*hash,		/* pointer to hash record */
	HASH_LINK	**link 		/* hash table link */
)
{

#ifdef DEBUG
	char			fname[]="DBGetHashLink()";
#endif

	char			name[15];		/* name from hash record read in */
	char			req_name[15];	/* copy of requests hash name */
	HASH_LINK	*current;		/* current hash table link */
	HASH_LINK	*prev=NULL;		/* previous hash table link */
	HASH_REC		*hash_rec;		/* hash record in hash table link */
	int			match;			/* return code */

	DBGEnter();

	/*
	 * convert request to lowercase for comparisons
	 */
	strcpy ( req_name, hash->name );
	DBMakeLower ( req_name );

	/*
	 * get the first link in the hash table
	 */
	current = (HASH_LINK *) DB_Hash_Head;

	/*
	 * if the hash table is null, return to caller
	 */
	if ( current == NULL )
	{
		DBGExit();
		return ( NULLHASHTABLE );
	}

	while ( current != 0 )
	{

		/*
		 * grab the hash record in the hash table link
		 */
		hash_rec = ( HASH_REC * ) current->hash;

		/*
		 * copy the name portion of the record to temporary storage 
		 */
		strcpy ( name, hash_rec->name );
		DBMakeLower ( name );
		DBGPrintf ( DBG_INFO, 
			("record hash: %s  request hash: %s\n", name, req_name) );

		/*
		 * compare hash record to requested hash
		 */
		if ( (int) strcmp ( name, req_name ) < 0 )
		{
			prev = current;				/* save the old one */
			current = current->next;	/* get the new one */
		}

		else
		{

			DBGPrintf ( DBG_INFO, ("previous link: 0x%08x\n", (int) prev) );
			DBGPrintf ( DBG_INFO, ("current link: 0x%08x\n", (int) current) );

			/*
			 * if the requested name is > or = to the table entry
			 * return the link pointer and set the appropriate return code
			 */

			if ( (int) strcmp ( name, req_name ) == 0 )
			{
				DBGPrint( DBG_INFO, 
					"request matches current hash table entry\n");

				/*
				 * in this case, hash_rec points to the hash record that 
				 * is equal the requested hash
				 */
				match = DB_MATCH;
				*link = current;
				hash_rec = ( HASH_REC * ) current->hash;
				hash->ptr = hash_rec->ptr;
			}
			else
			{
				if ( current->prev != 0 )
				{
					DBGPrint( DBG_INFO, 
						"request > current hash table entry; returning prev ptr\n");

					/*
					 * in this case hash_rec points to the record that
					 * would precede the new hash
					 */
					match = DB_NOMATCH;
					*link = current;
					prev = current->prev;
					hash_rec = ( HASH_REC * ) prev->hash;
					hash->ptr = hash_rec->ptr;
					DBGPrintf(DBG_INFO,
						("\n\tlink     = 0x%08x\n"
							"\thash_rec = 0x%08x\n"
							"\thash->ptr= 0x%08x\n",
							link, hash_rec, hash->ptr ) );
				}
				else
				{
					DBGPrint( DBG_INFO, 
						"request > current hash table entry; returning current ptr\n");
					/*
					 * in this case hash_rec points to the hash record that
					 * would follow the new hash record
					 */
					match = NEWHEAD;
					*link = current;
					hash_rec = ( HASH_REC * ) current->hash;
					hash->ptr = hash_rec->ptr;
				}
			}

			DBGExit();
			return ( match );
		}
	}

	/*
	 * no matching entry found, point to last link in list
	 */
	DBGPrintf( DBG_INFO, 
		("End of hash file reached.\n"
		 "No hash record found to match request string.\n"
		 "Addresses\n\tname: %x\n\treq_name: %x\n\tprev: %x\n", 
		(unsigned int) name, (unsigned int) req_name, (unsigned int) prev) );


	/*
	 * "prev" must have been set or we would have returned to the caller
	 * already
	 */
	*link = prev;
	hash_rec = ( HASH_REC * ) prev->hash;
	hash->ptr = hash_rec->ptr;

	DBGExit();
	return ( ENDOFHASHLIST );

}



/*========================================================================
 *	Name:			DBRemoveHashLink
 *	Prototype:	int DBRemoveHashLink( HASH_LINK *link )
 *
 *	Description:
 *		removes a link from the hash tables
 *
 *	Input Arguments:
 *		HASH_LINK *link		link to remove from list
 *
 *	Output Arguments:
 *	Return Values:
 *		DB_SUCCESS.
 *
 *	Global Variables:
 *		int	DB_Hash_Head		head of hash table link list
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
int
DBRemoveHashLink ( 
	HASH_LINK *link 	/* link to remove */
)
{

#ifdef DEBUG
	char			fname[]="DBRemoveHashLink()";
#endif

	HASH_LINK	*prev_link;
	HASH_LINK	*next_link;
	HASH_REC		*hash_rec;

	DBGEnter();

	if ( link->prev == 0 )
	{
		DB_Hash_Head = (int) link->next;
	}
	else
	{
		prev_link = ( HASH_LINK * ) link->prev;
		prev_link->next = link->next;
	}

	if ( link->next != 0 )
	{
		next_link = ( HASH_LINK * ) link->next;
		next_link->prev = link->prev;
	}

	hash_rec = ( HASH_REC * ) link->hash;
	free ( hash_rec );
	free ( link ); 

	DBGExit();
	return ( DB_SUCCESS );
}


#endif /* DBHASH_C */
