/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: DBInit.c
 *            DESCRIPTION: initialize flat file database
 *      DEFINED CONSTANTS: defined in db.h
 *       TYPE DEFINITIONS: defined in db.h
 *      MACRO DEFINITIONS: defined in db.h
 *       GLOBAL VARIABLES: defined in db.h
 *       PUBLIC FUNCTIONS: DBInit
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/DB, no underscores, mixed case		DBPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/DB, underscores, mixed case			DB_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		prefixed w/DB, underscores and all caps		DB_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBINIT_C
#define DBINIT_C

/* === System Headers === */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <stdlib.h>

/* === Project Headers === */
#include "db.h"
#include "debug.h"

/* === external routines === */
extern int DBBuildHashTable();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
char		*DB_Fields[DB_MAX_FIELDS];	/* the fields from the record */


/*========================================================================
 *	Name:			DBInit
 *	Prototype:	DBInit(char *directory, char *dbfile, char *hashfile,
 *						char *indexfile)
 *					
 *	Description:
 *		Initializes the flat file database and its associated hash and
 *		index files
 *
 *	Input Arguments:
 *		char	*directory		full path to directory which contains
 *									database files
 *		char	*dbfile			name of database flat file
 *		char	*hashfile		suffix which is appended to dbfile for hash
 *									file
 *		char	*indexfile		suffix which is appened to dbfille for index
 *									file
 *		
 *	Output Arguments:
 *		None.
 *
 *	Return Values:
 *		DB_SUCCESS				initialization completed successfully
 *		DB_FAILURE				initialization failed
 *
 *	Global Variables:
 *
 *	External Routines:
 *
 *	Method:
 *
 *	Restrictions:
 *
 *	Notes:
 *		
 *========================================================================*/
int
DBInit(
	char	*directory,
	char	*dbfile,
	char	*hashfile,
	char	*indexfile
)
{

#ifdef DEBUG
	char				fname[]="DBInit()";
#endif

	struct stat		stat_buf;				/* file info structure */
	char				buf[MAXBUFSIZE];		/* generic buffer */
	int				fd;						/* generic file descriptor */
	int				db_exist;
	int				bytes, i;

	/*
	 * initialize some global flags
	 */
	DB_Init = False;
	DB_Hash_Modified = False;

	/*
	 * initialize the array of character pointers which will be the fields
	 * of the record
	 */
	for ( i=0; i < DB_MAX_FIELDS; i++ )
		DB_Fields[i]=NULL;


	/*
	 * database file must exist, even if empty
	 */

	/*
	 * assume it doesn't
	 */
	db_exist = FALSE;

	/* 
	 * build the full path name to the database file
	 */
	sprintf( buf, "%s/%s", directory, dbfile );
	DB_Filename = (char *) malloc ( strlen ( buf ) + 1);
	strcpy ( DB_Filename, buf );

	/* 
	 * build the full path name to the hash file
	 */
	sprintf( buf, "%s/%s.%s", directory, dbfile, hashfile );
	DB_Hash_Filename = (char *) malloc ( strlen ( buf ) + 1);
	strcpy ( DB_Hash_Filename, buf );

	/* 
	 * build the full path name to the index file
	 */
	sprintf( buf, "%s/%s.%s", directory, dbfile, indexfile );
	DB_Index_Filename = (char *) malloc ( strlen ( buf ) + 1);
	strcpy ( DB_Index_Filename, buf );

	/*
	 * check if it exists
	 */
	if ( stat ( DB_Filename, &stat_buf ) == -1 )
	{
		switch ( errno )
		{

			case ENOTDIR:
				/*
				 * this should never happen - we would have caught it
				 * earlier
				 */
				printf ( "%s: The path to %s does not exist.  Aborting.",
					DB_Name, DB_Filename );
				return ( DB_FAILURE );
				break;


			case ENOENT:
				/*
				 * if the database didn't exist, we need to make empty
				 * hash and index files to accompany an empty database
				 */
				DBGPrint (DBG_INFO, "Database didn't exist.  Creating\n");
				DBGPrint (DBG_INFO, "empty database, index and hash files.\n");

				/*
				 * open the database file, then close it, just to create it
				 */
				if (( fd = open( DB_Filename, O_CREAT | O_EXCL, 0700 ) ) == -1 )
				{
					perror ( "database file open failure" );
					printf ("%s: Can't create database flat file: %s\n"
						"Aborting.\n",
						DB_Name, DB_Filename );
					return ( DB_FAILURE );
				}
				else
					close ( fd );

				/*
				 * create the hash file, with one dummy record
				 */
				if ( (fd = open ( DB_Hash_Filename, O_WRONLY | O_CREAT, 0644 )) 
								== -1 )
				{
					perror ( "hash file open failure" );
					printf ("%s: Can't open hash file: %s\n"
						"Aborting.\n",
						DB_Name, DB_Hash_Filename );
					return ( DB_FAILURE );
				}

				sprintf( buf, "    " );
				bytes = write ( fd, buf, 4 );
				DBGPrintf ( DBG_INFO, ("bytes written to hash file: %d\n", bytes));

				bytes = 0;
				bytes = write ( fd, &bytes, 4 );
				DBGPrintf ( DBG_INFO, ("bytes written to hash file: %d\n", bytes));

				close ( fd );

				/*
				 * create the index file
				 */
				if (( fd = open( DB_Index_Filename, O_CREAT | O_EXCL, 0700 ) ) 
								== -1 )
				{
					perror ( "index file open failure" );
					printf ("%s: Can't create index file: %s\n" 
						"Aborting.\n",
						DB_Name, DB_Index_Filename );
					return ( DB_FAILURE );
				}
				else
					close ( fd );

				break;

			default:
				printf ( "%s: Failed to stat %s - errno: %d.  Aborting.",
					DB_Name, DB_Filename, errno );
				return ( DB_FAILURE );
				break;

		}
	}
	else
		/*
		 * the database already exists
		 */
		db_exist = TRUE;


	/*
	 * if database file existed, hash and index files must already be there
	 */
	if ( db_exist == TRUE )
	{

		DBGPrint (DBG_INFO,
			"Database exists.  Validating index and hash files.\n");

		/*
		 * check for index file
		 */
		if ( stat ( DB_Index_Filename, &stat_buf ) == -1 )
		{
			if ( errno == ENOENT )
			{
				printf ( "%s: Database Index file - %s - does not exist.\n"
					"Aborting.\n" ,
					DB_Name, DB_Index_Filename);
				return ( DB_FAILURE );
			}
			else
			{
				printf ( "%s: Failed to stat %s - errno: %d.  Aborting.",
					DB_Name, DB_Index_Filename , errno );
				return ( DB_FAILURE );
			}
		}

		/*
		 * if the index file is there ...
		 */
		else
		{

			/*
			 * make sure its at least long enough for one index record
			 */
			if ( ( stat_buf.st_size < 20 ) && ( stat_buf.st_size > 0 ) )
			{
				printf ( "%s: Index file (%s) exists, but must have corrupt data.\n",
					DB_Name, DB_Index_Filename);
				printf ( "Its length is less than a single index record.\n");
				return ( DB_FAILURE );
			}
		}


		/*
		 * check for hash file
		 */
		if ( stat ( DB_Hash_Filename, &stat_buf ) == -1 )
		{
			if ( errno == ENOENT )
			{
				printf ( "%s: Database Hash file - %s", 
					DB_Name, DB_Hash_Filename );
				printf ( " - does not exist.  Aborting.\n" );
				return ( DB_FAILURE );
			}
			else
			{
				printf ( "%s: Failed to stat %s - errno: %d.  Aborting.",
					DB_Name, DB_Hash_Filename , errno );
				return ( DB_FAILURE );
			}
		}


		/*
		 * if the hash file is there ...
		 */
		else
		{

			/*
			 * if its there it would be possible for it to be empty,
			 * probably because the user added some records to a new 
			 * database, then removed them all
			 */
			if ( stat_buf.st_size < 0 ) {
				printf ( "%s: Hash file size is < 0.\n", DB_Name);
				printf ( "Hash file appears to be corrupt.\n");
				return ( DB_FAILURE );
			}
		}

	}	/* end of "if db_exist == TRUE" */
	DBGPrint (DBG_INFO, "Index and hash files ok.\n");

	/*
	 * Build the internal hash table from the hash file.
	 * if this fails, errors will be reported in the called
	 * routine so we just need to return a failure to our
	 * caller.
	 */
	if ( DBBuildHashTable() != DB_SUCCESS )
		return ( DB_FAILURE );
	else
	{
		/*
		 * we're up and running
		 */
		DB_Init=True;
		return ( DB_SUCCESS );
	}

}

#endif /* DBINIT_C */
