/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: DBUtil.c
 *            DESCRIPTION: generic utilities for the database library
 *      DEFINED CONSTANTS: defined in db.h
 *       TYPE DEFINITIONS: defined in db.h
 *      MACRO DEFINITIONS: defined in db.h
 *       GLOBAL VARIABLES: defined in db.h
 *       PUBLIC FUNCTIONS: DBMakeLower, DBParseBuf
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/DB, no underscores, mixed case		DBPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/DB, underscores, mixed case			DB_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		prefixed w/DB, underscores and all caps		DB_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBUTIL_C
#define DBUTIL_C

/* === System Headers === */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* === Project Headers === */
#include "db.h"
#include "debug.h"


/*========================================================================
 *	Name:			DBMakeLower
 *	Prototype:	DBMakeLower( char *buf )
 *
 *	Description:
 *		convert a string to lowercase
 *
 *	Input Arguments:
 *		char *buf			string to convert
 *
 *	Output Arguments:
 *	Return Values:
 *	Global Variables:
 *		None.
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		The string is converted in place.
 *		
 *========================================================================*/
void
DBMakeLower ( 
	char *buf 
)
{
	int	i;
	char	ch1,ch2;
	int	length;


	length = strlen( buf );

	for ( i = 0; i < length; i++ )
	{
		strncpy ( (char *)&ch1, buf,1 );
		ch2 = tolower ( ch1 ); 
		strncpy ( buf, (char *)&ch2, 1 );
		buf++;
	}
}



/*========================================================================
 *	Name:			DBParseBuf
 *	Prototype:	DBParseBuf(char *oldbuf, char **newbuf, int type, char *field)
 *
 *	Description:
 *		parses a "field" from a buffer.  "Field" delimiter is determined
 *		by the "type".  Old buffer is updated in place.
 *
 *	Input Arguments:
 *		char	*oldbuf			string to be parsed
 *		int	type				delimiter type to be used
 *									one of FIELD, SUBFIELD, ENDFIELD, SINGLEFIELD,
 *									WORD, or USERFIELD
 *		char	*field			user defined delimeter, if type is USERFIELD
 *									only the first character is used as a delimiter
 *
 *	Output Arguments:
 *		char	**newbuf			where parsed string is put.  Storage for string
 *									is allocated by this routine, but the caller is
 *									responsible for freeing it up.
 *
 *	Return Values:
 *		DB_SUCCESS				string parsed successfully
 *		DB_NO_DELIMITER		delimiter of "type" was not found in oldbuf
 *									newbuf and oldbuf are not changed
 *		DB_UNKNOWN_DELIMITER	"type" is unknown, newbuf and oldbuf not changed
 *		DB_EMPTY_FIELD			the field parsed had no characters in it
 *									(ie the first character in oldbuf was the
 *									delimiter)
 *
 *	Global Variables:
 *		None.
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		The oldbuf is updated with the parsed string removed.
 *		Upon successful completion, newbuf will point to an allocated block
 *		of storage with the parsed string.  It is the callers responsibility
 *		to free this storage.
 *		
 *========================================================================*/
int
DBParseBuf (
	char	*oldbuf,
	char	**newbuf,
	int	fieldtype,
	char	*field
)
{

#ifdef DEBUG
	char	fname[]="DBParseBuf()";
#endif

	int	length;
	char	*ptr, *newstring;
	char	delimiter;	


	DBGPrint(DBG_PARSE, "Entered Routine");
	DBGPrintf(DBG_PARSE, ("oldbuf= \"%s\"\n", oldbuf) );

	switch ( fieldtype )
	{
		case FIELD:	
			bcopy ( ";", &delimiter, 1 );
			break;

		case SUBFIELD:
			bcopy ( ":", &delimiter, 1 );
			break;

		case ENDFIELD:
			bcopy ( "\n", &delimiter, 1 );
			break;

		case SINGLEFIELD:
			bcopy ( "\n", &delimiter, 1 );
			break;

		case WORD:
			bcopy ( " ", &delimiter, 1 );
			break;

		case USERFIELD:
			if ( field != NULL )
				bcopy ( field, &delimiter, 1 );
			else
				return ( DB_NO_DELIMITER );
			break;

		default:
			return ( DB_UNKNOWN_DELIMITER );
			break;
	}

	/*
	 * get a pointer to the delimiter, if there is one
	 */
	DBGPrint(DBG_PARSE, "strchr()\n");
	if ( ( ptr = strchr( oldbuf, delimiter ) ) != NULL )
	{


		/*
		 * How long is the substring?  If its zero length then
		 * pull the delimiter out and tell the user there was an
		 * empty field there.
		 */
		if ( (length = (int)ptr - (int)oldbuf) == 0 )
		{
			/*
			 * make the new buffer NULL
			 */
			DBGPrint(DBG_PARSE, "*newbuf = NULL\n");
			*newbuf = NULL;

			/*
			 * update the original by removing the delimiter
			 */

			/*
			 * Maximum size of the new "oldbuf" is the size of the original
			 * so allocate that much space.
			 */
			DBGPrint(DBG_PARSE, "allocating newsting\n");
			length = strlen ( oldbuf );
			newstring = (char *) malloc ( length + 1 );
			bzero ( newstring, length + 1 );

			/*
			 * Copy the new string from the old buffer into the temporary
			 * storage.
			 */
			DBGPrint(DBG_PARSE, "copying in newstring\n");
			strcpy ( newstring, (char *)(ptr + 1) );

			/*
			 * Clean out the "oldbuf" and then copy in the updated string
			 */
			DBGPrint(DBG_PARSE, "clean out and copy to oldbuf\n");
			bzero ( oldbuf, length );
			strcpy ( oldbuf, newstring );

			/*
			 * And clean up the temporary storage
			 */
			DBGPrint(DBG_PARSE, "free newstring\n");
			free ( newstring );
			newstring = NULL;

			DBGPrint(DBG_PARSE, "Exiting Routine");
			return ( DB_EMPTY_FIELD );
		}

		/*
		 * Allocate a buffer for it, and fill it with null characters
		 */
		DBGPrint(DBG_PARSE, "allocat newbuf\n");
		*newbuf = (char *) malloc ( length + 1 );
		bzero ( (char *)(*newbuf), length + 1 );

		/*
		 * Copy the substring into the new buffer 
		 */
		DBGPrint(DBG_PARSE, "copy into newbuf\n");
		bcopy ( oldbuf, (char *) (*newbuf), length );

		/*
		 * Update the original by removing the substring
		 * strcpy() can cause seg faults if you try to copy from the
		 * end of one string to the beginning of the same string, so 
		 * we'll do this in a two step process.
		 */

		if ( strlen(ptr) > 1 )
		{

			/*
			 * Maximum size of the new "oldbuf" is the size of the original
			 * so allocate that much space.
			 */
			DBGPrint(DBG_PARSE, "allocating newsting\n");
			length = strlen ( oldbuf );
			newstring = (char *) malloc ( length + 1 );
			bzero ( newstring, length + 1 );
	
			/*
			 * Copy the new string from the old buffer into the temporary
			 * storage.
			 */
			DBGPrint(DBG_PARSE, "copying in newstring\n");
			strcpy ( newstring, (char *)(ptr + 1) );
	
			/*
			 * Clean out the "oldbuf" and then copy in the updated string
			 */
			DBGPrint(DBG_PARSE, "clean out and copy to oldbuf\n");
			bzero ( oldbuf, length );
			strcpy ( oldbuf, newstring );
	
			/*
			 * And clean up the temporary storage
			 */
			DBGPrintf(DBG_PARSE, ("free newstring: 0x%08x\n", (int) newstring) );
			free ( newstring );
			newstring = NULL;
	
			/*
			 * tell the caller things went ok
			 */
			DBGPrint(DBG_PARSE, "Exiting Routine");
			return ( DB_SUCCESS );
		}
		else
		{
			/*
			 * ptr pointed to the end of the string (or last delimiter with
			 * no trailing newlines) so just empty out the original string
			 */
			length = strlen ( oldbuf );
			bzero ( oldbuf, length );
			DBGPrint(DBG_PARSE, "Exiting Routine");
			return ( DB_SUCCESS );
		}
	}
	else
	{
		DBGPrint(DBG_PARSE, "Exiting Routine");
		return ( DB_NO_DELIMITER );
	}
}


#endif /* DBUTIL_C */
