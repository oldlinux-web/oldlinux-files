/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: DBSearch.c
 *            DESCRIPTION: search for a record in the database
 *      DEFINED CONSTANTS: defined in db.h
 *       TYPE DEFINITIONS: defined in db.h
 *      MACRO DEFINITIONS: defined in db.h
 *       GLOBAL VARIABLES: defined in db.h
 *       PUBLIC FUNCTIONS: DBSearchDB, DBCompare, DBCompareFields
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/DB, no underscores, mixed case		DBPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/DB, underscores, mixed case			DB_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		prefixed w/DB, underscores and all caps		DB_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBSEARCH_C
#define DBSEARCH_C

/* === System Headers === */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* === Project Headers === */
#include "db.h"
#include "debug.h"

/* === external routines === */
extern int	DBGetIndexRecord();
extern int	DBGetHashLink();
extern int	DBGetDBRecord();
extern void DBMakeLower();
extern void DBBuildHash();
extern int	DBParseBuf();

/* === Public routine prototypes === */
int DBCompare();
int DBCompareFields();

/* === Global Variables === */
extern char		*DB_Fields[DB_MAX_FIELDS];	/* the fields from the record */


/*========================================================================
 *	Name:			DBSearchDB
 *	Prototype:	DBSearchDB(int type, HASH_REC *request_hash, 
 *								INDEX_REC *request_index, char *return_record)
 *					
 *	Description:
 *		Searches the database for a record.
 *
 *	Input Arguments:
 *		int			type				one or more of
 *											DB_MATCH_ANY, DB_MATCH_EXACT, DB_MATCH_ALL,
 *											DB_MATCH_FIELDx (x = 1 to DB_MAX_FIELDS),
 *											DB_MATCH_RETURN, DB_MATCH_INDEX,
 *											DB_HAS_SUBFIELDS
 *		HASH_REC		*request_hash	hash record to be used for search
 *		INDEX_REC	*request_index	index recrd to be used for search
 *		
 *	Output Arguments:
 *		char	**return_record	matching record, or NULL if no record found
 *
 *	Return Values:
 *		DB_EXIST					record found; return_record points to record
 *		DB_FAILURE				errors encountered in DBSearchDB
 *		DB_MISSING_IFIELD		DB_Fields[0] is NULL
 *		DB_MATCH_ANY_INVALID_REQUEST
 *									DB_ANY type specified, but no hash or index provided
 *		DB_MATCH					records match compare criteria
 *
 *		DBGetIndexRecord return values:
 *		OPENINDEXFAIL			failed to open the index file
 *		INDEXLSEEKFAIL			failed to seek to location specified in hash
 *									record
 *		INDEXREADFAIL			failed to read the record from index file
 *
 *		DBGetDBRecord return values:
 *		DBOPENFAIL				failed to open the flat file
 *		DBLSEEKFAIL				failed lseek into the flat file
 *		DBREADFAIL				failed to read correct # of bytes from file
 *
 *	Global Variables:
 *		char	*DB_Fields[]	contains the fields which are used as search
 *									criteria if search type requires it
 *
 *	External Routines:
 *		DBCompare, DBGetIndexRecord, DBGetDBRecord, DBBuildHash
 *
 *	Method:
 *
 *	Restrictions:
 *
 *	Notes:
 *		DBSearchDB is not part of the API.  It should only be called from
 *		one of the API routines.
 *
 *		If a record is found and the caller requests the record be returned
 *		it will be returned in the return_record field.  It is the callers
 *		responsibility to free up the storage associated with that record.
 *
 *		The type field is interpreted in this way:
 *		DB_MATCH_INDEX		Use the index field to find the record.
 *								This is equivalent to DB_MATCH_FIELD1.
 *		DB_MATCH_ANY		Either the request_hash or the request_index
 *								must be non-NULL and contain a record to search
 *								for.  The request_hash is checked first.  If its
 *								non-NULL then the first record which matches the hash
 *								is returned.  If it is NULL then the request_index
 *								is used.  The record pointed to by this index is
 *								returned.  If both are NULL, DBSearchDB() returns
 *								DB_INVALID_REQUEST.  All other types are ignored
 *								if DB_MATCH_ANY is specified.
 *		DB_MATCH_EXACT		If specified, the fields must match exactly,
 *								otherwise the request field can be a substring
 *								of the database record.
 *		DB_MATCH_ALL		The request_hash and request_index records are ignored
 *								and all non-NULL fields in DB_Fields[] are used as 
 *								search criteria.  All other types are ignored (except 
 *								DB_MATCH_EXACT).
 *		DB_MATCH_FIELDx	Field x [1 to DB_MAX_FIELDS] is used as a search 
 *								criteria.   The DB_Fields[] array is used with 
 *								DB_Fieldx as an index.
 *		DB_MATCH_RETURN	If specified, the record found in the db is
 *								returned to the caller.
 *		DB_HAS_SUBFIELDS	processed by DBCompare(), if applicable
 *		
 *========================================================================*/
int
DBSearchDB(
	int			type,
	HASH_REC		*request_hash,
	INDEX_REC	*request_index,
	char			**return_record
)
{

#ifdef DEBUG
	char			fname[]="DBSearchDB()";
#endif

	HASH_REC		hash, *tmp_hash;	/* a hash record */
	HASH_LINK	*hash_link;			/* a hash record */
	INDEX_REC	index;				/* an index record */
	char			*db;					/* db record */
	int			rc;					/* return codes */


	DBGEnter();

	/*
	 * If DB_MATCH_ANY specified, then the caller wants to use either
	 * the request_hash or the request_index field as the search criteria.
	 */
	if ( type & DB_MATCH_ANY )
	{
		DBGPrint( DBG_INFO, "DB_MATCH_ANY specified by caller\n" );

		/*
		 * if the request_hash is specified, use that
		 */
		if ( request_hash != NULL )
		{
			DBGPrintf(DBG_INFO,
					("looking for index to\n"
					"   request_hash->name: %s\n", 
					request_hash->name) );

			/*
			 * get the index record
			 */
			if ( (rc = DBGetIndexRecord( request_hash, &index ) ) != DB_SUCCESS )
			{
				/*
				 * No index record for this hash!
				 * Thats bad, but let the caller deal with it.
				 */
				if ( type & DB_MATCH_RETURN )
					*return_record = NULL;
				DBGExit();
				return ( rc );
			}
	
			/*
			 * get the database record
			 */
			if ( ( rc = DBGetDBRecord ( &index, &db ) ) != DB_SUCCESS )
			{
				/*
				 * No record found, which is bad if the request_hash pointed
				 * to a valid hash record link (and hash record).  Again, let
				 * the caller deal with it.
				 */
				if ( type & DB_MATCH_RETURN )
					*return_record = NULL;
				DBGExit();
				return ( rc );
			}
			else
			{
				/*
				 * Found a record.  Save it to callers space (if requested)
				 * and tell caller it went ok
				 */
				if ( type & DB_MATCH_RETURN )
					*return_record = db;

				DBGExit();
				return ( DB_EXIST );
			}
		}


		/*
		 * we don't get here unless request_hash is NULL
		 */

		if ( request_index != NULL )
		{

			DBGPrintf(DBG_INFO,
					("looking for record using an index record\n"
					"   index->active: %d\n" 
					"   index->next:   %d\n" 
					"   index->prev:   %d\n" 
					"   index->ptr:    %d\n" 
					"   index->length: %d\n", 
					request_index->active, request_index->next, request_index->prev, 
					request_index->ptr, request_index->length ) );

			/*
			 * get the database record
			 */
			if ( ( rc = DBGetDBRecord ( request_index, &db ) ) != DB_SUCCESS )
			{
				/*
				 * No record found, which is bad if the request_index pointed
				 * to a valid hash record link (and hash record).  Again, let
				 * the caller deal with it.
				 */
				*return_record = NULL;
				DBGExit();
				return ( rc );
			}
			else
			{
				/*
				 * Found a record.  Save it to callers space (if requested)
				 * and tell caller it went ok
				 */
				if ( type & DB_MATCH_RETURN )
					*return_record = db;

				DBGExit();
				return ( DB_EXIST );
			}
		}
		else
		{
			/*
			 * DB_MATCH_ANY requires that either the request_hash or the
			 * request_index fields be non-NULL.  Tell the caller what happened.
			 */
			DBGPrint( DBG_INFO, 
					"DB_MATCH_ANY specified but no hash"
					"or index provided by caller\n" );

			if ( type & DB_MATCH_RETURN )
				*return_record = NULL;
			DBGExit();
			return ( DB_MATCH_ANY_INVALID_REQUEST );
		}

	}

	/*
	 * So we're not looking for a record based on the hash or index.
	 * The caller must want to use the DB_Fields[] array as the search
	 * criteria.
	 *
	 * First thing to do is create a hash from the DB_Fields[] index field.
	 */
	if ( DB_Fields[0] != NULL )
	{
		DBGPrintf(DBG_INFO, 
			("calling DBBuildHash(): index=\"%s\"\n", 
				DB_Fields[0]) );

		DBBuildHash( DB_Fields[0], &hash );
	}
	else
	{
		DBGPrint(DBG_INFO, "no index available\n" );
		/*
		 * If there is no first field (the indexed field) then we can't
		 * do the search.
		 */
		DBGExit();
		return (DB_MISSING_FIELD);
	}

	/*
	 * Find a matching hash record in the hash table
	 */
	DBGPrintf(DBG_INFO, 
			("calling DBGetHashLink(): hash name=\"%s\"\n", hash.name) );

	if ( DBGetHashLink ( &hash, &hash_link ) != DB_MATCH )
	{
		/*
		 * no hash record found - so there can't be a matching
		 * record in the database
		 */
		DBGPrint(DBG_INFO, "no hash record found\n" );
		DBGExit();
		return ( DB_NOMATCH );
	}

	/*
	 * copy the hash table entry to our hash record
	 */
	tmp_hash = (HASH_REC *)hash_link->hash;
	strcpy ( hash.name, tmp_hash->name );
	hash.ptr = tmp_hash->ptr;
	DBGPrintf( DBG_INFO, 
		("hash name: %s\tptr: 0x%08x\n", hash.name, hash.ptr));
 

	/*
	 * while the callers request does not match the current database 
	 * record and we've not reached the end of the database ...
	 */

	while ( TRUE )
	{ 	

		/*
		 * do the following to read in a record one at a time
		 */

		/*
		 * get an index record based on the current hash
		 */
		if ( ( rc = DBGetIndexRecord ( &hash, &index ) ) != DB_SUCCESS )
		{
			DBGPrint(DBG_INFO, "DBGetIndexRecord() did not return DB_SUCCESS\n");
			*return_record = NULL;
			DBGExit();
			return ( rc );
		}

		/*
		 * get the database record associated with that index
		 */
		if ( ( rc = DBGetDBRecord ( &index, &db ) ) != DB_SUCCESS )
		{
			DBGPrint(DBG_INFO, "DBGetDBRecord() did not return DB_SUCCESS\n");
			*return_record = NULL;
			DBGExit();
			return ( rc );
		}

		DBGPrintf( DBG_INFO, ("DBGetDBRecord() returned: %s\n", db ) );


		/*
		 * Compare this record with the one specified as the search
		 * criteria.
		 */
		if ( ( rc = DBCompare ( type, db ) ) != DB_MATCH )
		{
			DBGPrint(DBG_INFO, "DBCompare() did not match\n");

			/*
			 * Paranoid cleanup
			 */
			if ( db != NULL )
			{
				free ( db );
				db = NULL;
			}

			/*
			 * Get the next index record pointer, if any
			 */
			if ( index.next != -1 )
				hash.ptr = index.next;
			else
			{
				/*
				 * We've gone through all the indexes that match the hash
				 * so there must not be any records that match the request.
				 * Cleanup and return to the caller a no match result.
				 */
				DBGPrintf (DBG_INFO, ("%s() did not find record\n", fname) );

				free ( db );

				if ( type & DB_MATCH_RETURN )
					*return_record = NULL;

				DBGExit();
				return( DB_NOMATCH );
			}
		}
		else
		{
			/*
			 * Found a matching record; return it (if requested) and
			 * tell caller it was found.
			 */
			if ( type & DB_MATCH_RETURN )
			{
				*return_record = db;
				db = NULL;
			}

			DBGExit();
			return ( DB_EXIST );
		}
	}
}



/*========================================================================
 *	Name:			DBCompare
 *	Prototype:	DBCompare(int type, char *db)
 *					
 *	Description:
 *		compare a record with the record already parsed into the *DB_Fields[]
 *		record
 *
 *	Input Arguments:
 *		int			type				one or more of
 *											DB_MATCH_EXACT, DB_MATCH_ALL,
 *											DB_MATCH_FIELDx (x = 1 to DB_MAX_FIELDS),
 *											DB_HAS_SUBFIELDS
 *		char			*db				record to compare against DB_Fields[]
 *		
 *	Output Arguments:
 *		None.
 *
 *	Return Values:
 *		DB_CANT_PARSE			can't parse the record
 *		DB_TOO_MANY_FIELDS	record contains too many fields
 *		DB_NO_DELIMITER		can't find the FIELD delimiter
 *		DB_MATCH					records match compare criteria
 *		DB_NOMATCH				records do not match compare criteria
 *		DB_NOMATCH_HASH		record hashes do not match
 *		DB_MISSING_FIELD		DB_Fields[DB_FIELDx] is NULL, but DB_FIELDx was
 *									specified as a search criteria
 *
 *	Global Variables:
 *		char	*DB_Fields[]	contains the fields which are used as search
 *									criteria if search type requires it
 *
 *	External Routines:
 *		DBMakeLower, DBParseBuf, DBBuildHash, DBCompareFields
 *
 *	Method:
 *
 *	Restrictions:
 *
 *	Notes:
 *		DBCompare is not part of the API.  It should only be called from
 *		one of the API routines.
 *
 *		The type field is interpreted in this way:
 *		DB_MATCH_EXACT		If specified, the fields must match exactly,
 *								otherwise the request field can be a substring
 *								of the database record.
 *		DB_MATCH_ALL		The request_hash and request_index records are ignored
 *								and any non-NULL fields in DB_Fields[] are used as 
 *								search criteria.  All other types are ignored (except 
 *								DB_MATCH_EXACT).
 *		DB_MATCH_FIELDx	Field x [1 to DB_MAX_FIELDS] is used as a search 
 *								criteria.  The DB_Fields[] array is used with 
 *								DB_MATCH_FIELDx as an index.
 *		DB_HAS_SUBFIELDS	processed by DBCompareFields(), if applicable
 *		
 *========================================================================*/
int
DBCompare(
	int			type,
	char			*db
)
{

#ifdef DEBUG
	char		fname[]="DBCompare()";
#endif

	HASH_REC	hash_rec1, hash_rec2;	/* hash records */
	char		*dbcopy;						/* copy of db */
	char		*fields[DB_MAX_FIELDS];	/* parsed record */
	int		count, i;
	int		rc;


	DBGEnter();

	DBGPrintf(DBG_INFO, ("record passed in:\n%s\n", db) );

	/*
	 * Save a copy for converting to lowercase, which is how all
	 * comparisons are done.
	 */
	dbcopy = (char *) malloc ( strlen ( db ) + 1);
	strcpy ( dbcopy, db );
	DBMakeLower( dbcopy );
	DBGPrintf(DBG_INFO, ("copy of record:\n%s\n", dbcopy) );

	/*
	 * initialize the array of character pointers which will be the fields
	 * of the record
	 */
	for ( i=0; i < DB_MAX_FIELDS; i++ )
	{
		DBGPrintf(DBG_INFO, ("freeing up fields[%d]\n", i) );
		fields[i]=NULL;
	}
	DBGPrint(DBG_INFO, "Done freeing fields[]\n" );


	/*
	 * try to parse the record into component fields
	 */
	count = 0;
	while ( ( strlen (dbcopy) > 0 ) && ( count < DB_MAX_FIELDS ) )
	{
		rc = DBParseBuf( dbcopy, (char **)&(fields[count]), FIELD, NULL );

		switch ( rc )
		{
			case DB_SUCCESS:
				DBGPrintf(DBG_INFO, ("fields[%d]=%s\n", count, fields[count]) );
				break;

			case DB_EMPTY_FIELD:
				DBGPrintf(DBG_INFO, ("fields[%d] is empty\n", count) );
				break;

		 	case DB_NO_DELIMITER:
				/*
				 * if DBParseBuf() says the FIELD delimiter is not there then
				 * we have the last field, so copy it directly into the last field
				 */
				DBGPrintf(DBG_INFO,
					("dbcopy with missing FIELD delimiter:\n%s\n", dbcopy) );

				fields[count] = (char *) malloc ( strlen ( dbcopy ) + 1);
				strcpy ( fields[count], dbcopy );

				DBGPrintf( DBG_INFO, ("field %d: %s\n", count, fields[count]) );
				break;

			default:
				/*
				 * clean up storage allocated, if any
				 */
				DBGPrintf(DBG_INFO, ("DBParseBuf returned error: %d\n", rc) );
				free ( dbcopy );
				for ( i=0; i < count; i++ )
				{
					if ( fields[i] != NULL )
					{
						free ( fields[i] );
						fields[i] = NULL;
					}
				}

				/*
				 * tell the caller we can't parse the string they passed us
				 */
				DBGExit();
				return (DB_CANT_PARSE);
				break;

		}
		count++;
	}

	/*
	 * Make sure the index field is not null; it needs at least enough
	 * data to make a hash record.
	 */
	if ( fields[0] == NULL )
	{
		DBGPrint(DBG_INFO, "Index field is null, can't do comparison\n" );
		DBGExit();
		return ( DB_NOMATCH );
	}

	/*
	 * make sure we didn't exit last loop because we have too many fields
	 */
	if ( count > DB_MAX_FIELDS )
	{
		/*
		 * clean up storage allocated, if any
		 */
		free ( dbcopy );
		for ( i=0; i < count; i++ )
		{
			if ( fields[i] != NULL )
			{
				free ( fields[i] );
				fields[i] = NULL;
			}
		}

		/*
		 * tell caller the string they passed has too many fields in it
		 */
		DBGExit();
		return ( DB_TOO_MANY_FIELDS );
	}

	/*
	 * We don't need the copy any more, so free up its storage.
	 */
	free ( dbcopy );


	DBGPrintf( DBG_INFO, 
		("fields[0]: \"%s\"  DB_Fields[0]: \"%s\"\n", 
					fields[0], DB_Fields[0] ) );
	/*
	 * Build the hash for the record just fetched.
	 */
	DBBuildHash ( fields[0], &hash_rec1 );

	/*
	 * Make a copy of the indexed field (field 0), convert to lowercase,
	 * and then build a hash from it.
	 */
	DBBuildHash ( DB_Fields[0], &hash_rec2 );
	DBMakeLower ( hash_rec2.name );


	/*
	 * Check if the hash matches; if not return failure since nothing
	 * past the hash can make any difference.
	 */

	DBGPrintf( DBG_INFO, 
		("db hash: \"%s\"  request hash: \"%s\"\n", 
					hash_rec1.name, hash_rec2.name ) );

	if ( (int) strcmp ( hash_rec1.name, hash_rec2.name ) != 0 )
	{
		DBGPrint( DBG_INFO, "Hashes don't match\n");

		for ( i=0; i < count; i++ )
		{
			if ( fields[i] != NULL )
			{
				free ( fields[i] );
				fields[i] = NULL;
			}
		}
		DBGExit();
		return( DB_NOMATCH_HASH );
	}

	/*
	 * We don't need the copy of the index field any more, 
	 * so free up its storage.
	 */


	/*
	 * The hashes match.  From here there are only two possibilities:
	 * either we're checking specific fields to match or we're checking
	 * all fields to match.  So we'll handle these two cases seperately
	 * (DB_ALL takes precedence over any fields that may be specified)
	 */

	if ( type & DB_MATCH_ALL )
	{
		DBGPrint( DBG_INFO, "matching on all fields\n" );

		for ( i=0; i < DB_MAX_FIELDS; i++ )
		{
			DBGPrintf(DBG_INFO, 
				("DB_Fields[%d]=\"%s\"  fields[%d]=\"%s\"\n", 
					i, DB_Fields[i], i, fields[i]) );

			if ( DB_Fields[i] != NULL )
			{
				if ( DBCompareFields(type, fields, i) != DB_MATCH )
				{
					for ( i=0; i < count; i++ )
					{
						if ( fields[i] != NULL )
						{
							free ( fields[i] );
							fields[i] = NULL;
						}
					}
					DBGExit();
					return ( DB_NOMATCH );
				}
			}
		}

		/*
		 * If we get this far then all the fields matched.  Tell the
		 * caller the records match.
		 */
		for ( i=0; i < count; i++ )
		{
			if ( fields[i] != NULL )
			{
				free ( fields[i] );
				fields[i] = NULL;
			}
		}
		DBGExit();
		return ( DB_MATCH );
	}


	/*
	 * If we've gotten this far then we need to check specific fields.
	 *
	 * NOTE:  this is hacky.  It shouldn't be written with a knowledge
	 * of how many fields there are, but this was easy and I'm lazy.
	 */

	DBGPrint( DBG_INFO, "matching specific fields\n" );

	if ( type & DB_MATCH_FIELD1 )
	{
		if ( DB_Fields[0] != NULL )
		{
			DBGPrint( DBG_INFO, "matching on field 1\n" );

			if ( DBCompareFields(type, fields, 0) != DB_MATCH )
			{
				for ( i=0; i < count; i++ )
				{
					if ( fields[i] != NULL )
					{
						free ( fields[i] );
						fields[i] = NULL;
					}
				}
				DBGExit();
				return ( DB_NOMATCH );
			}
		}
		else
		{
			DBGPrint( DBG_INFO, "missing fields[0]\n" );
			return ( DB_NOMATCH );
		}
	}

	if ( type & DB_MATCH_FIELD2 )
	{
		DBGPrint( DBG_INFO, "matching on field 2\n" );

		if ( DB_Fields[1] != NULL )
		{
			if ( DBCompareFields(type, fields, 1) != DB_MATCH )
			{
				for ( i=0; i < count; i++ )
				{
					if ( fields[i] != NULL )
					{
						free ( fields[i] );
						fields[i] = NULL;
					}
				}
				DBGExit();
				return ( DB_NOMATCH );
			}
		}
		else
			return ( DB_NOMATCH );
	}

	if ( type & DB_MATCH_FIELD3 )
	{
		DBGPrint( DBG_INFO, "matching on field 3\n" );

		if ( DB_Fields[2] != NULL )
		{
			if ( DBCompareFields(type, fields, 2) != DB_MATCH )
			{
				for ( i=0; i < count; i++ )
				{
					if ( fields[i] != NULL )
					{
						free ( fields[i] );
						fields[i] = NULL;
					}
				}
				DBGExit();
				return ( DB_NOMATCH );
			}
		}
		else
			return ( DB_NOMATCH );
	}

	if ( type & DB_MATCH_FIELD4 )
	{
		DBGPrint( DBG_INFO, "matching on field 4\n" );

		if ( DB_Fields[3] != NULL )
		{
			if ( DBCompareFields(type, fields, 3) != DB_MATCH )
			{
				for ( i=0; i < count; i++ )
				{
					if ( fields[i] != NULL )
					{
						free ( fields[i] );
						fields[i] = NULL;
					}
				}
				DBGExit();
				return ( DB_NOMATCH );
			}
		}
		else
			return ( DB_NOMATCH );
	}

	if ( type & DB_MATCH_FIELD5 )
	{
		DBGPrint( DBG_INFO, "matching on field 5\n" );

		if ( DB_Fields[4] != NULL )
		{
			if ( DBCompareFields(type, fields, 4) != DB_MATCH )
			{
				for ( i=0; i < count; i++ )
				{
					if ( fields[i] != NULL )
					{
						free ( fields[i] );
						fields[i] = NULL;
					}
				}
				DBGExit();
				return ( DB_NOMATCH );
			}
		}
		else
			return ( DB_NOMATCH );
	}

	if ( type & DB_MATCH_FIELD6 )
	{
		DBGPrint( DBG_INFO, "matching on field 6\n" );

		if ( DB_Fields[5] != NULL )
		{
			if ( DBCompareFields(type, fields, 5) != DB_MATCH )
			{
				for ( i=0; i < count; i++ )
				{
					if ( fields[i] != NULL )
					{
						free ( fields[i] );
						fields[i] = NULL;
					}
				}
				DBGExit();
				return ( DB_NOMATCH );
			}
		}
		else
			return ( DB_NOMATCH );
	}

	if ( type & DB_MATCH_FIELD7 )
	{
		DBGPrint( DBG_INFO, "matching on field 7\n" );

		if ( DB_Fields[6] != NULL )
		{
			if ( DBCompareFields(type, fields, 6) != DB_MATCH )
			{
				for ( i=0; i < count; i++ )
				{
					if ( fields[i] != NULL )
					{
						free ( fields[i] );
						fields[i] = NULL;
					}
				}
				DBGExit();
				return ( DB_NOMATCH );
			}
		}
		else
			return ( DB_NOMATCH );
	}

	if ( type & DB_MATCH_FIELD8 )
	{
		DBGPrint( DBG_INFO, "matching on field 8\n" );

		if ( DB_Fields[7] != NULL )
		{
			if ( DBCompareFields(type, fields, 7) != DB_MATCH )
			{
				for ( i=0; i < count; i++ )
				{
					if ( fields[i] != NULL )
					{
						free ( fields[i] );
						fields[i] = NULL;
					}
				}
				DBGExit();
				return ( DB_NOMATCH );
			}
		}
		else
			return ( DB_NOMATCH );
	}

	/*
	 * The above macros will return DB_NOMATCH if the specified field
	 * doesn't match.  If we get this far then all the fields that were
	 * requested to be checked matched so we return DB_MATCH to the
	 * caller.
	 */
	for ( i=0; i < count; i++ )
	{
		if ( fields[i] != NULL )
		{
			free ( fields[i] );
			fields[i] = NULL;
		}
	}
	DBGExit();
	return ( DB_MATCH );

}



/*========================================================================
 *	Name:			DBCompareFields
 *	Prototype:	DBCompareFields(int type, char *local[], int field)
 *					
 *	Description:
 *	Compare two fields of a record.  This is used by DBCompare().
 *
 *	Input Arguments:
 *		int	type				flags; only concerned with presence of 
 *									DB_MATCH_EXACT
 *		char	*local[]			char * array of size DB_MAX_FIELDS
 *		int	field				which field of local to be concerned with
 *		
 *	Output Arguments:
 *		None.
 *
 *	Return Values:
 *		DB_MATCH					fields match compare criteria
 *		DB_NOMATCH				fields do not match compare criteria
 *
 *	Global Variables:
 *		char	*DB_Fields[]	contains the fields which are used as search
 *									criteria if search type requires it
 *
 *	External Routines:
 *		DBMakeLower
 *
 *	Method:
 *	Restrictions:
 *
 *	Notes:
 *		DBCompareFields is not part of the API.  It should only be called from
 *		DBCompare.
 *
 *		The type field is interpreted in this way:
 *		DB_MATCH_EXACT		If specified, the fields must match exactly,
 *								otherwise the request field can be a substring
 *								of the database record.
 *		DB_HAS_SUBFIELDS	field is broken into as many subfields as the
 *								callers request has and each is compared to
 *								the DB_Fields[] array entry's subfields.
 *								If a subfield is missing then the comparison
 *								fails.
 *		
 *========================================================================*/
int
DBCompareFields(
	int	type,
	char	*local[],
	int	field
)
{

#ifdef DEBUG
	char	fname[]="DBCompareFields()";
#endif

	char	*requestcopy, *dbcopy;
	char	*requestsubfield, *dbsubfield;
	int	rc;
	
	DBGEnter();
	DBGPrintf( DBG_INFO, ("field= %d\n", field) );
	
	/*
	 * Most simplistic case:  both fields are NULL; return match.
	 * If DB_Fields[] is null but local is not, then return no match.
	 */
	if ( DB_Fields[field] == NULL )
		if ( local[field] != NULL )
		{
			DBGPrint(DBG_INFO,"DB_Fields NULL but local is not\n");
			return ( DB_NOMATCH );
		}
		else
		{
			DBGPrint(DBG_INFO,"Both fields are NULL\n");
			return ( DB_MATCH );
		}
		
	/*
	 * Second most simplistic case:  DB_Fields[field] is not NULL but
	 * local[field] is; return no match
	 */
	if ( DB_Fields[field] != NULL )
		if ( local[field] == NULL )
		{
			DBGPrint(DBG_INFO,"DB_Fields is not NULL but local is\n");
			return ( DB_NOMATCH );
		}
		
	/*
	 * ok, both fields are non-NULL
	 */

	/*
	 * Get two buffers of equal size to the fields being compared
	 */
	dbcopy = (char *) malloc ( strlen (local[field]) + 1 );
	requestcopy = (char *) malloc ( strlen (DB_Fields[field]) + 1 );


	/*
	 * Get copies the fields
	 */
	strcpy ( dbcopy, local[field] );
	strcpy ( requestcopy, DB_Fields[field] );
	DBMakeLower( dbcopy );
	DBMakeLower( requestcopy );

	DBGPrintf( DBG_INFO,
			("\n\tdbcopy= \"%s\""
			"\n\tlocal[field]= \"%s\""
			"\n\trequestcopy= \"%s\""
			"\n\tDB_Fields[field]= \"%s\"\n",
			dbcopy, local[field], requestcopy, DB_Fields[field]) );


	if ( ! ( type & DB_HAS_SUBFIELDS ) )
	{
		DBGPrint(DBG_INFO, "No subfields used for comparisons\n");

		if ( type & DB_MATCH_EXACT )
		{
		
			/*
			 * Compare the fields exactly, character for character
			 */
			if ( strcmp ( requestcopy, dbcopy ) != 0 )
			{
				/*
				 * fields are not equivalent;  clean up and return to
				 * caller
		 		 */
				DBGPrint( DBG_INFO, "compared fields are not equivalent\n" );
				free ( requestcopy );
				free ( dbcopy );
				DBGExit();
				return ( DB_NOMATCH );
			}
		}
		else
		{
	
			/*
			 * Check if DB_Fields, which would be a field from the applications
			 * record, is a substring of the field passed by the caller of
			 * of this routine.
			 */
			if ( strstr ( dbcopy, requestcopy ) == NULL )
			{
				/*
				 * fields are not equivalent;  clean up and return to
				 * caller
		 		 */
				DBGPrintf( DBG_INFO,
					("DB_Fields[%d] (%s) is not a substring of callers field (%s)\n",
						field, requestcopy, dbcopy) );
	
				free ( requestcopy );
				free ( dbcopy );
				DBGExit();
				return ( DB_NOMATCH );
			}
		}

		/*
		 * Either they are equivalent or the callers field was a substring;
		 * tell the caller this.
		 */
		DBGPrint( DBG_INFO, "fields \"match\"\n" );
		free ( requestcopy );
		free ( dbcopy );

		DBGExit();
		return ( DB_MATCH );
	}

	/*
	 * The field in question has subfields, so we need to check each
	 * one individually, since the subfield delimiter could get in the
	 * way of a comparison.
	 */
	else
	{
		DBGPrint(DBG_INFO, "Subfields used for comparisons\n");

		/*
		 * as long as we have fields left in each record...
		 */
		while( ( strlen(requestcopy) > 0 ) && ( strlen(dbcopy) > 0 ) )
		{

			/*
			 * grab a subfield of the database field
			 */
			DBGPrintf(DBG_INFO, 
					("Address of dbsubfield: 0x%08x\n", (int)&dbsubfield));
			rc = DBParseBuf( dbcopy, (char **)&(dbsubfield), SUBFIELD, NULL );
			switch ( rc )
			{
				/*
				 * if DBParseBuf() says the SUBFIELD delimiter is not there then
				 * we have the last field, so copy it directly into the last field
				 */
				case DB_NO_DELIMITER:
					DBGPrint(DBG_INFO, 
						"DBParseBuf says there is no subfield delimiter\n" );
					dbsubfield = (char *) malloc ( strlen ( dbcopy ) + 1);
					strcpy ( dbsubfield, dbcopy );
					strcpy ( dbcopy, "\0" );
					break;

				/*
				 * nothing to do just yet if the parse went ok
				 */
				case DB_SUCCESS:
				case DB_EMPTY_FIELD:
					break;


				default:
					DBGPrintf(DBG_INFO, 
						("DBParseBuf couldn't parse: rc=%d\n", rc) );
	
					/*
					 * clean up storage allocated, if any
					 */
					free ( dbcopy );
					free ( requestcopy );
					if ( dbsubfield != NULL )
					{
						free ( dbsubfield );
						dbsubfield = NULL;
					}
	
					/*
					 * tell the caller we can't parse the string they passed us
					 */
					DBGExit();
					return (DB_CANT_PARSE);
					break;
			}

			/*
			 * grab a subfield of the request field
			 */
			DBGPrint(DBG_INFO, "Grabbing request subfield\n");
			rc = DBParseBuf( requestcopy, (char **)&(requestsubfield), 
					SUBFIELD, NULL );
			switch ( rc )
			{
				/*
				 * if DBParseBuf() says the FIELD delimiter is not there then
				 * we have the last field, so copy it directly into the last field
				 */
				case DB_NO_DELIMITER:
					DBGPrint(DBG_INFO, 
						"DBParseBuf says there is no subfield delimiter\n" );

					requestsubfield = (char *) malloc ( strlen ( requestcopy ) + 1);
					strcpy ( requestsubfield, requestcopy );
					strcpy ( requestcopy, "\0" );
					break;

				/*
				 * nothing to do just yet if the parse went ok
				 */
				case DB_SUCCESS:
				case DB_EMPTY_FIELD:
					break;

				default:
					DBGPrintf(DBG_INFO, 
						("DBParseBuf couldn't parse: rc=%d\n", rc) );
	
					/*
					 * clean up storage allocated, if any
					 */
					free ( dbcopy );
					free ( requestcopy );
					if ( dbsubfield != NULL )
					{
						free ( dbsubfield );
						dbsubfield = NULL;
					}
	
					/*
					 * tell the caller we can't parse the string they passed us
					 */
					DBGExit();
					return (DB_CANT_PARSE);
					break;
			}
			DBGPrintf(DBG_INFO, 
						("DBParseBuf parsed requestcopy: %s\n", requestsubfield) );

			/*
			 * If the requests subfield contains data, then we need
			 * to compare it to the database records, otherwise we skip it
			 */
			if ( requestsubfield != NULL )
			{
				DBGPrintf(DBG_INFO, 
					("requestsubfield (%s) is not empty - doing comparison\n",
					requestsubfield) );

				/*
				 * make sure the database has something to compare against
				 */
				if ( dbsubfield == NULL )
				{
					DBGPrint( DBG_INFO, "db has no field but request does\n" );
					free ( requestsubfield );
					free ( requestcopy );
					free ( dbcopy );
					DBGExit();
					return ( DB_NOMATCH );
				}
				
				/*
				 * Now we have the subfields to compare, so compare them
				 * based on the type of comparison requested.
				 */
	
				if ( type & DB_MATCH_EXACT )
				{
				
					/*
					 * Compare the fields exactly, character for character
					 */
					if ( strcmp ( requestsubfield, dbsubfield ) != 0 )
					{
						/*
						 * fields are not equivalent;  clean up and return to
						 * caller
				 		 */
						DBGPrint( DBG_INFO, "compared fields are not equivalent\n" );
						free ( requestsubfield );
						free ( requestcopy );
						free ( dbsubfield );
						free ( dbcopy );
						DBGExit();
						return ( DB_NOMATCH );
					}
				}
				else
				{
			
					/*
					 * Check if DB_Fields, which would be a field from the applications
					 * record, is a substring of the field passed by the caller of
					 * of this routine.
					 */
					if ( strstr ( dbsubfield, requestsubfield ) == NULL )
					{
						/*
						 * subfields are not equivalent;  clean up and return to
						 * caller
				 		 */
						DBGPrintf( DBG_INFO,
							("DB_Fields[%d] (%s) is not a substring of callers field (%s)\n",
								field, requestsubfield, dbsubfield) );
			
						free ( requestsubfield );
						free ( requestcopy );
						free ( dbsubfield );
						free ( dbcopy );
						DBGExit();
						return ( DB_NOMATCH );
					}
				}
			}
			else
			{
				DBGPrintf(DBG_INFO, 
					("requestsubfield (%s) is empty - no comparison done\n",
						requestsubfield) );
			}

			/*
			 * Free up the subfields and go grab the next
			 * subfields.
			 */
			free ( requestsubfield );
			free ( dbsubfield );
		}

		/*
		 * if we got this far then all subfields in question matched
		 */
		DBGPrint( DBG_INFO, "fields \"match\"\n" );
		free ( requestcopy );
		free ( dbcopy );

		DBGExit();
		return ( DB_MATCH );
	}
}

#endif /* DBSEARCH_C */
