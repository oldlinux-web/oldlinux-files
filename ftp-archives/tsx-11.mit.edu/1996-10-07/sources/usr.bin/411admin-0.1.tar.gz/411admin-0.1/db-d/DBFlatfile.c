/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: DBFlatfile.c
 *            DESCRIPTION: routines for accessing the flat file
 *      DEFINED CONSTANTS: defined in db.h
 *       TYPE DEFINITIONS: defined in db.h
 *      MACRO DEFINITIONS: defined in db.h
 *       GLOBAL VARIABLES: defined in db.h
 *       PUBLIC FUNCTIONS: DBGetDBRecord
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/DB, no underscores, mixed case		DBPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/DB, underscores, mixed case			DB_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		prefixed w/DB, underscores and all caps		DB_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBFLATFILE_C
#define DBFLATFILE_C

/* === System Headers === */
#include <stdio.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

/* === Project Headers === */
#include "db.h"
#include "debug.h"


/*========================================================================
 *	Name:			DBGetDBRecord
 *	Prototype:	DBGetDBRecord(INDEX_REC *index, char **return_record )
 *
 *	Description:
 * Retrieve the database record pointed to by the index record
 * from the database file.  Assumes valid pointer into database.
 * Allocates the space needed and assigns it to return_record.
 *
 *	Input Arguments:
 *		INDEX_REC	*index,				pointer to index record
 *
 *	Output Arguments:
 *		char			**return_record	buffer record goes into
 *
 *	Return Values:
 *		DB_SUCCESS					successful read of record from flat file
 *		DBOPENFAIL					failed to open the flat file
 *		DBLSEEKFAIL					failed lseek into the flat file
 *		DBREADFAIL					failed to read correct # of bytes from file
 *
 *	Global Variables:
 *		DB_Filename
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		It is the responsibility of the caller to free up the storage
 *		allocated by this routine.
 *		
 *========================================================================*/
int
DBGetDBRecord(
	INDEX_REC	*index,				/* pointer to index record */
	char			**return_record	/* buffer record goes into */
)
{

#ifdef DEBUG
	char		fname[]="DBGetDBRecord()";
#endif

	int		datafd;		/* file descriptor for database file */
	int		bytes_read;	/* number of bytes read from the file */


	DBGEnter();

	/*
	 * make sure the two parameters are valid
	 */
	if ( ( index == NULL ) || ( return_record == NULL ) )
	{
		DBGExit();
		return ( DBOPENFAIL );
	}

	/*
	 * get the database record the index points to
	 */
	if ( ( datafd = open ( DB_Filename, O_RDONLY ) ) == -1 )
	{
		DBGPrint ( DBG_INFO, "Error opening database file\n");
		DBGExit();
		return ( DBOPENFAIL );
	}

	/*
	 * set the file pointer to the position defined in the index record
	 */
	if ( lseek ( datafd, index->ptr, SEEK_SET ) == -1 ) {
		DBGPrint ( DBG_INFO, "Error setting file pointer in database file\n");
		close ( datafd );
		DBGExit();
		return ( DBLSEEKFAIL );
	}

	/*
	 * Allocate some storage for the record
	 */
	*return_record = (char *) malloc ( index->length + 1);
	bzero ( *return_record, index->length + 1);

	/*
	 * Read in the record
	 */
	bytes_read = read ( datafd, *return_record, index->length );
	close ( datafd );

	/*
	 * Make sure we got the whole record, or what we were expecting to get
	 */
	if ( bytes_read != index->length )
	{
		free ( *return_record );
		*return_record = NULL;

		DBGPrint ( DBG_INFO, "failed to get complete record\n" );
		DBGExit();
		return ( DBREADFAIL );
	}

	DBGPrintf ( DBG_INFO, ("Record pointed to by index:\n\"%s\"\n",
			*return_record) );
	DBGExit();
	return ( DB_SUCCESS );
}

#endif /* DBFLATFILE_C */
