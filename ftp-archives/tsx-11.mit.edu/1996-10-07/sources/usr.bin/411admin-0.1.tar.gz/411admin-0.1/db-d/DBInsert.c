/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: DBInsert.c
 *            DESCRIPTION: insert a record into the database
 *      DEFINED CONSTANTS: defined in db.h
 *       TYPE DEFINITIONS: defined in db.h
 *      MACRO DEFINITIONS: defined in db.h
 *       GLOBAL VARIABLES: defined in db.h
 *       PUBLIC FUNCTIONS: DBInsertRecord
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/DB, no underscores, mixed case		DBPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/DB, underscores, mixed case			DB_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		prefixed w/DB, underscores and all caps		DB_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBINSERT_C
#define DBINSERT_C

/* === System Headers === */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

/* === Project Headers === */
#include "db.h"
#include "debug.h"

/* === external routines === */
extern void	DBMakeLower();
extern int	DBParseBuf();
extern void	DBBuildHash();
extern int	DBGetIndexRecord();
extern int	DBGetDBRecord();
extern int	DBGetHashLink();
extern int	DBPutIndexRecord();


/*========================================================================
 *	Name:			DBInsertRecord
 *	Prototype:	DBInsertRecord( char *record )
 *
 *	Description:
 * add a single record to the databases
 *
 *	Input Arguments:
 *		char	*record			pointer to record to add
 *
 *	Output Arguments:
 *		None.
 *
 *	Return Values:
 *		DB_SUCCESS 				record successfully added
 *		HASHNULL 				hash is null, but db is not empty
 *		DB_CANT_PARSE			can't parse a field
 *		DB_EXIST 				record already exists
 *		
 *		INDEXWRITEFAIL 		failed in write of index record - db may be corrupt
 *		INDEXERR 				error in retrieving index record
 *		
 *		STATDBERR 				error in stat() of flat file
 *		DBOPENFAIL 				error in opening flat file
 *		DBWRITEFAIL 			error in writing to flat file
 *		DBFETCHERR 				error in reading flat file record
 *
 *	Global Variables:
 *		DB_Filename, DB_Index_Filename
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		This could probably be cleaned up quite a bit.
 *		
 *========================================================================*/
int
DBInsertRecord(
	char	*record			/* pointer to record to add */
)
{

#ifdef DEBUG
	char			fname[]="DBInsertRecord()";
#endif

	HASH_REC		hash_rec;
	HASH_REC		*new_hash;
	HASH_REC		*tmp_hash_rec;

	HASH_LINK	*hash_link;
	HASH_LINK	*new_hash_link;
	HASH_LINK	*tmp_hash_link;

	INDEX_REC	index;
	INDEX_REC	new_index;
	INDEX_REC	prev_index;

	char			*stringcopy, *buf;
	char			*namefield, *dbnamefield;
	int			db_ptr, index_ptr;
	int			rc;
	int			hash_pos;
	int			datafp;

	struct stat	stat_buf;

	DBGEnter();

	/*
	 * Copy the original to a working copy
	 */
	stringcopy = (char *) malloc ( strlen ( record ) + 1);
	strcpy ( stringcopy, record );

	/*
	 * Make it lower case
	 */
	DBMakeLower ( stringcopy );

	/*
	 * Parse the record to get the name
	 */
	if ( (rc = DBParseBuf( stringcopy, (char **)(&namefield), FIELD, NULL ) )
					!= DB_SUCCESS )
	{
		/*
		 * clean up storage allocated, if any
		 */
		free ( stringcopy );

		/*
		 * tell the caller we can't parse the string they passed us
		 */
		DBGExit();
		return (DB_CANT_PARSE);
	}

	DBGPrintf(DBG_INFO, ("namefield: \"%s\"\n", namefield) );
	free ( stringcopy );

	/*
	 * Build a hash from the callers request
	 */
	DBBuildHash( namefield, &hash_rec );
	free ( namefield );

	/*
	 * Get the hash link and its associated hash record
	 */
	hash_pos = DBGetHashLink ( &hash_rec, &hash_link );
	DBGPrintf(DBG_INFO, ("DBGetHashLink returned: %d\n", hash_pos) );

	/*
	 * based on return from DBGetHashLink(), add records to db and index
	 */
	switch ( hash_pos )
	{
		case NULLHASHTABLE:
			/*
			 * We have a NULL hash table.  This probably means there are db
			 * files present, but they contain inactive records.  We could
			 * clean them up, but we'll leave that to be done by explicit
			 * request.  To add a record, however, requires that we append
			 * to the end of the possibly existant files.
			 */

			/*
			 * determine if the flat file exists and, if so, how long
			 * it is.
			 */
			if ( stat ( DB_Filename , &stat_buf ) == 0 )
			{
				/*
				 * flat file exists;  save pointer to where the new record
				 * is being written.
				 */
				db_ptr = stat_buf.st_size;

			}
			else
			{
				/*
				 * flat file doesn't exist;  record written to offset 0
				 */
				db_ptr = 0;
			}

			/*
			 * open flat file
			 */
			if ( (datafp = open( DB_Filename, 
					O_CREAT | O_WRONLY | O_APPEND ) ) < 0 )
			{
				DBGExit();
				return ( DBOPENFAIL );
			}

			/*
			 * append record to the flat file
			 */
			if ( write ( datafp, record, strlen ( record ) ) < 0)
			{
				DBGExit();
				return ( DBWRITEFAIL );
			}
			close ( datafp );

			/*
			 * Determine if the index file exists and, if so, how long
			 * it is.
			 */
			if ( stat ( DB_Index_Filename , &stat_buf ) == 0 )
			{
				/*
				 * Index file exists; save offset into file for new record
				 */
				index_ptr = stat_buf.st_size;
			}
			else
			{
				/*
				 * Index file does not exist; offset into file is 0
				 */
				index_ptr = 0;
			}

			/*
			 * Build an index record for the flat file record and write it to the
			 * index file.
			 */
			index.active = 0;
			index.next = -1;
			index.prev = -1;
			index.ptr = db_ptr;
			index.length = strlen( record );

			/*
			 * write index
			 */
			hash_rec.ptr = index_ptr;

			DBGPrintf ( DBG_INFO, 
				("writing index:\n"
				"\thash.ptr: %d\n"
				"\tactive: %d\n"
				"\tnext: %d\n"
				"\tprev: %d\n"
				"\tptr: %d\n"
				"\tlength: %d\n",
				hash_rec.ptr,
				index.active, index.next, index.prev,
				index.ptr, index.length ));

			if ( DBPutIndexRecord ( &hash_rec, &index ) != DB_SUCCESS )
			{
				DBGExit();
				return ( INDEXWRITEFAIL );
			}


			/* 
			 * Adding a Hash table entry is handled after the end of this
			 * switch statement.
			 */

			break;

		/*
		 * In this case, the new index record will be the last on
		 * in the link list of index records
		 */
		case ENDOFHASHLIST:

			DBGPrint( DBG_INFO, "Adding record under \"ENDOFHASHLIST\"\n");

			/*
			 * grab a copy of the current hash record
			 */
			tmp_hash_rec = (HASH_REC *) malloc ( sizeof ( HASH_REC ) );
			bcopy ( (char *)hash_link->hash, (char *)tmp_hash_rec, 
							sizeof ( HASH_REC ) );

			/*
			 * find the index record for the last record in the db
			 */
			DBGetIndexRecord( tmp_hash_rec, &index );
			while ( index.next != -1 )
			{
				tmp_hash_rec->ptr = index.next;
				DBGetIndexRecord( tmp_hash_rec, &index );
			}

			/*
			 * Set the next and previous pointers, and active flag
			 */
			new_index.active = 0;
			new_index.next = -1;
			new_index.prev = tmp_hash_rec->ptr;
			free ( tmp_hash_rec );

			DBGPrintf(DBG_INFO, 
				("Index for new record:\n"
				 "active: %d\n"
				 "next: %d\n"
				 "prev: %d\n",
				 new_index.active, new_index.next, new_index.prev ));

			/*
			 * get the file stat information for the index, this is where
			 * the new index record will go
			 */
			rc = stat ( DB_Index_Filename , &stat_buf );
			index.next = stat_buf.st_size;

			/*
			 * get the file stat information for the database
			 */
			if ( ( rc = stat ( DB_Filename, &stat_buf ) ) != 0 )
			{
				DBGPrintf( DBG_INFO, 
					("error (rc= %d) stating %s\n", rc, DB_Filename) );

				DBGExit();
				return ( STATDBERR );
			}
			DBGPrintf ( DBG_INFO, ("stat of %s succeeded\n", DB_Filename) );

			/*
			 * Set the indexes pointer to the new location and 
			 * the new length of the record
			 */
			new_index.ptr = stat_buf.st_size;
			new_index.length = strlen ( record );

			/*
			 * append record to the database file
			 */
		
			/*
			 * open flat file
			 */
			if ( (datafp = open( DB_Filename, 
					O_CREAT | O_WRONLY | O_APPEND ) ) < 0 )
			{
				DBGExit();
				return ( DBOPENFAIL );
			}

			/*
			 * append record to the flat file
			 */
			if ( write ( datafp, record, strlen ( record ) ) < 0)
			{
				DBGExit();
				return ( DBWRITEFAIL );
			}
			close ( datafp );

			/*
			 * rewrite old index
			 */
			DBGPrintf ( DBG_INFO, 
				("rewriting index:\n"
				"\tactive: %d\n"
				"\tnext: %d\n"
				"\tprev: %d\n"
				"\tptr: %d\n"
				"\tlength: %d\n",
				index.active, index.next, index.prev,
				index.ptr, index.length ));

			hash_rec.ptr = new_index.prev;

			if ( DBPutIndexRecord ( &hash_rec, &index ) != DB_SUCCESS )
			{
				DBGExit();
				return ( INDEXWRITEFAIL );
			}

			/*
			 * write new index
			 */
			DBGPrintf ( DBG_INFO, 
				("writing new index:\n"
				"active: %d\tnext: %d\tprev: %d\tptr: %d\tlength: %d\n",
				new_index.active, new_index.next, new_index.prev,
				new_index.ptr, new_index.length )) ;

			hash_rec.ptr = index.next;

			if ( DBPutIndexRecord( &hash_rec, &new_index ) != DB_SUCCESS )
			{
				DBGExit();
				return ( INDEXWRITEFAIL );
			}
			break;

		/*
		 * in this case the new index will be the new head of the index
		 * link list
		 */
		case NEWHEAD:

			DBGPrint( DBG_INFO, "Adding record under \"NEWHEAD\"\n");

			/*
			 * make sure we have the index for the first record in the
			 * the index table
			 */
			tmp_hash_rec = ( HASH_REC * ) hash_link->hash;
			DBGetIndexRecord( tmp_hash_rec, &index );

			/*
			 * Set the next and previous pointers, and active flag
			 * for the index of the record being added
			 */
			new_index.active = 0;
			new_index.next = tmp_hash_rec->ptr;
			new_index.prev = -1;

			/*
			 * Get the file stat information for the index, this is where
			 * the new index record will go
			 */
			rc = stat ( DB_Index_Filename , &stat_buf );
			index.prev = stat_buf.st_size;

			/*
			 * Get the file stat information for the database
			 */
			if ( ( rc = stat ( DB_Filename, &stat_buf ) ) != 0 )
			{
				DBGPrintf( DBG_INFO, 
					("error (rc= %d) stating %s\n", rc, DB_Filename) );

				DBGExit();
				return ( STATDBERR );
			}
			DBGPrintf( DBG_INFO, ("stat of %s succeeded\n", DB_Filename) );

			/*
			 * Set the new indexes pointer to the location and
			 * the length of the record being added to the flt file
			 */
			new_index.ptr = stat_buf.st_size;
			new_index.length = strlen ( record );

			DBGPrintf( DBG_INFO, 
				("new_index:\n"
				"active: %d\tnext: %d\tprev: %d\tptr: %d\tlength: %d\n",
				new_index.active, new_index.next, new_index.prev,
				new_index.ptr, new_index.length) );

			/*
			 * append new record to the database flat file
			 */
		
			/*
			 * open flat file
			 */
			if ( (datafp = open( DB_Filename, 
						O_CREAT | O_WRONLY | O_APPEND ) ) < 0 )
			{
				DBGExit();
				return ( DBOPENFAIL );
			}

			/*
			 * append new record to the flat file
			 */
			if ( write ( datafp, record, strlen ( record ) ) < 0 )
			{
				DBGExit();
				return ( DBWRITEFAIL );
			}
			close ( datafp );

			/*
			 * rewrite old index
			 */
			DBGPrintf( DBG_INFO, 
				("rewriting index:\n"
				"active: %d\tnext: %d\tprev: %d\tptr: %d\tlength: %d\n",
				index.active, index.next, index.prev,
				index.ptr, index.length ) );

			hash_rec.ptr = new_index.next;
			if ( DBPutIndexRecord ( &hash_rec, &index ) != DB_SUCCESS )
			{
				DBGExit();
				return ( INDEXWRITEFAIL );
			}

			/*
			 * write new index
			 */
			DBGPrintf( DBG_INFO, 
				("writing new index:\n"
				"active: %d\tnext: %d\tprev: %d\tptr: %d\tlength: %d\n",
				new_index.active, new_index.next, new_index.prev,
				new_index.ptr, new_index.length ) );

			hash_rec.ptr = index.prev;
			if ( DBPutIndexRecord( &hash_rec, &new_index ) != DB_SUCCESS )
			{
				DBGExit();
				return ( INDEXWRITEFAIL );
			}
			break;


		/*
		 * In these two cases the new index will either between two
		 * other indexes or possibly the end of the link list; we couldn't
		 * tell just by the return code from the DBGetHashLink() call
		 */
		case DB_MATCH: 
		case DB_NOMATCH:

			DBGPrint( DBG_INFO, "Adding record under \"MATCH\"\n");

			/*
			 * Get the first index record using the hash record of the record
			 * we're going to add.
			 */
			if ( DBGetIndexRecord ( &hash_rec, &index ) != DB_SUCCESS )
			{
				DBGExit();
				return ( INDEXERR );
			}
		
			/*
			 * Get the database record pointed to by the current index
			 */
			if ( DBGetDBRecord ( &index, &buf ) != DB_SUCCESS )
			{
				DBGExit();
				return ( DBFETCHERR );
			}
			DBMakeLower(buf);
		
			/*
			 * Parse the record to get the name
			 */
			if ( (rc = DBParseBuf( buf, (char **)(&dbnamefield), FIELD, NULL ) )
							!= DB_SUCCESS )
			{
				/*
				 * clean up storage allocated, if any
				 */
				free ( buf );
		
				/*
				 * tell the caller we can't parse the string they passed us
				 */
				DBGExit();
				return (DB_CANT_PARSE);
			}
			free ( buf );
		
			/*
			 * Parse the callers record to get the name
			 */
			buf = (char *) malloc ( strlen ( record ) + 1 );
			strcpy ( buf, record );
			DBMakeLower( buf );
			if ( (rc = DBParseBuf( buf, (char **)(&namefield), FIELD, NULL ) )
							!= DB_SUCCESS )
			{
				/*
				 * clean up storage allocated, if any
				 */
				free ( buf );
				free ( dbnamefield );
		
				/*
				 * tell the caller we can't parse the string they passed us
				 */
				DBGExit();
				return (DB_CANT_PARSE);
			}
			free ( buf );
			buf = NULL;

			/*
			 * While the name in the record is less than the users new
			 * record name ...
			 */
			while ( strcmp ( dbnamefield, namefield ) < 0 )
			{
				/*
				 * free up storage from old db index field
				 */
				free ( dbnamefield );

				/*
				 * get the next index record
				 */
				if ( index.next == -1 )
					break;
				else
					hash_rec.ptr = index.next;

				if ( DBGetIndexRecord( &hash_rec, &index ) != DB_SUCCESS )
				{
					free ( namefield );

					DBGExit();
					return ( INDEXERR );
				}

				/*
				 * get the next database record
				 */
				DBGPrintf(DBG_INFO,
					(	"DBGetDBRecord()\n"
						"\tbuf:         0x%08x\n", buf ) );
				if ( DBGetDBRecord ( &index, &buf ) != DB_SUCCESS )
				{
					free ( namefield );

					DBGExit();
					return ( DBFETCHERR );
				}

				/*
				 * parse the record to get the name
				 */
				DBGPrintf(DBG_INFO,
					(	"Parsing record\n"
						"\tbuf:         0x%08x\n"
						"\tdbnamefield: 0x%08x\n",
						buf, dbnamefield) );
				(void) DBParseBuf( buf, (char **)&dbnamefield, FIELD, NULL );
				DBGPrintf(DBG_INFO,("dbnamefield: %s\n", dbnamefield) );
				DBMakeLower ( dbnamefield );
				free ( buf );
				buf = NULL;
	
			}

			/*
			 * If the index field of the callers request matches the db records
			 * index field then return; we don't want to add
			 * a record thats already in there - caller should use the update
			 * function.
			 */
			DBGPrint(DBG_INFO,"Comparing for =\n");
			if ( strcmp ( dbnamefield, namefield ) == 0 )
			{
				DBGPrint( DBG_INFO, "Index Fields match!  Can't add new record.\n");

				free ( dbnamefield );
				free ( namefield );

				DBGExit();
				return ( DB_EXIST );
			}
	
	
			/*
			 * If the last record retrieved is still less than the one that
			 * is about to be added then we are at the end of the link list.
			 * The new record will go at the end of the database.
			 */
			DBGPrint(DBG_INFO,"Comparing for <\n");
			if ( strcmp( dbnamefield, namefield ) < 0  )
			{
				DBGPrint( DBG_INFO, 
					"Adding new record at end of index link list.\n");

				/*
				 * free up storage for name fields
				 */
				free ( dbnamefield );
				free ( namefield );
	
				new_index.active = 0;
				new_index.next = -1;
	
				/*
				 * Get the file stat information for the index, this is 
				 * where the new index record will go
				 */
				rc = stat ( DB_Index_Filename, &stat_buf );
				index.next = stat_buf.st_size;
	
				/*
				 * If the current index is both tail AND head, set the new
				 * index's prev to point to the start of the index file
				 */
				if ( index.prev == -1 )
					new_index.prev = 0;
				else
				{

					/*
					 * get the previous index
					 */
					hash_rec.ptr = index.prev;
					if ( DBGetIndexRecord( &hash_rec, &prev_index ) != DB_SUCCESS )
					{
						free ( dbnamefield );
						free ( namefield );

						DBGExit();
						return ( INDEXERR );
					}

					/*
					 * And set the new index's next to the previous's 
					 * next
					 */
					new_index.prev = prev_index.next;
				}

				/*
				 * Get the flat file stat information
				 */
				if ( ( rc = stat ( DB_Filename, &stat_buf ) ) != 0 )
				{
					DBGPrintf( DBG_INFO, 
						("error (rc= %d) stating %s\n", rc, DB_Filename) );
					free ( dbnamefield );
					free ( namefield );

					DBGExit();
					return ( STATDBERR );
				}

				DBGPrintf( DBG_INFO, 
					("stat of %s succeeded\n", DB_Filename) );

				/*
				 * Set the new indexes pointer to the location and
				 * the length of the record being added to the flat file
				 */
				new_index.ptr = stat_buf.st_size;
				new_index.length = strlen ( record );
	
				/*
				 * append record to the database file
				 */
		
				/*
				 * open the flat file 
				 */
				if ( (datafp = open( DB_Filename, 
						O_CREAT | O_WRONLY | O_APPEND ) ) < 0 )
				{
					free ( dbnamefield );
					free ( namefield );

					DBGExit();
					return ( DBOPENFAIL );
				}

				/*
				 * append the record to the file
				 */
				if ( write ( datafp, record, strlen ( record ) ) < 0)
				{
					free ( dbnamefield );
					free ( namefield );

					DBGExit();
					return ( DBWRITEFAIL );
				}
				close ( datafp );

				/*
				 * rewrite the old index
				 */
				DBGPrintf( DBG_INFO, 
					("rewriting index:\n"
					"active: %d\tnext: %d\tprev: %d\tptr: %d\tlength: %d\n",
					index.active, index.next, index.prev,
					index.ptr, index.length) );

				hash_rec.ptr = new_index.prev;
				if ( DBPutIndexRecord ( &hash_rec, &index ) != DB_SUCCESS )
				{
					free ( dbnamefield );
					free ( namefield );

					DBGExit();
					return ( INDEXWRITEFAIL );
				}
	
				/*
				 * write new index
				 */
				DBGPrintf( DBG_INFO, 
					("writing new index:\n"
					"active: %d\tnext: %d\tprev: %d\tptr: %d\tlength: %d\n",
					new_index.active, new_index.next, new_index.prev,
					new_index.ptr, new_index.length) );

				hash_rec.ptr = index.next;
				if ( DBPutIndexRecord( &hash_rec, &new_index ) != DB_SUCCESS )
				{
					free ( dbnamefield );
					free ( namefield );

					DBGExit();
					return ( INDEXWRITEFAIL );
				}

				/*
				 * break out of switch statement - we're done adding the
				 * record.
				 */
				break;
	
			}
			else
			{
				DBGPrint(DBG_INFO,"Old index should follow new one\n");
				/*
				 * free up storage for name fields
				 */
				free ( dbnamefield );
				free ( namefield );

				new_index.active = 0;
	
				/*
				 * The old index should follow the new index.  There are two
				 * ways this can happen:
				 */

				/*
				 * The index is currently at the head of the index link
				 * link list, so we will be inserting the new index in
				 * front of it
				 */
				if ( index.prev == -1 )
				{
					DBGPrint( DBG_INFO, 
						"Adding new record at head of index table.\n");

					new_index.prev = -1;
	
					/*
					 * If its also the tail, then new index must point to
					 * start of index file
					 */
					if ( index.next == -1 )
						new_index.next = 0;
					else
					{
	
						/*
						 * otherwise get the next index and use its previous
						 * index to set the new_index's next field
						 */
						hash_rec.ptr = index.next;
						if ( DBGetIndexRecord (&hash_rec, &prev_index) != DB_SUCCESS )
						{
							DBGExit();
							return ( INDEXERR );
						}
						new_index.next = prev_index.prev;
					}
	
					/*
					 * Get the file stat information for the index, this is 
					 * where the new index record will go
					 */
					rc = stat ( DB_Index_Filename , &stat_buf );
					index.prev = stat_buf.st_size;
	
					/*
					 * Get the file stat information for the flat file
					 */
					if ( ( rc = stat ( DB_Filename, &stat_buf ) ) != 0 )
					{
						DBGPrintf( DBG_INFO, 
							("error (rc= %d) stating %s\n", rc, DB_Filename) );

						DBGExit();
						return ( STATDBERR );
					}

					DBGPrintf( DBG_INFO, 
						("stat of %s succeeded\n", DB_Filename) );

					/*
					 * Set the indexes pointer to the location and
					 * the length of the record being added to the flat file
					 */
					new_index.ptr = stat_buf.st_size;
					new_index.length = strlen ( record );
	
					/*
					 * append record to the database file
					 */
		
					/*
					 * open the flat file
					 */
					if ( (datafp = open( DB_Filename, 
							O_CREAT | O_WRONLY | O_APPEND ) ) < 0 )
					{	
						DBGExit();
						return ( DBOPENFAIL );
					}

					/*
					 * append the record to the flat file
					 */
					if ( write( datafp, record, strlen ( record ) ) < 0)
					{
						DBGExit();
						return ( DBWRITEFAIL );
					}
					close ( datafp );

					/*
					 * rewrite old index
					 */
					DBGPrintf( DBG_INFO, 
						("rewriting index:\n"
						"active: %d\tnext: %d\tprev: %d\tptr: %d\tlength: %d\n",
						index.active, index.next, index.prev,
						index.ptr, index.length ) );

					hash_rec.ptr = new_index.next;
					if ( DBPutIndexRecord( &hash_rec, &index ) != DB_SUCCESS )
					{
						DBGExit();
						return ( INDEXWRITEFAIL );
					}

					/*
					 * write index for new record
					 */
					DBGPrintf( DBG_INFO, 
						("writing new index:\n"
						"active: %d\tnext: %d\tprev: %d\tptr: %d\tlength: %d\n",
						new_index.active, new_index.next, new_index.prev,
						new_index.ptr, new_index.length ) );
	
					hash_rec.ptr = index.prev;
					if ( DBPutIndexRecord( &hash_rec, &new_index ) != DB_SUCCESS )
					{
						DBGExit();
						return ( INDEXWRITEFAIL );
					}

					/*
					 * Since this was the very first link, it
					 * obviously needs to be stuffed in front of the 
					 * current first link for this hash table entry.
					 */

					tmp_hash_rec = ( HASH_REC * ) hash_link->hash;
					tmp_hash_rec->ptr = index.prev;
					DB_Hash_Modified = True;
	
				}
	
				else
				{
					/*
					 * index follows new_index, and index is not the head of
					 * the index link list
					 */
					DBGPrint( DBG_INFO, 
						"Adding new record after index pointed to by hash.\n");

					new_index.prev = index.prev;
					hash_rec.ptr = index.prev;
					if ( DBGetIndexRecord ( &hash_rec, &prev_index ) != DB_SUCCESS )
					{
						DBGExit();
						return ( INDEXERR );
					}
					new_index.next = prev_index.next;
	
					/*
					 * Get the file stat information for the index, this is 
					 * where the new index record will go
					 */
					rc = stat ( DB_Index_Filename, &stat_buf );
					prev_index.next = stat_buf.st_size;
					index.prev = stat_buf.st_size;
	
					/*
					 * Get the file stat information for the database
					 */
					if ( ( rc = stat ( DB_Filename, &stat_buf ) ) != 0 )
					{
						DBGPrintf( DBG_INFO, 
							("error (rc= %d) stating %s\n", rc, DB_Filename) );

						DBGExit();
						return ( STATDBERR );
					}

					DBGPrintf( DBG_INFO, 
						("stat of %s succeeded\n", DB_Filename) );

					/*
					 * Set the new indexes pointer to the location and
					 * the length of the record being added to the flat file
					 */
					new_index.ptr = stat_buf.st_size;
					new_index.length = strlen ( record );
	
					/*
					 * Append record to the database file
					 */
		
					/*
					 * open the flat file
					 */
					if ( (datafp = open( DB_Filename, 
							O_CREAT | O_WRONLY | O_APPEND ) ) < 0 )
					{
						DBGExit();
						return ( DBOPENFAIL );
					}

					/*
					 * Append the record to the file
					 */
					if ( write( datafp, record, strlen ( record ) ) < 0 )
					{
						DBGExit();
						return ( DBWRITEFAIL );
					}
					close ( datafp );

					/*
					 * Rewrite previous index
					 */
					DBGPrintf( DBG_INFO, 
						("rewriting previous index:\n"
						"\tactive: %d\n"
						"\tnext  : %d\n"
						"\tprev  : %d\n"
						"\tptr   : %d\n"
						"\tlength: %d\n",
						prev_index.active, prev_index.next, prev_index.prev,
						prev_index.ptr, prev_index.length ) );

					hash_rec.ptr = new_index.prev;
					if ( DBPutIndexRecord ( &hash_rec, &prev_index ) != 0 )
					{
						DBGExit();
						return ( INDEXWRITEFAIL );
					}
	
					/*
					 * Rewrite current index
					 */
					DBGPrintf( DBG_INFO,
						("rewriting index:\n"
						"\tactive: %d\n"
						"\tnext  : %d\n"
						"\tprev  : %d\n"
						"\tptr   : %d\n"
						"\tlength: %d\n",
						index.active, index.next, index.prev,
						index.ptr, index.length ) );

					hash_rec.ptr = new_index.next;
					if ( DBPutIndexRecord ( &hash_rec, &index ) != 0 )
					{
						DBGExit();
						return ( INDEXWRITEFAIL );
					}
	
					/*
					 * Write index for record being added
					 */
					DBGPrintf( DBG_INFO,
						("writing new index:\n"
						"\tactive: %d\n"
						"\tnext  : %d\n"
						"\tprev  : %d\n"
						"\tptr   : %d\n"
						"\tlength: %d\n",
						new_index.active, new_index.next, new_index.prev,
						new_index.ptr, new_index.length ) );

					hash_rec.ptr = index.prev;
					if ( DBPutIndexRecord( &hash_rec, &new_index ) != 0 )
					{
						DBGExit();
						return ( INDEXWRITEFAIL );
					}

				}	/*
					 * End of "index follows new_index, and index is 
					 * not the head of the index link list"
					 */

			}	/*
				 * End of "the index should follow the new index.  
				 * There are two ways this can happen:"
				 */

			break;
	

	}	/* end of "switch ( hash_pos )" */
	

	/*
	 * Now we need to add a hash link, in certain situations that is...
	 */

	if (	( hash_pos == DB_NOMATCH )||
			( hash_pos == ENDOFHASHLIST ) ||
			( hash_pos == NULLHASHTABLE ) ||
			( hash_pos == NEWHEAD ) )
	{
		DBGPrint( DBG_INFO, "adding a hash entry\n" );

		/*
		 * Allocate the new hash link and hash record
		 */
		new_hash_link = ( HASH_LINK * ) malloc ( sizeof ( HASH_LINK ) );
		new_hash = ( HASH_REC * ) malloc ( sizeof ( HASH_REC ) );
	
		/*
		 * Fill the new hash record
		 */
		new_hash->ptr = hash_rec.ptr;
		strcpy ( new_hash->name, hash_rec.name );

		/*
		 * And stuff it in the hash link
		 */
		new_hash_link->hash = (int) new_hash;

		switch ( hash_pos )
		{

			case NULLHASHTABLE:

				/*
				 * set flag so hash is rewritten on exit
				 */
				DB_Hash_Modified = True;

				/*
				 * make the new hash the head of the table
				 */
				DB_Hash_Head = (int) new_hash_link;

				/*
				 * fill in the hash link pointers
				 */
				new_hash_link->prev = 0;
				new_hash_link->next = 0;

				break;


			case DB_NOMATCH:
			case ENDOFHASHLIST:

				DBGPrint(DBG_INFO, "Adding new hash after current hash\n" );
				{
					HASH_LINK	*i;
					HASH_REC		*ptr;

					DBGPrint(DBG_INFO, "Dump of hash table before adding link\n" );

					i = (HASH_LINK *)DB_Hash_Head;
					while ( i != 0 )
					{
						ptr = (HASH_REC *)i->hash;
						DBGPrintf(DBG_INFO,
							(	"\nlink: 0x%08x  "
								  "link->next: 0x%08x  "
								  "link->prev: 0x%08x  "
								  "hash->ptr: %d\n",
									(int)i, (int)i->next, 
									(int)i->prev, ptr->ptr) );
						i = (HASH_LINK *)i->next;
					}
				}

				/*
				 * set flag so hash is rewritten on exit
				 */
				DB_Hash_Modified = True;

				/*
				 * "hash_link" points to the link that should precede 
			 	 * the new link
				 */
				new_hash_link->prev = hash_link;
				new_hash_link->next = hash_link->next;
				hash_link->next = new_hash_link;
	
				/*
				 * If there is a link after the new one, make it point
			 	 * to the new one
				 */
				if ( new_hash_link->next != 0 )
				{
					DBGPrint( DBG_INFO, "adding hash in middle of table\n" );
					tmp_hash_link = new_hash_link->next;
					tmp_hash_link->prev = new_hash_link;
				}

				{
					HASH_LINK	*i;
					HASH_REC		*ptr;

					DBGPrint(DBG_INFO, "Dump of hash table after adding link\n" );

					i = (HASH_LINK *)DB_Hash_Head;
					while ( i != 0 )
					{
						ptr = (HASH_REC *)i->hash;
						DBGPrintf(DBG_INFO,
							(	"\nlink: 0x%08x  "
								  "link->next: 0x%08x  "
								  "link->prev: 0x%08x  "
								  "hash->ptr: %d\n",
									(int)i, (int)i->next, 
									(int)i->prev, ptr->ptr) );
						i = (HASH_LINK *)i->next;
					}
				}

				break;
	

			case NEWHEAD:

				DBGPrintf(DBG_INFO,
					("Adding new hash at head of list\n"
						"\thash_link      : 0x%08x\n"
						"\thash_link->next: 0x%08x\n"
						"\thash_link->prev: 0x%08x\n",
							(int)hash_link, (int)hash_link->next, 
							(int)hash_link->prev) );
				/*
				 * set flag so hash is rewritten on exit
				 */
				DB_Hash_Modified = TRUE;
	
				/*
				 * "hash_link" points to the link that should follow 
			 	 * the new link
				 */

				DBGPrint ( DBG_INFO, "adding a new head to hash table\n");

				new_hash_link->next = hash_link;
				new_hash_link->prev = 0;
				hash_link->prev = new_hash_link;

				DBGPrintf(DBG_INFO,
					("new_hash_link.next: %x\n"
					 "new_hash_link.prev: %x\n",
					 (unsigned int) new_hash_link->next,
					 (unsigned int) new_hash_link->prev) );
	
				DBGPrint( DBG_INFO, "adding hash at start of database table\n" );

				DB_Hash_Head = (int) new_hash_link;
				DBGPrintf(DBG_INFO, ("hash_head: %x\n", DB_Hash_Head) );

				break;
		}
	
		DBGPrint( DBG_INFO, "done adding hash table entry\n" );
	}

	return ( DB_SUCCESS );

}

#endif /* DBINSERT_C */
