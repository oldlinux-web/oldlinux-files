/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: DBStats.c
 *            DESCRIPTION: compute statistics on the database
 *      DEFINED CONSTANTS: db.h
 *       TYPE DEFINITIONS: db.h
 *      MACRO DEFINITIONS: db.h
 *       PUBLIC FUNCTIONS: DBStats
 *      PRIVATE FUNCTIONS: 
 *                  NOTES: set tabstops=3 for readability
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/DB, no underscores, mixed case		DBPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/DB, underscores, mixed case			DB_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBSTATS_C
#define DBSTATS_C

/* === System Headers === */
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <math.h>

/* === Project Headers === */
#include "db.h"
#include "debug.h"

/* === external routines === */
extern int DBGetIndexRecord();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */



/*========================================================================
 *	Name:			DBStats
 *	Prototype:	DBStats()
 *
 *	Description:
 *		compute statistics on the database
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *		int		DB_Hash_Head			head of hash table link list
 *		char		*DB_Filename			name of flat file
 *		char		*DB_Index_Filename	name of index file
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
int
DBStats(
	DB_STAT	*dbstat
)
{

#ifdef DEBUG
	char			fname[]="DBStats()";
#endif

	struct stat	stat_buf;			/* stat structure for various files */
	HASH_LINK	*hash_link;			/* hash link */
	HASH_REC		hash_rec, *hash_ptr;	/* hash records */
	INDEX_REC	index;				/* index record */


	if ( dbstat == NULL )
		return ( DB_NULL_STAT );

	hash_link = (HASH_LINK *) DB_Hash_Head; 

	/*
	 * compute the number of hash entries
	 */
	dbstat->num_hash = 0;
	while ( hash_link != 0 )
	{
		dbstat->num_hash++;
		hash_link = hash_link->next;
	}
	
	/*
	 * get length of flat file
	 */
	if ( ( stat ( DB_Filename, &stat_buf ) ) != 0 )
		return ( DB_CANT_STAT_FLATFILE );

	dbstat->ff_length = stat_buf.st_size;
	

	/*
	 * grab the head of the hash link
	 */
	hash_link = (HASH_LINK *) DB_Hash_Head; 


	/*
	 * Compute the number of active records
	 */
	dbstat->num_act_recs = 0;
	if ( hash_link != NULL )
	{
		/*
		 * Get a copy of the first hash record
		 */
		hash_ptr = (HASH_REC *) hash_link->hash;
		bcopy ( (char *)hash_ptr, (char *)&hash_rec, sizeof ( HASH_REC ) );

		/*
		 * Get first index record
		 */
		if ( DBGetIndexRecord ( &hash_rec, &index ) != DB_SUCCESS )
			return( INDEXFAIL );

		/*
		 * Increment record counter
		 */
		dbstat->num_act_recs++;
		
		/*
		 * While there are more records
		 */
		while ( index.next != -1 )
		{
		
			/*
			 * get next index record
			 */
			hash_rec.ptr = index.next;
			if ( DBGetIndexRecord ( &hash_rec, &index ) != DB_SUCCESS )
				return ( INDEXFAIL );

			/*
			 * increment record counter
			 */
			dbstat->num_act_recs++;

		}
	}
	DBGPrintf(DBG_INFO, ("number of active records: %d\n", dbstat->num_act_recs) );

	/*
	 * compute the total number of records in the database
	 */
	if ( ( stat ( DB_Index_Filename, &stat_buf ) ) !=0 )
		return ( DB_CANT_STAT_INDEXFILE );

	dbstat->i_length = stat_buf.st_size;
	if ( dbstat->i_length > 0 )
		dbstat->tot_num_recs = (int) ( dbstat->i_length / 20 );
	else
		dbstat->tot_num_recs = 0;

	/*
	 * compute number of inactive recors
	 */
	dbstat->num_inact_recs = dbstat->tot_num_recs - dbstat->num_act_recs;

	/*
	 * compute percentage of inactive records in database
	 */
	if ( dbstat->tot_num_recs > 0 )
		dbstat->perc = (int) floor ( 100 * 
					(double)( (double) dbstat->num_inact_recs / 
								(double) dbstat->tot_num_recs ) );
	else
		dbstat->perc = 0;

	return (DB_SUCCESS);
}


#endif /* DBSTATS_C */
