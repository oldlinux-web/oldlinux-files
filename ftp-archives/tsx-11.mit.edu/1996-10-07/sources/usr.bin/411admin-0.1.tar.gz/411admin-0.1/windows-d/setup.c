/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: setup.c
 *            DESCRIPTION: routines which prepare the 411admin environment
 *								 : for use with the selected function.
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMAddSetup, ADMViewSetup
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 *  Since this was ported from my original (and poorly written) Motif
 *  version, the variable names don't quite match the following
 *  special considerations.  But I'm trying to fix that.
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout all 411Admin
 * source:
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, key words capitalized			PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 *		no underscores, mixed case							staticVariable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 *	$Log$
 *
 *========================================================================*/
#ifndef SETUP_C
#define SETUP_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <stdio.h>
#include <stdlib.h>

/* === Project Headers === */
#include "debug.h"
#include "display.h"

/* === external routines === */
extern void ADMRemoveCallbacks();
extern void ADMAddAddCallbacks();
extern void ADMAddViewCallbacks();
extern void ADMGetRecord();
extern void ADMRecordDelete();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
extern Widget 		optionsButton;			/* options button on menu bar */
extern Widget 		optionMenuButton[NUM_OPTIONMENU];
													/* buttons in pop-down menu from
													 * Options button on Menu Bar
													 */
extern Widget 		databaseMenuButton[NUM_DATABASEMENU];
													/* buttons in pop-down menu from
													 * Database button on Menu Bar
													 */

extern char			*ADM_User_Data_String;
													/* string to pass to db library
													 * routines
													 */
extern char			*ADM_Old_Record;		/* string to pass to db library
													 * routines
													 */


/*========================================================================
 *	Name:			ADMAddSetup
 *	Prototype:	ADMAddSetup()
 *					
 *
 *	Description:
 *		set up menu buttons and callbacks for adding a record
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMAddSetup(
	Widget w,
	XtPointer client_data, 
	XtPointer call_data
)
{

#ifdef DEBUG
	char	fname[]="ADMAddSetup()";
#endif

	int	i;

	DBGEnter();

	/*
	 * Remove any callbacks for the Options menu buttons
	 * Since we don't from where this is called, we must remove them all
	 * in order to prepare the for the current function.
	 */
	ADMRemoveCallbacks();


	/*
	 * make the Options Menu Bar button active
	 * then activate only the options we need
	 */
	XtSetSensitive ( optionsButton, True );
	for ( i = 0; i < NUM_OPTIONMENU; i++ )
	{
		switch ( i )
		{
			case ACCEPTOPTION:
			case COMMENTSOPTION:
			case EMAILOPTION:
			case PHONEOPTION:
			case CLEARALLOPTION:
			case CLEARRECOPTION:
				XtSetSensitive ( optionMenuButton[i], True );
				break;

			case SEPERATOROPTION:
				break;

			default:
				XtSetSensitive ( optionMenuButton[i], False );
				break;
		}
	}

	/*
	 * add the callbacks necessary for this function
	 */
	ADMAddAddCallbacks();

	DBGExit();
}


/*========================================================================
 *	Name:			ADMViewSetup
 *	Prototype:	ADMViewSetup()
 *
 *	Description:
 *		callback to set items in the Main Menu Options pulldown menu
 *		when the Database View option is selected.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMViewSetup (
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char	fname[]="ADMViewSetup()";
#endif

	int	i;

	DBGEnter();


	/*
	 * Remove any callbacks for the Options menu buttons
	 * Since we don't from where this is called, we must remove them all
	 * in order to prepare the for the current function.
	 */
	ADMRemoveCallbacks();


	/*
	 * set the callbacks for the menu options
	 */
	for ( i = 0; i < NUM_OPTIONMENU; i++ )
	{
		switch ( i )
		{
			/*
			 * When viewing records, we can view any of the fields, plus
			 * do a search for a specific record.
			 */
			case PHONEOPTION:
			case EMAILOPTION:
			case COMMENTSOPTION:
			case SEARCHOPTION:
			case CLEARALLOPTION:
			case CLEARRECOPTION:
				XtSetSensitive ( optionMenuButton[i], True );
				break;

			case SEPERATOROPTION:
				break;

			default:
				XtSetSensitive ( optionMenuButton[i], False );
				break;
		}

	}

	/*
	 * add the callbacks necessary for this function
	 */
	ADMAddViewCallbacks();

	DBGExit();
}


/*========================================================================
 *	Name:			ADMDeleteSetup
 *	Prototype:	ADMDeleteSetup()
 *
 *	Description:
 *		callback to set items in the Main Menu Options pulldown menu
 *		when the Database Delete option is selected.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		This routine doesn't currently do anything, but its here in case  
 *		future development needs it.  It adheres to the same layout that
 *		ADMViewSetup and ADMAddSetup started.
 *		
 *========================================================================*/
void
ADMDeleteSetup (
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char	fname[]="ADMDeleteSetup()";
#endif

	int	i;

	DBGEnter();

	/*
	 * Remove any callbacks for the Options menu buttons
	 * Since we don't from where this is called, we must remove them all
	 * in order to prepare the for the current function.
	 */
	ADMRemoveCallbacks();


	/*
	 * set the sensitivity off for all the Options menu buttons
	 */
	for ( i = 0; i < NUM_OPTIONMENU; i++ )
	{
		switch ( i )
		{
			case SEPERATOROPTION:
				break;

			default:
				XtSetSensitive ( optionMenuButton[i], False );
				break;
		}

	}

	DBGExit();
}


/*========================================================================
 *	Name:			ADMUpdateSetup
 *	Prototype:	ADMUpdateSetup()
 *
 *	Description:
 *		callback to setup for updating a record
 *		when the Database Update option is selected.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMUpdateSetup (
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{
	/*
	 * Copy the ADM_User_Data_String to the ADM_Old_Record
	 */
	ADM_Old_Record = ( char * ) malloc ( strlen ( ADM_User_Data_String ) + 1 );
	strcpy ( ADM_Old_Record, ADM_User_Data_String );
}

#endif /* SETUP_C */
