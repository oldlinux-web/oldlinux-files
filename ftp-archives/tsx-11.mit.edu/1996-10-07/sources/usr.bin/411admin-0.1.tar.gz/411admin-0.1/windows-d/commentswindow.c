/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: commentswindow.c
 *            DESCRIPTION: manage the Comments window
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMCreateComments
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef COMMENTS_C
#define COMMENTS_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/SmeLine.h>
#include <X11/Xaw/SmeBSB.h>
#include <X11/Xaw/AsciiText.h>
#include <stdio.h>

/* === Project Headers === */
#include "411admin.h"
#include "display.h"
#include "help.h"
#include "debug.h"

/* === external routines === */
extern void ADMPopDownWindow();
extern void ADMPopUpHelp();
extern void ADMSetSensitive();
extern void ADMClearWindow();
extern int	ADMAddHelp();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
extern Widget	transientAppShell;	/* text for help window */
extern Widget	commentsShell;			/* pop up window for comments */

extern Widget	optionMenuButton[NUM_OPTIONMENU];
											/* buttons in pop-down menu from
											 * Options button on Menu Bar
											 */

Widget 			commentsScrolledWindow;	/* where comments are entered */

/* === Static Variables === */
char *comments_file_menu[] = {	/* items in the Options pull down menu */
	"Clear",
	"Close"
	};


/*========================================================================
 *	Name:			ADMCreateComments
 *	Prototype:	ADMCreateComments()
 *
 *	Description:
 *		Create the widgets necessary for the Comments window
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
ADMCreateComments()
{
	char				fname[]="ADMCreateComments()";
	char				buf[64];
	int				nargs;
	Arg				args[20];
	Dimension		width, twidth, height;
	int				startpos;
	int				i;


	Widget		commentsForm, comments_menubox;
	Widget		commentsFileButton, commentsFileMenu, commentsFileLine;
	Widget 		commentsFileMenuButton[NUM_COMMENTSMENU];
	Widget		comments_spacer;
	Widget		commentsTitle;
	Widget		commentsHelpButtonBox, commentsGetHelp;

	char			commentsHelpFile[]=COMMENTS_HELP_FILE;

	DBGEnter()

	/*
	 * COMMENTS SCROLLED WINDOW
	 */

	/*
	 * the main comments window
	 */
	DBGPrint(DBG_WINDOWS,"comments form\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	commentsForm = XtCreateManagedWidget(
			"commentsForm",			/* name */
			formWidgetClass,			/* class */
			commentsShell,				/* parent */
			args, nargs					/* arg list */
			);

	/*
	 * CREATE A BOX FOR THE MENU BUTTONS
	 */
	DBGPrint(DBG_WINDOWS,"creating menu box\n");

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, DEFAULT_COMMENTS_WIDTH ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNorientation, XtorientHorizontal ); nargs++;
	XtSetArg ( args[nargs], XtNvSpace, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhSpace, 0 ); nargs++;
	comments_menubox = XtCreateManagedWidget (
		"MenuBox",
		boxWidgetClass,
		commentsForm,
		args, nargs
		);

	/*
	 * CREATE FILE MENU AND CHILDREN
	 */

	DBGPrint(DBG_WINDOWS,"creating file menu\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Options" ); nargs++;
	XtSetArg ( args[nargs], XtNmenuName, "commentsFileMenu" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	commentsFileButton = XtCreateManagedWidget(
		"commentsFileButton",	/* widget name */
		menuButtonWidgetClass,	/* widget class */
		comments_menubox,			/* parent */
		args, nargs					/* argument list */
		);

	/*
	 * create menu popped down by statFileButton
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Comments Options" ); nargs++;
	commentsFileMenu = XtCreatePopupShell(
		"commentsFileMenu",		/* name */
		simpleMenuWidgetClass,	/* class */
		transientAppShell,		/* parent */
		args, nargs					/* no argument list needed */
		);

	/*
	 * a line seperator in the menu
	 */
	commentsFileLine = XtCreateManagedWidget(
		"commentsFileMenuLine",	/* name */
		smeLineObjectClass,		/* class */
		commentsFileMenu,			/* parent */
		NULL, 0						/* no argument list needed */
		);

	/*
	 * set the menu items in the pull-down menu
	 */
	for ( i = 0; i < NUM_COMMENTSMENU; i++ )
	{
		if ( i == NUM_COMMENTSMENU -1 )
			(void) sprintf ( buf, "commentsClose" );
		else
			(void) sprintf ( buf, "commentsMenu%d", i );

		nargs = 0;
		XtSetArg ( args[nargs], XtNlabel, comments_file_menu[i] ); nargs++;

		commentsFileMenuButton[i] = XtCreateManagedWidget(
			buf,						/* widget name */
			smeBSBObjectClass,	/* widget class */
			commentsFileMenu,		/* parent widget*/
			args, nargs				/* argument list */
			);

		/* set the callbacks */
		switch ( i )
		{
			case CMCLEAROPTION:
				XtAddCallback ( commentsFileMenuButton[i], XtNcallback,
						ADMClearWindow, (XtPointer) CLEAR_COMMENTS );
				break;

			case CMCLOSEOPTION:
				XtAddCallback( commentsFileMenuButton[i], 
					XtNcallback, ADMPopDownWindow, commentsShell );
				XtAddCallback( commentsFileMenuButton[i], 
					XtNcallback, ADMSetSensitive, optionMenuButton[COMMENTSOPTION]);
				break;

			default:
				break;
		}
	}

	/*
	 * CREATE A SPACER BETWEEN THE MENU BUTTONS AND THE HELP BUTTON
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &height ); nargs++;
	XtGetValues( commentsFileButton, args, nargs );

	DBGPrint(DBG_WINDOWS,"creating menu spacer\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "" ); nargs++;
	XtSetArg ( args[nargs], XtNheight, height ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, comments_menubox ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNresizable, True ); nargs++;
	comments_spacer = XtCreateManagedWidget(
		"menuSpacer",
		labelWidgetClass,
		commentsForm,
		args, nargs
		);

	/*
	 * create a box for the help button
	 */
	DBGPrint(DBG_WINDOWS,"creating help box\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, comments_spacer ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNorientation, XtorientHorizontal ); nargs++;
	XtSetArg ( args[nargs], XtNvSpace, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhSpace, 0 ); nargs++;
	commentsHelpButtonBox = XtCreateManagedWidget(
		"helpButtonBox",			/* name */
		boxWidgetClass,			/* class */
		commentsForm,				/* parent */
		args, nargs					/* arg list */
		);


	/*
	 * create button that will pop up the help window
	 */
	DBGPrint(DBG_WINDOWS,"creating help windows\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Help" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	commentsGetHelp = XtCreateManagedWidget(
		"getHelp",					/* name */
		commandWidgetClass,		/* class */
		commentsHelpButtonBox,	/* parent */
		args, nargs					/* arg list */
		);


	/*
	 * add the stats help text to the help box
	 */
	startpos = ADMAddHelp ( ADM_HELP_FILE, commentsHelpFile, 
						ADM_HELP_COMMENTS_LABEL);

	/*
	 * tell help button to pop up the help window and position the cursor
	 */
	DBGPrintf(DBG_WINDOWS,("start position for comments help text: %d\n", startpos));
   XtAddCallback ( commentsGetHelp, XtNcallback, 
			(XtCallbackProc)ADMPopUpHelp, (XtPointer)startpos );


	/*
	 * the comments window title bar
	 */
	DBGPrint(DBG_WINDOWS,"comments title bar\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, DEFAULT_COMMENTS_WIDTH ); nargs++;
	XtSetArg ( args[nargs], XtNlabel, "Comments" ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNjustify, XtJustifyCenter ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, comments_menubox ); nargs++;
	commentsTitle = XtCreateManagedWidget( 
			"commentsTitle",			/* name */
			labelWidgetClass,			/* class */
			commentsForm,				/* parent */ 
			args,	nargs					/* arg list */
			);


	/* readjust the width of the spacer */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &twidth ); nargs++;
	XtGetValues( commentsFileButton, args, nargs );
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( commentsGetHelp, args, nargs );
	twidth += width;
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( commentsTitle, args, nargs );
	twidth = width - twidth + 2;
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, twidth ); nargs++;
	XtSetValues( comments_spacer, args, nargs );


	/* the editable scrolled window */
	DBGPrint(DBG_WINDOWS,"comments text window\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, DEFAULT_COMMENTS_WIDTH ); nargs++;
	XtSetArg ( args[nargs], XtNheight, DEFAULT_COMMENTS_HEIGHT); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, commentsTitle ); nargs++;
	XtSetArg ( args[nargs], XtNstring, "" ); nargs++;
	XtSetArg ( args[nargs], XtNeditType, XawtextEdit ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom ); nargs++;
	XtSetArg ( args[nargs], XtNwrap, True ); nargs++;
	XtSetArg ( args[nargs], XtNwrap, XawtextWrapWord ); nargs++;
	XtSetArg ( args[nargs], XtNscrollHorizontal, XawtextScrollNever ); nargs++;
	XtSetArg ( args[nargs], XtNscrollVertical, XawtextScrollWhenNeeded ); 
		nargs++;
	commentsScrolledWindow = XtCreateManagedWidget (
			"commentsScrolledWindow",	/* name */
			asciiTextWidgetClass,		/* class */
			commentsForm,					/* parent */
			args,	nargs						/* arg list */
			);

	DBGExit();

}

#endif /* COMMENTS_C */
