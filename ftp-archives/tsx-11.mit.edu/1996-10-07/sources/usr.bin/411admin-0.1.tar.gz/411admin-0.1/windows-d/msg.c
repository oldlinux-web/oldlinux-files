/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: msg.c
 *            DESCRIPTION: handles msg window display
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMDestroyMsg, ADMPopUpMsg
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef MSG_C
#define MSG_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Dialog.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Viewport.h>
#include <stdio.h>

/* === Project Headers === */
#include "display.h"
#include "debug.h"

/* === external routines === */
extern void ADMPopUpWindow();

/* === Global variables === */
extern Widget transientAppShell; 	/* top level shell for transients */

/* === Static variables === */


/*========================================================================
 *	Name:			ADMDestroyMsg
 *	Prototype:	ADMDestroyMsg()
 *					
 *
 *	Description:
 *		Destroys the message shell and its children.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMDestroyMsg(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{
	XtDestroyWidget ( (Widget) client_data );
}


/*========================================================================
 *	Name:			ADMPopUpMsg
 *	Prototype:	ADMPopUpMsg( char *msg, int type )
 *					
 *
 *	Description:
 *		Creates and pops up the message shell and its children.  It is
 *		necessary to recreate the message shell each time since geometry
 *		management tools don't seem to allow for changing the parent shell
 *		width when the childs Dialog label changes.  At least *I* couldn't
 *		get them to do so.
 *
 *	Input Arguments:
 *		char	*msg				string that contains the message
 *		int	type				a string for the title of the window
 *									see "display.h"
 *
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMPopUpMsg(
	char	*msg,
	int	type
)
{
#ifdef DEBUG
	char	fname[]="ADMPopUpMsg()";
#endif

	Arg	args[3];
	char	*title;

	Widget	ADM_Msg_Shell;		/* pop up window for message information */
	Widget	ADM_Msg_Dialog;	/* dialog containing message information */
	Widget	msgOK;				/* OK button for message dialog */


	DBGEnter();

	switch ( type )
	{
		case ADM_ERROR_TYPE:
			title = ADM_ERROR_TITLE;
			break;
		case ADM_MSG_TYPE:
			title = ADM_MSG_TITLE;
			break;
		case ADM_INFO_TYPE:
			title = ADM_INFO_TITLE;
			break;
		default:
			title = NULL;
			break;
	}

	DBGPrintf(DBG_INFO, ("message= \"%s\"\n", msg ));

	/*
	 * Create popup for message messages
	 */
	if ( title != NULL )
	{
		XtSetArg ( args[0], XtNtitle, title );
		ADM_Msg_Shell = XtCreatePopupShell (
			"Message",							/* widget name */
			transientShellWidgetClass,		/* class */
			transientAppShell,				/* parent */
			args,	1								/* arg list */
			);
	}
	else
	{
		ADM_Msg_Shell = XtCreatePopupShell (
			"Message",								/* widget name */
			transientShellWidgetClass,		/* class */
			transientAppShell,				/* parent */
			NULL,	0								/* arg list */
			);
	}
	

	/*
	 * Dialog containing message
	 */
	XtSetArg ( args[0], XtNlabel, msg );
	ADM_Msg_Dialog = XtCreateManagedWidget (
		"msgDialog",				/* widget name */
		dialogWidgetClass,		/* class */
		ADM_Msg_Shell,				/* parent */
		args,	1						/* arg list */
		);

	/*
	 * button to close dialog
	 */
	XtSetArg ( args[0], XtNlabel, "OK");
	msgOK = XtCreateManagedWidget (
		"msgOK",						/* widget name */
		commandWidgetClass,		/* class */
		ADM_Msg_Dialog,			/* parent */
		args,	1						/* arg list */
		);

	/*
	 * callbacks for pressing the OK button on the Message Dialog
	 */
	XtAddCallback ( msgOK, XtNcallback,
		(XtCallbackProc) ADMDestroyMsg, ADM_Msg_Shell );

	XtPopup ( ADM_Msg_Shell, XtGrabExclusive );
}

#endif /* MSG_C */
