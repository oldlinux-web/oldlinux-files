/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: statswindow.c
 *            DESCRIPTION: manage the statistics window
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: 411CreateStats
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef STATSWINDOW_C
#define STATSWINDOW_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Text.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/Viewport.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/SmeLine.h>
#include <X11/Xaw/SmeBSB.h>
#include <stdio.h>

/* === Project Headers === */
#include "411admin.h"
#include "display.h"
#include "help.h"
#include "textstrings.h"
#include "debug.h"

/* === external routines === */
extern void ADMPopDownWindow();
extern void ADMPopUpWindow();
extern void ADMPopUpHelp();
extern void ADMDBStats();
extern int	ADMAddHelp();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
extern Widget		ADM_Top_Level;			/* parent for all widgets */
extern Widget		helpShell;				/* pop up help window */
extern Dimension	mainFormHeight;		/* height of main form */
extern Dimension	mainFormWidth;			/* width of main form */

Widget		statShell; 							/* pop up shell window 
														 * for file statistics
														 */
Widget		statViewPort; 						/* window for file statistics */
Widget 		statViewPortForm; 				/* window for file statistics */
Widget 		statTextFields[NUM_STATTEXT];	/* stat display widgets */
Dimension	statViewPortHeight;				/* height of the view port */
Dimension	statViewPortWidth;				/* height of the view port */

/* === Static Variables === */
char *statLabels[] = {
	"Length of flat file",
	"",
	"Number of hash records",
	"",
	"Total number of records",
	"Number of active records",
	"Number of inactive records",
	"",
	"Percentage of inactive records"
	};

char *stat_file_menu[] = {			/* items in the Options pull down menu */
	"Recalculate",
	"Close"
	};


/*========================================================================
 *	Name:			ADMCreateStats
 *	Prototype:	ADMCreateStats()
 *
 *	Description:
 *		Create the widgets necessary for the Stats window
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
ADMCreateStats()
{
	char				fname[]="ADMCreateStats()";
	char				buf[64];
	int				i, nargs;
	Arg				args[20];
	Dimension		width, twidth, height, theight;
	int				startpos;
	char				statsHelpFile[]=STATS_HELP_FILE;

	/* statistics windows */
	Widget		statAppShell;		/* top level for stats window */

	/* menu bar and buttons */
	Widget		stat_menubox, statFileButton, statFileMenu, statFileLine;
	Widget 		statFileMenuButton[NUM_STATMENU];
	Widget		stat_spacer;
	Widget		statHelpButtonBox, statGetHelp;

	Widget statForm; 							/* window for file statistics */
	Widget statTitle;							/* title bar of stat window */
	Widget statLabelFields[NUM_STATLABELS];
													/* label widgets for prompts */
	Widget statTextWindow;					/* form where numbers go */
	Widget statLabelWindow;					/* form where labels go */


	DBGEnter();

	/* VIEW FILE STATISTICS */
	
	/* THE MAIN FILE STATISTICS WINDOW */
	DBGPrint(DBG_WINDOWS, "main stats window\n");

	statAppShell = XtAppCreateShell (
			"Statistics",						/* name */
			"statAppShell",					/* app class */
			applicationShellWidgetClass,	/* widget class */
			XtDisplay (ADM_Top_Level),		/* display */
			NULL, 0								/* args */
			);

	statShell = XtCreatePopupShell (
			"Statistics",					/* name */
			transientShellWidgetClass,	/* class */
			statAppShell,					/* parent */
			NULL, 0							/* args */
			);

	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, mainFormHeight ); nargs++;
	XtSetArg ( args[nargs], XtNwidth, mainFormWidth ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	statForm = XtCreateManagedWidget(
			"statForm",			/* name */
			formWidgetClass,	/* class */
			statShell,			/* parent */
			args, nargs			/* arg list */
			);

	/*
	 * CREATE A BOX FOR THE MENU BUTTONS
	 */
	DBGPrint(DBG_WINDOWS,"creating menu box\n");

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, mainFormWidth ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNorientation, XtorientHorizontal ); nargs++;
	XtSetArg ( args[nargs], XtNvSpace, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhSpace, 0 ); nargs++;
	stat_menubox = XtCreateManagedWidget (
		"MenuBox",
		boxWidgetClass,
		statForm,
		args, nargs
		);

	/*
	 * CREATE FILE MENU AND CHILDREN
	 */

	DBGPrint(DBG_WINDOWS,"creating file menu\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Options" ); nargs++;
	XtSetArg ( args[nargs], XtNmenuName, "statFileMenu" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	statFileButton = XtCreateManagedWidget(
		"statFileButton",			/* widget name */
		menuButtonWidgetClass,	/* widget class */
		stat_menubox,				/* parent */
		args, nargs					/* argument list */
		);

	/*
	 * create menu popped down by statFileButton
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Menu" ); nargs++;
	statFileMenu = XtCreatePopupShell(
		"statFileMenu",			/* name */
		simpleMenuWidgetClass,	/* class */
		statAppShell,				/* parent */
		args, nargs					/* no argument list needed */
		);

	/*
	 * a line seperator in the menu
	 */
	statFileLine = XtCreateManagedWidget(
		"statFileMenuLine",		/* name */
		smeLineObjectClass,		/* class */
		statFileMenu,				/* parent */
		NULL, 0						/* no argument list needed */
		);

	/*
	 * set the menu items in the pull-down menu
	 */
	for ( i = 0; i < NUM_STATMENU; i++ )
	{
		if ( i == NUM_STATMENU -1 )
			(void) sprintf ( buf, "statClose" );
		else
			(void) sprintf ( buf, "fileMenu%d", i );

		nargs = 0;
		XtSetArg ( args[nargs], XtNlabel, stat_file_menu[i] ); nargs++;

    	statFileMenuButton[i] = XtCreateManagedWidget(
            buf,						/* widget name */
            smeBSBObjectClass,	/* widget class */
            statFileMenu,			/* parent widget*/
				args, nargs				/* argument list */
				);

		/* set the callbacks */
		switch ( i )
		{
			case SMRECALCULATEOPTION:
				XtAddCallback( statFileMenuButton[i],
						XtNcallback, (XtCallbackProc)ADMDBStats, NULL );
				break;

			case SMCLOSEOPTION:
				XtAddCallback( statFileMenuButton[i], 
					XtNcallback, ADMPopDownWindow, statShell );
				break;

			default:
				break;
		}
	}

	/*
	 * CREATE A SPACER BETWEEN THE MENU BUTTONS AND THE HELP BUTTON
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &height ); nargs++;
	XtGetValues( statFileButton, args, nargs );

	DBGPrint(DBG_WINDOWS,"creating menu spacer\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "" ); nargs++;
	XtSetArg ( args[nargs], XtNheight, height ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, stat_menubox ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNresizable, True ); nargs++;
	stat_spacer = XtCreateManagedWidget(
		"menuSpacer",
		labelWidgetClass,
		statForm,
		args, nargs
		);

	/*
	 * create a box for the help button
	 */
	DBGPrint(DBG_WINDOWS,"creating help box\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, stat_spacer ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNorientation, XtorientHorizontal ); nargs++;
	XtSetArg ( args[nargs], XtNvSpace, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhSpace, 0 ); nargs++;
	statHelpButtonBox = XtCreateManagedWidget(
		"helpButtonBox",			/* name */
		boxWidgetClass,			/* class */
		statForm,					/* parent */
		args, nargs					/* arg list */
		);


	/*
	 * create button that will pop up the help window
	 */
	DBGPrint(DBG_WINDOWS,"creating help windows\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Help" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	statGetHelp = XtCreateManagedWidget(
		"getHelp",					/* name */
		commandWidgetClass,		/* class */
		statHelpButtonBox,		/* parent */
		args, nargs					/* arg list */
		);


	/*
	 * add the stats help text to the help box
	 */
	startpos = ADMAddHelp ( ADM_HELP_FILE, statsHelpFile, 
						ADM_HELP_STATS_LABEL);

	/*
	 * tell help button to pop up the help window and position the cursor
	 */
	DBGPrintf(DBG_WINDOWS,("start position for stat help text: %d\n", startpos));
   XtAddCallback ( statGetHelp, XtNcallback, 
			(XtCallbackProc)ADMPopUpHelp, (XtPointer)startpos );


	/*
	 * the title bar for the window
	 */
	DBGPrint(DBG_WINDOWS, "stats title bar\n");

	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, STATS_TITLE ); nargs++;
	XtSetArg ( args[nargs], XtNwidth, mainFormWidth ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 1 ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, stat_menubox ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	statTitle = XtCreateManagedWidget( 
			"statTitle",				/* name */
			labelWidgetClass,			/* class */
			statForm,    				/* parent */ 
			args, nargs					/* arg list */
			);

	/* readjust the width of the spacer */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &twidth ); nargs++;
	XtGetValues( statFileButton, args, nargs );
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( statGetHelp, args, nargs );
	twidth += width;
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( statTitle, args, nargs );
	twidth = width - twidth + 2;
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, twidth ); nargs++;
	XtSetValues( stat_spacer, args, nargs );


	/* the viewport inside which all the rest of the windows will go */
	DBGPrint(DBG_WINDOWS, "stats viewport\n");

	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &height ); nargs++;
	XtGetValues ( statTitle, args, nargs );
	statViewPortHeight = mainFormHeight - height;

	DBGPrintf(DBG_WINDOWS, ("view port height and width\n\theight:%d\twidth:%d\n",
				height, mainFormWidth));

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, mainFormWidth ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, statTitle ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 1 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNuseBottom, True ); nargs++;
	XtSetArg ( args[nargs], XtNallowHoriz, True ); nargs++;
	XtSetArg ( args[nargs], XtNallowVert, True ); nargs++;
	statViewPort = XtCreateManagedWidget(
			"statViewPort",		/* name */
			viewportWidgetClass,	/* class */
			statForm,				/* parent */
			args, nargs				/* arg list */
			);


	/* a form constraint as the main child of the view port */
	nargs = 0;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	statViewPortForm = XtCreateManagedWidget(
			"statViewPortForm",	/* name */
			formWidgetClass,		/* class */
			statViewPort,			/* parent */
			args, nargs				/* arg list */
			);



	/* THE STATS LABELS */

	/* create a form window for the stats labels */
	DBGPrint(DBG_WINDOWS, "labels form window\n");

	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	statLabelWindow = XtCreateManagedWidget (
			"statLabelWindow",
			formWidgetClass,
			statViewPortForm,
			args, nargs
			);

	/* create the stat window label fields */
	DBGPrint(DBG_WINDOWS, "labels\n");
	theight = 0;
	for ( i = 0; i < NUM_STATLABELS; i++ )
	{

		nargs = 0;
		XtSetArg ( args[nargs], XtNlabel, statLabels[i] ); nargs++;
		XtSetArg ( args[nargs], XtNjustify, XtJustifyRight ); nargs++;
		XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
		XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
		XtSetArg ( args[nargs], XtNright, XtChainLeft ); nargs++;
		XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
		XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
		XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
		XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
		XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
		statLabelFields[i] = XtCreateWidget(
           	buf,
				labelWidgetClass,
           	statLabelWindow,
				args, nargs
           	);
		nargs = 0;
		XtSetArg ( args[nargs], XtNheight, &height );
		XtGetValues ( statLabelFields[i], args, 1 );
		theight += height;
	}

	/*
	 * add one more arg - this is cleaner that trying to do it
	 * in the last loop
	 */
	DBGPrint(DBG_WINDOWS, "resetting labels fromHoriz resource\n");
	for ( i = 1; i < NUM_STATLABELS; i++ )
	{
		XtSetArg ( args[0], XtNfromVert, statLabelFields[i-1] );
		XtSetValues ( statLabelFields[i], args, 1 );
	}

	XtManageChildren ( statLabelFields, NUM_STATLABELS );


	/*
	 * find the widest (in pixels) label of the bunch and make all
	 * the labels the same width - this will allow for right justification
	 */
	DBGPrint(DBG_WINDOWS, "finding widest label\n");
	twidth = 0;
	for ( i = 0; i < NUM_STATLABELS; i++ )
	{
		XtSetArg ( args[0], XtNwidth, &width );
		XtGetValues ( statLabelFields[i], args, 1 );

		if ( width > twidth )
			twidth = width;
	}
	for ( i = 0; i < NUM_STATLABELS; i++ )
	{
		XtSetArg ( args[0], XtNwidth, twidth );
		XtSetValues ( statLabelFields[i], args, 1 );
	}

	/*
	 * now determine how wide to make the output labels
	 */
	width = mainFormWidth - twidth;


	/* THE FORM WINDOW INSIDE WHICH THE OUTPUT FIELDS WILL GO */


	DBGPrint(DBG_WINDOWS, "output fields form\n");
	
	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, statLabelWindow ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	statTextWindow = XtCreateManagedWidget (
			"statTextWindow",
			formWidgetClass,
			statViewPortForm,
			args, nargs
			);



	/* create the stat window output fields */
	DBGPrint(DBG_WINDOWS, "output fields\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &height ); nargs++;
	XtGetValues ( statLabelFields[0], args, nargs );

	for ( i = 0; i < NUM_STATTEXT; i++ )
	{
		(void)sprintf ( buf, "statTextFields%d", i );
		nargs = 0;
		XtSetArg ( args[nargs], XtNheight, height ); nargs++;
		XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
		XtSetArg ( args[nargs], XtNright, XtChainLeft ); nargs++;
		XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
		XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
		XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
		XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
		XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
		XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
		XtSetArg ( args[nargs], XtNjustify, XtJustifyLeft ); nargs++;
		switch ( i )
		{
			case 0:
			case 2:
			case 4:
			case 5:
			case 6:
			case 8:
				XtSetArg ( args[nargs], XtNlabel, "No Data" ); nargs++;
				statTextFields[i] = XtCreateWidget(
            	buf,
					labelWidgetClass,
            	statTextWindow,
					args,	nargs
            	);
				break;

			default:
				XtSetArg ( args[nargs], XtNlabel, "" ); nargs++;
				statTextFields[i] = XtCreateWidget(
           		buf,
					labelWidgetClass,
           		statTextWindow,
					args, nargs
  					);
				break;
		}
	}

	/*
	 * add one more arg - this is cleaner that trying to do it
	 * in the last loop
	 */
	DBGPrint(DBG_WINDOWS, "resetting output fields fromHoriz resource\n");
	theight = 0;
	for ( i = 1; i < NUM_STATTEXT; i++ )
	{
		XtSetArg ( args[0], XtNfromVert, statTextFields[i-1] );
		XtSetValues ( statTextFields[i], args, 1 );
		XtSetArg ( args[0], XtNheight, &height );
		XtGetValues ( statTextFields[i], args, 1 );
		theight += height;
	}


	/*
	 * find the widest (in pixels) label of the bunch and make all
	 * the labels the same width - this will allow for filler to the right
	 */
	DBGPrint(DBG_WINDOWS, "finding widest label\n");
	twidth = 0;
	for ( i = 0; i < NUM_STATTEXT; i++ )
	{
		XtSetArg ( args[0], XtNwidth, &width );
		XtGetValues ( statTextFields[i], args, 1 );

		if ( width > twidth )
			twidth = width;
	}
	for ( i = 0; i < NUM_STATTEXT; i++ )
	{
		XtSetArg ( args[0], XtNwidth, twidth );
		XtSetValues ( statTextFields[i], args, 1 );
	}



	XtManageChildren ( statTextFields, NUM_STATTEXT );


	DBGExit();
}

#endif /* STATSWINDOW_C */
