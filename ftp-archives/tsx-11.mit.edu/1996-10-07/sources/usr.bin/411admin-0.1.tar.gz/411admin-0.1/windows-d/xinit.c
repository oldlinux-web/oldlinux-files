/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: xinit.c
 *            DESCRIPTION: initializes widgets for 411 Administrator
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMXinit
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 *  Since this was ported from my original (and poorly written) Motif
 *  version, the variable names don't quite match the following
 *  special considerations.  But I'm trying to fix that.
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout all 411Admin
 * source:
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, key words capitalized			PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 *		no underscores, mixed case							staticVariable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 *	$Log$
 *
 *========================================================================*/
#ifndef INIT_C
#define INIT_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Text.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/SmeLine.h>
#include <X11/Xaw/SmeBSB.h>
#include <stdio.h>

/* === Project Headers === */
#include "411admin.h"
#include "display.h"
#include "help.h"
#include "debug.h"

/* === external routines === */
extern void ADMShutdown();
extern void ADMPopUpHelp();
extern void ADMPopUpWindow();
extern void ADMPopDownWindow();
extern void ADMPopDownCurrent();
extern void ADMPopUpCurrent();
extern void ADMCreateTitle();
extern void ADMCreateStats();
extern void ADMCreateRecord();
extern void ADMCreateTransient();
extern void ADMSetSensitive();
extern void ADMSetInsensitive();
extern void ADMAddSetup();
extern void ADMViewSetup();
extern void ADMSetRecordTitle();
extern void ADMNextPrevRecord();
extern void ADMGetRecord();
extern void ADMRecordDelete();
extern void ADMDeleteSetup();
extern void ADMDBStats();
extern void ADMUpdateSetup();
extern void ADMRecordUpdate();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
extern XtAppContext	ADM_App_Context;	/* application context */
extern Widget			ADM_Top_Level;		/* shell of main window */
extern Widget 			statShell; 			/* window for file statistics */
extern Widget 			recordInput; 		/* window for file statistics */
extern Widget			helpShell;			/* pop up help dialog */
extern Widget			phoneShell;			/* pop up phone window */
extern Widget			emailShell;			/* pop up email window */
extern Widget			commentsShell;		/* pop up comments window */

Dimension	mainFormHeight;				/* height of main form */
Dimension	mainFormWidth;					/* width of main form */
Widget		ADM_Main_Window;				/* visible main window */
Widget		mainForm;						/* window to display or fetch data */
Widget 		optionsButton;					/* options button on menu bar */
Widget 		optionMenuButton[NUM_OPTIONMENU];
													/* buttons in pop-down menu from
													 * Options button on Menu Bar */
Widget		databaseMenuButton[NUM_DATABASEMENU];	
													/* buttons in pop-down menu from
													 * Database button on Menu Bar */


/* === Static Variables === */

char *file_menu[] = {			/* items in the File pull down menu */
	"Rebuild Files",
	"View File Stats",
	"Quit"
	};

char *database_menu[] = {
	"View a Record",
	"Add a Record",
	"Delete a Record",
	"Update a Record"
	};

char *options_menu[] = {
	"Accept",
	"Search",
	"Clear All",
	"Clear Record Input",
	"Next",
	"Previous",
	"",
	"Comments",
	"Phone/FAX Numbers",
	"Email Addresses"
	};


/*========================================================================
 *	Name:			ADMXInit
 *	Prototype:	ADMXInit()
 *					
 *
 *	Description:
 *		Creates all static widgets necessary for the Administrator
 *		to begin running.  Other widgets are created and destoryed
 *		on the fly.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
ADMXInit ( )
{

#ifdef DEBUG
	char			fname[]="ADMXInit()";	/* name of this routine */
#endif

	int 			i;
	int			nargs;					/* argument lists */
	Arg			args[20];
	char 			buf[255];				
	Dimension	twidth, width, height;

	/* === Widgets used statically === */

	/* 
	 * the main windows
	 */
	Widget 			mw_menubox, mw_spacer, mw_title_bar;


	/* 
	 * menu bar buttons, pull down menus and pushbuttons
	 */


	/*
	 * Help button and window
	 */
	Widget 			getHelp, helpButtonBox;

	/*
	 * File button and menu
	 */
	Widget 			fileButton, fileMenu, fileLine, fileMenuButton[NUM_FILEMENU];

	/*
	 * Database button and menu
	 */
	Widget 			databaseButton, databaseMenu, databaseLine;

	/*
	 * Options button and menu
	 */
	Widget 			optionMenu, optionsLine;



	DBGEnter();

	/* 
	 * create main application window in which all other windows
	 * are displayed 
	 */

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, width ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	ADM_Main_Window = XtCreateWidget(
		"mainWindow",			/* widget name */
		formWidgetClass,		/* widget class */
		ADM_Top_Level,			/* parent widget*/
		args, nargs				/* terminate varargs list */
		);

	/*
	 * a Title Bar in the Main Window
	 */
	DBGPrint(DBG_WINDOWS,"creating title bar\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( ADM_Top_Level, args, nargs );

	(void) sprintf ( buf, "%s R%s V%s", PROGNAME, RELEASE, VERSION );
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, width ); nargs++;
	XtSetArg ( args[nargs], XtNlabel, buf ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	mw_title_bar = XtCreateManagedWidget (
		"TitleBar",				/* widget name */
		labelWidgetClass,		/* widget class */
		ADM_Main_Window,		/* parent widget */
		args, nargs				/* argument list */
		);

	/*
	 * three windows inside the main window: a menu bar a Form/box
	 * window for the buttons, and a form window inside which will go 
	 * two main input/output windows
	 */

	/*
	 * CREATE A BOX FOR THE 4 MENU BUTTONS
	 */
	DBGPrint(DBG_WINDOWS,"creating menu box\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( ADM_Top_Level, args, nargs );

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, width ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, mw_title_bar ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNorientation, XtorientHorizontal ); nargs++;
	XtSetArg ( args[nargs], XtNvSpace, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhSpace, 0 ); nargs++;
	mw_menubox = XtCreateManagedWidget (
		"MenuBox",
		boxWidgetClass,
		ADM_Main_Window,
		args, nargs
		);

	/*
	 * create the 4 menu buttons
	 */


	/*
	 * CREATE FILE MENU AND CHILDREN
	 */

	DBGPrint(DBG_WINDOWS,"creating file menu\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "File" ); nargs++;
	XtSetArg ( args[nargs], XtNmenuName, "fileMenu" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	fileButton = XtCreateManagedWidget(
		"fileButton",				/* widget name */
		menuButtonWidgetClass,	/* widget class */
		mw_menubox,					/* parent */
		args, nargs					/* argument list */
		);

	/* start to add up the widths of the buttons */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &twidth ); nargs++;
	XtGetValues( fileButton, args, nargs );


	/*
	 * create menu popped down by fileButton
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Menu" ); nargs++;
	fileMenu = XtCreatePopupShell(
		"fileMenu",					/* name */
		simpleMenuWidgetClass,	/* class */
		ADM_Top_Level,				/* parent */
		args, nargs					/* no argument list needed */
		);

	/*
	 * a line seperator in the menu
	 */
	fileLine = XtCreateManagedWidget(
		"fileMenuLine",			/* name */
		smeLineObjectClass,		/* class */
		fileMenu,					/* parent */
		NULL, 0						/* no argument list needed */
		);

	/*
	 * set the menu items in the pull-down menu
	 */
	for ( i = 0; i < NUM_FILEMENU; i++ )
	{
		if ( i == NUM_FILEMENU -1 )
			(void) sprintf ( buf, "Quit" );
		else
			(void) sprintf ( buf, "fileMenu%d", i );

		nargs = 0;
		XtSetArg ( args[nargs], XtNlabel, file_menu[i] ); nargs++;

    	fileMenuButton[i] = XtCreateManagedWidget(
            buf,						/* widget name */
            smeBSBObjectClass,	/* widget class */
            fileMenu,				/* parent widget*/
				args, nargs				/* argument list */
				);

		/* set the callbacks */
		switch ( i )
		{
			case QUITOPTION:
				XtAddCallback( fileMenuButton[i], XtNcallback, ADMShutdown, NULL );
				DBGPrint(DBG_WINDOWS,"set call back for Quit button\n");
				break;

			default:
				break;
		}

	}


	/*
	 * CREATE DATABASE MENU AND CHILDREN
	 */

	/*
	 * create button that will pop up the menu
	 */
	DBGPrint(DBG_WINDOWS,"creating database menu\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Database" ); nargs++;
	XtSetArg ( args[nargs], XtNmenuName, "databaseMenu" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	databaseButton = XtCreateManagedWidget(
		"databaseButton",			/* widget name */
		menuButtonWidgetClass,	/* widget class */
		mw_menubox,					/* parent */
		args, nargs					/* terminate varargs list */
		);

	/* add in the width of the button */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( databaseButton, args, nargs );
	twidth+=width;

	/*
	 * create menu popped down by databaseButton
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Menu" ); nargs++;
	databaseMenu = XtCreatePopupShell(
		"databaseMenu", 			/* name */
		simpleMenuWidgetClass,	/* class */
		ADM_Top_Level,  			/* parent */
		args, nargs					/* no argument list needed */
		);

	/*
	 * a line seperator in the menu
	 */
	databaseLine = XtCreateManagedWidget(
		"databaseMenuLine",		/* name */
		smeLineObjectClass,		/* class */
		databaseMenu,				/* parent */
		NULL, 0						/* no argument list needed */
		);

	/*
	 * set the pushbuttons in the pull-down menu
	 */
	for ( i = 0; i < NUM_DATABASEMENU; i++ )
	{

		(void) sprintf ( buf, "databaseMenu%d", i );
		nargs = 0;
		XtSetArg ( args[nargs], XtNlabel, database_menu[i] ); nargs++;

		databaseMenuButton[i] = XtCreateManagedWidget(
				buf,						/* name */
				smeBSBObjectClass,	/* class */
				databaseMenu,			/* parent */
				args, nargs				/* terminate varargs list */
				);

		switch ( i )
		{
			case DELETEOPTION:
			case UPDATEOPTION:
				XtSetSensitive ( databaseMenuButton[i], False );
				break;
		}
	}

	/*
	 * CREATE OPTIONS MENU AND CHILDREN
	 */

	/*
	 * The options menu is only available after an option from the 
	 * Database menu has been selected
	 */

	/*
	 * create button that will pop up the menu
	 */
	DBGPrint(DBG_WINDOWS,"creating options menu\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Options" ); nargs++;
	XtSetArg ( args[nargs], XtNmenuName, "optionMenu" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	optionsButton = XtCreateManagedWidget(
		"optionsButton",			/* name */
		menuButtonWidgetClass,	/* class */
		mw_menubox,					/* parent */
		args, nargs					/* arg list */
		);

	/* add in the width of the button */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( optionsButton, args, nargs );
	twidth+=width;

	/*
	 * create menu popped down by optionsButton
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Menu" ); nargs++;
	optionMenu = XtCreatePopupShell(
		"optionMenu",				/* name */
		simpleMenuWidgetClass,	/* class */
		ADM_Top_Level,				/* parent */
		args,	nargs					/* argument list */
		);

	/*
	 * a line seperator in the menu
	 */
	optionsLine = XtCreateManagedWidget(
		"optionsMenuLine",		/* name */
		smeLineObjectClass,		/* class */
		optionMenu,					/* parent */
		NULL, 0						/* no argument list needed */
		);

	/*
	 * set the pushbuttons in the pull-down menu
	 */
	for ( i = 0; i < NUM_OPTIONMENU; i++ )
	{
		switch ( i )
		{

			case SEPERATOROPTION:
				(void) sprintf ( buf, "optionMenu%d", i );
				optionMenuButton[i] = XtCreateManagedWidget( 
						buf,						/* name */
						smeLineObjectClass,	/* class */
						optionMenu,				/* parent */
						NULL, 0					/* terminate varargs list */
						);
				break;

			default:
				(void) sprintf ( buf, "optionMenu%d", i );
				nargs = 0;
				XtSetArg ( args[nargs], XtNlabel, options_menu[i] ); nargs++;

				optionMenuButton[i] = XtCreateManagedWidget( 
						buf,						/* name */
						smeBSBObjectClass,	/* class */
						optionMenu,				/* parent */
						args, nargs				/* terminate varargs list */
						);
				break;
		}

		/* set callbacks for a few of the buttons */
		switch ( i )
		{
			case NEXTOPTION:
				XtAddCallback( optionMenuButton[i], XtNcallback, 
					(XtCallbackProc)ADMNextPrevRecord, (XtPointer) NEXTOPTION );
				break;

			case PREVOPTION:
				XtAddCallback( optionMenuButton[i], XtNcallback, 
					(XtCallbackProc)ADMNextPrevRecord, (XtPointer) PREVOPTION );
				break;
		}
	}


	/*
	 * make the default for the Options Menu Bar button be insensitive
	 */
	XtSetSensitive ( optionsButton, False );

	/*
	 * CREATE A SPACER BETWEEN THE MENU BUTTONS AND THE HELP BUTTON
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &height ); nargs++;
	XtGetValues( fileButton, args, nargs );

	DBGPrint(DBG_WINDOWS,"creating menu spacer\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "" ); nargs++;
	XtSetArg ( args[nargs], XtNheight, height ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, mw_title_bar ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, mw_menubox ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNresizable, True ); nargs++;
	mw_spacer = XtCreateManagedWidget(
		"menuSpacer",
		labelWidgetClass,
		ADM_Main_Window,
		args, nargs
		);

	/*
	 * create a box for the help button
	 */
	DBGPrint(DBG_WINDOWS,"creating help box\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, mw_title_bar ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, mw_spacer ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNorientation, XtorientHorizontal ); nargs++;
	XtSetArg ( args[nargs], XtNvSpace, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhSpace, 0 ); nargs++;
	helpButtonBox = XtCreateManagedWidget(
		"helpButtonBox",			/* name */
		boxWidgetClass,			/* class */
		ADM_Main_Window,			/* parent */
		args, nargs					/* arg list */
		);


	/*
	 * create button that will pop up the help window
	 */
	DBGPrint(DBG_WINDOWS,"creating help windows\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Help" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	getHelp = XtCreateManagedWidget(
		"getHelp",					/* name */
		commandWidgetClass,		/* class */
		helpButtonBox,				/* parent */
		args, nargs					/* arg list */
		);

	/*
	 * tell help button what routine to call when pressed
	 */
    XtAddCallback ( getHelp, XtNcallback, 
			(XtCallbackProc)ADMPopUpHelp, (XtPointer)0 );

	/* readjust the width of the spacer */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( getHelp, args, nargs );
	twidth = twidth + width;
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( mw_title_bar, args, nargs );
	twidth = width - twidth + 1;
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, twidth ); nargs++;
	XtSetValues( mw_spacer, args, nargs );


	/* CREATE FORM WINDOW UNDER MAIN APPLICATION SHELL */

	/* 
	 * create a form window in which the record windows will go
	 */
	DBGPrint(DBG_WINDOWS,"creating main form windows\n");

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &mainFormWidth ); nargs++;
	XtGetValues( mw_title_bar, args, nargs );

	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &mainFormHeight ); nargs++;
	XtGetValues( mw_title_bar, args, nargs );

	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &height ); nargs++;
	XtGetValues( fileButton, args, nargs );
	mainFormHeight += height;

	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &height ); nargs++;
	XtGetValues( ADM_Top_Level, args, nargs );
	mainFormHeight = height - mainFormHeight;

	DBGPrintf(DBG_WINDOWS,("main form height and width\n\theight:%d\twidth:%d\n",
					mainFormHeight, mainFormWidth));

	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, mw_menubox); nargs++;
	XtSetArg ( args[nargs], XtNwidth, mainFormWidth ); nargs++;
	XtSetArg ( args[nargs], XtNheight, mainFormHeight ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	mainForm = XtCreateManagedWidget(
		"mainForm",
		formWidgetClass,
		ADM_Main_Window,
		args, nargs
		);

	/* other window initializiations */
	ADMCreateTitle();
	ADMCreateStats();
	ADMCreateRecord();


	/* ADD CALLBACKS FOR THE MENU FUNCTIONS */

	/*
	 * arrange for Stats button to pop up stats window
	 */
	XtAddCallback( fileMenuButton[STATOPTION], 
					XtNcallback, (XtCallbackProc)ADMPopUpWindow, statShell );
	XtAddCallback( fileMenuButton[STATOPTION],
						XtNcallback, (XtCallbackProc)ADMDBStats, NULL );

	/*
	 * arrange for View button to call functions that view a record.
	 */
	XtAddCallback( databaseMenuButton[VIEWOPTION],
					XtNcallback, (XtCallbackProc)ADMPopDownCurrent, recordInput );
	XtAddCallback( databaseMenuButton[VIEWOPTION],
					XtNcallback, (XtCallbackProc)ADMPopUpCurrent, NULL );
	XtAddCallback( databaseMenuButton[VIEWOPTION],
					XtNcallback, (XtCallbackProc)ADMSetSensitive, optionsButton );
	XtAddCallback( databaseMenuButton[VIEWOPTION],
						XtNcallback, 
						(XtCallbackProc)ADMSetRecordTitle, 
						(XtPointer)ADM_VIEW_FUNCTION );
	XtAddCallback( databaseMenuButton[VIEWOPTION],
						XtNcallback, (XtCallbackProc)ADMViewSetup, NULL );


	/*
	 * arrange for Update button to call functions that update a record.
	 */
	XtAddCallback( databaseMenuButton[UPDATEOPTION],
					XtNcallback, (XtCallbackProc)ADMPopDownCurrent, recordInput );
	XtAddCallback( databaseMenuButton[UPDATEOPTION],
					XtNcallback, (XtCallbackProc)ADMPopUpCurrent, NULL );
	XtAddCallback( databaseMenuButton[UPDATEOPTION],
					XtNcallback, (XtCallbackProc)ADMSetInsensitive, optionsButton );
	XtAddCallback( databaseMenuButton[UPDATEOPTION],
						XtNcallback, 
						(XtCallbackProc)ADMSetRecordTitle, 
						(XtPointer)ADM_UPD_FUNCTION );
	XtAddCallback( databaseMenuButton[UPDATEOPTION],
						XtNcallback, (XtCallbackProc)ADMUpdateSetup, NULL );
	XtAddCallback( databaseMenuButton[UPDATEOPTION],
						XtNcallback, (XtCallbackProc)ADMGetRecord, NULL );
	XtAddCallback( databaseMenuButton[UPDATEOPTION],
						XtNcallback, (XtCallbackProc)ADMRecordUpdate, NULL );


	/*
	 * arrange for Add button to call functions that add a record.
	 */
	XtAddCallback( databaseMenuButton[ADDOPTION],
					XtNcallback, (XtCallbackProc)ADMPopDownCurrent, recordInput );
	XtAddCallback( databaseMenuButton[ADDOPTION],
					XtNcallback, (XtCallbackProc)ADMPopUpCurrent, NULL );
	XtAddCallback( databaseMenuButton[ADDOPTION],
					XtNcallback, (XtCallbackProc)ADMSetSensitive, optionsButton );
	XtAddCallback( databaseMenuButton[ADDOPTION],
						XtNcallback, 
						(XtCallbackProc)ADMSetRecordTitle, 
						ADM_ADD_FUNCTION );
	XtAddCallback( databaseMenuButton[ADDOPTION],
						XtNcallback, (XtCallbackProc)ADMAddSetup, NULL );


	/*
	 * arrange for Delete button to call functions that delete a record.
	 */
	XtAddCallback( databaseMenuButton[DELETEOPTION],
					XtNcallback, (XtCallbackProc)ADMPopDownCurrent, recordInput );
	XtAddCallback( databaseMenuButton[DELETEOPTION],
					XtNcallback, (XtCallbackProc)ADMPopUpCurrent, NULL );
	XtAddCallback( databaseMenuButton[DELETEOPTION],
					XtNcallback, (XtCallbackProc)ADMSetInsensitive, optionsButton );
	XtAddCallback( databaseMenuButton[DELETEOPTION],
						XtNcallback, 
						(XtCallbackProc)ADMSetRecordTitle, 
						(XtPointer)ADM_DEL_FUNCTION );
	XtAddCallback( databaseMenuButton[DELETEOPTION],
						XtNcallback, (XtCallbackProc)ADMDeleteSetup, NULL );
	XtAddCallback( databaseMenuButton[DELETEOPTION],
						XtNcallback, (XtCallbackProc)ADMGetRecord, NULL );
	XtAddCallback( databaseMenuButton[DELETEOPTION],
						XtNcallback, (XtCallbackProc)ADMRecordDelete, NULL );
	XtAddCallback( databaseMenuButton[DELETEOPTION],
						XtNcallback, 
						(XtCallbackProc)ADMSetRecordTitle, 
						(XtPointer)ADM_SEL_FUNCTION );


	/*
	 * Manage the main windows visible form
	 */
	XtManageChild ( ADM_Main_Window );

	DBGExit();

}


#endif /* INIT_C */


