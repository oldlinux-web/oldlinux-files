/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: debug.c
 *            DESCRIPTION: handle the varargs list of the debug macros
 *       PUBLIC FUNCTIONS: ADMDebugOut
 *  SOFTWARE DEPENDENCIES: requires Linux stdarg.h
 *                  NOTES: 
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DEBUG_C
#define DEBUG_C

#ifdef DEBUG

/* === System Headers === */
#include <stdio.h>
#include <stdarg.h>

/*========================================================================
 *	Name:			ADMDebugOut
 *	Prototype:	ADMDebugOut(const char *fmt, ... )
 *
 *	Description:
 *		handles varargs list of debug macros
 *
 *	Restrictions:
 *		this routine should only be called using the debug macros
 *		listed in debug.h
 *
 *	Notes:
 *		
 *========================================================================*/

char *
ADMDebugOut ( const char *fmt, ... )
{
	va_list	ap;
	char		p[255];

	va_start (ap, fmt);
	(void) vsprintf(p, fmt, ap);
	va_end (ap);
	return (p);
}

#endif /* DEBUG */

#endif /* DEBUG_C */

