/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: callbacks.c
 *            DESCRIPTION: sets and removes callbacks
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMRemoveCallbacks, ADMAddAddCallbacks
 *       					 : ADMViewCallbacks
 *      PRIVATE FUNCTIONS: removeAddCallbacks, removeViewCallbacks
 *      						 : 
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 *  Since this was ported from my original (and poorly written) Motif
 *  version, the variable names don't quite match the following
 *  special considerations.  But I'm trying to fix that.
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout all 411Admin
 * source:
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, key words capitalized			PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 *		no underscores, mixed case							staticVariable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 *	$Log$
 *
 *========================================================================*/
#ifndef CALLBACKS_C
#define CALLBACKS_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>

/* === Project Headers === */
#include "411admin.h"
#include "display.h"

/* === external routines === */
extern void ADMAddSetup();
extern void ADMClearWindow();
extern void ADMSetSensitive();
extern void ADMSetInsensitive();
extern void ADMPopUpWindow();
extern void ADMGetRecord();
extern void ADMRecordAdd();
extern void ADMRecordView();

/* === Public routine prototypes === */

/* === Private routine prototypes === */
void removeAddCallbacks();
void removeViewCallbacks();

/* === Global Variables === */
extern Widget 		optionMenuButton[NUM_OPTIONMENU];
extern Widget		phoneShell;			/* pop up phone window */
extern Widget		emailShell;			/* pop up email window */
extern Widget		commentsShell;		/* pop up comments window */


/*========================================================================
 *	Name:			ADMRemoveCallbacks
 *	Prototype:	ADMRemoveCallbacks()
 *					
 *	Description:
 * remove callbacks from the Options menu buttons so that when a new
 * function is selected we don't accidently execute callbacks that 
 * had been set for another function.  I'm not sure of any better way
 * to do this (the Motif manuals say don't use XtRemoveAllCallbacks())
 * other than list all the callbacks that might possibly have been
 * set.  XtRemoveCallback() won't report any problems if the callback
 * is not in its callback list so trying to remove a callback that
 * doesn't exist is, at worst, only time consuming.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMRemoveCallbacks(
)
{
	removeAddCallbacks();
	removeViewCallbacks();
}


/*========================================================================
 *	Name:			ADMAddAddCallbacks and removeAddCallbacks
 *	Prototype:	ADMAddAddCallbacks() and removeAddCallbacks()
 *					
 *	Description:
 *		add the callbacks necessary for using the Add feature and provide
 *		a way of removing these callbacks later, when the user switches
 *		to a different function.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
ADMAddAddCallbacks(
)
{

	/*
	 * set callback for the clear buttons
	 */
	XtAddCallback ( optionMenuButton[CLEARALLOPTION], XtNcallback,
			ADMClearWindow, (XtPointer) CLEAR_ALL );
	XtAddCallback ( optionMenuButton[CLEARRECOPTION], XtNcallback,
			ADMClearWindow, (XtPointer) CLEAR_RECORD );

	/*
	 * set callback for the comments button
	 */
	XtAddCallback( optionMenuButton[COMMENTSOPTION], 
			XtNcallback, (XtCallbackProc)ADMPopUpWindow, commentsShell );
	XtAddCallback ( optionMenuButton[COMMENTSOPTION], XtNcallback,
			ADMSetInsensitive, optionMenuButton[COMMENTSOPTION] );

	/*
	 * set callback for the email button
	 */
	XtAddCallback( optionMenuButton[EMAILOPTION], 
			XtNcallback, (XtCallbackProc)ADMPopUpWindow, emailShell );
	XtAddCallback ( optionMenuButton[EMAILOPTION], XtNcallback,
			ADMSetInsensitive, optionMenuButton[EMAILOPTION] );

	/*
	 * set callback for the phone button
	 */
	XtAddCallback( optionMenuButton[PHONEOPTION], 
			XtNcallback, (XtCallbackProc)ADMPopUpWindow, phoneShell );
	XtAddCallback ( optionMenuButton[PHONEOPTION], XtNcallback,
			ADMSetInsensitive, optionMenuButton[PHONEOPTION] );

	/*
	 * set callback for the accept button
	 */
	XtAddCallback ( optionMenuButton[ACCEPTOPTION], XtNcallback,
			ADMGetRecord, NULL );
	XtAddCallback ( optionMenuButton[ACCEPTOPTION], XtNcallback,
			ADMRecordAdd, NULL );

}

void
removeAddCallbacks(
)
{

	/*
	 * remove callback for the clear button
	 */
	XtRemoveCallback ( optionMenuButton[CLEARALLOPTION], XtNcallback,
			ADMClearWindow, NULL );
	XtRemoveCallback ( optionMenuButton[CLEARRECOPTION], XtNcallback,
			ADMClearWindow, (XtPointer) CLEAR_RECORD );

	/*
	 * remove callback for the comments button
	 */
	XtRemoveCallback ( optionMenuButton[COMMENTSOPTION], XtNcallback,
			ADMSetInsensitive, optionMenuButton[COMMENTSOPTION] );
	XtRemoveCallback( optionMenuButton[COMMENTSOPTION], 
			XtNcallback, (XtCallbackProc)ADMPopUpWindow, commentsShell );

	/*
	 * remove callback for the email button
	 */
	XtRemoveCallback( optionMenuButton[EMAILOPTION], 
			XtNcallback, (XtCallbackProc)ADMPopUpWindow, emailShell );
	XtRemoveCallback ( optionMenuButton[EMAILOPTION], XtNcallback,
			ADMSetInsensitive, optionMenuButton[EMAILOPTION] );

	/*
	 * remove callback for the phone button
	 */
	XtRemoveCallback( optionMenuButton[PHONEOPTION], 
			XtNcallback, (XtCallbackProc)ADMPopUpWindow, phoneShell );
	XtRemoveCallback ( optionMenuButton[PHONEOPTION], XtNcallback,
			ADMSetInsensitive, optionMenuButton[PHONEOPTION] );

	/*
	 * remove callback for the accept button
	 */
	XtRemoveCallback ( optionMenuButton[ACCEPTOPTION], XtNcallback,
			ADMGetRecord, NULL );
	XtRemoveCallback ( optionMenuButton[ACCEPTOPTION], XtNcallback,
			ADMRecordAdd, NULL );

}



/*========================================================================
 *	Name:			ADMAddViewCallbacks and removeViewCallbacks
 *	Prototype:	ADMAddViewCallbacks() and removeViewCallbacks()
 *					
 *	Description:
 *		add the callbacks necessary for using the View feature and provide
 *		a way of removing these callbacks later, when the user switches
 *		to a different function.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
ADMAddViewCallbacks(
)
{

	/*
	 * set callback for the clear button
	 */
	XtAddCallback ( optionMenuButton[CLEARALLOPTION], XtNcallback,
			ADMClearWindow, NULL );
	XtAddCallback ( optionMenuButton[CLEARRECOPTION], XtNcallback,
			ADMClearWindow, (XtPointer) CLEAR_RECORD );

	/*
	 * set callback for the comments button
	 */
	XtAddCallback( optionMenuButton[COMMENTSOPTION], 
			XtNcallback, (XtCallbackProc)ADMPopUpWindow, commentsShell );
	XtAddCallback ( optionMenuButton[COMMENTSOPTION], XtNcallback,
			ADMSetInsensitive, optionMenuButton[COMMENTSOPTION] );

	/*
	 * set callback for the email button
	 */
	XtAddCallback( optionMenuButton[EMAILOPTION], 
			XtNcallback, (XtCallbackProc)ADMPopUpWindow, emailShell );
	XtAddCallback ( optionMenuButton[EMAILOPTION], XtNcallback,
			ADMSetInsensitive, optionMenuButton[EMAILOPTION] );

	/*
	 * set callback for the phone button
	 */
	XtAddCallback( optionMenuButton[PHONEOPTION], 
			XtNcallback, (XtCallbackProc)ADMPopUpWindow, phoneShell );
	XtAddCallback ( optionMenuButton[PHONEOPTION], XtNcallback,
			ADMSetInsensitive, optionMenuButton[PHONEOPTION] );

	/*
	 * set callback for the search button
	 */
	XtAddCallback ( optionMenuButton[SEARCHOPTION], XtNcallback,
			ADMSetSensitive, optionMenuButton[NEXTOPTION] );
	XtAddCallback ( optionMenuButton[SEARCHOPTION], XtNcallback,
			ADMSetSensitive, optionMenuButton[PREVOPTION] );
	XtAddCallback ( optionMenuButton[SEARCHOPTION], XtNcallback,
			ADMGetRecord, NULL );
	XtAddCallback ( optionMenuButton[SEARCHOPTION], XtNcallback,
			ADMRecordView, NULL );

}

void
removeViewCallbacks(
)
{

	/*
	 * remove callback for the clear button
	 */
	XtRemoveCallback ( optionMenuButton[CLEARALLOPTION], XtNcallback,
			ADMClearWindow, NULL );
	XtRemoveCallback ( optionMenuButton[CLEARRECOPTION], XtNcallback,
			ADMClearWindow, (XtPointer) CLEAR_RECORD );

	/*
	 * remove callback for the comments button
	 */
	XtRemoveCallback ( optionMenuButton[COMMENTSOPTION], XtNcallback,
			ADMSetInsensitive, optionMenuButton[COMMENTSOPTION] );
	XtRemoveCallback( optionMenuButton[COMMENTSOPTION], 
			XtNcallback, (XtCallbackProc)ADMPopUpWindow, commentsShell );

	/*
	 * remove callback for the email button
	 */
	XtRemoveCallback( optionMenuButton[EMAILOPTION], 
			XtNcallback, (XtCallbackProc)ADMPopUpWindow, emailShell );
	XtRemoveCallback ( optionMenuButton[EMAILOPTION], XtNcallback,
			ADMSetInsensitive, optionMenuButton[EMAILOPTION] );

	/*
	 * remove callback for the phone button
	 */
	XtRemoveCallback( optionMenuButton[PHONEOPTION], 
			XtNcallback, (XtCallbackProc)ADMPopUpWindow, phoneShell );
	XtRemoveCallback ( optionMenuButton[PHONEOPTION], XtNcallback,
			ADMSetInsensitive, optionMenuButton[PHONEOPTION] );

	/*
	 * remove callback for the search button
	 */
	XtAddCallback ( optionMenuButton[SEARCHOPTION], XtNcallback,
			ADMSetSensitive, optionMenuButton[NEXTOPTION] );
	XtAddCallback ( optionMenuButton[SEARCHOPTION], XtNcallback,
			ADMSetSensitive, optionMenuButton[PREVOPTION] );
	XtRemoveCallback ( optionMenuButton[SEARCHOPTION], XtNcallback,
			ADMGetRecord, NULL );
	XtRemoveCallback ( optionMenuButton[SEARCHOPTION], XtNcallback,
			ADMRecordView, NULL );

}


#endif /* CALLBACKS_C */
