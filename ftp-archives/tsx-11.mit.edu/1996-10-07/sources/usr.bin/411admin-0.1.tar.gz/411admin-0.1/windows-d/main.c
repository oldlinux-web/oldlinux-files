/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: main.c
 *            DESCRIPTION: initialization of 411 Administrator
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: 
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout all 411Admin
 * source:
 *
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef MAIN_C
#define MAIN_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Xaw/AsciiText.h>
#include <stdio.h>
#include <stdlib.h>

/* === Project Headers === */
#include "411admin.h"
#include "display.h"
#include "help.h"
#include "debug.h"

/* === external routines === */
extern void ADMCreateTransient();
extern void ADMXInit();
extern void ADMShutdown();
extern void ADMInit();
extern int	ADMAddHelp();

extern void ADMNextRecord();
extern void ADMPreviousRecord();
extern void ADMRecordFocus();
extern void ADMHideRecord();

extern void ADMNextEmail();
extern void ADMPreviousEmail();
extern void ADMEmailFocus();
extern void ADMHideEmail();

extern void ADMNextPhone();
extern void ADMPreviousPhone();
extern void ADMPhoneFocus();
extern void ADMHidePhone();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */

/*
 * external
 */
extern Dimension	mainFormHeight;			/* height of the stats view port */
extern Dimension	mainFormWidth;				/* height of the records view port */
extern Widget		recordViewPort; 			/* window for records */
extern Dimension	recordViewPortHeight;	/* height of the records view port */
extern Widget		recordInput; 				/* main form for record input */
extern Widget		helpText;					/* window where help message is put */

/*
 * local
 */
Widget			ADM_Top_Level;			/* mother of all widgets */
XtAppContext	ADM_App_Context;		/* application context */
AppData			ADM_App_Data;			/* application resource data */


/* === Static Variables === */
static XrmOptionDescRec	options[] = {
	{"-dbdir",		"*dbDir",		XrmoptionSepArg,	NULL },
	{"-dbfile",		"*dbFile",		XrmoptionSepArg,	NULL },
	{"-hashfile",	"*hashFile",	XrmoptionSepArg,	NULL },
	{"-indexfile",	"*indexFile",	XrmoptionSepArg,	NULL },
	{"-helpdir",	"*helpDir",		XrmoptionSepArg,	NULL },
	{"-debugfile",	"*debugFile",	XrmoptionSepArg,	NULL },
	{"-debug",		"*debug",		XrmoptionSepArg,	NULL },
	{"-help",		"*help",			XrmoptionNoArg,	"True" },
};


#define offset(field)		XtOffset(AppDataPtr, field)
static XtResource resources[] = {
	{ "dbDir", "DbDir",			/* resource name and class */
		XtRString,					/* resource type representation */
		sizeof(String),			/* size of resource representation */
		offset(db_dir),			/* offset into resource list */
		XtRImmediate,				/* representative type for default value */
		DEFAULT_DB_DIR				/* default value */
	},
	{ "dbFile", "DbFile",		/* resource name and class */
		XtRString,					/* resource type representation */
		sizeof(String),			/* size of resource representation */
		offset(db_file),			/* offset into resource list */
		XtRImmediate,				/* representative type for default value */
		DEFAULT_DB_FILE			/* default value */
	},
	{ "hashFile", "HashFile",	/* resource name and class */
		XtRString,					/* resource type representation */
		sizeof(String),			/* size of resource representation */
		offset(hash_file),		/* offset into resource list */
		XtRImmediate,				/* representative type for default value */
		DEFAULT_HASH_FILE			/* default value */
	},
	{ "indexFile", "IndexFile",/* resource name and class */
		XtRString,					/* resource type representation */
		sizeof(String),			/* size of resource representation */
		offset(index_file),		/* offset into resource list */
		XtRImmediate,				/* representative type for default value */
		DEFAULT_INDEX_FILE		/* default value */
	},
	{ "helpDir", "HelpDir",		/* resource name and class */
		XtRString,					/* resource type representation */
		sizeof(String),			/* size of resource representation */
		offset(help_dir),			/* offset into resource list */
		XtRImmediate,				/* representative type for default value */
		DEFAULT_HELP_DIR			/* default value */
	},
	{ "debugFile", "DebugFile",/* resource name and class */
		XtRString,					/* resource type representation */
		sizeof(String),			/* size of resource representation */
		offset(debug_file),		/* offset into resource list */
		XtRImmediate,				/* representative type for default value */
		DEBUG_CONSOLE_DEV			/* default value */
	},
	{ "debug", "Debug",			/* resource name and class */
		XtRString,					/* resource type representation */
		sizeof(String),			/* size of resource representation */
		offset(debug),				/* offset into resource list */
		XtRImmediate,				/* representative type for default value */
		NULL							/* default value */
	},
	{ "help", "help",				/* resource name and class */
		XtRBoolean,					/* resource type representation */
		sizeof(Boolean),			/* size of resource representation */
		offset(help),				/* offset into resource list */
		XtRImmediate,				/* representative type for default value */
		False							/* default value */
	},
};
#undef offset
		
/*
 * translations used for the record window - see xutil.c for what
 * these really do
 */
static XtActionsRec  recordActions[] = {
	/*
	 * the record window translations
	 */
   {"next_record_field", (XtActionProc)ADMNextRecord},
   {"prev_record_field", (XtActionProc)ADMPreviousRecord},
   {"record_focus_in", (XtActionProc)ADMRecordFocus},
   {"record_focus_out", (XtActionProc)ADMHideRecord},

	/*
	 * the email window translations
	 */
   {"next_email_field", (XtActionProc)ADMNextEmail},
   {"prev_email_field", (XtActionProc)ADMPreviousEmail},
   {"email_focus_in", (XtActionProc)ADMEmailFocus},
   {"email_focus_out", (XtActionProc)ADMHideEmail},

	/*
	 * the email window translations
	 */
   {"next_phone_field", (XtActionProc)ADMNextPhone},
   {"prev_phone_field", (XtActionProc)ADMPreviousPhone},
   {"phone_focus_in", (XtActionProc)ADMPhoneFocus},
   {"phone_focus_out", (XtActionProc)ADMHidePhone},
};


/*========================================================================
 *	Name:			main	
 *	Prototype:	main( int argc, char **argv )
 *
 *	Description:
 *		well, you gotta start somewhere....
 *
 *	Input Arguments:
 *		int	argc			number of command line arguments
 *		char	**argv		command line argument list
 *		
 *	Output Arguments:
 *	Return Values:
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
main(
	int argc,
	char **argv
)
{

#ifdef DEBUG
	char				fname[]="main()";
#endif

	Arg				args[10];
	int				nargs;
	int				startpos;


	
	/*
	 * initialize the top level so we can check command line args
	 * before doing much else.
	 */
	ADM_Top_Level = XtVaAppInitialize(
			&ADM_App_Context,					/* Application context */
			"X411admin",						/* application class name */
			options, XtNumber(options),	/* command line option list */
			&argc, argv,						/* command line args */
			NULL,									/* for missing app-defaults file */
			NULL);								/* terminate varargs list */

	/*
	 * Grab all the application specific resources
	 */
	XtVaGetApplicationResources(
			ADM_Top_Level,
			&ADM_App_Data,
			resources,
			XtNumber( resources ),
			NULL
			);

	/*
	 * if the user requested help, provide it
	 */
	if ( ADM_App_Data.help == True )
	{
		printf( USAGE );
		exit ( 0 );
	}

	/*
	 * print out what the default values are for files and directories
	 */
	printf ( 
			"db dir    : %s\n"
			"help dir  : %s\n"
			"db file   : %s\n"
			"index file: %s\n"
			"hash file : %s\n",
			ADM_App_Data.db_dir,
			ADM_App_Data.help_dir,
			ADM_App_Data.db_file,
			ADM_App_Data.index_file,
			ADM_App_Data.hash_file );


#ifdef DEBUG

	/*
	 * set the debug file, if any
	 */
	if ( ADM_App_Data.debug_file != NULL )
		DBGFile = ADM_App_Data.debug_file;

	/*
	 * Set the debug level, if any.  The debug level must be set the
	 * same way it is in debug.h - using bit flags.
	 */
	if ( ADM_App_Data.debug != NULL )
		debug_level = atoi(ADM_App_Data.debug);

#endif


	/*
	 * debug output to /dev/console by default, if -DDEBUG was set at compile 
	 * time otherwise DBGxxx macros have no effect.
	 */
	DBGOpen( DEBUG_FD );
	DBGEnter();


	/*
	 * add default actions
	 */
	XtAppAddActions(ADM_App_Context, recordActions, XtNumber ( recordActions ));


	/* we have some initializing to do first */
	ADMInit();


	/*
	 * NOW BUILD ALL THE WIDGETS WE'LL NEED AT START UP
	 */


	/* 
	 * All transients we'll need right from the start
	 * This includes the help box.  The main help is inserted
	 * by this routine.
	 */
	ADMCreateTransient();

	/*
	 * Add the the help files associated with the record window 
	 * to the help text
	 */
	startpos = ADMAddHelp ( ADM_HELP_FILE, USE_HELP_FILE, 
						ADM_HELP_USE_HELP_LABEL);
	startpos = ADMAddHelp ( ADM_HELP_FILE, ABOUT_HELP_FILE, 
						ADM_HELP_ABOUT_LABEL);
	startpos = ADMAddHelp ( ADM_HELP_FILE, RECWINDOW_HELP_FILE, 
						ADM_HELP_RECWINDOW_LABEL);

	startpos = ADMAddHelp ( ADM_HELP_FILE, FILEMENU_HELP_FILE, 
						ADM_HELP_FILE_LABEL);
	startpos = ADMAddHelp ( ADM_HELP_FILE, DBMENU_HELP_FILE, 
						ADM_HELP_DATABASE_LABEL);
	startpos = ADMAddHelp ( ADM_HELP_FILE, OPTIONSMENU_HELP_FILE, 
						ADM_HELP_OPTIONS_LABEL);
	startpos = ADMAddHelp ( ADM_HELP_FILE, MSG_HELP_FILE, 
						ADM_HELP_MSG_LABEL);


	startpos = ADMAddHelp ( ADM_HELP_FILE, VIEW_HELP_FILE, 
						ADM_HELP_VIEW_LABEL);
	startpos = ADMAddHelp ( ADM_HELP_FILE, ADD_HELP_FILE, 
						ADM_HELP_ADD_LABEL);
	startpos = ADMAddHelp ( ADM_HELP_FILE, DELETE_HELP_FILE, 
						ADM_HELP_DELETE_LABEL);
	startpos = ADMAddHelp ( ADM_HELP_FILE, UPDATE_HELP_FILE, 
						ADM_HELP_UPDATE_LABEL);

	/* 
	 * create the rest of the windows
	 */
	ADMXInit();

	/*
	 * And some other help files.
	 */
	startpos = ADMAddHelp ( ADM_HELP_FILE, DBRECORD_HELP_FILE, 
						ADM_HELP_RECORD_LABEL);

	/*
	 * Make the help text window uneditable
	 */
	XtSetArg ( args[0], XtNeditType, XawtextRead );
	XtSetValues ( helpText, args, 1 );

	/*
	 * make me real, Gepetto!
	 */
	DBGPrint(DBG_INFO, "Calling XtRealizeWidget\n");
	XtRealizeWidget(ADM_Top_Level);

	/*
	 * HACK ALERT!
	 *
	 * some of the form widgets don't take their sizes until after the
	 * form has been realized, so we reset the appropriate widths
	 * here, after XtRealizeWidget() has been called for the top level
	 * widget.
	 */

	DBGPrint(DBG_INFO, "Resetting recordInput Height\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, mainFormHeight ); nargs++;
	XtSetValues ( recordInput, args, nargs );

	DBGPrint(DBG_INFO, "Resetting recordViewPort Height\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, recordViewPortHeight ); nargs++;
	XtSetValues ( recordViewPort, args, nargs );

	/*
	 * ok, sit and spin...
	 */
	DBGPrint(DBG_INFO, "Calling XtAppMainLoop\n");
	XtAppMainLoop(ADM_App_Context);

}

#endif /* MAIN_C */
