/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: emailwindow.c
 *            DESCRIPTION: builds pop up for handling email addresses
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMCreateEmail
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef EMAIL_C
#define EMAIL_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/SmeLine.h>
#include <X11/Xaw/SmeBSB.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Text.h>
#include <X11/Xaw/Viewport.h>
#include <stdio.h>


/* === Project Headers === */
#include "411admin.h"
#include "display.h"
#include "help.h"
#include "textstrings.h"
#include "debug.h"

/* === external routines === */
extern void	ADMPopDownWindow();
extern void	ADMPopUpHelp();
extern void	ADMSetSensitive();
extern void	ADMClearWindow();
extern int	ADMAddHelp();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
extern Widget	transientAppShell;	/* text for help window */
extern Widget	emailShell;				/* pop up shell for email addresses */
extern Widget	optionMenuButton[NUM_OPTIONMENU];
											/* buttons in pop-down menu from
											 * Options button on Menu Bar
											 */
extern int 		ADM_Email_Input_Field;

Widget emailText[NUM_EMAILTEXT];		/* input fields for email window */
Widget emailForm;							/* top level of email window */


/* === Static Variables === */
char *email_file_menu[] = {	/* items in the Options pull down menu */
	"Clear",
	"Close"
	};

char *email_list_init[] = {	/* initial empty list of email addresses */
	"",
	"",
	"",
	"",
	"",
	NULL
	};


/*========================================================================
 *	Name:			ADMCreateEmail
 *	Prototype:	ADMCreateEmail()
 *
 *	Description:
 *		Creates pop up window for email addresses
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
ADMCreateEmail()
{
	char				fname[]="ADMCreateEmail()";
	char				buf[64];
	Arg				args[20];
	int				nargs;
	int				i;
	Dimension		width, twidth, height;
	int				startpos;

	Widget		email_menubox;
	Widget		emailFileButton, emailFileMenu, emailFileLine;
	Widget 		emailFileMenuButton[NUM_EMAILMENU];
	Widget		email_spacer;
	Widget		emailTitle;
	Widget		emailHelpButtonBox, emailGetHelp;
	Widget		emailScrolledWindow, emailTextForm;

	char			emailHelpFile[]=EMAIL_HELP_FILE;


	/*
	 * the main sub window for the email addresses
	 */
	DBGPrint(DBG_WINDOWS, "email form\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	emailForm = XtCreateManagedWidget (
			"emailForm",			/* name */
			formWidgetClass,		/* class */
			emailShell,				/* parent */
			args,	nargs				/* arg list */
			);

	/*
	 * CREATE A BOX FOR THE MENU BUTTONS
	 */
	DBGPrint(DBG_WINDOWS,"creating menu box\n");

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, DEFAULT_EMAIL_WIDTH ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNorientation, XtorientHorizontal ); nargs++;
	XtSetArg ( args[nargs], XtNvSpace, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhSpace, 0 ); nargs++;
	email_menubox = XtCreateManagedWidget (
		"MenuBox",
		boxWidgetClass,
		emailForm,
		args, nargs
		);

	/*
	 * CREATE FILE MENU AND CHILDREN
	 */

	DBGPrint(DBG_WINDOWS,"creating file menu\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Options" ); nargs++;
	XtSetArg ( args[nargs], XtNmenuName, "emailFileMenu" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	emailFileButton = XtCreateManagedWidget(
		"emailFileButton",		/* widget name */
		menuButtonWidgetClass,	/* widget class */
		email_menubox,				/* parent */
		args, nargs					/* argument list */
		);

	/*
	 * create menu popped down by statFileButton
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Email Options" ); nargs++;
	emailFileMenu = XtCreatePopupShell(
		"emailFileMenu",			/* name */
		simpleMenuWidgetClass,	/* class */
		transientAppShell,		/* parent */
		args, nargs					/* no argument list needed */
		);

	/*
	 * a line seperator in the menu
	 */
	emailFileLine = XtCreateManagedWidget(
		"emailFileMenuLine",		/* name */
		smeLineObjectClass,		/* class */
		emailFileMenu,				/* parent */
		NULL, 0						/* no argument list needed */
		);

	/*
	 * set the menu items in the pull-down menu
	 */
	for ( i = 0; i < NUM_EMAILMENU; i++ )
	{
		if ( i == NUM_EMAILMENU -1 )
			(void) sprintf ( buf, "emailClose" );
		else
			(void) sprintf ( buf, "emailMenu%d", i );

		nargs = 0;
		XtSetArg ( args[nargs], XtNlabel, email_file_menu[i] ); nargs++;

		emailFileMenuButton[i] = XtCreateManagedWidget(
			buf,						/* widget name */
			smeBSBObjectClass,	/* widget class */
			emailFileMenu,			/* parent widget*/
			args, nargs				/* argument list */
			);

		/* set the callbacks */
		switch ( i )
		{
			case EMCLEAROPTION:
				XtAddCallback ( emailFileMenuButton[i], XtNcallback,
						ADMClearWindow, (XtPointer) CLEAR_EMAIL );
				break;

			case EMCLOSEOPTION:
				XtAddCallback( emailFileMenuButton[i], 
					XtNcallback, ADMPopDownWindow, emailShell );
				XtAddCallback( emailFileMenuButton[i], 
					XtNcallback, ADMSetSensitive, optionMenuButton[EMAILOPTION]);
				break;

			default:
				break;
		}
	}

	/*
	 * CREATE A SPACER BETWEEN THE MENU BUTTONS AND THE HELP BUTTON
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &height ); nargs++;
	XtGetValues( emailFileButton, args, nargs );

	DBGPrint(DBG_WINDOWS,"creating menu spacer\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "" ); nargs++;
	XtSetArg ( args[nargs], XtNheight, height ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, email_menubox ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNresizable, True ); nargs++;
	email_spacer = XtCreateManagedWidget(
		"menuSpacer",
		labelWidgetClass,
		emailForm,
		args, nargs
		);

	/*
	 * create a box for the help button
	 */
	DBGPrint(DBG_WINDOWS,"creating help box\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, email_spacer ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNorientation, XtorientHorizontal ); nargs++;
	XtSetArg ( args[nargs], XtNvSpace, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhSpace, 0 ); nargs++;
	emailHelpButtonBox = XtCreateManagedWidget(
		"helpButtonBox",			/* name */
		boxWidgetClass,			/* class */
		emailForm,					/* parent */
		args, nargs					/* arg list */
		);


	/*
	 * create button that will pop up the help window
	 */
	DBGPrint(DBG_WINDOWS,"creating help windows\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Help" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	emailGetHelp = XtCreateManagedWidget(
		"getHelp",					/* name */
		commandWidgetClass,		/* class */
		emailHelpButtonBox,		/* parent */
		args, nargs					/* arg list */
		);


	/*
	 * add the help text to the help box
	 */
	startpos = ADMAddHelp ( ADM_HELP_FILE, emailHelpFile, 
						ADM_HELP_EMAIL_LABEL );

	/*
	 * tell help button to pop up the help window and position the cursor
	 */
	DBGPrintf(DBG_WINDOWS,("start position for stat help text: %d\n", startpos));
   XtAddCallback ( emailGetHelp, XtNcallback, 
			(XtCallbackProc)ADMPopUpHelp, (XtPointer)startpos );


	/*
	 * the Title for the email addresses scrolled window
	 */
	DBGPrint(DBG_WINDOWS, "email title bar\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, DEFAULT_EMAIL_WIDTH ); nargs++;
	XtSetArg ( args[nargs], XtNlabel, "Email Addresses" ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNjustify, XtJustifyCenter ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, email_menubox ); nargs++;
	emailTitle = XtCreateManagedWidget (
			"emailTitle",			/* name */
			labelWidgetClass,		/* class */
			emailForm,				/* parent */
			args,	nargs				/* arg list */
			);

	/* readjust the width of the spacer */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &twidth ); nargs++;
	XtGetValues( emailFileButton, args, nargs );
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( emailGetHelp, args, nargs );
	twidth += width;
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( emailTitle, args, nargs );
	twidth = width - twidth + 2;
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, twidth ); nargs++;
	XtSetValues( email_spacer, args, nargs );



	/*
	 * the window that manages scrolling
	 */
	DBGPrint(DBG_WINDOWS, "email viewport\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNfromVert, emailTitle ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNallowHoriz, True ); nargs++;
	XtSetArg ( args[nargs], XtNallowVert, True ); nargs++;
	XtSetArg ( args[nargs], XtNuseBottom, True ); nargs++;
	emailScrolledWindow = XtCreateManagedWidget (
			"emailScrolledWindow",	/* name */
			viewportWidgetClass,		/* class */
			emailForm,					/* parent */
			args,	nargs					/* arg list */
			);

	/*
	 * create the list window which gets scrolled
	 */
	DBGPrint(DBG_WINDOWS, "email list\n");

	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	emailTextForm = XtCreateManagedWidget(
			"emailTextForm",			/* name */
			formWidgetClass,			/* class */
			emailScrolledWindow,		/* parent */
			args,	nargs					/* arg list */
			);

	/*
	 * the input fields - here is where the user actually types data
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, DEFAULT_EMAIL_WIDTH ); nargs++;
	XtSetArg ( args[nargs], XtNeditType, XawtextEdit ); nargs++;
	XtSetArg ( args[nargs], XtNtopMargin, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNrightMargin, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNleftMargin, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNbottomMargin, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNstring, "" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 1 ); nargs++;
	XtSetArg ( args[nargs], XtNdisplayCaret, False ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNscrollHorizontal, XawtextScrollNever );
		nargs++;
	XtSetArg ( args[nargs], XtNscrollVertical, XawtextScrollNever );
		nargs++;


	for ( i = 0; i < NUM_PHONETEXT; i++ )
	{
		(void)sprintf ( buf, "emailText%d", i );
		emailText[i] = XtCreateWidget(
			buf,   						/* name */
			asciiTextWidgetClass,	/* class */
			emailTextForm, 			/* parent */
			args,	nargs					/* arg list */
			);
	}
	/*
	 * adjust the text fields to be verticallly arranged
	 */
	for ( i = 1; i < NUM_EMAILTEXT; i++ )
	{
		nargs=0;
		XtSetArg ( args[nargs], XtNfromVert, emailText[i-1] ); nargs++;
		XtSetValues ( emailText[i], args, nargs );
	}


	XtManageChildren ( emailText, NUM_EMAILTEXT );

	/*
	 * Which window will get keyboard focus to start
	 * This is an index value into the emailText[] array.
	 */
	ADM_Email_Input_Field = 0;


	DBGExit();

}

#endif /* EMAIL_C */
