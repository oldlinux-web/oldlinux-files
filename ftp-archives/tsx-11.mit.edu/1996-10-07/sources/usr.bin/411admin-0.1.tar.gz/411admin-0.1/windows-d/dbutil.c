/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: dbutil.c
 *            DESCRIPTION: routines that prepare for access to db
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMAddField
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBUTIL_C
#define DBUTIL_C

/* === System Headers === */
#include <stdio.h>

/* === Project Headers === */
#include "db.h"


/*========================================================================
 *	Name:			ADMAddField
 *	Prototype:	ADMAddField( char *string, char *buf, int type )
 *
 *	Description:
 *		add a field to the record buffer 
 *
 *	Input Arguments:
 *		char	*string		string to add to buffer
 *		int	type			type of delimeter to tack on
 *
 *	Output Arguments:
 *		char	buf			buffer we'll be tacking the string onto
 *
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *		No checking is done to see if adding the string to the end of buf
 *		will overflow the latter.
 *
 *	Notes:
 *		Maybe its overkill to do this, but it makes for slightly cleaner
 *		code.  By making the delimeters an int and not a character string
 *		in 411admin.h, someone else can change this without having to
 *		recompile everything.
 *		
 *========================================================================*/
void
ADMAddField(
	char	*string,
	char	*buf,
	int	type
)
{

	/*
	 * concatenate the string to the buffer
	 */
	strcat ( buf, string );

	/* tack on the field delimeter */
	switch ( type )
	{
		case FIELD:
			strcat ( buf, ";" );
			break;

		case SUBFIELD:
			strcat ( buf, ":" );
			break;

		case ENDFIELD:
			strcat ( buf, "\n" );
			break;
	}

}

#endif /* DBUTIL_C */
