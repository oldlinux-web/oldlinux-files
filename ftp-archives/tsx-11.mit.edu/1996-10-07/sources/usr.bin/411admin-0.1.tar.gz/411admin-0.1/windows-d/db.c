/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: db.c
 *            DESCRIPTION: front end to db library routines
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMRecordAdd, ADMRecordView, ADMRecordNextPrev
 *       					 : ADMRecordDelete
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DB_C
#define DB_C

/* === System Headers === */
#include <stdio.h>
#include <stdlib.h>

/* === Project Headers === */
#include "411admin.h"
#include "display.h"
#include "db.h"
#include "debug.h"

/* === external routines === */
extern int	DBAddRecord();
extern int	DBDeleteRecord();
extern int	DBParseBuf();
extern int	DBGetRecord();
extern void	ADMPopUpMsg();
extern void	ADMPutRecord();
extern void	ADMSetRecordTitle();

/* === Global Variables === */
extern char			*ADM_User_Data_String;
extern char			*ADM_Old_Record;
extern Widget 		databaseMenuButton[NUM_DATABASEMENU];
													/* buttons in pop-down menu from
													 * Database button on Menu Bar */

char	*ADM_Old_Record=NULL;		/* string to pass to db library routines */


/*========================================================================
 *	Name:			ADMRecordAdd
 *	Prototype:	ADMRecordAdd()
 *					
 *
 *	Description:
 *		Add a record to the database, if possible
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *		DBRecordAdd, ADMPopUpMessage
 *
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMRecordAdd(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char	fname[]="ADMRecordAdd()";
#endif

	char	*stringcopy, *indexfield;
	char	*subfield1, *subfield2;
	char	errmsg[128];
	int	rc;


	DBGEnter();


	if ( ADM_User_Data_String != NULL )
	{
		/*
		 * Make a copy of the string so we can validate it
		 */
		stringcopy = (char *) malloc ( strlen ( ADM_User_Data_String ) + 1);
		strcpy ( stringcopy , ADM_User_Data_String );

		/*
		 * Parse out the index field - this must not be null.
		 */
		if ( DBParseBuf( stringcopy, &indexfield, FIELD, NULL ) != DB_SUCCESS )
		{
			/*
			 * pop up message dialog saying we hit a snag
			 */
			sprintf ( errmsg, 
				"Can't parse an index field from users data" );
			ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );

			free ( stringcopy );
			DBGExit();
			return;
		}
		DBGPrintf( DBG_INFO, ("index field: \"%s\"\n", indexfield) );
		
		/*
		 * DBAddRecord() doesn't check for subfields, but we can do
		 * so here.   Parse out the three subfields of the index and
		 * make sure the first two are not null - they are required
		 * fields!
		 */
		if ( DBParseBuf( indexfield, &subfield1, SUBFIELD, NULL ) != DB_SUCCESS )
		{
			/*
			 * pop up error message
			 */
			sprintf ( errmsg, "Can't parse last name from users data" );
			ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );

			free ( stringcopy );
			DBGExit();
			return;
		}
		DBGPrintf( DBG_INFO, ("last name: \"%s\"\n", subfield1) );

		if ( DBParseBuf( indexfield, &subfield2, SUBFIELD, NULL ) != DB_SUCCESS )
		{
			/*
			 * pop up error message
			 */
			sprintf ( errmsg, "Can't parse first name from users data" );
			ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );

			free ( stringcopy );
			free ( subfield1 );
			DBGExit();
			return;
		}
		DBGPrintf( DBG_INFO, ("first name: \"%s\"\n", subfield2) );

		if ( strlen ( subfield1 ) == 0 )
		{
			/*
			 * pop up error message
			 */
			sprintf ( errmsg, "Missing last name - can't add record");
			ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );

			free ( stringcopy );
			free ( subfield1 );
			free ( subfield2 );
			DBGExit();
			return;
		}
		if ( strlen ( subfield2 ) == 0 )
		{
			/*
			 * pop up error message
			 */
			sprintf ( errmsg, "Missing first name - can't add record");
			ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );

			free ( stringcopy );
			free ( subfield1 );
			free ( subfield2 );
			DBGExit();
			return;
		}
		free ( stringcopy );
		free ( subfield1 );
		free ( subfield2 );
		

		/*
		 * The index is ok, so add the record to the database
		 */
		if ( (rc = DBAddRecord( ADM_User_Data_String ) ) != DB_SUCCESS )
		{
			/*
			 * pop up message dialog saying we hit a snag
			 */
			switch ( rc )
			{
				case DB_EXIST:
					sprintf ( errmsg, 
						"Failed to Add record.\nRecord Already Exists." );
					break;

				default:
					sprintf ( errmsg, 
						"Failed to Add record.\nDBAddRecord() returned %d.", rc );
					break;
			}
			ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );
		}
		else
		{
			sprintf ( errmsg, "Add record succeeded." );
			ADMPopUpMsg( errmsg, ADM_INFO_TYPE );

			/*
			 * desensitize the Delete and Update Database menu options
			 */
			XtSetSensitive ( databaseMenuButton[UPDATEOPTION], True );
			XtSetSensitive ( databaseMenuButton[DELETEOPTION], True );

		}
	}
	else
	{
		/*
		 * pop up message dialog
		 */
		sprintf ( errmsg, 
				"No data available (ADM_User_Data_String is NULL)");
		ADMPopUpMsg( errmsg, ADM_MSG_TYPE );
	}

	DBGExit();
}


/*========================================================================
 *	Name:			ADMRecordView
 *	Prototype:	ADMRecordView()
 *					
 *
 *	Description:
 *		View a record from the database, if possible
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *		DBGetRecord, ADMPopUpMessage
 *
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMRecordView(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char	fname[]="ADMRecordView()";
#endif

	char	*stringcopy, *indexfield;
	char	*buf;
	char	errmsg[512];
	int	rc;


	DBGEnter();


	if ( ADM_User_Data_String != NULL )
	{

		/*
		 * Make a copy of the string so we can validate it
		 */
		stringcopy = (char *) malloc ( strlen ( ADM_User_Data_String ) + 1 );
		strcpy ( stringcopy , ADM_User_Data_String );

		/*
		 * Parse out the index field - this can be null
		 */
		if ( DBParseBuf( stringcopy, &indexfield, FIELD, NULL ) != DB_SUCCESS )
		{
			/*
			 * pop up message dialog saying we hit a snag
			 */
			sprintf ( errmsg, 
				"Can't parse an index field from users data" );
			ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );

			free ( stringcopy );
			DBGExit();
			return;
		}
		free ( stringcopy );
		DBGPrintf( DBG_INFO, ("index field: \"%s\"\n", indexfield) );

		/*
		 * if the index field is too short for a hash record then tell
		 * the user to provide more information.
		 */
		if ( (strlen( indexfield ) - 2) < MIN_HASH_LENGTH )
		{
			/*
			 * pop up message dialog saying we hit a snag
			 */
			sprintf ( errmsg, 
				"Last name must be at least 4 characters long or\n"
				"if last name is less than 4 characters, then last name\n"
				"plus first name must be at least 4 characters long." );
			ADMPopUpMsg( errmsg, ADM_INFO_TYPE );

			free ( indexfield );
			DBGExit();
			return;
		}
		DBGPrint( DBG_INFO, "index field is a valid length\n" );
		free ( indexfield );
		
		/*
		 * Paranoid initialization - in case something in the dblib
		 * tries to access a freed pointer.
		 */
		buf = NULL;

		/*
		 * Call DBGetRecord() to find the first record that matches
		 * the users request. 
		 */
		rc = DBGetRecord( (int)NULL, ADM_User_Data_String, 
				&buf, DB_HAS_SUBFIELDS );
		switch ( rc )
		{
			/*
			 * no matching record found
			 */
			case DB_NOMATCH:
				sprintf ( errmsg, "No matching record found" );
				ADMPopUpMsg( errmsg, ADM_INFO_TYPE );
				break;

			/*
			 * errors while processing search request
			 */
			case DB_FAILURE:
			case DB_CANT_PARSE:
			case DB_TOO_MANY_FIELDS:
			case DB_NO_DELIMITER:
			case DB_NULL_STRING:
			case DB_BAD_TYPE:
				sprintf ( errmsg, "DBGetRecord() returned error:\nrc=%d", rc );
				ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );
				break;

			/*
			 * Matching record found
			 */
			case DB_MATCH:
				/*
				 * Free up the old request buffer and have it point
				 * to the returned record.
				 */
				free ( ADM_User_Data_String );
				ADM_User_Data_String = (char *) malloc ( strlen (buf) + 1);
				strcpy ( ADM_User_Data_String, buf );
				free ( buf );
				
				/*
				 * Now display the record
				 */
				ADMPutRecord();

				/*
				 * desensitize the Delete and Update Database menu options
				 */
				XtSetSensitive ( databaseMenuButton[UPDATEOPTION], True );
				XtSetSensitive ( databaseMenuButton[DELETEOPTION], True );

				break;
		}
	}
	else
	{
		/*
		 * no string to look up!
		 */
		DBGPrint(DBG_INFO, "The ADM_User_Data_String is NULL\n" );

		sprintf ( errmsg, 
			"Can't find any search criteria.\n"
			"Did you provide at least a last name?" );
		ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );

		DBGExit();
		return;
	}

}


/*========================================================================
 *	Name:			ADMNextPrevRecord
 *	Prototype:	ADMNextPrevRecord()
 *					
 *
 *	Description:
 *		View the next record from the database, if possible
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *		DBGetRecord, ADMPopUpMessage
 *
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMNextPrevRecord(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char	fname[]="ADMNextPrevRecord()";
#endif

	char	*buf;
	char	errmsg[512];
	int	rc;
	int	type;

	DBGEnter();

	switch ( (int) client_data ) 
	{
		case NEXTOPTION:
			type = DB_GET_NEXT;
			break;

		case PREVOPTION:
			type = DB_GET_PREVIOUS;
			break;

		default:
			DBGPrintf(DBG_INFO,("invalid type in callback: %d\n", 
				(int) client_data) );
			sprintf ( errmsg, 
			"Internal error:  can't determine what record (Next or Prev) to get.");
			ADMPopUpMsg( errmsg, ADM_INFO_TYPE );
			return;
			break;
	}

	/*
	 * Call DBGetRecord() to find the first record that matches
	 * the users request. 
	 */
	rc = DBGetRecord( type, NULL, &buf, DB_HAS_SUBFIELDS );
	switch ( rc )
	{
		/*
		 * no matching record found
		 */
		case DB_NOMATCH:
			sprintf ( errmsg, "No matching record found" );
			ADMPopUpMsg( errmsg, ADM_INFO_TYPE );
			break;

		/*
		 * You haven't searched for the first record yet...
		 */
		case DB_NULL_STATIC_INDEX:
			sprintf ( errmsg, "No current record; can't search for next record" );
			ADMPopUpMsg( errmsg, ADM_INFO_TYPE );
			break;

		/*
		 * errors while processing search request
		 */
		case DB_FAILURE:
		case DB_CANT_PARSE:
		case DB_TOO_MANY_FIELDS:
		case DB_NO_DELIMITER:
		case DB_NULL_STRING:
		case DB_BAD_TYPE:
			sprintf ( errmsg, "DBGetRecord() returned error:\nrc=%d", rc );
			ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );
			break;

		/*
		 * Matching record found
		 */
		case DB_MATCH:
			/*
			 * Free up the old request buffer and have it point
			 * to the returned record.
			 */
			free ( ADM_User_Data_String );
			ADM_User_Data_String = (char *) malloc ( strlen (buf) + 1);
			strcpy ( ADM_User_Data_String, buf );
			free ( buf );
			
			/*
			 * Now display the record
			 */
			ADMPutRecord();

			/*
			 * Since we have a record pulled from the db, we can allow
			 * a delete to be done.
			 */
			XtSetSensitive ( databaseMenuButton[DELETEOPTION], True);
			XtSetSensitive ( databaseMenuButton[UPDATEOPTION], True);

			break;
	}

	DBGExit();

}


/*========================================================================
 *	Name:			ADMRecordDelete
 *	Prototype:	ADMRecordDelete()
 *					
 *
 *	Description:
 *		Delete a record from the database, if possible
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *		DBRecordDelete, ADMPopUpMessage
 *
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMRecordDelete(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char		fname[]="ADMRecordDelete()";
#endif

	char		errmsg[512];
	int		rc;


	DBGEnter();


	if ( ADM_User_Data_String != NULL )
	{
		if ( (rc = DBDeleteRecord( ADM_User_Data_String ) ) != DB_SUCCESS )
		{
			switch ( rc )
			{
				case DB_NOMATCH:
				case DB_NOMATCH_HASH:
					/*
					 * the record specified doesn't exist
					 */
					DBGPrint(DBG_INFO, "DBDeleteRecord returned DB_NOMATCH\n");

					sprintf ( errmsg, 
						"That record doesn't exist;  no records deleted." );
					ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );
					break;

				default:
					/*
					 * something went wrong during deletion process
					 */
					DBGPrintf(DBG_INFO, 
						("DBDeleteRecord returned error: rc=%d\n", rc) );

					sprintf ( errmsg, 
						"An error occured during the delete process.\n"
						"DBDeleteRecord returned an error:  rc=%d", rc );
					ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );
					break;

			}

		}
		else
		{
			/*
			 * record properly deleted
			 */
			DBGPrintf(DBG_INFO, 
				("DBDeleteRecord returned error: rc=%d\n", rc) );

			sprintf ( errmsg, "Record successfully deleted" );
			ADMPopUpMsg( errmsg, ADM_INFO_TYPE );

		}
	}
	else
	{
		/*
		 * no string to look up!
		 */
		DBGPrint(DBG_INFO, "The ADM_User_Data_String is NULL\n" );

		sprintf ( errmsg, 
			"No record to delete.  Did you provide\n"
			"at least a last name?" );
		ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );

	}

	/*
	 * desensitize the Delete and Update Database menu options
	 */
	XtSetSensitive ( databaseMenuButton[UPDATEOPTION], False );
	XtSetSensitive ( databaseMenuButton[DELETEOPTION], False );

	DBGExit();
	return;

}


/*========================================================================
 *	Name:			ADMRecordUpdate
 *	Prototype:	ADMRecordUpdate()
 *					
 *
 *	Description:
 *		Update a record from the database, if possible
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *		DBRecordDelete, DBRecordAdd, ADMPopUpMessage
 *
 *	Method:
 *		DBDeleteRecord( old_data )
 *		DBAddRecord( new record )
 *
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMRecordUpdate(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char		fname[]="ADMRecordUpdate()";
#endif

	int		rc;
	char		errmsg[128];

	/*
	 * Updating a record should not be possible until some other record
	 * has been viewed.  This is possibly annoying, but it prevents alot
	 * of other sticky situations that could arise.
	 */

	/*
	 * Validate the two strings we need
	 */
	if ( ADM_Old_Record == NULL )
	{
		/*
		 * no string to delete!
		 */
		DBGPrint(DBG_INFO, "The ADM_Old_Record is NULL\n" );

		sprintf ( errmsg, 
			"No record to delete.  Did you use the\n"
			"View option first?" );
		ADMPopUpMsg( errmsg, ADM_INFO_TYPE );
		return;
	}
	if ( ADM_User_Data_String == NULL )
	{
		/*
		 * no string to add!
		 */
		DBGPrint(DBG_INFO, "The ADM_User_Data_String is NULL\n" );

		sprintf ( errmsg, 
			"No record to update.  Did you specify\n"
			"the changes to the record?" );
		ADMPopUpMsg( errmsg, ADM_INFO_TYPE );
		return;
	}


	/*
	 * desensitize the Delete and Update Database menu options
	 */
	XtSetSensitive ( databaseMenuButton[UPDATEOPTION], False );
	XtSetSensitive ( databaseMenuButton[DELETEOPTION], False );


	/*
	 * We should already have the two records we need.  Delete the old
	 * record first.
	 */
	if ( (rc = DBDeleteRecord ( ADM_Old_Record ) ) != DB_SUCCESS )
	{
		/*
		 * Couldn't delete the record - don't try adding the new one!
		 */
		free ( ADM_Old_Record );
		ADM_Old_Record = NULL;

		if ( ADM_User_Data_String != NULL )
		{
			free ( ADM_User_Data_String );
			ADM_User_Data_String = NULL;
		}

		switch ( rc )
		{
			case DB_NOMATCH:
			case DB_NOMATCH_HASH:
				/*
				 * the record specified doesn't exist
				 */
				DBGPrint(DBG_INFO, "DBDeleteRecord returned DB_NOMATCH\n");

				sprintf ( errmsg, 
					"Couldn't find the original record;  record not updated." );
				ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );
				break;

			default:
				/*
				 * something went wrong during deletion process
				 */
				DBGPrintf(DBG_INFO, 
					("DBDeleteRecord returned error: rc=%d\n", rc) );

				sprintf ( errmsg, 
					"An error occured during the update process.\n"
					"DBDeleteRecord returned an error:  rc=%d", rc );
				ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );
				break;

		}
		return;
	}

	/*
	 * Old record deleted - now add the new one.  This better work
	 * since we can't rollback changes!
	 */
	if ( (rc = DBAddRecord( ADM_User_Data_String ) ) != DB_SUCCESS )
	{
		free ( ADM_Old_Record );
		ADM_Old_Record = NULL;

		free ( ADM_User_Data_String );
		ADM_User_Data_String = NULL;

		/*
		 * pop up message dialog saying we hit a snag
		 */
		switch ( rc )
		{
			case DB_EXIST:
				sprintf ( errmsg, 
					"That record already exists. No update done." );
				break;

			default:
				sprintf ( errmsg, 
					"Failed to update record.\nDBAddRecord() returned %d.", rc );
				break;
		}
		ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );

		return;
	}

	sprintf ( errmsg, "Update of record succeeded." );
	ADMPopUpMsg( errmsg, ADM_INFO_TYPE );

	free ( ADM_Old_Record );
	ADM_Old_Record = NULL;

	free ( ADM_User_Data_String );
	ADM_User_Data_String = NULL;

	/*
	 * Tell the user to select another function
	 */
	ADMSetRecordTitle( NULL, (XtPointer)ADM_SEL_FUNCTION, NULL );
}

#endif /* DB_C */
