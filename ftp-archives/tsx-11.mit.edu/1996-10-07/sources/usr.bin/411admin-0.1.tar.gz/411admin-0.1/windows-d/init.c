/* $Id$ */ 

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: init.c
 *            DESCRIPTION: initialization and shutdown for Administrator
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMShutdown
 *      PRIVATE FUNCTIONS:
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readability
 *
 * SPECIAL CONSIDERATIONS:
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 *	$LOG$
 *
 *========================================================================*/

#ifndef INIT_C
#define INIT_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>

/* === Project Headers === */
#include "411admin.h"
#include "db.h"
#include "debug.h"

/* === system defined === */

/* === external routines === */
extern int	DBInit();
extern void	DBShutdown();

/* === Public routine prototypes === */
void ADMShutdown();

/* === Private routine prototypes === */

/* === Global Variables === */

/*
 * external
 */
extern AppData		ADM_App_Data;			/* application resource data */


/*
 * local
 */
char			ADM_Lock_File[MAXNAMELENGTH];	/* name of program lock file */
int			ADM_fpa;								/* program lock file descriptor */



/* the following is a command to the lint program */
/* LINTLIBRARY */

/*========================================================================
 *	Name:			ADMShutdown
 *	Prototype:	ADMShutdown()
 *					
 *
 *	Description:
 *		Graceful shutdown of the 411admin program.
 *		Called either as a callback, by signal handlers, or just when
 *		life gets tough.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *	Global Variables:
 *	External Routines:
 *
 *	Method:
 *		A. close and remove the program lock file
 *
 *	Restrictions:
 *
 *	Notes:
 *		
 *========================================================================*/
void
ADMShutdown(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{
#ifdef DEBUG
	char	fname[]="ADMShutdown()";
#endif

	/*
	 * close up the database
	 */
	DBShutdown();


	/*
	 * remove the 411admin program lock
	 */
	if ( ADM_fpa != -1 )
	{
		(void) close( ADM_fpa );		
		if ( unlink ( ADM_Lock_File ) != 0 )
		{
			printf ("Can't find program lock file: %s\n", ADM_Lock_File);
			DBGPrintf(DBG_INFO,("Can't find prorgram lock file: %s\n",
					ADM_Lock_File));
		}
	}
	else
	{
		DBGPrint(DBG_INFO,"Lock file descriptor = -1\nCheck with sysadm!\n");
	}


	/*
	 * close the DEBUG output, if any
	 */
	DBGExit();
	DBGClose(DEBUG_FD);


	/*
	 * B'bye!
	 */
	exit ( 0 );
}


/*========================================================================
 *	Name:			ADMInit
 *	Prototype:	ADMInit()
 *					
 *
 *	Description:
 *		Checks for and creates, if necessary directories and files
 *		necessary to run the database.
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *	Global Variables:
 *	External Routines:
 *
 *	Method:
 *		A. close and remove the program lock file
 *
 *	Restrictions:
 *
 *	Notes:
 *		
 *========================================================================*/
void
ADMInit()
{

#ifdef DEBUG
	char				fname[]="ADMInit()";
#endif

	struct stat		stat_buf;				/* file info structure */


	DBGEnter();

	/*
	 * verify existance of database directory
	 */
	if ( stat ( ADM_App_Data.db_dir, &stat_buf ) != 0 )
	{
		printf ( "Checking for program lock file.\n");
		switch ( errno )
		{
			case EACCES:	
				printf ( "Search permission denied for portion of path");
				printf ( " leading to %s\n", ADM_App_Data.db_dir );
				printf ( "Aborting.\n");
				DBGClose ( DEBUG_FD );
				exit ( -1 );
				break;
			case ENOTDIR:	
				printf ( "A portion of the pathname to %s", ADM_App_Data.db_dir);
				printf ( " is invalid\n" );
				printf ( "Aborting.\n");
				DBGClose ( DEBUG_FD );
				exit ( -1 );
				break;
			case ENOENT:
				printf ( "%s: no such file or directory\n", ADM_App_Data.db_dir );
				printf ( "Aborting.\n");
				DBGClose ( DEBUG_FD );
				exit ( -1 );
				break;
			default:
				printf ("Unknown error (%d) while stat()'ing %s\n", errno,
					ADM_App_Data.db_dir );
				printf ( "Aborting.\n");
				DBGClose ( DEBUG_FD );
				exit ( -1 );
				break;
		}
	}


	/*
	 * Check to see if there is already a version of 411admin running.
	 * If not, try to create lock file
	 */
	DBGPrint(DBG_INFO, "setting program lock file\n");
	sprintf( ADM_Lock_File, "%s/%s", ADM_App_Data.db_dir, ADMLOCKNAME_P );
	if ( ( ADM_fpa = open( ADM_Lock_File, O_CREAT | O_EXCL, 0700 ) ) == -1 )
	{
		if ( errno == EEXIST )
		{
			DBGPrint( DBG_INFO,
				"Attempt to open a second administrator failed.\n" );
			printf( "A version of the Administrator is already running.\n" );
		}
		else
		{
			printf( "Could not open program lock file: "
						"%s\nopen() returned errno=%d\n", ADM_Lock_File, errno );
			DBGPrint( DBG_INFO,
				"Attempt to open administrator lock file failed\n");
		}
		DBGClose ( DEBUG_FD );
		exit( -1 );
	}


	/*
	 * deal with signals
	 * 	1. we only want to exit gracefully, via menus 
	 * 	2. if lost terminal, clean up and exit
	 */
	DBGPrint(DBG_INFO, "setting up signal handling\n");
	signal(SIGINT, (void *)ADMShutdown );  
	signal(SIGQUIT, (void *)ADMShutdown );
	signal(SIGTERM, (void *)ADMShutdown );
	signal(SIGKILL, (void *)ADMShutdown );
	signal(SIGHUP, (void *)ADMShutdown ); 
	signal(SIGSEGV, SIG_DFL ); 


	/*
	 * tell the user this might take a moment or two
	 */
	printf ( "Initializing.  Please wait.\n" );


	/*
	 * Initialize the database
	 */
	if ( DBInit (	ADM_App_Data.db_dir,
						ADM_App_Data.db_file,
						ADM_App_Data.hash_file,
						ADM_App_Data.index_file ) != DB_SUCCESS )
	{
		DBGPrint (DBG_INFO, "Database not initialized.\n");
		printf ("Errors initializing database.\n");
		printf ("Aborting.\n");
		DBGClose(DEBUG_FD);
		exit ( -1 );
	}

	DBGPrint (DBG_INFO, "Index and hash files ok.\n");

}

#endif /* INIT_C */
