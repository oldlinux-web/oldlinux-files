/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: stats.c
 *            DESCRIPTION: displays db status information
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMDBStatus
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 *  Since this was ported from my original (and poorly written) Motif
 *  version, the variable names don't quite match the following
 *  special considerations.  But I'm trying to fix that.
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout all 411Admin
 * source:
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, key words capitalized			PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 *		no underscores, mixed case							staticVariable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 *	$Log$
 *
 *========================================================================*/
#ifndef STATUS_C
#define STATUS_C

/* === System Headers === */
#include <stdio.h>

/* === Project Headers === */
#include "display.h"
#include "textstrings.h"
#include "db.h"
#include "debug.h"


/* === external routines === */
extern int	DBStats();
extern void	ADMPopUpMsg();
extern void	ADMSetRecordTitle();

/* === Global Variables === */
extern Widget statTextFields[NUM_STATTEXT];


/*========================================================================
 *	Name:			ADMDBStats
 *	Prototype:	ADMDBStats()
 *					
 *
 *	Description:
 *		compute and display various stats on data files
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *	External Routines:
 *		DBStats, ADMPopUpMessage
 *
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMDBStats(
	Widget w,
	XtPointer client_data, 
	XtPointer call_data
)
{

#ifdef DEBUG
	char			fname[]="ADMDBStats()";
#endif

	Arg			args[1];
	DB_STAT		dbstat;
	int			rc;
	char			errmsg[128];
	char			buf[32];


	/*
	 * Have the db lib compute the statistics on the database
	 */
	if ( (rc = DBStats ( &dbstat ) ) != DB_SUCCESS )
	{
		DBGPrintf(DBG_INFO, ("DBStats() returned error; rc=%d\n", rc) );

		sprintf ( errmsg, "Error retrieving database statistics." );
		ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );

		DBGExit();
		return;
	}

	/*
	 * now output it all to the screen
	 */

	sprintf ( buf, "%d", dbstat.ff_length );
	XtSetArg ( args[0], XtNlabel, buf );
	XtSetValues ( statTextFields[STATLENGTH], args, 1 );

	sprintf ( buf, "%d", dbstat.num_hash );
	XtSetArg ( args[0], XtNlabel, buf );
	XtSetValues ( statTextFields[STATHASH], args, 1 );

	sprintf ( buf, "%d", dbstat.tot_num_recs );
	XtSetArg ( args[0], XtNlabel, buf );
	XtSetValues ( statTextFields[STATTOTAL], args, 1 );

	sprintf ( buf, "%d", dbstat.num_act_recs );
	XtSetArg ( args[0], XtNlabel, buf );
	XtSetValues ( statTextFields[STATACTIVE], args, 1 );

	sprintf ( buf, "%d", dbstat.num_inact_recs );
	XtSetArg ( args[0], XtNlabel, buf );
	XtSetValues ( statTextFields[STATINACTIVE], args, 1 );

	sprintf ( buf, "%d%%", dbstat.perc );
	XtSetArg ( args[0], XtNlabel, buf );
	XtSetValues ( statTextFields[STATPERC], args, 1 );


	if ( dbstat.perc > 30 )
		ADMSetRecordTitle ( NULL, (XtPointer) ADM_REBUILD_NOTICE, NULL );

}

#endif /* STATUS_C */
