/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: xutil.c
 *            DESCRIPTION: generic window handling routines
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMPopUpWindow, ADMPopDownWindow, 
 *								 : ADMSetSensitive, ADMSetInsensitive, 
 *								 : ADMPopDownCurrent, ADMSetFocusIn,
 *								 : ADMHideCaret, ADMDisplayCaret, ADMNextField
 *								 : ADMPreviousField, ADMGetRecord
 *								 : ADMClearWindow, ADMGetRecord
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef XUTIL_C
#define XUTIL_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Xaw/AsciiText.h>
#include <stdio.h>
#include <stdlib.h>

/* === Project Headers === */
#include "411admin.h"
#include "display.h"
#include "help.h"
#include "debug.h"
#include "db.h"

/* === external routines === */
extern void	ADMAddField();
extern void	ADMPopUpMsg();
extern int	DBParseBuf();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
extern Widget	ADM_Top_Level;		/* shell of main window */
extern Widget	helpShell;			/* pop up help window */
extern Widget	helpText;			/* help text for the help window */
extern Widget	mainForm;			/* main window that manages multiple
											 * children at different times
											 */
extern Widget	optionMenuButton[NUM_OPTIONMENU];
											/* buttons in pop-down menu from
											 * Options button on Menu Bar
											 */
extern Widget	recordInput; 		/* main form for record input */
extern Widget	recordInputText[NUM_INPUTTEXT];
											/* input fields for record window */
extern Widget	phoneForm;			/* top level of phone window */
extern Widget	phoneText[NUM_PHONETEXT];
											/* input fields for phone window */
extern Widget	emailForm;			/* top level of email window */
extern Widget	emailText[NUM_EMAILTEXT];
											/* input fields for email window */
extern Widget 	commentsScrolledWindow;
											/* where comments are entered */

/*
 * locall defined
 */
Widget ADM_Current_Window;			/* which window is currently managed
											 * in the mainForm window
											 */
int ADM_Record_Input_Field;		/* current text field with focus applied */
int ADM_Email_Input_Field;			/* current text field with focus applied */
int ADM_Phone_Input_Field;			/* current text field with focus applied */

char	*ADM_User_Data_String=NULL;/* string to pass to db library routines */


/*========================================================================
 *	Name:			ADMPopUpWindow
 *	Prototype:	ADMPopUpWindow()
 *
 *	Description:
 *		callback to pop up a transient shell
 *
 *	Input Arguments:
 *		XtPointer client_data		widget to pop up
 *
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMPopUpWindow (
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char				fname[]="ADMPopUpWindow()";
#endif

	Arg				args[3];
	int				nargs;
	Window			root, child;
	unsigned int	mask;
	int				root_x, root_y, child_x, child_y;

	DBGEnter();

	/*
	 * find out where the mouse is and pop up the window there
	 */
	XQueryPointer ( XtDisplay(ADM_Top_Level), XtWindow(ADM_Top_Level),
		&root, &child,
		&root_x, &root_y,
		&child_x, &child_y,
		&mask
		);

	nargs=0;
	XtSetArg( args[nargs], XtNx, root_x ); nargs++;
	XtSetArg( args[nargs], XtNy, root_y ); nargs++;
	XtSetValues( (Widget) client_data, args, nargs );

	XtPopup ( (Widget) client_data, XtGrabNone );

	DBGExit();
}

/*========================================================================
 *	Name:			ADMPopDownWindow
 *	Prototype:	ADMPopDownWindow()
 *
 *	Description:
 *		callback to pop down a transient shell
 *
 *	Input Arguments:
 *		XtPointer client_data		widget to pop down
 *
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMPopDownWindow (
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char fname[]="ADMPopDownWindow()";
#endif

	DBGEnter();
	XtPopdown ( (Widget) client_data );
	DBGExit();
}


/*========================================================================
 *	Name:			ADMSetSensitive
 *	Prototype:	ADMSetSensitive()
 *
 *	Description:
 *		callback for sensitizing a widget
 *
 *	Input Arguments:
 *		XtPointer client_data		widget to set sensitive
 *
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMSetSensitive (
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char fname[]="ADMSetSensitive()";
#endif

	DBGEnter();
	XtSetSensitive ( (Widget) client_data, True );
	DBGExit();
}

/*========================================================================
 *	Name:			ADMSetInsensitive
 *	Prototype:	ADMSetInsensitive()
 *
 *	Description:
 *		callback for desensitizing a widget
 *
 *	Input Arguments:
 *		XtPointer client_data		widget to set insensitive
 *
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMSetInsensitive (
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char fname[]="ADMSetInsensitive()";
#endif

	DBGEnter();
	XtSetSensitive ( (Widget) client_data, False );
	DBGExit();
}



/*========================================================================
 *	Name:			ADMPopDownCurrent
 *	Prototype:	ADMPopDownCurrent()
 *
 *	Description:
 *		callback for popping down the current window and setting
 *		the new current window to be popped up.
 *
 *	Input Arguments:
 *		XtPointer client_data		widget id which will become the current
 *											widget in the mainForm window
 *
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *		ADM_Current_Window			widget id of the window currently
 *											displayed in the mainForm window
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMPopDownCurrent (
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char fname[]="ADMPopDownCurrent()";
#endif

	DBGEnter();

	/*
	 * don't switch windows if the one being requested is
	 * already managed.
	 */
	if ( (Widget) client_data != ADM_Current_Window )
	{
		XtUnmanageChild ( ADM_Current_Window );
		ADM_Current_Window = (Widget) client_data;
	}

	DBGExit();
}

/*========================================================================
 *	Name:			ADMPopUpCurrent
 *	Prototype:	ADMPopUpCurrent()
 *
 *	Description:
 *		callback for popping up the current window
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMPopUpCurrent (
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char					fname[]="ADMPopUpCurrent()";
#endif


	DBGEnter();

	/*
	 * don't switch windows if the one being requested is
	 * already managed.
	 */
	if ( XtIsManaged ( ADM_Current_Window ) != True )
	{
		XtManageChild ( ADM_Current_Window );
	}

	DBGExit();
}


/*========================================================================
 *	Name:			ADMPopUpHelp
 *	Prototype:	ADMPopUpHelp()
 *
 *	Description:
 *		callback to pop up the help window and position the cursor in it
 *
 *	Input Arguments:
 *		XtPointer client_data		location of text string to place cursor
 *
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMPopUpHelp (
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char	fname[]="ADMPopUpHelp()";
#endif

	Arg	args[4];
	int	nargs;

	DBGEnter();
	DBGPrintf(DBG_UTIL,("put cursor at position: %d\n", (int) client_data));

	nargs = 0;
	XtSetArg( args[nargs], XtNdisplayPosition, (int) client_data ); nargs++;
	XtSetValues ( helpText, args, nargs );

	XtPopup ( helpShell, XtGrabNone );

	DBGExit();
}



/*========================================================================
 *	Name:			ADMHideCaret
 *	Prototype:	ADMHideCaret( int window )
 *
 *	Description:
 *		turn off the caret in the current text field
 *
 *	Input Arguments:
 *		int window				window to hide carret
 *
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *		int ADM_Record_Input_Field			current record input field
 *		int ADM_Email_Input_Field			current email input field
 *		int ADM_Phone_Input_Field			current phone input field
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		ADMHideRecord, ADMHideEmail, and ADMHidePhone are convenience
 *		functions which call ADMHideCaret with the correct window identifier.
 *		
 *========================================================================*/
void
ADMHideCaret (
	int window
)
{

	Arg	args[1];
	int	nargs;


	nargs=0;
	XtSetArg ( args[nargs], XtNdisplayCaret, False ); nargs++;

	switch ( window )
	{

		case RECORDWINDOW:
			XtSetValues ( recordInputText[ADM_Record_Input_Field], args, nargs);
			break;

		case EMAILWINDOW:
			XtSetValues ( emailText[ADM_Email_Input_Field], args, nargs);
			break;

		case PHONEWINDOW:
			XtSetValues ( phoneText[ADM_Phone_Input_Field], args, nargs);
			break;

		default:
			break;
	}


}
void
ADMHidePhone()
{
	ADMHideCaret ( PHONEWINDOW );
}

void
ADMHideEmail()
{
	ADMHideCaret ( EMAILWINDOW );
}

void
ADMHideRecord()
{
	ADMHideCaret ( RECORDWINDOW );
}




/*========================================================================
 *	Name:			ADMDisplayCaret
 *	Prototype:	ADMDisplayCaret( int window )
 *
 *	Description:
 *		turn on the caret in the current text field
 *
 *	Input Arguments:
 *		int window				which window to display the caret in
 *
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *		int ADM_Record_Input_Field			current record input field
 *		int ADM_Email_Input_Field			current email input field
 *		int ADM_Phone_Input_Field			current phone input field
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMDisplayCaret (
	int	window
)
{

	Arg	args[1];
	int	nargs;

	nargs=0;
	XtSetArg ( args[nargs], XtNdisplayCaret, True ); nargs++;

	switch ( window )
	{
		case RECORDWINDOW:
			XtSetValues ( recordInputText[ADM_Record_Input_Field], args, nargs);
			break;

		case EMAILWINDOW:
			XtSetValues ( emailText[ADM_Email_Input_Field], args, nargs);
			break;

		case PHONEWINDOW:
			XtSetValues ( phoneText[ADM_Phone_Input_Field], args, nargs);
			break;

		default:
			break;
	}

}



/*========================================================================
 *	Name:			ADMNextField
 *	Prototype:	ADMNextField( int window )
 *
 *	Description:
 *		move the keyboard focus to the next field in the input window
 *		and display the caret.
 *
 *	Input Arguments:
 *		int window				which window we're moving around in
 *
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *		int ADM_Record_Input_Field			current record input field
 *		int ADM_Email_Input_Field			current email input field
 *		int ADM_Phone_Input_Field			current phone input field
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		ADMNextEmail, ADMNextPhone, and ADMNextRecord are convenience
 *		routines which call ADMNextField with the correct window identifier.
 *		
 *========================================================================*/
void
ADMNextField (
	int window
)
{

#ifdef DEBUG
	char	fname[]="ADMNextField()";
#endif

	DBGEnter();

	/*
	 * turn off the caret for the current text field
	 */
	ADMHideCaret( window );

	/*
	 * move to the next text field - this is circular
	 */
	switch ( window )
	{

		case RECORDWINDOW:
			switch ( ADM_Record_Input_Field )
			{
				case NUM_INPUTTEXT - 1:
					ADM_Record_Input_Field = 0;
					break;
				default:
					ADM_Record_Input_Field++;
			}

			/*
			 * set the focus to the new field
			 */
			DBGPrint ( DBG_UTIL, "Next Field: Record Window\n" );
			XtSetKeyboardFocus ( recordInput, 
				recordInputText[ADM_Record_Input_Field] );
			break;


		case EMAILWINDOW:
			switch ( ADM_Email_Input_Field )
			{
				case NUM_EMAILTEXT - 1:
					ADM_Email_Input_Field = 0;
					break;
				default:
					ADM_Email_Input_Field++;
			}

			/*
			 * set the focus to the new field
			 */
			DBGPrint ( DBG_UTIL, "Next Field: email Window\n" );
			XtSetKeyboardFocus ( emailForm, emailText[ADM_Email_Input_Field] );
			break;


		case PHONEWINDOW:
			switch ( ADM_Phone_Input_Field )
			{
				case NUM_PHONETEXT - 1:
					ADM_Phone_Input_Field = 0;
					break;
				default:
					ADM_Phone_Input_Field++;
			}

			/*
			 * set the focus to the new field
			 */
			DBGPrint ( DBG_UTIL, "Next Field: phone Window\n" );
			XtSetKeyboardFocus ( phoneForm, phoneText[ADM_Phone_Input_Field] );
			break;

		default:
			break;

	}

	/*
	 * turn on the caret for this field
	 */
	ADMDisplayCaret( window );

	DBGExit();

}
void
ADMNextPhone()
{
	ADMNextField ( PHONEWINDOW );
}

void
ADMNextEmail()
{
	ADMNextField ( EMAILWINDOW );
}

void
ADMNextRecord()
{
	ADMNextField ( RECORDWINDOW );
}




/*========================================================================
 *	Name:			ADMPreviousField
 *	Prototype:	ADMPreviousField( int window )
 *
 *	Description:
 *		move the keyboard focus to the previous field in the input window
 *		and display the caret.
 *
 *	Input Arguments:
 *		int window				which window we're moving around in
 *
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *		int ADM_Record_Input_Field			current record input field
 *		int ADM_Email_Input_Field			current email input field
 *		int ADM_Phone_Input_Field			current phone input field
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		ADMNextEmail, ADMNextPhone, and ADMNextRecord are convenience
 *		routines which call ADMNextField with the correct window identifier.
 *		
 *========================================================================*/
void
ADMPreviousField (
	int	window
)
{

#ifdef DEBUG
	char	fname[]="ADMPreviousField()";
#endif

	DBGEnter();

	/*
	 * turn off the caret for the current text field
	 */
	ADMHideCaret( window );

	switch ( window ) 
	{
		case RECORDWINDOW:
			/*
			 * move to the next text field - this is circular
			 */
			switch ( ADM_Record_Input_Field )
			{
				case 0:
					ADM_Record_Input_Field = NUM_INPUTTEXT - 1;
					break;
				default:
					ADM_Record_Input_Field--;
			}

			/*
			 * set the focus to the new field
			 */
			DBGPrint ( DBG_UTIL, "Previous Field: Record Window\n" );
			XtSetKeyboardFocus ( recordInput, 
				recordInputText[ADM_Record_Input_Field] );

			break;


		case EMAILWINDOW:
			/*
			 * move to the next text field - this is circular
			 */
			switch ( ADM_Email_Input_Field )
			{
				case 0:
					ADM_Email_Input_Field = NUM_EMAILTEXT - 1;
					break;
				default:
					ADM_Email_Input_Field--;
			}

			/*
			 * set the focus to the new field
			 */
			DBGPrint ( DBG_UTIL, "Previous Field: Email Window\n" );
			XtSetKeyboardFocus ( emailForm, emailText[ADM_Email_Input_Field] );

			break;


		case PHONEWINDOW:
			/*
			 * move to the next text field - this is circular
			 */
			switch ( ADM_Phone_Input_Field )
			{
				case 0:
					ADM_Phone_Input_Field = NUM_PHONETEXT - 1;
					break;
				default:
					ADM_Phone_Input_Field--;
			}

			/*
			 * set the focus to the new field
			 */
			DBGPrint ( DBG_UTIL, "Previous Phone: Email Window\n" );
			XtSetKeyboardFocus ( phoneForm, phoneText[ADM_Phone_Input_Field] );

			break;

	}

	/*
	 * turn on the caret for this field
	 */
	ADMDisplayCaret( window );


	DBGExit();

}

void
ADMPreviousPhone()
{
	ADMPreviousField ( PHONEWINDOW );
}

void
ADMPreviousEmail()
{
	ADMPreviousField ( EMAILWINDOW );
}

void
ADMPreviousRecord()
{
	ADMPreviousField ( RECORDWINDOW );
}




/*========================================================================
 *	Name:			ADMSetFocusIn
 *	Prototype:	ADMSetFocusIn( int window )
 *
 *	Description:
 *		set the focus to the current text field and display the caret
 *
 *	Input Arguments:
 *		int window				which window to set the focus in
 *
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *		int ADM_Record_Input_Field			current record input field
 *		int ADM_Email_Input_Field			current email input field
 *		int ADM_Phone_Input_Field			current phone input field
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		ADMRecordFocus, ADMEmailFocus, ADMPhoneFocus are convienence routines
 *		that call ADMSetFocusIn with the proper window identifier.
 *		
 *========================================================================*/
void
ADMSetFocusIn (
	int	window
)
{

	switch ( window )
	{

		case RECORDWINDOW:
			XtSetKeyboardFocus ( recordInput, 
				recordInputText[ADM_Record_Input_Field] );
			break;

		case EMAILWINDOW:
			XtSetKeyboardFocus ( emailForm, emailText[ADM_Email_Input_Field] );
			break;

		case PHONEWINDOW:
			XtSetKeyboardFocus ( phoneForm, phoneText[ADM_Phone_Input_Field] );
			break;

		default:
			break;
	}

	ADMDisplayCaret( window );

}

void
ADMRecordFocus()
{
	ADMSetFocusIn ( RECORDWINDOW );
}

void
ADMEmailFocus()
{
	ADMSetFocusIn ( EMAILWINDOW );
}

void
ADMPhoneFocus()
{
	ADMSetFocusIn ( PHONEWINDOW );
}



/*========================================================================
 *	Name:			ADMClearWindow
 *	Prototype:	ADMClearWindow()
 *
 *	Description:
 *		clear the record fields of the output windows
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *		Widget	optionMenuButton[]		main menu Options menu
 *		Widget	recordInputText[]			text fields in record window
 *		Widget	phoneText[]					text fields in phone window
 *		Widget	emailText[]					text fields in email window
 *		Widget 	commentsScrolledWindow	comments text field
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMClearWindow(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

	char		fname[]="ADMClearWindow()";
	Arg		args[10];
	int		i;


	DBGEnter();

	XtSetArg ( args[0], XtNstring, "\0" );

	switch ( (int) client_data )
	{

		case CLEAR_ALL:
			/* record window */
			for ( i = 0; i < NUM_INPUTTEXT; i++ )
				XtSetValues ( recordInputText[i], args, 1 );
		
			/* comments */
			XtSetValues ( commentsScrolledWindow, args, 1 );
		
			/* phone fields */
			for ( i = 0; i < NUM_PHONETEXT; i++ )
				XtSetValues ( phoneText[i], args, 1 );
		
			/* email addresses */
			for ( i = 0; i < NUM_EMAILTEXT; i++ )
				XtSetValues ( emailText[i], args, 1 );
		
			/*
			 * Set the keyboard focus back to the first input field
			 * of each window.
			 */
			XtSetKeyboardFocus ( recordInput, recordInputText[0] );
			XtSetKeyboardFocus ( emailForm, emailText[0] );
			XtSetKeyboardFocus ( phoneForm, phoneText[0] );
		
			ADM_Record_Input_Field = 0;
			ADM_Email_Input_Field = 0;
			ADM_Phone_Input_Field = 0;
			break;

		case CLEAR_COMMENTS:
			XtSetValues ( commentsScrolledWindow, args, 1 );
			break;
		
		case CLEAR_EMAIL:
			for ( i = 0; i < NUM_EMAILTEXT; i++ )
				XtSetValues ( emailText[i], args, 1 );
			XtSetKeyboardFocus ( emailForm, emailText[0] );
			ADM_Email_Input_Field = 0;
			break;
		
		case CLEAR_PHONE:
			for ( i = 0; i < NUM_PHONETEXT; i++ )
				XtSetValues ( phoneText[i], args, 1 );
			XtSetKeyboardFocus ( phoneForm, phoneText[0] );
			ADM_Phone_Input_Field = 0;
			break;

		case CLEAR_RECORD:
			for ( i = 0; i < NUM_INPUTTEXT; i++ )
				XtSetValues ( recordInputText[i], args, 1 );
			XtSetKeyboardFocus ( recordInput, recordInputText[0] );
			ADM_Record_Input_Field = 0;
			break;

	}

	DBGExit();

}


/*========================================================================
 *	Name:			ADMGetRecord
 *	Prototype:	ADMGetRecord
 *
 *	Description:
 *		retrieve data from the various windows
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *		Widget	recordInputText[]			text fields in record window
 *		Widget	phoneText[]					text fields in phone window
 *		Widget	emailText[]					text fields in email window
 *		Widget 	commentsScrolledWindow	comments text field
 *		char		*ADM_User_Data_String	global record string variable
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMGetRecord(
	Widget w,
	XtPointer client_data,
	XtPointer call_data
)
{

#ifdef DEBUG
	char		fname[]="ADMGetRecord()";
#endif

	Arg		args[1];
	int		length;
	char		*ptr;
	int		i;
	char		*string;


	DBGEnter();

	/*
	 * free up previously allocated storage, if any
	 */
	if ( ADM_User_Data_String != NULL )
	{
		DBGPrint(DBG_UTIL, "ADM_User_Data_String not null - cleaning up\n");
		free ( ADM_User_Data_String );
		ADM_User_Data_String = NULL;
	}

	length = 0;

	/* 
	 * find out how big a buffer we need
	 */

	/* record window */
	for ( i = 0; i < NUM_INPUTTEXT; i++ )
	{

		/* 
		 * get the length of the current field
		 */
		XtSetArg ( args[0], XtNstring, &string );
		XtGetValues ( recordInputText[i], args, 1 );

		/*
		 * add it to the current total
		 */
		length = length + strlen ( string ) + 1;
		
	}
	DBGPrintf(DBG_UTIL, ("length(record)= %d\n", length ) );

	/*
	 * add one for field delimeter
	 */
	length = length + 1;

	/* phone numbers */
	for ( i = 0; i < NUM_PHONETEXT; i++ )
	{
		/* 
		 * get the length of the current field
		 */
		XtSetArg ( args[0], XtNstring, &string );
		XtGetValues ( phoneText[i], args, 1 );

		/*
		 * add it to the current total, plus a delimeter
		 */
		length = length + strlen ( string ) + 1;

	}


	/* email addresses */
	for ( i = 0; i < NUM_EMAILTEXT; i++ )
	{
		/* 
		 * get the length of the current field
		 */
		XtSetArg ( args[0], XtNstring, &string );
		XtGetValues ( emailText[i], args, 1 );

		/*
		 * add it to the current total, plus a delimeter
		 */
		length = length + strlen ( string ) + 1;
	}

	/* comments */
	XtSetArg ( args[0], XtNstring, &string );
	XtGetValues ( commentsScrolledWindow, args, 1 );
	length = length + strlen ( string ) + 1;

	/* add space for the terminating null character */
	length++;
	
	/*
	 * allocate a buffer for this stuff; include space for terminator!
	 */
	ADM_User_Data_String = (char *) malloc ( length + 1 );
	bzero ( ADM_User_Data_String, length + 1 );

	/*
	 * build the string used to pass to the db routines
	 */

	/* record fields */
	for ( i = 0; i < NUM_INPUTTEXT; i++ )
	{

		XtSetArg ( args[0], XtNstring, &string );
		XtGetValues ( recordInputText[i], args, 1 );

		switch ( i )
		{
			case LNAMELABEL:
			case FNAMELABEL:
				ADMAddField ( string, ADM_User_Data_String, SUBFIELD );
				break;

			case MNAMELABEL:
			case ADDRESSLABEL:
			case ADDRESS2LABEL:
			case CITYLABEL:
			case STATELABEL:
			case ZIPCODELABEL:
			case COUNTYLABEL:
			case COUNTRYLABEL:
			case SECLEVELLABEL:
				ADMAddField ( string, ADM_User_Data_String, FIELD );
				break;
		}

	}

	/* email fields */
	for ( i = 0; i < NUM_EMAILTEXT; i++ )
	{

		XtSetArg ( args[0], XtNstring, &string );
		XtGetValues ( emailText[i], args, 1 );

		switch ( i )
		{
			case NUM_EMAILTEXT - 1:
				ADMAddField ( string, ADM_User_Data_String, FIELD );
				break;

			default:
				ADMAddField ( string, ADM_User_Data_String, SUBFIELD );
				break;
		}

	}

	/* phone fields */
	for ( i = 0; i < NUM_PHONETEXT; i++ )
	{

		XtSetArg ( args[0], XtNstring, &string );
		XtGetValues ( phoneText[i], args, 1 );

		switch ( i )
		{
			case NUM_PHONETEXT - 1:
				ADMAddField ( string, ADM_User_Data_String, FIELD );
				break;

			default:
				ADMAddField ( string, ADM_User_Data_String, SUBFIELD );
				break;
		}

	}

	XtSetArg ( args[0], XtNstring, &string );
	XtGetValues ( commentsScrolledWindow, args, 1 );

	/*
	 * Change all newlines to tildes before storing.  This is so there
	 * will only be one newline in the db record, but the user can put newlines
	 * in the text.  It will be converted back when displayed (tildes will
	 * be disallowed in the text).
	 */
	while ( (ptr = strchr ( string, '\n' )) != NULL )
		bcopy( "~", ptr, 1 );

	/*
	 * if the last character was a newline, change it back, otherwise
	 * add a newline to the string.
	 */
	length = strlen( string );
	if ( bcmp( "~", (char *)(string + length - 1), 1 ) != 0 )
		strcat( string, "\n" );
	else
		bcopy( "\n", (char *)(string + length - 1), 1 );

	/*
	 * now append it to the rest of the buffer
	 */
	strcat( ADM_User_Data_String, string );

	/*
	 * save the string to a global variable
	 */
	DBGPrintf( DBG_UTIL, ("record:\n%s\n", ADM_User_Data_String) );

	DBGExit();

}


/*========================================================================
 *	Name:			ADMPutRecord
 *	Prototype:	ADMPutRecord()
 *
 *	Description:
 *		put data into the record window
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *		Widget	recordInputText[]			text fields in record window
 *		Widget	phoneText[]					text fields in phone window
 *		Widget	emailText[]					text fields in email window
 *		Widget 	commentsScrolledWindow	comments text field
 *		char		*ADM_User_Data_String	global record string variable
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		Assumes the string ADM_User_Data_String exists.  I'm not sure I like
 *		how this works, but its acceptable for now... mjh
 *		
 *========================================================================*/
void
ADMPutRecord(
)
{

#ifdef DEBUG
	char		fname[]="ADMPutRecord()";
#endif

	Arg		args[1];
	int		i, rc;
	char		*field, *stringcopy, *ptr;
	char		errmsg[128];


	DBGEnter();

	/*
	 * grab a copy of the record to display
	 */
	stringcopy = (char *) malloc ( strlen ( ADM_User_Data_String + 1) );
	strcpy ( stringcopy, ADM_User_Data_String );

	/*
	 * Parse the string for the record input window
	 */
	for ( i = 0; i < NUM_INPUTTEXT; i++ )
	{
		switch ( i )
		{
			case LNAMELABEL:
			case FNAMELABEL:
				rc = DBParseBuf( stringcopy, &field, SUBFIELD, NULL );
				switch ( rc )
				{
					case DB_SUCCESS:
						/*
						 * The field was successfully parsed so we can
						 * use it for display purposes.
						 */
						break;

					case DB_EMPTY_FIELD:
						/*
						 * There was no data to put in this field, so
						 * put in an empty field.
						 */
						field = (char *) malloc ( 1 );
						bcopy ( "\0", field, 1 );
						break;
					
					default:
						DBGPrintf(DBG_UTIL, 
							("Can't parse record window fields from:\n%s\n",
								stringcopy) );
				
						/*
						 * pop up message dialog saying we hit a snag
						 */
						sprintf ( errmsg, 
							"Can't parse the record window fields"
							" from the database record" );
						ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );
				
						free ( stringcopy );
						DBGExit();
						return;
						break;
				}
				break;

			default:
				rc = DBParseBuf( stringcopy, &field, FIELD, NULL );
				switch ( rc )
				{
					case DB_SUCCESS:
						/*
						 * The field was successfully parsed so we can
						 * use it for display purposes.
						 */
						break;

					case DB_EMPTY_FIELD:
						/*
						 * There was no data to put in this field, so
						 * put in an empty field.
						 */
						field = (char *) malloc ( 1 );
						bcopy ( "\0", field, 1 );
						break;

					default:
						/*
						 * Problems - better tell the user
						 */
						DBGPrintf(DBG_UTIL, 
							("Can't parse record window fields from:\n%s\n", 
								stringcopy) );
			
						/*
						 * pop up message dialog saying we hit a snag
						 */
						sprintf ( errmsg, 
							"Can't parse the record window fields"
							" from the database record" );
						ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );
				
						free ( stringcopy );
						DBGExit();
						return;
						break;
				}
				break;
		}

		/*
		 * Output the value to its corresponding text window
		 */
		XtSetArg ( args[0], XtNstring, field );
		XtSetValues ( recordInputText[i], args, 1 );

		free ( field );

	}


	/*
	 * Parse the string for the email input window
	 */
	for ( i = 0; i < NUM_EMAILTEXT; i++ )
	{
		switch ( i )
		{
			case NUM_EMAILTEXT - 1:
				rc = DBParseBuf( stringcopy, &field, FIELD, NULL );
				switch ( rc )
				{
					case DB_SUCCESS:
						/*
						 * The field was successfully parsed so we can
						 * use it for display purposes.
						 */
						break;

					case DB_EMPTY_FIELD:
						/*
						 * There was no data to put in this field, so
						 * put in an empty field.
						 */
						field = (char *) malloc ( 1 );
						bcopy ( "\0", field, 1 );
						break;

					default:
						DBGPrintf(DBG_UTIL, 
							("Can't parse email subfield from:\n%s\n", stringcopy) );
				
						/*
						 * pop up message dialog saying we hit a snag
						 */
						sprintf ( errmsg, 
							"Can't parse the email fields from the database record" );
						ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );
				
						free ( stringcopy );
						DBGExit();
						return;
						break;
				}
				break;

			default:
				rc = DBParseBuf( stringcopy, &field, SUBFIELD, NULL );
				switch ( rc )
				{
					case DB_SUCCESS:
						/*
						 * The field was successfully parsed so we can
						 * use it for display purposes.
						 */
						break;

					case DB_EMPTY_FIELD:
						/*
						 * There was no data to put in this field, so
						 * put in an empty field.
						 */
						field = (char *) malloc ( 1 );
						bcopy ( "\0", field, 1 );
						break;

					default:
						DBGPrintf(DBG_UTIL, 
							("Can't parse email subfield from:\n%s\n", stringcopy) );
				
						/*
						 * pop up message dialog saying we hit a snag
						 */
						sprintf ( errmsg, 
							"Can't parse the email fields from the database record" );
						ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );
				
						free ( stringcopy );
						DBGExit();
						return;
						break;
				}
				break;

		}

		XtSetArg ( args[0], XtNstring, field );
		XtSetValues ( emailText[i], args, 1 );

		free ( field );

	}


	/*
	 * Parse the string for the phone input window
	 */
	for ( i = 0; i < NUM_PHONETEXT; i++ )
	{
		switch ( i )
		{
			case NUM_PHONETEXT - 1:
				rc = DBParseBuf( stringcopy, &field, FIELD, NULL );
				switch ( rc )
				{
					case DB_SUCCESS:
						/*
						 * The field was successfully parsed so we can
						 * use it for display purposes.
						 */
						break;

					case DB_EMPTY_FIELD:
						/*
						 * There was no data to put in this field, so
						 * put in an empty field.
						 */
						field = (char *) malloc ( 1 );
						bcopy ( "\0", field, 1 );
						break;

					default:
						DBGPrintf(DBG_UTIL, 
							("Can't parse phone subfield from:\n%s\n", stringcopy) );
				
						/*
						 * pop up message dialog saying we hit a snag
						 */
						sprintf ( errmsg, 
							"Can't parse the phone fields from the database record" );
						ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );
				
						free ( stringcopy );
						DBGExit();
						return;
						break;
				}
				break;

			default:
				rc = DBParseBuf( stringcopy, &field, SUBFIELD, NULL );
				switch ( rc )
				{
					case DB_SUCCESS:
						/*
						 * The field was successfully parsed so we can
						 * use it for display purposes.
						 */
						break;

					case DB_EMPTY_FIELD:
						/*
						 * There was no data to put in this field, so
						 * put in an empty field.
						 */
						field = (char *) malloc ( 1 );
						bcopy ( "\0", field, 1 );
						break;

					default:
						DBGPrintf(DBG_UTIL, 
							("Can't parse phone subfield from:\n%s\n", stringcopy) );
				
						/*
						 * pop up message dialog saying we hit a snag
						 */
						sprintf ( errmsg, 
							"Can't parse the phone fields from the database record" );
						ADMPopUpMsg( errmsg, ADM_ERROR_TYPE );
				
						free ( stringcopy );
						DBGExit();
						return;
						break;
				}
				break;
		}

		XtSetArg ( args[0], XtNstring, field );
		XtSetValues ( phoneText[i], args, 1 );

		free ( field );

	}

	/*
	 * Whatever is left in the string copy is the comments field
	 */

	/*
	 * convert any tildes back to newlines
	 */
	while ( (ptr = strchr ( stringcopy, '~' )) != NULL )
		bcopy( "\n", ptr, 1 );
	XtSetArg ( args[0], XtNstring, stringcopy );
	XtSetValues ( commentsScrolledWindow, args, 1 );
	free ( stringcopy );
	
	DBGExit();

}

#endif /* XUTIL_C */
