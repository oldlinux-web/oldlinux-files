/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: recordwindow.c
 *            DESCRIPTION: manage the records window
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMCreateRecord
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef CREATERECORD_C
#define CREATERECORD_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/Viewport.h>
#include <stdio.h>

/* === Project Headers === */
#include "411admin.h"
#include "display.h"
#include "textstrings.h"
#include "debug.h"

/* === external routines === */
extern void ADMCreatePhone();
extern void ADMCreateEmail();
extern void ADMCreateComments();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
extern Widget		mainForm;				/* parent for all record widgets */
extern Widget		ADM_Main_Window;		/* visible main window */
extern Dimension	mainFormHeight;		/* height of main form */
extern Dimension	mainFormWidth;			/* width of main form */
extern int 			ADM_Record_Input_Field;
													/* current text field w/focus applied */

Widget recordInput; 							/* main form for record input */
Widget recordInputTitle;					/* title bar of window */
Widget recordViewPort; 						/* main window for record input */
Widget recordInputText[NUM_INPUTTEXT];	/* input widgets */
Widget recordInputLabels[NUM_INPUTLABELS];	
													/* label widgets for prompts */

Dimension recordViewPortHeight;			/* height of record view port */

/* === Static Variables === */
char *InputLabels[] = {
	"Last Name:",
	"First Name:",
	"Middle Name:",
	"Address:",
	"",
	"City:",
	"State:",
	"Zipcode:",
	"County:",
	"Country:",
	"Security Level:"
	};

/*========================================================================
 *	Name:			ADMCreateRecord
 *	Prototype:	ADMCreateRecord()
 *					
 *
 *	Description:
 *		Create the record window
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
ADMCreateRecord()
{

#ifdef DEBUG
	char			fname[]="ADMCreateRecord()";
#endif

	char			buf[64];
	Dimension	width, height, theight;
	int			i, nargs;
	Arg			args[20];

	/* the input fields and labels */
	Widget recordViewPortForm; 			/* main form for record input */
	Widget recordInputLForm;				/* prompt fields form */
	Widget recordInputTForm;				/* input fields form */


	DBGEnter();

	/* THE RECORD INPUT WINDOW */

	DBGPrint(DBG_WINDOWS, "main window, title bar\n");

	/*
	 * the main window in which all the input and label fields go
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, mainFormHeight ); nargs++;
	XtSetArg ( args[nargs], XtNwidth, mainFormWidth ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 1 ); nargs++;
	recordInput = XtCreateWidget (
			"Records",					/* name */
			formWidgetClass,			/* class */
			mainForm,					/* parent */
			args, nargs					/* arg list */
			);


	/*
	 * a title bar for this window
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, mainFormWidth ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNlabel, RECORD_INPUT_TITLE ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 1 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	recordInputTitle = XtCreateManagedWidget ( 
			"recordInputTitle",		/* widget name */
			labelWidgetClass,			/* class */
			recordInput,				/* parent widget*/ 
			args,	nargs					/* arg list */
			);


	/*
	 * a viewport for the label and text fields, in case the user resizes
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &height ); nargs++;
	XtGetValues ( recordInputTitle, args, nargs );
	recordViewPortHeight = mainFormHeight - height;
	DBGPrintf(DBG_WINDOWS, ("view port height and width\n\theight:%d\twidth:%d\n",
				recordViewPortHeight, mainFormWidth));

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, mainFormWidth ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, recordInputTitle ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 1 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNuseBottom, True ); nargs++;
	XtSetArg ( args[nargs], XtNallowHoriz, True ); nargs++;
	XtSetArg ( args[nargs], XtNallowVert, True ); nargs++;
	recordViewPort = XtCreateManagedWidget (
			"recordViewPort",			/* name */
			viewportWidgetClass,		/* class */
			recordInput,				/* parent */
			args, nargs					/* arg list */
			);

	/*
	 * a form which is the child managed by the view port.  We'll put
	 * all the labels and text fields in here for constraint purposes
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, mainFormWidth ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	recordViewPortForm = XtCreateManagedWidget (
			"recordViewPortForm",	/* name */
			formWidgetClass,			/* class */
			recordViewPort,			/* parent */
			args, nargs					/* arg list */
			);


	/*
	 * Create a seperate form for the Labels.  This goes on the left
	 * side of the window when viewed.
	 */
	DBGPrint(DBG_WINDOWS, "form for labels\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &theight ); nargs++;
	XtGetValues ( recordInputTitle, args, nargs );
	height = height - theight;

	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, height ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	recordInputLForm = XtCreateManagedWidget(
			"recordInputLForm",		/* name */
			formWidgetClass,			/* class */
			recordViewPortForm,		/* parent */
			args,	nargs					/* arg list */
			);

	/*
	 * the label fields - just text explaining what goes in the text fields
	 */
	DBGPrint(DBG_WINDOWS, "label fields\n");
	for ( i = 0; i < NUM_INPUTLABELS; i++ )
	{
		nargs = 0;
		(void)sprintf ( buf, "recordInputLabels%d", i );
		XtSetArg ( args[nargs], XtNlabel, InputLabels[i] ); nargs++;
		XtSetArg ( args[nargs], XtNjustify, XtJustifyRight ); nargs++;
		XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
		XtSetArg ( args[nargs], XtNright, XtChainLeft ); nargs++;
		XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
		XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
		XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
		XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
		XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
		XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
		recordInputLabels[i] = XtCreateWidget(
			buf,							/* widget name */
			labelWidgetClass,			/* class */
			recordInputLForm,			/* parent widget*/
			args,	nargs					/* arg list */
			);
	}

	/*
	 * add one more arg - this is cleaner that trying to do it
	 * in the last loop
	 */
	for ( i = 1; i < NUM_INPUTLABELS; i++ )
	{
		XtSetArg ( args[0], XtNfromVert, recordInputLabels[i-1] );
		XtSetValues ( recordInputLabels[i], args, 1 );
	}

	XtManageChildren ( recordInputLabels, NUM_INPUTLABELS );


	/*
	 * create a seperate form for the Text input fields 
	 */
	DBGPrint(DBG_WINDOWS, "input fields\n");

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues ( recordInputLabels[0], args, 1 );
	width = mainFormWidth - width;
	
	DBGPrintf(DBG_WINDOWS, ("text form height width\n\twidth:%d\n", width));

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, width ); nargs++;
	XtSetArg ( args[nargs], XtNheight, mainFormHeight ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, recordInputLForm ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	recordInputTForm = XtCreateManagedWidget(
			"recordInputTForm",		/* name */
			formWidgetClass,			/* class */
			recordViewPortForm,		/* parent */
			args,	nargs					/* arg list */
			);

	/*
	 * the input fields - here is where the user actually types data
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, width ); nargs++;
	XtSetArg ( args[nargs], XtNeditType, XawtextEdit ); nargs++;
	XtSetArg ( args[nargs], XtNrightMargin, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNleftMargin, 0 ); nargs++;
/*
	XtSetArg ( args[nargs], XtNtopMargin, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNbottomMargin, 0 ); nargs++;
*/
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNstring, "" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 1 ); nargs++;
	XtSetArg ( args[nargs], XtNdisplayCaret, False ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNscrollHorizontal, XawtextScrollNever );
		nargs++;


	for ( i = 0; i < NUM_INPUTTEXT; i++ )
	{
		(void)sprintf ( buf, "recordInputText%d", i );
		recordInputText[i] = XtCreateWidget(
			buf,   						/* name */
			asciiTextWidgetClass,	/* class */
			recordInputTForm, 		/* parent */
			args,	nargs					/* arg list */
			);
	}
	DBGPrint(DBG_WINDOWS, "resetting text fromHoriz resource\n");
	for ( i = 1; i < NUM_INPUTTEXT; i++ )
	{
		XtSetArg ( args[0], XtNfromVert, recordInputText[i-1] );
		XtSetValues ( recordInputText[i], args, 1 );
	}

	/*
	 * Which window will get keyboard focus to start
	 * This is an index value into the recordInputText[] array.
	 */
	ADM_Record_Input_Field = 0;


	XtManageChildren ( recordInputText, NUM_INPUTTEXT );


	/*
	 * create the phone, email and comments pop ups - we do that here 
	 * since these windows are tied directly to record input/output
	 */
	ADMCreatePhone();
	ADMCreateEmail();
	ADMCreateComments();

	DBGExit();

}


/*========================================================================
 *	Name:			ADMSetRecordTitle
 *	Prototype:	ADMSetRecordTitle()
 *					
 *
 *	Description:
 *		Set the title bar in the record window based on which function
 *		is being started.  This is a callback that each function should
 *		call.  Functions are Add, Update, View, and Delete (as defined by
 *		the "Database" pull down menu).
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
ADMSetRecordTitle(
	Widget		w,
	XtPointer	client_data,
	XtPointer	call_data
)
{

#ifdef DEBUG
	char		fname[]="ADMSetRecordTitle()";
#endif

	Arg		args[5];
	int		nargs;


	DBGEnter();

	nargs = 0;

	/*
	 * set the title based on what function we're doing
	 */
	switch ( (int) client_data )
	{
		case ADM_ADD_FUNCTION:
			XtSetArg ( args[nargs], XtNlabel, RECORD_INPUT_TITLE_ADD ); nargs++;
			break;

		case ADM_VIEW_FUNCTION:
			XtSetArg ( args[nargs], XtNlabel, RECORD_INPUT_TITLE_VIEW ); nargs++;
			break;

		case ADM_UPD_FUNCTION:
			XtSetArg ( args[nargs], XtNlabel, RECORD_INPUT_TITLE_UPD ); nargs++;
			break;

		case ADM_DEL_FUNCTION:
			XtSetArg ( args[nargs], XtNlabel, RECORD_INPUT_TITLE_DEL ); nargs++;
			break;

		case ADM_SEL_FUNCTION:
			XtSetArg ( args[nargs], XtNlabel, RECORD_INPUT_TITLE_SEL ); nargs++;
			break;

		case ADM_REBUILD_NOTICE:
			XtSetArg ( args[nargs], XtNlabel, RECOMMEND_REBUILD ); nargs++;
			break;
	}
	XtSetArg ( args[nargs], XtNwidth, mainFormWidth ); nargs++;
	XtSetValues( recordInputTitle, args, nargs );

	DBGExit();
}

#endif /* CREATERECORD_C */
