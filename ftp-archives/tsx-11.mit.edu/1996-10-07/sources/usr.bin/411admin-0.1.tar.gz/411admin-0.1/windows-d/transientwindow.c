/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: transientwindow.c
 *            DESCRIPTION: routines dealing with transient windows
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMCreateTransient()
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef TRANSIENT_C
#define TRANSIENT_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Dialog.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/SmeLine.h>
#include <X11/Xaw/SmeBSB.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Viewport.h>
#include <stdio.h>

/* === Project Headers === */
#include "411admin.h"
#include "display.h"
#include "help.h"
#include "textstrings.h"
#include "debug.h"

/* === external routines === */
extern void ADMPopDownWindow();
extern void ADMPopUpHelp();

/* === Public routine prototypes === */

/* === Private routine prototypes === */
int	ADMAddHelp();

/* === Global Variables === */
extern Dimension	mainFormWidth;				/* width of main form */
extern Widget		ADM_Top_Level;				/* parent of all widgets */
extern AppData		ADM_App_Data;				/* application resource data */

Widget transientAppShell; 		/* top level shell for transients */
Widget helpShell;					/* pop up window for help messages */
Widget helpText;					/* window where help message is put */
Widget helpFileMenu;				/* pop down menu for help window */
Widget helpFileMenuButton[NUM_HELPBUTTONS];
										/* buttons to add for jumping around
										 * in the help facility
										 */
Widget phoneShell;				/* pop up window for phone numbers */
Widget emailShell;				/* pop up window for email addresses */
Widget commentsShell;			/* pop up window for comments */


Widget statsBox;					/* pop up window for rebuild message */


/* === Static Variables === */
static char *help_file_menu[] = {	/* items in the Options pull down menu */
	"Close"
	};

static Help_Count;				/* number of help entries in pull-down menu */


/*========================================================================
 *	Name:			ADMCreateTransient
 *	Prototype:	ADMCreateTransient()
 *
 *	Description:
 *		create all windows that get popped up and down
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *		none.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
ADMCreateTransient()
{

#ifdef DEBUG
	char 			fname[]="ADMCreateTransient()";
#endif

	Arg			args[20];
	int			nargs;
	int			i;
	Dimension	width, height;
	char			buf[32];

	Widget		helpTitle;
	Widget		help_menubox, helpFileButton;
	Widget		helpFileLine;
	Widget		helpBox, help_spacer;

	DBGEnter();

	/*
	 * Create a new application shell for all transients
	 */
	transientAppShell = XtAppCreateShell (
			"Transients",						/* name */
			"transientAppShell",				/* app class */
			applicationShellWidgetClass,	/* widget class */
			XtDisplay (ADM_Top_Level),		/* display */
			NULL, 0								/* args */
			);


	/*
	 * create windows that are transient - they get popped up and down
	 * due to actions by the user
	 */


	/*
	 * create popup that will contain help
	 */
	helpShell = XtCreatePopupShell (
		"Help",								/* widget name */
		transientShellWidgetClass,		/* class */
		transientAppShell,				/* parent */
		NULL,	0								/* arg list */
		);

	/*
	 * create form for help windows
	 */
	nargs=0;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	helpBox = XtCreateManagedWidget (
		"helpBox",						/* widget name */
		formWidgetClass,				/* class */
		helpShell,						/* parent widget */
		args, nargs						/* arg list */
		);


	/*
	 * CREATE A BOX FOR THE MENU BUTTONS
	 */
	DBGPrint(DBG_WINDOWS,"creating menu box\n");

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, DEFAULT_HELP_WIDTH ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNorientation, XtorientHorizontal ); nargs++;
	XtSetArg ( args[nargs], XtNvSpace, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhSpace, 0 ); nargs++;
	help_menubox = XtCreateManagedWidget (
		"MenuBox",
		boxWidgetClass,
		helpBox,
		args, nargs
		);

	/*
	 * CREATE FILE MENU AND CHILDREN
	 */

	DBGPrint(DBG_WINDOWS,"creating file menu\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Options" ); nargs++;
	XtSetArg ( args[nargs], XtNmenuName, "helpFileMenu" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	helpFileButton = XtCreateManagedWidget(
		"helpFileButton",			/* widget name */
		menuButtonWidgetClass,	/* widget class */
		help_menubox,				/* parent */
		args, nargs					/* argument list */
		);

	/*
	 * create pop down menu
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Help Options" ); nargs++;
	helpFileMenu = XtCreatePopupShell(
		"helpFileMenu",			/* name */
		simpleMenuWidgetClass,	/* class */
		transientAppShell,		/* parent */
		args, nargs					/* no argument list needed */
		);

	/*
	 * a line seperator in the menu
	 */
	helpFileLine = XtCreateManagedWidget(
		"helpFileMenuLine",		/* name */
		smeLineObjectClass,		/* class */
		helpFileMenu,				/* parent */
		NULL, 0						/* no argument list needed */
		);

	/*
	 * set the menu items in the pull-down menu
	 */
	for ( i = 0; i < NUM_HELPMENU; i++ )
	{
		if ( i == NUM_HELPMENU -1 )
			(void) sprintf ( buf, "helpClose" );
		else
			(void) sprintf ( buf, "helpMenu%d", i );

		nargs = 0;
		XtSetArg ( args[nargs], XtNlabel, help_file_menu[i] ); nargs++;

		helpFileMenuButton[i] = XtCreateManagedWidget(
			buf,						/* widget name */
			smeBSBObjectClass,	/* widget class */
			helpFileMenu,			/* parent widget*/
			args, nargs				/* argument list */
			);

		/* set the callbacks */
		switch ( i )
		{
			case HPCLOSEOPTION:
				XtAddCallback( helpFileMenuButton[i], 
					XtNcallback, ADMPopDownWindow, helpShell );
				break;

			default:
				break;
		}
	}
	Help_Count = NUM_HELPMENU-1;

	/*
	 * CREATE A SPACER BETWEEN THE MENU BUTTONS AND THE HELP BUTTON
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &height ); nargs++;
	XtGetValues( helpFileButton, args, nargs );

	DBGPrint(DBG_WINDOWS,"creating menu spacer\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "" ); nargs++;
	XtSetArg ( args[nargs], XtNheight, height ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, help_menubox ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNresizable, True ); nargs++;
	help_spacer = XtCreateManagedWidget(
		"menuSpacer",
		labelWidgetClass,
		helpBox,
		args, nargs
		);

	/*
	 * add a help title bar
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, HELP_TITLE ); nargs++;
	XtSetArg ( args[nargs], XtNwidth, DEFAULT_HELP_WIDTH ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNjustify, XtJustifyCenter ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, help_menubox ); nargs++;
	helpTitle = XtCreateManagedWidget (
		"helpTitle",					/* widget name */
		labelWidgetClass,				/* class */
		helpBox,							/* parent widget */
		args,	nargs						/* arg list */
		);

	/*
	 * add a text window
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues ( helpTitle, args, nargs );

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, width ); nargs++;
	XtSetArg ( args[nargs], XtNheight, DEFAULT_HELP_HEIGHT ); nargs++;
	XtSetArg ( args[nargs], XtNeditType, XawtextAppend ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, helpTitle ); nargs++;
	XtSetArg ( args[nargs], XtNwrap, XawtextWrapWord ); nargs++;
	XtSetArg ( args[nargs], XtNscrollVertical, XawtextScrollAlways ); nargs++;
	helpText = XtCreateManagedWidget (
			"helpText",					/* name */
			asciiTextWidgetClass,	/* class */
			helpBox,						/* parent */
			args, nargs					/* arg list */
			);

	ADMAddHelp( ADM_HELP_FILE, MAIN_HELP_FILE, ADM_HELP_MAIN_LABEL );



	/*
	 * create popup that will contain phone numbers
	 */
	phoneShell = XtCreatePopupShell (
		"Phones",							/* widget name */
		transientShellWidgetClass,		/* class */
		transientAppShell,				/* parent */
		NULL,	0								/* arg list */
		);

	/*
	 * create popup that will contain email addresses
	 */
	emailShell = XtCreatePopupShell (
		"Email",								/* widget name */
		transientShellWidgetClass,		/* class */
		transientAppShell,				/* parent */
		NULL,	0								/* arg list */
		);

	/*
	 * create popup that will contain comments
	 */
	commentsShell = XtCreatePopupShell (
		"Comments",								/* widget name */
		transientShellWidgetClass,		/* class */
		transientAppShell,				/* parent */
		NULL,	0								/* arg list */
		);

	DBGExit();

}


/*========================================================================
 *	Name:			ADMAddHelp
 *	Prototype:	int ADMAddHelp( int type, char *string, char *label )
 *
 *	Description:
 *		add help text to the help text window
 *
 *	Input Arguments:
 *		int	type				ADM_HELP_STRING or ADM_HELP_FILE
 *		char	*string			either a text string or a filename
 *		char	*label			label to use in pull down menu
 *
 *	Output Arguments:
 *	Return Values:
 *		offset into helpText widget source where this part of the help
 *		text can be found.
 *
 *		none.
 *
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

int
ADMAddHelp(
	int	type,
	char	*string,
	char	*label
)
{

	char				fname[]="ADMAddHelp()";

	Arg				args[3];
	int				nargs;

	FILE				*fd;
	char				filename[256];
	char				buf[MAX_HELP_LINE_LENGTH+1];
	int				startpos, pos;
	char				*textstring;
	XawTextBlock	text_block;

	/*
	 * Help text is set on initialization; die and fix it!
	 */
	if ( string == NULL )
	{
		printf ("%s: string to add to help text is NULL!\n", fname);
		exit(0);
	}


	switch ( type )
	{
		case ADM_HELP_STRING:

			nargs=0;
			XtSetArg ( args[nargs], XtNstring, &textstring ); nargs++;
			XtGetValues ( helpText, args, nargs );
			startpos = strlen(textstring);
			DBGPrintf(DBG_WINDOWS,
				("length of current help text: %d\n", startpos));

			text_block.firstPos = 0;
			text_block.length = strlen(string);
			text_block.ptr = string;
			text_block.format = FMT8BIT;
			if ( XawTextReplace( helpText, (long)startpos, 
						(long)startpos, &text_block) != XawEditDone )
			{
				/*
				 * Help text is set on initialization; die and fix it!
				 */
				printf ("%s: Can't append help message to help text\n", fname);
				exit(0);
			}

			return ( startpos );
			break;


		case ADM_HELP_FILE:
			/*
			 * Read the help text from the file specified by the string
			 */

			/*
			 * save the current location in the help text for the caller
			 */
			nargs=0;
			XtSetArg ( args[nargs], XtNstring, &textstring ); nargs++;
			XtGetValues ( helpText, args, nargs );
			startpos = strlen(textstring);

			/*
			 * Build the full path name
			 */
			sprintf ( filename, "%s/%s", ADM_App_Data.help_dir, string );

			/*
			 * Open the text file
			 */
			if ( (fd = fopen ( filename, "r" ) ) == NULL )
			{
				DBGPrintf(DBG_WINDOWS,
					("can't open %s\n", filename));

				sprintf( buf, "Can't open %s\n", filename );

				nargs=0;
				XtSetArg ( args[nargs], XtNstring, &textstring ); nargs++;
				XtGetValues ( helpText, args, nargs );
				pos = strlen(textstring);
				DBGPrintf(DBG_WINDOWS,
					("length of current help text: %d\n", pos));

				text_block.firstPos = 0;
				text_block.length = strlen(buf);
				text_block.ptr = buf;
				text_block.format = FMT8BIT;
				if ( XawTextReplace( helpText, (long)pos, 
						(long)pos, &text_block) != XawEditDone )
				{
					/*
					 * Help text is set on initialization; die and fix it!
					 */
					printf ("%s: Can't append help message to help text\n",
								fname);
					exit(0);
				}
			}

			/*
			 * Read in each line and add it to the help text
			 */
			while ( fgets( buf, MAX_HELP_LINE_LENGTH, fd ) != NULL )
			{
				nargs=0;
				XtSetArg ( args[nargs], XtNstring, &textstring ); nargs++;
				XtGetValues ( helpText, args, nargs );
				pos = strlen(textstring);
				DBGPrintf(DBG_WINDOWS,
					("length of current help text: %d\n", pos));

				text_block.firstPos = 0;
				text_block.length = strlen(buf);
				text_block.ptr = buf;
				text_block.format = FMT8BIT;
				if ( XawTextReplace( helpText, (long)pos, 
						(long)pos, &text_block) != XawEditDone )
				{
					/*
					 * Help text is set on initialization; die and fix it!
					 */
					printf ("%s: Can't append help message to help text\n",
								fname);
					exit(0);
				}
			}

			/*
			 * close the text file
			 */
			fclose ( fd );

			/*
			 * Add the button to the help menu
			 */
			if ( label == NULL )
			{
				printf ("%s: label to add to help text is NULL!\n", fname);
				exit(0);
			}

			nargs = 0;
			XtSetArg ( args[nargs], XtNlabel, label ); nargs++;

			helpFileMenuButton[++Help_Count] = XtCreateManagedWidget(
				buf,						/* widget name */
				smeBSBObjectClass,	/* widget class */
				helpFileMenu,			/* parent widget*/
				args, nargs				/* argument list */
				);

			XtAddCallback( helpFileMenuButton[Help_Count], 
					XtNcallback, ADMPopUpHelp, (XtPointer)startpos );

			/*
			 * return the starting position in the help text for the caller
			 */
			return ( startpos );
			break;

		default:
			return ( 0 );
			break;

	}

}

#endif /* TRANSIENT_C */
