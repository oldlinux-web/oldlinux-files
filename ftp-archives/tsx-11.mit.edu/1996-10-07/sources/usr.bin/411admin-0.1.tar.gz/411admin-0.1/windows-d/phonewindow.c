/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: phonewindow.c
 *            DESCRIPTION: builds pop up for handling phone numbers
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: ADMCreatePhone
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef PHONE_C
#define PHONE_C

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/SmeLine.h>
#include <X11/Xaw/SmeBSB.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Text.h>
#include <X11/Xaw/Viewport.h>
#include <stdio.h>


/* === Project Headers === */
#include "411admin.h"
#include "display.h"
#include "help.h"
#include "textstrings.h"
#include "debug.h"

/* === external routines === */
extern void ADMPopDownWindow();
extern void ADMPopUpHelp();
extern void ADMSetSensitive();
extern void ADMClearWindow();
extern int	ADMAddHelp();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
extern Widget	transientAppShell;	/* text for help window */
extern Widget	phoneShell;				/* pop up shell for phone numbers */
extern Widget	optionMenuButton[NUM_OPTIONMENU];
											/* buttons in pop-down menu from
											 * Options button on Menu Bar
											 */
extern int 		ADM_Phone_Input_Field;

Widget phoneText[NUM_PHONETEXT];		/* input fields for phone window */
Widget phoneForm;							/* top level of phone window */

/* === Static Variables === */
char *phone_file_menu[] = {	/* items in the Options pull down menu */
	"Clear",
	"Close"
	};

char *phone_list_init[] = {			/* initial empty list of phone numbers */
	"",
	"",
	"",
	"",
	"",
	NULL
	};


/*========================================================================
 *	Name:			ADMCreatePhone
 *	Prototype:	ADMCreatePhone()
 *
 *	Description:
 *		Creates pop up window for phone numbers
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
ADMCreatePhone()
{
	char				fname[]="ADMCreatePhone()";
	char				buf[64];
	Arg				args[20];
	int				nargs;
	int				i;
	Dimension		width, twidth, height;
	int				startpos;

	Widget		phone_menubox;
	Widget		phoneFileButton, phoneFileMenu, phoneFileLine;
	Widget 		phoneFileMenuButton[NUM_PHONEMENU];
	Widget		phone_spacer;
	Widget		phoneTitle;
	Widget		phoneHelpButtonBox, phoneGetHelp;
	Widget		phoneScrolledWindow, phoneTextForm;

	char			phoneHelpFile[]=PHONE_HELP_FILE;

	DBGEnter();

	/*
	 * the main sub window for the phone numbers
	 */
	DBGPrint(DBG_WINDOWS, "phone form\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	phoneForm = XtCreateManagedWidget (
			"phoneForm",			/* name */
			formWidgetClass,		/* class */
			phoneShell,				/* parent */
			args,	nargs				/* arg list */
			);

	/*
	 * CREATE A BOX FOR THE MENU BUTTONS
	 */
	DBGPrint(DBG_WINDOWS,"creating menu box\n");

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, DEFAULT_PHONE_WIDTH ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNorientation, XtorientHorizontal ); nargs++;
	XtSetArg ( args[nargs], XtNvSpace, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhSpace, 0 ); nargs++;
	phone_menubox = XtCreateManagedWidget (
		"MenuBox",
		boxWidgetClass,
		phoneForm,
		args, nargs
		);

	/*
	 * CREATE FILE MENU AND CHILDREN
	 */

	DBGPrint(DBG_WINDOWS,"creating file menu\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Options" ); nargs++;
	XtSetArg ( args[nargs], XtNmenuName, "phoneFileMenu" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	phoneFileButton = XtCreateManagedWidget(
		"phoneFileButton",		/* widget name */
		menuButtonWidgetClass,	/* widget class */
		phone_menubox,				/* parent */
		args, nargs					/* argument list */
		);

	/*
	 * create menu popped down by statFileButton
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Phone Options" ); nargs++;
	phoneFileMenu = XtCreatePopupShell(
		"phoneFileMenu",			/* name */
		simpleMenuWidgetClass,	/* class */
		transientAppShell,		/* parent */
		args, nargs					/* no argument list needed */
		);

	/*
	 * a line seperator in the menu
	 */
	phoneFileLine = XtCreateManagedWidget(
		"phoneFileMenuLine",		/* name */
		smeLineObjectClass,		/* class */
		phoneFileMenu,				/* parent */
		NULL, 0						/* no argument list needed */
		);

	/*
	 * set the menu items in the pull-down menu
	 */
	for ( i = 0; i < NUM_PHONEMENU; i++ )
	{
		if ( i == NUM_PHONEMENU -1 )
			(void) sprintf ( buf, "phoneClose" );
		else
			(void) sprintf ( buf, "phoneMenu%d", i );

		nargs = 0;
		XtSetArg ( args[nargs], XtNlabel, phone_file_menu[i] ); nargs++;

		phoneFileMenuButton[i] = XtCreateManagedWidget(
			buf,						/* widget name */
			smeBSBObjectClass,	/* widget class */
			phoneFileMenu,			/* parent widget*/
			args, nargs				/* argument list */
			);

		/* set the callbacks */
		switch ( i )
		{
			case PMCLEAROPTION:
				XtAddCallback ( phoneFileMenuButton[i], XtNcallback,
						ADMClearWindow, (XtPointer) CLEAR_PHONE );
				break;

			case PMCLOSEOPTION:
				XtAddCallback( phoneFileMenuButton[i], 
					XtNcallback, ADMPopDownWindow, phoneShell );
				XtAddCallback( phoneFileMenuButton[i], 
					XtNcallback, ADMSetSensitive, optionMenuButton[PHONEOPTION]);
				break;

			default:
				break;
		}
	}

	/*
	 * CREATE A SPACER BETWEEN THE MENU BUTTONS AND THE HELP BUTTON
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNheight, &height ); nargs++;
	XtGetValues( phoneFileButton, args, nargs );

	DBGPrint(DBG_WINDOWS,"creating menu spacer\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "" ); nargs++;
	XtSetArg ( args[nargs], XtNheight, height ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, phone_menubox ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNresizable, True ); nargs++;
	phone_spacer = XtCreateManagedWidget(
		"menuSpacer",
		labelWidgetClass,
		phoneForm,
		args, nargs
		);

	/*
	 * create a box for the help button
	 */
	DBGPrint(DBG_WINDOWS,"creating help box\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNfromHoriz, phone_spacer ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNorientation, XtorientHorizontal ); nargs++;
	XtSetArg ( args[nargs], XtNvSpace, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhSpace, 0 ); nargs++;
	phoneHelpButtonBox = XtCreateManagedWidget(
		"helpButtonBox",			/* name */
		boxWidgetClass,			/* class */
		phoneForm,					/* parent */
		args, nargs					/* arg list */
		);


	/*
	 * create button that will pop up the help window
	 */
	DBGPrint(DBG_WINDOWS,"creating help windows\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNlabel, "Help" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	phoneGetHelp = XtCreateManagedWidget(
		"getHelp",					/* name */
		commandWidgetClass,		/* class */
		phoneHelpButtonBox,		/* parent */
		args, nargs					/* arg list */
		);


	/*
	 * add the help text to the help box
	 */
	startpos = ADMAddHelp ( ADM_HELP_FILE, phoneHelpFile, 
						ADM_HELP_PHONE_LABEL);

	/*
	 * tell help button to pop up the help window and position the cursor
	 */
	DBGPrintf(DBG_WINDOWS,("start position for stat help text: %d\n", startpos));
   XtAddCallback ( phoneGetHelp, XtNcallback, 
			(XtCallbackProc)ADMPopUpHelp, (XtPointer)startpos );


	/*
	 * the Title for the phone number scrolled window
	 */
	DBGPrint(DBG_WINDOWS, "phone title bar\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, DEFAULT_PHONE_WIDTH ); nargs++;
	XtSetArg ( args[nargs], XtNlabel, "Phone Numbers" ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNjustify, XtJustifyCenter ); nargs++;
	XtSetArg ( args[nargs], XtNfromVert, phone_menubox ); nargs++;
	phoneTitle = XtCreateManagedWidget (
			"phoneTitle",			/* name */
			labelWidgetClass,		/* class */
			phoneForm,				/* parent */
			args,	nargs				/* arg list */
			);

	/* readjust the width of the spacer */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &twidth ); nargs++;
	XtGetValues( phoneFileButton, args, nargs );
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( phoneGetHelp, args, nargs );
	twidth += width;
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues( phoneTitle, args, nargs );
	twidth = width - twidth + 2;
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, twidth ); nargs++;
	XtSetValues( phone_spacer, args, nargs );



	/*
	 * the window that manages scrolling
	 */
	DBGPrint(DBG_WINDOWS, "phone viewport\n");
	nargs = 0;
	XtSetArg ( args[nargs], XtNfromVert, phoneTitle ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNallowHoriz, True ); nargs++;
	XtSetArg ( args[nargs], XtNallowVert, True ); nargs++;
	XtSetArg ( args[nargs], XtNuseBottom, True ); nargs++;
	phoneScrolledWindow = XtCreateManagedWidget (
			"phoneScrolledWindow",	/* name */
			viewportWidgetClass,		/* class */
			phoneForm,					/* parent */
			args,	nargs					/* arg list */
			);

	/*
	 * create the list window which gets scrolled
	 */

	DBGPrint(DBG_WINDOWS, "phone list\n");

	nargs = 0;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	phoneTextForm = XtCreateManagedWidget(
			"phoneTextForm",			/* name */
			formWidgetClass,			/* class */
			phoneScrolledWindow,		/* parent */
			args,	nargs					/* arg list */
			);

	/*
	 * the input fields - here is where the user actually types data
	 */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, DEFAULT_PHONE_WIDTH ); nargs++;
	XtSetArg ( args[nargs], XtNeditType, XawtextEdit ); nargs++;
	XtSetArg ( args[nargs], XtNtopMargin, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNrightMargin, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNleftMargin, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNbottomMargin, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNstring, "" ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 1 ); nargs++;
	XtSetArg ( args[nargs], XtNdisplayCaret, False ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNscrollHorizontal, XawtextScrollNever );
		nargs++;
	XtSetArg ( args[nargs], XtNscrollVertical, XawtextScrollNever );
		nargs++;


	for ( i = 0; i < NUM_PHONETEXT; i++ )
	{
		(void)sprintf ( buf, "phoneText%d", i );
		phoneText[i] = XtCreateWidget(
			buf,   						/* name */
			asciiTextWidgetClass,	/* class */
			phoneTextForm, 			/* parent */
			args,	nargs					/* arg list */
			);
	}
	/*
	 * adjust the text fields to be verticallly arranged
	 */
	for ( i = 1; i < NUM_PHONETEXT; i++ )
	{
		nargs=0;
		XtSetArg ( args[nargs], XtNfromVert, phoneText[i-1] ); nargs++;
		XtSetValues ( phoneText[i], args, nargs );
	}


	XtManageChildren ( phoneText, NUM_PHONETEXT );

	/*
	 * Which window will get keyboard focus to start
	 * This is an index value into the phoneText[] array.
	 */
	ADM_Phone_Input_Field = 0;


	DBGExit();

}

#endif /* PHONE_C */
