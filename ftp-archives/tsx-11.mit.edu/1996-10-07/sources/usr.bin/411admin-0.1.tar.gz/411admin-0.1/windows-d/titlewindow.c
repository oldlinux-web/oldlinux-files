/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: titlewindow.c
 *            DESCRIPTION: manage the title windows
 *      DEFINED CONSTANTS: 411admin.h
 *       TYPE DEFINITIONS: 411admin.h
 *      MACRO DEFINITIONS: 411admin.h
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: 411CreateTitle
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: set tabstops=3 for readibility
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/ADM, no underscores, mixed case	ADMPublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/ADM, underscores, mixed case		ADM_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		underscores and all caps							DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef TITLE_C 
#define TITLE_C 

/* === System Headers === */
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Label.h>
#include <stdio.h>
#include <math.h>

/* === Project Headers === */
#include "411admin.h"
#include "textstrings.h"
#include "debug.h"
#include "titlexbm.h"

/* === Global Variables === */
extern Widget	ADM_Top_Level;				/* mother of all widgets */
extern Widget	ADM_Main_Window;			/* visible main window */
extern Widget	ADM_Current_Window;		/* which widget in main window is
													 * currently being managed
													 */

/* === Project Headers === */
/* === external routines === */
/* === Public routine prototypes === */
/* === Private routine prototypes === */

/* === Global Variables === */
extern Widget	mainForm;	/* all widgets in the Title are children of
									 * mainForm
									 */
Widget titleWindow;			/* widget by which this window is accessed */



/*========================================================================
 *	Name:			ADMCreateTitle
 *	Prototype:	ADMCreateTitle()
 *					
 *
 *	Description:
 *		Create all the pieces of the Title Window
 *
 *	Input Arguments:
 *	Output Arguments:
 *	Return Values:
 *	Global Variables:
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/

void
ADMCreateTitle()
{

#ifdef DEBUG
	char			fname[]="ADMCreateTitle()";
#endif

	char			buf[128];
	Dimension	width;
	Screen		*screen;
	Display		*display;
	Pixmap		titlexbm;
	int			nargs;
	Arg			args[20];

	DBGEnter();

	screen = XtScreen( ADM_Top_Level);
	display = XtDisplay ( ADM_Top_Level);

	/* create the bitmap that will go into the title window */
	titlexbm = XCreatePixmapFromBitmapData(
					display,
					DefaultRootWindow(display),
					titlexbm_bits,
					titlexbm_width, titlexbm_height,
					BlackPixelOfScreen( screen ),
					WhitePixelOfScreen( screen ),
					DefaultDepthOfScreen( screen )
					);

	/* create a Title Window which is displayed at start up and then 
	 * can be removed later or over-displayed by other windows */

	sprintf ( buf, "%s\n%s\n%s\n%s", TITLE, BYLINE, AUTHOR, COMPANY );

	/* create a blank title window form */
	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, &width ); nargs++;
	XtGetValues ( mainForm, args, nargs );

	nargs = 0;
	XtSetArg ( args[nargs], XtNwidth, width ); nargs++;
	XtSetArg ( args[nargs], XtNbitmap, titlexbm ); nargs++;
	XtSetArg ( args[nargs], XtNtop, XtChainTop ); nargs++;
	XtSetArg ( args[nargs], XtNbottom, XtChainBottom ); nargs++;
	XtSetArg ( args[nargs], XtNright, XtChainRight ); nargs++;
	XtSetArg ( args[nargs], XtNleft, XtChainLeft ); nargs++;
	XtSetArg ( args[nargs], XtNhorizDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNvertDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNdefaultDistance, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNborderWidth, 0 ); nargs++;
	XtSetArg ( args[nargs], XtNresizable, True ); nargs++;
	/*
	XtSetArg ( args[nargs], XtNlabel, buf ); nargs++;
	*/

	/* don't manage it now, we'll do it later */
	titleWindow = XtCreateWidget (
			"titleWindow",		/* widget name */
			labelWidgetClass,	/* class */
			mainForm,			/* parent widget */
			args,	nargs			/* arg list */
			);

	XtManageChild ( titleWindow );

	/*
	 * tell the program which widget is currently being managed by
	 * the mainForm window
	 */
	ADM_Current_Window = titleWindow;

	DBGExit();
}

#endif /* TITLE_C */
