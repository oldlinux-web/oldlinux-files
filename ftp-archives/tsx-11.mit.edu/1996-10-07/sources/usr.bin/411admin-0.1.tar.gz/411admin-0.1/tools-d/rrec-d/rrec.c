/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: rrec.c
 *            DESCRIPTION: Displays an index record and the database 
 *								 : record it points to.
 *      DEFINED CONSTANTS: 
 *       TYPE DEFINITIONS: 
 *      MACRO DEFINITIONS: 
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: 
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: You must supply the offset into the index file of 
 *								 : the record you wish to see as the only command 
 *								 : line argument.
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/411, no underscores, mixed case	411PublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/411, underscores, mixed case		411_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		prefixed w/411, underscores and all caps		411_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBINIT_C
#define DBINIT_C

/* === System Headers === */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <getopt.h>
#include <ctype.h>

/* === Project Headers === */
#include "db.h"

#define USAGE "[ -i index_filename | -f db_filename ] <index-offset>"

#define HASHFILE	"/etc/411/411.hash"
#define INDEXFILE	"/etc/411/411.index"
#define DBFILE		"/etc/411/411"

/* === external routines === */

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
extern	char	*optarg;
extern	int	optind, opterr;


/*========================================================================
 *	Name:			parse_cmd
 *	Prototype:	parse_cmd( int argc, char **argv )
 *					
 *
 *	Description:
 *		parse command line options
 *
 *	Input Arguments:
 *		int	argc			number of command line arguments
 *		char	**argv		array of strings which are command line args
 *		
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *		char		*DB_FileName				name of flat file
 *		char		*DB_Index_FileName		name of index file
 *		char		*DB_Hash_FileName			name of hash file
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
parse_cmd(
	int argc,
	char **argv
)
{
	int c;

	opterr=0;
	while ( ( c = getopt( argc, argv, "?f:i:" )) != -1 )
	{
		switch (c)
		{
			case 'f':
				DB_Filename = (char *) malloc ( strlen (argv[optind-1]) );
				strcpy ( DB_Filename, argv[optind-1] );
				break;

			case 'i':
				DB_Index_Filename = (char *) malloc ( strlen (argv[optind-1]) );
				strcpy ( DB_Index_Filename, argv[optind-1] );
				break;

			case '?':
			default:	
				fprintf( stderr, "%s: Unknown argument: %s\n", 
					argv[0], argv[optind-1]);
				fprintf( stderr, "%s: %s\n", argv[0], USAGE);
				exit ( -1 );
				break;
		}
	}
}


int
main(
	int	argc,
	char	**argv
)
{
	int			indexfd, datafd;
	int			nbytes, n, i;
	char			chr;
	char			buf[25];
	char			*inbuf;
	INDEX_REC	i_rec;


	parse_cmd ( argc, argv );

	/*
	 * make sure offset has been specified
	 */
	n = strlen ( argv[optind] );
	for ( i=0; i < n; i++ )
	{
		bcopy ( (char *)(argv[optind]+i), &chr, 1 );
		if ( isdigit ( chr ) == 0 )
		{
			printf("You must provide an offset into the index file.\n");
			printf("%s: %s\n", argv[0], USAGE); 
			exit(-1);
		}
	}


	/*
	 * get the index file name
	 */
	if ( DB_Index_Filename == NULL )
	{
		DB_Index_Filename = (char *) malloc ( strlen ( INDEXFILE ) );
		strcpy ( DB_Index_Filename, INDEXFILE );
	}


	/*
	 * get the flat file name
	 */
	if ( DB_Filename == NULL )
	{
		DB_Filename = (char *) malloc ( strlen ( DBFILE ) );
		strcpy ( DB_Filename, DBFILE );
	}


	/*
	 * open the index file
	 */
	if ( ( indexfd = open ( DB_Index_Filename, O_RDONLY ) ) == -1 )
	{
		printf("Error opening index file (%s): errno= %d\n", 
			DB_Index_Filename, errno); 
		exit(-1);
	}

	/*
	 * jump to the offset provided on the command line
	 */
	if ( lseek ( indexfd, atoi(argv[optind]), SEEK_SET ) == -1 )
	{
		printf("Error in lseek() of %s: errno=%d\n", 
				DB_Index_Filename, errno);
		close ( indexfd );
		exit(-1);
	}

	/*
	 * Read in and print out the index record
	 * There is no newline here, we'll be tacking on a portion of the
	 * db flat file record to end of this.
	 */
	nbytes = read ( indexfd, &i_rec, sizeof ( INDEX_REC ) );
	close ( indexfd );
	printf ("%5d:   %d\t%5d\t%5d\t%5d\t%5d\t", 
		atoi(argv[optind]), 
		i_rec.active, 
		i_rec.next, 
		i_rec.prev, 
		i_rec.ptr, 
		i_rec.length);


	/*
	 * get the database record the index points to
	 */
	if ( ( datafd = open ( DB_Filename, O_RDONLY ) ) == -1 )
	{
		printf("Error opening database file (%s): errno=%d\n",
				DB_Filename, errno );
		exit(-1);
	}

	/*
	 * move to the correct offset in the flat file
	 */
	if ( lseek ( datafd, i_rec.ptr, SEEK_SET ) == -1 ) {
		printf("Error in lseek() of %s: errno=%d\n", 
				DB_Filename, errno);
		close ( datafd );
		exit(-1);
	}

	/*
	 * read in the flat file record
	 */
	inbuf = (char *) malloc ( i_rec.length + 1 );
	nbytes = read ( datafd, inbuf, i_rec.length );

	/*
	 * build an output line
	 */
	nbytes = strlen ( buf );
	strncpy( buf, inbuf, 15 );
	bcopy ( "\0", (char *)(buf+15+nbytes), 1 );
	strcat ( buf, "..." );
	printf ( "%s\n", buf );

	free ( inbuf );
	close ( datafd );

	exit ( 0 );
}

#endif /* DBINIT_C */
