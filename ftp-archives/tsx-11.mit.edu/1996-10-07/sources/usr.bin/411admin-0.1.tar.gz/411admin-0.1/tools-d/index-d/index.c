/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: index.c
 *            DESCRIPTION: build the index and hash tables from a flat file
 *      DEFINED CONSTANTS: 
 *       TYPE DEFINITIONS: 
 *      MACRO DEFINITIONS: 
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: found in libmhdb.a
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: all records in the flat file must already
 *								 : contain a newline at the end of the record!
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/411, no underscores, mixed case	411PublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/411, underscores, mixed case		411_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		prefixed w/411, underscores and all caps		411_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#define MAIN_C

/* === System Headers === */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <getopt.h>
#include <ctype.h>

/* === Project Headers === */
#include "db.h"
#include "debug.h"

#define USAGE \
"[ -I input_file | -d db_dir | -f db_filename | -i index_filename\n \
                 | -h hash_filename ]\n \
where\n \
input_file           relative path name to input file\n \
db_dir               directory where db files will exist\n \
db_filename          filename (no path) for flat file\n \
index_filename       filename (no path) for index file\n \
hash_filename        filename (no path) for hash file\n \
\n \
"

#define DBDIR		"/etc/411"
#define DBFILE		"411"
#define INDEXFILE	"411.index"
#define HASHFILE	"411.hash"

/*
 * we need a really large buffer, since we have no way of knowing how big
 * a record might be
 */
#define MAXRECORDSIZE	4096*10

/* === external routines === */
extern int	DBInit();
extern int	DBAddRecord();
extern void	DBShutdown();

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
char				*input_filename=NULL;
char				*DB_Directory=NULL;

extern	char	*optarg;
extern	int	optind, opterr;


/*========================================================================
 *	Name:			parse_cmd
 *	Prototype:	parse_cmd( int argc, char **argv )
 *					
 *
 *	Description:
 *		parse command line options
 *
 *	Input Arguments:
 *		int	argc			number of command line arguments
 *		char	**argv		array of strings which are command line args
 *		
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *		char		*DB_Hash_FileName			name of hash file
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
parse_cmd(
	int	argc,
	char	**argv
)
{
	int c;

	opterr=0;
	while ( ( c = getopt( argc, argv, "?d:f:i:I:h:" )) != -1 )
	{
		switch (c)
		{
			case 'd':
				DB_Directory = (char *) malloc ( strlen (argv[optind-1]) );
				strcpy ( DB_Directory, argv[optind-1] );
				break;

			case 'f':
				DB_Filename = (char *) malloc ( strlen (argv[optind-1]) );
				strcpy ( DB_Filename, argv[optind-1] );
				break;

			case 'i':
				DB_Index_Filename = (char *) malloc ( strlen (argv[optind-1]) );
				strcpy ( DB_Index_Filename, argv[optind-1] );
				break;

			case 'I':
				input_filename = (char *) malloc ( strlen (argv[optind-1]) );
				strcpy ( input_filename, argv[optind-1] );
				break;

			case 'h':
				DB_Hash_Filename = (char *) malloc ( strlen (argv[optind-1]) );
				strcpy ( DB_Hash_Filename, argv[optind-1] );
				break;

			case '?':
			default:	
				fprintf( stderr, "%s: Unknown argument: %s\n", 
					argv[0], argv[optind-1]);
				fprintf( stderr, "%s %s\n", argv[0], USAGE);
				exit ( -1 );
				break;
		}
	}
}



int
main(
	int	argc,
	char	**argv
)
{
	FILE			*datafp;
	char			*buf;
	int			rc;

	DBGOpen( DEBUG_FD );

	parse_cmd( argc, argv );

	/*
	 * The input filename is required
	 */
	if ( input_filename == NULL )
	{
		fprintf( stderr, 
			"You must supply the -I option to provide an input filename.\n");
		fprintf( stderr, "%s %s\n", argv[0], USAGE);
		exit ( -1 );
	}

	/*
	 * get the directory, flat, index, and hash file names
	 */
	if ( DB_Directory == NULL )
	{
		DB_Directory = (char *) malloc ( strlen ( DBDIR ) + 1 );
		strcpy ( DB_Directory, DBDIR );
	}
	if ( DB_Filename == NULL )
	{
		DB_Filename = (char *) malloc ( strlen ( DBFILE ) + 1 );
		strcpy ( DB_Filename, DBFILE );
	}
	if ( DB_Index_Filename == NULL )
	{
		DB_Index_Filename = (char *) malloc ( strlen ( INDEXFILE ) + 1 );
		strcpy ( DB_Index_Filename, INDEXFILE );
	}
	if ( DB_Hash_Filename == NULL )
	{
		DB_Hash_Filename = (char *) malloc ( strlen ( HASHFILE ) + 1 );
		strcpy ( DB_Hash_Filename, HASHFILE );
	}

	printf( "Using the following filenames:\n"
			"Input file   : %s\n"
			"DB Directory : %s\n"
			"Flat file    : %s\n"
			"Index file   : %s\n"
			"Hash file    : %s\n",
			input_filename, DB_Directory, DB_Filename, 
			DB_Index_Filename, DB_Hash_Filename);

	/*
	 * Some variable initialization
	 */
	buf = (char *) malloc ( MAXRECORDSIZE );
	bzero(buf, MAXRECORDSIZE);
	
	
	/*
	 * Initialize the database
	 */
	if ( DBInit (  DB_Directory,
						DB_Filename,
						DB_Hash_Filename,
						DB_Index_Filename ) != DB_SUCCESS )
	{
		printf ("Errors initializing database.\n");
		printf ("Aborting.\n");
		exit ( -1 );
	}


	/*
	 * open the input file
	 */
	if (  ( datafp = fopen ( input_filename, "r" ) ) == NULL )
	{
			printf("Error opening input file (%s)\n", input_filename );
			exit(-1);
	}


	/*
	 * read each record and process it
	 */
	while ( fgets( buf, MAXRECORDSIZE, datafp ) != NULL )
	{

		/*
		 * Use the db library to add the records
		 */
		if ( (rc = DBAddRecord( buf ) ) != DB_SUCCESS )
		{
			/*
			 * pop up message dialog saying we hit a snag
			 */
			switch ( rc )
			{
				case DB_EXIST:
					fprintf ( stderr, 
						"Failed to Add record: \"%s\""
						"\nRecord Already Exists.\n\n", 
							buf );
					break;

				default:
					fprintf ( stderr, 
						"Failed to Add record: \"%s\"."
						"\nDBAddRecord() returned %d.\n\n", 
							buf, rc );
					break;
			}
		}
		else
			fprintf ( stderr, "Record added: \"%s\"\n", buf );
	} 

	/*
	 * close files and exit
	 */
	fclose ( datafp );

	/*
	 * Shutdown the database
	 */
	DBShutdown();
	DBGClose(DEBUG_FD);

	exit (0);
}

