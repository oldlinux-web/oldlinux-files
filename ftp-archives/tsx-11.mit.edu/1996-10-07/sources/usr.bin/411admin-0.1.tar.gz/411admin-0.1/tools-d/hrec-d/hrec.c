/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: hrec.c
 *            DESCRIPTION: Displays an hash record.
 *      DEFINED CONSTANTS: 
 *       TYPE DEFINITIONS: 
 *      MACRO DEFINITIONS: 
 *       GLOBAL VARIABLES: 
 *       PUBLIC FUNCTIONS: 
 *      PRIVATE FUNCTIONS: 
 *  SOFTWARE DEPENDENCIES: 
 *  HARDWARE DEPENDENCIES: 
 *                  NOTES: You must supply the offset into the hash file of 
 *								 : the record you wish to see as the only command 
 *								 : line argument.
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Public routines:
 *		prefixed w/411, no underscores, mixed case	411PublicRoutine
 * Private routines:
 *		no underscores, mixed case							PrivateRoutine
 * Global variables:
 *		prefixed w/411, underscores, mixed case		411_Global_Variable
 * Static variables:
 *		underscores, lower case								static_variable;
 * Defined values (except debug macros):	
 *		prefixed w/411, underscores and all caps		411_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DBINIT_C
#define DBINIT_C

/* === System Headers === */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <getopt.h>
#include <ctype.h>

/* === Project Headers === */
#include "db.h"

#define USAGE "[ -h hash_filename ] <hash-offset>"

#define HASHFILE	"/etc/411/411.hash"

/* === external routines === */

/* === Public routine prototypes === */

/* === Private routine prototypes === */

/* === Global Variables === */
extern	char	*optarg;
extern	int	optind, opterr;


/*========================================================================
 *	Name:			parse_cmd
 *	Prototype:	parse_cmd( int argc, char **argv )
 *					
 *
 *	Description:
 *		parse command line options
 *
 *	Input Arguments:
 *		int	argc			number of command line arguments
 *		char	**argv		array of strings which are command line args
 *		
 *	Output Arguments:
 *	Return Values:
 *		None.
 *
 *	Global Variables:
 *		char		*DB_Hash_FileName			name of hash file
 *
 *	External Routines:
 *	Method:
 *	Restrictions:
 *	Notes:
 *		
 *========================================================================*/
void
parse_cmd(
	int argc,
	char **argv
)
{
	int c;

	opterr=0;
	while ( ( c = getopt( argc, argv, "?h:" )) != -1 )
	{
		switch (c)
		{
			case 'h':
				DB_Hash_Filename = (char *) malloc ( strlen (argv[optind-1]) );
				strcpy ( DB_Hash_Filename, argv[optind-1] );
				break;

			case '?':
			default:	
				fprintf( stderr, "%s: Unknown argument: %s\n", 
					argv[0], argv[optind-1]);
				fprintf( stderr, "%s: %s\n", argv[0], USAGE);
				exit ( -1 );
				break;
		}
	}
}



int
main(
	int	argc,
	char	**argv
)
{
	int		hashfd;		/* hash file file descriptor */
	int		nbytes;		/* number of bytes read */
	int		n, i;
	char		chr;
	HASH_REC	hash;			/* hash record */


	parse_cmd( argc, argv);

	/*
	 * get the hash file name
	 */
	if ( DB_Hash_Filename == NULL )
	{
		DB_Hash_Filename = (char *) malloc ( strlen ( HASHFILE ) );
		strcpy ( DB_Hash_Filename, HASHFILE );
	}

	/*
	 * make sure offset has been specified
	 */
	n = strlen ( argv[optind] );
	for ( i=0; i < n; i++ )
	{
		bcopy ( (char *)(argv[optind]+i), &chr, 1 );
		if ( isdigit ( chr ) == 0 )
		{
			printf("You must provide an offset into the hash file.\n");
			printf("%s: %s\n", argv[0], USAGE); 
			exit(-1);
		}
	}


	/*
	 * open the hash file
	 */
	if ( ( hashfd = open ( DB_Hash_Filename, O_RDONLY ) ) == -1 )
	{
		printf("Error opening hash file (%s): errno= %d\n", 
			DB_Hash_Filename, errno); 
		exit(-1);
	}

	/*
	 * move to the point specified on the command line
	 */
	if ( lseek ( hashfd, atoi(argv[optind]), SEEK_SET ) == -1 )
	{
		printf("Error setting file pointer in hash file\n");
		close ( hashfd );
		exit(-1);
	}

	/*
	 * read in the record
	 */
	nbytes = read ( hashfd, hash.name, 4 );
	bcopy ( "\0", (char *)(hash.name+4), 1 );
	nbytes = read ( hashfd, &hash.ptr, 4 );
	close ( hashfd );

	/*
	 * and display it
	 */
	printf ("%5d: %5d\t%s\n", atoi(argv[optind]), hash.ptr,
		hash.name );

	exit ( 0 );
}

#endif /* DBINIT_C */
