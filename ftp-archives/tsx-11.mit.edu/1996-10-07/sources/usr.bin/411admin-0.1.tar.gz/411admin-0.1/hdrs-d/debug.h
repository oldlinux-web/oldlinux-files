/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: debug.h
 *            DESCRIPTION: header file for debug facility
 *      DEFINED CONSTANTS: 
 *       TYPE DEFINITIONS: 
 *      MACRO DEFINITIONS: 
 *       GLOBAL VARIABLES: 
 *                  NOTES: Set tabstops=3 for readability
 *								 : The debug macros make use of a static
 *								 : character string called fname[].  If this
 *								 : is not defined, the debug macros will not
 *								 : compile.
 *
 * SPECIAL CONSIDERATIONS:
 *	The following naming conventions are used throughout the source:
 *
 * Defined values (except debug macros):	
 *		prefixed w/ADM, underscores and all caps		ADM_DEFINED_VALUE
 * Debug macros
 *		no underscores, mixed caps, prefixed w/DBG	DBGMacro
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DEBUG_H
#define DEBUG_H

/* make sure the top level header file is included */
#ifndef ADMIN_H
#include "411admin.h"
#endif
#ifndef _SYS_STAT_H
#include <sys/stat.h>
#endif
#ifndef _SYS_TYPES_H
#include <sys/types.h>
#endif
#ifndef _UNISTD_H
#include <unistd.h>
#endif
#ifndef _FCNTL_H
#include <fcntl.h>
#endif


#define DEBUG_CONSOLE_DEV	"/dev/console"		/* where to write to */


#ifdef DEBUG

#define DBG						"DBG411"				/* identifies debug lines */
#define DEBUG_ENTER			"Entered routine\n"
#define DEBUG_EXIT			"Exiting routine\n"

#define DBG_PROC			0x0001					/* procedure specific debug */
#define DBG_INFO			0x0002					/* general info */
#define DBG_PARSE			0x0004					/* parser info */
#define DBG_WINDOWS		0x0008					/* window creation info */
#define DBG_UTIL			0x0010					/* utility routines info */
#define DBG_SPECIAL		0x0100					/* special? */


extern char *ADMDebugOut();		/* found in debug.c */


/* provide some storage for the debug message strings */
#ifdef MAIN_C
int	debug_level = DBG_PROC | DBG_INFO | DBG_SPECIAL;		
char	*DBGFile=DEBUG_CONSOLE_DEV;
char	*DBGbuf;
int	DEBUG_FD;					/* filedesc for debug output */

#else

extern char	*DBGFile;
extern char	*DBGbuf;
extern int	debug_level;
extern int	DEBUG_FD;

#endif

/* Open the Debug output stream */
#define DBGOpen(fd)																		\
{																								\
	if ( ( fd = open ( DBGFile, 														\
				O_WRONLY | O_CREAT | O_TRUNC, 0666 ) ) == -1 )					\
	{																							\
		fprintf ( stderr, "Can't open %s\n", DBGFile );							\
		exit ( -1 );																		\
	}																							\
}


/* Close the Debug output stream */
#define DBGClose(fd)					\
{											\
	if ( fd != 0 )						\
		close ( fd );					\
}

	
/* Enter a routine */
#define DBGEnter()															\
{																					\
	if (debug_level & DBG_PROC)											\
	{																				\
		write ( DEBUG_FD, fname, strlen(fname) );						\
		write ( DEBUG_FD, ": ", 2 );										\
		write ( DEBUG_FD, DEBUG_ENTER, strlen (DEBUG_ENTER) );	\
	}																				\
}

/* Exit a routine */
#define DBGExit()																	\
{																						\
	if (debug_level & DBG_PROC)												\
	{																					\
		char	DBGString[256];													\
		write ( DEBUG_FD, fname, strlen(fname) );							\
		sprintf ( DBGString, " [%s(%d)]", __FILE__, __LINE__ );		\
		write ( DEBUG_FD, DBGString, strlen(DBGString));				\
		write ( DEBUG_FD, ": ", 2 );											\
		write ( DEBUG_FD, DEBUG_EXIT, strlen (DEBUG_EXIT) );			\
	}																					\
}


/*
 * Print just the message provided
 *
 * NOTE:  the newline is not provided!
 */
#define DBGPrint(level,A)														\
{																						\
	if (debug_level & (level))		 											\
	{																					\
		char	DBGString[256];													\
		write ( DEBUG_FD, fname, strlen(fname) );							\
		sprintf ( DBGString, " [%s(%d)]", __FILE__, __LINE__ );		\
		write ( DEBUG_FD, DBGString, strlen(DBGString));				\
		write ( DEBUG_FD, ": ", 2 );											\
		write ( DEBUG_FD, A, strlen(A) );									\
	}																					\
}


/*
 * format some debug output
 * An example of using this is:
 *		DBGPrintf(DBG_INFO, ("name: %s\n", name));
 *
 * This would expand the sprintf() call below to:
 * sprintf ( DBGbuf, "name: %s\n", name );
 *
 * NOTE:  the caller must specify the newline!
 * NOTE2: this macro relies on the ADMDebugOut()
 * 		 routine found in debug.c!
 */

#define DBGPrintf(level,A)														\
{																						\
	if (debug_level & (level))													\
	{																					\
		char	DBGString[256];													\
		write ( DEBUG_FD, fname, strlen(fname) );							\
		sprintf ( DBGString, " [%s(%d)]", __FILE__, __LINE__ );		\
		write ( DEBUG_FD, DBGString, strlen(DBGString));				\
		DBGbuf= (char *)ADMDebugOut A ;										\
		write ( DEBUG_FD, ": ", 2 );											\
		write ( DEBUG_FD, DBGbuf, strlen(DBGbuf) );						\
	}																					\
}

#else

#define DBGOpen(fd)
#define DBGClose(fd)
#define DBGEnter()
#define DBGExit()
#define DBGPrint(procno, A)
#define DBGPrintf(procno, A)

#endif /* DEBUG */


#endif /* DEBUG_H */
