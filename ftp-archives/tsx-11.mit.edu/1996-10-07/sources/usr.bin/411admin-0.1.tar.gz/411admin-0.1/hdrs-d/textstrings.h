/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: textstrings.h
 *            DESCRIPTION: text strings for various widgets; replace this
 *								 : file with language specific replacement
 *                  NOTES: set tabstops=3 for readability
 *
 * SPECIAL CONSIDERATIONS:
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef TEXTSTRINGS_H
#define TEXTSTRINGS_H

/* Menu and labels used in 411Admin; modify for language dependencies */

/* title bars */
#define RECORD_INPUT_TITLE			"Record Input/View Window"
#define RECORD_INPUT_TITLE_ADD	"Function: Add a record"
#define RECORD_INPUT_TITLE_VIEW	"Function: View a record"
#define RECORD_INPUT_TITLE_UPD	"Function: Update a record"
#define RECORD_INPUT_TITLE_DEL	"Deleting record..."
#define RECORD_INPUT_TITLE_SEL	"Please select another function"

#define STATS_TITLE				"File Statistics Window"
#define COMMENTS_INPUT_TITLE	"Comments Window"
#define HELP_TITLE				"411 Administrator Help Window"
#define ERROR_TITLE				"Error Message"
#define STATS_MESSAGE_TITLE	"Statistics Message"

#define RECOMMEND_REBUILD		"It is recommended that the database be rebuilt."


/*
 * strings in the title window (these aren't used with the version using
 * titlexbm.h)
 */
#define COMPANY					"(c) 1995"
#define AUTHOR						"Michael J. Hammel"
#define BYLINE						"Developed by"
#define TITLE						"The 411 Administrator"

#endif /* TEXTSTRINGS_H */
