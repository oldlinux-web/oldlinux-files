/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: display.h
 *            DESCRIPTION: display specific data
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *                  NOTES: set tabstops=3 for readabilty
 *
 * SPECIAL CONSIDERATIONS:
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef DISPLAY_H
#define DISPLAY_H

/*
 * Default widths of some of the windows
 */
#define DEFAULT_PHONE_WIDTH		200	/* phone numbers pop up window */
#define DEFAULT_EMAIL_WIDTH		200	/* email addresses pop up window */
#define DEFAULT_COMMENTS_WIDTH	400	/* comments pop up window */
#define DEFAULT_COMMENTS_HEIGHT	200	/* comments pop up window */


/*
 * Message types
 */
#define ADM_ERROR_TYPE		1
#define ADM_MSG_TYPE			2
#define ADM_INFO_TYPE		3

#define ADM_ERROR_TITLE		"411admin Error"
#define ADM_MSG_TITLE		"411admin Message"
#define ADM_INFO_TITLE		"411admin Information"

/*
 * number of options in each Menu Bar pull-down menu
 */
#define NUM_DATABASEMENU	4		/* num options in Database menu */
#define NUM_FILEMENU			3		/* num options in File menu */
#define NUM_OPTIONMENU		10		/* num options in Options menu */
#define NUM_STATMENU			2		/* num options in Stats window menu */
#define NUM_PHONEMENU		2		/* num options in Phone window menu */
#define NUM_EMAILMENU		2		/* num options in Phone window menu */
#define NUM_COMMENTSMENU	2		/* num options in Comments window menu */
#define NUM_HELPMENU			1		/* num options in Help window before
											 * the context specific buttons are added.
											 * this must never be more than
											 * NUM_HELPBUTTONS
											 */

#define NUM_HELPBUTTONS		45		/* max # of context help entries in menu */

/*
 * define which Menu Bar menu options is which
 */

/* file menu */
#define REBUILDOPTION		0
#define STATOPTION			1
#define QUITOPTION			2

/* database menu */
#define VIEWOPTION			0
#define ADDOPTION				1
#define DELETEOPTION			2
#define UPDATEOPTION			3

/* options menu */
#define ACCEPTOPTION			0
#define SEARCHOPTION			1
#define CLEARALLOPTION		2		
#define CLEARRECOPTION		3		/* clear the record window only */
#define NEXTOPTION			4
#define PREVOPTION			5
#define SEPERATOROPTION		6
#define COMMENTSOPTION		7
#define PHONEOPTION			8
#define EMAILOPTION			9

/* stat options menu */
#define SMRECALCULATEOPTION	0
#define SMCLOSEOPTION			1

/* phone options menu */
#define PMCLEAROPTION			0		/* clear the phone window only */
#define PMCLOSEOPTION			1

/* email options menu */
#define EMCLEAROPTION			0		/* clear the email window only */
#define EMCLOSEOPTION			1

/* comments options menu */
#define CMCLEAROPTION			0		/* clear the comments window only */
#define CMCLOSEOPTION			1

/* help options menu */
#define HPCLOSEOPTION			0

/* clear options */
#define CLEAR_ALL					0
#define CLEAR_RECORD				1
#define CLEAR_EMAIL				2
#define CLEAR_PHONE				3
#define CLEAR_COMMENTS			4

/*
 * number of labels and input fields in various windows
 */
#define NUM_INPUTLABELS			11		/* num of record field input labels */
#define NUM_INPUTTEXT			NUM_INPUTLABELS	
												/* num of record field input fields */
#define NUM_PHONEFIELDWIDTH	PHONEFIELDSIZE	
												/* width of a phone entry */
#define NUM_PHONETEXT			8		/* num of phone input fields */
#define NUM_EMAILFIELDWIDTH	EMAILFIELDSIZE	
												/* width of a phone entry */
#define NUM_EMAILTEXT			8		/* num of email input fields */
#define NUM_STATTEXT				9		/* num of stat output fields */
#define NUM_STATLABELS			NUM_STATTEXT	
												/* num of stat labels */

/*
 * Window ids used in calls to routines specified as translations
 * (see xutil.c)
 */
#define RECORDWINDOW				1
#define EMAILWINDOW				2
#define PHONEWINDOW				3


/*
 * the following #defines specify an ordering to the labels/input fields
 */
#define LNAMELABEL		0
#define FNAMELABEL		1
#define MNAMELABEL		2
#define ADDRESSLABEL		3
#define ADDRESS2LABEL	4
#define CITYLABEL			5
#define STATELABEL		6
#define ZIPCODELABEL		7
#define COUNTYLABEL		8
#define COUNTRYLABEL		9
#define SECLEVELLABEL	10

/*
 * ordering of the stats output window text fields
 */
#define STATLENGTH		0
#define STATHASH			2
#define STATTOTAL			4
#define STATACTIVE		5
#define STATINACTIVE		6
#define STATPERC			8
#define STATMESSAGE		9

/*
 * defines which title bar to use depending on which function is
 * currently active
 */
#define ADM_ADD_FUNCTION		0
#define ADM_VIEW_FUNCTION		1
#define ADM_UPD_FUNCTION		2
#define ADM_DEL_FUNCTION		3
#define ADM_SEL_FUNCTION		4
#define ADM_REBUILD_NOTICE		5

/* SOME TYPE DEFINITIONS */

#endif /* DISPLAY_H */

