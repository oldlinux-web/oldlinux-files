/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: 411admin.h
 *            DESCRIPTION: project level header for 411 Administrator
 *  SOFTWARE DEPENDENCIES: X11R6, Xaw
 *                  NOTES: set tabstops=3 for readability
 *								 : alot of this stuff is not used anymore; it 
 *								 : needs to be cleaned up.
 *
 * SPECIAL CONSIDERATIONS:
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef ADMIN_H
#define ADMIN_H

#ifndef _XtStringDefs_h_
#include <X11/StringDefs.h>
#endif
#ifndef _XtIntrinsic_h
#include <X11/Intrinsic.h>
#endif

/*
 * Program name and release/version numbers
 */
#define PROGNAME				"411 Administrator"
#define RELEASE				"0"
#define VERSION				"0.1"

/*
 * default file names; these are modifiable by user
 */
#define DEFAULT_DB_DIR		"/home/mjhammel/src/411/x06/dbdata-d"
#define DEFAULT_HELP_DIR	"/home/mjhammel/src/411/x06/help-d"
#define DEFAULT_DB_FILE		"411"				/* database file name */
#define DEFAULT_HASH_FILE	"hash"			/* suffix added for hash file name */
#define DEFAULT_INDEX_FILE	"index"			/* suffix added for index file name */

/*
 * These aren't currently used, but might be in the future
 */
#define SECURITYFILENAME	"/etc/411/security"
#define TMPFILENAME			"/etc/411/.411tmp"
#define RCFILENAME			".411rc"

/*
 * lock file for security and database files, and Administrator program
 */
#define ADMLOCKNAME_S		".sadm.lock"
#define ADMLOCKNAME_D		".dadm.lock"
#define ADMLOCKNAME_P		".aadm.lock"

/*
 * Files used to say how many server requests are being processed
 * Not used in current version.
 */
#define ACTLOCKNAME_D		"/etc/411/.dact.lock"
#define ACTLOCKNAME_S		"/etc/411/.sact.lock"
#define SERVERSFILE			"/etc/411/servers"


/*
 * Maximum length of a file name
 */
#define MAXNAMELENGTH		255

/* probably defined somewhere, but what the heck */
#define YES						0
#define NO						1
#ifndef TRUE
#define TRUE					1
#define FALSE					0
#endif


/* === typedefs and structs === */

/*
 * The application resources data structure
 */
typedef struct {
	String	db_dir;			/* name of the directory where the db lives */
	String	db_file;			/* name of the database flat file */
	String	hash_file;		/* name of the hash file */
	String	index_file;		/* name of the index file */
	String	help_dir;		/* name of the directory where the help files live */
	String	debug_file;		/* name of the debug file */
	String	debug;			/* debug level to set */
	Boolean	help;				/* provide cmd line help, if requested */
} AppData, *AppDataPtr;


#endif /* ADMIN_H */
