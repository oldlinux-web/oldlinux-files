/* $Id$ */

/*========================================================================
 *  Copyright (c) Michael J. Hammel 1995.
 *========================================================================
 *              FILE NAME: help.h
 *            DESCRIPTION: help text information
 *                  NOTES: set tabstops=3 for readability
 *
 * SPECIAL CONSIDERATIONS:
 *
 *========================================================================
 *
 * MODIFICATION HISTORY:
 * $Log$
 *
 *========================================================================*/
#ifndef HELP_H
#define HELP_H

/* default size for help box */

#define DEFAULT_HELP_WIDTH		300
#define DEFAULT_HELP_HEIGHT	100

/*
 * Defines which tell ADMAddHelp() whether to use a text string
 * or a file for the text to add to the help window.
 */
#define ADM_HELP_STRING			0
#define ADM_HELP_FILE			1

/*
 * Name of the help files
 */
#define MAIN_HELP_FILE			"mainhelp.txt"
#define EMAIL_HELP_FILE			"emailhelp.txt"
#define PHONE_HELP_FILE			"phonehelp.txt"
#define COMMENTS_HELP_FILE		"commentshelp.txt"
#define STATS_HELP_FILE			"statshelp.txt"
#define ADD_HELP_FILE			"addhelp.txt"
#define UPDATE_HELP_FILE		"updatehelp.txt"
#define VIEW_HELP_FILE			"viewhelp.txt"
#define DELETE_HELP_FILE		"deletehelp.txt"

#define ABOUT_HELP_FILE			"about.txt"
#define DBRECORD_HELP_FILE		"dbrecord.txt"
#define FILEMENU_HELP_FILE		"filemenu.txt"
#define DBMENU_HELP_FILE		"dbmenu.txt"
#define OPTIONSMENU_HELP_FILE	"optionsmenu.txt"
#define MSG_HELP_FILE			"msghelp.txt"
#define RECWINDOW_HELP_FILE	"recwindow.txt"
#define USE_HELP_FILE			"usehelp.txt"

/*
 * Labels to use in the help pull down menu
 */
#define ADM_HELP_MAIN_LABEL		"Top of Help"
#define ADM_HELP_EMAIL_LABEL		"Adding Email Addresses"
#define ADM_HELP_PHONE_LABEL		"Adding Phone Numbers"
#define ADM_HELP_COMMENTS_LABEL	"Using Comments"
#define ADM_HELP_STATS_LABEL		"Using Statistics"
#define ADM_HELP_ADD_LABEL			"Adding a Record"
#define ADM_HELP_UPDATE_LABEL		"Updating a Record"
#define ADM_HELP_VIEW_LABEL		"Viewing a Record"
#define ADM_HELP_DELETE_LABEL		"Deleting a Record"

#define ADM_HELP_ABOUT_LABEL			"About ..."
#define ADM_HELP_RECORD_LABEL			"Record Format"
#define ADM_HELP_FILE_LABEL			"File Pull Down Menu"
#define ADM_HELP_DATABASE_LABEL		"Database Pull Down Menu"
#define ADM_HELP_OPTIONS_LABEL		"Options Pull Down Menu"
#define ADM_HELP_MSG_LABEL				"The Message Pop Up Window"
#define ADM_HELP_RECWINDOW_LABEL		"The Record Input Window"
#define ADM_HELP_USE_HELP_LABEL		"Moving Around ..."

/*
 * Maximum length of a help line if the text is read from a file
 */
#define MAX_HELP_LINE_LENGTH	130


/*
 * Usage line
 */

#define USAGE \
"411admin accepts all standard X Toolkit command line options, plus\n\
the following:\n\
\n\
411admin [ -dbdir directory | -dbfile dbfilename | -hashfile hashfilename\n\
         | -indexfile indexfilename | -helpdir direcotry\n\
         | -debugfile debugfilename | -debug debuglevel | -help ]\n\
where\n\
directory      specifies what directory the database files are in\n\
dbfilename     name of the database file\n\
hashfilename   name of the hash file\n\
indexfilename  name of the index file\n\
helpdir        name of directory containing help files\n\
debugfilename  name of the debug file\n\
debug          debug level\n\
help           gives this help text\n\
\n\
Note: -debugfile and -debug only have meaning if 411admin is compiled\n\
with the -DDEBUG option.  Debug levels are as follows:\n\
\n\
Procedural (enter and exit)         1\n\
General Info (most useful info)     2\n\
Parser Info (excessive output)      4\n\
Window Creation                     8\n\
Utility Routines (2nd most useful)  16\n\
Special (not used yet)              256\n\
\n\
These are cumulative, so in order to get, say, Procedural and General\n\
debug information you would specify a level of 3 ( 1 + 2 ).\n\
\n\
"


/*
 * Help messages
 */


/*
 * Main help message
 */
#define MAIN_HELP_MESSAGE	\
"Welcome to the 411 Administrator!\n\
\n\
This is the Main Help Window.  The same window pops up no matter \
what window you are in when you select the Help button. \
\n\n\
Basics\n\
\n\
You can choose a specific topic to jump to by selecting an item from \
the Topics pull-down menu.\n\
\n\n\n\
"


/*
 * Phone numbers function help message
 */
#define PHONE_HELP_MESSAGE	\
"The Phone Numbers Window\n\
\n\
This window is used to view and enter phone numbers.  When viewing \
records the user cannot enter data.  When using the Add or Update \
functions this window allows input.\n\
\n\n\n\
"


/*
 * Comments function help message
 */
#define COMMENTS_HELP_MESSAGE	\
"The Comments Window\n\
\n\
This window is used to view and enter comments.  When viewing \
records the user cannot enter data.  When using the Add or Update \
functions this window allows input.\n\
\n\n\n\
"


/*
 * View function help message
 */
#define VIEW_HELP_MESSAGE	\
"The View Function\n\
\n\
The View function allows a user to search for a record from the database \
by specifying certain search criteria.\n\
\n\n\n\
"


/*
 * Stats function help message
 */
#define STATS_HELP_MESSAGE	\
"The Statistics Function\n\
\n\
The Statistics function provides information on disk space used by the \
database, number of active and inactive records, and so forth.  It is \
primarily informational but does make recommendations on when to rebuild \
the database based on the percentage of inactive records. \
The Options pull-down menu provides the only available facilities \
provided by the Statistics function.\n\
\n\
Available Options\n\
\n\
Recalculate the statistics:\n\
\tThis option recomputes database statistics.  Normally such computations \
are not done unless specifically requested.\n\
\n\
Close:\n\
\tThis option closes the Statistics window.\n\
\n\n\n\
"


/*
 * Update function help message
 */
#define UPD_HELP_MESSAGE \
"The Update Function\n\
\n\
The Update function allows a user to modify an exisiting record in the \
database.  The actual update is accomplished by deleting the old record, \
making it inactive, and adding the updated record as a new record.  \
This is an invisible process to the user but its important to remember \
to understand why multiple updates can cause the database to grow in \
size, and thus require the user to rebuild the database.\n\
\n\n\n\
"


/*
 * Add function help message
 */
#define ADD_HELP_MESSAGE \
"The Add Function\n\
\n\
The Add function allows a user to add a new record to the database. \
The users simply fills in the meaningful parts of the form and selects \
the Accept option from the Options pull-down menu.  If the record \
exists, that record is displayed in the form and an error message \
stating that the record already exists is displayed.  The user must then \
use the Update function to modify the record.\n\
\n\
If the record does not exist it is added to the database.\n\
\n\n\n\
"


#endif /* HELP_H */

