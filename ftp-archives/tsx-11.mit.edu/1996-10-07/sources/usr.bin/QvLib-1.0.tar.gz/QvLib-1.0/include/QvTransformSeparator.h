#ifndef  _QV_TRANSFORM_SEPARATOR_
#define  _QV_TRANSFORM_SEPARATOR_

#include <QvGroup.h>

class QvTransformSeparator : public QvGroup {

    QV_NODE_HEADER(QvTransformSeparator);

    // No fields
};

#endif /* _QV_TRANSFORM_SEPARATOR_ */
