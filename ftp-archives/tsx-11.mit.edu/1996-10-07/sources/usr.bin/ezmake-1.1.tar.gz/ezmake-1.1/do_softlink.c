#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <assert.h>

#include "e1.h"
#include "lspec.h"

#ifdef RCSID
static char rcsid[] = "$Id: do_softlink.c,v 1.2 1995/11/18 22:11:42 root Exp $";
#endif /* RCSID */

#ifdef COPYRIGHT

/*
 * Copyright (c), 1995, compuPage, Inc.
 * All Rights Reserved, Cal Page, <root@lorax.mv.com>
 *
 * This software comes with ABSOLUTELY NO WARRANTY.
 *
 * This software is released under the GPL, see
 * COPYING in source directory for further details.
 */

#endif /* COPYRIGHT */

/*
 * softlink ( directory , src-filespec-list )
 *
 *    next -> next ->
 *     | |
 *     | -> filespec
 *     |
 *     -> auxNext -> directory
 */
int do_softlink( void )
{
    int tok;
    char *directory;
    LSPECPTR tmp = NULL;
    LSPECPTR x;
    char **value;
    int i;

#ifdef JUNK
    char *tmp_chown;
    char *tmp_chgrp;
    char *tmp_chmod;
#endif

    /* skip '(' */
    tok = yylex();
    if ( tok != E1_TOK_brace )
      {
	  printf("do_softlink: missing '('\n");
	  exit(1);
      }

    /* get directory */
    tok = yylex ();
    if ( tok != E1_TOK_filespec )
      {
	  printf("do_softlink: missing or bad directory = <%s>\n",
		 yytext);
	  exit(1);
      }
    directory = strdup(YYTEXT);

    tok = yylex ();
    if ( tok != E1_TOK_comma )
      {
	  printf("do_softlink: missing comma <%s>\n",
		 yytext);
	  exit(1);
      }

    /* get filespec-list */
    while ( 1 )
      {
	  tok = yylex();

	  /* are we done ??? */
	  if ( tok == E1_TOK_brace_close )
	    break;

	  if ( tok != E1_TOK_filespec )
	    {
		printf("do_softlink: missing or bad filespec = <%s>\n",
		       yytext);
		exit(1);
	    }

	  /* remove any that are necessary */
	  if ( remlister ( YYTEXT , &tmp ) )
	    continue;

	  value = glob_filename ( YYTEXT );
	  if ( value == NULL )
	    {
		printf("do_softlink: out of memory\n");
		exit(1);
	    }
	  else if ((int) value == -1)
	    perror ( yytext );
	  else
	    {
		if ( value[0] == NULL )
		  {
		      /* just add file as glob could not find it */
		      lspec_add(lspec_new(YYTEXT),&tmp);
		  }
		else
		  {
		      for (i = 0; value[i] != NULL; i++)
			{
			    lspec_add(lspec_new(value[i]),&tmp);
			}
		  }
	    }
      }

#ifdef JUNK
    /* get chown */
    tok = yylex ();
    if ( tok != E1_TOK_filespec )
      {
	  printf("do_softlink: missing chown <%s>\n",
		 yytext);
	  exit(1);
      }
    tmp_chown = strdup(YYTEXT);
#endif

#ifdef JUNK
    /* get chgrp */
    tok = yylex ();
    if ( tok != E1_TOK_filespec )
      {
	  printf("do_softlink: missing chgrp <%s>\n",
		 yytext);
	  exit(1);
      }
    tmp_chgrp = strdup(YYTEXT);
#endif

#ifdef JUNK
    /* get chmod */
    tok = yylex ();
    if ( tok != E1_TOK_string )
      {
	  printf("do_softlink: missing chmod <%s>\n",
		 yytext);
	  exit(1);
      }
    tmp_chmod = strdup(YYTEXT);
#endif

#ifdef JUNK
    tok = yylex ();
    if ( tok != E1_TOK_brace_close )
      {
	  printf("do_softlink: missing ')' in <%s>\n",
		 yytext);
	  exit(1);
      }
#endif

    if ( tmp == NULL )
      {
	  /* just a directory */
	  x = lspec_add(lspec_new(directory),&softlink_root);
#ifdef JUNK
	  lspec_add(lspec_new(tmp_chown),&x->libNext);
	  lspec_add(lspec_new(tmp_chgrp),&x->libNext);
	  lspec_add(lspec_new(tmp_chmod),&x->libNext);
#endif
      }
    else
      {
	  while ( tmp != NULL )
	    {
		LSPECPTR y;

		lspec_add(lspec_new(directory),&tmp->auxNext);
#ifdef JUNK
		lspec_add(lspec_new(tmp_chown),&tmp->libNext);
		lspec_add(lspec_new(tmp_chgrp),&tmp->libNext);
		lspec_add(lspec_new(tmp_chmod),&tmp->libNext);
#endif
		/* unlink this one from tmp chain */
		y = tmp;
		tmp = tmp->next;

		/* add to perm chain at softlink_root */
		lspec_add(y,&softlink_root);
	    }
      }

    /* free resources */
    free(directory);

#ifdef JUNK
    free(tmp_chmod);
    free(tmp_chgrp);
    free(tmp_chown);
#endif

    /* return to caller */
    return 1;
}
