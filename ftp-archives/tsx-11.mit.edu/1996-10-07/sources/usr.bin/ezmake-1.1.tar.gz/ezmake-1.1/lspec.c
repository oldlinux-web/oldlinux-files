#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <assert.h>

#include "e1.h"
#include "lspec.h"

#ifdef RCSID
static char rcsid[] = "$Id: lspec.c,v 1.9 1995/11/12 08:25:16 root Exp $";
#endif /* RCSID */

#ifdef COPYRIGHT

/*
 * Copyright (c), 1995, compuPage, Inc.
 * All Rights Reserved, Cal Page, <root@lorax.mv.com>
 *
 * This software comes with ABSOLUTELY NO WARRANTY.
 *
 * This software is released under the GPL, see
 * COPYING in source directory for further details.
 */

#endif /* COPYRIGHT */

LSPECPTR lspec_new ( char *name )
{
    LSPECPTR x;

    x = (LSPECPTR)malloc(sizeof(LSPEC));
    assert(x!=NULL);
    x->next = NULL;
    x->auxNext = NULL;
    x->libNext = NULL;
    x->name = strdup(name);
    return x;
}

void lspec_destroy ( LSPECPTR x )
{
    if ( x->name != NULL )
      free(x->name);

    if ( x->auxNext != NULL )
      lspec_destroy(x->auxNext);

    if ( x->libNext != NULL )
      lspec_destroy(x->libNext);

    free(x);
}

LSPECPTR
lspec_find ( LSPECPTR x , LSPECPTR *root )
{
    LSPECPTR tmp = *root;

    while ( tmp != NULL )
      {
	  if ( strcmp(x->name,tmp->name) == 0 )
	    return tmp;
	  tmp = tmp->next;
      }
    return NULL;
}

LSPECPTR
lspec_find_name ( char *name , LSPECPTR *root )
{
    LSPECPTR tmp = *root;

    while ( tmp != NULL )
      {
	  if ( strcmp(name,tmp->name) == 0 )
	    return tmp;
	  tmp = tmp->next;
      }
    return NULL;
}

/* remove name from a list */
void
lspec_remove ( char *name , LSPECPTR *root )
{
    LSPECPTR x;
    LSPECPTR y;

    x = lspec_find_name ( name , root );
    if ( x == NULL )
      return;

    if ( *root == x )
      {
	  /* first in list */
	  *root = x->next;
	  lspec_destroy( x );
	  return;
      }

    y = *root;
    while ( y != NULL )
      {
	  if ( y->next == x )
	    {
		y->next = x->next;
		lspec_destroy( x );
		return;
	    }
	  y = y->next;
      }
}

/* add to END of list */
LSPECPTR lspec_add ( LSPECPTR x , LSPECPTR *root )
{
    LSPECPTR tmp;

    /* don't add if already there */
    if ( lspec_find ( x , root ) != NULL )
      return x;

    if ( *root == NULL )
      {
	  /* list empty, add to front */
	  *root = x;
	  x->next = NULL;
	  return x;
      }

    /* find end */
    tmp = *root;
    while ( tmp->next != NULL )
      tmp = tmp->next;

    /* add to end */
    tmp->next = x;
    x->next = NULL;

#ifdef JUNK
    x->next = *root;
    *root = x;
#endif

    return x;
}

void lspec_rem ( LSPECPTR *root )
{
    LSPECPTR x;
    while ( *root != NULL )
      {
	  x = *root;
	  *root = x->next;
	  lspec_destroy(x);
      }
}

void lspec_list ( char *what , LSPECPTR x , int spaces )
{
    int i;

    for ( i = 0 ; i < spaces ; i++ )
      printf(" ");

    printf("%s:\n",what);
    while ( x != NULL )
      {
	  for ( i = 0 ; i < spaces ; i++ )
	    printf(" ");
	  printf("\t%s\n",x->name);

	  if ( x->auxNext != NULL )
	    lspec_list ( "auxNext" , x->auxNext , spaces + 4);

	  if ( x->libNext != NULL )
	    lspec_list ( "libNext" , x->libNext , spaces + 4);

	  x = x->next;
      }
}

void dump_header ( FILE *outf , char *data[] )
{
    int i;
    char *x;

    for ( i = 0 ; (x=data[i]) != NULL ; i++ )
      fprintf(outf,"%s\n",x);
}

/* get file, etc, from full filespec */
int parse_file ( char *filespec, char *file , char *ext , int size)
{
    char *src;
    char *tgt;
    int sz;
    char *c;

    c = strrchr(filespec,'.');

    /* copy file */
    src = filespec;
    tgt = file;
    sz = size-2;
    while ( sz-- > 0 )
      {
	  if ( c == NULL && *src == 0 )
	    break;
	  if ( c != NULL && src == c )
	    break;
	  *tgt++ = *src++;
      }
    *tgt = 0;

    /* copy ext */
    if ( c == NULL )
      {
	  *ext = 0;
	  return 1;
      }
    src = c + 1;
    tgt = ext;
    sz = size - 2;
    while ( sz-- > 0 )
      {
	  if ( *src == 0 )
	    break;
	  *tgt++ = *src++;
      }
    *tgt = 0;
    return 1;
}

/* remove names from list if necessary
 * return 0 if not necessary, else return 1
 */
int
remlister ( char *name , LSPECPTR *x )
{
    char **value;
    int i;

    if ( name[0] == '~' )
      {
	  /* remove from list */
	  value = glob_filename ( &name[1] );
	  if ( value == NULL )
	    {
		printf("remlister: out of memory\n");
		exit(1);
	    }
	  else if ((int) value == -1)
	    perror ( name );
	  else
	    for (i = 0; value[i] != NULL; i++)
	      {
		  lspec_remove ( value[i] , x );
	      }
	  return 1;
      }

    return 0;
}

/* return TRUE if ext is of type */
int
isType ( char *name , char type )
{
    char *x;

    x = strrchr ( name , '.' );
    if ( x == NULL )
      return 0;
    if ( x[1] == type )
      return 1;
    return 0;
}

/* return TRUE if ext is of type */
int
isTypeStr ( char *name , char *type )
{
    char *x;

    x = strrchr ( name , '.' );
    if ( x == NULL )
      return 0;
    if ( strcmp(x+1,type) == 0 )
      return 1;
    return 0;
}

/* return TRUE if buildable */
int
isBuildable ( char *name )
{
    if ( strchr(name,'/') != NULL )
      return 0;
    if ( isType(name,'a') )
      return 0;
    return 1;
}
