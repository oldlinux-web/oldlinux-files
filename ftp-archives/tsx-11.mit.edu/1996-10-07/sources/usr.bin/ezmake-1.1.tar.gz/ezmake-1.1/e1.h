#ifdef COPYRIGHT

/*
 * Copyright (c), 1995, compuPage, Inc.
 * All Rights Reserved, Cal Page, <root@lorax.mv.com>
 *
 * This software comes with ABSOLUTELY NO WARRANTY.
 *
 * This software is released under the GPL, see
 * COPYING in source directory for further details.
 */

#endif /* COPYRIGHT */
#ifndef __E1_H__
#define __E1_H__

#ifndef COPYRIGHT
#define COPYRIGHT "Copyright (c) 1995, compuPage, Inc."
#endif /* COPYRIGHT */

#define VERSION "1.1"

#define E1_TOK_obj 1
#define E1_TOK_lib 2
#define E1_TOK_exe 3
#define E1_TOK_comma 4
#define E1_TOK_brace 5
#define E1_TOK_brace_close 6
#define E1_TOK_filespec 7
#define E1_TOK_minus 8
#define E1_TOK_install 9
#define E1_TOK_string 10
#define E1_TOK_man 11
#define E1_TOK_doc 12
#define E1_TOK_kit 13
#define E1_TOK_move 14
#define E1_TOK_softlink 15
#define E1_TOK_dollar 16
#define E1_TOK_dollar_equal 17
#define E1_TOK_dollar_rvalue 18

/* platform types */
#define E1_TOK_platform_linux 19

/* default platform */
#define E1_DEFAULT_PLATFORM E1_TOK_platform_linux

typedef struct lspec {
    struct lspec *next;
    struct lspec *auxNext;
    struct lspec *libNext;
    char *name;
} LSPEC,*LSPECPTR;

#endif /* __E1_H__ */

