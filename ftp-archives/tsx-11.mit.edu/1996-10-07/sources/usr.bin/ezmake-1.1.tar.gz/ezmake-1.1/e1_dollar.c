#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <assert.h>

#include "e1.h"
#include "lspec.h"

#ifdef RCSID
static char rcsid[] = "$Id: e1_dollar.c,v 1.2 1995/11/18 22:39:31 root Exp $";
#endif /* RCSID */

#ifdef COPYRIGHT

/*
 * Copyright (c), 1995, compuPage, Inc.
 * All Rights Reserved, Cal Page, <root@lorax.mv.com>
 *
 * This software comes with ABSOLUTELY NO WARRANTY.
 *
 * This software is released under the GPL, see
 * COPYING in source directory for further details.
 */

#endif /* COPYRIGHT */

/* save lvalue,rvalue pairs in dollars_root as:
 *
 *    next -> next -> next ->
 *    |  |
 *    |  ----> name -> lvalue
 *    -------> auxNext -> name -> rvalue
 */
static LSPECPTR dollar_root = NULL;

/* show dollar_root */
void
e1_show_dollar ( void )
{
    lspec_list ( "e1_show_dollar" , dollar_root , 4 );
}

/* parse and define a constant */
int
e1_define_dollar ( char *txt )
{
    int tok;
    LSPECPTR tmp;

    char *lvalue;
    char *rvalue;

    char *c1;

    /* save lvalue for later */
    lvalue = strdup ( txt );
    assert(lvalue!=NULL);

    /* skip '=' */
    tok = yylex();
    if ( tok != E1_TOK_dollar_equal )
      {
	  printf("e1_define_dollar: missing '='\n");
	  exit(1);
      }

    /* get rvalue */
    tok = yylex ();
    if ( tok != E1_TOK_dollar_rvalue )
      {
	  printf("e1_define_dollar: missing or bad rvalue = <%s>\n",
		 yytext);
	  exit(1);
      }

    c1 = yytext;
    while ( *c1 == ' ' || *c1 == '\t' ) c1++;
    rvalue = strdup(c1);
    assert(rvalue!=NULL);

    /* add to dollars_root */
    tmp = lspec_add(lspec_new(lvalue),&dollar_root);
    lspec_add(lspec_new(rvalue),&tmp->auxNext);

    /* cleanup */
    free(lvalue);
    free(rvalue);

    /* return to caller */
    return 1;
}

/*
 * If 'txt' begins with '$', try to translate it
 */
char *
e1_trans_dollar ( char *txt )
{
    LSPECPTR tmp;

/* printf("e1_trans_dollar: translating <%s>\n",txt); */

    if ( txt[0] != '$' )
      return txt;         /* no translation necessary */

    tmp = lspec_find_name ( &txt[1] , &dollar_root );
    if ( tmp == NULL )
      {
	  /* not found, don't translate */
	  return txt;
      }

    /* return the translation of this variable */
    assert(tmp->auxNext!=NULL);

/* printf("e1_trans_dollar: res <%s>\n",tmp->auxNext->name); */
    
    return tmp->auxNext->name;
}
