#ifndef __NEWVER_H__
#define __NEWVER_H__

/* DO NOT EDIT - Created by ezNewVer !!! */

#define NEWVER 3

#endif /* __NEWVER_H__ */
