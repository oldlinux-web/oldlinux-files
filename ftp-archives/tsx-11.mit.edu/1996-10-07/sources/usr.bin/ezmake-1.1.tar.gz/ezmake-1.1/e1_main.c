#ifdef COPYRIGHT

/*
 * Copyright (c), 1995, compuPage, Inc.
 * All Rights Reserved, Cal Page, <root@lorax.mv.com>
 *
 * This software comes with ABSOLUTELY NO WARRANTY.
 *
 * This software is released under the GPL, see
 * COPYING in source directory for further details.
 */

#endif /* COPYRIGHT */

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <assert.h>

#include "newver.h"
#include "e1.h"
#include "lspec.h"

#ifdef RCSID
static char rcsid[] = "$Id: e1_main.c,v 1.15 1995/11/18 22:02:16 root Exp $";
#endif /* RCSID */

#ifdef COPYRIGHT
/* Copyright (c) 1995, compuPage, Inc. */
static char copyright[] = COPYRIGHT;
#endif /* COPYRIGHT */

/* made targets, clean them up during clean: */
LSPECPTR clean_root = NULL;

/* make these objs */
LSPECPTR objs_root = NULL;

/* list of things for depend */
LSPECPTR depend_root = NULL;

/* list of things for all */
LSPECPTR all_root = NULL;

/* build dependancies temp */
LSPECPTR temp_root = NULL;

/* depend dependancies */
LSPECPTR depend_dep_root = NULL;

/* exe root */
LSPECPTR exe_root = NULL;

/* lib root */
LSPECPTR lib_root = NULL;

/* cflags */
LSPECPTR cflags_root = NULL;

/* install */
LSPECPTR install_root = NULL;

/* man */
LSPECPTR man_root = NULL;

/* doc */
LSPECPTR doc_root = NULL;

/* kit */
LSPECPTR kit_root = NULL;

/* move */
LSPECPTR move_root = NULL;

/* softlink */
LSPECPTR softlink_root = NULL;

/* the current platform */
int current_platform = E1_DEFAULT_PLATFORM;

int
toploop ()
{
    int tok;

    tok = yylex();
    switch ( tok )
      {
	case 0:
	  return 0;

	case E1_TOK_obj:
	  do_obj();
	  break;

	case E1_TOK_lib:
	  do_lib();
	  break;

	case E1_TOK_exe:
	  do_exe();
	  break;

	case E1_TOK_minus:
	  /* assume anyting -XXX is a cflags extension */
	  lspec_add(lspec_new(yytext),&cflags_root);
	  break;

	case E1_TOK_install:
	  do_install();
	  break;

	case E1_TOK_man:
	  do_man();
	  break;

	case E1_TOK_doc:
	  do_doc();
	  break;

	case E1_TOK_kit:
	  do_kit();
	  break;

	case E1_TOK_move:
	  do_move();
	  break;

	case E1_TOK_softlink:
	  do_softlink();
	  break;

	  /* process 'platform-type' here */
	case E1_TOK_platform_linux:
	  current_platform = E1_TOK_platform_linux;
	  break;

	  /* process any definition */
	case E1_TOK_dollar:
	  e1_define_dollar( yytext );
	  break;

	default:
	  printf("unknown token %d = <%s>\n",tok,yytext);
	  exit(1);
      }
    return 1;
}

int
main ( int argc , char *argv[] )
{
#ifdef COPYRIGHT
    fprintf(stderr,"%s : Version <%s.%d>\n",
	    argv[0],VERSION,NEWVER);
    fprintf(stderr,"%s\n",copyright);
    fprintf(stderr,"ezmake comes with ABSOLUTELY NO WARRANTY.\n");
#endif /* COPYRIGHT */

    /* syntax analysis */
    while ( toploop() );

    /* dispatch based on platform for code generation */
    switch ( current_platform )
      {
	case E1_TOK_platform_linux:
	  /* generate for linux at this time */
	  e1_gen_linux ( stdout );
	  break;

	  /* add other platforms here */

	default:
	  printf("unknown platform type = %d\n",current_platform);
	  exit(1);
	  break;
      }

#ifdef JUNK
    e1_show_dollar();
#endif

    /* return to caller */
    return 0;
}
