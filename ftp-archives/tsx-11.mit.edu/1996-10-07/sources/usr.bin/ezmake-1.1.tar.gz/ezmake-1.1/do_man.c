#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <assert.h>

#include "e1.h"
#include "lspec.h"

#ifdef RCSID
static char rcsid[] = "$Id: do_man.c,v 1.5 1995/11/18 22:11:42 root Exp $";
#endif /* RCSID */

#ifdef COPYRIGHT

/*
 * Copyright (c), 1995, compuPage, Inc.
 * All Rights Reserved, Cal Page, <root@lorax.mv.com>
 *
 * This software comes with ABSOLUTELY NO WARRANTY.
 *
 * This software is released under the GPL, see
 * COPYING in source directory for further details.
 */

#endif /* COPYRIGHT */

/*
 * man ( src-filespec-list )
 */
int do_man( void )
{
    int tok;
    char **value;
    int i;

    /* add 'man' to 'doc' */
    lspec_add(lspec_new("man"),&doc_root);

    /* add 'doc' to 'all' */
    lspec_add(lspec_new("doc"),&all_root);

    /* skip '(' */
    tok = yylex();
    if ( tok != E1_TOK_brace )
      {
	  printf("do_man: missing '('\n");
	  exit(1);
      }

    /* get src file list */
    while ( 1 )
      {
	  tok = yylex();

	  /* are we done ??? */
	  if ( tok == E1_TOK_brace_close )
	    {
		break;
	    }

	  if ( tok != E1_TOK_filespec )
	    {
		printf("do_man: missing or bad filespec = <%s>\n",
		       yytext);
		exit(1);
	    }

	  /* remove any that are necessary */
	  if ( remlister ( YYTEXT , &man_root ) )
	    continue;

	  if ( !isBuildable(YYTEXT) )
	    /* don't glob things we can't build */
	    lspec_add(lspec_new(YYTEXT),&man_root);
	  else
	    {
		value = glob_filename ( YYTEXT );
		if ( value == NULL )
		  {
		      printf("out of memory\n");
		      exit(1);
		  }
		else if ((int) value == -1)
		  perror ( YYTEXT );
		else
		  for (i = 0; value[i] != NULL; i++)
		    {
			lspec_add(lspec_new(value[i]),&man_root);
		    }
	    }
      }

    return 1;
}
