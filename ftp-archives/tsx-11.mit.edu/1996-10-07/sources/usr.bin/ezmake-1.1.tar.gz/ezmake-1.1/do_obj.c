#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <assert.h>

#include "e1.h"
#include "lspec.h"

#ifdef RCSID
static char rcsid[] = "$Id: do_obj.c,v 1.5 1995/11/18 22:02:16 root Exp $";
#endif /* RCSID */

#ifdef COPYRIGHT

/*
 * Copyright (c), 1995, compuPage, Inc.
 * All Rights Reserved, Cal Page, <root@lorax.mv.com>
 *
 * This software comes with ABSOLUTELY NO WARRANTY.
 *
 * This software is released under the GPL, see
 * COPYING in source directory for further details.
 */

#endif /* COPYRIGHT */

/*
 *    obj ( src-filespec-list )
 *
 *    objs_root:
 *        next -> next -> next -> ...
 *        |
 *        --> src-file-name
 */
int do_obj( void )
{
    int tok;
    char *filespec;
    char **value;
    int i;

    tok = yylex();
    if ( tok != E1_TOK_brace )
      {
	  printf("do_obj: missing '('\n");
	  exit(1);
      }

    while ( 1 )
      {
	  tok = yylex();

	  /* are we done ??? */
	  if ( tok == E1_TOK_brace_close ||
               tok == 0 )
	    {
		/* yes */
		return 1;
	    }

	  if ( tok != E1_TOK_filespec )
	    {
		printf("do_obj: missing or bad filespec = <%s>\n",
		       yytext);
		exit(1);
	    }

	  /* remove any that are necessary */
	  if ( remlister ( YYTEXT , &objs_root ) )
	    continue;

	  filespec = strdup(YYTEXT);

	  value = glob_filename ( filespec );
	  if ( value == NULL )
	    {
		printf("out of memory\n");
		exit(1);
	    }
	  else if ((int) value == -1)
	    perror ( filespec );
	  else
	    for (i = 0; value[i] != NULL; i++)
	      {
		  lspec_add(lspec_new(value[i]),&objs_root);
	      }
	  free(filespec);
      }

    return 0;
}

