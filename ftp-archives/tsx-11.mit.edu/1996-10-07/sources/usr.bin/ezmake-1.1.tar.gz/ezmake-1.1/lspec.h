#ifdef COPYRIGHT

/*
 * Copyright (c), 1995, compuPage, Inc.
 * All Rights Reserved, Cal Page, <root@lorax.mv.com>
 *
 * This software comes with ABSOLUTELY NO WARRANTY.
 *
 * This software is released under the GPL, see
 * COPYING in source directory for further details.
 */

#endif /* COPYRIGHT */
#ifndef __LSPEC_H__
#define __LSPEC_H__

#ifndef COPYRIGHT
#define COPYRIGHT "Copyright (c) 1995, compuPage, Inc."
#endif /* COPYRIGHT */

/* glob */
char **glob_filename (char *pathname);
/* lex external */
extern char yytext[];
extern int yylex(void);

LSPECPTR lspec_new ( char *name );
void lspec_destroy ( LSPECPTR x );
LSPECPTR lspec_add ( LSPECPTR x , LSPECPTR *root );
void lspec_rem ( LSPECPTR *root );
void lspec_list ( char *what , LSPECPTR x , int spaces );
LSPECPTR lspec_find ( LSPECPTR x , LSPECPTR *root );
LSPECPTR lspec_find_name ( char *name , LSPECPTR *root );
void lspec_remove ( char *name , LSPECPTR *root );

void dump_header ( FILE *outf , char *data[] );
int parse_file ( char *filespec, char *file , char *ext , int size);
int remlister ( char *name , LSPECPTR *x );
int isType ( char *name , char type );
int isTypeStr ( char *name , char *type );
int isBuildable ( char *name );

/* generate Makefile for linux */
int e1_gen_linux ( FILE *outf );

/*
 * exe ( executable , src-filespec-list , lib-list )
 */
int do_exe( void );
/*
 *    obj ( src-filespec-list )
 */
int do_obj( void );
/*
 *    lib ( name , contents )
 */
int do_lib( void );
/*
 * install ( directory , src-filespec-list , chown chgrp "chmod" )
 */
int do_install( void );
/*
 * man ( src-filespec-list )
 */
int do_man( void );
/*
 * doc ( doc-file , src-filespec-list [ , lib-list ] )
 *
 *    next -> next -> next
 *    | | |
 *    | | - name -> doc-file
 *    | |-- auxRoot -> src-filespec-list
 *    |---- libRoot -> lib-list
 *
 */
int do_doc( void );

/*
 * kit ( kit-name , file-list )
 *
 *    next -> next -> ...
 *    |  |
 *    |  |-> auxNext -> file-list
 *    |
 *    |-> name -> kit-name
 */
int do_kit( void );

/*
 * move ( directory , src-filespec-list , chown chgrp "chmod" )
 *
 * FILE moved
 *
 *    next -> next ->
 *     | |
 *     | -> filespec
 *     |
 *     -> auxNext -> directory
 *     |
 *     -> libNext -> chown -> chgrp -> chmod
 *
 */
int do_move( void );

/*
 * softlink ( directory , src-filespec-list )
 *
 *    next -> next ->
 *     | |
 *     | -> filespec
 *     |
 *     -> auxNext -> directory
 *
 */
int do_softlink( void );

/* made targets, clean them up during clean: */
extern LSPECPTR clean_root;

/* make these objs */
extern LSPECPTR objs_root;

/* list of things for depend */
extern LSPECPTR depend_root;

/* list of things for all */
extern LSPECPTR all_root;

/* build dependancies temp */
extern LSPECPTR temp_root;

/* depend dependancies */
extern LSPECPTR depend_dep_root;

/* exe root */
extern LSPECPTR exe_root;

/* lib root */
extern LSPECPTR lib_root;

/* cflags */
extern LSPECPTR cflags_root;

/* install */
extern LSPECPTR install_root;

/* man */
extern LSPECPTR man_root;

/* doc */
extern LSPECPTR doc_root;

/* kit */
extern LSPECPTR kit_root;

/* move */
extern LSPECPTR move_root;

/* softlink */
extern LSPECPTR softlink_root;

/* e1_dollar.c */
  /* parse and define a constant */
int e1_define_dollar ( char *txt );
  /*
   * If 'txt' begins with '$', try to translate it
   */
char *e1_trans_dollar ( char *txt );

#define YYTEXT e1_trans_dollar ( yytext )

/* show dollar_root */
void e1_show_dollar ( void );

#endif /* __LSPEC_H__ */


