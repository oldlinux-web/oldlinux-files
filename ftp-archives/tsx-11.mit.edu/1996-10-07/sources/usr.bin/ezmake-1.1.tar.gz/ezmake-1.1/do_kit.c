#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <assert.h>

#include "e1.h"
#include "lspec.h"

#ifdef RCSID
static char rcsid[] = "$Id: do_kit.c,v 1.4 1995/11/18 22:11:42 root Exp $";
#endif /* RCSID */

#ifdef COPYRIGHT

/*
 * Copyright (c), 1995, compuPage, Inc.
 * All Rights Reserved, Cal Page, <root@lorax.mv.com>
 *
 * This software comes with ABSOLUTELY NO WARRANTY.
 *
 * This software is released under the GPL, see
 * COPYING in source directory for further details.
 */

#endif /* COPYRIGHT */

/*
 * kit ( kit-name , file-list )
 *
 *    next -> next -> ...
 *    |  |
 *    |  |-> auxNext -> file-list
 *    |
 *    |-> name -> kit-name
 */
int do_kit( void )
{
    int tok;
    char *filespec,*tmpPtr;
    LSPECPTR tmp;
    char **value;
    int i;

    /* skip '(' */
    tok = yylex();
    if ( tok != E1_TOK_brace )
      {
	  printf("do_kit: missing '('\n");
	  exit(1);
      }

    /* get filespec */
    tok = yylex ();
    if ( tok != E1_TOK_filespec )
      {
	  printf("do_kit: missing or bad filespec = <%s>\n",
		 yytext);
	  exit(1);
      }
    filespec = strdup(YYTEXT);

    /* add to all_root */
    tmp = lspec_add(lspec_new(filespec),&kit_root);

    /* add directory to clean_root */
    tmpPtr = malloc ( strlen(filespec) + 32 );
    assert(tmpPtr!=NULL);
    sprintf(tmpPtr,"-r %s",filespec);
    lspec_add(lspec_new(tmpPtr),&clean_root);

    /* add .tar and .tar.gz to clean root */
    sprintf(tmpPtr,"%s.tar",filespec);
    lspec_add(lspec_new(tmpPtr),&clean_root);
    sprintf(tmpPtr,"%s.tar.gz",filespec);
    lspec_add(lspec_new(tmpPtr),&clean_root);

    /* free tmpPtr */
    free(tmpPtr);
    
    tok = yylex ();
    if ( tok != E1_TOK_comma )
      {
	  printf("do_kit: missing comma <%s>\n",
		 yytext);
	  exit(1);
      }

    /* get src file list */
    while ( 1 )
      {
	  tok = yylex();

	  /* are we done ??? */
	  if ( (tok == E1_TOK_comma) ||
               (tok == E1_TOK_brace_close) )
	    break;

	  if ( tok != E1_TOK_filespec )
	    {
		printf("do_kit: missing or bad filespec = <%s>\n",
		       yytext);
		exit(1);
	    }

	  /* remove any that are necessary */
	  if ( remlister ( YYTEXT , &tmp->auxNext ) )
	    continue;

	  if ( !isBuildable(YYTEXT) )
	    /* don't glob things we can't build */
	    lspec_add(lspec_new(YYTEXT),&tmp->auxNext);
	  else
	    {
		value = glob_filename ( YYTEXT );
		if ( value == NULL )
		  {
		      printf("out of memory\n");
		      exit(1);
		  }
		else if ((int) value == -1)
		  perror ( yytext );
		else
		  for (i = 0; value[i] != NULL; i++)
		    {
			lspec_add(lspec_new(value[i]),&tmp->auxNext);
		    }
	    }
      }

    free(filespec);
    return 1;
}
