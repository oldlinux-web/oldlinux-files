#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <assert.h>

#include "e1.h"
#include "lspec.h"

#ifdef RCSID
static char rcsid[] = "$Id: do_move.c,v 1.2 1995/11/18 22:11:42 root Exp $";
#endif /* RCSID */

#ifdef COPYRIGHT

/*
 * Copyright (c), 1995, compuPage, Inc.
 * All Rights Reserved, Cal Page, <root@lorax.mv.com>
 *
 * This software comes with ABSOLUTELY NO WARRANTY.
 *
 * This software is released under the GPL, see
 * COPYING in source directory for further details.
 */

#endif /* COPYRIGHT */

/*
 * move ( directory , src-filespec-list , chown chgrp "chmod" )
 *
 * FILE moved
 *
 *    next -> next ->
 *     | |
 *     | -> filespec
 *     |
 *     -> auxNext -> directory
 *     |
 *     -> libNext -> chown -> chgrp -> chmod
 *
 */
int do_move( void )
{
    int tok;
    char *directory;
    LSPECPTR tmp = NULL;
    LSPECPTR x;
    char **value;
    int i;

    char *tmp_chown;
    char *tmp_chgrp;
    char *tmp_chmod;

    /* skip '(' */
    tok = yylex();
    if ( tok != E1_TOK_brace )
      {
	  printf("do_move: missing '('\n");
	  exit(1);
      }

    /* get directory */
    tok = yylex ();
    if ( tok != E1_TOK_filespec )
      {
	  printf("do_move: missing or bad directory = <%s>\n",
		 yytext);
	  exit(1);
      }
    directory = strdup(YYTEXT);

    tok = yylex ();
    if ( tok != E1_TOK_comma )
      {
	  printf("do_move: missing comma <%s>\n",
		 yytext);
	  exit(1);
      }

    /* get filespec-list */
    while ( 1 )
      {
	  tok = yylex();

	  /* are we done ??? */
	  if ( tok == E1_TOK_comma )
	    break;

	  if ( tok != E1_TOK_filespec )
	    {
		printf("do_move: missing or bad filespec = <%s>\n",
		       yytext);
		exit(1);
	    }

	  /* remove any that are necessary */
	  if ( remlister ( YYTEXT , &tmp ) )
	    continue;

	  value = glob_filename ( YYTEXT );
	  if ( value == NULL )
	    {
		printf("do_move: out of memory\n");
		exit(1);
	    }
	  else if ((int) value == -1)
	    perror ( yytext );
	  else
	    {
		if ( value[0] == NULL )
		  {
		      /* just add file as glob could not find it */
		      lspec_add(lspec_new(YYTEXT),&tmp);
		  }
		else
		  {
		      for (i = 0; value[i] != NULL; i++)
			{
			    lspec_add(lspec_new(value[i]),&tmp);
			}
		  }
	    }
      }

    /* get chown */
    tok = yylex ();
    if ( tok != E1_TOK_filespec )
      {
	  printf("do_move: missing chown <%s>\n",
		 yytext);
	  exit(1);
      }
    tmp_chown = strdup(YYTEXT);

    /* get chgrp */
    tok = yylex ();
    if ( tok != E1_TOK_filespec )
      {
	  printf("do_move: missing chgrp <%s>\n",
		 yytext);
	  exit(1);
      }
    tmp_chgrp = strdup(YYTEXT);

    /* get chmod */
    tok = yylex ();
    if ( tok != E1_TOK_string )
      {
	  printf("do_move: missing chmod <%s>\n",
		 yytext);
	  exit(1);
      }
    tmp_chmod = strdup(YYTEXT);

    tok = yylex ();
    if ( tok != E1_TOK_brace_close )
      {
	  printf("do_move: missing ')' in <%s>\n",
		 yytext);
	  exit(1);
      }

    if ( tmp == NULL )
      {
	  /* just a directory */
	  x = lspec_add(lspec_new(directory),&move_root);

	  lspec_add(lspec_new(tmp_chown),&x->libNext);
	  lspec_add(lspec_new(tmp_chgrp),&x->libNext);
	  lspec_add(lspec_new(tmp_chmod),&x->libNext);
      }
    else
      {
	  while ( tmp != NULL )
	    {
		LSPECPTR y;

		lspec_add(lspec_new(directory),&tmp->auxNext);
		lspec_add(lspec_new(tmp_chown),&tmp->libNext);
		lspec_add(lspec_new(tmp_chgrp),&tmp->libNext);
		lspec_add(lspec_new(tmp_chmod),&tmp->libNext);

		/* unlink this one from tmp chain */
		y = tmp;
		tmp = tmp->next;

		/* add to perm chain at move_root */
		lspec_add(y,&move_root);
	    }
      }

    /* free resources */
    free(directory);
    free(tmp_chmod);
    free(tmp_chgrp);
    free(tmp_chown);

    /* return to caller */
    return 1;
}
