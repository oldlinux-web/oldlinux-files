#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <assert.h>
#include <ctype.h>
#include <unistd.h>

#include "e1.h"
#include "lspec.h"

#ifdef RCSID
static char rcsid[] = "$Id: e1_linux.c,v 1.24 1995/11/17 13:51:51 root Exp $";
#endif /* RCSID */

#ifdef COPYRIGHT

/*
 * Copyright (c), 1995, compuPage, Inc.
 * All Rights Reserved, Cal Page, <root@lorax.mv.com>
 *
 * This software comes with ABSOLUTELY NO WARRANTY.
 *
 * This software is released under the GPL, see
 * COPYING in source directory for further details.
 */

#endif /* COPYRIGHT */

/* a static root */
static LSPECPTR static_root = NULL;

/* undef if you don't want lorder called */
/* #define USE_LORDER */

/* maximum file size */
#define FILE_SIZE 256

static char *(header[]) = {
    "#",
    "# Copyright (c) 1995, compuPage, Inc.",
    "# $I" "d$",
    "#",
    "VERSION = 1",
    "PATCHLEVEL = 1",
    "SUBLEVEL = 1",
    "",
    "ARCH = i386",
    "",
    ".EXPORT_ALL_VARIABLES:",
    "",
    ".SUFFIXES: .pod .man .c .o .l",
    "",
    "AS	=as",
    "LEX	=lex",
    "LD	=ld",
    "CC	=gcc",
    "MAKE	=make",
    "CPP	=$(CC) -E",
    "RANLIB	=ranlib",
    "AR	=ar",
    "NM	=nm",
    "POD2MAN	=pod2man",
    "STRIP	=strip",
    "RM	= rm",
    "INSTALL	=install",
    "CP	=cp",
    "CD	=cd",
    "TAR	=tar",
    "GZIP	=gzip",
    "PERL5	=perl5",
    "SOFTLINK	=ln -f -s",
    "",
    ".c.o:",
    "\t$(CC) $(CFLAGS) -c $*.c",
    "",
    ".l.c:",
    "\t$(LEX) -t $*.l >$*.c",
    "",
    ".pod.man:",
    "\t$(PERL5) /usr/local/bin/pod2man $*.pod >$*.man",
    "",
    NULL };

static char *(trailer[]) = {
    "ifeq (.depend,$(wildcard .depend))",
    "include .depend",
    "endif",
    "",
    NULL };

static void
do_c ( FILE *outf , char *file , char *ext , char *work , LSPECPTR y )
{
    /* add to clean root */
    sprintf(work,"%s.o",file);
    lspec_add(lspec_new(work),&clean_root);

    /* add to depend root */
    lspec_add(lspec_new(y->name),&depend_root);

    /* add to temp root */
    sprintf(work,"%s.o : %s",file,y->name);
    lspec_add(lspec_new(work),&temp_root);
}

static void
do_pod ( FILE *outf , char *file , char *ext , char *work , LSPECPTR y )
{
    /* add to clean root */
    sprintf(work,"%s.man",file);
    lspec_add(lspec_new(work),&clean_root);

    /* add to temp root */
    sprintf(work,"%s.man : %s",file,y->name);
    lspec_add(lspec_new(work),&temp_root);
}

static void
do_l ( FILE *outf , char *file , char *ext , char *work , LSPECPTR y )
{
    /* add to clean root, both .c and .o are cleaned */
    sprintf(work,"%s.c",file);
    lspec_add(lspec_new(work),&clean_root);
    sprintf(work,"%s.o",file);
    lspec_add(lspec_new(work),&clean_root);

    /* add C file to depend root */
    sprintf(work,"%s.c",file);
    lspec_add(lspec_new(work),&depend_root);

    /* add to temp root */
    sprintf(work,"%s.c : %s",file,y->name);
    lspec_add(lspec_new(work),&temp_root);
    sprintf(work,"%s.o : %s.c",file,file);
    lspec_add(lspec_new(work),&temp_root);

    /* add to depend_dep_root */
    sprintf(work,"%s.c",file);
    lspec_add(lspec_new(work),&depend_dep_root);
}

static void
e1_gen_man ( FILE *outf ,
             char *c_mode,   /* mode     */
	     char *c_chown,  /* chown    */
	     char *c_chgrp,  /* chgrp    */
	     char *c_src,    /* src file */
	     char *c_path,   /* path     */
	     char *file , char *ext , char *work
	    )
{
    char new_ext[32];
    char *dst,*c;
    int cnt;

    /* get new_ext from path */
    cnt = sizeof(new_ext) - 2;
    dst = new_ext;
    c = &c_path[strlen(c_path)-1]; /* pts to last char */
    while ( !isdigit(*c) ) {
	if ( c == c_path )
	  break;
	c--;
    }
    while ( isdigit(*c) ) {
	if ( c == c_path )
	  break;
	c--;
    }
    if ( c != c_path )
      c++;
    while ( cnt-- > 0 )
      *dst++ = *c++;
    *dst = 0;

    /* break up file name */
    parse_file ( c_src , file , ext , FILE_SIZE );

    /* make our target name */
    sprintf(work,"%s.%s",file,new_ext);

    /* generate code */
    fprintf(outf,"\t$(CP) %s %s\n",c_src,work);
    fprintf(outf,"\t$(INSTALL) ");
    if ( strlen(c_mode) > 2 )
      fprintf(outf,"--mode %s ",c_mode);
    fprintf(outf,"--owner %s --group %s %s %s/%s\n",
	    c_chown,
	    c_chgrp,
	    work,
	    c_path,
	    work );

    /* add newly created file to clean root */
    sprintf(work,"%s",work);
    lspec_add(lspec_new(work),&clean_root);
}

/* generate Makefile for linux */
int
e1_gen_linux ( FILE *outf )
{
    LSPECPTR x;
    LSPECPTR y;
    LSPECPTR z;
    char file[FILE_SIZE],ext[FILE_SIZE],work[FILE_SIZE];
    int cnt;
    char *cwdPtr = NULL; /* points to current working directory */

    /* get cwdPtr */
    cwdPtr = getcwd ( NULL , 0 );
    /* fprintf(stderr,"cwdPtr = <%s>\n",cwdPtr); */

/*    lspec_list ( "exe_root" , exe_root , 0 ); */
/*    lspec_list ( "lib_root" , lib_root , 0 ); */
/*    lspec_list ( "install_root" , install_root , 0 ); */

    dump_header(outf,header);

    /* dump cflags_root */
    x = cflags_root;
    fprintf(outf,"CFLAGS=-Wall ");
    while ( x != NULL )
      {
	  fprintf(outf,"%s ",x->name);
	  x = x->next;
      }
    fprintf(outf,"\n");

    /* scan man root */
    x = man_root;
    while ( x != NULL )
      {
	  parse_file ( x->name , file , ext , sizeof(file) );

	  if ( strcmp(ext,"pod") != 0 )
	    {
		printf("Don't know how to make man file from <%s>\n",
		       x->name);
	    }
	  else
	    do_pod ( outf, file , ext , work , x );

	  /* onward */
	  x = x->next;
      }

    /* scan lib's root */
    x = lib_root;
    while ( x != NULL )
      {
	  /* add to all root */
	  sprintf(work,"lib%s.a",x->name);
	  lspec_add(lspec_new(work),&all_root);
	  /* add to clean list too */
	  lspec_add(lspec_new(work),&clean_root);

	  /* process all source files */
	  y = x->auxNext;
	  while ( y != NULL )
	    {
		parse_file ( y->name , file , ext , sizeof(file) );

		if ( strcmp(ext,"o") == 0 )
		  {
		      sprintf(work,"%s.o",file);
		      lspec_add(lspec_new(work),&x->libNext);

		      /* already compiled, just accept */
		      y = y->next;
		      continue;
		  }

		if ( strcmp(ext,"h") == 0 )
		  {
		      /* don't build headers */
		      y = y->next;
		      continue;
		  }

		if ( strcmp(ext,"c") == 0 )
		  {
		      do_c ( outf, file , ext , work , y );

		      sprintf(work,"%s.o",file);
		      lspec_add(lspec_new(work),&x->libNext);

		      /* onward */
		      y = y->next;
		      continue;
		  }

		if ( strcmp(ext,"l") == 0 )
		  {
		      /* use lex -> c -> gcc -> .o */
		      do_l ( outf, file , ext , work , y );

		      sprintf(work,"%s.o",file);
		      lspec_add(lspec_new(work),&x->libNext);

		      /* onward */
		      y = y->next;
		      continue;
		  }

		printf("I don't know how to build <%s>\n",y->name);
		y = y->next;
	    }

	  /* build string of form:
	   *
	   *   LIB_name = filelist
	   */
	  y = x->libNext;

/* number of files per line */
#define MAXX 6

	  cnt = MAXX;
	  fprintf(outf,"LIB_%s = \\\n",x->name);
	  while ( y != NULL )
	    {
		if ( cnt == MAXX )
		  fprintf(outf,"\t");

		fprintf(outf,"%s",y->name);

		if ( --cnt <= 0 )
		  {
		      if ( y->next != NULL )
			fprintf(outf," \\\n");
		      else
			fprintf(outf,"\n");

		      cnt = MAXX;
		  }
		else
		  fprintf(outf," ");

		y = y->next;
	    }
	  if ( cnt != MAXX )
	    fprintf(outf,"\n");

	  x = x->next;
      }

    /* scan exe's root */
    x = exe_root;
    while ( x != NULL )
      {
	  /* add to all root */
	  lspec_add(lspec_new(x->name),&all_root);

	  /* process all source files */
	  y = x->auxNext;
	  while ( y != NULL )
	    {
		parse_file ( y->name , file , ext , sizeof(file) );

		if ( strcmp(ext,"o") == 0 )
		  {
		      /* already compiled, just accept */
		      y = y->next;
		      continue;
		  }

		if ( strcmp(ext,"a") == 0 )
		  {
		      /* already compiled, just accept */
		      y = y->next;
		      continue;
		  }

		if ( strcmp(ext,"h") == 0 )
		  {
		      /* don't build headers */
		      y = y->next;
		      continue;
		  }

		if ( strcmp(ext,"c") == 0 )
		  {
		      do_c ( outf, file , ext , work , y );

		      /* onward */
		      y = y->next;
		      continue;
		  }

		if ( strcmp(ext,"l") == 0 )
		  {
		      /* use lex -> c -> gcc -> .o */
		      do_l ( outf, file , ext , work , y );

		      /* onward */
		      y = y->next;
		      continue;
		  }

		printf("I don't know how to build <%s>\n",y->name);
		y = y->next;
	    }
	  x = x->next;
      }

    /* scan obj's root */
    x = objs_root;
    while ( x != NULL )
      {
	  parse_file ( x->name , file , ext , sizeof(file) );

	  if ( strcmp(ext,"h") == 0 )
	    {
		/* don't build headers */
		x = x->next;
		continue;
	    }

	  if ( strcmp(ext,"c") == 0 )
	    {
		/* add to all root */
		sprintf(work,"%s.o",file);
		lspec_add(lspec_new(work),&all_root);

		/* add '.o' to auxNext */
		lspec_add(lspec_new(work),&x->auxNext);

		do_c ( outf, file , ext , work , x );

		/* onward */
		x = x->next;
		continue;
	    }

	  if ( strcmp(ext,"l") == 0 )
	    {
		/* use lex -> c -> gcc -> .o */

		/* add to all root */
		sprintf(work,"%s.o",file);
		lspec_add(lspec_new(work),&all_root);

		/* add '.o' to auxNext */
		lspec_add(lspec_new(work),&x->auxNext);

		do_l ( outf, file , ext , work , x );

		/* onward */
		x = x->next;
		continue;
	    }

	  printf("I don't know how to build <%s>\n",x->name);
	  x = x->next;
      }

    /* make all: */
    fprintf(outf,"\n");
    fprintf(outf,"all: ");
    x = all_root;
    while ( x != NULL )
      {
	  fprintf(outf,"%s ",x->name);
	  x = x->next;
      }
    fprintf(outf,"\n");

    /* build libraries of the form
     *
     *   lib : liblist 
     */
    x = lib_root;
    fprintf(outf,"\nlib: ");
    while ( x != NULL )
      {
	  sprintf(work,"lib%s.a",x->name);
	  fprintf(outf,"%s ",work);
	  x = x->next;
      }
    fprintf(outf,"\n\n");

    /* build .o's of the form
     *
     *    obj : o's-list
     */
    x = objs_root;
    fprintf(outf,"\nobj: ");
    while ( x != NULL )
      {
	  fprintf(outf,"%s ",x->auxNext->name);
	  x = x->next;
      }
    fprintf(outf,"\n\n");

    /* build exe's of the form
     *
     *    exe : exe-list
     */
    x = exe_root;
    fprintf(outf,"\nexe: ");
    while ( x != NULL )
      {
	  fprintf(outf,"%s ",x->name);
	  x = x->next;
      }
    fprintf(outf,"\n\n");

    /* build libraries of the form
     *
     *  libXXX.a : LIB_NAME
     */
    x = lib_root;
    while ( x != NULL )
      {
	  fprintf(outf,"\nlib%s.a: ${LIB_%s}\n",x->name,x->name);
	  fprintf(outf,"\t$(RM) -f $@\n");

#ifdef USE_LORDER
	  fprintf(outf,"\t$(AR) cq $@ `lorder ${LIB_%s} | tsort`\n",x->name);
#else
	  fprintf(outf,"\t$(AR) cq $@ ${LIB_%s}\n",x->name);
#endif /* USE_LORDER */

	  fprintf(outf,"\t$(RANLIB) $@\n");
	  fprintf(outf,"\n");

#ifdef JUNK
	  y = x->libNext;
	  while ( y != NULL )
	    {
		fprintf(outf,"%s ",y->name);
		y = y->next;
	    }
	  fprintf(outf,"\n");
#endif

	  x = x->next;
      }

    /* build any executables */
    x = exe_root;
    while ( x != NULL )
      {
	  /* zero a working root */
	  lspec_rem ( &static_root );

	  fprintf(outf,"\n");
	  fprintf(outf,"%s: ",x->name);
	  y = x->auxNext;
	  while ( y != NULL )
	    {
		if ( isBuildable ( y->name ) )
		  {
		      parse_file ( y->name , file , ext , sizeof(file) );
		      sprintf(work,"%s.o",file);
		      lspec_add(lspec_new(work),&static_root);
		  }
		else
		  {
		      lspec_add(lspec_new(y->name),&static_root);
		  }
		y = y->next;
	    }
	  y = static_root;
	  while ( y != NULL )
	    {
		fprintf(outf,"%s ",y->name);
		y = y->next;
	    }
	  fprintf(outf,"\n");

	  fprintf(outf,"\t$(CC) $(CFLAGS) -o %s ",x->name);
	  y = static_root;
	  while ( y != NULL )
	    {
		fprintf(outf,"%s ",y->name);
		y = y->next;
	    }
	  /* do libNext */
	  y = x->libNext;
	  while ( y != NULL )
	    {
		fprintf(outf,"%s ",y->name);
		y = y->next;
	    }
	  fprintf(outf,"\n");

	  x = x->next;
      }

    /* make install: */
    fprintf(outf,"\n");
    fprintf(outf,"install: ");
    x = install_root;
    while ( x != NULL )
      {
	  if ( x->auxNext != NULL )
	    /* don't put directories on dependancy string */
	    fprintf(outf,"%s ",x->name);
	  x = x->next;
      }
    fprintf(outf,"\n");

    x = install_root;
    while ( x != NULL )
      {
	  /* check for directory creation */
	  y = x->auxNext;
	  z = x->libNext;

	  if ( y == NULL )
	    {
		/* create a directory */
		if ( strlen(z->next->next->name) == 2 )
		  fprintf(outf,"\t$(INSTALL) --owner %s --group %s --directory %s\n",
			z->name,
			z->next->name,
			x->name );
		else
		  fprintf(outf,"\t$(INSTALL) --mode %s --owner %s --group %s --directory %s\n",
			z->next->next->name,
			z->name,
			z->next->name,
			x->name );
	    }
	  else
	    {
		/* no directory, just install a file */

		/* rename *.man as *.[1-9] and copy to that directory */
		if ( isTypeStr ( x->name , "man" ) )
		  {
		      /* generate code for man instalation */
		      e1_gen_man ( outf ,
			z->next->next->name,   /* mode     */
			z->name,               /* chown    */
			z->next->name,         /* chgrp    */
			x->name,               /* src file */
			y->name,               /* path     */
			file,ext,work
				  );
		  }
		else
		  {
		      /* generate code */
		      if ( strlen(z->next->next->name) == 2 )
			/* no mode switch */
			fprintf(outf,"\t$(INSTALL) --strip --owner %s --group %s %s %s/%s\n",
				z->name,
				z->next->name,
				x->name,
				y->name,
				x->name);
		      else
			/* with mode switch */
			fprintf(outf,"\t$(INSTALL) --strip --mode %s --owner %s --group %s %s %s/%s\n",
				z->next->next->name, /* mode     */
				z->name,             /* chown    */
				z->next->name,       /* chgrp    */
				x->name,             /* src file */
				y->name,             /* path     */
				x->name);
		  }
	    }
	  x = x->next;
      }
    fprintf(outf,"\n");

    /* make move: */
    fprintf(outf,"\n");
    fprintf(outf,"move: ");
    x = move_root;
    while ( x != NULL )
      {
	  if ( x->auxNext != NULL )
	    /* don't put directories on dependancy string */
	    fprintf(outf,"%s ",x->name);
	  x = x->next;
      }
    fprintf(outf,"\n");

    x = move_root;
    while ( x != NULL )
      {
	  /* check for directory creation */
	  y = x->auxNext;
	  z = x->libNext;

	  if ( y == NULL )
	    {
		/* create a directory */
		if ( strlen(z->next->next->name) == 2 )
		  fprintf(outf,"\t$(INSTALL) --owner %s --group %s --directory %s\n",
			z->name,
			z->next->name,
			x->name );
		else
		  fprintf(outf,"\t$(INSTALL) --mode %s --owner %s --group %s --directory %s\n",
			z->next->next->name,
			z->name,
			z->next->name,
			x->name );
	    }
	  else
	    {
		/* no directory, just install a file */
		if ( strlen(z->next->next->name) == 2 )
		  /* no mode switch */
		  fprintf(outf,"\t$(INSTALL) --owner %s --group %s %s %s/%s\n",
			  z->name,
			  z->next->name,
			  x->name,
			  y->name,
			  x->name);
		else
		  /* with mode switch */
		  fprintf(outf,"\t$(INSTALL) --mode %s --owner %s --group %s %s %s/%s\n",
			  z->next->next->name, /* mode     */
			  z->name, /* chown    */
			  z->next->name, /* chgrp    */
			  x->name, /* src file */
			  y->name, /* path     */
			  x->name);
	    }
	  x = x->next;
      }
    fprintf(outf,"\n");

    /* make move: */
    fprintf(outf,"\n");
    fprintf(outf,"softlink: ");
    x = softlink_root;
    while ( x != NULL )
      {
	  if ( x->auxNext != NULL )
	    /* don't put directories on dependancy string */
	    fprintf(outf,"%s ",x->name);
	  x = x->next;
      }
    fprintf(outf,"\n");
    x = softlink_root;
    while ( x != NULL )
      {
	  char *nameExistingFile;
	  char *nameNew;
	  
	  nameExistingFile = (char *)malloc(strlen(x->name)+strlen(cwdPtr)+2);
	  assert(nameExistingFile!=NULL);
	  sprintf(nameExistingFile,"%s/%s",cwdPtr,x->name);

	  nameNew = (char *)malloc(strlen(x->name)+strlen(x->auxNext->name)+2);
	  assert(nameExistingFile!=NULL);
	  sprintf(nameNew,"%s/%s",x->auxNext->name,x->name);

	  fprintf(outf,"\t$(SOFTLINK) %s %s\n",
		  nameExistingFile,
		  nameNew );

	  /* onward */
	  free(nameExistingFile);
	  free(nameNew);
	  x = x->next;
      }
    fprintf(outf,"\n");

    /* make doc: */
    fprintf(outf,"\n");
    fprintf(outf,"doc: ");
    x = doc_root;
    while ( x != NULL )
      {
	  fprintf(outf,"%s ",x->name);
	  x = x->next;
      }
    fprintf(outf,"\n\n");

    /* make man: */
    fprintf(outf,"\n");
    fprintf(outf,"man: ");
    x = man_root;
    while ( x != NULL )
      {
	  parse_file ( x->name , file , ext , sizeof(file) );
	  if ( strcmp(ext,"pod") == 0 )
	    {
		sprintf(work,"%s.man",file);
		fprintf(outf,"%s ",work);
	    }
	  x = x->next;
      }
    fprintf(outf,"\n\n");

    /* make kit */
    fprintf(outf,"\n");
    fprintf(outf,"kit: ");
    x = kit_root;
    while ( x != NULL ) {
	y = x->auxNext;
	while ( y != NULL ) {
	    fprintf(outf,"%s ",y->name);
	    y = y->next;
	}
	x = x->next;
    }
    fprintf(outf,"\n");
    x = kit_root;
    while ( x != NULL ) {
	fprintf(outf,"\t$(RM) -f %s.tar\n",x->name);
	fprintf(outf,"\t$(RM) -f %s.tar.gz\n",x->name);
	fprintf(outf,"\t$(RM) -rf %s\n",x->name);
	fprintf(outf,"\t$(INSTALL) --directory %s\n",x->name );
	x = x->next;
    }
    x = kit_root;
    while ( x != NULL ) {
	y = x->auxNext;
	while ( y != NULL ) {
	    fprintf(outf,"\t$(CP) %s %s/.\n",y->name,x->name);
	    y = y->next;
	}
	x = x->next;
    }
    x = kit_root;
    while ( x != NULL ) {
	fprintf(outf,"\t$(TAR) -cvf %s.tar %s\n",x->name,x->name );
#ifdef JUNK
	fprintf(outf,"\t$(GZIP) %s.tar\n",x->name );
#endif
	x = x->next;
    }
    fprintf(outf,"\n");

    /* make clean: */
    fprintf(outf,"\n");
    fprintf(outf,"clean:\n");
    fprintf(outf,"\t$(RM) -f .depend *~ *# *.bak build.log\n");
    x = clean_root;
    while ( x != NULL )
      {
	  fprintf(outf,"\t$(RM) -f %s\n",x->name);
	  x = x->next;
      }

    /* make depend: */
    fprintf(outf,"\n");
    fprintf(outf,"depend: ");
    x = depend_dep_root;
    while ( x != NULL )
      {
	  fprintf(outf,"%s ",x->name);
	  x = x->next;
      }
    fprintf(outf,"\n");

    x = depend_root;
    if ( x != NULL )
      {
	  fprintf(outf,"\t$(CC) $(CFLAGS) -E -MM ");
	  while ( x != NULL )
	    {
		fprintf(outf,"%s ",x->name);
		x = x->next;
	    }
	  fprintf(outf,">.depend\n");
      }
    else
      fprintf(outf,"\n");

    /* expand temp_root */
    fprintf(outf,"\n");
    x = temp_root;
    while ( x != NULL )
      {
	  fprintf(outf,"%s\n\n",x->name);
	  x = x->next;
      }

    fprintf(outf,"\n");

    dump_header(outf,trailer);

    if ( cwdPtr != NULL )
      free(cwdPtr);

    /* return to caller */
    return 0;
}

