#ifndef lint
static char *RCSid = "$Id: doc2hlp.c,v 1.9 1995/11/29 17:54:48 drd Exp $";
#endif


/*
 * doc2hlp.c  -- program to convert Gnuplot .DOC format to 
 * VMS help (.HLP) format.
 *
 * This involves stripping all lines with a leading ?,
 * @, #, or %.
 * Modified by Russell Lang from hlp2ms.c by Thomas Williams 
 *
 * usage:  doc2hlp [file.doc [file.hlp]]
 *
 * Original version by David Kotz used the following one line script!
 * sed '/^[?@#%]/d' file.doc > file.hlp
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#include "ansichek.h"

#define MAX_LINE_LEN	256
#define TRUE 1
#define FALSE 0

int main __P(( int argc, char **argv ));
void convert __P(( FILE *a, FILE *b ));
void process_line __P(( char *line, FILE *b ));

#include "termdoc.c"

int main(argc,argv)
int argc;
char **argv;
{
FILE * infile;
FILE * outfile;
	infile = stdin;
	outfile = stdout;
	if (argc > 3) {
		fprintf(stderr,"Usage: %s [infile [outfile]]\n", argv[0]);
		exit(1);
	}
	if (argc >= 2) 
		if ( (infile = fopen(argv[1],"r")) == (FILE *)NULL) {
			fprintf(stderr,"%s: Can't open %s for reading\n",
				argv[0], argv[1]);
			exit(1);
		}
	if (argc == 3)
		if ( (outfile = fopen(argv[2],"w")) == (FILE *)NULL) {
			fprintf(stderr,"%s: Can't open %s for writing\n",
				argv[0], argv[2]);
		}
	
	convert(infile,outfile);
	exit(0);
	return 0;
}


void convert(a,b)
	FILE *a,*b;
{
    static char line[MAX_LINE_LEN];

    while (fgets(line,MAX_LINE_LEN,a)) {
	   process_line(line, b);
    }
}

void process_line(line, b)
	char *line;
	FILE *b;
{
    static int line_count = 0;

    line_count++;

    switch(line[0]) {		/* control character */
	   case '?': {			/* interactive help entry */
		  break;			/* ignore */
	   }
	   case '@': {			/* start/end table */
		  break;			/* ignore */
	   }
	   case '#': {			/* latex table entry */
		  break;			/* ignore */
	   }
	   case '%': {			/* troff table entry */
		  break;			/* ignore */
	   }
	   case '^': {			/* html entry */
		  break;			/* ignore */
	   }
	   case '\n':			/* empty text line */
	   case ' ': {			/* normal text line */
		  (void) fputs(line,b); 
		  break;
	   }
	   default: {
		  if (isdigit(line[0])) { /* start of section */
			(void) fputs(line,b); 
		  } else
		    fprintf(stderr, "unknown control code '%c' in column 1, line %d\n", 
				  line[0], line_count);
		  break;
	   }
    }
}
