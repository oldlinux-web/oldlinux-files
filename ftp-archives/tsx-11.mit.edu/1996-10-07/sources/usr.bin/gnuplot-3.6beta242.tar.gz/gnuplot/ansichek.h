/*
 * $Id: ansichek.h,v 1.8 1995/05/11 11:59:40 drd Exp $
 *
 */

/* figure out if we can handle ANSI prototypes */

#ifndef ANSI_CHECK
#define ANSI_CHECK

#ifndef AUTOCONF
/* configure already tested the ANSI feature */

#ifdef __STDC__
#if __STDC__
#define ANSI_C
#endif
#endif

#if defined(__TURBOC__) || defined (__PUREC__) || defined (__ZTC__) || defined (_MSC_VER) || (defined(OSK) && defined(_ANSI_EXT))
#define ANSI_C
#endif

#endif /* AUTOCONF */

/* if the system header files use the __P prototype convention (e.g. Linux),
   we just include stdio, since this will define __P correctly */

#ifndef PROTOTYPE__P
#ifdef ANSI_C
#define __P(proto) proto
#else
#define __P(proto) ()
#endif
#else
#include <stdio.h>
#endif

/* generic pointer type. For old compilers this has to be changed to char *,
   but I don't know if there are any CC's that support void and not void * */

#define generic void

#endif /* ANSI_CHECK */
