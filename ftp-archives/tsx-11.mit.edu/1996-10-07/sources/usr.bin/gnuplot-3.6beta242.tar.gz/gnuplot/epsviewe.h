/*
 * $Id: epsviewe.h,v 1.2 1993/09/27 17:08:10 alex Exp $
 *
 */

#import <appkit/Application.h>
#import <appkit/graphics.h>
#import <dpsclient/dpsclient.h>
#import <appkit/Window.h>

@interface EpsViewer:Application
{
	id theNewWin;
}

- windowCreate:(NXCoord)width Height:(NXCoord)height;
- (NXRect *)nextRectForWidth:(NXCoord)width Height:(NXCoord)height;

@end


