/*
 * $Id: alloc.h,v 1.1 1994/09/13 16:11:10 alex Exp $
 */

/* prototypes from "alloc.c". This file figures out if the free hack is needed
 * and redefines free if necessary.
 */

char *alloc __P((unsigned long size, char *message));
generic *ralloc __P((generic *p, unsigned long size, char *message));

#if defined(MSDOS) && defined(__TURBOC__) && !defined(DOSX286) || defined(_Windows) && !defined(WIN32)
#define FARALLOC
void gpfree __P((generic *p));
#define free gpfree
#endif

