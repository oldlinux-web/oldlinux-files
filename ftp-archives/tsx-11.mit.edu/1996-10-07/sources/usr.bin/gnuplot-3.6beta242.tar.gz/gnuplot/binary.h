/*
 * $Id: binary.h,v 1.2 1994/09/13 16:11:21 alex Exp $
 *
 */

/* Copied from command.c -- this should be put in a shared macro file */
#ifndef inrange
#define inrange(z,min,max) ((min<max) ? ((z>=min)&&(z<=max)) : ((z>=max)&&(z<=min)) )
#endif

/* Routines for interfacing with command.c */
float GPFAR *vector __P(( int nl, int nh));
float GPFAR *extend_vector __P((float GPFAR *vec, int old_nl, int old_nh, int new_nh));
float GPFAR *retract_vector __P((float GPFAR *v, int old_nl, int old_nh, int new_nh));
float GPFAR * GPFAR *matrix __P(( int nrl, int nrh, int ncl, int nch));
float GPFAR * GPFAR *extend_matrix __P(( float GPFAR * GPFAR *a, int nrl, int nrh, int ncl, int nch, int srh, int sch));
float GPFAR * GPFAR *retract_matrix __P(( float GPFAR * GPFAR *a, int nrl, int nrh, int ncl, int nch, int srh, int sch));
void free_matrix __P((float GPFAR * GPFAR *m, unsigned nrl, unsigned nrh, unsigned ncl, unsigned nch));
void free_vector __P((float GPFAR *vec, int nl, int nh));
int is_binary_file __P(( FILE *fp));
int fread_matrix __P((FILE *fin, float GPFAR * GPFAR * GPFAR *ret_matrix, int *nr, int *nc, float GPFAR * GPFAR *row_title, float GPFAR * GPFAR *column_title));
int fwrite_matrix __P(( FILE *fout, float GPFAR * GPFAR *m, int nrl, int nrh, int ncl, int nch, float GPFAR *row_title, float GPFAR *column_title));
float GPFAR * GPFAR *convert_matrix __P((float GPFAR *a, int nrl, int nrh, int ncl, int nch));
void free_convert_matrix __P((float GPFAR* GPFAR *b, int nrl, int nrh, int ncl, int nch));
