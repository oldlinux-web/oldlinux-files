/*
 * $Id: fnproto.h,v 1.3 1994/08/28 11:11:47 alex Exp $
 *
 */

/* prototypes for gnuplot function primitives. These functions are not called
   directly, only via a function table.
*/

/* Prototypes from file "internal.c" */

void f_push __P((union argument *x));
void f_pushc __P((union argument *x));
void f_pushd1 __P((union argument *x));
void f_pushd2 __P((union argument *x));
void f_pushd __P((union argument *x));
void f_call __P((union argument *x));
void f_calln __P((union argument *x));
void f_lnot __P((void));
void f_bnot __P((void));
void f_bool __P((void));
void f_lor __P((void));
void f_land __P((void));
void f_bor __P((void));
void f_xor __P((void));
void f_band __P((void));
void f_uminus __P((void));
void f_eq __P((void));
void f_ne __P((void));
void f_gt __P((void));
void f_lt __P((void));
void f_ge __P((void));
void f_le __P((void));
void f_plus __P((void));
void f_minus __P((void));
void f_mult __P((void));
void f_div __P((void));
void f_mod __P((void));
void f_power __P((void));
void f_factorial __P((void));
int f_jump __P((union argument *x));
int f_jumpz __P((union argument *x));
int f_jumpnz __P((union argument *x));
int f_jtern __P((union argument *x));

/* Prototypes from file "standard.c" */

void f_real __P((void));
void f_imag __P((void));
void f_int __P((void));
void f_arg __P((void));
void f_conjg __P((void));
void f_sin __P((void));
void f_cos __P((void));
void f_tan __P((void));
void f_asin __P((void));
void f_acos __P((void));
void f_atan __P((void));
void f_sinh __P((void));
void f_cosh __P((void));
void f_tanh __P((void));
void f_void __P((void));
void f_abs __P((void));
void f_sgn __P((void));
void f_sqrt __P((void));
void f_exp __P((void));
void f_log10 __P((void));
void f_log __P((void));
void f_floor __P((void));
void f_ceil __P((void));
void f_besj0 __P((void));
void f_besj1 __P((void));
void f_besy0 __P((void));
void f_besy1 __P((void));

/* Prototypes from file "specfun.c" */

void f_erf __P((void));
void f_erfc __P((void));
void f_ibeta __P((void));
void f_igamma __P((void));
void f_gamma __P((void));
void f_lgamma __P((void));
void f_rand __P((void));
void f_normal __P((void));
void f_inverse_normal __P((void));
void f_inverse_erf __P((void));

/* prototypes from file "datafile.c" */

void f_dollars __P((union argument *x));
void f_column  __P((void));
void f_valid   __P((void));
