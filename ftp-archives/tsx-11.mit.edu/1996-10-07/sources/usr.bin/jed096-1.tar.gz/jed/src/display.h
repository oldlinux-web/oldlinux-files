/*
 *  Copyright (c) 1992, 1994 John E. Davis  (davis@amy.tch.harvard.edu)
 *  All Rights Reserved.
 */
/*
#define sprintf simple_sprintf
extern char *simple_sprintf(char *, char *, ...);
  */
extern int Scroll_By_Copying;
extern void set_scroll_region(int, int);
extern void reset_scroll_region(void);
extern void goto_rc(int, int);
extern void curs_bol(void);
extern void cursor_forward(int);
extern void cursor_backward(int);
extern void cursor_up(int);
extern void cursor_down(int);
extern void begin_insert(void);
extern void end_insert(void);
extern void tt_del_eol(void);
extern void tt_delete_nlines(int);
extern void tt_delete_char(void);
extern void tt_erase_line(void);
extern void tt_normal_video(void);
extern void set_attribute(int);
extern void cls(void);
extern int beep(void);
extern void reverse_index(int);
extern void smart_puts(unsigned short *, unsigned short *, int, int);
extern void wide_width(void);
extern void narrow_width(void);
extern void send_string_to_term(char *);
extern void tt_putchar(char);
extern int Ignore_Beep;
extern int Term_Cannot_Insert;
extern int Term_Supports_Color;
extern void get_terminfo(void);
#ifdef pc_system
  extern int Attribute_Byte;
# ifndef __GO32__
   extern int Cheap_Video;
   extern void video_off(void);
   extern void video_on(void);
# endif
#else
  extern int Output_Rate;
  extern int Use_Ansi_Colors;
# ifdef unix
   extern void enable_cursor_keys(void);
# endif
  extern void set_term_vtxxx(int *);
#endif
