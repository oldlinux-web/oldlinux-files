/* Changes should be made in Makefile, not to this file! */

#define TMP_DIR "/tmp"
#define REC_DIR "/usr/preserve"
