/***************************************************************************
 * This program is Copyright (C) 1986, 1987, 1988 by Jonathan Payne.  JOVE *
 * is provided to you without charge, and with no warranty.  You may give  *
 * away copies of JOVE, including sources, provided that this notice is    *
 * included in all the files.                                              *
 ***************************************************************************/

#ifdef	LOAD_AV
extern int	get_la proto((void));	/* integer, units of .01 */
extern void	closekmem proto((void));
#endif	/* LOAD_AV */
