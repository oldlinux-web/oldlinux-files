/***************************************************************************
 * This program is Copyright (C) 1986, 1987, 1988 by Jonathan Payne.  JOVE *
 * is provided to you without charge, and with no warranty.  You may give  *
 * away copies of JOVE, including sources, provided that this notice is    *
 * included in all the files.                                              *
 ***************************************************************************/

#include "jove.h"
#include "ttystate.h"

#ifdef	UNIX

# ifdef	BRLUNIX
struct sg_brl	sg[2];
#endif
#ifdef TERMIO
struct termio	sg[2];
#endif
#ifdef TERMIOS
struct termios	sg[2];
#endif
#ifdef SGTTY
struct sgttyb	sg[2];
#endif

# ifdef	TIOCSLTC
struct ltchars	ls[2];
# endif	/* TIOCSLTC */

# ifdef	TIOCGETC
struct tchars	tc[2];
# endif

#endif	/* UNIX */
