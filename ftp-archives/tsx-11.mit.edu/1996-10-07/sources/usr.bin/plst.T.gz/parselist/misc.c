/*
                              Nodelist Parser

              This module was originally written by Bob Hartman
                       Sysop of FidoNet node 1:104/501

 This program source code is being released with the following provisions:

 1.  You are  free to make  changes to this source  code for use on your own
 machine,  however,  altered source files may not be distributed without the
 consent of Spark Software.

 2.  You may distribute "patches"  or  "diff" files for any changes that you
 have made, provided that the "patch" or "diff" files are also sent to Spark
 Software for inclusion in future releases of the entire package.   A "diff"
 file for the source archives may also contain a compiled version,  provided
 it is  clearly marked as not  being created  from the original source code.
 No other  executable  versions may be  distributed without  the  consent of
 Spark Software.

 3.  You are free to include portions of this source code in any program you
 develop, providing:  a) Credit is given to Spark Software for any code that
 may is used, and  b) The resulting program is free to anyone wanting to use
 it, including commercial and government users.

 4.  There is  NO  technical support  available for dealing with this source
 code, or the accompanying executable files.  This source  code  is provided
 as is, with no warranty expressed or implied (I hate legalease).   In other
 words, if you don't know what to do with it,  don't use it,  and if you are
 brave enough to use it, you're on your own.

*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "dos.h"
#include <time.h>
#include <stdlib.h>

#include "types.h"
#include "externs.h"

#ifndef OS2
/* #define dir_findfirst(a,b,c) _dos_findfirst(a,b,c)
#define dir_findnext(a) _dos_findnext(a) */
#define _dos_findfirst(a,b,c) ffirst(a,b,c)
#define _dos_findnext(a) fnext(a)
#endif

int cmp (struct nidxs *a,struct nidxs *b)
{
   if (a->idxnet < b->idxnet)
      {
      return (-1);
      }
   else if (a->idxnet > b->idxnet)
      {
      return (1);
      }
   else
      {
      return (a->idxnode - b->idxnode);
      }
}

/* Returns the next field that ends with a comma or newline */
char *nextfield (char *p,char *s)
{
   while ((*p) && (*p != ',') && (*p != '\n'))
      {
      *s++ = *p++;
      }
   *s = '\0';
   return (++p);
}

/* Converts a "special" word to upper case and appends a space */
void spec_word (char *b1)
{
   char *p1;

   strupr (b1);
   p1 = b1 + strlen (b1);
   *p1++ = ' ';
   *p1 = '\0';
}

/* Uses malloc() to get memory, but exits on allocation error */
char *mymalloc(unsigned int s)
{
   char *p;
  /*  extern char *malloc(); */

   p = malloc (s);
   if (p == NULL)
      {
      printf ("\n\nNot Enough Memory - Exiting\n\n");
      exit (1);
      }
   return (p);
}

/* Gets the name of the nodelist that should be processed this run */
void nfile_name (char **fn)
{
   int i;
   long t;
   struct tm *tm1, *localtime();

   /* Get todays info */
   time (&t);
   tm1 = localtime (&t);

   /* find all NODELIST.* files and if end in number, put in array */
   get_nl_list ();

   for (i = tm1->tm_yday + 1; i >= 0; i--)
      {
      if (nl[i])
         {
         *fn = mymalloc (13);
         sprintf (*fn, "NODELIST.%03d", i);
         return;
         }
      }

   /* If no nodelist files, try last years */
   for (i = 366; i >= tm1->tm_yday; i--)
      {
      if (nl[i])
         {
         *fn = mymalloc (13);
         sprintf (*fn, "NODELIST.%03d", i);
         return;
         }
      }

   /* If still nothing, try the big numbers */
   for (i = 999; i >= 367; i--)
      {
      if (nl[i])
         {
         *fn = mymalloc (13);
         sprintf (*fn, "NODELIST.%03d", i);
         return;
         }
      }

   printf ("\n\nCannot find a valid NODELIST.xxx file - Exiting\n\n");
   exit (1);
}

/* Remove dashes from the string */
void undash (char *str)
{
   char *p, *p1;

   p = str;
   p1 = str;
   while (*p)
      {
      if (*p != '-')
         *p1++ = *p;
      ++p;
      }
   *p1 = '\0';
}

void
get_nl_list ()
{
   char str[13];
   char init_name[13];
   int i, d;

   /* Start out by initializing what we are looking for */
   strcpy (init_name, "NODELIST.*");
   d = 0;

   /* Now loop through getting each file name that matches,
      and copying the number into the array */
   do
      {
      (void) filedir (init_name, d, str, 0);
      i = 0;
      d = 1;
      sscanf (str, "NODELIST.%d", &i);

      if ((i > 0) &&
          (isdigit (str[9])) &&
          (isdigit (str[10])) &&
          (isdigit (str[11])))
         {
         nl[i] = 1;
         }
      }
   while (str[0] != '\0');
}

struct find_t sbuf;

char filedir (char *name,int times,char *ret_str,int mode)
{
    if (times == 0)
        {
#ifndef OS2
        if (_dos_findfirst (name, mode, &sbuf))
#else
        if (dir_findfirst (name, mode, &sbuf))
#endif
            sbuf.name[0] = '\0';
        strcpy (ret_str, sbuf.name);
        }
    else
        {
#ifndef OS2
        if (_dos_findnext (&sbuf))
#else
        if (dir_findnext (&sbuf))
#endif
            sbuf.name[0] = '\0';
        strcpy (ret_str, sbuf.name);
        }

    return 0;
    }

void get_addr (char *s,int *z,int *net,int *node)
{
   if (sscanf (s, "%d:%d/%d", z, net, node) != 3)
      {
      *z = myzone;
      if (sscanf (s, "%d/%d", net, node) != 2)
         {
         *node = *net;
         *net = mynet;
         }
      }
}

