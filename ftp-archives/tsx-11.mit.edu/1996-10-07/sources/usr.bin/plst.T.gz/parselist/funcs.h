/*
                       Message Base Reply Chain Linker

              This module was originally written by Bob Hartman
                       Sysop of FidoNet node 1:104/501

 This program source code is being released with the following provisions:

 1.  You are  free to make  changes to this source  code for use on your own
 machine,  however,  altered source files may not be distributed without the
 consent of Spark Software.

 2.  You may distribute "patches"  or  "diff" files for any changes that you
 have made, provided that the "patch" or "diff" files are also sent to Spark
 Software for inclusion in future releases of the entire package.   A "diff"
 file for the source archives may also contain a compiled version,  provided
 it is  clearly marked as not  being created  from the original source code.
 No other  executable  versions may be  distributed without  the  consent of
 Spark Software.

 3.  You are free to include portions of this source code in any program you
 develop, providing:  a) Credit is given to Spark Software for any code that
 may is used, and  b) The resulting program is free to anyone wanting to use
 it, including commercial and government users.

 4.  There is  NO  technical support  available for dealing with this source
 code, or the accompanying executable files.  This source  code  is provided
 as is, with no warranty expressed or implied (I hate legalease).   In other
 words, if you don't know what to do with it,  don't use it,  and if you are
 brave enough to use it, you're on your own.

*/

extern  int get_word(char * *from,char *new);
extern  int compile_areas(char *fname);
extern  int get_fido_sys(char *s,int q);
extern void main(int argc,char * *argv);
extern  unsigned int calcrc(char *ptr);
extern  int compare(struct msgtyp *arg1,struct msgtyp *arg2);
extern void update(void);
extern void read_msg_data(void );
extern void fancy_str(char *value);
extern  int get_system(char *where,SYS *ret_system);
extern void relink(void );
extern  int go_directory(char *dir,char *save);
extern void msglink_usage(void );
extern  unsigned int xcrc(unsigned int crc, unsigned char r);
extern  int filedir(char *name,int times,char *ret_str,int mode);
#ifndef OS_2
extern int fast_open(char *path, int oflag);
extern int fast_read(int handle, char *buffer, unsigned int count);
extern int fast_write(int handle, char *buffer, unsigned int count);
extern long fast_lseek(int handle, long offset, int origin);
extern int fast_close(int handle);
#else
extern long filedir1(char *name,int times,char *ret_str);
extern  int dir_findfirst(char *filename,int attribute,struct find_t *dta);
extern  int dir_findnext(struct find_t *dta);
#endif

