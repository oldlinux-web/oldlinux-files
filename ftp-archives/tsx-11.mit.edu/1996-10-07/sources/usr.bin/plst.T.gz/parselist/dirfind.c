#include "dos.h"

char curr_filename[256], curr_pathname[256];
DIR *dirp=NULL;

#define FILENAMELEN 13
/* #define ffirst _dos_findfirst
#define fnext _dos_findnext */

void unixize(char *dos, char *un)
{
	char *s, *d, ch;

	s = dos;	/* source */
	d = un;		/* dest */
	while(*s) {
		ch = *s++;
		switch(ch) {
			case '\\':
				*d++ = '/';		/* first change all \ into / */
				break;
			case '?':
				*d++ = '.';		/* any char as ? */
				break;
			case '.':
				*d++ = '\\';	/* dot as \. */
				*d++ = '.';
				break; 
			case '*':
				*d++ = '.';		/* any seq of char as .* */
				*d++ = '*';
				break;
			default:
				*d++ = ch;
				break;
		}
	}
	*d++ = '$';	/* end of line marker */
	*d = '\0';
}

void splitpath(char *path, char *file, char *dir)
{
	char *pos;

	file[0] = '\0';
	dir[0] = '\0';

	pos = rindex(path, '/');
	if (pos == 0)
		{
		strcpy(file, path);
		}
	else {
		*pos = '\0';
		strcpy(dir, path);
		pos++;
		strcpy(file, pos);
	}
}

/* checkfile returns TRUE when filename is correct */
int checkfile(struct direct *dp)
{
	char name[20];
	int res;

#ifdef BSD
	re_comp(curr_filename);
#endif
	strcpy(name, dp->d_name);
#ifdef BSD
	res = re_exec(name);
#else
	res = !recmp(curr_filename, name);
#endif
	return res;
}

int ffirst(char *name, int plouf, struct find_t *fin)
{
	char un[256];
	struct direct *dp;
	unixize(name, un);
	splitpath(un, name, curr_pathname);
/*	unixize (un, curr_filename); */
	strcpy(curr_filename, un);

	if(dirp)
		closedir(dirp); /* cleanup for previous usage */

	dirp = opendir(curr_pathname);
	if (!dirp)
		return 0;
	for (dp = readdir(dirp); dp != NULL; dp = readdir(dirp))
		if (checkfile(dp)) {
			strcpy (fin->name, dp->d_name);
			return 0;
		}
	closedir(dirp);
	dirp = NULL;
	return 1;
}

int fnext(struct find_t *fin)
{
	struct direct *dp;

	if(!dirp)
		return 0;

	for (dp = readdir(dirp); dp != NULL; dp = readdir(dirp))
		if (checkfile(dp)) {
			strcpy (fin->name, dp->d_name);
			return 0;
		}
	closedir(dirp);
	dirp = NULL;
	return 1;
}
