#include <sys/dir.h>

struct find_t {
	char name[256];
};
