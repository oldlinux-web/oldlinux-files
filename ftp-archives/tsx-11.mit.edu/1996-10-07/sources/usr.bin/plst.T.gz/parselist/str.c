char *strupr(char *str)
	{
	int i;
	
	for (i=0; str[i] != '\0'; i++)
		if((str[i] >= 'a') && (str[i] <= 'z'))
			str[i] = toupper(str[i]);
	}

char *strlwr(char *str)
	{
	int i;

	for (i=0; str[i] != '\0'; i++)
		if ((str[i] >= 'A') && (str[i] <= 'Z'))
			str[i] = tolower(str[i]);
	}
