/*
                              Nodelist Parser

              This module was originally written by Bob Hartman
                       Sysop of FidoNet node 1:104/501

 This program source code is being released with the following provisions:

 1.  You are  free to make  changes to this source  code for use on your own
 machine,  however,  altered source files may not be distributed without the
 consent of Spark Software.

 2.  You may distribute "patches"  or  "diff" files for any changes that you
 have made, provided that the "patch" or "diff" files are also sent to Spark
 Software for inclusion in future releases of the entire package.   A "diff"
 file for the source archives may also contain a compiled version,  provided
 it is  clearly marked as not  being created  from the original source code.
 No other  executable  versions may be  distributed without  the  consent of
 Spark Software.

 3.  You are free to include portions of this source code in any program you
 develop, providing:  a) Credit is given to Spark Software for any code that
 may is used, and  b) The resulting program is free to anyone wanting to use
 it, including commercial and government users.

 4.  There is  NO  technical support  available for dealing with this source
 code, or the accompanying executable files.  This source  code  is provided
 as is, with no warranty expressed or implied (I hate legalease).   In other
 words, if you don't know what to do with it,  don't use it,  and if you are
 brave enough to use it, you're on your own.

*/

extern PWTRP pw_head;
extern PHTRP ph_head;
extern BDTRP bd_head;
extern DLTRP dl_head;
extern COTRP co_head;
extern ETTRP et_head;
extern CMTRP cm_head;
extern FNLST fn_head;
extern PWTRP pw;
extern PHTRP ph;
extern BDTRP bd;
extern DLTRP dl;
extern COTRP co;
extern ETTRP et;
extern CMTRP cm;
extern FNLSTP fn;

extern char intl_pre_dl[];
extern char intl_post_dl[];
extern char country[];
extern char t_str[];
extern int intl_cost;
extern int maxbaud;
extern int out_type;
extern int rdata;
extern int udata;
extern int nlist;
extern int doreport;
extern int nodash;
extern int comments;
extern int version7;
extern int version6;
extern int version5;
extern int myzone;
extern int mynet;
extern int mynode;
extern int nzones;
extern int nregions;
extern int nnets;
extern int nhubs;
extern int ndown;
extern int nredirect;
extern int nnodes;
extern int npoints;
extern int likely;
extern int usezone;
extern int fidoprn;
extern int fidotxt;
extern int do_index;
extern int do_points;
extern int sealist;
extern int binkley;
extern int quickbbs;
extern char nl[1000];

extern    char      *mymalloc(unsigned int s);
extern    char      *nextfield(char *p,char *s);
extern    void      add_files(void );
extern    void      close_files(void );
extern    int       cmp(struct nidxs *a,struct nidxs *b);
extern unsigned int crcstr(char *buf,unsigned int crc);
extern    int       dir_findfirst(char *filename,int attribute,struct find_t *dta);
extern    int       dir_findnext(struct find_t *dta);
extern    void      do_names(void );
extern    void      edit(void );
#ifndef OS2
extern    int       fast_close(int f);
extern    int       OFAST_CLOSE(int f);
extern    int       fast_open(char *name,int mode,int pmode);
extern    int       OFAST_OPEN(char *name,int mode);
extern    int       fast_read(int f,char *st,unsigned int l);
extern    int       OFAST_READ(int f,char *st,unsigned int l);
extern    int       O1FAST_READ(int f,char far *st,unsigned int l);
extern    int       fast_write(int f,char *st,unsigned int l);
extern    int       OFAST_WRITE(int f,char *st,unsigned int l);
extern    int       O1FAST_WRITE(int f,char far *st,unsigned int l);
extern    char far  *_FMALLOC1(unsigned int l);
extern    void      _FFREE1(char far *st);
#endif
extern    char      filedir(char *name,int times,char *ret_str,int mode);
extern    void      fix_up(char *buf);
extern    void      get_addr(char *s,int *z,int *net,int *node);
extern    int       get_diff_name(char *temp_name);
extern    void      get_nl_list(void );
extern    void      get_old_name(char *temp_name);
extern    void      header(int which);
extern    void      how_likely(char *p,int dphone,int *addrs,int node,int n_baud);
extern    int       main(int argc,char * *argv);
extern    void      MEM1CPY(char far *dest, char *src, int len);
extern    void      MEM2CPY(char *dest, char far *src, int len);
extern    void      nfile_name(char * *fn);
extern    int       open_infiles(char *nodelist,char *difflist);
extern    void      open_outfiles(void );
extern    void      parse_config(char *filename,char *mylist,char *pvtlist);
extern    void      process_file(int times);
extern    void      size_report(void );
extern    void      spec_word(char *b1);
extern    void      undash(char *str);

