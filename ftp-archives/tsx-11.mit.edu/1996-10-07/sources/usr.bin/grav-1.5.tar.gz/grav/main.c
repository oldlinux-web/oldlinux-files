#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <dirent.h>
#include <ncurses.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <linux/fcntl.h>
#include <vga.h>

#include "standard.h"
#include "gbm.h"
#include "gbmerr.h"

#define MAIN

#include "grav.h"

void Init();                                            /* Initialisierung */
void GetParms(int argc,char *argv[]);           /* Lesen der Kommandozeile */
void ReadDir();                                     /* Liest Directory ein */
void ReadConfig();                     /* Lesen der Config ($HOME/.gravrc) */
void SaveConfig();                 /* Speichern der Config ($HOME/.gravrc) */
int  GDIRVergleich (void *, void *);      /* Zum Vergleichen des Directory */
int  GRAV_guess_filetype(char *FileName, int *Filetype); /* Erw. Filetypen */

main(int argc, char *argv[])
{
   
   int Index;                                   /* Index fuer Fileselector */
   int Taste;                                        /* Taste fuer getch() */
   int local;

   StdScr=initscr();                             /* NCurses initialisieren */

   UseColor=has_colors();               /* Koennen Farben verwendet werden */

   GetParms(argc, argv);                /* Lesen der Commandline-Arguments */

   if(UseColor)
   {   
      start_color();                                  /* Farben aktivieren */
      init_pair(1, COLOR_WHITE,  COLOR_BLUE);          /* Farben festlegen */
      init_pair(3, COLOR_YELLOW, COLOR_RED);
      init_pair(4, COLOR_BLACK,  COLOR_CYAN);
      init_pair(5, COLOR_WHITE,  COLOR_BLACK);
      init_pair(6, COLOR_YELLOW, COLOR_CYAN);
      init_pair(7, COLOR_YELLOW, COLOR_BLACK);
   }

   gbm_init();                           /* GBM-Schnittstelle initialisieren */
   vga_init();                                   /* SVGALIB initialisieren */

   Init();                                          /* GRAV initialisieren */
   InitNCurses();

   CardRC=0;                           /* Karte und Mode auf Standardwerte */
   ModeRC=0;

   ReadConfig();                                /* Lesen der Konfiguration */

   MakeScreen();                                          /* Menu aufbauen */

   vga_disabledriverreport();                       /* SVGALIB zaehmen ;-) */
   vga_runinbackground(FALSE);                      /* Nicht im Background */
   
   Quit=FALSE;
   SecondWin=FALSE;

   ShowCard();                                  /* Anzeigen der Videokarte */
   ShowMode();                                  /* Anzeigen des Videomodus */

   do
   {
      ClearWindow();
      ShowMode();
      ShowCard();
      ReadDir();                                     /* Directory einlesen */
      ShowDir(0);                                    /* Directory anzeigen */
      GetFile();                                           /* Fileselektor */
   }
   while(Quit==FALSE);

   SaveConfig();                                 /* Konfiguration sichern */

   gbm_deinit();                                  /* GBM deinitialisieren */

   ExitNCurses();                              /* Und weg mit den NCurses */
   
   GoodBye();                                      /* A word from Michael */
}
         
void Init(void)
{
   strcpy(GTYPES[0].Type,".TIFF");           GTYPES[0].Filetype = 3;


   strcpy(GCARD[0].Adapter,"UNDEFINED   "); 
   strcpy(GCARD[1].Adapter,"NORMAL VGA  "); 
   strcpy(GCARD[2].Adapter,"ET4000      "); 
   strcpy(GCARD[3].Adapter,"CIRRUS      "); 
   strcpy(GCARD[4].Adapter,"TRIDENT 8900"); 
   strcpy(GCARD[5].Adapter,"OAK         "); 
   strcpy(GCARD[6].Adapter,"EGA         "); 
   strcpy(GCARD[7].Adapter,"S3          "); 


   strcpy(GMODE[0].Mode,"320x200x16   ");    GMODE[0].ModeIndex=1;
   strcpy(GMODE[1].Mode,"640x200x16   ");    GMODE[1].ModeIndex=2;
   strcpy(GMODE[2].Mode,"640x350x16   ");    GMODE[2].ModeIndex=3;   
   strcpy(GMODE[3].Mode,"640x480x16   ");    GMODE[3].ModeIndex=4;
   strcpy(GMODE[4].Mode,"320x200x256  ");    GMODE[4].ModeIndex=5;
   strcpy(GMODE[5].Mode,"320x240x256  ");    GMODE[5].ModeIndex=6;
   strcpy(GMODE[6].Mode,"320x400x256  ");    GMODE[6].ModeIndex=7;
   strcpy(GMODE[7].Mode,"360x480x256  ");    GMODE[7].ModeIndex=8;
   strcpy(GMODE[8].Mode,"640x480x256  ");    GMODE[8].ModeIndex=10;
   strcpy(GMODE[9].Mode,"800x600x256  ");    GMODE[9].ModeIndex=11;
   strcpy(GMODE[10].Mode,"1024x768x256 ");   GMODE[10].ModeIndex=12;
   strcpy(GMODE[11].Mode,"1280x1024x256");   GMODE[11].ModeIndex=13;
   

   GMODE[0].Width=320;    GMODE[0].Heigh=200;        GMODE[0].Colors=16;
   GMODE[1].Width=640;    GMODE[1].Heigh=200;        GMODE[1].Colors=16;
   GMODE[2].Width=640;    GMODE[2].Heigh=350;        GMODE[2].Colors=16;
   GMODE[3].Width=640;    GMODE[3].Heigh=480;        GMODE[3].Colors=16;
   GMODE[4].Width=320;    GMODE[4].Heigh=200;        GMODE[4].Colors=256;
   GMODE[5].Width=320;    GMODE[5].Heigh=240;        GMODE[5].Colors=256;
   GMODE[6].Width=320;    GMODE[6].Heigh=400;        GMODE[6].Colors=256;
   GMODE[7].Width=360;    GMODE[7].Heigh=480;        GMODE[7].Colors=256;
   GMODE[8].Width=640;    GMODE[8].Heigh=480;        GMODE[8].Colors=256;
   GMODE[9].Width=800;    GMODE[9].Heigh=600;        GMODE[9].Colors=256;
   GMODE[10].Width=1024;  GMODE[10].Heigh=768;       GMODE[10].Colors=256;
   GMODE[11].Width=1280;  GMODE[11].Heigh=1024;      GMODE[11].Colors=256;
}

void ReadDir()
{
   DIR    *DirFile;
   
   struct dirent *DirEintrag;
   struct stat   Buffer;
   
   char   CurrentDir[257];
   char   RootUpperDir;
   char   UpperDir;
   char   CurrDir;
   char   DirOrFile;
   char   Okay;
   int    local;
   int    Temp;
   int    RC;

   local=0;
                       
   getcwd(CurrentDir,256);              /* Aktuelles Verzeichnis ermitteln */   
      
   DirFile=opendir(".");                              /* Directory oeffnen */
         
   while((DirEintrag=readdir(DirFile))!=NULL)   /* Bis keine Files mehr da */
   {
      Okay=FALSE; RootUpperDir=FALSE; CurrDir=FALSE; UpperDir=FALSE;
      
      if (strcmp(CurrentDir,"/")==0)               /* Wenn akt. Dir = ROOT */
        if (strcmp(DirEintrag->d_name,"..")==0)        /* und Eintrag = .. */
           RootUpperDir=TRUE;
                 
      if (strcmp(DirEintrag->d_name,".")==0)         /* Eintrag = CurrDir? */
         CurrDir=TRUE;           
         
      if (strcmp(DirEintrag->d_name,"..")==0)      /* Eintrag = UpperDir ? */
         UpperDir=TRUE;                      
      
      if ((stat(DirEintrag->d_name,&Buffer))==-1)
         Buffer.st_mode=0;
         
      if ((Buffer.st_mode & 0x7000)==0x4000) 
         DirOrFile=DIRECTORY;                 /* Eintrag ist ein Directory */ 
       else 
         DirOrFile=FILE;                         /* Eintrag ist eine Datei */

 
      if (DirOrFile==DIRECTORY)
         Okay=TRUE;
      else
         Okay=FALSE;

      if (DirOrFile==FILE)
      {
         RC=gbm_guess_filetype(DirEintrag->d_name, &Temp);
         if (RC==GBM_ERR_OK)
         {
            Okay=TRUE;
            GRAVDIR[local].Filetype=Temp;
         }
         else
         {
            RC=GRAV_guess_filetype(DirEintrag->d_name, &Temp);
            if (RC==TRUE)
            {
               Okay=TRUE;
               GRAVDIR[local].Filetype=Temp;
            }
         }
      }
      
      if (Okay && !CurrDir && !RootUpperDir )               /* Alles klar? */
      {
         GRAVDIR[local].DirOrFile=DirOrFile; /* In globale Struct kopieren */
         GRAVDIR[local].Tagged=FALSE;
         strcpy(GRAVDIR[local].DirEintrag,DirEintrag->d_name);   
         local++;
      }    
      
   }
   
   GRAVDIREintraege=local;                     
   closedir(DirFile);                              /* Directory schliessen */

   qsort (&(GRAVDIR[1]),         /* Und jetzt noch das Directory sortieren */
          GRAVDIREintraege-1,
          sizeof(struct GDIR),
          (void *)GDIRVergleich);
}

int GDIRVergleich(void *GDIRZeiger1, void *GDIRZeiger2)
{
   struct GDIR *Eintrag1,*Eintrag2;
   
   char Buffer1[80],Buffer2[80];                      /* Puffer allocieren */
   
   Eintrag1=(struct GDIR *)GDIRZeiger1;                  /* Erster Eintrag */ 
   Eintrag2=(struct GDIR *)GDIRZeiger2;                 /* Zweiter Eintrag */
   
   if (Eintrag1->DirOrFile==DIRECTORY)         /* Wenn Eintrag = DIRECTORY */
   {
      strcpy(Buffer1,"<");        /* Dann in Zeichen < und > einschliessen */
      strcat(Buffer1,Eintrag1->DirEintrag);
      strcat(Buffer1,">");
   }
   else
   {  strcpy(Buffer1,Eintrag1->DirEintrag); }   

   if (Eintrag2->DirOrFile==DIRECTORY)
   {
      strcpy(Buffer2,"<");
      strcat(Buffer2,Eintrag2->DirEintrag);
      strcat(Buffer2,">");
   }
   else
   {  strcpy(Buffer2,Eintrag2->DirEintrag); }
   
   return(strcmp(Buffer1,Buffer2));         /* Beide Eintraege vergleichen */
}

void ReadConfig()
{
   int gravrc;
   int local;
   char InFile[80];
   char *HomeDir;
   
   unsigned char *Byte;
   
   HomeDir=getenv("HOME");
   sprintf(InFile,"%s/.gravrc",HomeDir);

   gravrc=open(InFile,O_RDONLY);
   
   if(gravrc!=-1)
   {
      read (gravrc,Byte,1);    CardRC=atoi(Byte);
      read (gravrc,Byte,1);    ModeRC=atoi(Byte);
      close (gravrc);
   }   
   else
   {
      clear();                                       /* Bildschirm loeschen */

      if (UseColor)
      {
         attron(A_BOLD);
         DrawBox(10,68,7,6,3);                                  /* Fenster */
         attron(COLOR_PAIR(YELLOW_ON_RED));
      }
      else
      {
         DrawBoxBW(10,68,7,6,1);
         attron(A_REVERSE);
      }
      
      mvaddstr(7,8,"Welcome to GRAV 1.5.");
      mvaddstr(9,8,"This is the first time you run GRAV. Be sure that you set  the");
      mvaddstr(10,8,"correct Graphic-Card from the Main-Menu. If you  don't,  there");
      mvaddstr(11,8,"may be some trouble with your Text-Mode when getting back from");
      mvaddstr(12,8,"the VGA-Mode. So be careful!");
      mvaddstr(14,33,"Press any key");


      if (UseColor)
      {
         attroff(A_BOLD);
         attroff(COLOR_PAIR(YELLOW_ON_RED));
      }
      else
      {
         attroff(A_REVERSE);
      }
      
      refresh();
      getch();
   }
}

void SaveConfig()
{
   int gravrc;
   char OutFile[80];
   char *HomeDir;
   char Ausgabe [3];
   
   HomeDir=getenv("HOME");
   sprintf(OutFile,"%s/.gravrc",HomeDir);

   gravrc=open(OutFile, O_CREAT | O_WRONLY | O_TRUNC, 0700);

   if(gravrc!=-1)
   {
      sprintf(Ausgabe,"%d%d",CardRC,ModeRC);
      write(gravrc,Ausgabe,3);
      close(gravrc);   
   }   
}

void GetParms(int argc, char *argv[])
{
   int count;
   int ind;
   int ParmOK;
   char temp[200];


   for(count=1;count<argc;count++)
   {
      strcpy(temp,argv[count]);

      if (temp[0]=='-')
      {      
         for(ind=0;ind<strlen(temp);ind++)
         {
            temp[ind]=toupper(temp[ind]);
         }
      }
      
      ParmOK=0;

      if (temp[0]=='-')                    /* Ist ein ein Switch/Parameter? */
      {
         if (strcmp(temp,"-COLOR")==0)
         {  UseColor=1; ParmOK=1;  }

         if (strcmp(temp,"-COLOUR")==0)
         {  UseColor=1; ParmOK=1;  }

         if (strcmp(temp,"-MONO")==0)
         {  UseColor=0; ParmOK=1;  }

         if (strcmp(temp,"-BW")==0)
         {  UseColor=0; ParmOK=1;  }
         
         if (!ParmOK)
         {
            printf("\n>>> Unknown switch %s\n\n",argv[count]);  /* Falscher Parm */
            exit(1);                                        /* Abbrechen */
         }
      }
      else
      {
         if (access(temp,4)==0)        /* Kann die Datei gelesen werden? */
         {
            ParmOK=1;
            Interactive=FALSE;
            strcpy(GRAVDIR[0].DirEintrag,argv[count]);
            GRAVDIR[0].DirOrFile=FILE;
            GRAVDIR[0].Tagged=TRUE;
         }
         else
         {
            printf("\n>>> Cannot open file %s\n\n",argv[count]);
            exit(1);                                       /* Abbrechen! */
         }
      }
      
   }   
}

int GRAV_guess_filetype(char *FileName, int *Filetype)
{
   char Suffix3[5];
   char Suffix4[6];
   int  Laenge;
   int  Flag;
   int local;

   Flag = FALSE;                               /* Filetype nicht supported */
   Laenge = strlen(FileName);               /* Laenge vom String ermitteln */

   if (Laenge > 4)
   {
      Suffix4[0] = toupper(FileName[Laenge-5]);  /* Hier den Suffix er-   */
                                                 /* mitteln und gleich in */
      Suffix3[0] = toupper(FileName[Laenge-4]);  /* Grossbuchstaben um-   */
      Suffix4[1] = toupper(FileName[Laenge-4]);  /* deln                  */

      Suffix3[1] = toupper(FileName[Laenge-3]);
      Suffix4[2] = toupper(FileName[Laenge-3]);

      Suffix3[2] = toupper(FileName[Laenge-2]);
      Suffix4[3] = toupper(FileName[Laenge-2]);

      Suffix3[3] = toupper(FileName[Laenge-1]);
      Suffix4[4] = toupper(FileName[Laenge-1]);

      Suffix3[4] = 0;
      Suffix4[5] = 0;

      for (local=0;local<OWN_TYPES;local++)       /* Ist der Suffix in der */
      {                                           /* Tabelle? */
         if (strcmp(Suffix3,GTYPES[local].Type)==0)
         {
            Flag=TRUE;
            *Filetype = GTYPES[local].Filetype;
         }
         
         if (strcmp(Suffix4,GTYPES[local].Type)==0)
         {
            Flag=TRUE;
            *Filetype = GTYPES[local].Filetype;
         }
      }
   }
   
   return (Flag);
}

