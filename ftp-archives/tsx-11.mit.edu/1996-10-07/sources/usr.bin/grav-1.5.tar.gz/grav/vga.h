/*

 Include-File for GRAV 1.5                           (C) Michael Knigge, 1994
 
 VGA.C handles all Screen-IO using SVGALIB

*/

void MakeLine();
void ViewBitmap(int Line, int Offset, int BWidth, int SWidth);