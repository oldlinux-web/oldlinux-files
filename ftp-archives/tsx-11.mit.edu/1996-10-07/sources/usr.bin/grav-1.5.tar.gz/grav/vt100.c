#include <stdio.h>

void VT100_CLS()
{
   fprintf(stderr,"\x1b[H\x1b[J");
}