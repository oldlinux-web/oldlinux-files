/*

GBMERR.H  Interface to error diffusion module

*/

extern void    gbm_errdiff_line_24(byte *src, byte *dest, short *errs, int cx, byte rm, byte gm, byte bm);
extern BOOLEAN gbm_errdiff_24(GBM *gbm, byte *data24, byte *data24a, byte rm, byte gm, byte bm);

extern void    gbm_errdiff_pal_6R6G6B(GBMRGB *gbmrgb);
extern void    gbm_errdiff_line_6R6G6B(byte *src, byte *dest, short *errs, int cx);
extern BOOLEAN gbm_errdiff_6R6G6B(GBM *gbm, byte *data24, byte *data8);

extern void    gbm_errdiff_pal_7R8G4B(GBMRGB *gbmrgb);
extern void    gbm_errdiff_line_7R8G4B(byte *src, byte *dest, short *errs, int cx);
extern BOOLEAN gbm_errdiff_7R8G4B(GBM *gbm, byte *data24, byte *data8);

extern void    gbm_errdiff_pal_VGA(GBMRGB *gbmrgb);
extern void    gbm_errdiff_line_VGA(byte *src, byte *dest, short *errs, int cx);
extern BOOLEAN gbm_errdiff_VGA(GBM *gbm, byte *data24, byte *data4);

extern void    gbm_errdiff_pal_8(GBMRGB *gbmrgb);
extern void    gbm_errdiff_line_8(byte *src, byte *dest, short *errs, int cx);
extern BOOLEAN gbm_errdiff_8(GBM *gbm, byte *data24, byte *data4);

extern void    gbm_errdiff_pal_4G(GBMRGB *gbmrgb);
extern void    gbm_errdiff_line_4G(byte *src, byte *dest, short *errs, int cx);
extern BOOLEAN gbm_errdiff_4G(GBM *gbm, byte *data24, byte *data4);

extern void    gbm_errdiff_pal_BW(GBMRGB *gbmrgb);
extern void    gbm_errdiff_line_BW(byte *src, byte *dest, short *errs, int cx);
extern BOOLEAN gbm_errdiff_BW(GBM *gbm, byte *data24, byte *data1);
