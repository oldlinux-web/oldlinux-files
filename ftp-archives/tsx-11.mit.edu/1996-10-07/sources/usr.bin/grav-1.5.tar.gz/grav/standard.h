
typedef	int BOOLEAN;

#define	byte		unsigned char
#define	word		unsigned short
#define	dword		unsigned long
