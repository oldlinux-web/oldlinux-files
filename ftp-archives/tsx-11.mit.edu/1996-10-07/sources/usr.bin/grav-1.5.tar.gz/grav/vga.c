
#include <stdlib.h>
#include <vga.h>
#include <ncurses.h>
#include <sys/stat.h>
#include <linux/fcntl.h>

#include "standard.h"
#include "gbm.h"
#include "gbmerr.h"

#include "vga.h"

#define SUBPROG
#include "grav.h"

int ProcessFile(int Index)
{

/*
  if ( gbm_guess_filetype(GRAVDIR[Index].DirEintrag, &GBM_Typ) != GBM_ERR_OK )
  {
      return(ERROR_TYP);
  }                                                                                                                                                                                                                                                                                                             
*/

  GBM_Typ = GRAVDIR[Index].Filetype;

  if ( (GBM_File = open(GRAVDIR[Index].DirEintrag, O_RDONLY)) == -1 )
  {
      return(ERROR_OPEN);
   }

   gbm_query_filetype(GBM_Typ, &gbmft); 

   if ( (GBM_RC = gbm_read_header(GRAVDIR[Index].DirEintrag, GBM_File, GBM_Typ, &gbm, "\0")) != GBM_ERR_OK )
   {
      close(GBM_File);
      return(ERROR_HEADER);
   }         

   if (gbm.bpp==24)                     /* Noch kein Support fuer Truecolor */
   {
      close(GBM_File);
      return(ERROR_24BIT);
   }

   return(NO_ERROR);
}

int ViewFile(Index)
{   
   int PixelX, PixelY;
   int Pixel;
   int local;
   int RETURN;
   int RETURNCODE;
   int KeyPressed;
   int BitmapWidth;
   int ScreenWidth;
   int SkippedLines;
  
   long OldOffset;
   long Offset;
   long OldLines;
   long Lines;
   long MaxLines;
   long MaxOffset;
   long ImageSize;
   long ModeSize;
   long cRGB;

   char *SavedPointer;
   
   if ( (GBM_RC = gbm_read_palette(GBM_File, GBM_Typ, &gbm, gbmrgb)) != GBM_ERR_OK )
   {
       close(GBM_File);
       return(ERROR_PALETTE);
   }       

#ifdef TRACE
   printf("... Doing malloc for ScreenLine with %d Bytes\n",(int) gbm.w);
#endif

   if ( (ScreenLine = malloc((int) gbm.w)) == NULL)
   {
      close (GBM_File);
      return(ERROR_ALLOC);
   }
 
#ifdef TRACE
   printf("... ScreenLine Pointer= %ld \n",ScreenLine);
#endif  
 
   BitmapSize = gbm.h * (((gbm.w * gbm.bpp + 31) / 32) * 4);

#ifdef TRACE
   printf("... BitmapSize= %d Bytes\n",(int) BitmapSize);
#endif

   if ( (Bitmap = malloc((int) BitmapSize)) == NULL )
   {
      close(GBM_File);
      free(ScreenLine);
      return(ERROR_ALLOC);
   }  
   
#ifdef TRACE
   printf("... Bitmap Pointer= %ld \n",Bitmap);
#endif 

   attron(A_BOLD);
   attron(COLOR_PAIR(3));
   DrawBox(5,24,18,54,3);
   attron(A_BOLD);
   attron(COLOR_PAIR(3));
   mvaddstr(19,57,"Reading Data...");
   attroff(A_BOLD);
   attroff(COLOR_PAIR(3));
   refresh();

#ifdef TRACE
   printf("... Read Data\n");
#endif
 
   if ( (GBM_RC = gbm_read_data(GBM_File, GBM_Typ, &gbm, Bitmap)) != GBM_ERR_OK )
   {
      free(Bitmap);
      free(ScreenLine);
      close(GBM_File);
      return(ERROR_READ);
   }   

   close(GBM_File);

   if (gbm.w > GMODE[ModeRC].Width)
      MaxOffset=gbm.w-GMODE[ModeRC].Width;
   else
      MaxOffset=0;

#ifdef TRACE
   printf("... MaxOffset=%d\n",MaxOffset);
#endif      

   if (gbm.h > GMODE[ModeRC].Heigh)
      MaxLines=gbm.h - GMODE[ModeRC].Heigh;
   else
      MaxLines=0;

#ifdef TRACE
   printf("... MaxLines=%d\n",MaxLines);
#endif

   cRGB = ( (1 << gbm.bpp) & 0x1ff );                 /* Anzahl der Farben */
   
   switch (gbm.bpp)               /* Breite des Bitmaps in Bytes berechnen */
   {                              /* Muss jeweils durch 4 teilbar sein! */
      case 8: BitmapWidth=((gbm.w+3)/4)*4;      
              break;

      case 4: BitmapWidth=(((gbm.w/2)+3)/4)*4;      
              break;

      case 1: BitmapWidth=((((gbm.w+7)/8)+3)/4)*4;
              break;              
   }

   if (GMODE[ModeRC].Width < gbm.w)    /* Setzen Laenge je Bildschirmzeile */
      ScreenWidth=GMODE[ModeRC].Width;
    else
      ScreenWidth=gbm.w;

#ifdef TRACE
   printf("... ScreenWidth=%d\n",ScreenWidth);
   printf("*** PRESS ANY KEY ***\n");
   getch();
#endif

   ExitNCurses();                                 /* NCurses "ausschalten" */

   vga_setmode(GMODE[ModeRC].ModeIndex);               /* Videomode setzen */
   vga_setdisplaystart(0);             /* Start = erstes Byte im Video RAM */
   vga_setmodeX();                     /* X-Mode (wirkt nur bei 256 Farben */
   vga_clear();                                     /* Bildschirm loeschen */
   vga_screenoff();                              /* Bildschirm ausschalten */


   if (gbm.bpp!=24)
   {
      for ( local=0;local<cRGB;local++ )            /* Farb-Palette setzen */
      {
         gbmrgb[local].r=gbmrgb[local].r/4; 
         gbmrgb[local].g=gbmrgb[local].g/4;
         gbmrgb[local].b=gbmrgb[local].b/4;
      
         vga_setpalette(local,gbmrgb [local].r,gbmrgb [local].g,gbmrgb [local].b);
      }   
   }

   SavedPointer=ScreenLine;                               /* Pointer merken */

   ViewBitmap(0,0,BitmapWidth,ScreenWidth);                /* Bild anzeigen */
       
   vga_screenon();                                /* Bildschirm einschalten */

   RETURN=FALSE;

   Offset = 0;     Lines = 0;
   OldOffset = 0;  OldLines = 0;
   
   do
   {
      KeyPressed=getch();                                   /* Taste lesen */
   
      OldOffset = Offset;
      OldLines  = Lines;
   
      switch (KeyPressed)
      {
         case KEY_DOWN:   Lines=Lines+(GMODE[ModeRC].Heigh/10);
                          if (Lines>MaxLines)
                             Lines=MaxLines;
                 /*         ViewBitmap(Lines, Offset, BitmapWidth, ScreenWidth); */
                          break;
         
         case KEY_UP:     Lines=Lines-(GMODE[ModeRC].Heigh/10);
                          if (Lines<0)
                             Lines=0;
                  /*        ViewBitmap(Lines, Offset, BitmapWidth, ScreenWidth); */
                          break;
         
         case KEY_RIGHT:  Offset=Offset+(GMODE[ModeRC].Width/10/2);
                          if (Offset>MaxOffset)
                             Offset=MaxOffset;
                 /*         ViewBitmap(Lines, Offset, BitmapWidth, ScreenWidth); */
                          break;
         
         case KEY_LEFT:   Offset=Offset-(GMODE[ModeRC].Width/10/2);
                          if (Offset < 0)
                             Offset=0;
                   /*       ViewBitmap(Lines, Offset, BitmapWidth, ScreenWidth); */
                          break;

         case KEY_SPACE:  RETURN=TRUE;
                          RETURNCODE=NO_ERROR;
                          break;
         
         case KEY_ENTER:  RETURN=TRUE;
                          RETURNCODE=VIEW_ABORT;      
                          break;
      }
      
      if (OldOffset!=Offset || OldLines!=Lines)
         ViewBitmap(Lines, Offset, BitmapWidth, ScreenWidth);
   }
   while(RETURN==FALSE);

   ScreenLine=SavedPointer;
   vga_setmode(TEXT);                                /* Textmode aktivieren */

#ifdef TRACE
   printf("... Free Space of Bitmap at address %ld\n",Bitmap);
#endif

   free (Bitmap);                                     /* Speicher freigeben */

#ifdef TRACE
   printf("... Free Space of ScreenLine at address %ld\n",Bitmap);
#endif

   free (ScreenLine);
   
#ifdef TRACE
   printf("... Doing VT100_CLS\n");
#endif
   
   VT100_CLS();                                 /* VT100-Screencodes senden */
  
#ifdef TRACE
   printf("... Going home\n");
   getch();
   printf("\n*** PRESS ANY KEY ***\n");
#endif 
   
   return(RETURNCODE);                               /* Und wieder zurueck */
}

int CheckMode(void)
{
   vga_setchipset(CardRC);                           /* Grafikkarte setzen */

   if (!vga_hasmode(GMODE[ModeRC].ModeIndex))              /* kein Support */
      return (ERROR_SUPPORT);
   else
      return (NO_ERROR);
}

void MakeLine(void)
{
   int local;
   int IND;
   
   unsigned char Pixel;
   unsigned char Pixel1;
   unsigned char Pixel2;
   unsigned char Pixel3;
   unsigned char Pixel4;
   unsigned char Pixel5;
   unsigned char Pixel6;
   unsigned char Pixel7;
   unsigned char Pixel8;
   
   IND=0;

   switch (gbm.bpp)
   {
      case 8:   ScreenLine=Bitmap;                           /* 256 Farben */
                break;
      
      case 4:   for (local=0;local<(gbm.w+1)/2;local++)           /* 16 Farben */
                {  
                   Pixel=Bitmap[local];
                   
                   Pixel1=Pixel<<4;
                   Pixel1=Pixel1>>4;
                   
                   Pixel2=Pixel>>4;
                   
                   ScreenLine[IND]=Pixel2; IND++;
                   ScreenLine[IND]=Pixel1; IND++;
                }
                break;
      
      case 1:   for(local=0;local<(gbm.w+7)/8;local++)         /* 2 Farben */
                {
                   Pixel=Bitmap[local];
                   
                   Pixel1=Pixel&128;   Pixel2=Pixel&64;
                   Pixel3=Pixel&32;    Pixel4=Pixel&16;
                   Pixel5=Pixel&8;     Pixel6=Pixel&4;
                   Pixel7=Pixel&2;     Pixel8=Pixel&1;
                   
                   if (Pixel1!=0)
                      ScreenLine[IND]=0x01;
                   else
                      ScreenLine[IND]=0x00;
                   
                   IND++;
                   
                   if (Pixel2!=0)
                      ScreenLine[IND]=0x01;
                   else
                      ScreenLine[IND]=0x00;
                   
                   IND++;
                
                   if (Pixel3!=0)
                      ScreenLine[IND]=0x01;
                   else
                      ScreenLine[IND]=0x00;
                   
                   IND++;
                   
                   if (Pixel4!=0)
                      ScreenLine[IND]=0x01;
                   else
                      ScreenLine[IND]=0x00;
                   
                   IND++;
                   
                   if (Pixel5!=0)
                      ScreenLine[IND]=0x01;
                   else
                      ScreenLine[IND]=0x00;
                   
                   IND++;
                   
                   if (Pixel6!=0)
                      ScreenLine[IND]=0x01;
                   else
                      ScreenLine[IND]=0x00;
                   
                   IND++;
                
                   if (Pixel7!=0)
                      ScreenLine[IND]=0x01;
                   else
                      ScreenLine[IND]=0x00;
                   
                   IND++;
                   
                   if (Pixel8!=0)
                      ScreenLine[IND]=0x01;
                   else
                      ScreenLine[IND]=0x00;
                      
                   IND++;
                }
                break;
   }   
}                  

void ViewBitmap(int Line, int Offset, int BWidth, int SWidth)
{
   int  local;
   int  SkipPixels;
   int  SkipLines;
   char *SavedBitmap;

   switch (gbm.bpp)
   {
      case 24: Offset=Offset*3;
               break;
               
      case  8: break;
      
      case  4: Offset=(Offset+1)/2;
               break;
              
      case  1: Offset=(Offset+7)/8;
               break;
   }

   SavedBitmap=Bitmap;                        /* Pointer auf Bitmap sichern */
   
   Bitmap=Bitmap+BitmapSize;                      /* Auf Ende des Bereiches */
   
   Bitmap=Bitmap-BWidth;            /* Vor der Schleife eine Zeile abziehen */
   Bitmap=Bitmap+Offset;                         /* Und den Offset addieren */
   Bitmap=Bitmap-(Line*BWidth);                    /* Und die Lines skippen */

#ifdef TRACE
   vga_flip();
   printf("... Saved Address      : %ld\n",SavedBitmap);
   printf("... New Bitmap Address : %ld\n",Bitmap);
   printf("... BitmapSize         : %d\n",BitmapSize);
   printf("... Offset             : %d\n",Offset);
   printf("... Skipped Lines      : %d\n",Line);
   printf("... Graphic Width      : %d\n",BWidth);
   printf("... Graphic Heigh      : %d\n",gbm.h);
   printf("... Screen Width       : %d\n",SWidth);
   printf("... Screen Heigh       : %d\n",GMODE[ModeRC].Heigh);
   printf("\n*** PRESS ANY KEY ***\n");
   getch();
   vga_flip();
#endif

   if (GMODE[ModeRC].Width > gbm.w)
      SkipPixels = (GMODE[ModeRC].Width - gbm.w) / 2;
   else
      SkipPixels = 0;

   if (GMODE[ModeRC].Heigh > gbm.h)
      SkipLines = (GMODE[ModeRC].Heigh - gbm.h) / 2;
   else
      SkipLines = 0;

   for(local=1;local<GMODE[ModeRC].Heigh;local++)
   {  
      if (Bitmap>=SavedBitmap)
      {
         MakeLine();                                 /* Aufbauen der Linie */
         vga_drawscansegment(ScreenLine,0+SkipPixels,local+SkipLines,SWidth);
      }
      Bitmap=Bitmap-BWidth;             /* Ich liebe Pointerarithmetik ;-) */
   }
   
   Bitmap=SavedBitmap;                   /* Wieder in den Originalzustand */
}
