/*

 Include-File for GRAV 1.5                           (C) Michael Knigge, 1994
 
 SCREEN.C handles all Screen-IO using NCurses

*/

void ShowMode();
void ShowCard();
void InitNCurses();
void ExitNCurses();
void ClearWindow();
void ShowHelp();
void ShowErrorWindow(int ErrCode);
void DrawSelector(char *Item, int Line, int Column, int IDX);
void UndrawSelector(char *Item, int Line, int Column, int IDX);