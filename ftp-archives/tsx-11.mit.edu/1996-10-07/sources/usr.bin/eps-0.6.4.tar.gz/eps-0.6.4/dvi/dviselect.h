#ifndef dviselect_h
#define dviselct_h

#include "PROTO.h"
enum pstype {
	pt_lu,			/* have both lower and upper bounds */
	pt_l,			/* lower bound only */
	pt_u,			/* upper bound only */
	pt_unbounded,		/* any value at all */
	pt_even,		/* even values only */
	pt_odd			/* odd values only */
};
struct pagesel {
	enum pstype ps_type;	/* type of selector */
	i32	ps_low;		/* lower bound */
	i32	ps_high;	/* upper bound */
};
struct pagelist {
	struct	pagelist *pl_alt;	/* next in a series of alternates */
	int	pl_len;			/* number of ranges to check */
	int	pl_abs;			/* true iff absolute page ref */
	struct	pagesel pl_pages[10];	/* one for each \count variable */
};
struct fontinfo {
	i32	fi_newindex;	/* font number in output file */
	int	fi_reallyused;	/* true => used on a page we copied */
	i32	fi_checksum;	/* the checksum */
	i32	fi_mag;		/* the magnification */
	i32	fi_designsize;	/* the design size */
	short	fi_n1;		/* the name header length */
	short	fi_n2;		/* the name body length */
	char	*fi_name;	/* the name itself */
};
int DesiredPageP(void);
void message(int space, char *str, int len);
void BeginPage(void);
void EndPage(void);
void PostAmbleFontEnumerator(char *addr, i32 key);
void HandlePostAmble(void);
void WriteFont(struct fontinfo *fi);
void HandlePreAmble(void);
/* int main(int argc, char **argv); */
void InstallPL(struct pagesel *ps, int n, int absolute);
int evenodd(char *s);
int ParsePages(char *s);
void HandleFontDef(i32 index);
void HandleSpecial(int c, int l, i32 p);
void ReallyUseFont(void);
void PutFontSelector(i32 index);
void HandleDVIFile(void);

#endif
