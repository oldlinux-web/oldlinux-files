struct fontinfo {
	struct	fontinfo *fi_next;/* next in list */
	i32	fi_index;	/* font number in output file */
	i32	fi_checksum;	/* the checksum */
	i32	fi_mag;		/* the magnification */
	i32	fi_designsize;	/* the design size */
	short	fi_n1;		/* the name header length */
	short	fi_n2;		/* the name body length */
	char	*fi_name;	/* the name itself */
};
void BeginPage(void);
void EndPage(void);
void WriteFont(register struct fontinfo *fi);
void WritePostAmble(void);
void HandlePostAmble(void);
int HandlePreAmble(int firstone);
void doit(char *name, FILE *fp);
void HandleFontDef(i32 index);
void HandleSpecial(int c, register int l, register i32 p);
void UseFont(register i32 index);
void HandleDVIFile(void);
