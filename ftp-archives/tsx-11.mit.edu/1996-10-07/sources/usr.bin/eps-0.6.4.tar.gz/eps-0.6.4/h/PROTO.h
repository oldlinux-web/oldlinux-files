#ifndef PROTO_h
#define PROTO_h
#include "types.h"
#include <stdio.h> /* for FILE */
#include <stdarg.h> /* for va_list */
#include "bounds.h"
#include "conv.h"
#include "decinf.h"
#include "dviclass.h"
#include "dvicodes.h"
#include "dvistate.h"
#include "fio.h"
#include "font.h"
#include "fontconf.h"
#include "gfclass.h"
#include "gfcodes.h"
#include "gripes.h"
#include "num.h"
#include "pkdetails.h"
#include "postamble.h"
#include "sdecode.h"
#include "search.h"
#include "tfm.h"

/* FROM conv.c */
extern void CSetConversion(struct conversion *c, int hdpi, int vdpi,int usermag, i32 num, i32 denom, i32 dvimag);
/* FROM dviclass.c */
/* FROM dvistate.c */
extern void DVISetState(FILE *fp, struct font *(*fontfn)(char* name, i32 dvimag, i32 dvidsz), int hdpi, int vdpi, int xoffset, int yoffset);
static void pre(void);
static void post(struct PostAmbleInfo *p);
static void fntdef(struct PostAmbleFont *p);
extern struct font *DVIFindFont(i32 n);
extern void DVIRule(void (*fn)(i32 h, i32 w), int advance);
extern void DVIBeginPage(void (*fn)(i32* count));
/* FROM error.c */
extern void SetErrorTrap(void (*fn)(int,char*));
static char *readback(void);
static void verror(int quit, char *a0, char *fmt, va_list l, int e);
extern void error(int quit, int e, char *fmt, ...  );
extern void panic(char *fmt, ...  );
/* FROM findpost.c */
extern int FindPostAmble(register FILE *f);
/* FROM fio.c */
extern i32 GetByte(register FILE *fp);
extern i32 GetWord(register FILE *fp);
extern i32 Get3Byte(register FILE *fp);
extern i32 GetLong(register FILE *fp);
/* FROM font.c */
extern void fontinit(char *file);
static struct fontops *findops(register char *name);
static void readconf(char *name);
static void setfenv(struct fontconf *pfc, char *env, char *suf);
static void setfont(struct fontconf *pfc, char *path);
static void badcf(char *why);
static void basify(char *s, char *buf, int size);
static void pave(char *result, char *proto, char *name, int mag);
extern struct font *GetFont(char *nm, i32 dvimag, i32 dvidsz, char *dev, char **fname);
extern struct font *GetRasterlessFont(char *nm, i32 dvimag, i32 dvidsz, char *dev, char **fname);
static struct font *getafont(char *nm, i32 dvimag, i32 dvidsz, char *dev, char **fname, int wantrast);
/* FROM font_subr.c */
extern int FontHasGlyphs(register struct font *f, register int low, register int high);
static struct glyph *AllocGlyph(int n);
extern void FreeGlyph(struct font *f, register struct glyph *g);
extern void FreeFont(register struct font *f);
extern struct glyph *GetGlyph(register struct font *f, int c);
extern char *GetRaster(register struct glyph *g, register struct font *f, int r);
extern void FreeRaster(struct glyph *g);
extern char *Font_TeXName(register struct font *f);
/* FROM getopt.c */
extern int getopt(register int argc, register char **argv, char *optstring);
/* FROM gfclass.c */
/* FROM gffont.c */
static int findGFpostamble(int fd, long *postp, long *postpostp);
static int gf_read(register struct font *f, int fd);
static char *drawchar(register char *p, int abbrev, struct bounds globalb, char *gfname);
extern char *copyit(void);
static int gf_getgly(register struct font *f, int l, int h);
static int gf_rasterise(struct font *f, int l, int h);
static void gf_freefont(struct font *f);
/* FROM gripes0.c */
extern void GripeOutOfMemory(int n, char *why);
extern void GripeCannotGetFont(char *name, i32 mag, i32 dsz, char *dev, char *fullname);
extern void GripeDifferentChecksums(char *font, i32 tfmsum, i32 fontsum);
extern void GripeMissingFontsPreventOutput(int n);
/* FROM gripes1.c */
static char *dfn(void);
extern void GripeNoSuchFont(i32 n);
extern void GripeFontAlreadyDefined(i32 n);
extern void GripeUnexpectedDVIEOF(void);
extern void GripeUnexpectedOp(char *s);
extern void GripeMissingOp(char *s);
extern void GripeCannotFindPostamble(void);
extern void GripeMismatchedValue(char *s);
extern void GripeUndefinedOp(int n);
extern void GripeBadGlyph(i32 c, struct font *f);
/* FROM magfactor.c */
extern double DMagFactor(int mag);
/* FROM pkfont.c */
static int pk_unpack(register struct pk_details *pk);
static void skip_specials(struct font *f);
static int pk_read(register struct font *f, int fd);
static int scan_characters(struct font *f, char **reason);
static int pk_getgly(register struct font *f, int l, int h);
static int pk_rasterise(struct font *f, int l, int h);
static void pk_freefont(struct font *f);
/* FROM pxlfont.c */
static int pxl_read(struct font *f, int fd);
static int pxl_getgly(register struct font *f, int l, register int h);
static char *makeraster(register int h, register int w, register char *rp);
static int pxl_rasterise(register struct font *f, int l, register int h);
static void pxl_freefont(struct font *f);
/* FROM rotate.c */
extern void SetRotation(register struct glyph *g, int r);
static void RotateClockwise(struct glyph *glyph);
/* FROM rstfont.c */
static int rst_read(struct font *f, int fd);
static int rst_getgly(register struct font *f, int l, register int h);
static int rst_rasterise(register struct font *f, int l, register int h);
static void rst_freefont(struct font *f);
/* FROM scaletfm.c */
extern i32 ScaleOneWidth(register i32 t, register i32 z);
extern void ScaleGlyphs(register struct font *f, int l, int h);
/* FROM scanpost.c */
extern void ScanPostAmble(register FILE *f, void (*headerfunc)(struct PostAmbleInfo *p), void (*fontfunc)(struct PostAmbleFont *p));
/* FROM sdecode.c */
static int canon(register struct decode_info *di);
static char *word(register struct decode_info *di, int quietly);
extern void SDsetclass(register char *spaces, register char *semis);
static struct sdecode *lookup(register char *str, register struct sdecode *p, register int max);
extern void SDecode(FILE *fp, register i32 len, struct sdecode *table, int tsize);
static void args(register struct sdecode *tp, register struct decode_info *di);
static void badarg(int c, struct decode_info *di);
static int scan(struct decode_info* di, char** fmtp, ...);
static int scan_i(char *p, int c, i32 *result);
static int scan_d(char *p, double *result);
/* FROM search.c */
extern struct search *SCreate(register unsigned int dsize);
extern char *SSearch(register struct search *s, register i32 key, int *disp);
extern void SEnumerate(register struct search *s, register void (*f)(char*, i32));
/* FROM seek.c */
extern FILE *CopyFile(FILE *f);
extern FILE *SeekFile(FILE *f);
/* FROM skip.c */
extern void SkipFontDef(register FILE *fp);
/* FROM split.c */
extern int split(register char *s, register char **w, int nw);
/* FROM strsave.c */
extern char *strsave(register char *s);
/* FROM tempfile.c */
extern FILE* MakeRWTempFile(register char *name);
/* FROM tfm.c */
extern int readtfmfile(register FILE *f, register struct tfmdata *t, int stopafterwidth);
static int trd_header(register FILE *f, register struct tfmheader *th);
static int trd_ci(register FILE *f, register int nc, register struct char_info_word *ci);
static int trd_fix(register FILE *f, register int nf, register i32 *p);
/* FROM tfmfont.c */
static int box_read(struct font *f, int fd);
static int blank_read(struct font *f, int fd);
static int tfm_read(struct font *f, int fd);
static int do_read(register struct font *f, int fd, int blank);
static int tfm_getgly(register struct font *f, int l, register int h);
static int tfm_rasterise(struct font *f, int l, int h);
static void tfm_freefont(struct font *f);

/* from makefont.c  <mkl> */
extern int MakeFont(const char *basename, int base_res, int res, double mag, 
			const char *mode, char *path);
#endif
