#ifndef bounds_h
#define bounds_h

struct bounds {
	i32	min_m, max_m;	/* min and max `m' (colunm) values */
	i32	min_n, max_n;	/* min and max `n' (row) values */
};

#endif
