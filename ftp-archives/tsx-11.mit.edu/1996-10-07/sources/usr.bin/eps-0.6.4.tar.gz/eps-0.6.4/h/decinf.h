#ifndef decodeinfo_h
#define decodeinfo_h

struct decode_info {
	/* data used to read from input file */
	int	di_nch;		/* number of characters remaining in buffer */
	char	*di_cp;		/* next character to be read from buffer */
	long	di_nfilech;	/* number of characters remaining in file */
	FILE	*di_file;	/* the file itself */

	/* information used and/or returned by the canon routine */
	int	di_lexstate;	/* lexical state */
	int	di_call;	/* set when we reach terminating `semicolon' */

	/* information used more globally */
	char	*di_word;	/* last word from word() */
	char	*di_kw;		/* the keyword */
	int	di_bkw;		/* true iff keyword is in static buffer */
};

#endif
