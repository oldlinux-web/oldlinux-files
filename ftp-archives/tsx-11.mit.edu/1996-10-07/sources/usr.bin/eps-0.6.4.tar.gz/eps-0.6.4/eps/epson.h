#ifndef Epson_h
#define Epson_h

/* Copyright (c) 1993 Neal Becker
 * All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

/* epson.h,v 1.3 1993/10/02 03:23:13 neal Exp */

#include <stdio.h>
#include <stdlib.h>		/* for getenv, exit */
#include <limits.h>
#include "Bset.h"
#include "param.h"

#define MaxImFamily	128	/* hardware limitation on font family index */
#define DefaultMaxDrift	3	/* default value for MaxDrift */


int HPixels;

int VPixels;

int HBytes;

int BitMapRows;

const int SpacesPerInch = 10;

inline int 
max (int a, int b)
{
  return (a > b) ? a : b;
}

inline int 
min (int a, int b)
{
  return (a < b) ? a : b;
}

struct BitMapRow
{
  int Length;			/* last bit pos used */
  unsigned char Printed;
  char *Bits;
  BitMapRow ();
  void Clear ();
  void Set (char *S, int Slen, int Pos)
  {
    Bset (S, Slen, Bits, HBytes, Pos);
    Length = max( Length, min( HPixels - 1, Pos + ( 8 * Slen ) ) );
  };

  void SetBits (int Slen, int Pos)
  {
    ::SetBits (Slen, Bits, HPixels, Pos);
    Length = max (Length, min (HPixels - 1, Pos + Slen));
  };

  int NeedToPrint ()
  {
    return !Printed && Length != 0;
  };

  void Mark ()
  {
    Printed = 1;
  };
};

struct BitMap
  {
    BitMapRow **Rows;

    BitMap ();

    void Clear ();

    int NeedToPrint (int Row)
    {
      return Rows[Row]->NeedToPrint ();
    };

    int FindLength (int Row, int VPins, int VInterleave, int VInc);

    int FindFirst (int Row, int VPins, int VInterleave, int VInc);

    void Mark (int Row)
    {
      Rows[Row]->Mark ();
    };

    void Set (char *S, int Slen, int Row, int Pos)
    {
      Rows[Row]->Set (S, Slen, Pos);
    };

    void SetBits (int Slen, int Row, int Pos)
    {
      Rows[Row]->SetBits (Slen, Pos);
    };
  };

static const char BitMask[] =
{0x1, 0x2, 0x4, 0x8,
 0x10, 0x20, 0x40, 0x80
};

void ReportMem ();

class epson
{

  private:
  FILE * fp;
  int DviPos;
  int PrintPos;

  char* Zeros;
  
  char *PrintEngine;

  const int VPins;			/* Number of pins used in selected graphics mode. */

  const int DPIh;			/* Horizontal resolution of selected graphics mode. */

  const int DPIv;			/* Vertical resolution of selected graphics mode. */

  char *GraphicsMode;		/* String to set the desired graphics mode. */

  int VSkipUnit;		/* The number of rows skipped by ESC J 1.  This is computed
				   from DPIv/VSkip */

  int VSkipRpt;			/* If number of rows skipped by a single skip
				   is less than 1 this is the number of times
				   to repeat to get a unit skip */

  const int VInc;			/* Normally =1, but if you want to not use all
				 the pins you can set this larger.  If =2 then
				 skip every other pin.  May give better result
				 on some printers. */
  
  const int HInc;			/* Normally =1, but you can skip pin positions
				 horizontally.  If =2, then make 2 passes over
				 each line, skipping every other pin position.
				 Some printers need this? */
  
  const int VInterleave;		/* The number of rows skipped between pins. */

  char* InitString;		/* The string sent to initialize the printer */

  char* ResetString;		/* The string sent at the end to reset the printer */

  char* OutBuff;

  const int DotsPerSpace;

  const int MinSkippable;	/* minimum number of pixels that are worth
				 converting to spaces if they are all blank */
  
  const int VSpread;

  const char* VaddvStr;
  
  const int VBytes;            /* (VPins+7)/8 */

  int MaxHBit;

  void PrintRow (BitMap & theBitMap, int Row);

  void OutputRow (BitMap & theBitMap, int Row);

  void Encode (BitMap & theBitMap, int Row, int HBit );

  void SetVpos (int Row);

  void Vaddv (int n);

/* Reset Printer, Select Pica (10 cpi) */
  void Init ()
  {
    fputs ( InitString, fp );
  }

  void (epson::*DoSpaces)(int,int);

  void UseTabs( int Spaces, int CurrentSpacePos );

  void UseEscF0( int Spaces, int CurrentSpacePos );

  void UseSpaces( int Spaces, int CurrentSpacePos );
  
public:

  epson( FILE* f, param& P );

  ~epson() { fputs( ResetString, fp ); }
  
  char *Engine () const
  {
    return (PrintEngine);
  }

  int GetDPIh() const { return DPIh; }

  int GetDPIv() const { return DPIv; }

  void Reset ()
  {
    SetVaddv (0);
    PrintPos = 0;
  }

  void Eol ()
  {
    fputc ('\r', fp);
  }

  void EoP () {}

  void FF() { fputc ('\f', fp); }

  void SetVaddv (int n)
  {
    fputs ("\x1b" "3", fp);
    fputc (n, fp);
  }

  void ResVaddv ()
  {
    fputs ("\x1b" "2", fp);
  }

  void PrintBitMap (BitMap & theBitMap);

  void SyncVpos ()
  {
    SetVpos (DviPos);
  }

  int RoundUpToSpace( int HBit );

  int RoundDownToSpace( int HBit );

  int FindNextSkip( int HBit, int Length );

  void DoSkip( int& HBit, int Length );

  int BlankLength( int HBit, int Length );

  int IsBlank( int HBit );

  int IsSkippable( int HBit, int Length );

  void OutputData( int HBit, int Chunk );

  void SetPin( int HBit, int VBit );
  
};

#endif
