typedef union {
  char* strval;
  param* pval; /* would be nice to use a struct instead of a pointer */
	       /* but can't be a member of a union */
  int ival;
  double dval;
} YYSTYPE;
#define	STRING	258
#define	ENGINE	259
#define	VPINS	260
#define	DPIH	261
#define	DPIV	262
#define	GRAPHICSMODE	263
#define	VSKIP	264
#define	VINC	265
#define	VINTERLEAVE	266
#define	XOFF	267
#define	YOFF	268
#define	WIDTH	269
#define	HEIGHT	270
#define	INITSTRING	271
#define	RESETSTRING	272
#define	HINC	273
#define	USEESCF0	274
#define	USETABS	275
#define	USESPACES	276
#define	MINSKIPSPACES	277
#define	VSPREAD	278
#define	VADDVSTR	279


extern YYSTYPE yylval;
