/* Copyright (c) 1993 Neal Becker
 * All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

static const char rcsid[] = "parse.c,v 1.3 1993/10/02 03:23:15 neal Exp";

#include "parse.h"
#include <stdio.h>
#include "config.h"
#include "param.h"
#include "PROTO.h"
#include <errno.h>

int yyparse();
extern FILE *yyin;
int FoundPrinter = 0;
int yydebug = 1;

/* return 0 if not found, 1 if found, -1 if parse error */
int FindPrinter() {
  yyin = fopen( CONFIG_FILE, "r" );
  if( !yyin ) {
    error(0, errno, "can't open %s", CONFIG_FILE);
    return 0;
  }
  if( yyparse() )
    return -1;
  else
    return FoundPrinter;
}

extern char* yytext;
extern int LineNo;

extern void yyerror(char *s)
{
  fprintf(stderr, "%s\n", s );
  fprintf(stderr, "Line No %d, Last token was \"%s\"\n", LineNo, yytext );
}
