#ifndef Bset_h
#define Bset_h

/* Bset.h,v 1.3 1993/10/02 03:23:07 neal Exp */

/* Copyright (c) 1993 Neal Becker
 * All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

void Bset (char *S, int Slen, char *D, int Dlen, int Pos);

void SetBits (int Slen, char *D, int Dlen, int Pos);

#endif
