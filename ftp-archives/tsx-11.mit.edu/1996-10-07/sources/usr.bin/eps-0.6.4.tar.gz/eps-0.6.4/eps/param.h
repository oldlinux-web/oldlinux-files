// This may look like C code, but it is really -*- C++ -*-

#ifndef param_h
#define param_h

/* Copyright (c) 1993 Neal Becker
 * All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

/* param.h,v 1.3 1993/10/02 03:23:14 neal Exp */

#include "config.h"

struct param {

  enum Space_t { UseEscF0, UseTabs, UseSpaces } ;

  char* Engine;
  int VPins;
  int DPIh;
  int DPIv;
  char* GraphicsMode;
  int VSkip;
  int VInc;
  int HInc;
  int VInterleave;
  int xoff;
  int yoff;
  double Width;
  double Height;
  Space_t SpaceType;
  char* InitString;
  char* ResetString;
  int MinSkipSpaces;
  int VSpread;
  char* VaddvStr;
  
  param() : 
    Engine( DEFAULT_ENGINE ),
    VPins( DEFAULT_VPINS ),
    DPIh( DEFAULT_DPIH ),
    DPIv( DEFAULT_DPIV ),
    GraphicsMode( DEFAULT_GRAPHICSMODE ),
    VSkip( DEFAULT_VSKIP ),
    VInc( DEFAULT_VINC ),
    HInc( DEFAULT_HINC ),
    VInterleave( DEFAULT_VINTERLEAVE ),
    xoff( DEFAULT_XOFF ),
    yoff( DEFAULT_YOFF ),
    Width( DEFAULT_WIDTH ),
    Height( DEFAULT_HEIGHT ),
    InitString( DEFAULT_INITSTRING ),
    ResetString( DEFAULT_RESETSTRING ),
    SpaceType( DEFAULT_SPACETYPE ),
    MinSkipSpaces( DEFAULT_MINSKIPSPACES ),
    VSpread( DEFAULT_VSPREAD ),
    VaddvStr( DEFAULT_VADDVSTR )
  {}

};

#endif
