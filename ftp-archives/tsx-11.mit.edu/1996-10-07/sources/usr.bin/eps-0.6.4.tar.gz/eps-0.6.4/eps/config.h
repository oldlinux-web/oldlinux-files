#ifndef config_h
#define config_h

/* Copyright (c) 1993 Neal Becker
 * All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

/* config.h,v 1.3 1993/10/02 03:23:08 neal Exp */

#define DEFAULT_ENGINE "EpsonMXFX"	/* default engine to look for in fontdesc */
#define DEFAULT_VPINS 8		/* default number of pins */
#define DEFAULT_DPIH 240	/* default horizontal resolution */
#define DEFAULT_DPIV 216	/* default vertical resolution */
#define DEFAULT_GRAPHICSMODE "\x1b" "Z"	/* the string to set graphics mode */
#define DEFAULT_VSKIP 216	/* the 1/amount that is advanced by VAddvStr */
#define DEFAULT_VINC 1		/* If you want to not use all the pins you can
				   set this > 1.  If you set this to 2 you will
				   skip half the pins.  This may give better
				   results on some printers. */
#define DEFAULT_HINC 1		/* Some printers don't want to print all the
				 dots horizontally in one pass.  If you set
				 this to 2 you will make 2 passes horizontally
				 at each position, skipping every other bit. */
#define DEFAULT_VINTERLEAVE 3	/* the vertical interleave of the pins.  This
				   is the spacing of the pins/dpiv */
#define DEFAULT_XOFF 0		/* xoffset */
#define DEFAULT_YOFF 0		/* yoffset */
#define DEFAULT_WIDTH 8.5
#define DEFAULT_HEIGHT 11 
#define DEFAULT_INITSTRING "\x1b" "@" "\x1b" "P"
#define DEFAULT_RESETSTRING "\f" "\x1b" "@"
#define DEFAULT_SPACETYPE UseEscF0
#define DEFAULT_MINSKIPSPACES 5	/* smallest number of spaces worth converting */

#define DEFAULT_VSPREAD 1	/* If successive vertical rows of bits are not
				 supposed to go to successive pins. */

#define DEFAULT_VADDVSTR "\x1b" "J" "%c" /* String passed to fprintf() to
					  advance by n rows */

#define CONFIG_FILE "/usr/lib/texmf/fonts/eps.config"
#define PRINTERNAME "EpsonMXFX" /* What name to look for in CONFIG_FILE */

/* The following are used to in eps.c to open a pipe to the print command */
#define PRINTCMD "lpr"
#define PRINTSWITCH "-P"
  
#endif
