#ifndef parse_h
#define parse_h

int FindPrinter();

#endif
