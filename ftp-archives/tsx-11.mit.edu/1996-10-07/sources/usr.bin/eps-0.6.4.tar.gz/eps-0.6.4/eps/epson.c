/* Copyright (c) 1993 Neal Becker
 * All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

static const char rcsid[] = "epson.c,v 1.3 1993/10/02 03:23:12 neal Exp";

#include "epson.h"


#if defined( __MSDOS__ ) && !defined( __GNUC__ )
#include <mem.h>
#endif /* __MSDOS__ */

#include <stdlib.h>
#include "PROTO.h"

BitMapRow::BitMapRow ()
{
  if ((Bits = new char[HBytes]) == 0)
    GripeOutOfMemory (HBytes, "BitMap");
  Printed = Length = 0;
}

void BitMapRow::
Clear ()
{
  memset (Bits, 0, HBytes);
  Printed = Length = 0;
}

BitMap::BitMap ()
{
  if ((Rows = new BitMapRow *[BitMapRows]) == NULL)
    GripeOutOfMemory (sizeof (BitMapRow *) * (BitMapRows),
		      "BitMap");
  for (int i = 0; i < (BitMapRows); i++)
    {
      if ((Rows[i] = new BitMapRow) == NULL)
	GripeOutOfMemory (sizeof (BitMapRow), "BitMap");
    }
}

void BitMap::
Clear ()
{
  for (int i = 0; i < (BitMapRows); i++)
    Rows[i]->Clear ();
}

#if defined __MSDOS__ && !defined( __GNUC__ )

#include <alloc.h>
void
ReportMem ()
{
  fprintf (stderr, "%lX Bytes Left\n", (unsigned long) farcoreleft ());
}

#else /* __MSDOS__ */

void
ReportMem ()
{
}

#endif /* __MSDOS__ */

epson::
epson( FILE* f, param& P ) :
fp (f), DviPos (0), PrintPos (0), PrintEngine( P.Engine ),
  VPins( P.VPins ), DPIh( P.DPIh ), DPIv( P.DPIv ), 
  GraphicsMode( P.GraphicsMode ), VInc( P.VInc ), HInc( P.HInc ),
  VInterleave( P.VInterleave ),
  InitString( P.InitString), ResetString( P.ResetString ),
  DotsPerSpace( DPIh / SpacesPerInch ),
  MinSkippable( P.MinSkipSpaces * DotsPerSpace ),
  VSpread( P.VSpread ), VaddvStr( P.VaddvStr ),
  VBytes( ( ( VPins * VSpread ) + 7 ) / 8 )
{
  Init ();
  Reset ();

  switch( P.SpaceType ) {
  case param::UseEscF0:
    DoSpaces = UseEscF0; break;
  case param::UseTabs:
    DoSpaces = UseTabs; break;
  case param::UseSpaces:
    DoSpaces = UseSpaces; break;
  }
  HPixels = (int) (DPIh * P.Width);
  VPixels = (int) (DPIv * P.Height);
  HBytes = (HPixels + 7) / 8;
  BitMapRows = VPixels;
  if( P.VSkip <= DPIv ) {
    VSkipUnit = DPIv / P.VSkip;
    VSkipRpt = 1;
  }
  else {
    VSkipUnit = 1;
    VSkipRpt = P.VSkip / DPIv;
  }
  if( ( OutBuff = new char[ HPixels * VBytes ] ) == NULL )
    GripeOutOfMemory (sizeof (char) * HPixels * VBytes, "OutBuff");
  if( MinSkippable > 0 ) {
    if( ( Zeros = new char[ VBytes * MinSkippable ] ) == NULL )
      GripeOutOfMemory (sizeof (char) * VBytes * MinSkippable, "Zeros");
    memset( Zeros, 0, VBytes * MinSkippable );
  }
}

void epson::
PrintBitMap (BitMap & theBitMap)
{
  for (DviPos = 0; DviPos < BitMapRows; DviPos++)
    {
      if (theBitMap.NeedToPrint (DviPos))
	PrintRow (theBitMap, DviPos);
    }
  if (ferror (fp))
    panic ("error writing output");
}

void epson::
PrintRow (BitMap & theBitMap, int Row)
{
  SetVpos (Row);		/* SetVpos can only move in increments of VSkipUnit. */
  OutputRow( theBitMap, PrintPos );	/* So Output is at PrintPos (updated by SetVpos) */
};

int epson::
RoundUpToSpace( int HBit ) {
  return ( (HBit + DotsPerSpace - 1) / DotsPerSpace ) * DotsPerSpace;
}

int epson::
RoundDownToSpace( int HBit ) {
  return (HBit / DotsPerSpace) * DotsPerSpace;
}

int epson::
FindNextSkip( int HBit, int Length ) {
  if( MinSkippable <= 0 )
    return Length + 1;
  else {
    HBit = RoundUpToSpace( HBit );
    for( ; HBit <= Length; HBit += DotsPerSpace ) {
      if( IsSkippable( HBit, Length ) )
	return HBit;
    }
    return Length + 1;
  }
}

int epson::
IsSkippable( int HBit, int Length ) {
  if( HBit + MinSkippable >= Length )
    return 0;
  else {
    if(
       memcmp( OutBuff + ( HBit * VBytes ), Zeros, MinSkippable * VBytes )
       == 0 )
      return 1;
    else
      return 0;
  }
}

void epson::
DoSkip( int& HBit, int Length ) {
  int SkipPixelLength = RoundDownToSpace( BlankLength( HBit, Length ) );
  int SkipSpaces = SkipPixelLength / DotsPerSpace;
  (this->*DoSpaces)( SkipSpaces, HBit/DotsPerSpace );
  HBit += SkipPixelLength;
}

void epson::
UseEscF0( int Spaces, int CurrentSpacePos ) {
  fputs( "\x1b" "f0", fp );
  fputc( Spaces, fp );
}

void epson::
UseTabs( int Spaces, int CurrentSpacePos ) {
  fputs( "\x1b" "D", fp );
  fputc( CurrentSpacePos + Spaces, fp );
  fputc( 0, fp );
  fputc( '\t', fp );
}

void epson::
UseSpaces( int Spaces, int CurrentSpacePos ) {
  for( ; Spaces > 0; Spaces-- )
    fputc( ' ', fp );
}

int epson::
BlankLength( int HBit, int Length ) {
  for( int i = 0; HBit + i < Length; i++ )
    if( !IsBlank( HBit + i ) )
      return i;
  return Length - HBit;
}

/* Is this column of pixels blank? */
int epson::
IsBlank( int HBit ) {
  return memcmp( OutBuff + ( HBit * VBytes ), Zeros, VBytes ) == 0;
}
  
void epson::
OutputData( int HBit, int Chunk ) {
  char n1 = Chunk & 0xff;
  char n2 = (unsigned) (Chunk) >> 8;
  fputs( GraphicsMode, fp );
  fputc( n1, fp );
  fputc( n2, fp );
  for( int i = 0; i < Chunk; i++ )
    for( int j = 0; j < VBytes; j++ )
      fputc( OutBuff[ ( VBytes * ( HBit + i ) ) + j], fp );
}

void epson::
OutputRow( BitMap& theBitMap, int Row)
{
  for( int HPass = 0; HPass < HInc; HPass++ ) {
    int LastBitPos = theBitMap.FindLength (Row, VPins, VInterleave, VInc);

    int HBit;

    memset( OutBuff, 0, ( LastBitPos + 1 ) * VBytes );
    
// MaxHBit is like LastBitPos, but since we may be making 2 passes
// (HInc != 1) we need to find out where is the last bit.  MaxHBit
// is updated by Encode().

    MaxHBit = 0;
    for (HBit = 0; HBit <= LastBitPos; HBit++) {
      if( HBit % HInc == HPass )
	Encode (theBitMap, Row, HBit);
    }

    for( HBit = 0; HBit <= MaxHBit; ) {
      int NextSkipPos = FindNextSkip( HBit, MaxHBit );
      if( HBit != NextSkipPos ) {
	int Chunk = min( NextSkipPos, MaxHBit + 1 ) - HBit;
	OutputData( HBit, Chunk );
	HBit += Chunk;
      }
      if( HBit <= MaxHBit )
	DoSkip( HBit, MaxHBit );
    }
    

    Eol ();
  }

  for (int V = 0; V < VPins; V += VInc) {
    int TheRow = Row + (V * VInterleave);
    if (TheRow >= BitMapRows)
      break;
    theBitMap.Mark (TheRow);
  }
}

void epson::
Encode (BitMap & theBitMap, int Row, int HBit)
{
  int BytePos = HBit / 8;
  int BitPos = 7 - (HBit % 8);

  for (int VBit = 0; VBit < VPins; VBit += VInc)
    {
      int TheRow = Row + (VBit * VInterleave);
      if (TheRow >= BitMapRows)
	break;
      char TheChar = theBitMap.Rows[TheRow]->Bits[BytePos];
      if (TheChar & BitMask[BitPos])
	SetPin( HBit, VBit );
    }
}

void epson::SetPin( int HBit, int VBit ) {
  int PinNumber = VBit * VSpread;
  int PinByte = PinNumber / 8;
  int PinBit = 7 - ( PinNumber % 8 );
  OutBuff[ ( HBit * VBytes ) + PinByte ] |= BitMask[ PinBit ];
  MaxHBit = max( MaxHBit, HBit );
}

int BitMap::
FindLength (int Row, int VPins, int VInterleave, int VInc)
{
  for (int i = 0, l = 0; i < VPins; i += VInc)
    {
      int TheRow = Row + (i * VInterleave);
      if (TheRow >= BitMapRows)
	break;
      l = max (l, Rows[TheRow]->Length);
    }
  return l;
}

				/* Set vertical position of printer to a given row */
				/* Note that max advance is 255 (1 byte) */
void epson::
SetVpos (int n)
{
  while ( ( n - PrintPos ) / VSkipUnit > 255  )
    Vaddv (255);
  Vaddv ( ( n - PrintPos ) / VSkipUnit );
}

				/* Advance by n * VSkipUnit rows */
void epson::
Vaddv (int n)
{
//  fputs ("\x1b" "J", fp);
//  fputc ( n, fp);
  for( int i = 0; i < VSkipRpt; i++ )
    fprintf( fp, VaddvStr, n );
  PrintPos += n * VSkipUnit;
}
