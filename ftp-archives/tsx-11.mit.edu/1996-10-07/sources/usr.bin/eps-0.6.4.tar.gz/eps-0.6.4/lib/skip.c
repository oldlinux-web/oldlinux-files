#include "PROTO.h"
/*
 * Copyright (c) 1987, 1989 University of Maryland
 * Department of Computer Science.  All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

#ifndef lint
static char rcsid[] = "/usr/local/src/CVS/eps/lib/skip.c,v 1.1.1.1 1993/10/02 01:50:19 neal Exp";
#endif

#include <stdio.h>
#include "types.h"
#include "fio.h"

/*
 * Skip a font definition.  The font number has already been consumed.
 */
extern void SkipFontDef(register FILE *fp)
{
	register int i;

	(void) GetLong(fp);	/* checksum */
	(void) GetLong(fp);	/* mag */
	(void) GetLong(fp);	/* designsize */
	i = UnSign8(GetByte(fp)) + UnSign8(GetByte(fp));
	while (--i >= 0)
		(void) GetByte(fp);
}
