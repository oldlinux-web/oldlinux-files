/* Copyright (c) 1993 Michael Klemme, klemme@uni-paderborn.de
 * All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

#include "PROTO.h"
#include <string.h>
#include <stdlib.h>

extern int SFlag; /* defined in ../eps/eps.c */

#define COMMAND "MakeTeXPK %s  %d  %d %.3f %s %s"
/*Parameters are:         name dpi bdpi magnification mode path*/

extern int MakeFont(const char *basename, int base_res, int res, double mag, 
			const char *mode, char *path)
{
  char command[200];
  int status;

/* path is absolute path to the desired font file */
  char* fp = strsave( path );
/* pass just the dirname to MakeTeXPK */
  char* end = strrchr( fp, '/' );
  if( end )
    *end = '\0';
  
  sprintf(command, COMMAND, basename, res, base_res,
	  mag, mode, fp);

  (void)fprintf(stderr, "- %s\n", command) ;

  /*stdout is used for output, redirect stdout to stderr */
  if (SFlag) /* silent mode*/
    (void)strcat(command," >/dev/null ") ;
  else
    (void)strcat(command," >&2") ;  

  /* call MakeTeXPK */
  status = system(command);
  /* status = 1 <=> abnormal termination */

  free( fp );
  return (status);

};


