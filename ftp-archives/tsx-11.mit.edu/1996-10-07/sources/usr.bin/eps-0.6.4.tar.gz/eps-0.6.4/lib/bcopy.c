#include "PROTO.h"
#ifndef lint
static char rcsid[] = "/usr/local/src/CVS/eps/lib/bcopy.c,v 1.1.1.1 1993/10/02 01:50:19 neal Exp";
#endif

/*
 * Sample bcopy() routine.
 * This should be rewritten to be as fast as possible for your
 * machine.
 */

#ifndef __MSDOS__
bcopy(from, to, count)
	register char *from, *to;
	register int count;
{

	if (from == to)
		return;
	if (from > to) {
		while (--count >= 0)
			*to++ = *from++;
	} else {
		from += count;
		to += count;
		while (--count >= 0)
			*--to = *--from;
	}
}

#endif /* __MSDOS__ */
