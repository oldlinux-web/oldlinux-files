#include "PROTO.h"
#ifndef lint
static char rcsid[] = "/usr/local/src/CVS/eps/lib/bzero.c,v 1.1.1.1 1993/10/02 01:50:18 neal Exp";
#endif

/*
 * Sample bzero() routine.
 * This should be rewritten to be as fast as possible for your
 * machine.
 */
bzero(addr, count)
	register char *addr;
	register int count;
{

	while (--count >= 0)
		*addr++ = 0;
}
