#include "PROTO.h"
/*
 * Copyright (c) 1987, 1989 University of Maryland
 * Department of Computer Science.  All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

#ifndef lint
static char rcsid[] = "/usr/local/src/CVS/eps/lib/conv.c,v 1.1.1.1 1993/10/02 01:50:18 neal Exp";
#endif

/*
 * Conversions.
 */

#include "types.h"
#include "conv.h"

double	DMagFactor();

Conv	Conversion;		/* the global conversion */

/*
 * Set a conversion (possibly the global conversion).
 */
extern void CSetConversion(register struct conversion *c, int hdpi, int vdpi, int usermag, i32 num, i32 denom, i32 dvimag)
{
	double dhdpi = hdpi;
	double dvdpi = vdpi;

	c->c_mag = DMagFactor((int) dvimag) * DMagFactor(usermag);
	c->c_hdpi = dhdpi;
	c->c_vdpi = dvdpi;

	/*
	 * The conversion facture is figured as follows:  there are exactly
	 * num/denom DVI units per decimicron, and 254000 decimicrons per
	 * inch, and dpi pixels per inch.  Then we have to adjust this by
	 * the stated magnification. 
	 */
	c->c_fromsph = (num / 254000.0) * (dhdpi / denom) * c->c_mag;
	c->c_fromspv = (num / 254000.0) * (dvdpi / denom) * c->c_mag;

	/*
	 * c->c_tosp is 1/c->c_fromsp, but we will invert the expression
	 * above in the hopes of some extra accuracy.
	 *
	 * IS THIS ANY GOOD?  I NEED A NUMERICAL ANALYST!
	 */
	c->c_tosph = (254000.0 / num) * (denom / dhdpi) * (1.0 / c->c_mag);
	c->c_tospv = (254000.0 / num) * (denom / dvdpi) * (1.0 / c->c_mag);
}
