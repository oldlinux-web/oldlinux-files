#include "PROTO.h"
/*
 * Copyright (c) 1989 University of Maryland
 * Department of Computer Science.  All rights reserved.
 * Permission to copy for any purpose is hereby granted
 * so long as this copyright notice remains intact.
 */

#ifndef lint
static char rcsid[] = "/usr/local/src/CVS/eps/lib/tempfile.c,v 1.1.1.1 1993/10/02 01:50:20 neal Exp";
#endif

#include <stdio.h>
#include <sys/types.h>
#if !defined( __MSDOS__ ) || defined( __GNUC__ )
#  include <sys/file.h>
#else
#  include <fcntl.h>
#endif

#include <stdlib.h> /* for getenv */
#if defined( __MSDOS__ ) && !defined( __GNUC__ )
#  include <io.h>
#else
#  include <osfcn.h> /* for getpid, unlink, open */
#endif

FILE* MakeRWTempFile(register char *name)
{
  return( tmpfile() );
}
