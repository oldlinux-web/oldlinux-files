#include <stdio.h>
#include <sys/time.h>

int kbhit()
{
  unsigned long read,dummy;
  struct timeval t;

  if (stdin->_gptr < stdin->_egptr)
    { 
      return 1;
    }
  t.tv_sec=0;
  t.tv_usec=0;
  
  FD_ZERO(&read); FD_ZERO(&dummy);
  FD_SET(0,&read);
  
  if (select(1,&read,&dummy,&dummy,&t)<0)
    {
      perror("kbhit: select");
    }
  return (FD_ISSET(0,&read));
}
