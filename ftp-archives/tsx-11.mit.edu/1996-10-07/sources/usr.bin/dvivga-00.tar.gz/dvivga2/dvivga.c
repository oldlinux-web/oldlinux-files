/* latest revision Oct. 18, 1988 by JDM 
 
 
 
/* -*-C-*- dvivga.c */ 
/*-->dvivga*/ 
/**********************************************************************/ 
/******************************* dvivga *******************************/ 
/**********************************************************************/ 
#include "dvihead.h" 
 
 
/**********************************************************************/ 
/************************  Device Definitions  ************************/ 
/**********************************************************************/ 
 
/* All output-device-specific definitions go here.  This section must 
be changed when modifying a dvi driver for use on a new device */ 
 
 
#undef  DEBUG 
#define DEBUG 1 
#undef   VGASCREEN 
#define  VGASCREEN       1		/* conditional compilation flag */ 
 
 
 
 
#undef HIRES 
#define  HIRES		  0		/* this is 72 dpi version  */ 
 
#define VERSION_NO	"2.10"		/* DVI driver version number */ 
 
#define  DEVICE_ID	"VGA Screen Previewer" 
					/* this string is printed at runtime */ 
#define OUTFILE_EXT	"vga" 
 
#define  BYTE_SIZE        8		/* output file byte size */ 
 
#undef STDRES 
#define STDRES  0			/* 0 for low-resolution devices */ 
 
#define  XDPI           72 
#define  XPSIZE		8		/* horizontal paper size in inches */ 
#define  XSIZE          640 
#define  YPSIZE         14 
 
					/* 2*HOST_WORD_SIZE */ 
 
 
 
#define  XWORDS		((XSIZE + HOST_WORD_SIZE - 1)/HOST_WORD_SIZE) 
					/* number of words in rows  */ 
					/* of bitmap array */ 
 
#define  YDPI		XDPI		/* vertical dots/inch */ 
#define  YSIZE		(YDPI*YPSIZE)	/* number of vertical dots */ 
 
/* The printer bit map. */ 
 
#define XBIT XWORDS 
#define YBIT YSIZE 
 
#undef  SEGMEM 
#define SEGMEM 1  
 
#define  MINM  0 
 
int      firstlinepage, brokenprtpage; 
int      neednewpage, neednewbmap; 
double   newmagfact; 
int      first_picture = TRUE; 
int      maxm, nlines, oldvmode, displaycode ; 
 
UNSIGN32* bitmap[YBIT+1] = 
{ 
	(UNSIGN32*)NULL	/* only first entry need be initialized */ 
}; 
#define BITMAP(y,x) (bitmap[y] + (UNSIGN16)(x)) 
 
 
#include "main.h" 
#undef STDMAG 
#define STDMAG 550 
 
#include "abortrun.h" 
#include "actfact.h" 
#include "alldone.h" 
#include "chargf.h" 
#include "charpk.h" 
#include "charpxl.h" 
#include "clrbmap.h" 
#include "clrrow.h" 
#include "dbgopen.h" 
 
int  exfn(); 
 
 
int  exfn() 
{ 
    devterm(); 
    exit(1); 
} 
 
 
/*-->devinit*/ 
/**********************************************************************/ 
/****************************** devinit *******************************/ 
/**********************************************************************/ 
 
void 
devinit(argc,argv)		/* initialize device */ 
int argc; 
char *argv[]; 
{ 
  vga_setmode(G640x480x16);
  /**vga_setpalette(1,128,128,128);**/
  maxm=YBIT-480;
  nlines=480;
  (void)getbmap();  
} 
 
/*-->devterm*/ 
/**********************************************************************/ 
/****************************** devterm *******************************/ 
/**********************************************************************/ 
 
void 
devterm()			/* terminate device */ 
{ 
#if 0
   if(!first_picture)int86(16,&rg,&rg); 
#else
   vga_setmode(TEXT);
#endif
} 
 
#include "dispchar.h" 
#include "dvifile.h" 
#include "dviinit.h" 
#include "dviterm.h" 
#include "fatal.h" 
#include "fillrect.h" 
#include "findpost.h" 
#include "fixpos.h" 
#include "fontfile.h" 
#include "fontsub.h" 
 
void 
getbmap()				/* allocate bitmap array */ 
{ 
 
static unsigned long basebit[ (long)XBIT * (long)(YBIT+2)]; 
unsigned long *ibit; 
unsigned long i, j, k; 
unsigned y; 
    if (bitmap[0] == (UNSIGN32*)NULL) { 
 
        for (y = 0; y <= (UNSIGN16)YBIT; ++y) 
        { 
            ibit = (unsigned long *) &basebit[ y  * XBIT ]; 
                   /* UGH! fix up pointers to avoid segment overlap */ 
            bitmap[y] = (UNSIGN32*) ibit; 
        } 
    } 
} 
 
 
 
 
#include "getbytes.h" 
#include "getfntdf.h" 
#include "getpgtab.h" 
#include "inch.h" 
#include "initglob.h" 
#include "loadchar.h" 
 
/*-->makechar*/ 
/**********************************************************************/ 
/****************************** makechar ******************************/ 
/**********************************************************************/ 
 
char 
makechar(p,mask) 
UNSIGN32* p[]; 
register UNSIGN32 mask; 
{ 
 
} 
 
#include "movedown.h" 
#include "moveover.h" 
#include "moveto.h" 
#include "nosignex.h" 
#include "openfont.h" 
#include "option.h" 
 
/*-->outline*/ 
/**********************************************************************/ 
/****************************** outline *******************************/ 
/**********************************************************************/ 
 
 
void 
outline(pline) 
char *pline; 
{ 
 
} 
 
#include "outrow.h" 
 
/*-->prtbmap*/ 
/**********************************************************************/ 
/****************************** prtbmap *******************************/ 
/**********************************************************************/ 
void prtbmap() 
{ 
} 
#include "prtpage.h" 
#include "readfont.h" 
#include "readgf.h" 
#include "readpk.h" 
#include "readpost.h" 
#include "readpxl.h" 
#include "reldfont.h" 
#include "rulepxl.h" 
#include "setchar.h" 
#include "setfntnm.h" 
#include "setrule.h" 
#include "signex.h" 
#include "skgfspec.h" 
#include "skipfont.h" 
#include "skpkspec.h" 
#include "special.h" 
#include "strchr.h" 
#include "strcm2.h" 
#include "strid2.h" 
#include "strrchr.h" 
#include "tctos.h" 
#include "usage.h" 
#include "warning.h" 
 
 
void 
vgainit()		/* initialize device */ 
{ 
#if 0
    union REGS rg; 
    char *envptr; 
 
    *((unsigned long  *) (0x8c)) = (unsigned long)  exfn; 
    /* 
     * Oh my! That put a pointer to exfn() in the MS-DOS cntl-break 
     * interrupt vector!  
     */ 
 
    rg.h.ah = 15; 
    int86(16,&rg,&rg); 
    oldvmode = rg.h.al; 
 
    envptr = getenv("DVISCR"); 
    if(strcmp(envptr,"EGAM") == 0 && envptr != NULL) displaycode = 5; 
    else if(strcmp(envptr,"EGAC") == 0 && envptr != NULL) displaycode = 4; 
    else if(strcmp(envptr,"VGAM") == 0 && envptr != NULL) displaycode = 7; 
    else if(strcmp(envptr,"VGAC") == 0 && envptr != NULL) displaycode = 30; 
    else { 
 
        rg.x.ax = 0x1a00; 
        int86(16,&rg,&rg); 
        if(rg.h.al == 0x1a) { 
           displaycode = rg.h.bl; 
        } else { 
           rg.h.ah = 0x12; 
           rg.h.bl = 16; 
           int86(16,&rg,&rg); 
           if(rg.h.bl == 16) { 
               displaycode = 0; 
           } else { 
               if (oldvmode == 7) displaycode = 5; 
               else displaycode = 4; 
           } 
        } 
    } 
    switch (displaycode) { 
       case 4: 
           rg.x.ax = 16; 
           maxm =  YBIT-350; 
           nlines = 350; 
           break; 
       case 5: 
           rg.x.ax = 15; 
           maxm =  YBIT-350; 
           nlines = 350; 
           break; 
       case 7: 
       case 8: 
       case 11: 
       case 12: 
           rg.x.ax = 17; 
           maxm =  YBIT-480; 
           nlines = 480; 
           break; 
       case 30: 
           rg.x.ax = 18; 
           maxm = YBIT-480; 
           nlines = 480; 
           break; 
       default: 
           puts("Invalid display adapter - requires EGA, VGA, or MCGA."); 
           exit(1); 
    } 
    int86(16,&rg,&rg); 
#else

#endif
} 
 
 
void 
drawbmap(mline) 
int mline; 
{ 
 
    register char *c;			/* pointer into v7[] */ 
    unsigned char *q; 
    unsigned char  *sc; 
    register UNSIGN32 mask;		/* mask for single bit selection */ 
    INT16 i,j,k,brow,ybottom,ytop; 
    static char row[640];

    if(first_picture){ 
        first_picture = FALSE; 
        vgainit(); 
    } 
 
    ytop = YBIT-nlines-mline; 
    for (brow=0, i = nlines-1; i >= 0; i--, brow++) { 
        q = (unsigned char *)BITMAP((ytop+i),0); 
	sc=&row[0];

#define COLOUROF(x) (x? 15 : 0)
#define RCOLOUROF(x) (x? 0 : 15)
        if(reversevideo){ /* reverse video */
            for (j = 0; j < 640; j+=32, q += 4) { 
	      *sc++= RCOLOUROF(q[3] & 0x80);
	      *sc++= RCOLOUROF(q[3] & 0x40);
	      *sc++= RCOLOUROF(q[3] & 0x20);
	      *sc++= RCOLOUROF(q[3] & 0x10);
	      *sc++= RCOLOUROF(q[3] & 0x08);
	      *sc++= RCOLOUROF(q[3] & 0x04);
	      *sc++= RCOLOUROF(q[3] & 0x02);
	      *sc++= RCOLOUROF(q[3] & 0x01);
	      *sc++= RCOLOUROF(q[2] & 0x80);
	      *sc++= RCOLOUROF(q[2] & 0x40);
	      *sc++= RCOLOUROF(q[2] & 0x20);
	      *sc++= RCOLOUROF(q[2] & 0x10);
	      *sc++= RCOLOUROF(q[2] & 0x08);
	      *sc++= RCOLOUROF(q[2] & 0x04);
	      *sc++= RCOLOUROF(q[2] & 0x02);
	      *sc++= RCOLOUROF(q[2] & 0x01);
	      *sc++= RCOLOUROF(q[1] & 0x80);
	      *sc++= RCOLOUROF(q[1] & 0x40);
	      *sc++= RCOLOUROF(q[1] & 0x20);
	      *sc++= RCOLOUROF(q[1] & 0x10);
	      *sc++= RCOLOUROF(q[1] & 0x08);
	      *sc++= RCOLOUROF(q[1] & 0x04);
	      *sc++= RCOLOUROF(q[1] & 0x02);
	      *sc++= RCOLOUROF(q[1] & 0x01);
	      *sc++= RCOLOUROF(q[0] & 0x80);
	      *sc++= RCOLOUROF(q[0] & 0x40);
	      *sc++= RCOLOUROF(q[0] & 0x20);
	      *sc++= RCOLOUROF(q[0] & 0x10);
	      *sc++= RCOLOUROF(q[0] & 0x08);
	      *sc++= RCOLOUROF(q[0] & 0x04);
	      *sc++= RCOLOUROF(q[0] & 0x02);
	      *sc++= RCOLOUROF(q[0] & 0x01);
	     } 
	    vga_drawscanline(brow,row);
	    
        }  else { 
	  for (j = 0; j < 640; j+=32, q += 4) 	 {
	      *sc++= COLOUROF(q[3] & 0x80);
	      *sc++= COLOUROF(q[3] & 0x40);
	      *sc++= COLOUROF(q[3] & 0x20);
	      *sc++= COLOUROF(q[3] & 0x10);
	      *sc++= COLOUROF(q[3] & 0x08);
	      *sc++= COLOUROF(q[3] & 0x04);
	      *sc++= COLOUROF(q[3] & 0x02);
	      *sc++= COLOUROF(q[3] & 0x01);
	      *sc++= COLOUROF(q[2] & 0x80);
	      *sc++= COLOUROF(q[2] & 0x40);
	      *sc++= COLOUROF(q[2] & 0x20);
	      *sc++= COLOUROF(q[2] & 0x10);
	      *sc++= COLOUROF(q[2] & 0x08);
	      *sc++= COLOUROF(q[2] & 0x04);
	      *sc++= COLOUROF(q[2] & 0x02);
	      *sc++= COLOUROF(q[2] & 0x01);
	      *sc++= COLOUROF(q[1] & 0x80);
	      *sc++= COLOUROF(q[1] & 0x40);
	      *sc++= COLOUROF(q[1] & 0x20);
	      *sc++= COLOUROF(q[1] & 0x10);
	      *sc++= COLOUROF(q[1] & 0x08);
	      *sc++= COLOUROF(q[1] & 0x04);
	      *sc++= COLOUROF(q[1] & 0x02);
	      *sc++= COLOUROF(q[1] & 0x01);
	      *sc++= COLOUROF(q[0] & 0x80);
	      *sc++= COLOUROF(q[0] & 0x40);
	      *sc++= COLOUROF(q[0] & 0x20);
	      *sc++= COLOUROF(q[0] & 0x10);
	      *sc++= COLOUROF(q[0] & 0x08);
	      *sc++= COLOUROF(q[0] & 0x04);
	      *sc++= COLOUROF(q[0] & 0x02);
	      *sc++= COLOUROF(q[0] & 0x01);
	    } 
	    vga_drawscanline(brow,row);

	  } 
    } 
} 
 
/*-->unloadfonts*/ 
/**********************************************************************/ 
/***************************** unloadfonts ****************************/ 
/**********************************************************************/ 
 
void 
unloadfonts()			/* mark all fonts as not loaded */ 
{				/* and set no current fonts */ 
 
    for (fontptr = hfontptr; fontptr != (struct font_entry *)NULL; 
	 fontptr = fontptr->next) 
    { 
	if (fontptr->font_file_id != (FILE*)NULL) 
	{ 
	    (void)fclose(fontptr->font_file_id); 
	    fontptr->font_file_id = (FILE*)NULL; 
	} 
    } 
 
    fontfp = (FILE*)NULL;		/* no current font file */ 
    for ( ; nopen > 0; --nopen)		/* clear font file cache */ 
    { 
	font_files[nopen].font_id = (FILE*)NULL; 
	font_files[nopen].use_count = (INT16)0; 
    } 
 
 
} 
 
 
vgasequence()			/* end-of-page action */ 
{ 
    UNSIGN32 oldrunmag; 
    firstlinepage = 0; 
    cur_index = 0; 
    neednewpage = 1; 
    newmagfact = (double)1.; 
 
    while(1)
      { 
	neednewbmap = 0;     
	if(/*!first_picture || */ (kbhit() != 0))
	  collectkeys(); 
    
	if(neednewpage)
	  { 
	    if(newmagfact != (double)1){ 
	      do{ 
		oldrunmag = runmag; 
		runmag = MAGSIZE(actfact((UNSIGN32) 
					 ((double)runmag*newmagfact))); 
		conv = ((float)num/(float)den) * 
		  ((float)runmag/(float)STDMAG) * 
#if    USEGLOBALMAG 
		    actfact(mag) * 
#endif 
		      ((float)RESOLUTION/254000.0); 
		newmagfact = (double)1; 
		unloadfonts(); 
 
 
		/* NB: It is important here that the loop index be global; the relation 
		   of fontptr to pfontptr is used by openfont() to decide whether the font 
		   file is already open. */ 
 
		for (fontptr = hfontptr; fontptr != (struct font_entry *)NULL; 
		     fontptr = fontptr->next) 
		  { 
		    pfontptr = (struct font_entry *)(NULL); 
		    /* so reldfont() calls openfont() */ 
		    (void)reldfont(fontptr); 
		    /* get new font metrics */ 
		    if(kbhit())
		      collectkeys(); 
		    if(newmagfact != (double)1.) 
		      break; 
		  } 
	      } while( newmagfact != (double)1); 
 
	    } 
	    brokenprtpage = 0; 
	    prtpage(page_ptr[cur_index]); 
	    if(!brokenprtpage){ 
	      neednewpage = 0; 
	      neednewbmap = 1; 
	    } 
	  }
	if((!brokenprtpage) && neednewbmap)
	  drawbmap(firstlinepage); 
      } 
} 
 
 
 
collectkeys() 
{ 
 
unsigned   keyhit; 
unsigned   char tc, extend ; 
int        oldm, np; 
 
 
    do { 
 
        tc = getch(); 
 
	switch(tc) 
	  { 
	  case 'q':		/* quit */ 
	  case 'Q': 
	  case 'x':		/* exit */ 
	  case 'X': 
	  case '\003':		/* CTL-C */ 
	  case '\031':		/* CTL-Y */ 
	    (void)devterm();	/* terminate device output */ 
	    (void)dviterm();	/* terminate DVI file processing */ 
	    (void)alldone();	/* this does not return */ 
	  case 'r': 
	    leftmargin += (double)0.25; 
	    lmargin = (COORDINATE)(leftmargin*((float)XDPI)); 
	    neednewpage = 1; 
	    break; 
	  case 'R': 
	    leftmargin += (double)1.0; 
	    lmargin = (COORDINATE)(leftmargin*((float)XDPI)); 
	    neednewpage = 1; 
	    break; 
	  case 'l': 
	    leftmargin -= (double)0.25; 
	    lmargin = (COORDINATE)(leftmargin*((float)XDPI)); 
	    neednewpage = 1; 
	    break; 
	  case 'L': 
	    leftmargin -= (double)1.0; 
	    lmargin = (COORDINATE)(leftmargin*((float)XDPI)); 
	    neednewpage = 1; 
	    break; 
	  case 'd': 
	    topmargin += (double)0.25; 
	    tmargin = (COORDINATE)(topmargin*((float)YDPI)); 
	    neednewpage = 1; 
	    break; 
	  case 'D': 
	    topmargin += (double)1.0; 
	    tmargin = (COORDINATE)(topmargin*((float)YDPI)); 
	    neednewpage = 1; 
	    break; 
	  case 'u': 
	    topmargin -= (double)0.25; 
	    tmargin = (COORDINATE)(topmargin*((float)YDPI)); 
	    neednewpage = 1; 
	    break; 
	  case 'U': 
	    topmargin -= (double)1.0; 
	    tmargin = (COORDINATE)(topmargin*((float)YDPI)); 
	    neednewpage = 1; 
	    break; 
	  case '\r': 
	  case '\n':          
	    if (cur_index < page_count -1){ 
	      cur_index++; 
	      firstlinepage = 0; 
	      neednewpage = 1; 
	    } 
	    break; 
	  case '0':		/* goto n-th page */ 
	  case '1': 
	  case '2': 
	  case '3': 
	  case '4': 
	  case '5': 
	  case '6': 
	  case '7': 
	  case '8': 
	  case '9': 
	    oldm = cur_index; 
	    np = tc - 48; 
	    while(1) { 
	      while(!kbhit()); 
	      tc = getch(); 
	      if(tc == 0) (void)getch(); 
	      else { 
		if(tc == 27) goto escape;   
		if(tc == '\r') break; 
		tc -= 48; 
		if(tc >= 0 && tc <= 9) np = np*10 + tc; 
	      } 
	    }      
	    if(np < 0) np = 0; 
	    if(np > page_count) np = page_count; 
	    cur_index = np - 1; 
	    if(oldm != cur_index) { 
	      firstlinepage = 0; 
	      neednewpage = 1; 
	    } 
	  escape: 
	    break; 
	  case 'b': 
	    newmagfact *= sqrt((double)1.2); 
	    neednewpage = 1; 
	    break; 
	  case 'B': 
	    newmagfact *= (double)1.2; 
	    neednewpage = 1; 
	    break; 
	  case 's': 
	    newmagfact /= sqrt((double)1.2); 
	    neednewpage = 1; 
	    break; 
	  case 'S': 
	    newmagfact /= (double)1.2; 
	    neednewpage = 1; 
	    break; 
	  default: 
	    break; 
	  } 
      } while (kbhit()); 
} 
