/*
 * $Header: /u3/src/rfmail/RCS/timeb.h,v 0.4.1.6 1992/03/15 07:58:52 pgd Exp pgd $
 *
 * $Log: timeb.h,v $
 * Revision 0.4.1.6  1992/03/15  07:58:52  pgd
 * Untested version
 *
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

struct timeb {
	time_t		time;
	unsigned short	millitm;
	short		timezone;
	short		dstflag;
};
