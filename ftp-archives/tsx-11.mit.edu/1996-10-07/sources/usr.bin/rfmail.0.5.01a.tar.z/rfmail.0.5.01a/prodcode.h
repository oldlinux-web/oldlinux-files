static char *prodcode[] = {

/*  */
/*  code,name,environment,function,contact,net address */
/*  */
"Fido",	/* 00,MS-DOS,Packer/mailer,Tom Jennings,1:125/111 */
"Rover",	/* 01,MS-DOS,Packer/mailer,Bob Hartman,1:104/501 */
"SEAdog",	/* 02,MS-DOS,Packer/mailer,Thom Henderson,1:107/542.1 */
"WinDog",	/* 03,MS-DOS,Mailer,Solar Wind Computing,1:115/333 */
"Slick-150",	/* 04,HP-150,Packer/mailer,Jerry Bain,???? */
"Opus",	/* 05,MS-DOS,Packer/mailer,Doug Boone,1:124/4227 */
"Dutchie",	/* 06,MS-DOS,Packer/mailer,Henk Wevers,2:500/1 */
"WPL Library",	/* 07,Amiga,Mailer,Russell McOrmand,1:163/109 */
"Tabby",	/* 08,Macintosh,Packer/mailer,Michael Connick,1:107/412 */
"SWMail",	/* 09,OS/2,Mailer,Solar Wind Computing,1:115/333 */
"Wolf-68k",	/* 0A,CPM-68k,Packer/mailer,Robert Heller,1:321/153 */
"QMM",	/* 0B,QNX,Packer/mailer,Rick Duff,1:167/201 */
"FrontDoor",	/* 0C,MS-DOS,Packer/mailer,Joaquim Homrighausen,2:270/17 */
"GOmail",	/* 0D,MS-DOS,Packer,Scott Green,???? */
"FFGate",	/* 0E,MS-DOS,Packer,Ruedi Kneubuehler,2:301/580 */
"FileMgr",	/* 0F,MS-DOS,Packer,Erik van Emmerik,2:281/611 */
"FIDZERCP",	/* 10,MS-DOS,Packer,Thorsten Seidel,2:242/55 */
"MailMan",	/* 11,MS-DOS,Packer,Ron Bemis,1:124/1113 */
"OOPS",	/* 12,MS-DOS,Packer,Tom Kashuba,1:322/379 */
"GS-Point",	/* 13,Atari ST,Packer/mailer,Harry Lee,1:124/4230 */
"BGMail",	/* 14,????,????,Ray Gwinn,1:265/104 */
"ComMotion/2",	/* 15,OS/2,Packer/mailer,Michael Buenter,2:301/602 */
"OurBBS Fidomailer",	/* 16,MS-DOS/Unix/Coherent,Packer/mailer,Brian Keahl,1:133/524 */
"FidoPcb",	/* 17,MS-DOS,Packer,Matjaz Koce,2:380/100 */
"WimpLink",	/* 18,Archimedes,Packer/mailer,Remco de Vreugd,2:283/307 */
"BinkScan",	/* 19,MS-DOS,Packer,Shawn Stoddard,1:362/101 */
"D'Bridge",	/* 1A,MS-DOS,Packer/mailer,Chris Irwin,1:18/68 */
"BinkleyTerm",	/* 1B,MS-DOS,Mailer,Vince Perriello,1:343/491 */
"Yankee",	/* 1C,MS-DOS,Packer,Randy Edwards,???? */
"uuGate",	/* 1D,MS-DOS,Packer,Geoff Watts,3:690/710 */
"Daisy",	/* 1E,Apple ][,Packer/mailer,Raymond & Ken Lo,3:700/1 */
"Polar Bear",	/* 1F,????,Packer/mailer,Kenneth McLeod,1:101/190 */
"The-Box",	/* 20,MS-DOS/Atari ST,Packer/mailer,Jac Kersing/Arjen Lentz,2:283/333 */
"STARgate/2",	/* 21,OS/2,Packer/mailer,Shawn Stoddard,1:362/101 */
"TMail",	/* 22,MS-DOS,Packer,Larry Lewis,3:713/600.1701 */
"TCOMMail",	/* 23,MS-DOS,Packer/mailer,Mike Ratledge,1:372/888 */
"Bananna",	/* 24,Macintosh,Packer/mailer,Joe Keenan,1:109/401 */
"RBBSMail",	/* 25,MS-DOS,Packer,Jan Terpstra,2:512/10 */
"Apple-Netmail",	/* 26,Apple ][,Packer/mailer,Bill Fenner,1:129/87 */
"Chameleon",	/* 27,Amiga,Mailer,Juergen Hermann,2:241/2.12 */
"Majik Board",	/* 28,MS-DOS,Packer/mailer,Dale Barnes,1:3601/14.20 */
"QM",	/* 29,MS-DOS,Packer,George Peace,1:270/101 */
"Point And Click",	/* 2A,Amiga,Packer,Rob Tillotson,1:201/40.302 */
"Aurora Three Bundler",	/* 2B,MS-DOS,Packer,Oliver McDonald,???? */
"FourDog",	/* 2C,MS-DOS,Packer,Shay Walters,1:376/12 */
"MSG-PACK",	/* 2D,MS-DOS,Packer,Tom Hendricks,1:261/662 */
"AMAX",	/* 2E,MS-DOS,Packer,Alan Applegate,1:104/36 */
"Domain Communication System",	/* 2F,????,????,Hal Duprie,1:101/106 */
"LesRobot",	/* 30,????,Packer,Lennart Svensonn,2:501/2 */
"Rose",	/* 31,MS-DOS,Packer/mailer,Glen Jackson,1:100/617 */
"Paragon",	/* 32,Amiga,Packer/mailer,Jon Radoff,1:322/545 */
"BinkleyTerm/oMMM/ST",	/* 33,Atari ST,Packer/mailer,Peter Glasmacher,1:143/9 */
"StarNet",	/* 34,Atari ST,Mailer,Eric Drewry,1:322/566 */
"ZzyZx",	/* 35,MS-DOS,Packer,Jason Steck,1:124/424 */
"QEcho",	/* 36,MS-DOS,Packer,The QuickBBS Group,1:363/1701 */
"BOOM",	/* 37,MS-DOS,Packer,Andrew Farmer,1:243/1 */
"PBBS",	/* 38,Amiga,Packer/mailer,Todd Kover,1:261/1028 */
"TrapDoor",	/* 39,Amiga,Mailer,Maximilian Hantsch,2:310/6 */
"Welmat",	/* 3A,Amiga,Mailer,Russell McOrmand,1:163/109 */
"NetGate",	/* 3B,Unix-386,Packer,David Nugent,3:632/348 */
"Odie",	/* 3C,MS-DOS,Mailer,Matt Farrenkopf,1:105/376 */
"Quick Gimme",	/* 3D,CPM-80/MS-DOS,Packer/mailer,Laeeth Isaacs,2:254/18 */
"dbLink",	/* 3E,MS-DOS,Packer/mailer,Chris Irwin,1:18/68 */
"TosScan",	/* 3F,MS-DOS,Packer,Joaquim Homrighausen,2:270/17 */
"Beagle",	/* 40,MS-DOS,Mailer,Alexander Holy,2:310/90 */
"Igor",	/* 41,MS-DOS,Mailer,Harry Lee,1:124/4230 */
"TIMS",	/* 42,MS-DOS,Packer/mailer,Bit Bucket Software,1:104/501 */
"Isis",	/* 43,MS-DOS,Packer/mailer,Mike Bryeans,???? */
"FrontDoor APX",	/* 44,MS-DOS,Packer/mailer,Joaquim Homrighausen,2:270/17 */
"XRS",	/* 45,MS-DOS,Packer,Mike Ratledge,1:372/888 */
"Juliet Mail System",	/* 46,Amiga,Packer,Gregory Kritsch,1:163/109.30 */
"Jabberwocky",	/* 47,Macintosh,Packer,Eric Larson,1:2605/620 */
"XST",	/* 48,MS-DOS,Packer,Wayne Michaels,1:380/100 */
"MailStorm",	/* 49,Amiga,Packer,Russel Miranda,1:268/106 */
"BIX-Mail",	/* 4A,????,Mailer,Bob Hartman,1:104/501 */
"IMAIL",	/* 4B,MS-DOS,Packer,IMAIL INC.,2:246/47 */
"FTNGate",	/* 4C,MS-DOS,Packer,Jason Steck,1:104/424 */
"RealMail",	/* 4D,MS-DOS,Packer,Taine Gilliam,1:372/42 */
"Lora-CBIS",	/* 4E,MS-DOS,Mailer,Marco Maccaferri,2:332/402 */
"TDCS",	/* 4F,PDP-11,Packer/mailer,Terry Ebdon,2:254/6 */
"InterMail",	/* 50,MS-DOS,Packer/mailer,Peter Stewart,1:369/35 */
"RFD",	/* 51,MS-DOS,Packer,Doug Belkofer,1:234/10 */
"Yuppie!",	/* 52,MS-DOS,Packer,Leo Moll,2:242/2 */
"EMMA",	/* 53,MS-DOS,Packer,Johan Zwiekhorst,2:292/100 */
"QBoxMail",	/* 54,QDOS,Packer/mailer,Jan Bredenbeek,2:283/500 */
"Number 4",	/* 55,MS-DOS,Packer/mailer,Ola Garstad,2:502/15 */
"Number 5",	/* 56,MS-DOS,Packer/mailer,Ola Garstad,2:502/15 */
"GSBBS",	/* 57,MS-DOS,Packer,Michelangelo Jones,1:260/244 */
"Merlin",	/* 58,MS-DOS,Packer/mailer,Mark Lewis,2:258/25 */
"TPCS",	/* 59,MS-DOS,Packer,Mikael Kjellstrom,2:201/211 */
"Raid",	/* 5A,MS-DOS,Packer,George Peace,1:270/101 */
"Outpost",	/* 5B,MS-DOS,Packer/mailer,Mike Dailor,???? */
"Nizze",	/* 5C,MS-DOS,Packer,Tomas Nielsen,2:205/202 */
"Armadillo",	/* 5D,Macintosh,Packer,Erik Sea,1:221/109 */
"rfmail",	/* 5E,Unix,Packer/mailer,Per Lindqvist,2:201/332 */
"Msgtoss",	/* 5F,MS-DOS,Packer,Mike Zakharoff,1:343/36 */
"InfoTex",	/* 60,MS-DOS,Packer/mailer,Jan Spooren,2:292/852 */
"GEcho",	/* 61,MS-DOS,Packer,Gerard van der Land,2:283/1.5 */
"CDEhost",	/* 62,MS-DOS,Packer,Dennis D'Annunzio,1:379/28 */
"Pktize",	/* 63,MS-DOS,Packer,Joaquim Homrighausen,2:270/17 */
"PC-RAIN",	/* 64,MS-DOS,Packer/mailer,Ray Hyder,1:272/40 */
"Truffle",	/* 65,MS-DOS/OS2,Mailer,Mike Rissa,2:504/59 */
"Foozle",	/* 66,Amiga,Packer,Peer Hasselmeyer,2:247/4 */
"White Pointer",	/* 67,Macintosh,Packer/mailer,Alastair Rakine,3:680/820 */
"GateWorks",	/* 68,MS-DOS,Packer,Jamie Penner,1:153/1025 */
"Portal of Power",	/* 69,MS-DOS,Mailer,Soren Ager,2:231/12 */
"MacWoof",	/* 6A,Macintosh,Packer/mailer,Craig Vaughan,1:109/342 */
"Mosaic",	/* 6B,MS-DOS,Packer,Christopher King,1:103/315 */
"TPBEcho",	/* 6C,MS-DOS,Packer,Gerd Qualmann,2:242/1 */
"HandyMail",	/* 6D,MS-DOS,Packer/mailer,jim nutt,1:114/30 */
"EchoSmith",	/* 6E,MS-DOS,Packer,Noel Crow,1:170/409 */
"FileHost",	/* 6F,MS-DOS,Packer,Mark Cole,2:252/186 */
"SFTS",	/* 70,MS-DOS,Packer,Bruce Anderson,1:3402/6 */
"Benjamin",	/* 71,MS-DOS,Packer/mailer,Stefan Graf,2:245/4.5436 */
"RiBBS",	/* 72,OS9 (COCO),Packer/mailer,Ron Bihler,1:104/54 */
"MP",	/* 73,MS-DOS,Packer,Ivan Leong,6:600/28 */
"Ping",	/* 74,MS-DOS,Packer,David Nugent,3:632/348 */
"Door2Europe",	/* 75,MS-DOS,Packer/mailer,Michaela Schoebel,2:247/14 */
"SWIFT",	/* 76,MS-DOS,Packer/mailer,Hanno van der Maas,2:500/2 */
"WMAIL",	/* 77,MS-DOS,Packer,Silvan Calarco,2:334/100.2 */
"RATS",	/* 78,MS-DOS,Packer,Jason DeCaro,1:260/205 */
"Harry the Dirty Dog",	/* 79,OS2,Mailer/packer,George Edwards,3:632/340.7 */
"Maximus-CBCS",	/* 7A,MS-DOS/OS2,Packer,Scott Dudley,1:249/106 */
"SwifEcho",	/* 7B,MS-DOS,Packer,Dana Bell,1:3801/8 */
"GCChost",	/* 7C,Amiga,Packer,Davide Massarenti,2:332/505.3 */
"RPX-Mail",	/* 7D,MS-DOS,Packer,Joerg Wirtgen,2:241/4034 */
"Tosser",	/* 7E,MS-DOS,Packer,Albert Ng,6:700/185 */
"TCL",	/* 7F,MS-DOS,Packer,Ulf Hedlund,2:201/602 */
"MsgTrack",	/* 80,MS-DOS,Packer,Andrew Farmer,1:243/1 */
"FMail",	/* 81,MS-DOS,Packer,Folkert Wijnstra,2:282/310 */
"Scantoss",	/* 82,MS-DOS,Packer,Michael Matter,2:243/44.3443 */
"Point Manager",	/* 83,Amiga,Packer,Mario Pacchiarotti,2:335/12.33 */
"IMBINK",	/* 84,MS-DOS,Packer,Mike Hartmann,2:246/48 */
"Simplex",	/* 85,MS-DOS/OS2,Packer,Chris Laforet,1:152/401 */
"UMTP",	/* 86,MS-DOS,Packer,Byron Copeland,1:272/26 */
"Indaba",	/* 87,MS-DOS,Packer,Pieter Muller,5:7102/11 */
"Echomail Engine",	/* 88,MS-DOS,Packer,Joe Jared,1:103/200 */
"DragonMail",	/* 89,OS2,Packer,Patrick O'Riva,1:143/37 */
"Prox",	/* 8A,MS-DOS,Packer,Gerhard Hoogterp,2:283/1.2 */
"Tick",	/* 8B,MS-DOS/OS2,Packer,Barry Geller,1:266/12 */
"RA-Echo",	/* 8C,MS-DOS,Packer,Roger Kirchhoff,2:245/4 */
"TrapToss",	/* 8D,Amiga,Packer,Maximilian Hantsch,2:310/6 */
"Babel",	/* 8E,MS-DOS/OS2,Packer,Jorgen Abrahamsen,2:230/100.9 */
"UMS",	/* 8F,Amiga,Packer,Martin Horneffer,2:242/7.9 */
"RWMail",	/* 90,MS-DOS,Packer,Remko Westrik,2:285/309.5 */
"WildMail",	/* 91,MS-DOS,Packer,Derek Koopowitz,1:161/502 */
"AlMAIL",	/* 92,MS-DOS,Packer,Alan Leung,1:348/207 */
"XCS",	/* 93,MS-DOS,Packer,Rudi Kusters,2:512/34.4 */
"Fone-Link",	/* 94,MS-DOS,Packer/mailer,Chris Sloyan,1:269/602 */
"Dogfight",	/* 95,MS-DOS,Packer,Chris Tyson,2:256/36 */
"Ascan",	/* 96,MS-DOS,Packer,Arjen van Loon,2:281/1.397 */
"FastMail",	/* 97,MS-DOS,Packer,Jan Berends,2:282/5 */
"DoorMan",	/* 98,MS-DOS,Mailer,Christopher Dean,1:105/70 */
"PhaedoZap",	/* 99,Atari ST,Packer,Jeff Mitchell,1:229/422 */
"SCREAM",	/* 9A,MS-DOS,Packer/mailer,Jem Miller,1:147/33 */
"MoonMail",	/* 9B,MS-DOS,Packer/mailer,Hasse Wigdahl,2:206/101 */
"Backdoor",	/* 9C,Sinclair QL,Packer,Erik Slagter,2:283/500.3 */
"MailLink",	/* 9D,Archimedes,Packer/mailer,Jan-Jaap v. d. Geer,2:500/133.1138 */
"Mail Manager",	/* 9E,MS-DOS,Packer,Andreas Brodowski,2:241/4006 */
"Black Star",	/* 9F,Xenix 386,Packer/mailer,Jac Kersing,2:283/333 */
"Bermuda",	/* A0,Atari ST/MS-DOS,Packer,Jac Kersing,2:283/333 */
"PT",	/* A1,MS-DOS,Packer/mailer,Jerry Andrew,1:109/426 */
"UltiMail",	/* A2,MS-DOS,Mailer,Brett Floren,1:363/1000 */
"GMD",	/* A3,MS-DOS,Packer,John Souvestre,1:396/1 */
"FreeMail",	/* A4,MS-DOS,Packer,Chad Nelson,1:109/536 */
"Meliora",	/* A5,MS-DOS,Packer,Erik van Riper,1:107/230 */
"Foodo",	/* A6,CPM-80,Packer/mailer,Ron Murray,3:690/640.7 */
"MSBBS",	/* A7,CPM-80,Packer,Marc Newman,1:106/601 */
"Boston BBS",	/* A8,MS-DOS,Packer/mailer,Tom Bradford,1:101/625 */
"XenoMail",	/* A9,MS-DOS,Packer/mailer,Noah Wood,1:284/14 */
"XenoLink",	/* AA,Amiga,Packer/mailer,Jonathan Forbes,1:250/642 */
"ObjectMatrix",	/* AB,MS-DOS,Packer,Roberto Ceccarelli,2:332/305.1 */
"Milquetoast",	/* AC,Win3/MS-DOS,Mailer,Vince Perriello,1:343/491 */
"PipBase",	/* AD,MS-DOS,Packer,Roberto Piola,2:334/306 */
"EzyMail",	/* AE,MS-DOS,Packer,Peter Davies,3:636/204 */
"FastEcho",	/* AF,MS-DOS,Packer,Tobias Burchhardt,2:245/39 */
"IOS",	/* B0,Atari ST/TT,Packer,Rinaldo Visscher,2:280/3.1 */
"Communique",	/* B1,MS-DOS,Packer,Ian Harris,3:620/251 */
"PointMail",	/* B2,MS-DOS,Packer,Michele Clinco,2:331/302.11 */
"Harvey's Robot",	/* B3,MS-DOS,Packer,Harvey Parisien,1:249/114 */
"2daPoint",	/* B4,MS-DOS,Packer,Ron Pritchett,1:376/74 */
"CommLink",	/* B5,MS-DOS,Mailer,Steve Shapiro,1:382/35 */
"fronttoss",	/* B6,MS-DOS,Packer,Dirk Astrath,2:241/5603 */
"SysopPoint",	/* B7,MS-DOS,Packer,Rudolf Heeb,2:243/44 */
"PTMAIL",	/* B8,MS-DOS,Packer,Arturo Krogulski,2:341/27.7 */
"AECHO",	/* B9,MS-DOS,Packer,Roland Gautschi,2:301/501 */
"DLGMail",	/* BA,Amiga,Packer,Steve Lewis,1:114/52 */
"GatePrep",	/* BB,MS-DOS,Packer,Andrew Allen,1:382/92 */
"Spoint",	/* BC,MS-DOS,Packer,Conrad Thompson,1:130/29.106 */
"TurboMail",	/* BD,MS-DOS,Packer,B. J. Weschke,1:2606/403 */
"FXMAIL",	/* BE,MS-DOS,Packer,Kenneth Roach,1:208/401 */
"NextBBS",	/* BF,MS-DOS,Packer/mailer,Tomas Hood,1:352/777 */
"EchoToss",	/* C0,MS-DOS,Packer,Mikel Beck,1:107/218 */
"SilverBox",	/* C1,Amiga,Packer,David Lebel,1:240/516 */
"MBMail",	/* C2,MS-DOS,Packer,Ruud Uphoff,2:500/116.1928 */
"SkyFreq",	/* C3,Amiga,Packer,Luca Spada,2:331/106 */
"ProMailer",	/* C4,Amiga,Mailer,Ivan Pintori,2:335/311.21 */
"Mega Mail",	/* C5,MS-DOS,Packer/mailer,Mirko Mucko,2:242/94 */
"YaBom",	/* C6,MS-DOS,Packer,Berin Lautenbach,3:620/248 */
"TachEcho",	/* C7,MS-DOS,Packer,Tom Zacios,1:107/376 */
"XAP",	/* C8,MS-DOS,Packer,Jeroen Smulders,2:512/1.8 */
"EZMAIL",	/* C9,MS-DOS,Packer,Torben Paving,2:234/41 */
"Arc-Binkley",	/* CA,Archimedes,Mailer,Geoff Riley,2:250/208 */
"Roser",	/* CB,MS-DOS,Packer,Chan Kafai,6:700/158 */
"UU2",	/* CC,MS-DOS,Packer,Dmitri Zavalishin,2:5020/32 */
"NMS",	/* CD,MS-DOS,Packer/mailer,Michiel de.Bruijn,2:285/505.2 */
"BBCSCAN",	/* CE,Archimedes,Packer/mailer,E. G. Snel,2:512/222.17 */
"XBBS",	/* CF,MS-DOS,Packer,Mark Kimes,1:380/16 */
"LoTek Vzrul",	/* D0,Packer/mailer,Kevin Gates,1:140/64, */
"Private Point Project",	/* D1,MS-DOS,Packer,Oliver von Bueren,2:301/701 */
"NoSnail",	/* D2,MS-DOS,Packer,Eddie Rowe,1:19/124 */
"SmlNet",	/* D3,MS-DOS,Packer,Steve T. Gove,1:106/6 */
"STIR",	/* D4,MS-DOS,Packer,Paul Martin,2:250/107.3 */
"RiscBBS",	/* D5,Archimedes,Packer,Carl Declerck,2:292/500.10 */
"Hercules",	/* D6,Amiga,Packer/mailer,Andrew Gray,1:231/590 */
"AMPRGATE",	/* D7,MS-DOS,Packer/mailer,Mike Bilow,1:323/120.1 */
"BinkEMSI",	/* D8,MS-DOS,Mailer,Tobias Burchhardt,2:245/39 */
"EditMsg",	/* D9,MS-DOS,Packer,G. K. Pace,1:374/26 */
"Roof",	/* DA,Amiga,Packer,Robert Williamson,1:167/104 */
"QwkPkt",	/* DB,MS-DOS,Packer,Ross West,1:250/412 */
"MARISCAN",	/* DC,MS-DOS,Packer,Mario Elkati,2:341/14.9 */
"NewsFlash",	/* DD,MS-DOS,Packer,Chris Lueders,2:241/5306 */
"Paradise",	/* DE,MS-DOS,Packer/mailer,Kenneth Wall,1:300/5 */
"DogMatic-ACB",	/* DF,N/A,Packer/mailer,Martin Allard,2:245/48 */
"T-Mail",	/* E0,MS-DOS,Packer/mailer,Andy_Elkin,2:5030/15 */
"JetMail",	/* E1,Atari ST/STE/TT,Packer,Daniel Roesen,2:243/93.8 */
"MainDoor",	/* E2,MS-DOS,Packer/mailer,Francisco Sedano,2:341/20 */
"StarGate",	/* E3,MS-DOS,Packer,Chloe Rudzinski,1:314/1 */
"BMB",	/* E4,Amiga,Packer,Dentato Remo,2:335/311.33 */
"BNP",	/* E5,MS-DOS,Packer,Nathan Moschkin,1:109/427 */
"MailMaster",	/* E6,MS-DOS,Packer/mailer,Gary Murphy,1:130/85 */
"Mail Manager +Plus+",	/* E7,MS-DOS,Packer,Chip Morrow,1:226/1240 */
"BloufGate",	/* E8,Atari ST/Unix,Packer,Vincent Pomey,2:320/100.2 */
"CrossPoint",	/* E9,MS-DOS,Packer/mailer,Peter Mandrella,2:243/97.80 */
"DeltaEcho",	/* EA,MS-DOS,Packer,Mikael Staldal,2:201/337 */
"ALLFIX",	/* EB,MS-DOS,Packer,Harald Harms,2:512/145 */
"NetWay",	/* EC,Archimedes,Mailer,Steve Haslam,2:250/116.3 */
"MARSmail",	/* ED,Atari ST,Packer,Mario van den Heuvel,2:281/522.3 */
"ITRACK",	/* EE,MS-DOS,Packer,Frank Prade,2:246/55.1 */
"GateUtil",	/* EF,MS-DOS,Packer,Michael Skurka,1:397/2.1 */
"Bert",	/* F0,MS-DOS,Packer/mailer,Arnim Wiezer,2:241/2104.9 */
"Techno",	/* F1,MS-DOS,Packer,Patrik Holmsten,2:203/133 */
"AutoMail",	/* F2,MS-DOS,Packer,Mats Wallin,2:201/239 */
"April",	/* F3,Amiga,Packer,Nick de Jong,2:282/309.3 */
"Amanda",	/* F4,MS-DOS,Packer,David Douthitt,1:121/99.14 */
"NmFwd",	/* F5,MS-DOS,Packer,Alberto Pasquale,2:332/504 */
"FileScan",	/* F6,MS-DOS,Packer,Matthias Duesterhoeft,2:241/4512.2 */
"FredMail",	/* F7,MS-DOS,Packer,Michael Butler,3:712/515 */
"TP Kom",	/* F8,MS-DOS,Packer/mailer,Per Sten,2:201/124 */
"FidoZerb",	/* F9,MS-DOS,Packer,Ulrich Schlechte,2:241/3410.12 */
"!!MessageBase",	/* FA,MS-DOS,Packer/mailer,Holger Lembke,2:240/500.20 */
"EMFido",	/* FB,Amiga,Packer,Gary Glendown,2:249/3.999 */
"GS-Toss",	/* FC,MS-DOS,Packer,Marco Bungalski,2:241/2021 */
"QWKDoor",	/* FD,Atari ST,Packer,Christian Limpach,2:270/20.1 */
"Reserved",	/* FE,,,, */
"Reserved",	/* FF,,,, */
"",	/* ,,,, */
};

