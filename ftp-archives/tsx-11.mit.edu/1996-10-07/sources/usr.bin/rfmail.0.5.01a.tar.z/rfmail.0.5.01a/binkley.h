/*
 * Binkley specific stuff
 */

DECLARE( void, arc_mail, (Node, char, char *));
