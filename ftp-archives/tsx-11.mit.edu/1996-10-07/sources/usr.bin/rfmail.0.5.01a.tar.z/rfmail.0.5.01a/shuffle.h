/*
 * $Header: /u1/src/rfmail/RCS/shuffle.h,v 0.5 1992/05/18 04:27:24 pgd Exp pgd $
 *
 * $Log: shuffle.h,v $
 * Revision 0.5  1992/05/18  04:27:24  pgd
 * New distribution
 *
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

#define MAX_SHUFFLE_BUFFERS 64
#define MAX_SHUFFLE_BUFFERSIZE 4096
/* Support obsolete versions */
#define tcharp sbuffer
  
extern char *sbuffer;
extern char *shufflebuffers(void);

#define SHUFFLEBUFFERS shufflebuffers()
