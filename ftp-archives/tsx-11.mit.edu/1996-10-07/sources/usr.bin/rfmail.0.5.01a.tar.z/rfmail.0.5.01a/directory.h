/*
 * $Header: /u1/src/rfmail/RCS/directory.h,v 0.5 1992/05/18 04:27:24 pgd Exp pgd $
 *
 * $Log: directory.h,v $
 * Revision 0.5  1992/05/18  04:27:24  pgd
 * New distribution
 *
 * Revision 0.4.1.1  1991/05/21  11:13:48  pgd
 * *** empty log message ***
 *
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

#ifdef USENDIR
#	include "ndir.h"
#else
#ifdef HAVE_DIRENT
#	include <dirent.h>
#else
#	ifdef HAVE_NDIR
#		ifdef LIBNDIR
#			include <sys/ndir.h>
#			define dirent direct
#		else
#			include "ndir.h"
#		endif
#	else
#		ifdef BSD
#			include <sys/dir.h>
#			ifndef dirent
#				ifndef direct
#					define dirent direct
#				endif
#			endif
#		else

you have to find directory routines. Try searching keywords ndir and
posix-dir.

#		endif /* BSD */
#	endif /* ndir.h */
#endif /* dirent.h */
#endif

