/*
 * $Header: /u1/src/rfmail/RCS/rmail.h,v 0.5.0.1 1992/06/15 06:11:25 pgd Exp pgd $
 *
 * $Log: rmail.h,v $
 * Revision 0.5.0.1  1992/06/15  06:11:25  pgd
 * Minor compilation bug fixes.
 * Change of all types with u_ prefix to U prefix
 * Change of name of routine msleep() to mssleep()
 *
 * Revision 0.5  1992/05/18  04:27:24  pgd
 * New distribution
 *
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

/* Definitions for rmail
 
   @(#)Copyright (c) 1987 by Teemu Torma
 
   Permission is given to distribute this program and alter this code as
   needed to adapt it to forign systems provided that this header is
   included and that the original author's name is preserved. */

/* Configurable definitions. Change them to according your configuration. */

#define FIDOMAILER "/u2/lib/fnet/rfmail" /* fidonet mailer */
/* #define REAL_RMAIL "/usr/lib/mail/rmail" /* real rmail */
/* #define REAL_RMAIL "/bin/rmail" /* real rmail when you have mailer */
#define REAL_RMAIL "/usr/lib/rmail" /* real rmail when no smail/sendmail */
/* #define GATEWAY "pgmf" /* route to fidonet gateway */
  
/* Don't touch the rest if you are not absolutely sure what you are
   doing... */

#define marray(n) ((char **) mymalloc((Uint) ((n) * sizeof(char *))))
