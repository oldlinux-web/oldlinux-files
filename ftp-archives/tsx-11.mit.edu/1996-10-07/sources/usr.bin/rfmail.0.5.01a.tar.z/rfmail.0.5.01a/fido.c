/*
 * $Header: /u1/src/rfmail/RCS/fido.c,v 0.5 1992/05/18 04:27:24 pgd Exp pgd $
 *
 * $Log: fido.c,v $
 * Revision 0.5  1992/05/18  04:27:24  pgd
 * New distribution
 *
 * Revision 0.4.1.6  1992/03/15  07:58:52  pgd
 * Untested version
 *
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

/* This can be used as login shell instead of rfmail. It will call funpack
   after rfmail exits, thus mail gets unpacked right away. */

#include "fnet.h"

#ifdef FCNTL
#include <fcntl.h>
#endif

#include "nodelist.h"
#include "configs.h"

#ifdef USG
extern int setpgrp(void);
#endif

#ifdef HAVE_WAIT_H
#include <sys/wait.h>
#endif
SIG_FTYPE 
unpack()
{

  (void) signal(SIGHUP, SIG_IGN);

  if (!fork()) {
    int fd;

    (void) close(0);
    (void) close(1);
    (void) close(2);
    if ((fd = open("/dev/null", O_RDWR)) == -1)
	    exit(2);

    (void) dup(fd);
    (void) dup(fd);
#ifdef BSD
    (void) setpgrp(getpid(), getpid()); /* Is this correct? */
#endif
#ifdef USG
    (void) setpgrp();
#endif
    
    (void) execl("/usr/lib/fnet/funpack", "funpack", 0);
    exit(2);
  }
  (void) signal(SIGHUP, SIG_DFL);
  exit(0);
}


int
main(argc, argv)
	int argc;
	char **argv;
{
	(void) signal(SIGHUP, unpack);

	if (!fork()) {
		(void) execl("/usr/lib/fnet/fcall", "-fcall","-O", "/tmp/logi.fcall", 0);
		exit(2);
	}
	(void) wait((int *) 0);
	
	(void) signal(SIGHUP, SIG_IGN);
	unpack();

	return 0;
}
