/*
 * $Header: /u1/src/rfmail/RCS/declare.h,v 0.5 1992/05/18 04:27:24 pgd Exp pgd $
 *
 * $Log: declare.h,v $
 * Revision 0.5  1992/05/18  04:27:24  pgd
 * New distribution
 *
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

#ifndef H_DECLARE
#define H_DECLARE
  
#if defined(__STDC__) || defined(__GNUC__)
#define DECLARE(type, function, arguments) extern type function arguments
#define LDECLARE(type, function, arguments) static type function arguments
#define	VOID	void
#else
#define DECLARE(type, function, arguments) extern type function ()
#define LDECLARE(type, function, arguments) static type function ()
#define	VOID
#endif

#ifdef MAIN
#define GLOBAL
#else
#define GLOBAL extern
#endif

/*
 * This is an attempt to get stdarg/varargs to work 
 */
#ifdef HAVE_STDARG_H
#include <stdarg.h>
#ifndef __GNUC__
#define	VA_ALIST	,va_alist
#define	VA_DCL		va_dcl
#else
#define	VA_ALIST       
#define	VA_DCL
#endif
#define VA_START(args, arg1) va_start(args, arg1)
#else
#include <varargs.h>
#define	VA_ALIST	,va_alist
#define VA_START(args, arg1) va_start(args)
#define	VA_DCL	va_dcl
#endif

#ifndef __STDC__
#define	const
#endif

#endif /* H_DECLARE */
