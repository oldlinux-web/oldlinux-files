#define NODEFLAG_DVN 8
#define NODEFLAG_V21 25
#define NODEFLAG_V22 26
#define NODEFLAG_V23 27
#define NODEFLAG_V29 33
#define NODEFLAG_V32BIS 89
#define NODEFLAG_V32 91
#define NODEFLAG_V33 92
#define NODEFLAG_V34 93
#define NODEFLAG_V42 156
#define NODEFLAG_NEC 182
#define NODEFLAG_H14 205
#define NODEFLAG_H16 207
#define NODEFLAG_CM 272
#define NODEFLAG_HST 335
#define NODEFLAG_DS 343
#define NODEFLAG_V42BIS 346
#define NODEFLAG_MNP5 384
#define NODEFLAG_PDN 386
#define NODEFLAG_ISDNA 399
#define NODEFLAG_ISDNB 400
#define NODEFLAG_ISDNC 401
#define NODEFLAG_PEP 453
#define NODEFLAG_H55 466
#define NODEFLAG_WIN 590
#define NODEFLAG_XA 601
#define NODEFLAG_XB 602
#define NODEFLAG_XC 603
#define NODEFLAG_XP 616
#define NODEFLAG_XR 618
#define NODEFLAG_XW 623
#define NODEFLAG_XX 624
#define NODEFLAG_MNP 651
#define NODEFLAG_REC 698
#define NODEFLAG_V22B 700
#define NODEFLAG_CSP 710
#define NODEFLAG_NMP 715
#define NODEFLAG_H96 727
#define NODEFLAG_GUUCP 740
#define NODEFLAG_SDN 773
#define NODEFLAG_SDS 778
#define NODEFLAG_V32B 829
#define NODEFLAG_MAX 838
#define NODEFLAG_LO 859
#define NODEFLAG_DDS 891
#define NODEFLAG_MN 923
#define NODEFLAG_MO 924
#define NODEFLAG_V42B 958
#define NODEFLAG_ZYX 1003
#define NODEFLAG_MDN 1023

#ifdef __STDC__
extern unsigned int nodecomp_hash_function(char *);
#else
extern unsigned int nodecomp_hash_function();
#endif

extern char *nodecomp_hash_table[1024];
