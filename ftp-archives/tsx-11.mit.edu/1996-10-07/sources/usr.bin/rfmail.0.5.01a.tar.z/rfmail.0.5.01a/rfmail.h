/*
 * $header: /u/pgd/rfmail/rfmail.h,v 0.4 1991/05/08 04:23:43 pgd Exp pgd $
 *
 * $Log: rfmail.h,v $
 * Revision 0.5  1992/05/18  04:27:24  pgd
 * New distribution
 *
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

/*
 * Common header file for rfmail
 */

extern boolean fflag, bflag, Pflag;
extern Node fnode, Pnode;
extern char hostname[];

extern char version[];
extern char schedule;

DECLARE(void, get_nodelist, (void));
DECLARE(boolean, sendnews, (Message *, Newsgroup *));
