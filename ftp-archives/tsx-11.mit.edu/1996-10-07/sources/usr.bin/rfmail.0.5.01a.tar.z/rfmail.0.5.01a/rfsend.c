/*
 * $Header: /u1/src/rfmail/RCS/rfsend.c,v 0.5 1992/05/18 04:27:24 pgd Exp pgd $
 *
 * $Log: rfsend.c,v $
 * Revision 0.5  1992/05/18  04:27:24  pgd
 * New distribution
 *
 * Revision 0.4.1.6  1992/03/15  07:58:52  pgd
 * Untested version
 *
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

/* This program can be used instead of rfmail. It will call fpack
   automatically, so there is no more need to explicitly call fpack in cron or
   dialout script. */

#include "fnet.h"
#include "nodelist.h"
#include "configs.h"

#ifdef HAVE_WAIT_H
#include <sys/wait.h>
#endif

/* ARGSUSED */
int
main(argc, argv)
	char **argv;
	int argc;
{
	static char *tmp = "rfmail";
	argv[0] = tmp;

	get_configuration(&argc, argv, "");
  
	if (!fork()) {
		(void) execv(sprintfs("%s/%s", config.libdir, tmp), argv);
		exit(2);
	}
	(void) wait((int *) 0);
	
	(void) execl(sprintfs("%s/%s", config.libdir, "fpack"), "fpack", 0);
	return 0;
} 

void
printusage(fp)
	FILE *fp;
{
	fprintf(fp, "rfsend [options]\n");
	fprintf(fp, "\tCompile rfmail nodelist.\n");
	fprintf(fp, "Where options are any of:\n");
	configprintusage(fp);
}



