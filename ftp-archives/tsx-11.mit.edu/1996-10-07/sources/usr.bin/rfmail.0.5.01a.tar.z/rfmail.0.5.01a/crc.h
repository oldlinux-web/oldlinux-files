/*
 * $Header: /u1/src/rfmail/RCS/crc.h,v 0.5.0.1 1992/06/15 06:11:25 pgd Exp pgd $
 *
 * $Log: crc.h,v $
 * Revision 0.5.0.1  1992/06/15  06:11:25  pgd
 * Minor compilation bug fixes.
 * Change of all types with u_ prefix to U prefix
 * Change of name of routine msleep() to mssleep()
 *
 * Revision 0.5  1992/05/18  04:27:24  pgd
 * New distribution
 *
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

/* %M%  %I%  Teemu Torma %H%

   Header file for updcrc macro.

   @(#)Copyright (c) 1987 by Teemu Torma

   Permission is given to distribute this program and alter this code as
   needed to adapt it to forign systems provided that this header is
   included and that the original author's name is preserved. */

extern Ushort crctab[];
extern Ulong cr3tab[];

#define updcrc(c, crc) (crctab[((crc >> 8) & 255) ^ (Uchar)(c)] ^ (crc << 8))

#if 0
/* #define updcrc(c, crc) (crctab[((crc >> 8) & 255)] ^ (crc << 8) ^ c) */

#define updcrc32(b, c) (cr3tab[(Uchar)(c) ^ (Uchar)(b)] ^ (((Uchar)(c) >> 8) & 0x00FFFFFF))
#endif
