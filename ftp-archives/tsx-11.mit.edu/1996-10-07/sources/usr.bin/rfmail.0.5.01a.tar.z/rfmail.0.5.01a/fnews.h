/*
 * $Header: /u/pgd/rfmail/fnews.h,v 0.4 1991/05/08 04:23:43 pgd Exp pgd $
 *
 * $Log: fnews.h,v $
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

/* Definitions for fidonet news-system.
   
   @(#)Copyright (c) 1987 by Teemu Torma
   
   Permission is given to distribute this program and alter this code as
   needed to adapt it to forign systems provided that this header is
   included and that the original author's name is preserved. */

/* Definitions for news-system. */

/* If you have some junk area (like junk in Usenet News), define this
   to name of that area. Otherwise messages to unknown areas will
   be dicarded. */
#define JUNK_AREA "FNET.JUNK" /**/

/* Usenet news junk area. Unknown echos are put here */
#define JUNK "junk" /**/
