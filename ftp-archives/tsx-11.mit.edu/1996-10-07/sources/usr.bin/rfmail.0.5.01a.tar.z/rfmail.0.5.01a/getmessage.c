/*
 * $Header: /u1/src/rfmail/RCS/getmessage.c,v 0.5 1992/05/18 04:27:24 pgd Exp pgd $
 *
 * $Log: getmessage.c,v $
 * Revision 0.5  1992/05/18  04:27:24  pgd
 * New distribution
 *
 * Revision 0.4.1.6  1992/03/15  07:58:52  pgd
 * Untested version
 *
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

#include "fnet.h"

#include <sys/stat.h>

#include "nodelist.h"
#include "configs.h"
#include "packet.h"
  
void
getmessage(packet)
     FILE *packet;
{
#ifdef READY
	if (!read_int16(packet, &message.type))
		return FALSE;
	if (message.type != MSGTYPE) {
		if (message.type == 0)
			return FALSE; /* Last message */

		/* Otherwise we have a problem? */
		return TRUE;
	}
  
	(void)read_int16(packet, &message.origin.node);
	(void)read_int16(packet, &message.destination.node);
	(void)read_int16(packet, &message.origin.net);
	(void)read_int16(packet, &message.destination.net);
	(void)read_int16(packet, &message.attributes);
	(void)read_int16(packet, &message.cost);
	fgetheaderstring(message.datetime, 20, packet);
	fgetheaderstring(message.to, 36, packet);
	fgetheaderstring(message.from, 36, packet);
	fgetheaderstring(message.subject, 72, packet);
	fgettext(message.text, packet);
#endif
}
