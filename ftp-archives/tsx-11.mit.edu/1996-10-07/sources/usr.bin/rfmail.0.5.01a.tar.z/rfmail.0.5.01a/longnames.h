/*
 * $Header: /u/pgd/rfmail/longnames.h,v 0.4 1991/05/08 04:23:43 pgd Exp pgd $
 *
 * $Log: longnames.h,v $
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

#define CheckFile			XX4XX
#define DEBUG_STATE_READ		XX28XX
#define DEBUG_STATE_WRITE		XX27XX
#define _indexname			XX8XX
#define _indexnode			XX9XX
#define ascnode				XX34XX
#define ascnodei			XX33XX
#define compile_net			XX12XX
#define compile_region			XX13XX
#define compile_zone			XX14XX
#define distrib				XX19XX
#define distribution			XX20XX
#define packet_name			XX24XX
#define packetname			XX18XX
#define packetnode			XX17XX
#define receive_retrys			XX3XX
#define received_block_number		XX1XX
#define receiver			XX2XX
#define search_name			XX15XX
#define search_node			XX16XX
#define write_nameindex			XX10XX
#define write_nodeindex			XX11XX
