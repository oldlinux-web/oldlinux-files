/*
 * $Header: /u/pgd/rfmail/unistd.h,v 0.4 1991/05/08 04:23:43 pgd Exp pgd $
 *
 * $Log: unistd.h,v $
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

/* I hope I won't get sued because of look and feel of ... :-) */

#ifndef F_ULOCK
#define F_ULOCK 0	/* Unlock */
#endif
#ifndef F_LOCK
#define F_LOCK 1	/* Lock */
#endif
#ifndef F_TLOCK
#define F_TLOCK	2	/* Test and lock */
#endif
#ifndef F_TEST
#define F_TEST 3	/* Test */
#endif

/* For [fl]seek */
#define	SEEK_SET	0	/* absolute seek */
#define	SEEK_CUR	1	/* From currect point */
#define	SEEK_END	2	/* From end of file */



