/*
 * $Header: /u1/src/rfmail/RCS/config.h,v 0.5.0.1 1992/06/15 06:11:25 pgd Exp pgd $
 *
 * $Log: config.h,v $
 * Revision 0.5.0.1  1992/06/15  06:11:25  pgd
 * Minor compilation bug fixes.
 * Change of all types with u_ prefix to U prefix
 * Change of name of routine msleep() to mssleep()
 *
 * Revision 0.5  1992/05/18  04:27:24  pgd
 * New distribution
 *
 * Revision 0.4.1.6  1992/03/15  07:58:52  pgd
 * Untested version
 *
 * Revision 0.4.1.5  1991/09/07  10:37:46  pgd
 * not finished revision check-in
 *
 * Revision 0.4.1.3  1991/06/15  09:33:39  pgd
 * *** empty log message ***
 *
 * Added LIBDIR and SPOOLDIR configuration symbols
 *
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

/*    
   Configuration file for FidoNet mailing system.
   
   @(#)Copyright (c) 1987 by Teemu Torma
   
   Permission is given to distribute this program and alter this code as
   needed to adapt it to forign systems provided that this header is
   included and that the original author's name is preserved. */


/*
 * Authors:
 *
 * Teemu Torma who wrote the original code (?)
 *
 * Heikki Suonsivu (hsu@hutcs.hut.fi) who made a lot of enhancements
 * 
 * Per Lindqvist (pgd@compuram.bbt.se) who continued to enhance rfmail.
 */

/*
 * rfmail library directory. Normally /usr/lib/fnet
 */
#define	LIBDIR		"/usr/lib/fnet"

/*
 * rfmail Spool directory. Normally /usr/spool/fnet
 */
#define	SPOOLDIR	"/usr/spool/fnet"

/* Configuration file. Usually $LIBDIR/rfmail.cf. Again, full pathnames,
   not trailing slash. */

#define CONFIGFILE "/usr/lib/fnet/rfmail.cf"

/*
 * Superlock. This file will be created when configuration file is
 * recompiled.  There are no other uses for it. It may be same as lock
 * file for fidonet call in general, but note that this directory is
 * used before the config file is read, and thus is not relative to
 * config 'spooldir'
 * 
 */
#define SUPERLOCK "/usr/spool/uucp/LCK..fidonet"

/* 
 * Superlock timeout. Superlock should never be set for long time, only
 * for time to read/write configuration file contents, so it can be
 * reasonably short. Good time would be 60 seconds.
 */
#define SUPERLOCK_TIMEOUT 60

/* Define this if your poor compiler doesn't understand names longer than
 * 7 chars as in some USG versions. It just includes file created by
 * clash. To compile on systems on which even C prerocessor doesn't
 * understand long names, I would strongly getting cpp from GNU C
 * package, even though you probably sometimes have to switch between
 * original and it (relinking the kernel doesn't work on my miniframe
 * when using gnu cpp) 
 */
/* #define HAVE_SHORTNAMES */

/*
 * If you use Rfmail together with the Binkley mailer, define BNKLEY
 * below. It modifies the bahaviour of Rfmail so that it understands
 * Binkley style in- and outbound files and directories
 */
#define BINKLEY

/*
 * If you are living in Sweden, you should consider defining the following
 * symbol. It enables recognition of swedish month-names, which some mailers
 * emit.
 */
#define	SWEDISH

/****************************************************************************/

/* Configuration options following should be picked up by operating
 * system selection. It may be necessary tune these if your system is
 * somewhat special. Sometimes, you may make rfmail a bit less
 * unefficient by checking these through.
 */


/***************************************************************************/

/* End of important configuration section. Normally you can ignore rest
   of this file. */
   
/***************************************************************************/

/*
 * These maybe must be made smaller if trying to port to 16-bit
 * computers, as config structure should be less than 64 k, these
 * probably hit the roof.  Try shortening command length and newsgroup
 * length first.
 */
  
#define RECEIVE_PATH_LEN 128
#define DOMAIN_LEN 32
#define PATH_LEN 128 /* 1024 */
#define EXT_LEN 4		/* length of extension used by packer */ 
#define NAME_LEN 16		/* length of packer name in config */
#define ID_LEN 16		/* length of packer id string */
#define DIALS 20
#define DIALSTRING_LEN 20
#define ORIGIN_LEN 128
#define PASSW_LEN 9		/* 8 characters + \0 */
#define SCRIPT_LEN 128
#define	SYSTEM_NAME_LEN 60
#define	SYSOP_NAME_LEN 20
/* #define SEENBY_LEN 1024 */
/* Echolen 32 is imposed by fidonet echomail programs to my knowledge */
#define MAX_ECHOLEN 32
#define MAX_NGLEN 50 /* 64 */
#define MAX_DISTRIBUTION_LEN 16 /* 20 */
#define MAX_COMMAND_LEN 64 /* 256 */
#define	MAX_NEWSGROUP_NODES	8
/* I will soon hit 100 echos in my system, so this probably need a tweak at
   big sites (I'm in Europe) */
#define MAX_NEWSGROUPS 100 /* 200 */
#define MAX_AKAS 10
#define MAX_SEENBYS 12
#define MAX_HEADERS 20
#define MAX_HEADER_LEN 32 /* 256 */
#define	MAX_NODELISTS	5	/* Max number of nodelists */
#define	MAX_SYSTEMLISTS	5	/* Max number of system lists */
#define	MAILNAME_LEN	64
#define	MAX_ZONES	8	/* Max number of zones handled */
#define	MAX_NETS	16	/* Max number of nets to include/exclude */
#define	MAX_MODEMS	4	/* Max number of different modem types */
#define	MAX_LINES	8	/* Max number of different modem lines */
#define	MAX_MODEM_MESSAGES 25	/* Max number of modem messages */
#define	MAX_INCLUDES	4	/* Max number of include files in rfmail.cf */
#define	MAX_EVENTS	8	/* Max number of events */
#define MAX_PACKERS	16	/* MAx number of packers */
#define MAXARGS		32	/* Max number of arguments */

/* Routing tables. These may need some tweaking for big sites. */
/* Max number of routing statements */
#define MAX_TARGETS 20
/* Max number of nodes in list of targets */
#define MAX_MASKS 10

/* Destination info tables. May need teeaking for big sites. */
/* Max number of key statements */
#define MAX_KEYS 20

/*
 * Input buffer size. I personally recommend more than buffer sizes in
 * modems + the fossil output buffer in the other end. Don't worry
 * about this, unless you are at very high speed, it might require
 * some attention. Maybe also in case your system has problems with
 * big reads. 
 */
#define INPUT_BUFFER_SIZE 4096
  
/* End of configure section. Don't go further. */
  
#ifdef HAVE_SYSEXITS
# include <sysexits.h>
#else /* not HAVE_SYSEXITS */
# define EX_OK 0 /* successful termination */
# define EX_USAGE 64 /* command line usage error */
# define EX_DATAERR 65 /* data format error */
# define EX_NOINPUT 66 /* cannot open input */
# define EX_NOHOST 68 /* host name unknown */
# define EX_UNAVAILABLE 69 /* service unavailable */
# define EX_SOFTWARE 70 /* internal software error */
# define EX_OSERR 71 /* system error (e.g., can't fork) */
# define EX_OSFILE 72 /* critical OS file missing */
# define EX_CANTCREAT 73 /* can't create (user) output file */
# define EX_IOERR 74 /* input/output error */
# define EX_TEMPFAIL 75 /* ???? */
#endif /* not HAVE_SYSEXITS */

#ifdef HAVE_SHORTNAMES
#include "longnames.h"
#endif

#ifdef HAVE_UNISTD
#include <unistd.h>
#else
#include "unistd.h"
#endif
  
#ifdef BSD
#ifndef P_tmpdir
#define P_tmpdir "/tmp/"
#endif
#ifndef L_tmpnam
#define L_tmpnam (sizeof(P_tmpdir) + 255)
#endif
#endif /* BSD */


#ifdef USG
/* #define SVR3 */
/* #define HAVE_UTIME_H */

/* One of these must be defined. HAVE_DIRENT should work on SVR3 and on any
   posix-compatible system. Ndir is probably more common, and the only
   difference I am aware of between dirent and ndir is that directory
   structure is called dirent in dirent, direct in ndir. */

/* #define HAVE_DIRENT /**/
/* #define HAVE_NDIR /**/

#if !(defined(HAVE_DIRENT) || defined(HAVE_NDIR))
#ifdef USG
#if defined(POSIX) || defined(SVR3)
#define HAVE_DIRENT
#endif /* POSIX or SVR3 */
#endif /* USG */
#endif /* no directory option defined */
  
  
#endif /* USG */
  
#include <ctype.h>

#if !defined(USG) && !defined(BSD)
unknown operating system, trying to cause a panic...!
You need to define either USG or BSD.
hope it worked.
#endif


/*
 * Select locking method
 */
#ifdef HAVE_LOCKF
#define	LOCK_LOCKF
#else
#ifdef HAVE_LOCKING
#define	LOCK_LOCKING
#else
#define LOCK_LOCKFILES
#endif
#endif

#ifndef HAVE_BZERO
#define	bzero(ADDR,SIZE)	memset((ADDR), 0, (SIZE))
#endif

#ifndef HAVE_BCOPY
#define	bcopy(SRC, DST, SIZE)	memcpy((DST), (SRC), (SIZE))
#endif


#define	MSGID_POLITICS

/*
 * Important datatypes
 *
 * Uchar has to be 8 bits
 * Ushort has to be 16 bits
 * Ulong has to be 32 bits
 * size of int is at least 16 bits
 * Uint is unsigned int
 */
typedef unsigned char Uchar;
typedef unsigned short Ushort;
typedef unsigned int Uint;
typedef unsigned long Ulong;
typedef char routing_type;


