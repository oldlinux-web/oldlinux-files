/*
 * $Header: /u1/src/rfmail/RCS/lintlib.c,v 0.5.0.1 1992/06/15 06:11:25 pgd Exp pgd $
 *
 * $Log: lintlib.c,v $
 * Revision 0.5.0.1  1992/06/15  06:11:25  pgd
 * Minor compilation bug fixes.
 * Change of all types with u_ prefix to U prefix
 * Change of name of routine msleep() to mssleep()
 *
 * Revision 0.5  1992/05/18  04:27:24  pgd
 * New distribution
 *
 * Revision 0.4.1.6  1992/03/15  07:58:52  pgd
 * Untested version
 *
 * Revision 0.4.1.1  1991/05/21  11:13:48  pgd
 * *** empty log message ***
 *
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

/*LINTLIBRARY*/
/* This is for functions not defined anywhere */

#include <stdio.h>
#include <sys/types.h>
#include "config.h"

#ifdef lint
#ifdef LOCK_LOCKF
/*ARGSUSED*/
lockf(fd, mode, position) int fd, mode; long position; { return 0; }
#endif
#ifdef LOCK_LOCKING
/*ARGSUSED*/
locking(fd, mode, position) int fd, mode; long position; { return 0; }
#endif
/*ARGSUSED*/
char *strnchr(p, c, maxlen) Uchar *p; int c, maxlen;
{ return (char *) p; }
/*ARGSUSED*/
char *strsave(s) char *s; { return s; }
/*ARGSUSED*/
/*VARARGS1*/
char *regex(re) char *re; {}
/*ARGSUSED*/
time_t parsedate(p, now) char *p; struct timeb *now; { return 0L; }
#endif


