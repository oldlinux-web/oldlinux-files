/*
 * $Header: /u/pgd/rfmail/fidoquery.c,v 0.4 1991/05/08 04:23:43 pgd Exp pgd $
 *
 * $Log: fidoquery.c,v $
 * Revision 0.4  1991/05/08  04:23:43  pgd
 * Initial Beta-release
 *
 */

/*
 * Small stupid program to match fidonet addresses for smail
 */

/*
 * Author:
 * 
 * Per Lindqvist (pgd@compuram.bbt.se) who continued to enhance rfmail.
 */


main(argc, argv)
	int argc;
	char **argv;
{
	char *cp;

	exit (!(argv[1]
	      && (cp = strrchr(argv[1], '.'))
	      && strcmp(cp+1, "fidonet") == 0));
}
