char *version_string = "3.62";

/*
  Local variables:
  version-control: never
  End:
 */
