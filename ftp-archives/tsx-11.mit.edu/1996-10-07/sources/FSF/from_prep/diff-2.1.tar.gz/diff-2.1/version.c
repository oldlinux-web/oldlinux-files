/* Version number of GNU diff.  */

char *version_string = "2.1";
