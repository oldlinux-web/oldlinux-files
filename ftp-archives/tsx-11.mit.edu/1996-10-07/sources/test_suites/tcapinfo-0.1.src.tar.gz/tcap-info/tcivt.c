/* Show vtXXX emulation sequences and what Linux 0.99pl4 will handle
 *
 * Copyright (C) 1993  Wolfgang Thiel 
 *              upsyf173@dave.hrz.Uni-Bielefeld.de
 *              wthiel@post.Uni-Bielefeld.de
 *
 * The next lines are stolen from screen-3.2b:
 *
 * All rights reserved.
 *
 * Permission is granted to freely use, copy, modify, and redistribute
 * this software, provided that no attempt is made to gain profit from it,
 * the authors are not construed to be liable for any results of using the
 * software, alterations are clearly marked as such, and this notice is
 * not modified.
 *
 * I used information found in
 * - good old ATARI ST Uniterm 
 * - MSKermit docs (very old)
 *
 * Please report any bugs / missing sequencies to the author.
*/

#include <stdio.h>

struct vtxxx
{
  const char *seq, *info;
};

static struct vtxxx vt_info[] =
{
  { "^G", "bell" },
  { "^H", "move cursor: backspace" },
  { "^I", "move cursor: next tab" },
  { "^J", "move cursor: lf OR lf/cr (??? should be: lf OR cr/lf ???)" },
  { "^K", "move cursor: lf OR lf/cr (??? should be: lf ???)" },
  { "^L", "move cursor: lf OR lf/cr (??? should be: lf ???)" },
  { "^M", "move cursor: carriage return" },
  { "^N", "mode: select G1 charset" },
  { "^O", "mode: select G0 charset" },
  { "^X", "div: CANCEL: reset to normal character processing" },
  { "^Z", "div: CANCEL: reset to normal character processing" },

  { "\\ED", "move cursor: down (can scroll)" },
  { "\\EE", "move cursor: CR LF (can scroll" },
  { "\\EH", "tab: set tab stop" },
  { "\\EM", "move cursor: right (??? should be ReverseIndex=up ???)" },
  { "\\EZ", "request: who are you?" },
  { "\\Ec", "div: reset terminal to default" },
  { "\\E=", "mode: keypad application mode" },
  { "\\E>", "mode: keypad numeric mode" },
  { "\\E7", "mode: save cursor and attribute modes" },
  { "\\E8", "mode: restore cursor and attribute modes" },
  { "\\E#3", "(*NI*): line: double-height top half" },
  { "\\E#4", "(*NI*): line: double-height bottom half" },
  { "\\E#5", "(*NI*): line: single-width single-height" },
  { "\\E#6", "(*NI*): line: double-width single-height" },
  { "\\E#8", "div: screen alignment test" },

  { "\\E(c", "mode: set G0 charcter set: 0=graphics, B=normal, U=null (*NI*:A,1,2)" },
  { "\\E)c", "mode: set G1 charcter set: 0=graphics, B=normal, U=null (*NI*:A,1,2)" },

  { "\\E[[", "keypad: " },
  { "\\E[n`", "move cursor: column n, same line" },

  { "\\E[n@", "insert n characters" },
  { "\\E[nA", "move cursor: n lines up, same row" },
  { "\\E[nB", "move cursor: n lines down, same row" },
  { "\\E[nC", "move cursor: n columns right, same line" },
  { "\\E[nD", "move cursor: n columns left, same line" },
  { "\\E[nE", "move cursor: column 0, n lines down" },
  { "\\E[nF", "move cursor: column 0, n lines up" },
  { "\\E[nG", "move cursor: column n, same line" },
  { "\\E[y;xH", "move cursor: x|y" },

  { "\\E[J", "clear: cursor to end of screen" },
  { "\\E[0J", "clear: cursor to end of screen" },
  { "\\E[1J", "clear: beginning of screen to cursor" },
  { "\\E[2J", "clear: whole screen" },

  { "\\E[K", "clear: cursor to end of line" },
  { "\\E[0K", "clear: cursor to end of line" },
  { "\\E[1K", "clear: start of line to cursor" },
  { "\\E[2K", "clear: entire line" },

  { "\\E[nL", "insert: insert n lines" },
  { "\\E[nM", "delete: delete n lines" },
  { "\\E[nP", "delete: delete n charcters right" },
  { "\\E[y;xR", "report: cursor position" },

  { "\\E[na", "move cursor: n columns right, same line" },
  { "\\E[0c", "request: who are you?" },
  { "\\E[nd", "move cursor: line n, same row" },
  { "\\E[ne", "move cursor: n lines down, same row" },
  { "\\E[y;xf", "move cursor: x|y" },

  { "\\E[g", "tab: clear this tab stop" },
  { "\\E[0g", "tab: clear this tab stop" },
  { "\\E[3g", "tab: clear all tab stops" },

  { "\\E[2h", "(*NI*): mode: keyboard lock" },
  { "\\E[4h", "mode: insert mode on" },
  { "\\E[12h", "(*NI*): mode: local echo off" },
  { "\\E[20h", "mode: newline mode on: (return sends CR/LF" },

  { "\\E[ni", "(*NI*): printer control n" },

  { "\\E[2l", "(*NI*): mode: keyboard unlock" },
  { "\\E[4l", "mode: insert mode off" },
  { "\\E[12l", "(*NI*): mode: local echo on" },
  { "\\E[20l", "mode: newline mode off: (return sends LF" },

  { "\\E[m", "mode: all attributes off (\\E[21;24;25;27;39;49m" },
  { "\\E[0m", "mode: all attributes off (\\E[21;24;25;27;39;49m" },
  { "\\E[1m", "mode: intensity 2" },
  { "\\E[2m", "mode: intensity 0" },
  { "\\E[4m", "mode: underline on" },
  { "\\E[5m", "mode: blink on" },
  { "\\E[7m", "mode: reverse on" },
  { "\\E[21m", "mode: intensity 1" },
  { "\\E[22m", "mode: intensity 1" },
  { "\\E[24m", "mode: underline off" },
  { "\\E[25m", "mode: blink off" },
  { "\\E[27m", "mode: reverse off" },
  { "\\E[30m", "color: background: " },
  { "\\E[31m", "color: background: " },
  { "\\E[32m", "color: background: " },
  { "\\E[33m", "color: background: " },
  { "\\E[34m", "color: background: " },
  { "\\E[35m", "color: background: " },
  { "\\E[36m", "color: background: " },
  { "\\E[37m", "color: background: " },
  { "\\E[39m", "color: background: default" },
  { "\\E[40m", "color: foreground: " },
  { "\\E[41m", "color: foreground: " },
  { "\\E[42m", "color: foreground: " },
  { "\\E[43m", "color: foreground: " },
  { "\\E[44m", "color: foreground: " },
  { "\\E[45m", "color: foreground: " },
  { "\\E[46m", "color: foreground: " },
  { "\\E[47m", "color: foreground: " },
  { "\\E[49m", "color: foreground: default" },

  { "\\E[0n", "report: terminal ok" },
  { "\\E[3n", "(*NI*): report: terminal not ok" },
  { "\\E[5n", "request: status" },
  { "\\E[6n", "request: cursor position" },

  { "\\E[0q", "(*NI*): div: set leds: all off" },
  { "\\E[nq", "(*NI*): div: set leds: n on" },
  { "\\E[t;br", "region: set region top, buttom" },
  { "\\E[s", "div: save cursor and attribute modes" },
  { "\\E[u", "div: restore cursor and attribute modes" },
  { "\\E[0x", "(*NI*): request: send parameters after setup" },
  { "\\E[1x", "(*NI*): request: send parameters only on request" },
  { "\\E[2;..;x", "(*NI*): report: par;nbits;xspeed;rspeed;clkmul;flags" },
  { "\\E[3x", "(*NI*): report: parameters only on request" },

  { "\\E[2;ny", "(*NI*): div: invoke test n" },
  { "\\E[z", "(*NI*): div: reset terminal to power-up configuration" },

  { "\\E[0\"q", "(*NI*): mode: erase protection off" },
  { "\\E[1\"q", "(*NI*): mode: erase protection on" },
  { "\\E[2\"q", "(*NI*): mode: erasable" },

  { "\\E[?J", "(*NI*): clear: cursor to end of screen" },
  { "\\E[?0J", "(*NI*): clear: cursor to end of screen" },
  { "\\E[?1J", "(*NI*): clear: beginning of screen to cursor" },
  { "\\E[?2J", "(*NI*): clear: whole screen" },

  { "\\E[?K", "(*NI*): clear: cursor to end of line" },
  { "\\E[?0K", "(*NI*): clear: cursor to end of line" },
  { "\\E[?1K", "(*NI*): clear: start of line to cursor" },
  { "\\E[?2K", "(*NI*): clear: entire line" },

  { "\\E[?1h", "mode: cursor keys cursor mode (send \\EO..)" },
  { "\\E[?2h", "(*NI*): mode: ANSI/Vt102" },
  { "\\E[?4h", "(*NI*): mode: smooth scrolling" },
  { "\\E[?5h", "mode: reverse screen on" },
  { "\\E[?6h", "mode: origin mode relative" },
  { "\\E[?7h", "mode: autowrap on" },
  { "\\E[?8h", "mode: auto repeat on" },
  { "\\E[?9h", "(*NI*): mode: interlace on" },
  { "\\E[?18h", "(*NI*): mode: print formfeed off" },
  { "\\E[?19h", "(*NI*): mode: print full screen" },
  { "\\E[?25h", "mode: cursor off" },
  { "\\E[?38h", "(*NI*): mode: Tektronix mode" },

  { "\\E[?ni", "(*NI*): printer control n" },

  { "\\E[?1l", "mode: cursor keys application mode (send \\E[..)" },
  { "\\E[?2l", "(*NI*): mode: VT52" },
  { "\\E[?3l", "(*NI*): mode: 80 colums" },
  { "\\E[?4l", "(*NI*): mode: jump scrolling" },
  { "\\E[?5l", "mode: reverse screen off" },
  { "\\E[?6l", "mode: origin mode absolute" },
  { "\\E[?7l", "mode: autowrap off" },
  { "\\E[?8l", "mode: auto repeat off" },
  { "\\E[?9l", "(*NI*): mode: interlace off" },
  { "\\E[?18l", "(*NI*): mode: print formfeed on" },
  { "\\E[?19l", "(*NI*): mode: print scroll region" },
  { "\\E[?25l", "mode: cursor on" },
  { "\\E[?38l", "(*NI*): mode: VT200 mode" },

  { "\\E[?10n", "(*NI*): report: printer ready" },
  { "\\E[?11n", "(*NI*): report: printer not ready" },
  { "\\E[?13n", "(*NI*): report: no printer" },
  { "\\E[?15n", "(*NI*): request: printer status" },
  { "\\E[?20n", "(*NI*): report: function keys are unlocked" },
  { "\\E[?21n", "(*NI*): report: function keys are locked" },
  { "\\E[?25n", "(*NI*): request: are function keys locked?" },

  { "\\E[1;c]", "mode: setterm: set underline color" },
  { "\\E[2;c]", "mode: setterm: set half intensity color" },
  { "\\E[8]", "mode: setterm: save default colors" },
  { "\\E[9;n]", "mode: setterm: set blanking interval" }
};
#define NVTXXX (sizeof(vt_info)/sizeof(struct vtxxx))

extern char version[];

void pr_vtxxx(void)
{
  struct vtxxx *p;
  int i;

  printf("VTxxx sequences(%s): (*NI* = not in Linux 0.99p4)\n"
	, version);
  for (p = vt_info, i = 0; i < NVTXXX; ++i, ++p)
    {
      printf("%-10s %s\n", p->seq, p->info);
    }
  printf("\n");
}

#ifdef MAIN

int main(void)
{
  pr_vtxxx();
  return 0;
}
#endif
