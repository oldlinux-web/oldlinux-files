/* Show termcap entries in human readable form.
 * Copyright (C) 1993  Wolfgang Thiel 
 *              upsyf173@dave.hrz.Uni-Bielefeld.de
 *              wthiel@post.Uni-Bielefeld.de
 *
 * The next lines are stolen from screen-3.2b:
 *
 * All rights reserved.
 *
 * Permission is granted to freely use, copy, modify, and redistribute
 * this software, provided that no attempt is made to gain profit from it,
 * the authors are not construed to be liable for any results of using the
 * software, alterations are clearly marked as such, and this notice is
 * not modified.
 *
 * I used information found in
 * - GNU emacs termcap.info
 * - HPUX manual pages
 * - sources of programs like screen-3.2, microemacs, ...
 *
 * The flags are a bit confusing :
 * -a    Show all entries known to the program
 * -u    Show all entries found that are unknown to the program
 * -g    Show all entries mentioned in GNUemacs termcap.info
 * -gg   Show all entries not mentioned in GNUemacs termcap.info
 * -i    Show vtXXX sequences known to the program
 * -s    Sort by capability name
 * -ss   Sort by description
 *
 * Please report any bugs / capabilities not recognized by the program
 * to the author.
*/

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#ifdef NEED_TERMCAP
#include <termcap.h>
#endif

#ifdef NEED_CURSES
#include <curses.h>
#endif


struct tcap
{
  int GNUflag;
  int kind;
#define T_STRING    0
#define T_ARGSTRING 1
#define T_NUMBER    2
#define T_FLAG      3
  union
    {
      char *string;
      int number;
    } entry;
  const char *tag, *info;
};

#if defined(__STDC__) || defined(__cplusplus)
# define P_(s) s
#else
# define P_(s) ()
#endif

char *tcapstr P_((const char *p));
int compare_tag P_((struct tcap *t1, struct tcap *t2));
int info_len P_((const char *in));
int compare_info P_((struct tcap *t1, struct tcap *t2));
char kind P_((int i));
void print_tcap P_((void));
void free_tcap P_((void));
int find_tag P_((char *tag));
void show_entries P_((char *in));
int run P_((char *term));
void use P_((void));
int main P_((int argc, char **argv));
void pr_vtxxx P_((void));

#undef P_

struct tcap capabs[] =
{
 { 0, 0, {0}, "iP", "init: initialization program" },
 { 1, 0, {0}, "if", "init: file name initialization for each session" },
 { 1, 0, {0}, "is", "init: initialize terminal for each login session" },
 { 1, 0, {0}, "i1", "init: init strings to be sent before is" },
 { 1, 0, {0}, "i3", "init: init string to be sent after is" },
 { 0, 0, {0}, "rf", "init: reset filename" },
 { 1, 0, {0}, "rs", "init: reset from strange modes" },
 { 0, 0, {0}, "r1", "init: reset string" },
 { 0, 0, {0}, "r3", "init: reset string" },
 { 1, 0, {0}, "ti", "init: init string for programs that move cursor nonsequentially" },
 { 1, 0, {0}, "te", "init: exit string for programs that move cursor nonsequentially" },
 { 1, 0, {0}, "ct", "tabs: clear all stops" },
 { 1, 0, {0}, "st", "tabs: set stop" },
 { 1, 0, {0}, "uc", "underline 1 character, move right" },
 { 1, 0, {0}, "bl", "Bell" },
 { 1, 0, {0}, "pc", "Pad character" },
 { 1, 0, {0}, "tc", "terminal characteristics" },
 { 1, 0, {0}, "po", "print: start printer redirect" },
 { 1, 0, {0}, "pf", "print: stop printer redirect" },
 { 1, 0, {0}, "ps", "print: screen dump to printer" },
 { 1, 0, {0}, "nw", "clear to end of line, move cursor beginning of next line" },
 { 1, 0, {0}, "cr", "cursor: beginning of line" },
 { 1, 0, {0}, "ta", "cursor: next hardware tab" },
 { 1, 0, {0}, "le", "cursor: left" },
 { 1, 0, {0}, "bc", "cursor: left (obsolete)" },
 { 1, 0, {0}, "ri", "cursor: right" },
 { 1, 0, {0}, "up", "cursor: up" },
 { 1, 0, {0}, "hu", "cursor: half line up" },
 { 1, 0, {0}, "do", "cursor: down" },
 { 1, 0, {0}, "nl", "cursor: (obsolete) move down, scroll forward" },
 { 1, 0, {0}, "hd", "cursor: half line down" },
 { 1, 0, {0}, "nd", "cursor: non-destructive ri" },
 { 1, 0, {0}, "ho", "cursor: upper left corner of screen" },
 { 1, 0, {0}, "ll", "cursor: lower left corner of screen" },
 { 1, 0, {0}, "bt", "cursor: back tab" },
 { 1, 0, {0}, "ff", "cursor: next page (hardcopy terminal)" },
 { 1, 0, {0}, "ts", "status: move cursor: to status line" },
 { 1, 0, {0}, "fs", "status: move cursor: back from status line" },
 { 1, 0, {0}, "sc", "cursor: save" },
 { 1, 0, {0}, "rc", "cursor: restore" },
 { 1, 0, {0}, "cl", "clear: screen, goto 0|0" },
 { 1, 0, {0}, "ce", "clear: to end of line" },
 { 0, 0, {0}, "cb", "clear: to start of line (???)" },
 { 1, 0, {0}, "cd", "clear: this line to end of screen (defined for col 0 only)" },
 { 1, 0, {0}, "sf", "scroll: forward one line" },
 { 1, 0, {0}, "sr", "scroll: reverse one line" },
 { 0, 0, {0}, "ml", "memory lock above cursor" },
 { 0, 0, {0}, "mu", "memory lock off" },
 { 0, 0, {0}, "pk", "pfkey ???" },
 { 0, 0, {0}, "pl", "pfkey ???" },
 { 0, 0, {0}, "px", "pfkey ???" },
 { 0, 0, {0}, "WS", "change window size" },
 { 0, 0, {0}, "Z0", "change window width (132?)" },
 { 0, 0, {0}, "Z1", "change window width ( 80?)" },
 { 0, 0, {0}, "S0", "mode: is02022 on ???" },
 { 0, 0, {0}, "E0", "mode: is02022 off ???" },
 { 0, 0, {0}, "C0", "mode: is02022 characters ???" },
 { 0, 0, {0}, "ac", "mode: is02022 characters ???" },
 { 1, 0, {0}, "as", "mode: alternate character set on" },
 { 1, 0, {0}, "ae", "mode: alternate character set off" },
 { 1, 0, {0}, "so", "mode: standout on (->sg,ms,xs,xt)" },
 { 1, 0, {0}, "se", "mode: standout off (->sg,ms,xs,xt)" },
 { 1, 0, {0}, "us", "mode: underline on" },
 { 1, 0, {0}, "ue", "mode: underline off" },
 { 1, 0, {0}, "mb", "mode: blinking" },
 { 1, 0, {0}, "md", "mode: double-bright(bold)" },
 { 1, 0, {0}, "mh", "mode: half-bright" },
 { 1, 0, {0}, "mk", "mode: inivisible" },
 { 1, 0, {0}, "mp", "mode: protected" },
 { 1, 0, {0}, "mr", "mode: reverse" },
 { 1, 0, {0}, "me", "mode: all modes off" },
 { 1, 0, {0}, "CC", "mode: String to change terminal's command character." },
 { 0, 0, {0}, "RA", "wrap: (???) wrap off" },
 { 0, 0, {0}, "SA", "wrap: (???) wrap on" },
 { 1, 0, {0}, "ds", "status: disable status line" },
 { 1, 0, {0}, "vb", "mode: screen flash" },
 { 1, 0, {0}, "ve", "cursor: normal" },
 { 1, 0, {0}, "vi", "cursor: invisible" },
 { 1, 0, {0}, "vs", "cursor: enhance" },
 { 1, 0, {0}, "mm", "init: keypad: meta-key transmit on" },
 { 1, 0, {0}, "mo", "init: keypad: meta-key transmit off" },
 { 1, 0, {0}, "ks", "init: keypad: function key transmit" },
 { 1, 0, {0}, "ke", "init: keypad: function key work locally" },
 { 1, 0, {0}, "kl", "keypad: sent by le" },
 { 1, 0, {0}, "kr", "keypad: sent by ri" },
 { 1, 0, {0}, "ku", "keypad: sent by up" },
 { 1, 0, {0}, "kd", "keypad: sent by down" },
 { 1, 0, {0}, "kb", "keypad: sent by backspace" },
 { 1, 0, {0}, "kh", "keypad: sent by home" },
 { 1, 0, {0}, "kH", "keypad: sent by home down" },
 { 1, 0, {0}, "kI", "keypad: sent by insert char" },
 { 1, 0, {0}, "kA", "keypad: sent by insert line" },
 { 1, 0, {0}, "kC", "keypad: sent by clear screen" },
 { 1, 0, {0}, "kE", "keypad: sent by clear to end of line" },
 { 1, 0, {0}, "kS", "keypad: sent by clear to end of screen" },
 { 1, 0, {0}, "kt", "keypad: sent by clear tab stop" },
 { 1, 0, {0}, "kT", "keypad: sent by set tab stop" },
 { 1, 0, {0}, "kD", "keypad: sent by delete char" },
 { 1, 0, {0}, "kL", "keypad: sent by delete line" },
 { 1, 0, {0}, "kM", "keypad: sent by exit insert mode" },
 { 0, 0, {0}, "PU", "keypad: (non-standard) sent by previous page" },
 { 0, 0, {0}, "PD", "keypad: (non-standard) sent by next page" },
 { 1, 0, {0}, "kP", "keypad: sent by previous page" },
 { 1, 0, {0}, "kN", "keypad: sent by next page" },
 { 1, 0, {0}, "kF", "keypad: sent by scroll forward" },
 { 1, 0, {0}, "kR", "keypad: sent by scroll reverse" },
 { 1, 0, {0}, "ka", "keypad: sent by clear all tabs" },
 { 1, 0, {0}, "k1", "keypad: sent by by function key 1" },
 { 1, 0, {0}, "k2", "keypad: sent by by function key 2" },
 { 1, 0, {0}, "k3", "keypad: sent by by function key 3" },
 { 1, 0, {0}, "k4", "keypad: sent by by function key 4" },
 { 1, 0, {0}, "k5", "keypad: sent by by function key 5" },
 { 1, 0, {0}, "k6", "keypad: sent by by function key 6" },
 { 1, 0, {0}, "k7", "keypad: sent by by function key 7" },
 { 1, 0, {0}, "k8", "keypad: sent by by function key 8" },
 { 1, 0, {0}, "k9", "keypad: sent by by function key 9" },
 { 1, 0, {0}, "k0", "keypad: sent by by function key 0/10" },
 { 1, 0, {0}, "l0", "keypad: label function key 0/10" },
 { 1, 0, {0}, "l1", "keypad: label function key 1" },
 { 1, 0, {0}, "l2", "keypad: label function key 2" },
 { 1, 0, {0}, "l3", "keypad: label function key 3" },
 { 1, 0, {0}, "l4", "keypad: label function key 4" },
 { 1, 0, {0}, "l5", "keypad: label function key 5" },
 { 1, 0, {0}, "l6", "keypad: label function key 6" },
 { 1, 0, {0}, "l7", "keypad: label function key 7" },
 { 1, 0, {0}, "l8", "keypad: label function key 8" },
 { 1, 0, {0}, "l9", "keypad: label function key 9" },
 { 1, 0, {0}, "K1", "keypad: sent by upper left of 3X3 keypad" },
 { 1, 0, {0}, "K2", "keypad: sent by center of 3X3 keypad" },
 { 1, 0, {0}, "K3", "keypad: sent by upper right of 3X3 keypad" },
 { 1, 0, {0}, "K4", "keypad: sent by lower left of 3X3 keypad" },
 { 1, 0, {0}, "K5", "keypad: sent by lower right of 3X3 keypad" },
 { 0, 0, {0}, "KA", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KB", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KC", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KD", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KE", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KF", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KG", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KH", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KI", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KJ", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KK", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KL", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KM", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KN", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KO", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KP", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KQ", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KR", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KS", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KT", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KU", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KV", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KW", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KX", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KY", "keypad: (non-standard) sent by additional function key" },
 { 0, 0, {0}, "KZ", "keypad: (non-standard) sent by additional function key" },
 { 1, 0, {0}, "im", "ins/del: enter insert mode" },
 { 1, 0, {0}, "ei", "ins/del: leave insert mode" },
 { 1, 0, {0}, "ic", "ins/del: insert one character (not, if im is enough!)" },
 { 1, 0, {0}, "al", "ins/del: insert blank line, move current and lines below down" },
 { 1, 0, {0}, "ip", "ins/del: String to output following an inserted character in insert mode." },
 { 1, 0, {0}, "dm", "ins/del: enter delete mode" },
 { 1, 0, {0}, "ed", "ins/del: exit delete mode" },
 { 1, 0, {0}, "dc", "ins/del: delete one charcter (dm must be sent first)" },
 { 1, 0, {0}, "dl", "ins/del: delete line, move lines below 1 up (->db: last line reappears)" },
 { 0, 0, {0}, "c0", "color: foreground" },
 { 0, 0, {0}, "c1", "color: foreground" },
 { 0, 0, {0}, "c2", "color: foreground" },
 { 0, 0, {0}, "c3", "color: foreground" },
 { 0, 0, {0}, "c4", "color: foreground" },
 { 0, 0, {0}, "c5", "color: foreground" },
 { 0, 0, {0}, "c6", "color: foreground" },
 { 0, 0, {0}, "c7", "color: foreground" },
 { 0, 0, {0}, "d0", "color: background" },
 { 0, 0, {0}, "d1", "color: background" },
 { 0, 0, {0}, "d2", "color: background" },
 { 0, 0, {0}, "d3", "color: background" },
 { 0, 0, {0}, "d4", "color: background" },
 { 0, 0, {0}, "d5", "color: background" },
 { 0, 0, {0}, "d6", "color: background" },
 { 0, 0, {0}, "d7", "color: background" },
 { 1, 1, {0}, "pO", "print: redirect N characters to printer" },
 { 1, 1, {0}, "rp", "output character N times" },
 { 1, 1, {0}, "wi", "set screen window" },
 { 1, 1, {0}, "cm", "cursor: x|y" },
 { 1, 1, {0}, "CM", "cursor: x|y display memory relative" },
 { 1, 1, {0}, "ch", "cursor: column n, same line" },
 { 1, 1, {0}, "cv", "cursor: line n, same column" },
 { 1, 1, {0}, "LE", "cursor: n lines" },
 { 1, 1, {0}, "RI", "cursor: n lines" },
 { 1, 1, {0}, "UP", "cursor: n lines" },
 { 1, 1, {0}, "DO", "cursor: n lines" },
 { 1, 1, {0}, "cs", "scroll: set region" },
 { 1, 1, {0}, "cS", "scroll: set region" },
 { 1, 1, {0}, "SF", "scroll: forward N lines" },
 { 1, 1, {0}, "SR", "scroll: reverse N lines" },
 { 1, 1, {0}, "ec", "clear: N characters" },
 { 1, 1, {0}, "IC", "ins/del: insert N characters (im unnecessary)" },
 { 1, 1, {0}, "AL", "ins/del: insert N lines" },
 { 1, 1, {0}, "DC", "ins/del: delete N characters (dm not necessary)" },
 { 1, 1, {0}, "DL", "ins/del: delete N lines" },
 { 1, 1, {0}, "sa", "mode: appearance mode on/off (0/1):" },
/*#	      standout,underline,reverse,blink,half-bright,double-bright,
  #	      blank, protect, alt char set
*/
 { 1, 2, {0}, "co", "# columns" },
 { 1, 2, {0}, "li", "# lines" },
 { 1, 2, {0}, "lm", "# lines of display memory" },
 { 1, 2, {0}, "it", "tabs: initial spacing between hardware tab stop columns" },
 { 1, 2, {0}, "kn", "# of function keys" },
 { 1, 2, {0}, "ws", "status: width of status line" },
 { 1, 2, {0}, "sg", "mode: width of magic standout cookie" },
 { 1, 2, {0}, "ug", "mode: width of magic underline cookie" },
 { 1, 2, {0}, "pb", "lowest baud rate for padding" },
 { 0, 2, {0}, "vt", "terminal: virtual number" },
 { 1, 2, {0}, "dB", "(obsolete) # msec of padding needed for BS" },
 { 1, 2, {0}, "dC", "(obsolete) # msec of padding needed for CR" },
 { 1, 2, {0}, "dF", "(obsolete) # msec of padding needed for FF" },
 { 1, 2, {0}, "dN", "(obsolete) # msec of padding needed for NL" },
 { 1, 2, {0}, "dT", "(obsolete) # msec of padding needed for TAB" },
/* Flags: */
 { 1, 3, {0}, "am", "wrap: cursor does wrap" },
 { 1, 3, {0}, "bw", "wrap: `le' at left margin wraps to end of previous line." },
 { 1, 3, {0}, "bs", "cursor: ASCII BS moves cursor left (obsolete->le)" },
 { 1, 3, {0}, "km", "meta: has Meta key (on/off with mm/mo)" },
 { 1, 3, {0}, "in", "space output is different from moving over empty positions" },
 { 1, 3, {0}, "mi", "ins/del: cursor can be moved while in insert mode" },
 { 1, 3, {0}, "ms", "mode: can move in standout move" },
 { 1, 3, {0}, "nc", "(obsolete) do not use CR on this terminal" },
 { 1, 3, {0}, "ns", "scroll: terminal does not normally scroll" },
 { 1, 3, {0}, "os", "terminal does overstrike" },
 { 1, 3, {0}, "da", "scroll: Data scrolled off top of screen may be scrolled back." },
 { 1, 3, {0}, "db", "scroll: Data scrolled off bottom of screen may be scrolled back." },
 { 0, 3, {0}, "pt", "tabs: has hardware tab ???" },
 { 1, 3, {0}, "ul", "underline by overstriking with an underscore." },
 { 1, 3, {0}, "xb", "terminal is Superbee" },
 { 1, 3, {0}, "xn", "wrap: strange wrapping" },
 { 1, 3, {0}, "xs", "clear appearance modes by deleting line" },
 { 1, 3, {0}, "xt", "terminal is Telery 1061" },
 { 0, 3, {0}, "xv", "???" },
 { 0, 3, {0}, "xo", "flow: terminal uses xon/xoff" },
 { 0, 3, {0}, "NF", "flow: ???" },
 { 0, 3, {0}, "G0", "iso2022" },
 { 0, 3, {0}, "LC", "???" },
 { 0, 3, {0}, "LP", "???" },
 { 0, 3, {0}, "NL", "???" },
 { 0, 3, {0}, "OP", "???" },
 { 1, 3, {0}, "gn", "terminal type is generic" },
 { 1, 3, {0}, "hc", "terminal is hardcopy terminal" },
 { 1, 3, {0}, "hs", "status: terminal has status line" },
 { 1, 3, {0}, "hz", "terminal cannot accept ~" },
 { 1, 3, {0}, "eo", "output of a space can erase an overstrike" },
 { 1, 3, {0}, "es", "other display commands work while writing the status line." },
};
#define NCAPABS (sizeof(capabs)/sizeof(struct tcap))

typedef (*PFI)(struct tcap*, struct tcap*);

PFI compare_func[] =
{
  compare_tag, compare_info
};
#define NCOMPARE (sizeof(compare_func)/sizeof(PFI))

#define TBUFS 2048
char tbuf[TBUFS];
char save_area[TBUFS];

char *progname;
int flag_unknown;
int flag_sort;
int flag_all;
int flag_gnu;

char default_string[] = "(undef)";

extern char version[];

void use(void)
{
  printf("%s: show termcap entries.\n", progname);
  printf("   %s [-a] [-g] [-i] [-s] [-u] [terminaltype [...]] \n", progname);
  exit(0);
}

int main(int argc, char **argv)
{
  char *term, *p;

  if ((progname = strrchr(argv[0], '/')) != 0)
    ++progname;
  else
    progname = argv[0];
  
  --argc;
  while ((p = *++argv) != 0 && *p++ == '-')
    {
      --argc;
      while (*p)
	{
	  switch (*p++)
	    {
	    case 'a':
	      ++flag_all;
	      break;
	    case 'g':
	      if (flag_gnu < 2)
		++flag_gnu;
	      break;
	    case 'i':
	      pr_vtxxx();
	      break;
	    case 's':
	      if (flag_sort < NCOMPARE)
		++flag_sort;
	      break;
	    case 'u':
	      ++flag_unknown;
	      break;
	    default:
	      use();
	      break;
	    }
	}
    }

  printf("%s Version %s.\n", progname, version);
  if (argc == 0)
    run(getenv("TERM"));
  else
    while ((term = *argv++) != 0)
      run(term);
  return 0;
}

int run(char *term)
{
  int i;
  struct tcap *tp;
  char *area;


  printf("\nTERM=%s\n", term);
  if (!term || *term == 0 || tgetent(tbuf, term) < 1)
    return 1;

  if (flag_unknown)
    show_entries(tbuf);

  area = save_area;
  for (tp = capabs, i = 0; i < NCAPABS; ++i, ++tp)
    {
      if (tp->kind == T_STRING || tp->kind == T_ARGSTRING)
	  tp->entry.string = tcapstr(tgetstr((char *)tp->tag, &area));
      else if (tp->kind == T_FLAG)
	  tp->entry.number = tgetflag((char *)tp->tag);
      else if (tp->kind == T_NUMBER)
	  tp->entry.number = tgetnum((char *)tp->tag);
    }

  if (flag_sort > 0 && flag_sort <= NCOMPARE)
    qsort(capabs, NCAPABS, sizeof(capabs[0]), compare_func[flag_sort-1]);
  print_tcap();
  free_tcap();
  return 0;
}

void show_entries(char *in)
{
  char *start, *end;
  char c;
  char buf[TBUFS];
  int unknown = 0;

  printf("\nChecking for unknown termcap entries:\n");
  strcpy(buf, in);
  end = buf;
  while (*end)
    {
      start = end;
      while(*end != '=' && *end != '#' && *end != ':')
	++end;
      if (start != end && *start != ' ' && *start != '\n')
	{
	  c = *end;
	  *end = '\0';
	  if (end - start == 2)
	    {
	      if (!find_tag(start))
		{
		  *end = c;
		  while (*end != '\0' && *end != ':')
		    ++end;
		  c = *end;
		  *end = '\0';
		  printf("unknown: '%s'\n", start);
		  ++unknown;
		}
	      *end = c;
	    }
	  else
	    {
	      printf("ignored: '%s'\n", start);
	      *end = c;
	    }
	}
      while(*end != '\0' && *end++ != ':');
    }
  printf("%d unknown entries found.\n\n", unknown);
}

void print_tcap(void)
{
  int i;
  struct tcap *tp;

  tp = capabs;
  for (i = 0; i < NCAPABS; ++i, ++tp)
    {
      if (tp->kind == T_STRING || tp->kind == T_ARGSTRING)
	{
	  if (flag_all || tp->entry.string != default_string)
	    {
	      if (!flag_gnu 
		  || (flag_gnu == 1 && tp->GNUflag) 
		  || (flag_gnu == 2 && !tp->GNUflag))
		{
		  printf("%s\n    (%c) %s=", tp->info, kind(tp->kind)
			 , tp->tag);
		  printf("%s\n", tp->entry.string);
		}
	    }
	}
      else if (tp->kind == T_FLAG)
	{
	  if (flag_all || tp->entry.number == 1)
	    {
	      if (!flag_gnu 
		  || (flag_gnu == 1 && tp->GNUflag) 
		  || (flag_gnu == 2 && !tp->GNUflag))
		{
		  printf("%s\n    (%c) %s=", tp->info, kind(tp->kind)
			 , tp->tag);
		  printf("%d\n", tp->entry.number);
		}
	    }
	}
      else if (tp->kind == T_NUMBER)
	{
	  if (flag_all || tp->entry.number != -1)
	    {
	      if (!flag_gnu 
		  || (flag_gnu == 1 && tp->GNUflag) 
		  || (flag_gnu == 2 && !tp->GNUflag))
		{
		  printf("%s\n    (%c) %s=", tp->info, kind(tp->kind)
			 , tp->tag);
		  printf("%d\n", tp->entry.number);
		}
	    }
	}
    }
  printf("\n");
}

int find_tag(char *tag)
{
  int i;
  struct tcap *tp = capabs;

  for (i = 0; i < NCAPABS; ++i)
    {
      if (!strcmp(tp->tag, tag))
	return 1;
      ++tp;
    }
  return 0;
}

char *tcapstr(const char *p)
{
  static char string[80];
  char *d;

  if (p == 0)
      return default_string;

  d = string;
  while (*p && d < &string[sizeof(string)-4])
    {
      if (*p == 0x1b)
	{
	  *d++ = '\\';
	  *d++ = 'E';
	}
      else if (*p < ' ')
	{
	  *d++ = '^';
	  *d++ = *p + '@';
	}
      else
	*d++ = *p;
      ++p;
    }
  *d++ = '\0';
  return strdup(string);
}

int compare_tag (struct tcap *t1, struct tcap *t2)
{
  return(strcasecmp(t1->tag, t2->tag));
}

int compare_info (struct tcap *t1, struct tcap *t2)
{
  int n1, n2;
  n1 = info_len(t1->info);
  n2 = info_len(t2->info);
  return(strncmp(t1->info, t2->info, (n1 > n2) ? n2 : n1));
}

int info_len(const char *in)
{
  char *p = (char *)in;
  while (*p && *p != ' ')
    ++p;
  return p-in;
}

char kind(int i)
{
  static char kind_char[] = "sS#f";

  if (i < 0 || i > strlen(kind_char))
    return '?';
  return kind_char[i];
}

void free_tcap(void)
{
  int i;
  struct tcap *tp;

  tp = capabs;
  for (i = 0; i < NCAPABS; ++i)
    {
      switch (tp->kind)
	{
	case T_STRING:
	case T_ARGSTRING:
	  if (tp->entry.string != 0 && tp->entry.string != default_string)
	      free(tp->entry.string);
	  tp->entry.string = 0;
	  break;
	case T_FLAG:
	case T_NUMBER:
	  tp->entry.number = 0;
	  break;
	}
      ++tp;
    }
}
     
