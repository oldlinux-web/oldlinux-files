char version[] = "Fri Feb 5 13:31:15 MEZ 1993";
