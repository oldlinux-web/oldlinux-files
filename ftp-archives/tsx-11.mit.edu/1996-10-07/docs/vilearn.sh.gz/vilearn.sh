#! /bin/sh
# This is a shell archive.  Remove anything before this line, then unpack
# it by saving it into a file and typing "sh file".  To overwrite existing
# files, type "sh file -c".  You can also feed this as standard input via
# unshar, or by typing "sh <file", e.g..  If this archive is complete, you
# will see the following message at the end:
#		"End of shell archive."
# Contents:  README 1basics 2moving 3cutpaste 3temp 4inserting 5tricks
#   Makefile outline vilearn.sh
# Wrapped by wes@terminator.cc.umich.edu on Sun Aug 23 17:30:48 1992
PATH=/bin:/usr/bin:/usr/ucb ; export PATH
if test -f 'README' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'README'\"
else
echo shar: Extracting \"'README'\" \(1477 characters\)
sed "s/^X//" >'README' <<'END_OF_FILE'
XThis is version 1.0 beta of vilearn, an interactive vi tutorial.
X
XCopyright (c) 1992 Jill Kliger and Wesley Craig.  All Rights Reserved.
X
XPermission to use, copy, modify, and distribute this software and its
Xdocumentation for any purpose and without fee is hereby granted,
Xprovided that the above copyright notice appears in all copies and that
Xthe copyright notice, this permission notice, and an explicit record of
Xany local changes, appear in supporting documentation.  This software
Xis supplied as is without expressed or implied warranties of any kind.
X
XTo install, edit the Makefile and type
X
X	make install
X
XWe have a mailing list, vilearn-admins@terminator.cc.umich.edu. To be
Xadded to the list, send mail to vilearn-admins-request@terminator.  The
Xlist is intended to discuss the tutorials, coordinate projects relating
Xto them, and provide help to those who may need it.
X
XWe hope you enjoy and profit from these tutorials.  It is unfortunate
Xthat we did not profit from them in any way. We would like to sincerely
Xthank the Information Technology Division of the University of
XMichigan, a huge bureaucracy with a budget exceeding two million
Xdollars.  We offered ITD complete ownership of these tutorials,
Xincluding user testing and staff training sessions, for the
Xcontemptibly small fee of two thousand dollars. For some reason, they
Xcould not justify the cost...
X
XWesley Craig & Jill Kliger
X1317 Packard Street			vilearn@terminator.cc.umich.edu
XAnn Arbor, MI 48104
END_OF_FILE
if test 1477 -ne `wc -c <'README'`; then
    echo shar: \"'README'\" unpacked with wrong size!
fi
chmod +x 'README'
# end of 'README'
fi
if test -f '1basics' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'1basics'\"
else
echo shar: Extracting \"'1basics'\" \(5941 characters\)
sed "s/^X//" >'1basics' <<'END_OF_FILE'
Xvi tutorial #1: The Basics 
X
XThis lesson lasts 10-15 minutes and teaches simple editing.  Lines
Xwhich begin with  >>>  mark exercises you should try.  When you
Xwant to exit this tutorial type	 ZZ  (type capital Z, twice).
X
XWhen you type commands in vi they do not appear on the screen.	If the
Xletters you type unexpectedly appear on the screen, press the ESCAPE key.
X
X
XBASIC CURSOR MOVEMENT 
X---------------------
XTo move through the tutorial use ^D (control d) and ^U (control u).
X
X	^D	Move DOWN one half-screen
X		(depress the control key and type d)
X
X	^U	Move UP one half-screen
X		(depress the control key and type u)
X
X>>> Now type ^D (control d) and ^U (control u) to move down and back up.
X
XWhen you are done reading a screen, you are expected to type ^D to move
Xdown to the next screen.  You must remember to type ^D throughout the
Xtutorial.
X
XTo move the cursor line by line, or character by character, use the
Xfour keys h, j, k, and l.
X
X	h	Move left one character
X	j	Move down one line
X	k	Move up one line
X	l	Move right one character
X
XYou will notice that these keys are in a straight line on the
Xkeyboard.  Study the diagram below showing the function of h, j, k, l.
X
X				       UP
X		.......	  .......   .......   .......
X		:     :	  :	:   :	  :   :	    :
X	  LEFT	:  h  :	  :  j	:   :  k  :   :	 l  :  RIGHT
X		:.....:	  :.....:   :.....:   :.....:
X 
X			   DOWN
X
X>>> Now type  j	 or  k	a few times to bring the cursor to this line.
X
X>>> Try moving off the right end of a line using  l .  Notice that
X>>> vi will not allow you to move off the end of the line using	 l .
X>>> Likewise, you cannot use  h	 and  l	 on a blank line.
X
X>>> Try moving past the bottom of the screen using  j . Notice how
X>>> how the screen scrolls downward.
X
X>>> Now practice using	k  to move up, and  h  to move left.
X
X
XDELETION
X--------
XTo delete characters and lines, use x and dd.
X
X	x	X-OUT one character
X	dd	DELETE one line
X
XTo undo your changes, use u.
X
X	u	UNDO last change only
X
X>>> Delete this SCRAP line. Move to this line with  j or k , now type  dd .
X>>> Try undoing the deletion with  u .
X
X>>> Move to this line and x-out the Y's with  x : "whY ask whY?"
X
X>>> Try undoing the deletion with  u . Try typing  u  several times. 
X>>> Notice that	 u  only undoes the last change.
X
XHere are more lines on which to practice deleting and undoing (use: dd x u )
X
X	Emacs is an evil creation. Emacs is an evil creation.
X	Emacs is an evil creation. Emacs is an evil creation.
X	Emacs is an evil creation. Emacs is an evil creation.
X
X
XQUIT COMMANDS
X-------------
X(DO NOT QUIT the tutorial at this time.)
X
XTo quit a file without saving any changes you have made (for instance,
Xwith the  dd  or  x  commands) use  :q!<RETURN> . To quit and save your
Xchanges, use  ZZ .  When you are editing your own files, you normally
Xuse  ZZ	 to quit.
X
X :q!<RETURN>	QUIT without saving changes
X		(type a colon, then the letter q, then an
X		exclamation point, and press RETURN)
X
X	ZZ	Exit and save any changes
X		(type capital Z, twice)
X
X
XINSERTION
X---------
XYou enter insert mode with  i  or  o . Anything you type during insert
Xmode appears on the screen.  When you are done inserting, press ESC
Xto exit insert mode.  Type  ^[ (control [ ), if you do not have an ESC key.
X
X	o	OPEN a line for inserting text
X	i	INSERT starting at the cursor
X
X	ESC	ESCAPE from insert mode
X
XDuring insert mode, use your erase character (usually backspace or
Xdelete) to delete mistakes. The characters you delete will remain on
Xthe screen until you press ESC.	 
X
X>>> Insert your name and phone number below the next blank line. To do this:
X>>>	Open a line below using	 o . 
X>>>	Type your first and last name. Press RETURN. 
X>>>	Then type your phone number and press ESC.
X>>>	Use  x	to erase part of your phone number.
X
X>>> Type the date below your phone number. To do this:
X>>>	Open another line using	 o . 
X>>>	Type the date and press ESC.  
X
X>>> Type  u  to undo the insertion.
X
X>>> Insert a nickname between your first and last names, using i. To do this:
X>>>	Move the cursor to the spot between your names using  h, j, k, l.
X>>>	Press  i . 
X>>>	Type the nickname, use DELETE or BACKSPACE to erase any typos.
X>>>	Then press ESC.	 
X
XOn some computers, a line may be longer than the width of the screen.
XThis means that a very long line may appear to be two lines on the
Xscreen.  This happens when you keep typing without pressing RETURN at
Xthe edge of the screen. To avoid any confusion when you're inserting
Xtext, be sure to press RETURN before reaching the right edge of the
Xscreen.
X
X
XFILE BASICS
X-----------
XTo edit a file using vi, at the UNIX command line, type:
X
X	vi filename
X
Xwhere "filename" is the name of the file you want to edit.  When you
Xuse vi to edit a file that does not exist, the file is not immediately
Xcreated.  The file is created the first time you save it, until then it
Xonly exists in temporary space.	 If you make a mistake typing the name
Xof a file, just use  :q!<RETURN>  to abandon the new file.
X
X
XSUMMARY	   
X-------	   
XThese are the vi commands you should know after tutorial #1:
X
X	^D	Move DOWN one half-screen
X		(depress the control key and type d)
X
X	^U	Move UP one half-screen
X		(depress the control key and type u)
X
X	h	Move left one character
X	j	Move down one line
X	k	Move up one line
X	l	Move right one character
X
X	dd	DELETE one line
X	x	X-OUT one character
X
X	u	UNDO last change
X
X :q!<RETURN>	QUIT without saving changes
X		(type a colon, then the letter q, then an
X		exclamation point, and press RETURN)
X
X	ZZ	Exit and save any changes
X		(type capital Z, twice)
X
X	o	OPEN a line for inserting text
X	i	INSERT starting at the cursor
X
X	ESC	ESCAPE from insert mode
X
Xand to use vi from a UNIX command line:
X
X	vi filename
X
X
XYou are now prepared to do simple editing on your own files.  Practice
Xusing vi for a few days.  Then take the second vi tutorial to learn
Xmore powerful and useful vi commands.
X
XCopyright (c) 1992 Jill Kliger and Wesley Craig.  All Rights Reserved.
END_OF_FILE
if test 5941 -ne `wc -c <'1basics'`; then
    echo shar: \"'1basics'\" unpacked with wrong size!
fi
# end of '1basics'
fi
if test -f '2moving' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'2moving'\"
else
echo shar: Extracting \"'2moving'\" \(9001 characters\)
sed "s/^X//" >'2moving' <<'END_OF_FILE'
Xvi tutorial #2: Moving Through Files Efficiently
X
XThis lesson lasts 15-20 minutes.  The material taught here is used in
Xtutorial #3: Cutting and Pasting.  Lines which begin with  >>>  mark
Xexercises you should try.  When you want to exit this tutorial type  ZZ  .
X
X
XWORDS
X-----
XThere are many ways to move from one word to another. Consider these:
X
X        w       Move to the beginning of the next WORD
X        e       Move to the END of the next word
X        b       Move BACK to the beginning to the previous word
X
XFor  w, e, and b,  a word is delimited by any non-alphanumeric
Xcharacter. The capitalized versions,  W, E, and B,  also move from word
Xto word. The difference is that for  W, E, and B,  a word is delimited
Xby any blank space.
X
X>>>  Try out  w, b, e,  on the lines provided below.
X>>>  Next practice using  B, W, b, E  on the lines provided below.
X
X    EX-PER-IMENT on these lines;test moving back &forth.
X    EX-PER-IMENT on these lines;test moving back &forth.
X
X
XON THE LINE
X-----------
XYou can move immediately to any point on the current line.
X
X        $       Move to the end of the line
X        ^       Move to the first non-white character on the line
X
X	0       Move to the first column on the line (column zero)
X	#|      Move to an exact column on the line (column #) e.g.  5| 12|
X
X>>>  Experiment with  $  and  ^  on the line provided below.  Notice
X>>>  that  ^  moves to the first non-white character, not the beginning.
X
X    This is a PRACTICE LINE.  There is white space at the front.  END
X
X0 (zero) will always take you to the far left edge of the screen.
X
X#| (number vertical-bar) is for moving to an explicit column on a line.
XJust type any number 1-80 and press  | . For example:  5|   20|   30|
XNote that you can't move beyond the last column on a line.
X
X
XFINDING CHARACTERS
X------------------
XOften you want to move to a specific letter or character on a line.
X
X    f char	FIND the next occurrence of char on the line
X    t char	Move 'TIL the next occurrence of char on the line
X
X    F char	FIND the previous occurrence of char on the line
X    T char	Move 'TIL the previous occurrence of char on the line
X
X	;	Repeat the last  f, t, F, or T
X	,	Reverse the last  f, t, F, or T
X
Xf and F land on the character.  t and T land next to the character.
Xf and t move forward, while F and T move backward.
X
XIf the specified character is not on the line, vi will beep.
X
X>>>  Move to the beginning of the line below, and try out these commands:
X>>>	fe  fE  ;  ;  ,  ,  t@  TP  te  tE  ,  ;  ,  ;
X
X    "PRACTICE line?" "Each and Every?" "Find thE char@cter and move to it.END
X
X
XMATCHING
X--------
Xvi has a handy way to determine if (), {}, and [] pairs match up.
X
X	%       Show matching () or {} or []
X
X>>>  On the practice lines below, move your cursor over a (,),{,},[, or ].
X>>>  Then type  %  .
X
X    [TRY THIS.  ((Whether) the pairs match up is the question.)  [One] 
X    pair is incomplete].  Can you tell {which one? ]} END
X
X
XWINDOW POSITIONS
X----------------
XYou can move the cursor to the top, middle, or bottom of the vi window.
X
X	H    Move to the HIGHEST position in the window
X	M    Move to the MIDDLE position in the window
X	L    Move to the LOWEST position in the window
X
X>>>  Try out these commands:  type  H  then  M  and  L  and then  M  again.
X
X
XMARKING LOCATIONS
X-----------------
XYou can mark positions in the file and return to them.
X
X     m char     MARK this location and name it char
X     ' char     (quote character) return to line named char
X     ''         (quote quote) return from last movement
X
Xchar can be any lower case letter, a-z.  A mark persists until you:
X     1) use the same char to mark another location
X  or 2) delete the marked line
X
X>>>  Move to this line and type  ma  to mark it  a
X>>>  Move to this line and type  mb  to mark it  b
X>>>  Move to this line and type  mz  to mark it  z
X>>>  Type  'a  to return to line  a
X>>>  Type  'b  to return to line  b
X>>>  Type  'z  to return to line  z
X
XCertain commands can move you large distances. These commands cause
Xyour last position to be remembered in the special mark named ' (quote).
XTo move to this special mark, just type '' (quote quote).
X
X>>>  Try this:  'b  to return to line b, and then  ''  to return here.
X
X
XGO TO A LINE
X------------
X
X         G      GO to the last line in the file
X        #G      GO to line #.  (e.g., 3G , 5G , 124G )
X
XRead these directions carefully:
X>>>  Type  1G  to go to the top of the file, and then  ''  (quote quote)
X>>>  to return here.
X>>>  Now try  G  to go to the end of the file, and then  ''  to return here.
X
X
XBLOCKS OF TEXT
X--------------
XIt is often convenient to move through files jumping from one block of
Xtext to the next.  To do this use braces and parentheses:
X
X	{	(left brace) Move to the beginning of a paragraph
X        }	(right brace) Move to the end of a paragraph
X
X        (	(left paren) Move to the beginning of a sentence
X        )	(right paren) Move to the beginning of the next sentence
X
X>>>  Experiment with  }  and  {  on the two paragraphs provided below.
X>>>  Note that paragraphs are separated by a blank line.
X
X	EXPERIMENT on this first paragraph.  The quick brown fox jumped
X    over the seven lazy dogs.  The fox must have been very large to
X    jump over seven dogs!
X
X	EXPERIMENT on this second paragraph.  The quick brown dog
X    jumped over the seven lazy foxes.  The dog didn't have to be nearly
X    as large, since foxes aren't too big.
X
X>>>  Try out  )  and  (  on the two paragraphs provided above.
X>>>  Notice that sentences are separated by two blank spaces.
X
XC programmers find it useful to move by sections, since sections may be
Xdelimited by a left brace in the first column.  By placing the opening
Xbrace of a C subroutine in the first column, you can move to the top of
Xthe next subroutine, using [[ and  ]] .
X
X        [[      Move to the beginning of a section
X        ]]      Move to the end of a section
X
XNote that if vi does not find a left brace at the far left, it will
Xmove to the top or bottom of the file.
X
X>>>  Now try  ]]  then  ]]  and  [[  on the subroutines provided below:
X
Xmain()
X{
X    helloworld();
X}
X
Xhelloworld()
X{
X    printf( "Hello world\n" );
X}
X
X
XSEARCHING
X---------
XThis enables you to jump to the next occurrence of a string in a file.
XTo initially find the string use:
X
X    /string	 Find string looking forward
X    ?string	 Find string looking backward
X
XTo find additional occurrences of the string type:
X
X	n	 Repeat last / or ? command
X	N	 Reverse last / or ? command
X
Xvi may search past the bottom of the file and then start again at the top. 
X(Or, vi may search past the top and then start again at the bottom.)
X
X>>>  You are going to search for a string, find the next three
X>>>  occurrences.  Then flip directions and find the string until you
X>>>  return to this location.  To do this:
X>>>      Type   /the   then press RETURN.  
X>>>	 Type  n  three times.
X>>>	 Type  N  until you return to this location.
X
X
XSUMMARY
X-------
X
X        w       Move to the beginning of the next WORD
X        e       Move to the END of the next word
X        b       Move BACK to the beginning to the previous word
X
X        $       Move to the end of the line
X        ^       Move to the first non-white character on the line
X
X	0       Move to the first column on the line (column zero)
X	#|      Move to an exact column on the line (column #) e.g.  5| 12|
X
X    f char	FIND the next occurrence of char on the line
X    t char	Move 'TIL the next occurrence of char on the line
X
X    F char	FIND the previous occurrence of char on the line
X    T char	Move 'TIL the previous occurrence of char on the line
X
X	;	Repeat the last  f, t, F, or T
X	,	Reverse the last  f, t, F, or T
X
X	%       Show matching () or {} or []
X
X	H	Move to the HIGHEST position in the window
X	M	Move to the MIDDLE position in the window
X	L	Move to the LOWEST position in the window
X
X    m char	MARK this location and name it char
X    ' char	(quote character) return to line named char
X    ''		(quote quote) return from last movement
X
X         G      GO to the last line in the file
X        #G      GO to line #.  (e.g., 3G , 5G , 175G )
X
X	{	(left brace) Move to the beginning of a paragraph
X        }	(right brace) Move to the end of a paragraph
X
X        (	(left paren) Move to the beginning of a sentence
X        )	(right paren) Move to the beginning of the next sentence
X
X        [[      Move to the beginning of a section
X        ]]      Move to the end of a section
X
X    /string	 Find string looking forward
X    ?string	 Find string looking backward
X
X	n	 Repeat last / or ? command
X	N	 Reverse last / or ? command
X
XYou should now be able to move around files very efficiently.  These
Xcommands are especially useful if you are using vi over a slow modem.
XPractice the material in this lesson for a few days and then take
Xeither the third vi tutorial to learn how to copy, cut, and paste, or
Xthe forth vi tutorial to learn additional insertion techniques.
X
XCopyright (c) 1992 Jill Kliger and Wesley Craig.  All Rights Reserved.
END_OF_FILE
if test 9001 -ne `wc -c <'2moving'`; then
    echo shar: \"'2moving'\" unpacked with wrong size!
fi
# end of '2moving'
fi
if test -f '3cutpaste' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'3cutpaste'\"
else
echo shar: Extracting \"'3cutpaste'\" \(11082 characters\)
sed "s/^X//" >'3cutpaste' <<'END_OF_FILE'
Xvi tutorial #3: Copying, Cutting, and Pasting
X
XThis lesson lasts 15-20 minutes.  This tutorial assumes full knowledge
Xof tutorial #1, and familiarity with tutorial #2.  Lines which begin
Xwith  >>>  mark exercises you should try.
X
XWhen you want to exit this tutorial type  ZZ  to exit and save your
Xchanges.  Or type  :q!<RETURN>  to exit without saving changes.
XRemember that typing  u  will UNDO your last change.
X
X
XCUTTING TEXT
X------------
XThe delete command can be combined with any of the movement commands
Xtaught throughout tutorial #2.  The resulting command is of the form:
X
X    dmovement	DELETE to where the movement command specifies
X
XConsider the following examples:
X
X	dw	DELETE to the beginning of the next WORD
X	d$	DELETE to the end of the line
X	d)	DELETE to the beginning of the next sentence 
X	dte	DELETE 'TIL the next  e
X	dd	DELETE a line (dd is a special case of the d command)
X
X>>>  Experiment with  dw  d$  d)  dte  dd  on the paragraph provided below:
X
X    PRACTICE here.  Now is the time for all good users to learn the
X    editor.  The quick brown fox jumped over the seven lazy fish.  Now
X    is the time for all good users to learn the editor.  The quick
X    brown computer jumped over the seven lazy users.  END PRACTICE
X
X
XPASTING TEXT
X------------
XWhen text is deleted it is put into a buffer which contains the most
Xrecently deleted text.  To paste the contents of this buffer elsewhere
Xin the file use the  p  or  P  command.
X
X	P	(upper p) PUT the contents of the buffer before the cursor
X	p	(lower p) PUT the contents of the buffer after the cursor
X
X>>>  Try this sequence of commands on the practice lines below:
X>>>  	dd  	to delete one line
X>>>	j	to move down a line
X>>>	p	(lower p) to PUT the deleted text after the cursor
X>>>	}	to move to the end of the paragraph
X>>>	P	(upper p) to PUT the deleted text before the cursor
X
X	PRACTICE line.  Cut and Paste this line to the bottom of the
X	paragraph.  Here is some filler, feel free to cut and paste the
X	text in this practice region.  Remember that  u  undoes the last
X	action.  END OF PRACTICE
X
X>>>  Try this sequence of commands at the beginning of a word:
X>>>	dw  w  P
X
XThe fastest way to swap two letters is to type:  xp
X
X>>>  Use  xp  to correct the misspelled words below:
X
X	PRACTICE.  Thier weird quiet recieved an inconvenient shriek.
X	Thier belief is that to recieve grief from nieghbors outwieghs
X	all else.  Biege skies lead to wierd science.  END.
X
X
XNUMBERING
X---------
XConsider cutting and pasting 3 words.  Based on previous exercises you
Xwould type  dw , move to the new location, and type  p , and repeat
Xthis procedure twice more.  There is an easier way to do this:
X
X>>>  Using the practice lines below, try the following sequence of commands:
X>>>    Move to the beginning of the first sentence.
X>>>    Type  d3w  to DELETE 3 WORDS.
X>>>    Type  w  to move ahead one WORD. 
X>>>    Type  P  (upper p) to PUT the three words before the cursor.
X
X    PRACTICE Numbering vi commands is easy to do.  Now is the time for
X    all good users to learn the editor.  The quick brown fox jumped
X    over the seven lazy dogs.  Numbering vi commands is easy to do.
X    Now is the time for all good users to learn the editor. END PRACTICE
X
X>>>  Type  d2d  to DELETE 2 lines, using the practice paragraph above.
X>>>  Move to the top of the paragraph.
X>>>  Type  p  (lower p) to PUT the two lines after of the cursor.
X
XNumbering also works for movement commands.
X
X>>>  Now try  4w  to move ahead 4 WORDs, on the lines provided above.  
X>>>  Then use  3b  to move BACK 3 words.
X
XWhen you type  4w  THINK "4 words", when you type  d4w  think "delete 4
Xwords".  In general, we can write
X
X    #movement	repeat movement # times
X    d#movement	DELETE to where the  #movement  command specifies
X
X
XCOPYING TEXT
X------------
XThe YANK command works just like the DELETE command, except  y  is used
Xinstead of  d  .
X
X    ymovement	YANK to where the movement command specifies
X
XYANK and DELETE are identical except that YANK only copies the specified
Xtext into the buffer.
X
X>>>  Try this sequence of commands on the practice lines below:
X>>>  	yy  	to YANK a line (yy is a special case of the y command)
X>>>	3j	to move down 3 lines
X>>>	p	(lower p) to PUT the yanked text after the cursor
X
X	PRACTICE line.  Copy and Paste this line to the bottom of the
X	paragraph.  Here is some filler, feel free to copy and paste the
X	text in this practice region.  Remember that  u  undoes the last
X	action.  END OF PRACTICE
X
XPlease note that copy, cutting, and pasting large blocks of text may
Xsignificantly alter the tutorial file.  Remember that you can always get
Xa new copy of the tutorial file and that  u  UNDOes your last change.
X
XHere are some examples which show the similarity between  y  and  d .
X
X	yw	YANK to the beginning of the next WORD
X	y$	YANK to the end of the line
X	y)	YANK to the beginning of the next sentence 
X	yte	YANK 'TIL the next  e
X	yy	YANK a line 
X
XHere are some more examples using commands from tutorial #2.
X
X	yL	YANK from here to the lowest point of the window
X	y/and	YANK from here to the word "and"
X	y2}	YANK 2 paragraphs
X	y'a	YANK from here to the marked line "a" (mark line first)
X
X>>>  Experiment with  yw  yte  y4w  y2}  y3y  and  y$  on the paragraph
X>>>  provided below.  Copy text AND use  p  or  P  to paste it.
X
X	PRACTICE line.  Copy and Paste this line to the bottom of the
X	paragraph.  Here is some filler, feel free to copy and paste
X	the text in this practice region.  Remember that  u  undoes the
X        last action.  END OF PRACTICE
X
X
XNUMBERED BUFFERS
X----------------
XIn all of the previous pasting exercises you've used the "un-named"
Xbuffer.  The un-named buffer contains the text you most recently cut or
Xcopied.  When you make a new cut or copy, the old contents of the
Xun-named buffer are moved to one of the "numbered" buffers.  The
Xbuffers are numbered 1-9.  Each time you cut or copy text,
X
X	vi saves your current cut or copy in a buffer #1  
X	vi saves your 2nd to last cut or copy in a buffer #2  
X	The cut or copy before that is saved in a buffer #3 ...  
X	vi saves your 8th oldest cut or copy in a buffer #8
X	vi saves your 9th oldest cut or copy in a buffer #9
X
XNote that buffer #1 is the same as the un-named buffer.  Here's how to
Xpaste from the numbered buffers:
X
X	"#P	(upper p) PUT contents of buffer # before the cursor
X	"#p	(lower p) PUT contents of buffer # after the cursor
X
XFor example:
X
X	"1p	PUT buffer 1 after the cursor
X	"7p	PUT buffer 7 after the cursor
X
X>>>  Delete this 1st line with  dd
X>>>  Delete this 2nd line with  dd
X>>>  Delete this 3rd block with  d2d
X>>>    (2nd half of block 3)
X>>>  Delete this 4th block with  dd
X>>>  Now type   "1p   "2p   "3p   "4p
X
XIf you are using vi and have made accidental deletions, just PUT the
Xcontents of each numbered buffer to recover the deleted text.
X
X
XNAMED BUFFERS
X-------------
Xvi maintains the un-named and numbered buffers automatically.  You can
Xmaintain your own buffers named a-z.  That is, you can cut or copy text
Xinto buffer x and later paste the text from buffer x.
X
X    "aDELETE	DELETE text into buffer a
X    "aYANK	YANK text into buffer a
X    "aPUT	PUT text from buffer a
X
XNote, don't actually type 'DELETE', 'YANK', or 'PUT'; type one of the
XDELETE commands, YANK commands, or PUT commands.  See the examples below:
X
X	"ad}		DELETE paragraph into buffer a
X	"by3y		YANK 3 lines into buffer b
X	"cy200G    	YANK to line 200 into buffer c
X	"dp		PUT buffer d  after the cursor
X	"zP		PUT buffer z  before the cursor
X
XThe contents of a named buffer are lost if:
X     1) you store new text in a buffer with the same name
X  or 2) you quit vi (using  ZZ  or  :q!<RETURN>  )
X
X>>>  Delete this START line into buffer a  by typing  "add
X>>>  Paste buffer a  by typing  "ap
X
X>>>  Delete this INTERMEDIATE line into buffer b  by typing  "bdd
X>>>  Paste buffer b  by typing  "bp
X
XTo put new material into buffer a
X>>>  Delete this FINAL line into buffer a  by typing  "add
X>>>  Paste buffer a  by typing  "ap  
X
X
XSAVING WITHOUT QUITTING
X-----------------------
XWith  ZZ  you save changes and quit vi.  With :w  you can save and not
Xquit vi.  It is a safe practice to save changes to a file regularly.
XThis reduces re-typing in the event your computer crashes.
X
X    :w<RETURN>	WRITE contents of the file (without quitting)
X		(type a colon, type w , then press the RETURN key)
X
X>>>  Try  :w  now.  Note the message at the bottom of the screen.
X
X
XPASTING BETWEEN FILES
X---------------------
XThis is an extremely useful procedure in vi.  Only one new command is
Xrequired for pasting between files, the EDIT command
X
X    :e filename<RETURN>    Begin EDITing the file called "filename"
X
XThe EDIT command allows you to edit another file without quitting vi.
XThis is useful since named buffers are lost when you quit vi.
X
XLet's say you want to copy 6 lines from the file called "3temp" into
Xthis file which is named "3cutpaste": 
X(Note that "3temp" has already been created for you)
X
X    1) WRITE "3cutpaste".  vi will not allow	:w (press RETURN)
X    you to edit another file without first
X    saving any changes you've made.
X
X    2) EDIT "3temp" without quitting vi.	:e 3temp (press RETURN)
X
X    3) YANK 6 lines from "3temp".		"ay6y
X
X    4) Return to "3cutpaste".			:e 3cutpaste (press RETURN)
X
X    5) PUT from buffer a			"ap
X
XNote that the un-named and numbered buffers are lost when the EDIT
Xcommand is used.  Only named buffers are preserved with EDIT.
X
X>>>  Follow the 5-step procedure outlined above.  Don't be concerned
X>>>  with remembering all 5 steps, the instructions are repeated in
X>>>  "3temp".  Paste the text from "3temp" near this line of this file,
X>>>  "3cutpaste".
X
XYou can use this 5-step procedure on any two files, with any cutting or
Xcopying action (here, y6y is the example).
X
X
XSUMMARY
X-------
X
X    #movement	repeat movement # times
X
X    dmovement	DELETE to where "movement" command specifies
X    d#movement	DELETE to where the  #movement  command specifies
X		(e.g.  dw  d3w )
X
X    ymovement	YANK to where "movement" command specifies
X    y#movement	YANK to where the  #movement  command specifies
X		(e.g.  yw  y3w )
X
X	P	(upper p) PUT the contents of the buffer before the cursor
X	p	(lower p) PUT the contents of the buffer after the cursor
X
X	"#P	(upper p) PUT contents of buffer # before the cursor
X	"#p	(lower p) PUT contents of buffer # after the cursor
X		(e.g.  "2p  "7P )
X
X    "aDELETE	DELETE text into buffer a
X    "aYANK	YANK text into buffer a
X    "aPUT	PUT text from named buffer a
X		(Note, don't actually type 'DELETE', 'YANK', or 'PUT';
X		type one of the DELETE commands, YANK commands, or PUT
X		commands, e.g.  "ad}  "by3y  "cy200G  "dp  "zP  )
X
X    :w<RETURN>	WRITE contents of the file (without quitting)
X		(type a colon, type w , then press the RETURN key)
X
X    :e filename<RETURN>    Begin EDITing the file called "filename"
X
X
XYou are now prepared to handle all cutting, copying and pasting tasks
Xwhich may arise.  If you practice what you've learned you'll find editing
Xin vi to be fast and convenient.
X
XCopyright (c) 1992 Jill Kliger and Wesley Craig.  All Rights Reserved.
END_OF_FILE
if test 11082 -ne `wc -c <'3cutpaste'`; then
    echo shar: \"'3cutpaste'\" unpacked with wrong size!
fi
# end of '3cutpaste'
fi
if test -f '3temp' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'3temp'\"
else
echo shar: Extracting \"'3temp'\" \(531 characters\)
sed "s/^X//" >'3temp' <<'END_OF_FILE'
XHere are the instructions again.  You are currently reading "3temp".
XYou have already accomplished step 1 and step 2.
X--------------------------------------------------------------------
X
X    1) WRITE "3cutpaste".  vi will not allow	:w (press RETURN)
X    you to edit another file without first
X    saving any changes you've made.
X
X    2) EDIT "3temp" without quitting vi.	:e 3temp (press RETURN)
X
X    3) YANK 6 lines from "3temp".		"ay6y
X
X    4) Return to "3cutpaste".			:e 3cutpaste (press RETURN)
X
X    5) PUT from buffer a			"ap
END_OF_FILE
if test 531 -ne `wc -c <'3temp'`; then
    echo shar: \"'3temp'\" unpacked with wrong size!
fi
# end of '3temp'
fi
if test -f '4inserting' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'4inserting'\"
else
echo shar: Extracting \"'4inserting'\" \(5442 characters\)
sed "s/^X//" >'4inserting' <<'END_OF_FILE'
Xvi tutorial #4: Insertion Techniques
X
XThis lesson lasts 5-10 minutes.  This tutorial assumes full knowledge
Xof tutorial #1, and familiarity with tutorial #2.  Lines which begin
Xwith  >>>  mark exercises you should try.  When you want to exit this
Xtutorial type  ZZ .
X
X
XSIMPLE INSERTION
X----------------
XYou spend most of your time in vi inserting text.  As you might expect,
Xthere are several commands to begin insertion.
X
X	o	OPEN a line below the cursor
X	O	OPEN a line above the cursor
X
X	i	INSERT starting before the cursor
X	I	INSERT at the beginning of the line
X
X	a	APPEND starting after the cursor
X	A	APPEND at the end of the line
X
XRemember to type ESC to leave insert mode.  If you don't have an ESC key
Xtype  ^[ (control [ ).
X
X	ESC	ESCAPE from insert mode
X
X>>>  Move the cursor to this line.  Type  O  , enter your name.  Press ESC.
X>>>  Next type  o  , enter the date.  Press ESC.
X
XNote that  O  opens the line above and puts you in insert mode, 
Xwhile  o  opens the line below and also puts you in insert mode.
X
X>>>  Type  a  on any line above, enter your name.  Press ESC.  Do the
X>>>  same for  A.
X
X>>>  Read the following.  Your goal is to take the sentence fragment below:
X
X	BROWN FOX  OVER THE SEVEN LAZY
X
X>>>  and convert it to
X
X	THE QUICK BROWN FOX JUMPED OVER THE SEVEN LAZY DOGS.
X
X>>>  To do this type:
X>>>	I  to insert  THE QUICK  (then press ESC)
X>>>	move the cursor to after the X in FOX
X>>>	a  to insert  JUMPED   (then press ESC)
X>>>	A  to insert  DOGS.  (then press ESC)
X>>>  Now move to the sentence fragment and make the changes outlined above.
X
X
XJOINING LINES
X-------------
XOften it is convenient to join two short lines into one line.  There
Xare several ways to do this.  The easiest is the  J  command.  Other
Xmethods will be explored in tutorial #5.
X
X	J	JOIN two lines
X
X>>>  Go to the first line in the block below.  Type J.  Type J again.
X
X	Example: NOW IS THE TIME 
X	the walrus said
X	TO THINK OF MANY THINGS
X
XIn the event that joining lines creates a line which exceeds the width
Xof the screen, you can break the line by typing  i  and pressing RETURN.
X
X
XSUBSTITUTING TEXT
X-----------------
XSubstituting combines the delete command and the insert command into a
Xsingle step.
X
X	#s	SUBSTITUTE for # characters
X	#S	SUBSTITUTE for # whole lines
X
X
XIn order to substitute text you have to know how much text you want to
Xdelete.  Consider the following examples:
X
X	3s	SUBSTITUTE the next 3 characters for what will be typed
X	7s	SUBSTITUTE the next 7 characters for what will be typed
X
X>>>  Change the SAMPLE DEFINITION below.  To do this:
X>>>	move the cursor to the T in TWO
X>>>	type  3s
X>>>	type  FOUR  then press ESC
X
X     SAMPLE DEFINITION:  A string quartet is defined to be
X                         a group of TWO musicians.
X
X
XREPLACING TEXT
X--------------
XThe  r  and  R  commands allow you to directly type over existing text.
X
X	r	REPLACE character (NO need to press ESC)
X	R	enter over-type mode 
X
X>>>  Correct each of the TYPOs on the sample line below.  To do this:
X>>>	move the cursor to the misspelled character
X>>>	type  r
X>>>	type  the correct character
X
X     SAMPLE: maintanence  conveniance  complience  applience  dilagent
X
X>>>  Use the over-type command,  R  ,  on the sample line above.  
X>>>  Type  R  then type the name of a local restaurant.  Press ESC.
X
X
XCHANGING TEXT
X-------------
XThe change command combines insertion, deletion, and the movement
Xcommands. (Recall that the movement commands were taught in tutorial
X#2.)  Change is probably more useful than replace or substitute.  The
Xgeneral form of the change command is:
X
X    cmovement	CHANGE to where the movement command specifies
X
XConsider the following examples:
X
X	cw	CHANGE to the beginning of the next WORD
X	c$	CHANGE to the end of the line
X	c)	CHANGE to the beginning of the next sentence 
X	cte	CHANGE 'TIL the next  e
X	c3w	CHANGE the next 3 WORDS
X	cc	CHANGE a line (cc is a special case of the c command)
X	c}	CHANGE to the end of the paragraph
X
X>>>  Follow these steps:
X>>>     1.  move to the desired location in the practice paragraph below
X>>>     2.  type cw  (change to the beginning of the next WORD)
X>>>     3.  type your name 
X>>>     4.  press ESC
X
X    PRACTICE here.  Now is the time for all good users to learn the
X    editor.  The quick red fox jumped over the seven lazy fish.  Now
X    is the time for all good users to learn the editor.  The quick
X    brown computer jumped over the seven lazy users.  END PRACTICE
X
X>>>  Experiment by using a variety of options for step #2.  Try
X>>>  out   c$  c)  cte  c3w  cc  c}   on the practice paragraph above.
X
XNote that the change command follows the same pattern as the delete
Xand yank commands which were explored in tutorial #3.
X
X
XSUMMARY
X-------
X
X	o	OPEN a line below the cursor
X	O	OPEN a line above the cursor
X
X	i	INSERT starting before the cursor
X	I	INSERT at the beginning of the line
X
X	a	APPEND starting after the cursor
X	A	APPEND at the end of the line
X
X	ESC	ESCAPE from insert mode
X
X	J	JOIN two lines
X
X	#s	SUBSTITUTE for # characters
X	#S	SUBSTITUTE for # whole lines
X
X	r	REPLACE character (NO need to press ESC)
X	R	enter over-type mode
X
X    cmovement	CHANGE to where the movement commands specifies 
X		(e.g.  c3w  c$  cc )
X
X
XThese commands should improve your ability to insert text efficiently.
XThe next tutorials deal with advanced commands and tricks which can
Xfurther speed up your editing.
X
XCopyright (c) 1992 Jill Kliger and Wesley Craig.  All Rights Reserved.
END_OF_FILE
if test 5442 -ne `wc -c <'4inserting'`; then
    echo shar: \"'4inserting'\" unpacked with wrong size!
fi
# end of '4inserting'
fi
if test -f '5tricks' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'5tricks'\"
else
echo shar: Extracting \"'5tricks'\" \(9326 characters\)
sed "s/^X//" >'5tricks' <<'END_OF_FILE'
Xvi tutorial #5: Tricks and Timesavers
X
XThis lesson lasts 10-15 minutes.  You should have a strong
Xunderstanding of tutorials #1-3 before working through these timesaving
Xtechniques.  Lines which begin with  >>>  mark exercises you should
Xtry.  When you want to exit this tutorial type  ZZ .
X
X
XCASE CONVERSION
X---------------
XWhen you want to change an upper-case character to a lower-case
Xcharacter (or lower-case to upper-case) there is a single command which
Xdoes both:
X
X	~	(tilde) Convert case of current character
X
X>>>  Move the cursor to be OVER the first character in the example
X>>>  line below.  Press  ~  until you have changed the case of the
X>>>  entire line.  (  ~  will advance to the right automatically).
X
X	bOB WENT TO pARIS, fRANCE, TO SEE THE #1 CYCLING EVENT.  end.
X
XNote that  ~  only affects alphabetic characters.
X
X
XUNDOING
X-------
XYou have already learned the  u  command which UNDOes the last change.
XThe  U  command will undo more than one change.
X
X	U	(upper u) UNDO all changes made to the current line
X		as long as your cursor has not moved off the line
X
XThere are three rules to learn:
X
X  U  will not re-do changes you have UNDOne (e.g. by pressing  U  twice)
X  U  will not restore a line which has been deleted
X  U  will not work if you have moved off the line you changed
X
X>>>  Move the cursor to the first line of the example text.  Delete
X>>>  the words "FISH" and "RAT" from the first line.  Now type  U
X>>>  (all changes to that line should be undone).  Type  U  again
X>>>  (nothing should happen).
X
X	EXAMPLE:  The FISH fed the cat.  The RAT fed the cat.  Example
X	text is HARD to make interesting.  The man fed the BUG.  The
X	worm fed the cat.  Example text is hard to make interesting.  END.
X
X>>>  Move the cursor to the second line of the example text.  Delete
X>>>  the words "HARD" and "BUG" from the second line.  Now type  j .
X>>>  Then type  k  .  Then type  U  (nothing should happen).
X
X>>>  Delete the first line of example text using  dd  .  Then type  U
X>>>  (nothing should happen).
X
X
XREPEAT LAST COMMAND
X-------------------
XOften you want to make the same change at multiple locations in the
Xfile.  To help accomplish this, vi remembers your previous action.
X
X	.	(dot) repeat last change
X
X>>> Go through the example below changing "FISH" to "TOAD":
X>>>	Go to the "F" in the first instance of "FISH"
X>>>	To change the word:  type  cw  then type  TOAD  then press ESC
X>>>     Move the cursor to "F" in the second occurence of "FISH"
X>>>     Type  .  (dot)
X>>>     Move the cursor to "F" in the final occurence of "FISH"
X>>>     Type  .  (dot)
X>>>     Now move the cursor to each occurence of "CROW";  Type  .  (dot)
X
X	EXAMPLE:  The FISH fed the cat.  The CROW fed the cat.  Example
X	text is FISH to make interesting.  The man fed the CROW.  The
X	worm fed the FISH.  Example text is hard to make CROW.  END.
X
X>>> Go through the example above deleting all occurences of "TOAD":
X>>>     Move to the beginning of the EXAMPLE paragraph above.
X>>>     Type  /TOAD  and press RETURN (recall tutorial #2)
X>>>	Delete the word by typing  dw
X>>>     Type  n  to move to the next occurence of "TOAD"
X>>>     Type  .  (dot) to repeat the  dw  command
X>>>     Use  n.  to delete the remaining "TOAD"s
X
XNote that  .  only repeats changes, not cursor movements.
X
X
XWINDOW ACTIONS
X--------------
XYou are already familiar with the  ^U  (depress the control key and
Xtype u) and ^D  commands from tutorial #1.
X
X	^D	Move DOWN one half-screen
X	^U	Move UP one half-screen
X
XThere are several related commands:
X
X	^F	Move FORWARD one full-screen
X	^B	Move BACKWARD one full-screen
X
X	^E	Move the window down one line without moving cursor
X	^Y	Move the window up one line without moving cursor
X
XThe  ^E  and  ^Y  commands may seem obscure; however, notice that on
Xthe keyboard,  e and  y  are close to  d  and  u  respectively.  This
Xshould help you remember that  ^E  moves DOWN, and  ^Y  moves UP.
X
XRecall the  H  M  L  (HIGH MIDDLE LOW) window commands from Tutorial 2.
XConsider a scenario where you want to yank from the current line to a
Xline near the top of the window.  You could use  ^E  and  ^Y  to
Xposition the text in the window before you use the  yH  command.
X
XThe  z  command also moves the window without moving your cursor:
X
X    z<RETURN>	Position the current line to top of window
X	z.	Position the current line to middle of window
X	z-	Position the current line to bottom of window
X
X>>>     Move to this line.  Type  z  and press RETURN.  Notice that
X>>>     this text and the cursor have moved to the top of the window.
X>>>     Try  z-  and  z.  also.
X
X
XFILE AND DISPLAY CONTROL
X------------------------
XHere are two commands which you may need to use during a vi session but
Xdo not involve your text.
X
X	^G	Show status of current file 
X	^L	Refresh screen
X
XWhen you type  ^G  (depress the control key and type g) a line appears 
Xat the bottom of the window describing the current file.  The line
Xcontains:
X
X	the name of the file
X	the message "[Read only]" if the file is read only
X	the message "[Modified]" if there are unsaved changes
X	the position of the cursor in the file
X	the percentage of the file above the cursor
X
XThe  ^L  command clears and redraws your window.  This is useful when
Xsomething other than vi outputs to your window, e.g. line noise from a
Xmodem, or incoming mail.  If there is no "garbage" in your window,
Xpressing  ^L  may not do anything noticable.
X
X
XSUSPENDING VI
X-------------
XHere is a way to go back and forth between vi and the Unix command
Xline:
X
X	^Z	Suspend this job and return to the Unix command line
X	fg	(foreground) Continue the suspended job
X
XWith this pair of commands you can SUSPEND the vi session, do something
Xfrom the Unix command line, then resume the suspended session by
Xtyping  fg  at the command line.  Note that  fg  stands for foreground.
X
XRead these instructions CAREFULLY before suspending vi.
X>>>     (Imagine you have an urge to type  ls  at the command line).
X>>>     Type  ^Z  to suspend vi.
X>>>     At the command line type  ls  and then  fg  to foreground vi.
X
XIf your shell does not support job control, e.g. /bin/sh, then the ^Z
Xcommand will beep instead of suspending vi.
X
X
XBANG COMMAND
X------------
XThe exclamation point,  !  (aka BANG), command allows you to feed text
Xto any Unix command.  The output of the Unix command replaces the
Xoriginal text.  Here is a useful Unix command to use from within vi:
X
X	!}fmt   Format the paragraph, joining and filling lines to
X		produce output lines of up to 72 characters
X
X>>>  Move to the example paragraph below. Type  !}fmt  and press
X>>>  RETURN.  Notice the paragraph will be reformatted such that
X>>>  the lines are of approximately equal length.
X
X	EXAMPLE:
X	So we grow together,
X	Like to a double cherry, seeming parted,
X	But yet an union in partition;
X	Two lovely berries moulded on one stem;
X	So, with two seeming bodies, but one heart;
X	END.
X
XAnother useful command is:
X
X       !}sort	Sort lines of a paragraph alphabetically
X
X>>>  Move to the example text below. Type  !}sort  and press RETURN.
X
X	OBERON		king of the fairies.
X	PUCK		or Robin Goodfellow.
X	HERMIA		daughter to Egeus, in love with Lysander.
X	HELENA		in love with Demetrius.
X	LYSANDER	in love with Hermia.
X	DEMETRIUS	in love with Hermia.
X
XRemember, any Unix command may be used this way.
X
X
XSHIFTING TEXT
X-------------
XIt is possible to shift large blocks of text right and left with the >
Xand  <  commands.
X
X   >movement	Shift right to where the movement command specifies
X   <movement	Shift left to where the movement command specifies
X
XThese commands work like the  d  command.  For example:
X
X	>}	Shift right to the end of the paragraph
X	<}	Shift left to the end of the paragraph
X	>>	Shift the current line right
X	<<	Shift the current line left
X
X>>>  Move the cursor to the first line of the paragraph below.
X>>>  Type  >>  and  <<  to shift the line back and forth.  Next
X>>>  try  >}  to shift the paragraph to the right, then  <}  to shift
X>>>  it left, then type  .  until all four lines start at the left edge.
X
X	THIS IS THE FIRST LINE OF EXAMPLE TEXT
X	    IS
X    EXAMPLE
X		TEXT END
X
X
XSUMMARY
X-------
X
X	~	(tilde) Convert case of current character
X
X	U	(upper u) UNDO all changes made to the current line
X		as long as your cursor has not moved off the line
X
X	.	(dot) repeat last change
X
X	^D      Move DOWN one half-screen
X		(depress the control key and type d)
X
X	^U      Move UP one half-screen
X		(depress the control key and type u)
X
X	^F	Move FORWARD one full-screen
X	^B	Move BACKWARD one full-screen
X
X	^E	Move the window down one line without moving cursor
X	^Y	Move the window up one line without moving cursor
X
X    z<RETURN>	Position the current line to top of window
X	z.	Position the current line to middle of window
X	z-	Position the current line to bottom of window
X
X	^G	Show status of current file 
X	^L	Refresh screen
X
X	!}fmt   Format the paragraph, joining and filling lines to
X		produce output lines of up to 72 characters
X
X       !}sort	Sort lines of a paragraph alphabetically
X
X   >movement	Shift right to where the movement command specifies
X   <movement	Shift left to where the movement command specifies
X
X
XThese commands should significantly speed up your editing. Have a nice
Xday.  Tutorial 6 contains even more nifty commands.
X
XCopyright (c) 1992 Jill Kliger and Wesley Craig.  All Rights Reserved.
END_OF_FILE
if test 9326 -ne `wc -c <'5tricks'`; then
    echo shar: \"'5tricks'\" unpacked with wrong size!
fi
# end of '5tricks'
fi
if test -f 'Makefile' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'Makefile'\"
else
echo shar: Extracting \"'Makefile'\" \(635 characters\)
sed "s/^X//" >'Makefile' <<'END_OF_FILE'
X#
X# Copyright (c) 1992 Jill Kliger and Wesley Craig.  All Rights Reserved.
X#
X
X# BINDIR is where the vilearn shell script will live. It should be in
X# the path of new users.
XBINDIR=	/usr/local/bin
X
X# TUTORIALS is the directory where the master copies of the tutorials
X# will live.
XTUTORIALS=	/usr/local/lib/vilearn
X
XTUTS=	1basics 2moving 3cutpaste 3temp 4inserting 5tricks
X
Xall :
X
Xinstall : all
X	-mkdir ${TUTORIALS}
X	for i in ${TUTS} ; do \
X	    rm -f ${TUTORIALS}/$$i; \
X	    install -c -m 444 $$i ${TUTORIALS}/$$i ; \
X	done
X	sed -e s@:TUTORIALS:@${TUTORIALS}@ < vilearn.sh > vilearn
X	install -m 755 vilearn ${BINDIR}/vilearn
X
Xclean :
END_OF_FILE
if test 635 -ne `wc -c <'Makefile'`; then
    echo shar: \"'Makefile'\" unpacked with wrong size!
fi
# end of 'Makefile'
fi
if test -f 'outline' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'outline'\"
else
echo shar: Extracting \"'outline'\" \(1160 characters\)
sed "s/^X//" >'outline' <<'END_OF_FILE'
X
X*
X* tutorial 1		FILENAME:  1basics
X*	basics
X*
X
X^D	down
X^U	up
X
Xh	left
Xj	down
Xk	up
Xl	right
X
Xdd	delete line
Xx	x-out character
X
Xu	undo
X
X:q!	force quit
XZZ	good bye
X
Xo	open
Xi	insert
X
X*
X* tutorial 2		FILENAME:  2moving
X*	objects, finds & marks
X*
X
Xw W	word
Xb B	back
Xe E	end
X
X{ }	paragraph
X( )	sentence
X[ ]	sections
X
X$	end of line
X^	first non-white
X|	column
X0	beginning of line
X
Xf F	find
Xt T	to
X;	repeat fFtT
X,	reverse fFtT
X
XG	goto
X
XH	high
XM	middle
XL	low
X
Xn N	next
X? /	regex
X
X%	match
X
X'	move to marked line
Xm	mark
X
X
X*
X* tutorial 3		FILENAME:  3cutpaste & 3temp
X*
X*	cutting, pasting, buffers, and files
X*
X
Xd D	deletes
Xy Y	yank
Xp P	put
X"	buffer
X:e	edit
X
X*
X* tutorial 4		FILENAME: 4inserting
X*	insertion
X*
X
Xa A	append
Xc C	change
Xi I	insert
Xo O	open
Xr R	replace
Xs S	substitute
X
XJ	join
X
X*
X* tutorial 5		FILENAME: 5tricks
X*	tricks
X*
X
X~	case
X
Xu U	undo
X
X.	do again
X
X^B	back
X^F	forward
X^E	down line
X^Y	up line
Xz	zero
X
X^G	status
X^L	refresh
X
X^Z	suspend
X
X^T	pop tag		proposed
X^]	follow tag	proposed
X
X!	command
X
X< >	shift
X
X*
X* tutorial 6		PROPOSED
X*	commands from hell
X*
X
X:	colon commands
XQ	quit
X^R	redraw
X@	execute buffer as macro
X&	like :&
X
X^T	shift (insert)
X^D	unshift (insert)
END_OF_FILE
if test 1160 -ne `wc -c <'outline'`; then
    echo shar: \"'outline'\" unpacked with wrong size!
fi
# end of 'outline'
fi
if test -f 'vilearn.sh' -a "${1}" != "-c" ; then 
  echo shar: Will not clobber existing file \"'vilearn.sh'\"
else
echo shar: Extracting \"'vilearn.sh'\" \(3629 characters\)
sed "s/^X//" >'vilearn.sh' <<'END_OF_FILE'
X#!/bin/sh
X#
X# Copyright (c) 1992 Jill Kliger and Wesley Craig.  All Rights Reserved.
X#
X# Permission to use, copy, modify, and distribute this software and its
X# documentation for any purpose and without fee is hereby granted,
X# provided that the above copyright notice appears in all copies and that
X# the copyright notice, this permission notice, and an explicit record of
X# any local changes, appear in supporting documentation.  This software
X# is supplied as is without expressed or implied warranties of any kind.
X#
X
XTUTORIALS=:TUTORIALS:
X
XTUTORIAL=
X
Xecho "The following tutorials are available:"
Xecho
X
Xecho -n "	Tutorial 1 -- Basic Editing"
Xif [ -f ${HOME}/VILEARN/1basics ]; then
X    echo " (previously viewed)"
Xelse
X    echo
Xfi
X
Xecho -n "	Tutorial 2 -- Moving Efficiently"
Xif [ -f ${HOME}/VILEARN/2moving ]; then
X    echo " (previously viewed)"
Xelse
X    echo
Xfi
X
Xecho -n "	Tutorial 3 -- Cutting and Pasting"
Xif [ -f ${HOME}/VILEARN/3cutpaste ]; then
X    echo " (previously viewed)"
Xelse
X    echo
Xfi
X
Xecho -n "	Tutorial 4 -- Inserting"
Xif [ -f ${HOME}/VILEARN/4inserting ]; then
X    echo " (previously viewed)"
Xelse
X    echo
Xfi
X
Xecho -n "	Tutorial 5 -- Tricks and Timesavers"
Xif [ -f ${HOME}/VILEARN/5tricks ]; then
X    echo " (previously viewed)"
Xelse
X    echo
Xfi
X
Xecho
Xecho "You will be editing your own copy of the tutorial. Enter the number"
Xecho -n "of the tutorial you'd like to see (or q to quit): "
X
Xwhile [ x$TUTORIAL = x ]; do
X    read _ans
X    case "$_ans" in
X	[qQ]*)
X	    echo "You lose. Thanks for playing."
X	    exit
X	    ;;
X
X	*[0-9][0-9]*)
X	    echo "No sir, didn't like it."
X	    echo -n "Type 1, 2, 3, 4, 5, or q: "
X	    ;;
X
X	*1*|*[Bb]asic*)
X	    TUTORIAL=1basics
X	    ;;
X
X	*2*|*[Mm]ov*)
X	    TUTORIAL=2moving
X	    ;;
X
X	*3*|*[Cc]ut*|*[Pp]ast*)
X	    TUTORIAL=3cutpaste
X	    EXTRA=3temp
X	    ;;
X
X	*4*|*[Ii]sert*)
X	    TUTORIAL=4inserting
X	    ;;
X
X	*5*|*[Tt]rick*)
X	    TUTORIAL=5tricks
X	    ;;
X
X	*)
X	    echo "No sir, didn't like it."
X	    echo -n "Type 1, 2, 3, 4, 5, or q: "
X	    ;;
X
X    esac
Xdone
X
Xif [ ! -d ${HOME}/VILEARN ]; then
X    mkdir ${HOME}/VILEARN
Xfi
X
Xif [ -f ${HOME}/VILEARN/${TUTORIAL} ]; then
X    echo
X    echo "There is already a copy of the tutorial in your home directory."
X    echo -n "Would you like a fresh copy of the tutorial? "
X    read _ans
X    if [ `expr x"${_ans}" : 'x[Yy].*'` -ne 0 ]; then
X	echo "Copying tutorial..."
X	sleep 2
X	rm -f ${HOME}/VILEARN/${TUTORIAL}
X	cp ${TUTORIALS}/${TUTORIAL} ${HOME}/VILEARN/${TUTORIAL}
X	if [ x${EXTRA} != x ]; then
X	    rm -f ${HOME}/VILEARN/${EXTRA}
X	    cp ${TUTORIALS}/${EXTRA} ${HOME}/VILEARN/${EXTRA}
X	fi
X    else
X	echo "Using existing tutorial..."
X	sleep 2
X    fi
Xelse
X    echo "Copying tutorial..."
X    sleep 2
X    cp ${TUTORIALS}/${TUTORIAL} ${HOME}/VILEARN/${TUTORIAL}
X    if [ x${EXTRA} != x ]; then
X	cp ${TUTORIALS}/${EXTRA} ${HOME}/VILEARN/${EXTRA}
X    fi
Xfi
X
Xcd ${HOME}/VILEARN; vi ${TUTORIAL}
X
X#
X# Feel free to delete this on your local system. Do not remove
X# if you are redistributing: we'd like the truth to be known :)
X#
Xcat << EOF
X
X	We hope you have enjoyed and profitted from the tutorial you
X	have just completed. It is unfortunate that we did not profit
X	from these tutorials in any way. We would like to sincerely
X	thank the Information Technology Division of the University of
X	Michigan, a huge bureaucracy with a budget exceeding two
X	million dollars.  We offered ITD complete ownership of these
X	tutorials, including user testing and staff training sessions,
X	for the contemptibly small fee of two thousand dollars. For
X	some reason, they could not justify the cost...
X
XEOF
X
Xecho
Xecho "Here endeth the lesson."
Xexit 0
END_OF_FILE
if test 3629 -ne `wc -c <'vilearn.sh'`; then
    echo shar: \"'vilearn.sh'\" unpacked with wrong size!
fi
chmod +x 'vilearn.sh'
# end of 'vilearn.sh'
fi
echo shar: End of shell archive.
exit 0


