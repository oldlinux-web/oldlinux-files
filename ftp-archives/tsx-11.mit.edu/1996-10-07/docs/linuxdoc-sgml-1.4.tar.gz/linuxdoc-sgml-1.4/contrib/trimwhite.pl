#!/usr/local/bin/perl

# Trim trailing whitespace off of input
# (Side-effect of using groff)

$count = 0;

while (<STDIN>) {
  
  if (/^$/) {
    $count++;
  } else {
    while ($count > 0) { 
      print STDOUT "\n";
      $count--;
    }
    print STDOUT;
  }
}
