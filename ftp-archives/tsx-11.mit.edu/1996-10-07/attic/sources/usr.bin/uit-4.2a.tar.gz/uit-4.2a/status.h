/*
    Status line management header file
    Copyright (c) Tudor Hulubei & Andrei Pitis, May 1994

This file is part of UIT (UNIX Interactive Tools)

UIT is free software; you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free Software
Foundation; either version 2, or (at your option) any later version.

UIT is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
details .

You should have received a copy of the GNU General Public License along with
UIT; see the file COPYING.  If not, write to the Free Software Foundation,
675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef __STATUS_H
#define __STATUS_H


#include "config.h"


#define MSG_OK		0
#define MSG_WARNING	1
#define MSG_ERROR	2


void status_init(int columns, int begin_y,
		 char *def_msg, configuration *config);
void status_end(void);
int  status(char *msg_name, int wait, int sound, int restore, int msg_type);


#endif
