/*
    Terminal capabilities interface header file
    Copyright (c) Tudor Hulubei & Andrei Pitis, May 1994

This file is part of UIT (UNIX Interactive Tools)

UIT is free software; you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free Software
Foundation; either version 2, or (at your option) any later version.

UIT is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
details .

You should have received a copy of the GNU General Public License along with
UIT; see the file COPYING.  If not, write to the Free Software Foundation,
675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef __TERMCAP_H
#define __TERMCAP_H


#define TTY_DESCRIPTION_END	 0

#define TTY_CURSOR_MOVE		 1
#define TTY_UNDERLINE_ON	 2
#define TTY_UNDERLINE_OFF	 3
#define TTY_REVERSE_ON		 4
#define TTY_REVERSE_OFF		 5
#define TTY_CLRSCR		 6
#define TTY_BRIGHT_ON		 7
#define TTY_BRIGHT_OFF		 8


#define TTY_MAXCAP		(1 + 8)


void termcap_init(void);


#endif
