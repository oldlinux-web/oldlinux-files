#include <stdio.h>

int iwrite(int,FILE *);
int lwrite(long,FILE *);
int awrite(char *,FILE *);
int cwrite(char *,FILE *);
int kwrite(char *,FILE *);
