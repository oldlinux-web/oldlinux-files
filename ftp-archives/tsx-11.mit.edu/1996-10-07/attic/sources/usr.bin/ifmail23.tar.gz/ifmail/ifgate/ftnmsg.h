#ifndef _FTNMSG_H
#define _FTNMSG_H
#include "rfcmsg.h"

typedef struct _ftnmsg {
	int flags;
	faddr *to;
	faddr *from;
	char *date;
	char *subj;
	char *msgid;
	char *reply;
	char *origin;
	char *area;
} ftnmsg;

#define PVT 0x0001
#define CRS 0x0002
#define RCV 0x0004
#define SNT 0x0008
#define ATT 0x0010
#define TRN 0x0020
#define ORP 0x0040
#define K_S 0x0080
#define LOC 0x0100
#define HLD 0x0200
#define RSV 0x0400
#define FRQ 0x0800
#define RRQ 0x1000
#define RRC 0x2000
#define ARQ 0x4000
#define FUP 0x8000

extern void tidy_ftnmsg(ftnmsg *);
extern ftnmsg *mkftnhdr(rfcmsg *);
#endif
