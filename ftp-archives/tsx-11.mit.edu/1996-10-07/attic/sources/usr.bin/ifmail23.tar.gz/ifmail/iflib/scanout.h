#ifndef SCANOUT_H
#define SCANOUT_H
#include "ftn.h"

#define OUT_PKT 0
#define OUT_FLO 1
#define OUT_ARC 2

typedef int (_each_fn_t)(faddr*,char,int,char*);

extern int scanout(_each_fn_t*);

#endif
