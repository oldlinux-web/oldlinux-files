#include <unistd.h>
#include <stdio.h>
#include "lutil.h"
#include "nodelist.h"
#include "config.h"

int chat(node*,modem_string*,modem_string*,modem_string*,int,char*);

int dialphone(nlent,phone)
node *nlent;
char *phone;
{
	int rc;

	debug(18,"dialing %s",phone);
	rc=chat(nlent,modemreset,modemok,modemerror,3,phone);
	if (rc)
	{
		logerr("could not reset the modem");
		return rc;
	}
	rc=chat(nlent,modemdial,modemconnect,modemerror,70,phone);
	if (rc) loginf("could not connect to the remote");
	return rc;
}

int hangup(nlent)
node *nlent;
{
	debug(18,"hanging up");
	chat(nlent,modemhangup,NULL,NULL,0,NULL);
	sleep(1);
	return 0;
}
