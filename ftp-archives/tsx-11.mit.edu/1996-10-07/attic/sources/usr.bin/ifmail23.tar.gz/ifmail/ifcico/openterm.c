#include "xutil.h"

int openterm(char*);
int openterm(addr)
char *addr;
{
	debug(18,"try opening term connection \"%s\"",addr);
	return 0;
}
