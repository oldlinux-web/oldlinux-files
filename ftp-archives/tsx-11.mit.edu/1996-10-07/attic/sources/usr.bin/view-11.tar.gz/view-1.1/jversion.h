/*
 * jversion.h
 *
 * Copyright (C) 1991, 1992, Thomas G. Lane.
 * This file is part of the Independent JPEG Group's software.
 * For conditions of distribution and use, see the accompanying README file.
 *
 * This file contains software version identification.
 */


#define JVERSION	"4 10-Dec-92"

#define JCOPYRIGHT	"Copyright (C) 1992, Thomas G. Lane"
