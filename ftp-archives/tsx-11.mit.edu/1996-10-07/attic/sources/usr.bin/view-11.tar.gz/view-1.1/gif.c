#include <stdio.h>
#include <stdlib.h>
#include <vga.h>
#include "gif_lib.h"

#define MIN(x, y)	((x) < (y) ? (x) : (y))

extern int grayscale;
extern int sw_verbose;
extern int act_colors;
extern int xscale,yscale;

static char rcsheader[]="$Header$";

/* ChangeLog
 * $Log$
 */

extern unsigned char *vm_buffer;

extern int image_x,image_y;

static int
    ImageNum = 0,
    BackGround = 0,
    ForeGround = 1,			   /* As close to white as possible. */
    BeepsDisabled = FALSE,
    ZoomFactor = 1,
    MaximumScreenHeight = 1,
    BGIUserDriverMode = -1,
    DeviceMaxX = 640, DeviceMaxY = 480,	      /* Physical device dimensions. */
    ScreenWidth = 640, ScreenHeight = 480,         /* Gif image screen size. */
    InterlacedOffset[] = { 0, 4, 2, 1 }, /* The way Interlaced image should. */
    InterlacedJumps[] = { 8, 8, 4, 2 };    /* be read - offsets and jumps... */
static GifColorType
    *ColorMap;

static void PutScanLine(int y,GifRowType Row, GifFileType *GifFile,int s)
{ register int x;
  int maxx=vga_getxdim();
  int maxy=vga_getydim();

    for (x=0;x<=GifFile->SWidth;x++)
      { vga_setcolor(Row[x]);
	if ((x/(100/xscale)<maxx)&&(y/(100/yscale)<maxy))
	  vga_drawpixel (x/(100/xscale),y/(100/yscale));
	vm_buffer[(y/(100/yscale))*image_x+(x/(100/xscale))]
	  =Row[x];
	/*
	for (x2=GifFile->SWidth;x2<maxx;x2++)
	  vm_buffer[(y/(100/yscale))*image_x+(x2/(100/xscale))]=0;
	*/
      }
}

GIFERRORCODE ShowGif (char *gifname,int scale,GifFileType *GifFile) {
GifRecordType RecordType;
GifByteType *Extension;
GifRowType gline;

int	i, j, k, Error, NumFiles, Size, Row, Col,Width, Height, ExtCode,
	Count, ColorMapSize, GraphDriver, GraphMode, Sum;


if ((GifFile = DGifOpenFileName(gifname)) == NULL) return NOT_FOUND;
/* Allocate space for the buffer */
image_x = (GifFile->SWidth)/(100/xscale);
image_y = (GifFile->SHeight)/(100/yscale);

if ((vm_buffer = (unsigned char *) malloc(image_x*image_y)
     )==NULL)
  { perror ("malloc");
    return NOTENOMEM;
  }

if (sw_verbose)
  fprintf (stderr,"%li bytes virtual screen allocated\n",
	   (GifFile->SWidth)*(GifFile->SHeight));

/* Lets display it - set the global variables required and do it: */
    BackGround = GifFile -> SBackGroundColor;
    ColorMap = (GifFile -> IColorMap ? GifFile -> IColorMap :
				       GifFile -> SColorMap);
    ColorMapSize = 1 << (GifFile -> IColorMap ? GifFile -> IBitsPerPixel :
						GifFile -> SBitsPerPixel);

    /* Save current mode so we can recover. */

    act_colors = ColorMapSize;

    if (vga_getcolors() < ColorMapSize) return NOTENOCOLOR;

    BackGround = ForeGround = 1;
    Sum = ((int) ColorMap[1].Red) +
	  ((int) ColorMap[1].Green) +
	  ((int) ColorMap[1].Blue);
    j = k = Sum;
    if (!grayscale)
      for (i = 0; i < ColorMapSize; i++) {
	vga_setpalette(i, ColorMap[i].Red >> 2,
		 	 ColorMap[i].Green >> 2,
			 ColorMap[i].Blue >> 2);

	Sum = ((int) ColorMap[i].Red) +
	      ((int) ColorMap[i].Green) +
	      ((int) ColorMap[i].Blue);
	if (i != 0 && Sum > j) {			/* Dont use color 0. */
	    ForeGround = i;
	    j = Sum;
	}
	if (i != 0 && Sum <= k) {			/* Dont use color 0. */
	    BackGround = i;
	    k = Sum;
	}
      }
    else
      for (i = 0; i < ColorMapSize; i++) {
	vga_setpalette(i, ColorMap[i].Red >> 2,
		 	 ColorMap[i].Red >> 2,
			 ColorMap[i].Red >> 2);

	Sum = ((int) ColorMap[i].Red) +
	      ((int) ColorMap[i].Red) +
	      ((int) ColorMap[i].Red);
	if (i != 0 && Sum > j) {			/* Dont use color 0. */
	    ForeGround = i;
	    j = Sum;
	}
	if (i != 0 && Sum <= k) {			/* Dont use color 0. */
	    BackGround = i;
	    k = Sum;
	}
    }

    DeviceMaxX = vga_getxdim() - 1;		    /* Read size of physical screen. */
    DeviceMaxY = vga_getydim() -1 ;
    ScreenWidth = GifFile -> SWidth;
    ScreenHeight = MIN(GifFile -> SHeight, MaximumScreenHeight);
if ((gline = (GifRowType)
	malloc(GifFile -> SWidth)) == NULL) return NOTENOMEM;
    Size = GifFile -> SWidth * sizeof(GifPixelType);/* Size in bytes of one row.*/

    do {
	if (DGifGetRecordType(GifFile, &RecordType) == GIF_ERROR)
	   return GETRECORD;
	switch (RecordType) {
	    case IMAGE_DESC_RECORD_TYPE:
		if (DGifGetImageDesc(GifFile) == GIF_ERROR) return GETDESC;
		Row = GifFile -> ITop; /* Image Position relative to Screen. */
		Col = GifFile -> ILeft;
		Width = GifFile -> IWidth;
		Height = GifFile -> IHeight;
		/*
		if (GifFile -> ILeft + GifFile -> IWidth > GifFile -> SWidth ||
		   GifFile -> ITop + GifFile -> IHeight > GifFile -> SHeight) {
		    fprintf(stderr, "Image %d is not confined to screen dimension, aborted.\n");
		    exit(-2);
		}
		*/
		if (GifFile -> IInterlace) {
		    /* Need to perform 4 passes on the images: */
		    for (Count = i = 0; i < 4; i++)
			for (j = Row + InterlacedOffset[i]; j < Row + Height;
						 j += InterlacedJumps[i]) {
			    if (DGifGetLine(GifFile,gline,
				Width) == GIF_ERROR) return GETLINE;
			    PutScanLine(j,gline,GifFile,scale);
			}
		}
		else {
		    for (i = 0; i < Height; i++, Row++) {
			if (DGifGetLine(GifFile,gline,
				Width) == GIF_ERROR) {
			    MaximumScreenHeight = MIN(i - 1, MaximumScreenHeight);
			    return GETLINE;
			}
			 MaximumScreenHeight = MIN(i - 1, MaximumScreenHeight);
			PutScanLine(i,gline,GifFile,scale);
		    }
		}
		break;
	    case EXTENSION_RECORD_TYPE:
		/* Skip any extension blocks in file: */
		if (DGifGetExtension(GifFile, &ExtCode, &Extension) == GIF_ERROR)
		   return GETEXT;
		while (Extension != NULL) {
		    if (DGifGetExtensionNext(GifFile, &Extension) == GIF_ERROR)
                       return GETEXTNEXT;
		}
		break;
	    case TERMINATE_RECORD_TYPE:
		break;
	    default:		    /* Should be traps by DGifGetRecordType. */
		break;
	}
    }
    while (RecordType != TERMINATE_RECORD_TYPE);


    if (DGifCloseFile(GifFile) == GIF_ERROR) return NOTCLOSED;

return OK;
}


