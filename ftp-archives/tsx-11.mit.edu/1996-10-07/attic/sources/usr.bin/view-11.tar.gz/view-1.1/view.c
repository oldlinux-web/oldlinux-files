#include <stdio.h>
#include <stdlib.h>
#include <linux/limits.h>
#include <string.h>
#include <vga.h>
#include "gif_lib.h"
#include <curses.h>


#ifndef DEF_VMODE
  #define DEF_VMODE G320x240x256
#endif

#ifndef DEF_COLORS
  #define DEF_COLORS 256
#endif

#ifndef DEF_CHUNK
  #define DEF_CHUNK 50
#endif

int image_x;
int image_y;

typedef enum { GIFFILE, JFIFFILE, UNKNOWN } image_t;

int grayscale = 0;
int colors = DEF_COLORS, act_colors;
int scale = 100;
int xscale = 100, yscale = 100;
int videomode = DEF_VMODE;
int sw_verbose = 0;

unsigned char *vm_buffer;

void vhelp()
{
  fprintf (stderr,
	   "\nUsage: \E[1mview\E[m [\E[1mswitches\E[m] \E[1mimage\E[m\n");
  fprintf (stderr,"\n       switches:\n");
  fprintf (stderr,"            -\E[1mverbose\E[m         print some info\n");
  fprintf (stderr,
	   "            -\E[1mgrayscale\E[m       force grayscale output\n");
  fprintf (stderr,"            -\E[1mmode\E[m \E[4mvideomode\E[m  select videomode (1..8)\n"); 
  fprintf (stderr,"            -\E[1mscale\E[m \E[4mfactor\E[m    scale image (in percents)\n"); 
  fprintf (stderr,"            -\E[1mchunksize\E[m \E[4msize\E[m  pixels to scroll\n\n\n");
}

image_t check_ext (char ext[4])
{ if ((strcmp((char *) ext,"gif")==0)||(strcmp((char *) ext,"GIF")==0))
    return GIFFILE;
  if ((strcmp((char *) ext,"jpg")==0)||(strcmp((char *) ext,"JPG")==0))
    return JFIFFILE;
  return UNKNOWN;
}

void gif_error (int error)
{ 
  switch (error)
    { case NOT_FOUND:
	fprintf (stderr,"File not found\n");
	break;
      case GETEXT:
      case GETEXTNEXT:
	fprintf (stderr,"Error %d: get GIF extension\n",error);
	break;
      case GETDESC:
	fprintf (stderr,"Error %d: get GIF descriptor\n",error);
	break;
      case NOTENOCOLOR:
	fprintf (stderr,
		 "Cannot quantize the colors - choose 256 colors mode\n");
	break;
      default:
	fprintf (stderr,"Couldn't load GIF file - Error %d\n",error);
	break;
      }
  exit(5);
}

int main(int argc, char *argv[])
{ int ac=1;
  char image_name[NAME_MAX];
  char name_ext[4];
  GifFileType gif;
  int error;
  int cx=0,cy=0,update=0,chunk=DEF_CHUNK;
  int xscroll=1,yscroll=1;
  name_ext[3]='\0';
  
  if (argc==1)
    { vhelp();
      return 1;
    }
  
  while (argv[ac][0]=='-')
    {
      switch (argv[ac][1])
        {
	case 'v':
	  sw_verbose = 1; break;
	case 'g':
	  grayscale = 1; break;
	case 'm':
	  ac++;
	  videomode = atoi(argv[ac]);
	  if (videomode<5) colors=16;
	  else colors=256;
	  break;
	case 'c':
	  ac++;
	  chunk = atoi(argv[ac]);
	  break;
	case 's':
	  ac++;
	  scale = atoi(argv[ac]);
	  if (scale>100)
	    { fprintf (stderr,"You cannot magnify images - not in this version\n");
	      return 3;
	    }
	  xscale = scale;
	  yscale = scale;
	  break;
	case 'x':
	  ac++;
	  xscale = atoi(argv[ac]);
	  if (xscale>100)
	    { fprintf (stderr,"You cannot magnify images - not in this version\n");
	      return 3;
	    }
	  break;
	case 'y':
	  ac++;
	  yscale = atoi(argv[ac]);
	  if (yscale>100)
	    { fprintf (stderr,"You cannot magnify images - not in this version\n");
	      return 3;
	    }
	  break;
	default:
	  vhelp ();
	  return 1;
	}
      ac++;
    }
  
  if (ac>argc)
    { vhelp();
      return 1;
    }
  
  strcpy ((char *) image_name,argv[ac]);
  name_ext[2]=image_name[strlen(image_name)-1];
  name_ext[1]=image_name[strlen(image_name)-2];
  name_ext[0]=image_name[strlen(image_name)-3];

  initscr();
  cbreak();
  noecho();

  if (sw_verbose) fprintf (stderr,"Videomode %d selected.\n",videomode);
  switch (check_ext(name_ext))
    {
    case JFIFFILE:
      if (sw_verbose) fprintf (stderr,"%s is a JFIF image\n",image_name);
      read_JPEG_file (image_name);
      break;
    case GIFFILE:
      if (sw_verbose) fprintf (stderr,"%s is a GIF image\n",image_name);
      vga_setmode (videomode);
      error = ShowGif(image_name,100/scale,gif);
      if (error)
	{ vga_setmode(TEXT);
	  endwin();
	  gif_error(error);
	  return 6;
	}
      break;
    default:
      endwin();
      fprintf (stderr,"Unsupported image format\n");
      return 2;
    }
  
  if (sw_verbose)
    { fprintf (stderr,"Size: %dx%d, scaled %d%%\n",image_x,image_y,scale);
      fprintf (stderr,"Colors:%d (Output %d)\n",act_colors,colors);
    }
  
  if (image_x<vga_getxdim()) { xscroll=0; yscroll=0; }
  if (image_y<vga_getydim()) { yscroll=0; xscroll=0; }
  
  
while (1)
  { switch (getch())
      { case 'A':
	  if (yscroll)
	    {
	      if (cy>chunk) cy-=chunk;
	      else cy=0;
	      update = 1;
	    }
	  break;
	case 'B':
	  if (yscroll)
	    {
	      if ((image_y-(cy+vga_getydim()))>chunk)
		cy+=chunk;
	      else
		cy=image_y-vga_getydim()-1;
	      update = 1;
	    }
	  break;
	case 'D':
	  if (xscroll)
	    {
	      if (cx>chunk) cx-=chunk;
	      else cx=0;
	      update = 1;
	    }
	  break;
	case 'C':
	  if (xscroll)
	    {
	      if ((image_x-(cx+vga_getxdim()))>chunk)
		cx+=chunk;
	      else
		cx=image_x-vga_getxdim()-1;
	      update = 1;
	    }
	  break;
      
      case 'e':
	vga_setmode (TEXT);
	endwin();
	return 0;
      }
    if (update)
      { update = 0;
	vsmap (cx,cy,vm_buffer);
      }
  }
  vga_setmode (TEXT);
  return 0;
}



