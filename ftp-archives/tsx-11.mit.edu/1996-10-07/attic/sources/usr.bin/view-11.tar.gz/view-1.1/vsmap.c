#include <stdio.h>
#include <stdlib.h>
#include <vga.h>

extern int image_x;
extern int image_y;

void vsmap (int xpos, int ypos, unsigned char *buffer)
{ register int x,y;
  int maxx = vga_getxdim();
  int maxy = vga_getydim();
  char *lptr;
  
  for (y=ypos;y<((maxy<image_y)?(maxy+ypos):image_y);y++)
    { lptr = &(buffer[y*image_x+xpos]);
      vga_drawscanline (y-ypos,lptr);
    }
}
