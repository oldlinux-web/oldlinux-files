#include <stdio.h>
#include "bwrite.h"
#include "config.h"

/* write short (16bit) integer in "standart" byte order */
int iwrite(i,fp)
int i;
FILE *fp;
{
	putc(i & 0xff,fp);
	putc((i >> 8) & 0xff,fp);
	return 0;
}

/* write long (32bit) integer in "standart" byte order */
int lwrite(i,fp)
long i;
FILE *fp;
{
	int c;

	for (c=0;c<32;c+=8) putc((i >> c) & 0xff,fp);
	return 0;
}

int awrite(s,fp)
char *s;
FILE *fp;
{
	while (*s) putc(outtab[*(s++) & 0xff], fp);
	putc(0,fp);
	return 0;
}

/* write an arbitrary line to message body: change \n to \r\n */
int cwrite(s,fp)
char *s;
FILE *fp;
{
	while (*s) 
	{
		if (*s == '\n') putc('\r',fp);
		else putc(outtab[*s & 0xff],fp);
		s++;
	}
	return 0;
}

/* write (multiline) header to kluge: change \n to ' ' and end line with \r */
int kwrite(s,fp)
char *s;
FILE *fp;
{
	while (*s) 
	{
		if (*s != '\n') putc(outtab[*s & 0xff],fp);
		else if (*(s+1)) putc(' ',fp);
		s++;
	}
	putc('\r',fp);
	return 0;
}
