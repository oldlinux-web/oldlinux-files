#define LOCKDIR	"/usr/spool/mmdf/lock/home"
#define QDIR	"q.fidonet"
#define MSGDIR	"msg"

