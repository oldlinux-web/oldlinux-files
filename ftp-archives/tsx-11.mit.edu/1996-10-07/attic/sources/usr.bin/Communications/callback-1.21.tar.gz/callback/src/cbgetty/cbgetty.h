
/* Header file for pre-getty program cbgetty */

#include "../rss/rss.h" 
