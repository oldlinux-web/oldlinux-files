#include "rss.h"

int finduser (char *uname)			/* find index of directory */
{						/* entry matching "uname */
    register int
    	i;
    	
    for (i = 0; i < nentries; i++)		/* loop thru all entries */
    	if (! strcmp (entry [i].name, uname))	/* if name found: */
	{
	    if (! strcmp (entry [i].number,	/* is number part "extra"? */
			  "extra"))
	    {
		printf ("Enter number "		/* yes.. */
			"to call back: ");	/* read in phone number */
		gets (extranum);		
		if (! extranum [0])
		{
		    puts ("No number entered.");
		    exit (1);
		}
		return (EXTRAIND);
	    }
	    if (! strcmp (entry [i].number,	/* is number part "direct"? */
			  "direct"))
		return (DIRECTIND);
	    
    	    return (i);				/* no extra or direct, */
	}					/* return actual index */

    return (-1);				/* nothing found, -1 */
}
