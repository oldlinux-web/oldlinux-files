#include "cbgetty.h"

void main (int argc, char **argv)
{
    register int
	curstate;

    if ((curstate = getstate ()))	    /* if state indicates callback */
    {					    /* mode: */
	curstate--;			    /* decrement state */
	writestate (curstate);		    /* update state file */
	if (! curstate)			    /* if at zero, reset to waiting */
	    copyfile (ORGGETTY, DESTGETTY);
    }
	
    argv [0] = GETTYPROG;		    /* overlay ourselves with */
    execv (argv [0], argv);		    /* original getty program */

    /* should never get here */
    error ("cbgetty: cannot exec original getty!\n");
}
		      
