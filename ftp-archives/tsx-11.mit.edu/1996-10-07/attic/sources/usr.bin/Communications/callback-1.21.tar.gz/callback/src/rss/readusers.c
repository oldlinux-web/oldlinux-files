#include "rss.h"

void readusers ()
{
    register FILE
    	*inf;
    register char
    	*line;
    	
    if (nusers)				/* if already read.. */
    	return;				/* nogo */
    	
    /* try to open allowed users list */
    if (! (inf = fopen (USERLIST, "r")) )
    	error ("can't open user list \"%s\" for reading\n", USERLIST);
    	
    /* read in all names */
    while ( (line = fgetline (inf)) )
    {
    	if (! (user = realloc (user, (nusers + 1) * sizeof (char *)) ) ||
    	    ! (user [nusers] = strdup (line))
    	   )
    	    error ("out of memory");
    	nusers++;
    }
    
    if (! nusers)
    	error ("user list \"%s\" leads to no allowed usernames\n", 
    		USERLIST);
    
    fclose (inf);
}
