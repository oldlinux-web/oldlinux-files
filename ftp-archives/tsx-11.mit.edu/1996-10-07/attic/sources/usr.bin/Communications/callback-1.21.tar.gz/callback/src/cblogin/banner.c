#include "cblogin.h"

void banner ()
{
    printf ("\n"
    	    "ICCE Callback Facility  V1.05\n"
    	    "Copyright (c) ICCE 1993,1994. All rights reserved.\n"
    	    "\n");
}
