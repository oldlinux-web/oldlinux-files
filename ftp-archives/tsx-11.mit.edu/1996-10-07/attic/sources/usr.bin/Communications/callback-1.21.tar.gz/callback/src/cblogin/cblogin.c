#include "cblogin.h"

int main (int argc, char **argv)
{
    register int			/* index of number to call back */
	callback_nr;
    
    banner ();				/* print banner of this program */
    
    atexit (reinit);			/* re-load init when done */
    
    if (! getstate ())			/* if statefile indicates */
    {					/* first login: */
    
	readnums ();			/* read in phone numbers */
	readusers ();			/* read in allowed users */
	validate (argv [1]);		/* validate user name */
#   	ifdef SHOWNUMS
    	shownums ();			/* show list of allowed numbers */
    	putchar ('\n');
#   	endif

	callback_nr = getinput ();	/* read input */

	if (callback_nr == DIRECTIND)	/* and chosen? */
	    exec_login (argc, argv);	/* then run the login program */
	
	setcallback (callback_nr);	/* set callback mode */
    	
    	printf ("\nNow please break the connection.\n"
    		"Accept the next incoming call as a callback.\n"
    		"Bye!\n");
    }
    else				/* else, if state indicates */
	exec_login (argc, argv);	/* login time: run original login */

    return (0);				/* return success */
}
