#include "cblogin.h"

void validate (char *username)
{
    register int
    	i;
    	
    for (i = 0; i < nusers; i++)		/* username must match */
    	if (! strcmp (user [i], username))	/* one of the allowed */
    	{
    	    printf ("User %s validated for callback.\n", username);
    	    return;
    	}
    	
    						/* otherwise: nogo */
    puts ("\nValidation failed.\n"
    	  "Bye!");
    exit (1);
}
