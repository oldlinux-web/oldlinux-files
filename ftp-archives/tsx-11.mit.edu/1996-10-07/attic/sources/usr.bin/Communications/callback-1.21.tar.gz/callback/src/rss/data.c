#include "rss.h"

/* global data of programs */
PH_ENTRY_
    *entry = NULL;			/* vector of phone directory entriess */
unsigned
    nentries = 0;			/* # of entries */
char	
    **user = NULL;			/* vector of allowed usernames */
unsigned
    nusers = 0;				/* # of usernames */
char
    extranum [100];			/* buffer for "extra" phone number */
    
