#include "cbgetty.h"

void error (char *fmt, ...)		/* local error function, */
{					/* overrules ../rss/error.c */
    va_list
    	args;
    FILE
    	*logfile,
    	*panicfile;
    time_t
    	ltime;
    	
    va_start (args, fmt);
    if ((logfile = fopen (ERRLOG, "a")))
    {
    	time (&ltime);
    	fprintf (logfile, "%s", ctime (&ltime));
    	vfprintf (logfile, fmt, args);
    }
    else if ((panicfile = fopen (PANICLOG, "a")))
    {
    	fprintf (panicfile,
    		 "Callback panic: log file could not be opened.\n"
    		 "An error has occurred:\n");
	vfprintf (panicfile, fmt, args);
    }
    
    exit (1);
}
