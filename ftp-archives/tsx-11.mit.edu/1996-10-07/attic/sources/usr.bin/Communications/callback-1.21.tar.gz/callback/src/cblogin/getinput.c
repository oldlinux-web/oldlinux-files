#include "cblogin.h"

int getinput ()
{
    char
    	buf [200];				/* buffer for name */
    register int
    	i;					/* callback name index */
    	
    printf ("Enter name to call back: ");	/* prompt */
    gets (buf);					/* read input */

    if ( (i = finduser (buf)) == -1 )		/* invalid callback name */
    {
	puts ("No such name defined.");
	exit (1);
    }

    return (i);
}
