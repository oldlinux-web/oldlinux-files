#include "rss.h"

void setcallback (int phindex)
{
    makenewdef (phindex);
    copyfile (TMPGETTY, DESTGETTY);
    unlink (TMPGETTY);
    writestate (NTRIES + 1);
}
