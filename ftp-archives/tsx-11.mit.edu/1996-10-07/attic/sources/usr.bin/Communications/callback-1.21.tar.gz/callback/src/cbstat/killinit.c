#include "cbstat.h"

void killinit ()
{
    reinit();    	

#   ifdef PID_INIT
    if (kill(PID_INIT, SIGHUP))
        error ("can't restart init\n");
    else
	puts("init restarted\n");
#   endif	
}
    
