#include "cbstat.h"

int main (int argc, char **argv)
{
    register int
    	avlen;
    	
    if (argc == 1)
    	usage ();
    	
    avlen = strlen (argv [1]);
    	
    if (! strncmp (argv [1], "-call", avlen))
    {						/* call back to number */
    	readnums ();
    	force (argv [2]);
    }
#   ifdef DISABLEGETTY
    else if (! strncmp (argv [1], "-disable", avlen))
    {						/* disable line */
        copyfile (DISABLEGETTY, DESTGETTY);
        writestate (0);
        reinit ();
    }
#   endif    	    
    else if (! strncmp (argv [1], "-file", avlen))
    	showfile (); 				/* show file */
    else if (! strncmp (argv [1], "-state", avlen))	
    	showstat ();				/* show state */
    else if (! strncmp (argv [1], "-phone", avlen))
    {						/* show phone nums */
   	readnums ();
    	shownums ();
    }
    else if (! strncmp (argv [1], "-reset", avlen))
    {						/* reset to state 0 */
	copyfile (ORGGETTY, DESTGETTY);
    	writestate (0);
	reinit ();
    }
    else if (! strncmp (argv [1], "-users", avlen))
    {						/* show users */
    	readusers ();
    	showusers ();
    }
    else if (! strncmp (argv [1], "-wake", avlen))
	killinit ();				/* re-wake up getty */
    else
    	usage ();

    return (0);
}
    	
