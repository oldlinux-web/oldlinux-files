/* Main header file of cbstat program */

#include "../rss/rss.h"

extern void force (char *symname);
extern void killinit (void);
extern void showfile (void);
extern void showstat (void);
extern void showusers (void);
extern void usage (void);
