#include "rss.h"

void reinit ()
{
#ifdef PSCMD
    FILE
    	*pslist;
    char
    	buf [256];
    int
    	pid;
    	
    if (! (pslist = popen (PSCMD, "r")) )\
    	error ("can't get processes list\n");
    	
    while (fgets (buf, 255, pslist))
	if (strstr (buf, GETTYSTRING))
	    if (! sscanf (buf, " %d", &pid))
	    	error ("can't find PID in ps-output \"%s\"\n", buf);
	    else if (kill (pid, SIGHUP))
	    	error ("can't kill (%d,SIGHUP) in \"%s\"\n", pid, buf);
	    	    
    pclose (pslist);
#endif
}
    
