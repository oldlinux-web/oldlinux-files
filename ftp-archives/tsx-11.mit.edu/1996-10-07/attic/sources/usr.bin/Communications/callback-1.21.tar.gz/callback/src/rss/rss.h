/* Runtime support system header file */

/* all the include files you could wish for */
#include <ctype.h>
#include <malloc.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* here we have the configuration file */
#include "../config.h"

/* marker where to insert number to call back */
#define MARKER		"$PHONE"

/* type of the list of allowed callback numbers */
typedef struct
{
    char 
    	*name,
    	*number,
	*filename;
} PH_ENTRY_;

/* the list of numbers: realloc-able array, and number of entries */
extern PH_ENTRY_	*entry;
extern unsigned		nentries;

/* the list of allowed users, realloc-able array, and number of entries */
extern char		**user;
extern unsigned		nusers;

/* room extra phone num and its index */
extern char		extranum [];
#define	EXTRAIND	99998

/* index for a direct connection */
#define DIRECTIND	99999

/* function prototypes of all auxiliary stuff */
extern void copyfile (char *in, char *out);
extern void error (char *fmt, ...);
extern char *fgetline (FILE *inf);
extern int  finduser (char *uname);
extern int  getstate (void);
extern void makenewdef (int phonenumindex);
extern void readnums (void);
extern void readusers (void);
extern void reinit (void);
extern void setcallback (int phonenumindex);
extern void shownums (void);
extern void writestate (int st);
