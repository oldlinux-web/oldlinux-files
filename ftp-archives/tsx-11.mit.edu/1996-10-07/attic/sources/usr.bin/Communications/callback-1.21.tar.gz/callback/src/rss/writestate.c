#include "rss.h"

void writestate (int st)
{
    register FILE
    	*fstate;
    	
    if (! (fstate = fopen (STATE, "w")) )	/* open state file */
    	error ("can't open state file \"%s\" for writing\n", STATE);
    	
    fputc (st + '0', fstate);			/* write state id */
    
    fclose (fstate);				/* close state file */
}
