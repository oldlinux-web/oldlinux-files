/* 
   config.h: defines the pathnames of relevant files,
   process names, other settings.. 
   --------------------------------------------------
*/

/* the tty line on which your incoming calls occur, without the "/dev/". Use
"ttyS1" for an external modem, "ttyS3" for an internal modem.
*/
#define TTY_LINE                "ttyS3"

/* the file containing allowed callback numbers.. see examples
   for the format of this file 
*/
#define PHONELIST		"/conf/callback/callback.ph"

/* the file containing allowed users.. see examples for the format
   of this file 
*/
#define USERLIST		"/conf/callback/callback.users"   

/* the copy of the original getty definitions file 
   see examples directory for a sample
*/
#define ORGGETTY		"/conf/callback/getty." TTY_LINE ".org"

/* the definition file for the getty-callback, containing a $PHONE
    inplace of the number to call.. also, see examples directory 
*/
#define CBGETTY			"/conf/callback/getty." TTY_LINE ".cb"

/* the filename of a temporary getty definitions file 
   used only when constructing the getty-callback def file 
*/
#define TMPGETTY		"/tmp/getty." TTY_LINE ".tmp"

/* the callback state file which is automatically maintained by
   callback 
*/
#define STATE			"/conf/callback/callback.st"

/* the number of tries that should be made when calling back, before it's
   decided that this is a no-go situation. Only relevant when cbgetty is used;
   set to any non-zero value if you don't use cbgetty.
*/
#define NTRIES			3

/* the file which getty uses for its definition */
#define DESTGETTY		"/etc/default/getty." TTY_LINE

/* the login program */
#define LOGIN			"/bin/login"

/* the getty program which you use to listen to the modem */
#define GETTYPROG		"/etc/modem_getty"

/* the error-log file */
#define ERRLOG			"/usr/adm/callback.log"

/* the panic-log file, incase ERRLOG logging fails */
#define PANICLOG		"/dev/console"

/* the process number of init, should always be 1.. used only by
   cbstat -wake
*/
#define PID_INIT		1

/* command to list processes.. must lead to the process number in the first
   column, and the process with its arguments, used in resetting (uu)getty
   to a new state. Leave undefined if you don't want the programs to kill 
   off (uu)getty processes (but then what good is the package for?).
*/
#define PSCMD			"ps -ax"
   
/* process string of the (uu)getty process, used in resetting (uu)getty
   for a new definition file. Note that PSCMD (above) must show this
   string, when (uu)getty is running.. Check this carefully! Only interpreted 
   when PSCMD is defined.
   The way I do this, is I have a symlink in /etc/, made by:
   (cd /etc ; ln -s getty modem_getty). Then i have in /etc/inittab a call to
   /etc/modem_getty to listen to the modem. That way "modem_getty" is the only
   process which is ever associated with the modem.. 
*/
#define GETTYSTRING		"modem_getty"

/* e-mail address of sysadm which user can mail upon failure, displayed
   by error logging functions. Leave undefined if you don't want callback
   to display the message that the person can be e-mailed in case of trouble,
   otherwise please define it to your own address or my name will be all
   over your screen...
*/   
#define EMAIL			"karel@icce.rug.nl"

/* if you want callback to show the list of allowed phone numbers, 
   define SHOWNUMS; otherwise, leave it undefined
*/
#define SHOWNUMS
   
/* if you want cbstat to be able to do a 'disable', define the next name.
   if not defined, cbstat won't have a -disable flag;
   if defined, you will need that file in /conf/callback: that file should
   then effectively disable the dial-in
*/
#define DISABLEGETTY 		"/conf/callback/getty." TTY_LINE ".dis"
