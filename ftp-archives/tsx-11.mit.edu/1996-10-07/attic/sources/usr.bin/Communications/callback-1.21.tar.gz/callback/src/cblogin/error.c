#include "cblogin.h"

void error (char *fmt, ...)		/* local error function, */
{					/* overrules ../rss/error.c */
    va_list
    	args;
    FILE
    	*logfile,
    	*panicfile;
    time_t
    	ltime;
    	
    /* display message to user */
    puts ("The callback can't be established. An error has occurred.");
#   ifdef EMAIL
    printf ("Please e-mail to \"%s\" or ask the sysop to fix it.\n", EMAIL);
#   else
    puts ("Ask the sysop to fix it.");
#   endif    

    /* print message to logfile, or if that fails: to panicfile */    	
    va_start (args, fmt);
    if ((logfile = fopen (ERRLOG, "a")))
    {
    	time (&ltime);
    	fprintf (logfile, "%s", ctime (&ltime));
    	vfprintf (logfile, fmt, args);
    }
    else if ((panicfile = fopen (PANICLOG, "a")))
    {
    	fprintf (panicfile,
    		 "Callback panic: log file could not be opened.\n"
    		 "An error has occurred:\n");
	vfprintf (panicfile, fmt, args);
    }
    
    exit (1);
}
    
