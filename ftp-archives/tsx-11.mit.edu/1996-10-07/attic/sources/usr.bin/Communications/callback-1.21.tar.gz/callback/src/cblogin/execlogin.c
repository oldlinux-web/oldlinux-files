#include "cblogin.h"

void exec_login (int argc, char **argv)
{
    copyfile (ORGGETTY, DESTGETTY);	/* reset original getty deffile */
    writestate (0);			/* update statefile */
    reinit ();				/* restart init */
    argv [0] = LOGIN;			/* set new program name for exec */
    execv (LOGIN, argv);		/* proceed with login */
    	
    					/* should never get here */
    error ("can't proceed with login\n");
}
