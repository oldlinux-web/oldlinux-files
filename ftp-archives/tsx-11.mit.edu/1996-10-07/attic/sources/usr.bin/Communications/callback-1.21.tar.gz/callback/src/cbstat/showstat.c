#include "cbstat.h"

void showstat ()
{
    register int
    	state;
    	
    state = getstate ();
    printf ("Callback state: %d (%s)\n", 
        state,
        state ? 
            "dialling back after callback request" : 
            "waiting for callback request or using modem"
    );
}
