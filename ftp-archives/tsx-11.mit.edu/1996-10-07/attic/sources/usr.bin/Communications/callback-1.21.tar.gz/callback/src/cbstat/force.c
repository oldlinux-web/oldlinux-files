#include "cbstat.h"

void force (char *symname)
{
    register int
	i;

    if (! symname)
	error ("Missing name to call up.\n");
    if ( (i = finduser (symname)) == -1 )
	error ("No such name \"%s\" defined.\n", symname);
    if (i == DIRECTIND)
	error ("No sense establishing direct connection here.\n");
    setcallback (i);
    reinit ();
}
