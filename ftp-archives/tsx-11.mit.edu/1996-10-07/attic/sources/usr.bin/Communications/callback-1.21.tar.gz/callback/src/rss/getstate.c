#include "rss.h"

int getstate ()
{
    register FILE
    	*inf;
    register int
    	state;
    	
    if (! (inf = fopen (STATE, "r")) )		/* no state file? */
    	return (0);				/* assume 1st login */
    	
    state = fgetc (inf);			/* read in state character */
    if (feof (inf))				/* invalid state file? */
    	error ("invalid state file \"%s\"\n", STATE);
    	
    fclose (inf);
    return (state - '0');			/* return the read state */
}
