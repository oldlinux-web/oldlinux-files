/* Main header file for callback program */

/* here's the local runtime support system header file */
#include "../rss/rss.h"

/* function prototypes of all auxiliary stuff */
extern void banner (void);
extern void error (char *fmt, ...);
extern void exec_login (int ac, char **av);
extern int  getinput (void);
extern void validate (char *username);
