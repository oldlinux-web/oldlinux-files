#include "cbstat.h"

void showfile ()
{
    FILE
    	*inf;
    char
    	*cp;
    
    if (! (inf = fopen (DESTGETTY, "r")) )
    	error ("can't open \"%s\" for reading\n", DESTGETTY);
    	
    printf ("Current file \"%s\":\n", DESTGETTY);
    while ( (cp = fgetline (inf)) )
    	printf ("    %s\n", cp);
    fclose (inf);
}
    
    
