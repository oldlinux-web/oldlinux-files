#include "rss.h"

void makenewdef (int index)
{
    register FILE
    	*inf,
    	*outf;
    char
    	buf [300];
    register char
    	*cp,
    	*before,
    	*beyond;

    /* open IO files */
    /* source is either the name from the phonelist index, or when
       no given: the default callback definitions file */
    cp = (index < EXTRAIND) ?
	    (entry [index].filename ? entry [index].filename : CBGETTY)
			    :
	 CBGETTY;
    if (! (inf = fopen (cp, "r")) )
    	error ("can't open getty defintions file \"%s\"\n", cp);

    if (! (outf = fopen (TMPGETTY, "w")) )
    	error ("can't open temp file \"%s\"\n", TMPGETTY);
    	
    while (1)
    {
    	fgets (buf, 299, inf);			/* read input line */
    	if (feof (inf))				/* at EOF? */
    	    break;				/* done.. */
    	    
    	if ( (cp = strstr (buf, MARKER)) )	/* is there a $PHONE */
    	{					/* in the line ? */
    	    for (before = buf; 			/* yes.. change $PHONE into */
    	         before < cp; before++		/* the phone number to dial */
		)
    	    	fputc (*before, outf);
    	    	
	    if (index == EXTRAIND)		/* yes.. extra index? */
	    	fprintf (outf, "%s", extranum);
	    else
    	        fprintf (outf, "%s", entry [index].number);

    	    beyond = cp + strlen (MARKER);
    	    fprintf (outf, "%s", beyond);
    	}
    	else					/* no $PHONE.. just copy */
    	    fprintf (outf, buf);
    }
    
    fclose (inf);
    fclose (outf);
}
