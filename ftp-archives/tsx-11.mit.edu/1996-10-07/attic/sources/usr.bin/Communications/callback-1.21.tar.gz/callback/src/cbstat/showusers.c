#include "cbstat.h"

void showusers ()
{
    register int
    	i;
    	
    puts ("Allowed users:");
    for (i = 0; i < nusers; i++)
    	printf ("    %s\n", user [i]);
}
