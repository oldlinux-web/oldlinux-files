#include "rss.h"

void shownums ()
{
    register int
    	i;
    	
    puts ("Allowed callback names:");
    for (i = 0; i < nentries; i++)
	if (strcmp (entry [i].number, "extra") &&
	    strcmp (entry [i].number, "direct")
	   )
	    printf ("%30s\n", entry [i].name);
}
