#include "cbstat.h"

void usage ()
{
    error ("\n"
    	   "ICCE Callback Status Watcher  V1.07\n"
    	   "Copyright (c) ICCE 1993,1994. All rights reserved.\n"
    	   "\n"
    	   "Cbstat by Karel Kubat.\n"
    	   "\n"
    	   "Usage: cbstat -flag, where flag may be:\n"
    	   "       -call symbolic_name  : forces callback to name\n"
#	   ifdef DISABLEGETTY
	   "       -disable             : disables (uu)getty's dial-in\n"
#          endif	       	   
    	   "       -file                : shows (uu)getty's definition file\n"
    	   "       -phone               : shows allowed callback phone numbers\n"
    	   "       -reset               : resets callback to waiting state (state 0)\n"
    	   "       -state               : shows state of callback\n"
    	   "       -users               : shows allowed users who may use callback\n"
    	   "       -wake                : wakes up init to reload (uu)getty\n"
    	   "\n"
    	   "Flags may be abbreviated, e.g., \"-wa\" is equivalent to "
    	   							" \"-wake\".\n"
    	   "\n");
}
