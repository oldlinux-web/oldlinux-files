#include "dim.h"

void error (char *fmt, ...)
{
    va_list
    	args;
    	
    va_start (args, fmt);
    vprintf (fmt, args);
    
    exit (1);
}
    
