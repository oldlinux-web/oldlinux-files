#include "dim.h"

void copyfile (char *in, char *out)
{
    register FILE
    	*inf,
    	*outf;
    register int
    	ch;
    	
    /* open IO files */
    if (! (inf = fopen (in, "r")) )
    	error ("can't open file to copy from \"%s\"\n", in);
    if (! (outf = fopen (out, "w")) )
    	error ("can't open file to copy to \"%s\"\n", out);
    	
    while (1)
    {
    	ch = fgetc (inf);			/* read char */
    	if (feof (inf))				/* at EOF? */
    	    break;				/* yes.. done */
    	fputc (ch, outf);			/* no.. write to outfile */
    }
    
    fclose (inf);				/* close IO files */
    fclose (outf);
}    
