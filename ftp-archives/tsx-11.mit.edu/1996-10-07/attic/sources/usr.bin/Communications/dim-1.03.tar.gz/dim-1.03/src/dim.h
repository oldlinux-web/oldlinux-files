/*              Main header file of dim program 
*/

#include <ctype.h>              /* used include files */
#include <malloc.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
                                
#include "config.h"             /* here we have the configuration file */

#define PID_INIT	1       /* process ID of init, should be 1 */

                                /* function prototypes */
extern void copyfile (char *in, char *out);
extern void error (char *fmt, ...);
extern char *fgetline (FILE *inf);
extern void reinit (int kill_init);
extern void showfile (void);
extern void usage (void);
