#include "dim.h"

int main (int argc, char **argv)
{
    register int
    	avlen;
    	
    if (argc == 1)
    	usage ();
    	
    avlen = strlen (argv [1]);
    	
    if (! strncmp (argv [1], "-disable", avlen))
    {						/* disable line */
        copyfile (DISABLEGETTY, DESTGETTY);
        reinit (0);
    }
    else if (! strncmp (argv [1], "-enable", avlen))
    {						/* enabling dialling-in */
	copyfile (ORGGETTY, DESTGETTY);
	reinit (0);
    }
    else if (! strncmp (argv [1], "-file", avlen))
    	showfile (); 				/* show file */
    else if (! strncmp (argv [1], "-wake", avlen))
	reinit (1);				/* re-wake up getty, by killing init */
    else
    	usage ();

    return (0);
}
    	
