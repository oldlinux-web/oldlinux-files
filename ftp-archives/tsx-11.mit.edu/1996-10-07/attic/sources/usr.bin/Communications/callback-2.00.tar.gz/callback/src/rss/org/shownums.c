#include "rss.h"

void shownums (int phnumbers)
{
    register int
    	i;
    	
    puts ("Allowed callback names:");
    if (phnumbers)
    {
	for (i = 0; i < nentries; i++)
	{
	    printf ("%20s -- %s\n", entry [i].name, entry [i].number);
	    if (entry [i].filename)
		printf ("%20c    %s\n", ' ', entry [i].filename);
	}
    }
    else
    {
	for (i = 0; i < nentries; i++)
	{
	    if
	    (
		strcmp (entry [i].number, "extra")
		&&
		strcmp (entry [i].number, "direct")
	    )
		printf ("%20s\n", entry [i].name);
	}
    }
}
