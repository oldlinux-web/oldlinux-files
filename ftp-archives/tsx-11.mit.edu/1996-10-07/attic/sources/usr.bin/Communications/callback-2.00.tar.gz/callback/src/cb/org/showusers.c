#include "cbstat.h"

void showusers()
{
    register int
    	i;
    	
    puts("Initial entry keys:");
    for (i = 0; i < nusers; i++)
    	printf("    %s\n", user[i]);
}
