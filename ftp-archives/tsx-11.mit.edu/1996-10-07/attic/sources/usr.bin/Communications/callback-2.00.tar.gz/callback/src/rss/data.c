/***************************************************************************
**			State University of Groningen
**				    ICCE
**
**			       Frank B. Brokken
**
**	Copyright (c) State University of Groningen, ICCE, the Netherlands.
** 
**			This file is part of callback.
**
**
****************************************************************************


Callback was originally developed by Karel Kubat (karel@icce.rug.nl)

Callback version 2.00 was developed by Frank B. Brokken (frank@icce.rug.nl)
who is, as of February 1995, the maintainer of the callback software.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
ICCE OR THE STATE UNIVERSITY OF GRONINGEN BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.

Except as contained in this notice, the name of the ICCE shall not be used in
advertising or otherwise to promote the sale, use or other dealings in this
Software without prior written authorization from the ICCE.

*/
#include "rss.h"

char
    s_callback[]    = "callback",
    s_disable[]	    = "disable",
    s_enable[]	    = "enable",
    s_state[]	    = "state",
    *base_path	    =	"",
    *log_filename =	"/var/adm/callback.log",
    *panic_filename =	"/dev/console",
    *login_program =	"/bin/login",
    *email_address =	NULL,
    *modem_getty    =   "/usr/sbin/modem_getty",
    *getty_path	    =	"/etc/default/getty",
    *tmp_filename   =	"/tmp/callback",
    *expect = qq,
    **gvector,				/* groupname vector */
    out_of_memory[] = "Out of memory",	/* ... */
    *tty_line = NULL,			/* set the default tty-line */
    *filename[sizeof_the_file_enum],	/* vector of names of files to use */
    *progname,				/* points to programname */
    *version,				/* points to the version */
    qq[] = "??";

unsigned
    log_defaults = 0,
    call = 0,				/* by default: don't use the call kwd */
    kill_processes = 1,			/* by default assume killing ok */
    show_phonenumbers = 0,		/* numbers in the destinationlsts*/
    ntries = 3,				/* retries for callback */
    parse_errors = 0,			/* errors while parsing */
    yylineno = 1,			/* linenumber of setup file */
    ndestinations = 0,			/* number of destinations */
    ngroups = 0,			/* number of groups */
    ntargets = 0,			/* number of targets */
    nusers = 0;				/* number of usernames */

CB_MODE_
    cb_mode;

LOG_TYPE_
    log_type = log_default;

USER_
    *user;				/* user-array */

DESTINATION_				/* destination array */
    *destination;

TARGET_					/* target-array */
    *target;
