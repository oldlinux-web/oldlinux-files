#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	USERS	258
#define	LINE	259
#define	IDENTIFIER	260
#define	DESTINATIONS	261
#define	NUMBER	262
#define	DIRECT	263
#define	EXTRA	264
#define	USING	265
#define	SCRATCH	266
#define	PATH	267
#define	GETTYPATH	268
#define	MODEMGETTY	269
#define	LOGIN	270
#define	EMAIL	271
#define	PANICLOG	272
#define	LOGFILE	273
#define	RETRY	274
#define	NOKILLS	275
#define	SHOWNUMS	276
#define	CALL	277
#define	LOG	278
#define	ON	279
#define	DEFAULT	280
#define	OFF	281
#define	MODE	282
#define	CALLBACK	283
#define	DIALIN	284


extern YYSTYPE yylval;
