
#include <stdio.h> 
#include "parser.tab.h"

extern int
    yylineno;

extern char
    *expect,
    *yytext;

extern FILE
    *yyin;
    
int yyparse(void);
