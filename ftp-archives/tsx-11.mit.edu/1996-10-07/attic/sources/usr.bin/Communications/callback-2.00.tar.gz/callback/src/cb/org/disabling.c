#include "cbstat.h"

void disabling()
{
    int
	index;
	
    for (index = 0; index < nlines; index++)
    {
	tty_names(line[index]);		    /* define the line to use */
					    /* and disable */
	copyfile(filename[the_disfile], filename[the_destfile]);
        writestate(0, 0);
    }
}

