#include "rss.h"

static void insert (char *name, char *phone, char *file)	
{
    if (! (entry = realloc (entry, (nentries + 1) * sizeof (PH_ENTRY_))) ||
    	! (entry [nentries].name = strdup (name)) ||
    	! (entry [nentries].number = strdup (phone))
       )
    	error (out_of_memory);

    if (*file)
    {
	if (! (entry [nentries].filename = strdup (file)) )
	    error (out_of_memory);
    }
    else
	entry [nentries].filename = 0;
    	
    nentries++;
}

void readnums ()
{
    register FILE
    	*inf;
    register char
    	*line;
    char
    	name [256],
    	number [256],
	fname [256];
    register int
	res;
    
    if (nentries)				/* if already read: */
    	return;					/* nogo */
    	
    /* try to open phone numbers list */
    if (! (inf = fopen (NAMELIST, "r")) )
    	error ("can't open phone list \"%s\" for reading\n", NAMELIST);
    	
    /* read in all numbers */
    while ( (line = fgetline (inf)) )
    {
	fname [0] = '\0';
	
	if ( (res = sscanf (line, " %s %s %s ", name, number, fname)) < 2 )
	    error ("badly formatted phone list \"%s\"\n", NAMELIST);
	insert (name, number, fname);
    }
    
    if (! nentries)
    	error ("phone list \"%s\" leads to no allowed callback numbers\n",
    		NAMELIST);
    
    fclose (inf);
}
