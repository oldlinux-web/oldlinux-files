#include "rss.h"

void insert (char *name, char *phone)	/* insert name/phone into  list */
{				
    if (! (entry = realloc (entry, (nentries + 1) * sizeof (PH_ENTRY_))) ||
    	! (entry [nentries].name = strdup (name)) ||
    	! (entry [nentries].number = strdup (phone))
       )
    	error (out_of_memory);
    	
    nentries++;
}
