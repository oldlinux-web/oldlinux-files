#include "parser.h"

int
    yylineno = 1;
char
    *expect = "??";

int main(int argc, char **argv)
{
    if (!(yyin = fopen(argv[1], "r")))
	return (puts("Missing file to parse\n"));

    return (yyparse());
}

