#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/time.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>

#ifndef E
#define E extern
#endif

/* global variables */
E struct hostent *hi;
E int sockfd;

/* declarations */
int	sgetline(int fd, char *sbuf, int maxlen);
int sputline(int fd, char *outbuf);
char *number(char *sp, int *intPtr);
void failure();
void get_hostent(char *host);
void connect_to_nntphost(char *host);


/* debugging options. no need to change it */
#ifdef DEBUG1
#define DEBUG
#endif
#ifdef DEBUG2 
#define DEBUG
#endif
#ifdef DEBUG
E FILE *debugfp;
#endif

