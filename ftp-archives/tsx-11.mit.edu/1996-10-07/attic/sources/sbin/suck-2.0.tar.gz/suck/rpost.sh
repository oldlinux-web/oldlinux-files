#!/bin/sh
#change rpost to rpost server.domain if you
#have no NNTPSERVER variable set

for i in $*
do
echo "posting $i"
cat $i | rpost
done
