#define E
#include "both.h"
#include <pwd.h>

#define ORGANIZATION "USU (United Suck Users)"
#define DOMAIN "UNKNOWN"

main(int argc, char **argv)
{
char buf[1024];
struct passwd *pw;
int response,len;


#ifdef DEBUG
debugfp=fopen("rpost.debug","w");
#endif

 connect_to_nntphost( (argc>1) ? argv[1] : getenv("NNTPSERVER") );

#ifdef MAKE_HEADER
 pw = getpwuid(getuid());
 if (pw == NULL)
 {
  perror("Who are you ? Go away ! ");
  failure();
 }
#endif

 /*
  Get the announcement line
 */

 sgetline(sockfd, buf, 1024);
 fprintf(stderr,"%s\n", buf );

/*
 Initiate post mode
*/
  sputline(sockfd, "POST\r\n");
  sgetline(sockfd, buf, 1024);
  fprintf(stderr, "%s\n", buf);

  number(buf, &response);
  if (response!=340)
  {
   fprintf(stderr,"Bad luck. You can't use this server.\n");
   failure();
  }

#ifdef MAKE_HEADER
  strtok(pw->pw_gecos,",");
  sprintf(buf,"From: %s@%s (%s)\r\nOrganization: %s\r\n",
		pw->pw_name,DOMAIN,pw->pw_gecos,ORGANIZATION);
  strcat(buf,"X-Newsreader: suck 2.0\r\n");
  sputline(sockfd,buf);
#endif

  while(fgets(buf, 1022, stdin) != NULL)
  {
   len=strlen(buf);
   strncpy(&buf[len-1],"\r\n",3);
   sputline(sockfd, buf);
  }
  sputline(sockfd, ".\r\n");
  sgetline(sockfd, buf, 1024);
  fprintf(stderr,"%s\n",buf);

  number(buf, &response);
  if (response!=240)
  {
   fprintf(stderr,"Malfunction. Get rid of %s !\n",hi->h_name);
   failure();
  }
   
 fprintf(stderr,"Closing connection to %s\n",hi->h_name);
 sputline( sockfd, "quit\r\n" );
 close(sockfd);
#ifdef DEBUG
fclose(debugfp);
#endif
}
