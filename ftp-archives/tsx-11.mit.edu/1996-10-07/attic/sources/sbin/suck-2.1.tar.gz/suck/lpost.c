#include <stdio.h>

#define RNEWS "/usr/local/lib/news/bin/input/rnews"

extern int errno;

/* get news data from stdin and post it to the local server */

main()
{
FILE *pfp;
char line[1024];
int count = 0;
int len;

 pfp = NULL;
 while ( gets(line) != NULL)
 {
  len=strlen(line);
  if ( line[0] == '.' && len == 1) /* end of article */
  {
	fprintf(stderr,"end of article %d\n",count);
    if ( pfp != NULL )
	{
	 pclose(pfp);
	 pfp = NULL;
	 continue;
	}
  }

  if (pfp == NULL)
  {
   fprintf(stderr,"posting article %d\n", ++count);
   pfp = popen(RNEWS, "w");
   if ( pfp == NULL )
   {
	 perror("Error: cannot open rnews: ");
	 exit(1);
   }
  }
  fputs(line, pfp); putc('\n', pfp);
 } /* end while */
}
