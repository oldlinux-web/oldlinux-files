#ident "%W% %E% Copyright (c) 1993 Gert Doering"
;
/* type definitions, prototypes, defines needed for configuration stuff
 */

typedef struct conf_data {
		   char * key;
		   union { int i; void * p; } d;
		   enum { CT_INT, CT_STRING, CT_CHAT, CT_BOOL,
			  CT_FLOWL, CT_ACTION } type;
		   enum { C_EMPTY, C_PRESET, C_OVERRIDE, C_CONF,
			  C_IGNORE } flags;
		 } conf_data;

int get_config _PROTO(( char * conf_file, conf_data * cd,
		        char * section_key, char * key_value ));

char * fgetline _PROTO(( FILE * fp ));
void   norm_line _PROTO(( char ** line, char ** key ));

#ifndef ERROR
#define ERROR -1
#define NOERROR 0
#endif

