/***
 *** message printing tools
 *** (c) 1995 Koen Gadeyne (kmg@barco.be)
 ***
 ***/

#include <stdio.h>
#include <stdarg.h>
#include "messages.h"

int msgtype;  
  
void print_msg(char *format,...)
{
  char *typstr[4] = { "DEBUG: " , "" , "WARNING: " , "ERROR: " };
  va_list argptr;

  if ((msgtype==MSGTYP_DBG) && (debug_messages==FALSE)) return;
  va_start(argptr,format);
  fprintf(stderr,"%s: %s", CommandName, typstr[msgtype]);
  vfprintf(stderr,format,argptr);
  va_end(argptr);
  fputc('\n',stderr);
}


