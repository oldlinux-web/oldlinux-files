/*
	This is the "C" version of the program
*/
#include <stdio.h>
#include "dos.h"
#include <asm/system.h>
#include "set.h"

extern inline void outportb(char value, unsigned short port);
extern inline unsigned int inportb(unsigned short port);

#ifndef enable
#define enable()	sti()
#endif

#ifndef disable
#define disable()	cli()
#endif

void _Cdecl setdotclock(void _near *ptr,int a_parm)
  { register unsigned char a;
    register unsigned i;
    unsigned long m;

#define S(x)	outportb(0x3D5,(x|a))

    outportb(0x3d4,0x42);    /* Select Programmable Clock Register */
    a=inportb(0x3d5)&0xfc;   /* Get old values */
    if (a_parm!=-1) 
    { printf("Reg.#42 was %d - now %d",a,a_parm);a=a_parm; }
/*    disable();    Removed 5 Feb 93 - RLB*/

    S(2);S(0);S(2);

    for (i=0; i<6; i++) {S(3);S(2);}

    for (i=0; i<2; i++) {S(0);S(1);}
    
    for (i=0, m=1; i<24; i++, m+=m)
      if (*(unsigned long _near *)ptr & m)
	S(1), S(0), S(2), S(3);
      else
	S(3), S(2), S(0), S(1);

    S(3);S(2);S(3);S(2);

/*    enable();   Removed 5 Feb 93 - RLB*/
#undef S

  }

/* End of SetClock.C */
