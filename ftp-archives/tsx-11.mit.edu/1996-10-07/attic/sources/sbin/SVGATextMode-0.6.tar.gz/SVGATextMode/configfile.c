/***
 *** configfile.c: funtions to process config file, and some more general parsing functions
 *** (c) 1995 Koen Gadeyne (kmg@barco.be)
 ***
 ***/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "configfile.h"
#include "messages.h"


void cleanupstring(char *tstring)
{
     char *p=tstring;
     while (*p) 
     {
        switch (*p)
          {
             case '#':              /* discard remarks */
             case '\n': *p = '\0';  /* convert \n terminated strings to \0 terminated ones */
                        break;
             case '\t':             /* TABS to spaces */
             case '"': *p = ' ';    /* convert " (quotes) to spaces */
                       break;
          }
          if (*p == '\0') break;    /* stop processing */
          p++;
     }
}


char* findlabel(FILE* inputfile, char* reqlabel, int options)
{
   /* look for 'reqlabel' in config file, exit if not found */
   static char video_param_str[1024];
   char temp_param_str[1024];
   char inlabel[256];
   int nfound=1;
   int foundone=0;
   int required=(options&LABEL_REQUIRED);
   int fromstart=(options&LABEL_FROMSTART);
   int findlast=(options&LABEL_LAST);
   
   PDEBUG(("findlabel: Looking for %s occurrence of %s label '%s' from %s Configfile",
            (findlast) ? "last" : "first",
            (required) ? "required" : "optional",
            reqlabel,
            (fromstart) ? "beginning of" : "current position in"));
   if (fromstart) rewind(inputfile);
   do
   {
     nfound = 1;
     while ( (fgets(temp_param_str,1024,inputfile) != NULL) && (!feof(inputfile)) )   /* look for requested line */
     {
        strcpy(inlabel,""); /* avoid empty lines from leaving previous result in inlabel */
        cleanupstring(temp_param_str);
        sscanf(temp_param_str, "%s",inlabel);
        nfound = strcasecmp(inlabel,reqlabel);
        if (!nfound) break;
     }
     if (!nfound)
     {
       PDEBUG(("findlabel: found the following '%s' line:\n --> %s", reqlabel, temp_param_str))
       foundone=1;  /* remember if we already found a line (for "LAST" function) */
       strcpy(video_param_str, temp_param_str);
     }
   } while (findlast && !nfound);
   
   if (nfound && !foundone)
   {
     if (required) PERROR(("Could not find required '%s' line in config file '%s'. Aborting...",reqlabel,CONFIGFILE));
     PDEBUG(("findlabel: no (more) optional '%s' line found", reqlabel));
     return(NULL);
   }
   else return(video_param_str);
}


FILE* open_param_file(char* conf_file)
{
  FILE* param_file;
  PDEBUG(("Opening config file '%s'",conf_file));
  if ((param_file = fopen(conf_file,"r")) == NULL)
  {
      perror("fopen");
      PERROR(("Could not open Text mode config file '%s'",conf_file));
  }
  return(param_file);
}


char* showopts(const char* optstrings[], int num_optstrings)
{
  int i;
  static char optionstring[256];
  for (i=0; i<num_optstrings; i++)
  {
     strcat(optionstring, optstrings[i]);
     strcat(optionstring, (i==num_optstrings-1) ? "." : ", ");
  }
  return optionstring;
}


int findoption(char* inputstr, const char* optstrings[], int num_optstrings, char* optiontype)
{
  /* look which option string from given list matches input string, return option number, or exit when not found */
  int i, foundindex=-1;
  PDEBUG(("findoption: Looking for one out of %d %s string(s) in '%s'",num_optstrings, optiontype, inputstr));
  for (i=0; i<num_optstrings; i++) { if (!strcasecmp(inputstr,optstrings[i])) foundindex=i; };
  if ((foundindex < 0) || (foundindex > num_optstrings))
    PERROR(("Unknown %s definition '%s'.
     Valid %s definitions are: %s ",optiontype, inputstr, optiontype, showopts(optstrings, num_optstrings)));
  PDEBUG(("findoption: Selecting %s #%d = %s", optiontype, foundindex, optstrings[foundindex]));
  return(foundindex);
}


void check_int_range(int cvalue, int lmin, int lmax, char* descstr)
{
  if (cvalue<lmin || cvalue>lmax)
    PERROR(("%s = %d (0x%x) out of range [%d..%d]!", descstr, cvalue, cvalue, lmin, lmax));
}

int getbyte(char* instring, char* descrstring, int lmin, int lmax)
  /* convert the byte in 'instring' into an integer. Must be within specified limits 'lmin' and 'lmax' */
  /* 'descrstring' contains a description of the number to be parsed, used in error message */
{
  char** errstr=NULL;
  int readbyte;
  readbyte = strtol(instring,errstr,0);
  if (errstr != NULL) PERROR(("Illegal character '%c' in %s: '%s'", *errstr, descrstring, instring));
  check_int_range(readbyte, lmin, lmax, descrstring);
  return(readbyte);
}

float getfloat(char* instring, char* descrstring, int lmin, int lmax)
  /* convert the float in 'instring' into a float. Must be within specified INTEGER limits 'lmin' and 'lmax' */
  /* 'descrstring' contains a description of the number to be parsed, used in error message */
{
  char** errstr=NULL;
  double readfloat;
  readfloat = strtod(instring,errstr);
  if (errstr != NULL) PERROR(("Illegal character '%c' in %s: '%s'", *errstr, descrstring, instring));
  check_int_range(readfloat, lmin, lmax, descrstring);
  return((float)readfloat);
}


int GetPathOption(FILE *param_file, char *optionstring, int label_config, char *path)
/* look for certain path-related options in config file */
{ 
  char *arg_str;

  if (strtok(findlabel(param_file, optionstring, label_config)," ") != NULL)
  {
    if ((arg_str=strtok(NULL," ")) == NULL) PERROR(("%s: pathname not defined", optionstring));
    strcpy(path, arg_str);
    PDEBUG(("Using %s '%s'",optionstring , path));
    return(TRUE);
  } 
  return(FALSE);   /* no path option found */
}

void ParseFontXY(char *inputstr, int *x, int*y)
{
  if (sscanf(inputstr, "%dx%d", x, y) < 2)
    PERROR(("Illegal font size specification '%s'", inputstr));
  check_int_range(*x, 8, 9, "font width");
  check_int_range(*y, 1, 32, "font height");
}

void Run_extern_Prog(char *description, char *commandstring, char *arguments)
{
  int result=0;
  char commandline[1024];
  
  strcpy(commandline, commandstring);
  strcat(commandline, " ");
  strcat(commandline, arguments);
  
  PDEBUG(("%s: Executing external command '%s'", description, commandline));
  result=system(commandline);
  if (result !=0)
  {
    perror(commandstring);
    PERROR(("'%s' failed with error code %d", commandline, result));
  }
}

void check_bounds_realtime(FILE *param_file, char *descrline, float checkval, float defaultmin, float defaultmax, char *textdescr)
/* checks given boundaries with the restrictions in config file in real-time (reading config file on the fly) */
#define FRMARGIN 0.3           /* margin for single frequency definition */
{
  float start, end;
  int num;
  char *arg_str;
  int range_ok=FALSE;
  
  if (strtok(findlabel(param_file, descrline, LABEL_OPTIONAL+LABEL_FROMSTART)," ") != NULL)
  {
    if ((arg_str=strtok(NULL,",")) == NULL)
      PERROR(("'%s' line in config file: empty line.", descrline))
    do
    {
      PDEBUG(("bounds: %s", arg_str));
      if ((num = sscanf(arg_str, "%f-%f", &start, &end)) < 1) 
        PERROR(("%s: Must define <start>-<end> pairs or single values separated by comma's", descrline));
      if (num==1)
      {
        end = start+FRMARGIN;
        start -= FRMARGIN;
      }
    PDEBUG(("bounds: start=%f, end=%f", start, end));
    if (checkval>=start && checkval<=end) range_ok=TRUE;
    }
    while (((arg_str=strtok(NULL,",")) != NULL) && (range_ok==FALSE));
  }
  else
    if (checkval>=defaultmin && checkval<=defaultmax) range_ok=TRUE;
  if (range_ok==FALSE) PERROR(("%s in text mode out of range(s) specified in '%s' line", textdescr, descrline));
}
