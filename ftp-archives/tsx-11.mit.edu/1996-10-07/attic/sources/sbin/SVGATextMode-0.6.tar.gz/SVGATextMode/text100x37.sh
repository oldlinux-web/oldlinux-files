#!/bin/bash
#
# This (minimalistic) script changes the VGA textmode.
# This example is for a 100x37 character mode.
#
# Before installing it, check if your monitor can handle this!
#
# If you put this in your /etc/rc.d/rc.font file, it will be started 
# automatically when Linux boots.
#
echo "Changing to 100x37 character console"
SVGATextMode 100x37_VGA
