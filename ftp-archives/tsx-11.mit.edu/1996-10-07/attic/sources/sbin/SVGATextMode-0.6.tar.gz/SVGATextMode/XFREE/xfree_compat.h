/***
 *** xfree_compat.h: misc. stuff to get the XFREE code to compile. This is junk :-(
 *** Written by Koen Gadeyne (kmg@barco.be)
 ***
 ***/
 
#ifndef TRUE
#define TRUE (1)
#endif
#ifndef FALSE
#define FALSE (-1)
#endif
 

/*  gives compiler error ... 
#ifndef _COMPAT_H
#define _COMPAT_H
*/
 
#define NeedFunctionPrototypes 1

#include <stdio.h>
#define ErrorF printf


void GlennsIODelay();

typedef void *ScrnInfoRec;  /* dummy, not used by SVGATextMode */


int xf86DisableInterrupts();

void xf86EnableInterrupts();

void s3OutTiIndReg(unsigned char reg, unsigned char mask, unsigned char data);


/*
#endif
*/
