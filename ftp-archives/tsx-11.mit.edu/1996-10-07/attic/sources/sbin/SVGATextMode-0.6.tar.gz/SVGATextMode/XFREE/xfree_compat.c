/***
 *** xfree_compat: misc. stuff to get the XFREE code to compile. This is junk :-(
 *** Written by Koen Gadeyne (kmg@barco.be)
 ***
 ***/
 


#include <asm/io.h>
#include "xfree_compat.h"



/***************************************************************************/

/* next block is taken from xfree86/os-support/linux/lnx_video.c it was to
 * idiot to include the entire os-supportlinux dir here, since these
 * functions were so simple... [kmg] changing "Bool" to "int" for
 * xf86DisableInterrupts() is a bad hack, but the only way I could think of
 * getting the damn thing through the compiler WITHOUT changing any XFREE
 * code
 */

int xf86DisableInterrupts()
{
        return(TRUE);
}

void xf86EnableInterrupts()
{
        return;
}



/***************************************************************************/

/* next block is from xfree/accel/s3/s3TiCursor.c. It was cut out and placed
 * here because it looked like a big effort to get that .c file to compile under
 * SVGATextMode, and I needed only this one function...
 * some stuff from s3.c (from same dir) was added.
 */

/* #include "accel/s3/s3Ti3020.h" */ /* next two lines replace the prev. include ...*/
#define TI_INDEX_REG         0x3C6   /* CR55 low bit == 1 */
#define TI_DATA_REG          0x3C7   /* CR55 low bit == 1 */

/*
 * s3OutTiIndReg() and s3InTiIndReg() are used to access the indirect
 * 3020 registers only.
 */

#ifdef __STDC__
void s3OutTiIndReg(unsigned char reg, unsigned char mask, unsigned char data)
#else
void s3OutTiIndReg(reg, mask, data)
unsigned char reg;
unsigned char mask;
unsigned char data;
#endif
{
   unsigned char tmp, tmp1, tmp2 = 0x00;
   /* added by kmg */
   int vgaCRIndex, vgaCRReg;
   extern int vgaIOBase;
   
   vgaCRIndex = vgaIOBase + 4;
   vgaCRReg = vgaIOBase + 5;
   /* end kmg */

   /* High 2 bits of reg in CR55 bits 0-1 (1 is cleared for the TI ramdac) */
   outb(vgaCRIndex, 0x55);
   tmp = inb(vgaCRReg) & 0xFC;
   outb(vgaCRReg, tmp | 0x01);  /* toggle to upper 4 direct registers */
   tmp1 = inb(TI_INDEX_REG);
   outb(TI_INDEX_REG, reg);

   /* Have to map the low two bits to the correct DAC register */
   if (mask != 0x00)
      tmp2 = inb(TI_DATA_REG) & mask;
   outb(TI_DATA_REG, tmp2 | data);
   
   /* Now clear 2 high-order bits so that other things work */
   outb(TI_INDEX_REG, tmp1);  /* just in case anyone relies on this */
   outb(vgaCRReg, tmp);
}
