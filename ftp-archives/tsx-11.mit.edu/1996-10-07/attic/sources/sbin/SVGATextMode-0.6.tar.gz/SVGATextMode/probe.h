/***
 *** probe.h
 *** Copyright (c) 1995 by Koen Gadeyne (kmg@barco.be)
 ***
 *** All kinds of probing fuctions (currently just the clock probe)
 ***
 ***
 ***/
 
float pixclock(int hsize, int vsize);

