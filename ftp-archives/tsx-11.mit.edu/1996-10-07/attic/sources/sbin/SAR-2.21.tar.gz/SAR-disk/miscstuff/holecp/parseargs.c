#include "holecp.h"

/* parse argc/argv */

void parseargs (int *ac, char ***av)
{
    int
	i;
    
    while (*ac > 1 && *(*av) [1] == '-')
    {
	for (i = 1; i < strlen ( (*av) [1]); i++)
	    switch ((*av) [1][i])
	    {
		case 'v':
		    flags.verbose = 1;
		    break;
		case 'p':
		    flags.dontoverwrite = 1;
		    break;
		default:
		    error ("no such flag -%c", (*av)[1][i]);
	    }

	(*ac)--;
	(*av)++;
    }
}
