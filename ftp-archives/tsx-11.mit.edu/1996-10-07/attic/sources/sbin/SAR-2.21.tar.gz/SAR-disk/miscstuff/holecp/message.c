#include "holecp.h"

/* print error msg but don't die */

int message (char const *fmt, ...)
{
    va_list
	args;
    
    fprintf (stderr, "%s: ", progname);
    va_start (args, fmt);
    vfprintf (stderr, fmt, args);
    fputc ('\n', stderr);

    return (1);
}
