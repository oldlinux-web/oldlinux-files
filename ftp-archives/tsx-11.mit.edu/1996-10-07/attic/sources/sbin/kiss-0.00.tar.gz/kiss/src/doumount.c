#include "kiss.h"

int doumount (Stringstack s)
{
    if (s.nstr != 2 || getopt (s.nstr, s.str, "h") != -1)
	error ("Bad commandline.\n"
	       "Usage: %s device-or-directory\n"
	       , progname);

    if (umount (s.str [1]))
	error ("problem unmounting \"%s\"", s.str [1]);

    return (0);
}
