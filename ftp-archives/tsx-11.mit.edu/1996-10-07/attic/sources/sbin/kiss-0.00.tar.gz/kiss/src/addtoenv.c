#include "kiss.h"

void addtoenv (char *var, char *setting)
{
    char
	buf [FILENAMELEN];

    strcpy (buf, var);
    strcat (buf, "=");
    if (setting)
	strcat (buf, setting);

    putenv (xstrdup (buf));
}
