
#ifndef __gameSound__
#define __gameSound__

#include <sys/fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#ifdef TEST_SOUND
#include <sys/soundcard.h>
#endif

class Sound {
    public:
	static int init();
	static void restore();

	static int playwave( int samplerate, int bitspersample, 
                      int stereo, long size, void *data );

	static void play_file(char *file);

    private:
       static int dsp_fd;
       
   };

#endif
