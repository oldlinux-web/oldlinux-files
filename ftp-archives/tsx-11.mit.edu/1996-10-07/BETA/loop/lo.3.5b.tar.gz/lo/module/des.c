/*
 * The DES encryption module is distributed separately.
 *
 * From inside the US, you can get it from
 *   tsx-11.mit.edu:/pub/linux/BETA/loop/des.1.tar.gz
 * From outside the US, please get it from
 *   nic.funet.fi:/pub/OS/Linux/BETA/loop/des.1.tar.gz
 */
