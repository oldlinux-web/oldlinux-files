#ifndef _LINUX_DES_H
#define _LINUX_DES_H

/* Copyright (C) 1992 Eric Young - see COPYING for more details */
/* Collected and modified by Werner Almesberger */

#define DES_AVAILABLE

/* from des.h */

typedef unsigned char des_cblock[8];
typedef struct des_ks_struct
	{
	union	{
		des_cblock _;
		/* make sure things are correct size on machines with
		 * 8 byte longs */
		unsigned long pad[2];
		} ks;
/* #define _	ks._ */
	} des_key_schedule[16];

#define DES_ENCRYPT	1
#define DES_DECRYPT	0

int des_ecb_encrypt(des_cblock *input,des_cblock *output,des_key_schedule ks,
    int encrypt);
void des_set_key(des_cblock *key,des_key_schedule schedule);

#endif
