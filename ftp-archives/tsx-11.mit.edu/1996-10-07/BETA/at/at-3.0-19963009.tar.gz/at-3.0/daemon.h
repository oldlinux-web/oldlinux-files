void daemon_setup(void);
void daemon_cleanup(void);

void
#ifdef __GNUC__
__attribute__((noreturn))
#endif
pabort (const char *fmt, ...);

void
#ifdef __GNUC__
__attribute__((noreturn))
#endif
perr (const char *fmt, ...);

extern int daemon_debug;
