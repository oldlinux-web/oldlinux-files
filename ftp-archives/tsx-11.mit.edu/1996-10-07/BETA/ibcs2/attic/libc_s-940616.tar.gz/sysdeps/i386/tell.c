#include <unistd.h>

#ifdef ELF_LIBRARY
#define tell _tell
#define lseek _lseek
#endif

off_t tell (int fildes)
    {
    return lseek (fildes, 0, SEEK_CUR);
    }

#ifdef ELF_LIBRARY
__asm__(".weak tell; tell = _tell");
#endif
