unsigned short __fpu_control = 0;
