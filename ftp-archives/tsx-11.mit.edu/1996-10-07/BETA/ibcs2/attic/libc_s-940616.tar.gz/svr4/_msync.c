#include <sys/types.h>
#include <sys/mman.h>

int _msync(caddr_t addr, size_t len, int flags)
{
  return _memcntl(addr, len, MC_SYNC, flags, 0, 0);
}

#ifdef ELF_LIBRARY
__asm__(".weak msync; msync = _msync");
#endif
