#include <ctype.h>
#undef _old_tolower
int _old_tolower(int c) { return ___old_tolower(c); }
