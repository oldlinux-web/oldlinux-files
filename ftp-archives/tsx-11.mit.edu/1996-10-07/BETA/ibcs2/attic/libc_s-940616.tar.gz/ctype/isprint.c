#include <ctype.h>
#undef isprint
int isprint(int c) { return __isprint(c); }
