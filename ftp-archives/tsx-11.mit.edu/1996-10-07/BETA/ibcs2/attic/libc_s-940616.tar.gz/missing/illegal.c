/*
 *  This function should never be called. If it is then it indicates
 *  that the libc_s is not correct. It should only be used if there
 *  is a missing routine.
 */

typedef long	off_t;
typedef unsigned int size_t;

#ifndef FUNC_NAME
#define FUNC_NAME "libc_s"
#endif

static char __szIllegal[]  ="\nundefined " FUNC_NAME " function called\n";

void volatile routine (void);
void volatile routine (void)
    {
#undef write
#undef ultoa
#undef strlen
extern int write (int fildes, const char* buf, off_t count);
extern size_t strlen (const char *);

    write (2, __szIllegal, strlen (__szIllegal));
    _exit (1);
    }
