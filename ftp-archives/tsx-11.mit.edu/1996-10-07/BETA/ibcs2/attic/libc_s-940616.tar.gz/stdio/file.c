#include <stdio.h>
#include "file2.h"

/*
 * buffers for stdin, stdout, and stderr
 */

#ifndef COFF_LIBRARY
unsigned char    _bufin  [BUFSIZ];
unsigned char    _bufout [BUFSIZ];
#endif
unsigned char    _buferr [BUFSIZ];

/*
 *  Current index number for the temporary file name
 */

unsigned int _tempIndex = 0;

/*
 *   Number of buffers which are pending a flush operation
 */

unsigned int _cflush = 0;

/*
 *    FILE descriptors; preset for stdin/out/err
 */

#ifndef COFF_LIBRARY
#ifdef _STDIO_REVERSE
FILE _iob[ _NFILE ] = {
    /*	ptr,		cnt,	base,		flag,		file */
    {
	_bufin,		0,	_bufin,		_IOREAD,	0 }
    ,
    {
	_bufout,	0,	_bufout,	_IOWRT,		1 }
    ,
    {
	NULL,		0,	NULL,		_IOWRT,		2 }
    ,
};
#else
FILE _iob[ _NFILE ] = {
    /*	cnt,	ptr,	    	base,		flag,		file */
    {
	0,	_bufin,		_bufin,		_IOREAD,	0 }
    ,
    {
	0,	_bufout,	_bufout,	_IOWRT,		1 }
    ,
    {
	0,	NULL,		NULL,		_IOWRT,		2 }
    ,
};
#endif
#endif

#ifdef ELF_LIBRARY
/* I think the COFF libraries may need this as well.  I do not know how they
   get by without it, as a matter of fact */
unsigned char * _bufendtab[_NFILE] = { 
  &_bufin[BUFSIZ-1], &_bufout[BUFSIZ-1],};

__asm__(".weak _iob;_iob = __iob");
#endif

/*
 *    FILE2 descriptors; preset for stdin/out/err
 */

FILE2 _iob2[ _NFILE ] = {
    /*	flag2,		charbuf,	Buffer size */
#ifndef COFF_LIBRARY
    {
	_IOYOURBUF,	'\0',		0 }
    ,
    {
	_IOYOURBUF,	'\0',		0 }
    ,
    {
	0,		'\0',		0 }
    ,
#endif
};

/* pointer to end of descriptors */
#ifndef COFF_LIBRARY
FILE * _lastiob = &_iob[ _NFILE -1];
#endif
