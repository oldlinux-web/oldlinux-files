#define FILE2  struct _iobuf2

extern FILE2 {
    char  _flag2;
    char  _charbuf;
    char  _ttyflag;
    } _iob2[];

#define _IOYOURBUF 0x01
#define _IOUNGETC  0x04
#define _IOFEOF    0x08
#define _IOISTTY   0x01
#define _IONOTTY   0x02

#define inuse(fp)        ((fp)->_flag & (_IOREAD|_IOWRT|_IORW))
#define mbuf(fp)         ((fp)->_flag & _IOMYBUF)
#define nbuf(fp)         ((fp)->_flag & _IONBF)

#define DUMMY_FILE2      (_NFILE+1)

#if 0
#define _iob_index(fp)   (fp - (FILE *)_iob)
#else
#define _iob_index(fp)   ((fp)->_file)
#endif
#define file2p(fp)       (&_iob2[_iob_index(fp)])

#define ybuf(fp)         (file2p(fp)->_flag2 & _IOYOURBUF)
#define bigbuf(fp)       (mbuf(fp) || ybuf(fp))
#if 0
#define anybuf(fp)       ((fp)->_flag & (_IOMYBUF|_IONBF) || ybuf(fp))
#else
#define anybuf(fp)       ((fp)->_ptr != (void *) 0)
#endif

#ifdef COFF_LIBRARY
extern unsigned char **	_libc__bufendtab;
#define buf_size(fp)	(_libc__bufendtab[(fp)->_file] - (fp)->_base)
#define set_buf_size(fp, size)	(_libc__bufendtab[(fp)->_file] = ((fp)->_base + size))
#else
extern unsigned char *	_bufendtab[];
#define buf_size(fp)	(_bufendtab[(fp)->_file] - (fp)->_base)
#define set_buf_size(fp, size)	(_bufendtab[(fp)->_file] = ((fp)->_base + size))
#endif
