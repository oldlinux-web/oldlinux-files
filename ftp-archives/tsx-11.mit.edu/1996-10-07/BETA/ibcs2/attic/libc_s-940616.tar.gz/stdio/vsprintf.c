#include <stdio.h>
#include <stdarg.h>
#include "file2.h"
#include "internal.h"
#include <trace.h>

/***************************************************************************
 *
 * Function:    vsprintf
 *
 * Description:
 *     Formatted print data to the string using variable arguments.
 *
 * Input:
 *     stream   - pointer to the output string
 *     format   - pointer to the format string
 *     ap       - variable arg list pointer
 *
 * Result:
 *     The number of characters written to the output.
 */

int vsprintf (char *pszString, const char *pszFormat, va_list ap)
    {
    FILE    fdString;
    int     nAnswer;
    FUNC_ENTRY ("vsprintf");
/*
 *  Construct the output string file
 */
    fdString._flag = _IOWRT | _IOSTRG;
    fdString._ptr  =
    fdString._base = pszString;
    fdString._cnt  = 32767;       /* This should be enough for most output */
    fdString._file = _NFILE;
/*
 *  Output the stream
 */
    nAnswer = _doprnt (pszFormat, ap, &fdString);
    putc ('\0', &fdString);
/*
 *  Return the answer to the caller.
 */
    FUNC_EXIT ("vsprintf");
    return(nAnswer);
    }
