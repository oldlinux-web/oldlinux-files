/*
 *  linux/ibcs/svr4.c
 *
 *  Copyright (C) 1994 Eric Youngdale.
 *
 *  Misc support functions for SVr4.
 */

#include <linux/utsname.h>
#include <linux/mm.h>
#include <ibcs/ibcs.h>
#include <asm/segment.h>

/* Large enough for internet host names */

extern struct new_utsname system_utsname;

#define COPY_UNAMEF(FIELD) \
  memcpy_tofs(name->FIELD, system_utsname.FIELD,  \
	       sizeof(system_utsname.FIELD))

int abi_uname(struct svr4_utsname * name)
{
  int error;
  error = verify_area(VERIFY_WRITE, name, sizeof (*name));
  if (error)
    return error;

  COPY_UNAMEF(sysname);
  COPY_UNAMEF(nodename);
  COPY_UNAMEF(release);
  COPY_UNAMEF(version);
  COPY_UNAMEF(machine);
  return 0;
}
