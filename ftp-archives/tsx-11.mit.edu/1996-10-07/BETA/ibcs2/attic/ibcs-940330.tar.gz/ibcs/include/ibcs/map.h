/*
 *  linux/ibcs/map.h
 *
 *  Copyright (C) 1994  Mike Jagdis (jaggy@purplet.demon.co.uk)
 *
 * $Id: map.h,v 1.2 1994/03/28 08:29:59 mike Exp $
 * $Source: /var/CVS/ibcs/include/ibcs/map.h,v $
 */

struct map_segment {
	int start, end;
	unsigned char *map;
};


extern struct map_segment *af_map[];
extern struct map_segment *type_map[];
extern struct map_segment *sopt_map[];

extern int map_value(struct map_segment *m[], int val, int def);
