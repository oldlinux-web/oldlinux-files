/*
 * ibcs trace -- mask of trace values
 *
 * $Id: trace.h,v 1.2 1994/03/04 15:09:11 mike Exp $
 * $Source: /var/CVS/ibcs/include/ibcs/trace.h,v $
 */
#define	TRACE_API	0x00000001 /* all call/return values */
#define	TRACE_IOCTL	0x00000002 /* all ioctl calls */
#define	TRACE_IOCTL_F	0x00000004 /* ioctl calls that fail */
#define TRACE_SIGNAL	0x00000008 /* all signal calls */
#define TRACE_SIGNAL_F	0x00000010 /* signal calls that fail */
#define TRACE_SOCKSYS	0x00000020 /* socksys and spx devices */
#define	TRACE_FUNC	0x10000000 /* trace this function */

extern int ibcs_trace;
extern IBCS_func *ibcs_func_p;
