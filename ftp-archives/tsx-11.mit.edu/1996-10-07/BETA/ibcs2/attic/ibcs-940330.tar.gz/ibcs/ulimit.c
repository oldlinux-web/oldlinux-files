/*
 *  linux/ibcs/ulimit.c
 *
 *  Copyright (C) 1993  Joe Portman (baron@hebron.connected.com)
 *	 First stab at ulimit
 *
 * $Id: ulimit.c,v 1.1.1.2 1994/02/23 17:22:48 mike Exp $
 * $Source: /var/CVS/ibcs/ulimit.c,v $
 */
#include <linux/errno.h>
#include <linux/sched.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/stddef.h>
#include <linux/unistd.h>
#include <linux/segment.h>
#include <linux/ptrace.h>
#include <linux/config.h>

#include <asm/segment.h>
#include <asm/system.h>
#include <linux/fs.h>
#include <linux/sys.h>
#include <linux/resource.h>

#include <ibcs/ibcs.h>
#include <ibcs/trace.h>

#define U_GETFSIZE 	(1)		  /* get max file size in blocks */
#define U_SETFSIZE 	(2)		  /* set max file size in blocks */
#define U_GETMEMLIM	(3)		  /* get process size limit */
#define U_GETMAXOPEN	(4)		  /* get max open files for this process */
#define U_GTXTOFF		(64)		  /* get text offset */

int
ibcs_ulimit (int cmd, int val)
{
	switch (cmd) {
		case U_GETFSIZE:
			return current->rlim[RLIMIT_FSIZE].rlim_cur;

		case U_SETFSIZE:
		  	if (!suser ())
				return -EPERM;
			if (val > current->rlim[RLIMIT_FSIZE].rlim_max)
				return -ERANGE;
			current->rlim[RLIMIT_FSIZE].rlim_cur = val / 2;
			return 0;

		case U_GETMEMLIM:
			return current->rlim[RLIMIT_DATA].rlim_cur;

		case U_GETMAXOPEN:
			return NR_OPEN;

		default:
#ifdef IBCS_TRACE
			if ((ibcs_trace & TRACE_API) || ibcs_func_p->trace) {
				printk(KERN_DEBUG "iBCS2: unsupported ulimit call %d\n", cmd);
			}
#endif
			return -EINVAL;
	 }
}
