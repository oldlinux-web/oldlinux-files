#include <unistd.h>
#include <errno.h>
#include <dirent.h>
#undef lseek


off_t _telldir(DIR * dir)
{
  if (!dir) {
    errno = EBADF;
    return -1;
  }
  return _lseek(dir->dd_fd,0,SEEK_CUR);
}

#ifdef ELF_LIBRARY
__asm__(".weak telldir; telldir = _telldir");
#endif
