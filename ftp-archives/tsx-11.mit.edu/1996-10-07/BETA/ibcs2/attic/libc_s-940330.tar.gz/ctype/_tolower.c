#include <ctype.h>
#undef _tolower
int _tolower(int c) { return ___tolower(c); }

int tolower(int c) { return (islower(c) ? c : ___tolower(c)); }

