#include <ansidecl.h>
#include <unistd.h>
#include <errno.h>
#include <stdarg.h>
#include <stddef.h>

#ifdef ELF_LIBRARY
#define __environ _environ
extern char ** _environ;
#else
#ifndef	HAVE_GNU_LD
#define	__environ	_libc_environ
extern char ** _libc_environ;
#else
#endif
#endif

#ifdef ELF_LIBRARY
#define execv _execv
#define execve _execve
#endif

/* Execute PATH with all arguments after PATH until
   a NULL pointer and environment from `environ'.  */
int execv (const char * path, char * const argv[])
{
  return execve(path, (char *CONST *) argv, __environ);
}

#ifdef ELF_LIBRARY
__asm__(".weak execv; execv = _execv");
#endif
