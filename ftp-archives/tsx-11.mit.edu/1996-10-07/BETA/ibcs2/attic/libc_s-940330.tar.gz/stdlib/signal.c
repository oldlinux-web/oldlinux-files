#include <signal.h>

typedef (*sigfunc) (void);

void sigset (int sig, sigfunc func)
{
  
}

int sighold (int sig)
{
}

int sigrelse (int sig)
{
}

int sigignore (int sig)
{
}

int sigpause (int sig)
{
}

void signal (int sig, sigfunc func)
{
}

