#include <stdio.h>
#include "file2.h"

/*
 * buffers for stdin, stdout, and stderr
 */

#ifndef COFF_LIBRARY
unsigned char    _bufin  [BUFSIZ];
unsigned char    _bufout [BUFSIZ];
unsigned char    _buferr [BUFSIZ];
#endif

/*
 *  Current index number for the temporary file name
 */

unsigned int _tempIndex = 0;

/*
 *   Number of buffers which are pending a flush operation
 */

unsigned int _cflush = 0;

/*
 *    FILE descriptors; preset for stdin/out/err
 */

#ifndef COFF_LIBRARY
#ifdef _STDIO_REVERSE
FILE _iob[ _NFILE ] = {
    /*	ptr,		cnt,	base,		flag,		file */
    {
	_bufin,		0,	_bufin,		_IOREAD,	0 }
    ,
    {
	_bufout,	0,	_bufout,	_IOWRT,		1 }
    ,
    {
	NULL,		0,	NULL,		_IOWRT,		2 }
    ,
};
#else
FILE _iob[ _NFILE ] = {
    /*	cnt,	ptr,	    	base,		flag,		file */
    {
	0,	_bufin,		_bufin,		_IOREAD,	0 }
    ,
    {
	0,	_bufout,	_bufout,	_IOWRT,		1 }
    ,
    {
	0,	NULL,		NULL,		_IOWRT,		2 }
    ,
};
#endif
#endif

#ifdef ELF_LIBRARY
__asm__(".weak _iob;_iob = __iob");
#endif

/*
 *    FILE2 descriptors; preset for stdin/out/err
 */

FILE2 _iob2[ _NFILE ] = {
    /*	flag2,		charbuf,	Buffer size */
    {
	_IOYOURBUF,	'\0',		0,	BUFSIZ	}
    ,
    {
	_IOYOURBUF,	'\0',		0,	BUFSIZ	}
    ,
    {
	0,		'\0',		0,	0	}
    ,
};

/* pointer to end of descriptors */
#ifndef COFF_LIBRARY
FILE * _lastiob = &_iob[ _NFILE -1];
#endif
