#include <stdio.h>
#include <trace.h>
#undef fgetchar

/***************************************************************************
 *
 * Function:       fgetchar
 *
 * Description:    Read the next character from the stdin file
 *
 * Entry:           none.
 *
 * Returns:
 *      The input character or EOF to indicate an error/EOF condition.
 */

int fgetchar (void)
    {
    int answer;
    FUNC_ENTRY ("fgetchar");
    answer = getchar();
    FUNC_EXIT ("fgetchar");
    return (answer);
    }
