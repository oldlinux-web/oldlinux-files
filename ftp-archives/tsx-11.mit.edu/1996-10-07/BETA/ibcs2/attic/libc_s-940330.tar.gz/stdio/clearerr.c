#include <stdio.h>
#include <trace.h>
/**************************************************************************
 *
 * Function:   _cerror
 *
 * Description:
 *    Reset the ERR and EOF conditions on the file
 *
 * Input:
 *    stream    - Pointer to the file to be reset
 *
 * Result:
 *    none.
 */

#undef	_cerror
void _cerror (FILE *stream)
    {
    FUNC_ENTRY ("_cerror");
    __scerror (stream);
    FUNC_EXIT ("_cerror");
    }
