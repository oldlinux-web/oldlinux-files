#include <stdio.h>
#include <trace.h>

/**************************************************************************
 *
 * Function:     fgetpos
 *
 * Description:  Return the position of the indicated stream
 *
 * Input:
 *    stream    - Pointer to the stream to be measured
 *    pos       - file position
 *
 * Ouptut;
 *    0 to indicate sucess
 *  EOF to indicate an error condition
 */

int  fgetpos (FILE *stream, fpos_t *pos)
    {
    FUNC_ENTRY ("fgetpos");
    *pos = ftell (stream);
    FUNC_EXIT ("fgetpos");
    return (*pos == -1 ? -1 : 0);
    }
