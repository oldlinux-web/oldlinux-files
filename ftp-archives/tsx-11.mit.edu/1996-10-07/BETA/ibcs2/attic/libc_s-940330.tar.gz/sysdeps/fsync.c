/* well, better than nothing */

#include <unistd.h>

#ifdef ELF_LIBRARY
#define fsync _fsync
#define sync _sync
#endif

int fsync(int fd)
{
	return sync();
}

#ifdef ELF_LIBRARY
__asm__(".weak fsync; fsync = _fsync");
#endif
