
int optind = 1;
int optopt;
int opterr;

char * optarg;

char ** _environ;

unsigned long _tempoff;

extern unsigned short int __fpu_control;

int __fpstart()
{
  __setfpucw(__fpu_control);
  return 0;
}
