#ifndef _EMU_LCALL7_H_
#define _EMU_LCALL7_H_

extern int lcall7(int opcode, ...);

#endif /* _EMU_LCALL7_H_ */
