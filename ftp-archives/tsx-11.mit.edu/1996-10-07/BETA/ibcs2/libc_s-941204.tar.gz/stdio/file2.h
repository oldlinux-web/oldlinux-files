#define _IOISTTY   0x01
#define _IONOTTY   0x02

#define inuse(fp)        ((fp)->_flag & (_IOREAD|_IOWRT|_IORW))
#define mbuf(fp)         ((fp)->_flag & _IOFREEBF)
#define nbuf(fp)         ((fp)->_flag & _IONBF)
#define anybuf(fp)       ((fp)->_ptr != (void *) 0)

/* Test for string file(s) */
#define STRING_FILE      (_NFILE+1)
#define stringf(fp)	 ((fp)->_file == STRING_FILE)

/* Set/obtain ending pointer to buffer */
#ifdef COFF_LIBRARY
extern unsigned char ** _libc__bufendtab;
#define _bufendtab _libc__bufendtab
#else
extern unsigned char *	_bufendtab[];
#endif

#define buf_size(fp)	(_bufendtab[(fp)->_file] - (fp)->_base)
#define set_buf_size(fp, size)	(_bufendtab[(fp)->_file] = ((fp)->_base + size))
