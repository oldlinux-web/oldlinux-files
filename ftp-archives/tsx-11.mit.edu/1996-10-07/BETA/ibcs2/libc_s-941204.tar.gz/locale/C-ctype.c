#include <ansidecl.h>
#include <localeinfo.h>
#include <stddef.h>


extern CONST unsigned char __ctype_b_C[];
extern CONST struct ctype_mbchar_info __ctype_mbchar_C;
CONST struct ctype_info __ctype_C =
  {
    (unsigned char *) &__ctype_b_C,
    (struct ctype_mbchar_info*) &__ctype_mbchar_C
  };

CONST struct ctype_info *_ctype_info = &__ctype_C;
