#include <ctype.h>
#undef ispunct
int ispunct(int c) { return __ispunct(c); }
