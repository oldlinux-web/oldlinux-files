#include <ctype.h>
#undef isalpha
int isalpha(int c) { return __isalpha(c); }
