/*
 * sys/mount.h     iBCS compatable header
 */

#define MS_RDONLY 0x01
#define MS_FSS 0x02
#define MS_DATA 0x04
#define MS_CACHE 0x08
