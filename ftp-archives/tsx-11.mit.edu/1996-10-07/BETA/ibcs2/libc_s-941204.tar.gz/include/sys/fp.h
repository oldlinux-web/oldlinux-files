/*
 *   sys/fp.h     iBCS compatable file
 */

#define FP_NO        0
#define FP_SW        1
#define FP_HW        2
#define FP_287       2
#define FP_387       3
