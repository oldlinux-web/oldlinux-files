/*
 *  linux/ibcs/stream.h
 *
 *  Copyright (C) 1994  Mike Jagdis (jaggy@purplet.demon.co.uk)
 *
 * $Id: stream.h,v 1.2 1995/07/03 12:52:12 mike Exp $
 * $Source: /u3/CVS/ibcs/include/ibcs/stream.h,v $
 */

#ifndef _IBCS_STREAM_H_
#define _IBCS_STREAM_H_

#define RS_HIPRI	1

#define MORECTL		1
#define MOREDATA	2

struct strbuf {
	int	maxlen;		/* size of buffer */
	int	len;		/* number of bytes in buffer */
	char	*buf;		/* pointer to buffer */
};

#endif
