/*
 *  Copyright 1995  Mike Jagdis (jaggy@purplet.demon.co.uk)
 *
 *  $Id: libnsl_s_data.c,v 1.3 1996/02/01 15:41:09 mike Exp $
 */

/* We could include <xti.h> or <sys/tiuser.h>. I don't know which
 * we really need. The <xti.h> has a slightly longer list of errors.
 */
#include <xti.h>

int _ti_user             = 0;	/* 0xa1400004 */
char _old_ti[0x30]       = { 0 };	/* 0xa1400008 */
int t_errno              = 0;	/* 0xa1400038 */
int t_nerr               = TADDRBUSY+1;	/* 0xa140003c */
char _dummy_errno[16]    = { 0 };	/* 0xa1400040 */
char _dummy_nerr[16]     = { 0 };	/* 0xa1400050 */
char _dummy_errlst[16]   = { 0 };	/* 0xa1400060 */
char *t_errlist[20]      = { 		/* 0xa1400070 */
	_dummy_errlst+96,
	_dummy_errlst+96+12,
	_dummy_errlst+96+12+28,
	_dummy_errlst+96+12+28+28,
	_dummy_errlst+96+12+28+28+20,
	_dummy_errlst+96+12+28+28+20+24,
	_dummy_errlst+96+12+28+28+20+24+28,
	_dummy_errlst+96+12+28+28+20+24+28+44,
	_dummy_errlst+96+12+28+28+20+24+28+44+40,
	_dummy_errlst+96+12+28+28+20+24+28+44+40+16,
	_dummy_errlst+96+12+28+28+20+24+28+44+40+16+28,
	_dummy_errlst+96+12+28+28+20+24+28+44+40+16+28+24,
	_dummy_errlst+96+12+28+28+20+24+28+44+40+16+28+24+24,
	_dummy_errlst+96+12+28+28+20+24+28+44+40+16+28+24+24+32,
	_dummy_errlst+96+12+28+28+20+24+28+44+40+16+28+24+24+32+32,
	_dummy_errlst+96+12+28+28+20+24+28+44+40+16+28+24+24+32+32+32,
	_dummy_errlst+96+12+28+28+20+24+28+44+40+16+28+24+24+32+32+32+36,
	_dummy_errlst+96+12+28+28+20+24+28+44+40+16+28+24+24+32+32+32+36+28,
	_dummy_errlst+96+12+28+28+20+24+28+44+40+16+28+24+24+32+32+32+36+28+36,
	_dummy_errlst+96+12+28+28+20+24+28+44+40+16+28+24+24+32+32+32+36+28+36+36,
};
char __et1[] = "No error";
char __et2[] = "Incorrect address format";
char __et3[] = "Incorrect options format";
char __et4[] = "Illegal permissions";
char __et5[] = "Illegal file descriptor";
char __et6[] = "Couldn't allocate address";
char __et7[] = "Routine will place interface out of state";
char __et8[] = "Illegal called/calling sequence number";
char __et9[] = "System error";
char __et10[] = "An event requires attention";
char __et11[] = "Illegal amount of data";
char __et12[] = "Buffer not large enough";
char __et13[] = "Can't send message - (blocked)";
char __et14[] = "No message currently available";
char __et15[] = "Disconnect message not found";
char __et16[] = "Unitdata error message not found";
char __et17[] = "Incorrect flags specified";
char __et18[] = "Orderly release message not found";
char __et19[] = "Primitive not supported by provider";
char __et20[] = "State is in process of changing";
char __pad[836-12-28-28-20-24-28-44-40-16-28-24-24-32-32-32-36-28-36-36-32] = { 0, };

int (*__calloc)()        = 0;	/* 0xa1400404 */
int *__errno             = 0;	/* 0xa1400408 */
int (*__fcntl)()         = 0;	/* 0xa140040c */
int (*__free)()          = 0;	/* 0xa1400410 */
int (*__ioctl)()         = 0;	/* 0xa1400414 */
int (*__memcpy)()        = 0;	/* 0xa1400418 */
int (*__perror)()        = 0;	/* 0xa140041c */
int (*__getmsg)()        = 0;	/* 0xa1400420 */
int (*__putmsg)()        = 0;	/* 0xa1400424 */
int (*__sigset)()        = 0;	/* 0xa1400428 */
int (*__strlen)()        = 0;	/* 0xa140042c */
int (*__write)()         = 0;	/* 0xa1400430 */
int (*__open)()          = 0;	/* 0xa1400434 */
int (*__close)()         = 0;	/* 0xa1400438 */
int (*__ulimit)()        = 0;	/* 0xa140043c */
int openfiles            = 0;	/* 0xa1400440 */
int tiusr_statetbl       = 0;	/* 0xa1400444 */
int (*__dup2)()          = 0;	/* 0xa1400448 */
