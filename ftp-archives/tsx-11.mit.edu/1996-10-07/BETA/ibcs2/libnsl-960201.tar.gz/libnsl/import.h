/*
 *  Copyright 1995  Mike Jagdis (jaggy@purplet.demon.co.uk)
 *
 *  $Id: import.h,v 1.2 1996/02/01 15:41:09 mike Exp $
 */

#define calloc	(*__calloc)
#define errno	(*__errno)
#define fcntl	(*__fcntl)
#define free	(*__free)
#define ioctl	(*__ioctl)
#define memcpy	(*__memcpy)
#define perror	(*__perror)
#define getmsg	(*__getmsg)
#define putmsg	(*__putmsg)
#define sigset	(*__sigset)
#define strlen	(*__strlen)
#define write	(*__write)
#define open	(*__open)
#define close	(*__close)
#define ulimit	(*__ulimit)
