/*
 *  Copyright 1995  Mike Jagdis (jaggy@purplet.demon.co.uk)
 *
 *  $Id: global.h,v 1.2 1996/02/01 15:41:08 mike Exp $
 */

extern int (*__calloc)();
extern int *__errno;
extern int (*__fcntl)();
extern int (*__free)();
extern int (*__ioctl)();
extern int (*__memcpy)();
extern int (*__perror)();
extern int (*__getmsg)();
extern int (*__putmsg)();
extern int (*__sigset)();
extern int (*__strlen)();
extern int (*__write)();
extern int (*__open)();
extern int (*__close)();
extern int (*__ulimit)();

extern int t_errno;
extern int t_nerr;
