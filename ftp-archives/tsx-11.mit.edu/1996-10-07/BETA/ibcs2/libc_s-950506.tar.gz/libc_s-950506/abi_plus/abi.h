#define LIBSYS  0
#define LIBC	1
#define LIBNSL  2

#define SYM_REQUIRED 	0x01
#define SYM_OPTIONAL	0x02
#define SYM_SYNONYM  	0x04
#define SYM_I386     	0x08
#define SYM_FUNCTION 	0x10
#define SYM_DATA	0x20

struct symbol{
  char * name;
  unsigned int flags;
  unsigned int libname;
  unsigned int size;  /* Used for variables - make sure we have the same
			 * size so that user programs do not overwrite
			 * something useful
			 */
};

