/*
 * Functions local to the conversion library.
 */

char *_xtoa (const long int val, char *pszOut, int radix, int sign);

