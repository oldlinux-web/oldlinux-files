#include <unistd.h>

#ifdef ELF_LIBRARY
#define setpgrp _setpgrp
#define setpgid _setpgid
#endif

int setpgrp(void)
  {
    return setpgid(0,0);
  }

#ifdef ELF_LIBRARY
__asm__(".weak setpgrp; setpgrp = _setpgrp");
#endif
