/*
 *  ieeefp.h   iBCS compatable header file
 */

struct _fpstackframe {
       long      signo;         /* Signal number       */
       long      regs [SS+1];   /* List of registers   */
       struct _fpstate *fpsp;   /* Pointer to fpu state */
       char            *wsp;
};

struct _fpreg {
       unsigned short significand [4];
       unsigned short exponent;
};

struct _fpstate {
       unsigned long     cw,
                         sw,
                         tag,
                         ipoff,
                         cssel,
                         dataoff,
                         datasel;
       struct _fpreg     _st[8];
       unsigned long     status;
};
