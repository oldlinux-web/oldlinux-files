/*
 * sys/lock.h     iBCS compatable header
 */

#define UNLOCK 0
#define PROCLOCK 1
#define TXTLOCK 2
#define DATLOCK 4
