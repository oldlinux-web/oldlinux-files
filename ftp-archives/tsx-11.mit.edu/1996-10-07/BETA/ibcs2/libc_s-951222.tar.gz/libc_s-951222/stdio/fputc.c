#include <stdio.h>
#include "file2.h"
#include "internal.h"
#include <trace.h>

/***********************************************************************
 *
 * Function:      fputc
 *
 * Description:
 *    Write a single character to the output file. This is a function which
 *    simply calls the macro "putc".
 *
 * Entry:
 *    nChar   - Output character to be written
 *    stream  - Pointer to the output stream to which nChar is to be written
 *
 * Returns:
 *    The output character or EOF to indicate some abnormal condition.
 */

int fputc (int nChar, FILE *stream)
    {
    int answer;
    FUNC_ENTRY ("fputc");
    answer = __sputc (nChar, stream);
    FUNC_EXIT ("fputc");
    return (answer);
    }
