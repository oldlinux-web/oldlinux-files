
#include <unistd.h>

int truncate(const char *path, off_t length);
{
}


int ftruncate(int fildes, off_t length);
{
	ioctl(fd, , length);
}

