
/* Quick hack for __assert, copied from libc-linux.  Under SVr4 this
   is a function rather than a macro. */

__assert(expression, file, lineno) 
{
  printf ("%s:%u: failed assertion %s\n", file, lineno, expression);
  abort ();
}
