#include <ctype.h>
#undef _toupper
int _toupper(int c) { return ___toupper(c); }

int toupper(int c) { return (isupper(c) ? c : ___toupper(c)); }
