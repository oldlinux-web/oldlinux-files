#include <ctype.h>
#undef toascii

#ifdef ELF_LIBRARY
#define toascii _toascii
#endif


int toascii(int c) { return __toascii(c); }

#ifdef ELF_LIBRARY
__asm__(".weak toascii; toascii = _toascii");
#endif
