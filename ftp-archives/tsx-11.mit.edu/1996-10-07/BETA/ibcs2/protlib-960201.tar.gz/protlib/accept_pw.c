/*
 *  Copyright 1995  Mike Jagdis (jaggy@purplet.demon.co.uk)
 *
 *  $Id$
 */

#include "import.h"

#include <sys/types.h>
#include <prot.h>
#include <stdio.h>

#include "debug.h"


int
acceptable_password(word, stream)
	char *word;
	FILE *stream;
{
	/* Check the given password "word" for acceptability.
	 * Return 1 if it is ok otherwise write the reason to
	 * "stream" (if not null) and return 0.
	 */
	dbg_write(2, "acceptable_password\n", 20);
	return 1;
}
