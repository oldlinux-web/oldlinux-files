/*
 *  Copyright 1995  Mike Jagdis (jaggy@purplet.demon.co.uk)
 *
 *  $Id$
 */

#include "import.h"

#include <stdlib.h>
#include <unistd.h>

#include "debug.h"


/* Return non-zero if the user has the specified authorisation,
 * otherwise 0.
 */
int
authorized_user(auth)
	char *auth;
{
	dbg_write(2, "authorized_user\n", 17);
	return 1;
}


/* Return the bit offset of the authorisation or -1 if not recognised. */
int
primary_auth(name)
	char *name;
{
	dbg_write(2, "primary_auth\n", 13);
	return 1;
}


/* Return the bit offset of the authorisation or -1 if not recognised. */
int
secondary_auth(name)
	char *name;
{
	dbg_write(2, "secondary_auth\n", 15);
	return 1;
}


/* Return the primary authorisation name associated with the specified
 * secondary name.
 */
char *
primary_of_secondary_auth(name)
	char *name;
{
	dbg_write(2, "primary_of_secondary_auth\n", 26);
	return "system";
}


/* Return the total number of primary and secondary authorisation
 * strings recognised by the system.
 */
int
total_auths()
{
	dbg_write(2, "total_auths\n", 12);
	return 1;
}


/* Return the length of the longest authorisation string. */
int
widest_auth()
{
	dbg_write(2, "widest_auth\n", 12);
	return 32;
}


/* Update the subsystems database for the specified user with the given
 * list of authorisations.
 */
int
write_authorizations(user, auth_list, list_len)
	char *user, **auth_list;
	int list_len;
{
	dbg_write(2, "write_authorizations\n", 21);
	return 0;
}
