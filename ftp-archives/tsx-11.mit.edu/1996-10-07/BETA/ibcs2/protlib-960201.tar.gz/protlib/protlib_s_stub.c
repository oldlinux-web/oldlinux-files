/*
 *  Copyright 1995  Mike Jagdis (jaggy@purplet.demon.co.uk)
 *
 *  $Id$
 */

#include "import.h"

#include <sys/types.h>
#include <errno.h>
#include <prot.h>
#include <unistd.h>

#include "debug.h"


void
audit_adjust_mask()
{
	dbg_write(2, "audit_adjust_mask  \n", 20);
}
void
audit_auth_entry()
{
	dbg_write(2, "audit_auth_entry   \n", 20);
}
void
audit_lax_file()
{
	dbg_write(2, "audit_lax_file     \n", 20);
}
void
audit_lock()
{
	dbg_write(2, "audit_lock         \n", 20);
}
void
audit_login()
{
	dbg_write(2, "audit_login        \n", 20);
}
void
audit_no_resource()
{
	dbg_write(2, "audit_no_resource  \n", 20);
}
void
audit_passwd()
{
	dbg_write(2, "audit_passwd       \n", 20);
}
void
audit_security_failure()
{
	dbg_write(2, "audit_security_failure\n", 23);
}
void
audit_subsystem()
{
	dbg_write(2, "audit_subsystem    \n", 20);
}
char *
bigcrypt()
{
	dbg_write(2, "bigcrypt           \n", 20);
	return 0;
}
int
build_cmd_priv()
{
	dbg_write(2, "build_cmd_priv     \n", 20);
	return 0;
}
int
chpriv()
{
	dbg_write(2, "chpriv             \n", 20);
	return 0;
}
struct dev_asg *
copydvagent()
{
	dbg_write(2, "copydvagent        \n", 20);
	return 0;
}
int
create_file_securely()
{
	dbg_write(2, "create_file_securely\n", 21);
	return 0;
}
void
end_authcap()
{
	dbg_write(2, "end_authcap        \n", 20);
}
void
enddvagent()
{
	dbg_write(2, "enddvagent         \n", 20);
}
void
endprdfent()
{
	dbg_write(2, "endprdfent         \n", 20);
}
void
endprfient()
{
	dbg_write(2, "endprfient         \n", 20);
}
void
endprpwent()
{
	dbg_write(2, "endprpwent         \n", 20);
}
void
endprtcent()
{
	dbg_write(2, "endprtcent         \n", 20);
}
void
enter_quiet_zone()
{
	dbg_write(2, "enter_quiet_zone   \n", 20);
}
void
exit_quiet_zone()
{
	dbg_write(2, "exit_quiet_zone    \n", 20);
}
char *
fgetpasswd()
{
	dbg_write(2, "fgetpasswd         \n", 20);
	return 0;
}
char *
find_auth_file()
{
	dbg_write(2, "find_auth_file     \n", 20);
	return 0;
}
long
get_seed()
{
	dbg_write(2, "get_seed           \n", 20);
	return 0;
}
struct dev_asg *
getdvagent()
{
	dbg_write(2, "getdvagent         \n", 20);
	return 0;
}
struct dev_asg *
getdvagnam()
{
	dbg_write(2, "getdvagnam         \n", 20);
	return 0;
}
char *
getpasswd()
{
	dbg_write(2, "getpasswd          \n", 20);
	return 0;
}
struct pr_default *
getprdfent()
{
	dbg_write(2, "getprdfent         \n", 20);
	return 0;
}
struct pr_default *
getprdfnam()
{
	dbg_write(2, "getprdfnam         \n", 20);
	return 0;
}
struct pr_file *
getprfient()
{
	dbg_write(2, "getprfient         \n", 20);
	return 0;
}
struct pr_file *
getprfinam()
{
	dbg_write(2, "getprfinam         \n", 20);
	return 0;
}
int
getpriv()
{
	dbg_write(2, "getpriv            \n", 20);
	return 0;
}
struct pr_passwd *
getprpwent()
{
	dbg_write(2, "getprpwent         \n", 20);
	return 0;
}
struct pr_passwd *
getprpwnam()
{
	dbg_write(2, "getprpwnam         \n", 20);
	return 0;
}
struct pr_passwd *
getprpwuid()
{
	dbg_write(2, "getprpwuid         \n", 20);
	return 0;
}
struct pr_term *
getprtcent()
{
	dbg_write(2, "getprtcent         \n", 20);
	return 0;
}
struct pr_term *
getprtcnam()
{
	dbg_write(2, "getprtcnam         \n", 20);
	return 0;
}
char *
gr_idtoname()
{
	dbg_write(2, "gr_idtoname        \n", 20);
	return 0;
}
int
gr_nametoid()
{
	dbg_write(2, "gr_nametoid        \n", 20);
	return 0;
}
void
loadnamepair()
{
	dbg_write(2, "loadnamepair       \n", 20);
}
int
locked_out()
{
	dbg_write(2, "locked_out         \n", 20);
	return 0;
}
int
make_transition_files()
{
	dbg_write(2, "make_transition_files\n", 22);
	return 0;
}
void
open_auth_file()
{
	dbg_write(2, "open_auth_file     \n", 20);
}
int
pr_newline()
{
	dbg_write(2, "pr_newline         \n", 20);
	return 0;
}
void
printbuf()
{
	dbg_write(2, "printbuf           \n", 20);
}
int
privileged_user()
{
	dbg_write(2, "privileged_user    \n", 20);
	return 0;
}
int
putdvagnam()
{
	dbg_write(2, "putdvagnam         \n", 20);
	return 0;
}
int
putprdfnam()
{
	dbg_write(2, "putprdfnam         \n", 20);
	return 0;
}
int
putprfinam()
{
	dbg_write(2, "putprfinam         \n", 20);
	return 0;
}
int
putprpwnam()
{
	dbg_write(2, "putprpwnam         \n", 20);
	return 0;
}
int
putprtcnam()
{
	dbg_write(2, "putprtcnam         \n", 20);
	return 0;
}
char *
pw_idtoname()
{
	dbg_write(2, "pw_idtoname        \n", 20);
	return 0;
}
int
pw_nametoid()
{
	dbg_write(2, "pw_nametoid        \n", 20);
	return 0;
}
int
pw_was_eof()
{
	dbg_write(2, "pw_was_eof         \n", 20);
	return 0;
}
int
read_pw_fields()
{
	dbg_write(2, "read_pw_fields     \n", 20);
	return 0;
}
void
read_tc_fields()
{
	dbg_write(2, "read_tc_fields     \n", 20);
}
int
replace_file()
{
	dbg_write(2, "replace_file       \n", 20);
	return 0;
}
int
reset_default()
{
	dbg_write(2, "reset_default      \n", 20);
	return 0;
}
void
sa_audit_audit()
{
	dbg_write(2, "sa_audit_audit     \n", 20);
}
void
sa_audit_lock()
{
	dbg_write(2, "sa_audit_lock      \n", 20);
}
void
sa_audit_no_resource()
{
	dbg_write(2, "sa_audit_no_resource\n", 21);
}
void
sa_audit_security_failure()
{
	dbg_write(2, "sa_audit_security_failure\n", 26);
}
void
sa_audit_subsystem()
{
	dbg_write(2, "sa_audit_subsystem \n", 20);
}
void
set_seed()
{
	dbg_write(2, "set_seed           \n", 20);
}
void
setdvagent()
{
	dbg_write(2, "setdvagent         \n", 20);
}
void
setprdfent()
{
	dbg_write(2, "setprdfent         \n", 20);
}
void
setprfient()
{
	dbg_write(2, "setprfient         \n", 20);
}
int
setpriv()
{
	dbg_write(2, "setpriv            \n", 20);
	return 0;
}
void
setprpwent()
{
	dbg_write(2, "setprpwent         \n", 20);
}
void
setprtcent()
{
	dbg_write(2, "setprtcent         \n", 20);
}
void
setuid_least_privilege()
{
	dbg_write(2, "setuid_least_privilege\n", 23);
}
int
statpriv()
{
	dbg_write(2, "statpriv           \n", 20);
	return 0;
}
int
stopio()
{
	dbg_write(2, "stopio             \n", 20);
	return 0;
}
int
store_pw_fields()
{
	dbg_write(2, "store_pw_fields    \n", 20);
	return 0;
}
int
store_tc_fields()
{
	dbg_write(2, "store_tc_fields    \n", 20);
	return 0;
}
char *
storebool()
{
	dbg_write(2, "storebool          \n", 20);
	return 0;
}
char *
storenamepair()
{
	dbg_write(2, "storenamepair      \n", 20);
	return 0;
}
int
agetent()
{
	dbg_write(2, "agetent            \n", 20);
	return 0;
}
char *
cfs_to_string()
{
	dbg_write(2, "cfs_to_string      \n", 20);
	return 0;
}
int
integreq()
{
	dbg_write(2, "integreq           \n", 20);
	return 0;
}
void
set_override_mode()
{
	dbg_write(2, "set_override_mode  \n", 20);
}
int
get_override_mode()
{
	dbg_write(2, "get_override_mode  \n", 20);
	return 0;
}
int
pre_v3_passwd()
{
	dbg_write(2, "pre_v3_passwd      \n", 20);
	return 0;
}
void
set_open_lock()
{
	dbg_write(2, "set_open_lock      \n", 20);
}
int
get_open_lock()
{
	dbg_write(2, "get_open_lock      \n", 20);
	return 0;
}
void
set_write_mode()
{
	dbg_write(2, "set_write_mode     \n", 20);
}
int
get_write_mode()
{
	dbg_write(2, "get_write_mode     \n", 20);
	return 0;
}
char *
bigcryptmax()
{
	dbg_write(2, "bigcryptmax        \n", 20);
	return 0;
}
int
oktofaketcb()
{
	dbg_write(2, "oktofaketcb        \n", 20);
	return 0;
}

#if 0
int
__empty_slot()
{
	dbg_write(2, "empty branch table slot!", 24);
	return 0;
}
int
catch_no_sec_sys_calls()
{
	dbg_write(2, "catch_no_sec_sys_calls", 22);
	return 0;
}
int
do_spell()
{
	dbg_write(2, "do_spell            ", 20);
	return 0;
}
int
palindrome()
{
	dbg_write(2, "palindrome          ", 20);
	return 0;
}
int
login_name_derivative()
{
	dbg_write(2, "login_name_derivative", 21);
	return 0;
}
int
group_name_derivative()
{
	dbg_write(2, "group_name_derivative", 21);
	return 0;
}
int
english_word()
{
	dbg_write(2, "english_word        ", 20);
	return 0;
}
int
derivative()
{
	dbg_write(2, "derivative          ", 20);
	return 0;
}
int
char_comp()
{
	dbg_write(2, "char_comp           ", 20);
	return 0;
}
int
fillin_base_vec()
{
	dbg_write(2, "fillin_base_vec     ", 20);
	return 0;
}
int
call_audit_program()
{
	dbg_write(2, "call_audit_program  ", 20);
	return 0;
}
int
real_audit_security_failure()
{
	dbg_write(2, "real_audit_security_failure", 27);
	return 0;
}
int
real_audit_no_resource()
{
	dbg_write(2, "real_audit_no_resource", 22);
	return 0;
}
int
real_audit_subsystem()
{
	dbg_write(2, "real_audit_subsystem", 20);
	return 0;
}
int
match_name()
{
	dbg_write(2, "match_name          ", 20);
	return 0;
}
int
match_file()
{
	dbg_write(2, "match_file          ", 20);
	return 0;
}
int
askip()
{
	dbg_write(2, "askip               ", 20);
	return 0;
}
int
adecode()
{
	dbg_write(2, "adecode             ", 20);
	return 0;
}
int
match_name_buf()
{
	dbg_write(2, "match_name_buf      ", 20);
	return 0;
}
int
read_dv_fields()
{
	dbg_write(2, "read_dv_fields      ", 20);
	return 0;
}
int
parse_dv_field()
{
	dbg_write(2, "parse_dv_field      ", 20);
	return 0;
}
int
store_dv_fields()
{
	dbg_write(2, "store_dv_fields     ", 20);
	return 0;
}
int
catch()
{
	dbg_write(2, "catch               ", 20);
	return 0;
}
int
trunc_passwd()
{
	dbg_write(2, "trunc_passwd        ", 20);
	return 0;
}
int
disable_etc_default()
{
	dbg_write(2, "disable_etc_default ", 20);
	return 0;
}
int
enable_etc_default()
{
	dbg_write(2, "enable_etc_default  ", 20);
	return 0;
}
int
store_df_fields()
{
	dbg_write(2, "store_df_fields     ", 20);
	return 0;
}
int
read_fi_fields()
{
	dbg_write(2, "read_fi_fields      ", 20);
	return 0;
}
int
parse_fi_field()
{
	dbg_write(2, "parse_fi_field      ", 20);
	return 0;
}
int
store_fi_fields()
{
	dbg_write(2, "store_fi_fields     ", 20);
	return 0;
}
int
truncate_passwd()
{
	dbg_write(2, "truncate_passwd     ", 20);
	return 0;
}
int
check_pw()
{
	dbg_write(2, "check_pw            ", 20);
	return 0;
}
int
check_file()
{
	dbg_write(2, "check_file          ", 20);
	return 0;
}
int
make_file()
{
	dbg_write(2, "make_file           ", 20);
	return 0;
}
int
id_comp()
{
	dbg_write(2, "id_comp             ", 20);
	return 0;
}
int
name_comp()
{
	dbg_write(2, "name_comp           ", 20);
	return 0;
}
int
read_file()
{
	dbg_write(2, "read_file           ", 20);
	return 0;
}
int
parse_line()
{
	dbg_write(2, "parse_line          ", 20);
	return 0;
}
int
lock_file()
{
	dbg_write(2, "lock_file           ", 20);
	return 0;
}
int
unlock_file()
{
	dbg_write(2, "unlock_file         ", 20);
	return 0;
}
int
set_num_cols()
{
	dbg_write(2, "set_num_cols        ", 20);
	return 0;
}
int
compute_seed()
{
	dbg_write(2, "compute_seed        ", 20);
	return 0;
}
int
auto_seed()
{
	dbg_write(2, "auto_seed           ", 20);
	return 0;
}
int
report_blank()
{
	dbg_write(2, "report_blank        ", 20);
	return 0;
}
int
read_authorizations()
{
	dbg_write(2, "read_authorizations ", 20);
	return 0;
}
int
is_privileged()
{
	dbg_write(2, "is_privileged       ", 20);
	return 0;
}
int
has_default_auth()
{
	dbg_write(2, "has_default_auth    ", 20);
	return 0;
}
int
real_write_authorizations()
{
	dbg_write(2, "real_write_authorizations", 25);
	return 0;
}
int
write_subsystem_file()
{
	dbg_write(2, "write_subsystem_file", 20);
	return 0;
}
int
write_subsystem_line()
{
	dbg_write(2, "write_subsystem_line", 20);
	return 0;
}
int
update_default_file()
{
	dbg_write(2, "update_default_file ", 20);
	return 0;
}
int
evaluate_mirroring_fields()
{
	dbg_write(2, "evaluate_mirroring_fields", 25);
	return 0;
}
int
round_to_weeks()
{
	dbg_write(2, "round_to_weeks      ", 20);
	return 0;
}
int
round_to_days()
{
	dbg_write(2, "round_to_days       ", 20);
	return 0;
}
int
lock_dflt_files()
{
	dbg_write(2, "lock_dflt_files     ", 20);
	return 0;
}
int
lock_pw_files()
{
	dbg_write(2, "lock_pw_files       ", 20);
	return 0;
}
int
unlock_dflt_files()
{
	dbg_write(2, "unlock_dflt_files   ", 20);
	return 0;
}
int
unlock_pw_files()
{
	dbg_write(2, "unlock_pw_files     ", 20);
	return 0;
}
int
put_dflt_fields()
{
	dbg_write(2, "put_dflt_fields     ", 20);
	return 0;
}
int
replace_dflt_files()
{
	dbg_write(2, "replace_dflt_files  ", 20);
	return 0;
}
int
replace_pw_files()
{
	dbg_write(2, "replace_pw_files    ", 20);
	return 0;
}
int
create_lock_file()
{
	dbg_write(2, "create_lock_file    ", 20);
	return 0;
}
int
create_file_exclusively()
{
	dbg_write(2, "create_file_exclusively", 23);
	return 0;
}
int
free_update_paths()
{
	dbg_write(2, "free_update_paths   ", 20);
	return 0;
}
int
free_update_pw_paths()
{
	dbg_write(2, "free_update_pw_paths", 20);
	return 0;
}
int
get_dflt_fields()
{
	dbg_write(2, "get_dflt_fields     ", 20);
	return 0;
}
int
open_file()
{
	dbg_write(2, "open_file           ", 20);
	return 0;
}
int
validate_passwd_fields()
{
	dbg_write(2, "validate_passwd_fields", 22);
	return 0;
}
int
validate_dflt_fields()
{
	dbg_write(2, "validate_dflt_fields", 20);
	return 0;
}
int
evaluate_default_aging()
{
	dbg_write(2, "evaluate_default_aging", 22);
	return 0;
}
int
get_pw_fields()
{
	dbg_write(2, "get_pw_fields       ", 20);
	return 0;
}
int
read_shadow_fields()
{
	dbg_write(2, "read_shadow_fields  ", 20);
	return 0;
}
int
read_passwd_fields()
{
	dbg_write(2, "read_passwd_fields  ", 20);
	return 0;
}
int
get_passwd()
{
	dbg_write(2, "get_passwd          ", 20);
	return 0;
}
int
get_aging()
{
	dbg_write(2, "get_aging           ", 20);
	return 0;
}
int
get_slogin()
{
	dbg_write(2, "get_slogin          ", 20);
	return 0;
}
int
put_pw_fields()
{
	dbg_write(2, "put_pw_fields       ", 20);
	return 0;
}
int
write_shadow_fields()
{
	dbg_write(2, "write_shadow_fields ", 20);
	return 0;
}
int
write_passwd_fields()
{
	dbg_write(2, "write_passwd_fields ", 20);
	return 0;
}
int
put_passwd()
{
	dbg_write(2, "put_passwd          ", 20);
	return 0;
}
int
put_aging()
{
	dbg_write(2, "put_aging           ", 20);
	return 0;
}
int
put_remainder()
{
	dbg_write(2, "put_remainder       ", 20);
	return 0;
}
int
put_slogin()
{
	dbg_write(2, "put_slogin          ", 20);
	return 0;
}
int
copy_file()
{
	dbg_write(2, "copy_file           ", 20);
	return 0;
}
int
append_str()
{
	dbg_write(2, "append_str          ", 20);
	return 0;
}
int
audit_failure()
{
	dbg_write(2, "audit_failure       ", 20);
	return 0;
}
int
find_line()
{
	dbg_write(2, "find_line           ", 20);
	return 0;
}
int
find_any_line()
{
	dbg_write(2, "find_any_line       ", 20);
	return 0;
}
int
match_line()
{
	dbg_write(2, "match_line          ", 20);
	return 0;
}
int
get_buffer()
{
	dbg_write(2, "get_buffer          ", 20);
	return 0;
}
int
grow_buffer()
{
	dbg_write(2, "grow_buffer         ", 20);
	return 0;
}
int
add_to_buffer()
{
	dbg_write(2, "add_to_buffer       ", 20);
	return 0;
}
int
write_to_file()
{
	dbg_write(2, "write_to_file       ", 20);
	return 0;
}
int
free_buffer()
{
	dbg_write(2, "free_buffer         ", 20);
	return 0;
}
int
free_userbuf()
{
	dbg_write(2, "free_userbuf        ", 20);
	return 0;
}
int
skipfield()
{
	dbg_write(2, "skipfield           ", 20);
	return 0;
}
int
lastlogin_path()
{
	dbg_write(2, "lastlogin_path      ", 20);
	return 0;
}
int
cleanup()
{
	dbg_write(2, "cleanup             ", 20);
	return 0;
}
#endif
