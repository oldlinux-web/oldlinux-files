/*
 *  Copyright 1995  Mike Jagdis (jaggy@purplet.demon.co.uk)
 *
 *  $Id$
 */

#ifndef DEBUG
#define dbg_write(fd, str, len)
#endif
