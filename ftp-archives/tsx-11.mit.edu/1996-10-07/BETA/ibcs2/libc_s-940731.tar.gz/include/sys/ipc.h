/*
 *   sys/ipc.h       iBCS compatable header
 */

struct ipc_perm {
       unsigned short   uid;
       unsigned short   gid;
       unsigned short   cuid;
       unsigned short   cgid;
       unsigned short   mode;
       unsigned short   seq;
       key_t            key;
};

#define IPC_CREAT       0001000
#define IPC_EXCL        0002000
#define IPC_NOWAIT      0004000

#define IPC_PRIVATE     (key_t) 0

#define IPC_RMID        0
#define IPC_SET         1
#define IPC_STAT        2
