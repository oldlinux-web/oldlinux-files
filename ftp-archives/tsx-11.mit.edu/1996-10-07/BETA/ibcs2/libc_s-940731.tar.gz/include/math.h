/*
 * math.h     iBCS compatable header
 */

#include <nan.h>

#ifndef HUGE_VAL
#define HUGE_VAL        1.7976931348623157E+308
#endif

extern double modf (double x, double *iptr);

#ifdef ELF_LIBRARY
extern double _modf (double x, double *iptr);
#endif
