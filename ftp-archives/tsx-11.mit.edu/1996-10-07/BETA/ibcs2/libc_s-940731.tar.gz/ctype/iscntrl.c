#include <ctype.h>
#undef iscntrl
int iscntrl(int c) { return __iscntrl(c); }
