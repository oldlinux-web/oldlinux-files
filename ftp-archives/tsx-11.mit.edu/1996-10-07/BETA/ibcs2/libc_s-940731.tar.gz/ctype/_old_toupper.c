#include <ctype.h>
#undef _old_toupper
int _old_toupper(int c) { return ___old_toupper(c); }
