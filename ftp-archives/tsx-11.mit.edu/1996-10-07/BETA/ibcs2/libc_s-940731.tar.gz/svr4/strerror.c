#include <stdio.h>

char * strerror(int errno)
{
  return _sys_errlist[errno];
}
