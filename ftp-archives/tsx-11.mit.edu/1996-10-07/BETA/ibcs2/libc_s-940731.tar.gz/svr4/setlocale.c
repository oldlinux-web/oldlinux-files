#include <stdio.h>

char * setlocale(int category, const char * name)
{
  fprintf(stderr,"Warning - setlocale not supported yet.\n");
  fprintf(stderr,"Category %d, name %s\n", category, name);
}

/* We have only the "C" type of locale for now, so these simplified versions
   of these functions will suffice for now. */

int mbtowc(wchar_t * wch, const char * s, size_t n)
{
  if(wch) *wch = *s;
  return 1;
}

int mblen(const char * s, size_t n)
{
  return mbtowc(0, s, n);
}

int wctomb(char * s, wchar_t * wchar)
{
  *s = *wchar;
  return 1;
}
