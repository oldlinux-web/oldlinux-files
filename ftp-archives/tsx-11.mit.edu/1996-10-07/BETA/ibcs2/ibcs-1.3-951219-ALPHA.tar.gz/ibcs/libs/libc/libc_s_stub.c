#include <errno.h>
#include <syslog.h>

int
__empty_slot()
{
	dbg_write(2, "empty branch table slot!", 24);
	return -EINVAL;
}
int
_doprnt             ()
{
	dbg_write(2, "_doprnt             \n", 21);
	return 0;
}
int
_bufsync            ()
{
	dbg_write(2, "_bufsync            \n", 21);
	return 0;
}
int
_cerror             ()
{
	dbg_write(2, "_cerror             \n", 21);
	return 0;
}
int
_cleanup            ()
{
	dbg_write(2, "_cleanup            \n", 21);
	return 0;
}
int
_filbuf             ()
{
	dbg_write(2, "_filbuf             \n", 21);
	return 0;
}
int
_findbuf            ()
{
	dbg_write(2, "_findbuf            \n", 21);
	return 0;
}
int
_findiop            ()
{
	dbg_write(2, "_findiop            \n", 21);
	return 0;
}
int
_flsbuf             ()
{
	dbg_write(2, "_flsbuf             \n", 21);
	return 0;
}
int
_wrtchk             ()
{
	dbg_write(2, "_wrtchk             \n", 21);
	return 0;
}
int
_xflsbuf            ()
{
	dbg_write(2, "_xflsbuf            \n", 21);
	return 0;
}
int
abs                 ()
{
	dbg_write(2, "abs                 \n", 21);
	return 0;
}
int
access              ()
{
	dbg_write(2, "access              \n", 21);
	return 0;
}
int
atof                ()
{
	dbg_write(2, "atof                \n", 21);
	return 0;
}
int
atoi                ()
{
	dbg_write(2, "atoi                \n", 21);
	return 0;
}
int
atol                ()
{
	dbg_write(2, "atol                \n", 21);
	return 0;
}
int
brk                 ()
{
	dbg_write(2, "brk                 \n", 21);
	return 0;
}
int
calloc              ()
{
	dbg_write(2, "calloc              \n", 21);
	return 0;
}
int
cfree               ()
{
	dbg_write(2, "cfree               \n", 21);
	return 0;
}
int
chdir               ()
{
	dbg_write(2, "chdir               \n", 21);
	return 0;
}
int
chmod               ()
{
	dbg_write(2, "chmod               \n", 21);
	return 0;
}
int
close               ()
{
	dbg_write(2, "close               \n", 21);
	return 0;
}
int
creat               ()
{
	dbg_write(2, "creat               \n", 21);
	return 0;
}
int
ecvt                ()
{
	dbg_write(2, "ecvt                \n", 21);
	return 0;
}
int
fclose              ()
{
	dbg_write(2, "fclose              \n", 21);
	return 0;
}
int
fcntl               ()
{
	dbg_write(2, "fcntl               \n", 21);
	return 0;
}
int
fcvt                ()
{
	dbg_write(2, "fcvt                \n", 21);
	return 0;
}
int
fflush              ()
{
	dbg_write(2, "fflush              \n", 21);
	return 0;
}
int
fgetc               ()
{
	dbg_write(2, "fgetc               \n", 21);
	return 0;
}
int
fgets               ()
{
	dbg_write(2, "fgets               \n", 21);
	return 0;
}
int
fopen               ()
{
	dbg_write(2, "fopen               \n", 21);
	return 0;
}
int
fprintf             ()
{
	dbg_write(2, "fprintf             \n", 21);
	return 0;
}
int
fputc               ()
{
	dbg_write(2, "fputc               \n", 21);
	return 0;
}
int
fputs               ()
{
	dbg_write(2, "fputs               \n", 21);
	return 0;
}
int
fread               ()
{
	dbg_write(2, "fread               \n", 21);
	return 0;
}
int
free                ()
{
	dbg_write(2, "free                \n", 21);
	return 0;
}
int
freopen             ()
{
	dbg_write(2, "freopen             \n", 21);
	return 0;
}
int
frexp               ()
{
	dbg_write(2, "frexp               \n", 21);
	return 0;
}
int
fseek               ()
{
	dbg_write(2, "fseek               \n", 21);
	return 0;
}
int
fstat               ()
{
	dbg_write(2, "fstat               \n", 21);
	return 0;
}
int
fdbg_write              ()
{
	dbg_write(2, "fdbg_write              \n", 21);
	return 0;
}
int
gcvt                ()
{
	dbg_write(2, "gcvt                \n", 21);
	return 0;
}
int
getchar             ()
{
	dbg_write(2, "getchar             \n", 21);
	return 0;
}
int
getenv              ()
{
	dbg_write(2, "getenv              \n", 21);
	return 0;
}
int
getopt              ()
{
	dbg_write(2, "getopt              \n", 21);
	return 0;
}
int
gets                ()
{
	dbg_write(2, "gets                \n", 21);
	return 0;
}
int
getw                ()
{
	dbg_write(2, "getw                \n", 21);
	return 0;
}
int
ioctl               ()
{
	dbg_write(2, "ioctl               \n", 21);
	return 0;
}
int
isatty              ()
{
	dbg_write(2, "isatty              \n", 21);
	return 0;
}
int
isnand              ()
{
	dbg_write(2, "isnand              \n", 21);
	return 0;
}
int
kill                ()
{
	dbg_write(2, "kill                \n", 21);
	return 0;
}
int
ldexp               ()
{
	dbg_write(2, "ldexp               \n", 21);
	return 0;
}
int
lseek               ()
{
	dbg_write(2, "lseek               \n", 21);
	return 0;
}
int
malloc              ()
{
	dbg_write(2, "malloc              \n", 21);
	return 0;
}
int
memccpy             ()
{
	dbg_write(2, "memccpy             \n", 21);
	return 0;
}
int
memchr              ()
{
	dbg_write(2, "memchr              \n", 21);
	return 0;
}
int
memcmp              ()
{
	dbg_write(2, "memcmp              \n", 21);
	return 0;
}
int
memcpy              ()
{
	dbg_write(2, "memcpy              \n", 21);
	return 0;
}
int
memset              ()
{
	dbg_write(2, "memset              \n", 21);
	return 0;
}
int
mktemp              ()
{
	dbg_write(2, "mktemp              \n", 21);
	return 0;
}
int
open                ()
{
	dbg_write(2, "open                \n", 21);
	return 0;
}
int
printf              ()
{
	dbg_write(2, "printf              \n", 21);
	return 0;
}
int
putchar             ()
{
	dbg_write(2, "putchar             \n", 21);
	return 0;
}
int
puts                ()
{
	dbg_write(2, "puts                \n", 21);
	return 0;
}
int
putw                ()
{
	dbg_write(2, "putw                \n", 21);
	return 0;
}
int
read                ()
{
	dbg_write(2, "read                \n", 21);
	return 0;
}
int
realloc             ()
{
	dbg_write(2, "realloc             \n", 21);
	return 0;
}
int
sbrk                ()
{
	dbg_write(2, "sbrk                \n", 21);
	return 0;
}
int
setbuf              ()
{
	dbg_write(2, "setbuf              \n", 21);
	return 0;
}
int
sighold             ()
{
	dbg_write(2, "sighold             \n", 21);
	return 0;
}
int
sigignore           ()
{
	dbg_write(2, "sigignore           \n", 21);
	return 0;
}
int
signal              ()
{
	dbg_write(2, "signal              \n", 21);
	return 0;
}
int
sigpause            ()
{
	dbg_write(2, "sigpause            \n", 21);
	return 0;
}
int
sigrelse            ()
{
	dbg_write(2, "sigrelse            \n", 21);
	return 0;
}
int
sigset              ()
{
	dbg_write(2, "sigset              \n", 21);
	return 0;
}
int
sprintf             ()
{
	dbg_write(2, "sprintf             \n", 21);
	return 0;
}
int
stat                ()
{
	dbg_write(2, "stat                \n", 21);
	return 0;
}
int
strcat              ()
{
	dbg_write(2, "strcat              \n", 21);
	return 0;
}
int
strchr              ()
{
	dbg_write(2, "strchr              \n", 21);
	return 0;
}
int
strcmp              ()
{
	dbg_write(2, "strcmp              \n", 21);
	return 0;
}
int
strcpy              ()
{
	dbg_write(2, "strcpy              \n", 21);
	return 0;
}
int
strlen              ()
{
	dbg_write(2, "strlen              \n", 21);
	return 0;
}
int
strncat             ()
{
	dbg_write(2, "strncat             \n", 21);
	return 0;
}
int
strncmp             ()
{
	dbg_write(2, "strncmp             \n", 21);
	return 0;
}
int
strncpy             ()
{
	dbg_write(2, "strncpy             \n", 21);
	return 0;
}
int
strrchr             ()
{
	dbg_write(2, "strrchr             \n", 21);
	return 0;
}
int
time                ()
{
	dbg_write(2, "time                \n", 21);
	return 0;
}
int
old_tolower         ()
{
	dbg_write(2, "old_tolower         \n", 21);
	return 0;
}
int
old_toupper         ()
{
	dbg_write(2, "old_toupper         \n", 21);
	return 0;
}
int
ungetc              ()
{
	dbg_write(2, "ungetc              \n", 21);
	return 0;
}
int
unlink              ()
{
	dbg_write(2, "unlink              \n", 21);
	return 0;
}
int
utime               ()
{
	dbg_write(2, "utime               \n", 21);
	return 0;
}
int
write               ()
{
	dbg_write(2, "write               \n", 21);
	return 0;
}
int
getpid              ()
{
	dbg_write(2, "getpid              \n", 21);
	return 0;
}


int
_ctype()
{
	dbg_write(2, "_ctype              \n", 21);
	return 0;
}
int
_allocs()
{
	dbg_write(2, "_allocs             \n", 21);
	return 0;
}
int
_sibuf()
{
	dbg_write(2, "_sibuf              \n", 21);
	return 0;
}
int
_sobuf()
{
	dbg_write(2, "_sobuf              \n", 21);
	return 0;
}
int
_smbuf()
{
	dbg_write(2, "_smbuf              \n", 21);
	return 0;
}
int
_iob()
{
	dbg_write(2, "_iob                \n", 21);
	return 0;
}
int
_lastbuf()
{
	dbg_write(2, "_lastbuf            \n", 21);
	return 0;
}
int
_bufendtab()
{
	dbg_write(2, "_bufendtab          \n", 21);
	return 0;
}


#if 0
int
_endopen            ()
{
	dbg_write(2, "_endopen            \n", 21);
	return 0;
}
int
_lowdigit           ()
{
	dbg_write(2, "_lowdigit           \n", 21);
	return 0;
}
int
_dodbg_write            ()
{
	dbg_write(2, "_dodbg_write            \n", 21);
	return 0;
}
int
nvmatch             ()
{
	dbg_write(2, "nvmatch             \n", 21);
	return 0;
}
int
_sigreturn          ()
{
	dbg_write(2, "_sigreturn          \n", 21);
	return 0;
}
int
cvt                 ()
{
	dbg_write(2, "cvt                 \n", 21);
	return 0;
}
int
_dtop               ()
{
	dbg_write(2, "_dtop               \n", 21);
	return 0;
}
int
_ptod               ()
{
	dbg_write(2, "_ptod               \n", 21);
	return 0;
}
int
_ltostr             ()
{
	dbg_write(2, "_ltostr             \n", 21);
	return 0;
}
#endif
