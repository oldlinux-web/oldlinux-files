#include "import.h"

#include <sys/types.h>
#include <errno.h>
#include <prot.h>
#include <unistd.h>


int
adecodenum          ()
{
	dbg_write(2, "adecodenum         \n", 20);
	return 0;
}
int
agetdefault         ()
{
	dbg_write(2, "agetdefault        \n", 20);
	return 0;
}
char *
agetdefault_buf     ()
{
	dbg_write(2, "agetdefault_buf    \n", 20);
	return 0;
}
char *
agetdvag            ()
{
	dbg_write(2, "agetdvag           \n", 20);
	return 0;
}
char *
agetfile            ()
{
	dbg_write(2, "agetfile           \n", 20);
	return 0;
}
int
agetflag            ()
{
	dbg_write(2, "agetflag           \n", 20);
	return 0;
}
int
agetgid             ()
{
	dbg_write(2, "agetgid            \n", 20);
	return 0;
}
char *
agetstr             ()
{
	dbg_write(2, "agetstr            \n", 20);
	return 0;
}
char **
agetstrlist         ()
{
	dbg_write(2, "agetstrlist        \n", 20);
	return 0;
}
int
agettty             ()
{
	dbg_write(2, "agettty            \n", 20);
	return 0;
}
int
agetuid             ()
{
	dbg_write(2, "agetuid            \n", 20);
	return 0;
}
int
agetuser            ()
{
	dbg_write(2, "agetuser           \n", 20);
	return 0;
}
int
agtnum              ()
{
	dbg_write(2, "agtnum             \n", 20);
	return 0;
}
void
asetdefaults        ()
{
	dbg_write(2, "asetdefaults       \n", 20);
}
