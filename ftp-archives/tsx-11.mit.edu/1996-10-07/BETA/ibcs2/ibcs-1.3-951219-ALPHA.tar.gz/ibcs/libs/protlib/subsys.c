#include "import.h"

#include <stdlib.h>
#include <unistd.h>


/* Return non-zero if the user has the specified authorisation,
 * otherwise 0.
 */
int
authorized_user(auth)
	char *auth;
{
	return 1;
}


/* Return the bit offset of the authorisation or -1 if not recognised. */
int
primary_auth(name)
	char *name;
{
	return 1;
}


/* Return the bit offset of the authorisation or -1 if not recognised. */
int
secondary_auth(name)
	char *name;
{
	return 1;
}


/* Return the primary authorisation name associated with the specified
 * secondary name.
 */
char *
primary_of_secondary_auth(name)
	char *name;
{
	return "system";
}


/* Return the total number of primary and secondary authorisation
 * strings recognised by the system.
 */
int
total_auths()
{
	return 1;
}


/* Return the length of the longest authorisation string. */
int
widest_auth()
{
	return 32;
}


/* Update the subsystems database for the specified user with the given
 * list of authorisations.
 */
int
write_authorizations(user, auth_list, list_len)
	char *user, **auth_list;
	int list_len;
{
	return 0;
}
