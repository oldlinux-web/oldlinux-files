#include "import.h"

#include <sys/types.h>
#include <prot.h>
#include <stdlib.h>
#include <unistd.h>


static int auth_initialized = 0;

static ushort ruid, euid, luid, rgid, egid, lgid;


/* Check that C2 security is loaded in the kernel and save all uids/gids.
 * If C2 isn't available we should exit with an error message.
 */
void
set_auth_parameters(argc, argv)
	int argc;
	char *argv[];
{
	auth_initialized = 1;
	luid = ruid = getuid();
	euid = geteuid();
	lgid = rgid = getgid();
	egid = getegid();
}


/* If a call to set_auth_parameters has been made ok, otherwise exit
 * the program.
 */
void
check_auth_parameters()
{
	if (!auth_initialized)
		exit(1);
}


int
is_starting_egid(gid)
	ushort gid;
{
	return gid == egid ? 1 : 0;
}


int
is_starting_euid(uid)
	ushort uid;
{
	return uid == euid ? 1 : 0;
}


int
is_starting_luid(uid)
	ushort uid;
{
	return uid == luid ? 1 : 0;
}


int
is_starting_rgid(gid)
	ushort gid;
{
	return gid == rgid ? 1 : 0;
}


int
is_starting_ruid(uid)
	ushort uid;
{
	return uid == ruid ? 1 : 0;
}


ushort
starting_egid()
{
	return egid;
}


ushort
starting_euid()
{
	return euid;
}


ushort
starting_luid()
{
	return luid;
}


ushort
starting_rgid()
{
	return rgid;
}


ushort
starting_ruid()
{
	return ruid;
}
