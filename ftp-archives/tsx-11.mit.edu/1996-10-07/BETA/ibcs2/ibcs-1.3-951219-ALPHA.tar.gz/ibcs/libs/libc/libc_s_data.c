int (*_libc__ctype)()    = 0;	/* 0xa0400004 */
int (*_libc_malloc)()    = 0;	/* 0xa0400008 */
int (*_libc_realloc)()   = 0;	/* 0xa040000c */
int (*_libc_free)()      = 0;	/* 0xa0400010 */
int (*_libc__allocs)()   = 0;	/* 0xa0400014 */
int (*_libc__sibuf)()    = 0;	/* 0xa0400018 */
int (*_libc__sobuf)()    = 0;	/* 0xa040001c */
int (*_libc__smbuf)()    = 0;	/* 0xa0400020 */
int (*_libc__iob)()      = 0;	/* 0xa0400024 */
int (*_libc__lastbuf)()  = 0;	/* 0xa0400028 */
int (*_libc__bufendtab)()= 0;	/* 0xa040002c */
int (*_libc_end)()       = 0;	/* 0xa0400030 */
int (*_libc__cleanup)()  = 0;	/* 0xa0400034 */
int (*_libc_environ)()   = 0;	/* 0xa0400038 */
int opterr               = 0;	/* 0xa040003c */
int optind               = 0;	/* 0xa0400040 */
int optopt               = 0;	/* 0xa0400044 */
int optarg               = 0;	/* 0xa0400048 */
int errno                = 0;	/* 0xa040004c */
int _fac[2]              = { 0, };	/* 0xa0400050 */
int _fltused             = 0;	/* 0xa0400058 */
int _lct_numeric         = 0;	/* 0xa040005c */
char __pad[0x28]         = { 0, };	/* 0xa0400060 */
int __fltused            = 0;	/* 0xa0400088 */

int end = 0;
int environ = 0;

#if 0
int __fltused            = 0;	/* 0xa0400088 */
int _bigpow              = 0;	/* 0xa04001ac */
int _litpow              = 0;	/* 0xa04002b4 */
#endif
