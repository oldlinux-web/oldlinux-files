/*
 *  linux/ibcs/stream.h
 *
 *  Copyright (C) 1994  Mike Jagdis (jaggy@purplet.demon.co.uk)
 *
 * $Id: stream.h,v 1.1 1994/03/04 15:09:11 mike Exp $
 * $Source: /usr/CVS/ibcs/include/ibcs/stream.h,v $
 */

#ifndef _IBCS_STREAM_H_
#define _IBCS_STREAM_H_

struct strbuf {
	int	maxlen;		/* size of buffer */
	int	len;		/* number of bytes in buffer */
	char	*buf;		/* pointer to buffer */
};

#endif
