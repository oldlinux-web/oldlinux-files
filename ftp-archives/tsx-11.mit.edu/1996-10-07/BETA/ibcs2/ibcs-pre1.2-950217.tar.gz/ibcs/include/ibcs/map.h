/*
 *  linux/ibcs/map.h
 *
 *  Copyright (C) 1994  Mike Jagdis (jaggy@purplet.demon.co.uk)
 *
 * $Id: map.h,v 1.3 1994/06/21 14:12:11 mike Exp $
 * $Source: /usr/CVS/ibcs/include/ibcs/map.h,v $
 */

struct map_segment {
	int start, end;
	unsigned char *map;
};


extern struct map_segment *af_map[];
extern struct map_segment *type_map[];
extern struct map_segment *sopt_map[];

extern unsigned long map_bitvec(unsigned long vec, unsigned long map[]);
extern int map_value(struct map_segment *m[], int val, int def);
