#include <ibcs/unistd.h>
#include <sysdeps.h>


#ifdef ELF_LIBRARY
#define ELFTYPE(X)	.type SYMBOL_NAME(X),@function
#else
#define ELFTYPE(X)
#endif


#define SIGNAL_FUNCTION(NAME,MASK) 			\
	ELFTYPE(NAME);					\
	.text;						\
	.align	ALIGN;					\
	.globl	SYMBOL_NAME(NAME);		       	\
SYMBOL_NAME(NAME##:)					\
	movb	MASK,5(%esp);				\
	movl	$ __IBCS_sigset , %eax;			\
	.byte	0x9a, 0, 0, 0, 0, 7, 0;			\
	jnc	LF(1);					\
	STORE_NUMBER(%eax,ERRNO);			\
	mov	$-1,%eax;				\
L(1:)							\
	ret



#define SIGNAL_FUNCTION_H(NAME,MASK) 			\
	ELFTYPE(NAME);					\
	.text;						\
	.align	ALIGN;					\
	.globl	SYMBOL_NAME(NAME);		       	\
SYMBOL_NAME(NAME##:)					\
	movb	MASK,5(%esp);				\
	movl	$ __IBCS_sigset , %eax;			\
	leal	_sigreturn,%edx;			\
	.byte	0x9a, 0, 0, 0, 0, 7, 0;			\
	jnc	LF(1);					\
	STORE_NUMBER(%eax,ERRNO);			\
	mov	$-1,%eax;				\
L(1:)					       		\
	ret;						\
	.align ALIGN;					\
							\
_sigreturn:						\
	addl	$4,%esp;				\
	.byte	0x9a, 0, 0, 0, 0, 15, 0

