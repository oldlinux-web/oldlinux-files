

#define NL_SETD	1

typedef int nl_item;

typedef void *nl_catd;
