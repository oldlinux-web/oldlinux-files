/*
 *   sys/ftw.h      iBCS compatable header
 */

#define FTW_F        0
#define FTW_D        1
#define FTW_DNR      2
#define FTW_NS       3
