

int remove(const char * filename)
{
  _unlink(filename);
}
