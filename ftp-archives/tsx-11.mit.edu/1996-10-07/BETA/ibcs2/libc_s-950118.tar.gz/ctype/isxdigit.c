#include <ctype.h>
#undef isxdigit
int isxdigit(int c) { return __isxdigit(c); }
