#include <ctype.h>
#undef isgraph
int isgraph(int c) { return __isgraph(c); }
