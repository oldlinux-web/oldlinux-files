#include <stdlib.h>
#include "internal.h"

/*
 * char *ultoa(val,buf,radix) - Convert the input integer to an ascii string
 *
 * Purpose:
 *	This routine will translate the input long integer to the corresponding
 *	ascii string in the specified radix. The input is assumed to be a
 *	unsigned long integer.
 *
 * Entry:
 *	val   - Input integer to be converted
 *	buf   - Output buffer into which the conversion is done
 *	radix - The radix in which to do the conversion
 *
 * Exit:
 *	A pointer to the output string
 *
 * Exceptions:
 *
 */

char *ultoa (const unsigned long int val, char *buf, int radix)
    {
    return (_xtoa (val, buf, radix, 0));
    }
