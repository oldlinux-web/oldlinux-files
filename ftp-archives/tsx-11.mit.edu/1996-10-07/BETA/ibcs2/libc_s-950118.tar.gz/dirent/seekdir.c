#include <unistd.h>
#include <errno.h>
#include <dirent.h>
#undef lseek

void _seekdir(DIR * dir, off_t offset)
{
  if (!dir) {
    errno = EBADF;
    return;
  }
  _lseek(dir->dd_fd,offset,SEEK_SET);
}


#ifdef ELF_LIBRARY
__asm__(".weak seekdir; seekdir = _seekdir");
#endif
