#include <syscall.h>
#include "lcall7.h"


int
lcall7(int opcode, ...)
{
	register int res;

	__asm__ volatile ("addl $4,%%esp\n"
			".byte\t0x9a,0,0,0,0,7,0\n"
			"\tsubl $4,%%esp\n\t"
			: "=a" (res)
			: "0" (opcode));

	if (__check_errno(res))
		return res;
	errno = -res;
	return -1;
}
