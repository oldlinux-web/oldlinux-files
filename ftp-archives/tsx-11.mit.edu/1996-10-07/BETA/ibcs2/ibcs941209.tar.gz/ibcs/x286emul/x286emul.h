#ifndef _X286EMUL_H_
#define _X286EMUL_H_

extern unsigned long init_entry, init_cs, init_ds, limit_stk, init_stk;

extern struct xexec *xexec;
extern struct xext *xext;

#endif /* _X286EMUL_H_ */
