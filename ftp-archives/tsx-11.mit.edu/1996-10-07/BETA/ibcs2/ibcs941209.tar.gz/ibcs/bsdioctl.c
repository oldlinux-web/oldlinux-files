/*
 *  linux/ibcs/bsdioctl.c
 *
 *  Copyright (C) 1994  Mike Jagdis
 *
 * $Id: bsdioctl.c,v 1.7 1994/12/08 11:56:33 mike Exp $
 * $Source: /var/CVS/ibcs/bsdioctl.c,v $
 */

#include <linux/config.h>

#include <asm/segment.h>
#ifndef KERNEL_DS
#include <linux/segment.h>
#endif

#include <linux/errno.h>
#include <linux/stat.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/kernel.h>
#include <linux/sys.h>
#include <linux/termios.h>
#include <linux/time.h>

#include <ibcs/ibcs.h>
#include <ibcs/bsd.h>

#ifdef IBCS_TRACE
#include <ibcs/trace.h>
#endif


#define BSD_NCCS 20
struct bsd_termios {
	unsigned long	c_iflag;
	unsigned long	c_oflag;
	unsigned long	c_cflag;
	unsigned long	c_lflag;
	unsigned char	c_cc[BSD_NCCS];
	long		c_ispeed;
	long		c_ospeed;
};

static unsigned long speed_map[] = {
	0, 50, 75, 110, 134, 150, 200, 300, 600, 1200, 1800, 2400,
	4800, 9600, 19200, 38400
};

static unsigned long
bsd_to_linux_speed(unsigned long s)
{
	int i;

#ifdef B57600
	if (s == 57600)
		return B57600;
#endif
#ifdef B115200
	if (s == 115200)
		return B115200;
#endif
	
	for (i=0; i<sizeof(speed_map)/sizeof(speed_map[0]); i++)
		if (s <= speed_map[i])
			return i;
	return B38400;
}

static unsigned long
linux_to_bsd_speed(unsigned long s)
{
#ifdef B57600
	if (s == B57600)
		return 57600;
#endif
#ifdef B115200
	if (s == B115200)
		return 115200;
#endif
	return speed_map[s];
}


static int
bsd_to_linux_termios(int fd, int op, struct bsd_termios *it)
{
	struct termios t;
	int old_fs;
	unsigned long temp;
	char bsd_cc[BSD_NCCS];
	int error;

	error = verify_area(VERIFY_READ, it, sizeof(struct bsd_termios));
	if (error)
		return error;

	old_fs = get_fs();
	set_fs(get_ds());
	error = SYS(ioctl)(fd, TCGETS, &t);
	set_fs(old_fs);
	if (error)
		return error;

	t.c_iflag = get_fs_long(&it->c_iflag);
	t.c_iflag = (t.c_iflag & ~0xc00)
			| ((t.c_iflag & 0x400) << 1)
			| ((t.c_iflag & 0x800) >> 1);

	temp = get_fs_long(&it->c_oflag);
	t.c_oflag = (t.c_oflag & ~0x1805)
			| (temp & 9)
			| ((temp & 2) << 1)
			| ((temp & 4) << 10)
			| ((temp & 4) << 9);

	temp = get_fs_long(&it->c_cflag);
	t.c_cflag = (t.c_cflag & ~0xfff)
			| ((temp & 0xff00) >> 4);
	if (t.c_cflag & 0x30000)
		t.c_cflag |= 020000000000;
	t.c_cflag |= bsd_to_linux_speed(get_fs_long(&it->c_ospeed))
		| (bsd_to_linux_speed(get_fs_long(&it->c_ispeed)) << 16);

	temp = get_fs_long(&it->c_lflag);
	t.c_lflag = (t.c_lflag & ~0157663)
			| ((temp & 1) << 12)
			| ((temp & 0x46) << 3)
			| ((temp & 0x420) << 5)
			| ((temp & 0x180) >> 7)
			| ((temp & 0x400000) >> 14)
			| ((temp & 0x2800000) >> 11)
			| ((temp & 0x80000000) >> 24);

	memcpy_fromfs(bsd_cc, &it->c_cc, BSD_NCCS);
	t.c_cc[VEOF] = bsd_cc[0];
	t.c_cc[VEOL] = bsd_cc[1];
	t.c_cc[VEOL2] = bsd_cc[2];
	t.c_cc[VERASE] = bsd_cc[3];
	t.c_cc[VWERASE] = bsd_cc[4];
	t.c_cc[VKILL] = bsd_cc[5];
	t.c_cc[VREPRINT] = bsd_cc[6];
	t.c_cc[VSWTC] = bsd_cc[7];
	t.c_cc[VINTR] = bsd_cc[8];
	t.c_cc[VQUIT] = bsd_cc[9];
	t.c_cc[VSUSP] = bsd_cc[10];
/*	t.c_cc[VDSUSP] = bsd_cc[11];*/
	t.c_cc[VSTART] = bsd_cc[12];
	t.c_cc[VSTOP] = bsd_cc[13];
	t.c_cc[VLNEXT] = bsd_cc[14];
	t.c_cc[VDISCARD] = bsd_cc[15];
	t.c_cc[VMIN] = bsd_cc[16];
	t.c_cc[VTIME] = bsd_cc[17];
/*	t.c_cc[VSTATUS] = bsd_cc[18];*/

	set_fs(get_ds());
	error = SYS(ioctl)(fd, op, &t);
	set_fs(old_fs);

	return error;
}


static int
linux_to_bsd_termios(int fd, int op, struct bsd_termios *it)
{
	struct termios t;
	char bsd_cc[BSD_NCCS];
	int old_fs;
	int error;

	error = verify_area(VERIFY_WRITE, it, sizeof(struct bsd_termios));
	if (error)
		return error;

	old_fs = get_fs();
	set_fs(get_ds());
	error = SYS(ioctl)(fd, op, &t);
	set_fs(old_fs);
	if (error)
		return error;

	put_fs_long((t.c_iflag & 0777)
			| ((t.c_iflag & 02000) >> 1)
			| ((t.c_iflag & 010000) >> 2)
			| ((t.c_iflag & 020000) >> 4),
		&it->c_iflag);

	put_fs_long((t.c_oflag & 1)
			| ((t.c_oflag & 04) >> 1)
			| ((t.c_oflag & 014000) == 014000 ? 4 : 0),
		&it->c_oflag);

	put_fs_long((t.c_cflag & ~020000007777)
			| ((t.c_cflag & 0xff0) << 4)
			| ((t.c_cflag & 020000000000) ? 0x30000 : 0),
		&it->c_cflag);

	put_fs_long(linux_to_bsd_speed(t.c_cflag & CBAUD), &it->c_ospeed);
	if ((t.c_cflag & CIBAUD) != 0)
		put_fs_long(linux_to_bsd_speed((t.c_cflag & CIBAUD) >> 16),
			&it->c_ispeed);
	else
		put_fs_long(linux_to_bsd_speed(t.c_cflag & CBAUD),
			&it->c_ispeed);

	put_fs_long((t.c_lflag & 07777626010)
			| ((t.c_lflag & 03) << 7)
			| ((t.c_lflag & 01160) >> 3)
			| ((t.c_lflag & 0400) << 14)
			| ((t.c_lflag & 02000) >> 4)
			| ((t.c_lflag & 04000) >> 11)
			| ((t.c_lflag & 010000) << 11)
			| ((t.c_lflag & 040000) << 15)
			| ((t.c_lflag & 0100000) >> 5),
		&it->c_lflag);

	bsd_cc[0] = t.c_cc[VEOF];
	bsd_cc[1] = t.c_cc[VEOL];
	bsd_cc[2] = t.c_cc[VEOL2];
	bsd_cc[3] = t.c_cc[VERASE];
	bsd_cc[4] = t.c_cc[VWERASE];
	bsd_cc[5] = t.c_cc[VKILL];
	bsd_cc[6] = t.c_cc[VREPRINT];
	bsd_cc[7] = t.c_cc[VSWTC];
	bsd_cc[8] = t.c_cc[VINTR];
	bsd_cc[9] = t.c_cc[VQUIT];
	bsd_cc[10] = t.c_cc[VSUSP];
	bsd_cc[11] = t.c_cc[VSUSP];
	bsd_cc[12] = t.c_cc[VSTART];
	bsd_cc[13] = t.c_cc[VSTOP];
	bsd_cc[14] = t.c_cc[VLNEXT];
	bsd_cc[15] = t.c_cc[VDISCARD];
	bsd_cc[16] = t.c_cc[VMIN];
	bsd_cc[17] = t.c_cc[VTIME];
	bsd_cc[18] = 0; /* t.c_cc[VSTATUS]; */
	bsd_cc[19] = 0;

	memcpy_tofs(&it->c_cc, bsd_cc, BSD_NCCS);

	return error;
}


int
bsd_ioctl_termios(int fd, unsigned int func, void *arg)
{
	switch (func) {
		case BSD__IO('t', 13):				/* TIOEXCL */
			return SYS(ioctl)(fd, TIOCEXCL, arg);

		case BSD__IO('t', 14):				/* TIOCNXCL */
			return SYS(ioctl)(fd, TIOCNXCL, arg);

		case BSD__IOW('t', 16, int):			/* TIOCFLUSH */
			return SYS(ioctl)(fd, TCFLSH, arg);

		case BSD__IOR('t', 19, struct bsd_termios):	/* TIOCGETA */
			return linux_to_bsd_termios(fd, TCGETS, arg);

		case BSD__IOW('t', 20, struct bsd_termios):	/* TIOCSETA */
			return bsd_to_linux_termios(fd, TCSETS, arg);

		case BSD__IOW('t', 21, struct bsd_termios):	/* TIOCSETAW */
			return bsd_to_linux_termios(fd, TCSETSW, arg);

		case BSD__IOW('t', 22, struct bsd_termios):	/* TIOCSETAF */
 			return bsd_to_linux_termios(fd, TCSETSF, arg);

		case BSD__IOR('t', 0, int):			/* TIOCGETD */
			return -EINVAL;

		case BSD__IOR('t', 26, int):			/* TIOCGETD */
			return SYS(ioctl)(fd, TIOCGETD, arg);

		case BSD__IOW('t', 1, int):			/* TIOCSETD */
			return -EINVAL;

		case BSD__IOW('t', 27, int):			/* TIOCSETD */
			return SYS(ioctl)(fd, TIOCSETD, arg);

		case BSD__IO('t', 97):				/* TIOCSCTTY */
			return SYS(ioctl)(fd, TIOCSCTTY, arg);

		case BSD__IOW('t', 103, struct winsize):	/* TIOCSWINSZ */
			return SYS(ioctl)(fd, TIOCSWINSZ, arg);

		case BSD__IOR('t', 104, struct winsize):	/* TIOCGWINSZ */
			return SYS(ioctl)(fd, TIOCGWINSZ, arg);

		case BSD__IO('t', 113):				/* TIOCNOTTY */
			return SYS(ioctl)(fd, TIOCNOTTY, arg);

		case BSD__IOW('t', 118, int):			/* TIOCSPGRP */
			return SYS(ioctl)(fd, TIOCSPGRP, arg);

		case BSD__IOR('t', 119, int):			/* TIOCGPGRP */
			return SYS(ioctl)(fd, TIOCGPGRP, arg);

		case BSD__IO('t', 123):				/* TIOCSBRK */
			return SYS(ioctl)(fd, TCSBRK, arg);

		case BSD__IOR('t', 3, int):			/* TIOCMODG */
		case BSD__IOW('t', 4, int):			/* TIOCMODS */
		case BSD__IO('t', 122):				/* TIOCCBRK */
		case BSD__IO('t', 121):				/* TIOCSDTR */
		case BSD__IO('t', 120):				/* TIOCCDTR */
		case BSD__IOR('t', 115, int):			/* TIOCOUTQ */
		case BSD__IOW('t', 114, char):			/* TIOCSTI */
		case BSD__IOW('t', 112, int):			/* TIOCPKT */
		case BSD__IO('t', 111):				/* TIOCSTOP */
		case BSD__IO('t', 110):				/* TIOCSTART */
		case BSD__IOW('t', 109, int):			/* TIOCMSET */
		case BSD__IOW('t', 108, int):			/* TIOCMBIS */
		case BSD__IOW('t', 107, int):			/* TIOCMBIC */
		case BSD__IOR('t', 106, int):			/* TIOCMGET */
		case BSD__IOW('t', 105, int):			/* TIOCREMOTE */
		case BSD__IOW('t', 102, int):			/* TIOCUCNTL */
		case BSD__IOW('t', 98, int):			/* TIOCCONS */
		case BSD__IOW('t', 96, int):			/* TIOCEXT */
		case BSD__IO('t', 95):				/* TIOCSIG */
		case BSD__IO('t', 94):				/* TIOCDRAIN */
	}

	printk(KERN_ERR "BSD: termios ioctl 0x%08lx unsupported\n",
		(unsigned long)func);
	return -EINVAL;
}
