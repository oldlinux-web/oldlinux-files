#include <stdio.h>
#include <trace.h>

/**********************************************************************
 * 
 * Function:       fgetc
 *
 * Description:
 *    Read the next character from the indicated file.
 *
 * Input:
 *    stream    - Pointer to the input stream
 *
 * Result:
 *    The input character or EOF to indicate an error/EOF condition.
 */

#undef fgetc
int fgetc (FILE *stream)
    {
    int answer;
    FUNC_ENTRY ("fgetc");
    answer = getc (stream);
    FUNC_EXIT ("fgetc");
    return (answer);
    }
