#include <stdio.h>
#include <trace.h>
/**************************************************************************
 *
 * Function:   _clearerr
 *
 * Description:
 *    Reset the ERR and EOF conditions on the file
 *
 * Input:
 *    stream    - Pointer to the file to be reset
 *
 * Result:
 *    none.
 */

#undef	_clearerr
void _clearerr (FILE *stream)
    {
    FUNC_ENTRY ("_clearerr");
    __scerror (stream);
    FUNC_EXIT ("_clearerr");
    }
