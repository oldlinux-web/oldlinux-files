#include <stdio.h>
#include "file2.h"
#include "internal.h"
#include <trace.h>

/**************************************************************************
 *
 * Function:   fputchar
 *
 * Description:
 *    This function performs the same action as the macro putchar. It will
 *    write a character to the stdout file.
 *
 * Input:
 *    nChar     - Character to be written
 *
 * Output:
 *    The output character or EOF to indicate an abnormal condition.
 *
 */

int fputchar (int nChar)
    {
    int answer;
    FUNC_ENTRY ("fputchar");
    answer = putchar (nChar);
    FUNC_EXIT ("fputchar");
    return (answer);
    }
