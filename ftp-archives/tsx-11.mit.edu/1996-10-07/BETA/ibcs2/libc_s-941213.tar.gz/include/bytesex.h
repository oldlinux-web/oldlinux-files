#ifndef _BYTESEX_H
#define _BYTESEX_H

#undef __BYTE_ORDER
#define __BYTE_ORDER	1234

#endif /* _BYTESEX_H */
