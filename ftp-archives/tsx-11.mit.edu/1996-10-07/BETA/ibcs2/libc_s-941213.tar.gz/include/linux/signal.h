#ifndef  _IBCS_SIGNAL_H
#define  _IBCS_SIGNAL_H

#define  SIGHUP       1
#define  SIGINT       2
#define  SIGQUIT      3
#define  SIGILL       4
#define  SIGTRAP      5
#define  SIGIOT       6
#define  SIGABRT      6
#define  SIGEMT       7
#define  SIGFPE       8
#define  SIGKILL      9
#define  SIGBUS      10
#define  SIGSEGV     11
#define  SIGSYS      12
#define  SIGPIPE     13
#define  SIGALRM     14
#define  SIGUSR1     16
#define  SIGUSR2     17
#define  SIGCLD      18
#define  SIGCHLD     18
#define  SIGPWR      19
#define  SIGWINCH    20
#define  SIGPOLL     22

#define  SIG_DFL     ((void (*)()) 0)
#define  SIG_ERR     ((void (*)()) -1)
#define  SIG_IGN     ((void (*)()) 1)
#define  SIG_HOLD    ((void (*)()) 2)

#define  SIG_SETMASK  0
#define  SIG_BLOCK    1
#define  SIG_UNBLOCK  2

typedef long  sigset_t;

struct sigaction {
       void      (*sa_handler)();
       sigset_t  sa_mask;
       int       sa_flags;
};

#define SA_NOCLDSTOP   1

typedef void (*__sighandler_t)(int);

#endif
