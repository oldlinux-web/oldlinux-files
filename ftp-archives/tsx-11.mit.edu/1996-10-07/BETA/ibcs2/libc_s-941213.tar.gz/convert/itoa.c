#include <stdlib.h>
#include "internal.h"

/*
 * char *itoa(val,buf,radix) - Convert the input integer to an ascii string
 *
 * Purpose:
 *	This routine will translate the input integer to the corresponding
 *	ascii string in the specified radix. The input is assumed to be a
 *	signed integer.
 *
 * Entry:
 *	val   - Input integer to be converted
 *	*buf  - Output buffer into which the conversion is done
 *	radix - The radix in which to do the conversion
 *
 * Exit:
 *	A pointer to the output string
 *
 * Exceptions:
 *
 */

char *itoa (const int val, char *buf, const int radix)
    {
    return (_xtoa ((long int) val, buf, radix, 1));
    }
