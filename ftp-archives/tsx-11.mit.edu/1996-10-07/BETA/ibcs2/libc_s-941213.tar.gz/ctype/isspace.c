#include <ctype.h>
#undef isspace
int isspace(int c) { return __isspace(c); }
