#include <ctype.h>
#undef isdigit
int isdigit(int c) { return __isdigit(c); }
