#include <ctype.h>
#undef isascii

#ifdef ELF_LIBRARY
#define isascii _isascii
#endif

int isascii(int c) { return __isascii(c); }

#ifdef ELF_LIBRARY
__asm__(".weak isascii; isascii = _isascii");
#endif
