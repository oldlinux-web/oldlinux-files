#ifndef COFF_LIBRARY
int errno;
#endif
