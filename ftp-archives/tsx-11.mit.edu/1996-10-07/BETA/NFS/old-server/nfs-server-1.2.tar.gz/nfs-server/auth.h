#include "mount.h"

extern int promiscuous;
extern int allow_non_root;
extern int auth_initialized;
extern exportnode *export_list;
