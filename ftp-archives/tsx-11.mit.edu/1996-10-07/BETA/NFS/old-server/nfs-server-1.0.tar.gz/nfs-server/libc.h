/* libc.h - prototypes for system functions - rick sladkey */

#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <errno.h>

extern int h_errno;

#define MAXNAMLEN	NAME_MAX
