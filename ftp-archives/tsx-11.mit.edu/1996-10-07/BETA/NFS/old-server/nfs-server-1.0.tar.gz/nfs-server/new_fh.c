/*****************************************************************************\
*									      *
*	File:     new_fh.c						      *
*	Author:   Don Becker						      *
*	Created:  Fri Jun 16 16:09:08 1989				      *
*	Contents: New files for fh.c.					      *
*									      *
******************************************************************************/


void
fh_remove(path)
     char *path;
{
    int psi;
    nfsstat status;
    fhcache *fhc;

    psi = path_psi(path, &status, NULL);
    if (psi == 0)
	return;
    ex_state = active;
    fhc = fh_lookup(psi);
    if (fhc != NULL)
	fh_delete(fhc);

    ex_state = idle;
    return;
}
