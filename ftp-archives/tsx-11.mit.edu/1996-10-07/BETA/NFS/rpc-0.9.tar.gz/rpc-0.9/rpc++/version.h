// version.h,v 2.3 1992/12/06 18:57:57 mnl Exp
#ifndef _RPCPLPL_VERSION_H_
static char* version = "rpc++-library, version 2.3"
#endif
