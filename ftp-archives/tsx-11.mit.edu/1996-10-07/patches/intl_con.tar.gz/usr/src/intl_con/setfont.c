#include <stdio.h>
#include <memory.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/kd.h>

main(argc,argv)
int argc;
char *argv[];
{
	FILE *fp;
	struct stat stbuf;
	char buf[8192];
	int i,unit;

	if (argc < 2)
	{
		fprintf(stderr,"Loading EGA/VGA font\n",argv[0]);
		fprintf(stderr,"usage: %s font-file\n",argv[0]);
		exit(1);
	}
	if (stat(argv[1],&stbuf))
	{
		perror("Cannot stat font file");
		exit(1);
	}
	switch (stbuf.st_size)
	{
	case 2048:	unit= 8; break;
	case 3584:	unit=14; break;
	case 4096:	unit=16; break;
	default:	fprintf(stderr,"Can load only 8x8,8x14,8x16 fonts");
			exit(1);
	}
	if ((fp=fopen(argv[1],"r")) == NULL)
	{
		perror("Cannot open font file");
		exit(1);
	}

	memset(buf,0,sizeof(buf));

	for (i=0;i<256;i++)
	if (fread(buf+(32*i),unit,1,fp) != 1)
	{
		perror("Cannot read font from file");
		exit(1);
	}
	fclose(fp);

	printf("Loading 8x%d font from file %s\n",unit,argv[1]);

	i=ioctl(0,PIO_FONT,buf);
	if (i) perror("PIO_FONT ioctl error");

	return(i);
}
