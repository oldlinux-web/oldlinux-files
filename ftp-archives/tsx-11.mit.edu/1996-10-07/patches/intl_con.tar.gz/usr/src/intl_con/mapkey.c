#include <stdio.h>
#include <memory.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/kd.h>

static int parsekeymap(FILE *,struct kd_keymap *);

static struct kd_keymap buf = {
	{ 0,   27,  '1',  '2',  '3',  '4',  '5',  '6',
	'7',  '8',  '9',  '0',  '-',  '=',  127,    9,
	'q',  'w',  'e',  'r',  't',  'y',  'u',  'i',
	'o',  'p',  '[',  ']',   13,    0,  'a',  's',
	'd',  'f',  'g',  'h',  'j',  'k',  'l',  ';',
	'\'', '`',    0, '\\',  'z',  'x',  'c',  'v',
	'b',  'n',  'm',  ',',  '.',  '/',    0,  '*',
	  0,   32,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,  '-',    0,    0,    0,  '+',    0,
	  0,    0,    0,    0,    0,    0,  '<',    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0},

	{ 0,   27,  '!',  '@',  '#',  '$',  '%',  '^',
	'&',  '*',  '(',  ')',  '_',  '+',  127,    9,
	'Q',  'W',  'E',  'R',  'T',  'Y',  'U',  'I',
	'O',  'P',  '{',  '}',   13,    0,  'A',  'S',
	'D',  'F',  'G',  'H',  'J',  'K',  'L',  ':',
	'"',  '~',  '0',  '|',  'Z',  'X',  'C',  'V',
	'B',  'N',  'M',  '<',  '>',  '?',    0,  '*',
	  0,   32,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,  '-',    0,    0,    0,  '+',    0,
	  0,    0,    0,    0,    0,    0,  '>',    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0},

	{ 0,    0,    0,  '@',    0,  '$',    0,    0,
	'{',   '[',  ']', '}', '\\',    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,  '~',   13,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,  '|',    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0},

	{ 0,    0,    0,  '@',    0,  '$',    0,    0,
	'{',   '[',  ']', '}', '\\',    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,  '~',   13,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0,    0,    0,    0,    0,    0,  '|',    0,
	  0,    0,    0,    0,    0,    0,    0,    0,
	  0},

	{0x00, 0x00, 0xFF, 0xC3, 0xFE, 0x0F, 
	 0xE0, 0x00, 0x00, 0x00, 0x00, 0x00},

	{0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},

	{0x00}
};

main(argc,argv)
int argc;
char *argv[];
{
	FILE *fp;
	struct stat stbuf;
	int i,unit;

	if (argc < 2)
	{
		fprintf(stderr,"Load keyboard mapping tables\n",argv[0]);
		fprintf(stderr,"usage: %s map-file\n",argv[0]);
		exit(1);
	}
	if (stat(argv[1],&stbuf))
	{
		perror("Cannot stat map file");
		exit(1);
	}
	if ((fp=fopen(argv[1],"r")) == NULL)
	{
		perror("Cannot open map file");
		exit(1);
	}
	if (stbuf.st_size != sizeof(struct kd_keymap))
	{
		printf("Loading symbolic keymap from file %s\n",argv[1]);

		if (parsekeymap(fp,&buf))
		{
			fprintf(stderr,"Invalid symbolic keymap in file %s\n",
				argv[1]);
			exit(1);
		}
	}
	else
	{
		printf("Loading binary keymap from file %s\n",argv[1]);

		if (fread(&buf,sizeof(struct kd_keymap),1,fp) != 1)
		{
			perror("Cannot read map file");
			exit(1);
		}
	}
	fclose(fp);

	i=ioctl(0,KDSKBMAP,&buf);

	if (i) perror("KDSKBMAP ioctl error");

	return(i);
}

static int parsekeymap(fp,keymap)
FILE *fp;
struct kd_keymap *keymap;
{
	char buffer[256],*p,*sc,*nm,*sm,*cl,*am,*sam,*acl;
	int ln=0,rc=0,i;

	while (fgets(buffer,sizeof(buffer)-1,fp))
	{
		ln++;

		if (*(p=buffer+strlen(buffer)-1) != '\n')
		{
			fprintf(stderr,"error on line %d: too long\n",ln);
			rc=1;
			break;
		}
		else *p='\0';

		if (p=strchr(buffer,'#')) 
		{
			if ((*(p-1) != '\'') && (*(p+1) != '\''))
				*p='\0';
		}

		sc=strtok(buffer," \t,");
		nm=strtok(NULL," \t,");
		sm=strtok(NULL," \t,");
		cl=strtok(NULL," \t,");
		am=strtok(NULL," \t,");
		sam=strtok(NULL," \t,");
		acl=strtok(NULL," \t,");

		if ((sc == NULL) &&
		    (nm == NULL) &&
		    (sm == NULL) &&
		    (am == NULL) &&
		    (sam == NULL) &&
		    (cl == NULL) &&
		    (acl == NULL))
			continue;

		if (strcmp(sc,"flags") == 0)
		{
			i=ctoi(nm);
			if (i < 256) keymap->k_diacr_flags=i;
			else fprintf(stderr,"error on line %d: bad flags\n",
				ln);
			continue;
		}

		if ((sc == NULL) ||
		    (nm == NULL) ||
		    (sm == NULL) ||
		    (am == NULL) ||
		    (sam == NULL) ||
		    (cl == NULL) ||
		    (acl == NULL))
		{
			fprintf(stderr,"error on line %d: less than 7 tokens\n",
				ln);
			rc=2;
			break;
		}

		i=ctoi(sc);
		if ((i < 1) || (i > 96))
		{
			fprintf(stderr,"error on line %d: invalid scan code\n",
				ln);
			rc=3;
			break;
		}

		if ((strlen(cl) != 1) || (strspn(cl,"yYnN") != 1) ||
		    (strlen(acl) != 1) || (strspn(acl,"yYnN") != 1))
		{
			fprintf(stderr,"error on line %d: invalid CAPS flag\n",
				ln);
			rc=4;
			break;
		}

		keymap->k_main_map[i] = ctoi(nm);
		keymap->k_shft_map[i] = ctoi(sm);
		keymap->k_alt_map[i] = ctoi(am);
		keymap->k_a_s_map[i] = ctoi(sam);
		if ((*cl == 'y') || (*cl == 'Y'))
			keymap->k_main_acaps[i/8] |= (0x80 >> i%8);
		else
			keymap->k_main_acaps[i/8] &= ~(0x80 >> i%8);
		if ((*acl == 'y') || (*acl == 'Y'))
			keymap->k_alt_acaps[i/8] |= (0x80 >> i%8);
		else
			keymap->k_alt_acaps[i/8] &= ~(0x80 >> i%8);
	}
	return(rc);
}
