/*
 * linux/fs/xenix/alloc.c
 *
 * (C) 1991  Linus Torvalds
 *
 * Taken from minix/bitmap.c, modified by Doug Evans, dje@sspiff.uucp, 92Jun04.
 *
 * This file contains code for allocating/freeing blocks and inodes.
 */

#include <linux/sched.h>
#include <linux/xenix_fs.h>
#include <linux/stat.h>
#include <linux/kernel.h>
#include <linux/string.h>
#include <linux/locks.h>

#define clear_block(addr) \
__asm__("cld\n\t" \
	"rep\n\t" \
	"stosl" \
	::"a" (0),"c" (BLOCK_SIZE/4),"D" ((long) (addr)):"cx","di")

#ifndef MIN
#define MIN(a,b)	((a) < (b) ? (a) : (b))
#endif

void
xenix_free_block(struct super_block * sb, int block)
{
	struct buffer_head * bh;
	struct xenix_free_block * xfb;

	if (!sb)
		panic("xenix_free_block: trying to free block on nonexistent device");

	DEBUGPK(xenix_blocks,
		("xenix_free_block: dev 0x%x, block %d, s_nfree %d, s_tfree %d\n",
			sb->s_dev, block, sb->s_xenix_nfree,
#ifdef XENIX_GOT_PACK_2
			sb->s_xenix_tfree
#else
			*(daddr_t *) sb->s_xenix_tfree
#endif
	));

	lock_super(sb);
	if (block < sb->s_xenix_isize || block >= sb->s_xenix_fsize) {
		printk("xenix_free_block: block=%d, isize=%d, fsize=%d\n",
			block, sb->s_xenix_isize, sb->s_xenix_fsize);
		panic("xenix_free_block: trying to free block not in datazone");
	}
	if (sb->s_xenix_nfree > 100)
		panic("xenix_free_block: s_nfree > 100");

	/*
	 * If the cached free list is full, it's copied to this block ...
	 */

	if (sb->s_xenix_nfree == 100) {
		if (!(bh = getblk(sb->s_dev, block, BLOCK_SIZE)))
			panic("xenix_free_block: getblk() failed");
		xfb = (struct xenix_free_block *) bh->b_data;
		xfb->xfb_nfree = 100;
		memcpy(xfb->xfb_free, sb->s_xenix_free, 100 * sizeof(long));
		sb->s_xenix_nfree = 0;
		bh->b_dirt = 1;
		bh->b_uptodate = 1;
		brelse(bh);
	} else {
		bh = get_hash_table(sb->s_dev, block, BLOCK_SIZE);
		if (bh)
			bh->b_dirt = 0;
		brelse(bh);
	}
#ifdef XENIX_GOT_PACK_2
	sb->s_xenix_free[sb->s_xenix_nfree] = block;
#else
	*((daddr_t *) sb->s_xenix_free + sb->s_xenix_nfree) = block;
#endif
	sb->s_xenix_nfree++;
#ifdef XENIX_GOT_PACK_2
	sb->s_xenix_tfree++;
#else
	++*((daddr_t *) sb->s_xenix_tfree);
#endif
	sb->s_xenix_bh->b_dirt = 1;
	unlock_super(sb);
}

int
xenix_new_block(struct super_block * sb)
{
	struct buffer_head * bh;
	struct xenix_free_block * xfb;
	int block;

	if (!sb)
		panic("xenix_new_block: trying to get new block from nonexistant device");

	DEBUGPK(xenix_blocks, ("xenix_new_block: dev 0x%x, s_nfree %d, s_tfree %d\n",
		sb->s_dev, sb->s_xenix_nfree,
#ifdef XENIX_GOT_PACK_2
		sb->s_xenix_tfree
#else
		*(daddr_t *) sb->s_xenix_tfree
#endif
	));

	if (sb->s_xenix_nfree == 0)	/* FIXME: review */
		return 0;		/* no blocks available */
	lock_super(sb);
#ifdef XENIX_GOT_PACK_2
	block = sb->s_xenix_free[--sb->s_xenix_nfree];
#else
	block = *((daddr_t *) sb->s_xenix_free + --sb->s_xenix_nfree);
#endif
	if (block == 0) {
		sb->s_xenix_nfree++;
		lock_super(sb);
		return 0;		/* no blocks available */
	}
	if (sb->s_xenix_nfree == 0) {
		if (!(bh = bread(sb->s_dev, block, BLOCK_SIZE))) {
			/* FIXME: was panic() */
			printk("xenix_new_block: cannot read free-list block\n");
			sb->s_xenix_nfree++;
			lock_super(sb);
			return 0;
		}
		xfb = (struct xenix_free_block *) bh->b_data;
		if (xfb->xfb_nfree <= 1 || xfb->xfb_nfree > 100)
			panic("xenix_new_block: free-list block with 0 or >100 entries");
		sb->s_xenix_nfree = xfb->xfb_nfree;
		memcpy(sb->s_xenix_free, xfb->xfb_free, xfb->xfb_nfree * sizeof(daddr_t));
		brelse(bh);
	}
	if (!(bh = getblk(sb->s_dev, block, BLOCK_SIZE)))
		panic("xenix_new_block: getblk() failed");
	if (bh->b_count > 1)
		panic("xenix_new_block: b_count > 1");
	bh->b_count = 1;	/* could have been 0 (brelse() above called) */
	clear_block(bh->b_data);
	bh->b_uptodate = 1;
	bh->b_dirt = 1;
	brelse(bh);
#ifdef XENIX_GOT_PACK_2
	sb->s_xenix_tfree--;
#else
	--*((daddr_t *) sb->s_xenix_tfree);
#endif
	sb->s_xenix_bh->b_dirt = 1;
	unlock_super(sb);
	return block;
}

unsigned long
xenix_count_free_blocks(struct super_block * sb)
{
#ifdef XENIX_GOT_PACK_2
	return sb->s_xenix_tfree;
#else
	return *(daddr_t *) sb->s_xenix_tfree;
#endif
}

void
xenix_free_inode(struct inode * inode)
{
	struct buffer_head * bh;
	struct xenix_inode * raw_inode;
	struct super_block * sb;

	if (!inode)
		return;
	if (!inode->i_dev) {
		printk("xenix_free_inode: inode has no device\n");
		return;
	}
	if (inode->i_count != 1) {
		printk("xenix_free_inode: inode has count=%d\n", inode->i_count);
		return;
	}
	if (inode->i_nlink) {
		printk("xenix_free_inode: inode has nlink=%d\n", inode->i_nlink);
		return;
	}
	if (!(sb = inode->i_sb)) {
		printk("xenix_free_inode: inode on nonexistent device\n");
		return;
	}

	DEBUGPK(xenix_inodes,
		("xenix_free_inode: dev 0x%x, inode %d, s_ninode %d, s_tinode %d\n",
			inode->i_dev, inode->i_ino, sb->s_xenix_ninode, sb->s_xenix_tinode
	));

	if (inode->i_ino <= XENIX_ROOT_INO ||
			inode->i_ino > sb->s_xenix_isize * XENIX_INODES_PER_BLOCK) {
		printk("xenix_free_inode: inode 0,1,2 or nonexistent inode\n");
		return;
	}
	if (sb->s_xenix_ninode < 100)
		sb->s_xenix_inode[sb->s_xenix_ninode++] = inode->i_ino;
	/* FIXME: #define 31, 16 */
	if (!(bh = bread(inode->i_dev, (inode->i_ino + 31) / 16, BLOCK_SIZE))) {
		panic("xenix_free_inode: unable to read inode block");
		/* FIXME: too severe? */
		return;
	}
	/* FIXME: #define 31, 15 */
	raw_inode = (struct xenix_inode *) bh->b_data + (inode->i_ino + 31 & 15);
#if 0
	if (raw_inode->i_nlink == 0)
		printk("xenix_free_inode: inode already free\n");
	sb->s_xenix_tinode++;
	sb->s_xenix_bh->b_dirt = 1;
#else
	/*
	 * If two tasks try to remove the file at the same time, they might
	 * both hold up at the above bread(). One will succeed first and come
	 * through here. We need to watch for the second guy ...
	 */
	if (raw_inode->i_nlink != 0) {
		sb->s_xenix_tinode++;
		sb->s_xenix_bh->b_dirt = 1;
	}
#endif
	memset(raw_inode, 0, sizeof(*raw_inode));
	bh->b_dirt = 1;
	clear_inode(inode);
}

struct inode *
xenix_new_inode(const struct inode * dir)
{
	struct super_block * sb;
	struct inode * inode;
	struct buffer_head * bh;
	struct xenix_inode * raw_inode;
	int i,j,ino,block,max_alloc;

	if (!dir || !(inode = get_empty_inode()))
		return NULL;
	sb = dir->i_sb;
	inode->i_sb = sb;
	inode->i_flags = inode->i_sb->s_flags;

	DEBUGPK(xenix_inodes,
		("xenix_new_inode: dev 0x%x, s_ninode %d, s_tinode %d\n",
			dev, sb->s_xenix_ninode, sb->s_xenix_tinode
	));

	if (sb->s_xenix_ninode == 0) {
		for (i = 0, ino = 3, block = 2, max_alloc = MIN(100, sb->s_xenix_tinode);
			i < max_alloc && block < sb->s_xenix_isize;
		) {
			if (!(bh = bread(sb->s_dev, block, BLOCK_SIZE))) {
				printk("xenix_new_inode: unable to read inode table\n");
				iput(inode);
				return NULL;
			}
			raw_inode = (struct xenix_inode *) bh->b_data;
			for (j = ino == 3 ? 2 : 0; j < 16 && i < max_alloc; j++, ino++) {
				if (raw_inode[j].i_nlink == 0)
					sb->s_xenix_inode[i++] = ino;
			}
			brelse(bh);
			block++;
		}
		if (i == 0) {
			iput(inode);
			return NULL;	/* no inodes available */
		}
		sb->s_xenix_ninode = i;
	}
	ino = sb->s_xenix_inode[--sb->s_xenix_ninode];
	inode->i_count = 1;
	inode->i_nlink = 1;
	inode->i_dev = sb->s_dev;
	inode->i_uid = current->euid;
	inode->i_gid = (dir->i_mode & S_ISGID) ? dir->i_gid : current->egid;
	inode->i_dirt = 1;
	inode->i_ino = ino;
	inode->i_mtime = inode->i_atime = inode->i_ctime = CURRENT_TIME;
	inode->i_op = NULL;
	inode->i_blocks = inode->i_blksize = 0;
	inode->i_mode = 0;		/* for xenix_write_inode() */
	inode->i_size = 0;		/* ditto */
	xenix_write_inode(inode);	/* ensure inode not allocated again */
					/* FIXME: caller may call this too. */
	inode->i_dirt = 1;		/* cleared by xenix_write_inode() */
	sb->s_xenix_tinode--;
	sb->s_xenix_bh->b_dirt = 1;
	return inode;
}

unsigned long
xenix_count_free_inodes(struct super_block * sb)
{
	return sb->s_xenix_tinode;
}
