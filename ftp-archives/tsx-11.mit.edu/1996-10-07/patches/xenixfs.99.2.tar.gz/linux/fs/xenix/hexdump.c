/* hexdump.c */

/*
 * Simple utility to dump memory in hex.
 */

#include <linux/kernel.h>

static void dump_ascii(unsigned char *buf, int start, int end);

void
hex_dump(unsigned char *buf, int count)
{
	int i,j;

	for (i = 0, j = 0; i < count; i++) {
		printk(" %02x", buf[i]);
		if ((i + 1) % 16 == 0) {
			dump_ascii(buf, j, i);
			printk("\n");
			j = i + 1;
		}
	}
	if (i % 16 != 0) {
		if (j < i)
			dump_ascii(buf, j, i);
		printk("\n");
	}
}

static void
dump_ascii(unsigned char *buf, int start, int end)
{
	int i;

	printk("    ");
	for (i = start; i <= end; i++) {
		if (buf[i] < 32)
			printk(".");
		else
			printk("%c", buf[i]);
	}
}
