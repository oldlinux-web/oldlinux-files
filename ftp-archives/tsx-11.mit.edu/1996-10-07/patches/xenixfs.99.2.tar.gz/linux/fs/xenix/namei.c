/*
 * linux/fs/xenix/namei.c
 *
 * (C) 1991  Linus Torvalds
 *
 * Taken from minix/namei.c, modified by Doug Evans, dje@sspiff.uucp, 92Jun04.
 *
 * This file contains code for looking up entries in directories.
 */

#include <linux/sched.h>
#include <linux/fs.h>
#include <linux/xenix_fs.h>
#include <linux/kernel.h>
#include <linux/string.h>
#include <linux/stat.h>
#include <linux/fcntl.h>
#include <linux/errno.h>
#include <linux/config.h>

#include <asm/segment.h>

/*
 * comment out this line if you want names > XENIX_NAME_LEN chars to be
 * truncated. Else they will be disallowed.
 */
/* #define NO_TRUNCATE */

/*
 * ok, we cannot use strncmp, as the name is not in our data space.
 * Thus we'll have to use xenix_match. No big problem. Match also makes
 * some sanity tests.
 *
 * NOTE! unlike strncmp, xenix_match returns 1 for success, 0 for failure.
 */

static int
xenix_match(int len, const char * name, struct xenix_dir_entry * de)
{
	register int same __asm__("ax");

	if (!de || !de->inode || len > XENIX_NAME_LEN)
		return 0;
	/* "" means "." ---> so paths like "/usr/lib//libc.a" work */
	/* FIXME: Do I want them to work? */
	if (!len && de->name[0] == '.' && de->name[1] == '\0')
		return 1;
	if (len < XENIX_NAME_LEN && de->name[len])
		return 0;
	__asm__("cld\n\t"
		"fs ; repe ; cmpsb\n\t"
		"setz %%al"
		:"=a" (same)
		:"0" (0),"S" ((long) name),"D" ((long) de->name),"c" (len)
		:"cx","di","si");
	return same;
}

/*
 * xenix_find_entry()
 *
 * finds an entry in the specified directory with the wanted name. It
 * returns the cache buffer in which the entry was found, and the entry
 * itself (as a parameter - res_dir). It does NOT read the inode of the
 * entry - you'll have to do that yourself if you want to.
 */

static struct buffer_head *
xenix_find_entry(struct inode * dir, const char * name, int namelen,
	struct xenix_dir_entry ** res_dir)
{
	int i,entries;
	struct buffer_head * bh;
	struct xenix_dir_entry * de;

	*res_dir = NULL;
	if (!dir)
		return NULL;
#ifdef NO_TRUNCATE
	if (namelen > XENIX_NAME_LEN)
		return NULL;
#else
	if (namelen > XENIX_NAME_LEN)
		namelen = XENIX_NAME_LEN;
#endif
	entries = dir->i_size / (sizeof (struct xenix_dir_entry));
	bh = xenix_bread(dir, 0, 0);
	if (!bh)
		return NULL;
	i = 0;
	de = (struct xenix_dir_entry *) bh->b_data;
	while (i < entries) {
		if ((char *) de >= BLOCK_SIZE + bh->b_data) {
			brelse(bh);
			bh = xenix_bread(dir, i / XENIX_DIR_ENTRIES_PER_BLOCK, 0);
			if (!bh) {
				i += XENIX_DIR_ENTRIES_PER_BLOCK;
				continue;	/* FIXME: printk error msg? */
			}
			de = (struct xenix_dir_entry *) bh->b_data;
		}
		if (xenix_match(namelen, name, de)) {
			*res_dir = de;
			return bh;
		}
		de++;
		i++;
	}
	brelse(bh);
	return NULL;
}

int
xenix_lookup(struct inode * dir, const char * name, int len,
	struct inode ** result)
{
	int ino;
	struct xenix_dir_entry * de;
	struct buffer_head * bh;

	*result = NULL;
	if (!dir)
		return -ENOENT;
	if (!S_ISDIR(dir->i_mode)) {
		iput(dir);
		return -ENOENT;
	}
	if (!(bh = xenix_find_entry(dir, name, len, &de))) {
		iput(dir);
		return -ENOENT;
	}
	ino = de->inode;
	brelse(bh);
	if (!(*result = iget(dir->i_sb, ino))) {
		iput(dir);
		return -EACCES;
	}
	iput(dir);
	return 0;
}

/*
 * xenix_add_entry()
 *
 * adds a file entry to the specified directory, using the same
 * semantics as xenix_find_entry(). It returns NULL if it failed.
 *
 * NOTE!! The inode part of 'de' is left at 0 - which means you
 * may not sleep between calling this and putting something into
 * the entry, as someone else might have used it while you slept.
 *
 * Arggh. To avoid race-conditions, we copy the name into kernel
 * space before actually writing it into the buffer...
 */

static struct buffer_head *
xenix_add_entry(struct inode * dir, const char * name, int namelen,
	struct xenix_dir_entry ** res_dir)
{
	int i;
	struct buffer_head * bh;
	struct xenix_dir_entry * de;
	char name_buffer[XENIX_NAME_LEN];

	*res_dir = NULL;
	if (!dir)
		return NULL;
	if (namelen > XENIX_NAME_LEN) {
#ifdef NO_TRUNCATE
		return NULL;
#else
		namelen = XENIX_NAME_LEN;
#endif
	}
	if (!namelen)
		return NULL;
	bh = xenix_bread(dir, 0, 0);
	if (!bh)
		return NULL;
	for (i = 0; i < XENIX_NAME_LEN; i++)
		name_buffer[i] = (i < namelen) ? get_fs_byte(name + i) : 0;
	i = 0;
	de = (struct xenix_dir_entry *) bh->b_data;
	while (1) {
		if ((char *) de >= BLOCK_SIZE + bh->b_data) {
			brelse(bh);
			bh = xenix_bread(dir, i / XENIX_DIR_ENTRIES_PER_BLOCK, 1);
			if (!bh)
				return NULL;
			de = (struct xenix_dir_entry *) bh->b_data;
		}
		if (i * sizeof(struct xenix_dir_entry) >= dir->i_size) {
			de->inode = 0;
			dir->i_size = (i + 1) * sizeof(struct xenix_dir_entry);
			dir->i_dirt = 1;
			dir->i_ctime = CURRENT_TIME;
		}
		if (!de->inode) {
			dir->i_mtime = CURRENT_TIME;
			memcpy(de->name, name_buffer, XENIX_NAME_LEN);
			bh->b_dirt = 1;
			*res_dir = de;
			return bh;
		}
		de++;
		i++;
	}
	brelse(bh);
	return NULL;
}

int
xenix_create(struct inode * dir, const char * name, int len, int mode,
	struct inode ** result)
{
	struct inode * inode;
	struct buffer_head * bh;
	struct xenix_dir_entry * de;

	*result = NULL;
	if (!dir)
		return -ENOENT;
	inode = xenix_new_inode(dir);
	if (!inode) {
		iput(dir);
		return -ENOSPC;
	}
	inode->i_op = &xenix_file_inode_operations;
	inode->i_mode = mode;
	inode->i_dirt = 1;
	bh = xenix_add_entry(dir, name, len, &de);
	if (!bh) {
		inode->i_nlink--;
		inode->i_dirt = 1;
		iput(inode);
		iput(dir);
		return -ENOSPC;
	}
	de->inode = inode->i_ino;
	bh->b_dirt = 1;
	brelse(bh);
	iput(dir);
	*result = inode;
	return 0;
}

int
xenix_mknod(struct inode * dir, const char * name, int len, int mode, int rdev)
{
	struct inode * inode;
	struct buffer_head * bh;
	struct xenix_dir_entry * de;

	if (!dir)
		return -ENOENT;
	bh = xenix_find_entry(dir, name, len, &de);
	if (bh) {
		brelse(bh);
		iput(dir);
		return -EEXIST;
	}
	inode = xenix_new_inode(dir);
	if (!inode) {
		iput(dir);
		return -ENOSPC;
	}
	inode->i_uid = current->euid;
	inode->i_mode = mode;
	inode->i_op = NULL;
	if (S_ISREG(inode->i_mode))
		inode->i_op = &xenix_file_inode_operations;
	else if (S_ISDIR(inode->i_mode)) {
		inode->i_op = &xenix_dir_inode_operations;
		if (dir->i_mode & S_ISGID)
			inode->i_mode |= S_ISGID;
	} else if (S_ISLNK(inode->i_mode))
		inode->i_op = &xenix_symlink_inode_operations;
	else if (S_ISCHR(inode->i_mode))
		inode->i_op = &xenix_chrdev_inode_operations;
	else if (S_ISBLK(inode->i_mode))
		inode->i_op = &xenix_blkdev_inode_operations;
	else if (S_ISFIFO(inode->i_mode)) {
		inode->i_op = &xenix_fifo_inode_operations;
		inode->i_pipe = 1;
		PIPE_BASE(*inode) = NULL;
		PIPE_HEAD(*inode) = PIPE_TAIL(*inode) = 0;
		PIPE_READ_WAIT(*inode) = PIPE_WRITE_WAIT(*inode) = NULL;
		PIPE_READERS(*inode) = PIPE_WRITERS(*inode) = 0;
	}
	if (S_ISBLK(mode) || S_ISCHR(mode))
		inode->i_rdev = rdev;
	inode->i_mtime = inode->i_atime = CURRENT_TIME;
	inode->i_dirt = 1;
	bh = xenix_add_entry(dir, name, len, &de);
	if (!bh) {
		inode->i_nlink--;
		inode->i_dirt = 1;
		iput(inode);
		iput(dir);
		return -ENOSPC;
	}
	de->inode = inode->i_ino;
	bh->b_dirt = 1;
	brelse(bh);
	iput(dir);
	iput(inode);
	return 0;
}

int
xenix_mkdir(struct inode * dir, const char * name, int len, int mode)
{
	struct inode * inode;
	struct buffer_head * bh, * dir_block;
	struct xenix_dir_entry * de;
	
	bh = xenix_find_entry(dir, name, len, &de);
	if (bh) {
		brelse(bh);
		iput(dir);
		return -EEXIST;
	}
	inode = xenix_new_inode(dir);
	if (!inode) {
		iput(dir);
		return -ENOSPC;
	}
	inode->i_op = &xenix_dir_inode_operations;
	inode->i_size = 2 * sizeof (struct xenix_dir_entry);
	inode->i_mtime = inode->i_atime = CURRENT_TIME;
	dir_block = xenix_bread(inode, 0, 1);
	if (!dir_block) {
		iput(dir);
		inode->i_nlink--;
		inode->i_dirt = 1;
		iput(inode);
		return -ENOSPC;
	}
	de = (struct xenix_dir_entry *) dir_block->b_data;
	de->inode = inode->i_ino;
	strcpy(de->name, ".");
	de++;
	de->inode = dir->i_ino;
	strcpy(de->name, "..");
	inode->i_nlink = 2;
	dir_block->b_dirt = 1;
	brelse(dir_block);
	inode->i_mode = S_IFDIR | (mode & 0777 & ~current->umask);
	if (dir->i_mode & S_ISGID)
		inode->i_mode |= S_ISGID;
	inode->i_dirt = 1;
	bh = xenix_add_entry(dir, name, len, &de);
	if (!bh) {
		iput(dir);
		inode->i_nlink = 0;
		iput(inode);
		return -ENOSPC;
	}
	de->inode = inode->i_ino;
	bh->b_dirt = 1;
	dir->i_nlink++;
	dir->i_dirt = 1;
	iput(dir);
	iput(inode);
	brelse(bh);
	return 0;
}

/*
 * routine to check that the specified directory is empty (for rmdir)
 */

static int
empty_dir(struct inode * inode)
{
	int nr,len;
	struct buffer_head * bh;
	struct xenix_dir_entry * de;

	len = inode->i_size / sizeof (struct xenix_dir_entry);
	if (len < 2 || !(bh = xenix_bread(inode, 0, 0))) {
	    	printk("xenix_empty_dir: warning - bad directory on dev %04x\n", inode->i_dev);
		return 1;
	}
	de = (struct xenix_dir_entry *) bh->b_data;
	if (de[0].inode != inode->i_ino || !de[1].inode || 
	    strcmp(".", de[0].name) || strcmp("..", de[1].name)) {
	    	printk("xenix_empty_dir: warning - bad directory on dev %04x\n", inode->i_dev);
		return 1;
	}
	nr = 2;
	de += 2;
	while (nr < len) {
		if ((void *) de >= (void *) (bh->b_data + BLOCK_SIZE)) {
			brelse(bh);
			bh = xenix_bread(inode, nr / XENIX_DIR_ENTRIES_PER_BLOCK, 0);
			if (!bh) {
				nr += XENIX_DIR_ENTRIES_PER_BLOCK;
				continue;
			}
			de = (struct xenix_dir_entry *) bh->b_data;
		}
		if (de->inode) {
			brelse(bh);
			return 0;
		}
		de++;
		nr++;
	}
	brelse(bh);
	return 1;
}

int
xenix_rmdir(struct inode * dir, const char * name, int len)
{
	int retval;
	struct inode * inode;
	struct buffer_head * bh;
	struct xenix_dir_entry * de;

	inode = NULL;
	bh = xenix_find_entry(dir, name, len, &de);
	retval = -ENOENT;
	if (!bh)
		goto end_rmdir;
	retval = -EPERM;
	if (!(inode = iget(dir->i_sb, de->inode)))
		goto end_rmdir;
	if ((dir->i_mode & S_ISVTX) && current->euid &&
			inode->i_uid != current->euid)
		goto end_rmdir;
	if (inode->i_dev != dir->i_dev)
		goto end_rmdir;
	if (inode == dir)	/* we may not delete ".", but "../dir" is ok */
		goto end_rmdir;
	if (!S_ISDIR(inode->i_mode)) {
		retval = -ENOTDIR;
		goto end_rmdir;
	}
	if (!empty_dir(inode)) {
		retval = -ENOTEMPTY;
		goto end_rmdir;
	}
	if (inode->i_count > 1) {
		retval = -EBUSY;
		goto end_rmdir;
	}
	if (inode->i_nlink != 2)
		printk("xenix_rmdir: empty directory has nlink!=2 (%d)\n", inode->i_nlink);
	de->inode = 0;
	bh->b_dirt = 1;
	inode->i_nlink = 0;
	inode->i_dirt = 1;
	dir->i_nlink--;
	dir->i_ctime = dir->i_mtime = CURRENT_TIME;
	dir->i_dirt = 1;
	retval = 0;
end_rmdir:
	iput(dir);
	iput(inode);
	brelse(bh);
	return retval;
}

int
xenix_unlink(struct inode * dir, const char * name, int len)
{
	int retval;
	struct inode * inode;
	struct buffer_head * bh;
	struct xenix_dir_entry * de;

repeat:
	retval = -ENOENT;
	inode = NULL;
	bh = xenix_find_entry(dir, name, len, &de);
	if (!bh)
		goto end_unlink;
	if (!(inode = iget(dir->i_sb, de->inode)))
		goto end_unlink;
	if (de->inode != inode->i_ino) {
		iput(inode);
		brelse(bh);
		current->counter = 0;
		schedule();
		goto repeat;
	}
	retval = -EPERM;
	if ((dir->i_mode & S_ISVTX) && !suser() &&
			current->euid != inode->i_uid &&
			current->euid != dir->i_uid)
		goto end_unlink;
	if (S_ISDIR(inode->i_mode))
		goto end_unlink;
	if (!inode->i_nlink) {
		printk("xenix_unlink: deleting nonexistent file (%04x:%d), %d\n",
			inode->i_dev, inode->i_ino, inode->i_nlink);
		inode->i_nlink = 1;
	}
	de->inode = 0;
	bh->b_dirt = 1;
	dir->i_ctime = dir->i_mtime = CURRENT_TIME;
	dir->i_dirt = 1;
	inode->i_nlink--;
	inode->i_ctime = CURRENT_TIME;
	inode->i_dirt = 1;
	retval = 0;
end_unlink:
	brelse(bh);
	iput(inode);
	iput(dir);
	return retval;
}

int
xenix_symlink(struct inode * dir, const char * name, int len, const char * symname)
{
#if !defined(XENIX_KLUDGE_SYMLINKS) && !defined(XENIX_REAL_SYMLINKS)
	return -ENOSYS; /* FIXME: for now */
#else
	struct xenix_dir_entry * de;
	struct inode * inode = NULL;
	struct buffer_head * bh = NULL, * name_block = NULL;
	int i;
	char c;

	if (!(inode = xenix_new_inode(dir))) {
		iput(dir);
		return -ENOSPC;
	}
	inode->i_mode = S_IFLNK | 0777;
	inode->i_op = &xenix_symlink_inode_operations;
	name_block = xenix_bread(inode, 0, 1);
	if (!name_block) {
		iput(dir);
		inode->i_nlink--;
		inode->i_dirt = 1;
		iput(inode);
		return -ENOSPC;
	}
	i = 0;
	while (i < 1023 && (c = get_fs_byte(symname++)))
		name_block->b_data[i++] = c;
	name_block->b_data[i] = 0;
	name_block->b_dirt = 1;
	brelse(name_block);
	inode->i_size = i;
	inode->i_dirt = 1;
	bh = xenix_find_entry(dir, name, len, &de);
	if (bh) {
		inode->i_nlink--;
		inode->i_dirt = 1;
		iput(inode);
		brelse(bh);
		iput(dir);
		return -EEXIST;
	}
	bh = xenix_add_entry(dir, name, len, &de);
	if (!bh) {
		inode->i_nlink--;
		inode->i_dirt = 1;
		iput(inode);
		iput(dir);
		return -ENOSPC;
	}
	de->inode = inode->i_ino;
	bh->b_dirt = 1;
	brelse(bh);
	iput(dir);
	iput(inode);
	return 0;
#endif
}

int
xenix_link(struct inode * oldinode, struct inode * dir, const char * name, int len)
{
	struct xenix_dir_entry * de;
	struct buffer_head * bh;

	if (S_ISDIR(oldinode->i_mode)) {
		iput(oldinode);
		iput(dir);
		return -EPERM;
	}
	if (oldinode->i_nlink > 126) {
		iput(oldinode);
		iput(dir);
		return -EMLINK;
	}
	bh = xenix_find_entry(dir,name,len,&de);
	if (bh) {
		brelse(bh);
		iput(dir);
		iput(oldinode);
		return -EEXIST;
	}
	bh = xenix_add_entry(dir,name,len,&de);
	if (!bh) {
		iput(dir);
		iput(oldinode);
		return -ENOSPC;
	}
	de->inode = oldinode->i_ino;
	bh->b_dirt = 1;
	brelse(bh);
	iput(dir);
	oldinode->i_nlink++;
	oldinode->i_ctime = CURRENT_TIME;
	oldinode->i_dirt = 1;
	iput(oldinode);
	return 0;
}

static int
subdir(struct inode * new, struct inode * old)
{
	unsigned short fs;
	int ino;
	int result;

	__asm__("mov %%fs,%0":"=r" (fs));
	__asm__("mov %0,%%fs"::"r" ((unsigned short) 0x10));
	new->i_count++;
	result = 0;
	for (;;) {
		if (new == old) {
			result = 1;
			break;
		}
		if (new->i_dev != old->i_dev)
			break;
		ino = new->i_ino;
		if (xenix_lookup(new, "..", 2, &new))
			break;
		if (new->i_ino == ino)
			break;
	}
	iput(new);
	__asm__("mov %0,%%fs"::"r" (fs));
	return result;
}

#define PARENT_INO(buffer) \
(((struct xenix_dir_entry *) (buffer))[1].inode)

#define PARENT_NAME(buffer) \
(((struct xenix_dir_entry *) (buffer))[1].name)

/*
 * rename uses retrying to avoid race-conditions: at least they should be minimal.
 * it tries to allocate all the blocks, then sanity-checks, and if the sanity-
 * checks fail, it tries to restart itself again. Very practical - no changes
 * are done until we know everything works ok.. and then all the changes can be
 * done in one fell swoop when we have claimed all the buffers needed.
 *
 * Anybody can rename anything with this: the permission checks are left to the
 * higher-level routines.
 */

static int
do_xenix_rename(struct inode * old_dir, const char * old_name, int old_len,
	struct inode * new_dir, const char * new_name, int new_len)
{
	struct inode * old_inode, * new_inode;
	struct buffer_head * old_bh, * new_bh, * dir_bh;
	struct xenix_dir_entry * old_de, * new_de;
	int retval;

	goto start_up;
try_again:
	brelse(old_bh);
	brelse(new_bh);
	brelse(dir_bh);
	iput(old_inode);
	iput(new_inode);
	current->counter = 0;
	schedule();
start_up:
	old_inode = new_inode = NULL;
	old_bh = new_bh = dir_bh = NULL;
	old_bh = xenix_find_entry(old_dir, old_name, old_len, &old_de);
	retval = -ENOENT;
	if (!old_bh)
		goto end_rename;
	old_inode = iget(old_dir->i_sb, old_de->inode);
	if (!old_inode)
		goto end_rename;
	retval = -EPERM;
	if ((old_dir->i_mode & S_ISVTX) && 
	    current->euid != old_inode->i_uid &&
	    current->euid != old_dir->i_uid && !suser())
		goto end_rename;
	new_bh = xenix_find_entry(new_dir, new_name, new_len, &new_de);
	if (new_bh) {
		new_inode = iget(new_dir->i_sb, new_de->inode);
		if (!new_inode) {
			brelse(new_bh);
			new_bh = NULL;
		}
	}
	if (new_inode == old_inode) {
		retval = 0;
		goto end_rename;
	}
	if (new_inode && S_ISDIR(new_inode->i_mode)) {
		retval = -EEXIST;
		goto end_rename;
	}
	retval = -EPERM;
	if (new_inode && (new_dir->i_mode & S_ISVTX) && 
	    current->euid != new_inode->i_uid &&
	    current->euid != new_dir->i_uid && !suser())
		goto end_rename;
	if (S_ISDIR(old_inode->i_mode)) {
		retval = -EEXIST;
		if (new_bh)
			goto end_rename;
		retval = -EACCES;
		if (!permission(old_inode, MAY_WRITE))
			goto end_rename;
		retval = -EINVAL;
		if (subdir(new_dir, old_inode))
			goto end_rename;
		retval = -EIO;
		dir_bh = xenix_bread(old_inode, 0, 0);
		if (!dir_bh)
			goto end_rename;
		if (PARENT_INO(dir_bh->b_data) != old_dir->i_ino)
			goto end_rename;
	}
	if (!new_bh)
		new_bh = xenix_add_entry(new_dir, new_name, new_len, &new_de);
	retval = -ENOSPC;
	if (!new_bh)
		goto end_rename;
/* sanity checking before doing the rename - avoid races */
	if (new_inode && (new_de->inode != new_inode->i_ino))
		goto try_again;
	if (new_de->inode && !new_inode)
		goto try_again;
	if (old_de->inode != old_inode->i_ino)
		goto try_again;
/* ok, that's it */
	old_de->inode = 0;
	new_de->inode = old_inode->i_ino;
	if (new_inode) {
		new_inode->i_nlink--;
		new_inode->i_dirt = 1;
	}
	old_bh->b_dirt = 1;
	new_bh->b_dirt = 1;
	if (dir_bh) {
		PARENT_INO(dir_bh->b_data) = new_dir->i_ino;
		dir_bh->b_dirt = 1;
		old_dir->i_nlink--;
		new_dir->i_nlink++;
		old_dir->i_dirt = 1;
		new_dir->i_dirt = 1;
	}
	retval = 0;
end_rename:
	brelse(dir_bh);
	brelse(old_bh);
	brelse(new_bh);
	iput(old_inode);
	iput(new_inode);
	iput(old_dir);
	iput(new_dir);
	return retval;
}

/*
 * Ok, rename also locks out other renames, as they can change the parent of
 * a directory, and we don't want any races. Other races are checked for by
 * "do_rename()", which restarts if there are inconsistencies.
 *
 * Note that there is no race between different filesystems: it's only within
 * the same device that races occur: many renames can happen at once, as long
 * as they are on different partitions.
 */

int
xenix_rename(struct inode * old_dir, const char * old_name, int old_len,
	struct inode * new_dir, const char * new_name, int new_len)
{
	static struct wait_queue * wait = NULL;
	static int lock = 0;
	int result;

	while (lock)
		sleep_on(&wait);
	lock = 1;
	result = do_xenix_rename(old_dir, old_name, old_len,
		new_dir, new_name, new_len);
	lock = 0;
	wake_up(&wait);
	return result;
}
