#ifndef _XENIX_FS_I
#define _XENIX_FS_I

/*
 * Xenix fs inode data in memory
 */

struct xenix_inode_info {
	unsigned int i_data[13];
};

#endif
