/*
 * Add an MSDOS filesystem to a low level formatted diskette.
 *
 * Emmet P. Gray			US Army, HQ III Corps & Fort Hood
 * ...!uunet!uiucuxc!fthood!egray	Attn: AFZF-DE-ENV
 * fthood!egray@uxc.cso.uiuc.edu	Directorate of Engineering & Housing
 * 					Environmental Management Office
 * 					Fort Hood, TX 76544-5057
 */

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <ctype.h>
#include <memory.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>
#include "getopt.h"
#ifdef BSD
#include <sys/time.h>
#else /* BSD */
#include <time.h>
#endif /* BSD */
#include <errno.h>
#include "msdos.h"

extern int errno;

#ifdef NO_STRERROR
/* fixup braindead include philes */
extern char *sys_errlist[];
#define strerror(x) ( sys_errlist[x] )
#endif

void
mformat(argc, argv)
int argc;
char *argv[];
{
	struct bootsector boot;
	int i, c, oops, tracks, heads, sectors, fat_len, dir_len, clus_size;
	int tot_sectors, num_clus, rem_sect, occupied, tries;
	int argtracks, argheads, argsectors;
	long now;
	char drive, *name;

	unsigned char media, label[12], buf[MSECTOR_SIZE];
	struct device *dev;
	struct directory *dir;
	char errmsg[80];

	/* avoid compiler warnings */
	tracks = sectors = heads = 0;


	oops = 0;
	argtracks = 0;
	argheads = 0;
	argsectors = 0;
	label[0] = '\0';
					/* get command line options */
	while ((c = getopt(argc, argv, "t:h:s:l:")) != EOF) {
		switch (c) {
			case 't':
				argtracks = atoi(optarg);
				break;
			case 'h':
				argheads = atoi(optarg);
				break;
			case 's':
				argsectors = atoi(optarg);
				break;
			case 'l':
				sprintf((char *) label, "%-11.11s", optarg);
				break;
			default:
				oops = 1;
				break;
		}
	}

	if (oops || (argc - optind) != 1) {
		fprintf(stderr, "Mtools version %s, dated %s\n", mversion, mdate);
		fprintf(stderr, "Usage: %s [-t tracks] [-h heads] [-s sectors] [-l label] device\n", argv[0]);
		exit(1);
	}

	drive = argv[argc -1][0];
	if (islower(drive))
		drive = toupper(drive);

	/* check out a drive whose letter and parameters match */	
	sprintf(errmsg, "Drive '%c:' not supported", drive);	
	fd = -1;
	for(dev=devices;dev->drive;dev++) {

					/* drive letter */
	  if (dev->drive != drive)
	    continue;
					/* non removable media */
	  if ( dev->tracks == 0 &&
	      ( argtracks == 0 || argheads == 0 || argsectors == 0 )) {
	    sprintf(errmsg, 
		    "Non-removable media is not supported "
		    "(You must tell the complete geometry of the disk, "
		    "either in /etc/mtools or on the command line) " );
	    continue;
	  }
	  				/* parameters */
	  if (dev->tracks && !dev->gioctl) {
	    if ((argtracks && dev->tracks != argtracks) ||
		(argheads && dev->heads != argheads) ||
		(argsectors && dev->sectors != argsectors)){
	      sprintf(errmsg, "Paramaters not supported");
	      continue;
	    }
	  }
					/* open the device */
	  name = expand(dev->name);
	  if ( fd != -1 )
	    close(fd);
	  /* if we have an absolute filename, get group privs */
	  fd = open(name, 2 | dev->mode);
	  if (fd < 0) {
	    sprintf(errmsg,"init: open: %s", strerror(errno));
	    continue;
	  }

	  tracks = argtracks;
	  heads = argheads;
	  sectors = argsectors;
					/* fill in the blanks */
	  if (!tracks)
	    tracks = dev->tracks;
	  if (!heads)
	    heads = dev->heads;
	  if (!sectors)
	    sectors = dev->sectors;
					/* set parameters, if needed */
	  if (dev->gioctl) {
	    if ((*(dev->gioctl)) (fd, tracks, heads, sectors)){
	      sprintf(errmsg,"Could not set requested parameters");
	      continue;
	    }
	  }
					/* do a "test" read */
	  if (read(fd, (char *) buf, MSECTOR_SIZE) != MSECTOR_SIZE) {
	    sprintf(errmsg, "Error reading from '%s', wrong parameters?",name);
	    continue;
	  }

	  break;
	}
					/* print error msg if needed */	
	if ( dev->drive == 0 ){
	  fprintf(stderr,"%s: %s\n", argv[0],errmsg);
	  exit(1);
	}

					/* get the parameters */
	tot_sectors = tracks * heads * sectors;
	switch (tot_sectors) {
		case 320:		/* 40t * 1h * 8s = 160k */
			media = 0xfe;
			clus_size = 1;
			dir_len = 4;
			fat_len = 1;
			break;
		case 360:		/* 40t * 1h * 9s = 180k */
			media = 0xfc;
			clus_size = 1;
			dir_len = 4;
			fat_len = 2;
			break;
		case 640:		/* 40t * 2h * 8s = 320k */
			media = 0xff;
			clus_size = 2;
			dir_len = 7;
			fat_len = 1;
			break;
		case 720:		/* 40t * 2h * 9s = 360k */
			media = 0xfd;
			clus_size = 2;
			dir_len = 7;
			fat_len = 2;
			break;
		case 1440:		/* 80t * 2h * 9s = 720k */
			media = 0xf9;
			clus_size = 2;
			dir_len = 7;
			fat_len = 3;
			break;
		case 2400:		/* 80t * 2h * 15s = 1.2m */
			media = 0xf9;
			clus_size = 1;
			dir_len = 14;
			fat_len = 7;
			break;
		case 2880:		/* 80t * 2h * 18s = 1.44m */
			media = 0xf0;
			clus_size = 1;
			dir_len = 14;
			fat_len = 9;
			break;
		default:		/* a non-standard format */
			media = 0xf0;
			if (heads == 1)
				clus_size = 1;
			else
				clus_size = (tot_sectors > 2000) ? 1 : 2;
			if (heads == 1)
				dir_len = 4;
			else
				dir_len = (tot_sectors > 2000) ? 14 : 7;


			/* the "remaining sectors" after directory and boot
			 * has been accounted for.
			 */
			rem_sect = tot_sectors - dir_len - 1;

			/* rough estimate of fat size */
			fat_len = 1;
			
			tries=0;
			while(1){
			  num_clus = (rem_sect - 2 * fat_len ) / clus_size;
			  fat_len = ( ( 2 + num_clus ) * 3 + 1023 ) >> 10 ;
			  occupied = 2 * fat_len + clus_size * num_clus;

			  /* if we have exactly used up all sectors, fine */
			  if ( occupied == rem_sect )
			    break;

			  /* if we have used up more than we have, we'll have
			   * to reloop */
			  if ( occupied > rem_sect )
			    continue;

			  /* if we have not used up all our sectors, try again.
			   * After the second try, decrease the amount of
			   * available space. This is to deal with the case
			   * of 344 or 345, ..., 1705, ... available sectors.
			   */
			  switch(tries++){
			  default:
			    /* this should never arrive */
			    fprintf(stderr,
				    "Internal error in cluster/fat repartition"
				    " calculation.\n"
				    "Please report bug to "
				    "knaff@mururoa.imag.fr\n");
			    exit(1);
			  case 2:
			  case 1:
			    rem_sect--;
			  case 0:
			    continue;
			  }
			}
			break;
	}
					/* the boot sector */
	memset((char *) &boot, '\0', MSECTOR_SIZE);
	boot.jump[0] = 0xeb;
	boot.jump[1] = 0x44;
	boot.jump[2] = 0x90;
	strncpy((char *) boot.banner, "Mtools  ", 8);
	boot.secsiz[0] = 512 % 0x100;
	boot.secsiz[1] = 512 / 0x100;
	boot.clsiz = (unsigned char) clus_size;
	boot.nrsvsect[0] = 1;
	boot.nrsvsect[1] = 0;
	boot.nfat = 2;
	boot.dirents[0] = (dir_len * 16) % 0x100;
	boot.dirents[1] = (dir_len * 16) / 0x100;
	boot.psect[0] = tot_sectors % 0x100;
	boot.psect[1] = tot_sectors / 0x100;
	boot.descr = media;
	boot.fatlen[0] = fat_len % 0x100;
	boot.fatlen[1] = fat_len / 0x100;
	boot.nsect[0] = sectors % 0x100;
	boot.nsect[1] = sectors / 0x100;
	boot.nheads[0] = heads % 0x100;
	boot.nheads[1] = heads / 0x100;

					/* write the boot */
	lseek(fd, 0L, 0);
	write(fd, (char *) &boot, MSECTOR_SIZE);
					/* first fat */
	memset((char *) buf, '\0', MSECTOR_SIZE);
	buf[0] = media;
	buf[1] = 0xff;
	buf[2] = 0xff;
	write(fd, (char *) buf, MSECTOR_SIZE);
	memset((char *) buf, '\0', MSECTOR_SIZE);
	for (i = 1; i < fat_len; i++)
		write(fd, (char *) buf, MSECTOR_SIZE);
					/* second fat */
	buf[0] = media;
	buf[1] = 0xff;
	buf[2] = 0xff;
	write(fd, (char *) buf, MSECTOR_SIZE);
	memset((char *) buf, '\0', MSECTOR_SIZE);
	for (i = 1; i < fat_len; i++)
		write(fd, (char *) buf, MSECTOR_SIZE);
					/* the root directory */
	if (label[0] != '\0') {
		time(&now);
		dir = mk_entry(label, 0x08, 0, 0L, now);
		memcpy((char *) buf, (char *) dir, MDIR_SIZE);
	}
	write(fd, (char *) buf, MSECTOR_SIZE);
	memset((char *) buf, '\0', MSECTOR_SIZE);
	for (i = 1; i < dir_len; i++)
		write(fd, (char *) buf, MSECTOR_SIZE);
	close(fd);
	exit(0);
}
