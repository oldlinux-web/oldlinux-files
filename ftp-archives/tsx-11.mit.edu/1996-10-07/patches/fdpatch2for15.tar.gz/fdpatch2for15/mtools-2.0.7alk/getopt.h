#ifdef linux

#include <getopt.h>

#else
     int getopt();
     extern char *optarg;
     extern int optind, opterr;
#endif
