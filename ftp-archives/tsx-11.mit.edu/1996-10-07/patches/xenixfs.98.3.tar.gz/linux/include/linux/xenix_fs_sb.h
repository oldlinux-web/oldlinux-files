#ifndef _XENIX_FS_SB
#define _XENIX_FS_SB

/*
 * Xenix super-block data in memory
 *
 * The Xenix superblock contains dynamic data (it gets modified while the
 * system is running). This is in contrast to the Minix and Berkeley
 * filesystems (where the superblock is never modified). This affects the
 * sync() operation: we must keep the superblock in a disk buffer and use this
 * one as our "working copy".
 *
 * FIXME: The structure is such that it's a pain in the ass to work with
 *	without #pragma pack(2), so we keep <s_isize, s_fsize> here (they
 *	don't change).
 */

struct xenix_sb_info {
	struct buffer_head *s_bh;	/* actually, it's in a disk buffer */
	struct xenix_super_block *s_xsb;
	unsigned short s_isize;
	daddr_t s_fsize;
};

#endif
