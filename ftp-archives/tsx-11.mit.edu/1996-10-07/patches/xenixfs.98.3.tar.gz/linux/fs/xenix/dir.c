/*
 * linux/fs/xenix/dir.c
 *
 * (C) 1991  Linus Torvalds
 *
 * Taken from minix/dir.c, modified by Doug Evans, dje@sspiff.uucp, 92Jun04.
 *
 * This file contains xenix directory handling functions.
 */

#include <asm/segment.h>

#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/xenix_fs.h>
#include <linux/stat.h>

/*static*/ int xenix_file_read(struct inode *, struct file *, char *, int);
static int xenix_dir_read(struct inode *, struct file *, char *, int);
static int xenix_readdir(struct inode *, struct file *, struct dirent *, int);

static struct file_operations xenix_dir_operations = {
	NULL,			/* lseek - default */
#if 0	/* disable while we still have old code that uses this */
	xenix_dir_read,		/* read */
#else
	xenix_file_read,	/* read */
#endif
	NULL,			/* write - bad */
	xenix_readdir,		/* readdir */
	NULL,			/* select - default */
	NULL,			/* ioctl - default */
	NULL,			/* mmap */
	NULL,			/* no special open code */
	NULL			/* no special release code */
};

/*
 * directories can handle most operations...
 */

struct inode_operations xenix_dir_inode_operations = {
	&xenix_dir_operations,	/* default directory file-ops */
	xenix_create,		/* create */
	xenix_lookup,		/* lookup */
	xenix_link,		/* link */
	xenix_unlink,		/* unlink */
	xenix_symlink,		/* symlink */
	xenix_mkdir,		/* mkdir */
	xenix_rmdir,		/* rmdir */
	xenix_mknod,		/* mknod */
	xenix_rename,		/* rename */
	NULL,			/* readlink */
	NULL,			/* follow_link */
	xenix_bmap,		/* bmap (FIXME: gone in minix version) */
	xenix_truncate		/* truncate */
};

static int
xenix_readdir(struct inode * inode, struct file * filp,
	struct dirent * dirent, int count)
{
	unsigned int offset,i;
	char c;
	struct buffer_head * bh;
	struct xenix_dir_entry * de;

	if (!inode || !S_ISDIR(inode->i_mode))
		return -EBADF;
	if (filp->f_pos & (sizeof (struct xenix_dir_entry) - 1))
		return -EBADF;
	while (filp->f_pos < inode->i_size) {
		offset = filp->f_pos & 1023;
		bh = xenix_bread(inode, (filp->f_pos) >> BLOCK_SIZE_BITS, 0);
		if (!bh) {
			filp->f_pos += 1024 - offset;
			continue;
		}
		de = (struct xenix_dir_entry *) (offset + bh->b_data);
		while (offset < 1024 && filp->f_pos < inode->i_size) {
			offset += sizeof (struct xenix_dir_entry);
			filp->f_pos += sizeof (struct xenix_dir_entry);
			if (de->inode) {
				for (i = 0; i < XENIX_NAME_LEN; i++)
					if (c = de->name[i])
						put_fs_byte(c, i + dirent->d_name);
					else
						break;
				if (i) {
					put_fs_long(de->inode, &dirent->d_ino);
					put_fs_byte(0, i + dirent->d_name);
					put_fs_word(i, &dirent->d_reclen);
					brelse(bh);
					return i;
				}
			}
			de++;
		}
		brelse(bh);
	}
	return 0;
}

static int
xenix_dir_read(struct inode * inode, struct file * filp, char * buf, int count)
{
	return -EISDIR;
}
