/*
 *  linux/kernel/floppy.c
 *
 *  Copyright (C) 1991, 1992  Linus Torvalds
 *  Copyright (C) 1993, 1994  Alain Knaff
 */

/* Configuration */
/* The following does some extra sanity checks */
#define SANITY

/* Undefine the following if you have to floppy disk controllers:
 * This is untested. If you get two controllers working, with drives attached
 * too both, please mail me: Alain.Knaff@imag.fr */
/* #define HAVE_2_CONTROLLERS */

/* Undefine the following if you have problems accessing ED disks, but don't
 * have problems accessing them with the stock driver. If that is the case,
 * please mail me: Alain.Knaff@imag.fr */
/* #define FDC_FIFO_BUG */

/* Undefine the following if those "Weird unlocked..." messages after
 * I/O errors annoy you... */
/*#define NO_WEIRD_UNLOCKED*/

/* End of configuration */

/*
 * 02.12.91 - Changed to static variables to indicate need for reset
 * and recalibrate. This makes some things easier (output_byte reset
 * checking etc), and means less interrupt jumping in case of errors,
 * so the code is hopefully easier to understand.
 */

/*
 * This file is certainly a mess. I've tried my best to get it working,
 * but I don't like programming floppies, and I have only one anyway.
 * Urgel. I should check for more errors, and do more graceful error
 * recovery. Seems there are problems with several drives. I've tried to
 * correct them. No promises.
 */

/*
 * As with hd.c, all routines within this file can (and will) be called
 * by interrupts, so extreme caution is needed. A hardware interrupt
 * handler may not sleep, or a kernel panic will happen. Thus I cannot
 * call "floppy-on" directly, but have to set a special timer interrupt
 * etc.
 */

/*
 * 28.02.92 - made track-buffering routines, based on the routines written
 * by entropy@wintermute.wpi.edu (Lawrence Foard). Linus.
 */

/*
 * Automatic floppy-detection and formatting written by Werner Almesberger
 * (almesber@nessie.cs.id.ethz.ch), who also corrected some problems with
 * the floppy-change signal detection.
 */

/*
 * 1992/7/22 -- Hennus Bergman: Added better error reporting, fixed
 * FDC data overrun bug, added some preliminary stuff for vertical
 * recording support.
 *
 * 1992/9/17: Added DMA allocation & DMA functions. -- hhb.
 *
 * TODO: Errors are still not counted properly.
 */

/* 1992/9/20
 * Modifications for ``Sector Shifting'' by Rob Hooft (hooft@chem.ruu.nl)
 * modelled after the freeware MS/DOS program fdformat/88 V1.8 by
 * Christoph H. Hochst\"atter.
 * I have fixed the shift values to the ones I always use. Maybe a new
 * ioctl() should be created to be able to modify them.
 * There is a bug in the driver that makes it impossible to format a
 * floppy as the first thing after bootup.
 */

/*
 * 1993/4/29 -- Linus -- cleaned up the timer handling in the kernel, and
 * this helped the floppy driver as well. Much cleaner, and still seems to
 * work.
 */

/* 1994/6/24 --bbroad-- added the floppy table entries and made
 * minor modifications to allow 2.88 floppies to be run.
 */

/* 1994/7/13 -- Paul Vojta -- modified the probing code to allow three or more
 * disk types.
 */


#define REALLY_SLOW_IO
#define FLOPPY_IRQ 6
#define FLOPPY_DMA 2

#define DEBUGT 2

#include <linux/sched.h>
#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/timer.h>
#include <linux/fdreg.h>
#include <linux/fd.h>
#include <linux/errno.h>
#include <linux/malloc.h>
#include <linux/string.h>
#include <linux/fcntl.h>
#include <linux/delay.h>

#include <asm/dma.h>
#include <asm/irq.h>
#include <asm/system.h>
#include <asm/io.h>
#include <asm/segment.h>

#define MAJOR_NR FLOPPY_MAJOR
#include "blk.h"

static unsigned int changed_floppies = 0, fake_change = 0;
static int initialising=1;


#ifdef HAVE_2_CONTROLLERS
#define N_FDC 2
#define N_DRIVE 8
#else
#define N_FDC 1
#define N_DRIVE 4
#endif

#define TYPE(x) ( ((x)>>2) & 0x1f )
#define DRIVE(x) ( ((x)&0x03) | (((x)&0x80 ) >> 5))
#define UNIT(x) ( (x) & 0x03 )		/* drive on fdc */
#define FDC(x) ( ((x) & 0x04) >> 2 )  /* fdc of drive */
#define REVDRIVE(fdc, unit) ( (unit) + ((fdc) << 2 ))
				/* reverse mapping from unit and fdc to drive */
#define DP (&drive_params[current_drive])
#define DRS (&drive_state[current_drive])
#define FDCS (&fdc_state[fdc])

#define UDP (&drive_params[drive])
#define UDRS (&drive_state[drive])
#define UFDCS (&fdc_state[FDC(drive)])

/* read/write */
#define COMMAND raw_cmd.cmd[0]
#define DR_SELECT raw_cmd.cmd[1]
#define TRACK raw_cmd.cmd[2]
#define HEAD raw_cmd.cmd[3]
#define SECTOR raw_cmd.cmd[4]
#define SIZECODE raw_cmd.cmd[5]
#define SECT_PER_TRACK raw_cmd.cmd[6]
#define GAP raw_cmd.cmd[7]
#define SIZECODE2 raw_cmd.cmd[8]
#define NR_RW 9

/* format */
#define F_SIZECODE raw_cmd.cmd[2]
#define F_SECT_PER_TRACK raw_cmd.cmd[3]
#define F_GAP raw_cmd.cmd[4]
#define F_FILL raw_cmd.cmd[5]
#define NR_F 6

/*
 * Maximum disk size (in kilobytes). This default is used whenever the
 * current disk size is unknown.
 */
#define MAX_DISK_SIZE 3984



/*
 * The DMA channel used by the floppy controller cannot access data at
 * addresses >= 16MB
 *
 * Went back to the 1MB limit, as some people had problems with the floppy
 * driver otherwise. It doesn't matter much for performance anyway, as most
 * floppy accesses go through the track buffer.
 */
#define LAST_DMA_ADDR	(0x1000000)
#define K_64 (0x10000) /* 64 k */

/*
 * globals used by 'result()'
 */
#define MAX_REPLIES 10
static unsigned char reply_buffer[MAX_REPLIES];
static int inr; /* size of reply buffer, when called from interrupt */
#define ST0 (reply_buffer[0])
#define ST1 (reply_buffer[1])
#define ST2 (reply_buffer[2])
#define ST3 (reply_buffer[0]) /* result of GETSTATUS */
#define R_TRACK (reply_buffer[3])
#define R_HEAD (reply_buffer[4])
#define R_SECTOR (reply_buffer[5])
#define R_SIZECODE (reply_buffer[6])

/*
 * this struct defines the different floppy drive types.
 */
static struct {
	struct floppy_drive_params params;
	char *name; /* name printed while booting */
} default_drive_params[]= {
/* NOTE: the time values in jiffies should be in msec!
 CMOS drive type
  |     Maximum data rate supported by drive type
  |     |   Head load time, msec
  |     |   |   Head unload time, msec (not used)
  |     |   |   |     Step rate interval, usec
  |     |   |   |     |    Time needed for spinup time (jiffies)
  |     |   |   |     |    |    Timeout for spinning down (jiffies)
  |     |   |   |     |    |    |   Spindown offset (where disk stops)
  |     |   |   |     |    |    |   |  Select delay
  |     |   |   |     |    |    |   |  |  RPS
  |     |   |   |     |    |    |   |  |  |    Max number of tracks
  |     |   |   |     |    |    |   |  |  |    |     Interrupt timeout
  |     |   |   |     |    |    |   |  |  |    |     |   Max nonintlv. sectors
  |     |   |   |     |    |    |   |  |  |    |     |   | -Max Errors- flags */
{{0,  500, 16, 16, 8000, 100, 300,  0, 2, 5,  80, 3*HZ, 20, {3,1,2,0,2}, 0,
      0, { 7, 4,20,21, 0, 0, 0, 0 }, 150, 0 }, "unknown" },

{{1,  300, 16, 16, 8000, 100, 300,  0, 2, 5,  40, 3*HZ, 17, {3,1,2,0,2}, 0,
      0, { 1, 0, 0, 0, 0, 0, 0, 0 }, 150, 1 }, "360k PC" }, /*5 1/4 DD*/

{{2,  500, 16, 16, 6000,  40, 300, 14, 2, 6,  83, 3*HZ, 17, {3,1,2,0,2}, 0,
      0, { 2, 5, 0, 0, 0, 0, 0, 0 }, 150, 2 }, "1.2M" }, /*5 1/4 HD*/

{{3,  250, 16, 16, 3000, 100, 300,  0, 2, 5,  83, 3*HZ, 20, {3,1,2,0,2}, 0,
      0, { 4, 0, 0, 0, 0, 0, 0, 0 }, 150, 4 }, "720k" }, /*3 1/2 DD*/

{{4,  500, 16, 16, 3000,  40, 300, 10, 2, 5,  83, 3*HZ, 20, {3,1,2,0,2}, 0,
      0, { 7, 4,24,25, 0, 0, 0, 0 }, 150, 7 }, "1.44M" }, /*3 1/2 HD*/

{{5, 1000, 16, 16, 3000,  40, 300, 10, 2, 5,  83, 3*HZ, 40, {3,1,2,0,2}, 0,
      0, { 7, 8, 4,24,25,27,28, 0 }, 150, 8 }, "2.88M AMI BIOS" }, /*3 1/2 ED*/

{{6, 1000, 15,  8, 3000,  40, 300, 10, 2, 5,  83, 3*HZ, 40, {3,1,2,0,2}, 0,
      0, { 7, 8, 4,24,25,27,28, 0 }, 150, 8 }, "2.88M" } /*3 1/2 ED*/
/*    |  ---autodetected formats--     |  |      |
      read_track                       |  |    Name printed when booting
                                       | Native format
                                       Frequency of disk change checks */
};

static struct floppy_drive_params drive_params[N_DRIVE];
static struct floppy_drive_struct volatile drive_state[N_DRIVE];
static struct floppy_raw_cmd raw_cmd;

/*
 * This struct defines the different floppy types.
 *
 * The 'stretch' tells if the tracks need to be doubled for some
 * types (ie 360kB diskette in 1.2MB drive etc). Others should
 * be self-explanatory.
 */
static struct floppy_struct floppy_type[32] = {
	{    0, 0,0, 0,0,0x00,0x00,0x00,0x00,NULL },	/*  0 no testing */
	{  720, 9,2,40,0,0x2A,0x02,0xDF,0x50,"d360"},/*  1 360kB PC diskettes */
	{ 2400,15,2,80,0,0x1B,0x00,0xDF,0x54,"h1200"  },	/*  2 1.2 MB AT-diskettes */
	{  720, 9,1,80,0,0x2A,0x02,0xDF,0x50,"D360" },	/*  3 360kB in 720kB drive */
	{ 1440, 9,2,80,0,0x2A,0x02,0xDF,0x50,"D720"  },	/*  4 3.5" 720kB diskette */
	{  720, 9,2,40,1,0x23,0x01,0xDF,0x50,"h360"  },	/*  5 360kB in 1.2MB drive */
	{ 1440, 9,2,80,0,0x23,0x01,0xDF,0x50,"h720"  },	/*  6 720kB in 1.2MB drive */
	{ 2880,18,2,80,0,0x1B,0x00,0xCF,0x6C,"H1440" },	/*  7 1.44MB diskette */
	{ 5760,36,2,80,0,0x1B,0x43,0xAF,0x54,"E2880" },	/*  8 2.88MB diskette */
	{ 5760,36,2,80,0,0x1B,0x43,0xAF,0x54,"CompaQ"},	/*  9 2.88MB diskette */

	{ 2880,18,2,80,0,0x25,0x00,0xDF,0x02,"h1440" }, /* 10 1.44MB 5.25" */
	{ 3360,21,2,80,0,0x25,0x00,0xDF,0x0C,"H1680" }, /* 11 1.68MB 3.5" */
	{  820,10,2,41,1,0x25,0x01,0xDF,0x2E,"h410"  },	/* 12 410k 5.25" */
	{ 1640,10,2,82,0,0x25,0x02,0xDF,0x2E,"H820"  },	/* 13 820k 3.5" */
	{ 2952,18,2,82,0,0x25,0x00,0xDF,0x02,"h1476" },	/* 14 1.48MB 5.25" */
	{ 3444,21,2,82,0,0x25,0x00,0xDF,0x0C,"H1722" },	/* 15 1.72MB 3.5" */
	{  840,10,2,42,1,0x25,0x01,0xDF,0x2E,"h420"  },	/* 16 420k 5.25" */
	{ 1660,10,2,83,0,0x25,0x02,0xDF,0x2E,"H830"  },	/* 17 830k 3.5" */
	{ 2988,18,2,83,0,0x25,0x00,0xDF,0x02,"h1494" },	/* 18 1.49MB 5.25" */
	{ 3486,21,2,83,0,0x25,0x00,0xDF,0x0C,"H1743" },	/* 19 1.74MB 3.5" */

	{ 1760,11,2,80,0,0x1c,0x09,0xcf,0x6c,"d880"  }, /* 20 880k 5.25" */
	{ 2080,13,2,80,0,0x1c,0x0a,0xcf,0x6c,"D1040" }, /* 21 1.04MB 3.5"*/
	{ 2240,14,2,80,0,0x1c,0x1a,0xcf,0x6c,"D1120" }, /* 22 1.12MB 3.5" */
	{ 3200,20,2,80,0,0x1c,0x20,0xcf,0x6c,"h1600" }, /* 23 1.6Mb 5.25" */
	{ 3520,22,2,80,0,0x1b,0x08,0xcf,0x30,"H1760" }, /* 24 1.76MB 3.5" */
	{ 3840,24,2,80,0,0x25,0x20,0xcf,0x6c,"H1920" }, /* 25 1.92MB 3.5" */
	{ 6400,40,2,80,0,0x25,0x5b,0xcf,0x6c,"E3200" }, /* 26 3.20MB 3.5" */
	{ 7040,44,2,80,0,0x25,0x5b,0xcf,0x6c,"E3520" }, /* 27 3.52MB 3.5" */
	{ 7680,48,2,80,0,0x25,0x63,0xcf,0x6c,"E3840" }  /* 28 3.84MB 3.5" */
};

#define	NUMBER(x)	(sizeof(x) / sizeof(*(x)))
#define SECTSIZE ( _FD_SECTSIZE(*floppy))

/* Auto-detection: Disk type used until the next media change occurs. */
struct floppy_struct *current_type[N_DRIVE] = { NULL, NULL, NULL, NULL
#ifdef HAVE_2_CONTROLLERS
				          ,NULL, NULL, NULL, NULL
#endif
					};

/*
 * User-provided type information. current_type points to
 * the respective entry of this array.
 */
struct floppy_struct user_params[N_DRIVE];

static int floppy_sizes[256];

/*
 * The driver is trying to determine the correct media format
 * while probing is set. rw_interrupt() clears it after a
 * successful access.
 */
static int probing = 0;

/* Synchronization of FDC access. */
#define FD_COMMAND_DETECT -2
#define FD_COMMAND_NONE -1
#define FD_COMMAND_ERROR 2
#define FD_COMMAND_OKAY 3

static volatile int command_status = FD_COMMAND_NONE, fdc_busy = 0;
static struct wait_queue *fdc_wait = NULL, *command_done = NULL;

/* Errors during formatting are counted here. */
static int format_errors;

/* Format request descriptor. */
static struct format_descr format_req;

/*
 * Rate is 0 for 500kb/s, 1 for 300kbps, 2 for 250kbps
 * Spec1 is 0xSH, where S is stepping rate (F=1ms, E=2ms, D=3ms etc),
 * H is head unload time (1=16ms, 2=32ms, etc)
 */

/*
 * Track buffer
 * Because these are written to by the DMA controller, they must
 * not contain a 64k byte boundary crossing, or data will be
 * corrupted/lost. Alignment of these is enforced in boot/head.S.
 * Note that you must not change the sizes below without updating head.S.
 */
extern char floppy_track_buffer[512*2*MAX_BUFFER_SECTORS];

int *errors;
typedef void (*done_f)(int);
struct cont_t {
void (*interrupt)(void); /* this is called after the interrupt of the
			  * main command */
void (*redo)(void); /* this is called to retry the operation */
void (*error)(void); /* this is called to tally an error */
done_f done; /* this is called to say if the operation has succeeded/failed */
} *cont;

static void floppy_ready(void);
static void recalibrate_floppy(void);
static void seek_floppy(void);
static void floppy_shutdown(void);

int floppy_grab_irq_and_dma(void);
void floppy_release_irq_and_dma(void);

/*
 * The "reset" variable should be tested whenever an interrupt is scheduled,
 * after the commands have been sent. This is to ensure that the driver doesn't
 * get wedged when the interrupt doesn't come because of a failed command.
 * reset doesn't need to be tested before sending commands, because
 * output_byte is automatically disabled when reset is set.
 */
#define CHECK_RESET { if ( FDCS->reset ){ reset_fdc(); return ; } }
static void reset_fdc(void);

/*
 * These are global variables, as that's the easiest way to give
 * information to interrupts. They are the data used for the current
 * request.
 */
#define NO_TRACK -1
#define NEED_1_RECAL -2
#define NEED_2_RECAL -3

/* buffer related variables */
static int buffer_track = -1;
static int buffer_drive = -1;
static int buffer_min = -1;
static int buffer_max = -1;

#ifdef FDC_FIFO_BUG
static int force=0;
#endif

/* fdc related variables, should end up in a struct */
static struct floppy_fdc_state fdc_state[N_FDC];
int fdc; /* current fdc */

static struct floppy_struct * floppy = floppy_type;
static unsigned char current_drive = 255;
static long current_count_sectors = 0;
static char *current_addr = 0;
static unsigned char sector_t; /* sector in track */

#ifdef DEBUGT
long unsigned debugtimer;
#endif

/*
 * Debugging
 * =========
 */
static inline void set_debugt(void)
{
#ifdef DEBUGT
	debugtimer = jiffies;
#endif
}

static inline void debugt(char *message)
{
#ifdef DEBUGT
  if ( DP->flags & DEBUGT )
	printk("%s dtime=%lu\n", message, jiffies-debugtimer );
#endif
}

/*
 * Bottom half floppy driver.
 * ==========================
 *
 * This part of the file contains the code talking directly to the hardware,
 * and also the main service loop (seek-configure-spinup-command)
 */
static int set_dor(int fdc, char mask, char data)
{
	register unsigned char drive, unit, newdor,olddor;

	cli();
	olddor = FDCS->dor;
	newdor =  (olddor & mask) | data;
	if ( newdor != olddor ){
		unit = olddor & 0x3;
		drive = REVDRIVE(fdc,unit);
		if ( olddor & ( 0x10 << unit )){
			if ( inb_p( FD_DIR ) & 0x80 )
				UDRS->flags |= FD_VERIFY;
			else
				UDRS->last_checked=jiffies;
		}
		FDCS->dor = newdor;
		outb_p( newdor, FD_DOR);
	}
	sti();
	return olddor;
}

static void twaddle(void)
{
	cli();
	outb_p(FDCS->dor & ~(0x10<<UNIT(current_drive)),FD_DOR);
	outb_p(FDCS->dor, FD_DOR);
	sti();
}

/* reset all driver information about the current fdc. This is needed after
 * a reset, and after a raw command. */
static void reset_fdc_info(int mode)
{
	int drive;

	FDCS->spec1 = FDCS->spec2 = -1;
	FDCS->need_configure = 1;
	FDCS->perp_mode = 1;
	FDCS->rawcmd = 0;
	for ( drive = 0; drive < N_DRIVE; drive++)
		if (FDC(drive) == fdc &&
		    ( mode || UDRS->track != NEED_1_RECAL))
			UDRS->track = NEED_2_RECAL;
}

/* selects the fdc and drive, and enables the fdc's its input/dma. */
static void set_fdc(int drive)
{
	if ( drive >= 0 ){
		fdc = FDC(drive);
		current_drive = drive;
	}
	set_dor(fdc,~0,8);
#ifdef HAVE_2_CONTROLLERS
	set_dor(1-fdc, ~8, 0);
#endif
	if ( FDCS->rawcmd == 2 )
		reset_fdc_info(1);
	if( inb_p(FD_STATUS) != STATUS_READY )
		FDCS->reset = 1;
}

/* locks the driver */
static void lock_fdc(int drive)
{
	cli();
	while (fdc_busy) sleep_on(&fdc_wait);
	fdc_busy = 1;
	sti();
	command_status = FD_COMMAND_NONE;
	set_fdc(drive);
	if ( drive >= 0 ){
		timer_table[FLOPPY_TIMER].expires = jiffies + DP->timeout;
		timer_active |= 1 << FLOPPY_TIMER;
	}
}

/* unlocks the driver */
static inline int unlock_fdc(void)
{
	if (current_drive < N_DRIVE)
		floppy_off(current_drive);
	if (!fdc_busy)
		printk(DEVICE_NAME ": FDC access conflict!\n");

	if ( DEVICE_INTR )
		printk(DEVICE_NAME
		       ":device interrupt still active at FDC release: %p!\n",
		       DEVICE_INTR);
	command_status = FD_COMMAND_NONE;
	timer_active &= ~(1 << FLOPPY_TIMER);
	fdc_busy = 0;
	wake_up(&fdc_wait);
	return 0;
}

/* switches the motor off after a given timeout */
static void motor_off_callback(unsigned long nr)
{
	unsigned char mask = ~(0x10 << UNIT(nr));

	set_dor( FDC(nr), mask, 0 );
}

static struct timer_list motor_off_timer[N_DRIVE] = {
	{ NULL, NULL, 0, 0, motor_off_callback },
	{ NULL, NULL, 0, 1, motor_off_callback },
	{ NULL, NULL, 0, 2, motor_off_callback },
	{ NULL, NULL, 0, 3, motor_off_callback }
#ifdef HAVE_2_CONTROLLERS
	,{ NULL, NULL, 0, 4, motor_off_callback },
	{ NULL, NULL, 0, 5, motor_off_callback },
	{ NULL, NULL, 0, 6, motor_off_callback },
	{ NULL, NULL, 0, 7, motor_off_callback }
#endif
};

/* schedules motor off */
static void floppy_off(unsigned int nr)
{
	unsigned long volatile delta;

	del_timer(motor_off_timer+nr);

	/* make spindle stop in a position which minimizes spinup time
	 * next time */
	if ( drive_params[nr].rps ){
		delta = jiffies - drive_state[nr].first_read_date + HZ -
			drive_params[nr].spindown_offset;
		delta = (( delta * drive_params[nr].rps) % HZ ) /
			drive_params[nr].rps;
		motor_off_timer[nr].expires = drive_params[nr].spindown - delta;
	}
	add_timer(motor_off_timer+nr);
}

/*
 * cycle through all N_DRIVE floppy drives, for disk change testing.
 * stopping at current drive. This is done before any long operation, to
 * be sure to have up to date disk change information.
 */
static void scandrives(void)
{
	int i, drive, saved_drive;

	saved_drive = current_drive % N_DRIVE;
	for(i=0; i< N_DRIVE; i++){
		drive = (saved_drive + i + 1 ) % N_DRIVE;
		if ( UDRS->fd_ref == 0 )
			continue; /* skip closed drives */
		set_fdc(drive);
		UDRS->select_date = jiffies;
		if(! (set_dor( fdc, ~3, UNIT(drive) | ( 0x10 << UNIT(drive))) &
		      (0x10 << UNIT(drive))))
			/* switch the motor off again, if it was off to
			 * begin with */
			set_dor( fdc, ~( 0x10 << UNIT(drive) ), 0 );
	}
	current_drive = saved_drive;
}

typedef void (*timeout_fn)(unsigned long);
static struct timer_list fd_timer ={ NULL, NULL, 0, 0, 0 };

/* this function makes sure that the disk stays in the drive during the
 * transfer */
static void fd_watchdog(void)
{
	if ( inb_p( FD_DIR ) & 0x80 ){
		floppy_shutdown();
	} else {
		del_timer(&fd_timer);
		fd_timer.function = (timeout_fn) fd_watchdog;
		fd_timer.expires = 10;
		add_timer(&fd_timer);
	}
}

static void main_command_interrupt(void)
{
	del_timer(&fd_timer);
	cont->interrupt();
}

/* waits for a delay (spinup or select) to pass */
static int wait_for_completion(int nr, int delay, timeout_fn function)
{
	if ( FDCS->reset ){
		reset_fdc(); /* do the reset during sleep to win time
			      * if we don't need to sleep, it's a good
			      * occasion anyways */
		return 1;
	}

	if ( jiffies < delay ){
		del_timer(&fd_timer);
		fd_timer.function = function;
		fd_timer.expires = delay  - jiffies;
		add_timer(&fd_timer);
		return 1;
	}
	return 0;
}

static void setup_DMA(void)
{
#ifdef SANITY
	if ((!CURRENT ||
	     CURRENT->buffer != current_addr ||
	     raw_cmd.length > 512 * CURRENT->nr_sectors) &&
	    (current_addr < floppy_track_buffer ||
	     current_addr + raw_cmd.length >
	     floppy_track_buffer + 1024 * MAX_BUFFER_SECTORS)){
		printk("bad adrress. start=%p lg=%lx tb=%p\n",
		       current_addr, raw_cmd.length, floppy_track_buffer);
		if ( CURRENT ){
			printk("buffer=%p nr=%lx cnr=%lx\n",
			       CURRENT->buffer, CURRENT->nr_sectors,
			       CURRENT->current_nr_sectors);
		}
		cont->done(0);
		FDCS->reset=1;
		return;
	}
	if ((long) current_addr % 512 ){
		printk("non aligned address: %p\n", current_addr );
		cont->done(0);
		FDCS->reset=1;
		return;
	}
	if ( ( (long)current_addr & ~(64*1024-1) ) !=
	    ((long)(current_addr + raw_cmd.length-1)  & ~(64*1024-1))){
		printk("DMA crossing 64-K boundary %p-%p\n",
		       current_addr, current_addr + raw_cmd.length);
		cont->done(0);
		FDCS->reset=1;
		return;
	}

#endif
	cli();
	disable_dma(FLOPPY_DMA);
	clear_dma_ff(FLOPPY_DMA);
	set_dma_mode(FLOPPY_DMA,
		     (raw_cmd.flags & FD_RAW_READ)?
		     DMA_MODE_READ : DMA_MODE_WRITE);
	set_dma_addr(FLOPPY_DMA, (long) current_addr);
	set_dma_count(FLOPPY_DMA, raw_cmd.length);
	enable_dma(FLOPPY_DMA);
	sti();
}

/* sends a command byte to the fdc */
static int output_byte(char byte)
{
	int counter;
	unsigned char status;

	if (FDCS->reset)
		return -1;
	for(counter = 0 ; counter < 10000 ; counter++) {
		status = inb_p(FD_STATUS) &(STATUS_READY|STATUS_DIR|STATUS_DMA);
		if (!(status & STATUS_READY))
			continue;
		if (status == STATUS_READY
#ifdef FDC_FIFO_BUG
		    || ((status == STATUS_READY|STATUS_DIR|STATUS_BUSY) &&force)
#endif
		    )
		{
			outb_p(byte,FD_DATA);
			return 0;
		} else
			break;
	}
	FDCS->reset = 1;
	if ( !initialising )
		printk(DEVICE_NAME ": Unable to send byte to FDC %d (%x)\n",
		       fdc, status);
	return -1;
}
#define LAST_OUT(x) if(output_byte(x)){ reset_fdc();return;}

#ifdef FDC_FIFO_BUG
#define output_byte_force(x) force=1;output_byte(x);force=0;
#else
#define output_byte_force(x) output_byte(x);
#endif

/* gets the response from the fdc */
static int result(void)
{
	int i = 0, counter, status;

	if (FDCS->reset)
		return -1;
	for (counter = 0 ; counter < 10000 ; counter++) {
		status = inb_p(FD_STATUS)&
			(STATUS_DIR|STATUS_READY|STATUS_BUSY|STATUS_DMA);
		if (!(status & STATUS_READY))
			continue;
		if (status == STATUS_READY)
			return i;
		if (status & STATUS_DMA )
			break;
		if (status == (STATUS_DIR|STATUS_READY|STATUS_BUSY)) {
			if (i >= MAX_REPLIES) {
				printk(DEVICE_NAME
				       ": floppy_stat reply overrun\n");
				break;
			}
			reply_buffer[i++] = inb_p(FD_DATA);
		}
	}
	FDCS->reset = 1;
	if ( !initialising )
		printk(DEVICE_NAME ": Getstatus times out (%x) on fdc %d [%d]\n",
		       status, fdc,i);
	return -1;
}

/* Set perpendicular mode as required, based on data rate, if supported.
 * 82077 Untested! 1Mbps data rate only possible with 82077-1.
 * TODO: increase MAX_BUFFER_SECTORS, add floppy_type entries.
 */
static inline void perpendicular_mode(void)
{
	unsigned char perp_mode;

	if (!floppy)
		return;
	if (floppy->rate & 0x40){
		switch(raw_cmd.rate){
		case 0:
			perp_mode=/*2*/3;
			break;
		case 3:
			perp_mode=3;
			break;
		default:
			printk(DEVICE_NAME
			       ": Invalid data rate for perpendicular mode!\n");
			cont->done(0);
			FDCS->reset = 1; /* convenient way to return to
					  * redo without to much hassle (deep
					  * stack et al. */
			return;
		}
	} else
		perp_mode = 0;
			
	if ( FDCS->perp_mode == perp_mode )
		return;
	if (FDCS->version >= FDC_82077_ORIG && FDCS->has_fifo) {
		output_byte(FD_PERPENDICULAR);
		output_byte_force(perp_mode);
		FDCS->perp_mode = perp_mode;
	} else if (perp_mode) {
		printk(DEVICE_NAME
		       ": perpendicular mode not supported by this FDC.\n");
	}
} /* perpendicular_mode */

#define NOMINAL_DTR 500

/* Issue a "SPECIFY" command to set the step rate time, head unload time,
 * head load time, and DMA disable flag to values needed by floppy.
 *
 * The value "dtr" is the data transfer rate in Kbps.  It is needed
 * to account for the data rate-based scaling done by the 82072 and 82077
 * FDC types.  This parameter is ignored for other types of FDCs (i.e.
 * 8272a).
 *
 * Note that changing the data transfer rate has a (probably deleterious)
 * effect on the parameters subject to scaling for 82072/82077 FDCs, so
 * fdc_specify is called again after each data transfer rate
 * change.
 *
 * srt: 1000 to 16000 in microseconds
 * hut: 16 to 240 milliseconds
 * hlt: 2 to 254 milliseconds
 *
 * These values are rounded up to the next highest available delay time.
 */
static void fdc_specify(void)
{
	unsigned char spec1, spec2;
	int srt, hlt, hut;
	unsigned long dtr = NOMINAL_DTR;
	unsigned long scale_dtr = NOMINAL_DTR;
	int hlt_max_code = 0x7f;
	int hut_max_code = 0xf;

	if (FDCS->need_configure && FDCS->has_fifo) {
		if ( FDCS->reset )
			return;
		/* Turn on FIFO for 82077-class FDC (improves performance) */
		/* TODO: lock this in via LOCK during initialization */
		output_byte(FD_CONFIGURE);
		output_byte_force(0);
		output_byte(0x1A);	/* FIFO on, polling off, 10 byte threshold */
		output_byte_force(0);		/* precompensation from track 0 upwards */
		if ( FDCS->reset ){
			FDCS->has_fifo=0;
			return;
		}
		FDCS->need_configure = 0;
		/*printk(DEVICE_NAME ": FIFO enabled\n");*/
	}

	switch (raw_cmd.rate & 0x03) {
	case 3:
		dtr = 1000;
		break;
	case 1:
		dtr = 300;
		break;
	case 2:
		dtr = 250;
		break;
	}

	if (FDCS->version >= FDC_82072) {
		s* hlt: 2 to4u
int hlt_ma:
	.\n"0==256load** h0/ {
	time,/
star!perform0x7f;
	int hut_ma
	.\n"0==256load** h0/ {
	time,/
star!perfor}_timerCt = rt to set thempenso 16000 in medo w 2 to 254 my the4 b);
}rforpecse 36 - ( jifpec*82072) {
/ *
 *+*/

#define N- 1)/cale_dtr = NOMI	breecs>_maxDCS-pecse max_c	p_mode;
	pecs< 0DCS-pecse m_cod2 ter.f jif2 t*82072) {
/2*+*/

#define N- 1)/cale_dtr = NOMI	br2 te<_ma
1)t: 2 tut_ma
1_c	p_mode;
	2 tu>_max_)t: 2 tut_2 to4u
int h_cod2uter.f jif2uc*82072) {
/ 6*+*/

#define N- 1)/cale_dtr = NOMI	br2ute<_ma1)t: 2utut_ma1_c	p_mode;
	2ucs>_maxDCS-2utut_0x7f;
	int hsaved;

	FDC	pecs<< 4 UNI srt,r_mode *fd_f
	cli();
	 0ved;

 FDCr2 te< ;  UNIfd_f
	cli();
	f_timerIAlignmenect on the d/
st you must need tent waye probfter a* next tit drive;

	F!=signedO_BUS->spec1 = F!=signe>= FDC_merGneed timh cle( FignedOh cle1 = Fialization */
		outp* Issueyte_force(0);
		ot drive;

	FDCe;

	yte_force(0);
		ot drive;

2 =signe>=is FDC.\n"DCs, so
 * fo be ruSommand t d'shanging the data traFDCbe
 * B This p so
 *i* skip cboot/hs[]= y possiblng for 82072/8 Note that changina traar modesed afiR 50ds, bThis p so
 *ya "SPECIFes of ublems ac"DCs, so
 * ftimeout_f delay time.
 */
stati {
fdc_specifmerIAlangina tratrollloid f commais tsode  *
 * , commit.* next tim

	switch (ra=);
	olddotr perp_mode )
ifmerSomm {
	 nex  )
		{

	switch (rp(FDCSCERPEN
mance) */
 limi
	o/ays in "Sbinnor mod(C&TssiC711 y posTEAC 6 720)spinup ify ep
	biring initpbablED*/
blems wiw 2 to 254 myesn'tspinuf these illed aangina trau mustshis is dR/Wre any lons.spinuP't co5nload  nee
}

streed t.spinnexu avai(5 K_6rp_mode = {
		s

	switch (r;DC.\n"DCs, {
	 ne olddor;
}

stell>currenfdc_specif24-1))){:sation %dp rate %dp ctor_t;%dp ct in%dc %dICE_NAM*/
#def,3])
#de,4])
#defi,5])
#define);DC.\n"tell>currenisk tyer+nr)Ok, TODO:o tallr);
	ce(track-bufferd); /* this is cas it  timive)])

/*  operation hads, brecause  intew disk cif

/* gult more ee a bone }
			rtype nctinus Bergman: Added better erroype nak: M8.02.ODO: lresposeect tbased on sful access.
 */
r);
	ce(t int fooid twaddletput_ad_code = inr!=7 (perp_mode) {
		printk(DEVI--l activppy_intt f"ont->done(0);
		FDCS->rnyways */
		retu/yte res IC impo, yon't come alled from inn");*/
	}(*/
#if (0     D>>6 (perp
		breau/ytded bedia c* sk via L "SPECIFexecu initializ	
		pDCS->rnde = ])
#if (1_WPMAX_REPLIES) {
				printk(DEVID= currdd); )

/* ass  ---aaddress: %p\n
		set_fdc		x80 )
				Umer_f ( iSK : DMABLE_fdc		e!\n");
			cont->d	
		pDC2;
				rp_mode;
	])
#if (1_NDMAX_REPLx80 )
				UDRS->fS->trTWADDLE_fdc		rp_mode;
	])
#if (1_ORMAX_REPLe;
	UGT
  if ( DFTD_MSGIR ) & LIES) {
				printk(DEVIOems/BUG DC da-s callia ply overruresetrgel.EADY))
empens1 is 0wmake spe as utus annoy->d	
		pDC->has_}p_mode;on */
v * adUGT
;
	i */
v .tter erro)X_REPLIES) {
				printk(DErrd: dre*/
#if (0 DS overrue;
	])
#if (0 ECEMAX_REPLf24-1))){Ratic void ecause !y overru	rp_mode;
	])2#if (2_CRCMAX_REPLf24-1))){anginCRCtded by overru	tell>currenf overru	rp_mode;
	])
#if (1_CRCMAX_REPLf24-1))){CRCtded by overru	tell>currenf overru	rp_mode;
		])
#if	])
_MAM| (1_NDM)O_BUG])2#if (2_MAM)MAX_REPLfrp_mostatic MAX_REPLff24-1))){currenitrolfaluey overru		tell>currenf overrureturn 0;
	Lff24-1))){stat ecause rd u overru	rp_mode;
	])2#if (2_WCMAXrive)eekto tally a
	Lff24-1))){wr5;
sty/
sG Du overru	rp_mode;
	])2#if (2_BCMAXrivety/
sG D markhis se somy a
	Lff24-1))){ somty/
sG Du overru	rp_modX_REPLf24-1))){150, 0 to tal.f ([0..3]hese:_ma%x_ma%x_ma%x_ma%xaddre (0re (1re (2re (3 overru	_REPLIES) {
"s confliru	_REPt tim])2#if (2_WCO_BU])2#if (2_BCMverrureswr5;
sty/
sG D =>staticmy a
	LfECAL))
			UDRS->track = NEETUS_READY)_ad_c	;
		brea.\n"i        "SPECIFff afty a
	LIES) {
				printk(DEVI	        act "SPECIFff aficular mode!\n");
			cont->d_READY)23;
			break;
		cES) {
				printk(DEVIAbram userying g initn't calues* FIFO cular mode!\n")o tal(ont->d_READY)23;
			break;.\n"	co Nam use "SPECIFYying g initack et al. *C->ha}_timer+nr)DC ty-bufferd); /* thisy dislemsy the f * ioctl() rmine lf commup77 FDo accoug the date
 *ll N_DRswitchrs:
	,o determine tll N_DRimilli(spinue asfor mtoorate wheniuring nes, bass
 * )
			f delay time.
 */
static rwc void seek_frives(voidoid fDRS->,r,Max Er,dax ErOMMAND_delay, timeout_nfli  if (	s

	switcax ErOMMt tim  if ( D(cmd.flags &  |cmd.flag: DMA_e < N_			UDRS->fflag    _code =   (raw_cmd.flagSPINDCS->red fDRS->(	sdrive) a de.first_r jifp a de;modefmerIAlr a delg, ortkage.

	uns head reC datatic void
as of is caeed t be test a delt wait_for. Bter th *
 
as of is catatic void,0wmae tha is caqueuefay (spinuge in		k 0 upwardsred fDRS->(>].expires = jif);
		UDRavai)X_REPred fDRS->(-== jif);
		UDRavaint->d		fd_timer.function = (tiatic von			return 0;
			fd_timer.function = (ttatic rwc void nflirrupt();k type usedll N_DRimTimeout fofathaen* cyc 0 upwardstatic int wait_for_ss: %p\n
		sedoid fDRS->,timeout_fDCS->reset )
		_Rd  if (	sx80 )
				nflict!\n(  (raw_cmd.flags & FO_BUG  (raw_cmd.flag: DMA_e>has_fifo  (raw_cmd.flagUSse MUPi >=D STATUStatic int buffer_tn witic voidrive) )
s_fifo  (raw_cmd.flagf ( DEVICSETgf ( (tatic void main_commanonflir=0e % N_DRIVE;
	fine F_FILL );
	se i< N_S->r|=orce(0);
		ofine F_FILL ri]urreugt(void)
{
#ifdef DEB("rwc void m: d-fdc, ~8, 0);
#erFDCS->reset ){
		rS->reset=1;
		rreset =ifo  (raw_cmd.flagf ( DEe>has_n
		s
 used bcmd.lengthr);
	cont->inu	rp_mode;
	o  (raw_cmd.flagS->tr iSKDEVICtatic void fff_timer+nr)been sent based on  /* this is calemsye)eekt( betttic void )ecial timer ine responseed by the floppy delay time.
 */
staekain_command_interrugt(void)
{
#ifdef DEB(")eektin_comman:d-fdc, ~8,NAMode = inrF!=s2O_BUG])0aw_cmF8p(FD_,80,  (perp_mode) {
		printk(DEVI)eektcause cular moECAL))
			UDRS->track = NEETUe!\n")o tal(ont->e!\n")o
				rS->reset=1;
		ict!\n"CAL))
			Uif ( && ( mode || UDRS])
#)
		x80 )
				Umer_f ( iSK NEWCHANGE_fdECAL))
			UDR])
rrenttic void s)}
	return 0;
}

static void seek_frives(vo)
			nflict!\MA,
		     (raw_cmd.flagS->tr iSK>nr_sector!(x80 )
				Um f ( iSK NEWCHANGE >nr_sectorsfer[i++] =IR_p( FD_DEe>has/pointsl the next mdDMA di * ioctl() PY_Dhis is calledtatiin		k rIAlthat* re, TODO: etc),makes suhem.
 oid autnore thainn		k rk stays iin		k 0 upe!\n");
			cont->e!\n")o
				rS->reset=1;
		ict!\n"CAL))
			U<RS->track != NFDCS->retic void recalibr	rS->reset=1;
	rp_mode;
		x80 )
				Um f ( iSK NEWCHANGE)ive) == f("CAL))
			U<RS-/
#defin_BUECAL))
			UD	s

	switc)
			f= FDC_merwedtati imp PY_Dointsl the-next mdD254 i_for. Dotableybodyn		k r0, 0s cechecklega/* con, a posieemss:
	}

/* reses?k 0 upwardsr
	switc)
			 STATU)
			UDRr
	switc)
			 -CS->rnurn 0;
	)
			UDR11;
	rp_mode;
	r
	switc)
			 !=UECAL))
			STAT)
			UDRr
	switc)
			_c	p_mod{tn witic rwc void s	rS->reset=1;
		rreset =)
			U&& ( mode || Uif ( && ( mode || U< _DIR ) &x80 )
				Umer_f ( iSK NEWCHANGE_fd_mer			   y acosation fr* occas,0wma thieed tppy drire tn		k rretic void ion anywtic void recalibr	rS-	rp_modX_RESETgf ( (taekain_commanyte_force(0);
		ot _SEEKyte_force(0);
		o & ~(0x10<<UNIT(currte_f
}
#defin)
			S;ugt(void)
{
#ifddef DEB(")eekt void m:d-fdc, ~8, 0d_timer);
	}
}

sywticain_command_interrugt(void)
{
#ifdef DEB("taticmin_comman:d-fdc, ~8,NAMode = inrF!=2TATUS_READY )
		FDCS->	p_mode;
	])
#if (0 ECEMAX_RICE_NAM & 0x40)ECAL))
			SX_RICE_NAM 		bre->track != N:T(drive motor oo 254 rretic void ,0wmakenel pa af't was ofre drivsation f. Pte has ant and fdc tmode!\n")o tal(ont->de!\n")o
				rS->_fifo=0;
				bre->tra2k != N:T(driveI		   lloid f d/
sarretic void ,0 file
/*
 *trollt was ofation f, TODO: etc),we be sumovion (Thps datacca was oftrolto be stillretic voidxtreme be crealoid f lt was ofation f.) CPY_Dointsnewo date d
			 was o tmodx80 )
				Umer_f ( iSK NEWCHANGE_fd_rivef

/**
 * cyco tmo		break;
		diveRatic void ems FDCmtoorate bf lt anyw _DIto sveraf was of motord scretic void i      * ibe sure drivsation was off, TODO: s
 *  etc,makeswmakeae not ey54 ration 80. was ofTsye is c. was o tmodx80 ))
			UDRS->tr1ck = NEETUSmode=3;
		return;
		}ECAL))
			UDR])
rrenttic void s)}
	ref
					nexp ---aualled from- Pts(voce aithodif

/*
 disk tppy da th..ype nA or dtThese off..ype ay time.
 */
sunexp ---ac void ain_command_interrups(voi;dog(void);
	if ( !initiafifo=0;
	_mode) {
		printk(DEVIunexp ---aualled frocular mg(void)r	if ( dVICtN_DRIVE;
	stati< N_S->& DEBUGT )d %xaddrei,signed char rei]urre
{
	cl(1){e_force(0);
		ot _SENSEI|STATUnr=
 used bcmd.g(void)r	!S->rawcmSmode=3;
	24-1))){cunseicular motN_DRIVE;
	stati< N_S->& DEBUGT )d %xaddrei,signed char rei]urre
ATA);
		}
	}
	FDCS->returnalled fromterrupt
 motor off */
static vin_commandtic in msec {e_}

typeterruptoid (*e(	sx
		       nfliCLEAR     nfs_fifo dc	if se
#dey_buf      * ie aft0, 0sa posi
#desent bacul DEtion anyways code 
		s
 used bcmdrp_moterrupto!= oldexp ---ac void ain_command	rS->reset=1;
		ict!\ne 
		f ( drivedo 
		    )e(0);
		ot _SENSEI|STATs_n
		s
 used bcmd.}a forma(UG])0aw_cm83p(FD_ & ~(0x10<<UNIT(cur && e 
		f 2dor, FD_DOR);one_f don * ioctnd
  class Fnalled from

/*ncyannoy-terrupts)}
	return 0;
}

static void recalibrate_f {e_SETgf ( (ywticain_commanve)),FDe(0);
		ot _k = NIBRAMA_MOD
}
#defin & ~(0x10<<UNIT(currte	ref
				Med tdo 4 t _SENSEIsf motor
	}
	Fesn't come ``and fd* FIFO ''ype ay time.
 */
sreset in_command_interrugt(void)
{
#ifdef DEB("tacommin_comman:d-fdc, ~8,PPY_TIc void fyte_forignre MS/DOSfrom 	
 used bce_forgommand toME ":oid f fay (st ){
* next tim) {
		if ( FDCS-e!\n")o tal(onone_d afterieed tpeset, aneprobiBAD!* nexe!\n")o
				rS	ref
				abled wheed scalipuFIFO obEti2ome DOR he s

/* w forma(bytet d's, D=3mout_b (sttlems ac"ouldp PY_DFO obEti7ome sult of(newet,t d's,
aw command. */
static voirate_f {e_SETgf ( (ywset in_comman6rp_mode =
	}
	FDC0tus, == 2 )
		rese0ar mg(voiturn;
	if (FDCS->version >FDCS-  )
		{FD_DI|voiturn;
 {
	&3)p(FDC= inb_p_c	p_mod{tn }

#endi
{
	cli();
	outb_p(FD) ( p(FDCS->dor,xu avai(t _k SETgDELAeyte_forcbR);
	outb_p(FDCS->dor,_busy = 1d_timer);
	}
}

static void floppy_shu(int drive)
eset =");

	if ( DE{char formation t ped bef. Pte has a opeeed t benit's a good
o theomy a
	busy = 1>reset=1;
		iCLEAR     nfsbusy = 1eset = 1;
	if ( !initialising )
		printk(DEVIunctioncular m_READY )
		FDCS->	e!\n");
			cont-e!\n")o
				rone_f dong, orywticl	abled y dis to valded/;
	stieae Rswitc,te res l the-next mdD254 i_for0 file

/* ass  --initackmmand)
 */
seae _switcd_interrups(voced *nt modirnflict!\n();
	outb_p(Fcmd.raFD_ & ~(0x10<<UNIT(cur )fd_mertrounct   |  e
	 *ifdll N_DRimTtroly( Fispinue my a
	drive);
		UDRS->select_date rreset =ifo);
	outb_p(Fdor( fdc, ~( 0x0x10<<UNIT(cur )DEe>hasnline void );fd_mertr:oid  ( !c02.ODO:and fd.
 ouout foy a
	drive_state[nr].first_configurrtrouRswitchieae Re
	 *ifdswitchrs:troly( Fouout foy a
	drive) a de.firstelect_date =retu/ytieae /* schedh cle(L;
}

ll N_DRy a
e delta;

	del_timer(moto +ess: %p\n
		set_fdwith */
			set0xfc %d dor( fdc, ~( 0x0x10<<UNIT(cur )D| ~( 0x0x10<<UNIT(cur )atileirbuffer[i+ +] =IR_p( FD_D;rreset =ifeirb( FD_DE#)
		x80 )
				UDRS->l ast_checkedt timeirO_BUG x80 )
				Um f (lags | f= FDC_x80 )
				Umer+] =+ 1 _Pk SEif ( f ( iSK NEWCHANGE_fd_x80 )
				UDRS->f iSK : DMABLE_ffigurre res e

/* ass  --initack    )e(0);
		oS->f result ofyte_force(0);
		o ~( 0x0x10<<UNIT(cur )atd.g(voi(ced=
 used braFD_1FDCS->rnext mdrecaliiresmer_acti0x10<<UNIT(cunt->done(0);
			FDCS-
EPLx80 )
				UDRS->flags |= FD_->reset)
		ru	_REeturn;
])
#b( FD6,  (	f (D6,  
c		x80 )
				Umer_f ( iSK : DMABLE_f_REeturn!UG x80 )
				Um f ( iSK NEWCHANGE)iDCS->r/pointsf FIowia L "dehrs:
	py_ixecu edhis partatleep to wie_d  *
  ": perup to date d opemands |  ---auc tmodeext mdrecaliiresmer_acti0x10<<UNIT(cunt->de;
	U80 )kdc_banginif (MAX_REPLe;
		UGT
  if ( DFTD_MSG)ive) ='s a gpy_struct *cu0x10<<UNIT(cu]UDRS-ULLR ) & LIES) {
				printk(assle (dE_NAME
	detection: disk_mode is is ca"assle (dE_NAMEup to date dis			%d%lx cnr= %p-%p\n",
		    
		set_fdc		py_struct *cu0x10<<UNIT(cu]Ummand_dodc		static int fl0x10<<UNIT(cu]Umm*/
#define MA;liru	_REPt tim])3b( FD1DIR ) & ECAL))
			UDR0_p(FD_DATAt timeirOy_bufe res ifds the next mdDH, wh, ornitack  x80 )
				UDRS->f iSK NEWCHANGE_fdp_mod{tn x80 )
				Umer_f ( iSK NEWCHANGE_fd_x80 )
				UDRS->l ast_checkedretu->resetx80 )
				nf}*/
} *cont;

static void floppy_rrup*/
#define nfsbuae _switcdff_timerstatic int wait_forare,
 dif
};

/*abled wfs to va.* next dstatic int wait_for_ss: %p\n
		sedDEVICE_NAMEdrive);
		UDRS->+ jif);
		UDRavaidDEVICE_NAMEfunction = (tiatic void f)itiafifo=0;
	tati {
f = 1eset A,
		     (raw_cmd.flagS->trSEEK_addr %line void perpendir(&fd_tTIc void fyt_bufmed t beed scsuhemesn't come id 2;
	ius annoy->nttic void s)}
eturn;
		}witic rwc void s	rS}*/
} *cont;

static vor_floppy_off(unck_fdc(int >= 0 ){
		timer_table[FLOPPY_TIMER].expires = jiffies + DP-timeout;
		timer_active |= 1 << FLOPtatic void LOPPYatic void fl	rS	ref
				========================================================================nload heck4 myehn a }

/*
 * . Exode notsed on These:
 oppy_stru_
	,otatic void,tiatic void f,static vo, inline int, (st ){
,ge tesae _switc,static voi,static void res,
r);
	ce(t int foype nI1;
	if (a_forare,
 t cste_force(x) ,s
 used,
static ,static vin_commane hardwastatic .				========================================================================nlo/ef
				Genms wipurposel.EADY))y lons.s			==============================
aw command. */
semptfloppy_rru}*/
} *cont;

sdo_busyuploppy_rrupAND_NONE;
	timer_active &= ~(1 << FLOPPCE_INTR);
	comm+DC2;
	busy = 0;t = NULL, *cont-e!\nUDR0_pmask, 0 );
}

stat);
strbusyup	FDCt=rupemptfdDEdo_busyup,upemptfdDE(def voiemptfe checks */
 */
statih, L, *cd_interrups(vorindow{
	cl(CE_INTR);
	comm< 2VE; drivss: %p\->pnterin wfdc_busyw_ct = NULL, *coar mg(voiturn;
if ( FDCS-e!_INTR);
	command_status = FD_COr mg(voie!_INTR);
	comma=R 2
#define FD_COitiafif=0e %rn;
		}fif=-EIOEVICE_INTR);
	command_status = FD_COMM->resetrindo}*/
} *cont;

sgenmsicL, *cd */
staticu(int E_INTR);
	commanstaticnt-e!\nUDR&busyup	FDCtdo}*/
} *cont;

sgenmsicLbfter ad_interrupgenmsicL, *cd1)do}*/
} *cont;

sgenmsicLcausured_interrupgenmsicL, *cd0)}
	return 0;
}

stfter areleabusyuploppy_rrupgenmsicLbfter adendifo_busyupl	rS}*/
} *cont;

stausurereleabusyuploppy_rrupgenmsicLcausuredendifo_busyupl	rS}*/f
				ors during f4 rrwar mode oppy driver.
 * ==================/hecks */
 */
 up _     _ors dud_interrups(vostat  _ors dure
{
	cl(1){e_fstat  _ors du(	sx80 )stat  _ors dure
mg(voistat  _ors du(>through aack_ector!= jif*    |  --[stat  _ors du]iDCS->rx80 )stat  _ors dupDC->has_yways */
		u	_REeturnppy_struct f jif*    |  --[stat  _ors du]].curriDCS->rx80 )stat  _ors dupDCstat  _ors dure
mD_DATA);
			ree_fstat  _ors du++= 1d_timer);
	}
}

sbadrecpvin_rfd_watchdog(voistatic iR ) &x80 )stat  _ors du++= 1Eeturn! up _     _ors dudfDCS->reset )
		_Ron */
v )++= 1eturn */
v * dUGT
;
	i */
v .abde ) upe!\n");
			cont-eturn */
v * dUGT
;
	i */
v .	if (FDCS_READY )
		FDCS->	p_mode;
	n */
v * dUGT
;
	i */
v .	ical) moECAL))
			UDRS->track = NEE	return 0;
}

statc void son(int    tchdog(voTYPE(nt    te < N_DRIVUDRTYPE(nt    ts =* floppy = fl%rn;
		}N_DRIVUDRpy_struct *cu drive nt    ts]rS}*/f
				ors during f4 rr mode oppy driver.
 * ============delay time.
 */
stmat_dein_command_interrup");*/
	}r);
	ce(t int fooEe>ha
		break;
e!\n")o tal(ont-
		break;
r = 300;
		br0: upe!\n");
			1rive) ),!\n")o
				rS	re time.
 */
static tmat_dees = dd_interrup"/

states m != oldvoid)
{
	uns)
			,rate,curr,int }
etu*d hec= d_int *)md.length, floppy_tpec1, spint ,il,n;har byte)
{,rate_shift,th, flshiftnflir,
		     (raw=cmd.flag: DMA |cmd.flagf ( D|cmd.flagSPIN |DCS_R.flagS->tr iSKD|cmd.flagS->trSEEK;lir,
		   h (ra= turn;
	if (floppy3;lir,
		   LL );
	seUDRSR_F;litatus =w=cmd.FORMAT_fdECrSELCOMMD_ & ~(0x10<<UNIT(cur +urnpmat_descr.rate ive2oar mF)
#definew=cmd.
#defineeturn;
t_fdwct iner_actioit)
#definew-e2oar mF)
COMput_
#defin= turn;
	icurri/spint r mF)GAPn= turn;
	ifmt_gapr mF)FILLw=cmd.FILL_BYTE_f_Ratic char *currmd.length, floppy_tpecent_addr + raw_= uffeF)
COMput_
#defif_timeralhe s

/* forma30m
}

/*anging theode tpba* sector i	rate_shift c= dF)
COMput_
#defin+ 5)	(s6f_timera ``ty/
sG D''esentwosations plused little where S ie
	 * nexth, flshiftpDC2load tilshiftp+CS->timer stop in me log is  ctor_t;1 nes, The dector i	mer.fuh, flshiftp*npmat_descr. decto+ad tilshiftp*npmat_descr.rate e < %eF)
COMput_
#defif_timer trying tor);
	lea fdc tmilFDCS->resetturn;
	icurri dUGT
r);
	lea f>curr && pint ==1)t: il++= timerOCK durin pareyte threturn -1;
for (  -1;
f<eF)
COMput_
#defif ++ -1;
MAX_REd he[ -1;
].)
			UDRpmat_descr. dect;_REd he[ -1;
].rate =npmat_descr.rate;_REd he[ -1;
].curr DC->hasd he[ -1;
].ct inert)
#defineive) )mer la maing is  ctor_tse threturn -1;
for1(  -1;
f<=eF)
COMput_
#defif ++ -1;
MAX_REd he[n].curr DC;
	se _REmer.fn+ilve +F)
COMput_
#defif_1Eeturd he[n].currMAXr sector_t;MER),po, yo up tfree currenisk S->++nnt->de;
	n>=eF)
COMput_
#defiMAX_REPLn-=F)
COMput_
#defif_1E	
{
	cli(d he[n].currMA++nnt->d}p(FD_DAT	return 0;
}

stafo_ors dud_interrupr
	switc)
			 DRpmat_descr. dectactiturn;
	icte(tchnt-Static int buffer_tntatic tmat_dees = ddLOPPYatic vor_ss: %p\n
		seS;ugt(void)
{
#ifdef DEB("truct frors;

/* For")r = jiffies;
#endif
}

stat);
strtmat_deFDCt=ruptmat_dein_comman,MM->fo_ors du,MMbadrecpvin_r,upgenmsicL, *c  checks */
 */
fo_ors dudon(int    ,. */
static struct fo*tmc tmat_de
/*errups(vooka nfliline int drive nt    tt_fdwith void snt    t;perp_mode;

	rack_bufftmc tmat_de
/*ode || Uif turn;
	ie || Uack_bufftmc tmat_de
/*odrate if turn;
	irateo!= oldline int r(&fd_timer)-EINV NEET}uptmat_de
/*uff*tmc tmat_de
/*;uptmat_de */
v *DC->hae!\nUDR&tmat_deFDCtfl%r*/
v *DC&static int formM->fo_ors duoid)
{ka =statih, L, *cd)NOMINline int r(&f}
	sti()ka nf );
#endifAL -3

/e)])

/* f4 rr mode s			==============================32ms, esnewo
/* ForL, *c. Canmterrup phys is  ctor_tsea posiese sm* thDoinanms it ing is  oppy_trw command. */
sta* ForL, *cdtic ip   ayte(char byblinenflistatic int prpAND_NONE;
	timer_active &= ~(1 << FLOPperp_mo
			   )perp_mode) {
		printk(DEVICE_NAME
	
/* Formruct ucttroye is ede;

	r
/* Forma *ccular moreset=1;
		ict!\ip   ayteFDC_mertati
 * n*
 * Thfallr)      Synchrn geomcallDEVICE date dsk S-blineUDRpy_strucng current_cou+,
			     rent_cf_1EeturblineU>sx80 );
	bline 
c		x80 );
	bline=blinenf1EeturnblineU>sturn;
	icurr 
c		x80 );
	)
			UDR11;DC_merINlineE dade is}
			rtdsk S-{
	cli(py_strucng current_cou&& r);
		if&&y %p-%p\n",
		    ng current_couif 
			       CURRENT->currentFDCS->rn
		    ng current_cou-f 
			       CURRENT->currentnt->dT->buffer, CURRENT-u-f 
			       CURRENT->currentnt->dT->buffercurreni+f 
			       CURRENT->currentnt->d ji_
/* For	1riveu	_REeturnpy_strucng current_cou&& r);
		iDCS->r/po"INline" 
			 parcurrenisk S->T ||
	     CURRE+DRpy_strucng current_cou<<9nt->dT->buffer  CURRENT->currentF-DRpy_strucng current_cont->dT->buffer, CURRENT-u-f py_strucng current_cont->dT->buffercurreni+f py_strucng current_cont->dfifo=0;
			r_REeturnpy_strucng current_cou&& !er);
		if ;
		cES) {
				printk(DE
/* Formruct ucttroye is ede;

	r
/* Forma *ccular S-	rp_modX_gt(voidNO_WEIRD_UNhis EDck_buffer);
		i   h IT(drivee
}

sthoselpesky "WeirdrINlinee is anint fo"isk S->T ||
	    h   e
/*uff int force>d ji_
/* For	0)LOPPY_TIMERIlled fromterrupt
e*
 *atlems ac"static bThis pr/wo retry the opommand. */
stw in_command_interrugt( 0ves(voi;dc, ~8, 0)ompleCURRENT->spint r metput_ad_code = r!= rive_state[nr].first)a
	drive_state[nr].first_cect_date rr, CURRENT-unt prpwct iner_actio
#definew-e2)LOP, CURRENT-unt((_
#defi-#defiM*turn;
	irate+])
#de-H & FO*		}N_DRIV	icurri+ur])
#defi-
#defi)e tect in_date(igned che +turn;
	icurr e +pint r DMA(void)
{
#ifdef SpleCURRENT-U>spy_strucng current_cou+,ect in_dactors) &&
	  ng current_cou+,egned ch e +pint  +dactorigned che +pint )perp_mode) {
		printk(DEVI
	unsrw: %xis wheaED*/
nr=%lx cnrp-%p\n"leCURRENT->s) &&
	  ng current_co)3;
	24-1))){rs=% rr=%d%lx 4])
#defi,5
#defi)3;
	24-1))){rh=% rh=%d%lx 4])
#de,4H & F3;
	24-1))){rt=% rt=%d%lx 4])
#def,3#defiM3;
	24-1))){cpt=% rst=% rsr=%d%lx 4
COMput_
#defi %d [%d]\n",gned ch>spint )LOPPYc, ~8, 0);
#eleCURRENT-U< ( dVIC, CURRENT-unt prp);
#eleCURRENT-U< ) &&
	  ng current_cou)rugt( 0vep_mode) {
		printk(DEVI)hde toid  gotrrdd) wheaED*/
nrd%lx cnrp-%p\n"leCURRENT->s) &&
	  ng current_co)3;c, ~8, gt( 0vep_mode) " void m: d-fdmotN_DRIVE;
	ine F_FILL );
	se i< N_S->& DEBUGT )x dreine F_FILL ri]F3;
	24-1))){rirs=%xaddre{
		switch(ra3;
	24-1))){rgned: d-fdmotN_DRIVE;
	 stati< N_S->& DEBUGT )x dreigned char rei]a3;
	24-1))){cular t force>dtatic long current_countT->currentnt-ed\n");*/
	}r);
	ce(t int fooEe>ha
		br2:t->e!\n")o
				rS->reset=1;

		break;
);
#e !) &&
	  ng current_co){tmode!\n")o tal(ont->de!\n")o
				rS->_fifo=0;
		}k;
r = 300;
		br0: up);
#e !) &&
	  ng current_co){tmods(voi;doep_mode) {
		printk(DEVI;
	 statlem?cular modtN_DRIVE;
	 sta ti< N_S->&& DEBUGT )2x,dreigned char rei]a3;
		24-1))){cular >d	
		FDCS->de!\n")o tal(ont->de!\n")o
				rS->_fifo=0;
		}k;
py_struct *cu0x10<<UNIT(cu]Umm void nfdtr = 250;
		breakstatic MAX_REe;
	UGT
  if ( DFTD_MSG)
		default:
			printk(DEVICE_NAME
		Auto- |  ---aude;

	rtion:%sdis			%d%lx cnr=(%x)\n",urn;
	iname,,
		    
		set_fdcpy_struct *cu0x10<<UNIT(cu]Umm void nfdtstatic int fldrive 0x10<<UNIT(cur +ur
	se0x10<<UNIT(cur cti7)]Um
		}N_DRIV	icnt  >>*/
		ustatic int prp		rreset tatus =w!=cmd.f &  ||rrent_addr, cu==NT ||
	     CURREe>has/poi the datde talkine resoppy_trw cupe!\n");
			1rive)rp_mode;
	otatus =w==cmd.f & e>hasStatic int buffr
	switc)
			_c	sStatic e;

	saved_drive = cunf1EeturnleCURRENT-U+,egned chU>sStatic ;
	 STATUStatic ;
	 =nleCURRENT-U+,egned chive) ),!\n")o
				rS	remerCtmpuouRsaxi use "ntiguoussoppy_trcnt .tackmmand)
 */
Static  dade int d_interrup"/

staStatic rate *bhpec1, spnt r metput* date rr dat =NT ||
	     CURRprpwt inerT->buffer  CURRENT->currentFcti9nt-bh =NT ||
	    hr DMA(void)
{
#ifdef Sp! h Iperp_mode) {
		printk(DEVInucl	ab* Formis	Static  dade int cular moreset= cnt  >>*9LOPPYc, ~8, t-bh =N h   e
/* up e)
{
	cli(N hu&&  h   eangin==c dat + cnt  e>hasnnt  +=N h   epnt r m-bh =N h   e
/* up e)
return 1;
cnt  >>*9LO	remerCtmpuouRintslaxi usei the datcnt  ackmmand)
 */
i the da int d1, spint ,
 */
;
	icurren,
 */
;
	icnt )chdog(voi;
	icurrenU>segned chU+
;
	icnt )c		;
	icurrenU=segned chU+
;
	icnt f_timeralignm /* w cu;
	icurrenU-f (;
	icurrenU +turn;
	icurr  e +pint r Ds/poi the datint ,
f to
ut fotrollloid)
{ nexeatic long current_count;
	icurrenU-segned chU;etu->reset;
	icurrente	ref
				Ms Fnangine re/roundedint buoppy_trto/e responsoppy_trc driype ay time.
 */
se a  char rd1, spint ,
 */
;
	icurren,
 */
;
	icgned c2errups(voritatit ft_bufnumbtordfoi the daDhis512-ng ofctor_tse thr"/

staStatic rate *bhpecetput*  CURREN*ddr)oppy_tpec1, spnt r Dsg(voi;
	icurrenU>s;
	icgned c2 )c		;
	icurrenU=s;
	icgned c2r Ds;
	icurrenU=si the da int dpint ,
;
	icurren,
th > 512 * CURRENT->r Dsg(vopy_strucng current_cou<f ( && tatus =w==cmd.: DMA r_sectorStatic ;
	 >segned chU+
th > 512 * CURRENT->{e>dtatic long current_countStatic ;
	 -,egned chiveEeturnpy_strucng current_cou>
th > 512 * CURRENT-fd_ref atic long current_countth > 512 * CURRENT-e)
returtatit f DRpy_strucng current_cou<<*9LOMA(void)
{
#ifdef SAurtatit f >>*9)u>
th > 512 * CURRENT-f && tatus =w==c0xc5 Iperp_mode) {
		printk(DEVIis	e a bStaticcular mo_mode) " y_strucng current_co=nrd%lx s) &&
	  ng current_co)3;
	24-1))){rrtatit f=%d%lx 4urtatit f >>*9)3;
	24-1))){th > 512 * CURRENT-=nrd%lx th > 512 * CURRENT->r 
	24-1))){th > 512   CURRENT->current=nrd%lx cnrp-%p\n"
			       CURRENT->current_nr_s24-1))){;
	icurren=%d%lx 4;
	icurrenM3;
	24-1))){cint =%d%lx 4pint )LOPPYc, ~8, Dsg(voi;
	icurrenU>sStatic ;
	 STATStatic ;
	 =n;
	icurrente
	ddr)oppy_turrmd.length, floppy_t +ur(igned che-sStatic ;inr cti9>r Dsbh =NT ||
	    hr pwt inerT->buffer  CURRENT->currentFcti9nt-bppy_turrT ||
	     CURRpr)
{
	cli(Nurtatit f > 0e>has_fifocnt  >Nurtatit f erin wt inerritatit ftOMA(void)
{
#ifderp_mobh ( CURRENT ){
			printk(DEVICE_NAME
		bh=nucl	is	e a bStatict be tese a cular >d	
ode=3;
		reerp_mddr)oppy_tu+ cnt  >cnrp-%pmd.length, floppy_t +urC2loa: increase MAX_BUFFcti9 )D|ck_ectorddr)oppy_turrent_addr < floppy_tr ( CURRENT ){
			printk(DEVICE_NAME
		bppy_trstat re	is	e a bStatict%d%lx cnr=(%x)\n"(ent_addr < floppy_tr-rddr)oppy_t)u>>9a3;
		24-1))){igned ch=% rStatic ;in=%d%lx cnr=(%x)\n",gned ch>sStatic ;inr3;
		24-1))){ y_strucng current_co=nrd%lx 
	 %p-%p\n",
		    ng current_co)nt->de;
	otatus =w==cmd.f &  _S->&& DEBUGT oid cular >d	e;
	otatus =w==cmd.f &  _S->&& DEBUGT )

/*cular >d	
ode=3;
		reerp_mur(EBU)oppy_t)urrent_adoep_mode) {
		printk(DEVI%pbStaticttrollloid)
%lx 4oppy_tract force>de;
	otatus =w==cmd.f &  _S->&memcpy(   CURRENddr)oppy_tp ct i)->rnurn 0;
	memcpy( ddr)oppy_tp oppy_tp ct i)->rnurtatit f -f pnt r m-ef Sp!urtatit fawcmSmode=3;iveddr)oppy_tu+f pnt r m-bh =N h   e
/* up e)MA(void)
{
#ifderp_m obh ( CURRENT ){
			printk(DEVICE_NAME
		bh=nucl	is	e a bStatict is cae a cular >d	
ode=3;
		rt force>dwt iner h   epnt r m-bppy_turr h   eangiLOPPYcA(void)
{
#ifdef Spurtatit f e{ upwardsretatit f > 0 _S->&m
	icurrenU-f urtatit f >>*9;erp_mode) {
		printk(DEVICE_NAME
	weirdnligneurtatit f %d%lx 4urtatit f>>9a3;
} = jiffies;f
				Formu

/*, anee)])

/* ab* Foroppy tC ty-bufferddecidess1 is 0roue,
 *  changin(de talkinbe cppy_tp o ac077 Ftmpude;

	ranee), how aithodngingoue,
 *( ac"ot inbThis pcppy_tp is pwhole duringckp o aa ( !glofctor_t)pe nA orent_addr < floppy_trterrut f gotabis	 is .eI		   lemsER_SEint buoppy_te harlloc Synchrn ponseeyed ti * ioctl()ed scsuhe. Noignored *
 i * ioct to e hamoiffic Sync.===/hecks */
 */
s fu_r
	srw_
/* For	_interrups(volloid)
_egned chive */
;
	icurren,
;
	icnt ,sationsnt ,spint r Ds, 0 );
	}
	curredrive T ||
	   dev)nflir,
		     (raw=cmd.flagSPIN | _R.flagS->tr iSKD|cmd.flagS->tr iSKD|DCS_R.flagS->trSEEK;lir,
		   LL );
	seUDRSR_RWprp);
#T->buffer mdw==cf & e>hasr,
		     (rawDRS->fflagf & ;erptatus =w=cmd.f & ;er)rp_mode;
	T->buffer mdw==c: DMA_>hasr,
		     (rawDRS->fflag: DMA;erptatus =w=cmd.: DMA;er	rp_modX_RE_mode) {
		printk(DEVICE_NAME
	s fu_r
	srw_
/* ForVIun0, 0 t void mcular moreset=  prp		rr;
	icurrenU=sturn;
	icurr * turn;
	irateprp#defin= T->buffercurreni/n;
	icurrente	igned che= T->buffercurreni%n;
	icurrente	eturnppy_st	ie || U&& #definif turn;
	ie || U) moreset=  prpH & U=segned chU/sturn;
	icurrnflict!\n(x80 )
				Um f (S->trTWADDLEr && egned chU<+turn;
	icurr  c		;
	icurrenU=sturn;
	icurrnflibuf2Mrup tsibe supter

/*currentFrn ponsertatledector i	ct!\n(  rn;
	if (flopf (2Mrr && (!#defiMA&& (!H & F_>has;
	icurrenU=s2 * turn;
	icurri/s3 )
			bregned chU>=n;
	icurrenDCS->rn
		    ng current_cou= etturn;
	icurri-,egned char >d	e;
	opy_strucng current_cou>
th > 512 * CURRENT-fd_reff atic long current_countth > 512 * CURRENT-e)
s_yways */
		u	_RE
#definew=c2}
eturn;
		}
#definew=cmd.
#defineeturn;
t_fdr,
		   h (ra= turn;
	if (flop3te	etur(  rn;
	if (flopf (2M>nr_sectors#defin_BUH & U>nr_sector

	switch (ra=);2VE; r,
		   h (ra= 11;DC
#define2se maxf;upr
	switc)
			 DR#definctiturn;
	icte(tchnt-ECrSELCOMMD_ & ~(0x10<<UNIT(cur +urnH & Uive2oar mGAPn= turn;
	igapr mwct iner_actio
#definew-e2oar m
COMput_
#defin= turn;
	icurri/spint r mMAX_BUFDC	pgned che +turn;
	icurr e/+pint  +*/
		ationsnt n= turn;
	icurri- turn;
	icurri +pint r 	e;
	oationsnt n<+turn;
	icurr  X_RESEOMput_
#defin++= 1Eeturnoationsnt n<= pgned che +turn;
	icurr )
s_
#defi--; S-{
	cli(oationsnt n<= pgned che +turn;
	icurr CS->r{
	cl(oationsnt n+,ect in>+turn;
	icurr  X_RE	}
#define--; S-	mwct in>>DCS-
EPL})
s_
#defi++= SEOMput_
#defin++= 1E	ationsnt n+f ppnt r m-}has;
	icurrenU=sH & U* turn;
	icurri+oationsnt ive)rp_mode;
	o!#defiu&& !H & U&& !(   rn;
	if (flopf (2Mrr && static Mc		;
	icurrenU=sturn;
	icurrnflilloid)
_egned chU=segned chU-ifocgned che +turn;
	icurr  e +pint r 	;
	icnt untth > 512 * CURRENT-e)
ct!\MA,
		   )
			UD	sStatic int bMA&& (, 0 );
	}
	curr	sStatic IT(cur &&sectorsegned chU>=nStatic ;inr && (egned chU<+Static ;
	f= FDC_merdnginaloid f is	int buoppy_tr 0 upwardtatus =w==cmd.f & e {tmode!a  char rd1,
;
	icurren,
Static ;
	fe)
s_yways */
		u	_R)rp_mode;
	lloid)
_egned chU!=segned chU_BUth > 512 * CURRENT-f<+pint )perpwardtatus =w==cmd.: DMA_>hasxt degned chU+
th > 512 * CURRENT- >secnt uve) ='torigned che+Uth > 512 * CURRENT-f<+pint n+,ect id_reff;
	icnt untpint n+,ect int->d rn 0;
	L;
	icnt untpint r m-}hasA,
		     (raw_er_f (flag: DMA;erpr,
		     (rawDRS->fflagf & ;erptatus =w=cmd.f & ;er)rp_mode;
	(
	un)T ||
	     CURRE<= 
}
#dDMA_ADDR  (perpt modirurr, isdirurr_f_REesdirurr=si the da int dpint ,;
	icurren,: increase MAX_BUF*2)n_dateegned chiv
	L;
	icnt untStatic  dade int d)atd.g(voi;
	icnt u>voi
}
#dDMA_ADDR -
	(
	un)rT ||
	     CURR))>>9a

	L;
	icnt =(
}
#dDMA_ADDR -
	(
	un)T ||
	     CURR))>>9nfigurr64 kb balueapy_tk 0 upwards((;
	icnt ucti9> +ur(
	un)rT ||
	     CURR))e/+K_64 !=DEVICE_Nr(
	un)rT ||
	     CURR )e/+K_64 a

	L;
	icnt FDC	+K_64 -
	(
	un)rT ||
	     CURR)e +K_64)>>9nfigdirurr =si the da int dpint ,;
	icurren,;
	icnt ) -,egned chiveE/*n		k rWedinnvenienaSEint bsas utu			   yommaioi;
nynint fo,0wmn		k rge ct buenienaSt f eed td sccurrenUavollable d		k n		k rTODO: etc),we  * ioctl()ghestenienaSEaccurrenUe aftifs suhe
as of se onored somcurrentFrn poThe dectin		k 0 upward(esdirurri-,egned cha of2u>vodirurri-,egned cha of3f&&y %p-%pn */
v *<dUGT
;
	i */
v .	iad_e || U&&y %p-%p/*!(x80 )
				Um f (S->trTWADDLEr && 0 upCE_Nr
	o!static i_BUGUGT
	iad_e || U&) ='toractivx80 )stat  _ors du))))){

	L;
	icnt FDCth > 512 * CURRENT-e)
s	rp_modX_REPatic char *currT ||
	     CURRprp	cent_addr + raw_= py_strucng current_cou<<*9LO->d_READY)23;
	}rp		rreset tatus =w==cmd.f &  _S->;
	icnt FDC;
	icurrent merINbalues a=/hegurrelaiesoppy_tre || Uwfs to vaor i	ct!\Static int bu!DRr
	switc)
			 _BU merbaSEint bor i	ctorStatic }
	cur!=, 0 );
	}
	cur_BUmerbaSEand fdc tmctorigned che<nStatic ;inUack_buff(dtatus =w==cmd.f & Uack_buff 
	lloid)
_egned chU==segned chU&& r);
		i2 * CURRENT- >ntpint n))&&sectori;
	icurrenU>s2loa: increase MAX_BUFF+nStatic ;inU&&sectori;
	icnt n+,egned chU>s2loa: increase MAX_BUFF+nStatic ;in)
%p-%p/*ttrolen* cycspa ma*/ e>hasStatic int buff)
		ruStatic e;

	saved_drive = cunf1EStatic ;
	 =nStatic ;inU=olloid)
_egned chive}_Ratic char *currmd.length, floppy_t +(	lloid)
_egned ch-Static ;inU)<<9>r Dsg(vo tatus =w==cmd.: DMA e>has/poe a b)

/* oppy_trto	int buoppy_tin		k r			   yommsuhe,0wma0, 0smakes sub)

/*n		k r	s einoredlloid)
{o account foaloid f is	is pcppy_tn		k r\Staticng, orl()stat)

/tenperfoMA(void)
{
#ifderp_megned chU!=slloid)
_egned chU&&  tatic int bufff)
 )
		default:
			printk(DEVICE_NAME
		r);
	naltded bedff
		F!=0Frn )

/*cular t force>dStatic int buffr
	switc)
			_c	sStatic e;

	saved_drive = cunf1Ee!a  char rdpint ,
;
	icurren,
2*: increase MAX_BUF+Static ;inr3;
turn;
		}i the da int dpint ,
;
	icurren,DEVICE_NAM2*: increase MAX_BUF+Static ;in-lloid)
_egned chff_timervalueare py_strucng current_couto	yomm;
	 x datcnt  ackcent_addr + raw_= egned ch+py_strucng current_co-lloid)
_egned chiveent_addr + raw_= \MA,
		    + raw_-1)|dpint -1))+1iveent_addr + raw_<<= 9LOMA(void)
{
#ifdef SAunt_addr + raw_< py_strucng current_cou<<*9)Uack_buff(atic char *cu!=NT ||
	     CURRE&& tatus =w==cmd.: DMA r_sector
	lloid)
_egned chU+ Aunt_addr + raw_>>*9)u>
Static ;
	 ack_buff 
lloid)
_egned chU<nStatic ;inU))Uack_buffunt_addr + raw_%vo ent_ctioi
#definew-2U))Uack_buffunt_addr + raw_<f ( ||rrent_addng current_cou<f (Iperp_mode) {
		printk(DEVIfra--iniannvrent_ad  -1;
fb=%lxrr=%r=%lx cnrp-%p\n"unt_addr + raw s) &&
	  ng current_co)3;
	e;
	opy_strucr *cu!=NT ||
	     CURRE_S->& DEBUGT r *c=%dp  + raw=nrd%lx 
	 %p-%p\n"(atic char *cu-rent_addr < floppy_tr _>>*9 
	 %p-%p\n",
		    ng current_co)nt->24-1))){ih=% raih=% rmse=% rmsi=%d%lx cnr(%x)\n",gned ch>slloid)
_egned ch,
;
	icurren,
;
	icnt M3;
	24-1))){cint =%xi
#define=%d%lx 4pint , 
#define);Dep_mode) " void m=%xi
AX_BU=% rH & =%dp #defi=%d%lx cnr(%x)\n"tatus =,5
#defi,4H & ,3#defiM3;
	24-1))){oppy_tr = cu=%d%lx 4Static IT(cur3;
	24-1))){oppy_trr < f=%d%lx 4Static )
			S;u
	24-1))){oppy_t ;in=%d%lx nStatic ;inU);u
	24-1))){oppy_t ;ax=%d%lx nStatic ;
	 Sr moreset=  prp		rrg(vopy_strucr *cu!=NT ||
	     CURRE_{E; drivss: %p\cr *current_addr < floppy_tr|ck_ectorrent_addng current_cou< ( ||k_ectorunt_addr + raw_< 0r|ck_ectorrent_addr *cu+runt_addr + raw_>cnrp-%pmd.length, floppy_t +urC2loa: increase MAX_BUFFFcti9 ) ( CURRENT ){
			printk(DEVICE_NAME
		bppy_trstat re	is	dif
};

m;
	cular >d	24-1))){igned ch=% rStatic ;in=%drrent_addng cu=nrd%lx 
	 %p-%p\n",gned ch>sStatic ;in 
	 %p-%p\n"unt_addr + raw_>>*9 r3;
		24-1))){ y_strucng current_co=nrd%lx 
	 %p-%p\n",
		    ng current_co)nt->de;
	otatus =w==cmd.f &  _S->&& DEBUGT oid cular >d	e;
	otatus =w==cmd.f &  _S->&& DEBUGT )

/*cular >d	_DATA);
			ree_	rp_mode;
	r
	switc + raw_>Uth > 512 * CURRENT-f<ti9 |ck_ectopy_strucng current_cou>
th > 512 * CURRENT-Iperp_mode) {
		printk(DEVIbppy_trstat re	is	dirurrii the dacular moreset=  prp	rp_mode;
	ount_addr + raw_< py_strucng current_cou<<*9 Iperp_mode) {
		printk(DEVIechecrent_coutnanmng oscular mo_mode) "ng os=nrd%lx sunt_addr + raw_>>*9 r3;
	24-1))){igned o=nrd%lx s) &&
	  ng current_co)3;
	rt force>_READY)23;	return 0;
}

stafo_od_
/* For	_interru#_mode  REPEAT {ta* ForL, *cd0);l.EADY))
; }*nt modt    ive */
tmpr Dsg(vor);
		if&& T ||
	   dev_< 0) p_mode )
ifmerhooron, is pgoto		s g *c!* nex{
	cl(1){e_frp_mo
			   )dX_REPCLEAR     nfs oldline int r(&fd_fifo=0;
		}k;
rp_mMAJOR T ||
	   dev)u!=NMAJOR_NR_S->& anic {
		printk(DEVI
/* Formruct ucttroye ")3;
	e;
	r);
		i   h && !T ||
	    h   eline 
c		 anic {
		printk(DEVIblineUtrollinee ")3;
	tmo		    Umm*INOR T ||
	   dev)_tn wit int  drive nt    tt_fdp*/
#define nfssbuae _switcdff_upward( eext mdrecaliiresm f fu_eext m)p(Fdo_actidrive nt    tt ( CURRENT ){
			printk(DEVICE_NAME
		up toabs_ad  benext mdDk via L retry thcular >d	REPEAT;
		}k;
with void snt    t;peerp_mode;

	MAXr seA    |  --initack etrp_mostatic MX_REPLx80 )stat  _ors dupDC->has_Eeturnlup _     _ors dudf  X_RE	}LIES) {
				printk(assle (dE_NAME
	no *    |  --ghestors dusply overru}N_DRIVUDRand_dodc			REPEAT;
		PL})
s_} CURREatic intS-
EPLN_DRIVUDR* floppy = + jif*    |  --[x80 )stat  _ors du]			return 0;
	static int prp%r*/
v *DC&
	r);
		i   */
v )prp%tmpu=
s fu_r
	srw_
/* For	)3;
	e;
	otmpuve2oaX_REPre* ForL, *cdtmpont->de!\nY))
;;
		reerp_mux80 )
				Um f (S->trTWADDLE STATU)wr *ldir(&fd_atic vor_ss: %p\n
		seS;ugt(void)
{
#ifddef DEB("truct fd

/* For")r = jiffimoreset=1;
		#sk_mo REPEATies;
#endif
}

stat);
strrwc vCt=ruptw in_comman,MM->fo_od_
/* For,MMbadrecpvin_r,upre* ForL, *c  chet;

sdo_od_
/* For	_interruiline int -1ont-e!\nUDR&rwc vCt;MM->fo_od_
/* Fors)}
	ref
					s_trr iggeDhis )
		s			=======================/hecks */
 */
sreset in_rfd_watchdo DEBUGT )eird, tacommin_comman /* thiply oves;
#endif
}

stat);
strreset  vCt=rupteset in_r,uptfter areleabusyup,upgenmsicLcausure,upgenmsicL, *c  checks */
 */
us_t_tatic voirf(unck_fd,
 */
argerrups(voriaticnt 	
 used=0e %line int 
		set_fdw 0x40)arge>ha
		brt _k SETgALWAYS:DCS_READY )
		FDCS->r = 300;
		brt _k SETgIFfflaCMD: up);();
	our
	 mdw==ct_adoep, == 2 )
		rese1riveur = 250;
	mg(voiturn;
if ( FD{cupe!\nUDR&reset  vCtprp%t>= 0 ){
		timer_table[FLOPPY_TIMER].expires =5prp%t>= 0 t;
		timer_active |= 1 << FLOP>reset ){
		rS->reused=statih, L, *cd)NOM}OMINline int r(&f}
	sti(riaticnt	ref
				Misc Ioctl's f4 rr mode s			========================
 ackmmand)
 */
f );
pyoutd_int *es = ,
 *landest_int *r *cr a,
 */
cnt )chdog(voi;ddogER]tatify_anee(lags |.: DMA,es = ,cnt M3;
e = i) moreset= i;domemcpy_tofs(es = ,d_int *) r *cr a,
cnt M3;
reset=  pr}u#_mode  COPYefinx) (f );
pyoutd d_int *)es = ,
&nx),
cnt ofnx)))u#_mode  COPYINnx) (memcpy_e refs(
&nx),
d_int *) es = ,
cnt ofnx)),0)hecks */
 */
s* FIn
		se(f(unck_fdc(intline int 
		set_fdwuae _switcdff_uINline int r(&es;
#endifetput*
		se_name(f(uny = ,ff(unck_fd errup"/

stattatic i/

sta*turn;
;	 Dsg(vo tion:e < N_DRIVUDR* floppy = i+oa = fl%rn;
AX_REe;
	 U jif g ise_ors dup)
EPLN_DRIVUDR* floppy = i+oU jif g ise_ors du->rnurn 0;
	reset= "(nucl)"50;
	mg(voi,urn;
	inameU) moreset= ,urn;
	inamee %rn;
		}fifet= "(nucl)"50	remerr
	t void ms ackmmand)

}

stat);
strrnt_add  vCt=ruptfter areleabusyup,uptausurereleabusyup,upgenmsicLcausure,upgenmsicL, *c  checks */
 */
rnt_add ioctlrf(unck_fd,
_int *es = frives(voidyte)
{,trindo	mg(voiturn;
i
	 mdw<D_1FDDCS_READY 
	 mdw=tS-
Eeturn ior ( iuvehrough ti< N_X_REe;
	 
	sei)u!=Nint)t->de!\nY))
;;
	ct!\new==cck_fd e{ >d	e;
	o
		se_cks e[i].od_
/fu>

 )
		dd_timer)-EBUSYe)
s	rp_mode;
	o
		se_cks e[i].od_
/fu)
	dd_timer)-EBUSYe)
		rrg((turn;
if ( )&fd_timer)-EIOnfliCOPYINnrnt_addt_fdr,
		   h (ra&=Fcmd.;	 	;
	seUDRunt_addr + raw;lict!\MA,
		     (raw_c(md.flag: DMA |cmd.flagf & er &&sector;
	seU>a: increase MAX_BUFF* ent_*ct_adoe_timer)-ENOMEMdo	mg(voiA,
		     (raw_cmd.flag: DMA e>hasgER]tatify_anee(lags |.R & ,3A,
		   nt fdyte)
{ )atd.g(voi)
	dd_timer)i;hasStatic int buff)
		rumemcpy_e refs(md.length, floppy_t,3A,
		   nt fdyte)
{)e)
		rratic char *currmd.length, floppy_tpecent_addr  (rawDRS->fflagUSse MUPi >=Dnt-e!\nUDRR&rnt_add  vCtOPPYatic vor_ss: %p\n
		seS;u}fif=statih, L, *cd)NO
-ef Sp!urhU&& !turn;
if ( FD{cupr,
		   hgned ;
	seUDRstatdmotN_D RIVE;
	fine F_FIhgned ;
	seti< N_S->&ine F_FIhgnedei]u=eigned char rei]; upwardsr
	switc  (raw_c(cmd.flagf &  |cmd.flag: DMA e)rp	cent_addr + raw_= gtatima_tatidue(ve |= 1DMAr3;
turn;
		}r		FDC-EIOEVIECAL))
			UDRSO
#defif_1wardsret_adoe_timer)rindo	mg(voiA,
		     (raw_cmd.flagf &  _>hasg=f );
pyoutd A,
		   nt fdymd.length, floppy_t,3te)
{)e)
.g(voi)
	dd_timer)i;haretu->resetCOPYefinrnt_addt_f}hecks */
 */
r)      Sen
		se(f(unrdev)rivemerOC      Sesponsoppy_tr)
			Utotorsc*, aneenaSE nexedrive)
f fu_eext mimer_actidrive rdev)_tnbusy = 1INline int r(&fUDRS-_up t_eext m rdev)_tnreset=  pr}ukmmand)
 */
f )ioctlr
}

stain"deh*in"de,. */
statdest*tdep, inoppy_off(unadd,
ctorinoppy_of
	unses = friv#_mode  IOCTLgALLOWED (fdep && (fdep )
rpendw_c8 e)rup"/

stattatic i/

stanewes = d;up"/

static struct fotmc tmat_de
/*;ups(voidnt    ,ck_fd,y = ,ced *n"/

stattatic i/

sta*poTh_ void nfdetput*namee 
o		    Umm*INOR in"de->i_rdev)_tnb);*/
	}addtAX_RERO_IOCTLSsnt    ,es = )NOM}OMy = iDRTYPE(*INOR nt    tt_fd}
	curredrive *INOR nt    tt_fdb);*/
	}addtAX_R
		brt GETDRVTYP: up)=tatify_anee(lags |.: DMA,d_int *) es = ,16)atd.g(voi)
	dd_timer)i;hasnameU=cck_fd_name(y = ,IT(cur3;
	eturn ced= (  nt<16(  nt N_X_RE	orcefs);
		oname[ nt],) ='s a g((etpu*)es = )+cnhar >d	e;
	o!t*name )
		dd
ode=3;
		reereset=  prp
		brt GET: iERRS:DCS->resetCOPYefinUUGT
;
	i */
v )prp
		brt GETPRM: up);
#y = STATU)oTh_ void *DC&spy_struct fuct ]->rnurn de;
	()oTh_ void *DCpy_struct *cuIT(cu] (	fDEVIC-ULLR ) &_timer)-ENODEV;DCS->resetCOPYefin)oTh_ void [0])prp
		brt POLLDRVsult: up* FIn
		se(IT(cur3;
	ivef

/**
 * cyco tm
		brt GETDRVsult: up->resetCOPYefin*UECA)prp
		brt GETturnult: up->resetCOPYefin*Uturn)prp
		brt GETDRVPRM: up->resetCOPYefin*UEP)50;
	mg(vo!IOCTLgALLOWEDadoe_timer)-EPERM_fdb);*/
	}addtAX_R
		brt flaCMD: up);
#y = STATU_timer)-EINV NEETtline int 
		set_fd
with void snt    t;peerUDRunt_add)ioctlrck_fd,
d_int *) es = dor,xudline int r(&fd_timer)iprp
		brt FMTTRK: up);
#Ux80 )
d_
/fuFD_1)
	dd_timer)-EBUSYe)
mg(vo!
#Ux80 )
				Um f ( + 1 _Pk SEif )R ) &_timer)-ENXIOEVIiCOPYINntmc tmat_de
/*e(&fd_timer)fo_ors duont    ,.&tmc tmat_de
/*e(&f
		brt SET: iERRS:DCS->resetCOPYINnUUGT
;
	i */
v )prp
		brt FMTBEG:reereset=  prp
		brt CLRPRM: upline int 
		set_fd
py_struct *cuIT(cu]UDRand_dodcstatic int flIT(cu]UDR23;
	UU80 )kdc_banginnt prp%_timer)i)      Sen
		se(nt    t;pe
		brt FMTEND: u
		brt FLUSH: upline int 
		set_fd
_timer)i)      Sen
		se(nt    t;pe
		brt SETPRM: u
		brt DEFPRM: upCOPYINnnewes = dr3;
	ivesanityfe resic ietures = tryis. 0 upwannewes = d.curr <f ( ||k_ectonewes = d.rate if ( ||k_ectonewes = d. dectacf ( ||k_ectonewes = d. decta>cnrp-%UUGT
int bs>>newes = d.cte(tchSTATU_timer)-EINV NEETtg(vo tione{ >d	e;
	o!sus_t() )
		dd_timer)-EPERM_fd	iline int -1ont-
	eturn cedfor (  ;
f<ehrough ti nt N_X_RE	og(voTYPE(n		se_cks e[ nt].od_nt    ts==cy = ive) ='s a gn		se_cks e[ nt].od_
/f X_RE	}Ledrive f fu_eext mimer_acticed  busy = 1>PL})
s_} CURspy_struct fuct ] =nlewes = d;upURspy_struct fuct ].name="us_tatic st"nt-
	eturncedfory = iive2o;DEVICE_NA ;
f<e(y = iive2o> +u4o;DEVICE_NA ;
 N_S->&&static int fl0nt]=ugt(voidHA1 _2_CONTROLLERSverru}N_DRIV int fl0nt+FD_D]=ug jiffimo	pURspy_struct fuct ].int >>1nfs oldline int r(&fd_eturn cedfor (  ;
f<ehrough ti nt N_X_RE	og(voTYPE(n		se_cks e[ nt].od_nt    ts==cy = ive) ='s a gn		se_cks e[ nt].od_
/f _RE	}LeDRS-_up t_eext m n		se_cks e[ nt].imo	pURs aod_nt    t-
EPL})
s__DATA);
			ree upline int 
		set_fd
e;
	opmdw!=cmdDEFPRM IT(drivenotic*, aup to date dims theteeyedurn 0;
	 uf   looselour (sttlemsdims theteeyack etbuae _switcdff_upus_t_es = dlIT(cu]UDRlewes = d;upUct!\Static }
	curr	s}
	cur&&y %p-%pStatic ;
	 >sus_t_es = dlIT(cu].curr )
s_oppy_t ;ax=us_t_es = dlIT(cu].curr_fd
py_struct *cuIT(cu]UDR&us_t_es = dlIT(cu]dodcstatic int flIT(cu]UDRus_t_es = dlIT(cu].cnt  >>*/
		udrivsmdw==cmdDEFPRM 
c		x80 )kdc_banginnt)
		ruurn 0;
	x80 )kdc_banginnt13;
	iver)      Sync. IC      Ses
	py_y dis to va, i.e d		k _y dis suhef se aloid f rent_couis	is pcppy_trc drid		k _y oselnumbtorg, or date .rTODO: disseful,mesn't cd		k _mtools oftdis date myehn geomcallnbThis pup toais cd		k _loosic ikes subboobyblinek 0 upwardx80 );
	bline_>cnrp-%pus_t_es = dlIT(cu].currr|ck_ectorx80 );
	)
			U)
	dd_timer)i)      Sen
		se(nt    t;penurn 0;
	reset= INline int r(&fU		brt f SET:reereset= us_t_tatic voirnck_fd,
(EBU)es = dor,U		brt MSGON:;
	UUP )
				UDRS-TD_MSG;reereset=  prp
		brt MSGOFF:;
	UUP )
				U_er_fTD_MSG;reereset=  prp
		brt SETEMSGTf SH:;
	UUP );
	i */
v .	iode ic indate(inoppy_of)hde ) (es = p(Fcmdf);reereset=  prp
		brt TWADDLE: upline int 
		set_fd
)wr *ldir(&fdINline int r(&f}ode = r!=sus_t() )
		_timer)-EPERM_fdb);*/
}addt{rp
		brt SETDRVPRM: up->resetCOPYINn*UEP)50;voiault:&fd_timer)-EINV NEET}upreset=  pr#sk_mo IOCTLgALLOWEDr}uk#_mode  CMOSgf & (r *c) ({ \
{
	cli(r *c,0x70);l\
fer[i+0x71);l\
})return 0;
}

statc datct *crf(unck_fd,r byted )chdog(vo "deh> ( &&  "deh<DRanMBER ntiaultn
		se_es = df= FDC_memcpy((etput*)%UUG cnr(%x)\n"(etput*)%(&ntiaultn
		se_es = d[ "de].es = df cnr(%x)\n",nt ofn "/

stattatic 
		se_es = d )r3;
	24-1))){		%d: di%s",nck_fd,
ntiaultn
		se_es = d[ "de].namear moreset=1;
	rp_mode;
	!ted )c
	24-1))){		%d: ditrol) wh* thi",nck_fd)e %rn;
		}24-1))){		%d: diun0, 0 ttion:%i",ck_fd,ted )3;	return 0;
}

sconfigct *cs	_interrups(vo = cunf
Eeturn = cu= (  = cu<hrough a(  = cu N_X_REmer tiaultttion:eturunidtruifighestc voidk 0 upmemcpy((etput*)%UUG "(etput*)%(&ntiaultn
		se_es = d->es = df cnr(%x)\n",nt ofn "/

stattatic 
		se_es = d )r3;
}do DEBUGT Fvoid *
		se(s): d-fdmtatc datct *cr0 "(CMOSgf & (FD1D _>>*4)p(F15M3;
e = CMOSgf & (FD1D _(F15MdX_RE_mode) ",n"t_fd
with datct *cr1, CMOSgf & (FD1D _(F15M3;
}do DEBUGT ply oves;eturn 0;
}

smaybe	UDRS-_eext m on(int    tchdoregiss cas(vo = cunf
E}
	curredrive nt    t;perp_mUx80 )
				UDRS->l +oU jifUDRS-f
/*u<].expiresUack_buffUx80 )
				Um f (lags | ack_buff(d eext mdrecaliiresm f fu_eext m )p(Fdo_actick_fd))R ) eDRS-_up t_eext m nt    t;pes; */
fatic vis_wp(
 */
sin_t)p{ 	;
ybe	UDRS-_eext m sin_t +urMAJOR_NRacti8))_tnreset= !
	o
		se_cks e[edrive sin_t) ].
				Um f ( iSK : DMABLE  oves;e#_mode  WRAPPER(op)l\
mmand)
 */
fatic v##opr
}

stain"deh* in"de,. */
statdest* tdep, \cnr(%x)\etput*pcpp,ff(un -1;
MA\
{ \
	maybe	UDRS-_eext m on"de->i_rdev)_	\ mg(voieext mdrecaliires(Fdo_actidrive on"de->i_rdev)U))U\
 &_timer)-ENXIOEU\
 _timer)blinev##oprin"de,.tdep, cpp,fte)
{)el\
}

WRAPPER(oid )
WRAPPER()

/*)ukmmand)
 */
exclus	curre pr
} *cont;

static voiledatr
}

stain"deh* in"de,. */
statdest* tdeperrups(vo = cu=idrive on"de->i_rdev)nf
Eesync_nt  in"de->i_rdev)_tne;
	 U 80 )
d_
/fu< 0);
	UU80 )
d_
/f=0e %rn;
de;
	!UU80 )
d_
/f--) perp_mode) {
		printk(DEVIfatic voiledatrg,th 
d_
/fu==c0"t_fd
U 80 )
d_
/funt prp			fatic voiledat_irqreleadma r(&fexclus	cu=0rS}*/f
				oatic vopdis dres 

/* lia( !g (/dev/fd0rc nrl() ac"oame as				/dev/PS0 etc), f4 rup alhe s",nmultaneoussater a roundedoame				}
	curg,th iffy_ten(int    lnumbtos.===/h#_mode  RETERRnx) \difo{tatic voiledatrin"de,tdepeEU\
 \n"utimer)-nx);}{
	cl(0);cks */
 */
usage_ -1;
for (
mmand)
 */
fatic vopdir
}

stain"deh* in"de,. */
statdest* tdeperrups(vo = cu;ups(voold_nt do	mg(voexclus	cu)
		_timer)-EBUSYe)
e = r!fdep Iperp_mode) {
		printk(DEVIWeird, opdis * thirg,th 
dep=0cular moreset= -EIOEVI}f
E}
	curredrive in"de->i_rdev)_tne;
	 }
	cur>=through a)
 &_timer)-ENXIOE	rrg(vop!_INTR);
	comma=R 2
#define DETECif&& }
	cur>=tss: %p\n
		seS{
	iline int -1ont-
INline int r(&f}otne;
	 TYPE(on"de->i_rdev)U>DRanMBER spy_struct ))
%p-_timer)-ENXIOE	rrg(vofdep )
rpendw_c3_X_REe;
	 !#Ux80 )
				Um f ( + 1 _Pk SEif)R ) &_timer)-ENXIOEVI}otnold_nt MD_  80 )
d_dt    ive ;
#Ux80 )
d_
/fu&& old_nt M!= on"de->i_rdev)
		_timer)-EBUSYe)
e = spy_strgrab_irqreleadma r)
		_timer)-EBUSYe)rrg(vofdep )
r
				Um O_EXCLE_{E; drivusage_ -1;
>1){e_f	fatic voiledat_irqreleadma r(&fdd_timer)-EBUSYe)
s	urn 0;
	exclus	cu=1EVI}otn/* tdep )
rop: diand_tifs supup toDO: -1;
va, f4 rnon-and_tifsopdivaor i	ct!\tdep )
rop_{E; drivU 80 )
d_
/funnt)
)
	dd_timer)-EBUSYe)
mU 80 )
d_
/f++= 1E  80 )
d_dt     = on"de->i_rdev;er	rp_modX_REdrivU 80 )
d_
/fu){e_f	fatic voiledat_irqreleadma r(&fdd_timer)-EBUSYe)
s	;
	UU80 )
d_
/f=-1(&f}otne;
	old_nt M&& old_nt M!= on"de->i_rdev)X_REe;
	 Static }
	curr	s}
	cur )
s_oppy_t int buff)
		rui)      Sen}
			rt	old_nt r(&f}otne;
	fdep )
rpendw_c2 ||rpyingssionrin"de,2te < Ndep )
rpendwDRS8t merkdc__mtools worsic i=/hegdrivU);
	our
	 mdw==c1)k_buff 
 U);
	our
	 mdw= 2e)rrg(vofdep )
r
				Um O_NDELAY) moreset=  prpe;
	fdep )
rpendw_& !#Ux80 )
				Um f ( + 1 _Pk SEif)R ) RETERRnENXIO)_tne;(us_t_tatic voirck_fd,
t _k SETgIFfS->tED)R ) RETERRnEIO)_trrg(vofdep )
rpendw_c3_X_REeDRS-_up t_eext m in"de->i_rdev)_tnmg(voieext mdrecaliires(Fdo_acti}
	cur e{ >d	e;
	osus_t() _& tdep )
rop_imo	pmer re afrma semune rescrashic i=/h	pURsdep )
rpendw_= ~3nt->d rn 0;
	LRETERRnENXIO)_tn	}rp			etur( dep )
rpendw_c2) _& Ux80 )
				U< f ( iSK : DMABLEe>has_fifocus_t() _& tdep )
rop_imo	mer re afrma semune rescrashic i=/h	pUsdep )
rpendw_= ~2;penurn 0;
	RETERRnEACCES)EET}upreset=  pr#sk_mo RETERRS}*/f
				Ac0, 0thigeaup to date 
 ackmmand)
 */
aS-_eext m on(ink_fdc(intinoppy_off(unmaskner_acti = cu;upUx80 );
	bline_nt prpUx80 );
	)
			UDR prp);
#eStatic }
	curr	s}
	cur )
soppy_t int buff)
		rf fu_eext m _= ~masknfdetpt mdrecaliires(= ~masknfdyways */
	}*/f
				Cdres ifs supup tohasrl(dis date 
{o aifsao date dhasrl(disf fud.
 ackmmand)
 */
eDRS-_fatic veext m nt _(int errups(vo = curredrive int   = 1INoppy_off(unmaskner_acti = cu;u

rp_mMAJOR dev)u!=NMAJOR_NR_ perp_mode) {
		printk(DEVIfatic v date 
:ttrollIfatic cular moreset=  prp		rrg(vof fu_eext m _nmask) moreset= aS-_eext m ck_fd)e 		etur(Ux80 )
				Um f (lags | )i_BUGeext mdrecaliires(Fmask)Uack_buffUx80 )
				UDRS->l +oU jifUDRS-f
/*u<k_buff.expireo!= ols_t_tatic voirck_fd,
t _k SETgIFfS->tED); up* FIn
		se(IT(cur3;
	g(vopext mdrecaliires(Fmask){ >d	Ux80 )genms Sync++= 1E	reset= aS-_eext m ck_fd)e n	}rp			reset=  pr}ukmerre      Sespons void *up t, i.e rr iggeD frors;
a    |  --initbyienaSt fppy tCubboobbline_rblineU0) ackmmand)
 */
fatic voi      Se nt _(int errup"/

staStatic rate *  hr Dne;
	 TYPE(dev)u||rrent_addt *cudrive nt )] ) moreset=  prpe;
	!(bw_= gtablk nt ,0,1024)r)
		_timer)1prp);
#eSh && !r h   eip   ayte(	illsrw_bline(R & ,31, &bh)e nbrurn (bh)e nreset=  pr}ukmmand)
 */
statdes_ retry ths
fatic vfopMER]rupand_,mo	merrn ekr-rdtiaultt threatic voiad,o	merenaSE- genms l)bline-nt  enaSE nexeatic v)

/*,o	mer)

/* - genms l)bline-nt  )

/*  nexand_,mo	merenaSdicu-rbaSE nexand_,mo	mersilectt thred)ioctl,o	merioctlE nexand_,mo	mer_INpE nexeatic vopdi,o	meropdis threatic voiledat,o	merenledatr thrblinevesync,o	meresyncE nexand_,mo	merfasyncE nexeDRS-_fatic veext m,	mer_ the_ date dsk Sfatic voi      Se,	merre      Sessk  chef
				Fvoid *Dk_fdrrOCK durisry ths			==============================32ms, esDtrying topons void *up tat);
ro thDoiion:2ms/ rTODO:-bufferdwasr)

/tentbyiDavid C. Niemi ackmmand)
etputg= 2 )
	fdrsionr_interrups(voRpr)
buforce;
		of ( UMPk GS)E	mer82072 f4 rbets ca0, 0s UMPk GSor i	ct!\nturn;
if ( FD
		_timer)tur_NONEprp);
#e(ru=eigatic r)acf (x00D
		_timer)tur_NONEp	merNo)turr res_ad ???or i	ct!\(r==1) && (igned char re0]w==c0x80)Iperp_mode) "turr%d: diar8272A%lx int);
		_timer)tur_8272A;		mer8272a/765)ed 'ta0, 0s UMPk GSor i				eturcu!=N1D _perp_mode) "turrOCK :s UMPk GSVIunexp ---au}
	sti()fr%d:ng os.%lx su);
		_timer)tur_UNKNOWNEET}upbuforce;
		of (lagSION)e nru=eigatic r;lict!\MAw==c1) && (igned char re0]w==c0x80)Iperp_mode) "turr%d: diar82072%lx int);
		_timer)tur_82072;		mer82072 does 'ta0, 0slagSIONor i				eturrcu!=N1)i_BUGigned char re0]w!=c0x90) _perp_mode) "turrOCK :slagSIONVIunexp ---au}
	sti()fr%d:ng os.%lx su);
		_timer)tur_UNKNOWNEET}upbuforce;
		of (UNhis )e nru=eigatic r;lict!\MAw==c1) && (igned char re0]w==c0x80)Iperp_mode) "turr%d: diar re-1991r82077%lx sint);
		_timer)tur_82077_ORIGp	merPre-1991r82077 does 'ta0, 0shis /UNhis or i				eturrcu!=N1)i_BUGigned char re0]w!=c0x00) _perp_mode) "turrOCK :sUNhis VIunexp ---au}
	sti()fr%d:ng os.%lx su);
		_timer)tur_UNKNOWNEET}up_mode) "turr%d: diar ost-1991r82077%lx int);
	_timer)tur_82077p	merRevis-au82077AA passres

/**
topestdk 0 } mer )
		rit32ms, es			Dk_fd  |  --init-buffer.rTODO:rINouis	is pcaS-gvaluea{
	cliis pkernel				}otabonored(no ede;

	r
/

/*d)rOCK durisry th worsype ay time.
 */
s |  -- in_command_interruerp_mux80 )int bufff0t)a
	drive_ (rawDRS->f + 1 _Pk SEif /*| f ( iSK NEWCHANGE*/e %rn;
de;
	ux80 )int bu!=cS->tr1_k CALE_{E; eatic voiady(ar moreset=1;
		ieatic voff_ss: %p\n
		seS;u}ss: %p\n
		se++= 1drivss: %p\c}
	curr	shrough aack_buff )
	cks e[
	se0x10<<UNIT(cur].fdrsionma=R 2r_NONEe>hasnic voir0dor,xudline int r(&fdfatic voiledat_irqreleadma r(&fdreset=1;
		inic voirss: %p\n
		seS;u}eatic voiady(arp/*ttext32mses;
#endif
}

stat);
str |  --  vCt=rup |  -- in_comman,up |  -- in_comman,upempty,up(, *c_f) empty  chef
				TODO: dipons void *IRQ uct fipSync. TonsSA    ERRUPT	is	dar
				e hametc),we  re	ponsIRQ-terrupt
g,th in_commansrup ablud.
 ackmmand)

}

staoppa--iniattatic ippa--iniaR]rupfatic vin_comman,up0,upSA    ERRUPT,exand_
 chet;

sfatic vinir	_interrups(voir Dne;
	regiss c_blknt  MAJOR_NR,"fd",&fatic vfopM) _perp_mode) "Unghesteniyommmajeni%d 

/*fatic cul,MAJOR_NR_(&fdreset=1;
		
dtN_DRIVE;
	256ti< N_S->e;
	 TYPE(o))
EPLN_DRIV int fli]UDR* floppy = [TYPE(o)].cnt  >>*/
		uurn 0;
	N_DRIV int fli]UDR: in iSK 
#der Dsblk int [MAJOR_NR]UDR* floppint f;Dsblk nt [MAJOR_NR].re* ForLfiaR]{
		priREQUEST;
	t>= 0 ){
		timer_table[FLOfiaR]* floppihutdown;
	t>= 0 t;
		ti(= ~(_active |= 1 << Font-e!\figct *cs	)nf
Ee)
	cks e[0].r *cr ase ma3f prpe)
	cks e[1].r *cr ase ma370-
Eetu(e)
se m ;f )
f<ehr 2r;f )
 N_X_REturn;
dtruff)
		ruturn;
denU=s0;DCS_READY )
		U=s0;DCS_READYfdrsionma)tur_NONEprpinic dtu(e)
, ~0,c0xc )EVI}otn/* OCK durisstc voi cks edsk Sfturn cs: %p\n
		se= (  s: %p\c}
	cur<ehrough  (  s: %p\c}
	cu N_X_REdrive_ (raw=s0;DCSx80 )genms Syncw=s0;DCSx80 )kdc_banginnt prp% 80 )
d_
/funt prp	 80 )
d_dt     =  prp		rrspy_strgrab_irqreleadma r-
Eetu(e)
se m ;f )
f<ehr 2r;f )
 N_X_REturn;
r
	 mdw= 2e)	ne;(us_t_tatic voir-1,t _k SETgIFfS->tED)R ) de!\nY))
;;
	/ rTnnvenidtrying topons void *t);
ro thDoiion:2msCS_READYfdrsionma)g= 2 )
	fdrsionrr3;
	g(vo_READYfdrsionma=R 2r_NONEe ) de!\nY))
;;;
	/ rNrollllR 2rsrsiemnbe c()ghesteniterrupoponsfdrsionmp!_INTRd		k _pr reteyedsotorsc*, ane
		Ufo accoucksueapd)turrcl *cs,d		k _eniat;

sin_comman garbagein		k 0 up_READYhas_fifoma)turADYfdrsionm>=)tur_82077_ORIGp= ols_t_tatic voir-1,t _k SETgALWAYS)EET}upvoi=0e %, 0 );
	}
	curre0e %line int -1ont-OCK durisic in0e %,!_INTR);
	commaR 2
#define DETECint-e!\nUDR& |  --  vCt;lir,
		   LL );
	seUDR0;lir,
		     (raw=cmd.flagS->trSEEK;lir,
		   )
			UDR prpeatic voiady(ar medrive)es; */
fatic vgrab_irqreleadma _interruerp_musage_ -1;
 N_S->reset=  prpe;
	irqa--ini(ve |= 1IRQ,&fatic vippa--ini))dX_RE_mode) {
		printk(DEVICE_NAME
	UnghesteniyrabsIRQ%d 

/*pons void *uk_fdr%lx cnr(%x)\n"ve |= 1IRQar moreset= -1(&f}ode = re* ForL,ma ve |= 1DMAr)dX_RE_mode) {
		printk(DEVICE_NAME
	UnghesteniyrabsDMA%d 

/*pons void *uk_fdr%lx cnr(%x)\n"ve |= 1DMAr3;
	fret_irq(ve |= 1IRQar moreset= -1(&f}odenghes_irq(ve |= 1IRQar mreset=  pr}ukt;

static voiledat_irqreleadma _interruerp_m--usage_ -1;
)&fdreset=1;
up abluL,ma ve |= 1DMArprperet_,ma ve |= 1DMArprpup abluLirq(ve |= 1IRQar mfret_irq(ve |= 1IRQar gt(voidHA1 _2_CONTROLLERSvemers);*/
	niatrtatlt);
ro thDin				TODO:saoidkuhe douhestrn ponstext3reboob.e thr"ic dtu(0, ~0,c8 -fdmtatcdtu(1, ~8,f0t); = jiffies           