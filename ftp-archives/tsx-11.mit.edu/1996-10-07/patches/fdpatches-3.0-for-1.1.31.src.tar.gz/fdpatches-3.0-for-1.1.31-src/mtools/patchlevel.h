#define VERSION	"2.0.7alk"
#define DATE	"16 Feb 94"
