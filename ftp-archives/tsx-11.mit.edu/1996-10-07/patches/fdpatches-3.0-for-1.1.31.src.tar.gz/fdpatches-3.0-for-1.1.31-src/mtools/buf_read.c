/*
 * Do full cylinder buffered reads from slow devices.  Uses a simple
 * buffered read/delayed write algorithm.
 */

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include "msdos.h"

unsigned char *disk_buf;		/* disk read/write buffer */
int disk_size;				/* size of read/write buffer */
long disk_current;			/* first sector in buffer */
long disk_cur_size=0;			/* the current size */
int disk_dirty;				/* is the buffer dirty? */

void
disk_read(start, buf, len)
long start;
unsigned char *buf;
int len;
{
	register long i;
	int length;
	unsigned char *buf_ptr, *disk_ptr;
	long where, tail;
	int ret;

					/* don't use cache? */
	if (disk_size == 1) {
		where = (start * msector_size) + disk_offset;
		if (lseek(fd, where, 0) < 0) {
			perror("disk_read: lseek");
			exit(1);
		}
					/* read it! */
		if ((ret=read(fd, (char *) buf, (unsigned int) len)) != len) {
			if ( ret < 0 )
				perror("disk_read: read");
			else
				fprintf(stderr,"disk_read: read: end of file\n");
			exit(1);
		}
		return;
	}

	tail = start + (len / msector_size) - 1;
	for (i = start; i <= tail; i++) {
					/* a "cache" miss */
		if (i < disk_current || i >= disk_current + disk_cur_size) {

			if (disk_dirty)
				disk_flush();

			disk_current = (i / disk_size) * disk_size;
			where = (disk_current * msector_size) + disk_offset;
			length = disk_size * msector_size;			

					/* move to next location */
			if (lseek(fd, where, 0) < 0) {
				perror("disk_read: lseek");
				exit(1);
			}
					/* read it! */
			if ((ret=read(fd, (char *) disk_buf, (unsigned int) length)) != length) {
				if ( ret < 0 )
					perror("disk_read: read");
				else
					fprintf(stderr,"disk_read: read: end of file\n");
				exit(1);
			}
			disk_cur_size = disk_size;
		}
					/* a cache hit... */
		buf_ptr = buf + ((i - start) * msector_size);
		disk_ptr = disk_buf + ((i - disk_current) * msector_size);
		memcpy((char *) buf_ptr, (char *) disk_ptr, msector_size);
	}
	return;
}
