/*
 * cursor.c
 * Program to change software cursor color at run time.
 * Written by Bill Paul <ghod@drycas.club.cc.cmu.edu> on 12/5/93
 */


#include <stdio.h>
#define ESC 0x1B
#define MAXCHOICES 12

static char *colors[] = { "black", "blue", "green", "cyan",
		          "red", "magenta", "yellow", "white", 
			  "noblink", "blink", "underline", "block", NULL };

static short values[] = { 100, 116, 132, 148,
                        164, 180, 196, 212,
                        33, 33, 34, 34 };


main(argc,argv)
int argc;
char *argv[];

{
int val = 0 ;

if (argc == 1) {
	fprintf (stderr, 
"Usage: %s [black|blue|green|cyan|red|magenta -
               yellow|white|blink|noblink|underline|block]\n"
           ,argv[0]);
	exit (-1);
	}

while (strcmp(argv[1],colors[val]) && val < MAXCHOICES )
	val++;

if (val == MAXCHOICES) {
	fprintf(stderr,"`%s' is an illegal keyword.\n",argv[1]);
	exit (-2);
}

if (val < 8)
	printf ("%c[%dm",ESC,values[val]);
else
	printf ("%c[?%d%c",ESC,values[val], (val % 2) ? 'h' : 'l');

exit(0);
}
