/* This should be somewhere else, but where? */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

#define ESC 0x1b

void die( char *message )
  {
  printf("usecp:  %s\n",message);
  exit(1);
  }

void usage( void )
  {
  printf( "usage:  usecp codepage\n" );
  exit( 1 );
  }

int main( int argc, char **argv )
  {
  int whichcp = 0;
  int whichvc = 0;

  if( argc != 2 ) usage();
  whichcp = atoi( argv[ 1 ] );
  if( whichcp > 2 || whichcp < 0 )
    {
      printf("Invalid cp!" );
      return 1;
    }
  putchar( ESC );
  putchar( 'F' );
  putchar( 'U' );
  putchar( argv[1][0]);
  return 0;
  }






