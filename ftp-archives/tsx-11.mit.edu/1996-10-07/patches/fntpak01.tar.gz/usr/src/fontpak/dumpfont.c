#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
void dump_bin( char ch );
#define ESC 0x1b
unsigned char fontbuf[ 256*32 ];
int count;
int progcp_return;

FILE *infile, *outfile;

void die( char *message )
	{
	printf("addcp:  %s\n",message);
	exit( 1 );
	}

void usage( void )
	{
	printf("usage:  dumpfont infile outfile\n");
	exit( 1 );
	}

int main( int argc,char **argv )
	 {
	char temp_s[3];
	int whichcp = 0;
	int handle;

	unsigned int i,j,k;
  
	if( argc != 3 ) usage();
	whichcp = atoi(argv[2]);
	if((infile = fopen( argv[1], "rb" ))==NULL)
		{
		printf( "Can't open %s for input\n",argv[1] );
		exit( 1 );
		}
	if((outfile = fopen( argv[2], "wa" ))==NULL)
		{
		printf( "Can't open %s for output\n",argv[2] );
		exit( 1 );
		}

	/********************************************************
	Now we read the .fnt file, and extract the binary bitmaps
	***********************************************************/
#ifdef CODEPAGE
	read( handle, fontbuf, 40 ); /*Read and ignore 40 bytes of junk */
	read( handle, fontbuf, 256*16 ); /*Read and ignore the 16-byte font*/
	read( handle, fontbuf, 6 ); /*Read and ignore 6 more bytes of junk*/
	for (i=0 ; i < 256 ; i++) read( handle, &(fontbuf[ i*32 ]), 14 ); /*Finally, the real data! */
#endif
	fread( fontbuf, 1, 32*256, infile );
	close( infile );
	/******************************************************************
	Now output the actual dump stuff
       *****************************************************************/
	for( i=0; i<256; i++ )
	  {
	  fprintf( outfile,"# Character code %x\n", i );
	  count=0;
	  j = i*32;
	  for( k=0; k<32; k++ )
	    {
		 count++;
		 dump_bin( fontbuf[j++] );
	    }
	  fprintf( outfile,"#\n" );/* extra comment line at end of character */
	  }
	}

void dump_bin( char ch )
	{
	if( ch & 0x80 ) fprintf( outfile, "1"); else fprintf( outfile,"0" );
	if( ch & 0x40 ) fprintf( outfile, "1"); else fprintf( outfile,"0" );
	if( ch & 0x20 ) fprintf( outfile, "1"); else fprintf( outfile,"0" );
	if( ch & 0x10 ) fprintf( outfile, "1"); else fprintf( outfile,"0" );
	if( ch & 0x08 ) fprintf( outfile, "1"); else fprintf( outfile,"0" );
	if( ch & 0x04 ) fprintf( outfile, "1"); else fprintf( outfile,"0" );
	if( ch & 0x02 ) fprintf( outfile, "1"); else fprintf( outfile,"0" );
	if( ch & 0x01 ) fprintf( outfile, "1"); else fprintf( outfile,"0" );
	fprintf( outfile,"    ");
	if( ch & 0x80 ) fprintf( outfile,"#" ); else fprintf( outfile," " );
	if( ch & 0x40 ) fprintf( outfile,"#" ); else fprintf( outfile," " );
	if( ch & 0x20 ) fprintf( outfile,"#" ); else fprintf( outfile," " );
	if( ch & 0x10 ) fprintf( outfile,"#" ); else fprintf( outfile," " );
	if( ch & 0x08 ) fprintf( outfile,"#" ); else fprintf( outfile," " );
	if( ch & 0x04 ) fprintf( outfile,"#" ); else fprintf( outfile," " );
	if( ch & 0x02 ) fprintf( outfile,"#" ); else fprintf( outfile," " );
	if( ch & 0x01 ) fprintf( outfile,"#" ); else fprintf( outfile," " );
	fprintf( outfile, "\n" );
	}

