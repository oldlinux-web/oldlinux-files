#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
char hinyb( char ch );
char lonyb( char ch );

#define ESC 0x1b

int progcp_return;
void die( char *message )
	{
	printf("loadfont:  %s\n",message);
	exit( 1 );
	}

void usage( void )
	{
	printf("usage:  loadfont codepage-file codepage\n");
	exit( 1 );
	}

int main( int argc,char **argv )
	{
	unsigned char cp_data[ 257*32 ];
	char temp_s[3];
	int whichcp = 0;
	int handle;

	unsigned int i;

	if( argc != 3 ) usage();
	whichcp = atoi(argv[2]);
	if(( handle = open(argv[1], O_RDONLY)) < 0) die( "Can't open input file" );
  
	/********************************************************************
	Now we read the .cp file, and extract the data we need.
	Unfortunately, I don't know the real format of the .cp file, so I
	have to hope that what I've used before is the only possibility.
	***************************************************************/
	read( handle, cp_data, 256*32 );
	close( handle );
	/******************************************************************
	Now output the actual control string to the driver.
       *****************************************************************/
	putchar( ESC );
	putchar( 'F' );
	putchar( 'P' );
	putchar( argv[2][0] );
	for( i=0; i < 8192; i++)
	  {
	  putchar( hinyb( cp_data[ i ] ));
	  putchar( lonyb( cp_data[ i ] ));
	  }
	}


char hinyb( char ch )
{
ch >>= 4;
ch &= 0x0f;
ch += '0';
if( ch > '9' ) ch += 7;
return ch;
}

char lonyb( char ch )
{
ch &= 0x0f;
ch += '0';
if( ch > '9' ) ch += 7;
return ch;
}
