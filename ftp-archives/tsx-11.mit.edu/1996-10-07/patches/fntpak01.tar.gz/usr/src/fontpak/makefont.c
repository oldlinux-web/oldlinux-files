#include <stdio.h>
#include <stdlib.h>
FILE *infile, *outfile;
#define LINEBUFLEN 256
char linebuf[ LINEBUFLEN ];
#pragma pack(1)
unsigned char fontbuf[ 256*32 ];
main( int argc, char **argv )
	{
	unsigned int i,j;
	if( argc != 3 )
		{
		printf("Makefont: Syntax makefont infile outfile\n");
		exit( 1 );
		}
	if(( infile = fopen( argv[1], "rt" )) == NULL )
		{
		printf( "makefont: Unable to open %s for input!\n", argv[1] );
		exit( 1 );
		}
	if(( outfile = fopen( argv[2], "wb" )) == NULL )
		{
		printf( "makefont: Unable to open %s for output!\n", argv[2] );
		}
	/* get lines from the input file until there are no more lines */
	/* Ignore comment lines */
	i=0;
	j=0;
	while( fgets( linebuf, LINEBUFLEN, infile ))
		{
		if( linebuf[ 0 ] == '#' )
			{
			if( j )
				{
				i++;
				j=0;
				}
			}
		else fontbuf[ (i * 32 ) + (j++) ] = str2bin( linebuf );
		}
	fwrite( fontbuf, 1, 32*256, outfile );
	fclose( outfile );
	fclose( infile );
	exit( 0 );		/* success! */
	}


/*************************************************************************
str2bin():  Takes a string consisting of "1"s and "0"s zeros, and returns a
            binary byte.
**************************************************************************/
str2bin( char *s  )
	{
	unsigned char o_parm;
	unsigned char addend;
	int i;

	o_parm = 0;
	addend = 0x80;	/* top bit set */
	for( i=0; i<8; i++ )
		{
		if( *s++ == '1' )
			{
			o_parm += addend;
			}
		addend /= 2;
		}
	return o_parm;
	}
