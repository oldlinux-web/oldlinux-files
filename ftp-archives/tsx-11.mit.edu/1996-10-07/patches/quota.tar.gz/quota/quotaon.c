#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include "quota.h"

void main(int argc, char **argv)
{
  int ret;

  if (argc != 2) {
    puts ("Need device name for quotainit");
    return;
  }
  fputs ("Setting up quota on ",stdout);
  puts(argv[1]);

  ret =setquota(argv[1], "quotas");
  if (ret)
    perror("setquota");
  else
    puts("quota setup");
}
