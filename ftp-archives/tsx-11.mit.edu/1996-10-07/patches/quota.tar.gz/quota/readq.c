#include <sys/types.h>
#include "quota.h"
#include <pwd.h>

void main(int argc, char **argv)
{
  struct disk_quota_block qb;
  char quota_file[50];
  int file, uid;

  if (argc == 1)
    return;
  sprintf (quota_file,"%s/quotas",argv[1]);
  uid = getuid();
  file = open(quota_file,00);
  while ((read(file,&qb,sizeof(struct disk_quota_block)))>0) {
    if (qb.user == uid || !uid) {
    printf ("quotas for %s\n",((getpwuid(qb.user))->pw_name));
    printf ("  blocks                           files\n");
    printf ("  used     quota    limit      used     quota    limit\n");
    printf ("-------------------------------------------------------\n");
    printf ("%6ld    %6ld   %6ld    %6ld    %6ld     %6ld\n\n",
	qb.curblocks,qb.blk_softlimit, qb.blk_hardlimit, 
        qb.curinodes,qb.ino_softlimit, qb.ino_hardlimit);
   }
  }
}
 
