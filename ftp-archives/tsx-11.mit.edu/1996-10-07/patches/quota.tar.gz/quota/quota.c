#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <pwd.h>
#include <ctype.h>
#include "quota.h"

void main(int argc, char **argv)
{
  static struct passwd *pwd;
  struct copy_quota_block *blk;
  int ret;
  uid_t uid;
  u_char all=0;

  if (argc != 1) {
    if (getuid() && argv[1][0] != '-') {
      printf ("%s: Permission denied\n",argv[0]);
      return;
    } else {
      if (argv[1][0] == '-') {
	all++;
	if (argc == 3) {
	  if (isdigit(*argv[2]))
	    uid = atoi(argv[2]);
	  else {
	    if ((pwd = getpwnam(argv[2])) == (struct passwd *)0) {
	      printf ("%s: unknown user\n",argv[2]);
	      return;
	    }
	    uid = pwd->pw_uid;
	  }
	}
	else
	  uid = getuid();
      } else {
	if (isdigit(*argv[1]))
	  uid = atoi(argv[1]);
	else {
	  if ((pwd = getpwnam(argv[1])) == (struct passwd *)0) {
	    printf ("%s: unknown user\n",argv[1]);
	    return;
	  }
	  uid = pwd->pw_uid;
	}
      }
    }
  } else
    uid = getuid();
  
  if (getuid() != uid && getuid()) {
    errno = EACCES;
    perror (argv[0]);
    return;
  }
    
  blk = (struct copy_quota_block *)malloc(sizeof(struct copy_quota_block)+1);

  printf ("\nDisc quotas for %s (uid %d):\n",((getpwuid(uid))->pw_name),uid);
  puts ("   Filsys    current   quota      files   quota    ");

  ret =quota(Q_GETQUOTA, ((getpwuid(uid))->pw_dir), uid, (char *)blk);
  if (ret) {
    perror("quota");
    printf ("%d\n",ret);
    return;
  }
  printf (" %-11s %7.ld   %5.ld   %5.ld   %5.ld   %5.ld    %5.ld\n",
	  blk->dev_name,blk->blk_used, blk->blk_soft, blk->blk_hard,
	  blk->ino_used, blk->ino_soft, blk->ino_hard);

  if (all) {
    memset(blk,'\0',sizeof(struct copy_quota_block));
    ret =quota(Q_GETQUOTA, "/", uid, (char *)blk);
    if (ret) {
      perror("quota");
      return;
    }
    printf (" %-11s %7.ld   %5.ld   %5.ld   %5.ld   %5.ld    %5.ld\n",
	    blk->dev_name,blk->blk_used, blk->blk_soft, blk->blk_hard,
	    blk->ino_used, blk->ino_soft, blk->ino_hard);
  }
}
