#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <pwd.h>
#include <stdio.h>
#include "quota.h"

void main(int argc, char **argv)
{
  struct copy_quota_block *blk;
  FILE *in;
  int ret;
  uid_t uid;

  if (argc == 2) {
    if (getuid()) {
      errno = EPERM;
      perror (argv[0]);
      return;
    } else {
      uid = atoi(argv[1]);
    }
  } else
    uid = getuid();
  
  uid = 70;
  blk = (struct copy_quota_block *)malloc(sizeof(struct copy_quota_block)+1);

  blk->blk_hard=2000;
  blk->blk_soft=1200;
  blk->blk_used=656;
  blk->ino_hard=175;
  blk->ino_soft=150;
  blk->ino_used=56;

  ret =quota(Q_SETQUOTA, "/", uid, (char *)blk);
  if (ret) {
    perror("quota");
    return;
  }
}
