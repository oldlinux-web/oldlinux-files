/* quota.h - definitions for quota system

   Edvard Tuinder <v892231@si.hhs.nl>

   $Id: quota.h,v 1.1 1992/04/25 16:30:44 ettin Exp ettin $

  The constants for the systemcalls are copied from the BSD-ufs quota.h
  file
 */

#ifndef _quota_h_
#define _quota_h_
#include <sys/types.h>

#undef QUOTA_VERBOSE		/* produce some useful info */
#undef QUOTA_VERY_VERBOSE	/* lot's of rubbish */
#undef STRICT_QUOTA		/* quota for non-registered users */

#define Q_SYNC_CNT      5
#define Q_RESIDENT     20
#define Q_MAX_DEV_NAME 20
#define Q_NO_QUOTA     10

#if Q_RESIDENT > 28
#error "Q_RESIDENT too large. 20 is maximum"
#endif

#define	MAX_WAIT_TIME	(7*24*60*60)	/* 1 week */

#define	Q_QUOTAON	0x0100	/* enable quotas */
#define	Q_QUOTAOFF	0x0200	/* disable quotas */
#define	Q_GETQUOTA	0x0300	/* get limits and usage */
#define	Q_SETQUOTA	0x0400	/* set limits and usage */
#define	Q_SETUSE	0x0500	/* set usage */
#define	Q_SYNC		0x0600	/* sync disk copy of a filesystems quotas */
#define Q_SETQLIM       0x0700  /* set limit */

/* This structure is present on disk */
struct disk_quota_block {
	unsigned long	blk_hardlimit;	/* absolute limit on disk blks alloc */
	unsigned long	blk_softlimit;	/* preferred limit on disk blks */
	unsigned long	curblocks;	/* current block count */
	unsigned long	ino_hardlimit;	/* maximum # allocated inodes + 1 */
	unsigned long	ino_softlimit;	/* preferred inode limit */
	unsigned long	curinodes;	/* current # allocated inodes */
	time_t	blk_etime;	/* time limit for excessive disk use */
	time_t	ino_etime;	/* time limit for excessive files */
	uid_t   user;		/* user id */
};


/* Structure used throughout fs */
struct fs_quota_block {
	struct disk_quota_block disk;
	u_char  dirty;		/* 0 = not used, 1 = used, 2 = new */
};

/* structure used for passing info with GET_QUOTA/SET_QUOTA */
struct copy_quota_block {
	struct disk_quota_block disk;
	char dev_name[Q_MAX_DEV_NAME];
};

/* shorthand */
#define blk_hard disk.blk_hardlimit
#define blk_soft disk.blk_softlimit
#define blk_used disk.curblocks
#define ino_hard disk.ino_hardlimit
#define ino_soft disk.ino_softlimit
#define ino_used disk.curinodes
#define blk_time disk.blk_etime
#define ino_time disk.ino_etime
#define q_user	 disk.user


/* structure for quotas array */
struct quota_block {
	dev_t    dev;			/* device number */
	u_char   set_on;		/* 1 = used, 0 = not used */
	struct fs_quota_block user[Q_RESIDENT];
	struct inode *inode;
	char     dev_name[Q_MAX_DEV_NAME]; /* pathname of mounted fs */
};

#define Q_BLOCK_SIZE   (sizeof(struct disk_quota_block))

#endif
