/* quotaoff.c - remove quota from specified file system (that is the
   resident part).

   Edvard Tuinder <v892231@si.hhs.nl>

 */

#include <sys/types.h>
#include <stdio.h>
#include "quota.h"

void main(int argc, char **argv)
{
  int ret;

  if (argc == 1) {
    fputs("usage: quotaoff path-name\n",stderr);
    return;
  }

  ret = quota(Q_QUOTAOFF,argv[1],0,(char *)0);
  if (ret)
    perror("quota");
  else {
    fputs ("quota removed on ",stdout);
    puts(argv[1]);
  }
}
  
