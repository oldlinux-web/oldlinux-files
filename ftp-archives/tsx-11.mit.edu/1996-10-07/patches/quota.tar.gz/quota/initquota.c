#include <sys/types.h>
#include "quota.h"

main()
{
  struct disk_quota_block qb;
  int file;

  file = open ("quotas",01000|00100|01,0);
  if (!file) {
    perror("open");
    return;
  }
  printf("%d\n",sizeof(struct disk_quota_block));
  qb.blk_hardlimit=120;
  qb.blk_softlimit=100;
  qb.curblocks=20;
  qb.ino_hardlimit=120;
  qb.ino_softlimit=100;
  qb.curinodes=20;
  qb.blk_etime=0L;
  qb.ino_etime=0L;
  qb.user = 5;
  write (file,&qb,sizeof(struct disk_quota_block));
  qb.blk_hardlimit=2000;
  qb.blk_softlimit=1200;
  qb.curblocks=653;
  qb.ino_hardlimit=175;
  qb.ino_softlimit=150;
  qb.curinodes=56;
  qb.blk_etime=0L;
  qb.ino_etime=0L;
  qb.user = 10;
  write (file,&qb,sizeof(struct disk_quota_block));
  qb.blk_hardlimit=12000;
  qb.blk_softlimit=10000;
  qb.curblocks=199;
  qb.ino_hardlimit=12000;
  qb.ino_softlimit=10000;
  qb.curinodes=200;
  qb.blk_etime=0L;
  qb.ino_etime=0L;
  qb.user = 50;
  write (file,&qb,sizeof(struct disk_quota_block));
  close(file);
}
