/* quota.c - copied from ptrace.c */
#define __LIBRARY__
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include "quota.h"

int quota(int cmd, const char *special, uid_t uid, const char *addr)
{
  long res;

  __asm__ volatile ("int $0x80"
		    :"=a" (res)
		    :"0" (__NR_quota),"b" (cmd), "c" (special),
		    "d" (uid), "S" (addr)
		    : "si","bx","cx","dx");

  if (res >= 0)
    return res;
  errno = -res;
  return -1;
}

