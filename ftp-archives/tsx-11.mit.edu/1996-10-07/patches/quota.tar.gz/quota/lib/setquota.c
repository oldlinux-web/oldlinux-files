#define __LIBRARY__
#include <unistd.h>

_syscall2(int,setquota,const char *,device,const char *,specialfile)
