#include <sys/types.h>
#include <stdio.h>
#include "quota.h"
#include <pwd.h>

extern char *ctime(const time_t *);

void main(int argc, char **argv)
{
  struct disk_quota_block qb;
  char quota_file[50];
  int file;

  if (getuid()) {
    fputs ("Permission denied\n",stderr);
    return;
  }

  if (argc == 1) {
    fputs("usage: quotacheck path\n",stderr);
    return;
  }
  
  strcpy (quota_file, argv[1]);
  strcat (quota_file, "/quotas");

  file = open(quota_file,00);
  while ((read(file,&qb,sizeof(struct disk_quota_block)))>0) {
    fputs(((getpwuid(qb.user))->pw_name),stdout);
    if (qb.ino_etime || qb.blk_etime) {
      if (qb.ino_etime == qb.blk_etime) {
	fputs ("quota and file quota exceeded since ",stdout);
	fputs (ctime(&qb.ino_etime),stdout);
      } else if (qb.ino_etime) {
	fputs ("file quota exceeded since ",stdout);
	fputs (ctime(&qb.ino_etime),stdout);
      } else {
	fputs ("block quota exceeded since ",stdout);
	fputs (ctime(&qb.blk_etime),stdout);
      }
    } else
      puts("ok");
  }
  close(file);
}
 
