/* This should be somewhere else, but where? */

#define __LIBRARY__
#include "/usr/src/linux/include/linux/unistd.h"

_syscall2(int,activate_cp,int,whichvc,int,whichcp)

_syscall2(int,progcp,int,whichcp,char *,data)

_syscall3(int,progsfchar,int,whichcp,char,whichchar,char *,newchar)

#undef __LIBRARY

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>



void die(char *message) {
  printf("usecp:  %s\n",message);
  exit(1);
}

void usage(void) {
  printf("usage:  usecp codepage [vc]\n");
  exit(1);
}

int main(int argc,char **argv) {

  int whichcp = 0;
  int whichvc = 0;

  if ((argc > 3) || (argc < 2))
    usage();

  whichcp = atoi(argv[1]);

  if (argc > 2)
    whichvc = atoi(argv[2]) - 1; else
      die("auto-detection of fg-console not implemented");

  return(activate_cp(whichvc,whichcp));
}
