/*
 * used by plptodft/syncrepf.c -- should go away
 */
#define		CPU	0
