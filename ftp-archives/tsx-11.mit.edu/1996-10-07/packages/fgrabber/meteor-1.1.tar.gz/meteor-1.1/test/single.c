#define USE_MMAP
#include <sys/fcntl.h>
#ifdef USE_MMAP
#include <sys/mman.h>
#endif
#include "../ioctl_meteor.h"

extern int errno;

#define ROWS 300
#define COLS 400
#define SIZE (ROWS * COLS * 4)
void main(int argc, char **argv)
{
  struct meteor_geomet geo;
  char buf[SIZE],b[4],header[16],*p;
  char *mmbuf;
  int i,o,c;
  char *DevName;
  static char DefaultName[]="/dev/mmetfgrab0";

  if ( argc > 1 )
    DevName = *++argv;
  else
    DevName = DefaultName;

  if ((i = open(DevName, O_RDONLY)) < 0) {
    perror("open failed");
    printf("device %s\n", DevName);
    exit(1);
  }

  /* set up the capture type and size */
  geo.rows = ROWS;
  geo.columns = COLS;
  geo.frames = 1;
  geo.oformat = METEOR_GEO_RGB24 ;

  if (ioctl(i, METEORSETGEO, &geo) < 0) {
    perror("ioctl SetGeometry failed");
    exit(1);
  }

  c = METEOR_FMT_NTSC;

  if (ioctl(i, METEORSFMT, &c) < 0) {
    perror("ioctl SetFormat failed");
    exit(1);
  }

  c = METEOR_INPUT_DEV0;

  if (ioctl(i, METEORSINPUT, &c) < 0) {
    perror("ioctl Setinput failed");
    exit(1);
  }
  /*  sleep(1);*/
#ifdef USE_MMAP
  mmbuf=(char *)mmap((caddr_t)0, SIZE, PROT_READ,
		     MAP_FILE|MAP_PRIVATE, i, (off_t)0);
  if ( mmbuf == (char *)-1 ) {
    perror("mmap failed");
    exit(1);
  }
  /* capture one frame */
  c = METEOR_CAP_SINGLE ;
  if (ioctl(i, METEORCAPTUR, &c)) {
    perror("ioctl SingleCapture failed");
    exit(1);
  }
#else
  if ((c=read(i, &buf[0], SIZE)) < SIZE) {
    perror("read failed");
    exit(1);
  }
#endif
  close(i);

  if ((o = open("rgb24.ppm", O_WRONLY | O_CREAT, 0644)) < 0) {
    perror("ppm open failed");
    exit(1);
  }

  /* make PPM header and save to file */
  strcpy(&header[0], "P6 400 300 255 ");
  header[2] = header[6]  = header[10] = header[14] = '\n';
  write (o, &header[0], 15);
  /* save the RGB data to PPM file */
#ifdef USE_MMAP
  for (p = mmbuf; p < &mmbuf[SIZE]; ) {
#else
  for (p = &buf[0]; p < &buf[SIZE]; ) {
#endif
    b[2] = *p++;		/* blue */
    b[1] = *p++;		/* green */
    b[0] = *p++;		/* red */
    *p++;			/* NULL byte */
    write(o,&b[0], 3);	/* not very efficient */
  }
  close(o);
  exit(0);
}
