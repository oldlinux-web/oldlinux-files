/*
 * version.h --- controls the version number printed by rocketport driver
 */

#define ROCKET_VERSION "1.11"
#define ROCKET_DATE "9-May-96"

