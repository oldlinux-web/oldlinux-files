/*
 * version.h --- controls the version number printed by rocketport driver
 */

#define ROCKET_VERSION "1.09_BETA_1"
#define ROCKET_DATE "15-Feb-96"

