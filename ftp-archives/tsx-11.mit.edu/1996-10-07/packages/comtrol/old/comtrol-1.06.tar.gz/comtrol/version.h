/*
 * version.h --- controls the version number printed by rocketport driver
 */

#define ROCKET_VERSION "1.06"
#define ROCKET_DATE "21-May-95"

