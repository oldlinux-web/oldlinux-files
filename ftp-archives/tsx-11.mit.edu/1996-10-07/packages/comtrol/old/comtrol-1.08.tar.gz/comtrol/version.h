/*
 * version.h --- controls the version number printed by rocketport driver
 */

#define ROCKET_VERSION "1.08"
#define ROCKET_DATE "16-Jan-96"

