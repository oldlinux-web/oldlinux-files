/*
 * version.h --- controls the version number printed by rocketport driver
 */

#define ROCKET_VERSION "1.07"
#define ROCKET_DATE "11-Jul-95"

