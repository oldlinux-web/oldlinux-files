/*
 * version.h --- controls the version number printed by rocketport driver
 */

#define ROCKET_VERSION "1.10"
#define ROCKET_DATE "2-Apr-96"

