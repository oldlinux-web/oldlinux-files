/*
 * version.h --- controls the version number printed by rocketport driver
 */

#define ROCKET_VERSION "1.12"
#define ROCKET_DATE "9-Sep-96"

