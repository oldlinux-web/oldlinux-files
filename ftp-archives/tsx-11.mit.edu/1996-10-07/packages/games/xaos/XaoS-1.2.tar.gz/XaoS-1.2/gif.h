#ifndef GIF_H
#define GIF_H
#include "zoom.h"
char *writegif(zoom_context *);
#endif
