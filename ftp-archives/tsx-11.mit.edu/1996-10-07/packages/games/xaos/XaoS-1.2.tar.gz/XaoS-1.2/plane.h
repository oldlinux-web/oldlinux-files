#ifndef PLANE_H
#define PLANE_H

#include "config.h"
#include "zoom.h"

#define P_MU 0
#define P_INVERSE 1
#define P_PARABOL 2
#define P_LAMBDA 3
#define P_INVLAMBDA 4
#define P_TRANLAMBDA 5
#define P_MEREBERG 6
extern void INLINE recalculate(zoom_context *, number_t *, number_t *) REGISTERS(3);
extern void INLINE recalculateback(zoom_context *, number_t *, number_t *) REGISTERS(3);
extern char *planename[];

#endif				/* PLANE_H */
