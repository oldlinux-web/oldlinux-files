#ifndef AUTOPILOT_H
#define AUTOPILOT_H

#include "config.h"
#include "zoom.h"

void do_autopilot(CONST zoom_context *, int *, int *, int *);

#endif
