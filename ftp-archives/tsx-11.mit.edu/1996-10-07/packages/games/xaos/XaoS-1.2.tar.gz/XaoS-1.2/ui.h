#ifndef UI_H
#define UI_H

#define BUTTON1 256
#define BUTTON2 512
#define BUTTON3 1024

void ui_do_fractal(void);
void ui_message(void);
void ui_init(zoom_context *, void (*)(), int (*)(), int, void (*)(int, int, char *), int);
void ui_tbreak(void);
void ui_status(void);
void ui_savefile(void);
void ui_coloringmode(void);
void ui_mandelbrot(int, int);
void ui_incoloringmode(void);
int ui_autopilot(void);
void ui_speedup(void);
void ui_help(void);
void ui_updateparameters(void);
void ui_slowdown(void);
int ui_mouse(int, int, int, int);
int ui_inverse(void);

#endif				/* UI_H */
