#ifdef _plan9_
#include <u.h>
#include <libc.h>
#include <stdio.h>
#else
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#endif
#include "zoom.h"
#include "autopilot.h"
#include "ui.h"

#define InSet(i) (i==context->colors[0])

void do_autopilot(CONST zoom_context * context, int *x, int *y, int *controls)
{
    static int x1, y1, c1;
    int i, j, i1, j1, c, max;
    static int time;

    if (time <= 0) {
	max = NGUESSES1;
	ui_tbreak();
	do {
	    max--;
	    c = 0;
	    x1 = rand() % (context->width - 2 * LOOKSIZE) + LOOKSIZE;
	    y1 = rand() % (context->height - 2 * LOOKSIZE) + LOOKSIZE;
	    time = rand() % MAXTIME;
	    for (i = x1 - LOOKSIZE; i <= x1 + LOOKSIZE; i++)
		for (j = y1 - LOOKSIZE; j <= y1 + LOOKSIZE; j++)
		    if (InSet(*(context->vbuff + i + j * context->width)))
			c++;
	} while ((c == 0 || c > LOOKSIZE * LOOKSIZE) && max > 0);
	if (max > 0)
	    c1 = BUTTON1;
	else {
	    max = NGUESSES2;
	    do {
		max--;
		c = 0;
		x1 = rand() % (context->width - 2 * LOOKSIZE) + LOOKSIZE;
		y1 = rand() % (context->height - 2 * LOOKSIZE) + LOOKSIZE;
		time = rand() % MAXTIME;
		for (i = x1 - LOOKSIZE; i <= x1 + LOOKSIZE; i++)
		    for (j = y1 - LOOKSIZE; j < y1 + LOOKSIZE; j++)
			for (i1 = x1 - LOOKSIZE; i1 < x1 + LOOKSIZE; i1++)
			    for (j1 = y1 - LOOKSIZE; j1 < y1 + LOOKSIZE; j1++)
				if (i1 != i && j1 != j &&
				    (*(context->vbuff + i + j * context->width)) ==
				    (*(context->vbuff + i1 + j1 * context->width)))
				    c++;
	    } while ((c > LOOKSIZE * LOOKSIZE / 2) && max > 0);
	    if (max > 0)
		c1 = BUTTON1;
	    else
		c1 = BUTTON3, time >>= 1;
	}
    }
    time--; {
	*x = x1;
	*y = y1;
	*controls = c1;
    }
}
