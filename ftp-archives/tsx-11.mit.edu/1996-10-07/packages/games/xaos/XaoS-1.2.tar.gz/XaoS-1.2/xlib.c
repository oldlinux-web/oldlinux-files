#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include "xlib.h"
#include "config.h"

#define chkalloc(n) if (!n) fprintf(stderr, "out of memory\n"), exit(-1)

int INLINE xupdate_size(xdisplay * d)
{
    int tmp;
    Window wtmp;
    int width = d->width, height = d->height;
    XGetGeometry(d->display, d->window, &wtmp, &tmp, &tmp, &d->width, &d->height, (unsigned int *) &tmp, (unsigned int *) &tmp);
    if (d->width != width || d->height != height)
	return 1;
    return 0;
}

void INLINE xflip_buffers(xdisplay * d)
{
    d->back = d->vbuffs[d->current];
    d->current ^= 1;
    d->vbuff = d->vbuffs[d->current];
}

void INLINE draw_screen(xdisplay * d)
{
#ifdef MITSHM
    if (d->SharedMemFlag) {
	XShmPutImage(d->display, d->window, d->gc, d->image[d->current], 0, 0, 0,
		     0, d->width, d->height, True);
	XFlush(d->display);
    } else
#endif
    {
	XPutImage(d->display, d->window, d->gc, d->image[d->current], 0, 0, 0, 0, d->width, d->height);
	XFlush(d->display);
    }
    d->screen_changed = 0;
}

#ifdef MITSHM
int INLINE alloc_shm_image(xdisplay * new)
{
    register char *ptr;
    int temp, size = 0, i;
    ptr = DisplayString(new->display);
    if (!ptr || (*ptr == ':') || !strncmp(ptr, "localhost:", 10) ||
	!strncmp(ptr, "unix:", 5) || !strncmp(ptr, "local:", 6)) {
	new->SharedMemOption = XQueryExtension(new->display, "MIT-SHM", &temp, &temp, &temp);
    } else {
	new->SharedMemOption = False;
	return 0;
    }
    new->SharedMemFlag = False;
#if 0
    new->SharedMemOption = True;
    new->SharedMemFlag = False;
#endif

    if (new->SharedMemFlag) {
	XShmDetach(new->display, &new->xshminfo[0]);
	XShmDetach(new->display, &new->xshminfo[1]);
	new->image[0]->data = (char *) NULL;
	new->image[1]->data = (char *) NULL;
	shmdt(new->xshminfo[0].shmaddr);
	shmdt(new->xshminfo[1].shmaddr);
    }
    for (i = 0; i < 2; i++) {
	if (new->SharedMemOption) {
	    new->SharedMemFlag = False;
	    new->image[i] = XShmCreateImage(new->display, new->visual, new->depth, ZPixmap,
		       NULL, &new->xshminfo[i], new->width, new->height);
	    if (new->image[i]) {
		temp = new->image[i]->bytes_per_line * new->image[i]->height;
		new->linewidth = new->image[i]->bytes_per_line;
		if (temp > size)
		    size = temp;
		new->xshminfo[i].shmid = shmget(IPC_PRIVATE, size, IPC_CREAT | 0777);
		if (new->xshminfo[i].shmid != -1) {
		    new->xshminfo[i].shmaddr = (char *) shmat(new->xshminfo[i].shmid, 0, 0);
		    if (new->xshminfo[i].shmaddr != (char *) -1) {
			new->image[i]->data = new->xshminfo[i].shmaddr;
			new->vbuffs[i] = (char *) new->image[i]->data;
			new->xshminfo[i].readOnly = True;

			new->SharedMemFlag = XShmAttach(new->display, &new->xshminfo[i]);
			XSync(new->display, False);
		    }
		    /* Always Destroy Shared Memory Ident */
		    shmctl(new->xshminfo[i].shmid, IPC_RMID, 0);
		}
		if (!new->SharedMemFlag) {
		    XDestroyImage(new->image[i]);
		    new->image[i] = (XImage *) NULL;
		    new->SharedMemFlag = 0;
		    return 0;
		}
	    } else {
		new->SharedMemFlag = 0;
		return 0;
	    }
	} else {
	    new->SharedMemFlag = 0;
	    return 0;
	}
    }
    new->current = 0;
    xflip_buffers(new);
    return 1;
}

void INLINE free_shm_image(xdisplay * d)
{
    if (d->SharedMemFlag) {
	XDestroyImage(d->image[0]);
	XDestroyImage(d->image[1]);
	XShmDetach(d->display, &d->xshminfo[0]);
	XShmDetach(d->display, &d->xshminfo[1]);
	d->image[0]->data = (char *) NULL;
	d->image[1]->data = (char *) NULL;
	shmdt(d->xshminfo[0].shmaddr);
	shmdt(d->xshminfo[1].shmaddr);
    }
}

#endif

int INLINE alloc_image(xdisplay * d)
{
    int i;
#ifdef MITSHM
    if (alloc_shm_image(d))
	return 1;
#endif
    for (i = 0; i < 2; i++) {
	d->image[i] = XCreateImage(d->display, d->visual, d->depth, ZPixmap, 0,
	 malloc(d->width * d->height), d->width, d->height, 8, d->width);
	d->vbuffs[i] = (char *) d->image[i]->data;
	d->linewidth = d->image[i]->bytes_per_line;
    }
    xflip_buffers(d);
    return 1;
}

void INLINE free_image(xdisplay * d)
{
#ifdef MITSHM
    if (d->SharedMemFlag) {
	free_shm_image(d);
	return;
    }
#endif
    XDestroyImage(d->image[0]);
    XDestroyImage(d->image[1]);
}

xdisplay INLINE *xalloc_display(char *s, int x, int y)
{
    xdisplay *new;

    new = (xdisplay *) malloc(sizeof(xdisplay));
    chkalloc(new);
    new->display = XOpenDisplay((char *) NULL);
    if (!new->display) {
	fprintf(stderr, "could not open display\n");
	free((void *) new);
	exit(-1);
    }
    new->screen = DefaultScreen(new->display);
    new->attributes = (XSetWindowAttributes *)
	malloc(sizeof(XSetWindowAttributes));
    chkalloc(new->attributes);
    new->attributes->background_pixel = BlackPixel(new->display,
						   new->screen);
    new->attributes->border_pixel = BlackPixel(new->display, new->screen);
    new->attributes->event_mask = ButtonPressMask | StructureNotifyMask | ButtonReleaseMask | ButtonMotionMask | KeyPressMask | ExposureMask | KeyReleaseMask;
    new->attributes->override_redirect = False;
    new->attr_mask = CWBackPixel | CWBorderPixel | CWEventMask;
    new->depth = DefaultDepth(new->display, new->screen);
    new->class = InputOutput;
    new->parent_window = RootWindow(new->display, new->screen);
    new->visual = DefaultVisual(new->display, new->screen);
    if (new->visual->class == PseudoColor) {
	new->colormap = DefaultColormap(new->display, new->screen);
	new->depth = DefaultDepth(new->display, new->screen);
    } else {
	printf("Display does not support PseudoColor!\n");
	exit(-1);
    }

    new->window_name = s;
    new->height = y;
    new->width = x;
    new->border_width = 2;
    new->lastx = 0;
    new->lasty = 0;
    new->font_struct = (XFontStruct *) NULL;

    new->window = XCreateWindow(new->display, new->parent_window, 0, 0,
			      new->width, new->height, new->border_width,
				new->depth, new->class, new->visual,
				new->attr_mask, new->attributes);
    new->gc = XCreateGC(new->display, new->window, 0L, &(new->xgcvalues));
    XSetBackground(new->display, new->gc,
		   BlackPixel(new->display, new->screen));
    XSetForeground(new->display, new->gc,
		   WhitePixel(new->display, new->screen));
    XStoreName(new->display, new->window, new->window_name);
    XMapWindow(new->display, new->window);
#if 0
    XSelectInput(new->display, new->window, ExposureMask | KeyPress |
		 KeyRelease | ConfigureRequest | ButtonPressMask |
		 FocusChangeMask | ButtonReleaseMask |
		 StructureNotifyMask);
#endif
    new->pixmap = XCreatePixmap(new->display, new->window, new->width,
				new->height, new->depth);
    xclear_screen(new);
    return (new);
}

void INLINE xsetcolor(xdisplay * d, int col)
{
    switch (col) {
    case 0:
	XSetForeground(d->display, d->gc,
		       BlackPixel(d->display, d->screen));
	break;
    case 1:
	XSetForeground(d->display, d->gc,
		       WhitePixel(d->display, d->screen));
	break;
    default:
	if ((col - 2) > d->xcolor.n) {
	    fprintf(stderr, "color error\n");
	    exit(-1);
	}
	XSetForeground(d->display, d->gc,
		       d->xcolor.c[col - 2].pixel);
	break;
    }
}

int INLINE xalloc_color(xdisplay * d, int r, int g, int b, int readwrite)
{
    d->xcolor.n++;
    d->xcolor.c[d->xcolor.n - 1].flags = DoRed | DoGreen | DoBlue;
    d->xcolor.c[d->xcolor.n - 1].red = r;
    d->xcolor.c[d->xcolor.n - 1].green = g;
    d->xcolor.c[d->xcolor.n - 1].blue = b;
    d->xcolor.c[d->xcolor.n - 1].pixel = d->xcolor.n - 1;
    if (readwrite) {
	unsigned long cell;
	if (!XAllocColorCells(d->display, d->colormap, 0, 0, 0, &cell, 1)) {
	    d->xcolor.n--;
	    return (-1);
	}
	d->xcolor.c[d->xcolor.n - 1].pixel = cell;
	XStoreColor(d->display, d->colormap, &(d->xcolor.c[d->xcolor.n - 1]));
	return (cell);
    }
    if (!XAllocColor(d->display, d->colormap, &(d->xcolor.c[d->xcolor.n - 1]))) {
	d->xcolor.n--;
	return (-1);
    }
    return (d->xcolor.c[d->xcolor.n - 1].pixel);
}

void INLINE xfree_colors(xdisplay * d)
{
    unsigned long pixels[256];
    int i;
    for (i = 0; i < d->xcolor.n; i++)
	pixels[i] = d->xcolor.c[i].pixel;
    XFreeColors(d->display, d->colormap, pixels, d->xcolor.n, 0);
    d->xcolor.n = 0;
}

void INLINE xfree_display(xdisplay * d)
{
    XSync(d->display, 0);
    free_image(d);
    if (d->font_struct != (XFontStruct *) NULL) {
	XFreeFont(d->display, d->font_struct);
    }
    XUnmapWindow(d->display, d->window);
    XFreePixmap(d->display, d->pixmap);
    XDestroyWindow(d->display, d->window);
    XCloseDisplay(d->display);
    free((void *) d->attributes);
    free((void *) d);
}

void INLINE xline(xdisplay * d, int x1, int y1, int x2, int y2)
{
    XDrawLine(d->display, d->pixmap, d->gc, x1, y1, x2, y2);
    d->lastx = x2, d->lasty = y2;
    d->screen_changed = 1;
}

void INLINE xlineto(xdisplay * d, int x, int y)
{
    XDrawLine(d->display, d->pixmap, d->gc, d->lastx, d->lasty, x, y);
    d->lastx = x, d->lasty = y;
    d->screen_changed = 1;
}

void INLINE xmoveto(xdisplay * d, int x, int y)
{
    d->lastx = x, d->lasty = y;
}

void INLINE xrect(xdisplay * d, int x1, int y1, int x2, int y2)
{
    XDrawRectangle(d->display, d->pixmap, d->gc, x1, y1,
		   (x2 - x1), (y2 - y1));
    d->lastx = x2, d->lasty = y2;
    d->screen_changed = 1;
}

void INLINE xfillrect(xdisplay * d, int x1, int y1, int x2, int y2)
{
    XFillRectangle(d->display, d->pixmap, d->gc, x1, y1,
		   (x2 - x1), (y2 - y1));
    d->lastx = x2, d->lasty = y2;
    d->screen_changed = 1;
}

void INLINE xpoint(xdisplay * d, int x, int y)
{
    XDrawPoint(d->display, d->pixmap, d->gc, x, y);
    d->lastx = x, d->lasty = y;
    d->screen_changed = 1;
}

void INLINE xflush(xdisplay * d)
{
    draw_screen(d);
    XFlush(d->display);
}

void INLINE xclear_screen(xdisplay * d)
{
    xfillrect(d, 0, 0, d->width, d->height);
    d->screen_changed = 1;
}

int INLINE xsetfont(xdisplay * d, char *font_name)
{
    if (d->font_struct != (XFontStruct *) NULL) {
	XFreeFont(d->display, d->font_struct);
    }
    d->font_struct = XLoadQueryFont(d->display, font_name);
    if (!d->font_struct) {
	fprintf(stderr, "could not load font: %s\n", font_name);
	exit(-1);
    }
    return (d->font_struct->max_bounds.ascent + d->font_struct->max_bounds.descent);
}

void INLINE xouttext(xdisplay * d, char *string)
{
    int sz;

    sz = strlen(string);
    XDrawImageString(d->display, d->window, d->gc, d->lastx, d->lasty,
		     string, sz);
#if 0
    d->lastx += XTextWidth(d->font_struct, string, sz);
    d->screen_changed = 1;
#endif
}

void INLINE xresize(xdisplay * d, XEvent * ev)
{
    XFreePixmap(d->display, d->pixmap);
    d->width = ev->xconfigure.width;
    d->height = ev->xconfigure.height;
    d->pixmap = XCreatePixmap(d->display, d->window, d->width,
			      d->height, d->depth);
    xclear_screen(d);
}

void INLINE xarc(xdisplay * d, int x, int y, unsigned int w,
		 unsigned int h, int a1, int a2)
{
    XDrawArc(d->display, d->pixmap, d->gc, x, y, w, h, a1, a2);
}
void INLINE xfillarc(xdisplay * d, int x, int y, unsigned int w,
		     unsigned int h, int a1, int a2)
{
    XFillArc(d->display, d->pixmap, d->gc, x, y, w, h, a1, a2);
}

int INLINE xmouse_x(xdisplay * d)
{
    return d->mouse_x;
}

int INLINE xmouse_y(xdisplay * d)
{
    return d->mouse_y;
}

void INLINE xmouse_update(xdisplay * d)
{
    Window rootreturn, childreturn;
    int rootx = 0, rooty = 0;

    XQueryPointer(d->display, d->window, &rootreturn, &childreturn,
		  &rootx, &rooty, &(d->mouse_x), &(d->mouse_y),
		  &(d->mouse_buttons));
}

unsigned int INLINE xmouse_buttons(xdisplay * d)
{
    return d->mouse_buttons;
}
