#include "koules.h"
#define NO_CLIP_FONT  0x7FFFFFFF

extern int      vgadrawtext (CONST int, CONST int, CONST int, CONST char *);
extern int      vgatextsize (CONST int, CONST char *);
extern void     set_max_text_width (CONST int);
