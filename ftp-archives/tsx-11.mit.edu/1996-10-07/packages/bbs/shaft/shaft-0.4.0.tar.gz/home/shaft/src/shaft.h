/* This file is copyright 1996 by Matt Gischer (matt@fidalgo.net)
 * It is freely distributable for personal uses, but if you are employing
 * it for other things, you must first ask me.  I guess other than that, 
 * you should follow the GNU Public License.  thanks.  If you make any
 * changes/fixes, please mail them to me.  */
#define VERSION		"0.4.0"
#define FULLVERSION	"ShaftBBS v0.4Alpha0"

#define SYSOPLEV	100
#define NEWLEV		10
#define NEWUSERTIME	60
#define MAXUSERS	100
#define MAXMSGAREAS	32

#define BBSPATH		"/home/shaft/shaft"
#define DATAPATH	"/home/shaft/data/"
#define BBSDATA		"/home/shaft/data/users.bbs"
#define CFGFILE		"/home/shaft/data/config.bbs"
#define BBSHOMEPREFIX	"/home/shaft/home/"
#define MENUPATH	"/home/shaft/menu/"
#define MAINMENU	"main"
#define MENUANSPATH	"/home/shaft/menu/"
#define MAINANS		"main.ans"
#define ERRLOG		"/home/shaft/data/errlog.bbs"
#define TMPDIR		"/tmp/"

#define print(text) amtext(text)

struct setup
  {
    char bbsname[80];
    char sysopname[80];
    char phonenumber[80];
    char hostname[80];
  }
cfg;

struct user
  {
    char id[12];
    char alias[80];
    char firstname[80];
    char lastname[80];
    char address[80];
    char city[80];
    char state[3];
    char zipcode[12];
    char homephone[80];
    char dataphone[80];
    char email[80];
    char comment[80];
    int seclev;
    int timeday;
    int timeleft;
    long lastlogin;
    char editor[80];
    int chat;
    int ansi;
  };

struct user info[MAXUSERS];

struct menustuff
  {
    char cmd[80];
    char type[80];
    char param[80];
    int sl;
  };

struct menustuff menu[25];

struct passwd *User;
char *login;

int currentu;

int newuser;

int menuitems;

int ansi;

char currentmsgfile[80];

char prompt[80];
