/* This file is copyright 1996 by Matt Gischer (matt@fidalgo.net)
 * It is freely distributable for personal uses, but if you are employing
 * it for other things, you must first ask me.  I guess other than that, 
 * you should follow the GNU Public License.  thanks.  If you make any
 * changes/fixes, please mail them to me.  */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "shaft.h"

/* This file is just full of functions for the user editor and for users 
 * changing their own personal information.. a lot of the functions are very 
 * similar */

/* This function should probably never be needed, unless you for some 
 * reason change someone's login name */
change_login ()
{
  int i, p;
  char tmp[80];
  i = currentu;

  if (newuser == 0)
    {
      print ("@D[@C#i@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter login:@F ");
  gets (info[i].id);
}

change_alias ()
{
  int i, p, l;
  char tmp[80], *loc;
  i = currentu;

  if (newuser == 0)
    {
      print ("@D[@C#a@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter alias:@F ");
  gets (tmp);
/* this allows people to have one space in their nickname.. otherwise it gets cut off.. if there
 * are no spaces.. no problem :) */
  loc = strtok (tmp, " ");
  strcpy (info[i].alias, loc);
  if ((loc = strtok (NULL, " ")))
    {
      sprintf (tmp, " %s", loc);
      strcat (info[i].alias, tmp);
    }
}

change_sl ()
{
  int i, p;
  char tmp[80];
  i = currentu;

  do
    {
      if (newuser == 0)
	{
	  print ("@D[@C#S@D] @6[@0Old Value@6]\n");
	}
      print ("@DSecurity level: ");
      gets (tmp);
      info[i].seclev = atoi (tmp);
    }
  while ((info[i].seclev > SYSOPLEV) || (info[i].seclev < 0));
}

change_timeday ()
{
  int i, p;
  char tmp[80];
  i = currentu;

  if (newuser == 0)
    {
      print ("@D[@C#d@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter the time per day: ");
  gets (tmp);
  info[i].timeday = atoi (tmp);
}

change_timeleft ()
{
  int i, p;
  char tmp[80];
  i = currentu;

  if (newuser == 0)
    {
      print ("@D[@C#t@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter the time left today: ");
  gets (tmp);
  info[i].timeleft = atoi (tmp);
}

change_name ()
{
  int i;
  i = currentu;
  if (newuser == 0)
    {
      print ("@D[@C#f@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter your first name:@F ");
  gets (info[i].firstname);
  if (newuser == 0)
    {
      print ("@D[@C#l@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter your last name:@F ");
  gets (info[i].lastname);
}

change_addr ()
{
  int i, p;
  char tmp[80];
  i = currentu;

  if (newuser == 0)
    {
      print ("@D[@C#A@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter your address:@F ");
  gets (info[i].address);
}

change_city ()
{
  int i, p;
  char tmp[80];
  i = currentu;

  if (newuser == 0)
    {
      print ("@D[@C#c@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter the name of the city you live in:@F ");
  gets (info[i].city);
}

change_state ()
{
  int i, p;
  char tmp[80];
  i = currentu;
  do
    {
      if (newuser == 0)
	{
	  print ("@D[@C#s@D] @6[@0Old Value@6]\n");
	}
      print ("@DEnter the name of the state you live in:@F ");
      gets (info[i].state);
    }
  while (strlen (info[i].state) != 2);
  toup (info[i].state);
}

change_zipcode ()
{
  int i, p;
  char tmp[80];
  i = currentu;

  if (newuser == 0)
    {
      print ("@D[@C#Z@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter your zip code:@F ");
  gets (info[i].zipcode);
}

change_homephone ()
{
  int i, p;
  char tmp[80];
  i = currentu;

  if (newuser == 0)
    {
      print ("@D[@C#P@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter your home phone number:@F ");
  gets (info[i].homephone);
}
change_dataphone ()
{
  int i, p;
  char tmp[80];
  i = currentu;

  if (newuser == 0)
    {
      print ("@D[@C#D@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter your data phone number:@F ");
  gets (info[i].dataphone);
}

change_email ()
{
  int i, p;
  char tmp[80];
  i = currentu;

  if (newuser == 0)
    {
      print ("@D[@C#e@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter your email address:@F ");
  gets (info[i].email);
}

change_comment ()
{
  int i, p;
  char tmp[80];
  i = currentu;

  if (newuser == 0)
    {
      print ("@D[@C#C@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter your user comment:@F ");
  gets (info[i].comment);
}

change_lastlogin ()
{
  int i, p;
  char tmp[80];
  i = currentu;

  if (newuser == 0)
    {
      print ("@D[@C#L@D] @6[@0Old Value@6]\n");
    }
  print ("@DEnter the date of first login:@F ");
  gets (tmp);
  info[i].lastlogin = atoi (tmp);
}

change_editor ()
{
  int i;
  i = currentu;
  strcpy (info[i].editor, "/usr/bin/pico");
}

tog_ansi ()
{
  print ("@6Would you like ANSI Color?");
  info[currentu].ansi = yesno ();
}

tog_chat ()
{
  print ("@6Would you like to be available for chat?");
  info[currentu].chat = yesno ();
}
