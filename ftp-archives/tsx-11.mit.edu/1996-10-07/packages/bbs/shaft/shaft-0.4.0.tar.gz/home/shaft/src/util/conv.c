#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "shaft.h"
#include "shaft2.h"

main ()
{
  readinfo ();
  convert ();
  writeinfo ();
}

readinfo ()
{
  FILE *userfile;
  if ((userfile = fopen (BBSDATA, "rb")) == NULL)
    {
      printf ("Cannot open userfile, %s...exiting\n", BBSDATA);
      exit (1);
    }
  fread (&info, sizeof (struct user), MAXUSERS, userfile);
  fclose (userfile);
}

writeinfo ()
{
  FILE *userfile;
  if ((userfile = fopen (BBSDATA, "wb")) == NULL)
    {
      printf ("Cannot open userfile, %s...exiting\n", BBSDATA);
      exit (1);
    }
  fwrite (&infonew, sizeof (struct user2), MAXUSERS, userfile);
  fclose (userfile);
}

convert ()
{
  int i = 0, x = 0;
/*  while (!(strcmp (info[i].id, "")) == 0)
	 {
	 i++;
	 }*/
	 for (x = 0; x < 5; x++)
	 {
	 strcpy(infonew[x].id,info[x].id);
	 strcpy(infonew[x].alias,info[x].alias);
	 strcpy(infonew[x].firstname,info[x].firstname);
	 strcpy(infonew[x].lastname,info[x].lastname);
	 strcpy(infonew[x].address,info[x].address);
	 strcpy(infonew[x].city,info[x].city);
	 strcpy(infonew[x].state,info[x].state);
	 strcpy(infonew[x].zipcode,info[x].zipcode);
	 strcpy(infonew[x].homephone,info[x].homephone);
	 strcpy(infonew[x].dataphone,info[x].dataphone);
	 strcpy(infonew[x].email,info[x].email);
	 strcpy(infonew[x].comment,info[x].comment);
	 infonew[x].seclev=info[x].seclev;
	 infonew[x].timeday=info[x].timeday;
	 infonew[x].timeleft=info[x].timeleft;
	 infonew[x].lastlogin=info[x].lastlogin;
	 strcpy (infonew[x].editor, "/usr/bin/pico");
	 infonew[x].chat = 1;
	 infonew[x].ansi = 1;
	 }
	 }
