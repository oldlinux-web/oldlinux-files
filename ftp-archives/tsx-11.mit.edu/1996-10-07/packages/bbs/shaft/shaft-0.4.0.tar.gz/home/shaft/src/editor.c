/* This file is copyright 1996 by Matt Gischer (matt@fidalgo.net)
 * It is freely distributable for personal uses, but if you are employing
 * it for other things, you must first ask me.  I guess other than that, 
 * you should follow the GNU Public License.  thanks.  If you make any
 * changes/fixes, please mail them to me.  */
#include <stdio.h>
#include "shaft.h"
#include "msg.h"
/* Just threw some stuff I was working on in here.. obviously it doesn't work..heh. */

textedit ()
{
  while (msg[currentmsg].body[line - 1][0] != '/')
    {
      fgets (msg[currentmsg].body[line], 79, stdin);
      line++;
    }
  strcpy (currentmsgfile, "/tmp/lame");
  if ((msgfile = fopen (currentmsgfile, "w")) == 0)
    {
      exit (1);
    }
/* Prevents / from being caught */
  line--;
/* This loop writes the body to file */
  for (count = 0; count < line; count++)
    {
      sprintf (tmp, "%s\n", msg[currentmsg].body[count]);
      fputs (tmp, msgfile);
    }
  fclose (msgfile);
}
