/* This file is copyright 1996 by Matt Gischer (matt@fidalgo.net)
 * It is freely distributable for personal uses, but if you are employing
 * it for other things, you must first ask me.  I guess other than that, 
 * you should follow the GNU Public License.  thanks.  If you make any
 * changes/fixes, please mail them to me.  
 * Ok.. the original code for the amtext routine came from ambbs..
 * I've changed it around a whole lot, but without that help.. i'd never have
 * the function.  So.. amtext() is not mine.. see below comments :)
 * AmeriSoft OutPut Parser
 * 'AmText' -- ANSI Colors, and such
 * (C)opyRight 1995 by AmeriSoft Unix Technoliges
 * Programmed by James Tavares
 */
#include <stdio.h>
#include "shaft.h"
#include "msg.h"

/* Some ANSI escape sequences.. if there are some missing that you
 * wanna use.. add 'em */
char *Ansi[] =
{
  "1", "[0;31m",
  "2", "[0;32m",
  "3", "[0;33m",
  "4", "[0;34m",
  "5", "[0;35m",
  "6", "[0;36m",
  "7", "[0;37m",
  "8", "[0;38m",
  "9", "[0;39m",
  "0", "[1;30m",
  "A", "[1;31m",
  "B", "[1;32m",
  "C", "[1;33m",
  "D", "[1;34m",
  "E", "[1;35m",
  "F", "[1;36m",
  "G", "[1;37m",
  "H", "[1;38m",
  "I", "[1;39m",
  "J", "[1;40m",
  "K", "[1;41m",
  "L", "[1;42m",
  "M", "[1;43m",
  "N", "[1;44m",
  "O", "[1;45m",
  "P", "[1;46m",
  "Q", "[1;47m",
  "R", "[1;48m",
  "S", "[1;49m",
  "T", "[1;30m",

  "a", "[0;40m",
  "b", "[0;41m",
  "c", "[0;42m",
  "d", "[0;43m",
  "e", "[0;44m",
  "f", "[0;45m",
  "g", "[0;46m",
  "h", "[0;47m",
  "i", "[0;48m",
  "j", "[0;49m",
  "k", "[0;20m",
  "l", "[0;21m",
  "m", "[0;22m",
  "n", "[0;23m",
  "o", "[0;24m",
  "p", "[0;25m",
  "q", "[0;26m",
  "r", "[0;27m",
  "s", "[0;28m",
  "t", "[0;29m",

  "V", "[7m",
  "v", "[0m",
  NULL,
};

/* This function interprets all of the @ and # codes */
amtext (char *text)
{
  int len, c = 0, x = 0;
  char lame[80], d[80];

  len = strlen (text);
  while (c < len + 1)
    {
      {
	if (text[c] == '@')
	  {
	    c++;
	    if (text[c] == '@')
	      {
		fputs ("@", stdout);
		c++;
		goto end;
	      }
	    else
	      {
		if (info[currentu].ansi == 1)
		  {
		    printf ("\033");
		  }
		x = 0;
		while (x < 104)
		  {
		    if (text[c] == Ansi[x][0])
		      {
			if (info[currentu].ansi == 1)
			  {
			    fputs (Ansi[x + 1], stdout);
			  }
			c++;
			goto end;
		      }
		    x = x + 2;
		  }
	      }
	  }
	if (text[c] == '#')
	  {
	    c++;
	    if (text[c] == '#')
	      {
		fputs ("#", stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'a')
	      {
		fputs (info[currentu].alias, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'c')
	      {
		fputs (info[currentu].city, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'd')
	      {
		printf ("%i", info[currentu].timeday);
		c++;
		goto end;
	      }
	    else if (text[c] == 'e')
	      {
		fputs (info[currentu].email, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'f')
	      {
		fputs (info[currentu].firstname, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'i')
	      {
		fputs (info[currentu].id, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'l')
	      {
		fputs (info[currentu].lastname, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'p')
	      {
		fputs (cfg.phonenumber, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 's')
	      {
		fputs (info[currentu].state, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 't')
	      {
		printf ("%i", info[currentu].timeleft);
		c++;
		goto end;
	      }
	    else if (text[c] == 'A')
	      {
		fputs (info[currentu].address, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'B')
	      {
		fputs (cfg.bbsname, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'C')
	      {
		fputs (info[currentu].comment, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'D')
	      {
		fputs (info[currentu].dataphone, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'E')
	      {
		fputs (info[currentu].editor, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'F')
	      {
		fputs (FULLVERSION, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'H')
	      {
		fputs (cfg.hostname, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'L')
	      {
		getll (lame);
		printf ("%s", lame);
		c++;
		goto end;
	      }
	    else if (text[c] == 'M')
	      {
		fputs (area[currentmsgbase].name, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'N')
	      {
		printf ("%i", currentmsg[currentmsgbase]);
		c++;
		goto end;
	      }
	    else if (text[c] == 'P')
	      {
		fputs (info[currentu].homephone, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'U')
	      {
		fputs (cfg.sysopname, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'S')
	      {
		fprintf (stdout, "%i", info[currentu].seclev);
		c++;
		goto end;
	      }
	    else if (text[c] == 'T')
	      {
		getdate (d);
		fprintf (stdout, "%s", d);
		c++;
		goto end;
	      }
	    else if (text[c] == 'V')
	      {
		fputs (VERSION, stdout);
		c++;
		goto end;
	      }
	    else if (text[c] == 'X')
	      {
		if ((info[currentu].ansi) == 1)
		  {
		    printf ("\033[1;31m*");
		  }
		else
		  printf (" ");
		c++;
		goto end;
	      }
	    else if (text[c] == 'Y')
	      {
		if ((info[currentu].chat) == 1)
		  {
		    if ((info[currentu].ansi) == 1)
		      printf ("\033[1;31m*");
		    else
		      printf ("*");
		  }
		else
		  printf (" ");
		c++;
		goto end;
	      }
	    else if (text[c] == 'Z')
	      {
		fputs (info[currentu].zipcode, stdout);
		c++;
		goto end;
	      }
	  }
      }
      putchar (text[c]);
      c++;
    end:
    }
}

/* A function that attempts to print out characters in random colors.. fix it or somethin :) 
 * randcol (char *text)
 * {
 * char woo[80];
 * int y = 0, j = 0;
 * 
 * while(y < strlen (text))
 * {
 * j = randnum (9);
 * printf ("\033[1;3%im%c", j, text[y]);
 * y++;
 * }
 * puts ("");
 * }
 */
