
#include <stdio.h>

main (int argc, char *argv[])
{
  int i, x = 1;

  if (argc != 2)
    {
      printf ("Usage: %s filename\n", argv[0]);
    }
  for (i = x; i < argc; i++)
    {
      unlink (argv[i]);
      printf ("Deleting %s\n", argv[i]);
    }
}
