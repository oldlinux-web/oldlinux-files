/* This file is copyright 1996 by Matt Gischer (matt@fidalgo.net)
 * It is freely distributable for personal uses, but if you are employing
 * it for other things, you must first ask me.  I guess other than that, 
 * you should follow the GNU Public License.  thanks.  If you make any
 * changes/fixes, please mail them to me.  */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <signal.h>
#include "shaft.h"
#include "msg.h"

void logout ();
extern timecheck ();

main ()
{
/* Turns off ^C interupt 
 * if(signal (SIGINT, SIG_IGN) != SIG_IGN) */
  signal (SIGINT, logout);
  signal (SIGHUP, logout);
  signal (SIGSEGV, logout);
  signal (SIGTERM, logout);
  signal (SIGQUIT, logout);
  signal (SIGSTOP, logout);
  signal (SIGCONT, logout);
  signal (SIGKILL, logout);
  signal (SIGALRM, (void *)timecheck);
  alarm (60);
/* Read bbs configuration file */
  readcfg ();
  sendtolog ("Starting BBS up.");
/* Set the currentu variable up */
  getusernum ();
/* Read in the user file */
  readinfo ();
  resettime ();
  readmsgbased ();
  currentmsgbase = 0;
  readlastmsgfile();
  print ("Welcome to #B, #a.  You last logged in #L\n@k");
/* Tell them whether they have ansi enabled or not */
  AnsiStat ();
/* Display the main menu */
  readmenu (MAINMENU);
  logout ();
}
