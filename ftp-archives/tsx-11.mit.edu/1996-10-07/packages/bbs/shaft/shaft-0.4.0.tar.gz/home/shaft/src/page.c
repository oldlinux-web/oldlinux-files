/* This file is copyright 1996 by Matt Gischer (matt@fidalgo.net)
 * It is freely distributable for personal uses, but if you are employing
 * it for other things, you must first ask me.  I guess other than that, 
 * you should follow the GNU Public License.  thanks.  If you make any
 * changes/fixes, please mail them to me.  */
#include <stdio.h>
#include "shaft.h"

page (char *filename)
{
  FILE *in;
  char t[80], enter;
  int lines, len = 0, x = 0;

  info[currentu].ansi = 1;
  if ((in = fopen (filename, "r")) == NULL)
    {
    }
  for (lines = 0; !feof (in); lines++)
    {
      fgets (t, 79, in);
    }
  lines = lines - 2;
  rewind (in);
  do
    {
      fgets (t, 79, in);
      if (strlen (t) == 0)
	{
	  exit (0);
	}
      print (t);
      x++;
      if (x == 24)
	{
	  print ("@0[Hit enter for more]@k");
	  enter = getchar ();
	  if (enter == 'q')
	    {
	      exit (0);
	    }
	  else if (enter == ' ')
	    {
	      x--;
	    }
	  else
	    {
	      x = 0;
	    }
	}
      len++;
    }
  while (len <= lines);
  fclose (in);
  return 0;
}
