/* This file is copyright 1996 by Matt Gischer (matt@fidalgo.net)
 * It is freely distributable for personal uses, but if you are employing
 * it for other things, you must first ask me.  I guess other than that, 
 * you should follow the GNU Public License.  thanks.  If you make any
 * changes/fixes, please mail them to me.  */
#define MAXMSGAREAS 32
#define MAXMSGS	    256
#define MSGBASEPATH "/home/shaft/msgs/"
#define MSGBASEDATA "/home/shaft/msgs/msgbase.bbs"
#define LASTSCANFILE "/home/shaft/msgs/lastscan.bbs"

/* Format of the msg area file */
struct areas
  {
    char name[80];
    char desc[80];
    int number;
    int seclev;
    int nummsgs;
  };

struct areas area[MAXMSGAREAS];

struct areadata
  {
    int num[MAXMSGAREAS];
    char filename[MAXMSGAREAS][80];
  };
 
int damnit;

/* this is the format of the message file.. roughly...hehe */
struct message
  {
    char attr[80];
    char time[50];
    char sender[80];
    char subject[80];
    char body[1000][80];
  };

struct message msg[100];

int curmsgs[MAXUSERS][MAXMSGAREAS];

int currentmsg[MAXMSGAREAS];
int currentmsgbase;
/*int currentmsg; */

void writemsg ();
void readmsg ();
void getmsgnum ();
void readmsgbased ();
void writemsgbased ();
void showmsg ();
void addmsgbase ();
void delmsgbase ();
void showmsgbases ();
void choosecurrentmsg ();
void choosemsgbase ();
void upone ();
void downone ();
void writelastmsgfile ();
void readlastmsgfile ();
void createlastmsgfile ();

