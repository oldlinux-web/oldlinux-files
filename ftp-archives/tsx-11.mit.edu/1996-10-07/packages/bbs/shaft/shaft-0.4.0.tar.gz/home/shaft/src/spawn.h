#ifndef __SPAWN_H
#define __SPAWN_H

#include <unistd.h>

extern pid_t SPAWN_CHILD_PID;

#define spawnl(path, arg, args...) spawnfunc(execv, path , arg , ## args )
#define spawnlp(file, arg, args...) spawnfunc(execvp, file , arg , ## args )
#define spawnle(path, arg, args...) spawnfunc(exect, path , arg , ## args )

/* extern C {
 * * int spawnfunc(int (*func)(const char *path, char *const argv[]), const char *file, ...);
 * *
 * } */

#endif /* __SPAWN_H */
