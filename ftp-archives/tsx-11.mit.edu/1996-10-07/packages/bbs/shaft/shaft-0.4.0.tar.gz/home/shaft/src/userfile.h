void readinfo ();
void writeinfo ();
void changeinfo ();
void getusernum ();
void getuser ();
void adduser ();
void deluser ();
