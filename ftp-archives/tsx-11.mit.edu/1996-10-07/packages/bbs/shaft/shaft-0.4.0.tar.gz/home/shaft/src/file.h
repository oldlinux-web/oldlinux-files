void readcfg ();
void userlist ();
