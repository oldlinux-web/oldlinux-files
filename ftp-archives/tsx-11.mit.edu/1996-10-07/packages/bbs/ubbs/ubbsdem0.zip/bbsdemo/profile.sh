#
# @(#).profile - Author's own .profile.
#
echo Welcome on board, space cadet!
trap "trap '' 1 2 3 9 15; /usr/bbsdemo/bin/cleanabt.sh `tty`; exit 1" 1 2 3 9 15
tput clear
#stty hupcl -clocal
PATH=$PATH:/usr/bbsdemo/bin
export PATH 

ON="[1m"
OFF="[0m"

umask 011

echo "

"
if [ -s warning.bbs ] ; then
	cat warning.bbs
fi

echo "

"
echo "Chosissez la langue du logon  <*>  Select the logon language"
ask "
[${ON}F${OFF}] Francais                             [${ON}E${OFF}] English
[${ON}1${OFF}] Francais 7 bit                       [${ON}2${OFF}] English 7 bit

[${ON}Q${OFF}] Quitter / Quit

Reponse / Answer" FE12Q t=60 d=Q
RES=$?

echo "--"

if test $RES -eq 1 ; then
  bin/ubbs -g1
  RES=$?
elif test $RES -eq 2 ; then
  bin/ubbs
  RES=$?
elif test $RES -eq 3 ; then
  bin/ubbs -g1 -t
  RES=$?
elif test $RES -eq 4 ; then
  bin/ubbs -t
  RES=$?
fi

if [ $RES -eq 98 -o $RES -eq 99 ] ; then
  # cleanup
  # 98 = ^\ or ^K
  # 99 = hang up
  sh -c "/usr/bbsdemo/bin/cleanabt.sh `tty`"
fi

echo "Byebye - CLIC!"
sleep 3

# cut the communication
stty 0
exit 0
# end of program
