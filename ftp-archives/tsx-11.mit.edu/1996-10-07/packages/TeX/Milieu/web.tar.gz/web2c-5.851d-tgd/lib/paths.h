/* Generated from paths.h.in (Sun Jan 23 04:49:04 MET 1994).  */
/* Paths.  */

/* The meanings of these paths are described in the man pages.  This file is
   created from the defaults in Makefile.in.  */

#ifndef BIBINPUTS
#define BIBINPUTS ".:/usr/TeX/lib/tex/bib"
#endif

#ifndef BSTINPUTS
#define BSTINPUTS ".:/usr/TeX/lib/tex/inputs/bib"
#endif

#ifndef MFBASES
#define MFBASES "/usr/TeX/lib/mf/bases"
#endif

#ifndef MFINPUTS
#define MFINPUTS ".:/usr/TeX/lib/mf/macros//:/usr/TeX/src/TeX+MF/typefaces//"
#endif

#ifndef MFPOOL
#define MFPOOL "/usr/TeX/lib/mf"
#endif

#ifndef TEXFONTS
#define TEXFONTS ".:/usr/TeX/lib/tex/fonts//"
#endif

#ifndef TEXFORMATS
#define TEXFORMATS "/usr/TeX/lib/tex/formats"
#endif

#ifndef TEXINPUTS
#define TEXINPUTS ".:/usr/TeX/lib/tex/inputs//:/usr/TeX/lib/tex/macros//"
#endif

#ifndef TEXPOOL
#define TEXPOOL "/usr/TeX/lib/tex"
#endif

#ifndef GFFONTS
#define GFFONTS ".:/usr/TeX/lib/tex/fonts//"
#endif

#ifndef PKFONTS
#define PKFONTS ".:/usr/TeX/lib/tex/fonts//"
#endif

#ifndef VFFONTS
#define VFFONTS ".:/usr/TeX/lib/tex/fonts//"
#endif
