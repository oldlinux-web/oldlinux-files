char *versionstring = " (C version d)";
