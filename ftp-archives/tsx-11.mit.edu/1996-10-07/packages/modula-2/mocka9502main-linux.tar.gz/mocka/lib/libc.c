/* foo */

/* just for mtc */
BEGIN_libc(){}
