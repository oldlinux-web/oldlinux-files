(******************************************************************************)
(* Copyright (c) 1988 by GMD Karlruhe, Germany				      *)
(* Gesellschaft fuer Mathematik und Datenverarbeitung			      *)
(* (German National Research Center for Computer Science)		      *)
(* Forschungsstelle fuer Programmstrukturen an Universitaet Karlsruhe	      *)
(* All rights reserved.							      *)
(******************************************************************************)

DEFINITION MODULE McComp;

   PROCEDURE CompileDef (module: ARRAY OF CHAR);

   PROCEDURE CompileImp (module: ARRAY OF CHAR);

(* ++ 91/01 - rh *)
(* -- rh -- *)
END McComp.
