(******************************************************************************)
(* Copyright (c) 1988 by GMD Karlruhe, Germany				      *)
(* Gesellschaft fuer Mathematik und Datenverarbeitung			      *)
(* (German National Research Center for Computer Science)		      *)
(* Forschungsstelle fuer Programmstrukturen an Universitaet Karlsruhe	      *)
(* All rights reserved.							      *)
(******************************************************************************)

DEFINITION MODULE PaBodies;

   FROM DfTable IMPORT
      Object;

   PROCEDURE body
      (obj : Object);
   (* Parse the body of a module or procedure and translate
      into abstract syntax.
      On exit obj^.body refers to the tree.  *)

   PROCEDURE InitBodies;
   (* Initialize.  *)

END PaBodies.
