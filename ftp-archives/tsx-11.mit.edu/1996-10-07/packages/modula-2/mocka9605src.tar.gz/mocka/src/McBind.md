(******************************************************************************)
(* Copyright (c) 1988 by GMD Karlruhe, Germany				      *)
(* Gesellschaft fuer Mathematik und Datenverarbeitung			      *)
(* (German National Research Center for Computer Science)		      *)
(* Forschungsstelle fuer Programmstrukturen an Universitaet Karlsruhe	      *)
(* All rights reserved.							      *)
(******************************************************************************)

DEFINITION MODULE McBind;

   PROCEDURE Bind (VAR ProgramName : ARRAY OF CHAR);
   (* Bind the program with name 'ProgramName' *)

   PROCEDURE WriteDependencyFile;
   (* Write the Dependency File for the current compilation unit  *)

END McBind.
