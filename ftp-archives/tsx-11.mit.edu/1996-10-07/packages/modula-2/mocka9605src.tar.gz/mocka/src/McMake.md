(******************************************************************************)
(* Copyright (c) 1988 by GMD Karlruhe, Germany				      *)
(* Gesellschaft fuer Mathematik und Datenverarbeitung			      *)
(* (German National Research Center for Computer Science)		      *)
(* Forschungsstelle fuer Programmstrukturen an Universitaet Karlsruhe	      *)
(* All rights reserved.							      *)
(******************************************************************************)

DEFINITION MODULE McMake;

   TYPE
      GoalClass = (GoalClassSpec, GoalClassCode, GoalClassProg);


   PROCEDURE InitMake;

   PROCEDURE Make; 

   PROCEDURE DefineGoal (name: ARRAY OF CHAR; class: GoalClass);


END McMake.
