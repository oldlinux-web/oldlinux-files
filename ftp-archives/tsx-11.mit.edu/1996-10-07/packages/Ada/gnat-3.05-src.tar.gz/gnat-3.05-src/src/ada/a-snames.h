/****************************************************************************/
/*                                                                          */
/*                         GNAT COMPILER COMPONENTS                         */
/*                                                                          */
/*                             A - S N A M E S                              */
/*                                                                          */
/*                              C Header File                               */
/*                                                                          */
/*                            $Revision: 1.45 $                             */
/*                                                                          */
/*   Copyright (C) 1992,1993,1994,1995,1996 Free Software Foundation, Inc.  */
/*                                                                          */
/* GNAT is free software;  you can  redistribute it  and/or modify it under */
/* terms of the  GNU General Public License as published  by the Free Soft- */
/* ware  Foundation;  either version 2,  or (at your option) any later ver- */
/* sion.  GNAT is distributed in the hope that it will be useful, but WITH- */
/* OUT ANY WARRANTY;  without even the  implied warranty of MERCHANTABILITY */
/* or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License */
/* for  more details.  You should have  received  a copy of the GNU General */
/* Public License  distributed with GNAT;  see file COPYING.  If not, write */
/* to  the Free Software Foundation,  59 Temple Place - Suite 330,  Boston, */
/* MA 02111-1307, USA.                                                      */
/*                                                                          */
/* GNAT was originally developed  by the GNAT team at  New York University. */
/* It is now maintained by Ada Core Technologies Inc (http://www.gnat.com). */
/*                                                                          */
/****************************************************************************/

/* This is the C file that corresponds to the Ada package specification
   Snames. It was created manually from the file snames.ads.

/* Name_Id values */

#define Name_uParent (First_Name_Id + 256 +  13)
#define Name_uTag    (First_Name_Id + 256 +  17)
#define Name_Off     (First_Name_Id + 256 + 183)
#define Name_Space   (First_Name_Id + 256 + 185)
#define Name_Time    (First_Name_Id + 256 + 187)

/* Define the function to return one of the numeric values below.  Note
   that it actually returns a char since an enumeration value of less
   than 256 entries is represented that way in Ada.  The operand is a Chars
   field value.  */

#define Get_Attribute_Id snames__get_attribute_id
extern char Get_Attribute_Id PROTO ((int));

/* Define the numeric values for the attributes.  */

#define  Attr_Abort_Signal                   0
#define  Attr_Access                         1
#define  Attr_Address                        2
#define  Attr_Address_Size                   3
#define  Attr_Adjacent                       4
#define  Attr_Aft                            5
#define  Attr_Alignment                      6
#define  Attr_Bit_Order                      7
#define  Attr_Body_Version                   8
#define  Attr_Callable                       9
#define  Attr_Caller                        10
#define  Attr_Ceiling                       11
#define  Attr_Component_Size                12
#define  Attr_Compose                       13
#define  Attr_Constrained                   14
#define  Attr_Copy_Sign                     15
#define  Attr_Count                         16
#define  Attr_Default_Bit_Order             17
#define  Attr_Definite                      18
#define  Attr_Delta                         19
#define  Attr_Denorm                        20
#define  Attr_Digits                        21
#define  Attr_Emax                          22
#define  Attr_Enum_Rep                      23
#define  Attr_Epsilon                       24
#define  Attr_Exponent                      25
#define  Attr_External_Tag                  26
#define  Attr_First                         27
#define  Attr_First_Bit                     28
#define  Attr_Fixed_Value                   29
#define  Attr_Floor                         30
#define  Attr_Fore                          31
#define  Attr_Fraction                      32
#define  Attr_Has_Discriminants             33
#define  Attr_Identity                      34
#define  Attr_Image                         35
#define  Attr_Img                           36
#define  Attr_Input                         37
#define  Attr_Integer_Value                 38
#define  Attr_Large                         39
#define  Attr_Last                          40
#define  Attr_Last_Bit                      41
#define  Attr_Leading_Part                  42
#define  Attr_Length                        43
#define  Attr_Machine                       44
#define  Attr_Machine_Emax                  45
#define  Attr_Machine_Emin                  46
#define  Attr_Machine_Mantissa              47
#define  Attr_Machine_Overflows             48
#define  Attr_Machine_Radix                 49
#define  Attr_Machine_Rounds                50
#define  Attr_Mantissa                      51
#define  Attr_Max                           52
#define  Attr_Max_Interrupt_Priority        53
#define  Attr_Max_Priority                  54
#define  Attr_Max_Size_In_Storage_Elements  55
#define  Attr_Maximum_Alignment             56
#define  Attr_Min                           57
#define  Attr_Model                         58
#define  Attr_Model_Emin                    59
#define  Attr_Model_Epsilon                 60
#define  Attr_Model_Mantissa                61
#define  Attr_Model_Small                   62
#define  Attr_Modulus                       63
#define  Attr_Object_Size                   64
#define  Attr_Partition_Id                  65
#define  Attr_Passed_By_Reference           66
#define  Attr_Pos                           67
#define  Attr_Position                      68
#define  Attr_Pred                          69
#define  Attr_Range                         70
#define  Attr_Range_Length                  71
#define  Attr_Remainder                     72
#define  Attr_Round                         73
#define  Attr_Rounding                      74
#define  Attr_Safe_Emax                     75
#define  Attr_Safe_First                    76
#define  Attr_Safe_Large                    77
#define  Attr_Safe_Last                     78
#define  Attr_Safe_Small                    79
#define  Attr_Scale                         80
#define  Attr_Scaling                       81
#define  Attr_Signed_Zeros                  82
#define  Attr_Size                          83
#define  Attr_Small                         84
#define  Attr_Storage_Size                  85
#define  Attr_Storage_Unit                  86
#define  Attr_Succ                          87
#define  Attr_Tag                           88
#define  Attr_Terminated                    89
#define  Attr_Tick                          90
#define  Attr_Truncation                    91
#define  Attr_Unbiased_Rounding             92
#define  Attr_Unchecked_Access              93
#define  Attr_Universal_Literal_String      94
#define  Attr_Unrestricted_Access           95
#define  Attr_Val                           96
#define  Attr_Valid                         97
#define  Attr_Value                         98
#define  Attr_Value_Size                    99
#define  Attr_Version                      100
#define  Attr_Wide_Image                   101
#define  Attr_Wide_Value                   102
#define  Attr_Wide_Width                   103
#define  Attr_Width                        104
#define  Attr_Word_Size                    105

#define  Attr_Output                       106
#define  Attr_Read                         107
#define  Attr_Write                        108

#define  Attr_Elab_Body                    109
#define  Attr_Elab_Spec                    110
#define  Attr_Storage_Pool                 111

#define  Attr_Base                         112
#define  Attr_Class                        113

/* Define the function to return one of the numeric values below.  Note
   that it actually returns a char since an enumeration value of less
   than 256 entries is represented that way in Ada.  The operand is a Chars
   field value.  */

#define Get_Pragma_Id snames__get_pragma_id
extern char Get_Pragma_Id PROTO ((int));

/* Define the numeric values for the pragmas. */

/* Configuration pragmas first */

#define  Pragma_Locking_Policy               0
#define  Pragma_Normalize_Scalars            1
#define  Pragma_Queuing_Policy               2
#define  Pragma_Restrictions                 3
#define  Pragma_Reviewable                   4
#define  Pragma_Source_File_Name             5
#define  Pragma_Suppress                     6
#define  Pragma_Task_Dispatching_Policy      7
#define  Pragma_Unsuppress                   8
#define  Pragma_Warnings                     9

/* Remaining pragmas */

#define  Pragma_Abort_Defer                 10
#define  Pragma_Ada_83                      11
#define  Pragma_Ada_95                      12
#define  Pragma_All_Calls_Remote            13
#define  Pragma_Annotate                    14
#define  Pragma_Assert                      15
#define  Pragma_Asynchronous                16
#define  Pragma_Atomic                      17
#define  Pragma_Atomic_Components           18
#define  Pragma_Attach_Handler              19
#define  Pragma_Controlled                  20
#define  Pragma_Convention                  21
#define  Pragma_CPP_Class                   22
#define  Pragma_CPP_Constructor             23
#define  Pragma_CPP_Destructor              24
#define  Pragma_CPP_Virtual                 25
#define  Pragma_CPP_Vtable                  26
#define  Pragma_Debug                       27
#define  Pragma_Discard_Names               28
#define  Pragma_Elaborate                   29
#define  Pragma_Elaborate_All               30
#define  Pragma_Elaborate_Body              31
#define  Pragma_Error_Monitoring            32
#define  Pragma_Export                      33
#define  Pragma_Import                      34
#define  Pragma_Inline                      35
#define  Pragma_Inline_Generic              36
#define  Pragma_Inspection_Point            37
#define  Pragma_Interface                   38
#define  Pragma_Interface_Name              39
#define  Pragma_Interrupt_Handler           40
#define  Pragma_Interrupt_Priority          41
#define  Pragma_Linker_Options              42
#define  Pragma_List                        43
#define  Pragma_Machine_Attribute           44
#define  Pragma_Memory_Size                 45
#define  Pragma_No_Return                   46
#define  Pragma_Optimize                    47
#define  Pragma_Pack                        48
#define  Pragma_Page                        49
#define  Pragma_Preelaborate                50
#define  Pragma_Priority                    51
#define  Pragma_Pure                        52
#define  Pragma_Remote_Call_Interface       53
#define  Pragma_Remote_Types                54
#define  Pragma_Share_Generic               55
#define  Pragma_Shared                      56
#define  Pragma_Shared_Passive              57
#define  Pragma_Source_Reference            58
#define  Pragma_Subtitle                    59
#define  Pragma_System_Name                 60
#define  Pragma_Task_Info                   61
#define  Pragma_Title                       62
#define  Pragma_Unchecked_Union             63
#define  Pragma_Unimplemented_Unit          64
#define  Pragma_Volatile                    65
#define  Pragma_Volatile_Components         66

/* The following are deliberately out of alphabetical order, see Snames */

#define  Pragma_Storage_Size                67
#define  Pragma_Storage_Unit                68

/* Define the numeric values for the conventions.  */

#define  Convention_Ada                      0
#define  Convention_Intrinsic                1
#define  Convention_Entry                    2
#define  Convention_Protected                3
#define  Convention_Assembler                4
#define  Convention_C                        5
#define  Convention_COBOL                    6
#define  Convention_CPP                      7
#define  Convention_Fortran                  8
#define  Convention_Stdcall                  9

/* End of a-snames.h (C version of Snames package spec) */
