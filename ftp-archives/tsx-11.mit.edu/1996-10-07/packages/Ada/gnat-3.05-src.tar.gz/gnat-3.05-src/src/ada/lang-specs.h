/****************************************************************************/
/*                                                                          */
/*                         GNAT COMPILER COMPONENTS                         */
/*                                                                          */
/*                            L A N G - S P E C S                           */
/*                                                                          */
/*                              C Header File                               */
/*                                                                          */
/*                            $Revision: 1.6 $                              */
/*                                                                          */
/*    Copyright (C) 1992, 1993, 1994, 1995 Free Software Foundation, Inc.   */
/*                                                                          */
/* GNAT is free software;  you can  redistribute it  and/or modify it under */
/* terms of the  GNU General Public License as published  by the Free Soft- */
/* ware  Foundation;  either version 2,  or (at your option) any later ver- */
/* sion.  GNAT is distributed in the hope that it will be useful, but WITH- */
/* OUT ANY WARRANTY;  without even the  implied warranty of MERCHANTABILITY */
/* or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License */
/* for  more details.  You should have  received  a copy of the GNU General */
/* Public License  distributed with GNAT;  see file COPYING.  If not, write */
/* to  the Free Software Foundation,  59 Temple Place - Suite 330,  Boston, */
/* MA 02111-1307, USA.                                                      */
/*                                                                          */
/* GNAT was originally developed  by the GNAT team at  New York University. */
/* It is now maintained by Ada Core Technologies Inc (http://www.gnat.com). */
/*                                                                          */
/****************************************************************************/

/* This is the contribution to the `default_compilers' array in gcc.c for
   GNAT.  */

  {".ads", "@ada"},
  {".adb", "@ada"},
  {".ada", "@ada"},
  {"@ada",
   "%{!M:%{!MM:%{!E:gnat1 %{I*} %{k8:-gnatk8} %{w:-gnatws} %{!Q:-quiet}\
			  -dumpbase %{.adb:%b.adb}%{.ads:%b.ads}\
				%{!.adb:%{!.ads:%b.ada}}\
			  %{g*} %{O*} %{W*} %{w} %{p} %{pg:-p} %{m*}\
			  %{a} %{f*} %{d*}\
			  %{pg:%{fomit-frame-pointer:%e-pg and -fomit-frame-pointer are incompatible}}\
			  %i %{S:%W{o*}%{!o*:-o %b.s}}%{!S:-o %{|!pipe:%g.s}} |\n\
		    %{!S:%{!gnatc:%{!gnatz:%{!gnats:as %a %Y\
					      %{c:%W{o*}%{!o*:-o %w%b%O}}\
					      %{!c:-o %d%w%u%O} %{!pipe:%g.s} %A\n}}}}}}} "},

#if 0
----------------------
-- REVISION HISTORY --
----------------------

----------------------------
revision 1.1
date: Sun May 14 10:14:32 1995;  author: kenner
Initial revision
----------------------------
revision 1.2
date: Thu Sep 21 13:48:17 1995;  author: kenner
Pass -m and -a to gnat1.
----------------------------
revision 1.3
date: Tue Nov 14 09:06:38 1995;  author: kenner
Always supply value for -dumpbase (allows gcc -x ada <filename> to work)
----------------------------
** New changes after this line and before endif. **
New header
Remove old junk revision history section
#endif

#if 0
----------------------
-- REVISION HISTORY --
----------------------

----------------------------
revision 1.3
date: 1995/11/14 14:06:38;  author: kenner;  state: Exp;  lines: +2 -1
Always supply value for -dumpbase (allows gcc -x ada <filename> to work)
----------------------------
revision 1.4
date: 1995/11/25 18:08:52;  author: dewar;  state: Exp;  lines: +19 -6
New header
Remove old junk revision history section
----------------------------
revision 1.5
date: 1995/11/25 18:39:35;  author: kenner;  state: Exp;  lines: +1 -0
Allow .ada to be recognized as Ada.
---------------------------------
** New changes after this line and before endif. **
Treat -gnatz like -gnatc.
#endif
