#include <stdio.h>
imported_function ()
{
  printf ("\nI am now in the imported function\n\n");
}
