#!/bin/sh
#  install.sh from ObjectProDSP 0.2
#  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
#  Licensed for free use and distribution under version 2 of the Gnu General
#  Public License. Please see file COPYING for details and restrictions.
#  
#  ObjectProDSP is a trademark of Mountain Math Software.
#  
. $OPD_ROOT/scripts/set_opt
OPD_HEAD=$OPD_ROOT/scripts/Makefile_head
cp $OPD_ROOT/scripts/Makefile_head_base $OPD_HEAD
echo "OPD_SHELL=$OPD_SHELL" >> $OPD_HEAD
echo "OPD_MAKE=$OPD_MAKE" >> $OPD_HEAD
