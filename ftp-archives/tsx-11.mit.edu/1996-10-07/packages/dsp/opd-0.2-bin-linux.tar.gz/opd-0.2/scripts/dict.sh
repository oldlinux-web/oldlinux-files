#!/bin/sh
#  dict.sh from ObjectProDSP 0.2
#  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
#  Licensed for free use and distribution under version 2 of the Gnu General
#  Public License. Please see file COPYING for details and restrictions.
#  
#  ObjectProDSP is a trademark of Mountain Math Software.
#  
#uncomment the `diction' line to check the diction of all interactive messages
#as part of make from '.usr' files and the menu file.
# append is used so the spelling and diction checkers output to the same file
# If you are only running diciton you should overwrite the old file
# diction $1 >> $2
exit 0
