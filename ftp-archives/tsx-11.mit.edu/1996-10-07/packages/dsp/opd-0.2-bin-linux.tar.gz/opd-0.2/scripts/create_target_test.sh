#!/bin/sh
#  create_target_test.sh from ObjectProDSP 0.2
#  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
#  Licensed for free use and distribution under version 2 of the Gnu General
#  Public License. Please see file COPYING for details and restrictions.
#  
#  ObjectProDSP is a trademark of Mountain Math Software.
#  
#
OPD_DIR=${1%/*}
OPD_COMMAND=${1##*/}
OPD_TEST_LOG=$2

OPD_INT16=${OPD_DIR%_int16}
OPD_FLOAT=${OPD_DIR%_float}

if [ "$OPD_INT16" != "$OPD_DIR" ] ;then
    if [ -n "$3" ] ;then if [ "$3" != "int16" ] ;then exit 0 ;fi ;fi
elif [ "$OPD_FLOAT" != "$OPD_DIR" ] ;then
    if [ -n "$3" ] ;then if [ "$3" != "float" ] ;then exit 0 ;fi ;fi
else
    echo "\`$OPD_DIR' has unknown arithmetic." \
        >> $OPD_TEST_LOG
    exit 1
fi


OPD_TAR_VAL_PARAM="-l $OPD_TEST_LOG"
echo "if ! pushd $OPD_DIR ;then exit 1; fi"
echo "if [ ! -d test_data ] ;then if ! ln -s \
	$OPD_ROOT/validate/test_data/interactive test_data ;then exit 1 ;fi ;fi"
echo "if ! echo \"Doing \\\`$1' in \\\`$OPD_DIR' at \`date\`.\" >> $OPD_TEST_LOG ;then exit 1 ;fi" 
echo "if ! $OPD_COMMAND ;then exit 1 ;fi ; popd"
echo "if ! echo \"Did \\\`$1' at \`date\`.\" >> $OPD_TEST_LOG ;then exit 1 ;fi"

