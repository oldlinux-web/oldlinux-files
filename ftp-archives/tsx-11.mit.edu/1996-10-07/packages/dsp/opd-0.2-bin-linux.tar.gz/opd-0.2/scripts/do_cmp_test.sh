#!/bin/sh
#  do_cmp_test.sh from ObjectProDSP 0.2
#  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
#  Licensed for free use and distribution under version 2 of the Gnu General
#  Public License. Please see file COPYING for details and restrictions.
#  
#  ObjectProDSP is a trademark of Mountain Math Software.
#  
# $1 is `.cmp' file, $2 is validation log, $3 is master create flag
if [ ! -z "$3" ] ;then if [ ! -e ${1}b ] ;then cp $1 ${1}b ;fi ;fi
if [ -e ${1}b ] ;then $OPD_ROOT/bin/compare_byte $1 $2 ;fi
