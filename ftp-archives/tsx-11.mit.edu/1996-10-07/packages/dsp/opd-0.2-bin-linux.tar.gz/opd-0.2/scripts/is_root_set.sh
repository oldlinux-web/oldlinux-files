#!/bin/sh
#  is_root_set.sh from ObjectProDSP 0.2
#  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
#  Licensed for free use and distribution under version 2 of the Gnu General
#  Public License. Please see file COPYING for details and restrictions.
#  
#  ObjectProDSP is a trademark of Mountain Math Software.
#  
if [ -z "$OPD_ROOT" ] ;then
    echo "OPD_ROOT is not set. It must be set to the root directory in which ObjectProDSP"
    echo "is installed. You can set it by going to that directory and entering:"
	echo ". set_root"
	echo "DO NOT DO THIS IN ANOTHER DIRECTORY. You must \`cd' to the installation root."
    exit
fi

