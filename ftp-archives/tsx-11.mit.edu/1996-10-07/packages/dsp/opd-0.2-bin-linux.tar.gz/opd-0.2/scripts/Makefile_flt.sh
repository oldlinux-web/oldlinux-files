#!/bin/sh
#  Makefile_flt.sh from ObjectProDSP 0.2
#  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
#  Licensed for free use and distribution under version 2 of the Gnu General
#  Public License. Please see file COPYING for details and restrictions.
#  
#  ObjectProDSP is a trademark of Mountain Math Software.
#  
#!/usr/local/bin/bash
# Modify makefiles needed to create makemake for the target system
# is invoked by the Makefile to be update in the directory containg the file
echo sed -e \'
echo s/\$OPD_CC/$OPD_CC/
echo s/\$OPD_RANLIB/$OPD_RANLIB/
echo s/\$OPD_SHELL/$OPD_SHELL/
echo s/\$OPD_MAKE/$OPD_MAKE/
echo s/\$OPD_OBJ/$OPD_OBJ/\'

