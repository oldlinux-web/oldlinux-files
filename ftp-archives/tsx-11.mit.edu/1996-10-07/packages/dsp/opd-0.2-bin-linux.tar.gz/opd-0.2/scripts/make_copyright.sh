#!/bin/sh
#  make_copyright.sh from ObjectProDSP 0.2
#  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
#  Licensed for free use and distribution under version 2 of the Gnu General
#  Public License. Please see file COPYING for details and restrictions.
#  
#  ObjectProDSP is a trademark of Mountain Math Software.
#  
for i in $* ;do 
	BASE=${i##/*/} 
	echo "static const char * $BASE[] = {" 
	awk '{ if ( $1 != "#") print "\t\"" $$0 "\","}' < $i 
	echo "  0" 
	echo "};" 
	echo 
	echo
done

