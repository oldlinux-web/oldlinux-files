#!/bin/sh
#  set_version.sh from ObjectProDSP 0.2
#  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
#  Licensed for free use and distribution under version 2 of the Gnu General
#  Public License. Please see file COPYING for details and restrictions.
#  
#  ObjectProDSP is a trademark of Mountain Math Software.
#  
OPD_VER_FILE=$OPD_ROOT/src/include/ObjProDSP/version.h
VERSION=`fgrep '#define OBJ_PRO_DSP_VERSION_NUM' $OPD_VER_FILE | \
awk '{ print $3 }'` 
if [ -z "$VERSION" ] ;then
	echo "Cannot get version from \`$OPD_VER_FILE'." ;
	exit
fi

