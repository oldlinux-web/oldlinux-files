#!/bin/sh
#  spell.sh from ObjectProDSP 0.2
#  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
#  Licensed for free use and distribution under version 2 of the Gnu General
#  Public License. Please see file COPYING for details and restrictions.
#  
#  ObjectProDSP is a trademark of Mountain Math Software.
#  
OPD_CHECK=				# to not check spelling
#OPD_CHECK=yes			# to check spelling
if [ -n "$OPD_CHECK" ] ;then
	echo "Change \`$OPD_ROOT/scripts/spell.sh' to not check spelling."
	echo "\`domenus' and \`.usr' file translation will run faster."
	ispell -l < $1 | sort | uniq > $2 ; cat $2
else 
	echo "Not checking spelling."
	echo "Change \`$OPD_ROOT/scripts/spell.sh' to check."
fi
