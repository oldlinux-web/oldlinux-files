/*
 *  unpack.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef UNPACK_DOT_H
#define UNPACK_DOT_H

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/procstr.h"

class UnpackWord: public ProcessNodeStr {
#line 71 "../unpack.usr"
 
	int32 Ratio ;
	uint32 Mask ;
	int16 sign_bit ;
	uint32 fill_ones ;
#ifdef INTERACTIVE
	virtual void input_linked(int in_channel)
		{propagate_arith_type(in_channel,-GetOutputWordSize()*
            GetOutputsPerInput());}
#endif
#line 31 "/dist/opd_2/opd-0.2/src/include/ObjProDSPint/ObjProUsr/unpack.h"
	int16  OutputWordSize_1;
	int16  OutputsPerInput_2;
	int16  SignedOutput_3;
public:
	UnpackWord (const char * Name, int16 OutputWordSize, int16 OutputsPerInput, 
		int16 SignedOutput);
	virtual ~UnpackWord();
	int16 GetOutputWordSize() const {return OutputWordSize_1;}
	int16 GetOutputsPerInput() const {return OutputsPerInput_2;}
	int16 GetSignedOutput() const {return SignedOutput_3;}
	virtual int CheckSafeDelete() ;
	virtual ErrCode DoNode(int32);
	void Describe(OutTokens& Out, ListEntity Option);
	virtual int CppList(OutTokens& Out, CppListCmds Cmd);
};

extern UnpackWord * UnpackWordDef;


#endif /* #ifdef UNPACK_DOT_H */
