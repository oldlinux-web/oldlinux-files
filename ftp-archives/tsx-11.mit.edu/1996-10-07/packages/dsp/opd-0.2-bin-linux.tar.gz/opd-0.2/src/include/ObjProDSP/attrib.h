/*
 *  attrib.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  attrib.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
// Line types
#ifndef ATTRIB_DOT_H
#define ATTRIB_DOT_H
const UserLineType =		0 ;
const SolidLine = 		1 ;
const LongDashed =		2 ;
const Dotted =			3 ;
const DashDotted =		4 ;
const MediumDashed =		5 ;
const DashedWithTwoDots =	6 ;
const ShortDashed =		7 ;
	

// Color indicies
const Black =			0 ;
const White =			1 ;
const Red =			2 ;
const Green =			3 ;
const Blue =			4 ;
const Yellow =			5 ;
const Cyan =			6 ;
const Magenta =			7 ;
const Gray =			8 ;
const LightGray =		9 ;
const LightRed =		10 ;
const LightGreen = 		11 ;
const LightBlue =		12 ;
const Brown =			13 ;
const LightCyan =		14 ;
const LightMagneta =		15 ;


// Fill interior styles
const Hollow =			0 ;
const SolidInterior =		1 ;
const Pattern =			2 ;
const Hatch =			3 ;
const BitMap = 			4 ;


// Background modes (see base 3-201)
const Opaque =			0 ;
const Transparent =		1 ;

// Marker types (see base 3-262)
const MarkerDot =		1 ;
const MarkerPlus =		2 ;
const MarkerStar =		3 ;
const MarkerSquare =		4 ;
const MarkerX =			5 ;
const MarkerDiamond = 		6 ;

#endif /* #ifdef ATTRIB_DOT_H */
