/*
 *  strct_ctr.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#include "ObjProComGui/net_nd_undef.h"
#define const_char(obj) ix++ ;
#define const_char_list(obj) ix++ ;
#define int_value(obj) ix++ ;
#define int_list(obj) ix++ ;

	int ix = 0 ;
	all_of_the_members

#include "ObjProComGui/net_nd_undef.h"
#define const_char(obj) elts[ix++]=GenericArrayElement(obj);
#define int_value(obj) elts[ix++]=GenericArrayElement(obj);
#define const_char_list(obj) elts[ix++]= GenericArrayElement(obj);
#define int_list(obj) elts[ix++]=GenericArrayElement(obj);

	GenericArrayElement * elts = new GenericArrayElement[ix+1] ;
	ix = 0 ;
	all_of_the_members
	elts[ix++] = GenericArrayElement() ;
	elts[ix]= 0 ;
	return elts ;

#undef all_of_the_members
#include "ObjProComGui/net_nd_undef.h"


