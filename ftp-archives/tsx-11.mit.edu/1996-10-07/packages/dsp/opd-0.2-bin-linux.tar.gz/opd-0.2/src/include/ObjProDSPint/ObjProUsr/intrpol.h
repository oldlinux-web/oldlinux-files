/*
 *  intrpol.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef INTRPOL_DOT_H
#define INTRPOL_DOT_H
#include "ObjProArith/hrdarth.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/procstr.h"

class Interpolate: public ProcessNodeStr {
#line 36 "../intrpol.usr"
 
	double FractionFromLastSample ;
	MachWord * LastInputSample ;
	MachWord * NextInputSample ;
	int OutputIndex ;
	double InputDivOutput ;
	int InputHighIndex ;
	int32 ElementSize ;
	int UpdateInput(int Needed);
	int32 input_sample_index ;
	int32 output_sample_index ;
	ErrCode kernel(int32 k);
	void ctor();
	void dtor();
#line 36 "/dist/opd_2/opd-0.2/src/include/ObjProDSPint/ObjProUsr/intrpol.h"
	int16  DeltaIn_1;
	int16  DeltaOut_2;
public:
	Interpolate (const char * Name, int16 DeltaIn, int16 DeltaOut);
	virtual ~Interpolate();
	int16 GetDeltaIn() const {return DeltaIn_1;}
	int16 GetDeltaOut() const {return DeltaOut_2;}
	virtual int CheckSafeDelete() ;
	virtual ErrCode DoNode(int32);
	void Describe(OutTokens& Out, ListEntity Option);
	virtual int CppList(OutTokens& Out, CppListCmds Cmd);
};

extern Interpolate * InterpolateDef;


#endif /* #ifdef INTRPOL_DOT_H */
