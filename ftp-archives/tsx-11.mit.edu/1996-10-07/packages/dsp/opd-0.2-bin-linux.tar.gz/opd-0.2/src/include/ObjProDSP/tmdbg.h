/*
 *  tmdbg.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#define BASE_DEBUG(prefix,suffix) \
		prefix DEBUGNodeIndex suffix \
		prefix DEBUGNodeCount suffix \
		prefix DEBUGNetworkType suffix \
		prefix DEBUGTrainingState suffix \
		prefix DEBUGDeltaIn suffix \
		prefix DEBUGDeltaOut suffix \
		prefix DEBUGCheckState suffix

BASE_DEBUG(extern int,;) 

#define BASE_DEBUG_BLOCK(a,b) {BASE_DEBUG(a,b)}

#define DECLARE_DEBUG BASE_DEBUG(int,;)
#define CLEAR_DEBUG BASE_DEBUG_BLOCK(, =0 ;)

extern "C" {
	void DEBUGCheckStart();
	void DEBUGCheckEnd();
	void DEBUGChangeNetworkType(int type);
	void DEBUGHighSpeedOnly();
	void DEBUGNetwork0();
	void DEBUGNetwork1();
	void DEBUGNetwork2();
	void DEBUGNetwork3();
};


