/*
 *  usercom.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  usercom.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef USERCOM_DOT_H
#define USERCOM_DOT_H
#include "ObjProGen/usriotyp.h"

class ostream ;
class OutCon {
	class BasicIO * Basic ;
	int AppendFlag ;
public:
	void SetRedirect(RedirectSwitch) ;
	OutCon (RedirectSwitch sw, int append_flag=0) ;
	ostream& GetStream(int) ;
	void SetWindow(int TheType) ;
	void AddWindow(int NewWindowIndex);
	int GetOutputType() ;

	ostream& operator++(); 
	ostream& operator+(int TheType) ;
	ostream& operator<<(const char* Str);
	ostream& operator<<(int a);
	ostream& operator<<(long n);
	ostream& operator<<(double d);
	void Flush();
};

extern OutCon * Output ;
extern OutCon * OutputAppend ;

#define OutWin (OutputToWindow())

ostream& OutputToWindow(int Win=0);

#define HelpOut *Output + OutputHelp
#define PromptOut *Output + OutputPrompt
#define CppOut *Output + OutputCppHelp
#define OutputCurrentChannel *Output

#endif /* #ifdef USERCOM_DOT_H */
