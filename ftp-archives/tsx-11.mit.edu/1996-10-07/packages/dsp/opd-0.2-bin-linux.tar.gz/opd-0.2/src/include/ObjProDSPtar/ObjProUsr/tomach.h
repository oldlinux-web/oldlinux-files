/*
 *  tomach.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef TOMACH_DOT_H
#define TOMACH_DOT_H
#define __DSP_PP_TARGET_CODE__

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class ToMach: public TargetNode {
#line 32 "../tomach.usr"
 
#line 22 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/tomach.h"
	int16  SignedConversion_1;
public:
	ToMach (const char * Name, int16 SignedConversion,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay);
	virtual ~ToMach();
	int16 GetSignedConversion() const {return SignedConversion_1;}
	virtual ErrCode DoNode(int32);
};


#endif /* #ifdef TOMACH_DOT_H */
