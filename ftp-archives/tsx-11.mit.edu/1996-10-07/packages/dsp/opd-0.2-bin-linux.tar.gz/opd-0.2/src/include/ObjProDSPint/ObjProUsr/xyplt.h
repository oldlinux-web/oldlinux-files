/*
 *  xyplt.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef XYPLT_DOT_H
#define XYPLT_DOT_H
#include "ObjProArith/hrdarth.h"
#include "ObjProUsr/genplot.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/gpltstr.h"

class EyePlot: public GenericPlotStr {
#line 41 "../xyplt.usr"
 
	virtual DfNode * target_replacement(const char * target);
#line 25 "/dist/opd_2/opd-0.2/src/include/ObjProDSPint/ObjProUsr/xyplt.h"
	double  SamplesPerPlot_1;
	const char *  Caption_2;
public:
	EyePlot (const char * Name, double SamplesPerPlot, const char * Caption);
	virtual ~EyePlot();
	double GetSamplesPerPlot() const {return SamplesPerPlot_1;}
	const char * GetCaption() const {return Caption_2;}
	virtual int CheckSafeDelete() ;
	virtual ErrCode DoNode(int32);
	void Describe(OutTokens& Out, ListEntity Option);
	virtual int CppList(OutTokens& Out, CppListCmds Cmd);
	virtual double TimeFirst(DfNodeInLink *,DfNodeOutLink *);
};

extern EyePlot * EyePlotDef;


#endif /* #ifdef XYPLT_DOT_H */
