/*
 *  mousret.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  mousret.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef MOUSRET_DOT_H
#define MOUSRET_DOT_H

enum MouseReturn { MouseNotInWindow, MouseNoActionDefined, MouseDidAction,
	MouseChangeWindowSize, MouseChangeWindowScale} ;

enum MouseButtonMotion {MouseButtonDown, MouseButtonUp, MouseButtonAction} ;

#endif /* #ifdef MOUSRET_DOT_H */
