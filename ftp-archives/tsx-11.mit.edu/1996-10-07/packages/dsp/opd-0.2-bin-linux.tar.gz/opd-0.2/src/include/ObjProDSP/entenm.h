/*
 *  entenm.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  entenm.h   */
/*  Copyright 1990 Mountain Math Software  */
/*  All Rights Reserved                    */

#ifndef ENTENM_DOT_H
#define ENTENM_DOT_H

enum NameInUse {InUseNo,InUseEntity,InUseEntityType,InUseEntityBaseType,
	InUseBasic,InUseBasicType,InUseAliasType,InUseCReserved};

enum EntityReq {EntityReqCreate, EntityReqDelete, EntityReqDisplay,
	EntityReqDescribe, EntityReqDescribeFull} ;

enum ListEntity {ListSingleEntity, ListEntityMembers, ListEntityClasses,
	ListGlobalClasses, ListSetParameterValues} ;

enum CppListCmds {CppListCtor, CppListTargetCtor, CppListState,
	CppListTargetState, CppClearDecFlag};

enum InteractiveType{InteractiveNode, InteractiveSignal, InteractiveDisplay,
	InteractiveCmpdNode, InteractiveNet,
	InteractiveBuffer, InteractiveScheduler, InteractiveProcedure,
	InteractiveMiscellaneous,
				  // all new entities are added here
				  // the old groups are still used but
				  // are not needed given the existing
				  // general class hierarchy structure.
	InteractiveTypeEnd};

enum CheckAction {CheckActionCheck,CheckActionDescribe};

#endif /* #ifdef ENTENM_DOT_H */
