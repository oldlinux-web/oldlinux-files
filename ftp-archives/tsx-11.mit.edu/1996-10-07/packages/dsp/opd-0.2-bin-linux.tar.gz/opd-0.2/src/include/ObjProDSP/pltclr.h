/*
 *  pltclr.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  pltclr.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
static int ColorTable[] = {
	White,Yellow,Magenta,Cyan,Black,Green,Red-1} ;

static int LineTypeTable[] = {
	SolidLine, ShortDashed, DashedWithTwoDots, DashDotted, MediumDashed,
	Dotted, LongDashed, -1} ;

