/*
 *  yacoper.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  yacoper.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
char * MakeCompoundName(const char * Base, const char * a1 =0,
	const char * a2 =0, const char * a3 = 0, const char * a4 =0) ;
char * MakeOperatorString(int Operator) ;

char * MakeOperatorName(int Operator) ;
char * MakeOperatorName(const char *) ;
char * MakeOperatorName(const char *, const char *) ;

char * GetOperatorName(const char * OperatorString) ;
char * GetOperatorName(int Oper) ;

