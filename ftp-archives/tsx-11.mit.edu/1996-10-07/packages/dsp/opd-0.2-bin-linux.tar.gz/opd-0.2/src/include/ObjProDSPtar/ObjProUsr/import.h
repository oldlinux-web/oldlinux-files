/*
 *  import.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef IMPORT_DOT_H
#define IMPORT_DOT_H
#define __DSP_PP_TARGET_CODE__
#include "ObjProArith/hrdarth.h"
#include "ObjProDSPcom/inascii.h"
#include "ObjProDSP/entenm.h"
#include "ObjProDSPcom/nt_import.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class ImportData: public TargetNode {
#line 140 "../import.usr"
 
	int WriteBinaryFlag ;
	AsciiInputFile * TheInputFile ;
	const char * TheFormat ;
	int scaled_mach_word;
	int use_unsigned ;
	MachWord * TheRepeatedData ;
	int TheRepeatIndex ;
	int TheRepeatLimit ;
	int MaxRepeat ;
	void ctor();
	void dtor();
	ErrCode kernel(int32 k);
#line 38 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/import.h"
	const char *  FileName_1;
	const char *  Format_2;
	int16  Fields_3;
	int16  RepeatFlag_4;
	int32 *  SkipFields_5;
	int32 SkipFields_Length_6;
	int32 *  SkipColumns_7;
	int32 SkipColumns_Length_8;
public:
	ImportData (const char * Name, const char * FileName, const char * Format, 
		int16 Fields, int16 RepeatFlag, int32 * SkipFields, 
		int32 SkipFields_Length, int32 * SkipColumns, 
		int32 SkipColumns_Length,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay);
	virtual ~ImportData();
	const char * GetFileName() const {return FileName_1;}
	const char * GetFormat() const {return Format_2;}
	int16 GetFields() const {return Fields_3;}
	int16 GetRepeatFlag() const {return RepeatFlag_4;}
	int32 * GetSkipFields() const {return SkipFields_5;}
	int32 GetSkipFields_Length() const {return SkipFields_Length_6;}
	int32 * GetSkipColumns() const {return SkipColumns_7;}
	int32 GetSkipColumns_Length() const {return SkipColumns_Length_8;}
	virtual ErrCode DoNode(int32);
#line 155 "../import.usr"
	static int is_increasing(CheckAction TheAction,OneParameter * param);
	static int check_format(CheckAction TheAction,OneParameter * param);
#line 68 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/import.h"
};

extern ImportData * ImportDataDef;

	extern int32 TheDataForImportDataSkipFieldsDefaultArray[];

	extern int32 TheDataForImportDataSkipColumnsDefaultArray[];


#endif /* #ifdef IMPORT_DOT_H */
