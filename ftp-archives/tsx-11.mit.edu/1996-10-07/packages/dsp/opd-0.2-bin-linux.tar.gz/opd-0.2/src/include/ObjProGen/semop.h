/*
 *  semop.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef SEMOP_DOT_H
#define SEMOP_DOT_H
/*  semop.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */


union semun {
	int val;
	struct semid_ds * buf;
	ushort * array;
};
extern "C" {
	int semctl (int, int, int, semun);
	//	int semctl (int semid, int semnum,int cmd,semun arg);

	int semget(key_t, int, int);
	//	int semget(key_t key, int nsems, int semflg);

	int semop(int, struct sembuf *, int);
	//	int semop(int semid, struct sembuf * sops, int nsops);
}


#endif /* #ifdef SEMOP_DOT_H */
