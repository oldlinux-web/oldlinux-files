/*
 *  tarmac.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  tarmac.h   */
/*  Copyright 1991 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef TARMAC_DOT_H
#define TARMAC_DOT_H
#define IN_C(command) ;
#define OUT_C(command) ;
#define IN_CX(command) ;
#define OUT_CX(command) ;
#endif /* #ifdef TARMAC_DOT_H */
