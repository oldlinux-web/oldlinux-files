/*
 *  tarsysx.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
	TargetDescription ToMake ;
	Network ** TheParallelNets ;
	class TargetSystemGroup ** TheGroups ;
	int GroupAlreadyUsed(const char * GroupName) const ;
	int AlreadyUsed(Network&Check) const ;
	int MakeSystemInterface() ;
	ofstream * TheSystemFile ;
	int EnumCount ;
	void StartEnum(const char *EnumName) ;
	void EndEnum(const char* EnumPrefix) ;
	void OutputIncludes(ofstream& TheSystemFile) ;
	void OutputGroupTables() ;
	void TargetAbort() ;
	int OutputDriver() ;
	int CountNets() const ;
public:
	int ChangeNetwork(class ProcessNet&, const char *);
	void InitArithType(ArithType::ArithTypes type);
	

