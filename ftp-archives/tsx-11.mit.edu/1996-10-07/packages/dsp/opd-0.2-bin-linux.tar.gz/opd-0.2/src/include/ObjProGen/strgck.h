/*
 *  strgck.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  strgck.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
// Objects for checking lists or arrays of strings
#ifndef STRCK_DOT_H
#define STRCK_DOT_H
#include "ObjProDSP/portable.h"

typedef const char * (*GetIndexedString) (int) ;

class DuplicateStringCheck {
	int32 StringToCheck ;
	int32 CurrentCheck ;
	int32 LimitIndex ;
	GetIndexedString GetString ;
public:
	DuplicateStringCheck (GetIndexedString GetIS, int Lim) {
		StringToCheck = 0 ;
		CurrentCheck=1; LimitIndex=Lim; GetString=GetIS;}
	const char * Ck() ;
} ;
int ConstIsInList(const char * ,class ConstStringList *);
int IsInList(const char * ,class StringList *);
#endif
