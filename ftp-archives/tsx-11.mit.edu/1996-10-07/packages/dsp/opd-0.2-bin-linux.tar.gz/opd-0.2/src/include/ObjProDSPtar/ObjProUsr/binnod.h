/*
 *  binnod.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef BINNOD_DOT_H
#define BINNOD_DOT_H
#define __DSP_PP_TARGET_CODE__
#include "ObjProArith/hrdarth.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class BinaryOutNode: public TargetNode {
#line 45 "../binnod.usr"
 
	class BinaryOutputFile * TheOutputFile ;
#line 24 "/home/paul/opd_root/src/include/ObjProDSPtar/ObjProUsr/binnod.h"
	int  TheFile;
	int  DeleteName;
	int16  Channels_1;
	int16  ElementSize_2;
	int16  WordSize_3;
	const char *  FileName_4;
public:
	BinaryOutNode (const char * Name, int16 Channels, int16 ElementSize, 
		int16 WordSize, const char * FileName,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay);
	virtual ~BinaryOutNode();
	int16 GetChannels() const {return Channels_1;}
	int16 GetElementSize() const {return ElementSize_2;}
	int16 GetWordSize() const {return WordSize_3;}
	const char * GetFileName() const {return FileName_4;}
	int GetTheFile() const { return TheFile;}
	int GetDeleteName() const { return DeleteName;}
	virtual ErrCode DoNode(int32);
	virtual double TimeFirst(DfNodeInLink *,DfNodeOutLink *);
};


#endif /* #ifdef BINNOD_DOT_H */
