/*
 *  stack.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  stack.h   */
/*  Copyright 1990 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef STACK_DOT_H
#define STACK_DOT_H
class Stack {
	int * Values ;
	int ArraySize ;
	int StackSize ;
	int ForceTrueFlag ;
public:
	Stack(int InitialSize = 10);
	void Push(int Value);
	int Pop() ;
	void PopAll() {StackSize=0;ForceTrueFlag=0;}
	int Read (int IndexFromTop=0) const ;
	int ReadSize() const {return StackSize;} 
	int IfTop() const ;
	void ForceTrue() {ForceTrueFlag=1;}
	void Negate();
} ;


#endif /* #ifdef STACK_DOT_H */
