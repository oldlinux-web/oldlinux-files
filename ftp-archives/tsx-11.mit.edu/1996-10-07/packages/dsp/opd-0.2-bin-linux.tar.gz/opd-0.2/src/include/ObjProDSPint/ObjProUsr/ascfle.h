/*
 *  ascfle.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef ASCFLE_DOT_H
#define ASCFLE_DOT_H

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/dsplstr.h"

class AsciiFile: public DisplayNodeStr {
#line 85 "../ascfle.usr"
 
	class ofstream * TheFile ;
    int HeaderOut ;
    int32 SampleSize ;
    int32 BlockSize ;
	char * exp_file_name ;
	char * delete_file_name ;
    void WriteHeader() ;
    void OpenFile();
#ifdef INTERACTIVE
	int InitAfterLinked(){return set_read_integer_flag(integer_read_flag) ;}
    virtual DfNode * target_replacement(const char * target);
#endif
	void Ctor();
	void Dtor();
	ErrCode Kernel(int32 k);
#line 37 "/dist/opd_2/opd-0.2/src/include/ObjProDSPint/ObjProUsr/ascfle.h"
	int integer_read_flag ;
	virtual ErrCode EmitStaticInit(OutTokens& Out);
	virtual ErrCode EmitStaticCtorParameters(OutTokens& Out);
	const char *  FileName_1;
	int16  Hex_2;
	int16  NoGroup_3;
	int16  NoHeader_4;
public:
	AsciiFile (const char * Name, const char * FileName, int16 Hex, 
		int16 NoGroup, int16 NoHeader);
	virtual ~AsciiFile();
	const char * GetFileName() const {return FileName_1;}
	int16 GetHex() const {return Hex_2;}
	int16 GetNoGroup() const {return NoGroup_3;}
	int16 GetNoHeader() const {return NoHeader_4;}
	virtual int CheckSafeDelete() ;
	virtual ErrCode DoNode(int32);
	void Describe(OutTokens& Out, ListEntity Option);
	virtual int CppList(OutTokens& Out, CppListCmds Cmd);
	virtual double TimeFirst(DfNodeInLink *,DfNodeOutLink *);
	void SetHex(int16  Hex) { Hex_2 = Hex; parameter_changed(); }
};

extern AsciiFile * AsciiFileDef;


#endif /* #ifdef ASCFLE_DOT_H */
