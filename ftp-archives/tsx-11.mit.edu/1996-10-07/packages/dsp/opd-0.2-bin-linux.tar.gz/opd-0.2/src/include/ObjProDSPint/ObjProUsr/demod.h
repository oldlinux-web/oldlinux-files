/*
 *  demod.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef DEMOD_DOT_H
#define DEMOD_DOT_H

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/procnode.h"

class Demod: public ProcessNode {
#line 69 "../demod.usr"
 
	int DemodFlag ;
	int32 DemodIndex ;
	complex DemodPhase ;
	complex DemodDeltaPhase ;
#line 26 "/dist/opd_2/opd-0.2/src/include/ObjProDSPint/ObjProUsr/demod.h"
	int16  DataType_1;
	double  DemodFreq_2;
public:
	Demod (const char * Name, int16 DataType, double DemodFreq);
	virtual ~Demod();
	int16 GetDataType() const {return DataType_1;}
	double GetDemodFreq() const {return DemodFreq_2;}
	virtual int CheckSafeDelete() ;
	virtual ErrCode DoNode(int32);
	void Describe(OutTokens& Out, ListEntity Option);
	virtual int CppList(OutTokens& Out, CppListCmds Cmd);
	void SetDemodFreq(double  DemodFreq) { DemodFreq_2 = DemodFreq; parameter_changed(); }
};

extern Demod * DemodDef;


#endif /* #ifdef DEMOD_DOT_H */
