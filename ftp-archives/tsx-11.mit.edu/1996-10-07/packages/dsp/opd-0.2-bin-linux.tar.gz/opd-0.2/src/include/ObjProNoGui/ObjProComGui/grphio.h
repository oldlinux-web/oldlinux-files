/*
 *  grphio.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  grphio.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
// dummy graphics interface file for case when no graphics interface
// is present.
// None of these routines should ever be called
#include "ObjProDSP/mousret.h"
inline char * GetGraphicsRawBufLine(int){return 0;}
inline void GraphicsReturnToContinue(int){}
inline MouseReturn DoGraphicsMenu( class Menu *) {return MouseNotInWindow;}
const GraphicsMode = 0;
inline int WindowWrite(int,char) {return GraphicsMode;}
#include "ObjProGen/usriotyp.h"
void GraphicsReturnToContinue(OutputType) ;
int GraphicsReturnOrQuit(OutputType) ;


