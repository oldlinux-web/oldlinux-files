/*
 *  sysconst.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  sysconst.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef SYSCONST_DOT_H
#define SYSCONST_DOT_H
const MaxNameSize = 64 ;
const OpenFileMode = 0600 ;
#define CPP_SUFFIX ".cxx" 
/*
 * #ifndef __NT_VC__
 * #define OBJ_SUFFIX "o" 
 * #else
 * #define OBJ_SUFFIX "obj" 
 * #endif
 */
#define OBJ_SUFFIX "${OPD_OBJ}"

#endif /* #ifdef SYSCONST_DOT_H */
