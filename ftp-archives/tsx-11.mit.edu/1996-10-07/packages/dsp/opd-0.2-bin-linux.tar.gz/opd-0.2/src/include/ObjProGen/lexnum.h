/*
 *  lexnum.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  lexnum.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include "ObjProDSP/portable.h"

/*
 *	This file must be C as well as C++ compatible.
 *	In C you can assume that C is `define'ed to NULL.
 */

int32 OctConvert(const char * ) ;
int32 IntConvert(const char * ) ;
int32 HexConvert(const char * ) ;
char * MakeString(const char * ) ;
char * MakeCString(const char * ) ;
char * MakeLitString(const char * ) ;
double FloatConvert(const char * ) ;

