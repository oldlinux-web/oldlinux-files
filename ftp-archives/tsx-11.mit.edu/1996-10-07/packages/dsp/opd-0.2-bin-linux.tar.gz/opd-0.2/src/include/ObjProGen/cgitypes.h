/*
 *  cgitypes.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  cgitypes.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
// This file contains the CGI data types as described in the
// CGI C language reference guide
#ifndef CGITYPES_DOT_H
#define CGITYPES_DOT_H

#include "ObjProDSP/portable.h"

typedef uint8 BOOLEAN ;

typedef int16 SINT16 ;

typedef int8 CHAR ;

typedef int32 SINT32 ;

typedef uint8 BIT8 ;

typedef uint16 BIT16 ;

typedef uint32 BIT32 ;

typedef uint16 FD ;
#endif /* #ifdef CGITYPES_DOT_H */
