/*
 *  fde1.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef FDE1_DOT_H
#define FDE1_DOT_H
#define __DSP_PP_TARGET_CODE__
#include "ObjProDSP/fde1sim.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class ZFde1: public TargetNode {
#line 98 "../fde1.usr"
 
	Fde1Sim * sim ;
	virtual void parameter_changed() {if (sim) sim->parameter_changed();}
	ErrCode state;
#line 26 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/fde1.h"
	double  Factor_1;
	int32  Interval_2;
	int32  MaxSize_3;
	int32 *  Time0_4;
	int32 Time0_Length_5;
	int32 *  Time1_6;
	int32 Time1_Length_7;
	int32  DoubMaxSteps_8;
	int32  DiscrScheme_9;
public:
	ZFde1 (const char * Name, double Factor, int32 Interval, int32 MaxSize, 
		int32 * Time0, int32 Time0_Length, int32 * Time1, 
		int32 Time1_Length, int32 DoubMaxSteps, int32 DiscrScheme,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay);
	virtual ~ZFde1();
	double GetFactor() const {return Factor_1;}
	int32 GetInterval() const {return Interval_2;}
	int32 GetMaxSize() const {return MaxSize_3;}
	int32 * GetTime0() const {return Time0_4;}
	int32 GetTime0_Length() const {return Time0_Length_5;}
	int32 * GetTime1() const {return Time1_6;}
	int32 GetTime1_Length() const {return Time1_Length_7;}
	int32 GetDoubMaxSteps() const {return DoubMaxSteps_8;}
	int32 GetDiscrScheme() const {return DiscrScheme_9;}
	virtual ErrCode DoNode(int32);
	void SetInterval(int32  Interval) { Interval_2 = Interval; parameter_changed(); }
	void SetDoubMaxSteps(int32  DoubMaxSteps) { DoubMaxSteps_8 = DoubMaxSteps; parameter_changed(); }
	void SetDiscrScheme(int32  DiscrScheme) { DiscrScheme_9 = DiscrScheme; parameter_changed(); }
};

	extern int32 TheDataForZFde1Time0DefaultArray[];

	extern int32 TheDataForZFde1Time1DefaultArray[];


#endif /* #ifdef FDE1_DOT_H */
