/*
 *  dosname.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
char * ToDosName(const char * UnixName,int CppName=0) ;
inline char * ToDosCppName(const char * UnixName)
	{return ToDosName(UnixName,1);}
char * ToCppName(const char * String) ;
char * TruncateToLength(char * Name, int Length);
char * TruncateToDosPrefix(char * Name,int SaveLast=0);

const MaxDosPrefix = 8 ;

