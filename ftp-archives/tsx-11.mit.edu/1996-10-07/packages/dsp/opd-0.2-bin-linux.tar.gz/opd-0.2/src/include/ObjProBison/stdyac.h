/*
 *  stdyac.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  stdyac.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */

#ifndef STDYAC_DOT_H
#define STDYAC_DOT_H

#include "ObjProGen/stdyc.h"
#include "ObjProBison/input.h"

/*
 *	 This is the standard C++ header for yacc
 *	 it and stdyac.c should be usable for any lex/yacc application
 *	 Only the `stdio.h' include file needs to be changed to
 *	 get the correct semantic header interface
 */

/*
 *	This file must be C as well as C++ compatible.
 *	In C you can assume that C is `define'ed to NULL.
 */

extern const char * CurrentFileName ;

void OutWhereC() ;
void OutWhereEndC();

extern int LineNumber ;


void IllegalChar(char) ;

const char * MakeName(const char *);
const char * MakeWordString(const char *);

int ParseMain() ;
void Found(const char *);

extern int (*EndOfFileFound)();

#endif /* #ifdef STDYAC_DOT_H */
