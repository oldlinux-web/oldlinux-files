/*
 *  dspcom.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  dspcom.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
extern void DspMain();
void CheckReadAndSleep() ;

