/*
 *  tomach.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef TOMACH_DOT_H
#define TOMACH_DOT_H

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/procstr.h"

class ToMach: public ProcessNodeStr {
#line 32 "../tomach.usr"
 
#line 22 "/dist/opd_2/opd-0.2/src/include/ObjProDSPint/ObjProUsr/tomach.h"
	int16  SignedConversion_1;
public:
	ToMach (const char * Name, int16 SignedConversion);
	virtual ~ToMach();
	int16 GetSignedConversion() const {return SignedConversion_1;}
	virtual int CheckSafeDelete() ;
	virtual ErrCode DoNode(int32);
	void Describe(OutTokens& Out, ListEntity Option);
	virtual int CppList(OutTokens& Out, CppListCmds Cmd);
};


#endif /* #ifdef TOMACH_DOT_H */
