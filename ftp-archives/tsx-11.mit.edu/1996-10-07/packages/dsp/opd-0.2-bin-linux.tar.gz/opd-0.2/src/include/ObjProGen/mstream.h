/*
 *  mstream.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef MSTREAM_DOT_H
#define MSTREAM_DOT_H
#include <stream.h>

class istream {
public: 
	istream(int Size, char * Buf);
	~istream();
	operator>>(char * Buf);
};
#endif /* #ifdef MSTREAM_DOT_H */
