/*
 *  fde0.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef FDE0_DOT_H
#define FDE0_DOT_H

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/sigbase.h"

class ZFde0: public Signal {
#line 40 "../fde0.usr"
 
	int32 an;
	int32 anm1 ;
	double ean ;
	double eanm1 ;
	double factor ;
	ErrCode state ;
#line 28 "/dist/opd_2/opd-0.2/src/include/ObjProDSPint/ObjProUsr/fde0.h"
	int32  Time0_1;
	int32  Time1_2;
	double  Factor_3;
public:
	ZFde0 (const char * Name, int32 Time0, int32 Time1, double Factor);
	virtual ~ZFde0();
	int32 GetTime0() const {return Time0_1;}
	int32 GetTime1() const {return Time1_2;}
	double GetFactor() const {return Factor_3;}
	virtual int CheckSafeDelete() ;
	virtual ErrCode DoNode(int32);
	void Describe(OutTokens& Out, ListEntity Option);
	virtual int CppList(OutTokens& Out, CppListCmds Cmd);
};

extern ZFde0 * ZFde0Def;


#endif /* #ifdef FDE0_DOT_H */
