/*
 *  cgidbg.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  cgidbg.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */

#ifndef CGIDBG_DOT_H
#define CGIDBG_DOT_H
#include <stream.h>
#include "ObjProDSP/portable.h"
#include "ObjProGen/errcode.h"
#include "ObjProGen/debug.h"

extern void ExitAndCleanUp();

#define LogOut cerr
#define Output (&cerr)
#define TheLog LogOut


void SystemErrorMessage(int LastLineFeed = 1, char **ret=0) ;
void SetNewHandler();
void ExitOneWayOrAnother() ;


#endif /* #ifdef CGIDBG_DOT_H */
