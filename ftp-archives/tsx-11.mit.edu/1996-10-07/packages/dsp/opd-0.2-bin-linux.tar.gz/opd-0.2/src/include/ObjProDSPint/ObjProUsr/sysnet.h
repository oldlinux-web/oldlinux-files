/*
 *  sysnet.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef SYSNET_DOT_H
#define SYSNET_DOT_H
#include "ObjProDSP/portable.h"
#include "ObjProGui/basic.h"
#include "ObjProUsr/miscel.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/miscel.h"

class NetworkSystem: public Miscellaneous {
public:
	NetworkSystem (const char * Name);
	virtual ~NetworkSystem();
	virtual int CheckSafeDelete() ;
};


#endif /* #ifdef SYSNET_DOT_H */
