/*
 *  usriotyp.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  usriotyp.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef USRIOTYP_DOT_H
#define USRIOTYP_DOT_H
enum InputType {InputNotInitialized= -1,
	InputUndefined,InputHelp,InputMenu,InputPrompt,
	InputPlot,InputAcknowledge,InputCppEntry,
	InputCppHelp,InputInfo,InputEndOfInputTypes} ;

enum OutputType {OutputNotInitialized= -1,
	OutputUndefined,OutputHelp,OutputMenu,OutputPrompt,
	OutputPlot,OutputAcknowledge,OutputCppEntry,
	OutputCppHelp,OutputInfo,OutputEndOfOutputTypes} ;

enum RedirectSwitch {RedirectTerminal,RedirectCGI} ;


#endif /* #ifdef USRIOTYP_DOT_H */
