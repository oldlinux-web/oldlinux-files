/*
 *  editnet.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef EDITNET_DOT_H
#define EDITNET_DOT_H
class CppEnums {
	public:
	enum edit_network{created_node, create_network,
		created_network, statement_ok,statement_error,
		raise_window_containing_node,set_buffer_descriptor,
		delete_node, delete_network, delete_controller,
		add_unlinked_node_to_network,clear_active_net,
		buffer_descriptor_for_net,raise_network_window};
};

/********************
	Format for messages is: 
		message ID is eabove enum
		A. created node
			input links (16 bits)
			output links (16 bits)
			class name
			node name

		B. created netwrk
			controller name
			network name
*****************************/	
#endif /* #ifdef EDITNET_DOT_H */
