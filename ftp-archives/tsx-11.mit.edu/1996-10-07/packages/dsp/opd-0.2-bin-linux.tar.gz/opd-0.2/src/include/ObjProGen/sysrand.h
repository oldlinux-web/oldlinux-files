/*
 *  sysrand.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  sysrand.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
/* Prototypes for Xenix supplied random number generators
 *	definitions were edited from `man drand48' page.
 */

extern "C" {
	
	double drand48 ( ) ;
	
	double erand48 ( unsigned short xsubi[3]) ;
	 
	long lrand48 ( ) ;
	
	long nrand48 ( unsigned short xsubi[3]) ;
	 
	long mrand48 ( ) ;
	
	long jrand48 ( unsigned short xsubi[3]) ;
	 
	void srand48 ( long seedval) ;
	 
	unsigned short *seed48 ( unsigned short seed16v[3]) ;
	 
	void lcong48 ( unsigned short param[7]) ;
}
