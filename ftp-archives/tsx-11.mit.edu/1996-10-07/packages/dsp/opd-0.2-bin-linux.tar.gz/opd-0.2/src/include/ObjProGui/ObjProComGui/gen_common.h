/*
 *  gen_common.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#define const_char(obj) obj=elts(ix++).string ;
#define int_value(obj) obj=elts(ix++).val ;

#define const_char_list(obj) \
	const char ** lst = elts(ix++).list ; \
	int length = list_length(lst) ; \
	/* LogOut << "length= " << length << "\n" ; */  \
	if (!length) obj = (const char **) 0 ; \
	else { \
		obj = new const char * [length+1] ; \
		const char ** dest = obj ; \
		for (const char ** t = lst; *t; t++) *dest++ = *t ; \
		*dest = 0 ; \
	} 

#define int_list(obj) \
	int * int_lst = elts(ix++).int_list ; \
	int size = 0 ; \
	if (int_lst) for (int * t = int_lst; *t > -1;t++,size++); \
	if (!size) obj = (int *) 0 ; \
	else { \
		obj = new int [size+1] ; \
		for (int i = 0 ; i < size+1; i++) obj[i] = int_lst[i] ; \
	}


