/*
 *  compare.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef COMPARE_DOT_H
#define COMPARE_DOT_H
#define __DSP_PP_TARGET_CODE__
#include "ObjProArith/hrdarth.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class CompareDisk: public TargetNode {
#line 114 "../compare.usr"
 
	void FileInit() ;
	static class InputFile * TempInputFile ;
#ifdef INTERACTIVE
	int InitAfterLinked();
private:
	virtual TimingDescription * GetInitTiming(int Channel);
#endif
	void NoFileError();
	int Channels ;
	// int32 * ElementSize ;
	// int32 GetElementSize(int channel) {return ElementSize[channel];}
	int CompareValue(MachWord FileWord, MachWord InputWord);
	ErrCode CompareSamples(int32 k);
	class InputFile * TheInputFile ;
	double * SampleRateRatio ;
	double * CumulativeBlocks ;
	int32 compare_count;
	int ErrorCount ;
	int DisplayHandle ;
	int FirstTime ;
	int WindowId ;
	int BadNode ;
	double Diff ;
	double RelDiff ;
	double max_abs_diff ;
	double max_rel_diff ;
	class ofstream * out_file ;
	ErrCode kernel(int32 k);
	void dtor();
	void ctor();
#line 53 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/compare.h"
	int binary_read_flag ;
	const char *  FileName_1;
	int32  MaxReport_2;
	double  Tolerance_3;
	const char *  ErrorFile_4;
public:
	CompareDisk (const char * Name, const char * FileName, int32 MaxReport, 
		double Tolerance, const char * ErrorFile,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay,
		int CompareDiskStaticInitbinary_read_flag);
	virtual ~CompareDisk();
	const char * GetFileName() const {return FileName_1;}
	int32 GetMaxReport() const {return MaxReport_2;}
	double GetTolerance() const {return Tolerance_3;}
	const char * GetErrorFile() const {return ErrorFile_4;}
	virtual ErrCode DoNode(int32);
#line 146 "../compare.usr"
	virtual int window_id(){return WindowId;}
#line 74 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/compare.h"
};

extern CompareDisk * CompareDiskDef;


#endif /* #ifdef COMPARE_DOT_H */
