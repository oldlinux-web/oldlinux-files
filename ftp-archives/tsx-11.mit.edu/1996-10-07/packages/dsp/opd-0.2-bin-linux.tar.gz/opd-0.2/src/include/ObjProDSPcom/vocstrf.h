/*
 *  vocstrf.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  outbin.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include "ObjProArith/hrdarth.h"
#include "ObjProDSP/portable.h"
#include "ObjProGen/errcode.h"


class VoiceStripOutputFile {
	int TheFile ;
	const char * FileName ;
	const char * NodeName ;
	char * exp_file_name ;
	char * delete_file_name ;
public:
	VoiceStripOutputFile( const char * node_name, const char * FileName);
	~VoiceStripOutputFile();
	void Reset();
	ErrCode Write(MachWord Val) ;
	int CreateOK() {return TheFile > 0 ;}
	const char * GetFileName() const {return FileName;}
	void open(int force_error);
	const char * get_file_name() const {return FileName;}
};

