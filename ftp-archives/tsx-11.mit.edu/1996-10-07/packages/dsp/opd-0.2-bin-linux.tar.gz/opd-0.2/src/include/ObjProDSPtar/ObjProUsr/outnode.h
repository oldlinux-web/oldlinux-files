/*
 *  outnode.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef OUTNODE_DOT_H
#define OUTNODE_DOT_H
#define __DSP_PP_TARGET_CODE__
#include "ObjProArith/hrdarth.h"
#include "ObjProDSPcom/drvout.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class OutputNode: public TargetNode {
#line 110 "../outnode.usr"
 
#include "ObjProDSPcom/outndx.h"
#ifdef INTERACTIVE
void input_linked(int chan);
int InitAfterLinked();
int already_set ;
#endif
#line 30 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/outnode.h"
	int binary_read_flag ;
	const char *  FileName_1;
	int16  Flags_2;
	int16  Channels_3;
	int32  FileBlockSize_4;
	const char *  Caption_5;
	int32  DeltaIn_6;
public:
	OutputNode (const char * Name, const char * FileName, int16 Flags, 
		int16 Channels, int32 FileBlockSize, const char * Caption, 
		int32 DeltaIn,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay,
		int OutputNodeStaticInitbinary_read_flag);
	virtual ~OutputNode();
	const char * GetFileName() const {return FileName_1;}
	int16 GetFlags() const {return Flags_2;}
	int16 GetChannels() const {return Channels_3;}
	int32 GetFileBlockSize() const {return FileBlockSize_4;}
	const char * GetCaption() const {return Caption_5;}
	int32 GetDeltaIn() const {return DeltaIn_6;}
	virtual ErrCode DoNode(int32);
	virtual double TimeFirst(DfNodeInLink *,DfNodeOutLink *);
#line 118 "../outnode.usr"
	int read_binary();
#line 57 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/outnode.h"
};

extern OutputNode * OutputNodeDef;


#endif /* #ifdef OUTNODE_DOT_H */
