/*
 *  inword.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef INWORD_DOT_H
#define INWORD_DOT_H
#define __DSP_PP_TARGET_CODE__
#include "ObjProArith/hrdarth.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class InputWord: public TargetNode {
#line 97 "../inword.usr"
 
	class BinaryInputFile * file ;
	ErrCode node_state ;
	void ctor();
	void dtor();
	ErrCode kernel(int32 k);
#line 28 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/inword.h"
	int binary_read_flag ;
	const char *  FileName_1;
	int16  FormatIn_2;
	int16  IntegerOut_3;
	int32  InitialSkip_4;
	int16  ElementSize_5;
	int32  BlockSize_6;
public:
	InputWord (const char * Name, const char * FileName, int16 FormatIn, 
		int16 IntegerOut, int32 InitialSkip, int16 ElementSize, 
		int32 BlockSize,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay,
		int InputWordStaticInitbinary_read_flag);
	virtual ~InputWord();
	const char * GetFileName() const {return FileName_1;}
	int16 GetFormatIn() const {return FormatIn_2;}
	int16 GetIntegerOut() const {return IntegerOut_3;}
	int32 GetInitialSkip() const {return InitialSkip_4;}
	int16 GetElementSize() const {return ElementSize_5;}
	int32 GetBlockSize() const {return BlockSize_6;}
	virtual ErrCode DoNode(int32);
};

extern InputWord * InputWordDef;


#endif /* #ifdef INWORD_DOT_H */
