/*
 *  tarsysnet.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef TARSYSNET_DOT_H
#define TARSYSNET_DOT_H
#include <fstream.h>
#include "ObjProDSP/portable.h"
#include "ObjProGui/basic.h"
#include "ObjProUsr/net.h"
#include "ObjProGui/destrgt.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/netsys.h"

class TargetSystem: public NetworkSystem {
#line 202 "../tarsysnet.usr"
 
	const char * DoEmitState(OutTokens&);
	void Ctor() ;
#include "ObjProGui/tarsysx.h"
#line 30 "/home/paul/opd_root/src/include/ObjProDSPint/ObjProUsr/tarsysnet.h"
	const char *  InterfaceDirectory_1;
	const char *  Target_2;
	int32  Flags_3;
	int16  Channels_4;
	const char *  Directory_5;
	const char *  TargetName_6;
public:
	TargetSystem (const char * Name, const char * InterfaceDirectory, 
		const char * Target, int32 Flags, int16 Channels, 
		const char * Directory, const char * TargetName);
	virtual ~TargetSystem();
	const char * GetInterfaceDirectory() const {return InterfaceDirectory_1;}
	const char * GetTarget() const {return Target_2;}
	int32 GetFlags() const {return Flags_3;}
	int16 GetChannels() const {return Channels_4;}
	const char * GetDirectory() const {return Directory_5;}
	const char * GetTargetName() const {return TargetName_6;}
	virtual int CheckSafeDelete() ;
	void Describe(OutTokens& Out, ListEntity Option);
	virtual int CppList(OutTokens& Out, CppListCmds Cmd);
	virtual const char * EmitState(OutTokens& Out) ;
	void AddParallelNet (Network&TheNet);
	void MakeOneNetGroup (Network&TheNet);
	void MakeGroup (const char * GroupName);
	void AddToGroup (const char * GroupName, Network&TheNet);
	void Describe ();
	void MakeTarget ();
};


#endif /* #ifdef TARSYSNET_DOT_H */
