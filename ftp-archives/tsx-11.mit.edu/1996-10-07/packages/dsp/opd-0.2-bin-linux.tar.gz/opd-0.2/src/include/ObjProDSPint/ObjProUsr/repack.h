/*
 *  repack.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef REPACK_DOT_H
#define REPACK_DOT_H

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/procnode.h"

class RepackWord: public ProcessNode {
#line 34 "../repack.usr"
 
	int32 Ratio ;
	BinMachWord MaskIn ;
	BinMachWord Word ;
	int32 WordsOut ;
	int BitsLeftInWord ;
	BinMachWord GetNextOutWord();
#line 28 "/home/paul/opd_root/src/include/ObjProDSPint/ObjProUsr/repack.h"
	int16  OutputWordSize_1;
	int16  InputWordSize_2;
public:
	RepackWord (const char * Name, int16 OutputWordSize, int16 InputWordSize);
	virtual ~RepackWord();
	int16 GetOutputWordSize() const {return OutputWordSize_1;}
	int16 GetInputWordSize() const {return InputWordSize_2;}
	virtual int CheckSafeDelete() ;
	virtual ErrCode DoNode(int32);
	void Describe(OutTokens& Out, ListEntity Option);
	virtual int CppList(OutTokens& Out, CppListCmds Cmd);
};


#endif /* #ifdef REPACK_DOT_H */
