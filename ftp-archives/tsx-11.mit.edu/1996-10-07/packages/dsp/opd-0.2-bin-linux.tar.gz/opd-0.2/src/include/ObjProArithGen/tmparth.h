/*
 *  tmparth.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  tmparth.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
// This is a file to make temporary additions to the `hrdarth' files
// The three files this references should have their contents
// appended to the correct version of hrdarth.h enventually

#ifndef TMPARTH_DOT_H
#define TMPARTH_DOT_H
#include "ObjProArithGen/tmpglob.h"
extern const char * ArithTypeName ;
extern const char * ArithFormat ;
extern const char * ArithBinaryFormat ;

#endif /* #ifdef TMPARTH_DOT_H */
