/*
 *  helplev.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  helplev.h   */
/*  Copyright 1990 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef HELPLEV_DOT_H
#define HELPLEV_DOT_H
enum HelpLevel {HelpLevelNone, HelpLevelConfirm, HelpLevelAll} ;

#endif /* #ifdef HELPLEV_DOT_H */
