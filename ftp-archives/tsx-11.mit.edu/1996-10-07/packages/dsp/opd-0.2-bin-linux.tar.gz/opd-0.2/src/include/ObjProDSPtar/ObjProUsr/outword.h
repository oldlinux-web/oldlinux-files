/*
 *  outword.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef OUTWORD_DOT_H
#define OUTWORD_DOT_H
#define __DSP_PP_TARGET_CODE__
#include "ObjProArith/hrdarth.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class OutputWord: public TargetNode {
#line 43 "../outword.usr"
 
	class BinaryOutputFile * file ;
	ErrCode node_state ;
	void ctor();
	void dtor();
	ErrCode kernel(int32 k);
#ifdef INTERACTIVE
    int InitAfterLinked(){return set_read_binary_flag(integer_read_flag) ;}
#endif
#line 31 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/outword.h"
	int integer_read_flag ;
	const char *  FileName_1;
	int16  FormatOut_2;
public:
	OutputWord (const char * Name, const char * FileName, int16 FormatOut,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay,
		int OutputWordStaticInitinteger_read_flag);
	virtual ~OutputWord();
	const char * GetFileName() const {return FileName_1;}
	int16 GetFormatOut() const {return FormatOut_2;}
	virtual ErrCode DoNode(int32);
	virtual double TimeFirst(DfNodeInLink *,DfNodeOutLink *);
};

extern OutputWord * OutputWordDef;


#endif /* #ifdef OUTWORD_DOT_H */
