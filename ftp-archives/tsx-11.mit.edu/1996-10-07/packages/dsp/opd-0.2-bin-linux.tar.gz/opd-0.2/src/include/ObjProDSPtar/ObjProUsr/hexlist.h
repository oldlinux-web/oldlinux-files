/*
 *  hexlist.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef HEXLIST_DOT_H
#define HEXLIST_DOT_H
#define __DSP_PP_TARGET_CODE__
#include "ObjProArith/hrdarth.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class HexList: public TargetNode {
#line 77 "../hexlist.usr"
 
	uint32 * SavedBinaryWords ;
	int * NextBitToSet ;
	ErrCode BinaryKernel(int32 k);
	uint32 Mask ;
	int NumberBits ;
#ifdef INTERACTIVE
#endif
#line 30 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/hexlist.h"
	int  FirstTime;
	int  DisplayHandle;
	int  WindowId;
	int  Multi;
	int  MultiChan;
	int  Modulus;
	int  IndexOut;
	int32  Index;
	int16  Channels_1;
	const char *  Caption_2;
public:
	HexList (const char * Name, int16 Channels, const char * Caption,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay);
	virtual ~HexList();
	int16 GetChannels() const {return Channels_1;}
	const char * GetCaption() const {return Caption_2;}
	int GetFirstTime() const { return FirstTime;}
	int GetDisplayHandle() const { return DisplayHandle;}
	int GetWindowId() const { return WindowId;}
	int GetMulti() const { return Multi;}
	int GetMultiChan() const { return MultiChan;}
	int GetModulus() const { return Modulus;}
	int GetIndexOut() const { return IndexOut;}
	int32 GetIndex() const { return Index;}
	virtual ErrCode DoNode(int32);
	virtual double TimeFirst(DfNodeInLink *,DfNodeOutLink *);
#line 86 "../hexlist.usr"
	virtual int window_id(){return WindowId;}
#line 61 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/hexlist.h"
};

extern HexList * HexListDef;


#endif /* #ifdef HEXLIST_DOT_H */
