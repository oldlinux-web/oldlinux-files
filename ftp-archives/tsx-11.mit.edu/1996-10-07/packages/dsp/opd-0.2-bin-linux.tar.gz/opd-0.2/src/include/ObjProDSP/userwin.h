/*
 *  userwin.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  userwin.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef USERWIN_DOT_H
#define USERWIN_DOT_H
enum UserWindowOptions
	{UserWindowNotInitialized=-1,
		UserWindowMenu,UserWindowDialogue,UserWindowCpp,
		UserWindowError,UserWindowEnd} ;


// There is only one WindowManager and it is:
extern class WindowManager * TheWindowsManager ; 
extern int GraphicsMode ;


#endif /* #ifdef USERWIN_DOT_H */
