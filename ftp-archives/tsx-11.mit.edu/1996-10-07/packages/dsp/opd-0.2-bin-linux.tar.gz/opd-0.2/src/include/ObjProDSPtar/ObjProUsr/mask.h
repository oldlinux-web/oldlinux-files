/*
 *  mask.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef MASK_DOT_H
#define MASK_DOT_H
#define __DSP_PP_TARGET_CODE__

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class MaskWord: public TargetNode {
#line 36 "../mask.usr"
 
	uint32 TheMask ;
#line 23 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/mask.h"
	int32  Mask_1;
public:
	MaskWord (const char * Name, int32 Mask,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay);
	virtual ~MaskWord();
	int32 GetMask() const {return Mask_1;}
	virtual ErrCode DoNode(int32);
};

extern MaskWord * MaskWordDef;


#endif /* #ifdef MASK_DOT_H */
