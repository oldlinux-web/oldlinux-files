/*
 *  y.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

/*  /home/paul/opd_root/src/include/ObjProDSPtar/ObjProUsr/y.h   */
/*  Copyright 1991 Mountain Math Software  */
/*  All Rights Reserved                    */

#ifndef Y_DOT_H
#define Y_DOT_H
#define __DSP_PP_TARGET_CODE__

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
