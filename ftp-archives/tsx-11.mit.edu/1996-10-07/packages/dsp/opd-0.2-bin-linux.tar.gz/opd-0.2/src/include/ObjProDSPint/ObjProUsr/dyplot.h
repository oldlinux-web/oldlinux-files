/*
 *  dyplot.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef DYPLOT_DOT_H
#define DYPLOT_DOT_H
#include "ObjProArith/hrdarth.h"
#include "ObjProUsr/genplot.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/blkpltstr.h"

class Plot: public GenericBlockPlotStr {
#line 39 "../dyplot.usr"
 
	void CheckSetup() ;
	virtual DfNode * target_replacement(const char * target);
	int binary_read_flag ;
	int InitAfterLinked();
#line 28 "/dist/opd_2/opd-0.2/src/include/ObjProDSPint/ObjProUsr/dyplot.h"
	const char *  Caption_1;
public:
	Plot (const char * Name, const char * Caption);
	virtual ~Plot();
	const char * GetCaption() const {return Caption_1;}
	virtual int CheckSafeDelete() ;
	virtual ErrCode DoNode(int32);
	void Describe(OutTokens& Out, ListEntity Option);
	virtual int CppList(OutTokens& Out, CppListCmds Cmd);
	virtual double TimeFirst(DfNodeInLink *,DfNodeOutLink *);
};

extern Plot * PlotDef;


#endif /* #ifdef DYPLOT_DOT_H */
