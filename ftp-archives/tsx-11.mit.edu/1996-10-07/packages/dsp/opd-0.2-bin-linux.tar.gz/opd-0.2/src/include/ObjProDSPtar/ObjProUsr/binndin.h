/*
 *  binndin.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef BINNDIN_DOT_H
#define BINNDIN_DOT_H
#define __DSP_PP_TARGET_CODE__
#include "ObjProArith/hrdarth.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class BinInNode: public TargetNode {
#line 31 "../binndin.usr"
 
	class BinaryInputFile * TheInputFile ;
#line 24 "/home/paul/opd_root/src/include/ObjProDSPtar/ObjProUsr/binndin.h"
	const char *  FileName_1;
	int16  DataType_2;
public:
	BinInNode (const char * Name, const char * FileName, int16 DataType,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay);
	virtual ~BinInNode();
	const char * GetFileName() const {return FileName_1;}
	int16 GetDataType() const {return DataType_2;}
	virtual ErrCode DoNode(int32);
	virtual double TimeFirst(DfNodeInLink *,DfNodeOutLink *);
};

extern BinInNode * BinInNodeDef;


#endif /* #ifdef BINNDIN_DOT_H */
