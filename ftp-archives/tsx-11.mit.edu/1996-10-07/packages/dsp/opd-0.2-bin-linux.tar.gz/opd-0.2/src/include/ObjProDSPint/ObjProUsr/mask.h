/*
 *  mask.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef MASK_DOT_H
#define MASK_DOT_H

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/procstr.h"

class MaskWord: public ProcessNodeStr {
#line 36 "../mask.usr"
 
	uint32 TheMask ;
#line 23 "/dist/opd_2/opd-0.2/src/include/ObjProDSPint/ObjProUsr/mask.h"
	int32  Mask_1;
public:
	MaskWord (const char * Name, int32 Mask);
	virtual ~MaskWord();
	int32 GetMask() const {return Mask_1;}
	virtual int CheckSafeDelete() ;
	virtual ErrCode DoNode(int32);
	void Describe(OutTokens& Out, ListEntity Option);
	virtual int CppList(OutTokens& Out, CppListCmds Cmd);
};

extern MaskWord * MaskWordDef;


#endif /* #ifdef MASK_DOT_H */
