/*
 *  outndx.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifdef INTERACTIVE
	virtual DfNode * target_replacement(const char * target) ;
#endif
	class OutputFile * TheOutputFile ;
	void SetFileName(const char * Name) {FileName_1 = Name;}
	void FileInit() ;
	ErrCode TheKernel(int32 k);
	class NetworkReader * TheNetworkReader ;
	DriverOutputInterface TheReaderOutputInterface ;
	void Ctor() ;
	void Dtor() ;
public:
	ErrCode NodeReset() ;
	OutputFile * GetOutputFile() const {return TheOutputFile;}
	NetworkReader*GetNetworkReader()const{return TheNetworkReader;}
	void SetReaderInterface(DriverOutputInterface intfc,
		NetworkReader * drv=0)
		{TheReaderOutputInterface=intfc;
		TheNetworkReader=drv;}
private:

