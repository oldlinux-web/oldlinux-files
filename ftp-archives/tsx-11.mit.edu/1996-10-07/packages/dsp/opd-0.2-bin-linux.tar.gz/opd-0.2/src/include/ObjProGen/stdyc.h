/*
 *  stdyc.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef STDYC_DOT_H
#define STDYC_DOT_H
int yyback(int *, int) ;
extern "C" int yyparse(void) ;
// void yyoutput(int) ;
// void yyunput(int) ;
int yylex() ;
int yylook() ;

#ifndef __NT_VC__
extern "C" int yywrap();
#endif
void yyerror(const char * s0,const char * s1=0,const char *s2=0,
	const char * s3=0,const char *s4=0) ;
void YaccWarning(const char * s0,const char * s1=0,const char *s2=0,
	const char * s3=0,const char *s4=0) ;


#endif /* #ifdef STDYC_DOT_H */
