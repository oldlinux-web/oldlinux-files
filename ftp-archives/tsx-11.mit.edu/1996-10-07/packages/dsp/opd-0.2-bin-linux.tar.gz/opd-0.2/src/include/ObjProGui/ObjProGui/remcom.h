/*
 *  remcom.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef REMCOM_DOT_H
#define REMCOM_DOT_H
/*  remcom.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */

#include "ObjProGen/usriotyp.h"

extern class SharedSegment * ReadSeg ;
extern class SharedSegment * WriteSeg ;

extern int GraphicsStringAvailable[] ;
extern char * GraphicsString[] ;

extern int ComSetup ;

char * GetGraphicsBuf(InputType type, const char * Prompt,
	const char * P1=0, const char * P2=0,
	const char * P3=0, const char * P4=0) ;

inline int CheckForEvents() {return 1;}

#endif /* #ifdef REMCOM_DOT_H */
