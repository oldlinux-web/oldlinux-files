/*
 *  readflt.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef READFLT_DOT_H
#define READFLT_DOT_H
#define __DSP_PP_TARGET_CODE__
#include <fstream.h>
#include "ObjProArith/hrdarth.h"
#include "ObjProDSPcom/inascii.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class ReadFloat: public TargetNode {
#line 34 "../readflt.usr"
 
	void ctor();
	void dtor();
	void open_f(int force_error) ;
	ErrCode kernel(int32 k);
	ifstream * TheInputFile ;
	char * exp_name ;
	int DidCheck ;
	char * delete_name ;
#line 33 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/readflt.h"
	const char *  FileName_1;
public:
	ReadFloat (const char * Name, const char * FileName,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay);
	virtual ~ReadFloat();
	const char * GetFileName() const {return FileName_1;}
	virtual ErrCode DoNode(int32);
};

extern ReadFloat * ReadFloatDef;


#endif /* #ifdef READFLT_DOT_H */
