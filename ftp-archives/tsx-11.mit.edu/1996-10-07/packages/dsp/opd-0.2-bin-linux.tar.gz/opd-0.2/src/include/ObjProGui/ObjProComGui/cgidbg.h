/*
 *  cgidbg.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  cgidbg.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */

#ifndef CGIDBG_DOT_H
#define CGIDBG_DOT_H
#include <stream.h>
#include "ObjProDSP/portable.h"
#include "ObjProGen/errcode.h"
#include "ObjProComGui/usercom.h"
#include "ObjProGen/debug.h"

void LogMsg(const char * p1, const char * p2=0,const char * p3=0,
const char *p4=0);

void CGIError(char * Func) ;

//class ostream ;
//extern ostream * DebugOut ;

void LogForm(const char * format,int32 a, int32 b=0,int32 c=0, int32 d=0) ;

extern void ExitAndCleanUp();
extern void ExitMinimalCleanUp() ;
// Must be supplied by application
// Can do nothing but exit if no cleanup needed

extern const char * DebugOutFile;
// Debug file name to be initalized by application
// Cannot be done dynamically!

#define LogOut CheckLogOutDefined()
#define TheLog LogOut
class ostream& CheckLogOutDefined() ;
void SystemErrorMessage(int LastLineFeed = 1, char **ret=0) ;
void SetNewHandler();
void ExitOneWayOrAnother() ;



#endif /* #ifdef CGIDBG_DOT_H */
