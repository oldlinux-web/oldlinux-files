/*
 *  pltenm.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  pltenm.h   */
/*  Copyright 1990 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef PLTENM_DOT_H
#define PLTENM_DOT_H

enum PlotDynType {PlotDynStatic,PlotDynDyn};

enum PlotSpecificControlOptions {PlotControlHeader, PlotControlCaption,
    PlotControlName, PlotControlChannel, PlotControlElement,
    PlotControlLabelParameter, PlotControlComplete,
    PlotControlNewSampleRate,PlotControlRaiseWindow} ;


#endif /* #ifdef PLTENM_DOT_H */
