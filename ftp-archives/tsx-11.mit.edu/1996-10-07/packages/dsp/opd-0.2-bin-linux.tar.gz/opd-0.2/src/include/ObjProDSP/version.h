/*
 *  version.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#define OBJ_PRO_DSP_VERSION_NUM 0.2
#define OBJ_PRO_DSP_VERSION_STR(STR) # STR
#define OBJ_PRO_DSP_VERSION_XSTR(STR) OBJ_PRO_DSP_VERSION_STR(STR)
#define OBJ_PRO_DSP_VERSION OBJ_PRO_DSP_VERSION_XSTR(OBJ_PRO_DSP_VERSION_NUM)
