/*
 *  helpdir.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  helpdir.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
extern char * HelpFileDirectory ;
// directory where help files are expected - will need to be changed
//	so directory can be set by environmental variables

