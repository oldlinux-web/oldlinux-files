/*
 *  gcd.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  gcd.h   */
/*  Copyright 1991 Mountain Math Software  */
/*  All Rights Reserved                    */
// Algorithm taken from Knuth, Fundamental Algorithms, page 14 (sec 1.2.1)

#include "ObjProDSP/portable.h"
int32 GreatestCommonDivisor(int32 m, int32 n) ;
int32 LeastCommonMultiple(int32 a, int32 b) ;
int32 CheckMultiply(int32 a, int32 b) ;
int32 RemoveCommonFactor(int32& Num, int32& Denom) ;

