/*
 *  genrand.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  genrand.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */

#include "portable.h"

class GaussRand {
	enum {prev_size= 6, bits_in_un_long=31, state_size=256} ;
	double Previous[prev_size];
	int NextElt ;
    char * state ;
	char * save_state ;
	int shift ;
	long uniform_long ;
public:
	GaussRand(int32 seed);
	~GaussRand();
	double exp_rand() ;
	double gauss_rand() ;
	void set_state();
	void restore_state();
	void dump_state(const char * from);
};

