/*
 *  coord.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  coord.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */

#ifndef COORD_DOT_H
#define COORD_DOT_H
#include "ObjProDSP/portable.h"
struct Position {
	int16 X ;
	int16 Y ;
	Position(int16 x,int16 y) {X=x; Y=y;}
	Position() {X=Y=0;}
} ;
const Position EndPositionList = Position(-1,-1) ;

const DoubScale = 32768 ;
const AxisSize = 32767 ;
const FullScale = 32768 ;
const ProtectLine = 3 ;   // allow this many pixels between lines
			  // to prevent overwrite


#endif /* #ifdef COORD_DOT_H */
