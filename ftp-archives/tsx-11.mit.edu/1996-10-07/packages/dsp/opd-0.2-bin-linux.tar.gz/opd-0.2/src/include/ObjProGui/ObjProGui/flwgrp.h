/*
 *  flwgrp.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  flwgrp.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef FLWGRP_DOT_H
#define FLWGRP_DOT_H
void DataFlow::GraphDisplay(int16 Option)
{
	NetControl::GraphDisplay(Option);
}

void DataFlow::Execute(int32 Times)
{
	NetControl::DoExecute(Times);
}

void DataFlow::AssignBuffers(BufferDescript& Descript)
{
	NetControl::AssignBuffers(Descript);
}

void DataFlow::ClearBuffers()
{
	NetControl::ClearBuffers() ;
}

void DataFlow::ClearNetwork()
{
	NetControl::DeleteAllLinks() ;
}

#endif /* #ifdef FLWGRP_DOT_H */
