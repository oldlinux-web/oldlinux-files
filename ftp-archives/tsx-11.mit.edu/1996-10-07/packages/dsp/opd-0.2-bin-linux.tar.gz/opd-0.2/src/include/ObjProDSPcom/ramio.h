/*
 *  ramio.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef RAMIO_DOT_H
#define RAMIO_DOT_H
#define HexOut(a)
#define IntOut(a)
#define FloatOut(a)
#define StringOut(a)
#define CheckPoint(a,b)
#endif /* #ifdef RAMIO_DOT_H */
