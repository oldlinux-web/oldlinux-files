/*
 *  txtenm.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  txtenm.h   */
/*  Copyright 1990 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef TXTENM_DOT_H
#define TXTENM_DOT_H
enum LineStateOptions {LineStateNewEmpty,
	LineStateNewWritten,LineStateInFile,LineStateChangedFromFile};

enum DrawCase {DrawCaseDoNotDraw,DrawCaseDoDraw,DrawCaseInitPreserve};
// redraw and init options for TextSetScreen

#endif /* #ifdef TXTENM_DOT_H */
