/*
 *  buftype.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  buftype.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef BUFTYPE_DOT_H
#define BUFTYPE_DOT_H
enum BufferType {LinearBufferType, CircBufferType, MaxInvalidBufferType} ;
enum NodeExecuteType {NodeExecuteFixedBound, NodeExecuteSpaceBound,
	NodeExecuteFixedIgnoreSpace} ;

/*
 * 
 *	NodeExecuteFixedBound --- Must check available contiguous space
 *				but execute no more than limit set.
 *	NodeExecuteSpaceBound --- Can execute as much as space is available
 *				(can ignore execute count.)
 *	NodeExecuteFixedIgnoreSpace --- No need to check for contiguous space
 *				but must execute eactly as specified.
 *
 */

#endif /* #ifdef BUFTYPE_DOT_H */
