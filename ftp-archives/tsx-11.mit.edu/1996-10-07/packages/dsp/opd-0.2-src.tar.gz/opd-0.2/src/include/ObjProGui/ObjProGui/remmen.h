/*
 *  remmen.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  remmen.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */

void DescribeGenericInteractiveEntity(class InteractiveEntity *);

void CreateDefaultNodeInteractiveEntity(const char * EntityNode);
void CreateNodeInteractiveEntity(const char * EntityNode);

void DeleteNodeInteractiveEntity(const char * EntityNode,
	const char * NodeName);

void NodeDescribe(const char * TheNode);

void DescribeNodeInstance(const char * NodeClass, const char *NodeInstance) ;

void DescribeParamInstance(const char * NodeClass, const char * NodeInstance,
	const char * Param);

void DescribeParam(const char * NodeClass, const char * Param);

void MemberFunctionDescribe(const char * ClassName, const char * MemberName);

void ExecuteMemberFunction(const char * ClassName, const char * ObjectName,
	const char * FunctionName);

void DescribeMemberFunctionParameter(const char * ClassName,
	const char * MemberName, const char * Parameter);

void ExecuteSetParameter(const char * ClassName, const char * ObjectName,
	const char * FunctionName) ;

