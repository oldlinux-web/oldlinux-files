/*  usercomd.C   */
/*  Copyright 1990 Mountain Math Software  */
/*  All Rights Reserved                    */

#include <stream.h>
#include <ctype.h>
#include "usercom.h"
#include "cgidbg.h"
#include "grphio.h"
#include "portable.h"
#include "basicio.h"
#include "yacintfc.h"

int WindowBuf::overflow(int c)
{
/*
 *	LogOut << "WindowBuf::(" << (char) c << "), ix = " << PortIndex <<
 *		", Int = " << State.IsInteractive() << "\n" ;
 */
	int e = PortIndex ;
	if (GraphicsMode) WindowWrite((OutputType)PortIndex,c) ;
	else cout.put((char) c);
	return 0;
}

ostream& OutCon::operator+(int TheType)
{
    // LogOut << "SetWindow(" << TheType << ")\n" ;
	if (!State.IsInteractive()) if (TheType == OutputUndefined ||
            TheType == OutputPrompt) TheType = OutputCppHelp ;
    return Basic->SetWindow(TheType);
}




void OutCon::Flush()
{
	if (GraphicsMode) return ;
	cout.flush();
}

