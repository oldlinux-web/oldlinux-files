/*
 *  texutil.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  texutil.h   */
/*  Copyright 1991 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef TEXUTIL_DOT_H
#define TEXUTIL_DOT_H


class OutTokens ;
OutTokens& VSpace(OutTokens& Out);
void LitFillOut(const char *, class ostream *) ;
void LitFillConcat(const char *, class ostream *) ;
void LitFillQuoteConcat(const char *, class ostream *) ;
void LitQuoteOut(const char *, class ostream *) ;

const char * GetTeXSectionName(int index) ;
int MaxTeXSectionDepth();

const MaxTeXLengthToIndex = 40 ;
void ConditionalTeXIndex(OutTokens& Out, const char * String) ;
int IsTeXEscapable(char Check)  ;
int IsTeXSpecial(char Check)  ;
int TeXstrcmp(const char * a, const char * b) ;
int TeXchrcmp(char a, char b) ;

#endif /* #ifdef TEXUTIL_DOT_H */
