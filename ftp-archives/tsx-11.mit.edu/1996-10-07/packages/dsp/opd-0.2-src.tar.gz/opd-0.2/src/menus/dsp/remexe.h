/*
 *  remexe.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software. All rights reserved.
 *  
 *  This file is part of ObjectProDSP, a tool for Digital Signal
 *  Processing design, development and implementation. It is free
 *  software provided you use and distribute it under the terms of
 *  version 2 of the GNU General Public License as published
 *  by the Free Software Foundation. You may NOT distribute it or
 *  works derived from it or code that it generates under ANY
 *  OTHER terms.  In particular NONE of the ObjectProDSP system is
 *  licensed for use under the GNU General Public LIBRARY License.
 *  Mountain Math Software plans to offer a commercial version of
 *  ObjectProDSP for a fee. That version will allow redistribution
 *  of generated code under standard commercial terms.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of version 2 of the GNU General
 *  Public License along with this program. See file COPYING. If not
 *  or if you wish information on commercial versions and licensing
 *  write Mountain Math Software, P. O. Box 2124, Saratoga, CA 95070,
 *  USA, or send us e-mail at: support@mtnmath.com.
 *  
 *  You may also obtain the GNU General Public License by writing the
 *  Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *  USA.  However if you received a copy of this program without the
 *  file COPYING or without a copyright notice attached to all text
 *  files, libraries and executables please inform Mountain Math Software.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  remexe.h   */
/*  Copyright 1990 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef REMEXE_DOT_H 
#define REMEXE_DOT_H
#include "menucmd.h"
static CommandParameters DoSaveExit_Rem_Call_Struct = {
	-1, 0, 0, 0, 0, 0
};
static CommandParameters DoExit_Rem_Call_Struct = {
	-2, 0, 0, 0, 0, 0
};
static CommandParameters node_trace_on_Rem_Call_Struct = {
	-3, 0, 0, 0, 0, 0
};
static CommandParameters node_trace_off_Rem_Call_Struct = {
	-4, 0, 0, 0, 0, 0
};
static CommandParameters heap_check_on_Rem_Call_Struct = {
	-5, 0, 0, 0, 0, 0
};
static CommandParameters heap_check_off_Rem_Call_Struct = {
	-6, 0, 0, 0, 0, 0
};
static CommandParameters set_report_overflow_limit_Rem_Call_Struct = {
	-7, 0, 0, 0, 0, 0
};
static CommandParameters ListInt_Rem_Call_Struct = {
	-8, 0, 0, 0, 0, 0
};
static CommandParameters ListDouble_Rem_Call_Struct = {
	-9, 0, 0, 0, 0, 0
};
static CommandParameters ListMachWord_Rem_Call_Struct = {
	-10, 0, 0, 0, 0, 0
};
static CommandParameters ListAccMachWord_Rem_Call_Struct = {
	-11, 0, 0, 0, 0, 0
};
static CommandParameters ListComplex_Rem_Call_Struct = {
	-12, 0, 0, 0, 0, 0
};
static CommandParameters ListCxMachWord_Rem_Call_Struct = {
	-13, 0, 0, 0, 0, 0
};
static CommandParameters ListCxAccMachWord_Rem_Call_Struct = {
	-14, 0, 0, 0, 0, 0
};
static CommandParameters DoSave_Rem_Call_Struct = {
	-15, 0, 0, 0, 0, 0
};
static CommandParameters DoSavePeriod_Rem_Call_Struct = {
	-16, 0, 0, 0, 0, 0
};
static CommandParameters DisplaySaveFileName_Rem_Call_Struct = {
	-17, 0, 0, 0, 0, 0
};
static CommandParameters SetStateSaveFile_Rem_Call_Struct = {
	-18, 0, 0, 0, 0, 0
};
char * NodeDescribe__Add_String_Params[] = {
	"Add"
};

static CommandParameters NodeDescribe__Add_Rem_Call_Struct = {
	-19, 3, 0, NodeDescribe__Add_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Add_String_Params[] = {
	"Add"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Add_Rem_Call_Struct = {
	-20, 3, 0, CreateDefaultNodeInteractiveEntity__Add_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Add_String_Params[] = {
	"Add"
};

static CommandParameters CreateNodeInteractiveEntity__Add_Rem_Call_Struct = {
	-21, 3, 0, CreateNodeInteractiveEntity__Add_String_Params, 0, 0
};
char * DescribeNodeInstance__Add_STACK_String_Params[] = {
	"Add"
};

int DescribeNodeInstance__Add_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Add_STACK_Rem_Call_Struct = {
	-22, 4, 0, DescribeNodeInstance__Add_STACK_String_Params, 0, 
	DescribeNodeInstance__Add_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Add_STACK_String_Params[] = {
	"Add"
};

int DeleteNodeInteractiveEntity__Add_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Add_STACK_Rem_Call_Struct = {
	-23, 4, 0, DeleteNodeInteractiveEntity__Add_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Add_STACK_Stack_Params
};
char * DescribeParam__Add_Channels_String_Params[] = {
	"Add", "Channels"
};

static CommandParameters DescribeParam__Add_Channels_Rem_Call_Struct = {
	-24, 5, 0, DescribeParam__Add_Channels_String_Params, 0, 0
};
char * DescribeParam__Add_ElementSize_String_Params[] = {
	"Add", "ElementSize"
};

static CommandParameters DescribeParam__Add_ElementSize_Rem_Call_Struct = {
	-25, 5, 0, DescribeParam__Add_ElementSize_String_Params, 0, 0
};
char * DescribeParam__Add_Scale_String_Params[] = {
	"Add", "Scale"
};

static CommandParameters DescribeParam__Add_Scale_Rem_Call_Struct = {
	-26, 5, 0, DescribeParam__Add_Scale_String_Params, 0, 0
};
char * DescribeParamInstance__Add_STACK_Channels_String_Params[] = {
	"Add", "Channels"
};

int DescribeParamInstance__Add_STACK_Channels_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Add_STACK_Channels_Rem_Call_Struct = {
	-27, 6, 0, DescribeParamInstance__Add_STACK_Channels_String_Params, 0, 
	DescribeParamInstance__Add_STACK_Channels_Stack_Params
};
char * DescribeParamInstance__Add_STACK_ElementSize_String_Params[] = {
	"Add", "ElementSize"
};

int DescribeParamInstance__Add_STACK_ElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Add_STACK_ElementSize_Rem_Call_Struct = {
	-28, 6, 0, DescribeParamInstance__Add_STACK_ElementSize_String_Params, 0, 
	DescribeParamInstance__Add_STACK_ElementSize_Stack_Params
};
char * DescribeParamInstance__Add_STACK_Scale_String_Params[] = {
	"Add", "Scale"
};

int DescribeParamInstance__Add_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Add_STACK_Scale_Rem_Call_Struct = {
	-29, 6, 0, DescribeParamInstance__Add_STACK_Scale_String_Params, 0, 
	DescribeParamInstance__Add_STACK_Scale_Stack_Params
};
char * ExecuteSetParameter__Add_STACK_Scale_String_Params[] = {
	"Add", "Scale"
};

int ExecuteSetParameter__Add_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Add_STACK_Scale_Rem_Call_Struct = {
	-30, 6, 0, ExecuteSetParameter__Add_STACK_Scale_String_Params, 0, 
	ExecuteSetParameter__Add_STACK_Scale_Stack_Params
};
char * NodeDescribe__AsciiFile_String_Params[] = {
	"AsciiFile"
};

static CommandParameters NodeDescribe__AsciiFile_Rem_Call_Struct = {
	-31, 3, 0, NodeDescribe__AsciiFile_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__AsciiFile_String_Params[] = {
	"AsciiFile"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__AsciiFile_Rem_Call_Struct = {
	-32, 3, 0, CreateDefaultNodeInteractiveEntity__AsciiFile_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__AsciiFile_String_Params[] = {
	"AsciiFile"
};

static CommandParameters CreateNodeInteractiveEntity__AsciiFile_Rem_Call_Struct = {
	-33, 3, 0, CreateNodeInteractiveEntity__AsciiFile_String_Params, 0, 0
};
char * DescribeNodeInstance__AsciiFile_STACK_String_Params[] = {
	"AsciiFile"
};

int DescribeNodeInstance__AsciiFile_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__AsciiFile_STACK_Rem_Call_Struct = {
	-34, 4, 0, DescribeNodeInstance__AsciiFile_STACK_String_Params, 0, 
	DescribeNodeInstance__AsciiFile_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__AsciiFile_STACK_String_Params[] = {
	"AsciiFile"
};

int DeleteNodeInteractiveEntity__AsciiFile_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__AsciiFile_STACK_Rem_Call_Struct = {
	-35, 4, 0, DeleteNodeInteractiveEntity__AsciiFile_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__AsciiFile_STACK_Stack_Params
};
char * DescribeParam__AsciiFile_FileName_String_Params[] = {
	"AsciiFile", "FileName"
};

static CommandParameters DescribeParam__AsciiFile_FileName_Rem_Call_Struct = {
	-36, 5, 0, DescribeParam__AsciiFile_FileName_String_Params, 0, 0
};
char * DescribeParam__AsciiFile_Binary_String_Params[] = {
	"AsciiFile", "Binary"
};

static CommandParameters DescribeParam__AsciiFile_Binary_Rem_Call_Struct = {
	-37, 5, 0, DescribeParam__AsciiFile_Binary_String_Params, 0, 0
};
char * DescribeParam__AsciiFile_NoGroup_String_Params[] = {
	"AsciiFile", "NoGroup"
};

static CommandParameters DescribeParam__AsciiFile_NoGroup_Rem_Call_Struct = {
	-38, 5, 0, DescribeParam__AsciiFile_NoGroup_String_Params, 0, 0
};
char * DescribeParam__AsciiFile_NoHeader_String_Params[] = {
	"AsciiFile", "NoHeader"
};

static CommandParameters DescribeParam__AsciiFile_NoHeader_Rem_Call_Struct = {
	-39, 5, 0, DescribeParam__AsciiFile_NoHeader_String_Params, 0, 0
};
char * DescribeParam__AsciiFile_ScaleFactor_String_Params[] = {
	"AsciiFile", "ScaleFactor"
};

static CommandParameters DescribeParam__AsciiFile_ScaleFactor_Rem_Call_Struct = {
	-40, 5, 0, DescribeParam__AsciiFile_ScaleFactor_String_Params, 0, 0
};
char * DescribeParamInstance__AsciiFile_STACK_FileName_String_Params[] = {
	"AsciiFile", "FileName"
};

int DescribeParamInstance__AsciiFile_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__AsciiFile_STACK_FileName_Rem_Call_Struct = {
	-41, 6, 0, DescribeParamInstance__AsciiFile_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__AsciiFile_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__AsciiFile_STACK_Binary_String_Params[] = {
	"AsciiFile", "Binary"
};

int DescribeParamInstance__AsciiFile_STACK_Binary_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__AsciiFile_STACK_Binary_Rem_Call_Struct = {
	-42, 6, 0, DescribeParamInstance__AsciiFile_STACK_Binary_String_Params, 0, 
	DescribeParamInstance__AsciiFile_STACK_Binary_Stack_Params
};
char * DescribeParamInstance__AsciiFile_STACK_NoGroup_String_Params[] = {
	"AsciiFile", "NoGroup"
};

int DescribeParamInstance__AsciiFile_STACK_NoGroup_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__AsciiFile_STACK_NoGroup_Rem_Call_Struct = {
	-43, 6, 0, DescribeParamInstance__AsciiFile_STACK_NoGroup_String_Params, 0, 
	DescribeParamInstance__AsciiFile_STACK_NoGroup_Stack_Params
};
char * DescribeParamInstance__AsciiFile_STACK_NoHeader_String_Params[] = {
	"AsciiFile", "NoHeader"
};

int DescribeParamInstance__AsciiFile_STACK_NoHeader_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__AsciiFile_STACK_NoHeader_Rem_Call_Struct = {
	-44, 6, 0, DescribeParamInstance__AsciiFile_STACK_NoHeader_String_Params, 0, 
	DescribeParamInstance__AsciiFile_STACK_NoHeader_Stack_Params
};
char * DescribeParamInstance__AsciiFile_STACK_ScaleFactor_String_Params[] = {
	"AsciiFile", "ScaleFactor"
};

int DescribeParamInstance__AsciiFile_STACK_ScaleFactor_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__AsciiFile_STACK_ScaleFactor_Rem_Call_Struct = {
	-45, 6, 0, DescribeParamInstance__AsciiFile_STACK_ScaleFactor_String_Params, 0, 
	DescribeParamInstance__AsciiFile_STACK_ScaleFactor_Stack_Params
};
char * ExecuteSetParameter__AsciiFile_STACK_Binary_String_Params[] = {
	"AsciiFile", "Binary"
};

int ExecuteSetParameter__AsciiFile_STACK_Binary_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__AsciiFile_STACK_Binary_Rem_Call_Struct = {
	-46, 6, 0, ExecuteSetParameter__AsciiFile_STACK_Binary_String_Params, 0, 
	ExecuteSetParameter__AsciiFile_STACK_Binary_Stack_Params
};
char * NodeDescribe__BinInNode_String_Params[] = {
	"BinInNode"
};

static CommandParameters NodeDescribe__BinInNode_Rem_Call_Struct = {
	-47, 3, 0, NodeDescribe__BinInNode_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__BinInNode_String_Params[] = {
	"BinInNode"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__BinInNode_Rem_Call_Struct = {
	-48, 3, 0, CreateDefaultNodeInteractiveEntity__BinInNode_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__BinInNode_String_Params[] = {
	"BinInNode"
};

static CommandParameters CreateNodeInteractiveEntity__BinInNode_Rem_Call_Struct = {
	-49, 3, 0, CreateNodeInteractiveEntity__BinInNode_String_Params, 0, 0
};
char * DescribeNodeInstance__BinInNode_STACK_String_Params[] = {
	"BinInNode"
};

int DescribeNodeInstance__BinInNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__BinInNode_STACK_Rem_Call_Struct = {
	-50, 4, 0, DescribeNodeInstance__BinInNode_STACK_String_Params, 0, 
	DescribeNodeInstance__BinInNode_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__BinInNode_STACK_String_Params[] = {
	"BinInNode"
};

int DeleteNodeInteractiveEntity__BinInNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__BinInNode_STACK_Rem_Call_Struct = {
	-51, 4, 0, DeleteNodeInteractiveEntity__BinInNode_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__BinInNode_STACK_Stack_Params
};
char * DescribeParam__BinInNode_FileName_String_Params[] = {
	"BinInNode", "FileName"
};

static CommandParameters DescribeParam__BinInNode_FileName_Rem_Call_Struct = {
	-52, 5, 0, DescribeParam__BinInNode_FileName_String_Params, 0, 0
};
char * DescribeParam__BinInNode_DataType_String_Params[] = {
	"BinInNode", "DataType"
};

static CommandParameters DescribeParam__BinInNode_DataType_Rem_Call_Struct = {
	-53, 5, 0, DescribeParam__BinInNode_DataType_String_Params, 0, 0
};
char * DescribeParamInstance__BinInNode_STACK_FileName_String_Params[] = {
	"BinInNode", "FileName"
};

int DescribeParamInstance__BinInNode_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__BinInNode_STACK_FileName_Rem_Call_Struct = {
	-54, 6, 0, DescribeParamInstance__BinInNode_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__BinInNode_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__BinInNode_STACK_DataType_String_Params[] = {
	"BinInNode", "DataType"
};

int DescribeParamInstance__BinInNode_STACK_DataType_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__BinInNode_STACK_DataType_Rem_Call_Struct = {
	-55, 6, 0, DescribeParamInstance__BinInNode_STACK_DataType_String_Params, 0, 
	DescribeParamInstance__BinInNode_STACK_DataType_Stack_Params
};
char * NodeDescribe__BinaryOutNode_String_Params[] = {
	"BinaryOutNode"
};

static CommandParameters NodeDescribe__BinaryOutNode_Rem_Call_Struct = {
	-56, 3, 0, NodeDescribe__BinaryOutNode_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__BinaryOutNode_String_Params[] = {
	"BinaryOutNode"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__BinaryOutNode_Rem_Call_Struct = {
	-57, 3, 0, CreateDefaultNodeInteractiveEntity__BinaryOutNode_String_Params, 0, 
	0
};
char * CreateNodeInteractiveEntity__BinaryOutNode_String_Params[] = {
	"BinaryOutNode"
};

static CommandParameters CreateNodeInteractiveEntity__BinaryOutNode_Rem_Call_Struct = {
	-58, 3, 0, CreateNodeInteractiveEntity__BinaryOutNode_String_Params, 0, 0
};
char * DescribeNodeInstance__BinaryOutNode_STACK_String_Params[] = {
	"BinaryOutNode"
};

int DescribeNodeInstance__BinaryOutNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__BinaryOutNode_STACK_Rem_Call_Struct = {
	-59, 4, 0, DescribeNodeInstance__BinaryOutNode_STACK_String_Params, 0, 
	DescribeNodeInstance__BinaryOutNode_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__BinaryOutNode_STACK_String_Params[] = {
	"BinaryOutNode"
};

int DeleteNodeInteractiveEntity__BinaryOutNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__BinaryOutNode_STACK_Rem_Call_Struct = {
	-60, 4, 0, DeleteNodeInteractiveEntity__BinaryOutNode_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__BinaryOutNode_STACK_Stack_Params
};
char * DescribeParam__BinaryOutNode_Channels_String_Params[] = {
	"BinaryOutNode", "Channels"
};

static CommandParameters DescribeParam__BinaryOutNode_Channels_Rem_Call_Struct = {
	-61, 5, 0, DescribeParam__BinaryOutNode_Channels_String_Params, 0, 0
};
char * DescribeParam__BinaryOutNode_ElementSize_String_Params[] = {
	"BinaryOutNode", "ElementSize"
};

static CommandParameters DescribeParam__BinaryOutNode_ElementSize_Rem_Call_Struct = {
	-62, 5, 0, DescribeParam__BinaryOutNode_ElementSize_String_Params, 0, 0
};
char * DescribeParam__BinaryOutNode_WordSize_String_Params[] = {
	"BinaryOutNode", "WordSize"
};

static CommandParameters DescribeParam__BinaryOutNode_WordSize_Rem_Call_Struct = {
	-63, 5, 0, DescribeParam__BinaryOutNode_WordSize_String_Params, 0, 0
};
char * DescribeParam__BinaryOutNode_FileName_String_Params[] = {
	"BinaryOutNode", "FileName"
};

static CommandParameters DescribeParam__BinaryOutNode_FileName_Rem_Call_Struct = {
	-64, 5, 0, DescribeParam__BinaryOutNode_FileName_String_Params, 0, 0
};
char * DescribeParamInstance__BinaryOutNode_STACK_Channels_String_Params[] = {
	"BinaryOutNode", "Channels"
};

int DescribeParamInstance__BinaryOutNode_STACK_Channels_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__BinaryOutNode_STACK_Channels_Rem_Call_Struct = {
	-65, 6, 0, DescribeParamInstance__BinaryOutNode_STACK_Channels_String_Params, 0, 
	DescribeParamInstance__BinaryOutNode_STACK_Channels_Stack_Params
};
char * DescribeParamInstance__BinaryOutNode_STACK_ElementSize_String_Params[] = {
	"BinaryOutNode", "ElementSize"
};

int DescribeParamInstance__BinaryOutNode_STACK_ElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__BinaryOutNode_STACK_ElementSize_Rem_Call_Struct = {
	-66, 6, 0, DescribeParamInstance__BinaryOutNode_STACK_ElementSize_String_Params, 
	0, DescribeParamInstance__BinaryOutNode_STACK_ElementSize_Stack_Params
};
char * DescribeParamInstance__BinaryOutNode_STACK_WordSize_String_Params[] = {
	"BinaryOutNode", "WordSize"
};

int DescribeParamInstance__BinaryOutNode_STACK_WordSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__BinaryOutNode_STACK_WordSize_Rem_Call_Struct = {
	-67, 6, 0, DescribeParamInstance__BinaryOutNode_STACK_WordSize_String_Params, 0, 
	DescribeParamInstance__BinaryOutNode_STACK_WordSize_Stack_Params
};
char * DescribeParamInstance__BinaryOutNode_STACK_FileName_String_Params[] = {
	"BinaryOutNode", "FileName"
};

int DescribeParamInstance__BinaryOutNode_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__BinaryOutNode_STACK_FileName_Rem_Call_Struct = {
	-68, 6, 0, DescribeParamInstance__BinaryOutNode_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__BinaryOutNode_STACK_FileName_Stack_Params
};
char * NodeDescribe__BitsInNode_String_Params[] = {
	"BitsInNode"
};

static CommandParameters NodeDescribe__BitsInNode_Rem_Call_Struct = {
	-69, 3, 0, NodeDescribe__BitsInNode_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__BitsInNode_String_Params[] = {
	"BitsInNode"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__BitsInNode_Rem_Call_Struct = {
	-70, 3, 0, CreateDefaultNodeInteractiveEntity__BitsInNode_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__BitsInNode_String_Params[] = {
	"BitsInNode"
};

static CommandParameters CreateNodeInteractiveEntity__BitsInNode_Rem_Call_Struct = {
	-71, 3, 0, CreateNodeInteractiveEntity__BitsInNode_String_Params, 0, 0
};
char * DescribeNodeInstance__BitsInNode_STACK_String_Params[] = {
	"BitsInNode"
};

int DescribeNodeInstance__BitsInNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__BitsInNode_STACK_Rem_Call_Struct = {
	-72, 4, 0, DescribeNodeInstance__BitsInNode_STACK_String_Params, 0, 
	DescribeNodeInstance__BitsInNode_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__BitsInNode_STACK_String_Params[] = {
	"BitsInNode"
};

int DeleteNodeInteractiveEntity__BitsInNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__BitsInNode_STACK_Rem_Call_Struct = {
	-73, 4, 0, DeleteNodeInteractiveEntity__BitsInNode_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__BitsInNode_STACK_Stack_Params
};
char * DescribeParam__BitsInNode_FileName_String_Params[] = {
	"BitsInNode", "FileName"
};

static CommandParameters DescribeParam__BitsInNode_FileName_Rem_Call_Struct = {
	-74, 5, 0, DescribeParam__BitsInNode_FileName_String_Params, 0, 0
};
char * DescribeParam__BitsInNode_WordSize_String_Params[] = {
	"BitsInNode", "WordSize"
};

static CommandParameters DescribeParam__BitsInNode_WordSize_Rem_Call_Struct = {
	-75, 5, 0, DescribeParam__BitsInNode_WordSize_String_Params, 0, 0
};
char * DescribeParamInstance__BitsInNode_STACK_FileName_String_Params[] = {
	"BitsInNode", "FileName"
};

int DescribeParamInstance__BitsInNode_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__BitsInNode_STACK_FileName_Rem_Call_Struct = {
	-76, 6, 0, DescribeParamInstance__BitsInNode_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__BitsInNode_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__BitsInNode_STACK_WordSize_String_Params[] = {
	"BitsInNode", "WordSize"
};

int DescribeParamInstance__BitsInNode_STACK_WordSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__BitsInNode_STACK_WordSize_Rem_Call_Struct = {
	-77, 6, 0, DescribeParamInstance__BitsInNode_STACK_WordSize_String_Params, 0, 
	DescribeParamInstance__BitsInNode_STACK_WordSize_Stack_Params
};
char * NodeDescribe__CircBufDes_String_Params[] = {
	"CircBufDes"
};

static CommandParameters NodeDescribe__CircBufDes_Rem_Call_Struct = {
	-78, 3, 0, NodeDescribe__CircBufDes_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__CircBufDes_String_Params[] = {
	"CircBufDes"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__CircBufDes_Rem_Call_Struct = {
	-79, 3, 0, CreateDefaultNodeInteractiveEntity__CircBufDes_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__CircBufDes_String_Params[] = {
	"CircBufDes"
};

static CommandParameters CreateNodeInteractiveEntity__CircBufDes_Rem_Call_Struct = {
	-80, 3, 0, CreateNodeInteractiveEntity__CircBufDes_String_Params, 0, 0
};
char * MemberFunctionDescribe__CircBufDes_STACK_String_Params[] = {
	"CircBufDes"
};

int MemberFunctionDescribe__CircBufDes_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__CircBufDes_STACK_Rem_Call_Struct = {
	-81, 4, 0, MemberFunctionDescribe__CircBufDes_STACK_String_Params, 0, 
	MemberFunctionDescribe__CircBufDes_STACK_Stack_Params
};
char * DescribeNodeInstance__CircBufDes_STACK_String_Params[] = {
	"CircBufDes"
};

int DescribeNodeInstance__CircBufDes_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__CircBufDes_STACK_Rem_Call_Struct = {
	-82, 4, 0, DescribeNodeInstance__CircBufDes_STACK_String_Params, 0, 
	DescribeNodeInstance__CircBufDes_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__CircBufDes_STACK_String_Params[] = {
	"CircBufDes"
};

int DeleteNodeInteractiveEntity__CircBufDes_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__CircBufDes_STACK_Rem_Call_Struct = {
	-83, 4, 0, DeleteNodeInteractiveEntity__CircBufDes_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__CircBufDes_STACK_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_AssignToEdit_String_Params[] = {
	"AssignToEdit"
};

int ExecuteMemberFunction__STACK_STACK_AssignToEdit_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_AssignToEdit_Rem_Call_Struct = {
	-84, 7, 0, ExecuteMemberFunction__STACK_STACK_AssignToEdit_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_AssignToEdit_Stack_Params
};
char * DescribeParam__CircBufDes_Size_String_Params[] = {
	"CircBufDes", "Size"
};

static CommandParameters DescribeParam__CircBufDes_Size_Rem_Call_Struct = {
	-85, 5, 0, DescribeParam__CircBufDes_Size_String_Params, 0, 0
};
char * DescribeParam__CircBufDes_TargetSize_String_Params[] = {
	"CircBufDes", "TargetSize"
};

static CommandParameters DescribeParam__CircBufDes_TargetSize_Rem_Call_Struct = {
	-86, 5, 0, DescribeParam__CircBufDes_TargetSize_String_Params, 0, 0
};
char * DescribeParam__CircBufDes_TargetSizeGoal_String_Params[] = {
	"CircBufDes", "TargetSizeGoal"
};

static CommandParameters DescribeParam__CircBufDes_TargetSizeGoal_Rem_Call_Struct = {
	-87, 5, 0, DescribeParam__CircBufDes_TargetSizeGoal_String_Params, 0, 0
};
char * DescribeParam__CircBufDes_TargetControlGoal_String_Params[] = {
	"CircBufDes", "TargetControlGoal"
};

static CommandParameters DescribeParam__CircBufDes_TargetControlGoal_Rem_Call_Struct = {
	-88, 5, 0, DescribeParam__CircBufDes_TargetControlGoal_String_Params, 0, 0
};
char * DescribeParam__CircBufDes_MaxTargetSize_String_Params[] = {
	"CircBufDes", "MaxTargetSize"
};

static CommandParameters DescribeParam__CircBufDes_MaxTargetSize_Rem_Call_Struct = {
	-89, 5, 0, DescribeParam__CircBufDes_MaxTargetSize_String_Params, 0, 0
};
char * DescribeParam__CircBufDes_MinTargetSize_String_Params[] = {
	"CircBufDes", "MinTargetSize"
};

static CommandParameters DescribeParam__CircBufDes_MinTargetSize_Rem_Call_Struct = {
	-90, 5, 0, DescribeParam__CircBufDes_MinTargetSize_String_Params, 0, 0
};
char * DescribeParamInstance__CircBufDes_STACK_Size_String_Params[] = {
	"CircBufDes", "Size"
};

int DescribeParamInstance__CircBufDes_STACK_Size_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CircBufDes_STACK_Size_Rem_Call_Struct = {
	-91, 6, 0, DescribeParamInstance__CircBufDes_STACK_Size_String_Params, 0, 
	DescribeParamInstance__CircBufDes_STACK_Size_Stack_Params
};
char * DescribeParamInstance__CircBufDes_STACK_TargetSize_String_Params[] = {
	"CircBufDes", "TargetSize"
};

int DescribeParamInstance__CircBufDes_STACK_TargetSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CircBufDes_STACK_TargetSize_Rem_Call_Struct = {
	-92, 6, 0, DescribeParamInstance__CircBufDes_STACK_TargetSize_String_Params, 0, 
	DescribeParamInstance__CircBufDes_STACK_TargetSize_Stack_Params
};
char * DescribeParamInstance__CircBufDes_STACK_TargetSizeGoal_String_Params[] = {
	"CircBufDes", "TargetSizeGoal"
};

int DescribeParamInstance__CircBufDes_STACK_TargetSizeGoal_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CircBufDes_STACK_TargetSizeGoal_Rem_Call_Struct = {
	-93, 6, 0, DescribeParamInstance__CircBufDes_STACK_TargetSizeGoal_String_Params, 
	0, DescribeParamInstance__CircBufDes_STACK_TargetSizeGoal_Stack_Params
};
char * DescribeParamInstance__CircBufDes_STACK_TargetControlGoal_String_Params[] = {
	"CircBufDes", "TargetControlGoal"
};

int DescribeParamInstance__CircBufDes_STACK_TargetControlGoal_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CircBufDes_STACK_TargetControlGoal_Rem_Call_Struct = {
	-94, 6, 0, 
	DescribeParamInstance__CircBufDes_STACK_TargetControlGoal_String_Params, 0, 
	DescribeParamInstance__CircBufDes_STACK_TargetControlGoal_Stack_Params
};
char * DescribeParamInstance__CircBufDes_STACK_MaxTargetSize_String_Params[] = {
	"CircBufDes", "MaxTargetSize"
};

int DescribeParamInstance__CircBufDes_STACK_MaxTargetSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CircBufDes_STACK_MaxTargetSize_Rem_Call_Struct = {
	-95, 6, 0, DescribeParamInstance__CircBufDes_STACK_MaxTargetSize_String_Params, 
	0, DescribeParamInstance__CircBufDes_STACK_MaxTargetSize_Stack_Params
};
char * DescribeParamInstance__CircBufDes_STACK_MinTargetSize_String_Params[] = {
	"CircBufDes", "MinTargetSize"
};

int DescribeParamInstance__CircBufDes_STACK_MinTargetSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CircBufDes_STACK_MinTargetSize_Rem_Call_Struct = {
	-96, 6, 0, DescribeParamInstance__CircBufDes_STACK_MinTargetSize_String_Params, 
	0, DescribeParamInstance__CircBufDes_STACK_MinTargetSize_Stack_Params
};
char * ExecuteSetParameter__CircBufDes_STACK_TargetSize_String_Params[] = {
	"CircBufDes", "TargetSize"
};

int ExecuteSetParameter__CircBufDes_STACK_TargetSize_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CircBufDes_STACK_TargetSize_Rem_Call_Struct = {
	-97, 6, 0, ExecuteSetParameter__CircBufDes_STACK_TargetSize_String_Params, 0, 
	ExecuteSetParameter__CircBufDes_STACK_TargetSize_Stack_Params
};
char * ExecuteSetParameter__CircBufDes_STACK_TargetSizeGoal_String_Params[] = {
	"CircBufDes", "TargetSizeGoal"
};

int ExecuteSetParameter__CircBufDes_STACK_TargetSizeGoal_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CircBufDes_STACK_TargetSizeGoal_Rem_Call_Struct = {
	-98, 6, 0, ExecuteSetParameter__CircBufDes_STACK_TargetSizeGoal_String_Params, 
	0, ExecuteSetParameter__CircBufDes_STACK_TargetSizeGoal_Stack_Params
};
char * ExecuteSetParameter__CircBufDes_STACK_TargetControlGoal_String_Params[] = {
	"CircBufDes", "TargetControlGoal"
};

int ExecuteSetParameter__CircBufDes_STACK_TargetControlGoal_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CircBufDes_STACK_TargetControlGoal_Rem_Call_Struct = {
	-99, 6, 0, 
	ExecuteSetParameter__CircBufDes_STACK_TargetControlGoal_String_Params, 0, 
	ExecuteSetParameter__CircBufDes_STACK_TargetControlGoal_Stack_Params
};
char * ExecuteSetParameter__CircBufDes_STACK_MaxTargetSize_String_Params[] = {
	"CircBufDes", "MaxTargetSize"
};

int ExecuteSetParameter__CircBufDes_STACK_MaxTargetSize_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CircBufDes_STACK_MaxTargetSize_Rem_Call_Struct = {
	-100, 6, 0, ExecuteSetParameter__CircBufDes_STACK_MaxTargetSize_String_Params, 0, 
	ExecuteSetParameter__CircBufDes_STACK_MaxTargetSize_Stack_Params
};
char * ExecuteSetParameter__CircBufDes_STACK_MinTargetSize_String_Params[] = {
	"CircBufDes", "MinTargetSize"
};

int ExecuteSetParameter__CircBufDes_STACK_MinTargetSize_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CircBufDes_STACK_MinTargetSize_Rem_Call_Struct = {
	-101, 6, 0, ExecuteSetParameter__CircBufDes_STACK_MinTargetSize_String_Params, 0, 
	ExecuteSetParameter__CircBufDes_STACK_MinTargetSize_Stack_Params
};
char * NodeDescribe__DataFlow_String_Params[] = {
	"DataFlow"
};

static CommandParameters NodeDescribe__DataFlow_Rem_Call_Struct = {
	-102, 3, 0, NodeDescribe__DataFlow_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__DataFlow_String_Params[] = {
	"DataFlow"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__DataFlow_Rem_Call_Struct = {
	-103, 3, 0, CreateDefaultNodeInteractiveEntity__DataFlow_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__DataFlow_String_Params[] = {
	"DataFlow"
};

static CommandParameters CreateNodeInteractiveEntity__DataFlow_Rem_Call_Struct = {
	-104, 3, 0, CreateNodeInteractiveEntity__DataFlow_String_Params, 0, 0
};
char * MemberFunctionDescribe__DataFlow_STACK_String_Params[] = {
	"DataFlow"
};

int MemberFunctionDescribe__DataFlow_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__DataFlow_STACK_Rem_Call_Struct = {
	-105, 4, 0, MemberFunctionDescribe__DataFlow_STACK_String_Params, 0, 
	MemberFunctionDescribe__DataFlow_STACK_Stack_Params
};
char * DescribeMemberFunctionParameter__DataFlow_STACK_Option_String_Params[] = {
	"DataFlow", "Option"
};

int DescribeMemberFunctionParameter__DataFlow_STACK_Option_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__DataFlow_STACK_Option_Rem_Call_Struct = {
	-106, 6, 0, DescribeMemberFunctionParameter__DataFlow_STACK_Option_String_Params, 
	0, DescribeMemberFunctionParameter__DataFlow_STACK_Option_Stack_Params
};
char * DescribeMemberFunctionParameter__DataFlow_STACK_InputSamples_String_Params[] = {
	"DataFlow", "InputSamples"
};

int DescribeMemberFunctionParameter__DataFlow_STACK_InputSamples_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__DataFlow_STACK_InputSamples_Rem_Call_Struct = {
	-107, 6, 0, 
	DescribeMemberFunctionParameter__DataFlow_STACK_InputSamples_String_Params, 0, 
	DescribeMemberFunctionParameter__DataFlow_STACK_InputSamples_Stack_Params
};
char * DescribeMemberFunctionParameter__DataFlow_STACK_Descriptor_String_Params[] = {
	"DataFlow", "Descriptor"
};

int DescribeMemberFunctionParameter__DataFlow_STACK_Descriptor_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__DataFlow_STACK_Descriptor_Rem_Call_Struct = {
	-108, 6, 0, 
	DescribeMemberFunctionParameter__DataFlow_STACK_Descriptor_String_Params, 0, 
	DescribeMemberFunctionParameter__DataFlow_STACK_Descriptor_Stack_Params
};
char * DescribeNodeInstance__DataFlow_STACK_String_Params[] = {
	"DataFlow"
};

int DescribeNodeInstance__DataFlow_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__DataFlow_STACK_Rem_Call_Struct = {
	-109, 4, 0, DescribeNodeInstance__DataFlow_STACK_String_Params, 0, 
	DescribeNodeInstance__DataFlow_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__DataFlow_STACK_String_Params[] = {
	"DataFlow"
};

int DeleteNodeInteractiveEntity__DataFlow_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__DataFlow_STACK_Rem_Call_Struct = {
	-110, 4, 0, DeleteNodeInteractiveEntity__DataFlow_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__DataFlow_STACK_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_GraphDisplay_String_Params[] = {
	"GraphDisplay"
};

int ExecuteMemberFunction__STACK_STACK_GraphDisplay_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_GraphDisplay_Rem_Call_Struct = {
	-111, 7, 0, ExecuteMemberFunction__STACK_STACK_GraphDisplay_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_GraphDisplay_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_Execute_String_Params[] = {
	"Execute"
};

int ExecuteMemberFunction__STACK_STACK_Execute_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_Execute_Rem_Call_Struct = {
	-112, 7, 0, ExecuteMemberFunction__STACK_STACK_Execute_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_Execute_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_AssignBuffers_String_Params[] = {
	"AssignBuffers"
};

int ExecuteMemberFunction__STACK_STACK_AssignBuffers_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_AssignBuffers_Rem_Call_Struct = {
	-113, 7, 0, ExecuteMemberFunction__STACK_STACK_AssignBuffers_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_AssignBuffers_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_ClearBuffers_String_Params[] = {
	"ClearBuffers"
};

int ExecuteMemberFunction__STACK_STACK_ClearBuffers_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_ClearBuffers_Rem_Call_Struct = {
	-114, 7, 0, ExecuteMemberFunction__STACK_STACK_ClearBuffers_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_ClearBuffers_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_ClearNetwork_String_Params[] = {
	"ClearNetwork"
};

int ExecuteMemberFunction__STACK_STACK_ClearNetwork_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_ClearNetwork_Rem_Call_Struct = {
	-115, 7, 0, ExecuteMemberFunction__STACK_STACK_ClearNetwork_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_ClearNetwork_Stack_Params
};
char * DescribeParam__DataFlow_TheNet_String_Params[] = {
	"DataFlow", "TheNet"
};

static CommandParameters DescribeParam__DataFlow_TheNet_Rem_Call_Struct = {
	-116, 5, 0, DescribeParam__DataFlow_TheNet_String_Params, 0, 0
};
char * DescribeParamInstance__DataFlow_STACK_TheNet_String_Params[] = {
	"DataFlow", "TheNet"
};

int DescribeParamInstance__DataFlow_STACK_TheNet_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__DataFlow_STACK_TheNet_Rem_Call_Struct = {
	-117, 6, 0, DescribeParamInstance__DataFlow_STACK_TheNet_String_Params, 0, 
	DescribeParamInstance__DataFlow_STACK_TheNet_Stack_Params
};
char * NodeDescribe__CompareDisk_String_Params[] = {
	"CompareDisk"
};

static CommandParameters NodeDescribe__CompareDisk_Rem_Call_Struct = {
	-118, 3, 0, NodeDescribe__CompareDisk_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__CompareDisk_String_Params[] = {
	"CompareDisk"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__CompareDisk_Rem_Call_Struct = {
	-119, 3, 0, CreateDefaultNodeInteractiveEntity__CompareDisk_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__CompareDisk_String_Params[] = {
	"CompareDisk"
};

static CommandParameters CreateNodeInteractiveEntity__CompareDisk_Rem_Call_Struct = {
	-120, 3, 0, CreateNodeInteractiveEntity__CompareDisk_String_Params, 0, 0
};
char * MemberFunctionDescribe__CompareDisk_STACK_String_Params[] = {
	"CompareDisk"
};

int MemberFunctionDescribe__CompareDisk_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__CompareDisk_STACK_Rem_Call_Struct = {
	-121, 4, 0, MemberFunctionDescribe__CompareDisk_STACK_String_Params, 0, 
	MemberFunctionDescribe__CompareDisk_STACK_Stack_Params
};
char * DescribeNodeInstance__CompareDisk_STACK_String_Params[] = {
	"CompareDisk"
};

int DescribeNodeInstance__CompareDisk_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__CompareDisk_STACK_Rem_Call_Struct = {
	-122, 4, 0, DescribeNodeInstance__CompareDisk_STACK_String_Params, 0, 
	DescribeNodeInstance__CompareDisk_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__CompareDisk_STACK_String_Params[] = {
	"CompareDisk"
};

int DeleteNodeInteractiveEntity__CompareDisk_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__CompareDisk_STACK_Rem_Call_Struct = {
	-123, 4, 0, DeleteNodeInteractiveEntity__CompareDisk_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__CompareDisk_STACK_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_DisplayHeader_String_Params[] = {
	"DisplayHeader"
};

int ExecuteMemberFunction__STACK_STACK_DisplayHeader_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_DisplayHeader_Rem_Call_Struct = {
	-124, 7, 0, ExecuteMemberFunction__STACK_STACK_DisplayHeader_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_DisplayHeader_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_IgnoreHeaderCount_String_Params[] = {
	"IgnoreHeaderCount"
};

int ExecuteMemberFunction__STACK_STACK_IgnoreHeaderCount_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_IgnoreHeaderCount_Rem_Call_Struct = {
	-125, 7, 0, ExecuteMemberFunction__STACK_STACK_IgnoreHeaderCount_String_Params, 
	0, ExecuteMemberFunction__STACK_STACK_IgnoreHeaderCount_Stack_Params
};
char * DescribeParam__CompareDisk_FileName_String_Params[] = {
	"CompareDisk", "FileName"
};

static CommandParameters DescribeParam__CompareDisk_FileName_Rem_Call_Struct = {
	-126, 5, 0, DescribeParam__CompareDisk_FileName_String_Params, 0, 0
};
char * DescribeParam__CompareDisk_MaxReport_String_Params[] = {
	"CompareDisk", "MaxReport"
};

static CommandParameters DescribeParam__CompareDisk_MaxReport_Rem_Call_Struct = {
	-127, 5, 0, DescribeParam__CompareDisk_MaxReport_String_Params, 0, 0
};
char * DescribeParam__CompareDisk_Tolerance_String_Params[] = {
	"CompareDisk", "Tolerance"
};

static CommandParameters DescribeParam__CompareDisk_Tolerance_Rem_Call_Struct = {
	-128, 5, 0, DescribeParam__CompareDisk_Tolerance_String_Params, 0, 0
};
char * DescribeParamInstance__CompareDisk_STACK_FileName_String_Params[] = {
	"CompareDisk", "FileName"
};

int DescribeParamInstance__CompareDisk_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CompareDisk_STACK_FileName_Rem_Call_Struct = {
	-129, 6, 0, DescribeParamInstance__CompareDisk_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__CompareDisk_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__CompareDisk_STACK_MaxReport_String_Params[] = {
	"CompareDisk", "MaxReport"
};

int DescribeParamInstance__CompareDisk_STACK_MaxReport_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CompareDisk_STACK_MaxReport_Rem_Call_Struct = {
	-130, 6, 0, DescribeParamInstance__CompareDisk_STACK_MaxReport_String_Params, 0, 
	DescribeParamInstance__CompareDisk_STACK_MaxReport_Stack_Params
};
char * DescribeParamInstance__CompareDisk_STACK_Tolerance_String_Params[] = {
	"CompareDisk", "Tolerance"
};

int DescribeParamInstance__CompareDisk_STACK_Tolerance_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CompareDisk_STACK_Tolerance_Rem_Call_Struct = {
	-131, 6, 0, DescribeParamInstance__CompareDisk_STACK_Tolerance_String_Params, 0, 
	DescribeParamInstance__CompareDisk_STACK_Tolerance_Stack_Params
};
char * NodeDescribe__ConstantData_String_Params[] = {
	"ConstantData"
};

static CommandParameters NodeDescribe__ConstantData_Rem_Call_Struct = {
	-132, 3, 0, NodeDescribe__ConstantData_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__ConstantData_String_Params[] = {
	"ConstantData"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ConstantData_Rem_Call_Struct = {
	-133, 3, 0, CreateDefaultNodeInteractiveEntity__ConstantData_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ConstantData_String_Params[] = {
	"ConstantData"
};

static CommandParameters CreateNodeInteractiveEntity__ConstantData_Rem_Call_Struct = {
	-134, 3, 0, CreateNodeInteractiveEntity__ConstantData_String_Params, 0, 0
};
char * DescribeNodeInstance__ConstantData_STACK_String_Params[] = {
	"ConstantData"
};

int DescribeNodeInstance__ConstantData_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ConstantData_STACK_Rem_Call_Struct = {
	-135, 4, 0, DescribeNodeInstance__ConstantData_STACK_String_Params, 0, 
	DescribeNodeInstance__ConstantData_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ConstantData_STACK_String_Params[] = {
	"ConstantData"
};

int DeleteNodeInteractiveEntity__ConstantData_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ConstantData_STACK_Rem_Call_Struct = {
	-136, 4, 0, DeleteNodeInteractiveEntity__ConstantData_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ConstantData_STACK_Stack_Params
};
char * DescribeParam__ConstantData_Value_String_Params[] = {
	"ConstantData", "Value"
};

static CommandParameters DescribeParam__ConstantData_Value_Rem_Call_Struct = {
	-137, 5, 0, DescribeParam__ConstantData_Value_String_Params, 0, 0
};
char * DescribeParamInstance__ConstantData_STACK_Value_String_Params[] = {
	"ConstantData", "Value"
};

int DescribeParamInstance__ConstantData_STACK_Value_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ConstantData_STACK_Value_Rem_Call_Struct = {
	-138, 6, 0, DescribeParamInstance__ConstantData_STACK_Value_String_Params, 0, 
	DescribeParamInstance__ConstantData_STACK_Value_Stack_Params
};
char * ExecuteSetParameter__ConstantData_STACK_Value_String_Params[] = {
	"ConstantData", "Value"
};

int ExecuteSetParameter__ConstantData_STACK_Value_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__ConstantData_STACK_Value_Rem_Call_Struct = {
	-139, 6, 0, ExecuteSetParameter__ConstantData_STACK_Value_String_Params, 0, 
	ExecuteSetParameter__ConstantData_STACK_Value_Stack_Params
};
char * NodeDescribe__Cos_String_Params[] = {
	"Cos"
};

static CommandParameters NodeDescribe__Cos_Rem_Call_Struct = {
	-140, 3, 0, NodeDescribe__Cos_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Cos_String_Params[] = {
	"Cos"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Cos_Rem_Call_Struct = {
	-141, 3, 0, CreateDefaultNodeInteractiveEntity__Cos_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Cos_String_Params[] = {
	"Cos"
};

static CommandParameters CreateNodeInteractiveEntity__Cos_Rem_Call_Struct = {
	-142, 3, 0, CreateNodeInteractiveEntity__Cos_String_Params, 0, 0
};
char * DescribeNodeInstance__Cos_STACK_String_Params[] = {
	"Cos"
};

int DescribeNodeInstance__Cos_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Cos_STACK_Rem_Call_Struct = {
	-143, 4, 0, DescribeNodeInstance__Cos_STACK_String_Params, 0, 
	DescribeNodeInstance__Cos_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Cos_STACK_String_Params[] = {
	"Cos"
};

int DeleteNodeInteractiveEntity__Cos_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Cos_STACK_Rem_Call_Struct = {
	-144, 4, 0, DeleteNodeInteractiveEntity__Cos_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Cos_STACK_Stack_Params
};
char * DescribeParam__Cos_Frequency_String_Params[] = {
	"Cos", "Frequency"
};

static CommandParameters DescribeParam__Cos_Frequency_Rem_Call_Struct = {
	-145, 5, 0, DescribeParam__Cos_Frequency_String_Params, 0, 0
};
char * DescribeParam__Cos_Phase_String_Params[] = {
	"Cos", "Phase"
};

static CommandParameters DescribeParam__Cos_Phase_Rem_Call_Struct = {
	-146, 5, 0, DescribeParam__Cos_Phase_String_Params, 0, 0
};
char * DescribeParam__Cos_Amplitude_String_Params[] = {
	"Cos", "Amplitude"
};

static CommandParameters DescribeParam__Cos_Amplitude_Rem_Call_Struct = {
	-147, 5, 0, DescribeParam__Cos_Amplitude_String_Params, 0, 0
};
char * DescribeParamInstance__Cos_STACK_Frequency_String_Params[] = {
	"Cos", "Frequency"
};

int DescribeParamInstance__Cos_STACK_Frequency_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Cos_STACK_Frequency_Rem_Call_Struct = {
	-148, 6, 0, DescribeParamInstance__Cos_STACK_Frequency_String_Params, 0, 
	DescribeParamInstance__Cos_STACK_Frequency_Stack_Params
};
char * DescribeParamInstance__Cos_STACK_Phase_String_Params[] = {
	"Cos", "Phase"
};

int DescribeParamInstance__Cos_STACK_Phase_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Cos_STACK_Phase_Rem_Call_Struct = {
	-149, 6, 0, DescribeParamInstance__Cos_STACK_Phase_String_Params, 0, 
	DescribeParamInstance__Cos_STACK_Phase_Stack_Params
};
char * DescribeParamInstance__Cos_STACK_Amplitude_String_Params[] = {
	"Cos", "Amplitude"
};

int DescribeParamInstance__Cos_STACK_Amplitude_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Cos_STACK_Amplitude_Rem_Call_Struct = {
	-150, 6, 0, DescribeParamInstance__Cos_STACK_Amplitude_String_Params, 0, 
	DescribeParamInstance__Cos_STACK_Amplitude_Stack_Params
};
char * ExecuteSetParameter__Cos_STACK_Frequency_String_Params[] = {
	"Cos", "Frequency"
};

int ExecuteSetParameter__Cos_STACK_Frequency_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Cos_STACK_Frequency_Rem_Call_Struct = {
	-151, 6, 0, ExecuteSetParameter__Cos_STACK_Frequency_String_Params, 0, 
	ExecuteSetParameter__Cos_STACK_Frequency_Stack_Params
};
char * ExecuteSetParameter__Cos_STACK_Phase_String_Params[] = {
	"Cos", "Phase"
};

int ExecuteSetParameter__Cos_STACK_Phase_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Cos_STACK_Phase_Rem_Call_Struct = {
	-152, 6, 0, ExecuteSetParameter__Cos_STACK_Phase_String_Params, 0, 
	ExecuteSetParameter__Cos_STACK_Phase_Stack_Params
};
char * ExecuteSetParameter__Cos_STACK_Amplitude_String_Params[] = {
	"Cos", "Amplitude"
};

int ExecuteSetParameter__Cos_STACK_Amplitude_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Cos_STACK_Amplitude_Rem_Call_Struct = {
	-153, 6, 0, ExecuteSetParameter__Cos_STACK_Amplitude_String_Params, 0, 
	ExecuteSetParameter__Cos_STACK_Amplitude_Stack_Params
};
char * NodeDescribe__CxCos_String_Params[] = {
	"CxCos"
};

static CommandParameters NodeDescribe__CxCos_Rem_Call_Struct = {
	-154, 3, 0, NodeDescribe__CxCos_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__CxCos_String_Params[] = {
	"CxCos"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__CxCos_Rem_Call_Struct = {
	-155, 3, 0, CreateDefaultNodeInteractiveEntity__CxCos_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__CxCos_String_Params[] = {
	"CxCos"
};

static CommandParameters CreateNodeInteractiveEntity__CxCos_Rem_Call_Struct = {
	-156, 3, 0, CreateNodeInteractiveEntity__CxCos_String_Params, 0, 0
};
char * DescribeNodeInstance__CxCos_STACK_String_Params[] = {
	"CxCos"
};

int DescribeNodeInstance__CxCos_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__CxCos_STACK_Rem_Call_Struct = {
	-157, 4, 0, DescribeNodeInstance__CxCos_STACK_String_Params, 0, 
	DescribeNodeInstance__CxCos_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__CxCos_STACK_String_Params[] = {
	"CxCos"
};

int DeleteNodeInteractiveEntity__CxCos_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__CxCos_STACK_Rem_Call_Struct = {
	-158, 4, 0, DeleteNodeInteractiveEntity__CxCos_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__CxCos_STACK_Stack_Params
};
char * DescribeParam__CxCos_Frequency_String_Params[] = {
	"CxCos", "Frequency"
};

static CommandParameters DescribeParam__CxCos_Frequency_Rem_Call_Struct = {
	-159, 5, 0, DescribeParam__CxCos_Frequency_String_Params, 0, 0
};
char * DescribeParam__CxCos_Phase_String_Params[] = {
	"CxCos", "Phase"
};

static CommandParameters DescribeParam__CxCos_Phase_Rem_Call_Struct = {
	-160, 5, 0, DescribeParam__CxCos_Phase_String_Params, 0, 0
};
char * DescribeParam__CxCos_Amplitude_String_Params[] = {
	"CxCos", "Amplitude"
};

static CommandParameters DescribeParam__CxCos_Amplitude_Rem_Call_Struct = {
	-161, 5, 0, DescribeParam__CxCos_Amplitude_String_Params, 0, 0
};
char * DescribeParamInstance__CxCos_STACK_Frequency_String_Params[] = {
	"CxCos", "Frequency"
};

int DescribeParamInstance__CxCos_STACK_Frequency_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxCos_STACK_Frequency_Rem_Call_Struct = {
	-162, 6, 0, DescribeParamInstance__CxCos_STACK_Frequency_String_Params, 0, 
	DescribeParamInstance__CxCos_STACK_Frequency_Stack_Params
};
char * DescribeParamInstance__CxCos_STACK_Phase_String_Params[] = {
	"CxCos", "Phase"
};

int DescribeParamInstance__CxCos_STACK_Phase_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxCos_STACK_Phase_Rem_Call_Struct = {
	-163, 6, 0, DescribeParamInstance__CxCos_STACK_Phase_String_Params, 0, 
	DescribeParamInstance__CxCos_STACK_Phase_Stack_Params
};
char * DescribeParamInstance__CxCos_STACK_Amplitude_String_Params[] = {
	"CxCos", "Amplitude"
};

int DescribeParamInstance__CxCos_STACK_Amplitude_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxCos_STACK_Amplitude_Rem_Call_Struct = {
	-164, 6, 0, DescribeParamInstance__CxCos_STACK_Amplitude_String_Params, 0, 
	DescribeParamInstance__CxCos_STACK_Amplitude_Stack_Params
};
char * ExecuteSetParameter__CxCos_STACK_Frequency_String_Params[] = {
	"CxCos", "Frequency"
};

int ExecuteSetParameter__CxCos_STACK_Frequency_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CxCos_STACK_Frequency_Rem_Call_Struct = {
	-165, 6, 0, ExecuteSetParameter__CxCos_STACK_Frequency_String_Params, 0, 
	ExecuteSetParameter__CxCos_STACK_Frequency_Stack_Params
};
char * ExecuteSetParameter__CxCos_STACK_Phase_String_Params[] = {
	"CxCos", "Phase"
};

int ExecuteSetParameter__CxCos_STACK_Phase_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CxCos_STACK_Phase_Rem_Call_Struct = {
	-166, 6, 0, ExecuteSetParameter__CxCos_STACK_Phase_String_Params, 0, 
	ExecuteSetParameter__CxCos_STACK_Phase_Stack_Params
};
char * ExecuteSetParameter__CxCos_STACK_Amplitude_String_Params[] = {
	"CxCos", "Amplitude"
};

int ExecuteSetParameter__CxCos_STACK_Amplitude_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CxCos_STACK_Amplitude_Rem_Call_Struct = {
	-167, 6, 0, ExecuteSetParameter__CxCos_STACK_Amplitude_String_Params, 0, 
	ExecuteSetParameter__CxCos_STACK_Amplitude_Stack_Params
};
char * NodeDescribe__CxFFT_String_Params[] = {
	"CxFFT"
};

static CommandParameters NodeDescribe__CxFFT_Rem_Call_Struct = {
	-168, 3, 0, NodeDescribe__CxFFT_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__CxFFT_String_Params[] = {
	"CxFFT"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__CxFFT_Rem_Call_Struct = {
	-169, 3, 0, CreateDefaultNodeInteractiveEntity__CxFFT_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__CxFFT_String_Params[] = {
	"CxFFT"
};

static CommandParameters CreateNodeInteractiveEntity__CxFFT_Rem_Call_Struct = {
	-170, 3, 0, CreateNodeInteractiveEntity__CxFFT_String_Params, 0, 0
};
char * DescribeNodeInstance__CxFFT_STACK_String_Params[] = {
	"CxFFT"
};

int DescribeNodeInstance__CxFFT_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__CxFFT_STACK_Rem_Call_Struct = {
	-171, 4, 0, DescribeNodeInstance__CxFFT_STACK_String_Params, 0, 
	DescribeNodeInstance__CxFFT_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__CxFFT_STACK_String_Params[] = {
	"CxFFT"
};

int DeleteNodeInteractiveEntity__CxFFT_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__CxFFT_STACK_Rem_Call_Struct = {
	-172, 4, 0, DeleteNodeInteractiveEntity__CxFFT_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__CxFFT_STACK_Stack_Params
};
char * DescribeParam__CxFFT_LogSize_String_Params[] = {
	"CxFFT", "LogSize"
};

static CommandParameters DescribeParam__CxFFT_LogSize_Rem_Call_Struct = {
	-173, 5, 0, DescribeParam__CxFFT_LogSize_String_Params, 0, 0
};
char * DescribeParam__CxFFT_Overlap_String_Params[] = {
	"CxFFT", "Overlap"
};

static CommandParameters DescribeParam__CxFFT_Overlap_Rem_Call_Struct = {
	-174, 5, 0, DescribeParam__CxFFT_Overlap_String_Params, 0, 0
};
char * DescribeParam__CxFFT_CenterFrequency_String_Params[] = {
	"CxFFT", "CenterFrequency"
};

static CommandParameters DescribeParam__CxFFT_CenterFrequency_Rem_Call_Struct = {
	-175, 5, 0, DescribeParam__CxFFT_CenterFrequency_String_Params, 0, 0
};
char * DescribeParam__CxFFT_InverseFlag_String_Params[] = {
	"CxFFT", "InverseFlag"
};

static CommandParameters DescribeParam__CxFFT_InverseFlag_Rem_Call_Struct = {
	-176, 5, 0, DescribeParam__CxFFT_InverseFlag_String_Params, 0, 0
};
char * DescribeParamInstance__CxFFT_STACK_LogSize_String_Params[] = {
	"CxFFT", "LogSize"
};

int DescribeParamInstance__CxFFT_STACK_LogSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFFT_STACK_LogSize_Rem_Call_Struct = {
	-177, 6, 0, DescribeParamInstance__CxFFT_STACK_LogSize_String_Params, 0, 
	DescribeParamInstance__CxFFT_STACK_LogSize_Stack_Params
};
char * DescribeParamInstance__CxFFT_STACK_Overlap_String_Params[] = {
	"CxFFT", "Overlap"
};

int DescribeParamInstance__CxFFT_STACK_Overlap_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFFT_STACK_Overlap_Rem_Call_Struct = {
	-178, 6, 0, DescribeParamInstance__CxFFT_STACK_Overlap_String_Params, 0, 
	DescribeParamInstance__CxFFT_STACK_Overlap_Stack_Params
};
char * DescribeParamInstance__CxFFT_STACK_CenterFrequency_String_Params[] = {
	"CxFFT", "CenterFrequency"
};

int DescribeParamInstance__CxFFT_STACK_CenterFrequency_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFFT_STACK_CenterFrequency_Rem_Call_Struct = {
	-179, 6, 0, DescribeParamInstance__CxFFT_STACK_CenterFrequency_String_Params, 0, 
	DescribeParamInstance__CxFFT_STACK_CenterFrequency_Stack_Params
};
char * DescribeParamInstance__CxFFT_STACK_InverseFlag_String_Params[] = {
	"CxFFT", "InverseFlag"
};

int DescribeParamInstance__CxFFT_STACK_InverseFlag_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFFT_STACK_InverseFlag_Rem_Call_Struct = {
	-180, 6, 0, DescribeParamInstance__CxFFT_STACK_InverseFlag_String_Params, 0, 
	DescribeParamInstance__CxFFT_STACK_InverseFlag_Stack_Params
};
char * ExecuteSetParameter__CxFFT_STACK_CenterFrequency_String_Params[] = {
	"CxFFT", "CenterFrequency"
};

int ExecuteSetParameter__CxFFT_STACK_CenterFrequency_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CxFFT_STACK_CenterFrequency_Rem_Call_Struct = {
	-181, 6, 0, ExecuteSetParameter__CxFFT_STACK_CenterFrequency_String_Params, 0, 
	ExecuteSetParameter__CxFFT_STACK_CenterFrequency_Stack_Params
};
char * NodeDescribe__CxFir_String_Params[] = {
	"CxFir"
};

static CommandParameters NodeDescribe__CxFir_Rem_Call_Struct = {
	-182, 3, 0, NodeDescribe__CxFir_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__CxFir_String_Params[] = {
	"CxFir"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__CxFir_Rem_Call_Struct = {
	-183, 3, 0, CreateDefaultNodeInteractiveEntity__CxFir_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__CxFir_String_Params[] = {
	"CxFir"
};

static CommandParameters CreateNodeInteractiveEntity__CxFir_Rem_Call_Struct = {
	-184, 3, 0, CreateNodeInteractiveEntity__CxFir_String_Params, 0, 0
};
char * DescribeNodeInstance__CxFir_STACK_String_Params[] = {
	"CxFir"
};

int DescribeNodeInstance__CxFir_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__CxFir_STACK_Rem_Call_Struct = {
	-185, 4, 0, DescribeNodeInstance__CxFir_STACK_String_Params, 0, 
	DescribeNodeInstance__CxFir_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__CxFir_STACK_String_Params[] = {
	"CxFir"
};

int DeleteNodeInteractiveEntity__CxFir_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__CxFir_STACK_Rem_Call_Struct = {
	-186, 4, 0, DeleteNodeInteractiveEntity__CxFir_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__CxFir_STACK_Stack_Params
};
char * DescribeParam__CxFir_Resample_String_Params[] = {
	"CxFir", "Resample"
};

static CommandParameters DescribeParam__CxFir_Resample_Rem_Call_Struct = {
	-187, 5, 0, DescribeParam__CxFir_Resample_String_Params, 0, 0
};
char * DescribeParam__CxFir_ZeroPad_String_Params[] = {
	"CxFir", "ZeroPad"
};

static CommandParameters DescribeParam__CxFir_ZeroPad_Rem_Call_Struct = {
	-188, 5, 0, DescribeParam__CxFir_ZeroPad_String_Params, 0, 0
};
char * DescribeParam__CxFir_DemodFreq_String_Params[] = {
	"CxFir", "DemodFreq"
};

static CommandParameters DescribeParam__CxFir_DemodFreq_Rem_Call_Struct = {
	-189, 5, 0, DescribeParam__CxFir_DemodFreq_String_Params, 0, 0
};
char * DescribeParam__CxFir_Odd_String_Params[] = {
	"CxFir", "Odd"
};

static CommandParameters DescribeParam__CxFir_Odd_Rem_Call_Struct = {
	-190, 5, 0, DescribeParam__CxFir_Odd_String_Params, 0, 0
};
char * DescribeParam__CxFir_Coeff_String_Params[] = {
	"CxFir", "Coeff"
};

static CommandParameters DescribeParam__CxFir_Coeff_Rem_Call_Struct = {
	-191, 5, 0, DescribeParam__CxFir_Coeff_String_Params, 0, 0
};
char * DescribeParamInstance__CxFir_STACK_Resample_String_Params[] = {
	"CxFir", "Resample"
};

int DescribeParamInstance__CxFir_STACK_Resample_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFir_STACK_Resample_Rem_Call_Struct = {
	-192, 6, 0, DescribeParamInstance__CxFir_STACK_Resample_String_Params, 0, 
	DescribeParamInstance__CxFir_STACK_Resample_Stack_Params
};
char * DescribeParamInstance__CxFir_STACK_ZeroPad_String_Params[] = {
	"CxFir", "ZeroPad"
};

int DescribeParamInstance__CxFir_STACK_ZeroPad_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFir_STACK_ZeroPad_Rem_Call_Struct = {
	-193, 6, 0, DescribeParamInstance__CxFir_STACK_ZeroPad_String_Params, 0, 
	DescribeParamInstance__CxFir_STACK_ZeroPad_Stack_Params
};
char * DescribeParamInstance__CxFir_STACK_DemodFreq_String_Params[] = {
	"CxFir", "DemodFreq"
};

int DescribeParamInstance__CxFir_STACK_DemodFreq_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFir_STACK_DemodFreq_Rem_Call_Struct = {
	-194, 6, 0, DescribeParamInstance__CxFir_STACK_DemodFreq_String_Params, 0, 
	DescribeParamInstance__CxFir_STACK_DemodFreq_Stack_Params
};
char * DescribeParamInstance__CxFir_STACK_Odd_String_Params[] = {
	"CxFir", "Odd"
};

int DescribeParamInstance__CxFir_STACK_Odd_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFir_STACK_Odd_Rem_Call_Struct = {
	-195, 6, 0, DescribeParamInstance__CxFir_STACK_Odd_String_Params, 0, 
	DescribeParamInstance__CxFir_STACK_Odd_Stack_Params
};
char * DescribeParamInstance__CxFir_STACK_Coeff_String_Params[] = {
	"CxFir", "Coeff"
};

int DescribeParamInstance__CxFir_STACK_Coeff_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFir_STACK_Coeff_Rem_Call_Struct = {
	-196, 6, 0, DescribeParamInstance__CxFir_STACK_Coeff_String_Params, 0, 
	DescribeParamInstance__CxFir_STACK_Coeff_Stack_Params
};
char * ExecuteSetParameter__CxFir_STACK_DemodFreq_String_Params[] = {
	"CxFir", "DemodFreq"
};

int ExecuteSetParameter__CxFir_STACK_DemodFreq_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CxFir_STACK_DemodFreq_Rem_Call_Struct = {
	-197, 6, 0, ExecuteSetParameter__CxFir_STACK_DemodFreq_String_Params, 0, 
	ExecuteSetParameter__CxFir_STACK_DemodFreq_Stack_Params
};
char * NodeDescribe__SampleDelay_String_Params[] = {
	"SampleDelay"
};

static CommandParameters NodeDescribe__SampleDelay_Rem_Call_Struct = {
	-198, 3, 0, NodeDescribe__SampleDelay_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__SampleDelay_String_Params[] = {
	"SampleDelay"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__SampleDelay_Rem_Call_Struct = {
	-199, 3, 0, CreateDefaultNodeInteractiveEntity__SampleDelay_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__SampleDelay_String_Params[] = {
	"SampleDelay"
};

static CommandParameters CreateNodeInteractiveEntity__SampleDelay_Rem_Call_Struct = {
	-200, 3, 0, CreateNodeInteractiveEntity__SampleDelay_String_Params, 0, 0
};
char * DescribeNodeInstance__SampleDelay_STACK_String_Params[] = {
	"SampleDelay"
};

int DescribeNodeInstance__SampleDelay_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__SampleDelay_STACK_Rem_Call_Struct = {
	-201, 4, 0, DescribeNodeInstance__SampleDelay_STACK_String_Params, 0, 
	DescribeNodeInstance__SampleDelay_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__SampleDelay_STACK_String_Params[] = {
	"SampleDelay"
};

int DeleteNodeInteractiveEntity__SampleDelay_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__SampleDelay_STACK_Rem_Call_Struct = {
	-202, 4, 0, DeleteNodeInteractiveEntity__SampleDelay_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__SampleDelay_STACK_Stack_Params
};
char * DescribeParam__SampleDelay_Delta_String_Params[] = {
	"SampleDelay", "Delta"
};

static CommandParameters DescribeParam__SampleDelay_Delta_Rem_Call_Struct = {
	-203, 5, 0, DescribeParam__SampleDelay_Delta_String_Params, 0, 0
};
char * DescribeParam__SampleDelay_FillValue_String_Params[] = {
	"SampleDelay", "FillValue"
};

static CommandParameters DescribeParam__SampleDelay_FillValue_Rem_Call_Struct = {
	-204, 5, 0, DescribeParam__SampleDelay_FillValue_String_Params, 0, 0
};
char * DescribeParamInstance__SampleDelay_STACK_Delta_String_Params[] = {
	"SampleDelay", "Delta"
};

int DescribeParamInstance__SampleDelay_STACK_Delta_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__SampleDelay_STACK_Delta_Rem_Call_Struct = {
	-205, 6, 0, DescribeParamInstance__SampleDelay_STACK_Delta_String_Params, 0, 
	DescribeParamInstance__SampleDelay_STACK_Delta_Stack_Params
};
char * DescribeParamInstance__SampleDelay_STACK_FillValue_String_Params[] = {
	"SampleDelay", "FillValue"
};

int DescribeParamInstance__SampleDelay_STACK_FillValue_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__SampleDelay_STACK_FillValue_Rem_Call_Struct = {
	-206, 6, 0, DescribeParamInstance__SampleDelay_STACK_FillValue_String_Params, 0, 
	DescribeParamInstance__SampleDelay_STACK_FillValue_Stack_Params
};
char * NodeDescribe__Demod_String_Params[] = {
	"Demod"
};

static CommandParameters NodeDescribe__Demod_Rem_Call_Struct = {
	-207, 3, 0, NodeDescribe__Demod_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Demod_String_Params[] = {
	"Demod"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Demod_Rem_Call_Struct = {
	-208, 3, 0, CreateDefaultNodeInteractiveEntity__Demod_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Demod_String_Params[] = {
	"Demod"
};

static CommandParameters CreateNodeInteractiveEntity__Demod_Rem_Call_Struct = {
	-209, 3, 0, CreateNodeInteractiveEntity__Demod_String_Params, 0, 0
};
char * DescribeNodeInstance__Demod_STACK_String_Params[] = {
	"Demod"
};

int DescribeNodeInstance__Demod_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Demod_STACK_Rem_Call_Struct = {
	-210, 4, 0, DescribeNodeInstance__Demod_STACK_String_Params, 0, 
	DescribeNodeInstance__Demod_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Demod_STACK_String_Params[] = {
	"Demod"
};

int DeleteNodeInteractiveEntity__Demod_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Demod_STACK_Rem_Call_Struct = {
	-211, 4, 0, DeleteNodeInteractiveEntity__Demod_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Demod_STACK_Stack_Params
};
char * DescribeParam__Demod_DataType_String_Params[] = {
	"Demod", "DataType"
};

static CommandParameters DescribeParam__Demod_DataType_Rem_Call_Struct = {
	-212, 5, 0, DescribeParam__Demod_DataType_String_Params, 0, 0
};
char * DescribeParam__Demod_DemodFreq_String_Params[] = {
	"Demod", "DemodFreq"
};

static CommandParameters DescribeParam__Demod_DemodFreq_Rem_Call_Struct = {
	-213, 5, 0, DescribeParam__Demod_DemodFreq_String_Params, 0, 0
};
char * DescribeParamInstance__Demod_STACK_DataType_String_Params[] = {
	"Demod", "DataType"
};

int DescribeParamInstance__Demod_STACK_DataType_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Demod_STACK_DataType_Rem_Call_Struct = {
	-214, 6, 0, DescribeParamInstance__Demod_STACK_DataType_String_Params, 0, 
	DescribeParamInstance__Demod_STACK_DataType_Stack_Params
};
char * DescribeParamInstance__Demod_STACK_DemodFreq_String_Params[] = {
	"Demod", "DemodFreq"
};

int DescribeParamInstance__Demod_STACK_DemodFreq_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Demod_STACK_DemodFreq_Rem_Call_Struct = {
	-215, 6, 0, DescribeParamInstance__Demod_STACK_DemodFreq_String_Params, 0, 
	DescribeParamInstance__Demod_STACK_DemodFreq_Stack_Params
};
char * ExecuteSetParameter__Demod_STACK_DemodFreq_String_Params[] = {
	"Demod", "DemodFreq"
};

int ExecuteSetParameter__Demod_STACK_DemodFreq_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Demod_STACK_DemodFreq_Rem_Call_Struct = {
	-216, 6, 0, ExecuteSetParameter__Demod_STACK_DemodFreq_String_Params, 0, 
	ExecuteSetParameter__Demod_STACK_DemodFreq_Stack_Params
};
char * NodeDescribe__Demux_String_Params[] = {
	"Demux"
};

static CommandParameters NodeDescribe__Demux_Rem_Call_Struct = {
	-217, 3, 0, NodeDescribe__Demux_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Demux_String_Params[] = {
	"Demux"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Demux_Rem_Call_Struct = {
	-218, 3, 0, CreateDefaultNodeInteractiveEntity__Demux_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Demux_String_Params[] = {
	"Demux"
};

static CommandParameters CreateNodeInteractiveEntity__Demux_Rem_Call_Struct = {
	-219, 3, 0, CreateNodeInteractiveEntity__Demux_String_Params, 0, 0
};
char * DescribeNodeInstance__Demux_STACK_String_Params[] = {
	"Demux"
};

int DescribeNodeInstance__Demux_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Demux_STACK_Rem_Call_Struct = {
	-220, 4, 0, DescribeNodeInstance__Demux_STACK_String_Params, 0, 
	DescribeNodeInstance__Demux_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Demux_STACK_String_Params[] = {
	"Demux"
};

int DeleteNodeInteractiveEntity__Demux_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Demux_STACK_Rem_Call_Struct = {
	-221, 4, 0, DeleteNodeInteractiveEntity__Demux_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Demux_STACK_Stack_Params
};
char * DescribeParam__Demux_Channels_String_Params[] = {
	"Demux", "Channels"
};

static CommandParameters DescribeParam__Demux_Channels_Rem_Call_Struct = {
	-222, 5, 0, DescribeParam__Demux_Channels_String_Params, 0, 0
};
char * DescribeParam__Demux_InputSampleSize_String_Params[] = {
	"Demux", "InputSampleSize"
};

static CommandParameters DescribeParam__Demux_InputSampleSize_Rem_Call_Struct = {
	-223, 5, 0, DescribeParam__Demux_InputSampleSize_String_Params, 0, 0
};
char * DescribeParam__Demux_InputElementSize_String_Params[] = {
	"Demux", "InputElementSize"
};

static CommandParameters DescribeParam__Demux_InputElementSize_Rem_Call_Struct = {
	-224, 5, 0, DescribeParam__Demux_InputElementSize_String_Params, 0, 0
};
char * DescribeParam__Demux_OutputElementSize_String_Params[] = {
	"Demux", "OutputElementSize"
};

static CommandParameters DescribeParam__Demux_OutputElementSize_Rem_Call_Struct = {
	-225, 5, 0, DescribeParam__Demux_OutputElementSize_String_Params, 0, 0
};
char * DescribeParamInstance__Demux_STACK_Channels_String_Params[] = {
	"Demux", "Channels"
};

int DescribeParamInstance__Demux_STACK_Channels_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Demux_STACK_Channels_Rem_Call_Struct = {
	-226, 6, 0, DescribeParamInstance__Demux_STACK_Channels_String_Params, 0, 
	DescribeParamInstance__Demux_STACK_Channels_Stack_Params
};
char * DescribeParamInstance__Demux_STACK_InputSampleSize_String_Params[] = {
	"Demux", "InputSampleSize"
};

int DescribeParamInstance__Demux_STACK_InputSampleSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Demux_STACK_InputSampleSize_Rem_Call_Struct = {
	-227, 6, 0, DescribeParamInstance__Demux_STACK_InputSampleSize_String_Params, 0, 
	DescribeParamInstance__Demux_STACK_InputSampleSize_Stack_Params
};
char * DescribeParamInstance__Demux_STACK_InputElementSize_String_Params[] = {
	"Demux", "InputElementSize"
};

int DescribeParamInstance__Demux_STACK_InputElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Demux_STACK_InputElementSize_Rem_Call_Struct = {
	-228, 6, 0, DescribeParamInstance__Demux_STACK_InputElementSize_String_Params, 0, 
	DescribeParamInstance__Demux_STACK_InputElementSize_Stack_Params
};
char * DescribeParamInstance__Demux_STACK_OutputElementSize_String_Params[] = {
	"Demux", "OutputElementSize"
};

int DescribeParamInstance__Demux_STACK_OutputElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Demux_STACK_OutputElementSize_Rem_Call_Struct = {
	-229, 6, 0, DescribeParamInstance__Demux_STACK_OutputElementSize_String_Params, 
	0, DescribeParamInstance__Demux_STACK_OutputElementSize_Stack_Params
};
char * MemberFunctionDescribe__DisplayNodeStr_STACK_String_Params[] = {
	"DisplayNodeStr"
};

int MemberFunctionDescribe__DisplayNodeStr_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__DisplayNodeStr_STACK_Rem_Call_Struct = {
	-230, 4, 0, MemberFunctionDescribe__DisplayNodeStr_STACK_String_Params, 0, 
	MemberFunctionDescribe__DisplayNodeStr_STACK_Stack_Params
};
char * DescribeMemberFunctionParameter__DisplayNodeStr_STACK_Channel_String_Params[] = {
	"DisplayNodeStr", "Channel"
};

int DescribeMemberFunctionParameter__DisplayNodeStr_STACK_Channel_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__DisplayNodeStr_STACK_Channel_Rem_Call_Struct = {
	-231, 6, 0, 
	DescribeMemberFunctionParameter__DisplayNodeStr_STACK_Channel_String_Params, 0, 
	DescribeMemberFunctionParameter__DisplayNodeStr_STACK_Channel_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_Raise_String_Params[] = {
	"Raise"
};

int ExecuteMemberFunction__STACK_STACK_Raise_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_Raise_Rem_Call_Struct = {
	-232, 7, 0, ExecuteMemberFunction__STACK_STACK_Raise_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_Raise_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_DisplayInputTiming_String_Params[] = {
	"DisplayInputTiming"
};

int ExecuteMemberFunction__STACK_STACK_DisplayInputTiming_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_DisplayInputTiming_Rem_Call_Struct = {
	-233, 7, 0, ExecuteMemberFunction__STACK_STACK_DisplayInputTiming_String_Params, 
	0, ExecuteMemberFunction__STACK_STACK_DisplayInputTiming_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_Edit_String_Params[] = {
	"Edit"
};

int ExecuteMemberFunction__STACK_STACK_Edit_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_Edit_Rem_Call_Struct = {
	-234, 7, 0, ExecuteMemberFunction__STACK_STACK_Edit_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_Edit_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_Unlink_String_Params[] = {
	"Unlink"
};

int ExecuteMemberFunction__STACK_STACK_Unlink_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_Unlink_Rem_Call_Struct = {
	-235, 7, 0, ExecuteMemberFunction__STACK_STACK_Unlink_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_Unlink_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_LinkIn_String_Params[] = {
	"LinkIn"
};

int ExecuteMemberFunction__STACK_STACK_LinkIn_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_LinkIn_Rem_Call_Struct = {
	-236, 7, 0, ExecuteMemberFunction__STACK_STACK_LinkIn_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_LinkIn_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_NextFreeInput_String_Params[] = {
	"NextFreeInput"
};

int ExecuteMemberFunction__STACK_STACK_NextFreeInput_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_NextFreeInput_Rem_Call_Struct = {
	-237, 7, 0, ExecuteMemberFunction__STACK_STACK_NextFreeInput_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_NextFreeInput_Stack_Params
};
char * NodeDescribe__Listing_String_Params[] = {
	"Listing"
};

static CommandParameters NodeDescribe__Listing_Rem_Call_Struct = {
	-238, 3, 0, NodeDescribe__Listing_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Listing_String_Params[] = {
	"Listing"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Listing_Rem_Call_Struct = {
	-239, 3, 0, CreateDefaultNodeInteractiveEntity__Listing_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Listing_String_Params[] = {
	"Listing"
};

static CommandParameters CreateNodeInteractiveEntity__Listing_Rem_Call_Struct = {
	-240, 3, 0, CreateNodeInteractiveEntity__Listing_String_Params, 0, 0
};
char * DescribeNodeInstance__Listing_STACK_String_Params[] = {
	"Listing"
};

int DescribeNodeInstance__Listing_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Listing_STACK_Rem_Call_Struct = {
	-241, 4, 0, DescribeNodeInstance__Listing_STACK_String_Params, 0, 
	DescribeNodeInstance__Listing_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Listing_STACK_String_Params[] = {
	"Listing"
};

int DeleteNodeInteractiveEntity__Listing_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Listing_STACK_Rem_Call_Struct = {
	-242, 4, 0, DeleteNodeInteractiveEntity__Listing_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Listing_STACK_Stack_Params
};
char * DescribeParam__Listing_Binary_String_Params[] = {
	"Listing", "Binary"
};

static CommandParameters DescribeParam__Listing_Binary_Rem_Call_Struct = {
	-243, 5, 0, DescribeParam__Listing_Binary_String_Params, 0, 0
};
char * DescribeParam__Listing_TimeFlag_String_Params[] = {
	"Listing", "TimeFlag"
};

static CommandParameters DescribeParam__Listing_TimeFlag_Rem_Call_Struct = {
	-244, 5, 0, DescribeParam__Listing_TimeFlag_String_Params, 0, 0
};
char * DescribeParam__Listing_Caption_String_Params[] = {
	"Listing", "Caption"
};

static CommandParameters DescribeParam__Listing_Caption_Rem_Call_Struct = {
	-245, 5, 0, DescribeParam__Listing_Caption_String_Params, 0, 0
};
char * DescribeParamInstance__Listing_STACK_Binary_String_Params[] = {
	"Listing", "Binary"
};

int DescribeParamInstance__Listing_STACK_Binary_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Listing_STACK_Binary_Rem_Call_Struct = {
	-246, 6, 0, DescribeParamInstance__Listing_STACK_Binary_String_Params, 0, 
	DescribeParamInstance__Listing_STACK_Binary_Stack_Params
};
char * DescribeParamInstance__Listing_STACK_TimeFlag_String_Params[] = {
	"Listing", "TimeFlag"
};

int DescribeParamInstance__Listing_STACK_TimeFlag_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Listing_STACK_TimeFlag_Rem_Call_Struct = {
	-247, 6, 0, DescribeParamInstance__Listing_STACK_TimeFlag_String_Params, 0, 
	DescribeParamInstance__Listing_STACK_TimeFlag_Stack_Params
};
char * DescribeParamInstance__Listing_STACK_Caption_String_Params[] = {
	"Listing", "Caption"
};

int DescribeParamInstance__Listing_STACK_Caption_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Listing_STACK_Caption_Rem_Call_Struct = {
	-248, 6, 0, DescribeParamInstance__Listing_STACK_Caption_String_Params, 0, 
	DescribeParamInstance__Listing_STACK_Caption_Stack_Params
};
char * ExecuteSetParameter__Listing_STACK_Binary_String_Params[] = {
	"Listing", "Binary"
};

int ExecuteSetParameter__Listing_STACK_Binary_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Listing_STACK_Binary_Rem_Call_Struct = {
	-249, 6, 0, ExecuteSetParameter__Listing_STACK_Binary_String_Params, 0, 
	ExecuteSetParameter__Listing_STACK_Binary_Stack_Params
};
char * ExecuteSetParameter__Listing_STACK_TimeFlag_String_Params[] = {
	"Listing", "TimeFlag"
};

int ExecuteSetParameter__Listing_STACK_TimeFlag_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Listing_STACK_TimeFlag_Rem_Call_Struct = {
	-250, 6, 0, ExecuteSetParameter__Listing_STACK_TimeFlag_String_Params, 0, 
	ExecuteSetParameter__Listing_STACK_TimeFlag_Stack_Params
};
char * NodeDescribe__Plot_String_Params[] = {
	"Plot"
};

static CommandParameters NodeDescribe__Plot_Rem_Call_Struct = {
	-251, 3, 0, NodeDescribe__Plot_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Plot_String_Params[] = {
	"Plot"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Plot_Rem_Call_Struct = {
	-252, 3, 0, CreateDefaultNodeInteractiveEntity__Plot_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Plot_String_Params[] = {
	"Plot"
};

static CommandParameters CreateNodeInteractiveEntity__Plot_Rem_Call_Struct = {
	-253, 3, 0, CreateNodeInteractiveEntity__Plot_String_Params, 0, 0
};
char * DescribeNodeInstance__Plot_STACK_String_Params[] = {
	"Plot"
};

int DescribeNodeInstance__Plot_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Plot_STACK_Rem_Call_Struct = {
	-254, 4, 0, DescribeNodeInstance__Plot_STACK_String_Params, 0, 
	DescribeNodeInstance__Plot_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Plot_STACK_String_Params[] = {
	"Plot"
};

int DeleteNodeInteractiveEntity__Plot_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Plot_STACK_Rem_Call_Struct = {
	-255, 4, 0, DeleteNodeInteractiveEntity__Plot_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Plot_STACK_Stack_Params
};
char * DescribeParam__Plot_Caption_String_Params[] = {
	"Plot", "Caption"
};

static CommandParameters DescribeParam__Plot_Caption_Rem_Call_Struct = {
	-256, 5, 0, DescribeParam__Plot_Caption_String_Params, 0, 0
};
char * DescribeParam__Plot_Min_String_Params[] = {
	"Plot", "Min"
};

static CommandParameters DescribeParam__Plot_Min_Rem_Call_Struct = {
	-257, 5, 0, DescribeParam__Plot_Min_String_Params, 0, 0
};
char * DescribeParam__Plot_Max_String_Params[] = {
	"Plot", "Max"
};

static CommandParameters DescribeParam__Plot_Max_Rem_Call_Struct = {
	-258, 5, 0, DescribeParam__Plot_Max_String_Params, 0, 0
};
char * DescribeParamInstance__Plot_STACK_Caption_String_Params[] = {
	"Plot", "Caption"
};

int DescribeParamInstance__Plot_STACK_Caption_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Plot_STACK_Caption_Rem_Call_Struct = {
	-259, 6, 0, DescribeParamInstance__Plot_STACK_Caption_String_Params, 0, 
	DescribeParamInstance__Plot_STACK_Caption_Stack_Params
};
char * DescribeParamInstance__Plot_STACK_Min_String_Params[] = {
	"Plot", "Min"
};

int DescribeParamInstance__Plot_STACK_Min_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Plot_STACK_Min_Rem_Call_Struct = {
	-260, 6, 0, DescribeParamInstance__Plot_STACK_Min_String_Params, 0, 
	DescribeParamInstance__Plot_STACK_Min_Stack_Params
};
char * DescribeParamInstance__Plot_STACK_Max_String_Params[] = {
	"Plot", "Max"
};

int DescribeParamInstance__Plot_STACK_Max_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Plot_STACK_Max_Rem_Call_Struct = {
	-261, 6, 0, DescribeParamInstance__Plot_STACK_Max_String_Params, 0, 
	DescribeParamInstance__Plot_STACK_Max_Stack_Params
};
char * NodeDescribe__FindStartTail_String_Params[] = {
	"FindStartTail"
};

static CommandParameters NodeDescribe__FindStartTail_Rem_Call_Struct = {
	-262, 3, 0, NodeDescribe__FindStartTail_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__FindStartTail_String_Params[] = {
	"FindStartTail"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__FindStartTail_Rem_Call_Struct = {
	-263, 3, 0, CreateDefaultNodeInteractiveEntity__FindStartTail_String_Params, 0, 
	0
};
char * CreateNodeInteractiveEntity__FindStartTail_String_Params[] = {
	"FindStartTail"
};

static CommandParameters CreateNodeInteractiveEntity__FindStartTail_Rem_Call_Struct = {
	-264, 3, 0, CreateNodeInteractiveEntity__FindStartTail_String_Params, 0, 0
};
char * DescribeNodeInstance__FindStartTail_STACK_String_Params[] = {
	"FindStartTail"
};

int DescribeNodeInstance__FindStartTail_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__FindStartTail_STACK_Rem_Call_Struct = {
	-265, 4, 0, DescribeNodeInstance__FindStartTail_STACK_String_Params, 0, 
	DescribeNodeInstance__FindStartTail_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__FindStartTail_STACK_String_Params[] = {
	"FindStartTail"
};

int DeleteNodeInteractiveEntity__FindStartTail_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__FindStartTail_STACK_Rem_Call_Struct = {
	-266, 4, 0, DeleteNodeInteractiveEntity__FindStartTail_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__FindStartTail_STACK_Stack_Params
};
char * DescribeParam__FindStartTail_LowerBound_String_Params[] = {
	"FindStartTail", "LowerBound"
};

static CommandParameters DescribeParam__FindStartTail_LowerBound_Rem_Call_Struct = {
	-267, 5, 0, DescribeParam__FindStartTail_LowerBound_String_Params, 0, 0
};
char * DescribeParam__FindStartTail_UpperBound_String_Params[] = {
	"FindStartTail", "UpperBound"
};

static CommandParameters DescribeParam__FindStartTail_UpperBound_Rem_Call_Struct = {
	-268, 5, 0, DescribeParam__FindStartTail_UpperBound_String_Params, 0, 0
};
char * DescribeParam__FindStartTail_Flags_String_Params[] = {
	"FindStartTail", "Flags"
};

static CommandParameters DescribeParam__FindStartTail_Flags_Rem_Call_Struct = {
	-269, 5, 0, DescribeParam__FindStartTail_Flags_String_Params, 0, 0
};
char * DescribeParam__FindStartTail_Skip_String_Params[] = {
	"FindStartTail", "Skip"
};

static CommandParameters DescribeParam__FindStartTail_Skip_Rem_Call_Struct = {
	-270, 5, 0, DescribeParam__FindStartTail_Skip_String_Params, 0, 0
};
char * DescribeParamInstance__FindStartTail_STACK_LowerBound_String_Params[] = {
	"FindStartTail", "LowerBound"
};

int DescribeParamInstance__FindStartTail_STACK_LowerBound_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__FindStartTail_STACK_LowerBound_Rem_Call_Struct = {
	-271, 6, 0, DescribeParamInstance__FindStartTail_STACK_LowerBound_String_Params, 
	0, DescribeParamInstance__FindStartTail_STACK_LowerBound_Stack_Params
};
char * DescribeParamInstance__FindStartTail_STACK_UpperBound_String_Params[] = {
	"FindStartTail", "UpperBound"
};

int DescribeParamInstance__FindStartTail_STACK_UpperBound_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__FindStartTail_STACK_UpperBound_Rem_Call_Struct = {
	-272, 6, 0, DescribeParamInstance__FindStartTail_STACK_UpperBound_String_Params, 
	0, DescribeParamInstance__FindStartTail_STACK_UpperBound_Stack_Params
};
char * DescribeParamInstance__FindStartTail_STACK_Flags_String_Params[] = {
	"FindStartTail", "Flags"
};

int DescribeParamInstance__FindStartTail_STACK_Flags_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__FindStartTail_STACK_Flags_Rem_Call_Struct = {
	-273, 6, 0, DescribeParamInstance__FindStartTail_STACK_Flags_String_Params, 0, 
	DescribeParamInstance__FindStartTail_STACK_Flags_Stack_Params
};
char * DescribeParamInstance__FindStartTail_STACK_Skip_String_Params[] = {
	"FindStartTail", "Skip"
};

int DescribeParamInstance__FindStartTail_STACK_Skip_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__FindStartTail_STACK_Skip_Rem_Call_Struct = {
	-274, 6, 0, DescribeParamInstance__FindStartTail_STACK_Skip_String_Params, 0, 
	DescribeParamInstance__FindStartTail_STACK_Skip_Stack_Params
};
char * NodeDescribe__Gain_String_Params[] = {
	"Gain"
};

static CommandParameters NodeDescribe__Gain_Rem_Call_Struct = {
	-275, 3, 0, NodeDescribe__Gain_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Gain_String_Params[] = {
	"Gain"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Gain_Rem_Call_Struct = {
	-276, 3, 0, CreateDefaultNodeInteractiveEntity__Gain_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Gain_String_Params[] = {
	"Gain"
};

static CommandParameters CreateNodeInteractiveEntity__Gain_Rem_Call_Struct = {
	-277, 3, 0, CreateNodeInteractiveEntity__Gain_String_Params, 0, 0
};
char * DescribeNodeInstance__Gain_STACK_String_Params[] = {
	"Gain"
};

int DescribeNodeInstance__Gain_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Gain_STACK_Rem_Call_Struct = {
	-278, 4, 0, DescribeNodeInstance__Gain_STACK_String_Params, 0, 
	DescribeNodeInstance__Gain_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Gain_STACK_String_Params[] = {
	"Gain"
};

int DeleteNodeInteractiveEntity__Gain_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Gain_STACK_Rem_Call_Struct = {
	-279, 4, 0, DeleteNodeInteractiveEntity__Gain_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Gain_STACK_Stack_Params
};
char * DescribeParam__Gain_Scale_String_Params[] = {
	"Gain", "Scale"
};

static CommandParameters DescribeParam__Gain_Scale_Rem_Call_Struct = {
	-280, 5, 0, DescribeParam__Gain_Scale_String_Params, 0, 0
};
char * DescribeParamInstance__Gain_STACK_Scale_String_Params[] = {
	"Gain", "Scale"
};

int DescribeParamInstance__Gain_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Gain_STACK_Scale_Rem_Call_Struct = {
	-281, 6, 0, DescribeParamInstance__Gain_STACK_Scale_String_Params, 0, 
	DescribeParamInstance__Gain_STACK_Scale_Stack_Params
};
char * ExecuteSetParameter__Gain_STACK_Scale_String_Params[] = {
	"Gain", "Scale"
};

int ExecuteSetParameter__Gain_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Gain_STACK_Scale_Rem_Call_Struct = {
	-282, 6, 0, ExecuteSetParameter__Gain_STACK_Scale_String_Params, 0, 
	ExecuteSetParameter__Gain_STACK_Scale_Stack_Params
};
char * NodeDescribe__GainPad_String_Params[] = {
	"GainPad"
};

static CommandParameters NodeDescribe__GainPad_Rem_Call_Struct = {
	-283, 3, 0, NodeDescribe__GainPad_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__GainPad_String_Params[] = {
	"GainPad"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__GainPad_Rem_Call_Struct = {
	-284, 3, 0, CreateDefaultNodeInteractiveEntity__GainPad_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__GainPad_String_Params[] = {
	"GainPad"
};

static CommandParameters CreateNodeInteractiveEntity__GainPad_Rem_Call_Struct = {
	-285, 3, 0, CreateNodeInteractiveEntity__GainPad_String_Params, 0, 0
};
char * DescribeNodeInstance__GainPad_STACK_String_Params[] = {
	"GainPad"
};

int DescribeNodeInstance__GainPad_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__GainPad_STACK_Rem_Call_Struct = {
	-286, 4, 0, DescribeNodeInstance__GainPad_STACK_String_Params, 0, 
	DescribeNodeInstance__GainPad_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__GainPad_STACK_String_Params[] = {
	"GainPad"
};

int DeleteNodeInteractiveEntity__GainPad_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__GainPad_STACK_Rem_Call_Struct = {
	-287, 4, 0, DeleteNodeInteractiveEntity__GainPad_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__GainPad_STACK_Stack_Params
};
char * DescribeParam__GainPad_Scale_String_Params[] = {
	"GainPad", "Scale"
};

static CommandParameters DescribeParam__GainPad_Scale_Rem_Call_Struct = {
	-288, 5, 0, DescribeParam__GainPad_Scale_String_Params, 0, 0
};
char * DescribeParam__GainPad_ElementSize_String_Params[] = {
	"GainPad", "ElementSize"
};

static CommandParameters DescribeParam__GainPad_ElementSize_Rem_Call_Struct = {
	-289, 5, 0, DescribeParam__GainPad_ElementSize_String_Params, 0, 0
};
char * DescribeParam__GainPad_NullOutputSample_String_Params[] = {
	"GainPad", "NullOutputSample"
};

static CommandParameters DescribeParam__GainPad_NullOutputSample_Rem_Call_Struct = {
	-290, 5, 0, DescribeParam__GainPad_NullOutputSample_String_Params, 0, 0
};
char * DescribeParamInstance__GainPad_STACK_Scale_String_Params[] = {
	"GainPad", "Scale"
};

int DescribeParamInstance__GainPad_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__GainPad_STACK_Scale_Rem_Call_Struct = {
	-291, 6, 0, DescribeParamInstance__GainPad_STACK_Scale_String_Params, 0, 
	DescribeParamInstance__GainPad_STACK_Scale_Stack_Params
};
char * DescribeParamInstance__GainPad_STACK_ElementSize_String_Params[] = {
	"GainPad", "ElementSize"
};

int DescribeParamInstance__GainPad_STACK_ElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__GainPad_STACK_ElementSize_Rem_Call_Struct = {
	-292, 6, 0, DescribeParamInstance__GainPad_STACK_ElementSize_String_Params, 0, 
	DescribeParamInstance__GainPad_STACK_ElementSize_Stack_Params
};
char * DescribeParamInstance__GainPad_STACK_NullOutputSample_String_Params[] = {
	"GainPad", "NullOutputSample"
};

int DescribeParamInstance__GainPad_STACK_NullOutputSample_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__GainPad_STACK_NullOutputSample_Rem_Call_Struct = {
	-293, 6, 0, DescribeParamInstance__GainPad_STACK_NullOutputSample_String_Params, 
	0, DescribeParamInstance__GainPad_STACK_NullOutputSample_Stack_Params
};
char * ExecuteSetParameter__GainPad_STACK_Scale_String_Params[] = {
	"GainPad", "Scale"
};

int ExecuteSetParameter__GainPad_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__GainPad_STACK_Scale_Rem_Call_Struct = {
	-294, 6, 0, ExecuteSetParameter__GainPad_STACK_Scale_String_Params, 0, 
	ExecuteSetParameter__GainPad_STACK_Scale_Stack_Params
};
char * NodeDescribe__HexList_String_Params[] = {
	"HexList"
};

static CommandParameters NodeDescribe__HexList_Rem_Call_Struct = {
	-295, 3, 0, NodeDescribe__HexList_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__HexList_String_Params[] = {
	"HexList"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__HexList_Rem_Call_Struct = {
	-296, 3, 0, CreateDefaultNodeInteractiveEntity__HexList_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__HexList_String_Params[] = {
	"HexList"
};

static CommandParameters CreateNodeInteractiveEntity__HexList_Rem_Call_Struct = {
	-297, 3, 0, CreateNodeInteractiveEntity__HexList_String_Params, 0, 0
};
char * DescribeNodeInstance__HexList_STACK_String_Params[] = {
	"HexList"
};

int DescribeNodeInstance__HexList_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__HexList_STACK_Rem_Call_Struct = {
	-298, 4, 0, DescribeNodeInstance__HexList_STACK_String_Params, 0, 
	DescribeNodeInstance__HexList_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__HexList_STACK_String_Params[] = {
	"HexList"
};

int DeleteNodeInteractiveEntity__HexList_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__HexList_STACK_Rem_Call_Struct = {
	-299, 4, 0, DeleteNodeInteractiveEntity__HexList_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__HexList_STACK_Stack_Params
};
char * DescribeParam__HexList_Channels_String_Params[] = {
	"HexList", "Channels"
};

static CommandParameters DescribeParam__HexList_Channels_Rem_Call_Struct = {
	-300, 5, 0, DescribeParam__HexList_Channels_String_Params, 0, 0
};
char * DescribeParam__HexList_ElementSize_String_Params[] = {
	"HexList", "ElementSize"
};

static CommandParameters DescribeParam__HexList_ElementSize_Rem_Call_Struct = {
	-301, 5, 0, DescribeParam__HexList_ElementSize_String_Params, 0, 0
};
char * DescribeParam__HexList_Caption_String_Params[] = {
	"HexList", "Caption"
};

static CommandParameters DescribeParam__HexList_Caption_Rem_Call_Struct = {
	-302, 5, 0, DescribeParam__HexList_Caption_String_Params, 0, 0
};
char * DescribeParamInstance__HexList_STACK_Channels_String_Params[] = {
	"HexList", "Channels"
};

int DescribeParamInstance__HexList_STACK_Channels_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__HexList_STACK_Channels_Rem_Call_Struct = {
	-303, 6, 0, DescribeParamInstance__HexList_STACK_Channels_String_Params, 0, 
	DescribeParamInstance__HexList_STACK_Channels_Stack_Params
};
char * DescribeParamInstance__HexList_STACK_ElementSize_String_Params[] = {
	"HexList", "ElementSize"
};

int DescribeParamInstance__HexList_STACK_ElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__HexList_STACK_ElementSize_Rem_Call_Struct = {
	-304, 6, 0, DescribeParamInstance__HexList_STACK_ElementSize_String_Params, 0, 
	DescribeParamInstance__HexList_STACK_ElementSize_Stack_Params
};
char * DescribeParamInstance__HexList_STACK_Caption_String_Params[] = {
	"HexList", "Caption"
};

int DescribeParamInstance__HexList_STACK_Caption_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__HexList_STACK_Caption_Rem_Call_Struct = {
	-305, 6, 0, DescribeParamInstance__HexList_STACK_Caption_String_Params, 0, 
	DescribeParamInstance__HexList_STACK_Caption_Stack_Params
};
char * NodeDescribe__ImportData_String_Params[] = {
	"ImportData"
};

static CommandParameters NodeDescribe__ImportData_Rem_Call_Struct = {
	-306, 3, 0, NodeDescribe__ImportData_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__ImportData_String_Params[] = {
	"ImportData"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ImportData_Rem_Call_Struct = {
	-307, 3, 0, CreateDefaultNodeInteractiveEntity__ImportData_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ImportData_String_Params[] = {
	"ImportData"
};

static CommandParameters CreateNodeInteractiveEntity__ImportData_Rem_Call_Struct = {
	-308, 3, 0, CreateNodeInteractiveEntity__ImportData_String_Params, 0, 0
};
char * DescribeNodeInstance__ImportData_STACK_String_Params[] = {
	"ImportData"
};

int DescribeNodeInstance__ImportData_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ImportData_STACK_Rem_Call_Struct = {
	-309, 4, 0, DescribeNodeInstance__ImportData_STACK_String_Params, 0, 
	DescribeNodeInstance__ImportData_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ImportData_STACK_String_Params[] = {
	"ImportData"
};

int DeleteNodeInteractiveEntity__ImportData_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ImportData_STACK_Rem_Call_Struct = {
	-310, 4, 0, DeleteNodeInteractiveEntity__ImportData_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ImportData_STACK_Stack_Params
};
char * DescribeParam__ImportData_FileName_String_Params[] = {
	"ImportData", "FileName"
};

static CommandParameters DescribeParam__ImportData_FileName_Rem_Call_Struct = {
	-311, 5, 0, DescribeParam__ImportData_FileName_String_Params, 0, 0
};
char * DescribeParam__ImportData_Format_String_Params[] = {
	"ImportData", "Format"
};

static CommandParameters DescribeParam__ImportData_Format_Rem_Call_Struct = {
	-312, 5, 0, DescribeParam__ImportData_Format_String_Params, 0, 0
};
char * DescribeParam__ImportData_Fields_String_Params[] = {
	"ImportData", "Fields"
};

static CommandParameters DescribeParam__ImportData_Fields_Rem_Call_Struct = {
	-313, 5, 0, DescribeParam__ImportData_Fields_String_Params, 0, 0
};
char * DescribeParam__ImportData_RepeatFlag_String_Params[] = {
	"ImportData", "RepeatFlag"
};

static CommandParameters DescribeParam__ImportData_RepeatFlag_Rem_Call_Struct = {
	-314, 5, 0, DescribeParam__ImportData_RepeatFlag_String_Params, 0, 0
};
char * DescribeParam__ImportData_SkipFields_String_Params[] = {
	"ImportData", "SkipFields"
};

static CommandParameters DescribeParam__ImportData_SkipFields_Rem_Call_Struct = {
	-315, 5, 0, DescribeParam__ImportData_SkipFields_String_Params, 0, 0
};
char * DescribeParam__ImportData_SkipColumns_String_Params[] = {
	"ImportData", "SkipColumns"
};

static CommandParameters DescribeParam__ImportData_SkipColumns_Rem_Call_Struct = {
	-316, 5, 0, DescribeParam__ImportData_SkipColumns_String_Params, 0, 0
};
char * DescribeParam__ImportData_BitsPerField_String_Params[] = {
	"ImportData", "BitsPerField"
};

static CommandParameters DescribeParam__ImportData_BitsPerField_Rem_Call_Struct = {
	-317, 5, 0, DescribeParam__ImportData_BitsPerField_String_Params, 0, 0
};
char * DescribeParam__ImportData_BitsPerWord_String_Params[] = {
	"ImportData", "BitsPerWord"
};

static CommandParameters DescribeParam__ImportData_BitsPerWord_Rem_Call_Struct = {
	-318, 5, 0, DescribeParam__ImportData_BitsPerWord_String_Params, 0, 0
};
char * DescribeParamInstance__ImportData_STACK_FileName_String_Params[] = {
	"ImportData", "FileName"
};

int DescribeParamInstance__ImportData_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_FileName_Rem_Call_Struct = {
	-319, 6, 0, DescribeParamInstance__ImportData_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__ImportData_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__ImportData_STACK_Format_String_Params[] = {
	"ImportData", "Format"
};

int DescribeParamInstance__ImportData_STACK_Format_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_Format_Rem_Call_Struct = {
	-320, 6, 0, DescribeParamInstance__ImportData_STACK_Format_String_Params, 0, 
	DescribeParamInstance__ImportData_STACK_Format_Stack_Params
};
char * DescribeParamInstance__ImportData_STACK_Fields_String_Params[] = {
	"ImportData", "Fields"
};

int DescribeParamInstance__ImportData_STACK_Fields_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_Fields_Rem_Call_Struct = {
	-321, 6, 0, DescribeParamInstance__ImportData_STACK_Fields_String_Params, 0, 
	DescribeParamInstance__ImportData_STACK_Fields_Stack_Params
};
char * DescribeParamInstance__ImportData_STACK_RepeatFlag_String_Params[] = {
	"ImportData", "RepeatFlag"
};

int DescribeParamInstance__ImportData_STACK_RepeatFlag_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_RepeatFlag_Rem_Call_Struct = {
	-322, 6, 0, DescribeParamInstance__ImportData_STACK_RepeatFlag_String_Params, 0, 
	DescribeParamInstance__ImportData_STACK_RepeatFlag_Stack_Params
};
char * DescribeParamInstance__ImportData_STACK_SkipFields_String_Params[] = {
	"ImportData", "SkipFields"
};

int DescribeParamInstance__ImportData_STACK_SkipFields_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_SkipFields_Rem_Call_Struct = {
	-323, 6, 0, DescribeParamInstance__ImportData_STACK_SkipFields_String_Params, 0, 
	DescribeParamInstance__ImportData_STACK_SkipFields_Stack_Params
};
char * DescribeParamInstance__ImportData_STACK_SkipColumns_String_Params[] = {
	"ImportData", "SkipColumns"
};

int DescribeParamInstance__ImportData_STACK_SkipColumns_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_SkipColumns_Rem_Call_Struct = {
	-324, 6, 0, DescribeParamInstance__ImportData_STACK_SkipColumns_String_Params, 0, 
	DescribeParamInstance__ImportData_STACK_SkipColumns_Stack_Params
};
char * DescribeParamInstance__ImportData_STACK_BitsPerField_String_Params[] = {
	"ImportData", "BitsPerField"
};

int DescribeParamInstance__ImportData_STACK_BitsPerField_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_BitsPerField_Rem_Call_Struct = {
	-325, 6, 0, DescribeParamInstance__ImportData_STACK_BitsPerField_String_Params, 
	0, DescribeParamInstance__ImportData_STACK_BitsPerField_Stack_Params
};
char * DescribeParamInstance__ImportData_STACK_BitsPerWord_String_Params[] = {
	"ImportData", "BitsPerWord"
};

int DescribeParamInstance__ImportData_STACK_BitsPerWord_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_BitsPerWord_Rem_Call_Struct = {
	-326, 6, 0, DescribeParamInstance__ImportData_STACK_BitsPerWord_String_Params, 0, 
	DescribeParamInstance__ImportData_STACK_BitsPerWord_Stack_Params
};
char * NodeDescribe__CxImp_String_Params[] = {
	"CxImp"
};

static CommandParameters NodeDescribe__CxImp_Rem_Call_Struct = {
	-327, 3, 0, NodeDescribe__CxImp_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__CxImp_String_Params[] = {
	"CxImp"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__CxImp_Rem_Call_Struct = {
	-328, 3, 0, CreateDefaultNodeInteractiveEntity__CxImp_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__CxImp_String_Params[] = {
	"CxImp"
};

static CommandParameters CreateNodeInteractiveEntity__CxImp_Rem_Call_Struct = {
	-329, 3, 0, CreateNodeInteractiveEntity__CxImp_String_Params, 0, 0
};
char * DescribeNodeInstance__CxImp_STACK_String_Params[] = {
	"CxImp"
};

int DescribeNodeInstance__CxImp_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__CxImp_STACK_Rem_Call_Struct = {
	-330, 4, 0, DescribeNodeInstance__CxImp_STACK_String_Params, 0, 
	DescribeNodeInstance__CxImp_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__CxImp_STACK_String_Params[] = {
	"CxImp"
};

int DeleteNodeInteractiveEntity__CxImp_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__CxImp_STACK_Rem_Call_Struct = {
	-331, 4, 0, DeleteNodeInteractiveEntity__CxImp_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__CxImp_STACK_Stack_Params
};
char * DescribeParam__CxImp_Period_String_Params[] = {
	"CxImp", "Period"
};

static CommandParameters DescribeParam__CxImp_Period_Rem_Call_Struct = {
	-332, 5, 0, DescribeParam__CxImp_Period_String_Params, 0, 0
};
char * DescribeParam__CxImp_Phase_String_Params[] = {
	"CxImp", "Phase"
};

static CommandParameters DescribeParam__CxImp_Phase_Rem_Call_Struct = {
	-333, 5, 0, DescribeParam__CxImp_Phase_String_Params, 0, 0
};
char * DescribeParam__CxImp_Amplitude_String_Params[] = {
	"CxImp", "Amplitude"
};

static CommandParameters DescribeParam__CxImp_Amplitude_Rem_Call_Struct = {
	-334, 5, 0, DescribeParam__CxImp_Amplitude_String_Params, 0, 0
};
char * DescribeParam__CxImp_Width_String_Params[] = {
	"CxImp", "Width"
};

static CommandParameters DescribeParam__CxImp_Width_Rem_Call_Struct = {
	-335, 5, 0, DescribeParam__CxImp_Width_String_Params, 0, 0
};
char * DescribeParam__CxImp_Transition_String_Params[] = {
	"CxImp", "Transition"
};

static CommandParameters DescribeParam__CxImp_Transition_Rem_Call_Struct = {
	-336, 5, 0, DescribeParam__CxImp_Transition_String_Params, 0, 0
};
char * DescribeParamInstance__CxImp_STACK_Period_String_Params[] = {
	"CxImp", "Period"
};

int DescribeParamInstance__CxImp_STACK_Period_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxImp_STACK_Period_Rem_Call_Struct = {
	-337, 6, 0, DescribeParamInstance__CxImp_STACK_Period_String_Params, 0, 
	DescribeParamInstance__CxImp_STACK_Period_Stack_Params
};
char * DescribeParamInstance__CxImp_STACK_Phase_String_Params[] = {
	"CxImp", "Phase"
};

int DescribeParamInstance__CxImp_STACK_Phase_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxImp_STACK_Phase_Rem_Call_Struct = {
	-338, 6, 0, DescribeParamInstance__CxImp_STACK_Phase_String_Params, 0, 
	DescribeParamInstance__CxImp_STACK_Phase_Stack_Params
};
char * DescribeParamInstance__CxImp_STACK_Amplitude_String_Params[] = {
	"CxImp", "Amplitude"
};

int DescribeParamInstance__CxImp_STACK_Amplitude_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxImp_STACK_Amplitude_Rem_Call_Struct = {
	-339, 6, 0, DescribeParamInstance__CxImp_STACK_Amplitude_String_Params, 0, 
	DescribeParamInstance__CxImp_STACK_Amplitude_Stack_Params
};
char * DescribeParamInstance__CxImp_STACK_Width_String_Params[] = {
	"CxImp", "Width"
};

int DescribeParamInstance__CxImp_STACK_Width_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxImp_STACK_Width_Rem_Call_Struct = {
	-340, 6, 0, DescribeParamInstance__CxImp_STACK_Width_String_Params, 0, 
	DescribeParamInstance__CxImp_STACK_Width_Stack_Params
};
char * DescribeParamInstance__CxImp_STACK_Transition_String_Params[] = {
	"CxImp", "Transition"
};

int DescribeParamInstance__CxImp_STACK_Transition_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxImp_STACK_Transition_Rem_Call_Struct = {
	-341, 6, 0, DescribeParamInstance__CxImp_STACK_Transition_String_Params, 0, 
	DescribeParamInstance__CxImp_STACK_Transition_Stack_Params
};
char * NodeDescribe__InputNode_String_Params[] = {
	"InputNode"
};

static CommandParameters NodeDescribe__InputNode_Rem_Call_Struct = {
	-342, 3, 0, NodeDescribe__InputNode_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__InputNode_String_Params[] = {
	"InputNode"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__InputNode_Rem_Call_Struct = {
	-343, 3, 0, CreateDefaultNodeInteractiveEntity__InputNode_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__InputNode_String_Params[] = {
	"InputNode"
};

static CommandParameters CreateNodeInteractiveEntity__InputNode_Rem_Call_Struct = {
	-344, 3, 0, CreateNodeInteractiveEntity__InputNode_String_Params, 0, 0
};
char * MemberFunctionDescribe__InputNode_STACK_String_Params[] = {
	"InputNode"
};

int MemberFunctionDescribe__InputNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__InputNode_STACK_Rem_Call_Struct = {
	-345, 4, 0, MemberFunctionDescribe__InputNode_STACK_String_Params, 0, 
	MemberFunctionDescribe__InputNode_STACK_Stack_Params
};
char * DescribeNodeInstance__InputNode_STACK_String_Params[] = {
	"InputNode"
};

int DescribeNodeInstance__InputNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__InputNode_STACK_Rem_Call_Struct = {
	-346, 4, 0, DescribeNodeInstance__InputNode_STACK_String_Params, 0, 
	DescribeNodeInstance__InputNode_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__InputNode_STACK_String_Params[] = {
	"InputNode"
};

int DeleteNodeInteractiveEntity__InputNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__InputNode_STACK_Rem_Call_Struct = {
	-347, 4, 0, DeleteNodeInteractiveEntity__InputNode_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__InputNode_STACK_Stack_Params
};
char * DescribeParam__InputNode_FileName_String_Params[] = {
	"InputNode", "FileName"
};

static CommandParameters DescribeParam__InputNode_FileName_Rem_Call_Struct = {
	-348, 5, 0, DescribeParam__InputNode_FileName_String_Params, 0, 0
};
char * DescribeParam__InputNode_Flags_String_Params[] = {
	"InputNode", "Flags"
};

static CommandParameters DescribeParam__InputNode_Flags_Rem_Call_Struct = {
	-349, 5, 0, DescribeParam__InputNode_Flags_String_Params, 0, 0
};
char * DescribeParam__InputNode_DeltaOut_String_Params[] = {
	"InputNode", "DeltaOut"
};

static CommandParameters DescribeParam__InputNode_DeltaOut_Rem_Call_Struct = {
	-350, 5, 0, DescribeParam__InputNode_DeltaOut_String_Params, 0, 0
};
char * DescribeParamInstance__InputNode_STACK_FileName_String_Params[] = {
	"InputNode", "FileName"
};

int DescribeParamInstance__InputNode_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__InputNode_STACK_FileName_Rem_Call_Struct = {
	-351, 6, 0, DescribeParamInstance__InputNode_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__InputNode_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__InputNode_STACK_Flags_String_Params[] = {
	"InputNode", "Flags"
};

int DescribeParamInstance__InputNode_STACK_Flags_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__InputNode_STACK_Flags_Rem_Call_Struct = {
	-352, 6, 0, DescribeParamInstance__InputNode_STACK_Flags_String_Params, 0, 
	DescribeParamInstance__InputNode_STACK_Flags_Stack_Params
};
char * DescribeParamInstance__InputNode_STACK_DeltaOut_String_Params[] = {
	"InputNode", "DeltaOut"
};

int DescribeParamInstance__InputNode_STACK_DeltaOut_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__InputNode_STACK_DeltaOut_Rem_Call_Struct = {
	-353, 6, 0, DescribeParamInstance__InputNode_STACK_DeltaOut_String_Params, 0, 
	DescribeParamInstance__InputNode_STACK_DeltaOut_Stack_Params
};
char * NodeDescribe__Integrate_String_Params[] = {
	"Integrate"
};

static CommandParameters NodeDescribe__Integrate_Rem_Call_Struct = {
	-354, 3, 0, NodeDescribe__Integrate_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Integrate_String_Params[] = {
	"Integrate"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Integrate_Rem_Call_Struct = {
	-355, 3, 0, CreateDefaultNodeInteractiveEntity__Integrate_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Integrate_String_Params[] = {
	"Integrate"
};

static CommandParameters CreateNodeInteractiveEntity__Integrate_Rem_Call_Struct = {
	-356, 3, 0, CreateNodeInteractiveEntity__Integrate_String_Params, 0, 0
};
char * DescribeNodeInstance__Integrate_STACK_String_Params[] = {
	"Integrate"
};

int DescribeNodeInstance__Integrate_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Integrate_STACK_Rem_Call_Struct = {
	-357, 4, 0, DescribeNodeInstance__Integrate_STACK_String_Params, 0, 
	DescribeNodeInstance__Integrate_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Integrate_STACK_String_Params[] = {
	"Integrate"
};

int DeleteNodeInteractiveEntity__Integrate_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Integrate_STACK_Rem_Call_Struct = {
	-358, 4, 0, DeleteNodeInteractiveEntity__Integrate_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Integrate_STACK_Stack_Params
};
char * DescribeParam__Integrate_IntegrationSize_String_Params[] = {
	"Integrate", "IntegrationSize"
};

static CommandParameters DescribeParam__Integrate_IntegrationSize_Rem_Call_Struct = {
	-359, 5, 0, DescribeParam__Integrate_IntegrationSize_String_Params, 0, 0
};
char * DescribeParam__Integrate_OutputStep_String_Params[] = {
	"Integrate", "OutputStep"
};

static CommandParameters DescribeParam__Integrate_OutputStep_Rem_Call_Struct = {
	-360, 5, 0, DescribeParam__Integrate_OutputStep_String_Params, 0, 0
};
char * DescribeParam__Integrate_Scale_String_Params[] = {
	"Integrate", "Scale"
};

static CommandParameters DescribeParam__Integrate_Scale_Rem_Call_Struct = {
	-361, 5, 0, DescribeParam__Integrate_Scale_String_Params, 0, 0
};
char * DescribeParamInstance__Integrate_STACK_IntegrationSize_String_Params[] = {
	"Integrate", "IntegrationSize"
};

int DescribeParamInstance__Integrate_STACK_IntegrationSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Integrate_STACK_IntegrationSize_Rem_Call_Struct = {
	-362, 6, 0, DescribeParamInstance__Integrate_STACK_IntegrationSize_String_Params, 
	0, DescribeParamInstance__Integrate_STACK_IntegrationSize_Stack_Params
};
char * DescribeParamInstance__Integrate_STACK_OutputStep_String_Params[] = {
	"Integrate", "OutputStep"
};

int DescribeParamInstance__Integrate_STACK_OutputStep_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Integrate_STACK_OutputStep_Rem_Call_Struct = {
	-363, 6, 0, DescribeParamInstance__Integrate_STACK_OutputStep_String_Params, 0, 
	DescribeParamInstance__Integrate_STACK_OutputStep_Stack_Params
};
char * DescribeParamInstance__Integrate_STACK_Scale_String_Params[] = {
	"Integrate", "Scale"
};

int DescribeParamInstance__Integrate_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Integrate_STACK_Scale_Rem_Call_Struct = {
	-364, 6, 0, DescribeParamInstance__Integrate_STACK_Scale_String_Params, 0, 
	DescribeParamInstance__Integrate_STACK_Scale_Stack_Params
};
char * ExecuteSetParameter__Integrate_STACK_Scale_String_Params[] = {
	"Integrate", "Scale"
};

int ExecuteSetParameter__Integrate_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Integrate_STACK_Scale_Rem_Call_Struct = {
	-365, 6, 0, ExecuteSetParameter__Integrate_STACK_Scale_String_Params, 0, 
	ExecuteSetParameter__Integrate_STACK_Scale_Stack_Params
};
char * NodeDescribe__Interpolate_String_Params[] = {
	"Interpolate"
};

static CommandParameters NodeDescribe__Interpolate_Rem_Call_Struct = {
	-366, 3, 0, NodeDescribe__Interpolate_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Interpolate_String_Params[] = {
	"Interpolate"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Interpolate_Rem_Call_Struct = {
	-367, 3, 0, CreateDefaultNodeInteractiveEntity__Interpolate_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Interpolate_String_Params[] = {
	"Interpolate"
};

static CommandParameters CreateNodeInteractiveEntity__Interpolate_Rem_Call_Struct = {
	-368, 3, 0, CreateNodeInteractiveEntity__Interpolate_String_Params, 0, 0
};
char * DescribeNodeInstance__Interpolate_STACK_String_Params[] = {
	"Interpolate"
};

int DescribeNodeInstance__Interpolate_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Interpolate_STACK_Rem_Call_Struct = {
	-369, 4, 0, DescribeNodeInstance__Interpolate_STACK_String_Params, 0, 
	DescribeNodeInstance__Interpolate_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Interpolate_STACK_String_Params[] = {
	"Interpolate"
};

int DeleteNodeInteractiveEntity__Interpolate_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Interpolate_STACK_Rem_Call_Struct = {
	-370, 4, 0, DeleteNodeInteractiveEntity__Interpolate_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Interpolate_STACK_Stack_Params
};
char * DescribeParam__Interpolate_DeltaIn_String_Params[] = {
	"Interpolate", "DeltaIn"
};

static CommandParameters DescribeParam__Interpolate_DeltaIn_Rem_Call_Struct = {
	-371, 5, 0, DescribeParam__Interpolate_DeltaIn_String_Params, 0, 0
};
char * DescribeParam__Interpolate_DeltaOut_String_Params[] = {
	"Interpolate", "DeltaOut"
};

static CommandParameters DescribeParam__Interpolate_DeltaOut_Rem_Call_Struct = {
	-372, 5, 0, DescribeParam__Interpolate_DeltaOut_String_Params, 0, 0
};
char * DescribeParamInstance__Interpolate_STACK_DeltaIn_String_Params[] = {
	"Interpolate", "DeltaIn"
};

int DescribeParamInstance__Interpolate_STACK_DeltaIn_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Interpolate_STACK_DeltaIn_Rem_Call_Struct = {
	-373, 6, 0, DescribeParamInstance__Interpolate_STACK_DeltaIn_String_Params, 0, 
	DescribeParamInstance__Interpolate_STACK_DeltaIn_Stack_Params
};
char * DescribeParamInstance__Interpolate_STACK_DeltaOut_String_Params[] = {
	"Interpolate", "DeltaOut"
};

int DescribeParamInstance__Interpolate_STACK_DeltaOut_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Interpolate_STACK_DeltaOut_Rem_Call_Struct = {
	-374, 6, 0, DescribeParamInstance__Interpolate_STACK_DeltaOut_String_Params, 0, 
	DescribeParamInstance__Interpolate_STACK_DeltaOut_Stack_Params
};
char * NodeDescribe__MaskWord_String_Params[] = {
	"MaskWord"
};

static CommandParameters NodeDescribe__MaskWord_Rem_Call_Struct = {
	-375, 3, 0, NodeDescribe__MaskWord_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__MaskWord_String_Params[] = {
	"MaskWord"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__MaskWord_Rem_Call_Struct = {
	-376, 3, 0, CreateDefaultNodeInteractiveEntity__MaskWord_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__MaskWord_String_Params[] = {
	"MaskWord"
};

static CommandParameters CreateNodeInteractiveEntity__MaskWord_Rem_Call_Struct = {
	-377, 3, 0, CreateNodeInteractiveEntity__MaskWord_String_Params, 0, 0
};
char * DescribeNodeInstance__MaskWord_STACK_String_Params[] = {
	"MaskWord"
};

int DescribeNodeInstance__MaskWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__MaskWord_STACK_Rem_Call_Struct = {
	-378, 4, 0, DescribeNodeInstance__MaskWord_STACK_String_Params, 0, 
	DescribeNodeInstance__MaskWord_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__MaskWord_STACK_String_Params[] = {
	"MaskWord"
};

int DeleteNodeInteractiveEntity__MaskWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__MaskWord_STACK_Rem_Call_Struct = {
	-379, 4, 0, DeleteNodeInteractiveEntity__MaskWord_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__MaskWord_STACK_Stack_Params
};
char * DescribeParam__MaskWord_Mask_String_Params[] = {
	"MaskWord", "Mask"
};

static CommandParameters DescribeParam__MaskWord_Mask_Rem_Call_Struct = {
	-380, 5, 0, DescribeParam__MaskWord_Mask_String_Params, 0, 0
};
char * DescribeParamInstance__MaskWord_STACK_Mask_String_Params[] = {
	"MaskWord", "Mask"
};

int DescribeParamInstance__MaskWord_STACK_Mask_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__MaskWord_STACK_Mask_Rem_Call_Struct = {
	-381, 6, 0, DescribeParamInstance__MaskWord_STACK_Mask_String_Params, 0, 
	DescribeParamInstance__MaskWord_STACK_Mask_Stack_Params
};
char * NodeDescribe__Mux_String_Params[] = {
	"Mux"
};

static CommandParameters NodeDescribe__Mux_Rem_Call_Struct = {
	-382, 3, 0, NodeDescribe__Mux_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Mux_String_Params[] = {
	"Mux"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Mux_Rem_Call_Struct = {
	-383, 3, 0, CreateDefaultNodeInteractiveEntity__Mux_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Mux_String_Params[] = {
	"Mux"
};

static CommandParameters CreateNodeInteractiveEntity__Mux_Rem_Call_Struct = {
	-384, 3, 0, CreateNodeInteractiveEntity__Mux_String_Params, 0, 0
};
char * DescribeNodeInstance__Mux_STACK_String_Params[] = {
	"Mux"
};

int DescribeNodeInstance__Mux_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Mux_STACK_Rem_Call_Struct = {
	-385, 4, 0, DescribeNodeInstance__Mux_STACK_String_Params, 0, 
	DescribeNodeInstance__Mux_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Mux_STACK_String_Params[] = {
	"Mux"
};

int DeleteNodeInteractiveEntity__Mux_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Mux_STACK_Rem_Call_Struct = {
	-386, 4, 0, DeleteNodeInteractiveEntity__Mux_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Mux_STACK_Stack_Params
};
char * DescribeParam__Mux_Channels_String_Params[] = {
	"Mux", "Channels"
};

static CommandParameters DescribeParam__Mux_Channels_Rem_Call_Struct = {
	-387, 5, 0, DescribeParam__Mux_Channels_String_Params, 0, 0
};
char * DescribeParam__Mux_InputSampleSize_String_Params[] = {
	"Mux", "InputSampleSize"
};

static CommandParameters DescribeParam__Mux_InputSampleSize_Rem_Call_Struct = {
	-388, 5, 0, DescribeParam__Mux_InputSampleSize_String_Params, 0, 0
};
char * DescribeParam__Mux_OutputSampleSize_String_Params[] = {
	"Mux", "OutputSampleSize"
};

static CommandParameters DescribeParam__Mux_OutputSampleSize_Rem_Call_Struct = {
	-389, 5, 0, DescribeParam__Mux_OutputSampleSize_String_Params, 0, 0
};
char * DescribeParam__Mux_MinimumChunk_String_Params[] = {
	"Mux", "MinimumChunk"
};

static CommandParameters DescribeParam__Mux_MinimumChunk_Rem_Call_Struct = {
	-390, 5, 0, DescribeParam__Mux_MinimumChunk_String_Params, 0, 0
};
char * DescribeParamInstance__Mux_STACK_Channels_String_Params[] = {
	"Mux", "Channels"
};

int DescribeParamInstance__Mux_STACK_Channels_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Mux_STACK_Channels_Rem_Call_Struct = {
	-391, 6, 0, DescribeParamInstance__Mux_STACK_Channels_String_Params, 0, 
	DescribeParamInstance__Mux_STACK_Channels_Stack_Params
};
char * DescribeParamInstance__Mux_STACK_InputSampleSize_String_Params[] = {
	"Mux", "InputSampleSize"
};

int DescribeParamInstance__Mux_STACK_InputSampleSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Mux_STACK_InputSampleSize_Rem_Call_Struct = {
	-392, 6, 0, DescribeParamInstance__Mux_STACK_InputSampleSize_String_Params, 0, 
	DescribeParamInstance__Mux_STACK_InputSampleSize_Stack_Params
};
char * DescribeParamInstance__Mux_STACK_OutputSampleSize_String_Params[] = {
	"Mux", "OutputSampleSize"
};

int DescribeParamInstance__Mux_STACK_OutputSampleSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Mux_STACK_OutputSampleSize_Rem_Call_Struct = {
	-393, 6, 0, DescribeParamInstance__Mux_STACK_OutputSampleSize_String_Params, 0, 
	DescribeParamInstance__Mux_STACK_OutputSampleSize_Stack_Params
};
char * DescribeParamInstance__Mux_STACK_MinimumChunk_String_Params[] = {
	"Mux", "MinimumChunk"
};

int DescribeParamInstance__Mux_STACK_MinimumChunk_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Mux_STACK_MinimumChunk_Rem_Call_Struct = {
	-394, 6, 0, DescribeParamInstance__Mux_STACK_MinimumChunk_String_Params, 0, 
	DescribeParamInstance__Mux_STACK_MinimumChunk_Stack_Params
};
char * NodeDescribe__Network_String_Params[] = {
	"Network"
};

static CommandParameters NodeDescribe__Network_Rem_Call_Struct = {
	-395, 3, 0, NodeDescribe__Network_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Network_String_Params[] = {
	"Network"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Network_Rem_Call_Struct = {
	-396, 3, 0, CreateDefaultNodeInteractiveEntity__Network_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Network_String_Params[] = {
	"Network"
};

static CommandParameters CreateNodeInteractiveEntity__Network_Rem_Call_Struct = {
	-397, 3, 0, CreateNodeInteractiveEntity__Network_String_Params, 0, 0
};
char * MemberFunctionDescribe__Network_STACK_String_Params[] = {
	"Network"
};

int MemberFunctionDescribe__Network_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__Network_STACK_Rem_Call_Struct = {
	-398, 4, 0, MemberFunctionDescribe__Network_STACK_String_Params, 0, 
	MemberFunctionDescribe__Network_STACK_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_InputSamples_String_Params[] = {
	"Network", "InputSamples"
};

int DescribeMemberFunctionParameter__Network_STACK_InputSamples_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_InputSamples_Rem_Call_Struct = {
	-399, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_InputSamples_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_InputSamples_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_TheNode_String_Params[] = {
	"Network", "TheNode"
};

int DescribeMemberFunctionParameter__Network_STACK_TheNode_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_TheNode_Rem_Call_Struct = {
	-400, 6, 0, DescribeMemberFunctionParameter__Network_STACK_TheNode_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_TheNode_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_OutChannel_String_Params[] = {
	"Network", "OutChannel"
};

int DescribeMemberFunctionParameter__Network_STACK_OutChannel_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_OutChannel_Rem_Call_Struct = {
	-401, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_OutChannel_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_OutChannel_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_NodeOut_String_Params[] = {
	"Network", "NodeOut"
};

int DescribeMemberFunctionParameter__Network_STACK_NodeOut_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_NodeOut_Rem_Call_Struct = {
	-402, 6, 0, DescribeMemberFunctionParameter__Network_STACK_NodeOut_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_NodeOut_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_NodeIn_String_Params[] = {
	"Network", "NodeIn"
};

int DescribeMemberFunctionParameter__Network_STACK_NodeIn_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_NodeIn_Rem_Call_Struct = {
	-403, 6, 0, DescribeMemberFunctionParameter__Network_STACK_NodeIn_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_NodeIn_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_ChannelOut_String_Params[] = {
	"Network", "ChannelOut"
};

int DescribeMemberFunctionParameter__Network_STACK_ChannelOut_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_ChannelOut_Rem_Call_Struct = {
	-404, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ChannelOut_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ChannelOut_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_ChannelIn_String_Params[] = {
	"Network", "ChannelIn"
};

int DescribeMemberFunctionParameter__Network_STACK_ChannelIn_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_ChannelIn_Rem_Call_Struct = {
	-405, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ChannelIn_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ChannelIn_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_ToReplace_String_Params[] = {
	"Network", "ToReplace"
};

int DescribeMemberFunctionParameter__Network_STACK_ToReplace_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_ToReplace_Rem_Call_Struct = {
	-406, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ToReplace_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ToReplace_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Replacement_String_Params[] = {
	"Network", "Replacement"
};

int DescribeMemberFunctionParameter__Network_STACK_Replacement_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Replacement_Rem_Call_Struct = {
	-407, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Replacement_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Replacement_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Target_String_Params[] = {
	"Network", "Target"
};

int DescribeMemberFunctionParameter__Network_STACK_Target_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Target_Rem_Call_Struct = {
	-408, 6, 0, DescribeMemberFunctionParameter__Network_STACK_Target_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_Target_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Create_String_Params[] = {
	"Network", "Create"
};

int DescribeMemberFunctionParameter__Network_STACK_Create_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Create_Rem_Call_Struct = {
	-409, 6, 0, DescribeMemberFunctionParameter__Network_STACK_Create_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_Create_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Directory_String_Params[] = {
	"Network", "Directory"
};

int DescribeMemberFunctionParameter__Network_STACK_Directory_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Directory_Rem_Call_Struct = {
	-410, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Directory_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Directory_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Descriptor_String_Params[] = {
	"Network", "Descriptor"
};

int DescribeMemberFunctionParameter__Network_STACK_Descriptor_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Descriptor_Rem_Call_Struct = {
	-411, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Descriptor_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Descriptor_Stack_Params
};
char * DescribeNodeInstance__Network_STACK_String_Params[] = {
	"Network"
};

int DescribeNodeInstance__Network_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Network_STACK_Rem_Call_Struct = {
	-412, 4, 0, DescribeNodeInstance__Network_STACK_String_Params, 0, 
	DescribeNodeInstance__Network_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Network_STACK_String_Params[] = {
	"Network"
};

int DeleteNodeInteractiveEntity__Network_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Network_STACK_Rem_Call_Struct = {
	-413, 4, 0, DeleteNodeInteractiveEntity__Network_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Network_STACK_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_Link_String_Params[] = {
	"Link"
};

int ExecuteMemberFunction__STACK_STACK_Link_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_Link_Rem_Call_Struct = {
	-414, 7, 0, ExecuteMemberFunction__STACK_STACK_Link_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_Link_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_SelfLink_String_Params[] = {
	"SelfLink"
};

int ExecuteMemberFunction__STACK_STACK_SelfLink_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_SelfLink_Rem_Call_Struct = {
	-415, 7, 0, ExecuteMemberFunction__STACK_STACK_SelfLink_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_SelfLink_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_ReplaceNode_String_Params[] = {
	"ReplaceNode"
};

int ExecuteMemberFunction__STACK_STACK_ReplaceNode_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_ReplaceNode_Rem_Call_Struct = {
	-416, 7, 0, ExecuteMemberFunction__STACK_STACK_ReplaceNode_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_ReplaceNode_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_MakeTarget_String_Params[] = {
	"MakeTarget"
};

int ExecuteMemberFunction__STACK_STACK_MakeTarget_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_MakeTarget_Rem_Call_Struct = {
	-417, 7, 0, ExecuteMemberFunction__STACK_STACK_MakeTarget_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_MakeTarget_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_Add_Op_String_Params[] = {
	"operator+"
};

int ExecuteMemberFunction__STACK_STACK_Add_Op_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_Add_Op_Rem_Call_Struct = {
	-418, 7, 0, ExecuteMemberFunction__STACK_STACK_Add_Op_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_Add_Op_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_RightShift_Op_String_Params[] = {
	"operator>>"
};

int ExecuteMemberFunction__STACK_STACK_RightShift_Op_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_RightShift_Op_Rem_Call_Struct = {
	-419, 7, 0, ExecuteMemberFunction__STACK_STACK_RightShift_Op_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_RightShift_Op_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_SetBufferDescriptor_String_Params[] = {
	"SetBufferDescriptor"
};

int ExecuteMemberFunction__STACK_STACK_SetBufferDescriptor_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_SetBufferDescriptor_Rem_Call_Struct = {
	-420, 7, 0, ExecuteMemberFunction__STACK_STACK_SetBufferDescriptor_String_Params, 
	0, ExecuteMemberFunction__STACK_STACK_SetBufferDescriptor_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_GetBufferDescriptor_String_Params[] = {
	"GetBufferDescriptor"
};

int ExecuteMemberFunction__STACK_STACK_GetBufferDescriptor_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_GetBufferDescriptor_Rem_Call_Struct = {
	-421, 7, 0, ExecuteMemberFunction__STACK_STACK_GetBufferDescriptor_String_Params, 
	0, ExecuteMemberFunction__STACK_STACK_GetBufferDescriptor_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_GetNetController_String_Params[] = {
	"GetNetController"
};

int ExecuteMemberFunction__STACK_STACK_GetNetController_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_GetNetController_Rem_Call_Struct = {
	-422, 7, 0, ExecuteMemberFunction__STACK_STACK_GetNetController_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_GetNetController_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_AssociateNode_String_Params[] = {
	"AssociateNode"
};

int ExecuteMemberFunction__STACK_STACK_AssociateNode_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_AssociateNode_Rem_Call_Struct = {
	-423, 7, 0, ExecuteMemberFunction__STACK_STACK_AssociateNode_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_AssociateNode_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_DisplayNames_String_Params[] = {
	"DisplayNames"
};

int ExecuteMemberFunction__STACK_STACK_DisplayNames_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_DisplayNames_Rem_Call_Struct = {
	-424, 7, 0, ExecuteMemberFunction__STACK_STACK_DisplayNames_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_DisplayNames_Stack_Params
};
char * NodeDescribe__Normal_String_Params[] = {
	"Normal"
};

static CommandParameters NodeDescribe__Normal_Rem_Call_Struct = {
	-425, 3, 0, NodeDescribe__Normal_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Normal_String_Params[] = {
	"Normal"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Normal_Rem_Call_Struct = {
	-426, 3, 0, CreateDefaultNodeInteractiveEntity__Normal_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Normal_String_Params[] = {
	"Normal"
};

static CommandParameters CreateNodeInteractiveEntity__Normal_Rem_Call_Struct = {
	-427, 3, 0, CreateNodeInteractiveEntity__Normal_String_Params, 0, 0
};
char * DescribeNodeInstance__Normal_STACK_String_Params[] = {
	"Normal"
};

int DescribeNodeInstance__Normal_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Normal_STACK_Rem_Call_Struct = {
	-428, 4, 0, DescribeNodeInstance__Normal_STACK_String_Params, 0, 
	DescribeNodeInstance__Normal_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Normal_STACK_String_Params[] = {
	"Normal"
};

int DeleteNodeInteractiveEntity__Normal_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Normal_STACK_Rem_Call_Struct = {
	-429, 4, 0, DeleteNodeInteractiveEntity__Normal_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Normal_STACK_Stack_Params
};
char * DescribeParam__Normal_Sigma_String_Params[] = {
	"Normal", "Sigma"
};

static CommandParameters DescribeParam__Normal_Sigma_Rem_Call_Struct = {
	-430, 5, 0, DescribeParam__Normal_Sigma_String_Params, 0, 0
};
char * DescribeParam__Normal_Mean_String_Params[] = {
	"Normal", "Mean"
};

static CommandParameters DescribeParam__Normal_Mean_Rem_Call_Struct = {
	-431, 5, 0, DescribeParam__Normal_Mean_String_Params, 0, 0
};
char * DescribeParam__Normal_ElementSize_String_Params[] = {
	"Normal", "ElementSize"
};

static CommandParameters DescribeParam__Normal_ElementSize_Rem_Call_Struct = {
	-432, 5, 0, DescribeParam__Normal_ElementSize_String_Params, 0, 0
};
char * DescribeParamInstance__Normal_STACK_Sigma_String_Params[] = {
	"Normal", "Sigma"
};

int DescribeParamInstance__Normal_STACK_Sigma_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Normal_STACK_Sigma_Rem_Call_Struct = {
	-433, 6, 0, DescribeParamInstance__Normal_STACK_Sigma_String_Params, 0, 
	DescribeParamInstance__Normal_STACK_Sigma_Stack_Params
};
char * DescribeParamInstance__Normal_STACK_Mean_String_Params[] = {
	"Normal", "Mean"
};

int DescribeParamInstance__Normal_STACK_Mean_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Normal_STACK_Mean_Rem_Call_Struct = {
	-434, 6, 0, DescribeParamInstance__Normal_STACK_Mean_String_Params, 0, 
	DescribeParamInstance__Normal_STACK_Mean_Stack_Params
};
char * DescribeParamInstance__Normal_STACK_ElementSize_String_Params[] = {
	"Normal", "ElementSize"
};

int DescribeParamInstance__Normal_STACK_ElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Normal_STACK_ElementSize_Rem_Call_Struct = {
	-435, 6, 0, DescribeParamInstance__Normal_STACK_ElementSize_String_Params, 0, 
	DescribeParamInstance__Normal_STACK_ElementSize_Stack_Params
};
char * ExecuteSetParameter__Normal_STACK_Sigma_String_Params[] = {
	"Normal", "Sigma"
};

int ExecuteSetParameter__Normal_STACK_Sigma_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Normal_STACK_Sigma_Rem_Call_Struct = {
	-436, 6, 0, ExecuteSetParameter__Normal_STACK_Sigma_String_Params, 0, 
	ExecuteSetParameter__Normal_STACK_Sigma_Stack_Params
};
char * ExecuteSetParameter__Normal_STACK_Mean_String_Params[] = {
	"Normal", "Mean"
};

int ExecuteSetParameter__Normal_STACK_Mean_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Normal_STACK_Mean_Rem_Call_Struct = {
	-437, 6, 0, ExecuteSetParameter__Normal_STACK_Mean_String_Params, 0, 
	ExecuteSetParameter__Normal_STACK_Mean_Stack_Params
};
char * NodeDescribe__OutputNode_String_Params[] = {
	"OutputNode"
};

static CommandParameters NodeDescribe__OutputNode_Rem_Call_Struct = {
	-438, 3, 0, NodeDescribe__OutputNode_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__OutputNode_String_Params[] = {
	"OutputNode"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__OutputNode_Rem_Call_Struct = {
	-439, 3, 0, CreateDefaultNodeInteractiveEntity__OutputNode_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__OutputNode_String_Params[] = {
	"OutputNode"
};

static CommandParameters CreateNodeInteractiveEntity__OutputNode_Rem_Call_Struct = {
	-440, 3, 0, CreateNodeInteractiveEntity__OutputNode_String_Params, 0, 0
};
char * DescribeNodeInstance__OutputNode_STACK_String_Params[] = {
	"OutputNode"
};

int DescribeNodeInstance__OutputNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__OutputNode_STACK_Rem_Call_Struct = {
	-441, 4, 0, DescribeNodeInstance__OutputNode_STACK_String_Params, 0, 
	DescribeNodeInstance__OutputNode_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__OutputNode_STACK_String_Params[] = {
	"OutputNode"
};

int DeleteNodeInteractiveEntity__OutputNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__OutputNode_STACK_Rem_Call_Struct = {
	-442, 4, 0, DeleteNodeInteractiveEntity__OutputNode_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__OutputNode_STACK_Stack_Params
};
char * DescribeParam__OutputNode_FileName_String_Params[] = {
	"OutputNode", "FileName"
};

static CommandParameters DescribeParam__OutputNode_FileName_Rem_Call_Struct = {
	-443, 5, 0, DescribeParam__OutputNode_FileName_String_Params, 0, 0
};
char * DescribeParam__OutputNode_Flags_String_Params[] = {
	"OutputNode", "Flags"
};

static CommandParameters DescribeParam__OutputNode_Flags_Rem_Call_Struct = {
	-444, 5, 0, DescribeParam__OutputNode_Flags_String_Params, 0, 0
};
char * DescribeParam__OutputNode_Channels_String_Params[] = {
	"OutputNode", "Channels"
};

static CommandParameters DescribeParam__OutputNode_Channels_Rem_Call_Struct = {
	-445, 5, 0, DescribeParam__OutputNode_Channels_String_Params, 0, 0
};
char * DescribeParam__OutputNode_FileBlockSize_String_Params[] = {
	"OutputNode", "FileBlockSize"
};

static CommandParameters DescribeParam__OutputNode_FileBlockSize_Rem_Call_Struct = {
	-446, 5, 0, DescribeParam__OutputNode_FileBlockSize_String_Params, 0, 0
};
char * DescribeParam__OutputNode_Caption_String_Params[] = {
	"OutputNode", "Caption"
};

static CommandParameters DescribeParam__OutputNode_Caption_Rem_Call_Struct = {
	-447, 5, 0, DescribeParam__OutputNode_Caption_String_Params, 0, 0
};
char * DescribeParam__OutputNode_DeltaIn_String_Params[] = {
	"OutputNode", "DeltaIn"
};

static CommandParameters DescribeParam__OutputNode_DeltaIn_Rem_Call_Struct = {
	-448, 5, 0, DescribeParam__OutputNode_DeltaIn_String_Params, 0, 0
};
char * DescribeParamInstance__OutputNode_STACK_FileName_String_Params[] = {
	"OutputNode", "FileName"
};

int DescribeParamInstance__OutputNode_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputNode_STACK_FileName_Rem_Call_Struct = {
	-449, 6, 0, DescribeParamInstance__OutputNode_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__OutputNode_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__OutputNode_STACK_Flags_String_Params[] = {
	"OutputNode", "Flags"
};

int DescribeParamInstance__OutputNode_STACK_Flags_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputNode_STACK_Flags_Rem_Call_Struct = {
	-450, 6, 0, DescribeParamInstance__OutputNode_STACK_Flags_String_Params, 0, 
	DescribeParamInstance__OutputNode_STACK_Flags_Stack_Params
};
char * DescribeParamInstance__OutputNode_STACK_Channels_String_Params[] = {
	"OutputNode", "Channels"
};

int DescribeParamInstance__OutputNode_STACK_Channels_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputNode_STACK_Channels_Rem_Call_Struct = {
	-451, 6, 0, DescribeParamInstance__OutputNode_STACK_Channels_String_Params, 0, 
	DescribeParamInstance__OutputNode_STACK_Channels_Stack_Params
};
char * DescribeParamInstance__OutputNode_STACK_FileBlockSize_String_Params[] = {
	"OutputNode", "FileBlockSize"
};

int DescribeParamInstance__OutputNode_STACK_FileBlockSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputNode_STACK_FileBlockSize_Rem_Call_Struct = {
	-452, 6, 0, DescribeParamInstance__OutputNode_STACK_FileBlockSize_String_Params, 
	0, DescribeParamInstance__OutputNode_STACK_FileBlockSize_Stack_Params
};
char * DescribeParamInstance__OutputNode_STACK_Caption_String_Params[] = {
	"OutputNode", "Caption"
};

int DescribeParamInstance__OutputNode_STACK_Caption_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputNode_STACK_Caption_Rem_Call_Struct = {
	-453, 6, 0, DescribeParamInstance__OutputNode_STACK_Caption_String_Params, 0, 
	DescribeParamInstance__OutputNode_STACK_Caption_Stack_Params
};
char * DescribeParamInstance__OutputNode_STACK_DeltaIn_String_Params[] = {
	"OutputNode", "DeltaIn"
};

int DescribeParamInstance__OutputNode_STACK_DeltaIn_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputNode_STACK_DeltaIn_Rem_Call_Struct = {
	-454, 6, 0, DescribeParamInstance__OutputNode_STACK_DeltaIn_String_Params, 0, 
	DescribeParamInstance__OutputNode_STACK_DeltaIn_Stack_Params
};
char * NodeDescribe__Power_String_Params[] = {
	"Power"
};

static CommandParameters NodeDescribe__Power_Rem_Call_Struct = {
	-455, 3, 0, NodeDescribe__Power_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Power_String_Params[] = {
	"Power"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Power_Rem_Call_Struct = {
	-456, 3, 0, CreateDefaultNodeInteractiveEntity__Power_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Power_String_Params[] = {
	"Power"
};

static CommandParameters CreateNodeInteractiveEntity__Power_Rem_Call_Struct = {
	-457, 3, 0, CreateNodeInteractiveEntity__Power_String_Params, 0, 0
};
char * DescribeNodeInstance__Power_STACK_String_Params[] = {
	"Power"
};

int DescribeNodeInstance__Power_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Power_STACK_Rem_Call_Struct = {
	-458, 4, 0, DescribeNodeInstance__Power_STACK_String_Params, 0, 
	DescribeNodeInstance__Power_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Power_STACK_String_Params[] = {
	"Power"
};

int DeleteNodeInteractiveEntity__Power_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Power_STACK_Rem_Call_Struct = {
	-459, 4, 0, DeleteNodeInteractiveEntity__Power_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Power_STACK_Stack_Params
};
char * DescribeParam__Power_Amplitude_String_Params[] = {
	"Power", "Amplitude"
};

static CommandParameters DescribeParam__Power_Amplitude_Rem_Call_Struct = {
	-460, 5, 0, DescribeParam__Power_Amplitude_String_Params, 0, 0
};
char * DescribeParam__Power_Scale_String_Params[] = {
	"Power", "Scale"
};

static CommandParameters DescribeParam__Power_Scale_Rem_Call_Struct = {
	-461, 5, 0, DescribeParam__Power_Scale_String_Params, 0, 0
};
char * DescribeParamInstance__Power_STACK_Amplitude_String_Params[] = {
	"Power", "Amplitude"
};

int DescribeParamInstance__Power_STACK_Amplitude_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Power_STACK_Amplitude_Rem_Call_Struct = {
	-462, 6, 0, DescribeParamInstance__Power_STACK_Amplitude_String_Params, 0, 
	DescribeParamInstance__Power_STACK_Amplitude_Stack_Params
};
char * DescribeParamInstance__Power_STACK_Scale_String_Params[] = {
	"Power", "Scale"
};

int DescribeParamInstance__Power_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Power_STACK_Scale_Rem_Call_Struct = {
	-463, 6, 0, DescribeParamInstance__Power_STACK_Scale_String_Params, 0, 
	DescribeParamInstance__Power_STACK_Scale_Stack_Params
};
char * ExecuteSetParameter__Power_STACK_Scale_String_Params[] = {
	"Power", "Scale"
};

int ExecuteSetParameter__Power_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Power_STACK_Scale_Rem_Call_Struct = {
	-464, 6, 0, ExecuteSetParameter__Power_STACK_Scale_String_Params, 0, 
	ExecuteSetParameter__Power_STACK_Scale_Stack_Params
};
char * MemberFunctionDescribe__ProcessNodeStr_STACK_String_Params[] = {
	"ProcessNodeStr"
};

int MemberFunctionDescribe__ProcessNodeStr_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__ProcessNodeStr_STACK_Rem_Call_Struct = {
	-465, 4, 0, MemberFunctionDescribe__ProcessNodeStr_STACK_String_Params, 0, 
	MemberFunctionDescribe__ProcessNodeStr_STACK_Stack_Params
};
char * DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Rate_String_Params[] = {
	"ProcessNodeStr", "Rate"
};

int DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Rate_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Rate_Rem_Call_Struct = {
	-466, 6, 0, 
	DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Rate_String_Params, 0, 
	DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Rate_Stack_Params
};
char * DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Channel_String_Params[] = {
	"ProcessNodeStr", "Channel"
};

int DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Channel_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Channel_Rem_Call_Struct = {
	-467, 6, 0, 
	DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Channel_String_Params, 0, 
	DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Channel_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_SetSampleRate_String_Params[] = {
	"SetSampleRate"
};

int ExecuteMemberFunction__STACK_STACK_SetSampleRate_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_SetSampleRate_Rem_Call_Struct = {
	-468, 7, 0, ExecuteMemberFunction__STACK_STACK_SetSampleRate_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_SetSampleRate_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_DisplayOutputTiming_String_Params[] = {
	"DisplayOutputTiming"
};

int ExecuteMemberFunction__STACK_STACK_DisplayOutputTiming_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_DisplayOutputTiming_Rem_Call_Struct = {
	-469, 7, 0, ExecuteMemberFunction__STACK_STACK_DisplayOutputTiming_String_Params, 
	0, ExecuteMemberFunction__STACK_STACK_DisplayOutputTiming_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_NextFreeOutput_String_Params[] = {
	"NextFreeOutput"
};

int ExecuteMemberFunction__STACK_STACK_NextFreeOutput_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_NextFreeOutput_Rem_Call_Struct = {
	-470, 7, 0, ExecuteMemberFunction__STACK_STACK_NextFreeOutput_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_NextFreeOutput_Stack_Params
};
char * NodeDescribe__Ramp_String_Params[] = {
	"Ramp"
};

static CommandParameters NodeDescribe__Ramp_Rem_Call_Struct = {
	-471, 3, 0, NodeDescribe__Ramp_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Ramp_String_Params[] = {
	"Ramp"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Ramp_Rem_Call_Struct = {
	-472, 3, 0, CreateDefaultNodeInteractiveEntity__Ramp_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Ramp_String_Params[] = {
	"Ramp"
};

static CommandParameters CreateNodeInteractiveEntity__Ramp_Rem_Call_Struct = {
	-473, 3, 0, CreateNodeInteractiveEntity__Ramp_String_Params, 0, 0
};
char * DescribeNodeInstance__Ramp_STACK_String_Params[] = {
	"Ramp"
};

int DescribeNodeInstance__Ramp_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Ramp_STACK_Rem_Call_Struct = {
	-474, 4, 0, DescribeNodeInstance__Ramp_STACK_String_Params, 0, 
	DescribeNodeInstance__Ramp_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Ramp_STACK_String_Params[] = {
	"Ramp"
};

int DeleteNodeInteractiveEntity__Ramp_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Ramp_STACK_Rem_Call_Struct = {
	-475, 4, 0, DeleteNodeInteractiveEntity__Ramp_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Ramp_STACK_Stack_Params
};
char * DescribeParam__Ramp_Min_String_Params[] = {
	"Ramp", "Min"
};

static CommandParameters DescribeParam__Ramp_Min_Rem_Call_Struct = {
	-476, 5, 0, DescribeParam__Ramp_Min_String_Params, 0, 0
};
char * DescribeParam__Ramp_Max_String_Params[] = {
	"Ramp", "Max"
};

static CommandParameters DescribeParam__Ramp_Max_Rem_Call_Struct = {
	-477, 5, 0, DescribeParam__Ramp_Max_String_Params, 0, 0
};
char * DescribeParam__Ramp_Increment_String_Params[] = {
	"Ramp", "Increment"
};

static CommandParameters DescribeParam__Ramp_Increment_Rem_Call_Struct = {
	-478, 5, 0, DescribeParam__Ramp_Increment_String_Params, 0, 0
};
char * DescribeParamInstance__Ramp_STACK_Min_String_Params[] = {
	"Ramp", "Min"
};

int DescribeParamInstance__Ramp_STACK_Min_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Ramp_STACK_Min_Rem_Call_Struct = {
	-479, 6, 0, DescribeParamInstance__Ramp_STACK_Min_String_Params, 0, 
	DescribeParamInstance__Ramp_STACK_Min_Stack_Params
};
char * DescribeParamInstance__Ramp_STACK_Max_String_Params[] = {
	"Ramp", "Max"
};

int DescribeParamInstance__Ramp_STACK_Max_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Ramp_STACK_Max_Rem_Call_Struct = {
	-480, 6, 0, DescribeParamInstance__Ramp_STACK_Max_String_Params, 0, 
	DescribeParamInstance__Ramp_STACK_Max_Stack_Params
};
char * DescribeParamInstance__Ramp_STACK_Increment_String_Params[] = {
	"Ramp", "Increment"
};

int DescribeParamInstance__Ramp_STACK_Increment_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Ramp_STACK_Increment_Rem_Call_Struct = {
	-481, 6, 0, DescribeParamInstance__Ramp_STACK_Increment_String_Params, 0, 
	DescribeParamInstance__Ramp_STACK_Increment_Stack_Params
};
char * ExecuteSetParameter__Ramp_STACK_Min_String_Params[] = {
	"Ramp", "Min"
};

int ExecuteSetParameter__Ramp_STACK_Min_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Ramp_STACK_Min_Rem_Call_Struct = {
	-482, 6, 0, ExecuteSetParameter__Ramp_STACK_Min_String_Params, 0, 
	ExecuteSetParameter__Ramp_STACK_Min_Stack_Params
};
char * ExecuteSetParameter__Ramp_STACK_Max_String_Params[] = {
	"Ramp", "Max"
};

int ExecuteSetParameter__Ramp_STACK_Max_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Ramp_STACK_Max_Rem_Call_Struct = {
	-483, 6, 0, ExecuteSetParameter__Ramp_STACK_Max_String_Params, 0, 
	ExecuteSetParameter__Ramp_STACK_Max_Stack_Params
};
char * ExecuteSetParameter__Ramp_STACK_Increment_String_Params[] = {
	"Ramp", "Increment"
};

int ExecuteSetParameter__Ramp_STACK_Increment_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Ramp_STACK_Increment_Rem_Call_Struct = {
	-484, 6, 0, ExecuteSetParameter__Ramp_STACK_Increment_String_Params, 0, 
	ExecuteSetParameter__Ramp_STACK_Increment_Stack_Params
};
char * NodeDescribe__ReadFloat_String_Params[] = {
	"ReadFloat"
};

static CommandParameters NodeDescribe__ReadFloat_Rem_Call_Struct = {
	-485, 3, 0, NodeDescribe__ReadFloat_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__ReadFloat_String_Params[] = {
	"ReadFloat"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ReadFloat_Rem_Call_Struct = {
	-486, 3, 0, CreateDefaultNodeInteractiveEntity__ReadFloat_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ReadFloat_String_Params[] = {
	"ReadFloat"
};

static CommandParameters CreateNodeInteractiveEntity__ReadFloat_Rem_Call_Struct = {
	-487, 3, 0, CreateNodeInteractiveEntity__ReadFloat_String_Params, 0, 0
};
char * DescribeNodeInstance__ReadFloat_STACK_String_Params[] = {
	"ReadFloat"
};

int DescribeNodeInstance__ReadFloat_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ReadFloat_STACK_Rem_Call_Struct = {
	-488, 4, 0, DescribeNodeInstance__ReadFloat_STACK_String_Params, 0, 
	DescribeNodeInstance__ReadFloat_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ReadFloat_STACK_String_Params[] = {
	"ReadFloat"
};

int DeleteNodeInteractiveEntity__ReadFloat_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ReadFloat_STACK_Rem_Call_Struct = {
	-489, 4, 0, DeleteNodeInteractiveEntity__ReadFloat_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ReadFloat_STACK_Stack_Params
};
char * DescribeParam__ReadFloat_FileName_String_Params[] = {
	"ReadFloat", "FileName"
};

static CommandParameters DescribeParam__ReadFloat_FileName_Rem_Call_Struct = {
	-490, 5, 0, DescribeParam__ReadFloat_FileName_String_Params, 0, 0
};
char * DescribeParamInstance__ReadFloat_STACK_FileName_String_Params[] = {
	"ReadFloat", "FileName"
};

int DescribeParamInstance__ReadFloat_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ReadFloat_STACK_FileName_Rem_Call_Struct = {
	-491, 6, 0, DescribeParamInstance__ReadFloat_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__ReadFloat_STACK_FileName_Stack_Params
};
char * NodeDescribe__ReadInt_String_Params[] = {
	"ReadInt"
};

static CommandParameters NodeDescribe__ReadInt_Rem_Call_Struct = {
	-492, 3, 0, NodeDescribe__ReadInt_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__ReadInt_String_Params[] = {
	"ReadInt"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ReadInt_Rem_Call_Struct = {
	-493, 3, 0, CreateDefaultNodeInteractiveEntity__ReadInt_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ReadInt_String_Params[] = {
	"ReadInt"
};

static CommandParameters CreateNodeInteractiveEntity__ReadInt_Rem_Call_Struct = {
	-494, 3, 0, CreateNodeInteractiveEntity__ReadInt_String_Params, 0, 0
};
char * DescribeNodeInstance__ReadInt_STACK_String_Params[] = {
	"ReadInt"
};

int DescribeNodeInstance__ReadInt_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ReadInt_STACK_Rem_Call_Struct = {
	-495, 4, 0, DescribeNodeInstance__ReadInt_STACK_String_Params, 0, 
	DescribeNodeInstance__ReadInt_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ReadInt_STACK_String_Params[] = {
	"ReadInt"
};

int DeleteNodeInteractiveEntity__ReadInt_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ReadInt_STACK_Rem_Call_Struct = {
	-496, 4, 0, DeleteNodeInteractiveEntity__ReadInt_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ReadInt_STACK_Stack_Params
};
char * DescribeParam__ReadInt_FileName_String_Params[] = {
	"ReadInt", "FileName"
};

static CommandParameters DescribeParam__ReadInt_FileName_Rem_Call_Struct = {
	-497, 5, 0, DescribeParam__ReadInt_FileName_String_Params, 0, 0
};
char * DescribeParam__ReadInt_HexFlag_String_Params[] = {
	"ReadInt", "HexFlag"
};

static CommandParameters DescribeParam__ReadInt_HexFlag_Rem_Call_Struct = {
	-498, 5, 0, DescribeParam__ReadInt_HexFlag_String_Params, 0, 0
};
char * DescribeParamInstance__ReadInt_STACK_FileName_String_Params[] = {
	"ReadInt", "FileName"
};

int DescribeParamInstance__ReadInt_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ReadInt_STACK_FileName_Rem_Call_Struct = {
	-499, 6, 0, DescribeParamInstance__ReadInt_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__ReadInt_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__ReadInt_STACK_HexFlag_String_Params[] = {
	"ReadInt", "HexFlag"
};

int DescribeParamInstance__ReadInt_STACK_HexFlag_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ReadInt_STACK_HexFlag_Rem_Call_Struct = {
	-500, 6, 0, DescribeParamInstance__ReadInt_STACK_HexFlag_String_Params, 0, 
	DescribeParamInstance__ReadInt_STACK_HexFlag_Stack_Params
};
char * NodeDescribe__RepackWord_String_Params[] = {
	"RepackWord"
};

static CommandParameters NodeDescribe__RepackWord_Rem_Call_Struct = {
	-501, 3, 0, NodeDescribe__RepackWord_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__RepackWord_String_Params[] = {
	"RepackWord"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__RepackWord_Rem_Call_Struct = {
	-502, 3, 0, CreateDefaultNodeInteractiveEntity__RepackWord_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__RepackWord_String_Params[] = {
	"RepackWord"
};

static CommandParameters CreateNodeInteractiveEntity__RepackWord_Rem_Call_Struct = {
	-503, 3, 0, CreateNodeInteractiveEntity__RepackWord_String_Params, 0, 0
};
char * DescribeNodeInstance__RepackWord_STACK_String_Params[] = {
	"RepackWord"
};

int DescribeNodeInstance__RepackWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__RepackWord_STACK_Rem_Call_Struct = {
	-504, 4, 0, DescribeNodeInstance__RepackWord_STACK_String_Params, 0, 
	DescribeNodeInstance__RepackWord_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__RepackWord_STACK_String_Params[] = {
	"RepackWord"
};

int DeleteNodeInteractiveEntity__RepackWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__RepackWord_STACK_Rem_Call_Struct = {
	-505, 4, 0, DeleteNodeInteractiveEntity__RepackWord_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__RepackWord_STACK_Stack_Params
};
char * DescribeParam__RepackWord_OutputWordSize_String_Params[] = {
	"RepackWord", "OutputWordSize"
};

static CommandParameters DescribeParam__RepackWord_OutputWordSize_Rem_Call_Struct = {
	-506, 5, 0, DescribeParam__RepackWord_OutputWordSize_String_Params, 0, 0
};
char * DescribeParam__RepackWord_InputWordSize_String_Params[] = {
	"RepackWord", "InputWordSize"
};

static CommandParameters DescribeParam__RepackWord_InputWordSize_Rem_Call_Struct = {
	-507, 5, 0, DescribeParam__RepackWord_InputWordSize_String_Params, 0, 0
};
char * DescribeParamInstance__RepackWord_STACK_OutputWordSize_String_Params[] = {
	"RepackWord", "OutputWordSize"
};

int DescribeParamInstance__RepackWord_STACK_OutputWordSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__RepackWord_STACK_OutputWordSize_Rem_Call_Struct = {
	-508, 6, 0, DescribeParamInstance__RepackWord_STACK_OutputWordSize_String_Params, 
	0, DescribeParamInstance__RepackWord_STACK_OutputWordSize_Stack_Params
};
char * DescribeParamInstance__RepackWord_STACK_InputWordSize_String_Params[] = {
	"RepackWord", "InputWordSize"
};

int DescribeParamInstance__RepackWord_STACK_InputWordSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__RepackWord_STACK_InputWordSize_Rem_Call_Struct = {
	-509, 6, 0, DescribeParamInstance__RepackWord_STACK_InputWordSize_String_Params, 
	0, DescribeParamInstance__RepackWord_STACK_InputWordSize_Stack_Params
};
char * NodeDescribe__RealFir_String_Params[] = {
	"RealFir"
};

static CommandParameters NodeDescribe__RealFir_Rem_Call_Struct = {
	-510, 3, 0, NodeDescribe__RealFir_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__RealFir_String_Params[] = {
	"RealFir"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__RealFir_Rem_Call_Struct = {
	-511, 3, 0, CreateDefaultNodeInteractiveEntity__RealFir_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__RealFir_String_Params[] = {
	"RealFir"
};

static CommandParameters CreateNodeInteractiveEntity__RealFir_Rem_Call_Struct = {
	-512, 3, 0, CreateNodeInteractiveEntity__RealFir_String_Params, 0, 0
};
char * DescribeNodeInstance__RealFir_STACK_String_Params[] = {
	"RealFir"
};

int DescribeNodeInstance__RealFir_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__RealFir_STACK_Rem_Call_Struct = {
	-513, 4, 0, DescribeNodeInstance__RealFir_STACK_String_Params, 0, 
	DescribeNodeInstance__RealFir_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__RealFir_STACK_String_Params[] = {
	"RealFir"
};

int DeleteNodeInteractiveEntity__RealFir_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__RealFir_STACK_Rem_Call_Struct = {
	-514, 4, 0, DeleteNodeInteractiveEntity__RealFir_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__RealFir_STACK_Stack_Params
};
char * DescribeParam__RealFir_Resample_String_Params[] = {
	"RealFir", "Resample"
};

static CommandParameters DescribeParam__RealFir_Resample_Rem_Call_Struct = {
	-515, 5, 0, DescribeParam__RealFir_Resample_String_Params, 0, 0
};
char * DescribeParam__RealFir_ZeroPad_String_Params[] = {
	"RealFir", "ZeroPad"
};

static CommandParameters DescribeParam__RealFir_ZeroPad_Rem_Call_Struct = {
	-516, 5, 0, DescribeParam__RealFir_ZeroPad_String_Params, 0, 0
};
char * DescribeParam__RealFir_Odd_String_Params[] = {
	"RealFir", "Odd"
};

static CommandParameters DescribeParam__RealFir_Odd_Rem_Call_Struct = {
	-517, 5, 0, DescribeParam__RealFir_Odd_String_Params, 0, 0
};
char * DescribeParam__RealFir_Coeff_String_Params[] = {
	"RealFir", "Coeff"
};

static CommandParameters DescribeParam__RealFir_Coeff_Rem_Call_Struct = {
	-518, 5, 0, DescribeParam__RealFir_Coeff_String_Params, 0, 0
};
char * DescribeParamInstance__RealFir_STACK_Resample_String_Params[] = {
	"RealFir", "Resample"
};

int DescribeParamInstance__RealFir_STACK_Resample_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__RealFir_STACK_Resample_Rem_Call_Struct = {
	-519, 6, 0, DescribeParamInstance__RealFir_STACK_Resample_String_Params, 0, 
	DescribeParamInstance__RealFir_STACK_Resample_Stack_Params
};
char * DescribeParamInstance__RealFir_STACK_ZeroPad_String_Params[] = {
	"RealFir", "ZeroPad"
};

int DescribeParamInstance__RealFir_STACK_ZeroPad_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__RealFir_STACK_ZeroPad_Rem_Call_Struct = {
	-520, 6, 0, DescribeParamInstance__RealFir_STACK_ZeroPad_String_Params, 0, 
	DescribeParamInstance__RealFir_STACK_ZeroPad_Stack_Params
};
char * DescribeParamInstance__RealFir_STACK_Odd_String_Params[] = {
	"RealFir", "Odd"
};

int DescribeParamInstance__RealFir_STACK_Odd_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__RealFir_STACK_Odd_Rem_Call_Struct = {
	-521, 6, 0, DescribeParamInstance__RealFir_STACK_Odd_String_Params, 0, 
	DescribeParamInstance__RealFir_STACK_Odd_Stack_Params
};
char * DescribeParamInstance__RealFir_STACK_Coeff_String_Params[] = {
	"RealFir", "Coeff"
};

int DescribeParamInstance__RealFir_STACK_Coeff_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__RealFir_STACK_Coeff_Rem_Call_Struct = {
	-522, 6, 0, DescribeParamInstance__RealFir_STACK_Coeff_String_Params, 0, 
	DescribeParamInstance__RealFir_STACK_Coeff_Stack_Params
};
char * NodeDescribe__ExchBlcks_String_Params[] = {
	"ExchBlcks"
};

static CommandParameters NodeDescribe__ExchBlcks_Rem_Call_Struct = {
	-523, 3, 0, NodeDescribe__ExchBlcks_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__ExchBlcks_String_Params[] = {
	"ExchBlcks"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ExchBlcks_Rem_Call_Struct = {
	-524, 3, 0, CreateDefaultNodeInteractiveEntity__ExchBlcks_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ExchBlcks_String_Params[] = {
	"ExchBlcks"
};

static CommandParameters CreateNodeInteractiveEntity__ExchBlcks_Rem_Call_Struct = {
	-525, 3, 0, CreateNodeInteractiveEntity__ExchBlcks_String_Params, 0, 0
};
char * DescribeNodeInstance__ExchBlcks_STACK_String_Params[] = {
	"ExchBlcks"
};

int DescribeNodeInstance__ExchBlcks_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ExchBlcks_STACK_Rem_Call_Struct = {
	-526, 4, 0, DescribeNodeInstance__ExchBlcks_STACK_String_Params, 0, 
	DescribeNodeInstance__ExchBlcks_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ExchBlcks_STACK_String_Params[] = {
	"ExchBlcks"
};

int DeleteNodeInteractiveEntity__ExchBlcks_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ExchBlcks_STACK_Rem_Call_Struct = {
	-527, 4, 0, DeleteNodeInteractiveEntity__ExchBlcks_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ExchBlcks_STACK_Stack_Params
};
char * DescribeParam__ExchBlcks_Size_String_Params[] = {
	"ExchBlcks", "Size"
};

static CommandParameters DescribeParam__ExchBlcks_Size_Rem_Call_Struct = {
	-528, 5, 0, DescribeParam__ExchBlcks_Size_String_Params, 0, 0
};
char * DescribeParam__ExchBlcks_Exchange_String_Params[] = {
	"ExchBlcks", "Exchange"
};

static CommandParameters DescribeParam__ExchBlcks_Exchange_Rem_Call_Struct = {
	-529, 5, 0, DescribeParam__ExchBlcks_Exchange_String_Params, 0, 0
};
char * DescribeParamInstance__ExchBlcks_STACK_Size_String_Params[] = {
	"ExchBlcks", "Size"
};

int DescribeParamInstance__ExchBlcks_STACK_Size_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ExchBlcks_STACK_Size_Rem_Call_Struct = {
	-530, 6, 0, DescribeParamInstance__ExchBlcks_STACK_Size_String_Params, 0, 
	DescribeParamInstance__ExchBlcks_STACK_Size_Stack_Params
};
char * DescribeParamInstance__ExchBlcks_STACK_Exchange_String_Params[] = {
	"ExchBlcks", "Exchange"
};

int DescribeParamInstance__ExchBlcks_STACK_Exchange_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ExchBlcks_STACK_Exchange_Rem_Call_Struct = {
	-531, 6, 0, DescribeParamInstance__ExchBlcks_STACK_Exchange_String_Params, 0, 
	DescribeParamInstance__ExchBlcks_STACK_Exchange_Stack_Params
};
char * NodeDescribe__ExchBits_String_Params[] = {
	"ExchBits"
};

static CommandParameters NodeDescribe__ExchBits_Rem_Call_Struct = {
	-532, 3, 0, NodeDescribe__ExchBits_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__ExchBits_String_Params[] = {
	"ExchBits"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ExchBits_Rem_Call_Struct = {
	-533, 3, 0, CreateDefaultNodeInteractiveEntity__ExchBits_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ExchBits_String_Params[] = {
	"ExchBits"
};

static CommandParameters CreateNodeInteractiveEntity__ExchBits_Rem_Call_Struct = {
	-534, 3, 0, CreateNodeInteractiveEntity__ExchBits_String_Params, 0, 0
};
char * DescribeNodeInstance__ExchBits_STACK_String_Params[] = {
	"ExchBits"
};

int DescribeNodeInstance__ExchBits_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ExchBits_STACK_Rem_Call_Struct = {
	-535, 4, 0, DescribeNodeInstance__ExchBits_STACK_String_Params, 0, 
	DescribeNodeInstance__ExchBits_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ExchBits_STACK_String_Params[] = {
	"ExchBits"
};

int DeleteNodeInteractiveEntity__ExchBits_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ExchBits_STACK_Rem_Call_Struct = {
	-536, 4, 0, DeleteNodeInteractiveEntity__ExchBits_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ExchBits_STACK_Stack_Params
};
char * DescribeParam__ExchBits_Size_String_Params[] = {
	"ExchBits", "Size"
};

static CommandParameters DescribeParam__ExchBits_Size_Rem_Call_Struct = {
	-537, 5, 0, DescribeParam__ExchBits_Size_String_Params, 0, 0
};
char * DescribeParam__ExchBits_Exchange_String_Params[] = {
	"ExchBits", "Exchange"
};

static CommandParameters DescribeParam__ExchBits_Exchange_Rem_Call_Struct = {
	-538, 5, 0, DescribeParam__ExchBits_Exchange_String_Params, 0, 0
};
char * DescribeParamInstance__ExchBits_STACK_Size_String_Params[] = {
	"ExchBits", "Size"
};

int DescribeParamInstance__ExchBits_STACK_Size_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ExchBits_STACK_Size_Rem_Call_Struct = {
	-539, 6, 0, DescribeParamInstance__ExchBits_STACK_Size_String_Params, 0, 
	DescribeParamInstance__ExchBits_STACK_Size_Stack_Params
};
char * DescribeParamInstance__ExchBits_STACK_Exchange_String_Params[] = {
	"ExchBits", "Exchange"
};

int DescribeParamInstance__ExchBits_STACK_Exchange_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ExchBits_STACK_Exchange_Rem_Call_Struct = {
	-540, 6, 0, DescribeParamInstance__ExchBits_STACK_Exchange_String_Params, 0, 
	DescribeParamInstance__ExchBits_STACK_Exchange_Stack_Params
};
char * MemberFunctionDescribe__SignalStr_STACK_String_Params[] = {
	"SignalStr"
};

int MemberFunctionDescribe__SignalStr_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__SignalStr_STACK_Rem_Call_Struct = {
	-541, 4, 0, MemberFunctionDescribe__SignalStr_STACK_String_Params, 0, 
	MemberFunctionDescribe__SignalStr_STACK_Stack_Params
};
char * DescribeMemberFunctionParameter__SignalStr_STACK_Rate_String_Params[] = {
	"SignalStr", "Rate"
};

int DescribeMemberFunctionParameter__SignalStr_STACK_Rate_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__SignalStr_STACK_Rate_Rem_Call_Struct = {
	-542, 6, 0, DescribeMemberFunctionParameter__SignalStr_STACK_Rate_String_Params, 
	0, DescribeMemberFunctionParameter__SignalStr_STACK_Rate_Stack_Params
};
char * DescribeMemberFunctionParameter__SignalStr_STACK_Channel_String_Params[] = {
	"SignalStr", "Channel"
};

int DescribeMemberFunctionParameter__SignalStr_STACK_Channel_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__SignalStr_STACK_Channel_Rem_Call_Struct = {
	-543, 6, 0, 
	DescribeMemberFunctionParameter__SignalStr_STACK_Channel_String_Params, 0, 
	DescribeMemberFunctionParameter__SignalStr_STACK_Channel_Stack_Params
};
char * NodeDescribe__TargetSystem_String_Params[] = {
	"TargetSystem"
};

static CommandParameters NodeDescribe__TargetSystem_Rem_Call_Struct = {
	-544, 3, 0, NodeDescribe__TargetSystem_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__TargetSystem_String_Params[] = {
	"TargetSystem"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__TargetSystem_Rem_Call_Struct = {
	-545, 3, 0, CreateDefaultNodeInteractiveEntity__TargetSystem_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__TargetSystem_String_Params[] = {
	"TargetSystem"
};

static CommandParameters CreateNodeInteractiveEntity__TargetSystem_Rem_Call_Struct = {
	-546, 3, 0, CreateNodeInteractiveEntity__TargetSystem_String_Params, 0, 0
};
char * MemberFunctionDescribe__TargetSystem_STACK_String_Params[] = {
	"TargetSystem"
};

int MemberFunctionDescribe__TargetSystem_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__TargetSystem_STACK_Rem_Call_Struct = {
	-547, 4, 0, MemberFunctionDescribe__TargetSystem_STACK_String_Params, 0, 
	MemberFunctionDescribe__TargetSystem_STACK_Stack_Params
};
char * DescribeMemberFunctionParameter__TargetSystem_STACK_TheNet_String_Params[] = {
	"TargetSystem", "TheNet"
};

int DescribeMemberFunctionParameter__TargetSystem_STACK_TheNet_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__TargetSystem_STACK_TheNet_Rem_Call_Struct = {
	-548, 6, 0, 
	DescribeMemberFunctionParameter__TargetSystem_STACK_TheNet_String_Params, 0, 
	DescribeMemberFunctionParameter__TargetSystem_STACK_TheNet_Stack_Params
};
char * DescribeMemberFunctionParameter__TargetSystem_STACK_GroupName_String_Params[] = {
	"TargetSystem", "GroupName"
};

int DescribeMemberFunctionParameter__TargetSystem_STACK_GroupName_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__TargetSystem_STACK_GroupName_Rem_Call_Struct = {
	-549, 6, 0, 
	DescribeMemberFunctionParameter__TargetSystem_STACK_GroupName_String_Params, 0, 
	DescribeMemberFunctionParameter__TargetSystem_STACK_GroupName_Stack_Params
};
char * DescribeNodeInstance__TargetSystem_STACK_String_Params[] = {
	"TargetSystem"
};

int DescribeNodeInstance__TargetSystem_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__TargetSystem_STACK_Rem_Call_Struct = {
	-550, 4, 0, DescribeNodeInstance__TargetSystem_STACK_String_Params, 0, 
	DescribeNodeInstance__TargetSystem_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__TargetSystem_STACK_String_Params[] = {
	"TargetSystem"
};

int DeleteNodeInteractiveEntity__TargetSystem_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__TargetSystem_STACK_Rem_Call_Struct = {
	-551, 4, 0, DeleteNodeInteractiveEntity__TargetSystem_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__TargetSystem_STACK_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_AddParallelNet_String_Params[] = {
	"AddParallelNet"
};

int ExecuteMemberFunction__STACK_STACK_AddParallelNet_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_AddParallelNet_Rem_Call_Struct = {
	-552, 7, 0, ExecuteMemberFunction__STACK_STACK_AddParallelNet_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_AddParallelNet_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_MakeOneNetGroup_String_Params[] = {
	"MakeOneNetGroup"
};

int ExecuteMemberFunction__STACK_STACK_MakeOneNetGroup_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_MakeOneNetGroup_Rem_Call_Struct = {
	-553, 7, 0, ExecuteMemberFunction__STACK_STACK_MakeOneNetGroup_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_MakeOneNetGroup_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_MakeGroup_String_Params[] = {
	"MakeGroup"
};

int ExecuteMemberFunction__STACK_STACK_MakeGroup_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_MakeGroup_Rem_Call_Struct = {
	-554, 7, 0, ExecuteMemberFunction__STACK_STACK_MakeGroup_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_MakeGroup_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_AddToGroup_String_Params[] = {
	"AddToGroup"
};

int ExecuteMemberFunction__STACK_STACK_AddToGroup_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_AddToGroup_Rem_Call_Struct = {
	-555, 7, 0, ExecuteMemberFunction__STACK_STACK_AddToGroup_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_AddToGroup_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_Describe_String_Params[] = {
	"Describe"
};

int ExecuteMemberFunction__STACK_STACK_Describe_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_Describe_Rem_Call_Struct = {
	-556, 7, 0, ExecuteMemberFunction__STACK_STACK_Describe_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_Describe_Stack_Params
};
char * DescribeParam__TargetSystem_InterfaceDirectory_String_Params[] = {
	"TargetSystem", "InterfaceDirectory"
};

static CommandParameters DescribeParam__TargetSystem_InterfaceDirectory_Rem_Call_Struct = {
	-557, 5, 0, DescribeParam__TargetSystem_InterfaceDirectory_String_Params, 0, 0
};
char * DescribeParam__TargetSystem_Target_String_Params[] = {
	"TargetSystem", "Target"
};

static CommandParameters DescribeParam__TargetSystem_Target_Rem_Call_Struct = {
	-558, 5, 0, DescribeParam__TargetSystem_Target_String_Params, 0, 0
};
char * DescribeParam__TargetSystem_Flags_String_Params[] = {
	"TargetSystem", "Flags"
};

static CommandParameters DescribeParam__TargetSystem_Flags_Rem_Call_Struct = {
	-559, 5, 0, DescribeParam__TargetSystem_Flags_String_Params, 0, 0
};
char * DescribeParam__TargetSystem_Channels_String_Params[] = {
	"TargetSystem", "Channels"
};

static CommandParameters DescribeParam__TargetSystem_Channels_Rem_Call_Struct = {
	-560, 5, 0, DescribeParam__TargetSystem_Channels_String_Params, 0, 0
};
char * DescribeParam__TargetSystem_Directory_String_Params[] = {
	"TargetSystem", "Directory"
};

static CommandParameters DescribeParam__TargetSystem_Directory_Rem_Call_Struct = {
	-561, 5, 0, DescribeParam__TargetSystem_Directory_String_Params, 0, 0
};
char * DescribeParam__TargetSystem_TargetName_String_Params[] = {
	"TargetSystem", "TargetName"
};

static CommandParameters DescribeParam__TargetSystem_TargetName_Rem_Call_Struct = {
	-562, 5, 0, DescribeParam__TargetSystem_TargetName_String_Params, 0, 0
};
char * DescribeParamInstance__TargetSystem_STACK_InterfaceDirectory_String_Params[] = {
	"TargetSystem", "InterfaceDirectory"
};

int DescribeParamInstance__TargetSystem_STACK_InterfaceDirectory_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__TargetSystem_STACK_InterfaceDirectory_Rem_Call_Struct = {
	-563, 6, 0, 
	DescribeParamInstance__TargetSystem_STACK_InterfaceDirectory_String_Params, 0, 
	DescribeParamInstance__TargetSystem_STACK_InterfaceDirectory_Stack_Params
};
char * DescribeParamInstance__TargetSystem_STACK_Target_String_Params[] = {
	"TargetSystem", "Target"
};

int DescribeParamInstance__TargetSystem_STACK_Target_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__TargetSystem_STACK_Target_Rem_Call_Struct = {
	-564, 6, 0, DescribeParamInstance__TargetSystem_STACK_Target_String_Params, 0, 
	DescribeParamInstance__TargetSystem_STACK_Target_Stack_Params
};
char * DescribeParamInstance__TargetSystem_STACK_Flags_String_Params[] = {
	"TargetSystem", "Flags"
};

int DescribeParamInstance__TargetSystem_STACK_Flags_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__TargetSystem_STACK_Flags_Rem_Call_Struct = {
	-565, 6, 0, DescribeParamInstance__TargetSystem_STACK_Flags_String_Params, 0, 
	DescribeParamInstance__TargetSystem_STACK_Flags_Stack_Params
};
char * DescribeParamInstance__TargetSystem_STACK_Channels_String_Params[] = {
	"TargetSystem", "Channels"
};

int DescribeParamInstance__TargetSystem_STACK_Channels_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__TargetSystem_STACK_Channels_Rem_Call_Struct = {
	-566, 6, 0, DescribeParamInstance__TargetSystem_STACK_Channels_String_Params, 0, 
	DescribeParamInstance__TargetSystem_STACK_Channels_Stack_Params
};
char * DescribeParamInstance__TargetSystem_STACK_Directory_String_Params[] = {
	"TargetSystem", "Directory"
};

int DescribeParamInstance__TargetSystem_STACK_Directory_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__TargetSystem_STACK_Directory_Rem_Call_Struct = {
	-567, 6, 0, DescribeParamInstance__TargetSystem_STACK_Directory_String_Params, 0, 
	DescribeParamInstance__TargetSystem_STACK_Directory_Stack_Params
};
char * DescribeParamInstance__TargetSystem_STACK_TargetName_String_Params[] = {
	"TargetSystem", "TargetName"
};

int DescribeParamInstance__TargetSystem_STACK_TargetName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__TargetSystem_STACK_TargetName_Rem_Call_Struct = {
	-568, 6, 0, DescribeParamInstance__TargetSystem_STACK_TargetName_String_Params, 
	0, DescribeParamInstance__TargetSystem_STACK_TargetName_Stack_Params
};
char * NodeDescribe__ToMach_String_Params[] = {
	"ToMach"
};

static CommandParameters NodeDescribe__ToMach_Rem_Call_Struct = {
	-569, 3, 0, NodeDescribe__ToMach_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__ToMach_String_Params[] = {
	"ToMach"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ToMach_Rem_Call_Struct = {
	-570, 3, 0, CreateDefaultNodeInteractiveEntity__ToMach_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ToMach_String_Params[] = {
	"ToMach"
};

static CommandParameters CreateNodeInteractiveEntity__ToMach_Rem_Call_Struct = {
	-571, 3, 0, CreateNodeInteractiveEntity__ToMach_String_Params, 0, 0
};
char * DescribeNodeInstance__ToMach_STACK_String_Params[] = {
	"ToMach"
};

int DescribeNodeInstance__ToMach_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ToMach_STACK_Rem_Call_Struct = {
	-572, 4, 0, DescribeNodeInstance__ToMach_STACK_String_Params, 0, 
	DescribeNodeInstance__ToMach_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ToMach_STACK_String_Params[] = {
	"ToMach"
};

int DeleteNodeInteractiveEntity__ToMach_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ToMach_STACK_Rem_Call_Struct = {
	-573, 4, 0, DeleteNodeInteractiveEntity__ToMach_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ToMach_STACK_Stack_Params
};
char * NodeDescribe__DCTrap_String_Params[] = {
	"DCTrap"
};

static CommandParameters NodeDescribe__DCTrap_Rem_Call_Struct = {
	-574, 3, 0, NodeDescribe__DCTrap_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__DCTrap_String_Params[] = {
	"DCTrap"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__DCTrap_Rem_Call_Struct = {
	-575, 3, 0, CreateDefaultNodeInteractiveEntity__DCTrap_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__DCTrap_String_Params[] = {
	"DCTrap"
};

static CommandParameters CreateNodeInteractiveEntity__DCTrap_Rem_Call_Struct = {
	-576, 3, 0, CreateNodeInteractiveEntity__DCTrap_String_Params, 0, 0
};
char * DescribeNodeInstance__DCTrap_STACK_String_Params[] = {
	"DCTrap"
};

int DescribeNodeInstance__DCTrap_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__DCTrap_STACK_Rem_Call_Struct = {
	-577, 4, 0, DescribeNodeInstance__DCTrap_STACK_String_Params, 0, 
	DescribeNodeInstance__DCTrap_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__DCTrap_STACK_String_Params[] = {
	"DCTrap"
};

int DeleteNodeInteractiveEntity__DCTrap_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__DCTrap_STACK_Rem_Call_Struct = {
	-578, 4, 0, DeleteNodeInteractiveEntity__DCTrap_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__DCTrap_STACK_Stack_Params
};
char * DescribeParam__DCTrap_Type_String_Params[] = {
	"DCTrap", "Type"
};

static CommandParameters DescribeParam__DCTrap_Type_Rem_Call_Struct = {
	-579, 5, 0, DescribeParam__DCTrap_Type_String_Params, 0, 0
};
char * DescribeParam__DCTrap_Weight_String_Params[] = {
	"DCTrap", "Weight"
};

static CommandParameters DescribeParam__DCTrap_Weight_Rem_Call_Struct = {
	-580, 5, 0, DescribeParam__DCTrap_Weight_String_Params, 0, 0
};
char * DescribeParamInstance__DCTrap_STACK_Type_String_Params[] = {
	"DCTrap", "Type"
};

int DescribeParamInstance__DCTrap_STACK_Type_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__DCTrap_STACK_Type_Rem_Call_Struct = {
	-581, 6, 0, DescribeParamInstance__DCTrap_STACK_Type_String_Params, 0, 
	DescribeParamInstance__DCTrap_STACK_Type_Stack_Params
};
char * DescribeParamInstance__DCTrap_STACK_Weight_String_Params[] = {
	"DCTrap", "Weight"
};

int DescribeParamInstance__DCTrap_STACK_Weight_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__DCTrap_STACK_Weight_Rem_Call_Struct = {
	-582, 6, 0, DescribeParamInstance__DCTrap_STACK_Weight_String_Params, 0, 
	DescribeParamInstance__DCTrap_STACK_Weight_Stack_Params
};
char * NodeDescribe__UniformNoise_String_Params[] = {
	"UniformNoise"
};

static CommandParameters NodeDescribe__UniformNoise_Rem_Call_Struct = {
	-583, 3, 0, NodeDescribe__UniformNoise_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__UniformNoise_String_Params[] = {
	"UniformNoise"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__UniformNoise_Rem_Call_Struct = {
	-584, 3, 0, CreateDefaultNodeInteractiveEntity__UniformNoise_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__UniformNoise_String_Params[] = {
	"UniformNoise"
};

static CommandParameters CreateNodeInteractiveEntity__UniformNoise_Rem_Call_Struct = {
	-585, 3, 0, CreateNodeInteractiveEntity__UniformNoise_String_Params, 0, 0
};
char * DescribeNodeInstance__UniformNoise_STACK_String_Params[] = {
	"UniformNoise"
};

int DescribeNodeInstance__UniformNoise_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__UniformNoise_STACK_Rem_Call_Struct = {
	-586, 4, 0, DescribeNodeInstance__UniformNoise_STACK_String_Params, 0, 
	DescribeNodeInstance__UniformNoise_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__UniformNoise_STACK_String_Params[] = {
	"UniformNoise"
};

int DeleteNodeInteractiveEntity__UniformNoise_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__UniformNoise_STACK_Rem_Call_Struct = {
	-587, 4, 0, DeleteNodeInteractiveEntity__UniformNoise_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__UniformNoise_STACK_Stack_Params
};
char * DescribeParam__UniformNoise_Maximum_String_Params[] = {
	"UniformNoise", "Maximum"
};

static CommandParameters DescribeParam__UniformNoise_Maximum_Rem_Call_Struct = {
	-588, 5, 0, DescribeParam__UniformNoise_Maximum_String_Params, 0, 0
};
char * DescribeParam__UniformNoise_Minimum_String_Params[] = {
	"UniformNoise", "Minimum"
};

static CommandParameters DescribeParam__UniformNoise_Minimum_Rem_Call_Struct = {
	-589, 5, 0, DescribeParam__UniformNoise_Minimum_String_Params, 0, 0
};
char * DescribeParam__UniformNoise_ElementSize_String_Params[] = {
	"UniformNoise", "ElementSize"
};

static CommandParameters DescribeParam__UniformNoise_ElementSize_Rem_Call_Struct = {
	-590, 5, 0, DescribeParam__UniformNoise_ElementSize_String_Params, 0, 0
};
char * DescribeParamInstance__UniformNoise_STACK_Maximum_String_Params[] = {
	"UniformNoise", "Maximum"
};

int DescribeParamInstance__UniformNoise_STACK_Maximum_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__UniformNoise_STACK_Maximum_Rem_Call_Struct = {
	-591, 6, 0, DescribeParamInstance__UniformNoise_STACK_Maximum_String_Params, 0, 
	DescribeParamInstance__UniformNoise_STACK_Maximum_Stack_Params
};
char * DescribeParamInstance__UniformNoise_STACK_Minimum_String_Params[] = {
	"UniformNoise", "Minimum"
};

int DescribeParamInstance__UniformNoise_STACK_Minimum_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__UniformNoise_STACK_Minimum_Rem_Call_Struct = {
	-592, 6, 0, DescribeParamInstance__UniformNoise_STACK_Minimum_String_Params, 0, 
	DescribeParamInstance__UniformNoise_STACK_Minimum_Stack_Params
};
char * DescribeParamInstance__UniformNoise_STACK_ElementSize_String_Params[] = {
	"UniformNoise", "ElementSize"
};

int DescribeParamInstance__UniformNoise_STACK_ElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__UniformNoise_STACK_ElementSize_Rem_Call_Struct = {
	-593, 6, 0, DescribeParamInstance__UniformNoise_STACK_ElementSize_String_Params, 
	0, DescribeParamInstance__UniformNoise_STACK_ElementSize_Stack_Params
};
char * ExecuteSetParameter__UniformNoise_STACK_Maximum_String_Params[] = {
	"UniformNoise", "Maximum"
};

int ExecuteSetParameter__UniformNoise_STACK_Maximum_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__UniformNoise_STACK_Maximum_Rem_Call_Struct = {
	-594, 6, 0, ExecuteSetParameter__UniformNoise_STACK_Maximum_String_Params, 0, 
	ExecuteSetParameter__UniformNoise_STACK_Maximum_Stack_Params
};
char * ExecuteSetParameter__UniformNoise_STACK_Minimum_String_Params[] = {
	"UniformNoise", "Minimum"
};

int ExecuteSetParameter__UniformNoise_STACK_Minimum_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__UniformNoise_STACK_Minimum_Rem_Call_Struct = {
	-595, 6, 0, ExecuteSetParameter__UniformNoise_STACK_Minimum_String_Params, 0, 
	ExecuteSetParameter__UniformNoise_STACK_Minimum_Stack_Params
};
char * NodeDescribe__UnpackWord_String_Params[] = {
	"UnpackWord"
};

static CommandParameters NodeDescribe__UnpackWord_Rem_Call_Struct = {
	-596, 3, 0, NodeDescribe__UnpackWord_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__UnpackWord_String_Params[] = {
	"UnpackWord"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__UnpackWord_Rem_Call_Struct = {
	-597, 3, 0, CreateDefaultNodeInteractiveEntity__UnpackWord_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__UnpackWord_String_Params[] = {
	"UnpackWord"
};

static CommandParameters CreateNodeInteractiveEntity__UnpackWord_Rem_Call_Struct = {
	-598, 3, 0, CreateNodeInteractiveEntity__UnpackWord_String_Params, 0, 0
};
char * DescribeNodeInstance__UnpackWord_STACK_String_Params[] = {
	"UnpackWord"
};

int DescribeNodeInstance__UnpackWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__UnpackWord_STACK_Rem_Call_Struct = {
	-599, 4, 0, DescribeNodeInstance__UnpackWord_STACK_String_Params, 0, 
	DescribeNodeInstance__UnpackWord_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__UnpackWord_STACK_String_Params[] = {
	"UnpackWord"
};

int DeleteNodeInteractiveEntity__UnpackWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__UnpackWord_STACK_Rem_Call_Struct = {
	-600, 4, 0, DeleteNodeInteractiveEntity__UnpackWord_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__UnpackWord_STACK_Stack_Params
};
char * DescribeParam__UnpackWord_OutputWordSize_String_Params[] = {
	"UnpackWord", "OutputWordSize"
};

static CommandParameters DescribeParam__UnpackWord_OutputWordSize_Rem_Call_Struct = {
	-601, 5, 0, DescribeParam__UnpackWord_OutputWordSize_String_Params, 0, 0
};
char * DescribeParam__UnpackWord_InputWordSize_String_Params[] = {
	"UnpackWord", "InputWordSize"
};

static CommandParameters DescribeParam__UnpackWord_InputWordSize_Rem_Call_Struct = {
	-602, 5, 0, DescribeParam__UnpackWord_InputWordSize_String_Params, 0, 0
};
char * DescribeParamInstance__UnpackWord_STACK_OutputWordSize_String_Params[] = {
	"UnpackWord", "OutputWordSize"
};

int DescribeParamInstance__UnpackWord_STACK_OutputWordSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__UnpackWord_STACK_OutputWordSize_Rem_Call_Struct = {
	-603, 6, 0, DescribeParamInstance__UnpackWord_STACK_OutputWordSize_String_Params, 
	0, DescribeParamInstance__UnpackWord_STACK_OutputWordSize_Stack_Params
};
char * DescribeParamInstance__UnpackWord_STACK_InputWordSize_String_Params[] = {
	"UnpackWord", "InputWordSize"
};

int DescribeParamInstance__UnpackWord_STACK_InputWordSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__UnpackWord_STACK_InputWordSize_Rem_Call_Struct = {
	-604, 6, 0, DescribeParamInstance__UnpackWord_STACK_InputWordSize_String_Params, 
	0, DescribeParamInstance__UnpackWord_STACK_InputWordSize_Stack_Params
};
char * NodeDescribe__VoiceNode_String_Params[] = {
	"VoiceNode"
};

static CommandParameters NodeDescribe__VoiceNode_Rem_Call_Struct = {
	-605, 3, 0, NodeDescribe__VoiceNode_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__VoiceNode_String_Params[] = {
	"VoiceNode"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__VoiceNode_Rem_Call_Struct = {
	-606, 3, 0, CreateDefaultNodeInteractiveEntity__VoiceNode_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__VoiceNode_String_Params[] = {
	"VoiceNode"
};

static CommandParameters CreateNodeInteractiveEntity__VoiceNode_Rem_Call_Struct = {
	-607, 3, 0, CreateNodeInteractiveEntity__VoiceNode_String_Params, 0, 0
};
char * MemberFunctionDescribe__VoiceNode_STACK_String_Params[] = {
	"VoiceNode"
};

int MemberFunctionDescribe__VoiceNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__VoiceNode_STACK_Rem_Call_Struct = {
	-608, 4, 0, MemberFunctionDescribe__VoiceNode_STACK_String_Params, 0, 
	MemberFunctionDescribe__VoiceNode_STACK_Stack_Params
};
char * DescribeNodeInstance__VoiceNode_STACK_String_Params[] = {
	"VoiceNode"
};

int DescribeNodeInstance__VoiceNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__VoiceNode_STACK_Rem_Call_Struct = {
	-609, 4, 0, DescribeNodeInstance__VoiceNode_STACK_String_Params, 0, 
	DescribeNodeInstance__VoiceNode_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__VoiceNode_STACK_String_Params[] = {
	"VoiceNode"
};

int DeleteNodeInteractiveEntity__VoiceNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__VoiceNode_STACK_Rem_Call_Struct = {
	-610, 4, 0, DeleteNodeInteractiveEntity__VoiceNode_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__VoiceNode_STACK_Stack_Params
};
char * DescribeParam__VoiceNode_FileName_String_Params[] = {
	"VoiceNode", "FileName"
};

static CommandParameters DescribeParam__VoiceNode_FileName_Rem_Call_Struct = {
	-611, 5, 0, DescribeParam__VoiceNode_FileName_String_Params, 0, 0
};
char * DescribeParamInstance__VoiceNode_STACK_FileName_String_Params[] = {
	"VoiceNode", "FileName"
};

int DescribeParamInstance__VoiceNode_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__VoiceNode_STACK_FileName_Rem_Call_Struct = {
	-612, 6, 0, DescribeParamInstance__VoiceNode_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__VoiceNode_STACK_FileName_Stack_Params
};
char * NodeDescribe__EyePlot_String_Params[] = {
	"EyePlot"
};

static CommandParameters NodeDescribe__EyePlot_Rem_Call_Struct = {
	-613, 3, 0, NodeDescribe__EyePlot_String_Params, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__EyePlot_String_Params[] = {
	"EyePlot"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__EyePlot_Rem_Call_Struct = {
	-614, 3, 0, CreateDefaultNodeInteractiveEntity__EyePlot_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__EyePlot_String_Params[] = {
	"EyePlot"
};

static CommandParameters CreateNodeInteractiveEntity__EyePlot_Rem_Call_Struct = {
	-615, 3, 0, CreateNodeInteractiveEntity__EyePlot_String_Params, 0, 0
};
char * DescribeNodeInstance__EyePlot_STACK_String_Params[] = {
	"EyePlot"
};

int DescribeNodeInstance__EyePlot_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__EyePlot_STACK_Rem_Call_Struct = {
	-616, 4, 0, DescribeNodeInstance__EyePlot_STACK_String_Params, 0, 
	DescribeNodeInstance__EyePlot_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__EyePlot_STACK_String_Params[] = {
	"EyePlot"
};

int DeleteNodeInteractiveEntity__EyePlot_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__EyePlot_STACK_Rem_Call_Struct = {
	-617, 4, 0, DeleteNodeInteractiveEntity__EyePlot_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__EyePlot_STACK_Stack_Params
};
char * DescribeParam__EyePlot_Channels_String_Params[] = {
	"EyePlot", "Channels"
};

static CommandParameters DescribeParam__EyePlot_Channels_Rem_Call_Struct = {
	-618, 5, 0, DescribeParam__EyePlot_Channels_String_Params, 0, 0
};
char * DescribeParam__EyePlot_SamplesPerPlot_String_Params[] = {
	"EyePlot", "SamplesPerPlot"
};

static CommandParameters DescribeParam__EyePlot_SamplesPerPlot_Rem_Call_Struct = {
	-619, 5, 0, DescribeParam__EyePlot_SamplesPerPlot_String_Params, 0, 0
};
char * DescribeParam__EyePlot_MinX_String_Params[] = {
	"EyePlot", "MinX"
};

static CommandParameters DescribeParam__EyePlot_MinX_Rem_Call_Struct = {
	-620, 5, 0, DescribeParam__EyePlot_MinX_String_Params, 0, 0
};
char * DescribeParam__EyePlot_MaxX_String_Params[] = {
	"EyePlot", "MaxX"
};

static CommandParameters DescribeParam__EyePlot_MaxX_Rem_Call_Struct = {
	-621, 5, 0, DescribeParam__EyePlot_MaxX_String_Params, 0, 0
};
char * DescribeParam__EyePlot_MinY_String_Params[] = {
	"EyePlot", "MinY"
};

static CommandParameters DescribeParam__EyePlot_MinY_Rem_Call_Struct = {
	-622, 5, 0, DescribeParam__EyePlot_MinY_String_Params, 0, 0
};
char * DescribeParam__EyePlot_MaxY_String_Params[] = {
	"EyePlot", "MaxY"
};

static CommandParameters DescribeParam__EyePlot_MaxY_Rem_Call_Struct = {
	-623, 5, 0, DescribeParam__EyePlot_MaxY_String_Params, 0, 0
};
char * DescribeParam__EyePlot_Caption_String_Params[] = {
	"EyePlot", "Caption"
};

static CommandParameters DescribeParam__EyePlot_Caption_Rem_Call_Struct = {
	-624, 5, 0, DescribeParam__EyePlot_Caption_String_Params, 0, 0
};
char * DescribeParamInstance__EyePlot_STACK_Channels_String_Params[] = {
	"EyePlot", "Channels"
};

int DescribeParamInstance__EyePlot_STACK_Channels_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__EyePlot_STACK_Channels_Rem_Call_Struct = {
	-625, 6, 0, DescribeParamInstance__EyePlot_STACK_Channels_String_Params, 0, 
	DescribeParamInstance__EyePlot_STACK_Channels_Stack_Params
};
char * DescribeParamInstance__EyePlot_STACK_SamplesPerPlot_String_Params[] = {
	"EyePlot", "SamplesPerPlot"
};

int DescribeParamInstance__EyePlot_STACK_SamplesPerPlot_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__EyePlot_STACK_SamplesPerPlot_Rem_Call_Struct = {
	-626, 6, 0, DescribeParamInstance__EyePlot_STACK_SamplesPerPlot_String_Params, 0, 
	DescribeParamInstance__EyePlot_STACK_SamplesPerPlot_Stack_Params
};
char * DescribeParamInstance__EyePlot_STACK_MinX_String_Params[] = {
	"EyePlot", "MinX"
};

int DescribeParamInstance__EyePlot_STACK_MinX_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__EyePlot_STACK_MinX_Rem_Call_Struct = {
	-627, 6, 0, DescribeParamInstance__EyePlot_STACK_MinX_String_Params, 0, 
	DescribeParamInstance__EyePlot_STACK_MinX_Stack_Params
};
char * DescribeParamInstance__EyePlot_STACK_MaxX_String_Params[] = {
	"EyePlot", "MaxX"
};

int DescribeParamInstance__EyePlot_STACK_MaxX_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__EyePlot_STACK_MaxX_Rem_Call_Struct = {
	-628, 6, 0, DescribeParamInstance__EyePlot_STACK_MaxX_String_Params, 0, 
	DescribeParamInstance__EyePlot_STACK_MaxX_Stack_Params
};
char * DescribeParamInstance__EyePlot_STACK_MinY_String_Params[] = {
	"EyePlot", "MinY"
};

int DescribeParamInstance__EyePlot_STACK_MinY_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__EyePlot_STACK_MinY_Rem_Call_Struct = {
	-629, 6, 0, DescribeParamInstance__EyePlot_STACK_MinY_String_Params, 0, 
	DescribeParamInstance__EyePlot_STACK_MinY_Stack_Params
};
char * DescribeParamInstance__EyePlot_STACK_MaxY_String_Params[] = {
	"EyePlot", "MaxY"
};

int DescribeParamInstance__EyePlot_STACK_MaxY_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__EyePlot_STACK_MaxY_Rem_Call_Struct = {
	-630, 6, 0, DescribeParamInstance__EyePlot_STACK_MaxY_String_Params, 0, 
	DescribeParamInstance__EyePlot_STACK_MaxY_Stack_Params
};
char * DescribeParamInstance__EyePlot_STACK_Caption_String_Params[] = {
	"EyePlot", "Caption"
};

int DescribeParamInstance__EyePlot_STACK_Caption_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__EyePlot_STACK_Caption_Rem_Call_Struct = {
	-631, 6, 0, DescribeParamInstance__EyePlot_STACK_Caption_String_Params, 0, 
	DescribeParamInstance__EyePlot_STACK_Caption_Stack_Params
};
#endif /* #ifndef MENEXE_DOT_H*/
