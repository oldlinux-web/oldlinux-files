/*
 *  ger_ar_elt_ctr.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#include "ObjProComGui/net_nd_undef.h"
#define const_char(obj) obj=elts(ix++).string ;
#include "ObjProComGui/gen_common.h"
#define elts(i) objects[i].object

	int ix = 0 ;
	all_of_the_members 

#include "ObjProComGui/net_nd_undef.h"
#undef elts 
#undef all_of_the_members
