/*
 *  nodmem.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  nodmem.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */

#include "ObjProDSPcom/dskchnhd.h"
#include "ObjProComGui/cgidbg.h"

void ProcessNodeStr::Raise()
{
    raise_window();
}

void ProcessNodeStr::Edit()
{
	add_to_net_graph();
}

Node& ProcessNodeStr::LinkIn(int16 Channel)
{
	DfNode::LinkIn(Channel);
	return *this ;
}

void ProcessNodeStr::SetSampleRate(double Rate, int16 Channel)
{
	DfNode::SetSampleRate(Rate,Channel);
}

void ProcessNodeStr::DisplayInputTiming (int16 Channel)
{
	DfNode::DisplayInputTiming(Channel);

}

void ProcessNodeStr::DisplayOutputTiming (int16 Channel)
{
	DfNode::DisplayOutputTiming(Channel);
}

void ProcessNodeStr::NextFreeInput()
{
    DfNode::NextFreeInput();
}

void ProcessNodeStr::NextFreeOutput()
{
    DfNode::NextFreeOutput();
}


void ProcessNodeStr::Unlink()
{
	DfNode::Unlink();
}


