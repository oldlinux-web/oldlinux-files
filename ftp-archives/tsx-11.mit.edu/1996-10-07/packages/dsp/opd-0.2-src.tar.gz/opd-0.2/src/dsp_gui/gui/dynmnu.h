/*
 *  dynmnu.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  dynmnu.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include "ObjProComGui/dynmenu.h"


class DynamicMenuServer {
	
public:
	DynamicMenuServer() {}
	void AddItem(class MenuList * AddToThese, class MenuItem * Item);
	void RemoveItem(MenuList *RemoveFromThese, const char * CommandRemove) ;
	void MenuServer(class PacketHeader& Head,const char * Data);
	void DoCommand(MenuServerCommand Command,
		const char * MenuName, const char * ItemName) ;
} ;

extern DynamicMenuServer TheDynamicMenuServer ;

