/*
 *  specopt.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef SPECOPT_DOT_H
#define SPECOPT_DOT_H
class TraverseObject ;
class SpecialOptions {
	const enum SpecialOptionType {TraverseObjectOpt} TheType ;
	void * const TheOpt ;
public:
	SpecialOptions(TraverseObject& Obj);
	TraverseObject * GetTraverseObject();
};
#endif /* #ifdef SPECOPT_DOT_H */
