/*  xtok.c   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include "baseio.h"
#include "outtok.h"

// Dummy versions of routines that are not meaningful without GUI

void OutTokens::Init(OutputType, OutCon *)
{
}

void OutTokens::Check(ostream * o)
{
	out = o;
}

void EndOfFile()
{
}

