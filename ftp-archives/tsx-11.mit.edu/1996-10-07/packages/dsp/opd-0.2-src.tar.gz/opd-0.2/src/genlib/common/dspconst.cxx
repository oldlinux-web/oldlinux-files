/*  dspconst.c   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include "dspconst.h"
#include <math.h>

#define PI_CONST 3.14159265358979323844
const double DoublePi = PI_CONST ;
const double DoubleTwoPi = 2.0 * PI_CONST ;
#ifdef __NT_VC__
const complex TwoPiI = { 0.0, 2.0 * PI_CONST };
#else
const complex TwoPiI (0.0, 2.0 * PI_CONST) ;
#endif
#undef PI_CONST

