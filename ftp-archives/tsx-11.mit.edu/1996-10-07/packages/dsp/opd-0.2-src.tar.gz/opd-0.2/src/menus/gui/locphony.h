/*
 *  locphony.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef LOCPHONY_DOT_H 
#define LOCPHONY_DOT_H
#include "cgidbg.h"
#include "defined.h"

static void DescribeExample__STACK()
{
	LogDumMsg("DescribeExample__STACK called");
}

static void ExecuteExample__STACK_no()
{
	LogDumMsg("ExecuteExample__STACK_no called");
}

static void ExecuteExample__STACK_over()
{
	LogDumMsg("ExecuteExample__STACK_over called");
}

#endif /* #ifndef LOCPHONY_DOT_H*/
