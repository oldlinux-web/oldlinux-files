/*
 *  rel_pos.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef REL_POS_DOT_H
#define REL_POS_DOT_H


class AbsolutePosition {
	double x ;
	double y ;
public:
	AbsolutePosition():x(0),y(0){}
	AbsolutePosition(float _x, float _y):x(_x),y(_y){}
};

struct RelativePosition {
	float x ;
	float y ;
	RelativePosition():x(0),y(0){}
	RelativePosition(float _x, float _y):x(_x),y(_y){}
};

#endif /* #ifdef REL_POS_DOT_H */
