/*
 *  newaloc.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  newaloc.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef NEWALOC_DOT_H
#define NEWALOC_DOT_H
#include <malloc.h>

#include "ObjProDSP/portable.h"

#define NEW(typ,sz) (typ *) Malloc(sz * sizeof(typ))
	/* Above cludge is needed because current version of C++ cannot */
	/* declare arrays of objects in a user defined class properly. */

#ifdef PROTOTYPE
char * MoveNBytes(char *,const char*,int32) ;
char * Malloc(unsigned int) ;
#else
char * MoveNBytes() ;
char * Malloc() ;
#endif

#endif /* #ifdef NEWALOC_DOT_H */
