/*  incinit.c   */
/*  Copyright 1989, 1990 Mountain Math Software  */
/*  All Rights Reserved                    */
#include "tardb.h"
#include "cgidbg.h"
#include "tarnod.h"
#include "dfnode.h"
#include "interinit.h"
#include "network.h"
#include "netcnt.h"
#include "buffer.h"

void IncInit2();
void PullInAll()
{
	TargetDataBase = new NamePairList ;
	BufferNodesInit() ;
	NetControlsInit() ;
	ProcessNetsInit() ;

#include "initinc.h"
	// IncInit2();
}

