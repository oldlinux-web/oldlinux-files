/*  dbgcom.c   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include <fstream.h>
#include <stdlib.h>
#include "cgidbg.h"
#include "portable.h"


ostream * LogOutPtr = 0 ;

ostream& CheckLogOutDefined()
{
	if (!LogOutPtr) {
		LogOutPtr = new ofstream(DebugOutFile);
		LogOutPtr->setf(ios::unitbuf);
	}
	return *LogOutPtr ;
}
		

