/*
 *  dectype.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef DECTYPE_DOT_H
#define DECTYPE_DOT_H
/*  dectype.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
enum DecType{ DecInvalid, DecFloat, DecInt, DecName, DecString, //  0 1 2 3 4
	DecComplex, DecMachWord, DecCxMachWord, DecAccMachWord, // 5 6 7 8
	DecCxAccMachWord, DecProcedure, DecDspPP, DecParam, 	// 9 10 11 12
	DecEnt,DecEndOfTypes}; 						// 13


#endif /* #ifdef DECTYPE_DOT_H */
