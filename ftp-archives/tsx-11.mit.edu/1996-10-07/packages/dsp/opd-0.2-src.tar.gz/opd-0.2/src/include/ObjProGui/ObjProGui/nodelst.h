/*
 *  nodelst.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef NODELST_DOT_H
#define NODELST_DOT_H
#include "ObjProGen/slist.h"
class DfNode ;

class DfNodeList: public SingleList {
public:
	ErrCode Insert(DfNode *nt) {return SingleList::Insert(nt);}
	ErrCode Append(DfNode *nt) {return SingleList::Append(nt);}
	DfNode * Get()   {return (DfNode *) SingleList::Get();}
	DfNodeList(){;}
	DfNodeList(DfNode *nt):
		SingleList(nt) {}
	int InList(DfNode *nt);
	void Display();
 	void NameDisplay();
	void Clear(){SingleList::Clear();}
/*
 *	void Describe(OutTokens&, ListEntity) ; // interactive execution list
 *	int CheckComplete(const char * name) ;
 */
	int Size(){return SingleList::Size();}
	DfNode * GetFirst() { return (DfNode *) SingleList::GetFirst();}
} ;

class DfNodeIterator: public SingleListIterator {
public:
	DfNodeIterator(DfNodeList& df):
		SingleListIterator((SingleList&) df){}
	DfNode * operator()()
		{return (DfNode *) Next();}
};


#endif /* #ifdef NODELST_DOT_H */
