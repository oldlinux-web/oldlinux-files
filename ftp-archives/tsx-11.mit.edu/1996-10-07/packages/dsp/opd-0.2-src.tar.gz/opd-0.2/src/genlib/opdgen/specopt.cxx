#include "specopt.h"
#include "cgidbg.h"

SpecialOptions::SpecialOptions(TraverseObject& Obj):
	TheType(TraverseObjectOpt),
	TheOpt(&Obj)
{
}


TraverseObject * SpecialOptions::GetTraverseObject()
{
	switch (TheType) {
case TraverseObjectOpt:
		return (TraverseObject *) TheOpt ;
default:
		return 0 ;
	}
}

