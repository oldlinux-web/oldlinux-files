/*
 *  add.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef ADD_DOT_H
#define ADD_DOT_H
#define __DSP_PP_TARGET_CODE__

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class Add: public TargetNode {
#line 85 "../add.usr"
 
	int32 element_size ;
	int32 block_size ;
#line 24 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/add.h"
	int32  NumberOfOverflows;
	int16  Channels_1;
	int16  ElementSize_2;
	double  Scale_3;
public:
	Add (const char * Name, int16 Channels, int16 ElementSize, double Scale,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay);
	virtual ~Add();
	int16 GetChannels() const {return Channels_1;}
	int16 GetElementSize() const {return ElementSize_2;}
	double GetScale() const {return Scale_3;}
	int32 GetNumberOfOverflows() const { return NumberOfOverflows;}
	virtual ErrCode DoNode(int32);
	void SetScale(double  Scale) { Scale_3 = Scale; parameter_changed(); }
};

extern Add * AddDef;


#endif /* #ifdef ADD_DOT_H */
