/*
 *  outtokf.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  outtokf.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef OUTTOKF_DOT_H
#define OUTTOKF_DOT_H
#include "outtok.h"

class OutTokFile:public OutTokens {
	const char * FileName ;
	ostream * Stream ;
	filebuf * FileBuf ;
public:
	OutTokFile (
		const char * Name,
		filebuf& FileBuf,
		ostream& Out,
		int init=0,
		const char *ter=" \\",
		const char *sep = " ",
		const char * inis = "   " ,
		int lw =80 ,
		int lh = 24,
		ReturnOption quit = ReturnWait );
	virtual ~OutTokFile();
	static OutTokFile * open_tok_file(const char * Name,
		char * terminator  = " \\", int char_per_line=80);
	static void delete_tok_file(OutTokFile *) ;
};

#endif /* #ifdef OUTTOKF_DOT_H */
