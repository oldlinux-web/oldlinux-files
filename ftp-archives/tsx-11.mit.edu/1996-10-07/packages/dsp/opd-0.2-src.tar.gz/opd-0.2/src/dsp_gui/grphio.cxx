/*  grphio.c   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
// I/O interface from DSP++ semantic code via shared memory
// to graphics user interface

#include <string.h>

#include "sysintfc.h"

#include "cgidbg.h"
#include "grphio.h"
#include "usercom.h"
#include "baseio.h"
#include "shared.h"
#include "remcom.h"

int GraphicsMode = 0;
int GraphicsStringAvailable[InputEndOfInputTypes] ;

