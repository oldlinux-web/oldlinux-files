#include <stdlib.h>
#include "cgidbg.h"
#include "grphio.h"

void GraphicsReturnToContinue(OutputType) 
{
	TheLog << "GraphicsReturnToContinue called\n" ;
	exit(1);
}

int GraphicsReturnOrQuit(OutputType) 
{
	TheLog << "GraphicsReturnOrQuit called\n" ;
	exit(1);
	return 0;
}


