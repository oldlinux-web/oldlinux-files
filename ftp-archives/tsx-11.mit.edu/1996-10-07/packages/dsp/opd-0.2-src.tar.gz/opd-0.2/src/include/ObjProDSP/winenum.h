/*
 *  winenum.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  winenum.h   */
/*  Copyright 1990 Mountain Math Software  */
/*  All Rights Reserved                    */

#ifndef WINENUM_DOT_H
#define WINENUM_DOT_H
enum WindowType {WindowNotInitialized=-1, WindowBaseClass,WindowText,
	WindowTextLabel,WindowMenu, WindowIcon,WindowPlot,WindowLabPlot} ;

enum WindowViewType {WindowViewInvisible, WindowViewAlwaysVisible, 
	WindowViewFixedVisible, WindowViewFixedInvisible,
	WindowViewFixedAlwaysVisible,
	WindowViewVisible, WindowViewUndefined};


#endif /* #ifdef WINENUM_DOT_H */
