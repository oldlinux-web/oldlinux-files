/*
 *  plot_lim.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef PLOT_LIM_DOT_H
#define PLOT_LIM_DOT_H
#include <float.h>
#define very_big  (DBL_MAX/10.) 
#define very_small  (DBL_MIN*10.)

#endif /* #ifdef PLOT_LIM_DOT_H */
