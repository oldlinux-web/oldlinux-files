/*  newaloc.c   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include "newaloc.h"

#ifdef PROTOTYPE
char * Malloc(unsigned sz)
#else
char * Malloc(sz)
int sz;
#endif
{
	char * ret ;
	char * pt ;
	char * limit ;
	ret = (char *) malloc(sz);
	limit = ret + sz ;
	for (pt = ret ;pt<limit;pt++) *pt = '\0' ;
	return ret ;
} 

#ifdef PROTOTYPE
char * MoveNBytes(char *Dest,const char* Source,int32 N)
#else
char * MoveNBytes(Dest,Source,N)
char *Dest;
const char* Source;
int32 N;
#endif
{
	int i ;
	char * Ret = Dest ;
	for (i = 0 ; i < N ; i++) *Dest++ = *Source++ ;
	return Ret ;
}

