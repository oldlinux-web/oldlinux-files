/*
 *  remdyn.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  remdyn.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef REMDYN_DOT_H
#define REMDYN_DOT_H
#include "dynmen.h"
struct DynamicMenuInfo {
	DynamicMenu * TheMenu ;
	MenuLine Template ;
	const char * Name ;
} ;

extern class DynamicMenuInfo TheRemoteDynamicMenuTable[] ;

#endif /* #ifndef REMDYN_DOT_H */
