/*
 *  cpyrght_exe.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*
 * This should be included in every main program and in some program
 * in every library so the text of this copyright notice is in every 
 * distributed executable and library. Please ADD your own
 * copyright notice to programs that include code you hold a
 * copyright to.
 */

#include "ObjProDSP/version.h"

#define OBJ_PRO_DSP_VERSION_PARAM \
    ObjectProDSP OBJ_PRO_DSP_VERSION_NUM, \
    Copyright (C) 1994, Mountain Math Software, \
    All rights reserved.

static const char * ObjProDSP_copyright =
	OBJ_PRO_DSP_VERSION_XSTR((OBJ_PRO_DSP_VERSION_PARAM)) ;

