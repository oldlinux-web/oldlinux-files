/*  logdum.c   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include "cgidbg.h"

void LogDumMsg(const char * p1, const char * p2=0,const char * p3=0,
const char *p4=0)
{
	LogMsg(p1, p2,p3,p4);
}

