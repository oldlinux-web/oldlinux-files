/*
 *  delay.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef DELAY_DOT_H
#define DELAY_DOT_H

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/procstr.h"

class SampleDelay: public ProcessNodeStr {
#line 37 "../delay.usr"
 
	ErrCode NodeReset();
	int32 DelHistory ;
#line 24 "/dist/opd_2/opd-0.2/src/include/ObjProDSPint/ObjProUsr/delay.h"
	int32  Delta_1;
	MachWord  FillValue_2;
public:
	SampleDelay (const char * Name, int32 Delta, MachWord FillValue);
	virtual ~SampleDelay();
	int32 GetDelta() const {return Delta_1;}
	MachWord GetFillValue() const {return FillValue_2;}
	virtual int CheckSafeDelete() ;
	virtual ErrCode DoNode(int32);
	void Describe(OutTokens& Out, ListEntity Option);
	virtual int CppList(OutTokens& Out, CppListCmds Cmd);
};

extern SampleDelay * SampleDelayDef;


#endif /* #ifdef DELAY_DOT_H */
