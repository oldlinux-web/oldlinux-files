/*
 *  readint.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef READINT_DOT_H
#define READINT_DOT_H
#include <fstream.h>
#include "ObjProArith/hrdarth.h"
#include "ObjProDSPcom/inascii.h"
#include <fstream.h>

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/sigbase.h"

class ReadInt: public Signal {
#line 47 "../readint.usr"
 
	ifstream * ReadIntFile ;
	char * exp_name ;
	int DidCheck ;
	void open_f(int force_error) ;
	ErrCode kernel(int k);
	char * delete_name ;
#line 32 "/dist/opd_2/opd-0.2/src/include/ObjProDSPint/ObjProUsr/readint.h"
	const char *  FileName_1;
	int16  Flags_2;
public:
	ReadInt (const char * Name, const char * FileName, int16 Flags);
	virtual ~ReadInt();
	const char * GetFileName() const {return FileName_1;}
	int16 GetFlags() const {return Flags_2;}
	virtual int CheckSafeDelete() ;
	virtual ErrCode DoNode(int32);
	void Describe(OutTokens& Out, ListEntity Option);
	virtual int CppList(OutTokens& Out, CppListCmds Cmd);
};

extern ReadInt * ReadIntDef;


#endif /* #ifdef READINT_DOT_H */
