/*
 *  stdyacp.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  stdyacp.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef STDYACP_DOT_H
#define STDYACP_DOT_H
void OutWhere(ostream& = cerr) ;
void OutWhereX(int, ostream& = cerr);

inline void OutWhereEnd(ostream& Stream = cerr) { OutWhereX(1,Stream) ; }

#endif /* #ifdef STDYACP_DOT_H */
