/*
 *  makedir.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  makedir.h   */
/*  Copyright 1990 Mountain Math Software  */
/*  All Rights Reserved                    */
int CheckSubDir(const char * Name) ;
// Create directory Name if it does not exist already
// Return 0 if it does not exist and cannot be created

