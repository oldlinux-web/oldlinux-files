#include "xdrv.h"
#include <InterViews/enter-scope.h>
#include <Dispatch/enter-scope.h>
#include <InterViews/event.h>
#include <InterViews/input.h>
#include <InterViews/layout.h>
#include <InterViews/canvas.h>
#include <InterViews/geometry.h>
#include <InterViews/brush.h>
#include <InterViews/canvas.h>
#include <InterViews/glyph.h>
#include <InterViews/monoglyph.h>
#include <InterViews/polyglyph.h>
#include <InterViews/action.h>
#include <InterViews/action.h>
#include <InterViews/background.h>
#include <InterViews/label.h>
#include <InterViews/tile.h>
#include <InterViews/telltale.h>
#include <InterViews/color.h>
#include <InterViews/window.h>
#include <IV-look/button.h>
#include <IV-look/kit.h>
#include <InterViews/cursor.h>
#include <X11/cursorfont.h>
#include <X11/keysym.h>
#include <stdlib.h>
#include "portable.h"
#include "netdescg.h"
#include "netplot.h"
#include "dsp_app.h"
#include "cgidbg.h"
#include "mkstr.h"
#include "xgui.h"
#include "help.h"
#include "usercom.h"

void NetGraph::dump()
{
	glyphs.dump();
}

void VerticalGlyphs::dump()
{
	edible_graph.next(0);
	VerticalPosition * pos ;
	int count = 0 ;
	while (pos = edible_graph.next()) {
		TheLog << "VerticalPosition " << count++ << ":\n" ;
		pos->dump();
	}
}

void VerticalPosition::dump()
{
	the_glyphs.next(0);
	HorizontalPosition * pos ;
	int count = 0 ;
	while(pos = the_glyphs.next()) {
		TheLog << "\tHorizontalPosition " << count++ << ": " ;
		pos->dump();
		TheLog << "\n" ;
	}
}

void HorizontalPosition::dump()
{
	if (the_cookie) the_cookie->dump();
	else TheLog << "no cookie!\n" ;
}

void EdibleGlyph::dump()
{
	TheLog << "EdibleGlyph missing virtual dump" ;
}

void EdibleSpace::dump()
{
	TheLog << "space" ;
}


void EdibleOutputLabel::dump()
{
	TheLog << "->`" << text << "'" ;
}

void EdibleInputLabel::dump()
{
	TheLog << "`" << text << "'-> " ;
}


void NodeGlyph::dump()
{
	TheLog << "`" << the_node.name() << "'" ;
}

void NodeConnector::dump()
{
	TheLog << "->c " << channel << " ->b " <<  buffer_channel ;
}


