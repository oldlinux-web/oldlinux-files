/*
 *  dyntextg.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  dyntextg.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include <stream.h>
#include "dyntext.h"
#include "usriotyp.h"

class GuiDynamicTextControl: public DynamicTextControl{
	class WindowMapList * TheMaps;
	int NextFreeUserIndex ;
	int NewWindowId ;
	FILE * TheFile ;
public:
	GuiDynamicTextControl();
	virtual ~GuiDynamicTextControl();
	class WindowMapElement * GetMapElement(int Id) ;
	void TextWindowCreated(int UserIndex) ;
	const char * CheckNotOpened(int Id) ;
	void virtual TextServer(class PacketHeader& Head, const char *Data) ;
	int NewTextWindow(const char *Name, const char * Caption=0) ;
	void OpenTextWindow(const char * Name);
	int IsWindowBeingOpened() {return NewWindowId != 0;}
	void append(OutputType type,const char *str,OutputType nxt) ;
};




