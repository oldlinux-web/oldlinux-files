#include "menucmdg.h"
#include "remparm.h"

#include "locphony.h"

#include "defined.h"
void ExecuteCmdGui::DoCall()
{
	switch(Params->ParameterType) {
case 0:
		TheCall();
		break;
case 1:
		TheCall(GetMenuStackName(Params->StackParameters[0]));
		break;
case 2:
		TheCall(GetMenuStackName(Params->StackParameters[0]), 
			Params->StringParameters[0]);
		break;
case 3:
		TheCall(Params->StringParameters[0]);
		break;
case 4:
		TheCall(Params->StringParameters[0], 
			GetMenuStackName(Params->StackParameters[0]));
		break;
case 5:
		TheCall(Params->StringParameters[0], 
			Params->StringParameters[1]);
		break;
case 6:
		TheCall(Params->StringParameters[0], 
			GetMenuStackName(Params->StackParameters[0]), 
			Params->StringParameters[1]);
		break;
case 7:
		TheCall(GetMenuStackName(Params->StackParameters[0]), 
			GetMenuStackName(Params->StackParameters[1]), 
			Params->StringParameters[0]);
		break;

	}
}

ParameterizedActionCall AllActions[] = {
	(ParameterizedActionCall) DoSaveExit, 
	(ParameterizedActionCall) SetHelpLevelNone, 
	(ParameterizedActionCall) SetHelpLevelConfirm, 
	(ParameterizedActionCall) SetHelpLevelAll, 
	(ParameterizedActionCall) ReadState, 
	(ParameterizedActionCall) ReadOverState, 
	(ParameterizedActionCall) ReadPlot, 
	(ParameterizedActionCall) DescribeExample, 
	(ParameterizedActionCall) ExecuteExample, 
	(ParameterizedActionCall) ExecuteExample, 
	(ParameterizedActionCall) AbortDspExecution, 
	(ParameterizedActionCall) PlotErr, 
	(ParameterizedActionCall) FreezeDsp, 
	(ParameterizedActionCall) ThawDsp, (ParameterizedActionCall) DoExit, 
	(ParameterizedActionCall) RecordActions, 
	(ParameterizedActionCall) RecordOff, 
	(ParameterizedActionCall) RecordFlush, 
	(ParameterizedActionCall) PlayActions, 
	(ParameterizedActionCall) PlayPause
};

void DoSaveExit();
void SetHelpLevelNone();
void SetHelpLevelConfirm();
void SetHelpLevelAll();
void ReadState();
void ReadOverState();
void ReadPlot();
void DescribeExample(const char *);
void ExecuteExample(const char *, const char *);
void ExecuteExample(const char *, const char *);
void AbortDspExecution();
void PlotErr();
void FreezeDsp();
void ThawDsp();
void DoExit();
void RecordActions();
void RecordOff();
void RecordFlush();
void PlayActions();
void PlayPause();
