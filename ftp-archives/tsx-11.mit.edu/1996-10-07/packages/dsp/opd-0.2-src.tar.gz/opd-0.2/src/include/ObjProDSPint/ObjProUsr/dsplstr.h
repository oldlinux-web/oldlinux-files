/*
 *  dsplstr.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef DSPLSTR_DOT_H
#define DSPLSTR_DOT_H

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProUsr/node.h"

class DisplayNodeStr: public Node {
#line 86 "../dsplstr.usr"
 
#line 22 "/dist/opd_2/opd-0.2/src/include/ObjProDSPint/ObjProUsr/dsplstr.h"
	int16  in_1;
	int32  DeltaIn_2;
	StreamStr* StreamIn_3;
	TimingType  TheTimingType_4;
public:
	DisplayNodeStr (const char * Name, int16 in, int32 DeltaIn, 
		StreamStr*StreamIn, TimingType TheTimingType);
	virtual ~DisplayNodeStr();
	int16 Getin() const {return in_1;}
	int32 GetDeltaIn() const {return DeltaIn_2;}
	StreamStr*GetStreamIn() const {return StreamIn_3;}
	TimingType GetTheTimingType() const {return TheTimingType_4;}
	virtual int CheckSafeDelete() ;
	void Raise ();
	void DisplayInputTiming (int16 Channel);
	void Edit ();
	void Unlink ();
	Node& LinkIn (int16 Channel);
	void NextFreeInput ();
#line 88 "../dsplstr.usr"
	virtual int window_id(){return -1;}
#line 44 "/dist/opd_2/opd-0.2/src/include/ObjProDSPint/ObjProUsr/dsplstr.h"
};


#endif /* #ifdef DSPLSTR_DOT_H */
