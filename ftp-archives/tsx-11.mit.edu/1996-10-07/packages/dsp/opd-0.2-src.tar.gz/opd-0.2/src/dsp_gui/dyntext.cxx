/*  dyntext.c   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include "dyntext.h"
#include "cgidbg.h"

DynamicTextControl::DynamicTextControl()
{
}


void DynamicTextControl::TextServer(class PacketHeader&, const char *)
{
	DbgError("DynamicTextControl::TextServer","base function called");
}


