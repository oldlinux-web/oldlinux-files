/*
 *  tremfnc.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef TREMFNC_DOT_H 
#define TREMFNC_DOT_H
#include"menucmd.h"
ParameterLimits RemoteParamLimits[] = {
	{0, 0, 0, 0},
	{0, 0, 0, 1},
	{0, 1, 0, 1},
	{0, 1, 0, 0},
	{0, 1, 0, 1},
	{0, 2, 0, 0},
	{0, 2, 0, 1},
	{0, 1, 0, 2}
};

#endif /* #ifndef TREMFNC_DOT_H*/
