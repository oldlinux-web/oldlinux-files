/*
 *  user_cpy_strings.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/* ../user_cpy_strings.h */
static const char * user_copyright_text[] = {
	"",
	"### Copyright (C) 2520, Admiral James T Kirk.",
	"### Program updated to work on the Enterprise's computer.",
  0
};


