#include "menucmdd.h"
#include "defined.h"
void ExecuteCmdDsp::DoCall()
{
	switch(Params->ParameterType) {
case 0:
		TheCall();
		break;
case 1:
		TheCall(GetMenuStackName(Params->StackParameters[0]));
		break;
case 2:
		TheCall(GetMenuStackName(Params->StackParameters[0]), 
			Params->StringParameters[0]);
		break;
case 3:
		TheCall(Params->StringParameters[0]);
		break;
case 4:
		TheCall(Params->StringParameters[0], 
			GetMenuStackName(Params->StackParameters[0]));
		break;
case 5:
		TheCall(Params->StringParameters[0], 
			Params->StringParameters[1]);
		break;
case 6:
		TheCall(Params->StringParameters[0], 
			GetMenuStackName(Params->StackParameters[0]), 
			Params->StringParameters[1]);
		break;
case 7:
		TheCall(GetMenuStackName(Params->StackParameters[0]), 
			GetMenuStackName(Params->StackParameters[1]), 
			Params->StringParameters[0]);
		break;

	}
}

ParameterizedActionCall AllActions[] = {
	(ParameterizedActionCall) DoSaveExit, 
	(ParameterizedActionCall) DoExit, 
	(ParameterizedActionCall) node_trace_on, 
	(ParameterizedActionCall) node_trace_off, 
	(ParameterizedActionCall) heap_check_on, 
	(ParameterizedActionCall) heap_check_off, 
	(ParameterizedActionCall) set_report_overflow_limit, 
	(ParameterizedActionCall) ListInt, 
	(ParameterizedActionCall) ListDouble, 
	(ParameterizedActionCall) ListMachWord, 
	(ParameterizedActionCall) ListAccMachWord, 
	(ParameterizedActionCall) DoSave, 
	(ParameterizedActionCall) DoSaveAs, 
	(ParameterizedActionCall) DoSavePeriod, 
	(ParameterizedActionCall) SetStateSaveFile, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) MemberFunctionDescribe, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) MemberFunctionDescribe, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) MemberFunctionDescribe, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) MemberFunctionDescribe, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) MemberFunctionDescribe, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) MemberFunctionDescribe, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) MemberFunctionDescribe, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) ExecuteMemberFunction, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) MemberFunctionDescribe, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) DescribeMemberFunctionParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) MemberFunctionDescribe, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) CreateDefaultNodeInteractiveEntity, 
	(ParameterizedActionCall) CreateNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeNodeInstance, 
	(ParameterizedActionCall) DeleteNodeInteractiveEntity, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParam, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) DescribeParamInstance, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter, 
	(ParameterizedActionCall) ExecuteSetParameter
};

void DoSaveExit();
void DoExit();
void node_trace_on();
void node_trace_off();
void heap_check_on();
void heap_check_off();
void set_report_overflow_limit();
void ListInt();
void ListDouble();
void ListMachWord();
void ListAccMachWord();
void DoSave();
void DoSaveAs();
void DoSavePeriod();
void SetStateSaveFile();
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void MemberFunctionDescribe(const char *, const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void MemberFunctionDescribe(const char *, const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateNodeInteractiveEntity(const char *);
void MemberFunctionDescribe(const char *, const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void MemberFunctionDescribe(const char *, const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void MemberFunctionDescribe(const char *, const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void MemberFunctionDescribe(const char *, const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void MemberFunctionDescribe(const char *, const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void ExecuteMemberFunction(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void MemberFunctionDescribe(const char *, const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void DescribeMemberFunctionParameter(const char *, const char *, 
	const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void MemberFunctionDescribe(const char *, const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void CreateDefaultNodeInteractiveEntity(const char *);
void CreateNodeInteractiveEntity(const char *);
void DescribeNodeInstance(const char *, const char *);
void DeleteNodeInteractiveEntity(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParam(const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void DescribeParamInstance(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
void ExecuteSetParameter(const char *, const char *, const char *);
