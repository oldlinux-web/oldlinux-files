/*
 *  fltstrm.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#include "hrdarth.h"
#ifndef FLTSTRM_DOT_H
#define FLTSTRM_DOT_H
/************
inline ostream& operator<<(ostream& o, MachWord v)    {return o << ((double) v);}
inline ostream& operator<<(ostream& o, AccMachWord v) {return o << ((double) v);}
inline ostream& operator<<(ostream& o, CxMachWord v)  {return o << ((Complex) v);}
inline ostream& operator<<(ostream& o, const CxAccMachWord& v)
		{return o << ((complex) v);}
*************/


#endif /* #ifdef FLTSTRM_DOT_H */
