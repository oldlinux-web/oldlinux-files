/*  debug.c   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include <stream.h>
#include <signal.h>
/* #include <unistd.h> */
#include <unistd.h>
#include <stdlib.h>
#include "ObjProGen/debug.h"

#ifndef TI_C30
void DebugCode(int code)
{
#if !defined(NO_OSFCN) && !defined(__NT_VC__)
	cerr << "Error code " << code << "\n" ;
	cerr.flush();
	kill (getpid(),SIGQUIT);
#else
	exit(1);
#endif
}

void DbgError(const char * Routine,const char *ErrorType, const char* Class)
{
#if !defined(NO_OSFCN) && !defined(__NT_VC__)
	cerr << "Error " << ErrorType << "  from `" ;
	if (Class)  cerr << Class <<  "::" ;
	cerr <<	Routine  << "'.\n" ;
	cerr.flush();
	kill (getpid(),SIGQUIT);
#else
	exit(1);
#endif
}
#endif

