#include "textdefs.h"
#include "dsp_app.h"
#include "cgidbg.h"

static CaptureRead capture;

static void capture_read(const char * str, InputType  type, void * obj)
{
	capture.read(str,type,obj);
}

CaptureRead& CaptureRead::capture_read()
{
	return ::capture ;
}

SuspendedRead CaptureRead::capture(SuspendedRead rd)
{
	return ::capture.do_capture(rd);
}

SuspendedRead CaptureRead::do_capture(SuspendedRead rd)
{
	if (rd == (SuspendedRead) capture_read) return rd ;
	set_suspend(rd);
	return ::capture_read ;
}

void CaptureRead::read(const char * str, InputType type, void * obj)
{
	DspApplication::record_prompt(str);
	to_call(str,type,obj);
}
