/*
 *  basic.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef BASIC_DOT_H
#define BASIC_DOT_H

class UserEntity {
	const char * Name ;
public:
	UserEntity(const char * name):
		Name(name){}
	const char * GetName() const {return Name;}
	virtual void parameter_changed() {}
};

#endif /* #ifdef BASIC_DOT_H */
