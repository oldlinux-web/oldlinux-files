/*
 *  menexe.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef MENEXE_DOT_H 
#define MENEXE_DOT_H
#include "menucmd.h"
static CommandParameters DoSaveExit_Loc_Call_Struct = {
	1, 0, 0, 0, 0, 0
};
static CommandParameters SetHelpLevelNone_Loc_Call_Struct = {
	2, 0, 0, 0, 0, 0
};
static CommandParameters SetHelpLevelConfirm_Loc_Call_Struct = {
	3, 0, 0, 0, 0, 0
};
static CommandParameters SetHelpLevelAll_Loc_Call_Struct = {
	4, 0, 0, 0, 0, 0
};
static CommandParameters ReadState_Loc_Call_Struct = {
	5, 0, 0, 0, 0, 0
};
static CommandParameters ReadOverState_Loc_Call_Struct = {
	6, 0, 0, 0, 0, 0
};
static CommandParameters ReadPlot_Loc_Call_Struct = {
	7, 0, 0, 0, 0, 0
};
int DescribeExample__STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeExample__STACK_Loc_Call_Struct = {
	8, 1, 0, 0, 0, DescribeExample__STACK_Stack_Params
};
char * ExecuteExample__STACK_no_String_Params[] = {
	"no"
};

int ExecuteExample__STACK_no_Stack_Params[] = {
	1
};

static CommandParameters ExecuteExample__STACK_no_Loc_Call_Struct = {
	9, 2, 0, ExecuteExample__STACK_no_String_Params, 0, ExecuteExample__STACK_no_Stack_Params
};
char * ExecuteExample__STACK_over_String_Params[] = {
	"over"
};

int ExecuteExample__STACK_over_Stack_Params[] = {
	1
};

static CommandParameters ExecuteExample__STACK_over_Loc_Call_Struct = {
	10, 2, 0, ExecuteExample__STACK_over_String_Params, 0, 
	ExecuteExample__STACK_over_Stack_Params
};
static CommandParameters AbortDspExecution_Loc_Call_Struct = {
	11, 0, 0, 0, 0, 0
};
static CommandParameters PlotErr_Loc_Call_Struct = {
	12, 0, 0, 0, 0, 0
};
static CommandParameters FreezeDsp_Loc_Call_Struct = {
	13, 0, 0, 0, 0, 0
};
static CommandParameters ThawDsp_Loc_Call_Struct = {
	14, 0, 0, 0, 0, 0
};
static CommandParameters DoExit_Loc_Call_Struct = {
	15, 0, 0, 0, 0, 0
};
static CommandParameters RecordActions_Loc_Call_Struct = {
	16, 0, 0, 0, 0, 0
};
static CommandParameters RecordOff_Loc_Call_Struct = {
	17, 0, 0, 0, 0, 0
};
static CommandParameters RecordFlush_Loc_Call_Struct = {
	18, 0, 0, 0, 0, 0
};
static CommandParameters PlayActions_Loc_Call_Struct = {
	19, 0, 0, 0, 0, 0
};
static CommandParameters PlayPause_Loc_Call_Struct = {
	20, 0, 0, 0, 0, 0
};
#endif /* #ifndef MENEXE_DOT_H*/
