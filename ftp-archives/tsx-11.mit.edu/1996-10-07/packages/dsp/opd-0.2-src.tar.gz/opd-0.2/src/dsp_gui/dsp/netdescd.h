/*
 *  netdescd.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#include "netdesc.h"

class TransmitNetworkDescription: public CommunicateNetworkDescription {
	ProcessNet& net ;
	void send(StructType type,GenericArrayElement * array=0);
public:
	TransmitNetworkDescription(ProcessNet& n):net(n){}
	virtual ~TransmitNetworkDescription(); // send end of network
	void send(NetNodeDescription& node);
	void send(NetBufferDescription& buf);
	void send(NetworkDescription& net);
	void send_network_terminator();
};
