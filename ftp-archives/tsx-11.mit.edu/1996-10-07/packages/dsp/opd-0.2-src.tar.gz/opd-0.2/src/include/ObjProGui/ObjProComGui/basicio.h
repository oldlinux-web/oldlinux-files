/*
 *  basicio.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  basicio.h   */
/*  Copyright 1990 Mountain Math Software  */
/*  All Rights Reserved                    */
#include "ObjProComGui/usercom.h"

class BasicIO {
friend class OutCon ;
	class ostream ** TheStreams ;
	int LastOutput ;
	int ArraySize ;
	int ChannelsInUse ;
	int LastRedirect ;
	int AppendFlag ;
public:
	BasicIO(int AppendFlag) ;
	~BasicIO();
	void CleanUp();
	void LegalStreamIndex(int ix, const char * Where);
	ostream& GetStream(int i);
	ostream& operator++() ;
	ostream& SetWindow(int i);
	int GetOutputType();
	void AddWindow(int Index);
	void SetRedirect(RedirectSwitch Redirect) ;
} ;

class WindowBuf : public streambuf {
	int PortIndex ;
	int AppendFlag ;
	int overflow(int) ;
	int underflow() ;
public:
	WindowBuf(WindowBuf const&);
	WindowBuf(int Index, int append_flag=0)
		{PortIndex = Index;AppendFlag=append_flag;}
	~WindowBuf() {}
}; 


