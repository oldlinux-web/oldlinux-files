/*
 *  text.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  text.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */


#ifndef TEXT_DOT_H
#define TEXT_DOT_H


/*
 *	This file must be C as well as C++ compatible.
 *	In C you can assume that `const' is `define'ed to NULL,
 *	and `class' is `define'ed to `struct'.
 */

class ConstStringList ;
class ostream ;

class TextFragmentList * CurrentText() ;

void AddedText(const char * ) ;
void AddedChar(char ) ;
void AddEmbeddedName(const char * );


void EmitEmbeddedReference(const char *, int ) ;
	/* must be supplied  */

void BraceInit() ;
void LeftBrace() ;
int RightBrace() ;
const char * QuoteQuote(const char * String) ;


#endif /* #ifdef TEXT_DOT_H */
