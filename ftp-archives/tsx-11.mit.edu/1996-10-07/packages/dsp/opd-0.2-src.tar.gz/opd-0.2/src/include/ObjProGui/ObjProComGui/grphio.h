/*
 *  grphio.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef GRPHIO_DOT_H
#define GRPHIO_DOT_H
/*  grphio.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
// I/O interface from DSP++ semantic code via shared memory
// to graphics user interface

#include "ObjProGen/usriotyp.h"

extern int GraphicsMode  ;
char * GetGraphicsRawBufLine(InputType, const char * Prompt=0) ;
void GraphicsReturnToContinue(OutputType) ;
int GraphicsReturnOrQuit(OutputType) ;
int WindowWrite(OutputType,char) ;
extern int GraphicsStringAvailable[] ;
extern char * GraphicsString[] ;

#endif /* #ifdef GRPHIO_DOT_H */
