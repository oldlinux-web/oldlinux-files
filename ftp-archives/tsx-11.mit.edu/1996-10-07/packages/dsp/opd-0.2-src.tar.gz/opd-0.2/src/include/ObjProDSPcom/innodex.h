/*
 *  innodex.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
	void BadFile() ;
	void FileInit() ;
	void Ctor() ;
	void Dtor() ;
	ErrCode TheKernel(int k) ;
#ifdef INTERACTIVE
	virtual TimingDescription * GetInitTiming(int Channel);
#endif
	int Channels ;
	int32 * ElementSize ;
	int32 GetElementSize(int channel) {return ElementSize[channel];}
	class InputFile * TheInputFile ;
	double * SampleRateRatio ;
	double * CumulativeSamples ;
	DriverInputInterface TheDriverInterface ;
	class NetworkDriver * TheNetworkDriver ;
	int32 SampleCount ;
public:
	ErrCode NodeReset();
	InputFile * GetInputFile() const {return TheInputFile;}
	NetworkDriver*GetNetworkDriver()const{return TheNetworkDriver;}
	void SetDriverInterface(DriverInputInterface intfc,
		NetworkDriver * drv=0)
		{TheDriverInterface=intfc;
		TheNetworkDriver=drv;}
private:

