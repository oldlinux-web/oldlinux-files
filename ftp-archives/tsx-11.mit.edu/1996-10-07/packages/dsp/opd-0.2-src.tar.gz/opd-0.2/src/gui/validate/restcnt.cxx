#include "restcnt.h"

char * restore_control(char * str)
{
	if (!str) return 0 ;
	if (!*str) return str ;
    char * dest =  str ;
    for (const char * ptr = str ; *ptr; ptr++) if (*ptr != '^') *dest++ = *ptr ;
    else {
			if (!*++ptr) break ;
			*dest++ = *ptr - 'A' + 1 ;
	}
	*dest = '\0' ;
	return str ;
}

