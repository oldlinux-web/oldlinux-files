/*
 *  tarnod2.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef TARNOD2_DOT_H
#define TARNOD2_DOT_H
#include "ObjProNet/tarmac.h"
#include "ObjProDSPcom/tarnod.h"

inline int32 TargetNode::GetEltSize(int out_channel) const
	{return OutLinks[out_channel].GetElementSize();}


#endif /* #ifdef TARNOD2_DOT_H */
