/*
 *  remexe.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software. All rights reserved.
 *  
 *  This file is part of ObjectProDSP, a tool for Digital Signal
 *  Processing design, development and implementation. It is free
 *  software provided you use and distribute it under the terms of
 *  version 2 of the GNU General Public License as published
 *  by the Free Software Foundation. You may NOT distribute it or
 *  works derived from it or code that it generates under ANY
 *  OTHER terms.  In particular NONE of the ObjectProDSP system is
 *  licensed for use under the GNU General Public LIBRARY License.
 *  Mountain Math Software plans to offer a commercial version of
 *  ObjectProDSP for a fee. That version will allow redistribution
 *  of generated code under standard commercial terms.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of version 2 of the GNU General
 *  Public License along with this program. See file COPYING. If not
 *  or if you wish information on commercial versions and licensing
 *  write Mountain Math Software, P. O. Box 2124, Saratoga, CA 95070,
 *  USA, or send us e-mail at: support@mtnmath.com.
 *  
 *  You may also obtain the GNU General Public License by writing the
 *  Free Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139,
 *  USA.  However if you received a copy of this program without the
 *  file COPYING or without a copyright notice attached to all text
 *  files, libraries and executables please inform Mountain Math Software.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef REMEXE_DOT_H 
#define REMEXE_DOT_H
#include "menucmd.h"
static CommandParameters DoSaveExit_Rem_Call_Struct = {
	-1, 0, 0, 0, 0, 0
};
static CommandParameters DoExit_Rem_Call_Struct = {
	-2, 0, 0, 0, 0, 0
};
static CommandParameters node_trace_on_Rem_Call_Struct = {
	-3, 0, 0, 0, 0, 0
};
static CommandParameters node_trace_off_Rem_Call_Struct = {
	-4, 0, 0, 0, 0, 0
};
static CommandParameters heap_check_on_Rem_Call_Struct = {
	-5, 0, 0, 0, 0, 0
};
static CommandParameters heap_check_off_Rem_Call_Struct = {
	-6, 0, 0, 0, 0, 0
};
static CommandParameters set_report_overflow_limit_Rem_Call_Struct = {
	-7, 0, 0, 0, 0, 0
};
static CommandParameters ListInt_Rem_Call_Struct = {
	-8, 0, 0, 0, 0, 0
};
static CommandParameters ListDouble_Rem_Call_Struct = {
	-9, 0, 0, 0, 0, 0
};
static CommandParameters ListMachWord_Rem_Call_Struct = {
	-10, 0, 0, 0, 0, 0
};
static CommandParameters ListAccMachWord_Rem_Call_Struct = {
	-11, 0, 0, 0, 0, 0
};
static CommandParameters DoSave_Rem_Call_Struct = {
	-12, 0, 0, 0, 0, 0
};
static CommandParameters DoSaveAs_Rem_Call_Struct = {
	-13, 0, 0, 0, 0, 0
};
static CommandParameters DoSavePeriod_Rem_Call_Struct = {
	-14, 0, 0, 0, 0, 0
};
static CommandParameters SetStateSaveFile_Rem_Call_Struct = {
	-15, 0, 0, 0, 0, 0
};
char * CreateDefaultNodeInteractiveEntity__Add_String_Params[] = {
	"Add"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Add_Rem_Call_Struct = {
	-16, 3, 0, CreateDefaultNodeInteractiveEntity__Add_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Add_String_Params[] = {
	"Add"
};

static CommandParameters CreateNodeInteractiveEntity__Add_Rem_Call_Struct = {
	-17, 3, 0, CreateNodeInteractiveEntity__Add_String_Params, 0, 0
};
char * DescribeNodeInstance__Add_STACK_String_Params[] = {
	"Add"
};

int DescribeNodeInstance__Add_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Add_STACK_Rem_Call_Struct = {
	-18, 4, 0, DescribeNodeInstance__Add_STACK_String_Params, 0, 
	DescribeNodeInstance__Add_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Add_STACK_String_Params[] = {
	"Add"
};

int DeleteNodeInteractiveEntity__Add_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Add_STACK_Rem_Call_Struct = {
	-19, 4, 0, DeleteNodeInteractiveEntity__Add_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Add_STACK_Stack_Params
};
char * DescribeParam__Add_Channels_String_Params[] = {
	"Add", "Channels"
};

static CommandParameters DescribeParam__Add_Channels_Rem_Call_Struct = {
	-20, 5, 0, DescribeParam__Add_Channels_String_Params, 0, 0
};
char * DescribeParam__Add_ElementSize_String_Params[] = {
	"Add", "ElementSize"
};

static CommandParameters DescribeParam__Add_ElementSize_Rem_Call_Struct = {
	-21, 5, 0, DescribeParam__Add_ElementSize_String_Params, 0, 0
};
char * DescribeParam__Add_Scale_String_Params[] = {
	"Add", "Scale"
};

static CommandParameters DescribeParam__Add_Scale_Rem_Call_Struct = {
	-22, 5, 0, DescribeParam__Add_Scale_String_Params, 0, 0
};
char * DescribeParamInstance__Add_STACK_Channels_String_Params[] = {
	"Add", "Channels"
};

int DescribeParamInstance__Add_STACK_Channels_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Add_STACK_Channels_Rem_Call_Struct = {
	-23, 6, 0, DescribeParamInstance__Add_STACK_Channels_String_Params, 0, 
	DescribeParamInstance__Add_STACK_Channels_Stack_Params
};
char * DescribeParamInstance__Add_STACK_ElementSize_String_Params[] = {
	"Add", "ElementSize"
};

int DescribeParamInstance__Add_STACK_ElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Add_STACK_ElementSize_Rem_Call_Struct = {
	-24, 6, 0, DescribeParamInstance__Add_STACK_ElementSize_String_Params, 0, 
	DescribeParamInstance__Add_STACK_ElementSize_Stack_Params
};
char * DescribeParamInstance__Add_STACK_Scale_String_Params[] = {
	"Add", "Scale"
};

int DescribeParamInstance__Add_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Add_STACK_Scale_Rem_Call_Struct = {
	-25, 6, 0, DescribeParamInstance__Add_STACK_Scale_String_Params, 0, 
	DescribeParamInstance__Add_STACK_Scale_Stack_Params
};
char * ExecuteSetParameter__Add_STACK_Scale_String_Params[] = {
	"Add", "Scale"
};

int ExecuteSetParameter__Add_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Add_STACK_Scale_Rem_Call_Struct = {
	-26, 6, 0, ExecuteSetParameter__Add_STACK_Scale_String_Params, 0, 
	ExecuteSetParameter__Add_STACK_Scale_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__AsciiFile_String_Params[] = {
	"AsciiFile"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__AsciiFile_Rem_Call_Struct = {
	-27, 3, 0, CreateDefaultNodeInteractiveEntity__AsciiFile_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__AsciiFile_String_Params[] = {
	"AsciiFile"
};

static CommandParameters CreateNodeInteractiveEntity__AsciiFile_Rem_Call_Struct = {
	-28, 3, 0, CreateNodeInteractiveEntity__AsciiFile_String_Params, 0, 0
};
char * DescribeNodeInstance__AsciiFile_STACK_String_Params[] = {
	"AsciiFile"
};

int DescribeNodeInstance__AsciiFile_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__AsciiFile_STACK_Rem_Call_Struct = {
	-29, 4, 0, DescribeNodeInstance__AsciiFile_STACK_String_Params, 0, 
	DescribeNodeInstance__AsciiFile_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__AsciiFile_STACK_String_Params[] = {
	"AsciiFile"
};

int DeleteNodeInteractiveEntity__AsciiFile_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__AsciiFile_STACK_Rem_Call_Struct = {
	-30, 4, 0, DeleteNodeInteractiveEntity__AsciiFile_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__AsciiFile_STACK_Stack_Params
};
char * DescribeParam__AsciiFile_FileName_String_Params[] = {
	"AsciiFile", "FileName"
};

static CommandParameters DescribeParam__AsciiFile_FileName_Rem_Call_Struct = {
	-31, 5, 0, DescribeParam__AsciiFile_FileName_String_Params, 0, 0
};
char * DescribeParam__AsciiFile_Hex_String_Params[] = {
	"AsciiFile", "Hex"
};

static CommandParameters DescribeParam__AsciiFile_Hex_Rem_Call_Struct = {
	-32, 5, 0, DescribeParam__AsciiFile_Hex_String_Params, 0, 0
};
char * DescribeParam__AsciiFile_NoGroup_String_Params[] = {
	"AsciiFile", "NoGroup"
};

static CommandParameters DescribeParam__AsciiFile_NoGroup_Rem_Call_Struct = {
	-33, 5, 0, DescribeParam__AsciiFile_NoGroup_String_Params, 0, 0
};
char * DescribeParam__AsciiFile_NoHeader_String_Params[] = {
	"AsciiFile", "NoHeader"
};

static CommandParameters DescribeParam__AsciiFile_NoHeader_Rem_Call_Struct = {
	-34, 5, 0, DescribeParam__AsciiFile_NoHeader_String_Params, 0, 0
};
char * DescribeParamInstance__AsciiFile_STACK_FileName_String_Params[] = {
	"AsciiFile", "FileName"
};

int DescribeParamInstance__AsciiFile_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__AsciiFile_STACK_FileName_Rem_Call_Struct = {
	-35, 6, 0, DescribeParamInstance__AsciiFile_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__AsciiFile_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__AsciiFile_STACK_Hex_String_Params[] = {
	"AsciiFile", "Hex"
};

int DescribeParamInstance__AsciiFile_STACK_Hex_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__AsciiFile_STACK_Hex_Rem_Call_Struct = {
	-36, 6, 0, DescribeParamInstance__AsciiFile_STACK_Hex_String_Params, 0, 
	DescribeParamInstance__AsciiFile_STACK_Hex_Stack_Params
};
char * DescribeParamInstance__AsciiFile_STACK_NoGroup_String_Params[] = {
	"AsciiFile", "NoGroup"
};

int DescribeParamInstance__AsciiFile_STACK_NoGroup_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__AsciiFile_STACK_NoGroup_Rem_Call_Struct = {
	-37, 6, 0, DescribeParamInstance__AsciiFile_STACK_NoGroup_String_Params, 0, 
	DescribeParamInstance__AsciiFile_STACK_NoGroup_Stack_Params
};
char * DescribeParamInstance__AsciiFile_STACK_NoHeader_String_Params[] = {
	"AsciiFile", "NoHeader"
};

int DescribeParamInstance__AsciiFile_STACK_NoHeader_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__AsciiFile_STACK_NoHeader_Rem_Call_Struct = {
	-38, 6, 0, DescribeParamInstance__AsciiFile_STACK_NoHeader_String_Params, 0, 
	DescribeParamInstance__AsciiFile_STACK_NoHeader_Stack_Params
};
char * ExecuteSetParameter__AsciiFile_STACK_Hex_String_Params[] = {
	"AsciiFile", "Hex"
};

int ExecuteSetParameter__AsciiFile_STACK_Hex_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__AsciiFile_STACK_Hex_Rem_Call_Struct = {
	-39, 6, 0, ExecuteSetParameter__AsciiFile_STACK_Hex_String_Params, 0, 
	ExecuteSetParameter__AsciiFile_STACK_Hex_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Block_String_Params[] = {
	"Block"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Block_Rem_Call_Struct = {
	-40, 3, 0, CreateDefaultNodeInteractiveEntity__Block_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Block_String_Params[] = {
	"Block"
};

static CommandParameters CreateNodeInteractiveEntity__Block_Rem_Call_Struct = {
	-41, 3, 0, CreateNodeInteractiveEntity__Block_String_Params, 0, 0
};
char * DescribeNodeInstance__Block_STACK_String_Params[] = {
	"Block"
};

int DescribeNodeInstance__Block_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Block_STACK_Rem_Call_Struct = {
	-42, 4, 0, DescribeNodeInstance__Block_STACK_String_Params, 0, 
	DescribeNodeInstance__Block_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Block_STACK_String_Params[] = {
	"Block"
};

int DeleteNodeInteractiveEntity__Block_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Block_STACK_Rem_Call_Struct = {
	-43, 4, 0, DeleteNodeInteractiveEntity__Block_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Block_STACK_Stack_Params
};
char * DescribeParam__Block_ElementSize_String_Params[] = {
	"Block", "ElementSize"
};

static CommandParameters DescribeParam__Block_ElementSize_Rem_Call_Struct = {
	-44, 5, 0, DescribeParam__Block_ElementSize_String_Params, 0, 0
};
char * DescribeParam__Block_BlockSize_String_Params[] = {
	"Block", "BlockSize"
};

static CommandParameters DescribeParam__Block_BlockSize_Rem_Call_Struct = {
	-45, 5, 0, DescribeParam__Block_BlockSize_String_Params, 0, 0
};
char * DescribeParam__Block_OutputArithmetic_String_Params[] = {
	"Block", "OutputArithmetic"
};

static CommandParameters DescribeParam__Block_OutputArithmetic_Rem_Call_Struct = {
	-46, 5, 0, DescribeParam__Block_OutputArithmetic_String_Params, 0, 0
};
char * DescribeParamInstance__Block_STACK_ElementSize_String_Params[] = {
	"Block", "ElementSize"
};

int DescribeParamInstance__Block_STACK_ElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Block_STACK_ElementSize_Rem_Call_Struct = {
	-47, 6, 0, DescribeParamInstance__Block_STACK_ElementSize_String_Params, 0, 
	DescribeParamInstance__Block_STACK_ElementSize_Stack_Params
};
char * DescribeParamInstance__Block_STACK_BlockSize_String_Params[] = {
	"Block", "BlockSize"
};

int DescribeParamInstance__Block_STACK_BlockSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Block_STACK_BlockSize_Rem_Call_Struct = {
	-48, 6, 0, DescribeParamInstance__Block_STACK_BlockSize_String_Params, 0, 
	DescribeParamInstance__Block_STACK_BlockSize_Stack_Params
};
char * DescribeParamInstance__Block_STACK_OutputArithmetic_String_Params[] = {
	"Block", "OutputArithmetic"
};

int DescribeParamInstance__Block_STACK_OutputArithmetic_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Block_STACK_OutputArithmetic_Rem_Call_Struct = {
	-49, 6, 0, DescribeParamInstance__Block_STACK_OutputArithmetic_String_Params, 0, 
	DescribeParamInstance__Block_STACK_OutputArithmetic_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__CircBufDes_String_Params[] = {
	"CircBufDes"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__CircBufDes_Rem_Call_Struct = {
	-50, 3, 0, CreateDefaultNodeInteractiveEntity__CircBufDes_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__CircBufDes_String_Params[] = {
	"CircBufDes"
};

static CommandParameters CreateNodeInteractiveEntity__CircBufDes_Rem_Call_Struct = {
	-51, 3, 0, CreateNodeInteractiveEntity__CircBufDes_String_Params, 0, 0
};
char * MemberFunctionDescribe__CircBufDes_STACK_String_Params[] = {
	"CircBufDes"
};

int MemberFunctionDescribe__CircBufDes_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__CircBufDes_STACK_Rem_Call_Struct = {
	-52, 4, 0, MemberFunctionDescribe__CircBufDes_STACK_String_Params, 0, 
	MemberFunctionDescribe__CircBufDes_STACK_Stack_Params
};
char * DescribeNodeInstance__CircBufDes_STACK_String_Params[] = {
	"CircBufDes"
};

int DescribeNodeInstance__CircBufDes_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__CircBufDes_STACK_Rem_Call_Struct = {
	-53, 4, 0, DescribeNodeInstance__CircBufDes_STACK_String_Params, 0, 
	DescribeNodeInstance__CircBufDes_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__CircBufDes_STACK_String_Params[] = {
	"CircBufDes"
};

int DeleteNodeInteractiveEntity__CircBufDes_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__CircBufDes_STACK_Rem_Call_Struct = {
	-54, 4, 0, DeleteNodeInteractiveEntity__CircBufDes_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__CircBufDes_STACK_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_AssignToEdit_String_Params[] = {
	"AssignToEdit"
};

int ExecuteMemberFunction__STACK_STACK_AssignToEdit_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_AssignToEdit_Rem_Call_Struct = {
	-55, 7, 0, ExecuteMemberFunction__STACK_STACK_AssignToEdit_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_AssignToEdit_Stack_Params
};
char * DescribeParam__CircBufDes_Size_String_Params[] = {
	"CircBufDes", "Size"
};

static CommandParameters DescribeParam__CircBufDes_Size_Rem_Call_Struct = {
	-56, 5, 0, DescribeParam__CircBufDes_Size_String_Params, 0, 0
};
char * DescribeParam__CircBufDes_TargetSize_String_Params[] = {
	"CircBufDes", "TargetSize"
};

static CommandParameters DescribeParam__CircBufDes_TargetSize_Rem_Call_Struct = {
	-57, 5, 0, DescribeParam__CircBufDes_TargetSize_String_Params, 0, 0
};
char * DescribeParam__CircBufDes_TargetSizeGoal_String_Params[] = {
	"CircBufDes", "TargetSizeGoal"
};

static CommandParameters DescribeParam__CircBufDes_TargetSizeGoal_Rem_Call_Struct = {
	-58, 5, 0, DescribeParam__CircBufDes_TargetSizeGoal_String_Params, 0, 0
};
char * DescribeParam__CircBufDes_TargetControlGoal_String_Params[] = {
	"CircBufDes", "TargetControlGoal"
};

static CommandParameters DescribeParam__CircBufDes_TargetControlGoal_Rem_Call_Struct = {
	-59, 5, 0, DescribeParam__CircBufDes_TargetControlGoal_String_Params, 0, 0
};
char * DescribeParam__CircBufDes_MaxTargetSize_String_Params[] = {
	"CircBufDes", "MaxTargetSize"
};

static CommandParameters DescribeParam__CircBufDes_MaxTargetSize_Rem_Call_Struct = {
	-60, 5, 0, DescribeParam__CircBufDes_MaxTargetSize_String_Params, 0, 0
};
char * DescribeParam__CircBufDes_MinTargetSize_String_Params[] = {
	"CircBufDes", "MinTargetSize"
};

static CommandParameters DescribeParam__CircBufDes_MinTargetSize_Rem_Call_Struct = {
	-61, 5, 0, DescribeParam__CircBufDes_MinTargetSize_String_Params, 0, 0
};
char * DescribeParamInstance__CircBufDes_STACK_Size_String_Params[] = {
	"CircBufDes", "Size"
};

int DescribeParamInstance__CircBufDes_STACK_Size_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CircBufDes_STACK_Size_Rem_Call_Struct = {
	-62, 6, 0, DescribeParamInstance__CircBufDes_STACK_Size_String_Params, 0, 
	DescribeParamInstance__CircBufDes_STACK_Size_Stack_Params
};
char * DescribeParamInstance__CircBufDes_STACK_TargetSize_String_Params[] = {
	"CircBufDes", "TargetSize"
};

int DescribeParamInstance__CircBufDes_STACK_TargetSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CircBufDes_STACK_TargetSize_Rem_Call_Struct = {
	-63, 6, 0, DescribeParamInstance__CircBufDes_STACK_TargetSize_String_Params, 0, 
	DescribeParamInstance__CircBufDes_STACK_TargetSize_Stack_Params
};
char * DescribeParamInstance__CircBufDes_STACK_TargetSizeGoal_String_Params[] = {
	"CircBufDes", "TargetSizeGoal"
};

int DescribeParamInstance__CircBufDes_STACK_TargetSizeGoal_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CircBufDes_STACK_TargetSizeGoal_Rem_Call_Struct = {
	-64, 6, 0, DescribeParamInstance__CircBufDes_STACK_TargetSizeGoal_String_Params, 
	0, DescribeParamInstance__CircBufDes_STACK_TargetSizeGoal_Stack_Params
};
char * DescribeParamInstance__CircBufDes_STACK_TargetControlGoal_String_Params[] = {
	"CircBufDes", "TargetControlGoal"
};

int DescribeParamInstance__CircBufDes_STACK_TargetControlGoal_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CircBufDes_STACK_TargetControlGoal_Rem_Call_Struct = {
	-65, 6, 0, 
	DescribeParamInstance__CircBufDes_STACK_TargetControlGoal_String_Params, 0, 
	DescribeParamInstance__CircBufDes_STACK_TargetControlGoal_Stack_Params
};
char * DescribeParamInstance__CircBufDes_STACK_MaxTargetSize_String_Params[] = {
	"CircBufDes", "MaxTargetSize"
};

int DescribeParamInstance__CircBufDes_STACK_MaxTargetSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CircBufDes_STACK_MaxTargetSize_Rem_Call_Struct = {
	-66, 6, 0, DescribeParamInstance__CircBufDes_STACK_MaxTargetSize_String_Params, 
	0, DescribeParamInstance__CircBufDes_STACK_MaxTargetSize_Stack_Params
};
char * DescribeParamInstance__CircBufDes_STACK_MinTargetSize_String_Params[] = {
	"CircBufDes", "MinTargetSize"
};

int DescribeParamInstance__CircBufDes_STACK_MinTargetSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CircBufDes_STACK_MinTargetSize_Rem_Call_Struct = {
	-67, 6, 0, DescribeParamInstance__CircBufDes_STACK_MinTargetSize_String_Params, 
	0, DescribeParamInstance__CircBufDes_STACK_MinTargetSize_Stack_Params
};
char * ExecuteSetParameter__CircBufDes_STACK_TargetSize_String_Params[] = {
	"CircBufDes", "TargetSize"
};

int ExecuteSetParameter__CircBufDes_STACK_TargetSize_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CircBufDes_STACK_TargetSize_Rem_Call_Struct = {
	-68, 6, 0, ExecuteSetParameter__CircBufDes_STACK_TargetSize_String_Params, 0, 
	ExecuteSetParameter__CircBufDes_STACK_TargetSize_Stack_Params
};
char * ExecuteSetParameter__CircBufDes_STACK_TargetSizeGoal_String_Params[] = {
	"CircBufDes", "TargetSizeGoal"
};

int ExecuteSetParameter__CircBufDes_STACK_TargetSizeGoal_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CircBufDes_STACK_TargetSizeGoal_Rem_Call_Struct = {
	-69, 6, 0, ExecuteSetParameter__CircBufDes_STACK_TargetSizeGoal_String_Params, 
	0, ExecuteSetParameter__CircBufDes_STACK_TargetSizeGoal_Stack_Params
};
char * ExecuteSetParameter__CircBufDes_STACK_TargetControlGoal_String_Params[] = {
	"CircBufDes", "TargetControlGoal"
};

int ExecuteSetParameter__CircBufDes_STACK_TargetControlGoal_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CircBufDes_STACK_TargetControlGoal_Rem_Call_Struct = {
	-70, 6, 0, 
	ExecuteSetParameter__CircBufDes_STACK_TargetControlGoal_String_Params, 0, 
	ExecuteSetParameter__CircBufDes_STACK_TargetControlGoal_Stack_Params
};
char * ExecuteSetParameter__CircBufDes_STACK_MaxTargetSize_String_Params[] = {
	"CircBufDes", "MaxTargetSize"
};

int ExecuteSetParameter__CircBufDes_STACK_MaxTargetSize_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CircBufDes_STACK_MaxTargetSize_Rem_Call_Struct = {
	-71, 6, 0, ExecuteSetParameter__CircBufDes_STACK_MaxTargetSize_String_Params, 0, 
	ExecuteSetParameter__CircBufDes_STACK_MaxTargetSize_Stack_Params
};
char * ExecuteSetParameter__CircBufDes_STACK_MinTargetSize_String_Params[] = {
	"CircBufDes", "MinTargetSize"
};

int ExecuteSetParameter__CircBufDes_STACK_MinTargetSize_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CircBufDes_STACK_MinTargetSize_Rem_Call_Struct = {
	-72, 6, 0, ExecuteSetParameter__CircBufDes_STACK_MinTargetSize_String_Params, 0, 
	ExecuteSetParameter__CircBufDes_STACK_MinTargetSize_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__CompareDisk_String_Params[] = {
	"CompareDisk"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__CompareDisk_Rem_Call_Struct = {
	-73, 3, 0, CreateDefaultNodeInteractiveEntity__CompareDisk_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__CompareDisk_String_Params[] = {
	"CompareDisk"
};

static CommandParameters CreateNodeInteractiveEntity__CompareDisk_Rem_Call_Struct = {
	-74, 3, 0, CreateNodeInteractiveEntity__CompareDisk_String_Params, 0, 0
};
char * MemberFunctionDescribe__CompareDisk_STACK_String_Params[] = {
	"CompareDisk"
};

int MemberFunctionDescribe__CompareDisk_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__CompareDisk_STACK_Rem_Call_Struct = {
	-75, 4, 0, MemberFunctionDescribe__CompareDisk_STACK_String_Params, 0, 
	MemberFunctionDescribe__CompareDisk_STACK_Stack_Params
};
char * DescribeNodeInstance__CompareDisk_STACK_String_Params[] = {
	"CompareDisk"
};

int DescribeNodeInstance__CompareDisk_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__CompareDisk_STACK_Rem_Call_Struct = {
	-76, 4, 0, DescribeNodeInstance__CompareDisk_STACK_String_Params, 0, 
	DescribeNodeInstance__CompareDisk_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__CompareDisk_STACK_String_Params[] = {
	"CompareDisk"
};

int DeleteNodeInteractiveEntity__CompareDisk_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__CompareDisk_STACK_Rem_Call_Struct = {
	-77, 4, 0, DeleteNodeInteractiveEntity__CompareDisk_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__CompareDisk_STACK_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_DisplayHeader_String_Params[] = {
	"DisplayHeader"
};

int ExecuteMemberFunction__STACK_STACK_DisplayHeader_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_DisplayHeader_Rem_Call_Struct = {
	-78, 7, 0, ExecuteMemberFunction__STACK_STACK_DisplayHeader_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_DisplayHeader_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_IgnoreHeaderCount_String_Params[] = {
	"IgnoreHeaderCount"
};

int ExecuteMemberFunction__STACK_STACK_IgnoreHeaderCount_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_IgnoreHeaderCount_Rem_Call_Struct = {
	-79, 7, 0, ExecuteMemberFunction__STACK_STACK_IgnoreHeaderCount_String_Params, 
	0, ExecuteMemberFunction__STACK_STACK_IgnoreHeaderCount_Stack_Params
};
char * DescribeParam__CompareDisk_FileName_String_Params[] = {
	"CompareDisk", "FileName"
};

static CommandParameters DescribeParam__CompareDisk_FileName_Rem_Call_Struct = {
	-80, 5, 0, DescribeParam__CompareDisk_FileName_String_Params, 0, 0
};
char * DescribeParam__CompareDisk_MaxReport_String_Params[] = {
	"CompareDisk", "MaxReport"
};

static CommandParameters DescribeParam__CompareDisk_MaxReport_Rem_Call_Struct = {
	-81, 5, 0, DescribeParam__CompareDisk_MaxReport_String_Params, 0, 0
};
char * DescribeParam__CompareDisk_Tolerance_String_Params[] = {
	"CompareDisk", "Tolerance"
};

static CommandParameters DescribeParam__CompareDisk_Tolerance_Rem_Call_Struct = {
	-82, 5, 0, DescribeParam__CompareDisk_Tolerance_String_Params, 0, 0
};
char * DescribeParam__CompareDisk_ErrorFile_String_Params[] = {
	"CompareDisk", "ErrorFile"
};

static CommandParameters DescribeParam__CompareDisk_ErrorFile_Rem_Call_Struct = {
	-83, 5, 0, DescribeParam__CompareDisk_ErrorFile_String_Params, 0, 0
};
char * DescribeParamInstance__CompareDisk_STACK_FileName_String_Params[] = {
	"CompareDisk", "FileName"
};

int DescribeParamInstance__CompareDisk_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CompareDisk_STACK_FileName_Rem_Call_Struct = {
	-84, 6, 0, DescribeParamInstance__CompareDisk_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__CompareDisk_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__CompareDisk_STACK_MaxReport_String_Params[] = {
	"CompareDisk", "MaxReport"
};

int DescribeParamInstance__CompareDisk_STACK_MaxReport_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CompareDisk_STACK_MaxReport_Rem_Call_Struct = {
	-85, 6, 0, DescribeParamInstance__CompareDisk_STACK_MaxReport_String_Params, 0, 
	DescribeParamInstance__CompareDisk_STACK_MaxReport_Stack_Params
};
char * DescribeParamInstance__CompareDisk_STACK_Tolerance_String_Params[] = {
	"CompareDisk", "Tolerance"
};

int DescribeParamInstance__CompareDisk_STACK_Tolerance_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CompareDisk_STACK_Tolerance_Rem_Call_Struct = {
	-86, 6, 0, DescribeParamInstance__CompareDisk_STACK_Tolerance_String_Params, 0, 
	DescribeParamInstance__CompareDisk_STACK_Tolerance_Stack_Params
};
char * DescribeParamInstance__CompareDisk_STACK_ErrorFile_String_Params[] = {
	"CompareDisk", "ErrorFile"
};

int DescribeParamInstance__CompareDisk_STACK_ErrorFile_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CompareDisk_STACK_ErrorFile_Rem_Call_Struct = {
	-87, 6, 0, DescribeParamInstance__CompareDisk_STACK_ErrorFile_String_Params, 0, 
	DescribeParamInstance__CompareDisk_STACK_ErrorFile_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__ConstantData_String_Params[] = {
	"ConstantData"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ConstantData_Rem_Call_Struct = {
	-88, 3, 0, CreateDefaultNodeInteractiveEntity__ConstantData_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ConstantData_String_Params[] = {
	"ConstantData"
};

static CommandParameters CreateNodeInteractiveEntity__ConstantData_Rem_Call_Struct = {
	-89, 3, 0, CreateNodeInteractiveEntity__ConstantData_String_Params, 0, 0
};
char * DescribeNodeInstance__ConstantData_STACK_String_Params[] = {
	"ConstantData"
};

int DescribeNodeInstance__ConstantData_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ConstantData_STACK_Rem_Call_Struct = {
	-90, 4, 0, DescribeNodeInstance__ConstantData_STACK_String_Params, 0, 
	DescribeNodeInstance__ConstantData_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ConstantData_STACK_String_Params[] = {
	"ConstantData"
};

int DeleteNodeInteractiveEntity__ConstantData_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ConstantData_STACK_Rem_Call_Struct = {
	-91, 4, 0, DeleteNodeInteractiveEntity__ConstantData_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ConstantData_STACK_Stack_Params
};
char * DescribeParam__ConstantData_Value_String_Params[] = {
	"ConstantData", "Value"
};

static CommandParameters DescribeParam__ConstantData_Value_Rem_Call_Struct = {
	-92, 5, 0, DescribeParam__ConstantData_Value_String_Params, 0, 0
};
char * DescribeParamInstance__ConstantData_STACK_Value_String_Params[] = {
	"ConstantData", "Value"
};

int DescribeParamInstance__ConstantData_STACK_Value_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ConstantData_STACK_Value_Rem_Call_Struct = {
	-93, 6, 0, DescribeParamInstance__ConstantData_STACK_Value_String_Params, 0, 
	DescribeParamInstance__ConstantData_STACK_Value_Stack_Params
};
char * ExecuteSetParameter__ConstantData_STACK_Value_String_Params[] = {
	"ConstantData", "Value"
};

int ExecuteSetParameter__ConstantData_STACK_Value_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__ConstantData_STACK_Value_Rem_Call_Struct = {
	-94, 6, 0, ExecuteSetParameter__ConstantData_STACK_Value_String_Params, 0, 
	ExecuteSetParameter__ConstantData_STACK_Value_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Cos_String_Params[] = {
	"Cos"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Cos_Rem_Call_Struct = {
	-95, 3, 0, CreateDefaultNodeInteractiveEntity__Cos_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Cos_String_Params[] = {
	"Cos"
};

static CommandParameters CreateNodeInteractiveEntity__Cos_Rem_Call_Struct = {
	-96, 3, 0, CreateNodeInteractiveEntity__Cos_String_Params, 0, 0
};
char * DescribeNodeInstance__Cos_STACK_String_Params[] = {
	"Cos"
};

int DescribeNodeInstance__Cos_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Cos_STACK_Rem_Call_Struct = {
	-97, 4, 0, DescribeNodeInstance__Cos_STACK_String_Params, 0, 
	DescribeNodeInstance__Cos_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Cos_STACK_String_Params[] = {
	"Cos"
};

int DeleteNodeInteractiveEntity__Cos_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Cos_STACK_Rem_Call_Struct = {
	-98, 4, 0, DeleteNodeInteractiveEntity__Cos_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Cos_STACK_Stack_Params
};
char * DescribeParam__Cos_Frequency_String_Params[] = {
	"Cos", "Frequency"
};

static CommandParameters DescribeParam__Cos_Frequency_Rem_Call_Struct = {
	-99, 5, 0, DescribeParam__Cos_Frequency_String_Params, 0, 0
};
char * DescribeParam__Cos_Phase_String_Params[] = {
	"Cos", "Phase"
};

static CommandParameters DescribeParam__Cos_Phase_Rem_Call_Struct = {
	-100, 5, 0, DescribeParam__Cos_Phase_String_Params, 0, 0
};
char * DescribeParam__Cos_Amplitude_String_Params[] = {
	"Cos", "Amplitude"
};

static CommandParameters DescribeParam__Cos_Amplitude_Rem_Call_Struct = {
	-101, 5, 0, DescribeParam__Cos_Amplitude_String_Params, 0, 0
};
char * DescribeParamInstance__Cos_STACK_Frequency_String_Params[] = {
	"Cos", "Frequency"
};

int DescribeParamInstance__Cos_STACK_Frequency_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Cos_STACK_Frequency_Rem_Call_Struct = {
	-102, 6, 0, DescribeParamInstance__Cos_STACK_Frequency_String_Params, 0, 
	DescribeParamInstance__Cos_STACK_Frequency_Stack_Params
};
char * DescribeParamInstance__Cos_STACK_Phase_String_Params[] = {
	"Cos", "Phase"
};

int DescribeParamInstance__Cos_STACK_Phase_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Cos_STACK_Phase_Rem_Call_Struct = {
	-103, 6, 0, DescribeParamInstance__Cos_STACK_Phase_String_Params, 0, 
	DescribeParamInstance__Cos_STACK_Phase_Stack_Params
};
char * DescribeParamInstance__Cos_STACK_Amplitude_String_Params[] = {
	"Cos", "Amplitude"
};

int DescribeParamInstance__Cos_STACK_Amplitude_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Cos_STACK_Amplitude_Rem_Call_Struct = {
	-104, 6, 0, DescribeParamInstance__Cos_STACK_Amplitude_String_Params, 0, 
	DescribeParamInstance__Cos_STACK_Amplitude_Stack_Params
};
char * ExecuteSetParameter__Cos_STACK_Frequency_String_Params[] = {
	"Cos", "Frequency"
};

int ExecuteSetParameter__Cos_STACK_Frequency_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Cos_STACK_Frequency_Rem_Call_Struct = {
	-105, 6, 0, ExecuteSetParameter__Cos_STACK_Frequency_String_Params, 0, 
	ExecuteSetParameter__Cos_STACK_Frequency_Stack_Params
};
char * ExecuteSetParameter__Cos_STACK_Phase_String_Params[] = {
	"Cos", "Phase"
};

int ExecuteSetParameter__Cos_STACK_Phase_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Cos_STACK_Phase_Rem_Call_Struct = {
	-106, 6, 0, ExecuteSetParameter__Cos_STACK_Phase_String_Params, 0, 
	ExecuteSetParameter__Cos_STACK_Phase_Stack_Params
};
char * ExecuteSetParameter__Cos_STACK_Amplitude_String_Params[] = {
	"Cos", "Amplitude"
};

int ExecuteSetParameter__Cos_STACK_Amplitude_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Cos_STACK_Amplitude_Rem_Call_Struct = {
	-107, 6, 0, ExecuteSetParameter__Cos_STACK_Amplitude_String_Params, 0, 
	ExecuteSetParameter__Cos_STACK_Amplitude_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__CxCos_String_Params[] = {
	"CxCos"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__CxCos_Rem_Call_Struct = {
	-108, 3, 0, CreateDefaultNodeInteractiveEntity__CxCos_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__CxCos_String_Params[] = {
	"CxCos"
};

static CommandParameters CreateNodeInteractiveEntity__CxCos_Rem_Call_Struct = {
	-109, 3, 0, CreateNodeInteractiveEntity__CxCos_String_Params, 0, 0
};
char * DescribeNodeInstance__CxCos_STACK_String_Params[] = {
	"CxCos"
};

int DescribeNodeInstance__CxCos_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__CxCos_STACK_Rem_Call_Struct = {
	-110, 4, 0, DescribeNodeInstance__CxCos_STACK_String_Params, 0, 
	DescribeNodeInstance__CxCos_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__CxCos_STACK_String_Params[] = {
	"CxCos"
};

int DeleteNodeInteractiveEntity__CxCos_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__CxCos_STACK_Rem_Call_Struct = {
	-111, 4, 0, DeleteNodeInteractiveEntity__CxCos_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__CxCos_STACK_Stack_Params
};
char * DescribeParam__CxCos_Frequency_String_Params[] = {
	"CxCos", "Frequency"
};

static CommandParameters DescribeParam__CxCos_Frequency_Rem_Call_Struct = {
	-112, 5, 0, DescribeParam__CxCos_Frequency_String_Params, 0, 0
};
char * DescribeParam__CxCos_Phase_String_Params[] = {
	"CxCos", "Phase"
};

static CommandParameters DescribeParam__CxCos_Phase_Rem_Call_Struct = {
	-113, 5, 0, DescribeParam__CxCos_Phase_String_Params, 0, 0
};
char * DescribeParam__CxCos_Amplitude_String_Params[] = {
	"CxCos", "Amplitude"
};

static CommandParameters DescribeParam__CxCos_Amplitude_Rem_Call_Struct = {
	-114, 5, 0, DescribeParam__CxCos_Amplitude_String_Params, 0, 0
};
char * DescribeParamInstance__CxCos_STACK_Frequency_String_Params[] = {
	"CxCos", "Frequency"
};

int DescribeParamInstance__CxCos_STACK_Frequency_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxCos_STACK_Frequency_Rem_Call_Struct = {
	-115, 6, 0, DescribeParamInstance__CxCos_STACK_Frequency_String_Params, 0, 
	DescribeParamInstance__CxCos_STACK_Frequency_Stack_Params
};
char * DescribeParamInstance__CxCos_STACK_Phase_String_Params[] = {
	"CxCos", "Phase"
};

int DescribeParamInstance__CxCos_STACK_Phase_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxCos_STACK_Phase_Rem_Call_Struct = {
	-116, 6, 0, DescribeParamInstance__CxCos_STACK_Phase_String_Params, 0, 
	DescribeParamInstance__CxCos_STACK_Phase_Stack_Params
};
char * DescribeParamInstance__CxCos_STACK_Amplitude_String_Params[] = {
	"CxCos", "Amplitude"
};

int DescribeParamInstance__CxCos_STACK_Amplitude_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxCos_STACK_Amplitude_Rem_Call_Struct = {
	-117, 6, 0, DescribeParamInstance__CxCos_STACK_Amplitude_String_Params, 0, 
	DescribeParamInstance__CxCos_STACK_Amplitude_Stack_Params
};
char * ExecuteSetParameter__CxCos_STACK_Frequency_String_Params[] = {
	"CxCos", "Frequency"
};

int ExecuteSetParameter__CxCos_STACK_Frequency_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CxCos_STACK_Frequency_Rem_Call_Struct = {
	-118, 6, 0, ExecuteSetParameter__CxCos_STACK_Frequency_String_Params, 0, 
	ExecuteSetParameter__CxCos_STACK_Frequency_Stack_Params
};
char * ExecuteSetParameter__CxCos_STACK_Phase_String_Params[] = {
	"CxCos", "Phase"
};

int ExecuteSetParameter__CxCos_STACK_Phase_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CxCos_STACK_Phase_Rem_Call_Struct = {
	-119, 6, 0, ExecuteSetParameter__CxCos_STACK_Phase_String_Params, 0, 
	ExecuteSetParameter__CxCos_STACK_Phase_Stack_Params
};
char * ExecuteSetParameter__CxCos_STACK_Amplitude_String_Params[] = {
	"CxCos", "Amplitude"
};

int ExecuteSetParameter__CxCos_STACK_Amplitude_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CxCos_STACK_Amplitude_Rem_Call_Struct = {
	-120, 6, 0, ExecuteSetParameter__CxCos_STACK_Amplitude_String_Params, 0, 
	ExecuteSetParameter__CxCos_STACK_Amplitude_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__CxFFT_String_Params[] = {
	"CxFFT"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__CxFFT_Rem_Call_Struct = {
	-121, 3, 0, CreateDefaultNodeInteractiveEntity__CxFFT_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__CxFFT_String_Params[] = {
	"CxFFT"
};

static CommandParameters CreateNodeInteractiveEntity__CxFFT_Rem_Call_Struct = {
	-122, 3, 0, CreateNodeInteractiveEntity__CxFFT_String_Params, 0, 0
};
char * DescribeNodeInstance__CxFFT_STACK_String_Params[] = {
	"CxFFT"
};

int DescribeNodeInstance__CxFFT_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__CxFFT_STACK_Rem_Call_Struct = {
	-123, 4, 0, DescribeNodeInstance__CxFFT_STACK_String_Params, 0, 
	DescribeNodeInstance__CxFFT_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__CxFFT_STACK_String_Params[] = {
	"CxFFT"
};

int DeleteNodeInteractiveEntity__CxFFT_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__CxFFT_STACK_Rem_Call_Struct = {
	-124, 4, 0, DeleteNodeInteractiveEntity__CxFFT_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__CxFFT_STACK_Stack_Params
};
char * DescribeParam__CxFFT_LogSize_String_Params[] = {
	"CxFFT", "LogSize"
};

static CommandParameters DescribeParam__CxFFT_LogSize_Rem_Call_Struct = {
	-125, 5, 0, DescribeParam__CxFFT_LogSize_String_Params, 0, 0
};
char * DescribeParam__CxFFT_Overlap_String_Params[] = {
	"CxFFT", "Overlap"
};

static CommandParameters DescribeParam__CxFFT_Overlap_Rem_Call_Struct = {
	-126, 5, 0, DescribeParam__CxFFT_Overlap_String_Params, 0, 0
};
char * DescribeParam__CxFFT_CenterFrequency_String_Params[] = {
	"CxFFT", "CenterFrequency"
};

static CommandParameters DescribeParam__CxFFT_CenterFrequency_Rem_Call_Struct = {
	-127, 5, 0, DescribeParam__CxFFT_CenterFrequency_String_Params, 0, 0
};
char * DescribeParam__CxFFT_InverseFlag_String_Params[] = {
	"CxFFT", "InverseFlag"
};

static CommandParameters DescribeParam__CxFFT_InverseFlag_Rem_Call_Struct = {
	-128, 5, 0, DescribeParam__CxFFT_InverseFlag_String_Params, 0, 0
};
char * DescribeParamInstance__CxFFT_STACK_LogSize_String_Params[] = {
	"CxFFT", "LogSize"
};

int DescribeParamInstance__CxFFT_STACK_LogSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFFT_STACK_LogSize_Rem_Call_Struct = {
	-129, 6, 0, DescribeParamInstance__CxFFT_STACK_LogSize_String_Params, 0, 
	DescribeParamInstance__CxFFT_STACK_LogSize_Stack_Params
};
char * DescribeParamInstance__CxFFT_STACK_Overlap_String_Params[] = {
	"CxFFT", "Overlap"
};

int DescribeParamInstance__CxFFT_STACK_Overlap_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFFT_STACK_Overlap_Rem_Call_Struct = {
	-130, 6, 0, DescribeParamInstance__CxFFT_STACK_Overlap_String_Params, 0, 
	DescribeParamInstance__CxFFT_STACK_Overlap_Stack_Params
};
char * DescribeParamInstance__CxFFT_STACK_CenterFrequency_String_Params[] = {
	"CxFFT", "CenterFrequency"
};

int DescribeParamInstance__CxFFT_STACK_CenterFrequency_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFFT_STACK_CenterFrequency_Rem_Call_Struct = {
	-131, 6, 0, DescribeParamInstance__CxFFT_STACK_CenterFrequency_String_Params, 0, 
	DescribeParamInstance__CxFFT_STACK_CenterFrequency_Stack_Params
};
char * DescribeParamInstance__CxFFT_STACK_InverseFlag_String_Params[] = {
	"CxFFT", "InverseFlag"
};

int DescribeParamInstance__CxFFT_STACK_InverseFlag_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFFT_STACK_InverseFlag_Rem_Call_Struct = {
	-132, 6, 0, DescribeParamInstance__CxFFT_STACK_InverseFlag_String_Params, 0, 
	DescribeParamInstance__CxFFT_STACK_InverseFlag_Stack_Params
};
char * ExecuteSetParameter__CxFFT_STACK_CenterFrequency_String_Params[] = {
	"CxFFT", "CenterFrequency"
};

int ExecuteSetParameter__CxFFT_STACK_CenterFrequency_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__CxFFT_STACK_CenterFrequency_Rem_Call_Struct = {
	-133, 6, 0, ExecuteSetParameter__CxFFT_STACK_CenterFrequency_String_Params, 0, 
	ExecuteSetParameter__CxFFT_STACK_CenterFrequency_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__CxFir_String_Params[] = {
	"CxFir"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__CxFir_Rem_Call_Struct = {
	-134, 3, 0, CreateDefaultNodeInteractiveEntity__CxFir_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__CxFir_String_Params[] = {
	"CxFir"
};

static CommandParameters CreateNodeInteractiveEntity__CxFir_Rem_Call_Struct = {
	-135, 3, 0, CreateNodeInteractiveEntity__CxFir_String_Params, 0, 0
};
char * DescribeNodeInstance__CxFir_STACK_String_Params[] = {
	"CxFir"
};

int DescribeNodeInstance__CxFir_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__CxFir_STACK_Rem_Call_Struct = {
	-136, 4, 0, DescribeNodeInstance__CxFir_STACK_String_Params, 0, 
	DescribeNodeInstance__CxFir_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__CxFir_STACK_String_Params[] = {
	"CxFir"
};

int DeleteNodeInteractiveEntity__CxFir_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__CxFir_STACK_Rem_Call_Struct = {
	-137, 4, 0, DeleteNodeInteractiveEntity__CxFir_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__CxFir_STACK_Stack_Params
};
char * DescribeParam__CxFir_Resample_String_Params[] = {
	"CxFir", "Resample"
};

static CommandParameters DescribeParam__CxFir_Resample_Rem_Call_Struct = {
	-138, 5, 0, DescribeParam__CxFir_Resample_String_Params, 0, 0
};
char * DescribeParam__CxFir_ZeroPad_String_Params[] = {
	"CxFir", "ZeroPad"
};

static CommandParameters DescribeParam__CxFir_ZeroPad_Rem_Call_Struct = {
	-139, 5, 0, DescribeParam__CxFir_ZeroPad_String_Params, 0, 0
};
char * DescribeParam__CxFir_DemodFreq_String_Params[] = {
	"CxFir", "DemodFreq"
};

static CommandParameters DescribeParam__CxFir_DemodFreq_Rem_Call_Struct = {
	-140, 5, 0, DescribeParam__CxFir_DemodFreq_String_Params, 0, 0
};
char * DescribeParam__CxFir_Odd_String_Params[] = {
	"CxFir", "Odd"
};

static CommandParameters DescribeParam__CxFir_Odd_Rem_Call_Struct = {
	-141, 5, 0, DescribeParam__CxFir_Odd_String_Params, 0, 0
};
char * DescribeParam__CxFir_Coeff_String_Params[] = {
	"CxFir", "Coeff"
};

static CommandParameters DescribeParam__CxFir_Coeff_Rem_Call_Struct = {
	-142, 5, 0, DescribeParam__CxFir_Coeff_String_Params, 0, 0
};
char * DescribeParamInstance__CxFir_STACK_Resample_String_Params[] = {
	"CxFir", "Resample"
};

int DescribeParamInstance__CxFir_STACK_Resample_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFir_STACK_Resample_Rem_Call_Struct = {
	-143, 6, 0, DescribeParamInstance__CxFir_STACK_Resample_String_Params, 0, 
	DescribeParamInstance__CxFir_STACK_Resample_Stack_Params
};
char * DescribeParamInstance__CxFir_STACK_ZeroPad_String_Params[] = {
	"CxFir", "ZeroPad"
};

int DescribeParamInstance__CxFir_STACK_ZeroPad_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFir_STACK_ZeroPad_Rem_Call_Struct = {
	-144, 6, 0, DescribeParamInstance__CxFir_STACK_ZeroPad_String_Params, 0, 
	DescribeParamInstance__CxFir_STACK_ZeroPad_Stack_Params
};
char * DescribeParamInstance__CxFir_STACK_DemodFreq_String_Params[] = {
	"CxFir", "DemodFreq"
};

int DescribeParamInstance__CxFir_STACK_DemodFreq_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFir_STACK_DemodFreq_Rem_Call_Struct = {
	-145, 6, 0, DescribeParamInstance__CxFir_STACK_DemodFreq_String_Params, 0, 
	DescribeParamInstance__CxFir_STACK_DemodFreq_Stack_Params
};
char * DescribeParamInstance__CxFir_STACK_Odd_String_Params[] = {
	"CxFir", "Odd"
};

int DescribeParamInstance__CxFir_STACK_Odd_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFir_STACK_Odd_Rem_Call_Struct = {
	-146, 6, 0, DescribeParamInstance__CxFir_STACK_Odd_String_Params, 0, 
	DescribeParamInstance__CxFir_STACK_Odd_Stack_Params
};
char * DescribeParamInstance__CxFir_STACK_Coeff_String_Params[] = {
	"CxFir", "Coeff"
};

int DescribeParamInstance__CxFir_STACK_Coeff_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxFir_STACK_Coeff_Rem_Call_Struct = {
	-147, 6, 0, DescribeParamInstance__CxFir_STACK_Coeff_String_Params, 0, 
	DescribeParamInstance__CxFir_STACK_Coeff_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__CxImp_String_Params[] = {
	"CxImp"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__CxImp_Rem_Call_Struct = {
	-148, 3, 0, CreateDefaultNodeInteractiveEntity__CxImp_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__CxImp_String_Params[] = {
	"CxImp"
};

static CommandParameters CreateNodeInteractiveEntity__CxImp_Rem_Call_Struct = {
	-149, 3, 0, CreateNodeInteractiveEntity__CxImp_String_Params, 0, 0
};
char * DescribeNodeInstance__CxImp_STACK_String_Params[] = {
	"CxImp"
};

int DescribeNodeInstance__CxImp_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__CxImp_STACK_Rem_Call_Struct = {
	-150, 4, 0, DescribeNodeInstance__CxImp_STACK_String_Params, 0, 
	DescribeNodeInstance__CxImp_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__CxImp_STACK_String_Params[] = {
	"CxImp"
};

int DeleteNodeInteractiveEntity__CxImp_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__CxImp_STACK_Rem_Call_Struct = {
	-151, 4, 0, DeleteNodeInteractiveEntity__CxImp_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__CxImp_STACK_Stack_Params
};
char * DescribeParam__CxImp_Period_String_Params[] = {
	"CxImp", "Period"
};

static CommandParameters DescribeParam__CxImp_Period_Rem_Call_Struct = {
	-152, 5, 0, DescribeParam__CxImp_Period_String_Params, 0, 0
};
char * DescribeParam__CxImp_Phase_String_Params[] = {
	"CxImp", "Phase"
};

static CommandParameters DescribeParam__CxImp_Phase_Rem_Call_Struct = {
	-153, 5, 0, DescribeParam__CxImp_Phase_String_Params, 0, 0
};
char * DescribeParam__CxImp_Amplitude_String_Params[] = {
	"CxImp", "Amplitude"
};

static CommandParameters DescribeParam__CxImp_Amplitude_Rem_Call_Struct = {
	-154, 5, 0, DescribeParam__CxImp_Amplitude_String_Params, 0, 0
};
char * DescribeParam__CxImp_Width_String_Params[] = {
	"CxImp", "Width"
};

static CommandParameters DescribeParam__CxImp_Width_Rem_Call_Struct = {
	-155, 5, 0, DescribeParam__CxImp_Width_String_Params, 0, 0
};
char * DescribeParam__CxImp_Transition_String_Params[] = {
	"CxImp", "Transition"
};

static CommandParameters DescribeParam__CxImp_Transition_Rem_Call_Struct = {
	-156, 5, 0, DescribeParam__CxImp_Transition_String_Params, 0, 0
};
char * DescribeParamInstance__CxImp_STACK_Period_String_Params[] = {
	"CxImp", "Period"
};

int DescribeParamInstance__CxImp_STACK_Period_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxImp_STACK_Period_Rem_Call_Struct = {
	-157, 6, 0, DescribeParamInstance__CxImp_STACK_Period_String_Params, 0, 
	DescribeParamInstance__CxImp_STACK_Period_Stack_Params
};
char * DescribeParamInstance__CxImp_STACK_Phase_String_Params[] = {
	"CxImp", "Phase"
};

int DescribeParamInstance__CxImp_STACK_Phase_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxImp_STACK_Phase_Rem_Call_Struct = {
	-158, 6, 0, DescribeParamInstance__CxImp_STACK_Phase_String_Params, 0, 
	DescribeParamInstance__CxImp_STACK_Phase_Stack_Params
};
char * DescribeParamInstance__CxImp_STACK_Amplitude_String_Params[] = {
	"CxImp", "Amplitude"
};

int DescribeParamInstance__CxImp_STACK_Amplitude_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxImp_STACK_Amplitude_Rem_Call_Struct = {
	-159, 6, 0, DescribeParamInstance__CxImp_STACK_Amplitude_String_Params, 0, 
	DescribeParamInstance__CxImp_STACK_Amplitude_Stack_Params
};
char * DescribeParamInstance__CxImp_STACK_Width_String_Params[] = {
	"CxImp", "Width"
};

int DescribeParamInstance__CxImp_STACK_Width_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxImp_STACK_Width_Rem_Call_Struct = {
	-160, 6, 0, DescribeParamInstance__CxImp_STACK_Width_String_Params, 0, 
	DescribeParamInstance__CxImp_STACK_Width_Stack_Params
};
char * DescribeParamInstance__CxImp_STACK_Transition_String_Params[] = {
	"CxImp", "Transition"
};

int DescribeParamInstance__CxImp_STACK_Transition_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__CxImp_STACK_Transition_Rem_Call_Struct = {
	-161, 6, 0, DescribeParamInstance__CxImp_STACK_Transition_String_Params, 0, 
	DescribeParamInstance__CxImp_STACK_Transition_Stack_Params
};
char * CreateNodeInteractiveEntity__DataFlow_String_Params[] = {
	"DataFlow"
};

static CommandParameters CreateNodeInteractiveEntity__DataFlow_Rem_Call_Struct = {
	-162, 3, 0, CreateNodeInteractiveEntity__DataFlow_String_Params, 0, 0
};
char * MemberFunctionDescribe__DataFlow_STACK_String_Params[] = {
	"DataFlow"
};

int MemberFunctionDescribe__DataFlow_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__DataFlow_STACK_Rem_Call_Struct = {
	-163, 4, 0, MemberFunctionDescribe__DataFlow_STACK_String_Params, 0, 
	MemberFunctionDescribe__DataFlow_STACK_Stack_Params
};
char * DescribeMemberFunctionParameter__DataFlow_STACK_Option_String_Params[] = {
	"DataFlow", "Option"
};

int DescribeMemberFunctionParameter__DataFlow_STACK_Option_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__DataFlow_STACK_Option_Rem_Call_Struct = {
	-164, 6, 0, DescribeMemberFunctionParameter__DataFlow_STACK_Option_String_Params, 
	0, DescribeMemberFunctionParameter__DataFlow_STACK_Option_Stack_Params
};
char * DescribeMemberFunctionParameter__DataFlow_STACK_InputSamples_String_Params[] = {
	"DataFlow", "InputSamples"
};

int DescribeMemberFunctionParameter__DataFlow_STACK_InputSamples_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__DataFlow_STACK_InputSamples_Rem_Call_Struct = {
	-165, 6, 0, 
	DescribeMemberFunctionParameter__DataFlow_STACK_InputSamples_String_Params, 0, 
	DescribeMemberFunctionParameter__DataFlow_STACK_InputSamples_Stack_Params
};
char * DescribeMemberFunctionParameter__DataFlow_STACK_Descriptor_String_Params[] = {
	"DataFlow", "Descriptor"
};

int DescribeMemberFunctionParameter__DataFlow_STACK_Descriptor_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__DataFlow_STACK_Descriptor_Rem_Call_Struct = {
	-166, 6, 0, 
	DescribeMemberFunctionParameter__DataFlow_STACK_Descriptor_String_Params, 0, 
	DescribeMemberFunctionParameter__DataFlow_STACK_Descriptor_Stack_Params
};
char * DescribeNodeInstance__DataFlow_STACK_String_Params[] = {
	"DataFlow"
};

int DescribeNodeInstance__DataFlow_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__DataFlow_STACK_Rem_Call_Struct = {
	-167, 4, 0, DescribeNodeInstance__DataFlow_STACK_String_Params, 0, 
	DescribeNodeInstance__DataFlow_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__DataFlow_STACK_String_Params[] = {
	"DataFlow"
};

int DeleteNodeInteractiveEntity__DataFlow_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__DataFlow_STACK_Rem_Call_Struct = {
	-168, 4, 0, DeleteNodeInteractiveEntity__DataFlow_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__DataFlow_STACK_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_GraphDisplay_String_Params[] = {
	"GraphDisplay"
};

int ExecuteMemberFunction__STACK_STACK_GraphDisplay_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_GraphDisplay_Rem_Call_Struct = {
	-169, 7, 0, ExecuteMemberFunction__STACK_STACK_GraphDisplay_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_GraphDisplay_Stack_Params, 1
};
char * ExecuteMemberFunction__STACK_STACK_Execute_String_Params[] = {
	"Execute"
};

int ExecuteMemberFunction__STACK_STACK_Execute_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_Execute_Rem_Call_Struct = {
	-170, 7, 0, ExecuteMemberFunction__STACK_STACK_Execute_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_Execute_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_AssignBuffers_String_Params[] = {
	"AssignBuffers"
};

int ExecuteMemberFunction__STACK_STACK_AssignBuffers_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_AssignBuffers_Rem_Call_Struct = {
	-171, 7, 0, ExecuteMemberFunction__STACK_STACK_AssignBuffers_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_AssignBuffers_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_ClearBuffers_String_Params[] = {
	"ClearBuffers"
};

int ExecuteMemberFunction__STACK_STACK_ClearBuffers_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_ClearBuffers_Rem_Call_Struct = {
	-172, 7, 0, ExecuteMemberFunction__STACK_STACK_ClearBuffers_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_ClearBuffers_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_ClearNetwork_String_Params[] = {
	"ClearNetwork"
};

int ExecuteMemberFunction__STACK_STACK_ClearNetwork_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_ClearNetwork_Rem_Call_Struct = {
	-173, 7, 0, ExecuteMemberFunction__STACK_STACK_ClearNetwork_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_ClearNetwork_Stack_Params
};
char * DescribeParam__DataFlow_TheNet_String_Params[] = {
	"DataFlow", "TheNet"
};

static CommandParameters DescribeParam__DataFlow_TheNet_Rem_Call_Struct = {
	-174, 5, 0, DescribeParam__DataFlow_TheNet_String_Params, 0, 0
};
char * DescribeParamInstance__DataFlow_STACK_TheNet_String_Params[] = {
	"DataFlow", "TheNet"
};

int DescribeParamInstance__DataFlow_STACK_TheNet_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__DataFlow_STACK_TheNet_Rem_Call_Struct = {
	-175, 6, 0, DescribeParamInstance__DataFlow_STACK_TheNet_String_Params, 0, 
	DescribeParamInstance__DataFlow_STACK_TheNet_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Demod_String_Params[] = {
	"Demod"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Demod_Rem_Call_Struct = {
	-176, 3, 0, CreateDefaultNodeInteractiveEntity__Demod_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Demod_String_Params[] = {
	"Demod"
};

static CommandParameters CreateNodeInteractiveEntity__Demod_Rem_Call_Struct = {
	-177, 3, 0, CreateNodeInteractiveEntity__Demod_String_Params, 0, 0
};
char * DescribeNodeInstance__Demod_STACK_String_Params[] = {
	"Demod"
};

int DescribeNodeInstance__Demod_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Demod_STACK_Rem_Call_Struct = {
	-178, 4, 0, DescribeNodeInstance__Demod_STACK_String_Params, 0, 
	DescribeNodeInstance__Demod_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Demod_STACK_String_Params[] = {
	"Demod"
};

int DeleteNodeInteractiveEntity__Demod_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Demod_STACK_Rem_Call_Struct = {
	-179, 4, 0, DeleteNodeInteractiveEntity__Demod_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Demod_STACK_Stack_Params
};
char * DescribeParam__Demod_DataType_String_Params[] = {
	"Demod", "DataType"
};

static CommandParameters DescribeParam__Demod_DataType_Rem_Call_Struct = {
	-180, 5, 0, DescribeParam__Demod_DataType_String_Params, 0, 0
};
char * DescribeParam__Demod_DemodFreq_String_Params[] = {
	"Demod", "DemodFreq"
};

static CommandParameters DescribeParam__Demod_DemodFreq_Rem_Call_Struct = {
	-181, 5, 0, DescribeParam__Demod_DemodFreq_String_Params, 0, 0
};
char * DescribeParamInstance__Demod_STACK_DataType_String_Params[] = {
	"Demod", "DataType"
};

int DescribeParamInstance__Demod_STACK_DataType_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Demod_STACK_DataType_Rem_Call_Struct = {
	-182, 6, 0, DescribeParamInstance__Demod_STACK_DataType_String_Params, 0, 
	DescribeParamInstance__Demod_STACK_DataType_Stack_Params
};
char * DescribeParamInstance__Demod_STACK_DemodFreq_String_Params[] = {
	"Demod", "DemodFreq"
};

int DescribeParamInstance__Demod_STACK_DemodFreq_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Demod_STACK_DemodFreq_Rem_Call_Struct = {
	-183, 6, 0, DescribeParamInstance__Demod_STACK_DemodFreq_String_Params, 0, 
	DescribeParamInstance__Demod_STACK_DemodFreq_Stack_Params
};
char * ExecuteSetParameter__Demod_STACK_DemodFreq_String_Params[] = {
	"Demod", "DemodFreq"
};

int ExecuteSetParameter__Demod_STACK_DemodFreq_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Demod_STACK_DemodFreq_Rem_Call_Struct = {
	-184, 6, 0, ExecuteSetParameter__Demod_STACK_DemodFreq_String_Params, 0, 
	ExecuteSetParameter__Demod_STACK_DemodFreq_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Demux_String_Params[] = {
	"Demux"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Demux_Rem_Call_Struct = {
	-185, 3, 0, CreateDefaultNodeInteractiveEntity__Demux_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Demux_String_Params[] = {
	"Demux"
};

static CommandParameters CreateNodeInteractiveEntity__Demux_Rem_Call_Struct = {
	-186, 3, 0, CreateNodeInteractiveEntity__Demux_String_Params, 0, 0
};
char * DescribeNodeInstance__Demux_STACK_String_Params[] = {
	"Demux"
};

int DescribeNodeInstance__Demux_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Demux_STACK_Rem_Call_Struct = {
	-187, 4, 0, DescribeNodeInstance__Demux_STACK_String_Params, 0, 
	DescribeNodeInstance__Demux_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Demux_STACK_String_Params[] = {
	"Demux"
};

int DeleteNodeInteractiveEntity__Demux_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Demux_STACK_Rem_Call_Struct = {
	-188, 4, 0, DeleteNodeInteractiveEntity__Demux_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Demux_STACK_Stack_Params
};
char * DescribeParam__Demux_Channels_String_Params[] = {
	"Demux", "Channels"
};

static CommandParameters DescribeParam__Demux_Channels_Rem_Call_Struct = {
	-189, 5, 0, DescribeParam__Demux_Channels_String_Params, 0, 0
};
char * DescribeParam__Demux_InputSampleSize_String_Params[] = {
	"Demux", "InputSampleSize"
};

static CommandParameters DescribeParam__Demux_InputSampleSize_Rem_Call_Struct = {
	-190, 5, 0, DescribeParam__Demux_InputSampleSize_String_Params, 0, 0
};
char * DescribeParam__Demux_InputElementSize_String_Params[] = {
	"Demux", "InputElementSize"
};

static CommandParameters DescribeParam__Demux_InputElementSize_Rem_Call_Struct = {
	-191, 5, 0, DescribeParam__Demux_InputElementSize_String_Params, 0, 0
};
char * DescribeParam__Demux_OutputElementSize_String_Params[] = {
	"Demux", "OutputElementSize"
};

static CommandParameters DescribeParam__Demux_OutputElementSize_Rem_Call_Struct = {
	-192, 5, 0, DescribeParam__Demux_OutputElementSize_String_Params, 0, 0
};
char * DescribeParamInstance__Demux_STACK_Channels_String_Params[] = {
	"Demux", "Channels"
};

int DescribeParamInstance__Demux_STACK_Channels_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Demux_STACK_Channels_Rem_Call_Struct = {
	-193, 6, 0, DescribeParamInstance__Demux_STACK_Channels_String_Params, 0, 
	DescribeParamInstance__Demux_STACK_Channels_Stack_Params
};
char * DescribeParamInstance__Demux_STACK_InputSampleSize_String_Params[] = {
	"Demux", "InputSampleSize"
};

int DescribeParamInstance__Demux_STACK_InputSampleSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Demux_STACK_InputSampleSize_Rem_Call_Struct = {
	-194, 6, 0, DescribeParamInstance__Demux_STACK_InputSampleSize_String_Params, 0, 
	DescribeParamInstance__Demux_STACK_InputSampleSize_Stack_Params
};
char * DescribeParamInstance__Demux_STACK_InputElementSize_String_Params[] = {
	"Demux", "InputElementSize"
};

int DescribeParamInstance__Demux_STACK_InputElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Demux_STACK_InputElementSize_Rem_Call_Struct = {
	-195, 6, 0, DescribeParamInstance__Demux_STACK_InputElementSize_String_Params, 0, 
	DescribeParamInstance__Demux_STACK_InputElementSize_Stack_Params
};
char * DescribeParamInstance__Demux_STACK_OutputElementSize_String_Params[] = {
	"Demux", "OutputElementSize"
};

int DescribeParamInstance__Demux_STACK_OutputElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Demux_STACK_OutputElementSize_Rem_Call_Struct = {
	-196, 6, 0, DescribeParamInstance__Demux_STACK_OutputElementSize_String_Params, 
	0, DescribeParamInstance__Demux_STACK_OutputElementSize_Stack_Params
};
char * MemberFunctionDescribe__DisplayNodeStr_STACK_String_Params[] = {
	"DisplayNodeStr"
};

int MemberFunctionDescribe__DisplayNodeStr_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__DisplayNodeStr_STACK_Rem_Call_Struct = {
	-197, 4, 0, MemberFunctionDescribe__DisplayNodeStr_STACK_String_Params, 0, 
	MemberFunctionDescribe__DisplayNodeStr_STACK_Stack_Params
};
char * DescribeMemberFunctionParameter__DisplayNodeStr_STACK_Channel_String_Params[] = {
	"DisplayNodeStr", "Channel"
};

int DescribeMemberFunctionParameter__DisplayNodeStr_STACK_Channel_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__DisplayNodeStr_STACK_Channel_Rem_Call_Struct = {
	-198, 6, 0, 
	DescribeMemberFunctionParameter__DisplayNodeStr_STACK_Channel_String_Params, 0, 
	DescribeMemberFunctionParameter__DisplayNodeStr_STACK_Channel_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_Raise_String_Params[] = {
	"Raise"
};

int ExecuteMemberFunction__STACK_STACK_Raise_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_Raise_Rem_Call_Struct = {
	-199, 7, 0, ExecuteMemberFunction__STACK_STACK_Raise_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_Raise_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_DisplayInputTiming_String_Params[] = {
	"DisplayInputTiming"
};

int ExecuteMemberFunction__STACK_STACK_DisplayInputTiming_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_DisplayInputTiming_Rem_Call_Struct = {
	-200, 7, 0, ExecuteMemberFunction__STACK_STACK_DisplayInputTiming_String_Params, 
	0, ExecuteMemberFunction__STACK_STACK_DisplayInputTiming_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_Edit_String_Params[] = {
	"Edit"
};

int ExecuteMemberFunction__STACK_STACK_Edit_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_Edit_Rem_Call_Struct = {
	-201, 7, 0, ExecuteMemberFunction__STACK_STACK_Edit_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_Edit_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_Unlink_String_Params[] = {
	"Unlink"
};

int ExecuteMemberFunction__STACK_STACK_Unlink_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_Unlink_Rem_Call_Struct = {
	-202, 7, 0, ExecuteMemberFunction__STACK_STACK_Unlink_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_Unlink_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_LinkIn_String_Params[] = {
	"LinkIn"
};

int ExecuteMemberFunction__STACK_STACK_LinkIn_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_LinkIn_Rem_Call_Struct = {
	-203, 7, 0, ExecuteMemberFunction__STACK_STACK_LinkIn_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_LinkIn_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_NextFreeInput_String_Params[] = {
	"NextFreeInput"
};

int ExecuteMemberFunction__STACK_STACK_NextFreeInput_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_NextFreeInput_Rem_Call_Struct = {
	-204, 7, 0, ExecuteMemberFunction__STACK_STACK_NextFreeInput_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_NextFreeInput_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__EyePlot_String_Params[] = {
	"EyePlot"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__EyePlot_Rem_Call_Struct = {
	-205, 3, 0, CreateDefaultNodeInteractiveEntity__EyePlot_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__EyePlot_String_Params[] = {
	"EyePlot"
};

static CommandParameters CreateNodeInteractiveEntity__EyePlot_Rem_Call_Struct = {
	-206, 3, 0, CreateNodeInteractiveEntity__EyePlot_String_Params, 0, 0
};
char * DescribeNodeInstance__EyePlot_STACK_String_Params[] = {
	"EyePlot"
};

int DescribeNodeInstance__EyePlot_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__EyePlot_STACK_Rem_Call_Struct = {
	-207, 4, 0, DescribeNodeInstance__EyePlot_STACK_String_Params, 0, 
	DescribeNodeInstance__EyePlot_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__EyePlot_STACK_String_Params[] = {
	"EyePlot"
};

int DeleteNodeInteractiveEntity__EyePlot_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__EyePlot_STACK_Rem_Call_Struct = {
	-208, 4, 0, DeleteNodeInteractiveEntity__EyePlot_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__EyePlot_STACK_Stack_Params
};
char * DescribeParam__EyePlot_SamplesPerPlot_String_Params[] = {
	"EyePlot", "SamplesPerPlot"
};

static CommandParameters DescribeParam__EyePlot_SamplesPerPlot_Rem_Call_Struct = {
	-209, 5, 0, DescribeParam__EyePlot_SamplesPerPlot_String_Params, 0, 0
};
char * DescribeParam__EyePlot_Caption_String_Params[] = {
	"EyePlot", "Caption"
};

static CommandParameters DescribeParam__EyePlot_Caption_Rem_Call_Struct = {
	-210, 5, 0, DescribeParam__EyePlot_Caption_String_Params, 0, 0
};
char * DescribeParamInstance__EyePlot_STACK_SamplesPerPlot_String_Params[] = {
	"EyePlot", "SamplesPerPlot"
};

int DescribeParamInstance__EyePlot_STACK_SamplesPerPlot_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__EyePlot_STACK_SamplesPerPlot_Rem_Call_Struct = {
	-211, 6, 0, DescribeParamInstance__EyePlot_STACK_SamplesPerPlot_String_Params, 0, 
	DescribeParamInstance__EyePlot_STACK_SamplesPerPlot_Stack_Params
};
char * DescribeParamInstance__EyePlot_STACK_Caption_String_Params[] = {
	"EyePlot", "Caption"
};

int DescribeParamInstance__EyePlot_STACK_Caption_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__EyePlot_STACK_Caption_Rem_Call_Struct = {
	-212, 6, 0, DescribeParamInstance__EyePlot_STACK_Caption_String_Params, 0, 
	DescribeParamInstance__EyePlot_STACK_Caption_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__FindStartTail_String_Params[] = {
	"FindStartTail"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__FindStartTail_Rem_Call_Struct = {
	-213, 3, 0, CreateDefaultNodeInteractiveEntity__FindStartTail_String_Params, 0, 
	0
};
char * CreateNodeInteractiveEntity__FindStartTail_String_Params[] = {
	"FindStartTail"
};

static CommandParameters CreateNodeInteractiveEntity__FindStartTail_Rem_Call_Struct = {
	-214, 3, 0, CreateNodeInteractiveEntity__FindStartTail_String_Params, 0, 0
};
char * DescribeNodeInstance__FindStartTail_STACK_String_Params[] = {
	"FindStartTail"
};

int DescribeNodeInstance__FindStartTail_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__FindStartTail_STACK_Rem_Call_Struct = {
	-215, 4, 0, DescribeNodeInstance__FindStartTail_STACK_String_Params, 0, 
	DescribeNodeInstance__FindStartTail_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__FindStartTail_STACK_String_Params[] = {
	"FindStartTail"
};

int DeleteNodeInteractiveEntity__FindStartTail_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__FindStartTail_STACK_Rem_Call_Struct = {
	-216, 4, 0, DeleteNodeInteractiveEntity__FindStartTail_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__FindStartTail_STACK_Stack_Params
};
char * DescribeParam__FindStartTail_LowerBound_String_Params[] = {
	"FindStartTail", "LowerBound"
};

static CommandParameters DescribeParam__FindStartTail_LowerBound_Rem_Call_Struct = {
	-217, 5, 0, DescribeParam__FindStartTail_LowerBound_String_Params, 0, 0
};
char * DescribeParam__FindStartTail_UpperBound_String_Params[] = {
	"FindStartTail", "UpperBound"
};

static CommandParameters DescribeParam__FindStartTail_UpperBound_Rem_Call_Struct = {
	-218, 5, 0, DescribeParam__FindStartTail_UpperBound_String_Params, 0, 0
};
char * DescribeParam__FindStartTail_Flags_String_Params[] = {
	"FindStartTail", "Flags"
};

static CommandParameters DescribeParam__FindStartTail_Flags_Rem_Call_Struct = {
	-219, 5, 0, DescribeParam__FindStartTail_Flags_String_Params, 0, 0
};
char * DescribeParam__FindStartTail_Skip_String_Params[] = {
	"FindStartTail", "Skip"
};

static CommandParameters DescribeParam__FindStartTail_Skip_Rem_Call_Struct = {
	-220, 5, 0, DescribeParam__FindStartTail_Skip_String_Params, 0, 0
};
char * DescribeParamInstance__FindStartTail_STACK_LowerBound_String_Params[] = {
	"FindStartTail", "LowerBound"
};

int DescribeParamInstance__FindStartTail_STACK_LowerBound_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__FindStartTail_STACK_LowerBound_Rem_Call_Struct = {
	-221, 6, 0, DescribeParamInstance__FindStartTail_STACK_LowerBound_String_Params, 
	0, DescribeParamInstance__FindStartTail_STACK_LowerBound_Stack_Params
};
char * DescribeParamInstance__FindStartTail_STACK_UpperBound_String_Params[] = {
	"FindStartTail", "UpperBound"
};

int DescribeParamInstance__FindStartTail_STACK_UpperBound_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__FindStartTail_STACK_UpperBound_Rem_Call_Struct = {
	-222, 6, 0, DescribeParamInstance__FindStartTail_STACK_UpperBound_String_Params, 
	0, DescribeParamInstance__FindStartTail_STACK_UpperBound_Stack_Params
};
char * DescribeParamInstance__FindStartTail_STACK_Flags_String_Params[] = {
	"FindStartTail", "Flags"
};

int DescribeParamInstance__FindStartTail_STACK_Flags_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__FindStartTail_STACK_Flags_Rem_Call_Struct = {
	-223, 6, 0, DescribeParamInstance__FindStartTail_STACK_Flags_String_Params, 0, 
	DescribeParamInstance__FindStartTail_STACK_Flags_Stack_Params
};
char * DescribeParamInstance__FindStartTail_STACK_Skip_String_Params[] = {
	"FindStartTail", "Skip"
};

int DescribeParamInstance__FindStartTail_STACK_Skip_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__FindStartTail_STACK_Skip_Rem_Call_Struct = {
	-224, 6, 0, DescribeParamInstance__FindStartTail_STACK_Skip_String_Params, 0, 
	DescribeParamInstance__FindStartTail_STACK_Skip_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Gain_String_Params[] = {
	"Gain"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Gain_Rem_Call_Struct = {
	-225, 3, 0, CreateDefaultNodeInteractiveEntity__Gain_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Gain_String_Params[] = {
	"Gain"
};

static CommandParameters CreateNodeInteractiveEntity__Gain_Rem_Call_Struct = {
	-226, 3, 0, CreateNodeInteractiveEntity__Gain_String_Params, 0, 0
};
char * DescribeNodeInstance__Gain_STACK_String_Params[] = {
	"Gain"
};

int DescribeNodeInstance__Gain_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Gain_STACK_Rem_Call_Struct = {
	-227, 4, 0, DescribeNodeInstance__Gain_STACK_String_Params, 0, 
	DescribeNodeInstance__Gain_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Gain_STACK_String_Params[] = {
	"Gain"
};

int DeleteNodeInteractiveEntity__Gain_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Gain_STACK_Rem_Call_Struct = {
	-228, 4, 0, DeleteNodeInteractiveEntity__Gain_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Gain_STACK_Stack_Params
};
char * DescribeParam__Gain_Scale_String_Params[] = {
	"Gain", "Scale"
};

static CommandParameters DescribeParam__Gain_Scale_Rem_Call_Struct = {
	-229, 5, 0, DescribeParam__Gain_Scale_String_Params, 0, 0
};
char * DescribeParamInstance__Gain_STACK_Scale_String_Params[] = {
	"Gain", "Scale"
};

int DescribeParamInstance__Gain_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Gain_STACK_Scale_Rem_Call_Struct = {
	-230, 6, 0, DescribeParamInstance__Gain_STACK_Scale_String_Params, 0, 
	DescribeParamInstance__Gain_STACK_Scale_Stack_Params
};
char * ExecuteSetParameter__Gain_STACK_Scale_String_Params[] = {
	"Gain", "Scale"
};

int ExecuteSetParameter__Gain_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Gain_STACK_Scale_Rem_Call_Struct = {
	-231, 6, 0, ExecuteSetParameter__Gain_STACK_Scale_String_Params, 0, 
	ExecuteSetParameter__Gain_STACK_Scale_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__GainPad_String_Params[] = {
	"GainPad"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__GainPad_Rem_Call_Struct = {
	-232, 3, 0, CreateDefaultNodeInteractiveEntity__GainPad_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__GainPad_String_Params[] = {
	"GainPad"
};

static CommandParameters CreateNodeInteractiveEntity__GainPad_Rem_Call_Struct = {
	-233, 3, 0, CreateNodeInteractiveEntity__GainPad_String_Params, 0, 0
};
char * DescribeNodeInstance__GainPad_STACK_String_Params[] = {
	"GainPad"
};

int DescribeNodeInstance__GainPad_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__GainPad_STACK_Rem_Call_Struct = {
	-234, 4, 0, DescribeNodeInstance__GainPad_STACK_String_Params, 0, 
	DescribeNodeInstance__GainPad_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__GainPad_STACK_String_Params[] = {
	"GainPad"
};

int DeleteNodeInteractiveEntity__GainPad_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__GainPad_STACK_Rem_Call_Struct = {
	-235, 4, 0, DeleteNodeInteractiveEntity__GainPad_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__GainPad_STACK_Stack_Params
};
char * DescribeParam__GainPad_Scale_String_Params[] = {
	"GainPad", "Scale"
};

static CommandParameters DescribeParam__GainPad_Scale_Rem_Call_Struct = {
	-236, 5, 0, DescribeParam__GainPad_Scale_String_Params, 0, 0
};
char * DescribeParam__GainPad_ElementSize_String_Params[] = {
	"GainPad", "ElementSize"
};

static CommandParameters DescribeParam__GainPad_ElementSize_Rem_Call_Struct = {
	-237, 5, 0, DescribeParam__GainPad_ElementSize_String_Params, 0, 0
};
char * DescribeParam__GainPad_NullOutputSample_String_Params[] = {
	"GainPad", "NullOutputSample"
};

static CommandParameters DescribeParam__GainPad_NullOutputSample_Rem_Call_Struct = {
	-238, 5, 0, DescribeParam__GainPad_NullOutputSample_String_Params, 0, 0
};
char * DescribeParamInstance__GainPad_STACK_Scale_String_Params[] = {
	"GainPad", "Scale"
};

int DescribeParamInstance__GainPad_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__GainPad_STACK_Scale_Rem_Call_Struct = {
	-239, 6, 0, DescribeParamInstance__GainPad_STACK_Scale_String_Params, 0, 
	DescribeParamInstance__GainPad_STACK_Scale_Stack_Params
};
char * DescribeParamInstance__GainPad_STACK_ElementSize_String_Params[] = {
	"GainPad", "ElementSize"
};

int DescribeParamInstance__GainPad_STACK_ElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__GainPad_STACK_ElementSize_Rem_Call_Struct = {
	-240, 6, 0, DescribeParamInstance__GainPad_STACK_ElementSize_String_Params, 0, 
	DescribeParamInstance__GainPad_STACK_ElementSize_Stack_Params
};
char * DescribeParamInstance__GainPad_STACK_NullOutputSample_String_Params[] = {
	"GainPad", "NullOutputSample"
};

int DescribeParamInstance__GainPad_STACK_NullOutputSample_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__GainPad_STACK_NullOutputSample_Rem_Call_Struct = {
	-241, 6, 0, DescribeParamInstance__GainPad_STACK_NullOutputSample_String_Params, 
	0, DescribeParamInstance__GainPad_STACK_NullOutputSample_Stack_Params
};
char * ExecuteSetParameter__GainPad_STACK_Scale_String_Params[] = {
	"GainPad", "Scale"
};

int ExecuteSetParameter__GainPad_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__GainPad_STACK_Scale_Rem_Call_Struct = {
	-242, 6, 0, ExecuteSetParameter__GainPad_STACK_Scale_String_Params, 0, 
	ExecuteSetParameter__GainPad_STACK_Scale_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__HexList_String_Params[] = {
	"HexList"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__HexList_Rem_Call_Struct = {
	-243, 3, 0, CreateDefaultNodeInteractiveEntity__HexList_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__HexList_String_Params[] = {
	"HexList"
};

static CommandParameters CreateNodeInteractiveEntity__HexList_Rem_Call_Struct = {
	-244, 3, 0, CreateNodeInteractiveEntity__HexList_String_Params, 0, 0
};
char * DescribeNodeInstance__HexList_STACK_String_Params[] = {
	"HexList"
};

int DescribeNodeInstance__HexList_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__HexList_STACK_Rem_Call_Struct = {
	-245, 4, 0, DescribeNodeInstance__HexList_STACK_String_Params, 0, 
	DescribeNodeInstance__HexList_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__HexList_STACK_String_Params[] = {
	"HexList"
};

int DeleteNodeInteractiveEntity__HexList_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__HexList_STACK_Rem_Call_Struct = {
	-246, 4, 0, DeleteNodeInteractiveEntity__HexList_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__HexList_STACK_Stack_Params
};
char * DescribeParam__HexList_Channels_String_Params[] = {
	"HexList", "Channels"
};

static CommandParameters DescribeParam__HexList_Channels_Rem_Call_Struct = {
	-247, 5, 0, DescribeParam__HexList_Channels_String_Params, 0, 0
};
char * DescribeParam__HexList_Caption_String_Params[] = {
	"HexList", "Caption"
};

static CommandParameters DescribeParam__HexList_Caption_Rem_Call_Struct = {
	-248, 5, 0, DescribeParam__HexList_Caption_String_Params, 0, 0
};
char * DescribeParamInstance__HexList_STACK_Channels_String_Params[] = {
	"HexList", "Channels"
};

int DescribeParamInstance__HexList_STACK_Channels_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__HexList_STACK_Channels_Rem_Call_Struct = {
	-249, 6, 0, DescribeParamInstance__HexList_STACK_Channels_String_Params, 0, 
	DescribeParamInstance__HexList_STACK_Channels_Stack_Params
};
char * DescribeParamInstance__HexList_STACK_Caption_String_Params[] = {
	"HexList", "Caption"
};

int DescribeParamInstance__HexList_STACK_Caption_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__HexList_STACK_Caption_Rem_Call_Struct = {
	-250, 6, 0, DescribeParamInstance__HexList_STACK_Caption_String_Params, 0, 
	DescribeParamInstance__HexList_STACK_Caption_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__ImportData_String_Params[] = {
	"ImportData"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ImportData_Rem_Call_Struct = {
	-251, 3, 0, CreateDefaultNodeInteractiveEntity__ImportData_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ImportData_String_Params[] = {
	"ImportData"
};

static CommandParameters CreateNodeInteractiveEntity__ImportData_Rem_Call_Struct = {
	-252, 3, 0, CreateNodeInteractiveEntity__ImportData_String_Params, 0, 0
};
char * DescribeNodeInstance__ImportData_STACK_String_Params[] = {
	"ImportData"
};

int DescribeNodeInstance__ImportData_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ImportData_STACK_Rem_Call_Struct = {
	-253, 4, 0, DescribeNodeInstance__ImportData_STACK_String_Params, 0, 
	DescribeNodeInstance__ImportData_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ImportData_STACK_String_Params[] = {
	"ImportData"
};

int DeleteNodeInteractiveEntity__ImportData_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ImportData_STACK_Rem_Call_Struct = {
	-254, 4, 0, DeleteNodeInteractiveEntity__ImportData_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ImportData_STACK_Stack_Params
};
char * DescribeParam__ImportData_FileName_String_Params[] = {
	"ImportData", "FileName"
};

static CommandParameters DescribeParam__ImportData_FileName_Rem_Call_Struct = {
	-255, 5, 0, DescribeParam__ImportData_FileName_String_Params, 0, 0
};
char * DescribeParam__ImportData_Format_String_Params[] = {
	"ImportData", "Format"
};

static CommandParameters DescribeParam__ImportData_Format_Rem_Call_Struct = {
	-256, 5, 0, DescribeParam__ImportData_Format_String_Params, 0, 0
};
char * DescribeParam__ImportData_Fields_String_Params[] = {
	"ImportData", "Fields"
};

static CommandParameters DescribeParam__ImportData_Fields_Rem_Call_Struct = {
	-257, 5, 0, DescribeParam__ImportData_Fields_String_Params, 0, 0
};
char * DescribeParam__ImportData_RepeatFlag_String_Params[] = {
	"ImportData", "RepeatFlag"
};

static CommandParameters DescribeParam__ImportData_RepeatFlag_Rem_Call_Struct = {
	-258, 5, 0, DescribeParam__ImportData_RepeatFlag_String_Params, 0, 0
};
char * DescribeParam__ImportData_SkipFields_String_Params[] = {
	"ImportData", "SkipFields"
};

static CommandParameters DescribeParam__ImportData_SkipFields_Rem_Call_Struct = {
	-259, 5, 0, DescribeParam__ImportData_SkipFields_String_Params, 0, 0
};
char * DescribeParam__ImportData_SkipColumns_String_Params[] = {
	"ImportData", "SkipColumns"
};

static CommandParameters DescribeParam__ImportData_SkipColumns_Rem_Call_Struct = {
	-260, 5, 0, DescribeParam__ImportData_SkipColumns_String_Params, 0, 0
};
char * DescribeParamInstance__ImportData_STACK_FileName_String_Params[] = {
	"ImportData", "FileName"
};

int DescribeParamInstance__ImportData_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_FileName_Rem_Call_Struct = {
	-261, 6, 0, DescribeParamInstance__ImportData_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__ImportData_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__ImportData_STACK_Format_String_Params[] = {
	"ImportData", "Format"
};

int DescribeParamInstance__ImportData_STACK_Format_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_Format_Rem_Call_Struct = {
	-262, 6, 0, DescribeParamInstance__ImportData_STACK_Format_String_Params, 0, 
	DescribeParamInstance__ImportData_STACK_Format_Stack_Params
};
char * DescribeParamInstance__ImportData_STACK_Fields_String_Params[] = {
	"ImportData", "Fields"
};

int DescribeParamInstance__ImportData_STACK_Fields_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_Fields_Rem_Call_Struct = {
	-263, 6, 0, DescribeParamInstance__ImportData_STACK_Fields_String_Params, 0, 
	DescribeParamInstance__ImportData_STACK_Fields_Stack_Params
};
char * DescribeParamInstance__ImportData_STACK_RepeatFlag_String_Params[] = {
	"ImportData", "RepeatFlag"
};

int DescribeParamInstance__ImportData_STACK_RepeatFlag_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_RepeatFlag_Rem_Call_Struct = {
	-264, 6, 0, DescribeParamInstance__ImportData_STACK_RepeatFlag_String_Params, 0, 
	DescribeParamInstance__ImportData_STACK_RepeatFlag_Stack_Params
};
char * DescribeParamInstance__ImportData_STACK_SkipFields_String_Params[] = {
	"ImportData", "SkipFields"
};

int DescribeParamInstance__ImportData_STACK_SkipFields_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_SkipFields_Rem_Call_Struct = {
	-265, 6, 0, DescribeParamInstance__ImportData_STACK_SkipFields_String_Params, 0, 
	DescribeParamInstance__ImportData_STACK_SkipFields_Stack_Params
};
char * DescribeParamInstance__ImportData_STACK_SkipColumns_String_Params[] = {
	"ImportData", "SkipColumns"
};

int DescribeParamInstance__ImportData_STACK_SkipColumns_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ImportData_STACK_SkipColumns_Rem_Call_Struct = {
	-266, 6, 0, DescribeParamInstance__ImportData_STACK_SkipColumns_String_Params, 0, 
	DescribeParamInstance__ImportData_STACK_SkipColumns_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__InputNode_String_Params[] = {
	"InputNode"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__InputNode_Rem_Call_Struct = {
	-267, 3, 0, CreateDefaultNodeInteractiveEntity__InputNode_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__InputNode_String_Params[] = {
	"InputNode"
};

static CommandParameters CreateNodeInteractiveEntity__InputNode_Rem_Call_Struct = {
	-268, 3, 0, CreateNodeInteractiveEntity__InputNode_String_Params, 0, 0
};
char * MemberFunctionDescribe__InputNode_STACK_String_Params[] = {
	"InputNode"
};

int MemberFunctionDescribe__InputNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__InputNode_STACK_Rem_Call_Struct = {
	-269, 4, 0, MemberFunctionDescribe__InputNode_STACK_String_Params, 0, 
	MemberFunctionDescribe__InputNode_STACK_Stack_Params
};
char * DescribeNodeInstance__InputNode_STACK_String_Params[] = {
	"InputNode"
};

int DescribeNodeInstance__InputNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__InputNode_STACK_Rem_Call_Struct = {
	-270, 4, 0, DescribeNodeInstance__InputNode_STACK_String_Params, 0, 
	DescribeNodeInstance__InputNode_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__InputNode_STACK_String_Params[] = {
	"InputNode"
};

int DeleteNodeInteractiveEntity__InputNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__InputNode_STACK_Rem_Call_Struct = {
	-271, 4, 0, DeleteNodeInteractiveEntity__InputNode_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__InputNode_STACK_Stack_Params
};
char * DescribeParam__InputNode_FileName_String_Params[] = {
	"InputNode", "FileName"
};

static CommandParameters DescribeParam__InputNode_FileName_Rem_Call_Struct = {
	-272, 5, 0, DescribeParam__InputNode_FileName_String_Params, 0, 0
};
char * DescribeParam__InputNode_Flags_String_Params[] = {
	"InputNode", "Flags"
};

static CommandParameters DescribeParam__InputNode_Flags_Rem_Call_Struct = {
	-273, 5, 0, DescribeParam__InputNode_Flags_String_Params, 0, 0
};
char * DescribeParam__InputNode_DeltaOut_String_Params[] = {
	"InputNode", "DeltaOut"
};

static CommandParameters DescribeParam__InputNode_DeltaOut_Rem_Call_Struct = {
	-274, 5, 0, DescribeParam__InputNode_DeltaOut_String_Params, 0, 0
};
char * DescribeParamInstance__InputNode_STACK_FileName_String_Params[] = {
	"InputNode", "FileName"
};

int DescribeParamInstance__InputNode_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__InputNode_STACK_FileName_Rem_Call_Struct = {
	-275, 6, 0, DescribeParamInstance__InputNode_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__InputNode_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__InputNode_STACK_Flags_String_Params[] = {
	"InputNode", "Flags"
};

int DescribeParamInstance__InputNode_STACK_Flags_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__InputNode_STACK_Flags_Rem_Call_Struct = {
	-276, 6, 0, DescribeParamInstance__InputNode_STACK_Flags_String_Params, 0, 
	DescribeParamInstance__InputNode_STACK_Flags_Stack_Params
};
char * DescribeParamInstance__InputNode_STACK_DeltaOut_String_Params[] = {
	"InputNode", "DeltaOut"
};

int DescribeParamInstance__InputNode_STACK_DeltaOut_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__InputNode_STACK_DeltaOut_Rem_Call_Struct = {
	-277, 6, 0, DescribeParamInstance__InputNode_STACK_DeltaOut_String_Params, 0, 
	DescribeParamInstance__InputNode_STACK_DeltaOut_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__InputWord_String_Params[] = {
	"InputWord"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__InputWord_Rem_Call_Struct = {
	-278, 3, 0, CreateDefaultNodeInteractiveEntity__InputWord_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__InputWord_String_Params[] = {
	"InputWord"
};

static CommandParameters CreateNodeInteractiveEntity__InputWord_Rem_Call_Struct = {
	-279, 3, 0, CreateNodeInteractiveEntity__InputWord_String_Params, 0, 0
};
char * DescribeNodeInstance__InputWord_STACK_String_Params[] = {
	"InputWord"
};

int DescribeNodeInstance__InputWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__InputWord_STACK_Rem_Call_Struct = {
	-280, 4, 0, DescribeNodeInstance__InputWord_STACK_String_Params, 0, 
	DescribeNodeInstance__InputWord_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__InputWord_STACK_String_Params[] = {
	"InputWord"
};

int DeleteNodeInteractiveEntity__InputWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__InputWord_STACK_Rem_Call_Struct = {
	-281, 4, 0, DeleteNodeInteractiveEntity__InputWord_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__InputWord_STACK_Stack_Params
};
char * DescribeParam__InputWord_FileName_String_Params[] = {
	"InputWord", "FileName"
};

static CommandParameters DescribeParam__InputWord_FileName_Rem_Call_Struct = {
	-282, 5, 0, DescribeParam__InputWord_FileName_String_Params, 0, 0
};
char * DescribeParam__InputWord_FormatIn_String_Params[] = {
	"InputWord", "FormatIn"
};

static CommandParameters DescribeParam__InputWord_FormatIn_Rem_Call_Struct = {
	-283, 5, 0, DescribeParam__InputWord_FormatIn_String_Params, 0, 0
};
char * DescribeParam__InputWord_IntegerOut_String_Params[] = {
	"InputWord", "IntegerOut"
};

static CommandParameters DescribeParam__InputWord_IntegerOut_Rem_Call_Struct = {
	-284, 5, 0, DescribeParam__InputWord_IntegerOut_String_Params, 0, 0
};
char * DescribeParam__InputWord_InitialSkip_String_Params[] = {
	"InputWord", "InitialSkip"
};

static CommandParameters DescribeParam__InputWord_InitialSkip_Rem_Call_Struct = {
	-285, 5, 0, DescribeParam__InputWord_InitialSkip_String_Params, 0, 0
};
char * DescribeParam__InputWord_ElementSize_String_Params[] = {
	"InputWord", "ElementSize"
};

static CommandParameters DescribeParam__InputWord_ElementSize_Rem_Call_Struct = {
	-286, 5, 0, DescribeParam__InputWord_ElementSize_String_Params, 0, 0
};
char * DescribeParam__InputWord_BlockSize_String_Params[] = {
	"InputWord", "BlockSize"
};

static CommandParameters DescribeParam__InputWord_BlockSize_Rem_Call_Struct = {
	-287, 5, 0, DescribeParam__InputWord_BlockSize_String_Params, 0, 0
};
char * DescribeParamInstance__InputWord_STACK_FileName_String_Params[] = {
	"InputWord", "FileName"
};

int DescribeParamInstance__InputWord_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__InputWord_STACK_FileName_Rem_Call_Struct = {
	-288, 6, 0, DescribeParamInstance__InputWord_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__InputWord_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__InputWord_STACK_FormatIn_String_Params[] = {
	"InputWord", "FormatIn"
};

int DescribeParamInstance__InputWord_STACK_FormatIn_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__InputWord_STACK_FormatIn_Rem_Call_Struct = {
	-289, 6, 0, DescribeParamInstance__InputWord_STACK_FormatIn_String_Params, 0, 
	DescribeParamInstance__InputWord_STACK_FormatIn_Stack_Params
};
char * DescribeParamInstance__InputWord_STACK_IntegerOut_String_Params[] = {
	"InputWord", "IntegerOut"
};

int DescribeParamInstance__InputWord_STACK_IntegerOut_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__InputWord_STACK_IntegerOut_Rem_Call_Struct = {
	-290, 6, 0, DescribeParamInstance__InputWord_STACK_IntegerOut_String_Params, 0, 
	DescribeParamInstance__InputWord_STACK_IntegerOut_Stack_Params
};
char * DescribeParamInstance__InputWord_STACK_InitialSkip_String_Params[] = {
	"InputWord", "InitialSkip"
};

int DescribeParamInstance__InputWord_STACK_InitialSkip_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__InputWord_STACK_InitialSkip_Rem_Call_Struct = {
	-291, 6, 0, DescribeParamInstance__InputWord_STACK_InitialSkip_String_Params, 0, 
	DescribeParamInstance__InputWord_STACK_InitialSkip_Stack_Params
};
char * DescribeParamInstance__InputWord_STACK_ElementSize_String_Params[] = {
	"InputWord", "ElementSize"
};

int DescribeParamInstance__InputWord_STACK_ElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__InputWord_STACK_ElementSize_Rem_Call_Struct = {
	-292, 6, 0, DescribeParamInstance__InputWord_STACK_ElementSize_String_Params, 0, 
	DescribeParamInstance__InputWord_STACK_ElementSize_Stack_Params
};
char * DescribeParamInstance__InputWord_STACK_BlockSize_String_Params[] = {
	"InputWord", "BlockSize"
};

int DescribeParamInstance__InputWord_STACK_BlockSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__InputWord_STACK_BlockSize_Rem_Call_Struct = {
	-293, 6, 0, DescribeParamInstance__InputWord_STACK_BlockSize_String_Params, 0, 
	DescribeParamInstance__InputWord_STACK_BlockSize_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Integrate_String_Params[] = {
	"Integrate"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Integrate_Rem_Call_Struct = {
	-294, 3, 0, CreateDefaultNodeInteractiveEntity__Integrate_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Integrate_String_Params[] = {
	"Integrate"
};

static CommandParameters CreateNodeInteractiveEntity__Integrate_Rem_Call_Struct = {
	-295, 3, 0, CreateNodeInteractiveEntity__Integrate_String_Params, 0, 0
};
char * DescribeNodeInstance__Integrate_STACK_String_Params[] = {
	"Integrate"
};

int DescribeNodeInstance__Integrate_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Integrate_STACK_Rem_Call_Struct = {
	-296, 4, 0, DescribeNodeInstance__Integrate_STACK_String_Params, 0, 
	DescribeNodeInstance__Integrate_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Integrate_STACK_String_Params[] = {
	"Integrate"
};

int DeleteNodeInteractiveEntity__Integrate_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Integrate_STACK_Rem_Call_Struct = {
	-297, 4, 0, DeleteNodeInteractiveEntity__Integrate_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Integrate_STACK_Stack_Params
};
char * DescribeParam__Integrate_IntegrationSize_String_Params[] = {
	"Integrate", "IntegrationSize"
};

static CommandParameters DescribeParam__Integrate_IntegrationSize_Rem_Call_Struct = {
	-298, 5, 0, DescribeParam__Integrate_IntegrationSize_String_Params, 0, 0
};
char * DescribeParam__Integrate_OutputStep_String_Params[] = {
	"Integrate", "OutputStep"
};

static CommandParameters DescribeParam__Integrate_OutputStep_Rem_Call_Struct = {
	-299, 5, 0, DescribeParam__Integrate_OutputStep_String_Params, 0, 0
};
char * DescribeParam__Integrate_Scale_String_Params[] = {
	"Integrate", "Scale"
};

static CommandParameters DescribeParam__Integrate_Scale_Rem_Call_Struct = {
	-300, 5, 0, DescribeParam__Integrate_Scale_String_Params, 0, 0
};
char * DescribeParamInstance__Integrate_STACK_IntegrationSize_String_Params[] = {
	"Integrate", "IntegrationSize"
};

int DescribeParamInstance__Integrate_STACK_IntegrationSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Integrate_STACK_IntegrationSize_Rem_Call_Struct = {
	-301, 6, 0, DescribeParamInstance__Integrate_STACK_IntegrationSize_String_Params, 
	0, DescribeParamInstance__Integrate_STACK_IntegrationSize_Stack_Params
};
char * DescribeParamInstance__Integrate_STACK_OutputStep_String_Params[] = {
	"Integrate", "OutputStep"
};

int DescribeParamInstance__Integrate_STACK_OutputStep_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Integrate_STACK_OutputStep_Rem_Call_Struct = {
	-302, 6, 0, DescribeParamInstance__Integrate_STACK_OutputStep_String_Params, 0, 
	DescribeParamInstance__Integrate_STACK_OutputStep_Stack_Params
};
char * DescribeParamInstance__Integrate_STACK_Scale_String_Params[] = {
	"Integrate", "Scale"
};

int DescribeParamInstance__Integrate_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Integrate_STACK_Scale_Rem_Call_Struct = {
	-303, 6, 0, DescribeParamInstance__Integrate_STACK_Scale_String_Params, 0, 
	DescribeParamInstance__Integrate_STACK_Scale_Stack_Params
};
char * ExecuteSetParameter__Integrate_STACK_Scale_String_Params[] = {
	"Integrate", "Scale"
};

int ExecuteSetParameter__Integrate_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Integrate_STACK_Scale_Rem_Call_Struct = {
	-304, 6, 0, ExecuteSetParameter__Integrate_STACK_Scale_String_Params, 0, 
	ExecuteSetParameter__Integrate_STACK_Scale_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Interpolate_String_Params[] = {
	"Interpolate"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Interpolate_Rem_Call_Struct = {
	-305, 3, 0, CreateDefaultNodeInteractiveEntity__Interpolate_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Interpolate_String_Params[] = {
	"Interpolate"
};

static CommandParameters CreateNodeInteractiveEntity__Interpolate_Rem_Call_Struct = {
	-306, 3, 0, CreateNodeInteractiveEntity__Interpolate_String_Params, 0, 0
};
char * DescribeNodeInstance__Interpolate_STACK_String_Params[] = {
	"Interpolate"
};

int DescribeNodeInstance__Interpolate_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Interpolate_STACK_Rem_Call_Struct = {
	-307, 4, 0, DescribeNodeInstance__Interpolate_STACK_String_Params, 0, 
	DescribeNodeInstance__Interpolate_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Interpolate_STACK_String_Params[] = {
	"Interpolate"
};

int DeleteNodeInteractiveEntity__Interpolate_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Interpolate_STACK_Rem_Call_Struct = {
	-308, 4, 0, DeleteNodeInteractiveEntity__Interpolate_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Interpolate_STACK_Stack_Params
};
char * DescribeParam__Interpolate_DeltaIn_String_Params[] = {
	"Interpolate", "DeltaIn"
};

static CommandParameters DescribeParam__Interpolate_DeltaIn_Rem_Call_Struct = {
	-309, 5, 0, DescribeParam__Interpolate_DeltaIn_String_Params, 0, 0
};
char * DescribeParam__Interpolate_DeltaOut_String_Params[] = {
	"Interpolate", "DeltaOut"
};

static CommandParameters DescribeParam__Interpolate_DeltaOut_Rem_Call_Struct = {
	-310, 5, 0, DescribeParam__Interpolate_DeltaOut_String_Params, 0, 0
};
char * DescribeParamInstance__Interpolate_STACK_DeltaIn_String_Params[] = {
	"Interpolate", "DeltaIn"
};

int DescribeParamInstance__Interpolate_STACK_DeltaIn_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Interpolate_STACK_DeltaIn_Rem_Call_Struct = {
	-311, 6, 0, DescribeParamInstance__Interpolate_STACK_DeltaIn_String_Params, 0, 
	DescribeParamInstance__Interpolate_STACK_DeltaIn_Stack_Params
};
char * DescribeParamInstance__Interpolate_STACK_DeltaOut_String_Params[] = {
	"Interpolate", "DeltaOut"
};

int DescribeParamInstance__Interpolate_STACK_DeltaOut_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Interpolate_STACK_DeltaOut_Rem_Call_Struct = {
	-312, 6, 0, DescribeParamInstance__Interpolate_STACK_DeltaOut_String_Params, 0, 
	DescribeParamInstance__Interpolate_STACK_DeltaOut_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Listing_String_Params[] = {
	"Listing"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Listing_Rem_Call_Struct = {
	-313, 3, 0, CreateDefaultNodeInteractiveEntity__Listing_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Listing_String_Params[] = {
	"Listing"
};

static CommandParameters CreateNodeInteractiveEntity__Listing_Rem_Call_Struct = {
	-314, 3, 0, CreateNodeInteractiveEntity__Listing_String_Params, 0, 0
};
char * DescribeNodeInstance__Listing_STACK_String_Params[] = {
	"Listing"
};

int DescribeNodeInstance__Listing_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Listing_STACK_Rem_Call_Struct = {
	-315, 4, 0, DescribeNodeInstance__Listing_STACK_String_Params, 0, 
	DescribeNodeInstance__Listing_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Listing_STACK_String_Params[] = {
	"Listing"
};

int DeleteNodeInteractiveEntity__Listing_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Listing_STACK_Rem_Call_Struct = {
	-316, 4, 0, DeleteNodeInteractiveEntity__Listing_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Listing_STACK_Stack_Params
};
char * DescribeParam__Listing_Hex_String_Params[] = {
	"Listing", "Hex"
};

static CommandParameters DescribeParam__Listing_Hex_Rem_Call_Struct = {
	-317, 5, 0, DescribeParam__Listing_Hex_String_Params, 0, 0
};
char * DescribeParam__Listing_Caption_String_Params[] = {
	"Listing", "Caption"
};

static CommandParameters DescribeParam__Listing_Caption_Rem_Call_Struct = {
	-318, 5, 0, DescribeParam__Listing_Caption_String_Params, 0, 0
};
char * DescribeParamInstance__Listing_STACK_Hex_String_Params[] = {
	"Listing", "Hex"
};

int DescribeParamInstance__Listing_STACK_Hex_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Listing_STACK_Hex_Rem_Call_Struct = {
	-319, 6, 0, DescribeParamInstance__Listing_STACK_Hex_String_Params, 0, 
	DescribeParamInstance__Listing_STACK_Hex_Stack_Params
};
char * DescribeParamInstance__Listing_STACK_Caption_String_Params[] = {
	"Listing", "Caption"
};

int DescribeParamInstance__Listing_STACK_Caption_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Listing_STACK_Caption_Rem_Call_Struct = {
	-320, 6, 0, DescribeParamInstance__Listing_STACK_Caption_String_Params, 0, 
	DescribeParamInstance__Listing_STACK_Caption_Stack_Params
};
char * ExecuteSetParameter__Listing_STACK_Hex_String_Params[] = {
	"Listing", "Hex"
};

int ExecuteSetParameter__Listing_STACK_Hex_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Listing_STACK_Hex_Rem_Call_Struct = {
	-321, 6, 0, ExecuteSetParameter__Listing_STACK_Hex_String_Params, 0, 
	ExecuteSetParameter__Listing_STACK_Hex_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__MaskWord_String_Params[] = {
	"MaskWord"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__MaskWord_Rem_Call_Struct = {
	-322, 3, 0, CreateDefaultNodeInteractiveEntity__MaskWord_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__MaskWord_String_Params[] = {
	"MaskWord"
};

static CommandParameters CreateNodeInteractiveEntity__MaskWord_Rem_Call_Struct = {
	-323, 3, 0, CreateNodeInteractiveEntity__MaskWord_String_Params, 0, 0
};
char * DescribeNodeInstance__MaskWord_STACK_String_Params[] = {
	"MaskWord"
};

int DescribeNodeInstance__MaskWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__MaskWord_STACK_Rem_Call_Struct = {
	-324, 4, 0, DescribeNodeInstance__MaskWord_STACK_String_Params, 0, 
	DescribeNodeInstance__MaskWord_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__MaskWord_STACK_String_Params[] = {
	"MaskWord"
};

int DeleteNodeInteractiveEntity__MaskWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__MaskWord_STACK_Rem_Call_Struct = {
	-325, 4, 0, DeleteNodeInteractiveEntity__MaskWord_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__MaskWord_STACK_Stack_Params
};
char * DescribeParam__MaskWord_Mask_String_Params[] = {
	"MaskWord", "Mask"
};

static CommandParameters DescribeParam__MaskWord_Mask_Rem_Call_Struct = {
	-326, 5, 0, DescribeParam__MaskWord_Mask_String_Params, 0, 0
};
char * DescribeParamInstance__MaskWord_STACK_Mask_String_Params[] = {
	"MaskWord", "Mask"
};

int DescribeParamInstance__MaskWord_STACK_Mask_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__MaskWord_STACK_Mask_Rem_Call_Struct = {
	-327, 6, 0, DescribeParamInstance__MaskWord_STACK_Mask_String_Params, 0, 
	DescribeParamInstance__MaskWord_STACK_Mask_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Mux_String_Params[] = {
	"Mux"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Mux_Rem_Call_Struct = {
	-328, 3, 0, CreateDefaultNodeInteractiveEntity__Mux_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Mux_String_Params[] = {
	"Mux"
};

static CommandParameters CreateNodeInteractiveEntity__Mux_Rem_Call_Struct = {
	-329, 3, 0, CreateNodeInteractiveEntity__Mux_String_Params, 0, 0
};
char * DescribeNodeInstance__Mux_STACK_String_Params[] = {
	"Mux"
};

int DescribeNodeInstance__Mux_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Mux_STACK_Rem_Call_Struct = {
	-330, 4, 0, DescribeNodeInstance__Mux_STACK_String_Params, 0, 
	DescribeNodeInstance__Mux_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Mux_STACK_String_Params[] = {
	"Mux"
};

int DeleteNodeInteractiveEntity__Mux_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Mux_STACK_Rem_Call_Struct = {
	-331, 4, 0, DeleteNodeInteractiveEntity__Mux_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Mux_STACK_Stack_Params
};
char * DescribeParam__Mux_Channels_String_Params[] = {
	"Mux", "Channels"
};

static CommandParameters DescribeParam__Mux_Channels_Rem_Call_Struct = {
	-332, 5, 0, DescribeParam__Mux_Channels_String_Params, 0, 0
};
char * DescribeParam__Mux_InputSampleSize_String_Params[] = {
	"Mux", "InputSampleSize"
};

static CommandParameters DescribeParam__Mux_InputSampleSize_Rem_Call_Struct = {
	-333, 5, 0, DescribeParam__Mux_InputSampleSize_String_Params, 0, 0
};
char * DescribeParam__Mux_OutputSampleSize_String_Params[] = {
	"Mux", "OutputSampleSize"
};

static CommandParameters DescribeParam__Mux_OutputSampleSize_Rem_Call_Struct = {
	-334, 5, 0, DescribeParam__Mux_OutputSampleSize_String_Params, 0, 0
};
char * DescribeParam__Mux_MinimumChunk_String_Params[] = {
	"Mux", "MinimumChunk"
};

static CommandParameters DescribeParam__Mux_MinimumChunk_Rem_Call_Struct = {
	-335, 5, 0, DescribeParam__Mux_MinimumChunk_String_Params, 0, 0
};
char * DescribeParamInstance__Mux_STACK_Channels_String_Params[] = {
	"Mux", "Channels"
};

int DescribeParamInstance__Mux_STACK_Channels_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Mux_STACK_Channels_Rem_Call_Struct = {
	-336, 6, 0, DescribeParamInstance__Mux_STACK_Channels_String_Params, 0, 
	DescribeParamInstance__Mux_STACK_Channels_Stack_Params
};
char * DescribeParamInstance__Mux_STACK_InputSampleSize_String_Params[] = {
	"Mux", "InputSampleSize"
};

int DescribeParamInstance__Mux_STACK_InputSampleSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Mux_STACK_InputSampleSize_Rem_Call_Struct = {
	-337, 6, 0, DescribeParamInstance__Mux_STACK_InputSampleSize_String_Params, 0, 
	DescribeParamInstance__Mux_STACK_InputSampleSize_Stack_Params
};
char * DescribeParamInstance__Mux_STACK_OutputSampleSize_String_Params[] = {
	"Mux", "OutputSampleSize"
};

int DescribeParamInstance__Mux_STACK_OutputSampleSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Mux_STACK_OutputSampleSize_Rem_Call_Struct = {
	-338, 6, 0, DescribeParamInstance__Mux_STACK_OutputSampleSize_String_Params, 0, 
	DescribeParamInstance__Mux_STACK_OutputSampleSize_Stack_Params
};
char * DescribeParamInstance__Mux_STACK_MinimumChunk_String_Params[] = {
	"Mux", "MinimumChunk"
};

int DescribeParamInstance__Mux_STACK_MinimumChunk_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Mux_STACK_MinimumChunk_Rem_Call_Struct = {
	-339, 6, 0, DescribeParamInstance__Mux_STACK_MinimumChunk_String_Params, 0, 
	DescribeParamInstance__Mux_STACK_MinimumChunk_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Network_String_Params[] = {
	"Network"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Network_Rem_Call_Struct = {
	-340, 3, 0, CreateDefaultNodeInteractiveEntity__Network_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Network_String_Params[] = {
	"Network"
};

static CommandParameters CreateNodeInteractiveEntity__Network_Rem_Call_Struct = {
	-341, 3, 0, CreateNodeInteractiveEntity__Network_String_Params, 0, 0
};
char * MemberFunctionDescribe__Network_STACK_String_Params[] = {
	"Network"
};

int MemberFunctionDescribe__Network_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__Network_STACK_Rem_Call_Struct = {
	-342, 4, 0, MemberFunctionDescribe__Network_STACK_String_Params, 0, 
	MemberFunctionDescribe__Network_STACK_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_InputSamples_String_Params[] = {
	"Network", "InputSamples"
};

int DescribeMemberFunctionParameter__Network_STACK_InputSamples_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_InputSamples_Rem_Call_Struct = {
	-343, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_InputSamples_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_InputSamples_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_ToReplace_String_Params[] = {
	"Network", "ToReplace"
};

int DescribeMemberFunctionParameter__Network_STACK_ToReplace_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_ToReplace_Rem_Call_Struct = {
	-344, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ToReplace_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ToReplace_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Replacement_String_Params[] = {
	"Network", "Replacement"
};

int DescribeMemberFunctionParameter__Network_STACK_Replacement_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Replacement_Rem_Call_Struct = {
	-345, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Replacement_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Replacement_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Target_String_Params[] = {
	"Network", "Target"
};

int DescribeMemberFunctionParameter__Network_STACK_Target_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Target_Rem_Call_Struct = {
	-346, 6, 0, DescribeMemberFunctionParameter__Network_STACK_Target_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_Target_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Create_String_Params[] = {
	"Network", "Create"
};

int DescribeMemberFunctionParameter__Network_STACK_Create_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Create_Rem_Call_Struct = {
	-347, 6, 0, DescribeMemberFunctionParameter__Network_STACK_Create_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_Create_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Directory_String_Params[] = {
	"Network", "Directory"
};

int DescribeMemberFunctionParameter__Network_STACK_Directory_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Directory_Rem_Call_Struct = {
	-348, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Directory_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Directory_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_DirName_String_Params[] = {
	"Network", "DirName"
};

int DescribeMemberFunctionParameter__Network_STACK_DirName_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_DirName_Rem_Call_Struct = {
	-349, 6, 0, DescribeMemberFunctionParameter__Network_STACK_DirName_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_DirName_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_ExecuteCount_String_Params[] = {
	"Network", "ExecuteCount"
};

int DescribeMemberFunctionParameter__Network_STACK_ExecuteCount_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_ExecuteCount_Rem_Call_Struct = {
	-350, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ExecuteCount_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ExecuteCount_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_ExtraCountCreator_String_Params[] = {
	"Network", "ExtraCountCreator"
};

int DescribeMemberFunctionParameter__Network_STACK_ExtraCountCreator_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_ExtraCountCreator_Rem_Call_Struct = {
	-351, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ExtraCountCreator_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ExtraCountCreator_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_MaxReport_String_Params[] = {
	"Network", "MaxReport"
};

int DescribeMemberFunctionParameter__Network_STACK_MaxReport_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_MaxReport_Rem_Call_Struct = {
	-352, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_MaxReport_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_MaxReport_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Tolerance_String_Params[] = {
	"Network", "Tolerance"
};

int DescribeMemberFunctionParameter__Network_STACK_Tolerance_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Tolerance_Rem_Call_Struct = {
	-353, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Tolerance_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Tolerance_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_errorFile_String_Params[] = {
	"Network", "errorFile"
};

int DescribeMemberFunctionParameter__Network_STACK_errorFile_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_errorFile_Rem_Call_Struct = {
	-354, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_errorFile_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_errorFile_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_ErrorFile_String_Params[] = {
	"Network", "ErrorFile"
};

int DescribeMemberFunctionParameter__Network_STACK_ErrorFile_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_ErrorFile_Rem_Call_Struct = {
	-355, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ErrorFile_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ErrorFile_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Exact_String_Params[] = {
	"Network", "Exact"
};

int DescribeMemberFunctionParameter__Network_STACK_Exact_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Exact_Rem_Call_Struct = {
	-356, 6, 0, DescribeMemberFunctionParameter__Network_STACK_Exact_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_Exact_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_TheNode_String_Params[] = {
	"Network", "TheNode"
};

int DescribeMemberFunctionParameter__Network_STACK_TheNode_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_TheNode_Rem_Call_Struct = {
	-357, 6, 0, DescribeMemberFunctionParameter__Network_STACK_TheNode_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_TheNode_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Width_String_Params[] = {
	"Network", "Width"
};

int DescribeMemberFunctionParameter__Network_STACK_Width_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Width_Rem_Call_Struct = {
	-358, 6, 0, DescribeMemberFunctionParameter__Network_STACK_Width_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_Width_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Height_String_Params[] = {
	"Network", "Height"
};

int DescribeMemberFunctionParameter__Network_STACK_Height_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Height_Rem_Call_Struct = {
	-359, 6, 0, DescribeMemberFunctionParameter__Network_STACK_Height_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_Height_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_Descriptor_String_Params[] = {
	"Network", "Descriptor"
};

int DescribeMemberFunctionParameter__Network_STACK_Descriptor_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_Descriptor_Rem_Call_Struct = {
	-360, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Descriptor_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_Descriptor_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_OutChannel_String_Params[] = {
	"Network", "OutChannel"
};

int DescribeMemberFunctionParameter__Network_STACK_OutChannel_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_OutChannel_Rem_Call_Struct = {
	-361, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_OutChannel_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_OutChannel_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_NodeOut_String_Params[] = {
	"Network", "NodeOut"
};

int DescribeMemberFunctionParameter__Network_STACK_NodeOut_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_NodeOut_Rem_Call_Struct = {
	-362, 6, 0, DescribeMemberFunctionParameter__Network_STACK_NodeOut_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_NodeOut_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_NodeIn_String_Params[] = {
	"Network", "NodeIn"
};

int DescribeMemberFunctionParameter__Network_STACK_NodeIn_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_NodeIn_Rem_Call_Struct = {
	-363, 6, 0, DescribeMemberFunctionParameter__Network_STACK_NodeIn_String_Params, 
	0, DescribeMemberFunctionParameter__Network_STACK_NodeIn_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_ChannelOut_String_Params[] = {
	"Network", "ChannelOut"
};

int DescribeMemberFunctionParameter__Network_STACK_ChannelOut_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_ChannelOut_Rem_Call_Struct = {
	-364, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ChannelOut_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ChannelOut_Stack_Params
};
char * DescribeMemberFunctionParameter__Network_STACK_ChannelIn_String_Params[] = {
	"Network", "ChannelIn"
};

int DescribeMemberFunctionParameter__Network_STACK_ChannelIn_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__Network_STACK_ChannelIn_Rem_Call_Struct = {
	-365, 6, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ChannelIn_String_Params, 0, 
	DescribeMemberFunctionParameter__Network_STACK_ChannelIn_Stack_Params
};
char * DescribeNodeInstance__Network_STACK_String_Params[] = {
	"Network"
};

int DescribeNodeInstance__Network_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Network_STACK_Rem_Call_Struct = {
	-366, 4, 0, DescribeNodeInstance__Network_STACK_String_Params, 0, 
	DescribeNodeInstance__Network_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Network_STACK_String_Params[] = {
	"Network"
};

int DeleteNodeInteractiveEntity__Network_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Network_STACK_Rem_Call_Struct = {
	-367, 4, 0, DeleteNodeInteractiveEntity__Network_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Network_STACK_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_ReplaceNode_String_Params[] = {
	"ReplaceNode"
};

int ExecuteMemberFunction__STACK_STACK_ReplaceNode_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_ReplaceNode_Rem_Call_Struct = {
	-368, 7, 0, ExecuteMemberFunction__STACK_STACK_ReplaceNode_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_ReplaceNode_Stack_Params, 1
};
char * ExecuteMemberFunction__STACK_STACK_MakeTarget_String_Params[] = {
	"MakeTarget"
};

int ExecuteMemberFunction__STACK_STACK_MakeTarget_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_MakeTarget_Rem_Call_Struct = {
	-369, 7, 0, ExecuteMemberFunction__STACK_STACK_MakeTarget_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_MakeTarget_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_MakeValidate_String_Params[] = {
	"MakeValidate"
};

int ExecuteMemberFunction__STACK_STACK_MakeValidate_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_MakeValidate_Rem_Call_Struct = {
	-370, 7, 0, ExecuteMemberFunction__STACK_STACK_MakeValidate_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_MakeValidate_Stack_Params, 1
};
char * ExecuteMemberFunction__STACK_STACK_TargetValidate_String_Params[] = {
	"TargetValidate"
};

int ExecuteMemberFunction__STACK_STACK_TargetValidate_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_TargetValidate_Rem_Call_Struct = {
	-371, 7, 0, ExecuteMemberFunction__STACK_STACK_TargetValidate_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_TargetValidate_Stack_Params, 1
};
char * ExecuteMemberFunction__STACK_STACK_SetTimingExact_String_Params[] = {
	"SetTimingExact"
};

int ExecuteMemberFunction__STACK_STACK_SetTimingExact_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_SetTimingExact_Rem_Call_Struct = {
	-372, 7, 0, ExecuteMemberFunction__STACK_STACK_SetTimingExact_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_SetTimingExact_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_ReplaceWithOutput_String_Params[] = {
	"ReplaceWithOutput"
};

int ExecuteMemberFunction__STACK_STACK_ReplaceWithOutput_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_ReplaceWithOutput_Rem_Call_Struct = {
	-373, 7, 0, ExecuteMemberFunction__STACK_STACK_ReplaceWithOutput_String_Params, 
	0, ExecuteMemberFunction__STACK_STACK_ReplaceWithOutput_Stack_Params, 1
};
char * ExecuteMemberFunction__STACK_STACK_ReplaceWithCompare_String_Params[] = {
	"ReplaceWithCompare"
};

int ExecuteMemberFunction__STACK_STACK_ReplaceWithCompare_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_ReplaceWithCompare_Rem_Call_Struct = {
	-374, 7, 0, ExecuteMemberFunction__STACK_STACK_ReplaceWithCompare_String_Params, 
	0, ExecuteMemberFunction__STACK_STACK_ReplaceWithCompare_Stack_Params, 1
};
char * ExecuteMemberFunction__STACK_STACK_Add_Op_String_Params[] = {
	"operator+"
};

int ExecuteMemberFunction__STACK_STACK_Add_Op_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_Add_Op_Rem_Call_Struct = {
	-375, 7, 0, ExecuteMemberFunction__STACK_STACK_Add_Op_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_Add_Op_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_RightShift_Op_String_Params[] = {
	"operator>>"
};

int ExecuteMemberFunction__STACK_STACK_RightShift_Op_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_RightShift_Op_Rem_Call_Struct = {
	-376, 7, 0, ExecuteMemberFunction__STACK_STACK_RightShift_Op_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_RightShift_Op_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_GraphDisplayWindow_String_Params[] = {
	"GraphDisplayWindow"
};

int ExecuteMemberFunction__STACK_STACK_GraphDisplayWindow_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_GraphDisplayWindow_Rem_Call_Struct = {
	-377, 7, 0, ExecuteMemberFunction__STACK_STACK_GraphDisplayWindow_String_Params, 
	0, ExecuteMemberFunction__STACK_STACK_GraphDisplayWindow_Stack_Params, 1
};
char * ExecuteMemberFunction__STACK_STACK_DisplayNames_String_Params[] = {
	"DisplayNames"
};

int ExecuteMemberFunction__STACK_STACK_DisplayNames_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_DisplayNames_Rem_Call_Struct = {
	-378, 7, 0, ExecuteMemberFunction__STACK_STACK_DisplayNames_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_DisplayNames_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_SetBufferDescriptor_String_Params[] = {
	"SetBufferDescriptor"
};

int ExecuteMemberFunction__STACK_STACK_SetBufferDescriptor_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_SetBufferDescriptor_Rem_Call_Struct = {
	-379, 7, 0, ExecuteMemberFunction__STACK_STACK_SetBufferDescriptor_String_Params, 
	0, ExecuteMemberFunction__STACK_STACK_SetBufferDescriptor_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_AssociateNode_String_Params[] = {
	"AssociateNode"
};

int ExecuteMemberFunction__STACK_STACK_AssociateNode_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_AssociateNode_Rem_Call_Struct = {
	-380, 7, 0, ExecuteMemberFunction__STACK_STACK_AssociateNode_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_AssociateNode_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_Link_String_Params[] = {
	"Link"
};

int ExecuteMemberFunction__STACK_STACK_Link_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_Link_Rem_Call_Struct = {
	-381, 7, 0, ExecuteMemberFunction__STACK_STACK_Link_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_Link_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_SelfLink_String_Params[] = {
	"SelfLink"
};

int ExecuteMemberFunction__STACK_STACK_SelfLink_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_SelfLink_Rem_Call_Struct = {
	-382, 7, 0, ExecuteMemberFunction__STACK_STACK_SelfLink_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_SelfLink_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_GetBufferDescriptor_String_Params[] = {
	"GetBufferDescriptor"
};

int ExecuteMemberFunction__STACK_STACK_GetBufferDescriptor_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_GetBufferDescriptor_Rem_Call_Struct = {
	-383, 7, 0, ExecuteMemberFunction__STACK_STACK_GetBufferDescriptor_String_Params, 
	0, ExecuteMemberFunction__STACK_STACK_GetBufferDescriptor_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_GetNetController_String_Params[] = {
	"GetNetController"
};

int ExecuteMemberFunction__STACK_STACK_GetNetController_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_GetNetController_Rem_Call_Struct = {
	-384, 7, 0, ExecuteMemberFunction__STACK_STACK_GetNetController_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_GetNetController_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Normal_String_Params[] = {
	"Normal"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Normal_Rem_Call_Struct = {
	-385, 3, 0, CreateDefaultNodeInteractiveEntity__Normal_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Normal_String_Params[] = {
	"Normal"
};

static CommandParameters CreateNodeInteractiveEntity__Normal_Rem_Call_Struct = {
	-386, 3, 0, CreateNodeInteractiveEntity__Normal_String_Params, 0, 0
};
char * DescribeNodeInstance__Normal_STACK_String_Params[] = {
	"Normal"
};

int DescribeNodeInstance__Normal_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Normal_STACK_Rem_Call_Struct = {
	-387, 4, 0, DescribeNodeInstance__Normal_STACK_String_Params, 0, 
	DescribeNodeInstance__Normal_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Normal_STACK_String_Params[] = {
	"Normal"
};

int DeleteNodeInteractiveEntity__Normal_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Normal_STACK_Rem_Call_Struct = {
	-388, 4, 0, DeleteNodeInteractiveEntity__Normal_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Normal_STACK_Stack_Params
};
char * DescribeParam__Normal_Sigma_String_Params[] = {
	"Normal", "Sigma"
};

static CommandParameters DescribeParam__Normal_Sigma_Rem_Call_Struct = {
	-389, 5, 0, DescribeParam__Normal_Sigma_String_Params, 0, 0
};
char * DescribeParam__Normal_Mean_String_Params[] = {
	"Normal", "Mean"
};

static CommandParameters DescribeParam__Normal_Mean_Rem_Call_Struct = {
	-390, 5, 0, DescribeParam__Normal_Mean_String_Params, 0, 0
};
char * DescribeParam__Normal_ElementSize_String_Params[] = {
	"Normal", "ElementSize"
};

static CommandParameters DescribeParam__Normal_ElementSize_Rem_Call_Struct = {
	-391, 5, 0, DescribeParam__Normal_ElementSize_String_Params, 0, 0
};
char * DescribeParam__Normal_Seed_String_Params[] = {
	"Normal", "Seed"
};

static CommandParameters DescribeParam__Normal_Seed_Rem_Call_Struct = {
	-392, 5, 0, DescribeParam__Normal_Seed_String_Params, 0, 0
};
char * DescribeParamInstance__Normal_STACK_Sigma_String_Params[] = {
	"Normal", "Sigma"
};

int DescribeParamInstance__Normal_STACK_Sigma_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Normal_STACK_Sigma_Rem_Call_Struct = {
	-393, 6, 0, DescribeParamInstance__Normal_STACK_Sigma_String_Params, 0, 
	DescribeParamInstance__Normal_STACK_Sigma_Stack_Params
};
char * DescribeParamInstance__Normal_STACK_Mean_String_Params[] = {
	"Normal", "Mean"
};

int DescribeParamInstance__Normal_STACK_Mean_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Normal_STACK_Mean_Rem_Call_Struct = {
	-394, 6, 0, DescribeParamInstance__Normal_STACK_Mean_String_Params, 0, 
	DescribeParamInstance__Normal_STACK_Mean_Stack_Params
};
char * DescribeParamInstance__Normal_STACK_ElementSize_String_Params[] = {
	"Normal", "ElementSize"
};

int DescribeParamInstance__Normal_STACK_ElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Normal_STACK_ElementSize_Rem_Call_Struct = {
	-395, 6, 0, DescribeParamInstance__Normal_STACK_ElementSize_String_Params, 0, 
	DescribeParamInstance__Normal_STACK_ElementSize_Stack_Params
};
char * DescribeParamInstance__Normal_STACK_Seed_String_Params[] = {
	"Normal", "Seed"
};

int DescribeParamInstance__Normal_STACK_Seed_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Normal_STACK_Seed_Rem_Call_Struct = {
	-396, 6, 0, DescribeParamInstance__Normal_STACK_Seed_String_Params, 0, 
	DescribeParamInstance__Normal_STACK_Seed_Stack_Params
};
char * ExecuteSetParameter__Normal_STACK_Sigma_String_Params[] = {
	"Normal", "Sigma"
};

int ExecuteSetParameter__Normal_STACK_Sigma_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Normal_STACK_Sigma_Rem_Call_Struct = {
	-397, 6, 0, ExecuteSetParameter__Normal_STACK_Sigma_String_Params, 0, 
	ExecuteSetParameter__Normal_STACK_Sigma_Stack_Params
};
char * ExecuteSetParameter__Normal_STACK_Mean_String_Params[] = {
	"Normal", "Mean"
};

int ExecuteSetParameter__Normal_STACK_Mean_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Normal_STACK_Mean_Rem_Call_Struct = {
	-398, 6, 0, ExecuteSetParameter__Normal_STACK_Mean_String_Params, 0, 
	ExecuteSetParameter__Normal_STACK_Mean_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__OutputNode_String_Params[] = {
	"OutputNode"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__OutputNode_Rem_Call_Struct = {
	-399, 3, 0, CreateDefaultNodeInteractiveEntity__OutputNode_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__OutputNode_String_Params[] = {
	"OutputNode"
};

static CommandParameters CreateNodeInteractiveEntity__OutputNode_Rem_Call_Struct = {
	-400, 3, 0, CreateNodeInteractiveEntity__OutputNode_String_Params, 0, 0
};
char * DescribeNodeInstance__OutputNode_STACK_String_Params[] = {
	"OutputNode"
};

int DescribeNodeInstance__OutputNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__OutputNode_STACK_Rem_Call_Struct = {
	-401, 4, 0, DescribeNodeInstance__OutputNode_STACK_String_Params, 0, 
	DescribeNodeInstance__OutputNode_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__OutputNode_STACK_String_Params[] = {
	"OutputNode"
};

int DeleteNodeInteractiveEntity__OutputNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__OutputNode_STACK_Rem_Call_Struct = {
	-402, 4, 0, DeleteNodeInteractiveEntity__OutputNode_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__OutputNode_STACK_Stack_Params
};
char * DescribeParam__OutputNode_FileName_String_Params[] = {
	"OutputNode", "FileName"
};

static CommandParameters DescribeParam__OutputNode_FileName_Rem_Call_Struct = {
	-403, 5, 0, DescribeParam__OutputNode_FileName_String_Params, 0, 0
};
char * DescribeParam__OutputNode_Flags_String_Params[] = {
	"OutputNode", "Flags"
};

static CommandParameters DescribeParam__OutputNode_Flags_Rem_Call_Struct = {
	-404, 5, 0, DescribeParam__OutputNode_Flags_String_Params, 0, 0
};
char * DescribeParam__OutputNode_Channels_String_Params[] = {
	"OutputNode", "Channels"
};

static CommandParameters DescribeParam__OutputNode_Channels_Rem_Call_Struct = {
	-405, 5, 0, DescribeParam__OutputNode_Channels_String_Params, 0, 0
};
char * DescribeParam__OutputNode_FileBlockSize_String_Params[] = {
	"OutputNode", "FileBlockSize"
};

static CommandParameters DescribeParam__OutputNode_FileBlockSize_Rem_Call_Struct = {
	-406, 5, 0, DescribeParam__OutputNode_FileBlockSize_String_Params, 0, 0
};
char * DescribeParam__OutputNode_Caption_String_Params[] = {
	"OutputNode", "Caption"
};

static CommandParameters DescribeParam__OutputNode_Caption_Rem_Call_Struct = {
	-407, 5, 0, DescribeParam__OutputNode_Caption_String_Params, 0, 0
};
char * DescribeParam__OutputNode_DeltaIn_String_Params[] = {
	"OutputNode", "DeltaIn"
};

static CommandParameters DescribeParam__OutputNode_DeltaIn_Rem_Call_Struct = {
	-408, 5, 0, DescribeParam__OutputNode_DeltaIn_String_Params, 0, 0
};
char * DescribeParamInstance__OutputNode_STACK_FileName_String_Params[] = {
	"OutputNode", "FileName"
};

int DescribeParamInstance__OutputNode_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputNode_STACK_FileName_Rem_Call_Struct = {
	-409, 6, 0, DescribeParamInstance__OutputNode_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__OutputNode_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__OutputNode_STACK_Flags_String_Params[] = {
	"OutputNode", "Flags"
};

int DescribeParamInstance__OutputNode_STACK_Flags_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputNode_STACK_Flags_Rem_Call_Struct = {
	-410, 6, 0, DescribeParamInstance__OutputNode_STACK_Flags_String_Params, 0, 
	DescribeParamInstance__OutputNode_STACK_Flags_Stack_Params
};
char * DescribeParamInstance__OutputNode_STACK_Channels_String_Params[] = {
	"OutputNode", "Channels"
};

int DescribeParamInstance__OutputNode_STACK_Channels_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputNode_STACK_Channels_Rem_Call_Struct = {
	-411, 6, 0, DescribeParamInstance__OutputNode_STACK_Channels_String_Params, 0, 
	DescribeParamInstance__OutputNode_STACK_Channels_Stack_Params
};
char * DescribeParamInstance__OutputNode_STACK_FileBlockSize_String_Params[] = {
	"OutputNode", "FileBlockSize"
};

int DescribeParamInstance__OutputNode_STACK_FileBlockSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputNode_STACK_FileBlockSize_Rem_Call_Struct = {
	-412, 6, 0, DescribeParamInstance__OutputNode_STACK_FileBlockSize_String_Params, 
	0, DescribeParamInstance__OutputNode_STACK_FileBlockSize_Stack_Params
};
char * DescribeParamInstance__OutputNode_STACK_Caption_String_Params[] = {
	"OutputNode", "Caption"
};

int DescribeParamInstance__OutputNode_STACK_Caption_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputNode_STACK_Caption_Rem_Call_Struct = {
	-413, 6, 0, DescribeParamInstance__OutputNode_STACK_Caption_String_Params, 0, 
	DescribeParamInstance__OutputNode_STACK_Caption_Stack_Params
};
char * DescribeParamInstance__OutputNode_STACK_DeltaIn_String_Params[] = {
	"OutputNode", "DeltaIn"
};

int DescribeParamInstance__OutputNode_STACK_DeltaIn_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputNode_STACK_DeltaIn_Rem_Call_Struct = {
	-414, 6, 0, DescribeParamInstance__OutputNode_STACK_DeltaIn_String_Params, 0, 
	DescribeParamInstance__OutputNode_STACK_DeltaIn_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__OutputWord_String_Params[] = {
	"OutputWord"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__OutputWord_Rem_Call_Struct = {
	-415, 3, 0, CreateDefaultNodeInteractiveEntity__OutputWord_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__OutputWord_String_Params[] = {
	"OutputWord"
};

static CommandParameters CreateNodeInteractiveEntity__OutputWord_Rem_Call_Struct = {
	-416, 3, 0, CreateNodeInteractiveEntity__OutputWord_String_Params, 0, 0
};
char * DescribeNodeInstance__OutputWord_STACK_String_Params[] = {
	"OutputWord"
};

int DescribeNodeInstance__OutputWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__OutputWord_STACK_Rem_Call_Struct = {
	-417, 4, 0, DescribeNodeInstance__OutputWord_STACK_String_Params, 0, 
	DescribeNodeInstance__OutputWord_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__OutputWord_STACK_String_Params[] = {
	"OutputWord"
};

int DeleteNodeInteractiveEntity__OutputWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__OutputWord_STACK_Rem_Call_Struct = {
	-418, 4, 0, DeleteNodeInteractiveEntity__OutputWord_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__OutputWord_STACK_Stack_Params
};
char * DescribeParam__OutputWord_FileName_String_Params[] = {
	"OutputWord", "FileName"
};

static CommandParameters DescribeParam__OutputWord_FileName_Rem_Call_Struct = {
	-419, 5, 0, DescribeParam__OutputWord_FileName_String_Params, 0, 0
};
char * DescribeParam__OutputWord_FormatOut_String_Params[] = {
	"OutputWord", "FormatOut"
};

static CommandParameters DescribeParam__OutputWord_FormatOut_Rem_Call_Struct = {
	-420, 5, 0, DescribeParam__OutputWord_FormatOut_String_Params, 0, 0
};
char * DescribeParamInstance__OutputWord_STACK_FileName_String_Params[] = {
	"OutputWord", "FileName"
};

int DescribeParamInstance__OutputWord_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputWord_STACK_FileName_Rem_Call_Struct = {
	-421, 6, 0, DescribeParamInstance__OutputWord_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__OutputWord_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__OutputWord_STACK_FormatOut_String_Params[] = {
	"OutputWord", "FormatOut"
};

int DescribeParamInstance__OutputWord_STACK_FormatOut_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__OutputWord_STACK_FormatOut_Rem_Call_Struct = {
	-422, 6, 0, DescribeParamInstance__OutputWord_STACK_FormatOut_String_Params, 0, 
	DescribeParamInstance__OutputWord_STACK_FormatOut_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__PackWord_String_Params[] = {
	"PackWord"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__PackWord_Rem_Call_Struct = {
	-423, 3, 0, CreateDefaultNodeInteractiveEntity__PackWord_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__PackWord_String_Params[] = {
	"PackWord"
};

static CommandParameters CreateNodeInteractiveEntity__PackWord_Rem_Call_Struct = {
	-424, 3, 0, CreateNodeInteractiveEntity__PackWord_String_Params, 0, 0
};
char * DescribeNodeInstance__PackWord_STACK_String_Params[] = {
	"PackWord"
};

int DescribeNodeInstance__PackWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__PackWord_STACK_Rem_Call_Struct = {
	-425, 4, 0, DescribeNodeInstance__PackWord_STACK_String_Params, 0, 
	DescribeNodeInstance__PackWord_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__PackWord_STACK_String_Params[] = {
	"PackWord"
};

int DeleteNodeInteractiveEntity__PackWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__PackWord_STACK_Rem_Call_Struct = {
	-426, 4, 0, DeleteNodeInteractiveEntity__PackWord_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__PackWord_STACK_Stack_Params
};
char * DescribeParam__PackWord_InputWordSize_String_Params[] = {
	"PackWord", "InputWordSize"
};

static CommandParameters DescribeParam__PackWord_InputWordSize_Rem_Call_Struct = {
	-427, 5, 0, DescribeParam__PackWord_InputWordSize_String_Params, 0, 0
};
char * DescribeParam__PackWord_InputsPerOutput_String_Params[] = {
	"PackWord", "InputsPerOutput"
};

static CommandParameters DescribeParam__PackWord_InputsPerOutput_Rem_Call_Struct = {
	-428, 5, 0, DescribeParam__PackWord_InputsPerOutput_String_Params, 0, 0
};
char * DescribeParamInstance__PackWord_STACK_InputWordSize_String_Params[] = {
	"PackWord", "InputWordSize"
};

int DescribeParamInstance__PackWord_STACK_InputWordSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__PackWord_STACK_InputWordSize_Rem_Call_Struct = {
	-429, 6, 0, DescribeParamInstance__PackWord_STACK_InputWordSize_String_Params, 0, 
	DescribeParamInstance__PackWord_STACK_InputWordSize_Stack_Params
};
char * DescribeParamInstance__PackWord_STACK_InputsPerOutput_String_Params[] = {
	"PackWord", "InputsPerOutput"
};

int DescribeParamInstance__PackWord_STACK_InputsPerOutput_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__PackWord_STACK_InputsPerOutput_Rem_Call_Struct = {
	-430, 6, 0, DescribeParamInstance__PackWord_STACK_InputsPerOutput_String_Params, 
	0, DescribeParamInstance__PackWord_STACK_InputsPerOutput_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Plot_String_Params[] = {
	"Plot"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Plot_Rem_Call_Struct = {
	-431, 3, 0, CreateDefaultNodeInteractiveEntity__Plot_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Plot_String_Params[] = {
	"Plot"
};

static CommandParameters CreateNodeInteractiveEntity__Plot_Rem_Call_Struct = {
	-432, 3, 0, CreateNodeInteractiveEntity__Plot_String_Params, 0, 0
};
char * DescribeNodeInstance__Plot_STACK_String_Params[] = {
	"Plot"
};

int DescribeNodeInstance__Plot_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Plot_STACK_Rem_Call_Struct = {
	-433, 4, 0, DescribeNodeInstance__Plot_STACK_String_Params, 0, 
	DescribeNodeInstance__Plot_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Plot_STACK_String_Params[] = {
	"Plot"
};

int DeleteNodeInteractiveEntity__Plot_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Plot_STACK_Rem_Call_Struct = {
	-434, 4, 0, DeleteNodeInteractiveEntity__Plot_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Plot_STACK_Stack_Params
};
char * DescribeParam__Plot_Caption_String_Params[] = {
	"Plot", "Caption"
};

static CommandParameters DescribeParam__Plot_Caption_Rem_Call_Struct = {
	-435, 5, 0, DescribeParam__Plot_Caption_String_Params, 0, 0
};
char * DescribeParamInstance__Plot_STACK_Caption_String_Params[] = {
	"Plot", "Caption"
};

int DescribeParamInstance__Plot_STACK_Caption_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Plot_STACK_Caption_Rem_Call_Struct = {
	-436, 6, 0, DescribeParamInstance__Plot_STACK_Caption_String_Params, 0, 
	DescribeParamInstance__Plot_STACK_Caption_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Power_String_Params[] = {
	"Power"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Power_Rem_Call_Struct = {
	-437, 3, 0, CreateDefaultNodeInteractiveEntity__Power_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Power_String_Params[] = {
	"Power"
};

static CommandParameters CreateNodeInteractiveEntity__Power_Rem_Call_Struct = {
	-438, 3, 0, CreateNodeInteractiveEntity__Power_String_Params, 0, 0
};
char * DescribeNodeInstance__Power_STACK_String_Params[] = {
	"Power"
};

int DescribeNodeInstance__Power_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Power_STACK_Rem_Call_Struct = {
	-439, 4, 0, DescribeNodeInstance__Power_STACK_String_Params, 0, 
	DescribeNodeInstance__Power_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Power_STACK_String_Params[] = {
	"Power"
};

int DeleteNodeInteractiveEntity__Power_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Power_STACK_Rem_Call_Struct = {
	-440, 4, 0, DeleteNodeInteractiveEntity__Power_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Power_STACK_Stack_Params
};
char * DescribeParam__Power_Amplitude_String_Params[] = {
	"Power", "Amplitude"
};

static CommandParameters DescribeParam__Power_Amplitude_Rem_Call_Struct = {
	-441, 5, 0, DescribeParam__Power_Amplitude_String_Params, 0, 0
};
char * DescribeParam__Power_Scale_String_Params[] = {
	"Power", "Scale"
};

static CommandParameters DescribeParam__Power_Scale_Rem_Call_Struct = {
	-442, 5, 0, DescribeParam__Power_Scale_String_Params, 0, 0
};
char * DescribeParamInstance__Power_STACK_Amplitude_String_Params[] = {
	"Power", "Amplitude"
};

int DescribeParamInstance__Power_STACK_Amplitude_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Power_STACK_Amplitude_Rem_Call_Struct = {
	-443, 6, 0, DescribeParamInstance__Power_STACK_Amplitude_String_Params, 0, 
	DescribeParamInstance__Power_STACK_Amplitude_Stack_Params
};
char * DescribeParamInstance__Power_STACK_Scale_String_Params[] = {
	"Power", "Scale"
};

int DescribeParamInstance__Power_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Power_STACK_Scale_Rem_Call_Struct = {
	-444, 6, 0, DescribeParamInstance__Power_STACK_Scale_String_Params, 0, 
	DescribeParamInstance__Power_STACK_Scale_Stack_Params
};
char * ExecuteSetParameter__Power_STACK_Scale_String_Params[] = {
	"Power", "Scale"
};

int ExecuteSetParameter__Power_STACK_Scale_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Power_STACK_Scale_Rem_Call_Struct = {
	-445, 6, 0, ExecuteSetParameter__Power_STACK_Scale_String_Params, 0, 
	ExecuteSetParameter__Power_STACK_Scale_Stack_Params
};
char * MemberFunctionDescribe__ProcessNodeStr_STACK_String_Params[] = {
	"ProcessNodeStr"
};

int MemberFunctionDescribe__ProcessNodeStr_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__ProcessNodeStr_STACK_Rem_Call_Struct = {
	-446, 4, 0, MemberFunctionDescribe__ProcessNodeStr_STACK_String_Params, 0, 
	MemberFunctionDescribe__ProcessNodeStr_STACK_Stack_Params
};
char * DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Rate_String_Params[] = {
	"ProcessNodeStr", "Rate"
};

int DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Rate_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Rate_Rem_Call_Struct = {
	-447, 6, 0, 
	DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Rate_String_Params, 0, 
	DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Rate_Stack_Params
};
char * DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Channel_String_Params[] = {
	"ProcessNodeStr", "Channel"
};

int DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Channel_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Channel_Rem_Call_Struct = {
	-448, 6, 0, 
	DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Channel_String_Params, 0, 
	DescribeMemberFunctionParameter__ProcessNodeStr_STACK_Channel_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_SetSampleRate_String_Params[] = {
	"SetSampleRate"
};

int ExecuteMemberFunction__STACK_STACK_SetSampleRate_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_SetSampleRate_Rem_Call_Struct = {
	-449, 7, 0, ExecuteMemberFunction__STACK_STACK_SetSampleRate_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_SetSampleRate_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_DisplayOutputTiming_String_Params[] = {
	"DisplayOutputTiming"
};

int ExecuteMemberFunction__STACK_STACK_DisplayOutputTiming_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_DisplayOutputTiming_Rem_Call_Struct = {
	-450, 7, 0, ExecuteMemberFunction__STACK_STACK_DisplayOutputTiming_String_Params, 
	0, ExecuteMemberFunction__STACK_STACK_DisplayOutputTiming_Stack_Params
};
char * ExecuteMemberFunction__STACK_STACK_NextFreeOutput_String_Params[] = {
	"NextFreeOutput"
};

int ExecuteMemberFunction__STACK_STACK_NextFreeOutput_Stack_Params[] = {
	4, 2
};

static CommandParameters ExecuteMemberFunction__STACK_STACK_NextFreeOutput_Rem_Call_Struct = {
	-451, 7, 0, ExecuteMemberFunction__STACK_STACK_NextFreeOutput_String_Params, 0, 
	ExecuteMemberFunction__STACK_STACK_NextFreeOutput_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Ramp_String_Params[] = {
	"Ramp"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Ramp_Rem_Call_Struct = {
	-452, 3, 0, CreateDefaultNodeInteractiveEntity__Ramp_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Ramp_String_Params[] = {
	"Ramp"
};

static CommandParameters CreateNodeInteractiveEntity__Ramp_Rem_Call_Struct = {
	-453, 3, 0, CreateNodeInteractiveEntity__Ramp_String_Params, 0, 0
};
char * DescribeNodeInstance__Ramp_STACK_String_Params[] = {
	"Ramp"
};

int DescribeNodeInstance__Ramp_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Ramp_STACK_Rem_Call_Struct = {
	-454, 4, 0, DescribeNodeInstance__Ramp_STACK_String_Params, 0, 
	DescribeNodeInstance__Ramp_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Ramp_STACK_String_Params[] = {
	"Ramp"
};

int DeleteNodeInteractiveEntity__Ramp_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Ramp_STACK_Rem_Call_Struct = {
	-455, 4, 0, DeleteNodeInteractiveEntity__Ramp_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Ramp_STACK_Stack_Params
};
char * DescribeParam__Ramp_Min_String_Params[] = {
	"Ramp", "Min"
};

static CommandParameters DescribeParam__Ramp_Min_Rem_Call_Struct = {
	-456, 5, 0, DescribeParam__Ramp_Min_String_Params, 0, 0
};
char * DescribeParam__Ramp_Max_String_Params[] = {
	"Ramp", "Max"
};

static CommandParameters DescribeParam__Ramp_Max_Rem_Call_Struct = {
	-457, 5, 0, DescribeParam__Ramp_Max_String_Params, 0, 0
};
char * DescribeParam__Ramp_Increment_String_Params[] = {
	"Ramp", "Increment"
};

static CommandParameters DescribeParam__Ramp_Increment_Rem_Call_Struct = {
	-458, 5, 0, DescribeParam__Ramp_Increment_String_Params, 0, 0
};
char * DescribeParamInstance__Ramp_STACK_Min_String_Params[] = {
	"Ramp", "Min"
};

int DescribeParamInstance__Ramp_STACK_Min_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Ramp_STACK_Min_Rem_Call_Struct = {
	-459, 6, 0, DescribeParamInstance__Ramp_STACK_Min_String_Params, 0, 
	DescribeParamInstance__Ramp_STACK_Min_Stack_Params
};
char * DescribeParamInstance__Ramp_STACK_Max_String_Params[] = {
	"Ramp", "Max"
};

int DescribeParamInstance__Ramp_STACK_Max_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Ramp_STACK_Max_Rem_Call_Struct = {
	-460, 6, 0, DescribeParamInstance__Ramp_STACK_Max_String_Params, 0, 
	DescribeParamInstance__Ramp_STACK_Max_Stack_Params
};
char * DescribeParamInstance__Ramp_STACK_Increment_String_Params[] = {
	"Ramp", "Increment"
};

int DescribeParamInstance__Ramp_STACK_Increment_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Ramp_STACK_Increment_Rem_Call_Struct = {
	-461, 6, 0, DescribeParamInstance__Ramp_STACK_Increment_String_Params, 0, 
	DescribeParamInstance__Ramp_STACK_Increment_Stack_Params
};
char * ExecuteSetParameter__Ramp_STACK_Min_String_Params[] = {
	"Ramp", "Min"
};

int ExecuteSetParameter__Ramp_STACK_Min_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Ramp_STACK_Min_Rem_Call_Struct = {
	-462, 6, 0, ExecuteSetParameter__Ramp_STACK_Min_String_Params, 0, 
	ExecuteSetParameter__Ramp_STACK_Min_Stack_Params
};
char * ExecuteSetParameter__Ramp_STACK_Max_String_Params[] = {
	"Ramp", "Max"
};

int ExecuteSetParameter__Ramp_STACK_Max_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Ramp_STACK_Max_Rem_Call_Struct = {
	-463, 6, 0, ExecuteSetParameter__Ramp_STACK_Max_String_Params, 0, 
	ExecuteSetParameter__Ramp_STACK_Max_Stack_Params
};
char * ExecuteSetParameter__Ramp_STACK_Increment_String_Params[] = {
	"Ramp", "Increment"
};

int ExecuteSetParameter__Ramp_STACK_Increment_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Ramp_STACK_Increment_Rem_Call_Struct = {
	-464, 6, 0, ExecuteSetParameter__Ramp_STACK_Increment_String_Params, 0, 
	ExecuteSetParameter__Ramp_STACK_Increment_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__ReadFloat_String_Params[] = {
	"ReadFloat"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ReadFloat_Rem_Call_Struct = {
	-465, 3, 0, CreateDefaultNodeInteractiveEntity__ReadFloat_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ReadFloat_String_Params[] = {
	"ReadFloat"
};

static CommandParameters CreateNodeInteractiveEntity__ReadFloat_Rem_Call_Struct = {
	-466, 3, 0, CreateNodeInteractiveEntity__ReadFloat_String_Params, 0, 0
};
char * DescribeNodeInstance__ReadFloat_STACK_String_Params[] = {
	"ReadFloat"
};

int DescribeNodeInstance__ReadFloat_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ReadFloat_STACK_Rem_Call_Struct = {
	-467, 4, 0, DescribeNodeInstance__ReadFloat_STACK_String_Params, 0, 
	DescribeNodeInstance__ReadFloat_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ReadFloat_STACK_String_Params[] = {
	"ReadFloat"
};

int DeleteNodeInteractiveEntity__ReadFloat_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ReadFloat_STACK_Rem_Call_Struct = {
	-468, 4, 0, DeleteNodeInteractiveEntity__ReadFloat_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ReadFloat_STACK_Stack_Params
};
char * DescribeParam__ReadFloat_FileName_String_Params[] = {
	"ReadFloat", "FileName"
};

static CommandParameters DescribeParam__ReadFloat_FileName_Rem_Call_Struct = {
	-469, 5, 0, DescribeParam__ReadFloat_FileName_String_Params, 0, 0
};
char * DescribeParamInstance__ReadFloat_STACK_FileName_String_Params[] = {
	"ReadFloat", "FileName"
};

int DescribeParamInstance__ReadFloat_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ReadFloat_STACK_FileName_Rem_Call_Struct = {
	-470, 6, 0, DescribeParamInstance__ReadFloat_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__ReadFloat_STACK_FileName_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__ReadInt_String_Params[] = {
	"ReadInt"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ReadInt_Rem_Call_Struct = {
	-471, 3, 0, CreateDefaultNodeInteractiveEntity__ReadInt_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ReadInt_String_Params[] = {
	"ReadInt"
};

static CommandParameters CreateNodeInteractiveEntity__ReadInt_Rem_Call_Struct = {
	-472, 3, 0, CreateNodeInteractiveEntity__ReadInt_String_Params, 0, 0
};
char * DescribeNodeInstance__ReadInt_STACK_String_Params[] = {
	"ReadInt"
};

int DescribeNodeInstance__ReadInt_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ReadInt_STACK_Rem_Call_Struct = {
	-473, 4, 0, DescribeNodeInstance__ReadInt_STACK_String_Params, 0, 
	DescribeNodeInstance__ReadInt_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ReadInt_STACK_String_Params[] = {
	"ReadInt"
};

int DeleteNodeInteractiveEntity__ReadInt_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ReadInt_STACK_Rem_Call_Struct = {
	-474, 4, 0, DeleteNodeInteractiveEntity__ReadInt_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ReadInt_STACK_Stack_Params
};
char * DescribeParam__ReadInt_FileName_String_Params[] = {
	"ReadInt", "FileName"
};

static CommandParameters DescribeParam__ReadInt_FileName_Rem_Call_Struct = {
	-475, 5, 0, DescribeParam__ReadInt_FileName_String_Params, 0, 0
};
char * DescribeParam__ReadInt_Flags_String_Params[] = {
	"ReadInt", "Flags"
};

static CommandParameters DescribeParam__ReadInt_Flags_Rem_Call_Struct = {
	-476, 5, 0, DescribeParam__ReadInt_Flags_String_Params, 0, 0
};
char * DescribeParamInstance__ReadInt_STACK_FileName_String_Params[] = {
	"ReadInt", "FileName"
};

int DescribeParamInstance__ReadInt_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ReadInt_STACK_FileName_Rem_Call_Struct = {
	-477, 6, 0, DescribeParamInstance__ReadInt_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__ReadInt_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__ReadInt_STACK_Flags_String_Params[] = {
	"ReadInt", "Flags"
};

int DescribeParamInstance__ReadInt_STACK_Flags_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ReadInt_STACK_Flags_Rem_Call_Struct = {
	-478, 6, 0, DescribeParamInstance__ReadInt_STACK_Flags_String_Params, 0, 
	DescribeParamInstance__ReadInt_STACK_Flags_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__RealFir_String_Params[] = {
	"RealFir"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__RealFir_Rem_Call_Struct = {
	-479, 3, 0, CreateDefaultNodeInteractiveEntity__RealFir_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__RealFir_String_Params[] = {
	"RealFir"
};

static CommandParameters CreateNodeInteractiveEntity__RealFir_Rem_Call_Struct = {
	-480, 3, 0, CreateNodeInteractiveEntity__RealFir_String_Params, 0, 0
};
char * DescribeNodeInstance__RealFir_STACK_String_Params[] = {
	"RealFir"
};

int DescribeNodeInstance__RealFir_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__RealFir_STACK_Rem_Call_Struct = {
	-481, 4, 0, DescribeNodeInstance__RealFir_STACK_String_Params, 0, 
	DescribeNodeInstance__RealFir_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__RealFir_STACK_String_Params[] = {
	"RealFir"
};

int DeleteNodeInteractiveEntity__RealFir_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__RealFir_STACK_Rem_Call_Struct = {
	-482, 4, 0, DeleteNodeInteractiveEntity__RealFir_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__RealFir_STACK_Stack_Params
};
char * DescribeParam__RealFir_Resample_String_Params[] = {
	"RealFir", "Resample"
};

static CommandParameters DescribeParam__RealFir_Resample_Rem_Call_Struct = {
	-483, 5, 0, DescribeParam__RealFir_Resample_String_Params, 0, 0
};
char * DescribeParam__RealFir_ZeroPad_String_Params[] = {
	"RealFir", "ZeroPad"
};

static CommandParameters DescribeParam__RealFir_ZeroPad_Rem_Call_Struct = {
	-484, 5, 0, DescribeParam__RealFir_ZeroPad_String_Params, 0, 0
};
char * DescribeParam__RealFir_Odd_String_Params[] = {
	"RealFir", "Odd"
};

static CommandParameters DescribeParam__RealFir_Odd_Rem_Call_Struct = {
	-485, 5, 0, DescribeParam__RealFir_Odd_String_Params, 0, 0
};
char * DescribeParam__RealFir_Coeff_String_Params[] = {
	"RealFir", "Coeff"
};

static CommandParameters DescribeParam__RealFir_Coeff_Rem_Call_Struct = {
	-486, 5, 0, DescribeParam__RealFir_Coeff_String_Params, 0, 0
};
char * DescribeParamInstance__RealFir_STACK_Resample_String_Params[] = {
	"RealFir", "Resample"
};

int DescribeParamInstance__RealFir_STACK_Resample_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__RealFir_STACK_Resample_Rem_Call_Struct = {
	-487, 6, 0, DescribeParamInstance__RealFir_STACK_Resample_String_Params, 0, 
	DescribeParamInstance__RealFir_STACK_Resample_Stack_Params
};
char * DescribeParamInstance__RealFir_STACK_ZeroPad_String_Params[] = {
	"RealFir", "ZeroPad"
};

int DescribeParamInstance__RealFir_STACK_ZeroPad_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__RealFir_STACK_ZeroPad_Rem_Call_Struct = {
	-488, 6, 0, DescribeParamInstance__RealFir_STACK_ZeroPad_String_Params, 0, 
	DescribeParamInstance__RealFir_STACK_ZeroPad_Stack_Params
};
char * DescribeParamInstance__RealFir_STACK_Odd_String_Params[] = {
	"RealFir", "Odd"
};

int DescribeParamInstance__RealFir_STACK_Odd_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__RealFir_STACK_Odd_Rem_Call_Struct = {
	-489, 6, 0, DescribeParamInstance__RealFir_STACK_Odd_String_Params, 0, 
	DescribeParamInstance__RealFir_STACK_Odd_Stack_Params
};
char * DescribeParamInstance__RealFir_STACK_Coeff_String_Params[] = {
	"RealFir", "Coeff"
};

int DescribeParamInstance__RealFir_STACK_Coeff_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__RealFir_STACK_Coeff_Rem_Call_Struct = {
	-490, 6, 0, DescribeParamInstance__RealFir_STACK_Coeff_String_Params, 0, 
	DescribeParamInstance__RealFir_STACK_Coeff_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__RepackStream_String_Params[] = {
	"RepackStream"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__RepackStream_Rem_Call_Struct = {
	-491, 3, 0, CreateDefaultNodeInteractiveEntity__RepackStream_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__RepackStream_String_Params[] = {
	"RepackStream"
};

static CommandParameters CreateNodeInteractiveEntity__RepackStream_Rem_Call_Struct = {
	-492, 3, 0, CreateNodeInteractiveEntity__RepackStream_String_Params, 0, 0
};
char * DescribeNodeInstance__RepackStream_STACK_String_Params[] = {
	"RepackStream"
};

int DescribeNodeInstance__RepackStream_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__RepackStream_STACK_Rem_Call_Struct = {
	-493, 4, 0, DescribeNodeInstance__RepackStream_STACK_String_Params, 0, 
	DescribeNodeInstance__RepackStream_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__RepackStream_STACK_String_Params[] = {
	"RepackStream"
};

int DeleteNodeInteractiveEntity__RepackStream_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__RepackStream_STACK_Rem_Call_Struct = {
	-494, 4, 0, DeleteNodeInteractiveEntity__RepackStream_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__RepackStream_STACK_Stack_Params
};
char * DescribeParam__RepackStream_OutputWordSize_String_Params[] = {
	"RepackStream", "OutputWordSize"
};

static CommandParameters DescribeParam__RepackStream_OutputWordSize_Rem_Call_Struct = {
	-495, 5, 0, DescribeParam__RepackStream_OutputWordSize_String_Params, 0, 0
};
char * DescribeParam__RepackStream_InputWordSize_String_Params[] = {
	"RepackStream", "InputWordSize"
};

static CommandParameters DescribeParam__RepackStream_InputWordSize_Rem_Call_Struct = {
	-496, 5, 0, DescribeParam__RepackStream_InputWordSize_String_Params, 0, 0
};
char * DescribeParam__RepackStream_SignedOutput_String_Params[] = {
	"RepackStream", "SignedOutput"
};

static CommandParameters DescribeParam__RepackStream_SignedOutput_Rem_Call_Struct = {
	-497, 5, 0, DescribeParam__RepackStream_SignedOutput_String_Params, 0, 0
};
char * DescribeParamInstance__RepackStream_STACK_OutputWordSize_String_Params[] = {
	"RepackStream", "OutputWordSize"
};

int DescribeParamInstance__RepackStream_STACK_OutputWordSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__RepackStream_STACK_OutputWordSize_Rem_Call_Struct = {
	-498, 6, 0, 
	DescribeParamInstance__RepackStream_STACK_OutputWordSize_String_Params, 0, 
	DescribeParamInstance__RepackStream_STACK_OutputWordSize_Stack_Params
};
char * DescribeParamInstance__RepackStream_STACK_InputWordSize_String_Params[] = {
	"RepackStream", "InputWordSize"
};

int DescribeParamInstance__RepackStream_STACK_InputWordSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__RepackStream_STACK_InputWordSize_Rem_Call_Struct = {
	-499, 6, 0, 
	DescribeParamInstance__RepackStream_STACK_InputWordSize_String_Params, 0, 
	DescribeParamInstance__RepackStream_STACK_InputWordSize_Stack_Params
};
char * DescribeParamInstance__RepackStream_STACK_SignedOutput_String_Params[] = {
	"RepackStream", "SignedOutput"
};

int DescribeParamInstance__RepackStream_STACK_SignedOutput_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__RepackStream_STACK_SignedOutput_Rem_Call_Struct = {
	-500, 6, 0, DescribeParamInstance__RepackStream_STACK_SignedOutput_String_Params, 
	0, DescribeParamInstance__RepackStream_STACK_SignedOutput_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__SampleDelay_String_Params[] = {
	"SampleDelay"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__SampleDelay_Rem_Call_Struct = {
	-501, 3, 0, CreateDefaultNodeInteractiveEntity__SampleDelay_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__SampleDelay_String_Params[] = {
	"SampleDelay"
};

static CommandParameters CreateNodeInteractiveEntity__SampleDelay_Rem_Call_Struct = {
	-502, 3, 0, CreateNodeInteractiveEntity__SampleDelay_String_Params, 0, 0
};
char * DescribeNodeInstance__SampleDelay_STACK_String_Params[] = {
	"SampleDelay"
};

int DescribeNodeInstance__SampleDelay_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__SampleDelay_STACK_Rem_Call_Struct = {
	-503, 4, 0, DescribeNodeInstance__SampleDelay_STACK_String_Params, 0, 
	DescribeNodeInstance__SampleDelay_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__SampleDelay_STACK_String_Params[] = {
	"SampleDelay"
};

int DeleteNodeInteractiveEntity__SampleDelay_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__SampleDelay_STACK_Rem_Call_Struct = {
	-504, 4, 0, DeleteNodeInteractiveEntity__SampleDelay_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__SampleDelay_STACK_Stack_Params
};
char * DescribeParam__SampleDelay_Delta_String_Params[] = {
	"SampleDelay", "Delta"
};

static CommandParameters DescribeParam__SampleDelay_Delta_Rem_Call_Struct = {
	-505, 5, 0, DescribeParam__SampleDelay_Delta_String_Params, 0, 0
};
char * DescribeParam__SampleDelay_FillValue_String_Params[] = {
	"SampleDelay", "FillValue"
};

static CommandParameters DescribeParam__SampleDelay_FillValue_Rem_Call_Struct = {
	-506, 5, 0, DescribeParam__SampleDelay_FillValue_String_Params, 0, 0
};
char * DescribeParamInstance__SampleDelay_STACK_Delta_String_Params[] = {
	"SampleDelay", "Delta"
};

int DescribeParamInstance__SampleDelay_STACK_Delta_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__SampleDelay_STACK_Delta_Rem_Call_Struct = {
	-507, 6, 0, DescribeParamInstance__SampleDelay_STACK_Delta_String_Params, 0, 
	DescribeParamInstance__SampleDelay_STACK_Delta_Stack_Params
};
char * DescribeParamInstance__SampleDelay_STACK_FillValue_String_Params[] = {
	"SampleDelay", "FillValue"
};

int DescribeParamInstance__SampleDelay_STACK_FillValue_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__SampleDelay_STACK_FillValue_Rem_Call_Struct = {
	-508, 6, 0, DescribeParamInstance__SampleDelay_STACK_FillValue_String_Params, 0, 
	DescribeParamInstance__SampleDelay_STACK_FillValue_Stack_Params
};
char * MemberFunctionDescribe__SignalStr_STACK_String_Params[] = {
	"SignalStr"
};

int MemberFunctionDescribe__SignalStr_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__SignalStr_STACK_Rem_Call_Struct = {
	-509, 4, 0, MemberFunctionDescribe__SignalStr_STACK_String_Params, 0, 
	MemberFunctionDescribe__SignalStr_STACK_Stack_Params
};
char * DescribeMemberFunctionParameter__SignalStr_STACK_Rate_String_Params[] = {
	"SignalStr", "Rate"
};

int DescribeMemberFunctionParameter__SignalStr_STACK_Rate_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__SignalStr_STACK_Rate_Rem_Call_Struct = {
	-510, 6, 0, DescribeMemberFunctionParameter__SignalStr_STACK_Rate_String_Params, 
	0, DescribeMemberFunctionParameter__SignalStr_STACK_Rate_Stack_Params
};
char * DescribeMemberFunctionParameter__SignalStr_STACK_Channel_String_Params[] = {
	"SignalStr", "Channel"
};

int DescribeMemberFunctionParameter__SignalStr_STACK_Channel_Stack_Params[] = {
	2
};

static CommandParameters DescribeMemberFunctionParameter__SignalStr_STACK_Channel_Rem_Call_Struct = {
	-511, 6, 0, 
	DescribeMemberFunctionParameter__SignalStr_STACK_Channel_String_Params, 0, 
	DescribeMemberFunctionParameter__SignalStr_STACK_Channel_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__ToInteger_String_Params[] = {
	"ToInteger"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ToInteger_Rem_Call_Struct = {
	-512, 3, 0, CreateDefaultNodeInteractiveEntity__ToInteger_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ToInteger_String_Params[] = {
	"ToInteger"
};

static CommandParameters CreateNodeInteractiveEntity__ToInteger_Rem_Call_Struct = {
	-513, 3, 0, CreateNodeInteractiveEntity__ToInteger_String_Params, 0, 0
};
char * DescribeNodeInstance__ToInteger_STACK_String_Params[] = {
	"ToInteger"
};

int DescribeNodeInstance__ToInteger_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ToInteger_STACK_Rem_Call_Struct = {
	-514, 4, 0, DescribeNodeInstance__ToInteger_STACK_String_Params, 0, 
	DescribeNodeInstance__ToInteger_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ToInteger_STACK_String_Params[] = {
	"ToInteger"
};

int DeleteNodeInteractiveEntity__ToInteger_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ToInteger_STACK_Rem_Call_Struct = {
	-515, 4, 0, DeleteNodeInteractiveEntity__ToInteger_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ToInteger_STACK_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__ToMach_String_Params[] = {
	"ToMach"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ToMach_Rem_Call_Struct = {
	-516, 3, 0, CreateDefaultNodeInteractiveEntity__ToMach_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ToMach_String_Params[] = {
	"ToMach"
};

static CommandParameters CreateNodeInteractiveEntity__ToMach_Rem_Call_Struct = {
	-517, 3, 0, CreateNodeInteractiveEntity__ToMach_String_Params, 0, 0
};
char * DescribeNodeInstance__ToMach_STACK_String_Params[] = {
	"ToMach"
};

int DescribeNodeInstance__ToMach_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ToMach_STACK_Rem_Call_Struct = {
	-518, 4, 0, DescribeNodeInstance__ToMach_STACK_String_Params, 0, 
	DescribeNodeInstance__ToMach_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ToMach_STACK_String_Params[] = {
	"ToMach"
};

int DeleteNodeInteractiveEntity__ToMach_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ToMach_STACK_Rem_Call_Struct = {
	-519, 4, 0, DeleteNodeInteractiveEntity__ToMach_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ToMach_STACK_Stack_Params
};
char * DescribeParam__ToMach_SignedConversion_String_Params[] = {
	"ToMach", "SignedConversion"
};

static CommandParameters DescribeParam__ToMach_SignedConversion_Rem_Call_Struct = {
	-520, 5, 0, DescribeParam__ToMach_SignedConversion_String_Params, 0, 0
};
char * DescribeParamInstance__ToMach_STACK_SignedConversion_String_Params[] = {
	"ToMach", "SignedConversion"
};

int DescribeParamInstance__ToMach_STACK_SignedConversion_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ToMach_STACK_SignedConversion_Rem_Call_Struct = {
	-521, 6, 0, DescribeParamInstance__ToMach_STACK_SignedConversion_String_Params, 
	0, DescribeParamInstance__ToMach_STACK_SignedConversion_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__Truncate_String_Params[] = {
	"Truncate"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__Truncate_Rem_Call_Struct = {
	-522, 3, 0, CreateDefaultNodeInteractiveEntity__Truncate_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__Truncate_String_Params[] = {
	"Truncate"
};

static CommandParameters CreateNodeInteractiveEntity__Truncate_Rem_Call_Struct = {
	-523, 3, 0, CreateNodeInteractiveEntity__Truncate_String_Params, 0, 0
};
char * DescribeNodeInstance__Truncate_STACK_String_Params[] = {
	"Truncate"
};

int DescribeNodeInstance__Truncate_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__Truncate_STACK_Rem_Call_Struct = {
	-524, 4, 0, DescribeNodeInstance__Truncate_STACK_String_Params, 0, 
	DescribeNodeInstance__Truncate_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__Truncate_STACK_String_Params[] = {
	"Truncate"
};

int DeleteNodeInteractiveEntity__Truncate_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__Truncate_STACK_Rem_Call_Struct = {
	-525, 4, 0, DeleteNodeInteractiveEntity__Truncate_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__Truncate_STACK_Stack_Params
};
char * DescribeParam__Truncate_Range_String_Params[] = {
	"Truncate", "Range"
};

static CommandParameters DescribeParam__Truncate_Range_Rem_Call_Struct = {
	-526, 5, 0, DescribeParam__Truncate_Range_String_Params, 0, 0
};
char * DescribeParam__Truncate_Accuracy_String_Params[] = {
	"Truncate", "Accuracy"
};

static CommandParameters DescribeParam__Truncate_Accuracy_Rem_Call_Struct = {
	-527, 5, 0, DescribeParam__Truncate_Accuracy_String_Params, 0, 0
};
char * DescribeParam__Truncate_OverflowMode_String_Params[] = {
	"Truncate", "OverflowMode"
};

static CommandParameters DescribeParam__Truncate_OverflowMode_Rem_Call_Struct = {
	-528, 5, 0, DescribeParam__Truncate_OverflowMode_String_Params, 0, 0
};
char * DescribeParam__Truncate_Round_String_Params[] = {
	"Truncate", "Round"
};

static CommandParameters DescribeParam__Truncate_Round_Rem_Call_Struct = {
	-529, 5, 0, DescribeParam__Truncate_Round_String_Params, 0, 0
};
char * DescribeParamInstance__Truncate_STACK_Range_String_Params[] = {
	"Truncate", "Range"
};

int DescribeParamInstance__Truncate_STACK_Range_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Truncate_STACK_Range_Rem_Call_Struct = {
	-530, 6, 0, DescribeParamInstance__Truncate_STACK_Range_String_Params, 0, 
	DescribeParamInstance__Truncate_STACK_Range_Stack_Params
};
char * DescribeParamInstance__Truncate_STACK_Accuracy_String_Params[] = {
	"Truncate", "Accuracy"
};

int DescribeParamInstance__Truncate_STACK_Accuracy_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Truncate_STACK_Accuracy_Rem_Call_Struct = {
	-531, 6, 0, DescribeParamInstance__Truncate_STACK_Accuracy_String_Params, 0, 
	DescribeParamInstance__Truncate_STACK_Accuracy_Stack_Params
};
char * DescribeParamInstance__Truncate_STACK_OverflowMode_String_Params[] = {
	"Truncate", "OverflowMode"
};

int DescribeParamInstance__Truncate_STACK_OverflowMode_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Truncate_STACK_OverflowMode_Rem_Call_Struct = {
	-532, 6, 0, DescribeParamInstance__Truncate_STACK_OverflowMode_String_Params, 0, 
	DescribeParamInstance__Truncate_STACK_OverflowMode_Stack_Params
};
char * DescribeParamInstance__Truncate_STACK_Round_String_Params[] = {
	"Truncate", "Round"
};

int DescribeParamInstance__Truncate_STACK_Round_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__Truncate_STACK_Round_Rem_Call_Struct = {
	-533, 6, 0, DescribeParamInstance__Truncate_STACK_Round_String_Params, 0, 
	DescribeParamInstance__Truncate_STACK_Round_Stack_Params
};
char * ExecuteSetParameter__Truncate_STACK_Range_String_Params[] = {
	"Truncate", "Range"
};

int ExecuteSetParameter__Truncate_STACK_Range_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Truncate_STACK_Range_Rem_Call_Struct = {
	-534, 6, 0, ExecuteSetParameter__Truncate_STACK_Range_String_Params, 0, 
	ExecuteSetParameter__Truncate_STACK_Range_Stack_Params
};
char * ExecuteSetParameter__Truncate_STACK_Accuracy_String_Params[] = {
	"Truncate", "Accuracy"
};

int ExecuteSetParameter__Truncate_STACK_Accuracy_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Truncate_STACK_Accuracy_Rem_Call_Struct = {
	-535, 6, 0, ExecuteSetParameter__Truncate_STACK_Accuracy_String_Params, 0, 
	ExecuteSetParameter__Truncate_STACK_Accuracy_Stack_Params
};
char * ExecuteSetParameter__Truncate_STACK_OverflowMode_String_Params[] = {
	"Truncate", "OverflowMode"
};

int ExecuteSetParameter__Truncate_STACK_OverflowMode_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Truncate_STACK_OverflowMode_Rem_Call_Struct = {
	-536, 6, 0, ExecuteSetParameter__Truncate_STACK_OverflowMode_String_Params, 0, 
	ExecuteSetParameter__Truncate_STACK_OverflowMode_Stack_Params
};
char * ExecuteSetParameter__Truncate_STACK_Round_String_Params[] = {
	"Truncate", "Round"
};

int ExecuteSetParameter__Truncate_STACK_Round_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__Truncate_STACK_Round_Rem_Call_Struct = {
	-537, 6, 0, ExecuteSetParameter__Truncate_STACK_Round_String_Params, 0, 
	ExecuteSetParameter__Truncate_STACK_Round_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__UniformNoise_String_Params[] = {
	"UniformNoise"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__UniformNoise_Rem_Call_Struct = {
	-538, 3, 0, CreateDefaultNodeInteractiveEntity__UniformNoise_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__UniformNoise_String_Params[] = {
	"UniformNoise"
};

static CommandParameters CreateNodeInteractiveEntity__UniformNoise_Rem_Call_Struct = {
	-539, 3, 0, CreateNodeInteractiveEntity__UniformNoise_String_Params, 0, 0
};
char * DescribeNodeInstance__UniformNoise_STACK_String_Params[] = {
	"UniformNoise"
};

int DescribeNodeInstance__UniformNoise_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__UniformNoise_STACK_Rem_Call_Struct = {
	-540, 4, 0, DescribeNodeInstance__UniformNoise_STACK_String_Params, 0, 
	DescribeNodeInstance__UniformNoise_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__UniformNoise_STACK_String_Params[] = {
	"UniformNoise"
};

int DeleteNodeInteractiveEntity__UniformNoise_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__UniformNoise_STACK_Rem_Call_Struct = {
	-541, 4, 0, DeleteNodeInteractiveEntity__UniformNoise_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__UniformNoise_STACK_Stack_Params
};
char * DescribeParam__UniformNoise_Maximum_String_Params[] = {
	"UniformNoise", "Maximum"
};

static CommandParameters DescribeParam__UniformNoise_Maximum_Rem_Call_Struct = {
	-542, 5, 0, DescribeParam__UniformNoise_Maximum_String_Params, 0, 0
};
char * DescribeParam__UniformNoise_Minimum_String_Params[] = {
	"UniformNoise", "Minimum"
};

static CommandParameters DescribeParam__UniformNoise_Minimum_Rem_Call_Struct = {
	-543, 5, 0, DescribeParam__UniformNoise_Minimum_String_Params, 0, 0
};
char * DescribeParam__UniformNoise_ElementSize_String_Params[] = {
	"UniformNoise", "ElementSize"
};

static CommandParameters DescribeParam__UniformNoise_ElementSize_Rem_Call_Struct = {
	-544, 5, 0, DescribeParam__UniformNoise_ElementSize_String_Params, 0, 0
};
char * DescribeParam__UniformNoise_Seed_String_Params[] = {
	"UniformNoise", "Seed"
};

static CommandParameters DescribeParam__UniformNoise_Seed_Rem_Call_Struct = {
	-545, 5, 0, DescribeParam__UniformNoise_Seed_String_Params, 0, 0
};
char * DescribeParamInstance__UniformNoise_STACK_Maximum_String_Params[] = {
	"UniformNoise", "Maximum"
};

int DescribeParamInstance__UniformNoise_STACK_Maximum_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__UniformNoise_STACK_Maximum_Rem_Call_Struct = {
	-546, 6, 0, DescribeParamInstance__UniformNoise_STACK_Maximum_String_Params, 0, 
	DescribeParamInstance__UniformNoise_STACK_Maximum_Stack_Params
};
char * DescribeParamInstance__UniformNoise_STACK_Minimum_String_Params[] = {
	"UniformNoise", "Minimum"
};

int DescribeParamInstance__UniformNoise_STACK_Minimum_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__UniformNoise_STACK_Minimum_Rem_Call_Struct = {
	-547, 6, 0, DescribeParamInstance__UniformNoise_STACK_Minimum_String_Params, 0, 
	DescribeParamInstance__UniformNoise_STACK_Minimum_Stack_Params
};
char * DescribeParamInstance__UniformNoise_STACK_ElementSize_String_Params[] = {
	"UniformNoise", "ElementSize"
};

int DescribeParamInstance__UniformNoise_STACK_ElementSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__UniformNoise_STACK_ElementSize_Rem_Call_Struct = {
	-548, 6, 0, DescribeParamInstance__UniformNoise_STACK_ElementSize_String_Params, 
	0, DescribeParamInstance__UniformNoise_STACK_ElementSize_Stack_Params
};
char * DescribeParamInstance__UniformNoise_STACK_Seed_String_Params[] = {
	"UniformNoise", "Seed"
};

int DescribeParamInstance__UniformNoise_STACK_Seed_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__UniformNoise_STACK_Seed_Rem_Call_Struct = {
	-549, 6, 0, DescribeParamInstance__UniformNoise_STACK_Seed_String_Params, 0, 
	DescribeParamInstance__UniformNoise_STACK_Seed_Stack_Params
};
char * ExecuteSetParameter__UniformNoise_STACK_Maximum_String_Params[] = {
	"UniformNoise", "Maximum"
};

int ExecuteSetParameter__UniformNoise_STACK_Maximum_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__UniformNoise_STACK_Maximum_Rem_Call_Struct = {
	-550, 6, 0, ExecuteSetParameter__UniformNoise_STACK_Maximum_String_Params, 0, 
	ExecuteSetParameter__UniformNoise_STACK_Maximum_Stack_Params
};
char * ExecuteSetParameter__UniformNoise_STACK_Minimum_String_Params[] = {
	"UniformNoise", "Minimum"
};

int ExecuteSetParameter__UniformNoise_STACK_Minimum_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__UniformNoise_STACK_Minimum_Rem_Call_Struct = {
	-551, 6, 0, ExecuteSetParameter__UniformNoise_STACK_Minimum_String_Params, 0, 
	ExecuteSetParameter__UniformNoise_STACK_Minimum_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__UnpackWord_String_Params[] = {
	"UnpackWord"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__UnpackWord_Rem_Call_Struct = {
	-552, 3, 0, CreateDefaultNodeInteractiveEntity__UnpackWord_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__UnpackWord_String_Params[] = {
	"UnpackWord"
};

static CommandParameters CreateNodeInteractiveEntity__UnpackWord_Rem_Call_Struct = {
	-553, 3, 0, CreateNodeInteractiveEntity__UnpackWord_String_Params, 0, 0
};
char * DescribeNodeInstance__UnpackWord_STACK_String_Params[] = {
	"UnpackWord"
};

int DescribeNodeInstance__UnpackWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__UnpackWord_STACK_Rem_Call_Struct = {
	-554, 4, 0, DescribeNodeInstance__UnpackWord_STACK_String_Params, 0, 
	DescribeNodeInstance__UnpackWord_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__UnpackWord_STACK_String_Params[] = {
	"UnpackWord"
};

int DeleteNodeInteractiveEntity__UnpackWord_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__UnpackWord_STACK_Rem_Call_Struct = {
	-555, 4, 0, DeleteNodeInteractiveEntity__UnpackWord_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__UnpackWord_STACK_Stack_Params
};
char * DescribeParam__UnpackWord_OutputWordSize_String_Params[] = {
	"UnpackWord", "OutputWordSize"
};

static CommandParameters DescribeParam__UnpackWord_OutputWordSize_Rem_Call_Struct = {
	-556, 5, 0, DescribeParam__UnpackWord_OutputWordSize_String_Params, 0, 0
};
char * DescribeParam__UnpackWord_OutputsPerInput_String_Params[] = {
	"UnpackWord", "OutputsPerInput"
};

static CommandParameters DescribeParam__UnpackWord_OutputsPerInput_Rem_Call_Struct = {
	-557, 5, 0, DescribeParam__UnpackWord_OutputsPerInput_String_Params, 0, 0
};
char * DescribeParam__UnpackWord_SignedOutput_String_Params[] = {
	"UnpackWord", "SignedOutput"
};

static CommandParameters DescribeParam__UnpackWord_SignedOutput_Rem_Call_Struct = {
	-558, 5, 0, DescribeParam__UnpackWord_SignedOutput_String_Params, 0, 0
};
char * DescribeParamInstance__UnpackWord_STACK_OutputWordSize_String_Params[] = {
	"UnpackWord", "OutputWordSize"
};

int DescribeParamInstance__UnpackWord_STACK_OutputWordSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__UnpackWord_STACK_OutputWordSize_Rem_Call_Struct = {
	-559, 6, 0, DescribeParamInstance__UnpackWord_STACK_OutputWordSize_String_Params, 
	0, DescribeParamInstance__UnpackWord_STACK_OutputWordSize_Stack_Params
};
char * DescribeParamInstance__UnpackWord_STACK_OutputsPerInput_String_Params[] = {
	"UnpackWord", "OutputsPerInput"
};

int DescribeParamInstance__UnpackWord_STACK_OutputsPerInput_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__UnpackWord_STACK_OutputsPerInput_Rem_Call_Struct = {
	-560, 6, 0, 
	DescribeParamInstance__UnpackWord_STACK_OutputsPerInput_String_Params, 0, 
	DescribeParamInstance__UnpackWord_STACK_OutputsPerInput_Stack_Params
};
char * DescribeParamInstance__UnpackWord_STACK_SignedOutput_String_Params[] = {
	"UnpackWord", "SignedOutput"
};

int DescribeParamInstance__UnpackWord_STACK_SignedOutput_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__UnpackWord_STACK_SignedOutput_Rem_Call_Struct = {
	-561, 6, 0, DescribeParamInstance__UnpackWord_STACK_SignedOutput_String_Params, 
	0, DescribeParamInstance__UnpackWord_STACK_SignedOutput_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__VoiceNode_String_Params[] = {
	"VoiceNode"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__VoiceNode_Rem_Call_Struct = {
	-562, 3, 0, CreateDefaultNodeInteractiveEntity__VoiceNode_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__VoiceNode_String_Params[] = {
	"VoiceNode"
};

static CommandParameters CreateNodeInteractiveEntity__VoiceNode_Rem_Call_Struct = {
	-563, 3, 0, CreateNodeInteractiveEntity__VoiceNode_String_Params, 0, 0
};
char * MemberFunctionDescribe__VoiceNode_STACK_String_Params[] = {
	"VoiceNode"
};

int MemberFunctionDescribe__VoiceNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters MemberFunctionDescribe__VoiceNode_STACK_Rem_Call_Struct = {
	-564, 4, 0, MemberFunctionDescribe__VoiceNode_STACK_String_Params, 0, 
	MemberFunctionDescribe__VoiceNode_STACK_Stack_Params
};
char * DescribeNodeInstance__VoiceNode_STACK_String_Params[] = {
	"VoiceNode"
};

int DescribeNodeInstance__VoiceNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__VoiceNode_STACK_Rem_Call_Struct = {
	-565, 4, 0, DescribeNodeInstance__VoiceNode_STACK_String_Params, 0, 
	DescribeNodeInstance__VoiceNode_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__VoiceNode_STACK_String_Params[] = {
	"VoiceNode"
};

int DeleteNodeInteractiveEntity__VoiceNode_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__VoiceNode_STACK_Rem_Call_Struct = {
	-566, 4, 0, DeleteNodeInteractiveEntity__VoiceNode_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__VoiceNode_STACK_Stack_Params
};
char * DescribeParam__VoiceNode_FileName_String_Params[] = {
	"VoiceNode", "FileName"
};

static CommandParameters DescribeParam__VoiceNode_FileName_Rem_Call_Struct = {
	-567, 5, 0, DescribeParam__VoiceNode_FileName_String_Params, 0, 0
};
char * DescribeParam__VoiceNode_NoHeader_String_Params[] = {
	"VoiceNode", "NoHeader"
};

static CommandParameters DescribeParam__VoiceNode_NoHeader_Rem_Call_Struct = {
	-568, 5, 0, DescribeParam__VoiceNode_NoHeader_String_Params, 0, 0
};
char * DescribeParamInstance__VoiceNode_STACK_FileName_String_Params[] = {
	"VoiceNode", "FileName"
};

int DescribeParamInstance__VoiceNode_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__VoiceNode_STACK_FileName_Rem_Call_Struct = {
	-569, 6, 0, DescribeParamInstance__VoiceNode_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__VoiceNode_STACK_FileName_Stack_Params
};
char * DescribeParamInstance__VoiceNode_STACK_NoHeader_String_Params[] = {
	"VoiceNode", "NoHeader"
};

int DescribeParamInstance__VoiceNode_STACK_NoHeader_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__VoiceNode_STACK_NoHeader_Rem_Call_Struct = {
	-570, 6, 0, DescribeParamInstance__VoiceNode_STACK_NoHeader_String_Params, 0, 
	DescribeParamInstance__VoiceNode_STACK_NoHeader_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__VoiceStripOut_String_Params[] = {
	"VoiceStripOut"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__VoiceStripOut_Rem_Call_Struct = {
	-571, 3, 0, CreateDefaultNodeInteractiveEntity__VoiceStripOut_String_Params, 0, 
	0
};
char * CreateNodeInteractiveEntity__VoiceStripOut_String_Params[] = {
	"VoiceStripOut"
};

static CommandParameters CreateNodeInteractiveEntity__VoiceStripOut_Rem_Call_Struct = {
	-572, 3, 0, CreateNodeInteractiveEntity__VoiceStripOut_String_Params, 0, 0
};
char * DescribeNodeInstance__VoiceStripOut_STACK_String_Params[] = {
	"VoiceStripOut"
};

int DescribeNodeInstance__VoiceStripOut_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__VoiceStripOut_STACK_Rem_Call_Struct = {
	-573, 4, 0, DescribeNodeInstance__VoiceStripOut_STACK_String_Params, 0, 
	DescribeNodeInstance__VoiceStripOut_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__VoiceStripOut_STACK_String_Params[] = {
	"VoiceStripOut"
};

int DeleteNodeInteractiveEntity__VoiceStripOut_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__VoiceStripOut_STACK_Rem_Call_Struct = {
	-574, 4, 0, DeleteNodeInteractiveEntity__VoiceStripOut_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__VoiceStripOut_STACK_Stack_Params
};
char * DescribeParam__VoiceStripOut_FileName_String_Params[] = {
	"VoiceStripOut", "FileName"
};

static CommandParameters DescribeParam__VoiceStripOut_FileName_Rem_Call_Struct = {
	-575, 5, 0, DescribeParam__VoiceStripOut_FileName_String_Params, 0, 0
};
char * DescribeParamInstance__VoiceStripOut_STACK_FileName_String_Params[] = {
	"VoiceStripOut", "FileName"
};

int DescribeParamInstance__VoiceStripOut_STACK_FileName_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__VoiceStripOut_STACK_FileName_Rem_Call_Struct = {
	-576, 6, 0, DescribeParamInstance__VoiceStripOut_STACK_FileName_String_Params, 0, 
	DescribeParamInstance__VoiceStripOut_STACK_FileName_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__ZFde0_String_Params[] = {
	"ZFde0"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ZFde0_Rem_Call_Struct = {
	-577, 3, 0, CreateDefaultNodeInteractiveEntity__ZFde0_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ZFde0_String_Params[] = {
	"ZFde0"
};

static CommandParameters CreateNodeInteractiveEntity__ZFde0_Rem_Call_Struct = {
	-578, 3, 0, CreateNodeInteractiveEntity__ZFde0_String_Params, 0, 0
};
char * DescribeNodeInstance__ZFde0_STACK_String_Params[] = {
	"ZFde0"
};

int DescribeNodeInstance__ZFde0_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ZFde0_STACK_Rem_Call_Struct = {
	-579, 4, 0, DescribeNodeInstance__ZFde0_STACK_String_Params, 0, 
	DescribeNodeInstance__ZFde0_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ZFde0_STACK_String_Params[] = {
	"ZFde0"
};

int DeleteNodeInteractiveEntity__ZFde0_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ZFde0_STACK_Rem_Call_Struct = {
	-580, 4, 0, DeleteNodeInteractiveEntity__ZFde0_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ZFde0_STACK_Stack_Params
};
char * DescribeParam__ZFde0_Time0_String_Params[] = {
	"ZFde0", "Time0"
};

static CommandParameters DescribeParam__ZFde0_Time0_Rem_Call_Struct = {
	-581, 5, 0, DescribeParam__ZFde0_Time0_String_Params, 0, 0
};
char * DescribeParam__ZFde0_Time1_String_Params[] = {
	"ZFde0", "Time1"
};

static CommandParameters DescribeParam__ZFde0_Time1_Rem_Call_Struct = {
	-582, 5, 0, DescribeParam__ZFde0_Time1_String_Params, 0, 0
};
char * DescribeParam__ZFde0_Factor_String_Params[] = {
	"ZFde0", "Factor"
};

static CommandParameters DescribeParam__ZFde0_Factor_Rem_Call_Struct = {
	-583, 5, 0, DescribeParam__ZFde0_Factor_String_Params, 0, 0
};
char * DescribeParamInstance__ZFde0_STACK_Time0_String_Params[] = {
	"ZFde0", "Time0"
};

int DescribeParamInstance__ZFde0_STACK_Time0_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ZFde0_STACK_Time0_Rem_Call_Struct = {
	-584, 6, 0, DescribeParamInstance__ZFde0_STACK_Time0_String_Params, 0, 
	DescribeParamInstance__ZFde0_STACK_Time0_Stack_Params
};
char * DescribeParamInstance__ZFde0_STACK_Time1_String_Params[] = {
	"ZFde0", "Time1"
};

int DescribeParamInstance__ZFde0_STACK_Time1_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ZFde0_STACK_Time1_Rem_Call_Struct = {
	-585, 6, 0, DescribeParamInstance__ZFde0_STACK_Time1_String_Params, 0, 
	DescribeParamInstance__ZFde0_STACK_Time1_Stack_Params
};
char * DescribeParamInstance__ZFde0_STACK_Factor_String_Params[] = {
	"ZFde0", "Factor"
};

int DescribeParamInstance__ZFde0_STACK_Factor_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ZFde0_STACK_Factor_Rem_Call_Struct = {
	-586, 6, 0, DescribeParamInstance__ZFde0_STACK_Factor_String_Params, 0, 
	DescribeParamInstance__ZFde0_STACK_Factor_Stack_Params
};
char * CreateDefaultNodeInteractiveEntity__ZFde1_String_Params[] = {
	"ZFde1"
};

static CommandParameters CreateDefaultNodeInteractiveEntity__ZFde1_Rem_Call_Struct = {
	-587, 3, 0, CreateDefaultNodeInteractiveEntity__ZFde1_String_Params, 0, 0
};
char * CreateNodeInteractiveEntity__ZFde1_String_Params[] = {
	"ZFde1"
};

static CommandParameters CreateNodeInteractiveEntity__ZFde1_Rem_Call_Struct = {
	-588, 3, 0, CreateNodeInteractiveEntity__ZFde1_String_Params, 0, 0
};
char * DescribeNodeInstance__ZFde1_STACK_String_Params[] = {
	"ZFde1"
};

int DescribeNodeInstance__ZFde1_STACK_Stack_Params[] = {
	1
};

static CommandParameters DescribeNodeInstance__ZFde1_STACK_Rem_Call_Struct = {
	-589, 4, 0, DescribeNodeInstance__ZFde1_STACK_String_Params, 0, 
	DescribeNodeInstance__ZFde1_STACK_Stack_Params
};
char * DeleteNodeInteractiveEntity__ZFde1_STACK_String_Params[] = {
	"ZFde1"
};

int DeleteNodeInteractiveEntity__ZFde1_STACK_Stack_Params[] = {
	1
};

static CommandParameters DeleteNodeInteractiveEntity__ZFde1_STACK_Rem_Call_Struct = {
	-590, 4, 0, DeleteNodeInteractiveEntity__ZFde1_STACK_String_Params, 0, 
	DeleteNodeInteractiveEntity__ZFde1_STACK_Stack_Params
};
char * DescribeParam__ZFde1_Factor_String_Params[] = {
	"ZFde1", "Factor"
};

static CommandParameters DescribeParam__ZFde1_Factor_Rem_Call_Struct = {
	-591, 5, 0, DescribeParam__ZFde1_Factor_String_Params, 0, 0
};
char * DescribeParam__ZFde1_Interval_String_Params[] = {
	"ZFde1", "Interval"
};

static CommandParameters DescribeParam__ZFde1_Interval_Rem_Call_Struct = {
	-592, 5, 0, DescribeParam__ZFde1_Interval_String_Params, 0, 0
};
char * DescribeParam__ZFde1_MaxSize_String_Params[] = {
	"ZFde1", "MaxSize"
};

static CommandParameters DescribeParam__ZFde1_MaxSize_Rem_Call_Struct = {
	-593, 5, 0, DescribeParam__ZFde1_MaxSize_String_Params, 0, 0
};
char * DescribeParam__ZFde1_Time0_String_Params[] = {
	"ZFde1", "Time0"
};

static CommandParameters DescribeParam__ZFde1_Time0_Rem_Call_Struct = {
	-594, 5, 0, DescribeParam__ZFde1_Time0_String_Params, 0, 0
};
char * DescribeParam__ZFde1_Time1_String_Params[] = {
	"ZFde1", "Time1"
};

static CommandParameters DescribeParam__ZFde1_Time1_Rem_Call_Struct = {
	-595, 5, 0, DescribeParam__ZFde1_Time1_String_Params, 0, 0
};
char * DescribeParam__ZFde1_DoubMaxSteps_String_Params[] = {
	"ZFde1", "DoubMaxSteps"
};

static CommandParameters DescribeParam__ZFde1_DoubMaxSteps_Rem_Call_Struct = {
	-596, 5, 0, DescribeParam__ZFde1_DoubMaxSteps_String_Params, 0, 0
};
char * DescribeParam__ZFde1_DiscrScheme_String_Params[] = {
	"ZFde1", "DiscrScheme"
};

static CommandParameters DescribeParam__ZFde1_DiscrScheme_Rem_Call_Struct = {
	-597, 5, 0, DescribeParam__ZFde1_DiscrScheme_String_Params, 0, 0
};
char * DescribeParamInstance__ZFde1_STACK_Factor_String_Params[] = {
	"ZFde1", "Factor"
};

int DescribeParamInstance__ZFde1_STACK_Factor_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ZFde1_STACK_Factor_Rem_Call_Struct = {
	-598, 6, 0, DescribeParamInstance__ZFde1_STACK_Factor_String_Params, 0, 
	DescribeParamInstance__ZFde1_STACK_Factor_Stack_Params
};
char * DescribeParamInstance__ZFde1_STACK_Interval_String_Params[] = {
	"ZFde1", "Interval"
};

int DescribeParamInstance__ZFde1_STACK_Interval_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ZFde1_STACK_Interval_Rem_Call_Struct = {
	-599, 6, 0, DescribeParamInstance__ZFde1_STACK_Interval_String_Params, 0, 
	DescribeParamInstance__ZFde1_STACK_Interval_Stack_Params
};
char * DescribeParamInstance__ZFde1_STACK_MaxSize_String_Params[] = {
	"ZFde1", "MaxSize"
};

int DescribeParamInstance__ZFde1_STACK_MaxSize_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ZFde1_STACK_MaxSize_Rem_Call_Struct = {
	-600, 6, 0, DescribeParamInstance__ZFde1_STACK_MaxSize_String_Params, 0, 
	DescribeParamInstance__ZFde1_STACK_MaxSize_Stack_Params
};
char * DescribeParamInstance__ZFde1_STACK_Time0_String_Params[] = {
	"ZFde1", "Time0"
};

int DescribeParamInstance__ZFde1_STACK_Time0_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ZFde1_STACK_Time0_Rem_Call_Struct = {
	-601, 6, 0, DescribeParamInstance__ZFde1_STACK_Time0_String_Params, 0, 
	DescribeParamInstance__ZFde1_STACK_Time0_Stack_Params
};
char * DescribeParamInstance__ZFde1_STACK_Time1_String_Params[] = {
	"ZFde1", "Time1"
};

int DescribeParamInstance__ZFde1_STACK_Time1_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ZFde1_STACK_Time1_Rem_Call_Struct = {
	-602, 6, 0, DescribeParamInstance__ZFde1_STACK_Time1_String_Params, 0, 
	DescribeParamInstance__ZFde1_STACK_Time1_Stack_Params
};
char * DescribeParamInstance__ZFde1_STACK_DoubMaxSteps_String_Params[] = {
	"ZFde1", "DoubMaxSteps"
};

int DescribeParamInstance__ZFde1_STACK_DoubMaxSteps_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ZFde1_STACK_DoubMaxSteps_Rem_Call_Struct = {
	-603, 6, 0, DescribeParamInstance__ZFde1_STACK_DoubMaxSteps_String_Params, 0, 
	DescribeParamInstance__ZFde1_STACK_DoubMaxSteps_Stack_Params
};
char * DescribeParamInstance__ZFde1_STACK_DiscrScheme_String_Params[] = {
	"ZFde1", "DiscrScheme"
};

int DescribeParamInstance__ZFde1_STACK_DiscrScheme_Stack_Params[] = {
	2
};

static CommandParameters DescribeParamInstance__ZFde1_STACK_DiscrScheme_Rem_Call_Struct = {
	-604, 6, 0, DescribeParamInstance__ZFde1_STACK_DiscrScheme_String_Params, 0, 
	DescribeParamInstance__ZFde1_STACK_DiscrScheme_Stack_Params
};
char * ExecuteSetParameter__ZFde1_STACK_Interval_String_Params[] = {
	"ZFde1", "Interval"
};

int ExecuteSetParameter__ZFde1_STACK_Interval_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__ZFde1_STACK_Interval_Rem_Call_Struct = {
	-605, 6, 0, ExecuteSetParameter__ZFde1_STACK_Interval_String_Params, 0, 
	ExecuteSetParameter__ZFde1_STACK_Interval_Stack_Params
};
char * ExecuteSetParameter__ZFde1_STACK_DoubMaxSteps_String_Params[] = {
	"ZFde1", "DoubMaxSteps"
};

int ExecuteSetParameter__ZFde1_STACK_DoubMaxSteps_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__ZFde1_STACK_DoubMaxSteps_Rem_Call_Struct = {
	-606, 6, 0, ExecuteSetParameter__ZFde1_STACK_DoubMaxSteps_String_Params, 0, 
	ExecuteSetParameter__ZFde1_STACK_DoubMaxSteps_Stack_Params
};
char * ExecuteSetParameter__ZFde1_STACK_DiscrScheme_String_Params[] = {
	"ZFde1", "DiscrScheme"
};

int ExecuteSetParameter__ZFde1_STACK_DiscrScheme_Stack_Params[] = {
	2
};

static CommandParameters ExecuteSetParameter__ZFde1_STACK_DiscrScheme_Rem_Call_Struct = {
	-607, 6, 0, ExecuteSetParameter__ZFde1_STACK_DiscrScheme_String_Params, 0, 
	ExecuteSetParameter__ZFde1_STACK_DiscrScheme_Stack_Params
};
#endif /* #ifndef MENEXE_DOT_H*/
