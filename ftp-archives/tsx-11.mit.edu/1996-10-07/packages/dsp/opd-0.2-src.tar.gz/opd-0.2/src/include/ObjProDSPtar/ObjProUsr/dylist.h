/*
 *  dylist.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */

#ifndef DYLIST_DOT_H
#define DYLIST_DOT_H
#define __DSP_PP_TARGET_CODE__
#include "ObjProArith/hrdarth.h"

#include "ObjProDSP/portable.h"
#include "ObjProDSP/entenm.h"
#include "ObjProGen/debug.h"
#include "ObjProDSPcom/tarnod.h"
class Listing: public TargetNode {
#line 45 "../dylist.usr"
 
#ifdef INTERACTIVE
	StreamStr * stream_str ;
	virtual void NewSampleRate();
	double SampleRate ;
	virtual DfNode * target_replacement(const char * target);
    void input_linked(int chan);
	int already_set ;
#endif
	int DisplayHandle ;
	int FirstTime;
	int WindowId ;
	class GenericList * TheGenericKernel ;
	void ConstructorKernel();
	void SetupRemote();
	ErrCode Kernel(int32 K);
#line 38 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/dylist.h"
	int integer_read_flag ;
	int16  Hex_1;
	const char *  Caption_2;
public:
	Listing (const char * Name, int16 Hex, const char * Caption,
		DfNodeInLink* in_links, DfNodeOutLink* out_links,
		int ** exec_seq,  NodeExecuteType exec_type,
		int delay,
		int ListingStaticInitinteger_read_flag);
	virtual ~Listing();
	int16 GetHex() const {return Hex_1;}
	const char * GetCaption() const {return Caption_2;}
	virtual ErrCode DoNode(int32);
	virtual double TimeFirst(DfNodeInLink *,DfNodeOutLink *);
	void SetHex(int16  Hex) { Hex_1 = Hex; parameter_changed(); }
#line 62 "../dylist.usr"
	virtual int window_id(){return WindowId;}
#line 56 "/dist/opd_2/opd-0.2/src/include/ObjProDSPtar/ObjProUsr/dylist.h"
};

extern Listing * ListingDef;


#endif /* #ifdef DYLIST_DOT_H */
