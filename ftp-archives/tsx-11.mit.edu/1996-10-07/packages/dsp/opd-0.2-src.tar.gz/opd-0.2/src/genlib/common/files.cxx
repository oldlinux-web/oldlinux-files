/*  xfiles.c   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include <fstream.h>
#include <stdlib.h>
#include "files.h"
#include <errno.h>

void CerrSystemErrorMessage(int LastLineFeed=1)
{
	cerr << "The system error message is:\n" ;
	if (errno < sys_nerr) cerr << sys_errlist[errno] ;
	else cerr << "error number: " << errno <<
		" which is not in the system error table" ;
	cerr << "." ;
	if (LastLineFeed) cerr << "\n" ;

}


ostream& OpenFile (const char * FileName)
{
	return  *new ofstream(FileName) ;
}


