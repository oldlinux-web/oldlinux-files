/*
 *  nbits.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef NBITS_DOT_H
#define NBITS_DOT_H
#include <limits.h>

#include "ObjProArith/hrdarth.h"
#include "ObjProDSP/portable.h"

int NumberOnesUint32(uint32 word);
int NumberOnesBin(BinMachWord word);

int GetTrailingZero(uint32 Value) ;
int GetTrailingOne(uint32 Value) ;
int GetLeadingZero(uint32 Value) ;
int GetLeadingOne(uint32 Value) ;

extern int BitsPerBinWord ;
extern int BitsPerUint32 ;
#endif /* #ifdef NBITS_DOT_H */
