/*  error.c   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include <stream.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>

#include "error.h"

void InternalError(char * msg)
{
#if !defined(NO_OSFCN) && !defined(__NT_VC__)
	cerr << "Internal error: " << msg << ".\nJob terminated.\n" ;
	kill (getpid(),SIGQUIT);
	exit (2);
#else
	exit(1);
#endif
}

