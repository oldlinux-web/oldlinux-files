/*  help.c   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include <stream.h>
#include "usercom.h"

#include "help.h"


HelpControl HelpDo ;

 
void HelpControl::EchoCommand(const char * Cmd)
{
	if (Level < HelpLevelConfirm) return ;
	*Output + OutputHelp << Cmd << "\n" ;
}

void HelpControl::ConfirmAction(const char * Confirmation, const char * a,
	const char *b, const char * c)
{
	if (Level < HelpLevelConfirm) return ;
	*Output + OutputHelp << Confirmation ;
	if (a) *Output << a ;
	if (b) *Output << b ;
	if (c) *Output << c ;
	*Output << "\n" ;
}

