/*
 *  dyntextd.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  dyntextd.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include "ObjProComGui/dyntext.h"

class DspDynamicTextControl: public DynamicTextControl {
	class IntPtrList * TheHandleRequests ;
	class WindowMapList * TheWindowMap ;
	int ActiveWindowOpenRequest ;
public:
	DspDynamicTextControl() ;
	virtual void TextServer(struct PacketHeader& , const char *);
	void GetWindowHandle(int& ToWrite, const char * Name, const char * C);
	void CheckForPacket();
	void OpenWindow(int WindowHandle, int * ToSet);
	void OpenWindowAndWait(int WindowHandle, int * ToSet);
	int CheckWindowOpen(int WindowHandle);
	void WaitWindowOpen(int WindowHandle);
	int GetWindowId(int UserId);
};

extern DspDynamicTextControl * TheDynamicTextController;

void GetWindowHandle(int& ToSet, const char * Name, const char * Caption);
