/*
 *  fde1sim.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef FDE1_SIM_DOT_H
#define FDE1_SIM_DOT_H

class Fde1Grid ;
class ZFde1 ;

class Fde1Sim {
	ZFde1& param ;
	Fde1Grid * the_grid ;
public:
	Fde1Sim(ZFde1& p);
	~Fde1Sim();
	ErrCode simulate(int32 k);
	void parameter_changed();
};

#endif
