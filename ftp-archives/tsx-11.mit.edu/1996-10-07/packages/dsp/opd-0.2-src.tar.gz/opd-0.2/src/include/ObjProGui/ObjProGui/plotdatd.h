/*
 *  plotdatd.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  plotdatd.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#ifndef PLOTDATD_DOT_H
#define PLOTDATD_DOT_H
#include "ObjProComGui/plotdat.h"

class PlotController {
	class PlotNodeList * WaitingPlotId ;
	class PlotNodeList * WaitingHeaderComplete ;
public:
	PlotController() ;
	~PlotController() ;
	void GetPlotId(class PlotNode *);
	void SetPlotId(int Id) ;
	void SendComplete(int Id) ;
	void PlotServer(struct PacketHeader& Head, const char * Data);
} ;

extern PlotController ThePlotController ;

extern AxisScalingX SingleChannelXDefaultAxis ;
extern AxisScalingY SingleChannelYDefaultAxis ;
#endif /* #ifdef PLOTDATD_DOT_H */
