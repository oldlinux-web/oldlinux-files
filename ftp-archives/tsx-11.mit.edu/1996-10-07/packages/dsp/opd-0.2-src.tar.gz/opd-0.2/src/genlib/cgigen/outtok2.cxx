/*  outtok2.c   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include <stream.h>
#include "usercom.h"
#include "outtok.h"
#include "cgidbg.h"

void OutTokens::Init(OutputType typ, OutCon * o)
{
	// LogOut << "OutTokens::Init(OutputType\n";
	// LogOut << "OutTokens::Init(" << typ << ")\n" ;
	Out = typ;
	if (o) out = &o->GetStream(Out) ;
	else out = &Output->GetStream(Out);
}

void OutTokens::Check(ostream * o)
{
	out = o;
	return ;
}



