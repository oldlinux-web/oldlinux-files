/*
 *  menucmdg.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  menucmdg.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include "menucmd.h"

class ExecuteCmdGui {
	CommandParameters * Params ;
	ParameterizedActionCall TheCall;
	int ParameterSetIndex ;
	int wait_remote_flag ;
public:
	void Init (CommandParameters * params);
	ExecuteCmdGui():wait_remote_flag(0){Init(0);}
	// Init should be called first to set up parameters
	// Then DoCall is called to execute routine
	void DoCall(); 
	void Execute();
	void ExecuteRemote();
	int wait_remote_execute() const {return wait_remote_flag;}
	void set_wait_remote_execute() {wait_remote_flag=1;}
	void clear_wait_remote_execute() {wait_remote_flag=0;}
};

extern ParameterizedActionCall AllActions[] ;

extern ExecuteCmdGui Master ;

