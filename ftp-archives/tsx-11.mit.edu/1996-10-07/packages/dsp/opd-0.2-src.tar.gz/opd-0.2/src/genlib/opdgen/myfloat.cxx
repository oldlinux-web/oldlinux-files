/*  myfloat.c   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include <math.h>

#include "myfloat.h"

#include "dspguicom.h"
#include "arthnm.h"

const char * DspGuiCommon::default_prefix = 
	"Type RETURN to select the default value (" ;

const char * DspGuiCommon::default_suffix =  ") for `" ;



const char * FloatFormat(double value)
{
	double AbsValue = fabs(value);
	if (AbsValue < 1.e9 && AbsValue > 1.e-5) return "%f" ;
	return "%e" ;
} 
