/*
 *  menucmdd.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
/*  menucmdd.h   */
/*  Copyright 1989 Mountain Math Software  */
/*  All Rights Reserved                    */
#include "menucmd.h"

class ExecuteCmdDsp {
	CommandParameters * Params ;
	ParameterizedActionCall TheCall;
	int ParameterSetIndex ;
	
public:
	void Init (CommandParameters * params);
	ExecuteCmdDsp(){Init(0);}
	// Init should be called first to set up parameters
	// Then DoCall is called to execute routine
	void DoCall(); 
	void Execute();
	void SetParameters(struct PacketHeader& Head, const char *Buf) ;
	const char * GetMenuStackName(int index);
};

extern ParameterizedActionCall AllActions[] ;

void InterpretMenuCommand(struct PacketHeader& Head, const char * Buffer) ;

extern ExecuteCmdDsp Master ;

