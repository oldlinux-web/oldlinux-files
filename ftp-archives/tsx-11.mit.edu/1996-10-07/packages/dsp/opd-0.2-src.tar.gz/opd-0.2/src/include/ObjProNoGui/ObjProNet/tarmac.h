/*
 *  tarmac.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#ifndef TARMAC_DOT_H
#define TARMAC_DOT_H
#define OUT_C(command) { return OutLinks[chan].command; }
#define IN_C(command) { return InLinks[chan].command; }

#define OUT_CX(command) { OutLinks[chan].command; }
#define IN_CX(command) { InLinks[chan].command; }

#include "ObjProDSPint/netlnk.h"
#endif /* #ifdef TARMAC_DOT_H */
