/*
 *  timinfo.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
#include "ObjProDSP/portable.h"

struct TimingInfo {
	int32 TotalCount ;
	uint32 TotalClocks ;
	int32 FileEntrysForThisNode ;
	TimingInfo();
	void SetBenchMark(uint32 begin, uint32  end, int32 Count);

};

void CheckPointBegin(int DataCount=0) ;
void CheckPointEnd(uint32 CurrentClock, int32 DataCount=0) ;
extern int TimingCheckOn ;
extern int TimingEntrysLimit ;


