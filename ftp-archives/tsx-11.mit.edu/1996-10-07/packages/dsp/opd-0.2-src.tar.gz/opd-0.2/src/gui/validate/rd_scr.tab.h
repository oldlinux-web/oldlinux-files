/*
 *  rd_scr.tab.h from ObjectProDSP 0.2
 *  Copyright (C) 1994 1995, Mountain Math Software, All rights reserved.
 *  Licensed for free use and distribution under version 2 of the Gnu General
 *  Public License. Please see file COPYING for details and restrictions.
 *  
 *  ObjectProDSP is a trademark of Mountain Math Software.
 */
typedef union {
	int32 reserved ;
	int32 integer ;
	char * string ;
	} YYSTYPE;
#define	STRING	258
#define	INTEGER	259
#define	KEY	260
#define	ACTION	261
#define	MOUSE	262
#define	PROMPT	263
#define	MENU	264
#define	DPP	265
#define	MENU_STATE	266
#define	NEWLINE	267


extern YYSTYPE yylval;
