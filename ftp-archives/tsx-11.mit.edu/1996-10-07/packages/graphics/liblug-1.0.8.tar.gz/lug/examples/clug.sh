#!/bin/sh
#
# 
# This is an exmaple of a Universal compiler:
#
#	carreras --> is a Silicon Graphics machine
#	caballe  --> is an IBM AIX
#	<others> --> ... ok, others! ...
#

PROG=$1
shift
echo "Compilando $PROG.c"

case `hostname` in
carreras*)
  CC=cc
  GLIB="-limage -lgl_s";;
caballe*)
  CC=cc
  GLIB="-L/usr/local/X11R5/lib -lX11 -lgl";;
*)
  GLIB="-L/usr/local/X11R5/lib -lX11"
  CC=gcc;;
esac

$CC -o $PROG $PROG.c -O -I/usr/include/lug -llug -lrle -ltiff -ljpeg $GLIB -lm $*
if [ $? -eq 0 ]
then
    echo "Done."
else
    echo "Error."
fi

