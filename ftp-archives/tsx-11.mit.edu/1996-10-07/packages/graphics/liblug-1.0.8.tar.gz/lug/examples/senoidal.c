#include <lug.h>
#include <lugfnts.h>

main()
{
        bitmap_hdr in;
        int totalsize;
        byte *ptr, *ptr2;
        double val;
        int i, j;

        in.magic = LUGUSED;
        in.xsize = 512;
        in.ysize = 512;
        in.depth = 8;
        in.colors = 1 << in.depth;
        in.cmap = (byte *) create_bw_pallete();

        totalsize = in.xsize * in.ysize;
        ptr2 = in.b = in.g = in.r = (byte *) Malloc( totalsize );
        ptr = ( byte *) Malloc( in.xsize );

        for ( i = 0; i < in.xsize; i++ ) {
                val = 1. + sin((double)i / in.xsize * M_PI * 8. );
                val = .25 + ( val / 2. ) * 1.5;
                val *= 255. / 2.;
                ptr[i] = (int) CORRECT( val );
        }

        for ( i = 0; i < in.ysize; i++, ptr2 += in.xsize ) {
                bcopy( ptr, ptr2, in.xsize );
        }

        write_gif_file( "a.gif", &in ); 
}