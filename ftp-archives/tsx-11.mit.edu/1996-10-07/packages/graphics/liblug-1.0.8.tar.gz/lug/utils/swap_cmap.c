
/*
 * This software is copyrighted as noted below.  It may be freely copied,
 * modified, and redistributed, provided that the copyright notice is
 * preserved on all copies.
 *
 * There is no warranty or other guarantee of fitness for this software,
 * it is provided solely "as is".  Bug reports or fixes may be sent
 * to the author, who may or may not act on them as he desires.
 *
 * You may not include this software in a program or other software product
 * without supplying the source, or without informing the end-user that the
 * source is available for no extra charge.
 *
 * If you modify this software, you should include a notice giving the
 * name of the person performing the modification, the date of modification,
 * and the reason for such modification.
 */
/*
 * swap_cmap.c - swap the order of a color map.
 *
 * Author:      Raul Rivero
 *              Vicerrectorado de Estudiantes 
 *              University of Oviedo
 * Date:        Sat Aug 05 1995
 * Copyright (c) 1995, Raul Rivero
 *
 */

#include <lug.h>
#include <lugfnts.h>

extern int LUGverbose;

swap_cmap( inbitmap )
bitmap_hdr *inbitmap;
{
  register int i, j, k;
  byte *r, *end;
  color_map *map;

  if ( inbitmap->magic != LUGUSED )
    error( 19 );

  /* We need a mapped image */
  if ( inbitmap->depth > 8 )
    error( 15 );

  /* Ok, now we swap the color map table, ... */ 
  map  = (color_map *) inbitmap->cmap;
  /* Two pointers: up and down... */ 
  for ( i = 0, j = (k=inbitmap->colors-1); i < j; i++, j-- ) {
    SWAP( map[i][0], map[j][0] ); 
    SWAP( map[i][1], map[j][1] ); 
    SWAP( map[i][2], map[j][2] ); 
  } 

  /*
   * Fine, now we have the color map rigth but all the references
   * from the raw image are incorrect, so...
   */
  r = inbitmap->r;
  end = r + inbitmap->xsize * inbitmap->ysize;
  while ( end > r ) {
    *r++ = ABS ( *r - k ); 
  }
}
