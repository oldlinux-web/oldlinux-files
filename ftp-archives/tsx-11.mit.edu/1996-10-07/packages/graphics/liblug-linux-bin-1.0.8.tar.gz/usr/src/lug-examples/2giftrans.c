#include <lug.h>
#include <lugfnts.h>

extern LUGverbose;

main( argc, argv )
int argc;
char **argv;
{
  bitmap_hdr image;


  LUGverbose = TRUE;

  read_gif_file( argv[1], &image );

  set_write_gif89_flag(); 

  write_gif_file( argv[2], &image );
}
