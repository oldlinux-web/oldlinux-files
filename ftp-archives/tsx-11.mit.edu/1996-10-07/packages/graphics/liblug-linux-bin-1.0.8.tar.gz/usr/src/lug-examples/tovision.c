/*
 * I don't wanna write the header so only ...
 *
 * (c) 1992, Raul Rivero
 */

#include <lug.h>
#include <functions.h>

main(argc, argv)
int argc;
char **argv;
{
        bitmap_hdr in, out;
        FILE *handle;

        /* Read the Alias file */
        read_lug_file( argv[1], &in );

        /* Convert it to b&w */
        to_raw_bw( &in, &out );

        /*
         * Ok, now write it ( to file name if given else
         * to stdout.
         */
        if ( argc > 2 )
                handle = Fopen( argv[2], "w" );
        else handle = stdout;
        /* Write the sizes ( MSByte first ) ... */
        putc( MSB(out.xsize), handle );
        putc( LSB(out.xsize), handle );
        putc( MSB(out.ysize), handle );
        putc( LSB(out.ysize), handle );
        /* ... and the image */
        write8bitmap( handle, &out );
        Fclose( handle );

        /* Bye!!! */
        exit( 0 );
}
