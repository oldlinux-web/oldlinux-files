/*
 * version.h --- controls the version number printed by the e2fs
 * programs.
 *
 * Copyright 1995, Theodore Ts'o.  This file may be redistributed
 * under the GNU Public License.
 */

#define E2FSPROGS_VERSION "1.03"
#define E2FSPROGS_DATE "26-Mar-96"

