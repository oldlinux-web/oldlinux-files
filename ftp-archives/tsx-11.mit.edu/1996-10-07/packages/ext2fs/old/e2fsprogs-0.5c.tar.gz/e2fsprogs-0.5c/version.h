/*
 * version.h --- controls the version number printed by the e2fs
 * programs.
 *
 * Copyright 1995, Theodore Ts'o.  This file may be redistributed
 * under the GNU Public License.
 */

#define E2FSPROGS_VERSION "0.5c"
#define E2FSPROGS_DATE "27-Oct-95"

