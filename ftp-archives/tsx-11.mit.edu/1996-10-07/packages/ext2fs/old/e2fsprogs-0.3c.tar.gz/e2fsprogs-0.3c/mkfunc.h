/*
 * mkfunc.h		- Prototypes of global functions used by mke2fs
 *
 * Copyright (C) 1992, 1993  Remy Card <card@masi.ibp.fr>
 *
 * This file can be redistributed under the terms of the GNU General
 * Public License
 */

/*
 * History:
 * 93/05/26	- Creation from mke2fs
 */

/* badblocks2.c */
extern void	check_blocks	(int);
extern void	get_list_blocks	(const char *);

/* countblocks.c */
extern long	count_blocks	(const char *);

/* mke2fs.c */
extern volatile void
		die		(const char *, int);

/* tables2.c */
extern void	write_tables	(int);
extern void	make_group_desc	(void);
extern void	count_free	(void);
extern void	setup_tables	(void);
