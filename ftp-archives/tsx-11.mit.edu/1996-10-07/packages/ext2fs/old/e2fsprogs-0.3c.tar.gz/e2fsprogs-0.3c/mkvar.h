/*
 * mkvar.h		- Global variables used by mke2fs
 *
 * Copyright (C) 1992, 1993  Remy Card <card@masi.ibp.fr>
 *
 * This file can be redistributed under the terms of the GNU General
 * Public License
 */

/*
 * History:
 * 93/05/26	- Creation from mke2fs
 */

extern struct ext2_super_block * Super;

extern char * bad_map;
extern char * block_map;
extern char * inode_map;

extern char * inode_buffer;

extern char blkbuf[EXT2_MAX_BLOCK_SIZE * TEST_BUFFER_BLOCKS];

extern int inode_ratio;
extern int reserved_ratio;
extern long block_size;
extern long frag_size;
extern int frags_per_block;
extern int blocks_per_group;
extern long blocks;
extern int check;
extern int badblocks;
extern int verbose;

extern int changed;

extern int inode_blocks_per_group;
extern int addr_per_block;

extern unsigned long group_desc_count;
extern unsigned long group_desc_size;
extern unsigned long desc_blocks;
extern struct ext2_group_desc * group_desc;
