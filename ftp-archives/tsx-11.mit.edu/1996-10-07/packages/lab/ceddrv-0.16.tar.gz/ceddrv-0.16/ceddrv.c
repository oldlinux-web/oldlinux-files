/* -*-mode:C;tab-width:8;c-indent-level:4;c-label-offset:-2-*-
 * 
 * ceddrv.c -- a driver for CED 1401 laboratory interface
 *
 * Copyright (C) 1995 Georg v. Zezschwitz
 * Copyright (C) 1995 Alessandro Rubini
 *
 *                    zezschwi@kogs26.informatik.uni-hamburg.de
 *                    rubini@ipvvis.unipv.it
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#define __KERNEL__
#define MODULE

#include <linux/module.h>
#include <linux/version.h>

#include <linux/types.h>
#include <linux/sched.h>
#include <linux/kernel.h>
#include <linux/fcntl.h>
#include <linux/errno.h>
#include <linux/ioport.h>
#include <linux/config.h>
#include <linux/major.h>
#include <linux/malloc.h>
#include <linux/mman.h>

#include <asm/io.h>
#include <asm/system.h>
#include <asm/segment.h>
#include <asm/pgtable.h>
#include <asm/page.h>
#include <asm/dma.h>

#include "cedCfg.h"
#include "ceddrv.h"

/* These variables are those which are supposed to be changed by insmod */

int ced_major = 0;             /* major device number, 0 to autoassign */
int ced_fake  = 0;             /* 1 to avoid interrupt, 2 to avoid all */
int ced_base  = 0;             /* force a base address, 0 to autodetect */

#define PORT_MIN  0x300
#define PORT_MAX  0x3c0  /* c,d,e,f can't be used if a vga is there, anyways */
#define PORT_STEP  0x10

/*
 * If insmod should fail with complaints about Kernel version, make sure
 * /usr/include/linux/version.h holds a definition for UTS_RELEASE matching
 * your kernel version
*/
char    kernel_version [] = UTS_RELEASE;

/*
 * Right now, we have three subcategories of information.
 *
 * 1) Device Dependent information (hwinfo, max 4 devices)
 *
 * 2) Open Call dependent information (per file, to allow
 *     multiple open calls by diffrent clients) (ced_file_info)
 * 3) Single DMA-buffer related information, linked to file info
 *     dynamical, too (dma_desc)
 */

/* Low level (3) first: This is per Ced_Malloc-allocated Buffer */

typedef struct dma_desc {
    unsigned long   dma_adr;	/* Physical address, as by kmalloc */
    unsigned long   dma_size;	/* Size in bytes */
    unsigned long   user_adr;	/* Logical address in user space */
    struct dma_desc *next;
} dma_desc;


/* This is per device (Level 3) 				*/

typedef struct ced1401_str {
    int                irq;       /* -1 if not available */
    int		       dma;	  /* -1 if not available */
    unsigned int       base_adr;
    short              type, state1401;
    int                nopen;
    char              *inbuf;
    int                iiptr, ioptr, inum;
    char              *outbuf;
    int                oiptr, ooptr, onum;
    unsigned int       time, wait;
    unsigned short     dma_flag;	/* This stuff is for */
    unsigned short     dma_page, dma_offs;  /* RUNNING dma-  */
    unsigned short     dma_size, dma_direct; /* transfers    */
    unsigned           dma_addr;
    unsigned long      dma_log_adr;	/* ... and this for  */
    unsigned long      dma_phys_adr;    /* the next dma-     */
    unsigned long      dma_max_bytes;   /* transfer, set by  */
    unsigned long      dma_fs;		/* ioctl             */    
    struct wait_queue *ced_wait_iq;
    struct wait_queue *ced_wait_oq;
    int                status,value;
} ced1401_str;


/* This is allocated per File (level 2)			*/

typedef struct {
	ced1401_str	*devp;		/* Which 1401 do we use ? */
	dma_desc	*dmabuf_info;	/* Which buffers allocated */
} ced_file_info;


enum { TYPE1401_STD, TYPE1401_PLUS, TYPE1401_INVALID };

static ced1401_str  hwinfo[4]; /* max 4 boards */
static int hwcount=0;          /* but how many are there? */

#define CED1401_INBUF_SIZE  1020    /* Input buffer from 1401 */
#define CED1401_OUTBUF_SIZE 1020

#define CED1401_TIMEOUT      100    /* 10ms for response from 1401 */
#define CED1401_IN_TIMEOUT     2    /* Timeout for retrying to read  */
#define CED1401_DMA_MAX  0x10000    /* Maximum bytes xferred in one dma */


/* Definition of 1401 ports */

#define DV_DOT      0x00
#define DV_CSR      0x01
#define DV_BUS_L    0x02
#define DV_BUS_H    0x03
#define DV_DIN      0x08    /* device in */
#define DV_CLK_CSR  0x0c
#define DV_8253_IN  0x0c    /* 8253 read address */
#define DV_CLK_REG  0x0d
#define DV_8253_OUT 0x0e    /* 8253 write address */
#define DV_SW       0x0e    /* interrupt priority switch */
#define DV_DMA      0x0f    /* DMA control register */

/* Definition of DMA controller ports */

#define DMA_WRR     0x09
#define DMA_WSMBR   0x0A
#define DMA_WMR     0x0b
#define DMA_CBPFF   0x0c
#define DMA_RSR     0x08


static void ced_oneloop (ced1401_str *hwp);
static void TransferInit (ced1401_str *hwp);
static int SetupTransferAdr (struct file*, unsigned long adr);
static unsigned long AllocateDmaBuffer (struct file*, unsigned long size);
static int FreeDmaBuffer (struct file *file, unsigned long ptr);
static int CheckDmaAdr (struct file *file, unsigned long adr);
	
unsigned long ced_mem_remap(unsigned long addr, unsigned long len,
	unsigned long prot, unsigned long flags, unsigned long off);

/*----------------------------------------------------------------------*/
static int test_card (ced1401_str *ceds) 
{
    int base = ceds->base_adr;
    int settings, n;
    int t_irq = 2;
    int t_dma = -1;

    if (ced_fake>1) {printk("1401: look for irq\n"); return 0;}
    ceds->state1401 = 101;
    o_outb (0x01, base+DV_CSR);		/* reset 1401 */
    for (n = 0; n < 10000; n++); 
    o_outb (0, base+DV_DMA);
    if (o_inb (base+DV_DMA) & 0xCF) return -1;
    o_outb (3, base+DV_CLK_CSR);
    o_outb (0x74, base+DV_8253_OUT);
    o_outb (0x5, base+DV_DMA);
    if ((o_inb (base+DV_DMA) & 0x4f)!=0x5) return -1;
    o_outb (0x70, base+DV_8253_OUT);
    if ((o_inb (base+DV_DMA) & 0x4f)!=0x4) return -1;
    o_outb (0x0, base+DV_DMA);
    settings = o_inb (base+DV_SW);
    PDEBUG(("1401: base is ox%x, settings is 0x%x\n",base,settings));
    while (t_irq<6) {
	if (!(settings & 1))
	    break;
	t_irq++;
	settings >>= 1;
    }
    if (t_irq >= 6) {
	PDEBUG (("1401: No interrupt set!\n"));
	ceds->irq=-1;
	return -1;
    }
    PDEBUG(("1401: Found interrupt %d\n",t_irq));
    ceds->irq = (t_irq==2) ? 9 : t_irq;

    settings = o_inb (base+DV_SW) & 0x30;
    if (settings==0x10) {
	t_dma = 3;
    } else if (settings==0x20) {
	t_dma = 1;
    }
    ceds->dma=t_dma;
    o_outb (0x8, base+DV_DMA);
    ceds->state1401 = 0;
    return 0;
}

/*----------------------------------------------------------------------*/
static int reset1401 (ced1401_str *hwp) 
{
    int n;
    int base = hwp->base_adr;

    if (ced_fake>1) {printk("1401: reset faked\n"); return 0;}
    hwp->state1401 = 100;
    o_outb (0x01, base+DV_CSR);
    schedule();             /* or "SLOW_DOWN_IO;" ? */
    o_outb (0x80, base+DV_CSR);
    o_outb (0xaa, base+DV_BUS_L);
    n = o_inb (base+DV_BUS_L);
    if (n == 0xaa)
	hwp->type = TYPE1401_STD;
    else if (n == 0x8)
	hwp->type = TYPE1401_PLUS;
    else {
	hwp->type = TYPE1401_INVALID;
	hwp->state1401 = 102;
	printk("1401: Not a valid device\n");
	return -ENODEV;
    }
    o_outb (0x10, base+DV_CSR);
    do {
	o_outb (0x8D, base);
	if ((o_inb (base+DV_CSR) & 1)) break;
	while ((o_inb (base+DV_CSR) & 128)) {
	    PDEBUG(("1401: Reset reports %2X\n",o_inb (base+DV_DIN)));
	    o_outb (0x8d, base);
	}
    } while (1);
    o_outb (0x0, base+DV_CSR);
    hwp->state1401 = 0;
    return 0;
}


/*----------------------------------------------------------------------*/
static inline int ced_charout (char ochar, ced1401_str *hwp) 
{
    int base = hwp->base_adr;

    if (o_inb (base+DV_CSR) & 0x40) {
	o_outb (ochar, ced_base);
	return 1;
    }
    return 0;
}


/*----------------------------------------------------------------------*
 * Tells the board what we're ready to wait for
 */
static inline void SetCEDIrq (ced1401_str *hwp) 
{
    enum { WAIT_READ = 2, WAIT_WRITE = 4 } crs=0;

    o_outb (0, hwp->base_adr+DV_CSR);
    cli ();
    o_outb (0x20, 0x20);
    if (hwp->inum) crs |= WAIT_READ;
    if (hwp->onum < CED1401_OUTBUF_SIZE) crs |= WAIT_WRITE;
    o_outb (crs, hwp->base_adr+DV_CSR);
    sti ();
}


/*----------------------------------------------------------------------*
 * Gets the pointer to the page table entry for the page being
 * used by the (logical) address adr.
 * Zero if invalid
 */
static inline pte_t *GetPteAdr (unsigned long adr) 
{
    pmd_t   *pmd;
    pgd_t   *pgd;

    pgd = pgd_offset (current, adr);
    if (!pgd) return 0;
    pmd = pmd_offset (pgd, adr);
    if (!pmd) return 0;
    return pte_offset (pmd, adr);
}
    
/*----------------------------------------------------------------------*
 * Builds the linear address (Phys is wrong :-) from a logical 
 * address 
 */
static unsigned long GetPhysAdr (unsigned long adr) 
{
    pte_t   *ptep, pte;

    ptep = GetPteAdr (adr);
    pte = *ptep;
    if (!pte_val (pte)) return 0;
    return pte_page (pte);
}


    
/*======================================================================*
 *
 * WRITE
 *
 * The following semantic is implemented:
 * If O_NDELAY is there, then we put stuff in the buffer, and return.
 * Otherwise, we put the process in the wait queue, and wait for write
 * to terminate.
 *
 * ===> STILL TO GO
 */

static int ced_write (struct inode *inode, struct file *file,
		      char *ostr, int count) 
{
    unsigned long   copy_size;
    unsigned long   total_bytes_written = 0;
    unsigned long   bytes_written;
    unsigned char   c;
    ced1401_str    *hwp = ((ced_file_info*)(file->private_data))->devp;

    do { /* FIX */
	bytes_written = 0;
	copy_size = (count <= CED1401_INBUF_SIZE-hwp->inum ? 
		count : CED1401_INBUF_SIZE-hwp->inum);

	PDEBUG(("1401 write: copy size is %ld\n", copy_size));

	if (!copy_size && count) {
	    current->timeout = jiffies + CED1401_TIMEOUT;
	    interruptible_sleep_on (&(hwp->ced_wait_oq));
	    if (current->signal & ~current->blocked) {
		if (total_bytes_written + bytes_written) 
		    return total_bytes_written + bytes_written;
		else 
		    return -ERESTARTSYS;
	    }
	} else {
	    bytes_written += copy_size;
	    while (copy_size-->0) {
		c = hwp->inbuf [hwp->iiptr] = get_fs_byte (ostr++);

		if (c==0x1b || c==0x9b) {
		    c = get_fs_byte (ostr++);
		    copy_size--;
		    printk ("1401: Caught Escape-Sequence: %c\n", c);
		    printk ("1401: ESCs are not supported, please use ioctl!");
		}
		else {
		    hwp->iiptr = (hwp->iiptr+1) % CED1401_INBUF_SIZE;
		    hwp->inum++;
		}
	    }
	}
        cli ();
	while (hwp->inum && 
	    ced_charout (hwp->inbuf [hwp->ioptr], hwp)) {
	    hwp->ioptr++;
	    if (hwp->ioptr==CED1401_INBUF_SIZE) hwp->ioptr = 0;
	    hwp->inum--;
        }
	sti ();
        SetCEDIrq (hwp);
 	total_bytes_written += bytes_written;
	count -= bytes_written;

	PDEBUG(("1401W:Remaining in count: %d, to write: %d\n",\
		count, hwp->inum));
    } while (count > 0);
	    
    return total_bytes_written;
}

    
/*======================================================================*
 *
 * READ
 *
 * If O_NDELAY is there, we only copy from the buffer to the user space.
 * Otherwise, we wait for data. The first byte has an indefinite timeout,
 * while the subsequent ones have CED1401_TIMEOUT.
 * Thus, a burst should be returned by a single read.
 */

  /* QQQ: georg check out this one, or use your previous one */
       /* AAA: check out what? Your code works fine, no blocking! 
        *      Try the sample_chan program with freqs up to 40000,
        *      pipe output to /dev/null and enjoy your nearly fully
        *      aware processor!! (And then remove this and the lower
        *      code 
        */

static int ced_read (struct inode *inode, struct file *file,
		     char *ostr, int count)
{
    ced1401_str    *hwp = ((ced_file_info*)(file->private_data))->devp;
    unsigned long   bytes_read = 0;
    int             prev_onum;

    if (!count) return 0;

    PDEBUG(("Got request of %d bytes (in Buf: %d, ptr:%d) CSR=%X\n",
	    count, hwp->onum, hwp->oiptr,
	    o_inb (hwp->base_adr+DV_CSR)));

    /* empty and non-blocking */
    if (!(hwp->onum) && file->f_flags & O_NONBLOCK)
      return -EAGAIN;

    /* empty: block */
    if (!(hwp->onum)) {
	current->timeout = ~0; /* infinite */
	do {
	    prev_onum=hwp->onum;
	    SetCEDIrq (hwp);
	    interruptible_sleep_on (&(hwp->ced_wait_iq));
	    if (prev_onum == hwp->onum)
	      break;
	    if (hwp->onum == CED1401_OUTBUF_SIZE)
	      break;
#if 0 /* a real performance penalty.... */
	    current->timeout = jiffies + CED1401_IN_TIMEOUT;
#else
	    break;
#endif
	} while (1);
    }

    /* if some byte is there, return them */

    if (hwp->onum) {
	cli ();
	while (count && hwp->onum) {
		put_fs_byte (hwp->outbuf [hwp->ooptr], ostr);
		ostr++; bytes_read++; count--; hwp->onum--;
		hwp->ooptr = (hwp->ooptr+1) % CED1401_OUTBUF_SIZE;
	    }
	sti ();	
	PDEBUG(("1401 read: got %ld\n",bytes_read));
    }

    if (count) SetCEDIrq (hwp); /* still left... */
    ced_oneloop(hwp);           /* what's that? */

    if (!bytes_read && (current->signal & ~current->blocked))
      return -ERESTARTSYS;

    return bytes_read;
    
}
	

/*----------------------------------------------------------------------*/
static void ced_interrupt (int irq, struct pt_regs *regs)
{
    int base = 0, flag = 0;
    ced1401_str *hwp;
    char    c;

    /* Detect the device */
    for (base=0, hwp=hwinfo; base<hwcount; base++, hwp++)
      if (hwp->irq == irq)
	break;
    if (base==hwcount) return;
	  
    PDEBUGG(("1401 Interrupt for device %d\n",base));
    base=hwp->base_adr;
    if (!(hwp->status))
      hwp->status = 5;

    if (hwp->dma_flag==4) {                     /* Is dma running ? */
	if (o_inb (base+DV_CSR)&0x10) {		/* dma ended ? */
	    disable_dma (hwp->dma);
	    o_outb (0x08, base+DV_DMA);
	    hwp->dma_flag = 0;
	    o_outb (0x20, 0x20);
	    SetCEDIrq (hwp);
	    return;
	}
	else {
	    cli ();
	    if ((o_inb (DMA_RSR) & (hwp->dma==1 ? 2 : 8))!=0) {
	        hwp->dma_page++;
		hwp->dma_addr = (hwp->dma_addr + 0xffff)
		  & (~0xffff);
		clear_dma_ff (0); /* We only use dma-chan 0-3 */
		set_dma_addr (hwp->dma, 0);
		set_dma_count (hwp->dma, 0xffff);
		enable_dma (hwp->dma);
		o_outb (0x59 + hwp->dma_direct, 
			hwp->base_adr + DV_DMA); /* Start DMA */
	    }
	    o_outb (0x20, 0x20);			/* Enabe 1401 ints */
	    o_outb (0x10, hwp->base_adr + DV_CSR);	/* DMA is running */
	    return;
	}
    }
	
    /* get data bytes */
    while (hwp->onum < CED1401_OUTBUF_SIZE 
	   && (o_inb (base+DV_CSR) & 128)) {
	c = o_inb (base+DV_DIN);
	if (hwp->status==5)
	  hwp->value = c + 1000;
	if ((unsigned char)c==0x9b) { 
	    TransferInit (hwp);
	    return;
	}
	if (c==',') c=' ';
	if (c=='\r') c='\n';
	hwp->outbuf [hwp->oiptr++] = c;
	hwp->onum++;
	if (hwp->oiptr==CED1401_OUTBUF_SIZE)
	  hwp->oiptr = 0;
	flag++;
	PDEBUGG(("1401 int: got one\n"));
    }
    if (flag) wake_up_interruptible (&(hwp->ced_wait_iq));
    flag=0;
	
    /* put data bytes */
    while (hwp->inum && 
	   ced_charout (hwp->inbuf [hwp->ioptr], hwp)) {
	hwp->ioptr++;
	if (hwp->ioptr==CED1401_INBUF_SIZE) hwp->ioptr = 0;
	hwp->inum--;
	flag++;
	PDEBUGG(("1401 int: put one\n"));
    }
    if (flag) wake_up_interruptible (&(hwp->ced_wait_oq));

    SetCEDIrq (hwp);
}


/*----------------------------------------------------------------------*/
static void ced_oneloop (ced1401_str *hwp) 
{
    int n = 0;
    char    c;
    int base = hwp->base_adr;

    cli ();
    while (hwp->onum < CED1401_OUTBUF_SIZE 
	   && (o_inb (base+DV_CSR) & 128)) {
	c = o_inb (base+DV_DIN);
	if (c==',') c=' ';
	hwp->status = 6; hwp->value = c;
	if ((unsigned char)c==0x9b) { 
	    TransferInit (hwp);
	    continue;
	}
	hwp->outbuf [hwp->oiptr++] = c;
	hwp->onum++;
	if (hwp->oiptr==CED1401_OUTBUF_SIZE)
	  hwp->oiptr = 0;
    }
    while (hwp->inum &&
	   ced_charout (hwp->inbuf [hwp->ioptr], hwp)) {
	hwp->ioptr++;
	if (hwp->ioptr==CED1401_INBUF_SIZE) hwp->ioptr = 0;
	hwp->inum--;
	n = 1;
    }
    sti ();
}

/*======================================================================*
 *
 * LSEEK
 *
 * Just an error.
 */

static  int ced_lseek (struct inode *inode, struct file *file,
	    off_t ofs, int origin) 
{
    return  -ESPIPE;
}

/*======================================================================*
 *
 * OPEN
 *
 * According to the minor number, an hwinfo structure is used.
 * filp->private_data points to it. All the buffers are shared, and
 * process have to agree to avoid contention. Just like it works with ttys
 * and serial lines. The interface is only reset on the first open.
 */

static  int ced_open (struct inode *inode, struct file *file)
{
    ced_file_info	*fip;
    ced1401_str         *hwp;
    int minor=MINOR(inode->i_rdev);

    PDEBUG(("1401 open: minor %d (hwcount %d)\n",minor,hwcount));
    if (minor >=hwcount) return -ENODEV;
    fip = (ced_file_info*) kmalloc (sizeof (ced_file_info), GFP_KERNEL);
    if (!fip) return -ENOMEM;
    file->private_data = fip;
    hwp=hwinfo+minor;
    fip->devp = hwp;
    fip->dmabuf_info = NULL; 

    if (hwp->nopen==0) {
	if (reset1401(hwp)) {
	    printk("1401 open: reset failed - can't happen\n");
	    kfree_s(fip,sizeof (ced_file_info));
	    return -ENODEV;
	}
	hwp->inum = hwp->onum = 0;
	hwp->iiptr = hwp->ioptr = 0;
	hwp->oiptr = hwp->ooptr = 0;
	hwp->status = hwp->value = 0;
    }
    hwp->nopen++;
    PDEBUG(("1401 open: %i times\n",hwp->nopen));
    MOD_INC_USE_COUNT;
    return 0;
}

/*======================================================================*
 *
 * CLOSE
 *
 * Closing is easy, just free everything we allocated.
 */

static  void ced_close (struct inode *inode, struct file *file) 
{
    dma_desc	  *dbi, *dbil;
    ced_file_info *fip=(ced_file_info*)(file->private_data);
    ced1401_str   *hwp=fip->devp;
 
    dbi = fip->dmabuf_info;
    if (!fip) return;
    while (dbi) {
	kfree_s ((char*) dbi->dma_adr, dbi->dma_size);
	dbil = dbi;
	dbi = dbi->next;
        kfree_s (dbil, sizeof (dma_desc));
    }
    kfree_s(fip,sizeof (ced_file_info));
    hwp->nopen--;
    PDEBUG(("1401 close: still opened %i times\n",hwp->nopen));
    MOD_DEC_USE_COUNT;
}



/*======================================================================*
 *
 * SELECT
 *
 * Though both are implemented, only select for read is working
 */

static int ced_select (struct inode *inode, struct file *file,
		       int sel_type, select_table *wait)
{
    ced1401_str *hwp=((ced_file_info*)(file->private_data))->devp;

    PDEBUGG(("1401 Select\n"));
    if (sel_type==SEL_IN) {
	if (hwp->onum) return 1;
	select_wait(&(hwp->ced_wait_iq), wait);
	return 0;
    }
    if (sel_type==SEL_OUT) {
	if (hwp->inum) return 1;
	select_wait(&(hwp->ced_wait_oq), wait);
	return 0;
    }
    return 0;
}


/*======================================================================*
 *
 * IOCTL
 *
 * Various functionality. Almost everything.
 *    QQQ: Georg, are you turning "102" to a symbol?
 *    AAA: Sorry, what?
 */
 
static int ced_ioctl(struct inode *inode, struct file *file,
		     unsigned int cmd, unsigned long arg)
{
    ced1401_str *hwp=((ced_file_info*)(file->private_data))->devp;

    switch(cmd) {
      case CED_RESET:
	return reset1401(hwp);
      case CED_STATUS:
 	return hwp->state1401 ?
		(hwp->state1401==103 ? 0 : 2) :
		(hwp->type ? 10 : 8);	
      case CED_REVISION: /* fix: use the structure proper */
	put_fs_long (CED_REV_MAJOR, arg);
	put_fs_long (CED_REV_MINOR, arg+4);
	put_fs_long (hwp->type, arg+8);
	return 0;
      case CED_SETADR:
	return SetupTransferAdr (file, arg);
      case CED_MALLOC:
	return AllocateDmaBuffer (file, arg);
      case CED_FREE:	
	return FreeDmaBuffer (file, arg);
      case CED_CHKADR:
	return CheckDmaAdr (file, arg);
      default:
	return -EINVAL;
    }
}


/*======================================================================*/
static struct file_operations ced_fops = {
    ced_lseek,
    ced_read,
    ced_write,
    NULL,       /* ced_readdir */  
    ced_select,
    ced_ioctl,
    NULL,       /* ced_mmap */
    ced_open,
    ced_close
};
    
    
/*======================================================================*
 *
 * init_module
 *
 * This function is buggy: it doesn't look for multiple devices. Since
 * all the rest is clean in this respect, I'll send in patches as soon
 * as possible.
 */

int init_module (void) 
{
    int base, err;
    ced1401_str *hwp=hwinfo;

    base = ced_base; /* by now */

    PDEBUG(("1401: base %x, major %d, fake %d\n",ced_base,ced_major,ced_fake));

    err = register_chrdev (ced_major, "ced1401", &ced_fops);
    if (err<0) {
	if (err == -EEXIST)  {
	    printk("1401: devices %d already present. Module not loaded.\n",
		   ced_major);
	}
	return err;
    }
    if (ced_major==0) ced_major=err;

    /*
     * Look for ports, and allow auto_assignment
     */

    base = ced_base ? ced_base : PORT_MIN;
    do {
	if ((err=check_region(base,PORT_STEP))!=0) {
	    PDEBUG(("1401: address 0x%x already in use\n",base));
	    continue;
	}
	request_region(base,PORT_STEP,"ced1401");
	hwp->base_adr=base;

	if ((err=test_card(hwp)) == 0 &&
	    (err=reset1401(hwp)) == 0)
	  break;

	release_region(base,PORT_STEP);
    }
    while (ced_base==0 && (base+=PORT_STEP)<PORT_MAX);

    if (err) {
	printk("1401: no ports found\n");
	goto fail1;
    }

    ced_base = base;

    printk ("1401: Use %s at 0x%03X, irq %d, dma %d\n", 
	(hwp->type ? "1401 plus" : "standard 1401" ),
	(unsigned)hwp->base_adr, hwp->irq, hwp->dma);
    printk ("1401: Assign major device number %d\n", ced_major);

    hwp->inbuf = (char*) kmalloc (CED1401_INBUF_SIZE, GFP_KERNEL);
    if (!hwp->inbuf) {
	printk ("1401: Unable to get mem for buffer\n");
	err = -ENOMEM;
	goto fail2;
    }
    hwp->outbuf = (char*) kmalloc (CED1401_OUTBUF_SIZE, GFP_KERNEL);
    if (!hwp->outbuf) {
	printk ("1401: Unable to get mem for buffer\n");
	err = -ENOMEM;
	goto fail3;
    }
    PDEBUG(("1401: Inbuf: %p (%db)\n",hwp->inbuf,CED1401_INBUF_SIZE));
    PDEBUG(("1401: Otbuf: %p (%db)\n",hwp->outbuf,CED1401_OUTBUF_SIZE));

    if (hwp->irq > 0) {
	err = request_irq (hwp->irq,
			   ced_interrupt, SA_INTERRUPT, "ced1401");
	if (err && ced_fake > 1) {
	    printk ("1401: Unable to use interrupt %d, error %d\n",
		    (int)hwp->irq, err);
	    goto fail4;
	}
	if (err) hwp->irq=-1; /* go on */
    }
    else {
	printk("1401: No interrupt... let's go on anyways\n");
    }
    hwp->iiptr = hwp->ioptr = hwp->inum = 0;
    hwp->oiptr = hwp->ooptr = hwp->onum = 0;
    hwp->dma_flag = 0;

    /* Ok, we managed to */
    hwcount=1; /* fix */
    return 0;

    /*
     * though we hate goto's, we have to clean up partial initialization..
     */
    fail4: kfree_s (hwp->outbuf, CED1401_OUTBUF_SIZE);
    fail3: kfree_s (hwp->inbuf, CED1401_INBUF_SIZE);
    fail2: release_region(base, 0x10);
    fail1: unregister_chrdev(ced_major, "ced1401");

    PDEBUG(("1401: Not loaded\n"));
    return err;
}

/*======================================================================*/
void cleanup_module (void) 
{

    ced1401_str *hwp=hwinfo;

    if (MOD_IN_USE) 
	printk ("1401: busy, remove delayed\n");
    else {
	PDEBUG(("1401: Unloading\n"));
	release_region (hwp->base_adr, PORT_STEP);
	unregister_chrdev (ced_major, "ced1401");
	if (hwp->irq >= 0)
	  free_irq (hwp->irq);
	kfree_s (hwp->inbuf, CED1401_INBUF_SIZE);
	kfree_s (hwp->outbuf, CED1401_OUTBUF_SIZE);
    }
    
}


/************** DMA related code is here below. Good work, Georg ;-) */
/**** ATTENTION, you are leaving the zone of tidy code ************* */
/**** QQQ: Sorry, poor Alessandro, still like that? **************** */


/* This is a workaround for a bug in 1.3.6 */

int bad_user_access_length (void) {
	printk ("1401: Bad user access length\n");
	return 0;
}


/* =====================================================================*
 *
 * CHECK_DMA_ADR
 *
 * This functions checks if a given address belongs to the memory
 * allocated for dma-transfers and returns the maximal number of bytes,
 * that might be written behind this address. E.g., the user allocated
 * 0x2000 bytes, got address 0xea0000, and now asks for 0xea1000, 
 * 0x1000 will be returned. 
 * Zero will be returned on invalid addresses.
 */

static int CheckDmaAdr (struct file *file, unsigned long adr) 
{
    ced_file_info   *fip;
    ced1401_str	    *dev;
    dma_desc        *dip;

    fip = (ced_file_info*)(file->private_data);
    dev = fip->devp;
    dip = fip->dmabuf_info;
    dev->dma_phys_adr = 0;
    while (dip) {
	if (dip->user_adr <= adr && dip->user_adr+dip->dma_size > adr)
	    break;
	dip = dip->next;
    }
    return dip ? (dip->dma_size+dip->user_adr - adr) : 0;
}
	

/* =====================================================================*
 *
 * ALLOCATE_DMA_BUFFER
 *
 * The user desires a(nother) dma-buffer, that is allocated by 
 * kmalloc (GFP_DMA) (continous and in lower 16 MB).
 * The allocated buffer is mapped to user-space by some functions
 * derived from original Linux-sources.
 * This has to be done 
 *  a) to work around a /dev/kmem - mmap -buf
 *  b) to use functions of the kernel that are not exported
 *  c) because we don't want to do a) and b) by modifying the kernel
 * 0 or <0 means error occured, user space address returned on success
 * This is the main basis of the Ced_Malloc-Call
 */

static unsigned long AllocateDmaBuffer (struct file *file, unsigned long size) {
	unsigned long	pAdr, uAdr;
	dma_desc	*dpi;
	ced_file_info	*fip;

	fip = (ced_file_info*)(file->private_data);
	if (!fip) return 0;
	dpi = kmalloc (sizeof (dma_desc), GFP_KERNEL);
	if (!dpi) return 0;
	PDEBUG (("Size requested: %ld\n", size));
	if (size > 0x1FFF0) return 0;
	pAdr = (unsigned long) kmalloc (size, GFP_DMA | GFP_BUFFER);
	uAdr = ced_mem_remap (0, (size+~PAGE_MASK) & PAGE_MASK,
		PROT_READ | PROT_WRITE, MAP_SHARED,
		pAdr & PAGE_MASK);
	if ((signed long) uAdr <= 0) {
		kfree_s (dpi, sizeof (dma_desc));
		kfree_s ((void*)pAdr, size);
		return uAdr;
	}
	PDEBUG (("Mapped physical %lX to %lX\n", pAdr, uAdr));
	uAdr |= pAdr & ~PAGE_MASK;
	dpi->dma_adr = pAdr;
	dpi->user_adr = uAdr;
	dpi->dma_size= size;
	dpi->next = fip->dmabuf_info;
	fip->dmabuf_info = dpi;
	return uAdr;
}


/* ==================================================================
 * 
 * FREE_DMA_BUFFER
 *
 * Releases memory previous allocated by AllocateDmaBuffer
 *
 */

static int FreeDmaBuffer (struct file *file, unsigned long ptr) {
	dma_desc	*dpi, **dpil;
	ced_file_info	*fip;

	fip = (ced_file_info*)(file->private_data);
	if (!fip) return 0;
	dpil = &(fip->dmabuf_info);
	for (dpi = fip->dmabuf_info; dpi; dpi=dpi->next) {
		if (dpi->user_adr==ptr) break;
		dpil = &(dpi->next);
	}
	if (!dpi) return -EINVAL;
	*dpil = dpi->next;
	kfree_s ((void*)dpi->dma_adr, dpi->dma_size);
	do_munmap (ptr & PAGE_MASK, 
		(dpi->dma_size+(~PAGE_MASK)) & PAGE_MASK);
	kfree_s (dpi, sizeof (dma_desc));
	return 0;
}
	
	
/* ================================================================
 *
 * SETUP_TRANSFER_ADR
 *
 * User tells us, which buffer to use for next dma-transfer
 * Make sure this was allocated by Ced_Malloc, as severe problems
 * might otherwise even crash you harddisk!!
 */

static int SetupTransferAdr (struct file *file, unsigned long adr) 
{
    ced_file_info   *fip;
    ced1401_str	    *dev;
    dma_desc        *dip;
    unsigned long   pAdr;

    fip = (ced_file_info*)(file->private_data);
    dev = fip->devp;
    dip = fip->dmabuf_info;
    dev->dma_phys_adr = 0;
    while (dip) {
	if (dip->user_adr <= adr && dip->user_adr+dip->dma_size > adr)
	    break;
	dip = dip->next;
    }
    if (!dip) {
	printk ("1401: User wishs DMA at %lX (Phys: %lX)\n", adr, GetPhysAdr (adr));
	printk ("1401: Invalid DMA-address requested, use Ced_Malloc\n");
	return -EINVAL;
    }
    pAdr = dip->dma_adr + (adr - dip->user_adr);
    if (dip->dma_adr > pAdr || dip->dma_adr+dip->dma_size <= pAdr) {
	printk ("1401: Got diffrent physAdr than expected");
	return -EINVAL;
    }
    dev->dma_log_adr = adr;
    dev->dma_phys_adr = pAdr;
    dev->dma_max_bytes = dip->dma_size - (pAdr - dip->dma_adr);   
    dev->dma_fs = get_fs ();
    return 0;
}
	

/* ====================================================================
 *
 * LINEAR_DMA_MOVE
 *
 * Initiate Linear DMA-Transfer, adr shows address,
 * mode is 0 for 1401->Host, 2 for Host->1401
 */

static void LinearDMAMove (ced1401_str *p, unsigned adr, int mode) {
	p->dma_page = adr >> 16;
	p->dma_addr = adr;
	p->dma_offs = adr & 0xffff;
	p->dma_size = (~(unsigned short) p->dma_offs);
	p->dma_direct = mode;
	o_outb (0x18, p->base_adr + DV_DMA);
        cli ();
	set_dma_mode (p->dma, mode ? DMA_MODE_WRITE : DMA_MODE_READ);
	o_outb (p->dma_offs, DMA_CBPFF);	/* Clear FlipFlop-Flag */
	set_dma_addr (p->dma, adr);
	set_dma_count (p->dma, p->dma_size);
	enable_dma (p->dma);
	o_outb (p->dma, DMA_WSMBR);
	o_outb (0x59 + mode, p->base_adr + DV_DMA); /* Start DMA */
        p->dma_flag = 4;
	o_outb (0x20, 0x20);				/* Enabe 1401 ints */
	o_outb (0x10, p->base_adr + DV_CSR);		/* DMA is running */
}
	
/* I know this is ugly, but things should come hard to crash this:
   It reads a char from 1401 when there *must* be a char!
*/

static inline int RdCh (ced1401_str *hwp) 
{
    long    m = 500000;
    int  base = hwp->base_adr;


    o_outb (0x10, base+DV_CSR);
    do {
	while ((o_inb (base+DV_CSR) & 1) && --m!=0)
	    ;
	if (!m) return -1;
    } while ((o_inb(base+DV_CSR) & 0x80)==0);
    return (unsigned char) o_inb (base+DV_DIN);
}


/* ================================================================
 *
 * TRANSFER_INIT
 *
 * When 1401 told us by interrupt it wants to initiate a dma-
 * transfer, this function is called: It reads the host memory
 * address and transfer mode. Then, transfer is started
 *
 */
static void TransferInit (ced1401_str *hwp) 
{
    int           mode;
    long          adr;
    char         *cp;
    int           base = hwp->base_adr;

    mode = RdCh (hwp);
    if (mode < 0) return;
    switch (mode) {
    case 0:         /* To Host */
	adr = RdCh (hwp);
	adr |= RdCh (hwp) << 8;
	if (adr < 0) return;
	if (!hwp->dma_phys_adr || 
		adr>hwp->dma_max_bytes) break;
	adr += hwp->dma_phys_adr;
	sti ();
	if (hwp->dma > 0) {
		LinearDMAMove (hwp, adr, 0);
		return;
	}
	cp = (char*) adr;
	do {
	    mode = o_inb (base+DV_CSR);
	    if (mode & 1) break;
	    if ((mode & 0x80)==0) continue;
	    *cp++ = o_inb (base+DV_DIN);
	} while (1);
	SetCEDIrq (hwp);
	return;
    case 1:         /* To 1401 */
	adr = RdCh (hwp);
	adr |= RdCh (hwp) << 8;
	if (adr < 0) return;
	if (!hwp->dma_phys_adr || adr>hwp->dma_max_bytes) break;
	adr += hwp->dma_phys_adr;
	sti ();
	if (hwp->dma > 0) {
		LinearDMAMove (hwp, adr, 2);
		return;
	}
	cp = (char*) adr;
	do {
	    mode = o_inb (base+DV_CSR);
	    if (mode & 1) break;
	    if ((mode & 0x40)==0) continue;
	    o_outb (*cp++, base+DV_DOT);
	} while (1);
	SetCEDIrq (hwp);
	return;
    default:
    }
}

/* =======================================================================
 * =======================================================================
 *
 * NOW, HERE COMES THE SECTION OF SLIGHTLY MODIFIED, ORIGINAL LINUX
 * CODE, MOSTLY DERIVED FROM KERNEL 1.3.6
 *
 * Names are usually the same as in original, with a ced_ prefix.
 * (As parameters may change in diffrent kernel version, but may
 *  be included by original names in the linux/include-files
 *
 */


/*
 *	This code is derived from linux/mm/mmap.c (1.3.7)
 *
 *      It was originally written by obz.
 */


/*
 * description of effects of mapping type and prot in current implementation.
 * this is due to the limited x86 page protection hardware.  The expected
 * behavior is in parens:
 *
 * map_type	prot
 *		PROT_NONE	PROT_READ	PROT_WRITE	PROT_EXEC
 * MAP_SHARED	r: (no) no	r: (yes) yes	r: (no) yes	r: (no) yes
 *		w: (no) no	w: (no) no	w: (yes) yes	w: (no) no
 *		x: (no) no	x: (no) yes	x: (no) yes	x: (yes) yes
 *		
 * MAP_PRIVATE	r: (no) no	r: (yes) yes	r: (no) yes	r: (no) yes
 *		w: (no) no	w: (no) no	w: (copy) copy	w: (no) no
 *		x: (no) no	x: (no) yes	x: (no) yes	x: (yes) yes
 *
 */

unsigned long ced_get_unmapped_area(unsigned long addr, unsigned long len);
int ced_remap_page_range(unsigned long from, unsigned long offset, 
	unsigned long size, pgprot_t prot);

void swap_free (unsigned long x) {
	printk ("DANGER: swapfree(%ld) is only a dummy\n", x);
}

inline pte_t * pte_alloc(pmd_t * pmd, unsigned long address)
{
        address = (address >> PAGE_SHIFT) & (PTRS_PER_PTE - 1);
        if (pmd_none(*pmd)) {
                pte_t * page = (pte_t *) get_free_page(GFP_KERNEL);
                if (page) {
                         pmd_val(*pmd) = _PAGE_TABLE | (unsigned long) page;
                         return page + address;
                }
                return NULL;
        }
	if (pmd_bad(*pmd)) {
            printk("Bad pmd in pte_alloc: %08lx\n", pmd_val(*pmd));
	    return NULL;
	}
        return (pte_t *) pmd_page(*pmd) + address;
}


pgprot_t protection_map[16] = {
	__P000, __P001, __P010, __P011, __P100, __P101, __P110, __P111,
	__S000, __S001, __S010, __S011, __S100, __S101, __S110, __S111
};

unsigned long high_memory = -1;

/*  This is derived from do_mmap, but it only fit the needs for
    memory remapping
*/

unsigned long ced_mem_remap(unsigned long addr, unsigned long len,
	unsigned long prot, unsigned long flags, unsigned long off)
{
	int error;
	struct vm_area_struct * vma;

	if ((len = PAGE_ALIGN(len)) == 0)
		return addr;

	if (addr > TASK_SIZE || len > TASK_SIZE || addr > TASK_SIZE-len)
		return -EINVAL;

	/* offset overflow? */
	if (off + len < off)
		return -EINVAL;


	/*
	 * obtain the address to map to. we verify (or select) it and ensure
	 * that it represents a valid section of the address space.
	 */

	if (flags & MAP_FIXED) {
		if (addr & ~PAGE_MASK)
			return -EINVAL;
		if (len > TASK_SIZE || addr > TASK_SIZE - len)
			return -EINVAL;
	} else {
		addr = ced_get_unmapped_area(addr, len);
		if (!addr)
			return -ENOMEM;
	}

	/*
	 * determine the object being mapped and call the appropriate
	 * specific mapper. the address has already been validated, but
	 * not unmapped, but the maps are removed from the list.
	 */

	vma = (struct vm_area_struct *)kmalloc(sizeof(struct vm_area_struct),
		GFP_KERNEL);
	if (!vma)
		return -ENOMEM;

	vma->vm_task = current;
	vma->vm_start = addr;
	vma->vm_end = addr + len;
	vma->vm_flags = prot & (VM_READ | VM_WRITE | VM_EXEC);
	vma->vm_flags |= flags & (VM_GROWSDOWN | VM_DENYWRITE | VM_EXECUTABLE);
	vma->vm_flags |= VM_MAYREAD | VM_MAYWRITE | VM_MAYEXEC;
	if (flags & MAP_SHARED) {
		vma->vm_flags |= VM_SHARED | VM_MAYSHARE;
	}
	vma->vm_page_prot = protection_map[vma->vm_flags & 0x0f];
	vma->vm_ops = NULL;
	vma->vm_offset = off;
	vma->vm_inode = NULL;
	vma->vm_pte = 0;

	do_munmap(addr, len);	/* Clear old maps */

	error = ced_remap_page_range(addr, off, len, vma->vm_page_prot);

	if (error) {
		kfree(vma);
		return error;
	}
	insert_vm_struct(current, vma);
	merge_segments(current, vma->vm_start, vma->vm_end);
	return addr;
}

/*
 * Get an address range which is currently unmapped.
 * For mmap() without MAP_FIXED and shmat() with addr=0.
 * Return value 0 means ENOMEM.
 */
unsigned long ced_get_unmapped_area(unsigned long addr, unsigned long len)
{
	struct vm_area_struct * vmm;

	if (len > TASK_SIZE)
		return 0;
	if (!addr)
		addr = TASK_SIZE / 3;
	addr = PAGE_ALIGN(addr);

	for (vmm = current->mm->mmap; ; vmm = vmm->vm_next) {
		if (TASK_SIZE - len < addr)
			return 0;
		if (!vmm)
			return addr;
		if (addr > vmm->vm_end)
			continue;
		if (addr + len > vmm->vm_start) {
			addr = vmm->vm_end;
			continue;
		}
		return addr;
	}
}


/*
 *  The following parts where derived from linux/mm/memory.c (Version 1.3.7)
 *
 *  Copyright (C) 1991, 1992, 1993, 1994  Linus Torvalds
 */

/*
 * demand-loading started 01.12.91 - seems it is high on the list of
 * things wanted, and it should be easy to implement. - Linus
 */

/*
 * Ok, demand-loading was easy, shared pages a little bit tricker. Shared
 * pages started 02.12.91, seems to work. - Linus.
 *
 * Tested sharing by executing about 30 /bin/sh: under the old kernel it
 * would have taken more than the 6M I have free, but it worked well as
 * far as I could see.
 *
 * Also corrected some "invalidate()"s - I wasn't doing enough of them.
 */

/*
 * Real VM (paging to/from disk) started 18.12.91. Much more work and
 * thought has to go into this. Oh, well..
 * 19.12.91  -  works, somewhat. Sometimes I get faults, don't know why.
 *		Found it. Everything seems to work now.
 * 20.12.91  -  Ok, making the swap-device changeable like the root.
 */

/*
 * 05.04.94  -  Multi-page memory management added for v1.1.
 * 		Idea by Alex Bligh (alex@cconcepts.co.uk)
 */


#define USER_PTRS_PER_PGD (TASK_SIZE / PGDIR_SIZE)

static inline void forget_pte(pte_t page)
{
	if (pte_none(page))
		return;
	if (pte_present(page)) {
		free_page(pte_page(page));
		if (mem_map[MAP_NR(pte_page(page))] & MAP_PAGE_RESERVED)
			return;
		if (current->mm->rss <= 0)
			return;
		current->mm->rss--;
		return;
	}
	swap_free(pte_val(page));
}

/*
 * maps a range of physical memory into the requested pages. the old
 * mappings are removed. any references to nonexistent pages results
 * in null mappings (currently treated as "copy-on-access")
 */
static inline void remap_pte_range(pte_t * pte, unsigned long address, unsigned long size,
	unsigned long offset, pgprot_t prot)
{
	unsigned long end;

	address &= ~PMD_MASK;
	end = address + size;
	if (end > PMD_SIZE)
		end = PMD_SIZE;
	do {
		pte_t oldpage = *pte;
		pte_clear(pte);
		*pte = mk_pte(offset, prot);
		if ((~mem_map [MAP_NR(offset)] & MAP_PAGE_RESERVED) &&
		     (mem_map [MAP_NR(offset)] & ~MAP_PAGE_RESERVED))
			mem_map [MAP_NR(offset)]++;
		forget_pte(oldpage);
		address += PAGE_SIZE;
		offset += PAGE_SIZE;
		pte++;
	} while (address < end);
}

static inline int remap_pmd_range(pmd_t * pmd, unsigned long address, unsigned long size,
	unsigned long offset, pgprot_t prot)
{
	unsigned long end;

	address &= ~PGDIR_MASK;
	end = address + size;
	if (end > PGDIR_SIZE)
		end = PGDIR_SIZE;
	offset -= address;
	do {
		pte_t * pte = pte_alloc(pmd, address);
		if (!pte)
			return -ENOMEM;
		remap_pte_range(pte, address, end - address, address + offset, prot);
		address = (address + PMD_SIZE) & PMD_MASK;
		pmd++;
	} while (address < end);
	return 0;
}

int ced_remap_page_range(unsigned long from, unsigned long offset, unsigned long size, pgprot_t prot)
{
	int error = 0;
	pgd_t * dir;
	unsigned long end = from + size;

	offset -= from;
	dir = pgd_offset(current, from);
	while (from < end) {
		pmd_t *pmd = pmd_alloc(dir, from);
		error = -ENOMEM;
		if (!pmd)
			break;
		error = remap_pmd_range(pmd, from, end - from, offset + from, prot);
		if (error)
			break;
		from = (from + PGDIR_SIZE) & PGDIR_MASK;
		dir++;
	}
	invalidate();
	return error;
}

