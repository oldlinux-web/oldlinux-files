/* -*-mode:C;tab-width:8;c-indent-level:4;c-label-offset:-2-*- */

/*
 * This is just for testing, if device-driver for 1401 works.
 *
 * If you give an argument on cmdline, the device won't be read
 * (useful to run seltest)
 */

#include <stdio.h>
#include <fcntl.h>
#include "ceddrv.h"

#define NODE "/dev/ced0"

int main (int argc, char **argv) 
{
    char s[80];
    int n;
    FILE *fi, *fo;
    
    fi = fopen (NODE, "r+"); if (!fi) {perror(NODE); exit(1);}
    fo = fopen (NODE, "w"); if (!fo) {perror(NODE); exit(1);}
    
    if (argc>1) {
	fclose(fi);
	fi=stdin;
	fcntl(fileno(stdin),F_SETFL,
	      fcntl(fileno(stdin),F_GETFL) | O_NDELAY);
    }

    for (n = 0; n < 3000; n+=3) {
        fprintf (fo, "DAC,0,%d;ADC,0;", n);
        fflush (fo);
		printf("Sent: %4d  ",n);
        if (fscanf (fi, "%s", s)!=1)
		  printf("Got nothing\n");
		else
		  printf("Got \"%s\"\n",s);

        if (ferror (fo))
            printf ("Fehler %d\n", ferror (fo));
    }
    fclose (fo); fclose (fi);
	exit(0);
}

