/* load.c -*-mode:C;tab-width:8;c-indent-level:4;c-label-offset:-2-*-
**
** C interface to CED 1401 device driver. 
**
** Tested with GNU C version 2.5.8, Linux 1.2.10
**
** Other versions of C
**
** Not known.
** We are pleased to help you write new interfaces, and would appreciate
** any contributions from users.
**
**********************************************************************
**
** Copyright (c) Cambridge Electronic Design 1987,1988,1990,1992
**
** Revision History
** 13-Feb-87 GPS 0.0  First version, supported MICROSOFT C 4.0
** 08-Apr-87 GPS      Lattice C added
** 04-Apr-88 GPS      \x1bB in Open1401 changed to \x01bB for MICROSOFT C 5.0
** 01-Nov-88 SEC      Added ESC sequence to flush buffers when opening 1401
** 17-Aug-90 JCN      \x1B" "B  (for example) now used for MicroSoft C 6.0
**                    open1401() returns a code. 0=ok, !0 is an error code.
**                    get1401info() added to get info on driver and 1401.
** 17-Oct-90 JCN      sCmdExt added, set by Open1401 to .CMD or .GXC
** 14-Nov-90 JCN      ld() returns 0 or an error code.
** 15-Nov-90 JCN      Function declarations brought up to modern standards.
** 12-Feb-91 JCN      toHost() & to1401() use unsigned long size and address
**                    for 1401plus. 0 byte transfers call setseg() before they
**                    return (compatible with other languages).
** 11-Mar-91 JCN 1.0  Version 1.0 released, and this comment added!
** 04-Jul-91 JCN      Esc F is sent first (host output buffer was not cleared
**                    if full) to fix 'LABO not ready for writing' problem.
** 30-Mar-92 JCN 1.1  ldcmd, ld, and open1401 have new error codes as follows: 
**                    ldcmd
**                       5: CLOAD timed out (replaces 3, 'failure to load')
**                    ld 5: ldcmd timeout code described above.
**                       6: timed out waiting ERR reply after trying to
**                          run the command to see if present.
**                    open1401
**                     104:Timed out on ERR sent after reset and get1401Info.
**                     105:Received non-zero error code from ERR. (Unlikely)
** 02/Dec/92 GPS 1.2  Tidied the code up (a great deal) and removed the need
**                    to compile with any packing options. Also sCmdExt was
**                    length 4 (should have been 5, so was corrupting memory).
** 25/May/93 JCN 1.3  Changed LdCmd to use environment variable 1401DIR to
**                    replace the default 1401 directory. This allows user to 
**                    hide 1401 commands in a subdirectory.
** 21/Jul/93 JCN 1.4  clock declared static to make it local to this unit
** 23/Jun/95 GVZ 1.0  adapted this version to GNU CC, supporting Linux with
**                    the new developed driver for 1401 using Linux 1.2.x
*/ 
#define CED_DOSCOMPAT
#include "ceddrv.h"

#include <sys/time.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <ulimit.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <ctype.h>

#include <dirent.h> /* PATH_MAX */

#define READFILEMODE "r"
#define WRITEFILEMODE "w"

#define NODE_I "/dev/ced0"
#define NODE_O "/dev/ced0"

FILE *labo = NULL;          /* used to refer to the 1401 output */
FILE *labi = NULL;          /* used to refer to the 1401 input  */
static char sCmdExt[5] = ".cmd";    /* file extension for 1401 commands */


/************************************************************************
**
** w a i t 1 4 0 1 ( )
**
** Wait for the 1401 for a specified length of time only
** Returns 0 if no characters pending before timeout in 100ths of a second
**
** ################### moved to libdos.c
*/


/************************************************************************
**
** r e s e t 1 4 0 1 ( )
**
** Send the Esc I sequence to the 1401 to reset
**
**   ############## DESTROYED ################ ioctl() is used
*/

/************************************************************************
**
** o p e n 1 4 0 1 ( )
**
** Open up the 1401 and report any errors as:
**
**   0 1401 has been opened without error
**   2 the 1401 device driver (ceddrv.o) is missing or unsuitable
**   4 not enough file handles to open the 1401. C needs 2
** 100 the 1401 is powered down
** 101 the 1401 is not connected to the interface card
** 102 indicates a serious fault in the 1401
** 103 the interface card is not present
** 104 times out waiting from ERR sent after reset and Get1401Info.
** 105 received non-zero error code from ERR. (Unlikely)
**
*/
int open1401(void)
{
    int driver;
    int bus;
    int type1401;
    int state;
    int err;
    int e0,e1;
    char buf [80];

    if ((labi=fopen(NODE_I,READFILEMODE))==NULL) 
        return(errno);      /* could not assign stream, return dos error*/

    if ((labo=fopen(NODE_O,WRITEFILEMODE))==NULL)
    { 
        fclose(labi);           /* close input file after all*/
        return(errno);      /* couldn't assign stream, return dos error */
    }
    setvbuf (labo,NULL,_IONBF,0);         /* unbuffered (send immediately) */
    setvbuf (labi,NULL,_IONBF,0);         /* unbuffered (read immediately) */

    get1401info(&driver,&bus,&type1401,&state); /* bus type not used here */
    strcpy(sCmdExt, (type1401>=1) ? ".gxc" : ".cmd"); /* set command type */

    if (driver == 1)
        err=0;                  /* hope for the best, no other info */
    else
        if (driver >= 2)        /* modern driver, so use state info */
            err = state;        /* state found out by get1401Info() */
        else
            err=2;              /* device driver too old to use */

    if (err == 0)
    {
        fputs("ERR;", labo);    /* send err to 1401 */
        if (wait1401(500))      /* apply a timeout */
        {
	    fgets (buf, 80, labi);
            if (sscanf(buf,"%d %d",&e0,&e1)!=2 || e0 || e1) 
            		/* read back error codes, see if any error */
                err = 105;
        }
        else
            err = 104;
    }

    if (err != 0)               /* if we failed to open usefully... */
        close1401();            /* ...release any file handles */

    return(err);
}

/*********************************************************************
**
** g e t 1 4 0 1 i n f o ( )
**
** Get the current state of the 1401 and the device driver
**
** driverRev : device driver revision level or -1 for not found out
** bus       : 0 for AT  , 1 for PS/2         -1 for not found out
** type1401  : 0 for 1401, 1 for 1401+         -1 for not found out 
** state     : same values as Open1401 with    -1 for not found out
** 
** Ranges of values are as follows:
**             unknown
** driverRev    -1    0      1      2
** bus          -1    0=pc   1=ps/2
** type1401     -1    0      1
** state        -1      0      2     100   101   102     103  104  105
*/
void get1401info(int *rev, int *bus, int *type1401, int *state)
{
    Ced_Revision 	ced_rev;
    int			w, werr = 0;

    *type1401 = -1; /* set unknown 1401 type */
    *state = -1;    /* set unknown state */

    if (ioctl (fileno (labo), CED_REVISION, &ced_rev)<0)
	*state = 2;
    else {
	*rev = (ced_rev.rev_major << 8) | ced_rev.rev_minor;
	*bus = 0;
	w = ioctl (fileno (labo), CED_STATUS, 0);
	if (w >= 0) {
            switch (w)
            {
             case 0:                /* no interface found */
                werr=103;
                break;

             case 1:                /* 1401 or 1401plus switched off */
                werr=100;
                break;

             case 2:                /* 1401/1401plus not connected */
                werr=101;
                break;

               case 4:              /* no response from 1401 */
                werr=102;
                *type1401=0;
                break;

             case 6:                /* no response from 1401plus */
                werr=102;
                *type1401 = 1;

             case 8:                /* 1401 is ok */
                *type1401 = 0;
                break;

             case 10:               /* 1401plus is ok */
                *type1401 = 1;
                break;

            default:                /* something wrong with the driver */
                werr = 2;
            }
            *state = werr;          /* state obtained from Esc W*/
         }
        else
            *state = 2;             /* something wrong with the driver */
    }
    return; 
}

/************************************************************************
**
** c l o s e 1 4 0 1 ( )
**
** release the handles.
** 
** destroyed, a handle is used
*/

/***********************************************************************
**
** s t a t 1 4 0 1 ( )
**
** Return true if any characters to read in the 1401 input buffer
**
** destroyed, it is now a #define
*/

/***********************************************************************
**
** s e t s e g ( )
**
** set segment in the device handler, argument must be FAR pointer
**
** destroyed, it is now a #define
*/

/***********************************************************************
**
** t o h o s t ( )
**
** transfer 1401 memory to host
** object   Far pointer to data item to be moved
** size     Number of bytes to move
** addr1401 Where in 1401 user space to move to/from
*/
int tohost(char *object, unsigned long size, unsigned long addr1401)
{
    int    e0,e1;         /* for error test */

    if (ioctl (fileno (labo), CED_CHKADR, object) < size)
	return -EINVAL;
    setseg(object);       /* tell device driver our segment */
    if ( !size )
        return(1);        /* quit with no error for 0 size */
    fprintf(labo,"TOHOST,$%lX,$%lX,$%X;ERR;",
            addr1401,size, 0);
    fscanf (labi,"%d %d",&e0,&e1);    /* so we wait til done */
    return (e0 == 0);
}

/***********************************************************************
**
** t o 1 4 0 1 ( )
**
** transfer host memory to 1401
** object   Far pointer to data item to be moved
** size     Number of bytes to move
** addr1401 Where in 1401 user space to move to/from
*/
int to1401(char *object, unsigned long size, unsigned long addr1401)
{
    int    e0,e1;         /* for error test */

    if (ioctl (fileno (labo), CED_CHKADR, object) < size)
	return -EINVAL;
    setseg(object);       /* tell device driver our segment */
    if ( !size )
        return(1);        /* quit with no error for 0 size */
    fprintf(labo,"TO1401,$%lX,$%lX,$%X;ERR;",
            addr1401,size,0);
    fscanf (labi,"%d %d",&e0,&e1);    /* so we wait til done */
    return (e0==0);
}

/**********************************************************************
**
** l d c m d ( )
**
** Load one command into the 1401
** 
** command  name of command to be loaded
**
** Loads the command from the host into the 1401. If there is no "." in
** the name the full name becomes \1401\<name><ext> where name is pointed
** to by command and <ext> is given by the global variable sCmdExt set
** in open1401() to be .CMD or .GXC
**
** Return code is:
** 0 command loaded successfully
*
* QQQ
*    should we return errno instead?
*    "permission denied" or "file not found" or "no such device" is much
*    more meaningful...  Ok, maybe I'm thinking of the unix lib, while
*    this is the compatible one.
*
** 1 file not found in host
** 2 error reading file
** 3 failed to load command to 1401 or 1401plus
** 4 out of memory in host
** 5 timed out loading command (after 2 seconds)
**
** The next few lines describe the structure (packed on 1 byte boundaries)
** that is at the start of a 1401 and 1401plus file. We have not used
** this structure in the code to avoid problems with packing, instead we
** simply use an offset into the buffer and extract the data we want.
**
**  struct thead        defines header block on command
**  {
**      char basic[5];  BASIC information
**      int  basicSz;   size as seen by BASIC
**      int  cmdSize;   size of the following info
**      int  relPnt;    relocation pointer... actual start
**      char name[8];   string holding the command name
**      char monRev;    monitor revision level
**      char cmdRev;    command revision level
**  };
*/

typedef unsigned char BLK[512]; /* one disk block */
typedef BLK *TBLKP;     /* pointer to a disk block */
#define CMDSIZE 7       /* byte number of command size in block */

int ldcmd(char *command)           
{
    char filnam[PATH_MAX];    /* space to build name in */
    FILE *pFile;              /* file for command */
    char* path1401=getenv("CED1401_LIBRARY"); /* Was "1401" in dos */

/*
 * Look for the file "as is", otherwise look in the default place,
 * otherwise add the right extension, otherwise fail.
 */

    pFile=fopen(command,"r");

    if (!pFile) {
	if (!path1401) strcpy(filnam, CED1401_LIBRARY);
	else strcpy(filnam,path1401);
	strcat(filnam,"/"); strcat(filnam,command);

	pFile=fopen(filnam,"r");
    }

    if (!pFile) {
	strcat(filnam,sCmdExt);  /* and the extension on the end */
	pFile=fopen(filnam,"r");
    }

    if (!pFile)
      return(1);                  /* failed to open the file */

    {                   /* get space for header block and read it */
    int loadSz;         /* size of image to pass */
    unsigned int nBlk;  /* number of blocks to load */
    TBLKP pBlk;         /* pBlk is our pointer */
    int  ie0,ie1;       /* for error returns */
    int iErr;           /* for returning the error code*/
    
    pBlk = (TBLKP) malloc( sizeof( BLK ) );
    if (pBlk==NULL)
      return 4;       /* not enough memory */
    
    if (fread((char*)pBlk, sizeof( BLK ), 1, pFile) != 1)
      return 2;       /* attempt to read, error if fail */
    
    loadSz = (int)((*pBlk)[CMDSIZE] + (((*pBlk)[CMDSIZE+1])<<8));
    nBlk = (loadSz + 9 + 511) / 512;    /* blocks to read */
    
    free (pBlk);		/* Now get dma-able memory */
    pBlk = (TBLKP) Ced_Malloc(sizeof( BLK )*(nBlk+1));
    if (pBlk == NULL)
      return 4;   /* check space, error if out of memory */
    fseek (pFile, 0, SEEK_SET);
    if (fread(pBlk, sizeof( BLK ), nBlk, pFile) != nBlk)
      return 2;   /* error if not read */
    
    setseg((char *)pBlk);    /* tell driver segment to use */
    fprintf(labo,"CLOAD,$%X,$%X;ERR;",9,
	    loadSz);
    iErr = 0;           /* ok so far*/
    if (wait1401(200))  /* wait no longer than 2 seconds*/
      {
	  fgets (filnam, sizeof (filnam), labi);
	  sscanf(filnam,"%d %d",&ie0,&ie1);   /* read the error codes */
	  if (ie0 || ie1) /* check for any error */
	    iErr = 3;
      }
    else
      iErr = 5;       /* timed out after 2 secs*/
    
    fclose (pFile);     /* close the file we used */
    Ced_Free((char*)pBlk);  /* release any used memory */
    return iErr;
    }
}

/***********************************************************************
**
** l d ( )
**
** Load a string of several commands into the 1401
** vl   path in which commands are found in host
** str  list of commands
**
** This routine loads a list of commands into the 1401 if they are not
** already loaded. It returns a non-zero code on the first failure or zero
** when they are all loaded successfully.
**
** If vl is empty the simple command name is passed to ldcmd which will add
** \1401\ and the correct file extension. If vl is not empty it is added as
** a prefix to each command and the file extension is added as a suffix.
** The file extension is .CMD or .GXC (depends on type of 1401).
**
** Returns:
**          0  All commands in the string loaded successfully
**   not zero  A command did not load and no further commands have loaded:
** c*256+code  <c>    is the number of the first command to fail (position
**                    in the list passed in str
**             <code> is the error code:
**                    0      Command present or loaded OK
**                    1 to 5 Error code from LdCmd
**                    6      Timed out (1/2 sec) in ERR response
*/

int ld(char *vl,char *str)
{
    char filnam[80];    /* strings to hold file name */
    char strcopy[100];  /* to hold copy of work string */
    char *cmd;          /* pointer to get command names */
    int  ie0,ie1,dum=0;   /* work variables */
    int  count = 0;     /* count commands found in str */

    for (count = 0; str [count]; count++) /* avoid changing original */
	strcopy [count] = tolower (str [count]); /* make sure lower case */
    strcopy [count] = 0;

    cmd = strtok (strcopy, ",");
    dum = 0;

    while ((cmd!=NULL) && (dum == 0)) /* got a name and no error */
    {
       count=count+1;                  /* position of command in str */
        fprintf(labo, "%s;ERR;",cmd);   /* see if loaded */
        if (wait1401(50))               /* wait up to 0.5 seconds */
        {
	    fgets (filnam, sizeof (filnam), labi);
            sscanf (filnam, "%d %d",&ie0, &ie1);  /* read errors   */
            if (ie0 == 255)             /* is command not already in 1401 */
            {
                if (*vl)                /* if vl[0] we have a path name */
                   {
                       strcpy(filnam,vl);
                       strncat(filnam, cmd, 8);
                       strncat(filnam, sCmdExt,5);
                   }
                   else
                       strcpy(filnam,cmd); /* simple name   */
         
                   dum = ldcmd(filnam); /* load command  */
            }
        }
        else
            dum = 6;                    /* timed out testing command present*/
	if (!dum)
	    cmd = strtok (NULL, ",");
    }

    return (dum ? (count*256+dum) : 0); /* report any error, or 0 if ok */
}
