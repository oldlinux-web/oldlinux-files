/* -*-mode:C;tab-width:8;c-indent-level:4;c-label-offset:-2-*-
 * 
 * ceddrv.c -- a driver for CED 1401 laboratory interface
 *
 * Copyright (C) 1995 Alessandro Rubini
 * Copyright (C) 1995 Georg v. Zezschwitz
 *
 *                    rubini@ipvvis.unipv.it
 *                    zezschwi@kogs26.informatik.uni-hamburg.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "ceddrv.h"

#define NODE "/dev/ced0"
#define S_LEN 80

/* FIX - use 1401 or 1401plus */
int main (int argc, char **argv) 
{
  FILE    *fo, *fi;
  char s[S_LEN];
  char name[S_LEN];
  int a,b,c,d;

  fi = fopen (NODE, "r+"); if (!fi) {perror(NODE); exit(1);}
  fo = fopen (NODE,  "w"); if (!fo) {perror(NODE); exit(1);}
  setvbuf(fi,NULL,_IONBF,0);
  setvbuf(fo,NULL,_IONBF,0);

  printf("Your ced has the following features:\n\n");

  fprintf(fo,"memtop,b;");
  fgets(s,S_LEN,fi);
  if (sscanf(s,"%d %d %d %d",&a,&b,&c,&d)!=4)
	printf("Got \"%s\"\n",s);
  else
	printf("Commandsize is %ik, heap is %ik, stack is %ik, user is %ik\n",
		   a/1024,b/1024,c/1024,d/1024);

  fprintf(fo,"clist;");
  while (strlen (fgets (s, S_LEN, fi)) > 3) {
	sscanf (s,"%s %d.%d",name,&a,&b);
	printf("Command %-7s  version %2d.%d\n",name,a,b);
  }
  fclose (fo); fclose (fi);
  exit(0);
}






