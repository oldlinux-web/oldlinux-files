/* -*-mode:C;tab-width:8;c-indent-level:4;c-label-offset:-2-*-
 * 
 * lib.c -- the library to ease use of /dev/ced0
 *
 * Copyright (C) 1995 Alessandro Rubini
 * Copyright (C) 1995 Georg v. Zezschwitz
 *
 *                    rubini@ipvvis.unipv.it
 *                    zezschwi@kogs26.informatik.uni-hamburg.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


