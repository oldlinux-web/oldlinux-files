/*
 * cedCfg.h -- parameters for the driver for CED 1401 laboratory interface
 *
 * Copyright (C) 1995 Georg v. Zezschwitz
 * Copyright (C) 1995 Alessandro Rubini
 *
 *                    zezschwi@kogs26.informatik.uni-hamburg.de
 *                    rubini@ipvvis.unipv.it
 */

#ifndef _CED1401CFG_H_
#define _CED1401CFG_H_


	/* Our version of "byte out" (might be outb or outb_p) */
#define o_outb outb_p	
#define o_inb inb_p

	/* How many times can we open our device */
#define CED_MAX_INODES_PER_DEVICE 10

	/* How many DMA-buffers per inode */
#define CED_MAX_DMABUF_PER_INODE 4

    /* What revision of driver ? */
#define CED_REV_MAJOR 0              /* _checkit_ */
#define CED_REV_MINOR 16             /* _checkit_ */    

#endif /* _CED1401CFG_H_ */
