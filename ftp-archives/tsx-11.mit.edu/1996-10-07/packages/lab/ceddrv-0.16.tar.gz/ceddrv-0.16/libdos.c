/* -*-mode:C;tab-width:8;c-indent-level:4;c-label-offset:-2-*-
 * 
 * libdos.c -- library for 1401 usage by Unix (with dos-compatible calls)
 *
 * Copyright (C) 1995 Georg v. Zezschwitz
 * Copyright (C) 1995 Alessandro Rubini
 *
 *                    zezschwi@kogs26.informatik.uni-hamburg.de
 *                    rubini@ipvvis.unipv.it
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/* Library for 1401 usage by Unix */

#include <stdio.h>
#include <sys/mman.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <asm/page.h>

#define CED_DOSCOMPAT 1
#include "ceddrv.h"

void *Ced_Malloc (unsigned long size) {
    return (void*) ioctl (fileno (labo), CED_MALLOC, size);	
}

void Ced_Free (void *ptr) {
    ioctl (fileno (labo), CED_FREE, ptr);
}

int wait1401(unsigned wTimeout)
{
    fd_set		readfds;
    struct timeval	timeout;
    int		rv;
    int             fd=fileno(labi);
    
    timeout.tv_sec = wTimeout / 100;
    timeout.tv_usec= (wTimeout% 100) * 10000;
    FD_ZERO (&readfds);
    FD_SET (fd, &readfds);
    rv = select (fd+1, &readfds, (fd_set*)NULL, (fd_set*)NULL,
		 &timeout);
    return rv;
}
