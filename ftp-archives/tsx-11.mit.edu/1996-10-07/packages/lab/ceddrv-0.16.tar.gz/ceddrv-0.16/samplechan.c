/* -*-mode:C;tab-width:8;c-indent-level:4;c-label-offset:-2-*-
 * 
 * samplechan.c -- a test case for dma with the ced 1401.
 *
 * Copyright (C) 1995 Georg v. Zezschwitz
 * Copyright (C) 1995 Alessandro Rubini
 *
 *                    zezschwi@kogs26.informatik.uni-hamburg.de
 *                    rubini@ipvvis.unipv.it
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

/*
 * This samples a single chan at given rate and writes values to stdout
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

#define CED_DOSCOMPAT
#include "ceddrv.h"

#define DMASIZE 16000

#define DMASIZE_H (DMASIZE/2)
#define DMASIZE_Q (DMASIZE/4)

int CheckErr (char *str) {
	int	a, b;

	fputs ("ERR;", labo);
	if (wait1401(100)) {
		fscanf (labi, "%d %d", &a, &b);
		if (a || b) {
			fprintf (stderr, 
				"%s caused error %d,%d\n", str, a, b);
			return 1;
		}
		return 0;
	}
	return 2;
}
		
int main (int argc, char **argv) 
{
	int 	a, b, lastStatus = 2;
	int	pre, count;
	double	freq, match, bestMatch;
	int	bestPre=-1, bestCount=-1;
	unsigned expectedJiffies;
	short	*arr;

	if (argc!=3) {
		fprintf (stderr, "samplechan <channel> <frequency>\n");
		return -1;
	}
	freq = atof (argv [2]);
	if (freq <= 0.0) {
		fprintf (stderr, "Frequency should be > 0!\n");
		return -1;
	}
	bestMatch = freq;
	for (pre = 2; pre < 65536; pre++) {
		count = 4e6 / (pre*freq)+0.5;
		if (count > 65535) continue;
		if (count < pre) break;
		match = fabs (4.0e6/(count*pre)-freq);
		if (match<bestMatch) {
			bestMatch = match;
			bestPre = pre; bestCount = count;
		}
	}
	if (bestPre < 0) {
		fprintf (stderr, "Cant determine good divisors!\n");
		return -1;
	}

	a = open1401 ();
	if (a) {
		fprintf (stderr, "Open1401 returned error %d\n", a);
		return -1;
	}
	a = ld ("", "adcmem");
	if (a) {
		fprintf (stderr, "Ld returned error %d\n", a);
		return -1;
	}
	arr = (short*)Ced_Malloc (DMASIZE);
	if (!arr) return -1;
	
	setseg ((char*)arr);
	fprintf (labo, "ADCMEM,I,2,0,%d,%s,65535,H,%d,%d;",
		DMASIZE, argv [1], bestPre, bestCount);
	expectedJiffies = 20 * DMASIZE_H / freq;

	if (CheckErr ("ADCMEM")) return -1;
	do {
		if (expectedJiffies && wait1401 (expectedJiffies)) {
			fprintf (stderr, "Unexpected Characters\n");
			break;
		}
		fputs ("ADCMEM,?;", labo);
		if (!wait1401 (100)) break;
		fscanf (labi, "%d", &a);
		if (a<0) {
			if (a==-128) continue;
			fprintf (stderr,
				"Aborting sampling with error %d\n", a);
			break;
		}
		if (a==0) {
			fprintf (stderr,
				"Normal end of sampling\n");	
			break;
		}
		if (a != lastStatus) {
			memset (arr, 1, DMASIZE_H);
			if (tohost ((char*)arr,DMASIZE_H,a==1?0:DMASIZE_H)==0) {
				fprintf (stderr, "Tohost-error\n");
				break;
			}
			for (b = 0; b < DMASIZE_Q; b++)
				printf ("%d (%d),", arr [b], b);
			lastStatus = a;
		}
	} while (1);
		
	fprintf (labo, "ADCMEM,K;");
	
	close1401 ();
	exit(0);
}

