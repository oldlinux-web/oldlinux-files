/*           -*-mode:C;tab-width:8;c-indent-level:4-
 *
 * Simple program to test select()
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>        /* strncmp */
#include <unistd.h>        /* select(); */
#include <sys/time.h>      /* timeval */
#include <sys/fcntl.h>     /* O_RDONLY */



int main (int argc, char **argv)
{
  fd_set selSet;
  int *fds, i, j, c;
  struct timeval to;
  char data[80];

  if (argc==1)
	{
	printf("%s: specify selectable devices on cmdline\n",argv[0]);
	exit(1);
	}


  FD_ZERO(&selSet);
  FD_SET(0,&selSet); /* stdin */

  fds=malloc(sizeof(int)*argc);
  if (!fds)
	{ perror("malloc()"); exit(1); }

  argv[0]="<stdin>";
  fds[0]=0;
  for (i=1; i<argc; i++)
	{
	if ((fds[i]=open(argv[i],O_RDONLY))<0)
	  { perror(argv[i]); exit(1); }
	}

  while(1)
	{
	to.tv_sec=5;
	for (i=1; i<argc; i++)
	  FD_SET(fds[i],&selSet);
	j=select(fds[argc-1]+1,&selSet,(fd_set *)NULL,(fd_set *)NULL,&to);
	printf("Selected %i times\n",j);
	if (j<=0) continue;

	for (i=0; j && i<argc; i++)
	  {
	  if (FD_ISSET(fds[i],&selSet))
		{
		c=read(fds[i],data,80);data[c]=0;
		printf("%s: %i - \"%s\"\n",argv[i],c,data);
		j--;
		}
	  }
		  
	}
  return 0;
}
