
/*
 * Load command(s) to 1401, if not already present
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define CED_DOSCOMPAT
#include "ceddrv.h"


int main (int argc, char **argv) 
{
	char	commands [512];
	int 	a, b;
	char	name [80];

	a = open1401 ();
	if (a) {
		printf ("Open1401 returned error %d\n", a);
		return -1;
	}
	commands [0] = 0;
	for (a = 1; a < argc; a++) {
		if (a>1) strcat (commands, ",");
		strcat (commands, argv [1]);
	}
	a = ld ("", commands);
	if (a) {
		printf ("Ld returned error %d\n", a);
		return -1;
	}
	
	fprintf(labo,"clist;");
	printf ("Now loaded commands: \n\n");
	while (strlen(fgets(commands,80,labi))>3)
	{
		sscanf(commands,"%s %d.%d",name,&a,&b);
		printf("Command %-7s  version %2d.%d\n",name,a,b);
	}
	close1401 ();
	exit(0);
}

