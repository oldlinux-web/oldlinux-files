/*
 * ceddrv.h -- the public include file
 *
 * Copyright (C) 1995 Georg v. Zezschwitz
 * Copyright (C) 1995 Alessandro Rubini
 *
 *                    zezschwi@kogs26.informatik.uni-hamburg.de
 *                    rubini@ipvvis.unipv.it
 */

#ifndef _CEDDRV_H_
#define _CEDDRV_H_

/*========== the PDEBUG symbol masks fprintf =======*/

#ifdef __KERNEL__
#  ifdef DEBUG1401M
#    define PDEBUG(data) printk data
#  else
#    define PDEBUG(data)
#  endif
#else
#  ifdef DEBUG1401P
#    define PDEBUG(data) fprintf data
#  else
#    define PDEBUG(data)
#  endif
#endif

/*========== the PDEBUGG symbol hides everything =======*/

#define PDEBUGG(data)

/*========== the following are the ioctl() commands =======*/
/*
 * I chose the '4' for the magic number.
 * Look at /usr/src/linux/MAGIC
 */

#define CED_RESET    0x3480   /* was "<ESC>-I" */
#define CED_REVISION 0x3481   /* was "<ESC>-R" */
#define CED_STATUS   0x3482   /* was "<ESC>-W" */
#define CED_SETADR   0x3483   /* was "<ESC>-L" */
#define CED_MALLOC   0x3484   /* was "<ESC>-O" */
#define CED_FREE     0x3485   /* New */
#define CED_CHKADR   0x3486   /* New */

/*================================================ library functions =======*/
#ifndef __KERNEL__

#define Ced_Reset(f)      Ced_Resetfd(fileno(f))
#define Ced_Resetfd(fd)   ioctl(fd,CED_RESET)

void *Ced_Malloc (unsigned long size);
void  Ced_Free (void *pt);

/*========== type definitons ========*/

		/* Used by ioctl (..., CED_REVISION, &return_val): */
typedef struct {
	int	rev_major, rev_minor;
	int	type_1401;
} Ced_Revision;



#ifdef CED_DOSCOMPAT
/*
 * This code is the "load.h" header by CED, it is used to provide a
 * namespace similar to the one in the dos library, to ease port of dos
 * programs.
 *
 * Part of this section is
 *
 *       Copyright Cambridge Electronic Design 1987-1992
 */

#include <stdio.h>
#include <sys/ioctl.h>

extern FILE *labo;
extern FILE *labi;

int open1401(void);

#define reset1401()  Ced_Reset(labo)
#define close1401()  (fclose(labi), fclose(labo))
#define stat1401()   wait1401(0)
#define setseg(ptr)  ioctl(fileno(labo), CED_SETADR, ptr)

/* these are still there */

void get1401info(int *rev, int *bus, int *type1401, int *state);
int ldcmd(char *command);
int ld(char *vl,char *str);
int tohost(char *object,unsigned long size,unsigned long addr1401);
int to1401(char *object,unsigned long size,unsigned long addr1401);
int wait1401(unsigned wTimeout);

/* QQQ: This stuff should rather belong to lib.c. But it needs labi and labo
       at the moment (before you make the mmap directly in the module.
       As there is momentary no single source line of "Real Unix"-Code, I
       put it here.
   AAA: Ok, this stuff is slowly growing. I'll try to keep it ordered.
       My point will become clearer when the docs will be ready.
*/

#endif /* CED_DOSCOMPAT */
#endif /* __KERNEL__ */
#endif /* _CEDDRV_H_ */
