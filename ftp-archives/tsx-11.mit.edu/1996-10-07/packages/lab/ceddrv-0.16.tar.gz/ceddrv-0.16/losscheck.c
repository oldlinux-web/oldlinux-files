/* Real silly tool to find missing kfree() in close() */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

int main()
{
int i;
  while ((i=open("/dev/ced0",1))>0)
	close(i);
  perror("/dev/ced0");
return 0;
}

