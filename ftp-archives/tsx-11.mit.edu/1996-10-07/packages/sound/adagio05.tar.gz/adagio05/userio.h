int askbool();
FILE *fileopen();
void readln();
extern char midi_file_path[];
