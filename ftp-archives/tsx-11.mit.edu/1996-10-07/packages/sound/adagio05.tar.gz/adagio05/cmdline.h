int cl_init();
char *cl_option();
char *cl_noption();
int cl_switch();
char *cl_nswitch();
char *cl_arg();
