/*
 * Handle patch loading for external synth.
 *
 * dummy version for linking pmgr
 */
#include "adagio.h"
#include "allphase.h"

struct voice_type ext_voice[1];

int
loadext(int pgm, char *data)
{
	return(0);
}
