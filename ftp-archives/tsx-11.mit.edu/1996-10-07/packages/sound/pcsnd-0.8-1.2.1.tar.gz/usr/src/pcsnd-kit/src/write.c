#include <stdio.h>
#include <stdlib.h>

main(int argc, char *argv[])
{
	FILE *f, *fw;
	char buffer[81920];
	int i;

	if (argc < 3) {
		fprintf(stderr, "more args please\n");
		return 1;
	}
	if (! (f = fopen(argv[1], "r")) ) {
		perror(argv[1]);
		return 1;
	}
	if (! (fw = fopen(argv[2], "w")) ) {
		perror(argv[2]);
		return 1;
	}
	fread(buffer, 10240, 1, f);
	i = write(fileno(fw), buffer, 10240);
	printf("%d written\n", i);
	return 0;
}
