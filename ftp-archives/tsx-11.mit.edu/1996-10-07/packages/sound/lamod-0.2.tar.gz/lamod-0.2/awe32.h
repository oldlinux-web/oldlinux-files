unsigned int AWE32RegR(int Command,int DataPort);
void AWE32RegW(int Command,int DataPort,unsigned int Data);
void AWE32RegDW(int Command,int DataPort,unsigned long Data);
unsigned long AWE32RegDR(int Command,int DataPort);
int AWE32Detect();
void InitEffect(unsigned int* Data);
void InitEffect2(unsigned int* Data);
void AWE32Wait(unsigned int Clocks);
void AWE32Init();
void SetReverbEffect(char Effect);
void SetChorusEffect(char Effect);
void EnableDRAM();
void DisableDRAM();
void CheckDRAM();
void SaveMixer();
void RestoreMixer();

