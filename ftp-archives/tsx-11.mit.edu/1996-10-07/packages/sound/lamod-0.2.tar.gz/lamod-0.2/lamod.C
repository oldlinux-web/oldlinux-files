/*-------------------------------------------------------------------------
                        Linux Awe32 MOD player 0.2

                             Jean-Michel ROY (roy@issy.cnet.fr) 12/11/95
  -------------------------------------------------------------------------*/
#include "lamod.h"

int debug = 0;

extern Tcl_Interp *interp;
extern Tk_Window mainWindow;
extern int DRAMSize;
extern unsigned int AWE32Base;

int playing = 0;

char *filename;

char *nomprog;

char TCLcmd[256];

/****************************/
/* Various constant defines */
/****************************/
#define         IRQ0                    8
#define         Left            255
#define         Center          127
#define         Right                   0

#define         Room1                   0
#define         Room2                   1
#define         Room3                   2
#define         Hall1                   3
#define         Hall2                   4
#define         Plate                   5
#define         Delay                   6
#define         PanningDelay    7

#define         Chorus1                 0
#define         Chorus2                 1
#define         Chorus3                 2
#define         Chorus4                 3
#define         FeedbackChorus          4
#define         Flanger                 5
#define         ShortDelay              6
#define         Shortdelay              7

/****************/
/* Effect list  */
/****************/  
#define         Arpeggio                     0x0
#define         SlideUp                      0x1
#define         SlideDown                    0x2
#define         TonePortamento               0x3
#define         Vibrato                      0x4
#define         TonePortamentoAndVolumeSlide 0x5
#define         VibratoAndVolumeSlide        0x6
#define         Tremolo                      0x7
#define         SampleOffset                 0x9
#define         VolumeSlideUD                0xA
#define         PositionJump                 0xB
#define         SetVolume                    0xC
#define         PatternBreak                 0xD
#define         Command                      0xE
#define         SetSpeed                     0xF


char *notes[12] = {"C-", "C#", "D-", "D#", "E-", "F-", "F#", "G-", "G#",
		      "A-", "A#", "B-"};
int vnotes[60] =
{ 1712, 1616, 1525, 1440, 1359, 1283, 1211, 1143, 1078, 1018, 961, 902,
  856,808, 762, 720, 678, 640, 604, 570, 538, 508, 480, 453,
  428, 404, 381, 360, 339, 320, 302, 285, 269, 254, 240, 226,
  214, 202, 190, 180, 170, 160, 151, 143, 135, 127, 120, 113,
  107, 101, 95, 90, 85, 76, 71, 67, 64, 60, 57, 54 };

unsigned char inotes[1713];

struct timeval tstart, tnow;

char *effets[16] = {"Arpeggio", "Slide Up", "Slide Down", "Tone Portamento",
		    "Vibrato", "Tone Portamento + Volume Slide",
		    "Vibrato + Volume Slide", "Tremolo", "Unused",
		    "SampleOffset", "Volume Slide", "Position Jump",
		    "Volume", "Pattern Break", "Command", "Speed"};

char *commandes[16] = {"Filter on/off", "Fineslide up", "Fineslide down",
		     "Glissando on/off", "Set vibrato waveform",
		     "Finetune value", "Loop pattern",
		     "Tremolo waveform", "Unused", "Retrigger sample",
		     "Fine volume slide up", "Fine volume slide down",
		     "Cut sample", "Delay sample", "Delay pattern",
		     "Invert loop"};

int min(int x, int y)
{
   if (x < y)
      return(x);
   else
      return(y);
}

/*----------------------------- M O D --------------------------------*/
FILE *Soundfile;

struct ChannelInfo
{
   unsigned long StartAddr;
   unsigned long LoopStart;
   unsigned long LoopEnd;
   unsigned long Offset;
   int Pitch;
   int Period;
   char Finetune;
   char Volume;
   char VolumeSlide;
   int PitchSlide;
   int PortamentoSpeed;
   unsigned char Reverb;
   unsigned char Chorus;
   unsigned char Pan;
   char AWE32Chan;
   char State;
   char FirstNote;
   unsigned char Env2Decay;
   unsigned char Env2Sustain;
   int MaxSlide;
   int MinSlide;
   unsigned char VibSpeed;                        // Vibrato speed
   unsigned char VibDepth;                        // Vibrato depth
   unsigned char TremSpeed;                       // Tremolo speed
   unsigned char TremDepth;                       // Tremolo depth
   unsigned int ArpeggioD[3];
   unsigned int ArpeggioP;
};

struct SampleInfo
{
   char SampleName[22];                           // padded with null bytes
   unsigned short SampleLen;                      // sample length in words
   char Finetune;
   char Volume;                                   // 0-64
   unsigned short LoopStart;                      // loop start point in words
   unsigned short LoopLen;                        // loop length in words
};

struct SampleInfoE
{
   unsigned long StartAddr;
   unsigned long LoopStart;
   unsigned long LoopEnd;
};

struct SongInfo
{
   char SongName[20];                             // song name
   SampleInfo SampleA[31];                        // 31 sample attributes
   unsigned char SongLength;                      // length of song
   char Unused;
   unsigned char PattSeq[128];                    // points to pattern sequence
   char FileID[4];                             // "M.K." for 31 sample modfiles
};
SongInfo* Header = new SongInfo;

struct Pattern
{
   unsigned char patt[2048];     // qui peut le plus ...
};

unsigned char CR = 0;                                           // Current row
unsigned char NumberOfPatterns = 0;
unsigned char NbTracks = 4;
Pattern* Patt[128];
SampleInfoE* SampleAE = new SampleInfoE[31];     // Extended sample attributes
unsigned char SongPos = 0;                       // Sequnce pattern position
char SongSpeed = 12;                              // Song speed(6 default)
char TrackTick = SongSpeed;              // Counter for Beat interrupt handler

unsigned char* VolTable = new unsigned char[65];
unsigned int* LogTable = new unsigned int[2000]; // AWE32 log rate table

ChannelInfo* Channel = new ChannelInfo[8];

unsigned char Reverb = 64;                             // Reverb effect, 0-255
unsigned char Chorus = 64;                             // Chorus effect, 0-255

/*********************************************/
/* Convert an Motorola word to an Intel word */
/*********************************************/
unsigned int cword(unsigned int BigEndian)
{
   return ((BigEndian&0xFF)<<8) | ((BigEndian&0xFF00)>>8);
}

/*********************************/
/* Sample interpolating routines */
/*********************************/
int MAXOVERSAMPLES=0;
unsigned OverSamples=0;               // number of lineary interpolated samples
                                      // to be inserted between regular samples
void CalcOverSamples(void)
{
   int Instr;
   long SampleLen;
   long AWE32FreeMem = DRAMSize*1024L, ModMem=0;

   if (MAXOVERSAMPLES > 0)
   {
      for (Instr=0;Instr<31;Instr++)
      {
	 SampleLen = cword(Header->SampleA[Instr].SampleLen);
	 if (SampleLen > 0)
	    ModMem += 2*SampleLen+8;
      }

      if (ModMem < AWE32FreeMem)
	 OverSamples = min(MAXOVERSAMPLES,(int)(AWE32FreeMem/ModMem)-1);      //max. (MAXOVERSAMPLES+1)*8363 Hz
   }
}

void SendOverSamples(long Sample1, long Sample2)
{
   int i;
   float Sample = Sample1;
   float delta = ((float)Sample2-(float)Sample1)/(float)(OverSamples+1);

   if (OverSamples > 0)
      for (i=0; i<OverSamples; i++)
      {
	 Sample += delta;
	 AWE32RegW(0x3A,0xA20,(unsigned int)(Sample+0.5));
      }
}

/******************************************/
/* Load & upload instruments to the AWE32 */
/******************************************/
void LoadInstruments()
{
   long AWE32FreeMem = DRAMSize * 1024L;
   long BufferSize = 32768;
   long SampleLen,LoopStart,LoopLen,LoopEnd;
   long CurrentAddr = 0x200000;
   long Samples;
   long CurrentSample;
   long LastSample=0;
   char* SampleBuffer = new char[BufferSize];
   char LoopSample1=0x00,LoopSample2;
   
   CalcOverSamples();

   cout << "Uploading instruments to AWE32 DRAM: " << endl;
   EnableDRAM();
   AWE32RegDW(0x36,0xA20,CurrentAddr);                // write start address
   
   sprintf(TCLcmd, "set type {Type: %c%c%c%c}; wm title .p {%s}; initlig %d",
	   Header->FileID[0], Header->FileID[1],
	   Header->FileID[2], Header->FileID[3], Header->SongName, NbTracks);
   if (TclInterface::TclEval(interp, TCLcmd) == TCL_ERROR)
   {
      cerr << "TclInterface::Initialize TclInterface::TclEval failed : "
	   << interp->result << endl;
   }

   for(int Instr=0; Instr<31; Instr++)                // Load 31 samples
   {
      SampleLen = cword(Header->SampleA[Instr].SampleLen)*2L;
      SampleAE[Instr].StartAddr = 0;    // Start address 0 will not play sample
      if(SampleLen == 0)                             // Is this a sample?
	 continue;
		
      for(int m=0; m<22; m++)
      {
	 if(Header->SampleA[Instr].SampleName[m] < 32)
	 {
	    Header->SampleA[Instr].SampleName[m] = 0;
	    break;
	 }
	 if(m == 21)
	    Header->SampleA[Instr].SampleName[m] = 0;
      }

      sprintf(TCLcmd, ".s.f.l insert end {%02d: %-22s %6d}",
	      Instr+1, Header->SampleA[Instr].SampleName, SampleLen);
      if (TclInterface::TclEval(interp, TCLcmd) == TCL_ERROR)
      {
	 cerr << "TclInterface::Initialize TclInterface::TclEval failed : "
	      << interp->result << endl;
      }

      if(AWE32FreeMem < (SampleLen+8))
      {
	 fseek(Soundfile,SampleLen,SEEK_CUR);
	 cout << "ERROR: Not enough AWE32 memory!" << endl;
	 continue;
      }

      LoopStart = cword(Header->SampleA[Instr].LoopStart)*2L;
      LoopLen = cword(Header->SampleA[Instr].LoopLen)*2L;
      LoopEnd = LoopStart+LoopLen;

      if((Header->SampleA[Instr].Finetune &8) != 0)           // Expand finetune signed nibble to signed char
	 Header->SampleA[Instr].Finetune |= 0xF0;

      CurrentSample = 0;

      if(LoopLen < 4)
      {
	 LoopStart = SampleLen+1;                     // Never find loopstart
	 LoopSample1 = 0;                             // Smooth end to 0
	 LoopEnd = SampleLen;
      }

      do
      {
	 if((CurrentSample+BufferSize) >= SampleLen)
	    Samples = SampleLen-CurrentSample;
	 else
	    Samples = BufferSize;

	 fread(SampleBuffer,1,Samples,Soundfile); // read sample data from file

	 if(LoopStart < (CurrentSample + Samples)) // Find first sample in loop
	 {
	    if(LoopStart > CurrentSample)
	       LoopSample1 = SampleBuffer[LoopStart-CurrentSample];
	 }

	 if(LoopEnd <= (CurrentSample + Samples))   // Find last sample in loop
	 {
	    if(LoopEnd >= CurrentSample)
	    {
	       LoopSample2 = SampleBuffer[LoopEnd-CurrentSample-9];
	       for(int i=0; i<8; i++)
		  SampleBuffer[LoopEnd-CurrentSample-8+i] =
		     LoopSample2+(i+1)*(LoopSample1-LoopSample2)/8;
					}
	 }

	 if (CurrentSample > 0)      // send oversamples between last sample of
	    SendOverSamples(LastSample<<8,SampleBuffer[0]<<8);      // previous buffer and first sample of current buffer

	 for(long i=0; i<Samples; i++)
	 {
	    AWE32RegW(0x3A,0xA20,SampleBuffer[i]<<8);   // upload data to AWE32 DRAM
	    if (i != Samples-1)                      // last sample in buffer ?
	       SendOverSamples(SampleBuffer[i]<<8,SampleBuffer[i+1]<<8);       // send oversamples between Buffer[i] and Buffer[i+1]
	    if((CurrentSample + i) == LoopStart)
	       LoopSample1 = SampleBuffer[i];
	 }

	 CurrentSample += Samples;
	 LastSample = SampleBuffer[Samples-1];
      }
      while(CurrentSample != SampleLen);
      
      SampleAE[Instr].StartAddr = CurrentAddr;

      if(LoopLen < 4)
      {
	 for(int i=0; i<8; i++)                           // Anticlick samples
	    AWE32RegW(0x3A,0xA20,0);
	 SampleAE[Instr].LoopStart = SampleLen*(OverSamples+1)-OverSamples+CurrentAddr;
	 SampleAE[Instr].LoopEnd = SampleLen*(OverSamples+1)-OverSamples+5+CurrentAddr;
	 CurrentAddr += SampleLen*(OverSamples+1)-OverSamples + 8;
	 AWE32FreeMem -= SampleLen*(OverSamples+1)-OverSamples + 8;
      }
      else
      {
	 SampleAE[Instr].LoopStart = LoopStart*(OverSamples+1)+CurrentAddr;
	 SampleAE[Instr].LoopEnd = (LoopStart+LoopLen)*(OverSamples+1)+CurrentAddr-3;
	 CurrentAddr += SampleLen*(OverSamples+1);
	 AWE32FreeMem -= SampleLen*(OverSamples+1);
      }
   }

   delete SampleBuffer;
   DisableDRAM();
}

/******************************************/
/* Play a note with settings from Chan[i] */
/******************************************/
void PlayNote(ChannelInfo* Chan, int i)
{
   char GChan = Chan[i].AWE32Chan;

   AWE32RegW(0xA0+GChan,0xA20,0x807F);            // envelope 2 sustain & decay
   AWE32RegW(0x00+GChan,0xE20,0xE000);                             // pitch

   AWE32RegW(0xA0+GChan,0xA20,0x80);              // envelope 2 sustain & decay
   AWE32RegDW(0x60+GChan,0x620,0xFFFF);

   AWE32RegW(0x80+GChan,0xA20,0x8000);                 // envelope 2 delay
   AWE32RegW(0x80+GChan,0xA22,0x7F7F);              // envelope 2 hold & attack
   AWE32RegW(0xC0+GChan,0xA20,0x8000);                     // envelope 1 delay
   AWE32RegW(0xC0+GChan,0xA22,0x7F7F);             // envelope 1 hold & attack
   AWE32RegW(0xE0+GChan,0xA20,0x7F);              // envelope 2 sustain & decay

   AWE32RegW(0x00+GChan,0xE20,Chan[i].Pitch);             // pitch
   unsigned char AWE32Vol = VolTable[Chan[i].Volume];

   AWE32RegW(0x20+GChan,0xE20,0xFF00 | AWE32Vol);     // filter cutoff & volume
   AWE32RegW(0xA0+GChan,0xA22,0x8000);                     // LFO1 delay
   AWE32RegW(0xE0+GChan,0xA22,0x8000);                     // LFO2 delay
   AWE32RegW(0x40+GChan,0xE20,0);               // envelope 2 to pitch & filter
   AWE32RegW(0x60+GChan,0xE20,0);                    // LFO1 to pitch & filter
//     AWE32RegW(0x80+GChan,0xE20,0x7F);                       // LFO1 frequency & to volume -----------------------------------
   AWE32RegW(0x80+GChan,0xE20,(Chan[i].TremDepth << 8) | Chan[i].TremSpeed);
   AWE32RegW(0xA0+GChan,0xE20,(Chan[i].VibDepth << 8) | Chan[i].VibSpeed);
   AWE32RegDW(0x20+GChan,0x620,(Chan[i].Reverb<<8) | (AWE32RegDR(0x20+GChan,0x620)&0xFFFF0000));
   long TempPan = Chan[i].Pan;
   TempPan <<= 24L;
   AWE32RegDW(0xC0+GChan,0x620,TempPan | Chan[i].LoopStart);

   TempPan = Chan[i].Chorus;
   TempPan <<= 24L;
   AWE32RegDW(0xE0+GChan,0x620,TempPan | Chan[i].LoopEnd);

   AWE32RegDW(0x00+GChan,0xA20,Chan[i].StartAddr+Chan[i].Offset);
   AWE32RegW(0xA0+GChan,0xA20,Chan[i].Env2Sustain<<8 | Chan[i].Env2Decay);
}

void NoteOff(char Channel)
{
   AWE32RegW(0xA0+Channel,0xA20,0x807F);
   AWE32RegW(0xE0+Channel,0xA20,0x807F);
}

/**********************************************/
/* Calculate the AWE32 logarithmic rate table */
/**********************************************/
void CalcLogTable()
{
   long Frequency;
   for(int k=75;k<2000;k++)
   {
      Frequency = (OverSamples+1)*8363L*428L/k;
      LogTable[k] = int(log(Frequency)*5909.27-5850.98);
   }

   VolTable[0] = 127;
   for(k=1; k<65; k++)
      VolTable[k] = char(127 - log(k)*26.6899);

}
/**********************/
/* Beat function data */
/**********************/
   unsigned char CP;                                // Current pattern
   char Effect;                                     // Effect type
   unsigned char EffectD, EffectDx;                           // Effect data
   unsigned char NewSongPos = 255;
   unsigned char NewCR = 0;
   int Finetune;
   char i;                                          // Channel number in loop
   char l;
   unsigned char s;                                 // Sample to play
   unsigned char mems[8];
   int pers[8];
   char effs[8];
   int Period;                                      // Note to play
   int PrevPeriod;
   int     StackSeg;
   int     StackPtr;
   int     StackData[1024];
   char TempSTR[8];
   unsigned int TempTimer;
   int pos;
   char *note_template = "C-C#D-D#E-F-F#G-G#A-A#B-";
/******************************************************/
/* IRQ0 Timer interrupt handler                       */
/*                                                    */
/* Counts TrackTick down to 0 and then plays a row    */
/******************************************************/
void Beat(int sig)
{
   int min, sec;

   CP = Header->PattSeq[SongPos];// Fetch current pattern from pattern sequence
   TrackTick -= 1;            // TrackTick is a counter based on the song speed

   if(TrackTick != 0)
   {
      if( TrackTick % 2)
      {
      for(i=0; i<NbTracks; i++)
      {
	 if(Channel[i].VolumeSlide != 0)
	 {
	    Channel[i].Volume += Channel[i].VolumeSlide;
	    if(Channel[i].Volume > 64)
	       Channel[i].Volume = 64;         // Don't slide higher than 64
	    if(Channel[i].Volume < 0)          // Don't slide less than 0
	       Channel[i].Volume = 0;
	    AWE32RegW(0x20+Channel[i].AWE32Chan,0xE20,0xFF00 | VolTable[Channel[i].Volume]);
	 }
	 if(Channel[i].PitchSlide != 0)
	 {
	    Channel[i].Period += Channel[i].PitchSlide;
	    if(Channel[i].Period > Channel[i].MinSlide)
	       Channel[i].Period = Channel[i].MinSlide;
	    if(Channel[i].Period < Channel[i].MaxSlide)
	       Channel[i].Period = Channel[i].MaxSlide;
	    AWE32RegW(Channel[i].AWE32Chan,0xE20,LogTable[Channel[i].Period + Channel[i].Finetune]);
	 }
	 if(Channel[i].ArpeggioD[0] != 0)
	 {
	    AWE32RegW(Channel[i].AWE32Chan,0xE20,LogTable[Channel[i].ArpeggioD[Channel[i].ArpeggioP] + Channel[i].Finetune]);
	    if(Channel[i].ArpeggioP == 2)
	       Channel[i].ArpeggioP = 0;
	    else
	       Channel[i].ArpeggioP++;
	 }
      }
      }
      return;                        // Don't play new row yet
   }
   TrackTick = SongSpeed;
   
   for (i=0; i<NbTracks; i++)
   {
      if(Channel[i].VibSpeed != 0)
	 AWE32RegW(0xA0+Channel[i].AWE32Chan,0xE20,0);   // stop vibrating
      if(Channel[i].TremSpeed != 0)
	 AWE32RegW(0x80+Channel[i].AWE32Chan,0xE20,0);   // stop tremolo
      if(Channel[i].ArpeggioD[0] != 0)
	 AWE32RegW(Channel[i].AWE32Chan,0xE20,LogTable[Channel[i].Period + Channel[i].Finetune]);
      Channel[i].ArpeggioD[0] = 0;

      pos = ((CR * NbTracks) + i) * 4;
      s = Patt[CP]->patt[pos] & 0xF0 |
	 (Patt[CP]->patt[pos+2] & 0xF0) >> 4;
      Period = ((Patt[CP]->patt[pos] & 0x0f) << 8) |
	 (Patt[CP]->patt[pos+1] & 0xFF);
      EffectD = Patt[CP]->patt[pos+3];
      Effect = Patt[CP]->patt[pos+2] & 0xF;
      Period &= 0xFFF;                            // Throw away the effect type

      if(Period == 0)
	 s = 0;

      if(s != 0)
      {
	 Channel[i].State = 1;
	 s -= 1;
	 Channel[i].Volume = Header->SampleA[s].Volume;
	 Channel[i].StartAddr = SampleAE[s].StartAddr;
	 Channel[i].LoopStart = SampleAE[s].LoopStart;
	 Channel[i].LoopEnd = SampleAE[s].LoopEnd;
	 Channel[i].Env2Decay = 0x7F;                // Decay time set to zero
	 Channel[i].Env2Sustain = 0x7F;                  // Max sustain
	 Finetune = Header->SampleA[s].Finetune;
	 Channel[i].Pitch = LogTable[Period+Finetune];           // AWE32 logarithmic rate
	 //Channel[i].Period = Period;
	 Channel[i].Finetune = Finetune;
	 Channel[i].VibSpeed = 0;
	 Channel[i].TremSpeed = 0;
	 Channel[i].Offset = 0;
      }

      if(Period == 0)
	 Channel[i].State = 0;
      
      if(Finetune && 8)                     // Finetune is a 4-bit signed value
	 Finetune |= 0xFFF0;                        // Expand sign to 16-bit

      Channel[i].Reverb = Reverb;
      Channel[i].Chorus = Chorus;
      Channel[i].VolumeSlide = 0;
      Channel[i].PitchSlide = 0;

      switch(Effect)                           // Find out which effect we have
      {
      case Arpeggio:
	 if(EffectD != 0)
	 {
	    Channel[i].ArpeggioP = 1;
	    Channel[i].ArpeggioD[0] = Channel[i].Period;
	    Channel[i].ArpeggioD[1] = Channel[i].Period;
	    Channel[i].ArpeggioD[2] = Channel[i].Period;
	    for(l=0; l<((EffectD>>4)&0xF); l++)
	       Channel[i].ArpeggioD[1] -= Channel[i].ArpeggioD[1]>>4;
	    for(l=0; l<(EffectD&0xF); l++)
	       Channel[i].ArpeggioD[2] -= Channel[i].ArpeggioD[2]>>4;
	 }
	 break;
      case SlideUp:
	 Channel[i].PitchSlide = - EffectD;
	 Channel[i].MaxSlide = 113;
	 Channel[i].MinSlide = 856;
	 break;
      case SlideDown:
	 Channel[i].PitchSlide = EffectD;
	 Channel[i].MaxSlide = 113;
	 Channel[i].MinSlide = 856;
	 break;
      case TonePortamento:
	 if(EffectD == 0)
	 {
	    Channel[i].PitchSlide = Channel[i].PortamentoSpeed;
	    break;
	 }
	 if(Period != 0)
	 {
	    if(Channel[i].Period > Period)
	    {
	       Channel[i].PitchSlide =  -1 * EffectD;
	       Channel[i].MaxSlide = Period;
	    }
	    else
	    {
	       Channel[i].MinSlide = Period;
	       Channel[i].PitchSlide = EffectD;
	    }
	 }
	 else
	 {
	    if(Channel[i].PortamentoSpeed > 0)
	       Channel[i].PitchSlide = EffectD;
	    else
	       Channel[i].PitchSlide = -1 * EffectD;
	 }
	 Channel[i].PortamentoSpeed = Channel[i].PitchSlide;
	 break;
      case Vibrato:
	 if(EffectD & 0xF != 0)
	    Channel[i].VibSpeed = (EffectD >> 4)*16+7;
	 if(EffectD & 0xF0 != 0)
	    Channel[i].VibDepth = EffectD & 0xF;
	 if(Channel[i].State == 0)
	    AWE32RegW(0xA0+Channel[i].AWE32Chan,0xE20,(Channel[i].VibDepth << 8) | Channel[i].VibSpeed);
	 break;
      case Tremolo:
	 if(EffectD & 0xF != 0)
	    Channel[i].TremSpeed = (EffectD >> 4)*16+7;
	 if(EffectD & 0xF0 != 0)
	    Channel[i].TremDepth = EffectD & 0xF;
	 if(Channel[i].State == 0)
	    AWE32RegW(0x80+Channel[i].AWE32Chan,0xE20,(Channel[i].TremDepth << 8) | Channel[i].TremSpeed);
	 break;
      case SampleOffset:
	 Channel[i].Offset = (EffectD << 8L)*(OverSamples+1);
	 break;
      case TonePortamentoAndVolumeSlide:
      case VibratoAndVolumeSlide:
      case VolumeSlideUD:
	 if((EffectD & 0xF0) == 0)
	    Channel[i].VolumeSlide = - EffectD;
	 if((EffectD & 0xF) == 0)
	    Channel[i].VolumeSlide = EffectD>>4;
	 break;
      case PositionJump:
	 NewSongPos = EffectD;
	 break;
      case SetVolume:
	 Channel[i].Volume = EffectD;
	 if(Channel[i].State == 0)
	    AWE32RegW(0x20+Channel[i].AWE32Chan,0xE20,0xFF00 | VolTable[EffectD]);
	 break;
      case PatternBreak:
	 NewCR = EffectD;
         NewSongPos = SongPos + 1;
	 break;
      case SetSpeed:
	 if(EffectD < 32)
	    SongSpeed = EffectD * 2;
	 else
	    SongSpeed = (60000 / (EffectD * 4) + 5) /10 ;
	 break;
      case Command:
	 EffectDx = EffectD & 0xF;
	 switch ( EffectD >> 4)
	 {
	 case 10 :                             // Fine volume slide up
	    Channel[i].Volume += EffectDx;
	    if(Channel[i].Volume > 64)
	       Channel[i].Volume = 64;         // Don't slide higher than 64
	    if(Channel[i].Volume < 0)          // Don't slide less than 0
	       Channel[i].Volume = 0;
	    if(Channel[i].State == 0)
	       AWE32RegW(0x20+Channel[i].AWE32Chan,0xE20,0xFF00 | VolTable[EffectD]);
	    break;
	 case 11 :                             // Fine volume slide down
	    Channel[i].Volume -= EffectDx;
	    if(Channel[i].Volume > 64)
	       Channel[i].Volume = 64;         // Don't slide higher than 64
	    if(Channel[i].Volume < 0)          // Don't slide less than 0
	       Channel[i].Volume = 0;
	    if(Channel[i].State == 0)
	       AWE32RegW(0x20+Channel[i].AWE32Chan,0xE20,0xFF00 | VolTable[EffectD]);
	    break;
	 default:
	    printf("Effect %s (data=%02x) not implemented\n", commandes[EffectD >> 4], EffectDx); 
	 }
      }
      if (Effect != TonePortamento && Period != 0)
	 Channel[i].Period = Period;
   }

   l = 0;
   for(i=0; i<NbTracks; i++)
   {
      while( l != 30 )
      {
	 if((AWE32RegR(0xA0+l,0xA20) >> 15) == 1)
	    if((AWE32RegDR(0x60+l,0x620) >> 16) == 0)
	       break;
	 l++;
      }
      if(l == 30)
	 break;

      if(Channel[i].State == 1)
      {
	 if(Channel[i].FirstNote != 1)
	    NoteOff(Channel[i].AWE32Chan);
	 else
	    Channel[i].FirstNote = 0;
	 
	 Channel[i].AWE32Chan = l;
	 if(Channel[i].StartAddr != 0)
	    PlayNote(Channel, i);
	 Channel[i].State = 0;
	 l++;
      }
   }
   
   gettimeofday(&tnow, NULL);
   min = (tnow.tv_sec - tstart.tv_sec) / 60;
   sec = (tnow.tv_sec - tstart.tv_sec) % 60;

   sprintf(TCLcmd, "set col %02d;set row %02d/%02d;set pattern %02d;set bpm %03d;set heure %02d:%02d",
	   CR, SongPos, Header->SongLength-1, CP, 1500 / SongSpeed, min, sec);
   if (TclInterface::TclEval(interp, TCLcmd) == TCL_ERROR)
   {
      cerr << "TclInterface::Initialize TclInterface::TclEval failed : "
	   << interp->result << endl;
   }

   for (i=0; i<NbTracks; i++)
   {
      pos = ((CR * NbTracks) + i) * 4;
      s = Patt[CP]->patt[pos] & 0xF0 |
	 (Patt[CP]->patt[pos+2] & 0xF0) >> 4;
      Period = ((Patt[CP]->patt[pos] & 0x0f) << 8) |
	    (Patt[CP]->patt[pos+1] & 0xFF);
      EffectD = Patt[CP]->patt[pos+3];
      Effect = Patt[CP]->patt[pos+2] & 0xF;
      Period &= 0xFFF;                         // Throw away the effect type

      if (s != 0 && s != mems[i])
      {
	 mems[i] = s;
	 sprintf(TCLcmd, "set nos%d {[%2d] %-22s}", i, s, Header->SampleA[s-1].SampleName);
	 if (TclInterface::TclEval(interp, TCLcmd) == TCL_ERROR)
	 {
	    cerr << "TclInterface::Initialize TclInterface::TclEval failed : "
		 << interp->result << endl;
	 }
      }

      if (Period != pers[i])
      {
	 pers[i] = Period;
	 if (Period == 0)
	    sprintf(TCLcmd, "set not%d {   }", i);
	 else
	    sprintf(TCLcmd, "set not%d {%s%d}", i,
		 notes[inotes[Period]%12], inotes[Period]/12);
	 if (TclInterface::TclEval(interp, TCLcmd) == TCL_ERROR)
	 {
	    cerr << "TclInterface::Initialize TclInterface::TclEval failed : "
		 << interp->result << endl;
	 }
      }

      if (Effect != 0)
      {
	 if (Effect == 14) 
	    sprintf(TCLcmd, "set eff%d {%s : %02x}", i, commandes[EffectD >> 4], EffectD & 0xF);
	 else
	    sprintf(TCLcmd, "set eff%d {%s : %02x}", i, effets[Effect], EffectD);
	 if (TclInterface::TclEval(interp, TCLcmd) == TCL_ERROR)
	 {
	    cerr << "TclInterface::Initialize TclInterface::TclEval failed : "
		 << interp->result << endl;
	 }
      }
   }
   CR++;
   if(NewSongPos != 255)
   {
      SongPos = NewSongPos;
      CR = NewCR;
      NewSongPos = 255;
      NewCR = 0;
   }
   else if (CR == 64)
   {
      CR = 0;
      SongPos++;
      if (SongPos >= Header->SongLength)
	 SongPos = 0;
   }

   return;
}
/*--------------------------- /dev/sequencer ----------------------------*/
extern unsigned char _seqbuf[];
extern int _seqbuflen, _seqbufptr;
unsigned char dump_enabled=1;
SEQ_DEFINEBUF (2048);
int seqfd;
long next_time, tick_duration;
char buf[8];

/* SEQBUF DUMP
 * borrowed from gmod 
 * this dumps all the current 
 * sequencer information to /dev/sequencer
 */

void seqbuf_dump ()
{
   int result;
   while (_seqbufptr && dump_enabled)
   {
      if ((result = write (seqfd, _seqbuf, _seqbufptr)) == -1)
      {
         perror ("write /dev/sequencer");
         exit (-1);
      }
      else if (result != _seqbufptr)
      {
         _seqbufptr -= result;
         memmove (_seqbuf, &(_seqbuf[result]), _seqbufptr);
      }
      else
         _seqbufptr = 0;
   }
}

int StartPlay(ClientData, Tcl_Interp *interp, int argc, char *argv[])
{
   next_time = 0;
   playing = 1;
   SEQ_START_TIMER();
   gettimeofday(&tstart, NULL);
   return(0);
}

int StopPlay(ClientData, Tcl_Interp *interp, int argc, char *argv[])
{
   playing = 0;
   SongPos = 0;
   CR = 0;
   AWE32Init();
   return(0);
}

int Quitter(ClientData, Tcl_Interp *interp, int argc, char *argv[])
{
   AWE32Init();
   exit(0);
}
/*--------------------------------------------------------------------*/

int main(int argc, char **argv)
{
   nomprog = argv[0];
   filename = argv[1];
   TclInterface tci;
   
   for(int in=0; in<1713; in++)
      inotes[in] = 0;
   for(in=0; in<5; in++)
      for(int jn=0; jn<12; jn++)
	 inotes[vnotes[jn+(in*12)]] = jn+(in*12);

   iopl(3);

   if (AWE32Detect() !=0)
   {
      printf("Impossible de d�tecter l'adresse de base\n");
      exit(-1);
   }
   AWE32Init();

   CheckDRAM();
   if(DRAMSize == 0)
   {
      printf("Your AWE32 doesn't have any RAM");
      exit(0);
   }

   SaveMixer();
   SetReverbEffect(Room1);
   SetChorusEffect(Chorus3);

   cout << "SoundBlaster AWE32 found at " << hex << AWE32Base << "H";
   cout << " with " << dec << DRAMSize << "kB onboard DRAM" << endl;
   cout << endl;

/*----------------------------- M O D --------------------------------*/
   
   if((argc < 2) || (argc > 3))               // first argument is our program
   {
      printf("Usage: awe32mod example.mod [/on]\n\t/o  - automatic oversampling (default)\n\t/on - n-times oversampling (max. 5)");         // second argument is sound file
      exit(-1);
   }

   if((argc == 3) && (strncmp(argv[2],"/o",2) == 0))
   {
      MAXOVERSAMPLES = min(4,atoi(argv[2]+2));
      if (MAXOVERSAMPLES == 0)
	 MAXOVERSAMPLES = 4;
   }

   if((Soundfile = fopen(filename,"rb")) == NULL)           // open sound file
   {
      printf("Could not open file : %s\n", filename);       // file not found
      exit(-1);
   }

   if (tci.Initialize(nomprog) == TCL_ERROR)
   {
      printf("TCL Initialize Error\n");
      exit(-1);
   }
   
   fread(Header,1,sizeof(SongInfo),Soundfile);         // read header
   if(!strncmp(Header->FileID,"M.K.",4) || !strncmp(Header->FileID,"FLT4",4))
      NbTracks = 4;
   else
      if(!strncmp(Header->FileID,"6CHN",4))
	 NbTracks = 6;
      else
	 if(!strncmp(Header->FileID,"8CHN",4))
	    NbTracks = 8;
	 else
	 {
	    printf("File not a known sound module : %c%c%c%c\n",
		   Header->FileID[0], Header->FileID[1],
		   Header->FileID[2], Header->FileID[3]);
	    exit(0);
	 }
   int LgPattern = 64 * 4 * NbTracks;
   printf("LgPattern=%d\n", LgPattern);
   
   for(int k=0; k<128; k++)
   {
      if (Header->PattSeq[k] > NumberOfPatterns)
	 NumberOfPatterns = Header->PattSeq[k];     // get number of patterns in song
   }
printf("%d Patterns\n", NumberOfPatterns);
   NumberOfPatterns++;

   for(k=0; k<NumberOfPatterns; k++)
   {
      Patt[k] = new Pattern;
      fread(Patt[k],1,LgPattern,Soundfile);
   }

   LoadInstruments();

   fclose(Soundfile);
   
   Channel[0].Pan = Left;
   Channel[1].Pan = Right;
   Channel[2].Pan = Right;
   Channel[3].Pan = Left;
   for(int i=0; i<NbTracks; i++)
   {
      Channel[i].State = 0;
      Channel[i].FirstNote = 1;
      Channel[i].VolumeSlide = 0;
      Channel[i].PitchSlide = 0;
      Channel[i].MaxSlide = 113;
      Channel[i].MinSlide = 856;
      Channel[i].ArpeggioD[0] = 0;
   }
   CalcLogTable();

   if ((seqfd = open ("/dev/sequencer", O_RDWR, 0)) == -1)
   {
      perror ("/dev/sequencer");
      exit(-1);
   }
   ioctl (seqfd, SNDCTL_SEQ_SYNC, 0);

   next_time = 0;
   tick_duration = 1;

   while(1)
   {
      if (playing)
      {
	 next_time += tick_duration;
	 SEQ_WAIT_TIME ((long) next_time);
	 SEQ_ECHO_BACK((long) 0);
	 SEQ_DUMPBUF();
	 if (read(seqfd, buf, 8) == -1)
	    printf("Erreur de lecture\n");
	 
	 Beat(0);
      }
      Tk_DoOneEvent(TK_DONT_WAIT);
   }

}
