#ifndef _TCL_INTERFACE_H_
#define _TCL_INTERFACE_H_

#include <tcl.h>
#include <tk.h> 


class TclInterface {
public:
   
   // Declaration of extern C++ methodes to be called from tcl
   static int InitInterface(Tcl_Interp *interp);
   
   // Methode called from the tcl program
   static int BougeCurseur(ClientData, Tcl_Interp *interp, 
			   int argc, char *argv[]);

   // Methode called from C++ program to interract with tcl
   static int TclEval(Tcl_Interp *interp, char *commande);

   static int TclInterface::Initialize(char *argv);

   void DestroyAllWindows();
};

#endif
