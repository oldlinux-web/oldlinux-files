#include "lamod.h"

Tcl_Interp *interp;
Tk_Window mainWindow;


int TclInterface::InitInterface(Tcl_Interp *interp)
{
  Tcl_CreateCommand(interp, "StartPlay",
		    StartPlay, 
		    (ClientData) NULL,
		    (Tcl_CmdDeleteProc *)NULL);

  Tcl_CreateCommand(interp, "StopPlay",
		    StopPlay, 
		    (ClientData) NULL,
		    (Tcl_CmdDeleteProc *)NULL);

  Tcl_CreateCommand(interp, "Quitter",
		    Quitter, 
		    (ClientData) NULL,
		    (Tcl_CmdDeleteProc *)NULL);

  return TCL_OK;
}

int TclInterface::TclEval(Tcl_Interp *interp, char *commande)
{
  return (Tcl_Eval(interp, commande));
}

int TclInterface::Initialize(char *argv)
{
   char cmd[128];
   char progtcl[128];
   char *display;
   char *trace;
   
   display = (char *)NULL;

   interp = Tcl_CreateInterp();

   mainWindow = Tk_CreateMainWindow(interp, display, argv, "Tk");
   if (mainWindow == NULL) {
     cerr << "TclInterface::Initialize Tk_CreateMainWindow failed :"
	  << interp->result << endl;
     return(TCL_ERROR);
   }

   if (Tcl_Init(interp) == TCL_ERROR) {
     cerr << "TclInterface::Initialize Tcl_Init failed : "
	  << interp->result << endl;
     return (TCL_ERROR);
   }
 
   if (Tk_Init(interp) == TCL_ERROR) {
     cerr << "TclInterface::Initialize Tk_Init failed : "
	  << interp->result << endl;
     return (TCL_ERROR);
   }

   sprintf(progtcl, "%s/lamod.tcl", DESTDIR);
   if (Tcl_EvalFile(interp, progtcl) == TCL_ERROR) {
     cerr << "TclInterface::Initialize Tcl_EvalFile failed : "
	  <<  progtcl << interp->result << endl;
     trace = Tcl_GetVar(interp, "errorInfo", TCL_GLOBAL_ONLY);
     if (trace != NULL) {
       cerr << "*** TCL TRACE ***" << endl;
       cerr << trace << endl;
     }
     return (TCL_ERROR);
   }

   if (TclInterface::InitInterface(interp) == TCL_ERROR) {
     cerr << "TclInterface::Initialize TclInterface::InitInterface failed : "
	  << interp->result << endl;
     return (TCL_ERROR);
   }

   return (TCL_OK);
}

void TclInterface::DestroyAllWindows()
{
   Tk_DestroyWindow(mainWindow);
}
