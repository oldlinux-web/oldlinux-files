#include <iostream.h>
#include <fcntl.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <asm/io.h>
#include <sys/soundcard.h>

#include "awe32.h"
#include "la_tcl.h"

#define OUTP(x, y)              outb((y), (x))
#define INP(x)                  inb((x))

#define OUTPW(x, y)              outw((y), (x))
#define INPW(x)                  inw((x))

int Quitter(ClientData, Tcl_Interp *interp, int argc, char *argv[]);
int StartPlay(ClientData, Tcl_Interp *interp, int argc, char *argv[]);
int StopPlay(ClientData, Tcl_Interp *interp, int argc, char *argv[]);
