char version[] = "version from util-linux-2.5";
