#include <exec/types.h>
#include <libraries/dos.h>

BPTR Input_handle = NULL;
BPTR Output_handle = NULL;
