
#include "window.h"

void
initmbar(win)
WINDOW	*win;
{
	int	i;

	L_INIT (win->mbar.nrmenus, win->mbar.menulist);

	for (i = 0; i < globmenus.nrmenus; i++)
		wmenuattach (win, (void *)(globmenus.menulist[i]));
}

