/* Bruno Haible 24.9.1993 */
/* On Unix, this file will be overwritten by `configure'. */

/* List of supported STDWIN ports */

#ifndef __PORTS_H__    /* Guard against multiple inclusion */
#define __PORTS_H__

/* Define if both x11 and alfa ports shall be supported at the same time. */
#undef BOTH_X11_ALFA

#endif /* __PORTS_H__ */
