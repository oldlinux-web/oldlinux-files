/* Useful definitions, include files etc. */

/*
   #[ configur.h :
#include "configur.h"
	Figure out whether we are using MPW or LSC.
	We assume that if 'unix' and 'MSDOS' are undefined,
	this is the Macintosh; of the two compilers used there,
	MPW defines 'macintosh', while LSC doesn't.
	For the benefit of portable code we define 'macintosh'
	when we find this is LSC; all LSC or MPW-dependent code
	should test for 'LSC' or 'MPW', while general Mac-specific code
	should test for 'macintosh'.
	In order that this file be re-entrant, we also if LSC is already
	defined.

	Note: on the Atari this works because both MW-C and turbo C take
	the LSC definitions in tools.h
*/

#ifndef unix
#ifndef MSDOS
#ifndef LSC
#ifndef macintosh
#define LSC
#define macintosh
#else
#ifndef MPW
#define MPW
#endif
#endif
#endif
#endif
#endif
/*
   #] configur.h :
*/

/* C library stuff: */

#include <stdio.h> /* Must be before stdwin.h because it defines NULL */
#include <ctype.h>

#ifdef SYSV

#include <string.h>

#else

#ifdef ANSI
#include <string.h>
#else
#include <strings.h>
#endif
#ifndef LSC
#define strchr index
#define strrchr rindex
#endif

#endif

#ifdef ANSI
#include <stdlib.h>
#else
#ifdef THINK_C
void *malloc(), *calloc(), *realloc();
#else
char *malloc(), *calloc(), *realloc();
#endif
int free();
#endif

char *ctime();
#ifndef LSC
long time();
#endif

char *getenv();

#ifdef ANSI
#include <errno.h>
#else
extern int errno;
#endif

#ifndef ANSI
#ifdef NO_MEMCPY
#define memcpy(dest, src, n)	bcopy(src, dest, n)
#define memcmp(a, b, cnt)	bcmp(a, b, cnt)
#else
char *memcpy();
#endif
#endif

/* For getopt: */
extern int optind;
extern char * optarg;

/* Dynamic array macros: */

/*
   #[ l_defs.h :
#include "l_defs.h"
   Generic package to manipulate dynamic arrays represented like
   argc/argv (but not necessarily containing character pointers).
   Operations provided are macros that expand to groups of statements;
   their arguments should be side-effect-free.  The arguments argc and
   argv should be single identifiers, since they are assigned to.
   (L_DECLARE expands to a series of declarations.)

   This code was written because I found myself writing code very
   similar to it times and times over, or, worse, using fixed-length
   arrays out of laziness.  It's slow for large arrays (although this
   could be improved easily by rounding up the sizes passed to
   malloc/realloc), but this shouldn't be a problem for the applications
   I am currently using it for.  It sure helped me write some array
   processing code faster.

   Operations:

   L_DECLARE(argc, argv, type)		declare a list with element type 'type'
   L_INIT(argc, argv)			initialize a list
   L_DEALLOC(argc, argv)		deallocate a list
   L_SETSIZE(argc, argv, type, size)	set list to size 'size'
   L_EXTEND(argc, argv, type, count)	append 'count' unitinialized elements
   L_APPEND(argc, argv, type, elem)	append a given element
   L_REMOVE(argc, argv, type, index)	remove element number 'index'
   L_INSERT(argc, argv, type, index, elem)	insert 'elem' at 'index'
   L_SORT(argc, argv, type, compare)	sort the list ('compare' is a function)

   (There should also be operations to insert in the middle and to
   remove elements.)

   NB: the 'type' argument could be discarded (except for L_DECLARE)
   if we could live with warnings about assignments from malloc/realloc
   to other pointer types.

*/

/* Universal pointer; 'void *' for ANSI C, 'char *' for most others */

#ifdef THINK_C
#define _UNIVPTR void *
#endif

#ifdef __STDC__
#define _UNIVPTR void *
#define GOOD_REALLOC
#endif

#ifndef UNIVPTR
#define _UNIVPTR char *
#endif

#ifdef ANSI
#include <stdlib.h>
#else
extern _UNIVPTR malloc();
extern _UNIVPTR realloc();
#endif

#ifdef GOOD_REALLOC
#define _REALLOC(p, size) realloc(p, size)
#else
#define _REALLOC(p, size) ((p) ? realloc(p, size) : malloc(size))
#endif

#define L_DECLARE(argc, argv, type)	int argc= 0; type *argv= 0

#define L_INIT(argc, argv)		argc= 0; argv= 0

#define L_DEALLOC(argc, argv)		argc= 0; \
					if (argv != 0) { \
						free((char*)argv); \
						argv= 0; \
					}

#define L_SETSIZE(argc, argv, type, size) \
	argv= (type *) _REALLOC((_UNIVPTR) argv, \
		(unsigned) (size) * sizeof(type)); \
	argc= (argv == 0) ? 0 : size

#define L_EXTEND(argc, argv, type, count) \
	L_SETSIZE(argc, argv, type, argc+count)

#define L_APPEND(argc, argv, type, elem) \
	argv= (type *) _REALLOC((_UNIVPTR) argv, \
		(unsigned) (argc+1) * sizeof(type)); \
	if (argv == 0) \
		argc= 0; \
	else \
		argv[argc++]= elem

#define L_REMOVE(argc, argv, type, index) \
	{ \
		int k_; \
		for (k_= index+1; k_ < argc; ++k_) \
			argv[k_-1]= argv[k_]; \
		L_SETSIZE(argc, argv, type, argc-1); \
	}

#define L_INSERT(argc, argv, type, index, item) \
	{ \
		int k_; \
		L_SETSIZE(argc, argv, type, argc+1); \
		for (k_= argc-1; k_ > index; --k_) \
			argv[k_]= argv[k_-1]; \
		argv[index]= item; \
	}

#define L_SORT(argc, argv, type, compare) \
	qsort((_UNIVPTR)argv, argc, sizeof(type), compare)

/*
   #] l_defs.h :
*/

/* Boolean data type: */
#ifndef bool
#define bool int
#endif
#define tbool char	/* Tiny bool, used in structs or arrays */
#define FALSE 0
#define TRUE 1

/* Character shorthands: */
#define EOS '\0'
#define EOL '\n'

/* Copy string to malloc'ed memory: */
char *strdup();
char *strndup();

/* Other useful macros: */

#define CNTRL(x) ((x) & 0x1f) /* Usage: CNTRL('X') */

#define ABS(x) ((x) < 0 ? -(x) : (x))

#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif
#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

#define CLIPMIN(var, min) if ((var) >= (min)) ; else (var)= (min)
#define CLIPMAX(var, max) if ((var) <= (max)) ; else (var)= (max)

/* Memory allocation macros: */

#define ALLOC(type) ((type*) malloc(sizeof(type)))
#define FREE(p) if(p){free((void *)(p)); (p) = 0;}
/* #define FREE(p) (((p) ? free((char*)(p)) : 0), (p)= 0) */

/* Array (re)allocation macros.
   RESIZE yields nonzero if the realloc succeeded. */

#define NALLOC(type, n) ((type*) malloc((unsigned)(n) * sizeof(type)))
#define RESIZE(var, type, n) \
	(var= (type *) realloc((char*)var, (n) * sizeof(type)))
