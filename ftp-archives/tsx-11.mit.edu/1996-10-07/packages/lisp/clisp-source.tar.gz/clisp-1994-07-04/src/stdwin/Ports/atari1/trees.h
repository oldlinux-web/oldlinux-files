/* External interface to trees.c */


/* Definition of a tree (under construction).
   'Focus' is the index of the current node.
   The root node is always the first node.
   If the tree is empty, the focus is undefined. */

typedef struct tree {
        OBJECT *obj;
        int nobjs;
        int focus;
} TREE;

int tr_root();
int tr_parent();
int tr_sibling();
int tr_child();
int tr_nchildren();
OBJECT *tr_add();
void tr_dump();
OBJECT *tr_node();
OBJECT *tr_tree();
