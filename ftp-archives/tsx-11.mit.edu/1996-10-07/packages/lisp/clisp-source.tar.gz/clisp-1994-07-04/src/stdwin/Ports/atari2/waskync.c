
#include "window.h"

int
waskync(question, def)
char *question;
int def;
{
	char buf[256];

	strcpy(buf, "[2][");
	if ( strlen(question) >= 16 )
		strcat(buf, question);
	else
		sprintf(buf + 4, "%-16s", question);
	strcat(buf, "][Yes|No|Cancel]");

	return(2 - form_alert (2 - def, buf));
}

