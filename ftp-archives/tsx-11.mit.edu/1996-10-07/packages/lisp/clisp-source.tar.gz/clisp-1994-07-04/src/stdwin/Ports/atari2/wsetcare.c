
#include "window.h"

void
wsetcaret(win, h, v)
WINDOW *win;
int h;
int v;
{
	if ( win == active ) rmcaret();

	win->caret_h = h;
	win->caret_v = v;

	if ( win == active ) showcaret();
}

