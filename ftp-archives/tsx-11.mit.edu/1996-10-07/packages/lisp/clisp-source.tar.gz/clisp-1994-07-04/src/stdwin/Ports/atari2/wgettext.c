
#include "stdwin.h"
#include "style.h"

void
wgettextattr(attr)
TEXTATTR *attr;
{
	*attr= wattr;
}

