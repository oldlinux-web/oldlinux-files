
#include "window.h"

void
wgetwinsize(win, pwidth, pheight)
WINDOW *win;
int *pwidth;
int *pheight;
{
	if (win == NULL) return;
	*pwidth = win->width;
	*pheight = win->height;
}

