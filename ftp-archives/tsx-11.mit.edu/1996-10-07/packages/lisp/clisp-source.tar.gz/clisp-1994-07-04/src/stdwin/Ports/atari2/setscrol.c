
#include "window.h"

void
setscrollbars(win)
WINDOW	*win;
{
	int	dummy;
	int	old;
	int	size;
	int	pos;
	int	win_width = win->width;
	int	win_height = win->height;
	int	doc_width = win->doc_width;
	int	doc_height = win->doc_height;
	int	orgh = win->orgh;
	int	orgv = win->orgv;

	if ( doc_width <= win_width ) {
		size = 1000;
		pos = 0;
	}
	else {
		size = (long) win_width * 1000L / (long) doc_width;
		pos = (long) orgh * 1000L / (long) (doc_width - win_width);
	}

	if ( size > 1000 ) size = 1000;

	wind_get (win->handle, WF_HSLIDE, &old, &dummy, &dummy, &dummy);
	if (old != pos)
		wind_set (win->handle, WF_HSLIDE, pos, dummy, dummy, dummy);
	wind_get (win->handle, WF_HSLSIZE, &old, &dummy, &dummy, &dummy);
	if (old != size)
		wind_set (win->handle, WF_HSLSIZE, size, dummy, dummy, dummy);

	if ( doc_height <= win_height ) {
		size = 1000;
		pos = 0;
	}
	else {
		size = win_height * 1000L / (long) doc_height;
		pos = orgv * 1000L / (long) (doc_height - win_height);
	}

	if (size > 1000) size = 1000;

	wind_get (win->handle, WF_VSLIDE, &old, &dummy, &dummy, &dummy);
	if (old != pos)
		wind_set (win->handle, WF_VSLIDE, pos, dummy, dummy, dummy);
	wind_get (win->handle, WF_VSLSIZE, &old, &dummy, &dummy, &dummy);
	if (old != size)
		wind_set (win->handle, WF_VSLSIZE, size, dummy, dummy, dummy);
}

