
#include "window.h"

void
wchange(win, left, top, right, bottom)
WINDOW *win;
int left;
int top;
int right;
int bottom;
{
	register int a;
	if ( win == NULL ) return;

	if ( left < win->orgh) left = win->orgh;
	if ( top < win->orgv)  top = win->orgv;
	if ( right > (a = win->orgh + win->width) ) right = a;
	if ( bottom > (a = win->orgv + win->height) ) bottom = a;

	if ( left >= right || top >= bottom ) return;

	if ( !win->needupdate ) {
/*
		No changed area; assign paramters
*/
		win->needupdate = TRUE;
		win->left = left;
		win->top = top;
		win->right = right;
		win->bottom = bottom;
	}
	else {
/*
		Already a changed area; calculate new rectangle
*/
		if ( left < win->left )     win->left = left;
		if ( top < win->top )       win->top = top;
		if ( right > win->right )   win->right = right;
		if ( bottom > win->bottom ) win->bottom = bottom;
	}
}

