
#include "window.h"

void
wgetscrsize(pwidth, pheight)
int *pwidth;
int *pheight;
{
	*pwidth = scr_width;
	*pheight = scr_height;
}

