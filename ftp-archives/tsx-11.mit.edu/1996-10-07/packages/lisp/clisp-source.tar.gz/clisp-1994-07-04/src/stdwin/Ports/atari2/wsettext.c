
#include "stdwin.h"
#include "style.h"

void
wsettextattr(attr)
TEXTATTR *attr;
{
	wattr= *attr;
	setattr ();
}
