
#include "window.h"

void
winvert(left, top, right, bottom)
int left;
int top;
int right;
int bottom;
{
	if ( drawing != NULL ) inVertrect(drawing, left, top, right, bottom);
}

