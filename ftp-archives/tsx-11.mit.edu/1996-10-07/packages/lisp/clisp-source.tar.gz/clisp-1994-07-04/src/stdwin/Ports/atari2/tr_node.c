
#include "trees.h"

OBJECT *
tr_node(t)
TREE *t;
{
	if ( t->nobjs <= 0 ) return (OBJECT *)0;
	return &t->obj[t->focus];
}

