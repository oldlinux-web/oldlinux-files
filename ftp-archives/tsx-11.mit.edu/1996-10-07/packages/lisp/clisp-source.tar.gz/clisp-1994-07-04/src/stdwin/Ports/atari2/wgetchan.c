
#include "window.h"

void
wgetchange(win, pleft, ptop, pright, pbottom)
WINDOW *win;
int *pleft;
int *ptop;
int *pright;
int *pbottom;
{
	*pleft = *ptop = *pright = *pbottom = 0;

	if ( win != NULL && win->needupdate ) {
		*pleft = win->left;
		*ptop = win->top;
		*pright = win->right;
		*pbottom = win->bottom;
	}
}

