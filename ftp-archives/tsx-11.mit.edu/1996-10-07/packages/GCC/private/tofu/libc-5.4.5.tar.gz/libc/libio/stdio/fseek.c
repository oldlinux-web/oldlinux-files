#include "stdio.h"
#include "libioP.h"

int
fseek(fp, offset, whence)
     _IO_FILE* fp;
     long int offset;
     int whence;
{
#ifdef _LIBPTHREAD
  CHECK_FILE(fp, -1);
  flockfile (fp);
  whence = _IO_fseek (fp, offset, whence);
  funlockfile (fp);
  return whence;
#else
  CHECK_FILE(fp, -1);
  return _IO_fseek(fp, offset, whence);
#endif
}

#ifndef _LIBPTHREAD
#ifdef __ELF__
#pragma weak fseek
#endif
#endif
