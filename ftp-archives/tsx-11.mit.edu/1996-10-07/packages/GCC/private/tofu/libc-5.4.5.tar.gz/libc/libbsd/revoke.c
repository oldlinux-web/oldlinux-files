/* revoke.c - can't quite emulate BSD revoke? - rick sladkey */


int revoke(char *line)
{
	return 0;	
}

