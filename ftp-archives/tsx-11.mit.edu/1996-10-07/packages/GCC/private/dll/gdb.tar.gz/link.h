/*
 * Header file that describes the internal data structures used by the ELF
 * dynamic linker.
 */

struct link_map{
  /* These entries must be in this order to be compatible with the interface used
     by gdb to obtain the list of symbols. */
  char * l_addr;
  char * l_name;
  unsigned int * l_ld;
  struct link_map * l_next;
  struct link_map * l_prev;
};

/*
 * The DT_DEBUG entry in the .dynamic section is given the address of this structure.
 * gdb can pick this up to obtain the correct list of loaded modules.
 */

struct r_debug{
  int r_version;
  struct link_map * r_map;
  unsigned long brk_fun;
  enum {RT_CONSISTENT, RT_ADD, RT_DELETE};
  unsigned long ldbase;
};

