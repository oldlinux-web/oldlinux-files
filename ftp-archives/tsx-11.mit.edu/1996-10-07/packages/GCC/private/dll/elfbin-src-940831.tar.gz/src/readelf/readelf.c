#include <stdlib.h>
#include <getopt.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include "linuxelf.h"

#define ELF32_R_SYM(x) ((x) >> 8)
#define ELF32_R_TYPE(x) ((x) & 0xff)
char * header;
unsigned int dynamic_addr;
unsigned int dynamic_size;
char * pint;

int dynamic_info[24];

unsigned int rel_addr;
unsigned int rel_size;
int loadaddr = -1;

unsigned int rela_addr;
unsigned int rela_size;

struct dynamic * dpnt;
struct Elf32_Rel * rpnt;

struct Elf32_Sym * symtab;
char * strtab;
int symtab_index;

FILE * infile;

char * filetype[] = {
  "None", "Rel", "Executable", "Dynamic", "Core", "Num"};

char * phtype[] = {
  "Null", "Load", "Dynamic", "Interp", "Note", "Shared lib", "PHDR", "Num"};

char * sectiontype[] ={
  "NULL", "PROGBITS", "SYMTAB", "STRTAB", "RELA", "HASH", "DYNAMIC",
  "NOTE", "NOBITS", "REL", "SHLIB", "DYNSYM", "NUM"};

char * dyntype[] ={
  "NULL", "NEEDED","PLTRELSZ","PLTGOT","HASH","STRTAB","SYMTAB","RELA",
  "RELASZ","RELAENT","STRSZ","SYMENT","INIT","FINI","SONAME","RPATH",
  "SYMBOLIC","REL","RELSZ","RELENT","PLTREL","DEBUG","TEXTREL","JMPREL"};

char * sttinfo[] = {"NOTYPE","OBJECT","FUNC","SECTION","FILE"};
char * stbinfo[] = {"LOCAL","GLOBAL","WEAK"};

static void usage()
{
    printf("Usage: readelf [-Sadhlrs] elfbin\n");
}

main(int argc, char * argv[]){
  int do_dynamic, do_syms, do_reloc, do_section, do_load;
  int do_header;
  struct elfhdr * epnt;
  struct elf_phdr * ppnt;
  struct elf_shdr * spnt;
  struct stat statbuf;
  int lastmapped;
  int i;
  int status;
  char c;

  if(argc < 2) {
    usage();
    exit(0);
  };

  do_section = do_syms = do_reloc = do_dynamic = do_load = 0;
  do_header = 0;

  while ((c = getopt(argc, argv, "rsahldS")) != EOF)
    {
      switch (c)
	{
	case 'a':
	  do_syms++;
	  do_reloc++;
	  do_dynamic++;
	  do_header++;
	  do_section++;
	  do_load++;
	  break;
	case 'r':
	  do_reloc++;
	  break;
	case 'h':
	  do_header++;
	  break;
	case 'l':
	  do_load++;
	  break;
	case 's':
	  do_syms++;
	  break;
	case 'S':
	  do_section++;
	  break;
	case 'd':
	  do_dynamic++;
	  break;
	default:
	  fprintf(stderr, "Invalid option '-%c'\n", c);
	  usage();
	  exit(1);
	};
    };

  if(do_section + do_syms + do_reloc + do_dynamic + do_load + do_header == 0)
    {
      usage();
      exit(0);
    }

  infile = fopen(argv[optind], "r");
  if (!infile){
    printf("Input file %s not found.\n",argv[1]);
    exit(1);
  };

  status = fstat(fileno(infile), &statbuf);
  if(status) exit(0);

  header = mmap(0, statbuf.st_size, PROT_READ, MAP_PRIVATE, fileno(infile), 0);

  epnt = (struct elfhdr *) header;
  if (epnt->e_ident[0] != 0x7f || strncmp(&epnt->e_ident[1], "ELF",3)){
    printf("%s is not an ELF file\n",argv[1]);
    exit(1);
  };

#if 0
  if(epnt->e_type != 2) {
    printf("%s is not an ELF executable\n",argv[1]);
    exit(1);
  };
#endif
  if(epnt->e_machine != 3 && epnt->e_machine != 6){
    printf("%s is not an ELF executable for the 386/486\n",argv[1]);
    exit(1);
  };

  if(do_header) {
    int ijk;
    printf("ELF magic:");
    for(ijk = 0; ijk < 16; ijk++) printf("%2.2x ", epnt->e_ident[ijk]);
    printf("\n");
    printf("Type, machine, version = %d %d %d\n", epnt->e_type, 
	   epnt->e_machine, epnt->e_version);
    printf("Entry, phoff, shoff, flags = %x %d %d %x\n",
	   epnt->e_entry, epnt->e_phoff, epnt->e_shoff, epnt->e_flags);
    printf("ehsize, phentsize, phnum = %d %d %d\n", epnt->e_ehsize,
	   epnt->e_phentsize, epnt->e_phnum);
    printf("shentsize, shnum, shstrndx = %d %d %d\n", epnt->e_shentsize, 
	   epnt->e_shnum, epnt->e_shstrndx);
  }


  if(do_load) {
    printf("Elf file is %s\n",filetype[epnt->e_type]);
    printf("Entry point 0x%x\n",epnt->e_entry);
    printf("There are %d program headers, starting at offset %x:\n",
	   epnt->e_phnum, epnt->e_phoff);
  };
  ppnt = (struct elf_phdr *) &header[epnt->e_phoff];
  for(i=0;i < epnt->e_phnum; i++){
    if(loadaddr == -1 && ppnt->p_vaddr != 0) 
      loadaddr = (ppnt->p_vaddr & 0xfffff000) - (ppnt->p_offset & 0xfffff000);
    if(do_load){
      printf("%-10s ",phtype[ppnt->p_type]);
      printf("0x%5.5x ",ppnt->p_offset);
      printf("0x%8.8x ",ppnt->p_vaddr);
      printf("0x%5.5x 0x%5.5x ",ppnt->p_filesz, ppnt->p_memsz);
      printf("%c%c%c ",
	     (ppnt->p_flags & 4 ? 'R' : ' '),
	     (ppnt->p_flags & 2 ? 'W' : ' '),
	     (ppnt->p_flags & 1 ? 'E' : ' '));
    };

    if(ppnt->p_type == 2) {
      if(dynamic_addr) fprintf(stderr,"Error - more than one dynamic section");
      dynamic_addr = ppnt->p_offset;
      dynamic_size = ppnt->p_filesz;
      };
    if(ppnt->p_type == 3 && do_load) {
      printf("\nRequesting program interpreter [%s]",&header[ppnt->p_offset]);
      pint = strdup(&header[ppnt->p_offset]);
    }
    if(do_load) printf("\n");
    ppnt++;
  };

  if(do_section){
    spnt = (struct elf_shdr *) &header[epnt->e_shoff];
    spnt += epnt->e_shstrndx;
    lastmapped = spnt->sh_offset;
    printf("There are %d section headers, starting at offset %x:\n",
	   epnt->e_shnum, epnt->e_shoff);
    spnt = (struct elf_shdr *) &header[epnt->e_shoff];
    printf("sec#  name      type             addr    offst fsize esz flg lnk inf addraln\n");
    for(i=0;i < epnt->e_shnum; i++){
      printf("[%2x] %-10s", i, &header[lastmapped+spnt->sh_name]);
      if(spnt->sh_type < 12)
	printf(" %-15s ",sectiontype[spnt->sh_type]);
      else
	printf(" %8x ", spnt->sh_type);
      printf("%8.8x %5.5x %5.5x %2.2x",
	     spnt->sh_addr, spnt->sh_offset, spnt->sh_size, spnt->sh_entsize);

      printf("   %x  %2x  %3x   %x ", spnt->sh_flags, spnt->sh_link, spnt->sh_info, spnt->sh_addralign);
      if(spnt->sh_type == 9){
	rel_addr = spnt->sh_offset;
	rel_size = spnt->sh_size;
      };
      printf("\n");
      spnt++;
    };
  }

/* Now parse the dynamic section */
#if 0
  printf("\n Dynamic section data:%x %x\n",dynamic_addr, dynamic_size);
#endif

  dpnt = (struct dynamic *) &header[dynamic_addr];
  dynamic_size = dynamic_size / sizeof(struct dynamic);
  for(i=0; i< dynamic_size; i++){
    if(do_dynamic) printf("Tag: %d (%s) Value %x\n", dpnt->d_tag, dyntype[dpnt->d_tag],
	   dpnt->d_un.d_ptr);
    if(dpnt->d_tag < 0 || dpnt->d_tag > 24) {
      fprintf("Invalid dynamic tag %d\n", dpnt->d_tag);
      break;
    }
    dynamic_info[dpnt->d_tag] = dpnt->d_un.d_val;
    dpnt++;
  };

  symtab =  (struct Elf32_Sym *) (header - loadaddr + dynamic_info[DT_SYMTAB]);
  strtab = (char *) (header - loadaddr + dynamic_info[DT_STRTAB]);
 
 dpnt = (struct dynamic *) &header[dynamic_addr];
  for(i=0; i< dynamic_size; i++){
    switch(dpnt->d_tag){
    case DT_NEEDED:
      printf("Shared library: %s\n", (dpnt->d_un.d_val + strtab));
      break;
    case DT_SONAME:
      printf("SONAME: %s\n", (dpnt->d_un.d_val + strtab));
      break;
    case DT_RPATH:
      printf("RPATH = %s\n", (dpnt->d_un.d_val + strtab));
      break;
    }
    dpnt++;
  };

  if(do_reloc) {
    rpnt = (struct Elf32_Rel *) (header + dynamic_info[DT_REL] - loadaddr);
    rel_size = dynamic_info[DT_RELSZ];
    rel_size = rel_size / sizeof(struct Elf32_Rel);
    printf("\n Relocation section data:%x %x\n",dynamic_info[DT_REL], rel_size);
    for(i=0; i< rel_size; i++){
      symtab_index = ELF32_R_SYM(rpnt->info);
      printf("Tag: %x Value %x (%x %s) \n", rpnt->offset, rpnt->info, 
	     symtab[symtab_index].st_value,
	     strtab + symtab[symtab_index].st_name);
      rpnt++;
    };
    
    
    rpnt = (struct Elf32_Rel *) (header + dynamic_info[DT_JMPREL] - loadaddr);
    rel_size = dynamic_info[DT_PLTRELSZ];
    rel_size = rel_size / sizeof(struct Elf32_Rel);
    printf("\n Jumptable Relocation section data:%x %x\n",dynamic_info[DT_JMPREL], rel_size);
    for(i=0; i< rel_size; i++){
      symtab_index = ELF32_R_SYM(rpnt->info);
      printf("Tag: %x Value %x (%x %s) \n", rpnt->offset, rpnt->info, 
	     symtab[symtab_index].st_value,
	     strtab + symtab[symtab_index].st_name);
      rpnt++;
    };
  }

  /* Now dump the symbol table */
  if(do_syms)  {
    int nbucket, nchain, *elf_buckets, *chains;
    int hn, si;
    char * pnt;
    int * hash_addr = (unsigned int *) (dynamic_info[DT_HASH] + header - loadaddr);
    nbucket = *hash_addr++;
    nchain = *hash_addr++;
    elf_buckets = hash_addr;
    hash_addr += nbucket;
    chains = hash_addr;
    printf("Symbol table for image\n");
    for(hn = 0; hn < nbucket; hn++) {
      if(!elf_buckets[hn]) continue;
      for(si = elf_buckets[hn]; si; si = chains[si]) {
	pnt = strtab + symtab[si].st_name;
	printf("%3.3d %3.3d: %8x %5d %6s %6s %2.2d %3.3d %s\n", si, hn,
	       symtab[si].st_value,
	       symtab[si].st_size,
	       sttinfo[ELF32_ST_TYPE(symtab[si].st_info)],
	       stbinfo[ELF32_ST_BIND(symtab[si].st_info)],
	       symtab[si].st_other,
	       symtab[si].st_shndx,
	       pnt);
      }
    }

  }

}
