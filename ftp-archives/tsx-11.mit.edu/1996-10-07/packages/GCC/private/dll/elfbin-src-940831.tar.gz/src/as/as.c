#include <stdio.h>
#include <string.h>

/*
 * Front end for linux assembler.  We look for -m options to indicate
 * which format is desired, and attempt to call the proper assembler
 * based upon the options.
 */

#define EMULATION_ENVIRON "ASEMULATION"
/* Look in this variable for a target format */
#define DEFAULT_EMULATION "i386linux"

/* We need to find any explicitly given emulation in order to initialize the
   state that's needed by the lex&yacc argument parser (parse_args).  */

static char *
get_emulation (argc, argv)
     int * argc;
     char **argv;
{
  char *emulation;
  int i, j;

  emulation = (char *) getenv (EMULATION_ENVIRON);
  if (emulation == NULL)
    emulation = DEFAULT_EMULATION;

  for (i = 1; i < *argc; i++)
    {
      if (!strncmp (argv[i], "-m", 2))
	{
	  if (argv[i][2] == '\0')
	    {
	      /* -m EMUL */
	      if (i < *argc - 1)
		{
		  emulation = argv[i + 1];
		  for(j=i; j<*argc-2; j++)
		    argv[j] = argv[j+2];
		  *argc -= 2;
		  i--;
		}
	      else
		{
		  fprintf(stderr,"as: missing argument to -m\n");
		  exit(1);
		}
	    }
	  else if (strcmp (argv[i], "-mips1") == 0
		   || strcmp (argv[i], "-mips2") == 0
		   || strcmp (argv[i], "-mips3") == 0)
	    {
	      /* FIXME: The arguments -mips1, -mips2 and -mips3 are
		 passed to the linker by some MIPS compilers.  They
		 generally tell the linker to use a slightly different
		 library path.  Perhaps someday these should be
		 implemented as emulations; until then, we just ignore
		 the arguments and hope that nobody ever creates
		 emulations named ips1, ips2 or ips3.  */
	    }
	  else if (strcmp (argv[i], "-m486") == 0)
	    {
	      /* FIXME: The argument -m486 is passed to the linker on
		 some Linux systems.  Hope that nobody creates an
		 emulation named 486.  */
	    }
	  else
	    {
	      /* -mEMUL */
	      emulation = &argv[i][2];
	    }
	}
    }

  return emulation;
}

main(int argc, char * argv[])
{
  int i, status;
  char * old_path;
  char path[128];

  old_path = strrchr(argv[0], '/');
  if(old_path) {
    old_path++;
    *old_path = 0;
    old_path = argv[0];
  } else {
    old_path = "/usr/bin/";
  }

  sprintf(path,"%sas-%s", old_path, get_emulation(&argc, argv));
  argv[argc] = 0;
  argv[0] = &path[0];

#if 0
  printf("Emulation = %s\n", path);
  for(i=0; i<argc; i++)
    fprintf(stderr,"%s ", argv[i]);
  fprintf(stderr,"\n");
#endif

  status = execv(path, argv);
  if(status) {
    fprintf(stderr,"Unable to exec: %s ", path);
    for(i=1; i<argc; i++)
      fprintf(stderr,"%s ", argv[i]);
    fprintf(stderr,"\n");
  }
}
