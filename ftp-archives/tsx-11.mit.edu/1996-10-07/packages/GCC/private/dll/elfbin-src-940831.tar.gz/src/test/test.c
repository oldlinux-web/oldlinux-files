
extern unsigned int ___brk_addr;

main(int argc, char * argv[], char * envp[])
{
  char * pnt;
  pnt = malloc(1024);
  *pnt = 3;
  printf("Hello world %x\n", ___brk_addr);
}
