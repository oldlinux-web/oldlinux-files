#define FALSE 0
#define TRUE 1

typedef unsigned char boolean_t;
typedef unsigned long db_addr_t;

