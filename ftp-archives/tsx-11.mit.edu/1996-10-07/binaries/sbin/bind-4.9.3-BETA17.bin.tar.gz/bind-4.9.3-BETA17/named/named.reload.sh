#!/bin/sh -
#
#	from named.reload	5.2 (Berkeley) 6/27/89
#	$Id: named.reload.sh,v 8.1 1994/12/15 06:24:14 vixie Exp $
#

exec %DESTSBIN%/%INDOT%ndc reload
