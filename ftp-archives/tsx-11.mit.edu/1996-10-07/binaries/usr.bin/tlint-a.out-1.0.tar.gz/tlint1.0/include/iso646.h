/*
 * Copyright (c) 1995, by Thinkage Ltd.
 */

#define and		&&
#define and_eq	&=
#define bitand	&
#define bitor	|
#define compl	~
#define ne		!=
#define not		!
#define or		||
#define or_eq	|=
#define xor		^
#define xor_eq	^=
