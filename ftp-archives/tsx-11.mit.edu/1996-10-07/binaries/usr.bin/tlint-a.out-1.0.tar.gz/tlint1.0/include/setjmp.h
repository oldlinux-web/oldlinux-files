/*
 * Copyright (c) 1995, by Thinkage Ltd.
 *
 * setjmp.h - Definitions for non-local goto's.
 *
 */

#ifndef _D_SETJMP
#	define	_D_SETJMP
#	pragma idempotent
#	protoset setjmp

	typedef int jmp_buf[2];

#endif /* _D_SETJMP */
