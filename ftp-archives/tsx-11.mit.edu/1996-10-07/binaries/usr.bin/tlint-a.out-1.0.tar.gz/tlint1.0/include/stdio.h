/*
 * Copyright (c) 1995, by Thinkage Ltd.
 *
 * stdio.h - definitions for the standard I/O package
 */

#ifndef _D_STDIO
#define _D_STDIO
#pragma idempotent

#protoset stdio

#	include <stddef.h>
#	include <stdarg.h>

typedef struct _iobuf {
	int _dummy_because_empty_structs_are_illegal;
} FILE;

typedef struct {
	int _dummy_because_empty_structs_are_illegal;
} fpos_t;

#define	EOF				(-1)
#define	SYS_OPEN		20		/* maximum number of open files */
#define	OPEN_MAX		SYS_OPEN
#define	TMP_MAX			25

/*
 * For setbuf and setvbuf
 */
#	define _IOFBF		0	/* use full buffering */
#	define _IOLBF		1	/* use line buffering */
#	define _IONBF		2	/* no buffering is to be used */
#	define BUFSIZ		0	/* size of buffer */

/*
 * certain macros
 */
#	define L_tmpnam		7
#	define P_tmpdir		""
#	define SEEK_SET		0
#	define SEEK_CUR		1
#	define SEEK_END		2

/* Operation on files */


#endif /* _D_STDIO */

