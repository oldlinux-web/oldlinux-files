/*
 * Copyright (c) 1995, by Thinkage Ltd.
 */

#ifndef _D_STDDEF
#	define _D_STDDEF
#	pragma idempotent

#	protoset stddef

#	define NULL				((void *)0)
#	define offsetof(t,id)	((size_t)((char *)(&((t *)0)->id) - (char *)0))

#endif /* _D_STDDEF */























