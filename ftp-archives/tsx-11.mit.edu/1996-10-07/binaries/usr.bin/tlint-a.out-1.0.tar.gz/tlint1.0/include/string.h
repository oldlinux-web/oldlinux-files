/*
 * Copyright (c) 1995, by Thinkage Ltd.
 *
 * string.h - definitions of string functions
 */
#define	_D_STRING
#pragma idempotent
#protoset string

#if !defined(NULL)
#	define	NULL		((void *)0)
#endif
