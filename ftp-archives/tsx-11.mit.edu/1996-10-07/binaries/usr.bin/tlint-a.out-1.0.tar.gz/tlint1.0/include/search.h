/*
 * Copyright (c) 1995, by Thinkage Ltd.
 *
 * search.h - definitions for Hsearch(3C), Tsearch(3C)
*/

#ifndef _D_SEARCH
#	define _D_SEARCH
#pragma idempotent

	typedef enum { FIND, ENTER }
ACTION;
	
typedef struct {
	char *key;
	char *data;
} ENTRY;
	
	typedef enum { preorder, postorder, endorder, leaf }
VISIT;

#endif /* _D_SEARCH */
