92/07/22




This  is 3.14 of Chuck Forsberg's ZMODEM protocol drivers
rz, and sz, in binary form.  They were compiled with GCC 2.2.2,
under Linux 0.96c(pl0).  

   They were compiled with the command

gcc sz.c -o sz
gcc rz.c -o rz


Instead of with the makefile that comes in the distribution.
I believe that it defaults to USG, in the abscense of of Defines.

This seems pretty simple, but someone mailed me that it probably would
be useful to upload the binaries, at least for the people without 
a compiler.



NOTICE: This is SHAREWARE, ie you have register it!  I think that this is
correct.  More information can be obtained in the aaareadme, and readme
that came in the distribution and that I am including.

The distribution contains:

aaareadme    - Notice of Sharewareness.
readme       - Readme first stuff.
rz.doc       - Documentation for rz/sz
sz.doc       
sz	     - The actual programmes.
rz



Chris Maxwell,
maxwell@ug.cs.dal.ca
