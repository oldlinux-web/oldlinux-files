/*
 * Copyright (c) 1995, by Thinkage Ltd.
 *
 * errno.h - System error codes, and the "standard" names for them.
 */

#ifndef _D_ERRNO
#define _D_ERRNO
#pragma idempotent
#protoset errno

#	define EPERM		1
#	define ENOENT		2
#	define EIO			3
#	define E2BIG		4
#	define EBADF		5
#	define EACCES		6
#	define EFAULT		7
#	define EEXIST		8
#	define EINVAL		9
#	define ERANGE		10
#	define EDOM  		11

#endif
