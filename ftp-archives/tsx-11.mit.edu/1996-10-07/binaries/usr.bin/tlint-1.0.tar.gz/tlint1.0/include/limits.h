/*
 * Copyright (c) 1995, by Thinkage Ltd.
 */

#ifndef _D_LIMITS
#	define _D_LIMITS
#	pragma idempotent

#	protoset limits

#	define CHAR_BIT			8
#	define INT_MAX			32767
#	define INT_MIN			(-32767)
#	define LONG_MAX			2147483647L
#	define LONG_MIN			(-2147483647L)
#	define SCHAR_MAX		127
#	define SCHAR_MIN		(-127)
#	define SHRT_MAX			32767
#	define SHRT_MIN			(-32767)
#	define UCHAR_MAX		255U
#	define UINT_MAX			65535U
#	define ULONG_MAX		4294967295U
#	define USHRT_MAX		65535U
#	define MB_LEN_MAX		1

#	ifdef _DEFAULT_SIGNED_CHARS
#		define CHAR_MAX		SCHAR_MAX
#		define CHAR_MIN		SCHAR_MIN
#	else
#		define CHAR_MAX		UCHAR_MAX
#		define CHAR_MIN		0
#	endif

#endif /* _D_LIMITS */
