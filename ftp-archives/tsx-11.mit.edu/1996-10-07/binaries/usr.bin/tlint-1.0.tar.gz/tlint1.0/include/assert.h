/*
 * Copyright (c) 1995, by Thinkage Ltd.
 *
 * assert.h - assertion macros
 */
#define _D_ASSERT
#pragma idempotent
#protoset assert

#if defined(NDEBUG)
#	define assert(ex) ((void) 0)
#else
#	define assert(ex) ((ex) ? (void)0 : __assert(#ex, __FILE__, __LINE__))
#endif

	extern void
__assert(const char *, const char *, long);
