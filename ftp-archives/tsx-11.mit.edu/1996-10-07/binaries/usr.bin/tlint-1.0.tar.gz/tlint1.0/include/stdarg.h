/*
 * Copyright (c) 1995, by Thinkage Ltd.
 *
 * stdarg.h - interface for arbitrary argument functions
 */

#ifndef _D_STDARG
#   define _D_STDARG
#   pragma idempotent

#	protoset stdarg

	typedef void *va_list[1]; 

#   define va_start(ap,parmN)   ((ap)[0] = ((&(parmN)) + 1))

#   define va_arg(ap,type)  (                               \
        ((ap)[0] = __alignp( (ap)[0], __alignof(type) )),    \
        (*(*(type **) &(ap)[0])++)                          \
    )

#   define va_end(ap)   ((ap)[0] = NULL)

    void *
__alignp( void *, unsigned );

#endif /* _D_STDARG */
