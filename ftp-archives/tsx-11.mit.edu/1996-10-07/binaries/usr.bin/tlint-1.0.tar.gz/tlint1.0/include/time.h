/*
 * Copyright (c) 1995, by Thinkage Ltd.
 *
 * time.h - date/time routines
 */

#include <stddef.h>

#ifndef	_D_TIME
#	define	_D_TIME
#	pragma idempotent

#	protoset time

	typedef unsigned long time_t;
	typedef long clock_t;

#	define  CLOCKS_PER_SEC	1
#	define	_START_DAY	0

	struct tm {
		int tm_sec;			/* 0-59 */
		int tm_min;			/* 0-59 */
		int tm_hour;		/* 0-23 */
		int tm_mday;		/* 1-31 */
		int tm_mon;			/* 0-11 */
		int tm_year;		/* year-1900 */
		int tm_wday;		/* sunday=0 */
		int tm_yday;		/* 0-365 */
		int tm_isdst;		/* dst=nonzero */
	};

#endif /* _D_TIME */
