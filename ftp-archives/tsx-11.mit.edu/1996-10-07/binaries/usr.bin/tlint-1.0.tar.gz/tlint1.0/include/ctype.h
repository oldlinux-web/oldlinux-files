/*
 * Copyright (c) 1995, by Thinkage Ltd.
 *
 * ctype.h - character manipulation macros.
 */

#ifndef _D_CTYPE
#	define _D_CTYPE
#pragma idempotent
#protoset ctype

#	define _toupper(c)	((c) - 'a' + 'A')
#	define _tolower(c)	((c) - 'A' + 'a')

#endif	/* _D_CTYPE */
