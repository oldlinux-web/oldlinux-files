divert(10)dnl
#
# SMTP UUCP connections on cad.
# The macro SMTPUUCPPAIR is defined in m4/uucpm.m4.
#
# @(#)smtpuucp.cad.m4	1.1	(Berkeley) 3/31/88
#
divert(0)dnl

SMTPUUCPPAIR(ames, ames.arc.nasa.gov)
SMTPUUCPPAIR(ucbvax, ucbvax.berkeley.edu)
