divert(10)dnl
#
# UUCP connections on okeeffe
#
# @(#)uucp.okeeffe.m4	1.1 (Berkeley) 10/28/87
#
divert(0)dnl
CV	blia
CV	ccicpg
CV	mjk
CV	pixar
CV	zulu
