divert(10)dnl
#
# UUCP connections on ucbarpa
#
# @(#)uucp.ucbarpa.m4	1.4 (Berkeley) 7/5/87
#
divert(0)dnl
CV	endotsew
CV	fateman
CV	franz
CV	interlan
CV	metron
