/* this file is generated automatically, do not edit */

/* directory for temporary uncompressed files */
#define TMP "/tmp"

/* extension for compressed files */
#define EXT ".gz"

/* maximal length of user-supplied extension */
#define MAXEXTLEN 5

/* program used to uncompress files */
#define UNCOMPR "/usr/bin/gzip", "-dc"

/* use /proc filesystem to find out command name */
#define HAVE_PROC

/* per user configuration file */
#define HOMECONF ".zlibrc"

/* system wide configuration file */
#define SYSTEMCONF "/usr/lib/zlibrc"

