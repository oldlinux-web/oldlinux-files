/*
 * QUOTA    An implementation of the diskquota system for the LINUX
 *          operating system. QUOTA is implemented using the BSD systemcall
 *          interface as the means of communication with the user level.
 *          Should work for all filesystems because of integration into the
 *          VFS layer of the operating system.
 *          This is based on the Melbourne quota system wich uses both user and
 *          group quota files.
 *
 *          This part accepts the rquota rpc-requests.
 *
 * Version: $Id: rquota_svc.c,v 2.0 1993/08/23 19:50:47 mvw Exp mvw $
 *
 * Authors: Marco van Wieringen <v892273@si.hhs.nl> <mvw@hacktic.nl>
 *          Edvard Tuinder <v892231@si.hhs.nl> <etuinder@hacktic.nl>
 *
 *          This program is free software; you can redistribute it and/or
 *          modify it under the terms of the GNU General Public License
 *          as published by the Free Software Foundation; either version
 *          2 of the License, or (at your option) any later version.
 */
#include <rpc/rpc.h>
#include "rquota.h"
#include <stdlib.h>
#include <rpc/pmap_clnt.h>
#include <string.h>
#include <memory.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <syslog.h>

#ifdef __STDC__
#define SIG_PF void(*)(int)
#endif

extern getquota_rslt *getquotainfo(int active, getquota_args *argp,
				   struct svc_req *rqstp);
extern getquota_rslt *rquotaproc_getquota_2_svc(getquota_args *argp,
						struct svc_req *rqstp);
extern getquota_rslt *rquotaproc_getactivequota_2_svc(getquota_args *argp,
						      struct svc_req *rqstp);

/*
 * Global authentication credentials.
 */
struct authunix_parms *unix_cred;

static void rquotaprog_2(struct svc_req *rqstp, register SVCXPRT *transp)
{
   union {
      getquota_args rquotaproc_getquota_2_arg;
      getquota_args rquotaproc_getactivequota_2_arg;
   } argument;
   char *result;
   xdrproc_t xdr_argument, xdr_result;
   char *(*local)(char *, struct svc_req *);

   /*
    * Don't bother authentication for NULLPROC.
    */
   if (rqstp->rq_proc == NULLPROC) {
      (void) svc_sendreply(transp, (xdrproc_t) xdr_void, (char *)NULL);
      return;
   }

   /*
    * First get authentication.
    */
   switch (rqstp->rq_cred.oa_flavor) {
      case AUTH_UNIX:
         unix_cred = (struct authunix_parms *)rqstp->rq_clntcred;
         break;
      case AUTH_NULL:
      default:
         svcerr_weakauth(transp);
         return;
   }

   switch (rqstp->rq_proc) {
      case RQUOTAPROC_GETQUOTA:
         xdr_argument = (xdrproc_t) xdr_getquota_args;
         xdr_result = (xdrproc_t) xdr_getquota_rslt;
         local = (char *(*)(char *, struct svc_req *)) rquotaproc_getquota_2_svc;
         break;

      case RQUOTAPROC_GETACTIVEQUOTA:
         xdr_argument = (xdrproc_t) xdr_getquota_args;
         xdr_result = (xdrproc_t) xdr_getquota_rslt;
         local = (char *(*)(char *, struct svc_req *)) rquotaproc_getactivequota_2_svc;
         break;

      default:
         svcerr_noproc(transp);
         return;
   }

   (void) memset((char *)&argument, 0, sizeof (argument));
   if (!svc_getargs(transp, xdr_argument, (caddr_t) &argument)) {
      svcerr_decode(transp);
      return;
   }
   result = (*local)((char *)&argument, rqstp);
   if (result != NULL && !svc_sendreply(transp, xdr_result, result)) {
      svcerr_systemerr(transp);
   }

   if (!svc_freeargs(transp, xdr_argument, (caddr_t) &argument)) {
      syslog(LOG_ERR, "unable to free arguments");
      exit(1);
   }
   return;
}

int main(int argc, char **argv)
{
   register SVCXPRT *transp;

   (void) pmap_unset(RQUOTAPROG, RQUOTAVERS);
   openlog("rquota", LOG_PID, LOG_DAEMON);

   transp = svcudp_create(RPC_ANYSOCK);
   if (transp == NULL) {
      syslog(LOG_ERR, "cannot create udp service.");
      exit(1);
   }
   if (!svc_register(transp, RQUOTAPROG, RQUOTAVERS, rquotaprog_2, IPPROTO_UDP)) {
      syslog(LOG_ERR, "unable to register (RQUOTAPROG, RQUOTAVERS, udp).");
      exit(1);
   }

   transp = svctcp_create(RPC_ANYSOCK, 0, 0);
   if (transp == NULL) {
      syslog(LOG_ERR, "cannot create tcp service.");
      exit(1);
   }
   if (!svc_register(transp, RQUOTAPROG, RQUOTAVERS, rquotaprog_2, IPPROTO_TCP)) {
      syslog(LOG_ERR, "unable to register (RQUOTAPROG, RQUOTAVERS, tcp).");
      exit(1);
   }

   init_rquotad();
   syslog(LOG_ERR, "svc_run returned");
   exit(1);
   /* NOTREACHED */
}
