#ifndef __LINUX_ACCT_H
#define __LINUX_ACCT_H

/*
 * refer to appropriate line in task_struct in header file
 * /usr/src/linux/include/linux/sched.h
 */
#define ACCT_COMM 16

struct acct
{
	long ac_exitcode;
	long ac_utime;
	long ac_stime;
	long ac_btime;
	int ac_tty;
	unsigned short ac_uid;
	unsigned short ac_gid;
	char ac_comm[ACCT_COMM];
	char ac_flag;
};

#define ASU	1
#define AFORK	2

#define AHZ     100

#endif
