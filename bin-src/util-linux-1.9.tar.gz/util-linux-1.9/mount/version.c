char version[] = "(u)mount: version from util-linux-1.7";
