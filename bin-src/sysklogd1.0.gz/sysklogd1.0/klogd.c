/*
 * Read log messages from the kernel - send them to syslogd
 *
 * Steve Lord (lord@cray.com) 7th Nov 92
 *
 * Modified to check for kernel info by Dr. G.W. Wettstein 02/17/93.
 *
 * Fri Mar 12 16:53:56 CST 1993:  Dr. Wettstein
 * 	Modified LogLine to use a newline as the line separator in
 *	the kernel message buffer.
 *
 *	Added debugging code to dump the contents of the kernel message
 *	buffer at the start of the LogLine function.
 *
 * Thu Jul 29 11:40:32 CDT 1993:  Dr. Wettstein
 *	Added syscalls to turn off logging of kernel messages to the
 *	console when klogd becomes responsible for kernel messages.
 *
 *	klogd now catches SIGTERM and SIGKILL signals.  Receipt of these
 *	signals cases the clean_up function to be called which shuts down
 *	kernel logging and re-enables logging of messages to the console.
 *
 * Sat Dec 11 11:54:22 CST 1993:  Dr. Wettstein
 *	Added fixes to allow compilation with no complaints with -Wall.
 *
 *      When the daemon catches a fatal signal (SIGTERM, SIGKILL) a 
 *	message is output to the logfile advising that the daemon is
 *	going to termiante.
 *
 */


#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <sys/fcntl.h>
#include <sys/stat.h>
#include <linux/time.h>

static int kmsg;
static enum LOGSRC {none, proc, kernel} logsrc;

static enum LOGSRC GetKernelLogSrc(void);

int sys_syslog(int, char *, int);

void CloseLogSrc()

{
	/* Turn on logging of messages to console. */
  	sys_syslog(7, NULL, 0);

  
        /* Shutdown the log sources. */
	switch ( logsrc )
	{
	    case kernel:
		sys_syslog(0, 0, 0);
		syslog(LOG_INFO, "Kernel logging (sys_syslog) stopped.");
		break;
            case proc:
		close(kmsg);
		syslog(LOG_INFO, "Kernel logging (proc) stopped.");
		break;
	    case none:
		break;
	}

	return;
}


void restart()

{
	signal(SIGCONT, restart);
	CloseLogSrc();
	logsrc = GetKernelLogSrc();
	return;
}

void stop()
{
	signal(SIGTSTP, stop);
	signal(SIGSTOP, stop);
	CloseLogSrc();
	logsrc = none;
	return;
}


void clean_up(int sig)

{
  	CloseLogSrc();
 	syslog(LOG_INFO, "Kernel log daemon terminating.");
 	sleep(1);
	closelog();
	exit(0);
}


static enum LOGSRC GetKernelLogSrc(void)

{
	auto struct stat sb;


	/* Disable logging of kernel messages to console. */
	sys_syslog(6, NULL, 0);


	/*
	 * First do a stat to determine whether or not the proc based
	 * file system is available to get kernel messages from.
	 */
	if ( (stat("/proc/kmsg", &sb) < 0)  &&  (errno == ENOENT) )
	{
	  	/* Initialize kernel logging. */
	  	sys_syslog(1, NULL, 0);
		syslog(LOG_INFO, "Kernel logging (sys_syslog) started.");
		return(kernel);
	}
	
	if ( (kmsg = open("/proc/kmsg", O_RDONLY)) < 0 )
	{
		syslog(LOG_ERR, "Cannot open proc file system.");
		exit(1);
	}
	syslog(LOG_INFO, "Kernel logging (proc) started.");
	return(proc);
}


static void LogLine(char *ptr, int len)

{
	auto char *nl;
	auto int index = 0;
	static char line[4096];

#if defined(DEBUG)
	fprintf(stderr, "Log buffer contains: %d characters.\n", len);
	while ( index <= len )
	{
		fprintf(stderr, "Character #%d - %d:%c\n", index, ptr[index], ptr[index]);
		++index;
	}
#endif
	
	while (len) {
		nl = strpbrk(ptr, "\r\n"); /* Find first line terminator */
		if (nl) {
			len -= nl - ptr + 1;
			strncpy(line + index, ptr, nl - ptr);
			line[index + nl - ptr] = '\0';
			ptr = nl + 1;
			index = 0;
			/* Check for empty log line (may be produced if 
			   kernel messages have multiple terminators, eg.
			   \n\r) */
			if (*line)
				syslog(LOG_ERR, line);
		 }
		 else{
			strncat(line + index, ptr, len);
			index += len;
			len = 0;
		}
	}

	return;
}


static void LogKernelLine(void)

{
	static char buffer[256];
	auto int len;

	len = sys_syslog(2, buffer, sizeof(buffer));
	LogLine(buffer, len);
	return;
}


static void LogProcLine(void)

{
	auto int rdcnt;
	auto char buf[4096];

	if ( (rdcnt = read(kmsg, buf, sizeof(buf))) < 0 )
		syslog(LOG_ERR, "Cannot read proc file system.");
	LogLine(buf, rdcnt);

	return;
}
	    
	  
int main()

{
	/*
	 * The following code allows klogd to auto-background itself.
	 * What happens is that the program forks and the parent quits.
	 * The child closes all its open file descriptors, and issues a
	 * call to setsid to establish itself as an independent session
	 * immune from control signals.
	 */
#if !defined(NO_FORK)
	if ( fork() == 0 )
	{
		auto int fl;
		
		/* This is the child closing its file descriptors. */
		for (fl= 0; fl <= FD_SETSIZE; ++fl)
			close(fl);
		setsid();
	}
	else
		exit(0);
#endif


	/* Basic setup. */
	signal(SIGINT, clean_up);
	signal(SIGKILL, clean_up);
	signal(SIGTERM, clean_up);
	signal(SIGTSTP, stop);
	signal(SIGSTOP, stop);
	signal(SIGCONT, restart);
	openlog("kernel", 0, LOG_KERN);

	/* Determine where kernel logging information is to come from. */
	sleep(1);
	logsrc = GetKernelLogSrc();

        /* The main loop. */
	while (1)
	{
		switch ( logsrc )
		{
			case kernel:
	  			LogKernelLine();
				break;
			case proc:
				LogProcLine();
				break;
		        case none:
				break;
		}
	}
}

#define __LIBRARY__
#include <linux/unistd.h>

#define __NR_sys_syslog __NR_syslog

_syscall3(int,sys_syslog,int, type, char *, but, int, len);
