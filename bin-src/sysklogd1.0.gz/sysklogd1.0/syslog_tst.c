/* Program to test daemon logging. */

/*
 * Sat Dec 11 12:07:50 CST 1993:  Dr. Wettstein
 *	Compiles clean with -Wall.  Renamed for first public distribution.
 *	Use this freely but if you make a ton of money with it I
 *	expect a cut...  :-)
 *
 */

#include <stdio.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/param.h>

extern int main(int, char **);


int main(int argc, char *argv[])
{
	openlog("DOTEST", LOG_PID, LOG_DAEMON);
	if (argc > 1)
	{
		while (argc-- > 1)
			syslog(LOG_INFO, argv++[1]);
	}
	else
	{
		syslog(LOG_ALERT, "Alert log.");
		syslog(LOG_CRIT, "Critical log.");
		syslog(LOG_ERR, "Error log.");
		syslog(LOG_WARNING, "Warning log.");
		syslog(LOG_NOTICE, "Notice log.");
		syslog(LOG_INFO, "Info log.");
		syslog(LOG_DEBUG, "Debug log.");
		closelog();
		return(0);
	}

	return(0);
}
