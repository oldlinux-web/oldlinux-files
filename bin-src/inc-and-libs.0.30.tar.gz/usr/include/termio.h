#ifndef _TERMIO_H
#define _TERMIO_H
/* OK, we'll assume that if this file is included, that termio is
   what is desired. */

#include <termios.h>
#define _IS_TERMIO

#undef VINTR
#define VINTR _VINTR
#undef VQUIT
#define VQUIT _VQUIT
#undef VERASE
#define VERASE _VERASE
#undef VKILL
#define VKILL _VKILL
#undef VEOF
#define VEOF _VEOF
#undef VMIN
#define VMIN _VMIN
#undef VEOL
#define VEOL _VEOL
#undef VTIME
#define VTIME _VTIME
#undef VEOL2
#define VEOL2 _VEOL2
#undef VSWTC
#define VSWTC _VSWTC
#endif
