#ifndef _SCNHDR_H
#define _SCNHDR_H

/* Compatibility with OSF/1 code. */

struct scnhdr {
      char s_name[8];
      long s_paddr;
      long s_vaddr;
      long s_size;
      long s_scnptr;
      long s_relptr;
      long s_lnnoptr;
      unsigned short s_nreloc;
      unsigned short s_nlnno;
      int s_flags;
};

#define _TEXT   ".text"
#define _DATA   ".data"
#define _BSS    ".bss"
#define _TV ".tv"
#define _INIT   ".init"
#define _FINI   ".fini"
#define _LIB    ".lib"
#define _RDATA  ".rdata"
#define _RCONST ".rconst"
#define _SDATA  ".sdata"
#define _SBSS   ".sbss"
#define _UCODE  ".ucode"
#define _LIT8   ".lit8"
#define _LIT4   ".lit4"
#define _LITA   ".lita"

#define STYP_REG 0x00000000
#define STYP_DSECT 0x00000001
#define STYP_NOLOAD 0x00000002
#define STYP_GROUP 0x00000004
#define STYP_PAD 0x00000008
#define STYP_COPY 0x00000010
#define STYP_TEXT 0x00000020
#define STYP_DATA 0x00000040
#define STYP_BSS 0x00000080
#define STYP_RDATA 0x00000100
#define STYP_SDATA 0x00000200
#define STYP_SBSS 0x00000400
#define STYP_UCODE 0x00000800
#define STYP_GOT 0x00001000
#define STYP_DYNAMIC 0x00002000
#define STYP_DYNSYM 0x00004000
#define STYP_REL_DYN 0x00008000
#define STYP_DYNSTR 0x00010000
#define STYP_HASH 0x00020000
#define STYP_DSOLIST 0x00040000
#define STYP_RESERVED1 0x00080000
#define STYP_CONFLICT 0x00100000
#define STYP_REGINFO 0x00200000
#define STYP_PACKAGE 0x00400000
#define STYP_PACKSYM 0x00800000
#define STYP_FINI 0x01000000
#define STYP_EXTENDESC 0x02000000
#define STYP_LITA 0x04000000
#define STYP_LIT8 0x08000000
#define STYP_LIT4 0x10000000
#define S_NRELOC_OVFL 0x20000000
#define STYP_LIB 0x40000000
#define STYP_INIT 0x80000000
#define STYP_EXTMASK 0x0FF00000
#define STYP_COMMENT 0x02100000
#define STYP_RCONST 0x02200000
#define STYP_XDATA 0x02400000
#define STYP_PDATA 0x02800000

#endif
