#define	MS_STAMP 3
#define	LS_STAMP 11
#define INCLUDE_STAMP "3.11"
#define BUILD_VERSION 2
