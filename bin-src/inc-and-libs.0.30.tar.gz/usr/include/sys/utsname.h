#ifndef _SYS_UTSNAME_H
#define _SYS_UTSNAME_H

#include <features.h>
#include <sys/param.h>

#ifndef __linux__
#include <linux/utsname.h>

#define utsname new_utsname

#else

struct utsname {
  char sysname[32];
  char nodename[32];
  char release[32];
  char version[32];
  char machine[32];
};

#endif

__BEGIN_DECLS

extern int uname __P ((struct utsname * __utsbuf));
extern int __uname __P ((struct utsname * __utsbuf));

__END_DECLS

#endif
