#ifndef _IO_H
#define _IO_H

#ifdef __alpha__

void outb(unsigned char b,unsigned long port);
void outw(unsigned short w,unsigned long port);
void outl(unsigned int l,unsigned long port);
unsigned int inb(unsigned long port);
unsigned int inw(unsigned long port);
unsigned int inl(unsigned long port);

#else

#include <asm/io.h>

#endif
#endif
