#ifndef _SYS_PTRACE_H
#define _SYS_PTRACE_H

#include <features.h>
#include <linux/ptrace.h>

__BEGIN_DECLS

#ifndef __alpha__
extern int	ptrace __P ((int __request, int __pid, int __addr,
			int __data));
#else
extern long	ptrace __P ((int __request, pid_t __pid, long __addr,
			long __data));
#endif

__END_DECLS

#endif /* _SYS_PTRACE_H */
