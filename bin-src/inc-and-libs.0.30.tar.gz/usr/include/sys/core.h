#ifndef _CORE_H
#define _CORE_H

/* 
 * I got this in a dream. 
 *
 *  This is only needed on the Alpha, for libbfd.a.
 */

#define MAXCOMLEN 16

#define CORE_VERS 1

#define SCNTEXT  1
#define SCNDATA  2
#define SCNRGN   3
#define SCNSTACK 4
#define SCNREGS  5
#define SCNOVFL  6

struct core_filehdr {
      char magic[4];
      unsigned short version;
      unsigned short nscns;
      int tid;
      unsigned int nthreads;
      int signo;
      char name[MAXCOMLEN+1];
};

struct core_scnhdr {
      unsigned short scntype;
      union {
	    int tid;
	    unsigned int prot;
      } c_u;
      void *vaddr;
      unsigned long size;
      unsigned int scnptr;
};

#endif
