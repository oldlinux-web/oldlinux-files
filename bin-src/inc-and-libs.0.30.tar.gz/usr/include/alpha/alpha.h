/*
 * This file contains structure and constant declarations related
 * to the Digital Alpha microprocessor.
 *
 * Copyright 1994 Digital Equipment Corporation, Maynard, MA.
 *
 */

#ifndef ALPHA_H
#define ALPHA_H

#ifdef LANGUAGE_C

/* This is how we express a quadword to a 32-bit compiler that
 * groks quadwords as "long long"s:
 */
typedef unsigned long long	U64;
typedef long long	S64;


/* Hardware Restart Parameter Block (HWRPB).  This is our roadmap
 * to the rest of the system on bootup.
 */
typedef struct hwrpb_struct {
	U64	rpb_paddr;		/* Phys addr of rpb */
	U64	rpb_idstring;		/* "HWRPB<0><0><0>" */
	U64	rpb_revision;		/* RPB rev level */
	U64	rpb_size;		/* Size of RPB in bytes */
	U64	rpb_pri_cpu_id;		/* primary CPU id */
	U64	rpb_page_size;		/* System page size */
	U64	rpb_pa_bits;		/* Physical addr bits supported */
	U64	rpb_max_asn;		/* highest addr spc no. supported */
	U64	rpb_ssn[2];		/* System serial number */
	U64	rpb_systype;		/* System type */
	U64	rpb_sysvar;		/* System variation */
	U64	rpb_sysrev;		/* System revision */
	U64	rpb_clkint_freq;	/* Interval clk interrupt frequency */
	U64	rpb_rpcc_freq;		/* Cycle counter frequency */
	U64	rpb_vptptr;		/* Virtual page table base */
	U64	rpb_reserved;		/* Reserved */
	U64	rpb_tbhint_offset;	/* Offset to TB hint block */
	U64	rpb_num_cpu_slots;	/* Number of CPU slots */
	U64	rpb_percpu_slot_size;	/* Size of CPU slot data area */
	U64	rpb_percpu_slot_offset;	/* Offset to per-CPU slots */
	U64	rpb_num_ctbs;		/* Number of CTBs */
	U64	rpb_ctb_size;		/* Size of CTB */
	U64	rpb_ctb_offset;		/* Offset to CTBs */
	U64	rpb_crb_offset;		/* Offset of console callback table */
	U64	rpb_memdesc_offset;	/* Offset to memory descriptor table */
	U64	rpb_cdb_offset;		/* Offset to config. data blk */
	U64	rpb_fru_offset;		/* Offset to FRU table */
	U64	rpb_tssr_va;		/* VA of terminal save state routine */
	U64	rpb_tssr_pv;		/* PV of terminal save state routine */
	U64	rpb_trsr_va;		/* VA of term. restore state routine */
	U64	rpb_trsr_pv;		/* PV of term. restore state routine */
	U64	rpb_cpurs_va;		/* VA of cpu restart routine */
	U64	rpb_cpurs_pv;		/* PV of cpu restart routine */
	U64	rpb_sys_reserved;	/* Reserved for system software */
	U64	rpb_hw_reserved;	/* Reserved for hardware */
	U64	rpb_checksum;		/* Checksum */
	U64	rpb_rxrdy_mask;		/* RXRDY bitmask */
	U64	rpb_txrdy_mask;		/* TXRDY bitmask */
} HWRPB;

/*
 * DEC processor types for Alpha systems.  Found in HWRPB.
 * These values are architected.
 */

#define EV3_CPU                 1       /* EV3                  */
#define EV4_CPU                 2       /* EV4 (21064)          */
#define LCA4_CPU                4       /* LCA4 (21066/21068)   */
#define EV5_CPU                 5       /* EV5 (21164)          */
#define EV45_CPU                6       /* EV4.5 (21064/xxx)    */

/*
 * DEC system types for Alpha systems.  Found in HWRPB.
 * These values are architected.
 */

#define ST_ADU                  1       /* Alpha ADU systype    */
#define ST_DEC_4000             2       /* Cobra systype        */
#define ST_DEC_7000             3       /* Ruby systype         */
#define ST_DEC_3000_500         4       /* Flamingo systype     */
#define ST_DEC_2000_300         6       /* Jensen systype       */
#define ST_DEC_3000_300         7       /* Pelican systype      */
#define ST_DEC_2100_A500        9       /* Sable systype        */
#define ST_DEC_AXPVME_64       10       /* AXPvme system type   */
#define ST_DEC_AXPPCI_33       11       /* NoName system type   */
#define ST_DEC_TLASER          12       /* Turbolaser systype	*/
#define ST_DEC_2100_A50        13       /* Avanti systype       */
#define ST_DEC_MUSTANG         14       /* Mustang systype      */
#define ST_DEC_ALCOR           15       /* Alcor systype	*/
#define ST_DEC_1000            17       /* Mikasa systype       */
#define ST_DEC_EB64            18       /* EB64 systype		*/
#define ST_DEC_EB66            19       /* EB66 systype		*/
#define ST_DEC_EB64P           20       /* EB64+ systype        */
#define ST_DEC_BURNS	       21	/* BURNS (laptop proto) */

#define PASS1_LCA_TYPE	       0x100000004ULL	/* Pass 1 LCA chip detect */


/* Console callback routine block.  This is found by adding the offset
 * in HWRPB.rpb_ccb_offset to the address of HWRPB itself.
 */
typedef struct _crb_struct {
	U64	crb_dispatch_va;	/* Phys addr of DISPATCH routine */
	U64	crb_dispatch_pa;	/* Virtual addr of DISPATCH routine */
	U64	crb_fixup_va;		/* Phys addr of FIXUP routine */
	U64	crb_fixup_pa;		/* Virtual addr of FIXUP routine */
	U64	crb_v_p_map_entries;	/* Number of entries in v-p map */
	U64	crb_pages_to_map;	/* Number of pages to be mapped */
	struct {
	    U64	map_vaddr;
	    U64	map_paddr;
	    U64	map_pgcount;
	} crb_page_map[1];		/* Actually, crb_v_p_map_entries */
					/* gives the number of entries here */

} CRB;

/* Memory cluster descriptor */
typedef struct _memclust_descrip {
	U64	start_pfn;		/* First PFN in cluster */
	U64	page_count;		/* Number of pages in cluster */
	U64	tested_pages;		/* Count of tested pages in cluster bitmap */
	U64	bitmap_va;		/* Virtual addr of cluster bitmap */
	U64	bitmap_pa;		/* Phys addr of cluster bitmap */
	U64	bitmap_checksum;	/* Checksum of cluster bitmap */
	U64	usage;			/* Cluster usage */
} MEM_CLUSTER;

/* Memory descriptor table */
typedef struct __memdesc_struct {
	U64	md_checksum;
	U64	md_optinfo_pa;
	U64	md_nclusters;
	MEM_CLUSTER	md_clusters[1];	/* Actually longer */
} MEMDESC;

/* per-cpu slots */
typedef struct _bootpcb {
    U64    rpb_ksp;             /* 000: kernel stack pointer */
    U64    rpb_usp;             /* 008: user stack pointer */
    U64    rpb_ptbr;            /* 010: page table base register */
    int    rpb_cc;              /* 018: cycle counter */
    int    rpb_asn;             /* 01C: address space number */
    U64    rpb_proc_uniq;       /* 020: proc/thread unique value */
    U64    rpb_fen;             /* 028: floating point enable */
    U64    rpb_palscr[2];       /* 030: pal scratch area */
    U64    rpb_pcbpad[8];       /* 040: padding for fixed size */
} BOOTPCB;

typedef struct rpb_percpu {
    BOOTPCB rpb_pcb;     	/* 000: boot/restart HWPCB */
    U64    rpb_state;           /* 080: per-cpu state bits */
    U64    rpb_palmem;          /* 088: palcode memory length */
    U64    rpb_palscratch;      /* 090: palcode scratch length */
    U64    rpb_palmem_addr;     /* 098: phys addr of palcode mem space */
    U64    rpb_palscratch_addr; /* 0A0: phys addr of palcode scratch space */
    U64    rpb_palrev;          /* 0A8: PALcode rev required */
    U64    rpb_proctype;        /* 0B0: processor type */
    U64    rpb_procvar;         /* 0B8: processor variation */
    U64    rpb_procrev;         /* 0C0: processor revision */
    char   rpb_procsn[16];      /* 0C8: proc serial num: 10 ascii chars */
    U64    rpb_logout;          /* 0D8: phys addr of logout area */
    U64    rpb_logout_len;      /* 0E0: length in bytes of logout area */
    U64    rpb_haltpb;          /* 0E8: halt pcb base */
    U64    rpb_haltpc;          /* 0F0: halt pc */
    U64    rpb_haltps;          /* 0F8: halt ps */
    U64    rpb_haltal;          /* 100: halt arg list (R25) */
    U64    rpb_haltra;          /* 108: halt return address (R26) */
    U64    rpb_haltpv;          /* 110: halt procedure value (R27) */
    U64    rpb_haltcode;        /* 118: reason for halt */
    U64    rpb_software;        /* 120: for software */
    U64    rpb_buffer[21];      /* 128: inter-console buffer area */
    U64    rpb_palrev_avail[16];/* 1D0: PALcode revs available */
    U64    rpb_pcrsvd[6];       /* 250: reserved for arch use */
/* the dump stack grows from the end of the rpb page not to reach here */
} RPB_PERCPU;

/* hardware PCB */
/*
 * single step information
 * used to hold instructions that have been replaced by break's when
 * single stepping
 */
struct ssi {
        int ssi_cnt;                    /* number of bp's installed */
        struct ssi_bp {
                U64 bp_addr;      	/* address of replaced instruction */
                unsigned bp_inst;       /* replaced instruction */
        } ssi_bp[2];
};

typedef struct _pcb {
        /*
         * Hardware portion of the PCB
         */
        U64  	pcb_ksp;        /* 0: kernel stack pointer         */
        U64     pcb_usp;        /* 8: user stack pointer           */
        U64     pcb_ptbr;       /* 16: page table base register     */
        unsigned int   pcb_cc;         /* 24: process cycle counter        */
        unsigned int   pcb_asn;        /* 32: address space number         */
        U64     pcb_proc_uniq;  /* 40: process/thread unique value  */
        U64     pcb_fen;        /* 48: floating point enable        */
        U64     pcb_palscr[2];  /* 56/64: pal scratch area             */
        /*
         * Software portion of the PCB (this is for OSF; may
	 * change completely for Linux!)
         */
        U64     pcb_asten;      /* reschedule ast enable        */
        U64     pcb_regs[33];    /* kernel context (C callee+pc) */
        U64     pcb_fpregs[32]; /* floating point registers     */
        U64     pcb_fpcr;       /* floating point control register */

        U64	pcb_paddr;      /* physical of this pcb         */
        U64	pcb_cpuptr;     /* ptr to per-cpu data of current processor */
        U64	pcb_sswap;     /* ptr for non-local resume     */

        U64     pcb_resched;    /* non-zero if time to resched  */
        U64     pcb_sstep;      /* non-zero if single stepping  */
        struct  ssi pcb_ssi;    /* single step state info */
        U64     pcb_ownedfp;    /* has used the fp at one time  */
        U64     pcb_nofault;    /* no fault trap handler flag   */
        U64     pcb_traparg_a0; /* 1st trap() arg passed to sendsig() */
        U64     pcb_traparg_a1; /* 2nd trap() arg passed to sendsig() */
        U64     pcb_traparg_a2; /* 3rd trap() arg passed to sendsig() */
        int     pcb_cpu_number;
        U64     pcb_kstack;
} PCB;

/* Page table entries */
struct _ptebits
{
unsigned int    _pg_v:1,         /* valid */
                _pg_flt_on:3,    /* fault on read/write/execute */
                _pg_asm:1,       /* address space match */
                _pg_gh:2,        /* granularity hint */
                :1,             /* reserved for hardware future */
                _pg_prot:8,      /* R/W kernel/executive/supervisor/user */
		_pg_software:16;	/* Bits for software use. */
unsigned int    _pg_pfnum;    	/* page frame number */
};

typedef union _pte {
    struct _ptebits	_bits;
    unsigned int	_longwords[2];
    U64			_quadword;
} PTE;

#define ALPHA_PTES_PER_PAGE	(ALPHA_PAGE_SIZE/sizeof(PTE))

#define	pg_v		_bits._pg_v
#define	pg_flt_on	_bits._pg_flt_on
#define	pg_asm		_bits._pg_asm
#define	pg_gh		_bits._pg_gh
#define	pg_prot		_bits._pg_prot
#define pg_software	_bits._pg_software
#define	pg_pfnum	_bits._pg_pfnum
#define pg_hiword	_longwords[1]
#define	pg_loword	_longwords[0]
#define pg_quadword	_quadword
#define pg_flags	_longwords[0]

/* Page protection codes */
#define			PG_FOR	1		/* fault-on-read */
#define			PG_FOW	2		/* fault-on-write */
#define			PG_FOE	4		/* fault-on-execute */
#define			PG_KERNEL_READ	0x01	/* Kernel read access */
#define			PG_USER_READ	0x02	/* User read access */
#define			PG_KERNEL_WRITE	0x10	/* Kernel write access */
#define			PG_USER_WRITE	0X20	/* User write access */
#define			PG_KERNEL_RW	0x11	/* Kernel read/write */
#define			PG_USER_RW	0x22	/* User read/write */
#define			PG_NOACCESS	0	/* No access */

#endif /* LANGUAGE_C */


#define		ALPHA_PAGE_SIZE	8192
#define		ALPHA_PG_SHIFT	13
#define		ALPHA_NPGPT	1024


/* PS (Processor Staatus) fields */
#define		PS_MODE		0x00000008
#define		PS_MODE_USER	0x00000008
#define		PS_MODE_KERNEL	0x00000000
#define		PS_IPL		0x00000007
#define		IPLMAX		7

/* Interrupt types */
#define		INT_IPI		0		/* Interprocessor interrupt */
#define		INT_CLOCK	1		/* timer tick */
#define		INT_MCHK	2		/* Machine check */
#define		INT_IO		3		/* I/O device */
#define		INT_PERF	4		/* Performance counter */

#ifdef LANGUAGE_C
/* Macros to extract the page-table indices for a given virtual address */

/* Because we're only using 32-bit virtual addresses, this will always
 * be zero
 */
#define	L1PT_INDEX(vaddr)	0
#define	L1PT_OFFSET(vaddr)	0
#define	L2PT_INDEX(vaddr)	(((unsigned long)(vaddr) & 0xff800000)>>23)
#define	L2PT_OFFSET(vaddr)	(((unsigned long)(vaddr) & 0xff800000)>>20)
#define	L3PT_INDEX(vaddr)	(((unsigned long)(vaddr) & 0x007fe000)>>13)
#define	L3PT_OFFSET(vaddr)	(((unsigned long)(vaddr) & 0x007fe000)>>10)
#endif /* LANGUAGE_C */

/* The memory layout for Linux/Alpha is as follows:
 *
 *	00000000 - 3fffffff	User memory
 *	40000000 - 5fffffff	Currently unused.  May become available
 *			 	for user memory once we optimize the loading
 *				of L2 pte's.
 *	60000000 - 6fffffff	Kernel VM (for vmalloc())
 *	70000000 - 7bffffff	KSEG
 *	7c000000 - 7fefffff	Kernel code/data/bss goes in here.
 *	7ff56000 - 7ff75fff	Kernel physical memory map (mem_map)
 *				(128Kb, bounded by size of KSEG)
 *	7ff76000 - 7ff77fff	Initial kernel stack (8Kb)
 * 	7ff78000 - 7ff79fff	System-wide Level-1 page table
 *	7ff7a000 - 7ff7bfff	System-wide Level-2 page table
 *	7ff7c000 - 7ff7dfff	Kernel code L3 page table
 *	7ff7e000 - 7ff7ffff	Kernel utility L3 page table
 *	7ff80000 - 7fffffff	Available for HWRPB (up to 512Kb)
 */

/* This is the number of user L2 PTEs */
#define		USER_L2PT_NENTRIES	128

/* This is the virtual address of the beginning of the kernel VM area. */
#define		KERNEL_VM_START		0x60000000
#define		KERNEL_VM_END		0x70000000

/* This is the virtual address of our "mini-KSEG".  Because we're running
 * in 32-bit mode, we cannot use the real KSEG except by jumping through
 * hoops.  So we map the physical memory to kernel virtual memory starting
 * at this address.  Note that because we only want to use the memory
 * from 0x70000000 to 0x7c000000, we're currently limited to 192Mb of 
 * physical memory on the system.  On the other hand, if we had that much
 * memory we could run OSF 8-)  Also, if we port Linux to 64 bits, we can
 * do away with this and just use the regular KSEG.
 */
#define		LINUX_KSEG_VADDR	0x70000000
#define		LINUX_KSEG_TOP		0X7c000000

/* This is the virtual address where we will map the kernel
 * code.
 */
#define		KERNEL_START_VADDR	0x7c000000

/* Translate a physical address into a kseg virtual address */
#define		KSEG_ADDRESS(addr) \
			(((unsigned long)(addr))+LINUX_KSEG_VADDR)
#define		PHYS_ADDRESS(addr) \
			(((unsigned long)(addr))-LINUX_KSEG_VADDR)

#define		KUTIL_START_VADDR	0x7ff00000
#define		MEM_MAP_VADDR		0x7ff56000

/* This is the virtual address of the HWRPB on system
 * initialization.
 */
#define		HWRPB_STARTUP_VADDR	0x10000000

/* This is the virtual address of the HWRPB after we've
 * mapped out kernel virtual memory.
 */
#define		HWRPB_SYSTEM_VADDR	0x7ff80000

/* This is the virtual address of the HWRPB CRB data areas 
 */
/* #define		HWRPB_CRB_VADDR		0x80000000 */
#define		HWRPB_CRB_VADDR		0x50000000 /* verify firmware bug... */

/* Virtual address of the system's level 1 page table */
#define		SYSTEM_L1PT_VADDR	0x7ff78000

/* Virtual address of the system's level 2 page table */
#define		SYSTEM_L2PT_VADDR	0x7ff7a000

/* Virtual address of the kernel's level 3 page table
 * for code
 */
#define		KCODE_L3PT_VADDR	0x7ff7c000

/* Virtual address of the kernel's level 3 page table
 * for utility areas (HWRPB, page tables, stack...)
 */
#define		KUTIL_L3PT_VADDR	0x7ff7e000

/* Initial kernel stack */
#define		KERNEL_INITIAL_SP	0x7ff78000

/* Initial kernel stack size */
#define		KERNEL_INITIAL_STACKSIZE	0x2000

#endif /* ALPHA_H */
