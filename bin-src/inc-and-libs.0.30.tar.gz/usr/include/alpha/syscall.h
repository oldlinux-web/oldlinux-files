#ifndef _ALPHA_SYSCALL_H
#define _ALPHA_SYSCALL_H

extern long int syscall0(long int call);
extern long int syscall1(long int a1,long int call);
extern long int syscall2(long int a1,long int a2,long int call);
extern long int syscall3(long int a1,long int a2,long int a3,long int call);
extern long int syscall4(long int a1,long int a2,long int a3,long int a4,long int call);
extern long int syscall5(long int a1,long int a2,long int a3,long int a4,long int a5,long int call);

#define _syscall0(type,name) type name(void) { return syscall0(SYS_##name); }
#define _syscall1(type,name,atype,a) type name(atype a) { return syscall1(a,SYS_##name); }
#define _syscall2(type,name,atype,a,btype,b) type name(atype a,btype b) { return syscall2(a,b,SYS_##name); }
#define _syscall3(type,name,atype,a,btype,b,ctype,c) type name(atype a,btype b,ctype c) { return syscall3(a,b,c,SYS_##name); }
#define _syscall4(type,name,atype,a,btype,b,ctype,c,dtype,d) type name(atype a,btype b,ctype c,dtype d) {  return syscall4(a,b,c,d,SYS_##name); }
#define _syscall5(type,name,atype,a,btype,b,ctype,c,dtype,d,etype,e) type name(atype a,btype b,ctype c,dtype d,etype e) { return syscall5(a,b,c,d,e,SYS_##name); }
#endif
