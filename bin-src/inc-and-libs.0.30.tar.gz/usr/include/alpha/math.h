#ifndef _ALPHA_MATH_H
#define _ALPHA_MATH_H

extern		    double __logb(double val);
extern		    double __scalb(double x,int n);
extern		    double __drem(double x,double y);
extern		    double __expm1(double x);

#endif
