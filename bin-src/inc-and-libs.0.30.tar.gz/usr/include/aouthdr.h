#ifndef _AOUTHDR_H
#define _AOUTHDR_H

/* Compatibility with OSF/1 code. */

struct aouthdr {
      short	magic;
      short	vstamp;
      short   bldrev;
      short   padcell;
      long 	tsize;
      long 	dsize;
      long 	bsize;
      long 	entry;
      long 	text_start;
      long 	data_start;
      long	bss_start;
      int	gprmask;
      int	fprmask;
      long	gp_value;
};

#define	OMAGIC	0407
#define	NMAGIC 0410
#define	ZMAGIC 0413
#define SMAGIC 0411
#define	LIBMAGIC 0443

#endif
