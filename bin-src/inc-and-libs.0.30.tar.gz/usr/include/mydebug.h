#ifndef MYDEBUG_H
#define MYDEBUG_H
#define dmesg(x) write(2,x,strlen(x))

static void _writeint(int i,char *msg) {
  char buf[30];
  char *ptr=buf+29;
  int j=i;
  if(j<0) j=-j;

  buf[29]=0;

  do {
    *(--ptr)='0'+j%10;
    j=j/10;
  } while(j);
  if(i<0) {
    *(--ptr)='-';
  }
  dmesg(ptr);
  dmesg(msg);
}
#endif
