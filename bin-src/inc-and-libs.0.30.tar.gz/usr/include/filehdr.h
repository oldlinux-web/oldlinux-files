#ifndef _FILEHDR_H
#define _FILEHDR_H

/* Compatibility with OSF/1 code. */

#define ALPHAMAGIC 0603
#define ALPHAUMAGIC 0617
struct filehdr {
      unsigned short f_magic;
      unsigned short f_nscns;
      int f_timdat;
      long f_symptr;
      int f_nsyms;
      unsigned short f_opthdr;
      unsigned short f_flags;
};

#endif
