#include_next <varargs.h>
