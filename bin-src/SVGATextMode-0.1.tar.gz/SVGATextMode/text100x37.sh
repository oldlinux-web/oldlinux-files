#!/bin/bash
#
# This (minimalistic) script changes VGA textmode and terminal settings
# for 6 virtual consoles. This example is for a 100x37 character mode.
echo "Changing to 100x37 character console"
SVGATextMode 100x37
setfont /usr/lib/kbd/consolefonts/Cyr_a8x16
for NUM in 1 2 3 4 5 6
do
  stty rows 37 </dev/tty$NUM
  stty columns 100 </dev/tty$NUM
done
  