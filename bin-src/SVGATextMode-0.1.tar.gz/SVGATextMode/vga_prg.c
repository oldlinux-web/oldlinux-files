/***
 *** VGA chip programming functions for SVGATextMode
 *** Written by Koen Gadeyne (kmg@barco.be)
 ***
 *** version : 0.1
 ***/

#include <stdio.h>
#include <unistd.h>
#include <asm/io.h>
#include <math.h>
#include "vga_prg.h"
#include "SVGATextMode.h"
  

/*
 * Some macro's and functions to make life easier (?!)
 */
 
void outb_SEQ(int index, unsigned char data)
{ 
  outb (index, SEQ_INDEX); outb (data, SEQ_DATA);
}

int inb_SEQ (int index)
{
  outb (index, SEQ_INDEX); return inb (SEQ_DATA);
}

void outbit_SEQ (int index, unsigned char bitno, int data)
{
  unsigned char bitmask = (1 << bitno);
  unsigned char onebit = ((data == 0) ? 0 : bitmask);
  outb_SEQ (index, (inb_SEQ(index) & ~bitmask) | onebit);
}

void outb_CRTC (int index, unsigned char data)
{
  outb (index, CRTC_INDEX); outb (data, CRTC_DATA);
}

int inb_CRTC (int index)
{
  outb (index, CRTC_INDEX); return inb (CRTC_DATA);
}

void outbit_CRTC (int index, unsigned char bitno, int data)
{
  unsigned char bitmask = (1 << bitno);
  unsigned char onebit = ((data == 0) ? 0 : bitmask);
  outb_CRTC (index, (inb_CRTC(index) & ~bitmask) | onebit);
}

void outb_GR_CTL(int index, unsigned char data)
{ 
  outb (index, GR_CTL_INDEX); outb (data, GR_CTL_DATA);
}

int inb_GR_CTL (int index)
{
  outb (index, GR_CTL_INDEX); return inb (GR_CTL_DATA);
}

void outb_ATR_CTL (int index, unsigned char data)
{
  inb(0x3da);
  outb (index & 0x1f, 0x3c0);
  outb ( data, 0x3c0);
  inb(0x3da);
  outb ( (index & 0x1f) | 0x20, 0x3c0);
  outb ( data, 0x3c0);
}

unsigned char inb_ATR_CTL (int index)
{
  int res;

  inb(0x3da);
  outb (index & 0x1f, 0x3c0);
  res=inb(0x3c1);
  inb(0x3da);
  outb ( (index & 0x1f) | 0x20, 0x3c0);
  inb(0x3c1);
  return res;
}

/*****************************************************************************************************************************/
int get_VGA_io_perm()
{
  if (ioperm(0x3b4, 0x3df - 0x3b4 + 1, 1)) return(-1);
  setuid(getuid());     /* renounce supervisor rights. */
  setgid(getgid());                    
  return(0);
}

/*****************************************************************************************************************************/

void TVGAClockSelect(int chipset, int num_clocks, int no)
{
    print_DEBUG("TVGAClockSelect: clock no %d (of total %d) for chipset %d.", no, num_clocks, chipset);
    outb(( inb(VGA_MISC_R) & 0xf3) | ((no << 2) & 0x0C) , VGA_MISC_W); /* bits 0 and 1 of clock no */
    outb_SEQ(0x0B, 0); inb_SEQ(0x0B);  /* Select "new mode regs" for CS2 and TVGA9000 CS3. */
#if 0
    outb_SEQ(0x0D, inb_SEQ(0x0D) & 0xF9);  /* set clock dividers to no division */
#else
    outbit_SEQ(0x0D, 1, 0);  /* set clock dividers (div 2) to no division */
    outbit_SEQ(0x0D, 2, 0);  /* set clock dividers (div 4 ?) to no division */
#endif    
    outbit_SEQ(0x0D, 0, no & 0x04);  /* bit 2 of clock no */
    if (chipset == CS_TVGA9000)
    {
       outbit_SEQ(0x0D, 6, no & 0x08);  /* bit 3 of clock no */
    }
    if ((chipset == CS_TVGA8900) && (num_clocks > 7))
    {
       outb_SEQ(0x0B, 0);    /* Switch to Old Mode for CS3 */
       outbit_SEQ(0x0E, 4, no & 0x08);      /* bit 3 of clock no */
    }
}

void s3ClockSelect(int no)
  /* clock number is supposed to be in the allowable range by now. error checking should have been done before */
{
   outb(inb(VGA_MISC_R) | 0x0C, VGA_MISC_W);
   outb_CRTC(0x42, no);
}

void ET4000ClockSelect(int no, int hibit)
{
   /* get access to extended registers */
   outb(3, 0x3bf);
   outb(0xa0, inb(VGA_MISC_R) & 0x01 ? 0x3d8 : 0x3b8);
   /* program clock */
   outb(( inb(VGA_MISC_R) & 0xf3) | ((no << 2) & 0x0C) , VGA_MISC_W); /* bits 0 and 1 of clock no */
   outbit_CRTC(0x34, 1, no & 0x04);                                   /* bit 2 of clock no */
#if 0
   switch (hibit)
   {
      case 0 :
         if (no>7) outb_SEQ(7, inb_SEQ(7) | 0x40);
            else outb_SEQ(7, inb_SEQ(7) & 0xBF);
         break;
      case 1 : 
         if (no>7) outb_SEQ(7, inb_SEQ(7) & 0xBF);
            else outb_SEQ(7, inb_SEQ(7) | 0x40);
         break;
      default:
         fprintf(stderr,"ET4000: invalid hibit code %d.\n",hibit);
   }
#else
   outbit_SEQ(7, 6, hibit == 0 ? (no & 0x08) : (no & 0x08)^0x08);     /* bit 3 of clock sel */
#endif
 
}

int CirrusClockSelect(float freq, float *closestfreq, int setit)
{
  float realclock;
  float fraction;
  int dmin,dmax,nmin,nmax;
  int nom,denom,closestnom,closestdenom;
  float delta;

  if(freq<CIRRUS_MIN_CLOCK || freq>CIRRUS_MAX_CLOCK) 
  {
     return(CLKSEL_OUT_OF_BOUNDS);
  }
         
  fraction=freq/CIRRUS_CLOCK_REF;
  
  dmin=1/fraction+0.5;
  dmax=127/fraction+0.5;
  
  if(dmin<=0) dmin=1;
  if(dmax>=124) dmax=124;
  
  nmin=fraction*dmin+0.5;
  nmax=fraction*dmax+0.5;
  
  if(nmin>=0) nmin=1;
  if(nmax>127) nmax=127;

  delta=1e10;
  closestnom=closestdenom=-1;
  for(nom=nmax;nom>=nmin;nom--)
  {
    if(nom/fraction+0.5 > 62)
    {  /* denom = 4-fold */
      denom=nom/(fraction*4)+0.5; denom*=4;
    }
    else
    {
      denom=nom/(fraction*2)+0.5; denom*=2;
    }
    if(denom<=0) denom=2;
    print_DEBUG("CIRRUS: %f",fabs(nom*CIRRUS_CLOCK_REF/denom-freq));
    if(fabs(nom*CIRRUS_CLOCK_REF/denom-freq)<delta)
    {
      closestnom=nom;
      closestdenom=denom;
      delta=fabs(nom*CIRRUS_CLOCK_REF/denom-freq);
    }
  }
  
  realclock=closestnom*CIRRUS_CLOCK_REF/closestdenom;
  print_DEBUG("CIRRUS: nom = %d ; denom = %d ; realclock = %f",closestnom,closestdenom,realclock);
  if(setit)
  {
    int sr,sr1;
    
    sr=closestnom;
    sr1=closestdenom>62 ? closestdenom/2 +1 : closestdenom & 0xfe;

/* clock in kHz is (numer * (CIRRUS_REF_KHZ / (denom & 0x3E)) >> (denom & 1) */
#define CLOCKVAL(n, d) \
   ((((n) & 0x7F) * CIRRUS_REF_KHZ / ((d) & 0x3E)) >> ((d) & 1))

  
  print_DEBUG("%d %d   %d",sr,sr1,CLOCKVAL(sr,sr1));
    /* Use VCLK3 for these extended clocks */
    outb (inb (0x3cc) | 0xc, 0x3c2);
    /* Set SRE and SR1E */
    outb_SEQ (0x0e, (inb_SEQ (0xe) & 0x80) | (sr & 0x7f));
    outb_SEQ (0x1e, (inb_SEQ (0x1e) & 0xc0) | (sr1 & 0x3f));
  }
  *closestfreq = realclock;
  return(0);  
}

int findclosestclock(float *gclocks, int num_gclocks, float req_clock, float *closest_clock)
{
   /* returns closest clock NUMBER when one is found, error code otherwise */
   /* should also take the standard VGA possibility to divide the dot clock by 2 !!! ==> more clocks */
   /* and the maybe an option to disable that for VGA chips that do NOT allow this ! */

   int i, closest=0;

#ifdef ALLOW_CLOCKDIV2
   for (i=0; i<(num_gclocks-1); i++) gclocks[i+num_gclocks] = gclocks[i]/2;
#endif

   /* find closest clock frequency */
#ifdef ALLOW_CLOCKDIV2
   for (i=0 ; i < num_gclocks*2 ; i ++)
#else
   for (i=0 ; i < num_gclocks ; i ++)
#endif
   {
      if ( fabs(gclocks[i] - req_clock) < fabs(gclocks[closest] - req_clock) ) { closest = i; }
   }
   *closest_clock = gclocks[closest];
   print_DEBUG("findclosestclock: closest clock nr %d = %f MHz.",closest, *closest_clock);
   if (closest < 0)
   {
      return(CLKSEL_DONOTHING);
   }
#ifdef ALLOW_CLOCKDIV2
   if (closest > num_gclocks*2)
#else
   if (closest > num_gclocks)
#endif
   {
      return(CLKSEL_ILLEGAL_NUM);
   }
   if (gclocks[closest] == 0)
   {
      return(CLKSEL_NULLCLOCK);
   }
   return(closest);
}

int GetClock(int chipset, float* clocks, int num_clocks, float freq, float *closestfreq)
{
   int result;
   
   switch(chipset)
   {
     case CS_CIRRUS: result = CirrusClockSelect(freq, closestfreq, 0);
                     break;
     default: result = findclosestclock(clocks,num_clocks,freq,closestfreq);
   }
   return(result);
}

int SetClock(int chipset, float* clocks, int num_clocks, float freq, float *closestfreq, int et4_hibit)
{
   int result, divby2=0;
   
   if ( (result=GetClock(chipset, clocks, num_clocks, freq, closestfreq)) < 0 ) return(result);
  /* clock number is supposed to be in the allowable range by now.
     error checking should have been done before.
     No error checking will be done in clock-setting routime! */
#ifdef ALLOW_CLOCKDIV2
   if (result > num_clocks-1) 
   /* Cirrus goes bananas when this register is programmed */
   {
      divby2 = 1;
      result -= num_clocks; /* make clock selection routine pick the real clock (before division by 2) */
   }
#endif
   switch(chipset)
   {
    case CS_CIRRUS : CirrusClockSelect(freq, closestfreq, 1);
                     break;
    case CS_S3     : s3ClockSelect(result);
                     break;
    case CS_ET4000 : ET4000ClockSelect(result,et4_hibit);
                     break;
    case CS_TVGA8900 :
    case CS_TVGA9000 : TVGAClockSelect(chipset, num_clocks, result);
                       break;
   }
#ifdef ALLOW_CLOCKDIV2
   if (chipset != CS_CIRRUS)
   {
      outbit_SEQ(1,3,divby2);
      if (divby2) print_DEBUG("Clock (%f) needed 'division by 2' feature.",*closestfreq);
   }
#endif
   usleep(150000); /* let PLL clock synthesizer stabilize */
   return(result);
}

/*****************************************************************************************************************************/

void unlock(int chipset)
{
   /* unlock ALL locked registers for specified chipset. A bit rough, but simplest */
   print_DEBUG("Unlocking chipset %d",chipset);
   outbit_CRTC (0x11, 7, 0); /* CRTC index 0x00..0x07 */
   switch(chipset)
   {
    case CS_CIRRUS :
       outb_SEQ (0x6, 0x12);	/* unlock cirrus special */
       break;
    case CS_S3     : 
       outb_CRTC(0x39, 0xa5); /* system extension regs (CRTC index 0x50..0x5E) */
       outb_CRTC(0x38, 0x48); /* S3 register set (CRTC index 0x30..0x3C) */
       outbit_CRTC(0x35, 4, 0); /* VERT timing regs (CRTC index 6,7(bit0,2,3,5,7),9,10,11(bits0..3),15,16 ) */
       outbit_CRTC(0x35, 5, 0); /* HOR timing regs (CRTC index 0..5, 17(bit2) ) */
       /* outbit_CRTC(0x40, 0, 1); */ /* enhanced register access, only for access to accelerator commands */
       break;
    case CS_ET4000 :
       break;
    case CS_TVGA9000 :
    case CS_TVGA8900 : 
#if 0  /* this does not work properlyon 8900CL */   
                       outb_SEQ(0x0B, 0);      /* Select "old mode" by writing to SEQ index 0x0B */
                       outb_SEQ(0x0E, 0x82);   /* unlock conf. reg */
#endif
                       break;
    default: print_err("UNLOCK VGA: unknown chipset #%d",chipset);
   }
}
/*****************************************************************************************************************************/

void special(int chipset)
/* chipset specific settings, like memory speed and the likes */
{
   switch(chipset)
   {
    case CS_CIRRUS : outb_SEQ(31,37);  /* set DRAM timing (34=62 Mhz) */
                     break;
    case CS_S3     : break;
    case CS_ET4000 : break;
    case CS_TVGA9000 :
    case CS_TVGA8900 : break;
    default: print_err("SPECIAL VGA settings: unknown chipset #%d",chipset);
   }
}
/*****************************************************************************************************************************/

void set_VERT_TOTAL (int vt)
{
  vt = vt - 2; /* must program actual value - 2 */
  outb_CRTC (0x6, vt & 0xff);       /* bits 0..7 */
  outbit_CRTC(0x7, 0, vt & 0x100);  /* bit 8 */ 
  outbit_CRTC(0x7, 5, vt & 0x200);  /* bit 9 */
}

void set_MAX_SCANLINE (int msl)
{
  msl = msl - 1;
  outb_CRTC (0x9, (inb_CRTC (0x9) & 0xe0) | (msl & 0x1f));
}

void set_VRETRACE (int start, int end)
{
  outb_CRTC (0x10, start & 0xff);                           /* start bits 0..7 */
  outbit_CRTC (0x7, 2, start & 0x100);                      /* start bit 8 */
  outbit_CRTC (0x7, 7, start & 0x200);                      /* start bit 9 */
  outb_CRTC (0x11, (inb_CRTC (0x11) & 0xf0) | (end & 0xf)); /* end */
}

void set_VDISPL_END (int vde)
{
  vde = vde - 1;
  outb_CRTC (0x12, vde & 0xff);      /* bits 0..7 */
  outbit_CRTC(0x7, 1, vde & 0x100);  /* bit 8 */
  outbit_CRTC(0x7, 6, vde & 0x200);  /* bit 9 */
}

void set_VBLANK (int start, int end)
{
  start = start - 1;
  outb_CRTC (0x15, start & 0xff);                       /* start bits 0..7 */
  outbit_CRTC(0x7, 3, start & 0x100);                   /* start bit 8 */
  outbit_CRTC(0x9, 5, start & 0x200);                   /* start bit 9 */
  outb_CRTC (0x16, (start & 0xFF) - 1 + (end - start)); /* end */
}

void set_CURSOR (int start, int end)
{
  outb_CRTC (0x0A,  (inb_CRTC(0x0a) & 0xe0) | (start & 0x1f) );
  outb_CRTC (0x0B,  (inb_CRTC(0x0b) & 0xe0) | (end   & 0x1f) );
}

void set_HOR_TOTAL (int htot)
{
  outb_CRTC(0, htot - 5);
}

void set_HOR_DISPL_END (int hend)
{
  print_DEBUG("set_HOR_DISPL_END: active chars = %d", hend);
  outb_CRTC(1, hend - 1);
}

void set_HSYNC (int start, int end)
{
  outb_CRTC(4, start);
  outb_CRTC(5, (inb_CRTC(5) & 0xe0) | (end & 0x1f));
}

void set_HBLANK (int start, int end)
{
  outb_CRTC(2, start);                                 /* start */
  outb_CRTC(3, (inb_CRTC(3) & 0xe0) | (end & 0x1f));   /* end bits 0..4 */
  outbit_CRTC(5, 7, end & 0x20);                       /* end bit 5 */  
}

void set_HSYNC_POL(int pol)
{
   outb((inb(VGA_MISC_R) & 0xBF) | ((pol < 0) ? 0x40 : 0x00) , VGA_MISC_W);
}

void set_VSYNC_POL(int pol)
{
   outb((inb(VGA_MISC_R) & 0x7F) | ((pol < 0) ? 0x80 : 0x00) , VGA_MISC_W);
}

void set_LOG_SCREEN_WIDTH(int width)
{
   outb_CRTC(0x13, width/2);
}

void set_textmode()
{
   outb_GR_CTL(6,inb_GR_CTL(6) & 0xFE);
   outb_ATR_CTL(16,inb_ATR_CTL(16) & 0xFE);
}

void set_graphmode()
{
   outb_GR_CTL(6,inb_GR_CTL(6) | 0x01);
   outb_ATR_CTL(16,inb_ATR_CTL(16) | 0x01);
}

int set_charwidth(int width)
{
   switch(width)
   {
      case 8: outbit_SEQ(1, 0, 1);
              break;
      case 9: outbit_SEQ(1, 0, 0);
              break;
      default: return(1);
   }
   print_DEBUG("Set_CharWidth: SEQ (1) = 0x%x",inb_SEQ(1));
   return(0);
}

