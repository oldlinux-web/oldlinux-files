/***
 *** constant data for some VGA cards
 ***/

#ifndef _SVGATEXTMODE_H
#define _SVGATEXTMODE_H
   
#define DO_HARDWARE
#define NODEBUG 

/* if ALLOW_CLOCKDIV2 defined, VGA clocks can be divided by two as well, so twice as many clocks available */
#define ALLOW_CLOCKDIV2

void print_err(char *format,...);
void print_warn(char *format,...);
void print_DEBUG(char *format,...);

/*
 * Some config for SVGATextMode istelf
 */
 
#define MAX_ATTRIBS	4
#define ATTRIB_LEN	10
#define MAX_CLOCKDEVIATION 3.0

/*
 * Supported Chipsets
 */
 
#define NUM_CHIPSETS      5
enum t_chipsets           { CS_S3=0, CS_CIRRUS=1 , CS_ET4000=2 , CS_TVGA8900=3 , CS_TVGA9000=4};
#define CHIPSET_STRINGS   { "S3" , "CLGD542x", "ET4000" , "TVGA8900" , "TVGA9000" }

/*
 * Cirrus Logic specific stuff
 */
 
#define CIRRUS_MIN_CLOCK 20.0
#define CIRRUS_MAX_CLOCK 85.0
#define CIRRUS_CLOCK_REF (14.318*2)   /* or 28.322 ??? */
#define CIRRUS_REF_KHZ (int)(CIRRUS_CLOCK_REF*1000)


/*
 * Clock selection error codes (MUST be negative !!!)
 */
 
#define CLKSEL_OUT_OF_BOUNDS	-4
#define CLKSEL_DONOTHING	-3
#define CLKSEL_ILLEGAL_NUM	-2
#define CLKSEL_NULLCLOCK	-1

/*
 * clock stuff
 */

#define MAX_CLOCKS		32   /* I suppose there are no chipsets with 32 clocks out there */
#define NUM_S3_CLOCKS		16
#define NUM_ET4000_CLOCKS	16

#define MIN_CLOCK		5.0
#define MAX_CLOCK		500.0

#endif