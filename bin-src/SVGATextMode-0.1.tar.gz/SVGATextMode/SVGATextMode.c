/***
 *** SVGATextMode, an SVGA textmode setting program
 *** Written by Koen Gadeyne (kmg@barco.be)
 ***
 *** Version: 0.1
 ***/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>
#include <sys/types.h>
#include <linux/vt.h>
#include <sys/ioctl.h>
#include "SVGATextMode.h"
#include "vga_prg.h"

char *CommandName;

void print_err(char *format,...)
{
  va_list argptr;
  va_start(argptr,format);
  fprintf(stderr,"%s: Error: ",CommandName);
  vfprintf(stderr,format,argptr);
  va_end(argptr);
  fputc('\n',stderr);
  exit(1);
}

void print_warn(char *format,...)
{
  va_list argptr;
  va_start(argptr,format);
  fprintf(stderr,"%s: Warning: ",CommandName);
  vfprintf(stderr,format,argptr);
  va_end(argptr);
  fputc('\n',stderr);
}

void print_DEBUG(char *format,...)
{
#ifdef DEBUG
  va_list argptr;
  va_start(argptr,format);
  fprintf(stderr,"DEBUG: ");
  vfprintf(stderr,format,argptr);
  va_end(argptr);
  fputc('\n',stderr);
#endif
}

void cleanupstring(char *tstring)
{
     char *p=tstring;
     while (*p) 
     {
        switch (*p)
          {
             case '#':              /* discard remarks */
             case '\n': *p = '\0';  /* convert \n terminated strings to \0 terminated ones */
                        break;
             case '\t':             /* TABS to spaces */
             case '"': *p = ' ';    /* convert " (quotes) to spaces */
                       break;
          }
          if (*p == '\0') break;    /* stop processing */
          p++;
     }
}

char* findlabel(FILE* inputfile, char* reqlabel)
{
   /* look for 'reqlabel' in config file, exit if not found */
   static char video_param_str[1024];
   char inlabel[256]="";
   int nfound=1;
   
   rewind(inputfile);
   while ( fgets(video_param_str,1024,inputfile) != NULL )
   {
      cleanupstring(video_param_str);
      sscanf(video_param_str, "%s",inlabel);
      if (!(nfound = strcasecmp(inlabel,reqlabel))) break;
   }
   if (nfound) print_err("Could not find '%s' line in config file '%s'. Aborting...",reqlabel,CONFIGFILE);
   return(video_param_str);
}

void clock_check(int result)
{
  if (result < 0)
  {
    switch(result)
    {
      case CLKSEL_DONOTHING:     print_warn("Clock selection: Warning: Clock not changed");
                                 break;
      case CLKSEL_ILLEGAL_NUM:   print_err("Clock selection: illegal clock number.");
                                 break;
      case CLKSEL_NULLCLOCK:     print_err("Clock selection: 0 MHz clock selected! It would lock up the video card. Aborting...");
                                 break;
      case CLKSEL_OUT_OF_BOUNDS: print_err("Clock selection: Requested clock frequency out of bounds");
                                 break;
      default: print_err("Clock selection: unknown error");
    }
  }
}

/****************************************************************************************************************************/
int main (argc, argv)
int argc;
char *argv[];
{
  char* req_label;
  char* arg_str;
  char tempstr[1024]="";
  const char *str_chipsets[NUM_CHIPSETS] = CHIPSET_STRINGS;

  int chipset = -1;
#ifdef ALLOW_CLOCKDIV2
  float clocks[MAX_CLOCKS*2];
#else
  float clocks[MAX_CLOCKS];
#endif
  int num_clocks=0;
  int et4_hibit=1;       /* "hibit" status ET4000 */
    
  float clockfreq,realclock,horfreq;
  int activepix, start_hsync, stop_hsync, totalpix;
  int activelines, start_vsync, stop_vsync, totallines;
  char attrib[MAX_ATTRIBS][ATTRIB_LEN];
  
  int textlines;
  int blanklines;
  int charsperline;

  struct vt_sizes *p_my_vt_size;      /* this struct passes the new screen size on to the kernel */
  
  int i=0, result=0;

  int font_height=16, font_width=8;      /* height/width of character cell */
  int h_polarity = -1, v_polarity = 1; /* default sync polarities: May not be OK */
  
  FILE *param_file;
  
  CommandName = argv[0];

 /*
  * command-line argument parsing
  */
  if (argc != 2)
     print_err("usage: %s textmodelabel",argv[0]);
  else req_label = argv[1];

 /*
  * open parameter file
  */
  print_DEBUG("Parameter file = %s",CONFIGFILE);
  if ((param_file = fopen(CONFIGFILE,"r")) == NULL)
  {
      perror("fopen");
      print_err("Could not open Text mode config file '%s'",CONFIGFILE);
  }

 /*
  * get chipset definition 
  */
  sscanf(findlabel(param_file, "ChipSet"), "%*s %s", tempstr);
  for (i=0; i<NUM_CHIPSETS; i++) { if (!strcasecmp(tempstr,str_chipsets[i])) chipset=i; };
  if ((chipset < 0) || (chipset > NUM_CHIPSETS))
  {
     fprintf(stderr,"Supported chipsets are: ");
     for (i=0; i<NUM_CHIPSETS; i++) fprintf(stderr,"'%s' ",str_chipsets[i]);
     fputc('\n',stderr);
     print_err("Unknown ChipSet definition '%s' in config file '%s'. Aborting...",tempstr,CONFIGFILE);
  }
  print_DEBUG("Selecting chipset #%d = %s", chipset, str_chipsets[chipset]);
  
 /*
  * For ET4000 only: get "high-bit" option for clock selection.
  */
  if (chipset == CS_ET4000)
  {
     sscanf(findlabel(param_file, "Option"), "%*s %s", tempstr);
     if ( strcasecmp(tempstr,"hibit_high") && strcasecmp(tempstr,"hibit_low") )
        print_err("ET4000 option must be either 'hibit_high' or 'hibit_low' in config file '%s'. Aborting...",CONFIGFILE);
     if (!strcasecmp(tempstr,"hibit_high")) et4_hibit=1;
        else if (!strcasecmp(tempstr,"hibit_low")) et4_hibit=0;
           else et4_hibit=-1;
     print_DEBUG("ET4000 hibit option: %d", et4_hibit);
  }
  

 /*
  * get pixel clocks (must be on ONE line!)
  */
  switch (chipset)
  {
    case CS_CIRRUS: break;
    default:
        arg_str = findlabel(param_file, "Clocks");
        num_clocks = 0;
        arg_str = strtok(arg_str," ");
        while ((arg_str=strtok(NULL," ")) != NULL) clocks[num_clocks++] = atof(arg_str);
        if ((num_clocks <4) || (num_clocks >32))
           print_err("Strange number of clocks (%d) in config file '%s'",num_clocks,CONFIGFILE);
  }
  print_DEBUG("Clocks: found %d clocks",num_clocks);

 /*
  * find requested text mode line
  */
  arg_str = findlabel(param_file, req_label);
  result = sscanf(arg_str, "%*s %f  %d %d %d %d  %d %d %d %d   %s %s %s %s\n",
              &clockfreq,
              &activepix, &start_hsync, &stop_hsync, &totalpix,
              &activelines, &start_vsync, &stop_vsync, &totallines,
              attrib[0], attrib[1], attrib[2], attrib[3]);
  if (result<10)
     print_err("Badly formed textmode config string at label '%s' in config file '%s'",req_label,CONFIGFILE);
  print_DEBUG("Selected Mode = '%s', Mode Line = '%s'", req_label, arg_str);
  

 /*
  *  parse attribute strings
  */
  for (i=0; i<MAX_ATTRIBS; i++)
  {
     if      (!strcasecmp(attrib[i],"font")) 
     {
        /* get size attribute */
        if (++i >= MAX_ATTRIBS)
           print_err("'font' attribute must be followed by a font size (e.g. 8x16)");
        if (sscanf(attrib[i], "%dx%d", &font_width, &font_height) < 2)
           print_err("'font' attribute must be followed by a font size (e.g. 8x16), not '%s'", attrib[i]);
        if ((font_width<8) || (font_width>9)) 
           print_err("Illegal font width: %d. Must be 8 or 9.",font_width);
        if ((font_height<1) || (font_height>32)) 
           print_err("Illegal font height: %d. Must be 1..32.",font_height);
        print_DEBUG("attribute parsing: Font size read = %dx%d", font_width, font_height);
     }
     else if (!strcasecmp(attrib[i],"-hsync")) h_polarity = -1;
     else if (!strcasecmp(attrib[i],"+hsync")) h_polarity = 1;
     else if (!strcasecmp(attrib[i],"-vsync")) v_polarity = -1;
     else if (!strcasecmp(attrib[i],"+vsync")) v_polarity = 1;
     else if (strcasecmp(attrib[i],"")) 
       print_warn("Only supported attributes are: +hsync, -hsync, +vsync, -vsync and font: '%s' attribute ignored.",attrib[i]);
  }
  print_DEBUG("attribute parsing: sync polarities: Hsync: %d, Vsync: %d", h_polarity, v_polarity);
  
 /*
  * look for a suitable clock for the specified chip set
  */
  result = GetClock(chipset, clocks, num_clocks, clockfreq, &realclock);
  clock_check(result);
  if( fabs(realclock-clockfreq)> MAX_CLOCKDEVIATION )
    print_err("The closest available clock %f differs too much from specified clock %f",realclock,clockfreq);

 /*
  * calculate some screen parameters
  */
  textlines = activelines / font_height;
  activelines = font_height * textlines; /* make activelines integer multiple of font_height */
  blanklines = totallines - activelines;
  charsperline = (activepix / 8) & 0xFFFFFFFE; /* must be multiple of 2 in VGA byte-mode adressing */  

#ifdef DO_HARDWARE

 /*
  * now get to the REAL hardware stuff !
  */
  /* someone says this should be checked AT THE BEGINNING, not here... */
  if (get_VGA_io_perm() != 0) print_err("Cannot get VGA I/O permissions: must be superuser!");
/*  WAIT_VERT_BLK; */
  SCREEN_OFF;
  unlock(chipset);

  special(chipset); /* change chipset-specific things, if needed */

  result = SetClock(chipset, clocks, num_clocks, clockfreq, &realclock, et4_hibit);
  clock_check(result);

  special(chipset); /* change chipset-specific things, if needed */

  set_MAX_SCANLINE (font_height);

  set_VERT_TOTAL (totallines);
  set_VDISPL_END (activelines);
  set_VRETRACE (start_vsync, stop_vsync);
  set_VBLANK (start_vsync, stop_vsync);

  set_HOR_TOTAL(totalpix/8);
  set_HOR_DISPL_END(charsperline);
  set_HSYNC(start_hsync/8, stop_hsync/8);
  set_HBLANK((start_hsync-1)/8, stop_hsync/8);
  set_LOG_SCREEN_WIDTH(charsperline);

  set_CURSOR(font_height-2, font_height-1); /* cursor start/end */

 /*
  * set sync polarity : some monitors (especially those old ones
  * without digital controls) use it to change vertical screen size 
  */
     
  set_HSYNC_POL(h_polarity); set_VSYNC_POL(v_polarity);

  set_textmode();
  if (set_charwidth(font_width)) print_err("Illegal character width: %d",font_width);
  
  SCREEN_ON;
  
 /*
  * resize the internal kernel VT parameters, so they comply with the new ones
  */
  p_my_vt_size = (struct vt_sizes *) malloc(sizeof(struct vt_sizes));
  p_my_vt_size->v_rows = textlines;
  p_my_vt_size->v_cols = charsperline;
  p_my_vt_size->v_scrollsize = 0; /* kernel tries to get as many scroll-back lines as possible by itself (?) */
  if (ioctl(0, VT_RESIZE, p_my_vt_size)) {
      perror("VT_RESIZE");
      print_err("");
  }

#endif

 /*
  * show the user what he has just done
  */
  horfreq = (realclock*1000)/( ((int)(totalpix / 8)) * font_width);
  print_DEBUG("Refresh will be %3.2fkHz/%3.1fHz",horfreq,(horfreq*1000)/totallines);
  printf("Chipset = '%s', Textmode clock = %3.2f MHz, %dx%d chars, CharCell = %dx%d. Refresh = %3.2fkHz/%3.1fHz.\n",
          str_chipsets[chipset],realclock,charsperline,textlines,font_width,font_height,horfreq,(horfreq*1000)/totallines);

  return(0);
}

