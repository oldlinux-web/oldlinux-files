/***
 *** VGA chip programming functions
 ***/

#ifndef _VGA_PRG_H
#define _VGA_PRG_H

#undef DEBUG_CIRRUS

#ifdef DEBUG
#define DEBUG_CIRRUS
#endif
 
/*#define floatabs(a) ((a)< (float)0.0 ? (-(a)) : (a))*/

/*
 * if ALLOW_CLOCKDIV2 defined, VGA clocks can be divided by two as well, so twice as many clocks available
 */
#define ALLOW_CLOCKDIV2


/*
 * Some important VGA registers
 */

#define SEQ_INDEX	0x3C4
#define SEQ_DATA	0x3C5
#define CRTC_INDEX	0x3D4
#define CRTC_DATA	0x3D5
#define VGA_MISC_R	0x3CC
#define VGA_MISC_W	0x3C2
#define GR_CTL_INDEX	0x3CE
#define GR_CTL_DATA	0x3CF
#define ATR_CTL_INDEX	0x3CE
#define ATR_CTL_DATA	0x3CF

void outb_SEQ(int index, unsigned char data);

int inb_SEQ (int index);

void outbit_SEQ (int index, unsigned char bitno, int data);

void outb_CRTC (int index, unsigned char data);

int inb_CRTC (int index);

void outbit_CRTC (int index, unsigned char bitno, int data);

void outb_GR_CTL(int index, unsigned char data);

int inb_GR_CTL (int index);

void outb_ATR_CTL (int index, unsigned char data);

unsigned char inb_ATR_CTL (int index);

#define SCREEN_OFF	{ outbit_SEQ(0x1, 5, 1); }
#define SCREEN_ON	{ outbit_SEQ(0x1, 5, 0); }
#define WAIT_VERT_BLK	{ while(inb(0x3c2) & 0x80); }

/*****************************************************************************************************************************/
int get_VGA_io_perm();

/*****************************************************************************************************************************/

void TVGAClockSelect(int chipset, int num_clocks, int no);

void s3ClockSelect(int no);

void ET4000ClockSelect(int no, int hibit);

int CirrusClockSelect(float freq, float *closestfreq, int setit);

int findclosestclock(float *gclocks, int num_gclocks, float req_clock, float *closest_clock);

int GetClock(int chipset, float* clocks, int num_clocks, float freq, float *closestfreq);

int SetClock(int chipset, float* clocks, int num_clocks, float freq, float *closestfreq, int et4_hibit);


void unlock(int chipset);

void special(int chipset);



void set_VERT_TOTAL (int vt);

void set_MAX_SCANLINE (int msl);

void set_VRETRACE (int start, int end);

void set_VDISPL_END (int vde);

void set_VBLANK (int start, int end);

void set_CURSOR (int start, int end);

void set_HOR_TOTAL (int htot);

void set_HOR_DISPL_END (int hend);

void set_HSYNC (int start, int end);

void set_HBLANK (int start, int end);

void set_HSYNC_POL(int pol);

void set_VSYNC_POL(int pol);

void set_LOG_SCREEN_WIDTH(int width);

void set_textmode();

void set_graphmode();

int set_charwidth(int width);

void outb_ATTR (int index, unsigned char data);

unsigned char inb_ATTR (int index);

#endif