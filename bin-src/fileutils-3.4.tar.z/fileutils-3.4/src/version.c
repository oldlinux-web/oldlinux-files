/* Make the binaries identifiable with the RCS ident command.  */
char *version_string = "\n$Version: GNU fileutils 3.4 $\n";
