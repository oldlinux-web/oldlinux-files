#ifndef _LINUX_B004_H
#define _LINUX_B004_H

/*
 * usr/include/linux/b004.h
 * based on
 * usr/include/linux/lp.h c.1991-1992 James Wiegand
 * many modifications copyright (C) 1992 Michael K. Johnson
 *
 * Christoph Niemann (niemann@rubdv15.ETDV.ruhr-uni-bochum.de)
 */
#define B004_DEVICE	24
#define B004_NAME	"link"

/*
 * Per POSIX guidelines, this module reserves the B004 and b004 prefixes
 * These are the b004_table.flags flags...
 */
#define B004_EXIST 		0x0001	/* Is a B004-Board with at least one 
					   Transputer present ? */
#define B004_BUSY  		0x0002	/* Is the B004-board in use ? */
#define B004_READ_ABORT		0x0004  /* abort reading after timeout ? */
#define B004_WRITE_ABORT	0x0008  /* abort writing after timeout ? */


/* This is the amount of time that the driver waits for the link to
 * catch up when the C012's buffer appears to be filled.  If you
 * want to tune this, decrease or increase this number.
 * This is in hundredths of a second, the default 1 being .01 second.
 */

#define B004_INIT_TIME 1

/* IOCTL numbers */
#define B004TIME		0x0001  /* corresponds to B004_INIT_TIME */
#define B004RESET		0x0002
#define B004WRITEABLE		0x0004
#define B004READABLE		0x0008
#define B004ANALYSE		0x0010
#define B004ERROR		0x0020
#define B004READTIMEOUT		0x0040
#define B004WRITETIMEOUT	0x0080
#define B004READABORT		0x0100
#define B004WRITEABORT		0x0200


/* timeout for printk'ing a timeout, in jiffies (100ths of a second).
   This is also used for re-checking error conditions if B004_READ_ABORT or 
   B004_WRITE_ABORT is not set. This is the default behavior for reading.
   writing has the timeout enabled per default. */

#define B004_INIT_WRITE_TIMEOUT	1000
#define B004_INIT_READ_TIMEOUT	100

#define B004_BASE	0x150		/* IO-address */
#define B004_IDR	B004_BASE + 0	/* Input Data Register */
#define B004_ODR	B004_BASE + 1	/* Output Data Register */
#define B004_ISR	B004_BASE + 2	/* Input Status Register */
#define B004_OSR	B004_BASE + 3	/* Output Status Register */
#define B004_RESET	B004_BASE + 16	/* Reset/Error Register */
#define B004_ERROR	B004_BASE + 16
#define B004_ANALYSE	B004_BASE + 17	/* Analyse Register */

struct b004_struct {
	int flags;
	unsigned int time;
	unsigned int read_timeout;
	unsigned int write_timeout;
};

#define B004_NO 1

#define B004_TIME		b004_table.time
#define B004_F			b004_table.flags
#define B004_READ_TIMEOUT	b004_table.read_timeout
#define B004_WRITE_TIMEOUT	b004_table.write_timeout
#define B004_MAXTRY 		100

/* 
 * bit defines for C012 status ports
 * base + 2/3
 * accessed with B004_IS, B004_OS, which gets the byte...
 */
#define B004_READBYTE	0x01
#define B004_WRITEBYTE	0x01

/* 
 * defines for C012 reset/error port
 * base + 16
 * accessed with 
 */
#define B004_ASSERT_RESET	0x01	/* resetting the transputer */
#define B004_DEASSERT_RESET	0x00
#define B004_TEST_ERROR		0x01	/* for testing the transputer's error
					  flag */

/*
 * defines for C012 analyse port
 * base + 17
 *
 */
#define B004_ASSERT_ANALYSE	0x01	/* switch transputer in analyse-mode */
#define B004_DEASSERT_ANALYSE	0x00

#define B004_RESET_JIFFIES	3
#define B004_ANALYSE_JIFFIES	2


/*
 * function prototypes
 */

extern long b004_init(long);

#endif
