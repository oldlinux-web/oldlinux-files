/************************************************************************
*									*
*	Device Driver for INMOS-B004 compatible Link-Interfaces		*
*									*
*	Copyright (C) 1993 by Christoph Niemann				*
*	based on /linux/kernel/chr_drv/lp.c				*
*									*
*************************************************************************/

/* Copyright (C) 1992 by Jim Weigand, Linus Torvalds, and Michael K. Johnson
*/

#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/b004.h>

#include <asm/io.h>
#include <asm/segment.h>

#undef B004_DEBUG 
#undef B004_DEBUG_MORE

/* If your link interface does not work with the normal io-commands use
   the slower ones. But I think this should be no problem for any C012
   board.
   Defining the symbol B004_REALLY_SLOW_C012 will decrease the data-
   transfer-rate from about 300 KBytes/sec to 200 KBytes/sec
   (on my no name 486/33/8).
*/

#ifdef B004_REALLY_SLOW_C012
#define outb outb_p
#define inb inb_p
#endif

struct b004_struct b004_table =	{
				  B004_WRITE_ABORT, 
				  B004_INIT_TIME,
				  B004_INIT_READ_TIMEOUT,
				  B004_INIT_WRITE_TIMEOUT
				};
	

static void b004_reset( void )
{

#ifdef	B004_DEBUG
	printk("B004 resetting transputer\n");
#endif

	outb( B004_DEASSERT_ANALYSE, B004_ANALYSE );
	current->state = TASK_INTERRUPTIBLE;
	current->timeout = jiffies + B004_ANALYSE_JIFFIES;
	schedule();

	outb( B004_DEASSERT_RESET, B004_RESET );
	current->state = TASK_INTERRUPTIBLE;
	current->timeout = jiffies + B004_RESET_JIFFIES;
	schedule();

	outb( B004_ASSERT_RESET, B004_RESET );
	current->state = TASK_INTERRUPTIBLE;
	current->timeout = jiffies + B004_RESET_JIFFIES;
	schedule();

	outb( B004_DEASSERT_RESET, B004_RESET );
	current->state = TASK_INTERRUPTIBLE;
	current->timeout = jiffies + B004_RESET_JIFFIES;
	schedule();

#ifdef B004_DEBUG
	printk("B004 reset done\n");
#endif

}

static void b004_analyse( void )
{

#ifdef	B004_DEBUG
	printk("B004 switching transputer to analyse-mode\n");
#endif

	outb( B004_DEASSERT_ANALYSE, B004_ANALYSE );
	current->state = TASK_INTERRUPTIBLE;
	current->timeout = jiffies + B004_ANALYSE_JIFFIES;
	schedule();

	outb( B004_ASSERT_ANALYSE, B004_ANALYSE );
	current->state = TASK_INTERRUPTIBLE;
	current->timeout = jiffies + B004_RESET_JIFFIES;
	schedule();

	outb( B004_ASSERT_RESET, B004_RESET );
	current->state = TASK_INTERRUPTIBLE;
	current->timeout = jiffies + B004_RESET_JIFFIES;
	schedule();

	outb( B004_DEASSERT_RESET, B004_RESET );
	current->state = TASK_INTERRUPTIBLE;
	current->timeout = jiffies + B004_ANALYSE_JIFFIES;
	schedule();

	outb( B004_DEASSERT_ANALYSE, B004_ANALYSE );
	current->state = TASK_INTERRUPTIBLE;
	current->timeout = jiffies + B004_RESET_JIFFIES;
	schedule();

#ifdef B004_DEBUG
	printk("B004 switching done\n");
#endif

}

#ifdef B004_DEBUG
	unsigned int b004_total_bytes_read = 0;
	unsigned int b004_read_last_call = 0;
#endif

static int b004_read(struct inode * inode, struct file * file, char * buf, int count)
{
	int	i;
	char 	*temp = buf;

#ifdef B004_DEBUG
	if (jiffies-b004_read_last_call > B004_TIME) 
		b004_total_bytes_read = 0;
	b004_read_last_call = jiffies;
#ifdef B004_DEBUG_MORE
	printk("B004 reading %d bytes from link\n", count);
#endif
#endif

	if ( count < 0) {
#ifdef B004_DEBUG
		printk("B004 invalid argument for reading: count = %d\n", count);
#endif
		return -EINVAL;
	}

	while ( count ) {
		/* now read a byte from the link-interface */
		for ( i = 0; !(inb(B004_ISR) & B004_READBYTE) && 
			(i < B004_MAXTRY); i++);
		/* only update counting vars if C012 is able to send a byte */
		if ( i < B004_MAXTRY ) { 
			put_fs_byte( (char) inb( B004_IDR ), temp++ );
			count--;
#ifdef B004_DEBUG
			b004_total_bytes_read++;
#endif
			if ( need_resched ) 
				schedule();
		} else	{ /* not read */
			/* check for signals before going to sleep */
			if ( (current->signal & ~current->blocked) && (count > 0) )
				return temp - buf;
#ifdef B004_DEBUG
			printk("B004 sleeping at %d bytes for %d jiffies (reading)\n",
				b004_total_bytes_read, B004_TIME );
			b004_total_bytes_read=0;
#endif
			current->state = TASK_INTERRUPTIBLE;
			current->timeout = jiffies + B004_TIME;
			schedule();

			/* If nothing is coming from the C012
			   for a considerable length of time,
			   someone oughtta know.  */
			while ( !( inb(B004_ISR) & B004_READBYTE ) ) {

				/* check for signals before going to sleep */
				if ( (current->signal & ~current->blocked) && (count > 0) )
					return temp - buf;

				current->state = TASK_INTERRUPTIBLE;
				current->timeout = jiffies + B004_READ_TIMEOUT;
				schedule();
#ifdef B004_DEBUG
				printk("B004: timeout reading from link\n");
#endif
				if ( !( inb(B004_ISR) & B004_READBYTE ) && (B004_F & B004_READ_ABORT) ) {
					printk("B004: timeout reading from link\n");
					return temp - buf ? temp - buf : -EFAULT;
				}
				
			}
		}
	}
#ifdef B004_DEBUG_MORE
	printk("B004 reading successful\n");
#endif
	return temp - buf;
}


#ifdef B004_DEBUG
	unsigned int b004_total_bytes_written = 0;
	unsigned int b004_write_last_call = 0;
#endif

static int b004_write(struct inode * inode, struct file * file, char * buf, int count)
{
	int	i;
	char	*temp = buf;

#ifdef B004_DEBUG
	if (jiffies-b004_write_last_call > B004_TIME) 
		b004_total_bytes_written = 0;
	b004_write_last_call = jiffies;
#ifdef B004_DEBUG_MORE
	printk("B004 writing %d bytes to link\n", count);
#endif
#endif

	if ( count < 0) {
#ifdef B004_DEBUG
		printk("B004 invalid argument for writing: count = %d\n", count);
#endif
		return -EINVAL;
	}

	while ( count ) {
		/* now write this byte to the link-interface */
		for ( i = 0; !(inb(B004_OSR) & B004_WRITEBYTE) && 
			(i < B004_MAXTRY); i++);
		/* only update counting vars if C012 is able to receive byte */
		if ( i < B004_MAXTRY ) { 
			outb( get_fs_byte(temp++), B004_ODR );
			count--;
#ifdef B004_DEBUG
			b004_total_bytes_written++;
#endif
			if ( need_resched )
				schedule();
		} else	{ /* not written */
			/* check for signals before going to sleep */
			if ( (current->signal & ~current->blocked) && (count > 0))
				return temp - buf;
#ifdef B004_DEBUG
			printk("B004 sleeping at %d bytes for %d jiffies (writing)\n",
				b004_total_bytes_written, B004_TIME );
			b004_total_bytes_written=0;
#endif
			current->state = TASK_INTERRUPTIBLE;
			current->timeout = jiffies + B004_TIME;
			schedule();

			/* If nothing is getting to the C012
			   for a considerable length of time,
			   someone oughtta know.  */
			while ( !( inb(B004_OSR) & B004_WRITEBYTE ) ) {
				if ( (current->signal & ~current->blocked) && (count > 0) )
					return temp - buf;
				current->state = TASK_INTERRUPTIBLE;
				current->timeout = jiffies + B004_WRITE_TIMEOUT;
				schedule();
				if ( !( inb(B004_OSR) & B004_WRITEBYTE ) && (B004_F & B004_WRITE_ABORT) ) {
					printk("B004: timeout writing to link\n");
					return temp - buf ? temp - buf : -EFAULT;
				}
			}
		}
	}
#ifdef B004_DEBUG_MORE
	printk("B004 writing successful\n");
#endif
	return temp-buf;
}


static int b004_lseek(struct inode * inode, struct file * file,
		    off_t offset, int origin)
{
	return -ESPIPE;
}

static int b004_open(struct inode * inode, struct file * file)
{
	unsigned int minor = MINOR(inode->i_rdev);

	if (minor >= B004_NO)
#ifdef B004_DEBUG
	{
		printk("B004 not opened, minor device number != 0\n");
		return -ENODEV;
	}
#else
		return -ENODEV;
#endif
	if ((B004_F & B004_EXIST) == 0)
#ifdef B004_DEBUG
	{
		printk("B004 not opened, B004-board does not exist\n");
		return -ENODEV;
	}
#else
		return -ENODEV;
#endif
	if (B004_F & B004_BUSY)
#ifdef B004_DEBUG
	{
		printk("B004 not opened, B004-board busy\n");
		return -EBUSY;
	}
#else
		return -EBUSY;
#endif

	B004_F |= B004_BUSY;
#ifdef B004_DEBUG
	printk( "B004 opened\n" );
#endif
	return 0;
}


static void b004_release(struct inode * inode, struct file * file)
{
#ifdef B004_DEBUG
	printk( "B004 released\n" );
#endif
	B004_F &= ~B004_BUSY;
}


static int b004_ioctl(struct inode *inode, struct file *file,
		    unsigned int cmd, unsigned int arg)
{
	unsigned int minor = MINOR(inode->i_rdev);
	unsigned int temp;

#ifdef B004_DEBUG
	printk("B004 ioctl, cmd: 0x%x, arg: 0x%x\n", cmd, arg);
#endif
	if (minor >= B004_NO)
#ifdef B004_DEBUG
	{
		printk("B004 ioctl exit, minor >= B004_NO" );
#endif
		return -ENODEV;
#ifdef B004_DEBUG
	}
#endif
	if ((B004_F & B004_EXIST) == 0)
#ifdef B004_DEBUG
	{
		printk("B004 ioctl exit, (B004_F & B004_EXIST) == 0" );
#endif
		return -ENODEV;
#ifdef B004_DEBUG
	}
#endif
	switch ( cmd ) {
		case B004TIME:
			B004_TIME = arg;
			break;
		case B004RESET:		/* reset transputer */
			b004_reset();
			break;
		case B004WRITEABLE:	/* can we write a byte to C012 ? */
	 		arg = ( ( inb(B004_OSR) & B004_WRITEBYTE) != 0 ); 
			break;
		case B004READABLE:	/* can we read a byte from C012 ? */
	 		arg = ( ( inb(B004_ISR) & B004_READBYTE) != 0 ); 
			break;
		case B004ANALYSE:	/* switch transputer to analyse mode */
			b004_analyse();
			break;
		case B004ERROR:		/* test error-flag */
			arg = ( inb(B004_ERROR) & B004_TEST_ERROR) ? 0 : 1;
			break;
		case B004READTIMEOUT:
			temp = B004_READ_TIMEOUT;
			B004_READ_TIMEOUT = arg;
			arg = temp;
			break;
		case B004WRITETIMEOUT:
			temp = B004_WRITE_TIMEOUT;
			B004_WRITE_TIMEOUT = arg;
			arg = temp;
			break;
		case B004READABORT:
			if ( arg )
				B004_F |= B004_READ_ABORT;
			else
				B004_F &= ~B004_READ_ABORT;
			break;
		case B004WRITEABORT:
			if ( arg )
				B004_F |= B004_WRITE_ABORT;
			else
				B004_F &= ~B004_WRITE_ABORT;
			break;
		default: arg = -EINVAL;
	}
#ifdef B004_DEBUG
	printk("B004 ioctl done\n");
#endif
	return arg;
}


static struct file_operations b004_fops = {
	b004_lseek,
	b004_read,
	b004_write,
	NULL,		/* b004_readdir */
	NULL,		/* b004_select */
	b004_ioctl,
	NULL,		/* b004_mmap */
	b004_open,
	b004_release
};

long b004_init(long kmem_start)
{
	unsigned int testvalue, i;

	if ( register_chrdev( B004_DEVICE, B004_NAME, &b004_fops ) )
	{
		printk("b004_init: unable to get major %d for link interface",
			B004_DEVICE );
		return kmem_start;
	}

	/* After a reset it should be possible to write a byte to
	   the B004. So do a reset and then test the output status
	   register
	*/
	b004_reset();

	for (i = 0; i < B004_MAXTRY; i++) testvalue = inb(B004_OSR);

	if ( testvalue & B004_WRITEBYTE) {
		B004_F |= B004_EXIST;
		printk("b004_init: B004 driver installed\n" );
	} else
		printk("b004_init: no B004-Board found\n");

	return kmem_start;
}
