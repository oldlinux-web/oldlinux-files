#define DOS_DRIVES 5		/* Number of your DOS-Drives */

char DosMount[DOS_DRIVES][20] = {	"/user",	/* A: is mounted as */
					"/user",	/* B: */
					"/c",		/* C: */
					"/d",		/* D: */
					"/e",		/* C: */
				};
char RootPrefix[20] =	"/c";		/* inserted if filename starts with \ */

char Printer[20]	= "/dev/lp1";	/* used for file prn */
