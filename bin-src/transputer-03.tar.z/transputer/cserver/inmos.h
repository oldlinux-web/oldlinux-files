/*
--  -----------------------------------------------------------------
--
--     Object Name  :   inmos.h
--     Revision     :   1.0
--
--     Copyright (c) Inmos Ltd, 1987.
--     All Rights Reserved.
--
--     DESCRIPTION
--        This is the Inmos C predefine file.
--
--     NOTES
--
--     HISTORY
--        brb    23-oct-87   JG - Creation
--        brb    15-Dec-87   RJO Added typedefs to this file.
--   -----------------------------------------------------------------
*/

#define PUBLIC
#define PRIVATE static
#define EXTERN  extern

#define TRUE     1
#define FALSE    0
#define BAD     -1

/*
-- ---------------------------------------------------------------------------
-- Some useful typedefs.
-- ---------------------------------------------------------------------------
*/

typedef unsigned char BYTE;
typedef int BOOL;

/*
--
--     End of File.
--
*/
