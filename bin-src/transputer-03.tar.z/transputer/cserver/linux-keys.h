#define LINUX_KEYS 60

int keys[LINUX_KEYS][5] = {	
/*1*/			{ 0, 0, 0, 0, FT_REFRESH },		/* ESC */
			{ 91, 91, 65, 65, FT_HELP },		/* F1 */
			{ 91, 91, 66, 66, FT_FOLD_INFO },	/* F2 */
			{ 91, 91, 67, 67, FT_MOVE },		/* F3 */
			{ 91, 91, 68, 68, FT_COPY },		/* F4 */
			{ 91, 91, 69, 69, FT_GET_CODE },	/* F5 */
			{ 91, 49, 55, 126, FT_RUN },		/* F6 */
			{ 91, 49, 56, 126, FT_SOL }, 		/* F7 */
			{ 91, 49, 57, 126, FT_EOL }, 		/* F8 */
/*10*/			{ 91, 50, 48, 126, FT_LINE_UP }, 	/* F9 */
			{ 91, 50, 49, 126, FT_LINE_DOWN },	/* F10 */
			{ 91, 50, 51, 126, FT_BAD },		/* Sh-F1 */
			{ 91, 50, 52, 126, FT_FILE_FOLD },	/* Sh-F2 */
			{ 91, 50, 53, 126, FT_PUT },		/* Sh-F3 */
			{ 91, 50, 54, 126, FT_COPY_PICK },	/* Sh-F4 */
			{ 91, 50, 56, 126, FT_AUTOLOAD }, 	/* Sh-F5 */
			{ 91, 50, 57, 126, FT_CLEAR_ALL },	/* Sh-F6 */
			{ 91, 51, 49, 126, FT_WORD_LEFT },	/* Sh-F7 */
			{ 91, 51, 50, 126, FT_WORD_RIGHT }, 	/* Sh-F8 */
/*20*/			{ 91, 51, 51, 126, FT_TOP_OF_FOLD }, 	/* Sh-F9 */
			{ 91, 51, 52, 126, FT_BOTTOM_OF_FOLD },	/* Sh-F10 */
			{ 91, 65, 65, 65, FT_UP },		/* Cur Up */
			{ 91, 66, 66, 66, FT_DOWN },		/* Cur Down */
			{ 91, 67, 67, 67, FT_RIGHT },		/* Cur Right */
			{ 91, 68, 68, 68, FT_LEFT },		/* Cur Left */
			{ 91, 49, 126, 126, FT_ENTER_FOLD },	/* Home */
			{ 91, 53, 126, 126, FT_EXIT_FOLD },	/* Pg Up */
			{ 91, 54, 126, 126, FT_OPEN_FOLD },	/* Pg Down */
			{ 91, 52, 126, 126, FT_CLOSE_FOLD },	/* End */
/*30*/			{ 91, 50, 126, 126, FT_CREATE_FOLD }, 	/* Ins */
			{ 91, 51, 126, 126, FT_DEL_CHR }, 	/* Del */
			{ 48, 48, 48, 48, FT_TOOL0 },		/* Alt-0 */
			{ 49, 49, 49, 49, FT_TOOL1 },		/* Alt-1 */
			{ 50, 50, 50, 50, FT_TOOL2 },		/* Alt-2 */
			{ 51, 51, 51, 51, FT_TOOL3 },		/* Alt-3 */
			{ 52, 52, 52, 52, FT_TOOL4 },		/* Alt-4 */
			{ 53, 53, 53, 53, FT_TOOL5 },		/* Alt-5 */
			{ 54, 54, 54, 54, FT_TOOL6 },		/* Alt-6 */
/*40*/			{ 55, 55, 55, 55, FT_TOOL7 },		/* Alt-7 */
			{ 56, 56, 56, 56, FT_TOOL8 },		/* Alt-8 */
			{ 57, 57, 57, 57, FT_TOOL9 },		/* Alt-9 */
			{ 120, 120, 120, 120, FT_FINISH },	/* Alt-x */
			{ 115, 115, 115, 115, FT_SUSPEND_TDS },	/* Alt-s */
			{ 108, 108, 108, 108, FT_WORD_LEFT },	/* Alt-l */
			{ 114, 114, 114, 114, FT_WORD_RIGHT },	/* Alt-r */
			{ 117, 117, 117, 117, FT_PAGE_UP },	/* Alt-u 	was Alt-F9 */
			{ 100, 100, 100, 100, FT_PAGE_DOWN }, 	/* Alt-d 	was Alt-F10 */
			{ 110, 110, 110, 110, FT_NEXT_UTIL },	/* Alt-n 	was Alt-F5 */
/*50*/			{ 121, 121, 121, 121, FT_UNDEL_LINE }, 	/* Alt-y 	was Alt-F8 */
			{ 105, 105, 105, 105, FT_CODE_INFO }, 	/* Alt-i	was Alt-F2 */
			{ 101, 101, 101, 101, FT_EDIT_PARAMS },	/* Alt-e	was Alt-F1 */
			{ 102, 102, 102, 102, FT_REMOVE_FOLD }, /* Alt-f	was Crtl-PgUp */
			{ 112, 112, 112, 112, FT_PICK },	/* Alt-p	was Alt-F3 */
			{ 116, 116, 116, 116, FT_NEXT_EXE },	/* Alt-t	was Alt-F6 */
			{ 113, 113, 113, 113, FT_DEL_LINE },	/* Alt-q	was Alt-F7 */
			{ 109, 109, 109, 109, FT_DEFINE_MACRO },/* Alt-m	was Ctrl-F9 */
			{ 119, 119, 119, 119, FT_CALL_MACRO },	/* Alt-w	was Ctrl-F10*/
			{  99,  99,  99,  99, FT_CLEAR_UTIL },	/* Alt-c 	was Ctrl-F5 */
/*60*/			{  98,  98,  98,  98, FT_CLEAR_EXE },	/* Alt-b 	was Ctrl-F6 */

		};

