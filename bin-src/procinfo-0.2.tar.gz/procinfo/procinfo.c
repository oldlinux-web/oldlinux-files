/*
   proc.c

   Displays general info from /proc.

   copyright (c) 1994 svm@kozmix.hacktic.nl

   This software is released under the GNU Public Licence. See the
   file `COPYING' for details. Since you're probably running Linux I'm
   sure your hard disk is already infested with copies of this file,
   but if not, mail me and I'll send you one.

   $Id: procinfo.c,v 1.7 1994/03/30 15:03:35 svm Exp svm $
 */

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <termcap.h>
#include <signal.h>
#include <getopt.h>
#include <unistd.h>

#define VERSION		"0.2 (1994-03-30)"
#define ISSTR(s)	(!strcmp(s, type))
#define VAL		(atol(strtok(NULL, " ")))

typedef unsigned long ul;

void init_terminal_data (void);
char *my_tgets (char *te);

char *cd;			/* clear to eos */
char *ce;			/* clear to eol */
char *cl;			/* clear screen */
char *cm;			/* move cursor */
char *ho;			/* home */
char *se;			/* standout off */
char *so;			/* standout on */
char *ve;			/* cursor on */
char *vi;			/* cursor off */
int co;				/* columns */
int li;				/* lines */

FILE *
myfopen (char *name)
{
    FILE *fp;

    if ((fp = fopen (name, "r")) == NULL)
    {
	fprintf (stdout, "can't open file %s: %s\n", name, strerror (errno));
	exit (1);
    }
    return fp;
}

char *
hms (long t)
{
    int h, m, s;
    static char buf[16];

    h = (int) (t / 3600);
    t = t - (long) (h * 3600);
    m = (int) (t / 60);
    t = t - (long) (m * 60);
    s = (int) t;
    sprintf (buf, "%3d:%02d:%02d", h, m, s);
    return buf;
}

void
bye (int i)
{
    printf ("%s%s%s", ve, se, tgoto (cm, 0, li + 1));
    exit (0);
}

void
tstp (int i)
{
   /* Restore cursor & attributes, then do the actual suspend. Would be fun
      to try this unaltered on BSD-based systems. :-) */
    printf ("%s%s%s", ve, se, tgoto (cm, 0, li - 1));
    fflush (stdout);
    raise (SIGTSTP);
}

void
cont (int i)
{
    signal (SIGTSTP, tstp);
    signal (SIGCONT, cont);
    printf ("%s%s", cl, vi);
    fflush (stdout);
}

int
main (int ac, char **av)
{
    FILE *loadavgfp, *meminfofp, *modulesfp, *statfp, *uptimefp, *versionfp;
    char line[1024];
    char version[1024];
    int fs = 0;
    int sl = 5;
    int getoptopt;

    while ((getoptopt = getopt (ac, av, "fn:hv")) != EOF)
    {
	switch (getoptopt)
	{
	case 'n':
	    sl = atoi (optarg);
	   /* PLUMMET */
	case 'f':
	    fs = 1;
	    break;
	case 'v':
	    printf ("procinfo version %s\n", VERSION);
	    exit (0);
	case 'h':
	default:
	    printf ("procinfo version %s\n"
		    "usage: %s [-f] [-nN] [-v] [-h]\n"
		    "\t-f\trun full screen\n"
		    "\t-nN\tpause N second between updates (implies -f)\n"
		    "\t-v\tprint version info\n"
		    "\t-h\tprint this help\n",
		    VERSION, av[0]);
	    exit (1);
	}
    }

    if (sl == 0)
	nice (-20);

    if (fs)
    {
	init_terminal_data ();
	if ((co = tgetnum ("co")) == -1)
	    co = 80;
	if ((li = tgetnum ("li")) == -1)
	    li = 24;
	li -= 2;
	cd = my_tgets ("cd");
	ce = my_tgets ("ce");
	cl = my_tgets ("cl");
	cm = my_tgets ("cm");
	ho = my_tgets ("ho");
	se = my_tgets ("se");
	so = my_tgets ("so");
	ve = my_tgets ("ve");
	vi = my_tgets ("vi");

	signal (SIGHUP, bye);
	signal (SIGINT, bye);
	signal (SIGQUIT, bye);
	signal (SIGTERM, bye);
	signal (SIGTSTP, tstp);
	signal (SIGCONT, cont);
    }

    versionfp = myfopen ("/proc/version");
    fgets (version, sizeof (version), versionfp);
    version[strlen (version) - 1] = '\0';
    fclose (versionfp);

    uptimefp = myfopen ("/proc/uptime");
    loadavgfp = myfopen ("/proc/loadavg");
    meminfofp = myfopen ("/proc/meminfo");
    modulesfp = myfopen ("/proc/modules");
    statfp = myfopen ("/proc/stat");

    if (fs)
	printf ("%s%s", cl, vi);

    while (42)
    {
	ul  to, us, fr, sh, bu;
	char loadavg[32];
	ul  uptime = 0, cpu_user = 0, cpu_nice = 0, cpu_sys = 0, cpu_idle = 0;
	ul  disk[4] = {0, 0, 0, 0};
	ul  pgin = 0, pgout = 0, swin = 0, swout = 0;
#ifndef NO_IRQ_ARRAY
	int i;
	ul  intr[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#else
	ul  intr = 0;
#endif
	ul ctxt = 0;
	char booted[40] = "";
	time_t btime;

	if (fs)
	    printf ("%s%s%*s%s\n\n", ho, so, -(co - 1), version, se);
	else
	    printf ("%s\n\n", version);

	fseek (uptimefp, 0L, SEEK_SET);
	fgets (line, sizeof (line), uptimefp);
	uptime = atol (strtok (line, " "));

	fseek (loadavgfp, 0L, SEEK_SET);
	fgets (line, sizeof (line), loadavgfp);
	strcpy (loadavg, line);
	loadavg[strlen (loadavg) - 1] = '\0';

	fseek (meminfofp, 0L, SEEK_SET);
	printf ("Memory: %12s%12s%12s%12s%12s\n",
		"Total", "Used", "Free", "Shared", "Buffers");
	fgets (line, sizeof (line), meminfofp);
	fgets (line, sizeof (line), meminfofp);
	strtok (line, " ");
	to = atol (strtok (NULL, " ")) / 1024;
	us = atol (strtok (NULL, " ")) / 1024;
	fr = atol (strtok (NULL, " ")) / 1024;
	sh = atol (strtok (NULL, " ")) / 1024;
	bu = atol (strtok (NULL, " ")) / 1024;
	printf ("Mem:    %12lu%12lu%12lu%12lu%12lu\n", to, us, fr, sh, bu);
	fgets (line, sizeof (line), meminfofp);
	strtok (line, " ");
	to = atol (strtok (NULL, " ")) / 1024;
	us = atol (strtok (NULL, " ")) / 1024;
	fr = atol (strtok (NULL, " ")) / 1024;
	printf ("Swap:   %12lu%12lu%12lu\n\n", to, us, fr);

	fseek (statfp, 0L, SEEK_SET);
	while (fgets (line, sizeof (line), statfp))
	{
	    char *type = strtok (line, " ");

	    if (ISSTR ("cpu"))
	    {
		cpu_user = VAL / 100;
		cpu_nice = VAL / 100;
		cpu_sys = VAL / 100;
		cpu_idle = VAL / 100;
	    }
	    else if (ISSTR ("disk"))
	    {
		disk[0] = VAL;
		disk[1] = VAL;
		disk[2] = VAL;
		disk[3] = VAL;
	    }
	    else if (ISSTR ("page"))
	    {
		pgin = VAL;
		pgout = VAL;
	    }
	    else if (ISSTR ("swap"))
	    {
		swin = VAL;
		swout = VAL;
	    }
	    else if (ISSTR ("intr"))
#ifndef NO_IRQ_ARRAY
	    {
		VAL;		/* First value is total of all interrupts,
				   for compatibility with rpc.rstatd. We
				   ignore it. */
		for (i = 0; i < 16; i++)
		    intr[i] = VAL;
	    }
#else
		intr = VAL;
#endif
	    else if (ISSTR ("ctxt"))
		ctxt = VAL;
	    else if (ISSTR ("btime"))
		btime = (time_t) VAL;
	}

	if (!booted[0])
	    strftime (booted, sizeof (booted), "%c", localtime (&btime));
	printf ("Bootup: %s\tLoad average: %s\n\n", booted, loadavg);

	printf ("user  : %s\t", hms (cpu_user));
	printf ("page in : %8lu\t", pgin);
	if (disk[0])
	    printf ("disk 1: %8lu\n", disk[0]);
	else
	    putchar ('\n');
	printf ("nice  : %s\t", hms (cpu_nice));
	printf ("page out: %8lu\t", pgout);
	if (disk[1])
	    printf ("disk 2: %8lu\n", disk[1]);
	else
	    putchar ('\n');
	printf ("system: %s\t", hms (cpu_sys));
	printf ("swap in : %8lu\t", swin);
	if (disk[2])
	    printf ("disk 3: %8lu\n", disk[2]);
	else
	    putchar ('\n');
	printf ("idle  : %s\t", hms (cpu_idle));
	printf ("swap out: %8lu\t", swout);
	if (disk[3])
	    printf ("disk 4: %8lu\n", disk[3]);
	else
	    putchar ('\n');
	printf ("uptime: %s\tcontext : %8lu", hms (uptime), ctxt);

#ifndef NO_IRQ_ARRAY
	fputs ("\n\nInterrupts:\n0-7 : ", stdout);
	for (i = 0; i < 8; i++)
	    printf ("%9lu", intr[i]);
	printf ("\n8-15: ");
	for (i = 8; i < 16; i++)
	    printf ("%9lu", intr[i]);
	fputs ("\n\n", stdout);
#else
	printf ("\tinterrupts: %8lu\n\n", intr);
#endif

	fseek (modulesfp, 0L, SEEK_SET);
	printf ("Modules:    size\n");
	while (fgets (line, sizeof (line), modulesfp))
	{
	    char *mod;
	    long pg;

	    mod = strtok (line, " ");
	    pg = atol (strtok (NULL, "")) * 4;
	    printf ("%-12s%4lu    ", mod, pg);
	}

	if (fs)
	{
	    fputs (cd, stdout);
	    fflush (stdout);
	    if (sl)
		sleep (sl);
	}
	else
	{
	    putchar ('\n');
	    exit (0);
	}
    }
}
