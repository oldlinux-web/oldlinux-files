char version[] = "Linux bootutils, version 0.99.14";
