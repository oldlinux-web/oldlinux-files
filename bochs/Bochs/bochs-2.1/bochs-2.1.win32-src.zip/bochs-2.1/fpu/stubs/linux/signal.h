#ifndef _ASMi386_SIGNAL_H
#define _ASMi386_SIGNAL_H

#define SIGILL           4
#define SIGFPE           8
#define SIGSEGV         11

#endif
