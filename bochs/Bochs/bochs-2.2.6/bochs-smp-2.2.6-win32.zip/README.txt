Bochs x86 Emulator (SMP package for Windows)
Version: 2.2.6

This package contains a Bochs executable compiled with SMP support enabled.
An existing Bochs installation of the same version is required. By default it
starts with one CPU and you can use the new "cpu: count=N" option to enable
more processors. Bochs currently supports up to 8 CPUs.
NOTE: The SMP feature in Bochs is still incomplete. Some of the SMP-aware
operating systems will work, other may still fail.

See the home page of the Bochs project at http://bochs.sourceforge.net
