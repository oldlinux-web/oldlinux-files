/*
 * $Id: hello.cc,v 1.2 2001/10/03 13:10:38 bdenney Exp $
 */

#include <stdio.h>

  int
main()
{
  printf("hello world.\n");
  return(0);
}
