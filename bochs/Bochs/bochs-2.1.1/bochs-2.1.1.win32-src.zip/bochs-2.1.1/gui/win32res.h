#define ICON_BOCHS  1000

#define ASK_DLG     2000
#define IDASKTX1    2010
#define IDASKDEV    2020
#define IDASKTX2    2030
#define IDASKMSG    2040
#define IDASKLIST   2050
#define STRING_DLG  2100
#define IDSTRING    2110
#define FLOPPY_DLG  2200
#define IDDEVTX     2205
#define IDDEVTYPE   2210
#define IDPATHTX    2215
#define IDPATH      2220
#define IDBROWSE    2230
#define IDSTATUS    2240
#define IDCREATE    2250
