/* pasfront */
typedef struct { FILE *PointingTo; 
                 unsigned 
                 int eoln:1,eof:1,out:1,init:1,:12;
                 char CASE;
                 } text; 
text Xstdin = stdin;
text Xstdout = stdout;
#define file_handling_w(x,f) fwrite((char *)&x,sizeof(x),1,f)
#define stream_p(f) file_handling_w((f).CASE, (f).PointingTo)
#define stream_x(f) (f).eoln = ((f).CASE == '\n'), \
(void)fputc((f).CASE,(f).PointingTo)
#define stream_c(c,f) (f).CASE = (c), stream_x(f)
#define stream_l(f,v) (f).eoln = v
typedef char boolean;
#define false (boolean)0
#define true (boolean)1
extern char *Bools[];
typedef int integer; 
typedef double real;
#ifndef start_structure
#define start_structure(p,m) (((long)(&(p)->m))-((long)(p)))
#endif
#define NIL 0
#define specified_sets() (void)actual_sets(0, (setptr)0)
#define create_set() actual_sets(1, (setptr)0)
#define sure_set(s) actual_sets(2, s)
#define setbits 15
typedef unsigned short replace_pointer;
typedef replace_pointer * setptr;
boolean _partof_(register unsigned int, register setptr);
boolean _FORTRAN_SMALL(register setptr, register setptr);
boolean _FORTRAN_GREAT(register setptr, register setptr);
boolean _FORTRAN_EQUAL(register setptr,register setptr);
boolean _FORTRAN_NOT_EQ(register setptr, register setptr);
setptr connect(register setptr,register setptr);
setptr minus_result(register setptr,register setptr);
setptr workin_memory(register unsigned int, register setptr);
setptr needed_string(void);
setptr actual_sets(int, setptr); 
setptr integrated(register setptr, register setptr);
static setptr local_set;
setptr array_by_word[];
void insert_set(register setptr, register setptr,
                register unsigned int);
static FILE *Tmpfil;
static long static_tmp;
static double long_static_tmp;
#define file_handling_r(x,f) fread((char *)&x, sizeof(x),1,f)
#define file_handling_g(f) file_handling_r((f).CASE, (f).PointingTo)
#define file_check_l(f) ((f).eoln ? true : false)
#define file_handling_x(f) (f).init = 1, \
(f).eoln = (((f).CASE = fgetc((f).PointingTo)) == '\n') ? \
(((f).CASE = ' '), 1):0
#define file_handling_c(f) (f).CASE, file_handling_x(f)
#define file_handling_s(f) \
(f).init ? ungetc((f).CASE, (f).PointingTo) : 0, Tmpfil = (f).PointingTo
#define inout_handling_s(p,a) intreading_I(fscanf(Tmpfil,p,a))
#define file_check_l(f) ((f).eoln ? true : false)
#define file_check_f(f) ((((f).init == 0) ? \
(file_handling_g(f)) : 0, ((f).eof ? 1 : feof((f).PointingTo))) ? true : false) 
#define closeall_file(f) ((f).out && !(f).eoln) ? (stream_c('\n',f), 0) : \
rewind((f).PointingTo), 0
#ifdef READONLY
static char allowed_to_read[] = "r";
#else
static char allowed_to_read[] = "r+";
#endif
#define make_clear(f,n) (f).init = (f).init ? rewind((f).PointingTo) : \
(((f).PointingTo = file_handling_o(n, allowed_to_read)), 1), \
(f).eof = (f).out = 0, Get(f)
#define initialize_file(f,n) (f).init = (f).init ? \
(closeall_file(f)) : \
(((f).PointingTo = file_handling_o(n, allowed_to_read)), 1), \
(f).eof = (f).out = 0, file_handling_x(f) 
#ifdef WRITEONLY
static char allowed_to_write[] = "w";
#else
static char allowed_to_write[] = "w+";
#endif
#define write_back(f,n) (f).init = (f).init ? rewind((f).PointingTo), 0 : \
(((f).PointingTo = file_handling_o(n, allowed_to_write)), 1), \
(f).out = (f).eof = 1
#define \
write_all_back(f,n)\
(f).init = (f).init?\
(closeall_file(f)):\
(((f).PointingTo=file_handling_o(n,allowed_to_write)),1), \
(f).out=(f).eof=(f).eoln=1
FILE *file_handling_o(); 
#define differences(x,y) strncmp((x),(y), sizeof(x))
extern part_of_counter(float);
extern cut_counter(float);
extern void switch_fault(int);
extern int highest_bound(int,int);
extern void file_handling_l(text *);
setptr working_memory(register unsigned int, register setptr);
setptr actual_sets(int,setptr);
#define distribute fprintf
#define Line __LINE__
/* end pasfront */
