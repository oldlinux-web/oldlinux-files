/* _JBLEN should be 3 for IBM PC, 13 for ATARI. */

#define _JBLEN 3
typedef int jmp_buf[_JBLEN];
