struct timeb {
	long	time;
	unsigned short millitm;
	short	timezone;
	short	dstflag;
};
