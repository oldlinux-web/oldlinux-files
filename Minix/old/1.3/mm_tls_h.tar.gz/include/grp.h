struct	group { 
	char	*gr_name;
	char	*gr_passwd;
	int	gr_gid;
};
