echo x - READ_ME
sed '/^X/s///' > READ_ME << '/'
XSome enties have not been checked yet.  Grep for #### to find them.
X
/
echo x - animals
sed '/^X/s///' > animals << '/'
X.CD "animals \(en twenty-questions type guessing game about animals"
X.SX "animals\fR [\fIdatabase\fR]"
X.FL "\fR(none)"
X.EY "animals" "Start the game"
X.PP
X\fIAnimals\fR is a guessing game.  The user picks an animal and the 
Xcomputer tries to guess it by posing questions that should be answered by 
Xtyping \*(OQy\*(CQ for yes and \*(OQn\*(CQ for no.  
XWhenever the computer loses, it asks 
Xsome questions that allow it to improve its database, so as time goes on, it 
Xlearns.  The default database should be in \fI/usr/lib/animals\fR.
X
X
X
X.SP 0.3
/
echo x - anm
sed '/^X/s///' > anm << '/'
X.CD "anm \(en print name list [68000]"
X.SX "anm \fR[\fB\(engnoprus\fR] \fIfile\fR ..."
X.FL "\(eng" "Global symbols only"
X.FL "\(enn" "Sort numerically"
X.FL "\(eno" "Prepend the filename to each line"
X.FL "\(enp" "No sorting\(emuse symbol table order"
X.FL "\(enr" "Sort in reverse order"
X.FL "\(enu" "List undefined symbols only"
X.FL "\(ens" "Sort in section order"
X.EY "anm  \(engn  test.o" "Print global symbols in numerical order"
X.PP
X.I Anm
Xprints the name list (symbol table) of each ACK format object
X.I file
Xin the argument list.
XIf no file name is given, \fIa.out\fR is used.
XEach symbol name is preceded by its value, a section indicator
Xand a type indicator.
XThe section indicators are:
X.SP 0.7
X.HS
X.ta 0.25i 0.50i
X.nf
X	\fBU\fR	Undefined symbol
X	\fBA\fR	Absolute symbol
X	\fB\(en\fR	Other symbol
X.sp
XThe type indicators are:
X.HS
X	\fBF\fR	Filename
X	\fBM\fR	Module name
X	\fBS\fR	Section name
X	\fBE\fR	External (global) symbol
X	\fB\(en\fR	Local symbol
X.fi
X.PP
XThe output is sorted alphabetically, unless otherwise specified.
XNotice that \fIanm\fR can only be used on ACK format object files 
X(that is: \fI.o\fR and \fI.out\fR files). 
XIf you want to get the name list of an executable program use 
X.I nm
Xinstead.
X
X
X
/
echo x - aoutdump
sed '/^X/s///' > aoutdump << '/'
X.CD "aoutdump \(en display the contents of an object file [68000]"
X.SX "aoutdump \fR[\fIfile\fR [\fIabcdef\fR] ]"
X.FL "\fR(none)"
X.EY "aoutdump test.o 000010" "dump the symbol table records of \fItest.o\fR"
X.PP
X.I Aoutdump
Xgives a complete dump of each ACK formatted object
X.I file
Xin the argument list.
XIf no
X.I file
Xis given, \fIa.out\fR is displayed.
XThe parameter following the file name is a bit map that
Xcan be used to specify a partial dump.
XEach bit must be 0 or 1.
XThe 6 bits in the map have the following meanings:
X.HS
X.ta 0.25i 0.50i
X.nf
X	\fIa\fR	Display the header record
X	\fIb\fR	Display the section records
X	\fIc\fR	Display the code bytes
X	\fId\fR	Display the relocation records
X	\fIe\fR	Display the symbol table records
X	\fIf\fR	Display the string area
X.fi
X
X
X
X.SP 1.5
/
echo x - ar
sed '/^X/s///' > ar << '/'
X.CD "ar \(en archiver"
X.SX "ar\fR [\fBdmpqrtx\fR][\fBabciluv\fR]\fR [\fIposname\fR] \fIarchive \fIfile ..."
X.FL "\fR(none)"
X.EX "ar r libc.a sort.s" "Replace \fIsort\fR.s in \fIlibc.a\fR"
X.EX "ar rb a.s libc.a b.s" "Insert \fIb.s\fR before \fIa.s\fR in \fIlibc.a\fR"
X.PP
X\fIAr\fR allows groups of files to be put together into a single archive.
XIt is normally used for libraries of compiled procedures.  The following keys
Xare allowed:
X.HS
X.ta 0.25i 0.50i
X.nf
X	\fBd\fR:	Delete. \fIAr\fR will delete the named members.
X	\fBm\fR:	Move named files. \fIAr\fR expects \fIa\fR, \fIb\fR, or \fIi\fR to be specified.
X	\fBp\fR:	Print the named files (list them on \fIstdout\fR)
X	\fBq\fR:	Quickly append to the end of the archive file.
X	\fBr\fR:	Replace (append when not in archive).
X	\fBt\fR:	Print the archive's table of contents.
X	\fBx\fR:	Extract
X.fi
X.HS
X\fBThe keys may optionally concatencated with one or more of the following\fR:
X.nf
X.HS
X	\fBa\fR:	After \fIposname\fR
X	\fBb\fR:	Before \fIposname\fR
X	\fBc\fR:	Create  (suppresses creation message)
X	\fBi\fR:	Before \fIposname\fR
X	\fBl\fR:	Local temporary file for work instead of \fI/tmp/ar.$$$$$\fR
X	\fBu\fR:	Replace only if dated later than member in archive
X	\fBv\fR:	Verbose
X.HS
X.fi
X
X
X
/
echo x - as
sed '/^X/s///' > as << '/'
X.CD "as \(en MC68000 assembler [68000]"
X.SX "as [\(ens][\(enu][\(enT\fIdir\fP][\(eno \fIname\fR] \fIfile\fR ..."
X.FL "\(ens" "Strip symbol table"
X.FL "\(enu" "Accept undefined symbols as external references"
X.FL "\(enT" "Make temporary files in \fIdir\fP"
X.FL "\(eno" "Put output on file named by next arg"
X.EY "as \(enu \(eno file.o file.s" "assemble file.s into file.o"
X.PP
X.I As
Xaccepts MC68000 instruction in a format like:
X.I "move.l 4(a0),\(en(sp)" .
XSee some of the source files, like
X.I kernel/stmpx.s
Xand
X.I lib/sthead.s
Xto get a feel for the syntax. The assembler supports a variable
Xnumber of sections, but the combination with the code generator
Xand linker assume that you start each assembly file by introducing the
Xfollowing sections:
X.ta 0.25i 1i
X.HS
X	.sect	.text
X.br
X	.sect	.rom
X.br
X	.sect	.data
X.br
X	.sect	.bss
X.HS
XTo get a large sample of code, compile some C programs and inspect the
Xresulting assembly code.
XThis will give an idea of what the assembly language looks like.
X
X
X
/
echo x - ascii
sed '/^X/s///' > ascii << '/'
X.CD "ascii \(en strip all the pure ASCII lines from a file"
X.SX "ascii\fR [\fB\(enn\fR]\fR [\fIfile\fR]"
X.FL "\(enn" "Extract the lines containing nonASCII characters"
X.EX "ascii file >outf" "Write all the ASCII lines on \fIoutf\fR"
X.EX "ascii \(enn <file >outf" "Write all the nonASCII lines on \fIoutf\fR"
X.PP
XSometimes a file contains some nonASCII characters that are in the way.
XThis program allows the lines containing only ASCII characters to be 
X\fIgrepped\fR from the file.  
XWith the \fB\(enn\fR flag, the nonASCII lines are 
X\fIgrepped\fR.  
XNo matter whether the flag is used or not, the program returns an exit status 
Xof true if the file is pure ASCII, and false otherwise.
X
X
X
/
echo x - asize
sed '/^X/s///' > asize << '/'
X.CD "asize \(en report the size of an object file [68000]"
X.SX "asize \fIfile\fR ..."
X.FL "\fR(none)"
X.EY "asize test.o" "Give the size of \fItest.o\fR"
X.PP
X.I Asize
Xprints for each argument
Xthe (decimal) number of bytes used by the different sections,
Xas well as their sum in decimal and hexadecimal.
XIf no
X.I file
Xis given \fIa.out\fR is used.
X.I Asize
Xcan only be used to obtain the size of a \(M2 \fI.o\fR or \fI.out\fR file. 
XTo obtain the size of an executable, use
X.I size
Xinstead.
X
X
X
/
echo x - asld
sed '/^X/s///' > asld << '/'
X.CD "asld \(en assembler-loader [IBM]"
X.SX "asld\fR [\fB\(enLis\fR]\fR [\fB\(enT \fIdir\fR] [\fB\(eno \fIname\fR] \fIfile\fR ..."
X.FL "\(enL" "A listing is produced on \fIstdout\fR"
X.FL "\(enT" "Used to specify a directory for the temporary file"
X.FL "\(eni" "Use separate I & D space (64K + 64K)"
X.FL "\(eno" "Output goes to file named by next argument"
X.FL "\(ens" "A symbol table is produced on \fIstdout\fR"
X.EX "asld \(ens file.s" "Assemble \fIfile.s and \fP list symbols"
X.EX "asld \(eno output file.s" "Assemble \fIfile.s\fP, put binary on \fIoutput\fP"
X.EX "asld \(enT. file1.s file2.s" "Use current directory for temporary file"
X.PP
X.I Asld
Xis the
X.MX
Xassembler and loader combined.
XIt accepts a language similar to that accepted by the \s-2PC-IX\s+2
Xassembler (see Chap. 9).
XSymbols are made up of letters, digits and underscores.
XThe machine instructions and addressing modes are the same as those
Xused by
X\s-2PC-IX\s+2, except that modes using multiple registers are written
Xlike this example: 
X.I "mov ax,(bx_si)."
XConstant operands are denoted by a sharp sign.
XLocal labels are permitted in the usual 
X.UX
Xstyle: the instruction 
X.I "jmp 1f"
Xjumps forward to the closest label 
X.I 1:
X.PP
XThe pseudoinstructions accepted by the assembler are listed below:
X.HS
X.ta 0.25i 1.25i
X.nf
X	\fB.align\fR n	\fRAlign to a multiple of \fIn\fP bytes
X	\fB.ascii\fP str	\fRAssemble a string
X	\fB.asciz\fP str	\fRAssemble a zero-terminated string
X	\fB.bss\fP	\fRWhat follows goes in the bss segment
X	\fB.byte\fP n	\fRAssemble one or more bytes
X	\fB.data\fP	\fRWhat follows goes in the data segment
X	\fB.define\fP sym	\fRExport \fIsym\fR from the file
X	\fB.errnz\fP n	\fRForce error if \fIn\fP is nonzero
X	\fB.even\fP	\fRAlign to an even address
X	\fB.extern\fP sym	\fRDeclare \fIsym\fR external
X	\fB.globl\fP sym	\fRSame as \fBextern
X	\fB.long\fR n	\fRAssemble \fIn\fR as a long
X	\fB.org\fP adr	\fRSet address within current segment
X	\fB.short\fP n	\fRAssemble \fIn\fR as a short
X	\fB.space\fP n	\fRSkip \fIn\fR bytes
X	\fB.text\fP	\fRWhat follows goes in the text segment
X	\fB.word\fP n	\fRAssemble \fIn\fR as a word
X	\fB.zerow\fP n	\fRAssemble \fIn\fP words of zeros
X.fi
X.HS
XIn the above pseudoinstructions,
X.I adr
Xis an expression yielding a machine address,
X.I n
Xis a numeric expression,
X.I str
Xis a quoted string, and
X.I sym
Xis a symbol.
XThe library
X.DI /usr/lib/libc.a
Xis a packed archive of assembly code.
XTo see some examples of it, extract some files from the archive with
X.I ar
Xand then use the filter 
X.I libupack
Xto convert them to readable ASCII.
X.PP
XIBM PC
X.MX
Xdoes not use
X.I \&.o
Xfiles.
XCompiler output is packed assembly language, as are the modules in an archive.
XThis scheme requires reassembling archive modules all the time, but it saves
Xspace.
XThe 68000 versions use \fI.o\fR files.
XSee also Chap. 9.
X
X
X
/
echo x - ast
sed '/^X/s///' > ast << '/'
X.CD "ast \(en add symbol table to executable file [IBM]"
X.SX "ast\fR [\fB\(enXx\fR]\fR [\fIfile\fR] [\fIsymbol_file\fR]"
X.FL "\(enX" "Preserve local symbols (except compiler generated ones)"
X.FL "\(enx" "Do not preserve local symbols"
X.EY "ast \(enX a.out" "Add symbols from \fIsymbol.out\fR to \fIa.out\fR"
X.PP
X\fIAst\fR adds the symbol table produced by the \fB\(ens\fR 
Xoption of asld to the executable file.  
XIf no symbol table file is listed, the default
Xname \fIsymbol.out\fR is used.  
XThe symbol table can also be directly added to an executed file by the
Xcommands \fIcc \(ens prog.c\fR.
X
X
X.SP -0.2
/
echo x - astrip
sed '/^X/s///' > astrip << '/'
X.CD "astrip \(en remove symbols [68000]"
X.SX "astrip \fIfile\fR ..."
X.FL "\fR(none)"
X.EY "astrip kernel.out" "Removes the symbol table from \fIkernel.out\fR"
X.PP
X.I Astrip
Xremoves the symbol table ordinarily attached to
XACK format object files.
X.I Astrip
Xcan only be used to remove the symbol table from a 
X.MX
X\fI.out\fR file. 
XIt cannot be used to remove symbol tables from executables.
XTo do that use
X.I strip
Xinstead.
X
X
X
/
echo x - at
sed '/^X/s///' > at << '/'
X.CD "at \(en execute commands at a later time"
X.SX "at \fItime\fR [\fImonth day\fR] [\fIfile\fR]"
X.FL "\fR(none)"
X.EX "at 2315 Jan 31 myfile" "Myfile executed Jan 31 at 11:15 pm"
X.EX "at 0900" "Job input read from \fIstdin\fR"
X.EX "at 0711 4 29 " "Read from \fIstdin\fR, exec on April 29"
X.PP
X\fIAt\fR prepares a file to be executed later at the specified time by 
Xcreating a special entry in \fI/usr/spool/at\fR.  
XThe program \fIatrun\fR should be started 
Xperiodically, for example, every minute by \fIcron\fR.  \fIAtrun\fR 
Xchecks to see if any
Xfiles in \fI/usr/spool/at\fR should now be run, and if so, it runs them 
Xand then puts them in \fI/usr/spool/at/past\fR.
XThe name of the file created in \fI/usr/spool/at\fR by 
X\fIat\fR is YY.DDD.HHMM.UU (where YY, DDD, HH, and MM give the time to execute and 
XUU is a unique number).  Note that when the command runs, it will not be able 
Xto use \fIstdin\fR or \fIstdout\fR unless specifically redirected.  In 
Xthe first example above, it might be necessary to put \fI>/dev/tty0\fR
Xon some lines in the shell script \fImyfile\fR.  
XThe same holds for the commands typed directly to \fIat\fR.
X
X
X
/
echo x - backup
sed '/^X/s///' > backup << '/'
X.CD "backup \(en backup files"
X.SX "backup\fR [\fB\(endjmnorstvz\fR] \fIdir1 dir2"
X.FL "\(end" "At top level, only directories are backed up"
X.FL "\(enj" "Do not copy junk: \fI *.Z, *.bak, a.out, core\fR, etc"
X.FL "\(enm" "If device full, prompt for new diskette"
X.FL "\(enn" "Do not backup top-level directories"
X.FL "\(eno" "Do not copy \fI*.o\fR files"
X.FL "\(enr" "Restore files"
X.FL "\(ens" "Do not copy \fI*.s\fR files"
X.FL "\(ent" "Preserve creation times"
X.FL "\(env" "Verbose; list files being backed up"
X.FL "\(enz" "Compress the files on the backup medium"
X.EX "backup \(enmz . /f0" "Backup current directory compressed"
X.EX "backup /bin /usr/bin" "Backup bin from RAM disk to hard disk"
X.PP
X\fIBackup\fR (recursively) backs up the contents of a given directory and its
Xsubdirectories to another part of the file system.
XIt has two typical uses.
XFirst, some portion of the file system can be backed up onto 1 or more
Xdiskettes.
XWhen a diskette fills up, the user is prompted for a new one.
XThe backups are in the form of mountable file systems.
XSecond, a directory on RAM disk can be backed up onto hard disk.
XIf the target directory is empty, the entire source directory is copied
Xthere, optionally compressed to save space.
XIf the target directory is an old backup, only those files in the target
Xdirectory that are older than similar names in the source directory are
Xreplaced.
X\fIBackup\fR uses times for this purpose, like \fImake\fR.
XCalling \fIBackup\fR as \fIRestore\fR is equivalent to using the -r option; 
Xthis replaces newer files in the target directory with older files from the
Xsource directory, uncompressing them if necessary.  The target directory
Xcontents are thus returned to some previous state.
/
echo x - badblocks
sed '/^X/s///' > badblocks << '/'
X.CD "badblocks \(en put a list of bad blocks in a file"
X.SX "badblocks \fIblock_special\fR [\fIblock\fR] ..."
X.FL "\fR(none)"
X.EX "badblocks /dev/hd1~~~~~~~" "Handle bad blocks on \fI/dev/hd1\fP"
X.EX "badblocks /dev/hd3 310 570 1680 " "Three bad blocks on \fI/dev/hd3\fP"
X.PP
XIf a device contains bad sectors, it is important to not have them
Xallocated to important files.  This program makes it possible to collect
Xup to 7 bad blocks into a dummy file, so they will not be allocated for a 
X\*(OQreal\*(CQ file.  
XWhen the program starts up, it asks for a list of bad blocks, unless
Xthey are provided as arguments.
XThen it creates a file whose name is of the
Xform \fI.Bad_xxxxx\fR, where \fIxxxxx\fR is a pid.
X
X
X.SP 0.7
/
echo x - banner
sed '/^X/s///' > banner << '/'
X.CD "banner \(en print a banner"
X.SX "banner \fIarg ..."
X.FL "\fR(none)"
X.EY "banner happy birthday" "Print a banner saying happy birthday"
X.PP
X\fIBanner\fR prints its arguments on \fIstdout\fR using a matrix 
Xof 6 x 6 pixels per character.  The @ sign is used for the pixels.
X
X
X
/
echo x - basename
sed '/^X/s///' > basename << '/'
X.CD "basename \(en strip off file prefixes and suffixes"
X.SX "basename \fIfile\fR [\fIsuffix\fR]
X.FL "\fR(none)"
X.EX "basename /user/ast/file.c" "Strips path to yield \fIfile.c\fP"
X.EX "basename /user/file.c .c" "Strips path and \fI.c\fP to yield \fIfile\fP"
X.PP
XThe initial directory names (if any) are removed yielding the name of the
Xfile itself.
XIf a second argument is present, it is interpreted as a suffix and is
Xalso stripped, if present.
XThis program is primarily used in shell scripts.
X
X
X
/
echo x - bawk
sed '/^X/s///' > bawk << '/'
X.CD "bawk \(en pattern matching language"
X.SX "bawk \fIrules\fR [\fIfile\fR] ...
X.FL "\fR(none)"
X.EX "bawk rules input" "Process \fIinput\fR according to \fIrules\fR"
X.EX "bawk rules \(en  >out" "Input from terminal, output to \fIout\fR"
X.PP
X\fIAwk\fR is a pattern matching language.
X\fIBawk\fR is Basic Awk, a subset of the original.
XThe file name \(en can be used to designate \fIstdin\fR.
XThe manual is given in Chap. 9.
X
X
/
echo x - btoa
sed '/^X/s///' > btoa << '/'
X.CD "btoa \(en binary to ascii conversion"
X.SX "btoa\fR [\fB\(enadhor\fR]\fR [\fIinfile\fR] [\fIoutfile\fR]"
X.FL "\(ena" "Decode, rather than encode, the file"
X.FL "\(end" "Extracts repair file from diagnosis file"
X.FL "\(enh" "Help menu is displayed giving the options"
X.FL "\(eno" "The obsolete algorithm is used for backward compatibility"
X.FL "\(enr" "Repair a damaged file"
X.EX "btoa <a.out >a.btoa" "Convert \fIa.out\fR to ASCII"
X.EX "btoa \(ena <a.btoa >a.out" "Reverse the above"
X.PP
X\fIBtoa\fR is a filter that converts a binary file to ascii for transmission
Xover a telephone line.  If two file names are provided, the first in used for
Xinput and the second for output.  If only one is provided, it is used as the
Xinput file.  The program is a functionally similar alternative 
Xto \fIuue/uud\fR, but the encoding is completely different.
XSince both of these are widely used, both have been provided with 
X.MX .
XThe file is expanded about 25 percent in the process.
X
X
X
/
echo x - cal
sed '/^X/s///' > cal << '/'
X.CD "cal \(en print a calendar"
X.SX "cal\fR [\fImonth\fR] \fIyear"
X.FL "\fR(none)"
X.EY "cal 3 1992" "Print March 1992"
X.PP
X\fICal\fR prints a calendar for a month or year.  The year can be 
Xbetween 1 and 9999.  
XNote that the year 91 is not a synonym for 1991, but is itself a
Xvalid year about 19 centuries ago.  The calendar produced is the one used
Xby England and her colonies.  Try Sept. 1752, Feb 1900, and Feb 2000.  If
Xyou do not understand what is going on, look up \fICalendar, Gregorian\fR in a
Xgood encyclopedia.
X
X
X.SP 2.5
/
echo x - calendar
sed '/^X/s///' > calendar << '/'
X.CD "calendar \(en reminder service"
X.SX "calendar [\fB\(en\fR] [\fB\(enr\fR]"
X.FL "\(en" "Work for every user and send mail to him"
X.FL "\(enr" "Restrict multiple execution on the same day"
X.EX "calendar" "Check \fIcalendar\fR file in current directory"
X.EX "calendar" "Normary used under the control of cron(8)"
X.EX "calendar \(enr" " Normary used in /etc/rc file"
X.PP
XBasically \fIcalendar\fR program consults the file \fIcalendar\fR in the 
Xcurrent directory and display lines which contain today's or tomorrow's date.
XMonth-day formats such as '12/25', 'Dec. 25', 
X'december 25', '*/25', '12/*', '*/*' are recognized.  The asterisk
Xmeans 'all' days or 'all' months.  On weekends 'tomorrow' extends through 
Xnext Monday without any consideration about holidays.
XTo prevent ambiguity, the formats '25 Dec.' and '25/12' are not recognized.
X.PP
XWhen an argument \fB\(en\fR is present, \fIcalendar\fR works for all users
Xwith a file \fIcalendar\fR in their login directories and sends them mail.
XNormally this is done daily under the control of \fIcron\fR.
X.PP
XThe \fB\(enr\fR option does its the same job as \fB\(en\fR option, but touches
Xthe \fIcalendar\fR to prevents further access on the same day.
XNormally this is done in the \fI/etc/rc\fR file on a machine  which may be
Xbooted several times in one day.
/
echo x - cat
sed '/^X/s///' > cat << '/'
X.CD "cat \(en concatenate files and write them to \fIstdout\fP"
X.SX "cat\fR [\fB\(enu\fR]\fR [\fIfile\fR] ..."
X.FL "\(enu" "Unbuffered output"
X.EX "cat file" "Display file on the terminal"
X.EX "cat file1 file2 | lpr" "Concatenate 2 files and print result"
X.PP
X.I Cat
Xconcatenates its input files and copies the result to \fIstdout\fR.
XIf no input file is named, or \(en is encountered as a file name, standard
Xinput is used.
XOutput is buffered in 512 byte blocks unless the 
X.B \(enu
Xflag is given.
XIf you just want to copy a file, \fIcp\fR should be used since it is faster.
X.SP 2.5
X
X
/
echo x - cc
sed '/^X/s///' > cc << '/'
X.CD "cc \(en C compiler"
X.SX "cc\fR [\fB\(enFLRSTUciosvw\fR]\fR [\fB\(enD\fIname\fR] ... [\fB\(enI\fIdir\fR] ... [\fB\(enLIB\fR] \fIfile\fR ..."
X.FL "\(enD" "The flag \fB\(enD\fIx=y\fR defines a macro \fIx\fR with (optional) value \fIy\fR"
X.FL "\(enF" "Use a file instead of a pipe for preprocessor output [IBM]"
X.FL "\(enI" "\fB\(enI\fIdir\fR searches \fIdir\fP for include files"
X.FL "\(enL" "List the assembly code on \fIstdout\fR [IBM]"
X.FL "\(enLIB~\fRProduce a library module [IBM]" ""
X.FL "\(enR" "Complain about all non Kernighan & Ritchie code"
X.FL "\(enS" "Produce an assembly code file, then stop"
X.FL "\(enT" "The flag \fB\(enT\fIdir\fR tells \fIcem\fR to use \fIdir\fR for temporary files"
X.FL "\(enU" "Undefine a macro"
X.FL "\(enc" "Compile only. Do not link.
X.FL "\(eni" "Use separate I & D space (64K + 64K) [IBM]"
X.FL "\(eno" "Put output on file named by next arg"
X.FL "\(ens" "For IBM, add symbol table; for 68000 strip symbol table"
X.FL "\(env" "Verbose; print pass names"
X.FL "\(enw" "Suppress warning messages"
X.EX "cc \(enc file.c" "Compile \fIfile.c\fP"
X.EX "cc \(enD_MINIX file.c" "Treat the symbol \fI_MINIX\fP as defined"
X.EX "cc \(enc \(enLIB file.c" "Make a module for the library"
X.PP
XThis is the C compiler.
XIt has multiple passes.
XThe names of the programs executed for each pass, their inputs and their
Xoutputs are given in the table below.
X.HS
X.ta 1.4i 2.1i 2.8i 3.5
X   \fBProgram	Input	Output	Operation performed\fR
X.br
X   /lib/cpp	prog.c	prog.i	C preprocessor [IBM]
X.br
X   /lib/cem	prog.i	prog.k	Parsing and semantic analysis
X.br
X   /usr/lib/opt	prog.k	prog.m	Optimization of the intermediate code
X.br
X   /usr/lib/cg	prog.m	prog.s	Code generation
X.br
X   /usr/bin/asld	prog.s	a.out	Assembly and linking [IBM]
X.br
X   /usr/bin/as	prog.s	prog.o	Assembly [68000]
X.br
X   /usr/lib/ld	prog.o	.out	Linking [68000]
X.br
X   /usr/lib/cv	.out	a.out	Conversion to \s-2MINIX\s0 format [68000]
X.HS
XThe main program,
X.I cc ,
Xforks appropriately to call the passes, transmitting flags and arguments.
XThe \fB\(env\fR flag causes the passes to be listed as they are called.
X.PP
XThe IBM C compiler uses a combined assembler-linker that takes in assembly
Xcode files in packed format and produces an \fIa.out\fR file.
XThe 68000 C compiler uses normal \fI.o\fR files.
XAssembly language files on the IBM can be packed and unpacked using the
Xfilters \fIlibpack\fR and \fIlibupack\fR.
XThe IBM libraries are 
Xarchives of packed assembly code files, except that defined symbols
Xmust be declared by \fI.define\fP statements at the beginning.
XTo make modules for inclusion in the library, use the \fB\(enc\fP and
X\fB\(enLIB\fP options.
XIf you compile library modules by accident without using the \fB\(enLIB\fR
Xflag, they will not be recognized, leading to undefined reference error
Xmessages from the linker.
X.PP
XIf memory is tight, use the \fB\(enF\fR flag to force the compiler to
Xrun the passes one at a time, without pipes.
XWhen available memory is very limited, it may be
Xnecessary to run
X.I chmem
Xto reduce the sizes of some compiler passes.
XOn the other hand, 
Xif the compiler (or, in fact, almost any program)
Xbegins acting strange, it is almost always due to its running
Xout of stack or disk space.
XThe relevant pass can be given more stack space using
X.I chmem .
XFor large programs, it make take a little experimenting to get the sizes
Xright.
XThe \fIcem\fR is usually the guilty party.
XBe careful about \fI/tmp\fR filling up too.
XMore space for scratch files can be obtained by removing other files
Xof using \fB\(enT\fR.
X.PP
XThe compiler is derived from the ACK system (Tanenbaum et 
Xal., \fICommunications of the ACM\fR, Sept. 1983),
Xnot from the AT&T portable C compiler.
XThe sources are available from the companies listed after the Table of
XContents.
X
X
X
/
echo x - cdiff
sed '/^X/s///' > cdiff << '/'
X.CD "cdiff \(en context diff"
X.SX "cdiff\fR [\fB\(enc\fIn\fR] \fIoldfile \fInewfile"
X.FL "\(enc" "Provide \fIn\fR lines of context"
X.EX "cdiff old new >f" "Write context diff on \fIf\fR"
X.EX "cdiff \(enc1 old new >f" "Use only 1 line of context"
X.PP
X\fICdiff\fR produces a context diff by first running \fIdiff\fR and then 
Xadding context.  
XSome update programs, like \fIpatch\fR, can use context diffs to update
Xfiles, even in the presence of other, independent changes.
X
X
X
/
echo x - cgrep
sed '/^X/s///' > cgrep << '/'
X.CD "cgrep \(en grep and display context"
X.SX "cgrep\fR [\fB\(ena \fIn\fR]\fR [\fB\(enb \fIn\fR] [\fB\(enf\fR] [\fB\(enl \fIn\fR]  [\fB\(enn\fR] [\fB\(enw \fIn\fR] \fIpattern\fR [\fIfile\fR] ...
X.FL "\(ena" "How many lines to display after the matching line"
X.FL "\(enb" "How many lines to display before the matching line"
X.FL "\(enf" "Suppress file name in the output"
X.FL "\(enl" "Lines are truncated to this length before comparison"
X.FL "\(enn" "Suppress line numbers in the output"
X.FL "\(enw" "Sets window size (same as \fB\(ena\fR n \fB\(enb\fR n)"
X.EY "cgrep \(enw 3 hello file1" "Print 3 lines of context each way"
X.PP
X\fICgrep\fR is a program like \fIgrep\fR, except that it also can print
Xa few lines above and/or below the matching lines.
XIt also prints the line numbers of the output.
X
X
X
/
echo x - chgrp
sed '/^X/s///' > chgrp << '/'
X############ NEXT ENTRY HAS NOT BEEN CHECKED #############
X.CD "chgrp \(en change group"
X.SX "chgrp [\fB\(enR\fR] [\fIuser.\fR]\fIgroup \fIfile\fR ..."
X.FL "\(enR" "Change directory hierarchies"
X.EX "chgrp system file1 file2" "Make \fIsystem\fR the group of the files"
X.EX "chrgp \(enR other dir1" "Make \fIother\R the group of all files below dir1"
X.PP
XThe group field (and optionally user field) of the named files is changed to 
X.I group
Xand
X.I user .
XAlternatively, a decimal gid (uid) may be specified instead of a group name.
XIf the \fB\(enR\fR flag is used, the changes will be applied recursively to
Xall files in named directories. Only the superuser may execute this command.
X
X
X
/
echo x - chmem
sed '/^X/s///' > chmem << '/'
X.CD "chmem \(en change memory allocation"
X.SX "chmem\fR [\fB+\fR]\fR [\fB\(en\fR] [\fB=\fR] \fIamount file
X.FL "\fR(none)"
X.EX "chmem =50000 a.out" "Give \fIa.out\fP 50K of stack space"
X.EX "chmem \(en4000 a.out" "Reduce the stack space by 4000 bytes"
X.EX "chmem +1000 file1" "Increase each stack by 1000 bytes"
X.PP
XWhen a program is loaded into memory, it is allocated enough memory
Xfor the text and data+bss segments, plus
Xan area for the stack.
XData segment growth using 
X.I malloc ,
X.I brk ,
Xor
X.I sbrk 
Xeats up stack space from the low end.
XThe amount of stack space to allocate is derived
Xfrom a field in the executable program's file header.
XIf the combined stack and data segment growth exceeds the stack space
Xallocated, the program will be terminated.
X.PP
XIt is therefore important to set the amount of stack space carefully.
XIf too little is provided, the program may crash.
XIf too much is provided, memory will be wasted, and fewer programs will be able
Xto fit in memory and run simultaneously.
X.MX
Xdoes not swap, so that when memory is full, subsequent attempts to fork will
Xfail.
XThe compiler sets the stack space
Xto the largest possible value (for the Intel CPUs, 64K \(en text \(en data).
XFor many programs, this value is far too large.
XNonrecursive programs that do not call
X.I brk ,
X.I sbrk ,
Xor
X.I malloc ,
Xand do not have any local arrays usually do not need more than 8K of stack
Xspace.
X.PP
XThe
X.I chmem
Xcommand changes the value of the header field that determines the stack allocation, and
Xthus indirectly the total memory required to run the program.
XThe = option sets the stack size
Xto a specific value; the + and \(en options increment and decrement the
Xcurrent value by the indicated amount.
XThe old and new stack sizes are printed.
X
X
X
/
echo x - chmod
sed '/^X/s///' > chmod << '/'
X############ NEXT ENTRY HAS NOT BEEN CHECKED #############
X.CD "chmod \(en change access mode for files"
X.SX "chmod [\fB\(enR\fR] \fImode \fIfile\fR ..."
X.FL "\(enR" "Change hierarchies recursively"
X.EX "chmod 755 file" "Owner: rwx Group: r\(enx Others: r\(enx"
X.EX "chmod +x file1 file2" "Make \fIfile1\fR and \fIfile2\fR executable"
X.EX "chmod a\(enw file" "Make \fIfile\fR read only"
X.EX "chmod u+s file" "Turn on SETUID for \fIfile\fR"
X.EX "chmod \(enR o+w dir" "Allow writing for all files in dir"
X.PP
XThe given mode is applied to each file in the file list. If the \fB\(enR\fR
Xflag is present, the files in a directory will be changed as well.
XThe mode can be either absolute or symbolic. Absolute modes are given as an
Xoctal number that represents the new file mode. The mode bits are defined as
Xfollows: 
X.ta 0.25i
X.nf
X.HS
X	4000    Set effective user id on execution to file's owner id
X	2000    Set effective group id on execution to file's group id
X	0400    file is readable by the owner of the file
X	0200    writeable by owner
X	0100    executable by owner
X	0070    same as above, for other users in the same group
X	0007    same as above, for all other users
X.HS
X.fi
XSymbolic modes modify the current file mode in a specified way. The form is:
X.HS
X	[who] op permissions { op permissions ...} {, [who] op ... }
X.HS
XThe possibilities for \fIwho\fR are \fIu\fR, \fIg\fR, \fIo\fR, and \fIa\fR,
Xstanding for user, group, other and all, respectively.  
XIf \fIwho\fR is omitted, \fIa\fR is assumed, but the current umask is used.  
XThe op can be \fI+\fR, \fI-\fR, or \fI=\fR;  \fI+\fR turns on the 
Xgiven permissions, \fI\(en \fRturns them off; \fI=\fR sets the permissions 
Xexclusively for the given \fIwho\fR.  
XFor example \fIg=x\fR sets the group permissions to \fI--x\fR. 
X.PP
XThe possible permissions are \fIr\fR, \fIw\fR, \fIx\fR; which stand for read, 
Xwrite, and execute;  \fIs\fR turns on the set effective user/group id bits.  
X\fIs\fR only makes sense with \fIu\fR and \fIg\fR;\fR o+s\fR is 
Xharmless.
X
X
X
/
echo x - chown
sed '/^X/s///' > chown << '/'
X############ NEXT ENTRY HAS NOT BEEN CHECKED #############
X.CD "chown \(en change owner"
X.SX "chown [\fB\(enR\fR] \fIuser\fR[.\fIgroup\fR] \fIfile\fR ..."
X.FL "\(enR" "Change directory hierarchies"
X.EX "chown ast file1 file2" "Make \fIast\fR the owner of the files"
X.EX "chown \(enR ast.other dir" "Change the owner and group of all files in dir"
X.PP
XThe owner field (and optionally group field) of the named files is changed
Xto
X.I user 
X(i.e., login name specified) and
X.I group .
XAlternatively, a decimal uid(gid) may be specified instead of a user name.
XOnly the superuser may execute this command.
X
X
X
/
echo x - cksum
sed '/^X/s///' > cksum << '/'
X############ NEXT ENTRY HAS NOT BEEN CHECKED #############
X.CD "cksum \(en display file checksum and size"
X.SX "cksum [\fIfile\fR ...]"
X.FL "\fR(none)"
X.EX "cksum" "Display CRC and size of \fIstdin\fR"
X.EX "cksum *.c" "Display CRC and size of \fI.c\fP files"
X.PP
X.I Cksum
Xcalculates and writes to standard output the 32-bits CRC of the input
X.I files ,
Xor of stdin if no
X.I files
Xwere specified. The size in bytes of each
X.I file
Xwill be displayed after a space. The name of each
X.I file
Xwill be displayed after another space.
X
X
X
X
/
echo x - clr
sed '/^X/s///' > clr << '/'
X.CD "clr \(en clear the screen"
X.SX "clr~~~~~~~~" 
X.FL "\fR(none)"
X.EY "clr	~" "Clear the screen"
X.PP
XAll text is removed from the screen, resulting in an empty screen with the
Xcursor positioned in the upper left-hand corner.
X
X
X
X.SP 1.7
/
echo x - cmp
sed '/^X/s///' > cmp << '/'
X.CD "cmp \(en compare two files"
X.SX "cmp\fR [\fB\(enls\fR] \fIfile1 file2"
X.FL "\(enl" "Loud mode. Print bytes that differ (in octal)"
X.FL "\(ens" "Silent mode.  Print nothing, just return exit status"
X.EX "cmp file1 file2" "Tell whether the files are the same"
X.EX "cmp \(enl file1 file2" "Print all corresponding bytes that differ"
X.PP
XTwo files are compared.
XIf they are identical, exit status 0 is returned.
XIf they differ, exit status 1 is returned.
XIf the files cannot be opened, exit status 2 is returned.
XIf either file is \(en ,\fIstdin\fR is used.
X
X
X
X
/
echo x - cmpO
sed '/^X/s///' > cmpO << '/'
X.CD "cmp \(en compare two files"
X.SX "cmp\fR [\fB\(enls\fR] \fIfile1 file2"
X.FL "\(enl" "Loud mode. Print bytes that differ (in octal)"
X.FL "\(ens" "Silent mode.  Print nothing, just return exit status"
X.EX "cmp file1 file2" "Tell whether the files are the same"
X.EX "cmp \(enl file1 file2" "Print all corresponding bytes that differ"
X.PP
XTwo files are compared.
XIf they are identical, exit status 0 is returned.
XIf they differ, exit status 1 is returned.
XIf the files cannot be opened, exit status 2 is returned.
XIf either file is \(en ,\fIstdin\fR is used.
X
X
X
X
/
echo x - comm
sed '/^X/s///' > comm << '/'
X.CD "comm \(en print lines common to two sorted files"
X.SX "comm\fR [\fB\(en123\fR] \fIfile1 file2
X.FL "\(en1" "Suppress column 1 (lines present only in \fIfile1\fP)" 
X.FL "\(en2" "Suppress column 2 (lines present only in \fIfile2\fP)" 
X.FL "\(en3" "Suppress column 3 (lines present in both files)"
X.EX "comm file1 file2" "Print all three columns"
X.EX "comm \(en12 file1 file2" "Print only lines common to both files"
X.PP
XTwo sorted files are read and compared.
XA three column listing is produced.
XFiles only in 
X.I file1
Xare in column 1;
Xfiles only in
X.I file2
Xare in column 2;
Xfiles common to both files are in column 3.
XThe file name \(en means \fIstdin\fR. 
X
X
X
X.SP 1.5
/
echo x - compress
sed '/^X/s///' > compress << '/'
X.CD "compress \(en compress a file using modified Lempel-Ziv coding"
X.SX "compress\fR [\fB\(encdfv\fR]\fR [\fIfile\fR] ..."
X.FL "\(enc" "Put output on \fIstdout\fR instead of on \fIfile.Z\fR"
X.FL "\(end" "Decompress instead of compress"
X.FL "\(enf" "Force output even if there is no saving"
X.FL "\(env" "Verbose mode"
X.EX "compress <infile >outfile" "Compress 1 file"
X.EX "compress x y z" "Compress 3 files to \fIx.Z\fR, \fIy.Z\fR, and \fIz.Z\fR"
X.EX "compress \(end file.Z" "Decompress \fIfile.Z\fR to \fIfile\fR"
X.PP
XThe listed files (or \fIstdin\fR, if none are given) are compressed
Xusing the Ziv-Lempel algorithm.  If the output is smaller than the input,
Xthe output is put on \fIfile.Z\fR or \fIstdout\fR if no files are listed.  
XIf \fIcompress\fR is linked to \fIuncompress\fR, the latter is the same 
Xas giving the \fB\(end\fP flag.
XSimilarly, a link to \fIzcat\fR decompresses to \fIstdout\fR.
XThe
X.MX
Xversion of \fIcompress\fR uses 13-bit compression.
XThis means that when compressing files on other systems for transmission to
X.MX ,
Xbe sure that only 13-bit compression is used.
XOn many systems, the default is 16-bit (too big).
X
X
X.SP 1.5
/
echo x - cp
sed '/^X/s///' > cp << '/'
X############ NEXT ENTRY HAS NOT BEEN CHECKED #############
X.CD "cp \(en file copy"
X.SX "cp [\fB\(enRf\&iprv\fR] \fIfile1\fR \fIfile2\fR"
X.SX "cp [\fB\(enfR\&iprv\fR] \fIfile\fR ... \fIdirectory\fR"
X.FL "\(enf" "Forced remove existing file"
X.FL "\(eni" "Ask before removing existing file"
X.FL "\(enp" "Preserver full mode, uid, gid and times"
X.FL "\(enr" "Copy directories and treat special files as ordinary"
X.FL "\(env" "Display what cp is doing"
X.FL "\(enR" "Copy directories"
X.EX "cp oldfile newfile" "Copy \fIoldfile\fR to \fInewfile\fR"
X.EX "cp -R special newspecial" "Copy the \fIspecial\fR file"
X.PP
X.I Cp
Xcopies one file to another, or copies one or more files to a directory.
XUnless the \fB\(enr\fR flag is specified, special files will be copied as
Xspecial files. Copying a directory requires either the \fB\(enr\fR or the
X\fB\(enR\fR flags.
X
X
X
X
/
echo x - cpdir
sed '/^X/s///' > cpdir << '/'
X############ NEXT ENTRY HAS NOT BEEN CHECKED #############
X.CD "cpdir \(en copy a directory and its subdirectories"
X.SX "cpdir [\fB\(enpv\fR] \fIsrcdir\fR \fIdstdir\fR"
X.FL "\(enp" "Preserve the full mode, uid, gid and times"
X.FL "\(env" "Display cpdir's actions"
X.EY "cpdir dir1 dir2" "create \fIdir2\fR and copy \fIdir1\fR's files in it"
X.PP
X.I Cpdir
Xis identical to \fIcp \(enR\fR command, except that the destination directory 
Xis allowed to exists before the copy. Also, unlike
X.I cp ,
X.I cpdir
Xwill preserve the link structure of the copied directory.
X
X
X
X
/
echo x - crc
sed '/^X/s///' > crc << '/'
X.CD "crc \(en print the checksum of the file data"
X.SX "crc \fIfile\fR ..."
X.FL "\fR(none)\fR"
X.EY "crc *.c" "Print checksums of all the C programs"
X.PP
XThe checksum of each argument is computed and printed, along with the file
Xlength and its name, one file per line.
XThis program is useful for seeing if a file transmitted to another machine
Xhas arrived correctly.
XIt is conceptually similar to \fIsum\fR, except that it uses a stronger 
Xchecksum algorithm and also prints the length.
X
X
X
X.SP 1
/
echo x - cron
sed '/^X/s///' > cron << '/'
X.CD "cron \(en clock daemon"
X.SX "cron"
X.FL "\fR(none)"
X.EY "/usr/bin/cron" "Use absolute path in \fI/etc/rc\fR"
X.PP
X\fICron\fR is clock daemon.  It is typically started up by including the
Xcommand \fI/usr/bin/cron\fR in the \fI/etc/rc\fR file.  
XOnce started, \fIcron\fR puts itself
Xin the background, so no & is needed.  It runs forever, sleeping most of
Xthe time.  Once a minute it wakes up and examines \fI/usr/lib/crontab\fR to see
Xif there is any work to do.  If there is, the work is done.  The entries of
X\fI/usr/lib/crontab\fR contain 6 elements each.  Some examples follow:
X.HS
X.nf
X.ta 0.10i 0.40i 0.70i 1.0i 1.3i 1.8i 4.0i
X\fB	Min	Hr	Dat	Mo	Day	Command\fR
X	\0*	\0*	\0*	\0*	\0*	/usr/bin/date >/dev/tty0   #print date every minute
X	\00	\0*	\0*	\0*	\0*	/usr/bin/date >/dev/tty0   #print date on the hour
X	30	\04	\0*	\0*	1-5	/bin/backup /dev/fd1       #do backup Mon-Fri at 0430
X	30	19	\0*	\0*	1,3,5	/etc/backup /dev/fd1       #Mon, Wed, Fri at 1930
X	\00	\09	25	12	\0*	/usr/bin/sing >/dev/tty0   #Xmas morning at 0900 only
X.fi
X
X
X
X
/
echo x - ctags
sed '/^X/s///' > ctags << '/'
X.CD "ctags \(en build a tags file"
X.SX "ctags \fR[\fB\(enr\fR]\fR \fIfile\fR ..."
X.FL "\(enr" "Generate refs as well as tags"
X.EY "ctags \(enr *.h *.c" "Generate the tags file"
X.PP
X\fICtags\fR generates a \fItags\fR file from a collection of
XC source files.  It can also generate a \fIrefs\fR file.
XThe \fItags\fR file is used by \fIelvis'\fR 
X\*(OQ:tag\*(CQ command, and its \fB\(ent\fR
Xoption. 
XEach C source file is scanned for \fI#define\fR statements and global
Xfunction definitions.  The name of the macro or function becomes the name of
Xa tag.  For each tag, a line is added to the \fItags\fR file which contains:
Xthe name of the tag, a tab character, the name of the file containing the tag,
Xa tab character, and a way to find the particular line within the file.
X.PP
XThe \fIrefs\fR file is used by the \fIref\fR program, which can be invoked 
Xvia \fIelvis\fR K command.  When ctags finds a global function definition, it 
Xcopies the function header into the \fIrefs\fR file.  
XThe first line is flush against the
Xright margin, but the argument definitions are indented.the C source files.
X
X
X
X.SP -0.5
/
echo x - cut
sed '/^X/s///' > cut << '/'
X.CD "cut \(en select out columns of a file"
X.SX "cut [ \fB \(enb \fR|\fB \(enc\fR] \fIlist\fR [\fIfile...\fR]"
X.SX "cut \(enf \fIlist\fR [\fB\(end \fIdelim\fR] [\fB \(ens\fR]
X[\fIfile...\fR]" 
X.FL "\(enb" "Cut specified bytes"
X.FL "\(enc" "Select out specific characters"
X.FL "\(end" "Change the column delimiter to \fIdelim\fR"
X.FL "\(enf" "Select out specific fields that are separated by the
Xdelimiter character ( see \fIdelim\fR)"
X.FL "\(eni" "Runs of delimiters count as one"
X.FL "\(ens" "Suppres lines with no delimiter characters, when used
Xwith the \(enf option. Lines with no delimiters are passwd through
Xuntouched"
X.EX "cut \(enf 2 file" "Extract field 2"
X.EX "cut \(enc 1\(en2,5 file" "Extract character columns 1, 2, and 5"
X.EX "cut \(enc 1\(en5,7\(en file" "Extract all columns except 6"
X.PP
X\fICut\fR extracts one or more fields or columns from a file and writes them on
Xstandard output.
XIf the \fB\(enf\fR flag is used, the fields are separated by a delimiter 
Xcharacter, normally a tab, but can be changed using the \fB\(end\fR flag.
XIf the \fB\(enc\fR flag is used, specific columns can be specified.
XThe list can be comma or BLANK separated. The \fB\(enf\fR and
X\fB\(enc\fR flags  are mutually exclusive.
XNote: The POSIX1003.2 standard requires the option \(enb to cut out
Xspecific bytes in a file. It is intended for systems with multi byte
Xcharacters (e.g. kanji), since MINIX uses only one byte characters,
Xthis option is equivalent to \(enc. For the same reason, the option
X\(enn has no effect and is not listed in this manual page.
X
X
X
X
/
echo x - date
sed '/^X/s///' > date << '/'
X############ NEXT ENTRY HAS NOT BEEN CHECKED #############
X.CD "date \(en print or set the date and time"
X.SX "date [\fB\(enq\fR] [[\fIMMDDYY\fR]\fIhhmm\fR[\fIss\fR]\fR]"
X.SX "date [\fB\(enu\fR] [\fI+format\fR]
X.FL "\(enq" "Read the date from \fIstdin\fR"
X.FL "\(enu" "Print the date as GMT"
X.EX "date" "Print the date and time"
X.EX "date 0221921610" "Set date to Feb 21, 1992 at 4:10 p.m."
X.PP
XWith the \fB\(enq\fR flag or a numeric argument,
X.I date
Xsets the GMT time and date.
X.I MMDDYY
Xrefers to the month, day, and year;
X.I hhmmss
Xrefers to the hour, minute and second.
XEach of the six fields must be exactly two digits, no more and no less.
X.I date
Xalways display the date and time, with the default format for the system.
XThe \fB\(enu\fR flag request GMT time instead of local time.
XA format may be specified with a + followed by a printf-like string with
Xthe following options:
X.ta 0.25i
X.nf
X.HS
X	%%  % character
X	%A  Name of the day
X	%B  Name of the month
X	%D  mm/dd/yy
X	%H  Decimal hour on 2 digits
X	%I  Decimal hour modulo 12 on 2 digits
X	%M  Decimal minute on 2 digits
X	%S  Decimal seconds on 2 digits
X	%T  HH:MM:SS
X	%U  Decimal week number, Sunday being first day of week
X	%W  Decimal week number, Monday being first day of week
X	%X  Same as %T
X	%Y  Decimal year on 4 digits
X	%Z  Time Zone (if any)
X	%a  Abbreviated name of the day
X	%b  Abbreviated name of the month
X	%c  Appropriate date & time (default format)
X	%d  Decimal day of the month on 2 digits
X	%e  Same as %d, but a space replaces leading 0
X	%h  Same as %b
X	%j  Decimal dey of the year on 3 digits
X	%m  Decimal month on 2 digits
X	%n  Newline character
X	%p  AM or PM
X	%r  12-hour clock time with AM/PM
X	%t  Tab character
X	%w  Decimal day of the week (0=Sunday)
X	%x  Same as %D
X	%y  Decimal year on 2 digits
X.HS
X
X
X
/
echo x - dd
sed '/^X/s///' > dd << '/'
X.CD "dd \(en disk dumper"
X.SX "dd\fR [\fIoption = value\fR] ..."
X.FL "\fR(none)"
X.EX "dd if=/dev/fd0 of=/dev/fd1" "Copy disk 0 to disk 1"
X.EX "dd if=x of=y bs=1w skip=4" "Copy \fIx\fP to \fIy\fP, skipping 4 words"
X.EX "dd if=x of=y count=3" "Copy three 512\(enbyte blocks"
X.PP
XThis command is intended for copying partial files.
XThe block size, skip count, and number of blocks to copy can be specified.
XThe options are:
X.HS
X.ta 0.25i 1.5i
X	\fBif\fR = file	\(en Input file (default is \fIstdin\fR)
X.br
X	\fBof\fR = file	\(en Output file (default is standard output)
X.br
X	\fBibs\fR = n	\(en Input block size (default 512 bytes)
X.br
X	\fBobs\fR = n	\(en Output block size (default is 512 bytes)
X.br
X	\fBbs\fR = n	\(en Block size; sets \fIibs\fP and \fIobs\fP (default is 512 bytes)
X.br
X	\fBskip\fR = n	\(en Skip \fIn\fP input blocks before reading
X.br
X	\fBseek\fR = n	\(en Skip \fIn\fP output blocks before writing
X.br
X	\fBcount\fR = n	\(en Copy only \fIn\fP input blocks
X.br
X	\fBconv = lcase\fR	\(en Convert upper case letters to lower case
X.br
X	\fBconv = ucase\fR	\(en Convert lower case letters to upper case
X.br
X	\fBconv = swab\fR	\(en Swap every pair of bytes
X.br
X	\fBconv = noerror\fR	\(en Ignore errors and just keep going
X.HS
XWhere sizes are expected, they are in bytes.
XHowever, the letters \fBw\fR, \fBb\fR, or \fBk\fR may be appended to the
Xnumber to indicate words (2 bytes), blocks (512 bytes), or K
X(1024 bytes), respectively.
XWhen
X.I dd
Xis finished, it reports the number of full and partial blocks read and written.
X
X
X
X.SP 1
/
echo x - de
sed '/^X/s///' > de << '/'
X.CD "de \(en disk editor"
X.SX "de\fR [\fB\(enw\fR] \fIblock_device"
X.SX "de \(enr \fIfile
X.FL "\(enr" "Recover a file that has been removed"
X.FL "\(enw" "Enable writing, so device can be modified"
X.EX "de \(enr /usr/ast/prog.c" "Undo the effects of: \fIrm /usr/ast/prog.c\fR"
X.EX "de \(enw /dev/fd0" "Edit \fI/dev/fd0\fR for writing"
X.PP
X\fIDe\fR is a program for system administrators that allows disks to be
Xinspected block by block.
XA variety of display options and commands are available, as described in
XChap. 9.
XFor a summary, start the program and type \fIh\fR for help.
XThe program can also restore files that have just been removed by \fIrm\fR,
Xprovided that the i-node and blocks are still intact.
XAnother feature is searching disks for ASCII strings, to help locate things
Xafter a crash.
XFinally, individual disk words can be changed, for example, the sizes of
Xblock special files.
X
X
X
/
echo x - df
sed '/^X/s///' > df << '/'
X.CD "df \(en report on free disk space and i-nodes"
X.SX "df \fIspecial ..."
X.FL "\fR(none)"
X.EX "df /dev/ram" "Report on free RAM disk space"
X.EX "df /dev/fd0 /dev/fd1" "Report on diskette space"
X.EX "df~~~" "Report on all mounted devices"
X.PP
XThe amount of disk space and number of i-nodes, both free and used is
Xreported.
XIf no argument is given, \fIdf\fR reports on the root device and all mounted
Xfile systems.
X
X
X
/
echo x - dhrystone
sed '/^X/s///' > dhrystone << '/'
X.CD "dhrystone \(en integer benchmark"
X.SX "dhrystone"
X.FL "\fR(none)"
X.EY "dhrystone" "Run the dhrystone benchmark"
X.PP
XMany years ago, a floating-point benchmark called \fIwhetstone\fR was
Xpopular for benchmarking FORTRAN programs.
XNowadays, an integer benchmark called \fIdhrystone\fR is widely used
Xfor benchmarking UNIX systems.
XThis is it.
XBe warned, however, that \fIdhrystone\fR is entirely CPU bound, and
Xgoes blindingly fast on machines with high-speed caches.
XAlthough this is a good measure for programs that spend most of their
Xtime in some inner loop, it is a poor benchmark for I/O bound applications.
X
X
X
/
echo x - diff
sed '/^X/s///' > diff << '/'
X.CD "diff \(en print differences between two files"
X.SX "diff  \fR [\fB\(enc \fR|\fB \(ene \fR|\fB \(enC \fIn\fR\] [\fB\(enbr\fR]\fIfile1 file2\fR"
X.FL "\(enC \In" "Produce output that contains \fIn\fR lines of context"
X.FL "\(enb" "Ignore white space when comparing"
X.FL "\(enc" "Produce output that contains three lines of context"
X.FL "\(ene" "Produce an \fIed\fR-script to convert \fIfile1\fR into \fIfile2\fR"
X.FL "\(enr" "Apply \fIdiff\fR recursively to files and directories of
Xthe same name, when \fIfile1\fR and \fIfile2\fR are both directories"
X.EX "diff file1 file2" "Print differences between 2 files"
X.EX "diff -C 0 file1 file2" "Same as above"
X.EX "diff -C 3 file1 file2" "Output three lines of context with every
Xdifference encountered"
X.EX "diff -c file1 file2" Same as above"
X.EX "diff /etc /dev" "Compares recursively the directories \fI/etc\fR and \fI/dev\fR"
X.EX "diff passwd /etc" "Compares \fI./passwd\fR to \fI/etc/passwd"
X.PP
X\fIDiff\fR compares two files and generates a list of lines telling how
Xthe two files differ.  Lines may not be longer than 128 characters.
XIf the two  arguments on the command line are both directories,
X\fIdiff\fR recursively steps through all subdirectories comparing
Xfiles of the same name. If a file name is found only in one directory,
Xa diagnostic message is written to \fIstdout\fR. A file that is of
Xeither block special, character special or FIFO special type, cannot
Xbe compared to any other file.
XOn the other hand, if there is one directory and one file given on the
Xcommand line, \fIdiff\fR tries to compare the file with the same name
Xas \fIfile\fR in the directory \fIdirectory\fR.
X
X
X
/
echo x - dis88
sed '/^X/s///' > dis88 << '/'
X.CD "dis88 \(en disassembler [IBM]"
X.SX "dis88\fR [\fB\(eno\fR] \fIinfile\fR [\fIoutfile\fR]"
X.FL "\(eno" "List the object code along with the assembly code"
X.EX "dis88 a.out >listing" "Disassemble \fIa.out\fR"
X.EX "dis88 \(eno a.out listing" "Ditto, but with object code"
X.PP
X\fIDis88\fR is an 8088 disassembler.  
XIt takes an executable file and prints the
Xsymbolic assembly code that corresponds to it.  If the executable file contains
Xa symbol table (added by the program \fIast\fR), the symbol table 
Xinformation is used to give a more readable asembly listing.
XMore information is provided in Chap. 9.
X
X
X
/
echo x - diskcheck
sed '/^X/s///' > diskcheck << '/'
X.CD "diskcheck \(en check a disk for bad sectors"
X.SX "diskcheck \fIdevice \fIstart \fIcount"
X.FL "\fR(none)"
X.EX "diskcheck /dev/at0 0 1200" "Check 1.2 MB diskette"
X.EX "diskcheck /dev/at0 100 50" "Check blocks 100 to 149"
X.PP
X\fIDiskcheck\fR checks a disk for bad sectors by reading in each sector,
Xwriting a known bit pattern onto it, reading it back in and comparing with
Xwhat was written.  This check is then done a second time.  Bad sectors are 
Xreported.  After each sector is tested, the original sector is restored.
XOnly use this program on unmounted partitions.
XKilling it part way through may result in lost data.
X
X
X
/
echo x - diskcopy
sed '/^X/s///' > diskcopy << '/'
X.CD "diskcopy \(en copy a disk with only one drive [AMIGA]"
X.SX "diskcopy"
X.FL "\fR(none)"
X.EY "diskcopy" "Copy a disk using the internal disk drive"
X.PP
XBefore using
X.I diskcopy ,
Xuse
X.I chmem
Xto increase the stack+malloc area to as much as you can get away with.
XIn the ideal case you should
X.I chmem
Xit to a little over 720K (say, 750000) so you do not have to swap
Xdisks.
XIn this way, the entire diskette will be read in at once and stored in
Xmemory.
XOnce you have inserted the destination disk, the whole thing will be
Xwritten back in one fell swoop, eliminating the need to constantly
Xshuffle diskettes.
X
X
X
/
echo x - diskrtc
sed '/^X/s///' > diskrtc << '/'
X.CD "diskrtc \(en set date from a disk controller real time clock [ATARI]"
X.SX "diskrtc [bms1] [bms2] [supra] [icd]"
X.FL "bms1   \fRRead the clock from a bms 100 disk controller"
X.FL "bms2   \fRRead the clock from a bms 200 disk controller"
X.FL "supra  \fRRead the clock from a supra disk controller"
X.FL "icd       \fRRead the clock from an icd disk controller"
X.EY "diskrtc icd" "Read the date from an icd disk controller"
X.PP
X.I Diskrtc
Xreads the current date and time from the clock supplied on a disk
Xcontroller and sets the time accordingly.
XThis program is usually called from
X.I /etc/rc .
X
X
X
/
echo x - diskset
sed '/^X/s///' > diskset << '/'
X.CD "diskset \(en set real time clock on disk controller [ATARI]"
X.SX "diskset [bms1] [bms2]"
X.FL "bms1  \fRSet the clock of a bms 100 disk controller"
X.FL "bms2  \fRSet the clock of a bms 200 disk controller"
X.EY "diskset bms1" "Set the clock of a bms 100 disk controller"
X.PP
X.I Diskset
Xinitializes the clock on a bms 100 or 200 diskcontroller with
X.MX 's
Xidea of the current date and time.
X
X
X
/
echo x - dosdir
sed '/^X/s///' > dosdir << '/'
X.CD "dosdir \(en list an \s-2MS-DOS\s+2 directory [IBM]"
X.SX "dosdir\fR [\fB\(enlr\fR] \fIdrive"
X.FL "\(enl" "Long listing"
X.FL "\(enr" "Recursively descend and print subdirectories"
X.EX "dosdir \(enl A" "List root directory on drive A"
X.EX "dosdir \(enr C x/y" "Recursively list directory \fIx/y\fR"
X.PP
X.I Dosdir
Xreads standard IBM PC diskettes or hard disk partitions in
X\s-2MS-DOS\s+2 format and lists their contents on standard output.
XDirectory names should contain slashes to separate components, even though
X\s-2MS-DOS\s+2 uses backslashes.
XThe names
X.I dosdir ,
X.I dosread ,
Xand 
X.I doswrite
Xare all links to the same program.
XThe program sees which function to perform by seeing how it was called.
XA drive code of
X.I A
Xcauses the program to use \fI/dev/dosA\fR, for example, 
Xa link to \fI/dev/fd0\fR.
XSimilarly, to have hard disk partition 1 be DOS drive C, \fI/dev/dosC\fR 
Xcould be a link to \fI/dev/hd1\fR, and so on for other drive codes.
X
X
X
/
echo x - dosread
sed '/^X/s///' > dosread << '/'
X.CD "dosread \(en read a file from an \s-2MS-DOS\s+2 diskette [IBM]"
X.SX "dosread\fR [\fB\(ena\fR] \fIdrive \fIfile"
X.FL "\(ena" "ASCII file"
X.EX "dosread C g/adv >adv" "Read file \fIg/adv\fR from hard disk"
X.EX "dosread \(ena A prog.c >x" "Read ASCII file \fIprog.c\fR from drive A"
X.PP
X.I Dosread
Xreads one \s-2MS-DOS\s+2 file and writes it on standard output.
XThe file name must use slash, not backslash as a separator.
XASCII files have the final CTRL-Z stripped, and carriage return plus
Xline feed are mapped to line feed only, the usual
X.MX
Xconvention.
XA drive code of
X.I A
Xcauses the program to use \fI/dev/dosA\fR, typically a link to \fI/dev/fd0\fR.
XSimilarly, to have hard disk partition 1 be DOS drive C, \fI/dev/dosC\fR 
Xshould be a link to \fI/dev/hd1\fR, and so on for other drive codes.
X
X
X
/
echo x - doswrite
sed '/^X/s///' > doswrite << '/'
X.CD "doswrite \(en write a file onto an \s-2MS-DOS\s+2 diskette [IBM]"
X.SX "doswrite\fR [\fB\(ena\fR] \fIdrive \fIfile"
X.FL "\(ena" "ASCII file"
X.EX "doswrite A x/y <z" "Write file \fIz\fR to disk as \fIx/y\fR"
X.EX "doswrite \(ena B f" "Copy \fIstdin\fR to \s-2MS-DOS\s+2 file \fIf\fR"
X.PP
X.I Doswrite
Xwrites its \fIstdin\fR to an \s-2MS-DOS\s+2 file.
XThe diskette or partition must be formatted and have an \s-2MS-DOS\s+2 file 
Xsystem already in place, including all the directories leading up to the file.
XA drive code of
X.I A
Xcauses the program to use \fI/dev/dosA\fR, typically a link to \fI/dev/fd0\fR.
XSimilarly, to have hard disk partition 1 be DOS drive C, \fI/dev/dosC\fR 
Xshould be a link to \fI/dev/hd1\fR, and so on for other drive codes.
X
X
X
/
echo x - du
sed '/^X/s///' > du << '/'
X.CD "du \(en print disk usage"
X.SX "du\fR [\fB\(enas\fR]\fR [\fB\(enl \fIn\fR] \fIdir\fR ..."
X.FL "\(ena" "Give usage for all files"
X.FL "\(enl" "List up to \fIn\fR levels of subdirectories"
X.FL "\(ens" "Summary only"
X.EX "du dir" "List disk space used by files in dir"
X.EX "du \(ens dir1 dir2" "Give summaries only"
X.PP
X\fIDu\fR examines one or more directories and prints the amount of space 
Xoccupied by the files in those directories and their subdirectories.
X
X
X
/
echo x - echo
sed '/^X/s///' > echo << '/'
X.CD "echo \(en print the arguments"
X.SX "echo\fR [\fB\(enn\fR] \fIargument\fR ..."
X.FL "\(enn" "No line feed is output when done"
X.EX "echo Start Phase 1" "\*(OQStart Phase 1\*(CQ is printed"
X.EX "echo \(enn Hello" "\*(OQHello\*(CQ is printed without a line feed"
X.PP
X.I Echo 
Xwrites its arguments to standard output.
XThey are separated by blanks and terminated with a line feed unless
X.B \(enn
Xis present.
XThis command is used mostly in shell scripts.
X
X
X
/
echo x - ed
sed '/^X/s///' > ed << '/'
X.CD "ed \(en editor"
X.SX "ed \fIfile"
X.FL "\fR(none)"
X.EY "ed prog.c" "Edit \fIprog.c\fR"
X.PP
X\fIEd\fR is functionally equivalent to the standard V7 editor, ed.  
XIt supports the following commands:
X.HS
X.nf
X.ta 0.5i 0.95i	
X	(.)	a: append
X	(.,.)	c: change
X	(.,.)	d: delete
X		e: edit new file"
X		f: print name of edited file"
X	(1,$)	g: global command
X	(.)	i: insert
X	(.,.+1)	j: join lines together
X	(.)	k: mark
X	(.)	l: print with special characters in octal
X	(.,.)	m: move
X	(.,.)	p: print
X		q: quit editor"
X	(.)	r: read in new file
X	(.,.)	s: substitute
X	(1,$)	v: like g, except select lines that do not match
X	(1,$)	w: write out edited file
X.fi
X
XMany of the commands can take one or two addresses, as indicated above.  The
Xdefaults are shown in parentheses.  Thus \fIa\fR appends to the current 
Xline, and \fIg\fR works on the whole file as default.  
XThe dot refers to the current line.
XBelow is a sample editing session with comments given following the # symbol.
X.HS
X.nf
X.ta 0.5i 2.5i
X	ed prog.c	# Edit prog.c
X	3,20p	# Print lines 3 through 20
X	/whole/	# Find next occurence of \fIwhole\fR
X	s/whole/while/	# Replace \fIwhole\fR by \fIwhile\fR
X	g/Buf/s//BUF/g	# Replace \fIBuf\fR by \fIBUF\fR everywhere
X	w	# Write the file back
X	q	# Exit the editor
X.fi
X\fIEd\fR is provided for its sentimental value.
XIf you want a line-oriented editor, try \fIex\fR.
XIf you want a good editor, use \fIelle\fR, \fIelvis\fR, or \fImined\fR.
X
X
X
/
echo x - eject
sed '/^X/s///' > eject << '/'
X.CD "eject \(en eject a diskette from a drive [MACINTOSH]"
X.SX "eject [\fIdrive\fR]"
X.FL "\fR(none)"
X.EX "eject" "Eject the diskette in drive 0"
X.EX "eject 2" "Eject the diskette in drive 2"
X.PP
X.I Eject
Xwill eject the diskette from the specified drive (or drive 0 if no
Xdrive is specified). 
X
X
X
/
echo x - elle
sed '/^X/s///' > elle << '/'
X.CD "elle \(en ELLE Looks Like Emacs"
X.SX "elle \fIfile\fR [\fIfile2\fR]"
X.FL "\fR(none)"
X.EY "elle file.c" "Start the editor"
X.PP
X\fIElle\fR is a screen-oriented editor that is patterned after Emacs.
XIt can edit multiple files, regardless of their length, 
Xcan support 1 or 2 windows, and has many other powerful features.
XAn \fIelle\fR manual is given in Chap. 9.
X
X
X
/
echo x - elvis
sed '/^X/s///' > elvis << '/'
X.CD "elvis \(en clone of the Berkeley vi editor"
X.SX "elvis \fR[\fB\(enRerv\fR] [\fB\(ent \fItag\fR] \fR[\fIfile\fR] ..."
X.FL "\(enR" "Set the read-only option"
X.FL "\(ene" "Start up emulating \fIex\fR"
X.FL "\(enr" "Tell the user to use \fIvirecover\fR instead
X.FL "\(ent" "Start editing at the given tag"
X.FL "\(env" "Start up emulating \fIvi\fR"
X.EX "elvis" "Call the editor"
X.EX "elvis prog.c" "edit \fIprog.c\fR"
X.PP
X\fIElvis\fR is a screen editor patterned very closely after the Berkeley
X\fIvi\fR editor.
XIt has many commands, described in Chap. 9.
XSee also \fIctags\fR, \fIex\fR, \fIref\fR, and \fIvirecover\fR.
X
X
X
/
echo x - ex
sed '/^X/s///' > ex << '/'
X.CD "ex \(en Berkeley line editor"
X.SX "ex \fR[\fB\(enRerv\fR] [\fB\(ent \fItag\fR] \fR[\fIfile\fR] ..."
X.FL "\(enR" "Set the readonly option"
X.FL "\(ene" "Start up emulating \fIex\fR"
X.FL "\(enr" "Tell the user to use \fIvirecover\fR instead
X.FL "\(ent" "Tagstart editing at the given tag"
X.FL "\(env" "Start up emulating \fIvi\fR"
X.EX "ex" "Call the editor"
X.EX "ex prog.c" "edit \fIprog.c\fR"
X.PP
X\fIEx\fR is a line editor patterned very closely after the Berkeley
Xprogram of the same name.
XIt is essentially a much improved version of \fIed\fR.
XActually, \fIex\fR is really just a link to \fIelvis\fR, which is a
X\fIvi\fR clone.
XIts commands are described in Chap. 9.
XSee also \fIctags\fR, \fIelvis\fR, \fIref\fR, and \fIvirecover\fR.
X
X
X
/
echo x - expand
sed '/^X/s///' > expand << '/'
X.CD "expand \(en convert tabs to spaces" 
X.SX "expand\fR [\fB\(en\fIt1,t2, ...\fR]\fR [\fIfile\fR]
X.FL "\(en\fIt\fR" "Tab stop positions"
X.EY "expand \(en16,32,48,64" "Expand \fIstdin\fR with tabs every 16 columns"
X.PP
X\fIExpand\fR replaces tabs in the named files with the equivalent numbers
Xof spaces.  If no files are listed, \fIstdin\fR is given.  If only one
Xtab is given, the rest are multiples of it.  The default is a tab every 8
Xspaces.
X
X
X
/
echo x - expr
sed '/^X/s///' > expr << '/'
X.CD "expr \(en evaluate experession"
X.SX "expr \fIarg ..."
X.FL "\fR(none)"
X.EY "x=\`expr \$x + 1\`" "Add 1 to shell variable x"
X.PP
X\fIExpr\fR computes the value of its argument and writes the result on
Xstandard output.  The valid operators, in order of increasing precedence,
Xare listed below.  Operators grouped by {...} have the same precedence.
XThe operators are: |, &, {<, <=, ==, !=, >=, >}, {+, \(en}, *, /, %, and :.
XParentheses are permitted.
X
X
X
/
echo x - factor
sed '/^X/s///' > factor << '/'
X.CD "factor \(en factor an integer less than 2**31"
X.SX "factor \fInumber"
X.FL "\fR(none)"
X.EY "factor 450180" "Print the prime factors of 450180"
X.PP
X\fIFactor\fR prints the prime factors of its argument in increasing order.
XEach factor is printed as many times as it appears in the number.
X
X
X
/
echo x - fdisk
sed '/^X/s///' > fdisk << '/'
X.CD "fdisk \(en partition a hard disk [IBM]"
X.SX "fdisk\fR [\fB\(enh\fIm\fR]\fR [\fB\(ens\fIn\fR]\fR [\fIfile\fR]"
X.FL "\fB\(enh" "Number of disk heads is \fIm\fR"
X.FL "\fB\(ens" "Number of sectors per track is \fIn\fR"
X.EX "fdisk /dev/hd0" "Examine disk partitions"
X.EX "fdisk \(enh9 /dev/hd0" "Examine disk with 9 heads"
X.PP
XWhen \fIfdisk\fR starts up, it reads in the partition table and displays 
Xit.
XIt then presents a menu to allow the user to modify partitions, store the
Xpartition table on a file, or load it from a file.  Partitions can be marked
Xas 
X.MX ,
XDOS or other, as well as active or not.
XUsing \fIfdisk\fR is self-explanatory.  
XHowever, be aware that
Xrepartitioning a disk will cause information on it to be lost.  
XRebooting the system \fIimmediately\fR 
Xis mandatory after changing partition sizes and parameters.
X.MX , 
X\&\s-2XENIX\s0, \s-2PC-IX\s0, and \s-2MS-DOS\s0 all have different 
Xpartition numbering schemes.
XThus when using multiple systems on the same disk, be careful.
X.PP
XFurthermore,
X.MX
Xexpects all partitions to begin on an even sector.  The \fIm\fR command, which
Xmarks a partition as 
X.MX ,
Xautomatically rounds odd partitions upward.
XThe reason that odd partition sizes do not cause a problem with
X\s-2MS-DOS\s0 is that \s-2MS-DOS\s0 allocates disk space in units of
X512-byte sectors, whereas 
X.MX
Xuses 1K blocks.
XThus an odd number of sectors is no problem for 
X\s-2MS-DOS\s0 but it is a problem for
X.MX .
XThat is why a command has been provided to round 
X.MX
Xpartitions to an even starting address and an even size.
XIf your disk has partitions for both \s-2MS-DOS\s0 and
X.MX ,
Xonly the
X.MX
Xones should be rounded off.
X\fIFdisk\fR has a variety of other features that can be seen by typing \fIh\fR.
X
X
X
/
echo x - fgrep
sed '/^X/s///' > fgrep << '/'
X.CD "fgrep \(en fast grep"
X.SX "fgrep\fR [\fB\(encfhlnsv\fR]\fR [\fIstring_file\fR] [\fIstring\fR] [\fIfile\fR] ..."
X.FL "\(enc" "Count matching lines and only print count, not the lines"
X.FL "\(enf" "Take strings from file named in following argument"
X.FL "\(enh" "Omit file headers from printout"
X.FL "\(enl" "List file names once only"
X.FL "\(enn" "Each line is preceded by its line number"
X.FL "\(ens" "Status only, no output"
X.FL "\(env" "Print only lines not matching"
X.EX "fgrep % prog.c" "Print lines containing % sign"
X.EX "fgrep \(enf pattern prog.c" "Take strings from \fIpattern\fR"
X.PP
X\fIFgrep\fR is essentially the same as grep, except that it only searches
Xfor lines containing literal strings (no wildcard characters), and it is much
Xfaster.
X
X
X
/
echo x - file
sed '/^X/s///' > file << '/'
X.CD "file \(en make a guess as to a file's type based on contents"
X.SX "file \fIname ..."
X.FL "\fR(none)"
X.EY "file a.out ar.h" "Guess at types"
X.PP
X\fIFile\fR reads the first block of a file and tries to make an 
Xintelligent guess about what kind of file it is.  
XIt understands about archives, C
Xsource programs, executable binaries, shell scripts, and English text.
X
X
X
/
echo x - find
sed '/^X/s///' > find << '/'
X.CD "find \(en find files meeting a given condition"
X.SX "find \fIdirectory \fIexpression"
X.FL "\fR(none)"
X.EX "find /  \(enname a.out \(enprint~~~~~~~~~~~~~~~~" "Print all \fIa.out\fR paths"
X.EX "find /usr/ast ! \(ennewer f \(enok rm {} \\\\\^;~~~~~~~~~~" "Ask before removing"
X.EX "find /usr \(ensize +20 \(enexec mv {} /big \\\\\^;~~~~~" "move files > 20 blks"
X.EX "find / \( \(enname a.out \(eno \(enname \(fm*.o\(fm \) \(enexec rm {}\\\\\^;" "2 conds"
X.PP
X\fIFind\fR descends the file tree starting at the given directory checking
Xeach file in that directory and its subdirectories against a predicate.
XIf the predicate is true, an action is taken.  The predicates may be
Xconnected by \fB\(ena\fR (Boolean and), \fB\(eno\fR (Boolean or) and !
X(Boolean negation).
XEach predicate is true under the conditions specified below.  The integer 
X\fIn\fR may also be +\fIn\fR to mean any value greater than \fIn\fR, 
X\fI\(enn\fR to mean any value less than
X\fIn\fR, or just \fIn\fR for exactly \fIn\fR.
X.HS
X.ta 0.25i 1.0i
X.nf
X	\(enname s	true if current filename is \fIs\fR (include shell wild cards)
X	\(ensize n	true if file size is \fIn\fR blocks
X	\(eninum n	true if the current file's i-node number is \fIn\fR
X	\(enmtime n	true if modification time relative to today (in days) is \fIn\fR
X	\(enlinks n	true if the number of links to the file is \fIn\fR
X	\(ennewer f	true if the file is newer than \fIf\fR
X	\(enperm n	true if the file's permission bits = \fIn\fR (\fIn\fR is in octal)
X	\(enuser u	true if the uid = \fIu\fR (a numerical value, not a login name)
X	\(engroup g	true if the gid = \fIg\fR (a numerical value, not a group name)
X	\(entype x	where \fIx\fR is \fBbcdfug\fR (block, char, dir, regular file, setuid, setgid)
X	\(enxdev	do not cross devices to search mounted file systems
X.fi
X.HS
XFollowing the expression can be one of the following, telling what to do
Xwhen a file is found:
X.HS
X.nf
X	\(enprint	print the file name on standard output
X	\(enexec	execute a \s-2MINIX\s0 command, {} stands for the file name
X	\(enok	prompts before executing the command
X.fi
X.HS
X
X
X
/
echo x - fix
sed '/^X/s///' > fix << '/'
X.CD "fix \(en generate new file from old one and diff listing"
X.SX "fix \fIoldfile \fIdifflist \fI>newfile"
X.FL "\fR(none)"
X.EY "fix old difflist >new" "Generate new from old and diffs"
X.PP
X\fIFix\fR accepts a diff listing produced by diff and reconstructs the
Xnew file.  It is common for people to take a file, modify it, and then
Xsend the diff listing between the old and new files to other people.
XUsing \fIfix\fR, the old file, and the diff listing, it is possible to creat
Xthe new file.  For example:
X.HS
X  diff oldfile newfile >difflist
X  fix oldfile difflist >new2
X.HS
Xwill generate a file \fInew2\fR that is identical to \fInewfile\fR.
XA more sophisticated alternative to \fIfix\fR is \fIpatch\fR,
Xas \fIfix\fR only handles old-style diffs.
X
X
X
X.SP 1
/
echo x - fold
sed '/^X/s///' > fold << '/'
X.CD "fold \(en fold long lines"
X.SX "fold\fR [\fB\(en\fIn\fR]\fR [\fIfile\fR] ..."
X.FL "\(en\fIn\fR" "How long should the output lines be"
X.EX "fold \(en60" "Fold \fIstdin\fR to 60 characters"
X.EX "fold file" "Fold \fIfile\fP to 80 characters"
X.PP
X\fIFold\fR takes copies its input from the named file (or \fIstdin\fR,
Xif none is specified) to standard output.
XHowever, lines longer than the given maximum (default 80) are broken
Xinto multiple lines of the maximum length by inserting new line characters.
X
X
X
/
echo x - format
sed '/^X/s///' > format << '/'
X.CD "format - format a diskette [IBM]"
X.SX "format [\fB\(ena\fR][\fB\(enq\fR][\fISpecial\fR [\fIkbsize\fR]] [\fB\(env [\fBdosvollabel\fR]\fR]"
X.FL "\(ena" " Sort interactive list alphabetically not by size"
X.FL "\(enq" "Quiet mode: skips asking if you are sure"
X.FL "\(env" "Volume label added along with DOS structures"
X.EX "format" "Have \fIformat\fR display a menu"
X.EX "format /dev/at0" "format disk in /dev/at0"
X.EX "format /dev/at0 360" "Format disk with 360 blocks"
X.EX "format /dev/dosA" "Format for DOS"
X.EX "format /dev/fd1 -v DOS_DISK" "Format and label DOS disk"
X.PP
X\fIFormat\fR allows the superuser to format diskettes.
XIt can format all seven non-automatic
Xdisk/media combinations that PC-Minix supports.  It will also try to
Xformat automatics, minor devices 0 through 3, if a device size is nozero.
X\fIFormat\fR will optionally add the structures \s-2MS-DOS\s0 needs if either the device
Xname is an \s-2MS-DOS\s0 device, like \fI/dev/dosA\fR, or if the 
X\\fB\(env\fR flag is used.
XIf no special file is specified in the command line \fIformat\fR will
Xdisplay a menu of choices.
XIt then allows automatic devices to be formatted even if
Xthey were made with a size of zero.
X\fIarning:\fR  Some disk drives are media sensitive, in which case
Xthe diskette must match the drive (e.g., no 360K diskettes in 1.2M drives).
X
X
X
X.CD "format \(en format a diskette [ATARI]"
X.SX "format \fIdevice\fR"
X.EY "format /dev/dd0" "Format a double sided diskette"
X.PP
X.I Format 
Xformats and verifies a diskette on the given device.
XDepending on the device specified the disk is formatted single or
Xdouble sided. Formatted disks always contain 80 tracks and 9 sectors
Xper track. The diskettess can be used under both 
X.MX
Xand TOS.
X
X
X
/
echo x - fortune
sed '/^X/s///' > fortune << '/'
X.CD "fortune \(en print a fortune"
X.SX "fortune"
X.FL "\fR(none)"
X.EY "fortune" "Print a fortune"
X.PP
X\fIFortune\fR prints a fortune at random from the fortunes file,  
X\fI/usr/lib/fortune.dat\fR.  This file consists of pieces
Xof text separated by a line containing only %%.
X
X
X
/
echo x - from
sed '/^X/s///' > from << '/'
X.CD "from \(en input half of a connection [IBM]"
X.SX "from \fIport"
X.FL "\fR(none)"
X.EX "from port | sort >x" "Fetch and sort an incoming file"
X.EX "from abc | sh" "Primitive sherver"
X.PP
X\fITo\fR and \fIfrom\fR are used together to provide connection-oriented service over an Ethernet.
XOn the sending machine, the last member of a pipeline is \fIto port\fR.  
XOn the
Xreceiving machine, the first member of a pipe line is \fIfrom port\fR.  
XThe net
Xresult is that the output of the sending pipeline goes into the input of the
Xreceiving pipeline, making pipelines work across the network. 
XSee also \fIto\fR.
X
X
X
/
echo x - fsck
sed '/^X/s///' > fsck << '/'
X.CD "fsck \(en perform file system consistency check"
X.SX "fsck\fR [\fB\(enaclmrs\fR]\fR [\fIdevice\fR] ..."
X.FL "\(ena" "Automatically repair inconsistencies"
X.FL "\(enc" "Check and list only the specified i-nodes
X.FL "\(enl" "List the files and directories in the filesytem
X.FL "\(enr" "Prompt user for repairs if inconsistencies are found
X.FL "\(ens" "List the superblock of the file system"
X.EX "fsck /dev/hd4" "Check file system on \fI/dev/hd4\fR"
X.EX "fsck \(ena /dev/at0" "Automatically fix errors on \fI/dev/at0\fR"
X.EX "fsck \(enl /dev/fd0" "List the contents of \fI/dev/fd0\fR"
X.EX "fsck \(enc 2 3 /dev/hd3" "Check and list \fI/dev/hd3\fR i-nodes 2 & 3"
X.PP
X\fIFsck\fR performs consistency checks on the file systems which reside 
Xon the specified devices.  
XWhen either the \fB\(ena\fR or \fB\(enr\fR flags are given, the file system
Xwill be repaired if errors are found.
XBefore running \fIfsck\fR on a mounted file system, it must first be unmounted.
XTrying to repair a mounted file system is dangerous and should not be 
Xattempted.
X.PP
XTo repair the root file system (which cannot be unmounted), first 
Xhit the F1 key to find the pid of the \fI/etc/update\fR process.
XThen become superuser and send \fIupdate\fR signal 9 using \fIkill\fR.
XAfter doing this, hit F1 again to verify that \fI/etc/update\fR has vanished.
XNext run \fIfsck\fR and then immediately reboot
Xthe computer, WITHOUT doing a \fIsync\fR.
X.PP
XThis is the only situation in which you can (in fact, must) reboot without
Xdoing a \fIsync\fR.
XRebooting is needed because \fIfsck\fR repairs the disk but does not affect
Xthe (possibly incorrect) information held in memory.
XDoing a \fIsync\fR would force the (possibly incorrect) information from
Xmemory back onto the disk, thus ruining the work done by \fIfsck\fR.
XBy rebooting immediately, memory is reloaded with correct information from the
Xdisk.
XIt is necessary to kill \fI/etc/update\fR before repairing the root file system
Xto prevent it from issuing \fIsync\fR calls while \fIfsck\fR is running.
XBecause \fI/etc/update\fR only affects mounted file systems (and the root),
Xwhen repairing a nonroot file system, unmounting it is sufficient; it is not
Xnecessary to kill \fI/etc/update\fR.
X
X
X
X.SP 1
/
echo x - gather
sed '/^X/s///' > gather << '/'
X.CD "gather \(en gather up the files in a directory for transmission"
X.SX "gather\fR [\fB\(ens\fR] \fIsource_dir [\fB\(end\fR] dest_dir\fR [\fB\(enb\fR] \fIbytes\fR [\fB\(enf\fR] \fIfile\fR 
X.FL "\(enb" "Desired number of bytes per output file"
X.FL "\(end" "Destination directory"
X.FL "\(enf" "Base name of output files"
X.FL "\(ens" "Source directory"
X.EX "gather" "Collect files in current dir into 60K archives"
X.EX "gather \(end dir" "Put the archives in \fIdir\fR
X.EX "gather \(enb 90000" "Try to produce 90K archives"
X.EX "gather \(ens .. \(end targ \(enb 5000" "Try to produce 5K archives"
X.PP
XIt is often useful to collect all the files in a directory into one or
Xmore archives for transmission by mail.  This program collects all the
Xfiles in the source directory (default: current directory) and puts
Xthem into a shar archive.  The shar archive is then compressed and
Xuuencoded.  An attempt is made to have the final \fI.uue\fR file be
Xabout the given size (default: 60K), but since \fIgather\fR cannot really
Xpredict how much \fIshar\fR will add to the file, how much \fIcompress\fR
Xwill reduce the file, and how much \fIuue\fR will add again, the sizes
Xcan fluctuate.  If the \fB\(enf \fIfile\fR flag is given, the archives will
Xbe given the names \fIfile_00.uue\fR, \fIfile_01.uue\fR etc.  If \fB\(enf\fR
Xis not given, the name of the source directory is used as the base name.
XSince 7 characters of suffix are appended, the base name should not exceed
X7 characters.
X
X
X
X.SP -0.5
/
echo x - getlf
sed '/^X/s///' > getlf << '/'
X.CD "getlf \(en wait until a line has been typed"
X.SX "getlf\fR [\fIargument\fR]"
X.FL "\fR(none)"
X.EY "getlf" "Wait for a line"
X.PP
XIn shell scripts it is sometimes necessary to pause to give the user a
Xchance to perform some action, such as inserting a diskette.
XThis command prints its argument, if any,
Xand then waits until a carriage return has been typed, at which
Xtime it terminates.
XIt is used in
X.I /etc/rc .
X.SP -0.5
X
X
/
echo x - getty
sed '/^X/s///' > getty << '/'
X.CD "getty \(en get terminal line parameters for login"
X.SX "getty\fI line \fR[\fB\(enc \fIfile\fR] [\fB\(enh\fR] [\fB\(enk\fR] [\fB\(ent\fR] [\fIspeed\fR]
X.FL "\(enc" "Use \fIfname\fR as \fIgettydefs\fR file"
X.FL "\(enh" "Do not hang up the phone after reset"
X.FL "\(enk" "Do not use speed selection"
X.FL "\(ent" "Do not time out at \fILogin:\fR prompt"
X.EY "/etc/getty /dev/tty1 1200" "Connect to \fItty1 at 1200 baud\fR"
X.PP
XThe \fIgetty\fR program allows a terminal port to be used for both dialin and
Xdialout. It also detects the speed used, and, if enabled, it sets the
Xvarious line discipline parameters.
XWhen \fIgetty\fR starts up, it searches through the \fI/etc/gettydefs\fR
Xfile until it finds an entry that matches the label as specified in the
X\fIspeed\fR parameter. 
XIf no paramater is present, the first entry is used. \fIGetty\fR
Xthen sets up the terminal line according to the initial parameters
Xfield found in \fIgettydefs\fR.
X
X
X
X.SP 1
/
echo x - grep
sed '/^X/s///' > grep << '/'
X.CD "grep \(en search a file for lines containing a given pattern"
X.SX "grep\fR [\fB\(enelnsv\fR] \fIpattern\fR [\fIfile\fR] ..."
X.FL "\(ene" "\fB\(ene \fIpattern\fR is the same as \fIpattern\fP
X.FL "\(enl" "Do not print line numbers"
X.FL "\(enn" "Print line numbers"
X.FL "\(ens" "Status only, no printed output"
X.FL "\(env" "Select lines that do not match"
X.EX "grep mouse file " "Find lines in \fIfile\fP containing \fImouse\fP"
X.EX "grep [0\(en9] file" "Print lines containing a digit"
X.PP
X.I Grep
Xsearches one or more files (by default, \fIstdin\fR) and selects out
Xall the lines that match the pattern.
XAll the regular expressions accepted by
X.I ed
Xand
X.I mined 
Xare allowed.
XIn addition, + can be used instead of \(** to mean 1 or more occurrences,
X? can be used to mean 0 or 1 occurrences, and
X| can be used between two regular expressions to mean either
Xone of them.
XParentheses can be used for grouping.
XIf a match is found, exit status 0 is returned.
XIf no match is found, exit status 1 is returned.
XIf an error is detected, exit status 2 is returned.
X
X
X
/
echo x - gres
sed '/^X/s///' > gres << '/'
X.CD "gres \(en grep and substitute"
X.SX "gres\fR [\fB\(eng\fR] \fIpattern \fIstring\fR [\fIfile\fR] ..."
X.FL "\(eng" "Only change the first occurrence per line"
X.EX "gres bug insect" "Replace \fIbug\fP with \fIinsect\fP"
X.EX "gres \*(SQ^[A\(enZ]+$\*(SQ CAPS" "Replace capital-only lines with \fICAPS\fP"
X.PP
X.I Gres
Xis a poor man's
X.I sed .
XIt looks for the same patterns as
X.I grep ,
Xand replaces each one by the given string.
X
X
X
X.SP 1.5
/
echo x - hdclose
sed '/^X/s///' > hdclose << '/'
X.CD "hdclose \(en close hard disk partition [MACINTOSH]"
X.SX "hdclose \fIdevice\fR"
X.FL "\fR(none)"
X.EX "hdclose /dev/hd3" "Disconnect \fIhd3\fR from its current Macintosh file"
X.PP
X.I Hdclose
Xwill disconnect the current Macintosh file from the given hard disk
Xpartition.  See also \fIhdopen\fR.  You \fBmust\fR unmount the file system
X\fBbefore\fR you close it.
X
X
X
X.SP 1.5
/
echo x - hdopen
sed '/^X/s///' > hdopen << '/'
X.CD "hdopen \(en set correspondence of a HD partition [MACINTOSH]"
X.SX "hdopen \fIvol:dir:file\fR \fIdevice\fR"
X.FL "\fR(none)"
X.EX "hdopen vol:dir:file /dev/hd3" "Set \fIhd3\fR to Macintosh file \fIfile\fR"
X.PP
X.I Hdopen
Xwill set up a correspondence between the given Macintosh file and
Xa
X.MX
Xhard disk partition.  On the Macintosh,
X.MX
Xhard disk partitions are nothing more than a standard Macintosh file.
XThis program will set the given hard disk partition to the given file.
XIf a file is already associated with that partition, you must first use
X\fIhdclose\fR.
X
X
X
/
echo x - head
sed '/^X/s///' > head << '/'
X.CD "head \(en print the first few lines of a file"
X.SX "head\fR [\fB\(en\fIn\fR]\fR [\fIfile\fR] ..."
X.FL "\(en\fIn\fR" "How many lines to print"
X.EX "head \(en6" "Print first 6 lines of \fIstdin\fR"
X.EX "head \(en1 file1 file2" "Print first line of two files"
X.PP
XThe first few lines of one or more files are printed.
XThe default count is 10 lines.
XThe default file is \fIstdin\fR.
X
X
X
X.SP 1.5
/
echo x - ic
sed '/^X/s///' > ic << '/'
X.CD "ic \(en integer calculator"
X.SX "ic\fR [\fIexpression\fR]"
X.FL "\fR(none)"
X.EX "ic~~~~" "Start the calculator"
X.EX "ic 250 300+" "Start calculator with 550 on the stack"
X.PP
X\fIIc\fR is a reverse Polish notation calculator that works on 32-bit integers.
XIt starts out by computing the expression given as an argument, if any, and
Xthen expects keyboard input.  As an example, to compute \*(OQ23+5\*(CQ one 
Xfirst converts this to reverse Polish, \*(OQ23 5+\*(CQ. 
XAfter the calculator starts, type \*(OQ23\*(CQ followed by a carriage return.
XThen type \*(OQ5\*(CQ and another carriage return.
XFinally type \*(OQ+\*(CQ to see the result, 28 displayed on the stack.
XOther operations work the same way.  The calculator can use other radices for
Xinput and output, and has registers that can be stored and loaded.  The \fIh\fR
Xcommand gives the help menu.  See also Chap. 9.
X
X
X
X.SP 0.4
/
echo x - id
sed '/^X/s///' > id << '/'
X.CD "id \(en print the uid and gid"
X.SX "id"
X.FL "\fR(none)"
X.EY "id" "Print the uid and gid"
X.PP
X\fIId\fR prints the current uid and gid, both numerically and symbolically.
XIf the effective uid and gid are different from the real ones, all of them
Xare printed.
X
X
X
X.SP 0.4
/
echo x - ifdef
sed '/^X/s///' > ifdef << '/'
X.CD "ifdef \(en remove #ifdefs from a file"
X.SX "ifdef \fR[\fB\(ent\fR] [\fB\(end\fIsymbol\fR] [\fB\(enD\fIsymbol\fR] [\fB\(enU\fIsymbol\fR] [\fB\(enI\fIsymbol\fR] [file]"
X.FL "\(enD" "Define symbol permanently"
X.FL "\(enI" "Ignore symbol"
X.FL "\(enU" "Undefine symbol permanently"
X.FL "\(end" "Define symbol. It may be #undef'ed later"
X.FL "\(ent" "Produce a table of the symbols on \fIstdout\fR"
X.EX "ifdef \(enDUNIX file.c >newfile.c" "Define \fIUNIX\fR"
X.EX "ifdef \(enD_MINIX \(enUDOS <x.c >y.c "Define \fI_MINIX\fR, undefine \fIDOS\fR"
X.PP
X\fIIfdef\fR
Xallows conditional code [ #ifdef ... #endif ]
Xto be selectively removed from C files, but at the same time leaving
Xall other C preprocessor commands intact such as #define, #include etc.
XInput to
X.I ifdef
Xis either the file named as the last argument, or \fIstdin\fR if no file
Xis named.
XOutput goes to \fIstdout\fR.
X.PP
XSymbols may be defined with the \fB\(end\fR or \fB\(enD\fR flags just like
X\fIcpp\fR, except that the latter option ignores subsequent \fI#undefs\fR.
XIt is not permitted to give values to symbols.
XSimilarly, \fB\(enU\fR undefines a symbol and ignores subsequent 
X\fI#defines\fRs.
XSymbols defined with \fB\(enI\fR are ignored; any \fI#ifdef\fR using an
Xignored symbol will be left intact.
X
X
X
/
echo x - indent
sed '/^X/s///' > indent << '/'
X.CD "indent \(en reformat the layout of a program"
X.SX "indent \fIin_file\fR [\fIout_file\fR] [\fIoptions\fR]
X.FL "\fR(many)"
X.EX "indent \(enbr \(enc25 prog.c " "Indent \fIprog.c\fR
X.EX "indent \(ennpcs prog.c newprog.c" "Put output on \fInewprog.c"
X.PP
X\fIIndent\fR reformats a C program according to a set of options provided.
XMost of the common choices are available.
XThe output file replaces the input file, unless an explicit output file
Xis specified (but a backup is made of the original with suffix \fI.BAK\fR).
XThe options are given in Chap. 9.
X
X
X
/
echo x - inodes
sed '/^X/s///' > inodes << '/'
X.CD "inodes \(en print i-node information"
X.SX "inodes"
X.FL "\fR(none)"
X.EX "inodes" "Print information about file names typed in"
X.EX "cd /dev; ls | inodes" "Print information about the special files"
X.PP
X\fIInodes\fR expects a list of file names on \fIstdin\fR, one file name
Xper line.
XFor each file named, the file type, mode, uid, gid, checksum, length,
Xand name is printed.
XThe checksum is the same as used by \fIcrc\fR.
XThis program provides a way to see the sizes of the block special
Xfiles in \fI/dev\fR, as shown in the second example above.
X
X
X
/
echo x - kermit
sed '/^X/s///' > kermit << '/'
X.CD "kermit \(en transfer a file using the kermit protocol"
X.SX "kermit"
X.FL "\fR(many)"
X.EY "kermit" "Start kermit"
X.PP
X\fIKermit\fR is a file transfer program, remote connection program, and
Xmuch more.
XEven summarizing it here would be out of the question.
XFor a description of it, see the 379 page book 
X\fIKermit: A File Transfer Protocol\fR
Xby Frank da Cruz, Digital Press, 1987, ISBN 0-932376-88-6, and also
XChap. 9.
X
X
X
/
echo x - kill
sed '/^X/s///' > kill << '/'
X.CD "kill \(en send a signal to a process"
X.SX "kill\fR [\fB\(en\fIn\fR] \fIprocess"
X.FL "\(en\fIn\fR" "Signal number to send"
X.EX "kill 35" "Send signal 15 to process 35"
X.EX "kill \(en9 40" "Send signal 9 to process 40"
X.EX "kill \(en2 0" "Send signal 2 to whole process group"
X.PP
XA signal is sent to a given process.
XBy default signal 15 (SIGTERM) is sent.
XProcess 0 means all the processes in the sender's process group.
X
X
X
/
echo x - last
sed '/^X/s///' > last << '/'
X.CD "last \(en display recent on-line session records"
X.SX "last\fR [\fB\(enf \fIfile\fR]\fR [\fB\(enr\fR] [\fB\(en\fIn\fR] [\fIname\fR] [\fItty\fR] ..."
X.FL "\(enf" "Use \fIfile\fR instead of /usr/adm/wtmp"
X.FL "\(enr" "Search backwards only to last reboot"
X.FL "\(en\fIn\fP" "Print a maximum of \fIn\fR lines"
X.EX "last reboot" "When was the system last rebooted?"
X.EX "last ast" "When was the last login for ast?"
X.EX "last \(en10 tty0 tty1" "Display last 10 logins on tty0 or tty1"
X.PP
X.I Last
XSearches backward through the login administration file (default is
X\fI/usr/adm/wtmp\fR), printing information about previous logins and
Xreboots.
XDuring a long search, the SIGQUIT signal (CTRL-\\) causes \fIlast\fR to 
Xdisplay how far back it has gone; it then continues. 
X
X
X
/
echo x - leave
sed '/^X/s///' > leave << '/'
X.CD "leave \(en warn when it is time to go home"
X.SX "leave\fR [\fR [\fB+\fR] \fIhh\fR[\fB:\fR]\fImm\fR]"
X.FL "\fR(none)"
X.EX "leave 1500" "Issue a warning at 2:55 p.m."
X.EX "leave 10:00" "Issue a warning at 9:55 a.m."
X.EX "leave + 30" "Issue a warning in 25 minutes"
X.PP
X\fILeave\fR sets an alarm clock to a specified time and issues a warning
X5 minutes before, 1 minute before, and at the time to leave.
XIt then keeps issuing warnings every minute for 10 minutes, then quits.
XIf no time is provided, the program prompts for one.
X
X
X
X.SP -0.5
/
echo x - libpack
sed '/^X/s///' > libpack << '/'
X.CD "libpack \(en pack an ASCII assembly code file [IBM]"
X.SX "libpack"
X.FL "\fR(none)"
X.EY "libpack <x.s >y.s" "Pack \fIx.s\fP"
X.PP
XThis program is a filter that reads an ASCII assembly code file from standard
Xinput and writes the corresponding packed file on standard output.
XThe compiler libraries are archives of packed assembly code files.
X.SP -0.5
X
X
X
/
echo x - libupack
sed '/^X/s///' > libupack << '/'
X.CD "libupack \(en convert a packed assembly code file to ASCII [IBM]"
X.SX "libupack"
X.FL "\fR(none)"
X.EY "libupack <y.s >x.s" "Unpack \fIy.s\fP"
X.PP
XThis program is a filter that reads a packed assembly code file
Xfrom \fIstdin\fR and writes the corresponding ASCII file on standard output.
X
X
X
/
echo x - ln
sed '/^X/s///' > ln << '/'
X############ NEXT ENTRY HAS NOT BEEN CHECKED #############
X.CD "ln \(en create a link to a file"
X.SX "ln [\fB\(enf\fR] \fIfile\fR [\fIname\fR]
X.SX "ln [\fB\(enf\fR] \fIfile\fR ... \fIdir\fR
X.FL "\(enf" "Remove existing links"
X.EX "ln file newname" "Make \fInewname\fP a synonym for \fIfile\fP"
X.EX "ln /usr/games/chess" "Create a link called \fIchess\fP"
X.PP
XA directory entry is created for
X.I name .
XThe entry points to
X.I file .
XHenceforth,
X.I name
Xand
X.I file
Xcan be used interchangeably.
XIf
X.I name
Xis not supplied, the last component of
X.I file
Xis used as the link name.
XIf more than one
X.I file
Xis supplied or the
X.I name
Xrefers to an existing directory, links will be created in that directory.
XAn existing
X.I name
Xwill not be removed unless the \fB\(enf\fR flag is specified.
X
X
X
/
echo x - login
sed '/^X/s///' > login << '/'
X.CD "login \(en log into the computer"
X.SX "login\fR [\fIuser\fR]"
X.FL "\fR(none)"
X.EY "login ast" "Login as ast"
X.PP
X\fILogin\fR allows a logged in user to login as someone else without first
Xlogging out.
XIf a password is needed, \fIlogin\fR will prompt for it.
X
X
X
X.SP 1.6
/
echo x - look
sed '/^X/s///' > look << '/'
X.CD "look \(en look up words in dictionary"
X.SX "look\fR [\fB\(enf\fR] \fIprefix\fR[\fB/\fIsuffix\fR]\fR [\fIdictionary\fR]"
X.FL "\(enf" "Fold upper case letters to lower case"
X.EX "look ard" "Print words starting with \fIard\fR"
X.EX "look /bing" "Print words ending with \fIbing\fR"
X.EX "look \(enf f/ar" "Print words starting with \fIf\fR, ending with \fIar\fR"
X.PP
X\fILook\fR takes a prefix and/or suffix and searches \fI/usr/lib/dictionary\fR
Xor the specified dictionary for all words with that match.
XThe words are printed.
XThe \fB\(enf\fR flag causes all upper case letters to be treated as lower
Xcase.
X
X
X
X.SP 1.6
/
echo x - lorder
sed '/^X/s///' > lorder << '/'
X.CD "lorder \(en compute the order for library modules [IBM]"
X.SX "lorder \fIfile ..."
X.FL "\fR(none)"
X.EY "lorder proc1.s proc2.s" "Give \fIlorder\fR information"
X.PP
X\fILorder\fR accepts a series of packed or unpacked \fI.s\fR files and 
Xlibraries, and produces a partial ordering suitable for processing by 
X\fItsort\fR.
X
X
X
/
echo x - lpr
sed '/^X/s///' > lpr << '/'
X.CD "lpr \(en copy a file to the line printer"
X.SX "lpr\fR [\fIfile\fR] ..."
X.FL "\fR(none)"
X.EX "lpr file &" "Print \fIfile\fP on the line printer"
X.EX "pr file | lpr &" "Print \fIstdin\fR (\fIpr\fR's output)"
X.PP
XEach argument is interpreted as a file to be printed.
X.I Lpr
Xcopies each file to 
X.I /dev/lp ,
Xwithout spooling.
XIt inserts carriage returns and expands tabs.
XOnly one
X.I lpr
Xat a time may be running.
X
X
X
X.SP 1
/
echo x - ls
sed '/^X/s///' > ls << '/'
X.CD "ls \(en list the contents of a directory"
X.SX "ls\fR [\fB\(enabcdfgilmnopqrstux01ACFLRS\fR]\fR [\fIname\fR] ...
X.FL "\(enA" "All entries are listed, except \fI.\fR and \fI..\fR"
X.FL "\(enC" "Multicolumn listing with entries sorted down the page"
X.FL "\(enF" "Put /, | and * after directories, fifos and executables"
X.FL "\(enL" "Print information about symbolic links"
X.FL "\(enR" "Recursively list subdirectories"
X.FL "\(enS" "Squeeze column widths in multicolumn listings"
X.FL "\(ena" "List all entries including those starting with \fI.\fR"
X.FL "\(enb" "Print non-graphic characters in octal \\ddd notation"
X.FL "\(enc" "Use the status change time instead of modification time"
X.FL "\(end" "Do not list contents of directories"
X.FL "\(enf" "List argument as unsorted directory"
X.FL "\(eng" "As for \(enl, but print the group only"
X.FL "\(eni" "I-node number printed in first column"
X.FL "\(enl" "Long listing: mode, links, owner, group, size and time"
X.FL "\(enm" "Stream output format"
X.FL "\(enn" "As for \(enl, but print numeric uid and gid"
X.FL "\(eno" "As for \(enl, but print the owner only"
X.FL "\(enp" "Put / after directory names"
X.FL "\(enq" "Print ? in place of non-graphic characters"
X.FL "\(enr" "Reverse the sort order"
X.FL "\(ens" "Print the size in 512 byte units"
X.FL "\(ent" "Sort by time, latest first"
X.FL "\(enu" "Use last usage time instead of modification time"
X.FL "\(enx" "Multicolumn listing with entries sorted across the page"
X.FL "\(en0" "Reset all options"
X.FL "\(en1" "Print one entry per line (default)"
X.EX "ls \(enl~~" "List files in working directory"
X.EX "ls \(enlis" "List with i-nodes and sizes"
XFor each file argument, list it.
XFor each directory argument, list its contents, unless \fB\(end\fR is present.
XWhen no argument is present, the working directory is listed.
/
echo x - m4
sed '/^X/s///' > m4 << '/'
X.CD "m4 \(en macro processor"
X.SX "m4\fR [\fB\(enD \fIname\fR = \fIvalue\fR]\fR [\fB\(enU \fIname\fR] 
X.FL "\(enD" "Define a symbol"
X.FL "\(enU" "Undefine a symbol"
X.EY "m4 <m4test" "Run M4"
X.PP
X\fIM4\fR is a general-purpose macro processor.
XIt is described in Chap. 9.
XIt has been used to implement programming languages, such as RATFOR.
X
X
X
/
echo x - maccreate
sed '/^X/s///' > maccreate << '/'
X.CD "maccreate \(en create an empty macintosh file [MACINTOSH]"
X.SX "maccreate \fInblocks\fR \fIfile\fR"
X.FL "\fR(none)"
X.EX "maccreate 512 vol:dir:file" "Create a 512K file"
X.PP
X.I Maccreate
Xwill create a Macintosh file that can serve as a
X.MX
Xdisk partition. Also see the descriptions of hdopen and hdclose.
X
X
X
/
echo x - macfile
sed '/^X/s///' > macfile << '/'
X.CD "macfile \(en list, read and write Macintosh volumes [MACINTOSH]"
X.SX "macfile\fR [\fB\(enRadlrw\fR] [\fIfile\fR]"
X.FL "\(enR" "Recursively descend directories when listing them"
X.FL "\(ena" "Read or write ASCII file"
X.FL "\(end" "Directory list"
X.FL "\(enl" "Use long format for directory listing"
X.FL "\(enr" "Read a \s-2Macintosh\s0 file into \s-2MINIX\s0"
X.FL "\(enw" "Write a \s-2MINIX\s0" file to a \s-2Macintosh\s0 volume"
X.EX "macfile \(endl" "List mounted volumes"
X.EX "macfile \(endl vol:dir" "Long listing of the specified directory"
X.EX "macfile \(enr dir:file >adv" "Read file \fIfile\fR into adv"
X.EX "macfile \(enwa f" "Copy ASCII \fIstdin\fR to file \fIf\fR"
X.PP
X.I Macfile
Xuses the Macintosh ROM to transfer files between the
Xnormal Macintosh operating system and \s-2MINIX\s0.
XIt can list volumes, directories and read and write files.
XWhen the ASCII flag is specified, the
X.MX
Xnew line character is mapped onto
Xthe Macintosh line feed character.
X.I Macfile
Xmay be linked to
X.I macdir ,
X.I macread
Xand
X.I macwrite ,
Xin which case the \fB\(end\fR, \fB\(enr\fR, and \fB\(enw\fR flags are not
Xneeded.
X
X
X
X.SP -0.5
/
echo x - macread
sed '/^X/s///' > macread << '/'
X.CD "macread \(en read a Macintosh file [MACINTOSH]"
X.SX "macread\fR [\fB\(ena\fR] \fIfile\fR"
X.EX "macread dir:file >adv" "Copy file \fIfile\fR into adv"
X.EX "macread \(ena dir:file >adv" "Copy ascii file \fIfile\fR onto stdout"
X.FL "\(ena" "Read an ASCII file"
X.PP
X.I Macread
Xuses the Macintosh ROM to copy a
XMacintosh operating system file to standard output.
XWhen the ASCII flag is specified, the
XMacintosh line feed character
Xis mapped onto
Xthe
X.MX
Xnew line character.
X.I Macread
Xis a link to
X.I macfile.
X
X
X
X.SP -0.5
/
echo x - macros
sed '/^X/s///' > macros << '/'
X.de CD
X.ne 2
X.if t .ta 0.9i 1.15i 2.75i 3.25i 3.75i
X.if n .ta 11m 15m 40m
X.nr x 0 0
X.nr y 0 0
X.nr z 0 0
X.if n #\\$1
X.if n .br
X\\fBCommand:\&	\\$1\\fR
X.br
X..
X.de SX
X.if \\nx<=0 \\fBSyntax:\&	\\$1
X.if \\nx>0 \&	\\fB\\$1
X.nr x 1 1
X.br
X..
X.de FL
X.if \\ny<=0 \\fBFlags:\&	\\fB\\$1	\\fR\\$2
X.if \\ny>0 \& 	\\fB\\$1	\\fR\\$2
X.nr y 1 1
X.br
X..
X.de EX
X.br
X.nf
X.if \\nz<=0 \\fB\&Examples:	\\fR\\$1	\\fR# \\$2
X.if \\nz>0 \&	\\fR\\$1	\\fR# \\$2
X.nr z 1 1
X.br
X..
X.de EY
X.br
X.nf
X.if \\nz<=0 \\fB\&Example:	\\fR\\$1	\\fR# \\$2
X.if \\nz>0 \&	\\fR\\$1	\\fR# \\$2
X.nr z 1 1
X.br
X..
X
/
echo x - macwrite
sed '/^X/s///' > macwrite << '/'
X.CD "macwrite \(en write a Macintosh file [MACINTOSH]"
X.SX "macwrite\fR [\fB\(ena\fR] \fIfile\fR"
X.EX "macwrite dir:file <adv" "Copy file adv to mac file \fIfile\fR"
X.EX "macwrite \(ena dir:file" "Copy stdin to mac file \fIfile\fR"
X.FL "\(ena" "Write an ASCII file"
X.PP
X.I Macwrite
Xuses the Macintosh ROM to copy standard input into the
Xthe named Macintosh file.
XWhen the ASCII flag is specified, the
X.MX
Xnew line character
Xis mapped onto the
XMacintosh line feed character.
XThe file is created if it doesn't exist, or is overwritten if it does.
XOnce the file is written you can set the type and creator
Xflags with the \fIsettype\fR command.
X.I Macwrite
Xis a link to
X.I macfile.
X
X
X
X.SP 1
/
echo x - mail
sed '/^X/s///' > mail << '/'
X.CD "mail \(en send and receive electronic mail"
X.SX "mail\fR [\fB\(endpqrv\fR]\fR [\fB\(enf \fIfile\fR] [\fIuser\fR]
X.FL "\(end" "Force use of the shell variable \fIMAILER\fR"
X.FL "\(enf" "Use \fIfile\fR instead of \fI/usr/spool/mail/user\fR as mailbox"
X.FL "\(enp" "Print all mail and then exit"
X.FL "\(enq" "Quit program if SIGINT received"
X.FL "\(enr" "Reverse print order, i.e., print oldest first"
X.FL "\(env" "Verbose mode"
X.EX "mail ast" "Send a message to \fIast\fR"
X.EX "mail" "Read your mail"
X.PP
X\fIMail\fR is an extremely simple electronic mail program.  It can be used
Xto send or receive email on a single 
X.MX 
Xsystem, in which case it functions
Xas user agent and local delivery agent.  
XIf the flag \fIMAILER\fR is defined in \fImail.c\fR,
Xit can also call a trans\%port agent to handle remote mail as well.
XNo such agent is supplied with
X.MX .
X.PP
XWhen called by \fIuser\fR with no arguments, it examines the mailbox
X\fI/usr/spool/mail/user\fR, prints one message (depending on the \fB\(enr\fR
Xflag), and waits for one of the following commands:
X.SP 1
X.HS
X.nf
X.ta 0.25i 1.25i
X	<newline>	Go to the next message
X	\(en	Print the previous message
X	!command	Fork off a shell and execute \fIcommand\fR
X	CTRL-D	Update the mailbox and quit (same as q)
X	d	Delete the current message and go to the next one
X	q	Update the mailbox and quit (same as CTRL-D)
X	p	Print the current message again
X	s [\fIfile\fR]	Save message in the named file
X	x	Exit without updating the mailbox
X.HS
X.PP
X.SP 1
XTo send mail, the program is called with the name of the recipient as an
Xargument.  The mail is sent, along with a postmark line containing the date.
XFor local delivery, a file named after the recipient in the directory
X\fI/usr/spool/mail\fR must be writable.
X
X
X
/
echo x - make
sed '/^X/s///' > make << '/'
X.CD "make \(en a program for maintaining large programs"
X.SX "make\fR [\fB\(enf \fIfile\fR]\fR [\fB\(eniknpqrst\fR] [\fIoption\fR] ... [\fItarget\fR]
X.FL "\(enf" "Use \fIfile\fP as the makefile"
X.FL "\(eni" "Ignore status returned by commands"
X.FL "\(enk" "On error, skip to next command"
X.FL "\(enn" "Report, but do not execute"
X.FL "\(enp" "Print macros and targets"
X.FL "\(enq" "Question up-to-dateness of target"
X.FL "\(enr" "Rule inhibit; do not use default rules"
X.FL "\(ens" "Silent mode"
X.FL "\(ent" "Touch files instead of making them"
X.EX "make kernel" "Make \fIkernel\fP up to date"
X.EX "make \(enn \(enf mfile" "Tell what needs to be done"
X.PP
X.I Make
Xis a program that is normally used for developing large programs consisting of
Xmultiple files.
XIt keeps track of which object files depend on which source and header files.
XWhen called, it does the minimum amount of recompilation to bring the target
Xfile up to date.
X.PP
XThe file dependencies are expected in 
X.I makefile
Xor
X.I Makefile ,
Xunless another file is specified with \fB\(enf\fR.
X.I Make
Xhas some default rules built in, for example, it knows how to make 
X.I .s
Xfiles
Xfrom 
X.I .c
Xfiles.
XHere is a sample 
X.I makefile .
X.HS
X.nf
X.ta 0.25i 1.0i 3.0i
X	d=/user/ast		# \fId\fP is a macro
X	program:	head.s tail.s	# \fIprogram\fR depends on these
X		cc \(eno program head.s tail.s	# tells how to make \fIprogram\fP 
X		echo Program done.	# announce completion
X	head.s:	$d/def.h head.c	# \fIhead.s\fP depends on these
X.br
X	tail.s:	$d/var.h tail.c	# \fItail.s\fP depends on these
X.HS
X.fi
XA complete description of \fImake\fR would require too much space here.
XMany books on
X.UX
Xdiscuss
X.I make .
XStudy the numerous \fIMakefiles\fR in the 
X.MX
Xsource tree for examples.
X
X
X
/
echo x - man
sed '/^X/s///' > man << '/'
X.CD "man \(en display manual page"
X.SX "man\fR [\fIman_directory\fR]\fR [\fIdigit\fR] [\fIname\fR] ...
X.FL "\fR(none)"
X.EX "man" "Display main index"
X.EX "man cdiff" "Display man page for \fIcdiff\fR program"
X.EX "man 2 fork" "Display man page for \fIfork\fR system call"
X.EX "man 3" "Display the part 3 man pages"
X.PP
X\fIMan\fR is a program that displays manual pages.
XWhen called with a program name, it displays the manual page for that
Xprogram.
XWhen the digit \fIk\fR is given as an argument, the file \fI/usr/man/man\fRk
Xis used instead of the default, \fI/usr/man/man1\fR.
XWhen no name is given (or just a digit), the list of valid entries is
Xdisplayed.
XThe arrows can be used to select an entry, and <return> can be used to
Xdisplay the selected entry.
X\fIQ\fR or \fIq\fR leaves the program.
XA directory name can be given to override the use of \fI/usr/man\fR.
XSince all the manual pages are provided in printed format, to save diskette
Xspace, no manual pages are provided on diskette.
XThus \fIman\fR is primarily useful for your own documentation.
X
X
X
X.SP 1
/
echo x - man1.uue
sed '/^X/s///' > man1.uue << '/'
Xtable
X !"#$%&'()*+,-./0123456789:;<=>?
X@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_
Xbegin 644 man1.Z
XM'YV-9<:@>0,"#X@6(,*X2=,F#)LY"N:4(0/BQ LO6%[,><'Q! @?"1<V? B"z
XM!X^*+TXHP.)B"!$0(A0R=#@'!!<49=R H',G)YT\+>+4*3.'3IHW;FK^A%,&y
XMQ)FA<^:D<7/&:9@V3<.(>5.'3LB9#T6L=#$%"TR9(^=P,2,%Q):U2<B$H:,Ux
XMC,2U4KJ(96F$"4R\*-P@+9-BKXLB6<Z*I"D"YA2Z<KS20=/TS-4RAJ% 60DWw
XMR.*'>$&DJ1G&*52I5*UB=0$"!!7*(.I(E ,"3IHQ:TCK1.LP),7)35>.>=,&v
XM3M<RM.G(24-T)\&G1&NF\2HF3^TWJ*L*)6H4J5(T<T',&5B'#44Q69/VE#,1u
XM1'40*Y=.K<I%!8HG4?+41S$D"@@S;]"61W,*4;0??F[LU]]_ 8(@&&OP87$%t
XM96Z480=R.\$V7'''T<8&=D2Q()I7=N46X1S$-;5=44<EE6%X#GUXQXC.B5:<s
XM'&]<.&)-<M$EAEUEB(AB0DHQ5-D;S2$EXG01LE%&&'(D!>%K39%1AAEAE.=5r
XMCW5))!YYYKG7U%0VF9'$"[+)\0(;:8CQ F^@L>7"2G1B,=844(  @PLS*/""q
XM @$-5-!!(;4147L68:011RE]5&A))UFD$DLN*=:&33CI!,=R;GCEQF4@L%F4p
XM6S;@ ,.I>MUI5DQN7(K76V8(<5-.9PBVJ6QX=5%F$F:DX61H+@1K6%]_97I&o
XM8R(<\>&/;(B71QM;D804&WD,ZY<(L[KA!K)3!.AI'5@M-T:,U8Y%++:9OH$Ln
XM%.PQY<9OL/7JY*=8U?BD0*%.A9FYUV8+![).$(1B9//-VH9L3<WQ;+0[:>4Dm
XM" %:*8>UQ>8TL6/>BJ83>Q?*X67$R%&,;DYU(,O$:%[5\>Z5^E*D,+1O2.L&l
XMM2)G.P>W&9,IT1C=Z03RQ&,A9FEKV=;:&AW<N: N3.Q.Y=49R_;V<K32Z>0&k
XMN,C=UMO/F6W&4A(@>&8H%ILZ_5U3]#8EJE<H3!USPV(XF0+$9H!P+QIA#[$$j
XM@W(TY-4;8J@1$!UC@2UO&2N1"5Q"<CR%5:?Y%C4G%KPZ2-#A#H(ZFE-I7.B&i
XMB'"%H717H6V.,!F3%Q$&OFXWF[9H-6T:T$3MO3==378X-)2(I>W<L\9D:$U'h
XM@"L5F-!.>3 %O/ !3DZE>(.WN/RXPWO,>!DZW)GGGC>,A<048]&EIPLRU)#&g
XM^#7 D,98;IBQ4@)K"5$%7@E4L7*O%;J\<,SOQQ\$_4$0 XK8<!QGP8P-_8M5f
XMMNCW!.#0IG5CF0,<5O*\I8SI7<RS'I2PYSWP80%^L3("_8S@JYQ<)H%": +]e
XMFO &,I0';2?\8/RF0+\I1 \IF<,*"HM OR+@ 6E1Z@T*H 8XA\P-@C)48*;Hd
XMQX0WC*M92'1!K\:B&0K"ABMT,(Y7-C<PI%'$(7  #WJ,\D1JB4AE3HH*Q!QXc
XMA]$DC"EC2$.O)C*Y@)&Q*9,)3^A:%9IQ^6QFUD%/;"1"$1P&06]\\QO$ C>Xb
XM_Y2P)BM!01ZW. <=[$IIH3$>7$9'A] <;@XI8,U**I<'KH#@#@J1S'/*(!G8a
XMO&YM= N)W? 0D*XXK"F;>L,9Y'"500;G:PX:VU2*\B34U8E.?PH400R"D#!@z
XMT87%.11%$I61C73$4<[L"C3A "F43*HE+XG),\'%S6R!('@29$,8K+.XX73*y
XM)S5Y0]T4LDC!\<R1#]M"J4X%@U2QI"QG&6=QRB0%6/&JA*$QJ%;&8"4SY H$x
XM_G3!N0 CF H5)FB)$:<VR;F3I!&$GS"( 0R0M<T,)6Q_S?+1P]@S'#F0(9YUw
XM@PO2)/<&O'2M<&$3Z 2Q<(;.$0@$&X*#DY!V3H[*TVZKP]LA]P:@OLW%B_4<v
XM'$X/ESB=+ Y*CO-)Y.@PN<H)9JHE3%Q->NHYT)E)=%@L'8]&(]1UTM&*N(32u
XM98#((#;(:#XFQ2<,Z[6YTHB!20WAYB2%0T]!GJY&$@R('*U3&CA R2B]V6;Jt
XMDNH>P,J&.DV! <1H$P/GP<8&E:5#U?(:6!" 1T>+ Y!=W]#&U&!%)E2I9 ?#s
XM5YH]E>]\>TK?^EC2O@0F(0ST(P);U<E.V% F#!(# 4LCYELQ!'>XZ\RK[Z2Wr
XM7)=")(E)&,-STQG==K:P*=69J6_)L-VV%K<I[/D0]:@;D(A=%X1)*$-YB2M=q
XME,)MI>VUKF\=RI8$")>[YQ6/<O"ZP3",98IV2K#V0-#9&O@)4 )9)J&@)$V4p
XM*,J:C0()E+HIJ;%4*B:T,2>4!.)3H/US55!*:/S(4)PX1 8/N8*5$!;JJSK8o
XM(5<J-A,<L).VAX9.#B36$5PP%RP7U(PM@1G,15E2!!33QD-M&H,+>N<M%]P,n
XM)E(H0UO'T!2X=!$O5M;8KM@D!BD#ERV&:?)9GBR&A(29S&9VCY61E82D(,<Km
XM<!&#E4.#GJ9V^:Q[9HN8X0+G*=N4BE[KC!PRN=H[C!5'=8 #3/6J%(((4HO.l
XM.0,K*4,;IQ&D=_-YV(C1X-.N4M)R3K6K=0[;U'R)@9?+25+=@EI"BN22RRYDk
XMSQRF%*^8W34U:RA#'JZ[P80T>B+98\GW:#N^VZ)/?>QS7Q*%0%ZVZ,"_91AJj
XM&5BCZ-"TT:[GS#8K\>C*RU $*]!"SJY1V :\7)N%.DH;13[);3,%8=&"+@,>i
XMX"C:79U9"F9-@G/9(J(&P24-H1F>F,0#1SDRQYC3AH.[$] TR"U.WI0& 0I@h
XM"9Q+X=#+="!#6MF2 A3&8>)1J,-MUD"MA,#!7;\AR.)R4LBZ717(I-;1X28'g
XM0B'@6PK7SO*6FX*",+R<YJ>DD.6VN!N<^S24*.RDM2G.J59FQ>D7.H%2;AE+f
XM=R*M4^N>-HRG[D/EK(YP+$&P"Y:-A?@]+]C#!D%#K/,&./2,7$!%"O5RLG>*e
XMM'$R$*O09N4>H*8<-;6^9FW!K!WMV4[[W]<.@AGH"I<=SZ'';$'AP(&> "%<d
XMJ?"[LCSFI8!"[4Y]".R92U,T/H=(RRXJS1E#ZG^'E:B$0=,EGS;"I^YY/X>>c
XMQY?!"PK9,/$F/K&CQ0D0E*R#N5;?(4!KT!@QD1M+N+R #L5YDQQ<0(+N=U_Xb
XMTZ[#Q(6N3BX'ON5R/*?J*:).NN91)^A&3Z>;'F3$3?O&4[<"<K8B$<=+<;?'a
XME$P1-BC-!!&$9&'5Q"@>H6$U81+>Y&'A9!>8DA,@T 1#L$^G0B02 2U.0AOZz
XM9"JH8A@ %1,U\1:9,@==8((DDX+90@5P$3SX!@4LF"Z[,GJZ,F0()6A%5C,Gy
XMR"T#QDVM<U_[PA?]DBDE Q-!, 9<9G>Q<3\M8T!40R2S!$2?TBSL80;(P7=$x
XMP8,Y007(T@1A$&S(MV.PQGR/-&AF H-K 05<*!CKTA40TQ68AD.8@W'O42$_w
XMQ#C'@E%G41/94@<3*!AZI32#>&4DN(%QTQ0[5S4*MW/J@F@X%03$IH1:UF\6v
XMB(&:-4S*40<\(SUD4AI-I4AL$FS)Y@)@(P)MD"/;UBPT4'0PD (LD"UM P>%u
XM 0*38T,)DR*QM#@H4@= IHB/)"*C:'^F" +!%B79IA'8!P=X8&7%\RXX16;*t
XM>%RH<UT*IVDD\A]ED&U\4U^=$@;-Z!JP81>(V('BX7K>0AH@D#O+<4LK<37Is
XM1AM'-5W>(2)B (?>!2U3,1?2\W=XXUU6XA0Y@1QS03Q88#QLX@;'J(%8\R)>r
XM44J 6!2/A53X0HYEP(%F^#"VTRDXXD)QE!K L1*J]6M508])48KB8UOFPV"[q
XMM78>E !6-C@PB30_-!:O]CXQR3,PB2-CXP(W^4$Y20<PR24V*0<XZ3LP*4#7p
XMY9(4M$K9J$Z-DS!7(52&-VO?)2*T]C H4B]#4!LXLDM7H1L4,4S\9E(KH6M:o
XM0F"PAY%Y9R6>M3G?UBQDE1ZB826E<51W !Y6IX$7&3?6H4Y440>WIS9O\ 8Fn
XM,HR3$X 0)BC,1"1QM#X'2$V+<DT,^)@<EA(0V(>6:4Y%L1S<%"-Y91SL$393m
XM, 1) #8)V1QFP)/'<S@BB&)S\)@Y)BN9DB!LT04Y=E"_<IMMN"TP47:\=$^+l
XMDYHUX75A,!5X55%!4)JG"53@$9Q =#-! YN6B3D^@$5F@"Q7L!Q$!9J+LYRFk
XMB9KZ$D\Z 1?8>6A,1IUI<#[9HA,\8)W8J9W<F17@=G%( 9[-29R!MROGB6:0j
XMB 7=@A5&47NM64)Y]XW#)!ZZJ)S,"38"(5<\HVX.>3UBMCBHE =O&3M?R4N7i
XM$B.L=3;Y4B'%B11T@9RI,2W6@9\.^IQG)Z$*)TB<82:[I&5,46UML9K$D5<[h
XMUQHK<073\8^P$3_MZ4GJ= 8B8I]NH*(A2B"C&:-),*-'9Z,0LA(!(W=/A2%Yg
XMN6D8DEI%"CN^5$BT(1AT<*2PD4M@>2GL00>^Z"+TI&],(I%J"DE8<'AR,!2Bf
XM87/Q8J";(YI-H:*\\R[_01.&QT9NE)@*)H",.6%2H0>($YD7D8"4221IP*B7e
XM^4T?9A>3VF69HEQ:EC&\F*FQ1$^ 8T]>@3D?R$\1-8*82JDXN)MML8/\\A=(d
XM5E&$D689M:IXY%'(<@0^)5V@>E0RY5'HZ0)5!$R2F*DK439@UXUWHX=8TRGQc
XM 1LH8"5Q-!)S X_R%TOAU1R']1Z+$SQF@(7L 3DF.0<L4#PUT1/@)H' D08/b
XM!"YB1JU@X1NFI6_(I5@CT55U\U7 1%58L#ES69Z -G)M83J$-#G%>*R,2EA_a
XMU'*&=8 *!S@E:E6PL:A5>3PWT00R<$DU)6@&9R:<Y$DE)$I80 4$(;''2;$)z
XM\ZOSI!/Z5DLJ%22^A%,66U73!W&*J4P$2"3F46&2B6$+R+,4X8 =1BD1. =Ay
XM(F)KF8ART (?<J\>F 0IE*JP:1ZSF2TGHQ:W>;690@6[HH:WZ19"2H-P88.[x
XM<CC (BRQ.C)NP 3($@1;A5=[VI&<V!X?9R9%(7*DXY]$6#%NX(4P4040*S -w
XM9P:,=4[N.C@!PGP-LCA(DWQEJ%=MF ;((K@)HV5R151@8P(@\!(2M#I$9P,Tv
XML#<K  *BNP1+)E%%F!-+(P)/((=P> 9(4FEZE4.U8QUX2"*-\ZQTT(:&"+=!u
XM&+->FDL>:;<"FP1Y2[!I5K4&<H*%^+9+^S"MNFUB629Y DNM(YWIV8=)2X-8t
XMA&F+"+WE^&>Z2;UK*"*8]E>?(@=T=[S?N[=L.)W<V[Q=R!J'TUDU<3@R,&>!s
XMZR5CX(OCNB6)RS.+VXV/2X;+)[G_F;!(2P9B998LT00)9I$<B"$(^090FW?Zr
XMF#^FEA"4:'?J")A/,9CBP1"^LF$*-TD>O(10Y:U!.@<M( -0, 0MD 1M-P<Kq
XM( /H.KZTT3;;" )# !YPP!HY '4 BE*D,9H-$9"1%DM#%9TB$CP]U6_&HS(2p
XM$YN%%W;/TQ D)GB:6*>=Z!WTBEQDH&O907A6DL3D)I7UPJX#T7]8T*UYP!DPo
XM+,,T;,-<@,,R("+ZQL(3FHII/$AX=3!L8!14R:D]14P:-)IWP)U?MQ+#F"&;n
XM8Z_%X226A%.HF",)@0<L@ )B@ =?(!6AM!=#X!UT 3EU1Y#OHL;A)J:W>SSCm
XM 25 F :U,CG&UQOJA!XD46Q,T3?3 56* QNR(9C-,A95D&!%D0>6G%=?S(F_l
XM@\EJ,% QD)TKH0;DE+\!@DHN52/M]"$2,2JYS(TX%0.E6*S/(VEE4 <BU\QAk
XMS*8?W,(!1L%,2Z%K4SO9QEJER'8ND)+DLY*==5N--VU3QB:U$AIN $)2$ 0$j
XM;56?)G=I><C :B:VF2?;^E[Q,V6QN9YK*&!R@-"2.+ZP/&!4@4(8'4=ZL-&=i
XMZ='1FQ4@P*@XT@) U ;["%6=.1\DK91KB- 3$AXC^:%.,;L5"AM*"3UG\#AHh
XMUW,^F0=(L]$'C1<?W9</,QB#EXJC6=$DS24YC1<[7:J)YV@_W1S!7"5ST3MEg
XM4-0^<=4L4R$H_2P([4-DB&=X^RR>Q)JI%58"C1Q1<M)FD"=-S19&$"#FA]<-f
XMDGYEN]&;4U$N_08D;2$YD=5LH="TS-"RQ-B[009E'!V+_4/(,=$&A-!$$!!0e
XM2;XO$QKZ1H4.0=)$%#=KW08(/06@(H'Q4]J;3=(?0A4&K=(@7=B")H&E4=MGd
XM0-(!<@8;C5P=C1<V1"*6;<:G]*-D\K]R$,!$;=0D/1[>PM2X#=7D:YMMP=M?c
XMXBW3[5A<9MW&O09I4$X2S6=*310D39-2!P4ZK9=U)2-C!=1AW5%Y*!%F#:T"b
XM_7PN)=Z/O=(UF$GJR-\.+-")?0?^G=  KMMY0N"3EMA+J79L5V=YI16J6!L2a
XMH<YOP,X]8ZXX1=P/W*;[9L;2DP?,81X$9J5=G!7)'1WG"DQN$.(.@C7B,DNOz
XM)Q5*0K/*(>-"\08T+=)&ZALT^RPRWCJ>I39M4H9C001@@R9SH";26&@&]J_Jy
XM"-[!]D58=['RW'+#X99-"3VY6"^43)63-AU\_$/0J:#U\DG_0=?CF.7+/1D?x
XM;I0'":C H1,(HZ.^0E?1V":1MCIK$!\$X4X=8W67HG"I)Q>)2)KAB;#%*K5-w
XM  (S/!82O!(BUQQB.K/ Q 4FH#0B^4B34\K%44+R"+NG9N7ML>5_J1 CK&F\v
XMP\J+ \@O-%KT-&JE9D5<)! 7B5YE(!2)6Q.I%[T$!N>RGD;&EE*P,: R>X];u
XMY!5S$ 87<EV?RV5';KH@J%D=@^,NDN>;U+$W"NHK@8O&-B1!;'1$;*C(M)@2t
XM5H"$XZ@7IH#8-"I$BYE&VX=XMJED#(5O([P*][+_*[RF"NE4:^]<FQ-8,'9Ys
XMD9MH&[8&U3I?L/!YT898L"ZZAAPZHEY2@\0:U\>5J,&V88Z:5B&\!%6# 4IMr
XMB ?(0@0$D>FO9_&$>7S9:ZOV'HAF@59=\;:6K>\D@:.N$M<'%+*"IG"A _12q
XM<%-M9V]%D4F6#:+!RW7$6[?G$6!CFQ-:VQ8K47>_<U1V$28I#!O^;DN+OJ,1p
XMXE4"8U\ KZ<U4<]D0*95<B594LCO""I>AE)$[Z6G,Z4E6[%FSW5^-.Z65B4#o
XM3 <M1\;MH7 B#K/M@3DN;'\;TA"KO"M*&(@:JDLN8'I2@.[_E"<M8%L/IK.-n
XM:1<_Z+./.ID91B0_6*F928*G;T[LD8HZDKVD<NT#K_J>>;8Y^*IJV[?8,JM*m
XM)O.T7][&N-G9QDG(DF6NWQR\N/=ASYIP<8P5P@9$;_0,'/I8T/JJR/3*']4Nl
XMM8_+,?AT0!>Z'G,KL52)%!ZCVDCT%HDUO5-]CZ(+=UB(?I$7GOP')(1MGJ.Ek
XM0>D)UNU[^^U.0K))P"OXD4SWL H?0;!^KR_[J2;6]/5BEA8C"")G0B$,'>>9j
XM;!;20"Z8K_,-H,_7[A#%Z -:V,0KS#M+%8'N'05J@$VA\14(TO"45$]R,!*Oi
XMZ2S M0!H)')3*NH4>$,NZ >&-[URQ9&1 DG&HBPO&0@"9, ,B $U  0H 7IRh
XM!.5.'G!-,*$)/$$#A0(IPA+4"4TP/,0 <H8$:T,;&((QP2O @!QP*I"%$@ <g
XM&@/3)+K[U_.05\B9"L-*S81!/7$#MB (H %%, ? !"Q33-C@KLA;<)#@S)* f
XML)^"0-EH%C(@!QB]SB!UVH+L<"RZID ]C!?5%*I@J'"!"6$O)98X,D=^@Y%Pe
XM#]9!.,R>%+<)TT!O\ GL"PV=B32A$79,S'@3C1#OG;,-U4M"QR;2;MVM/)R'd
XMA $9H$JRRAHM1&NH&A'1:L:<D^!C'<,ZR+2K053> UR0/4@!S! ->W,+0X-Pc
XMH RX@79)A#'1LN88%F!S9,+ZL$()4IC8 "P,#=1-%UJ.&2%(ZM3GH%?I!T4Lb
XM":_@#L_&I7A&\((":1%[J J=G)H@AZ]P+KP QY+TY 1<L5V[*$\]#-GS)(#9a
XM\?*'K; <GD-!\QZ<U%Q0*R @"V0!%T $.N+:00)-H FX@"I0!31.EAI-&E%$z
XM=$0B("*0 !+X4Q0A)'(.U)+L/F&_HR7_+CU0A)5 $KU4:5 9:6 [S+AX%$I:y
XM@QTA-^$A2ZDL#>;X*$(]G(?+#=P0P*RPZ 2=+_F#;Q 7?BPWJ+<:81-*(S6Ax
XM%/:*,F(=V ,,&AQTI#50N&@%C#R&5S"&5%$50469=@;0 &9Q$+/#]J1"A8-Iw
XMX((/> %6P@Y<GY\  \ /#ME*2$Y$!;6$01G 36SR3#.P#4Q!5R4+*Q:H& CFv
XM 9LE!PU!')JB4D@>[>$L\HR6(_3.2BP\)G8"4:T[]P#H(HWH>W>1ZD?@AB8Vu
XM E.?;%P#3<R<W,8F]DEBH C8C1)'T,B8;$$&HIE@<(MV0*_EA:_EKF( XI(#t
XM,J -D8&WI4JXB9.X$&R@X "2YZBX8@TKNXWM(=*T(360\E:>C\L[<, Z6#.%s
XM9$G@ @A0 2Y "X@(^/@CU@#OX"18J?#@!3Y&!\9 &_J",*%R!,;;H(C*0W;Tr
XM2L2!";6:"C$CT$FP^7Y#2'7Y+=\D E3>TF&-LU&PU!VGQ=B:A6BL'LQ!>TE(q
XMMM6Z+&2F&P[I<5? 1V]':=K0Q1 !6:8H@)[>N+9L1GF\D"C2.L %^%CU6F2-p
XMS!2]BVE4/#F@(Q@B/\(ARDY$3I1,80>0A?Z1 _RG#.R K9)QT -> 8\403S^o
XMR)R@!Y"%J+MQ>L[8(4FAUAJY"58('N "# +'0-0&]( M @$OP R,%)@P8S(Dn
XM4 %@6N5#%K"@8L8F@IHLDW!2?<%)5JB^D$6=Q(W<1%#R/!"0T"*=@ZP1SXDBm
XM.,A%:"8.9:0)#2B I?@BJ8 =\\#<N(TUH8EYEW>RK+3>3*1 >C(5&H_;L1):l
XMCQA(E2&R1B@$'\=I:L-$.CP*\:00DS;0P<"#4G@^R,,V'!^$$79(B%L4$KKHk
XMK4D/7 F,M-*P>5Q I;" %T 7'KD)B2((SK%!4#7[XR!9R4R9'!." I6&;@DAj
XM\0E)B#1LSY=TFLE7'*!*JRD-##+P;)N#"!Q967T+1;$D%:F,L^<L=V78L2'Ni
XM9.T=CU39OAAE$'"4HR'Z]#U!@B5C@[7L% 0A4B*N.; &]%5>@0S8B#L2L%0Xh
XMR=IE'DB7/B%Q*2A?9'X(II="D0^'+;*'@F-W6@3>X9/1P0"*!VCW1D"7Q71<g
XM6(65:,SJ81WZBL\($\!1.Y+&-]8LP=I2Q)BLQ-(%O@*FPHI-S$@N[Z>$R32Hf
XM9+M&"R_B"K]H9Q:P#7*6M$SY>2M'3VJ5R=! +'>"D=",DBQV^"++([,B&5QHe
XM",$&S*R$(1 C\ I<L)3!<;OY(3,1(ZN'?!$TD\S7Y8YYH4H$&4B"#2U 'K5,d
XMI# EH]7F:!=?LR8P2 P!#H]FSA1@+(5GQCF\\30IYQE:E"$)"_2BK$DPSX@;c
XM@)E1 :]TG#N%%[F,7L10K:&"7$ZMR;Z$ XF")Q1J,L@&3J6FD%',47.XA&,<b
XMA=T)I^:E:MQ9/X(,Q TGDAM>(Z0J?<ES>69#U%?O?B-RD9XFPIQ@FMZ&,K05a
XM]<&>M$Z!G1B8$#W52_8T$]@SE#4<AY";L.=#@56ZCZ+T/OEE/96G^:P)@-%"z
XMO  T0 9B@!_XGP#4#R +)% @--+WO)_[R?H$QOW9/]?0G[2?S!-_+E#^.0- y
XMP!'4+#7@!FB6&+!/]J (> WL85J>!P1ZM\[$!"4#,\"!_J?*,2XM!($\4!.Kx
XM)B1/Z+$QS16-V!P,X:VEDAJ1Z4[+&AL;'JKOU(@<ZBUV*+V)G:1F\ITI*Q5Lw
XMI(-7L#Q28=$IG.%@5Z1*'-.0(. &L,81&D$UAN$K*FU ,NH59&E2K$-<NI""v
XM)(BNGVZ4_]J.?< /J8?XV(<%(?9ZE-)9'&:*0PF8QQ(JX0!4+!%HDWN.BJ,Ru
XM0\&GZ02+;)&QC*9<8@?2@)7X(DDLJX"=(Z<3F(21G"F2L"GD)1"!$#<'LQ1)t
XM :(-NH 90P:^ !XXI:=T/R:=++0K4&DJ!9Q5SI%B/K*P/5Q ]SB>C>E': ODs
XMX#Q)7]#2I2*/>H(3\JD0@JGVK#K' YB&#%5!3'=IB#DKC<,6Y;X1*3^%(!^Rr
XMGL[4M!B=%/E7(@/_7"<4SVDDTV**(9Z=B4L-0HR;NJO)H ,II=ATIJ%!6?6;q
XMV^&LC!IYPHI=D6R>L=+@-Y:#0;AZ=0.T& 308AMH"4GH9<X)0@$17M,4@$ )p
XM,QH&*_$UKC*5!@QJV,E9&Y!0_ B)D#9Z*0@$"1O5A-2+VE@]0^KKX$RG3Y[4o
XM#<PA.WH%+:E>K2=<5=0MQ$RM)T>5>V8"XHDMO%4'9"K"ZP(UDO=9T^UE4T5Jn
XM4W!RR.%-%(4X.;+\HV/X0;%C+OPC@F#BLHV!R*E-584259,**I"JFM@Y8\ 6m
XM.541\!@\4U0%/)H$9)F>/*%PJFK2PJJ[*7ZQ!',&&Y 39/&02S,5IHV:@ +2l
XMCT+PE!0* ;8'MQH\#N=>N5BA$W/<CFQC!BPF60N8]52KS"VBX!.@(@Y])W) k
XM=D 5[A9372H\)#8/06#\H!JU).I&R^L4&0I!+M&Y-1.ZWZHY0#JC,4(1V5/>j
XM1$L&Q*4:-0S<@4#G[I[G+]6MT8>D#E/KN5L#D:V$D%'"2O5'4I,:1)A@TC2^i
XM\4<45[A0I]*(PKM]NJ+(!%4@2*M2EQR4KM&GNAI-+4+QG$ATV!5308MD$B44h
XM,50G0:"NLRX.K@KPJEQFG7']"%B$SK@!\$77D,,R= @%Q]35"//4_]QI$-BMg
XM&+&Q7*GDZC>Z6%5PKH-I<MQ-X(H19XQ4"*L'UC["LCH@0'0FL]PLM&P?0;^#f
XM6(?DWJ9:F$T!_D% HA#95 \^#827[R Z/F+FI0*6F"EW0PP$Y !TAUL1@A@8e
XM'@:FM_I21_%C,9@P_3!%MC3H1N['3CY-1CL?A$[=M(CH"F0+WJ<@ P/AY^ Fd
XMX7APV@=VW:E) #MAUS84!E)>>[$2(F+DU<JHR7>N4IB,D$N2YB +X'1V@!WFc
XM<E>U:U$&C]LC&*1"_BHA;0@-#-!L8R9)AI=")^:E/9 5U7E%%F=2:$.MZWD b
XMC@$R;HR-[.).:.!21-1YTR!NHS:C"$&%'_T5-O$37&3QN[.T85Q>A<$T;P Ma
XM_4RR)<'F>04?(#J2K)=$"H7.W]0]A:.BU"20#42E@0?4VE]+:XD?'\QV:RPAz
XM;(4+X4Z%0)6%I9+0_<"W*!L9U)'Z2F"8P_ ]60/&2Y*"3$N=2.'J=8SC@32<y
XM1!B1:JD)0E0.GG Y#-1>I5",U)%.A'39*]RBF&$U!BF]PB'CP8O:"Z!J->^+x
XMJZC%NN'^I-K<RA'R5F RB4TKA4*GOBU5(PN)!D]=HD?[RG]0&>T,[TB%J;EAw
XM'()I,PHZPBK"A3HP%-"$.E.ES"ZOM-G"6A4V1U#1-BT'7(DKGW"+IH+YV0J v
XMAUEZB6+31JQ$RSD=]HA6:E,=@1[T(8YHI(]T<T8(%R#!;!&)17LVKD"DNJT u
XMA\I';4 .7 9RU+=;$QUNJ[K;64_$H\([D'!\A.N'.3['5)R6AB="<Z"$;WPBt
XM-I!$H0$?8R8&A-O=KD&P5EW3XU-!8T .R '144B*4S"$<QC,WXV._PDNT$WBs
XM(VCDJ3IBN^]BP[Q+PH,#!X_=W3X2%P1<WFBI$V 4%A@C/8$".4?C\7?_+MX[r
XMBA-J<6S>'. <#]MY[!UYH*(\BV[D=UFO/8)#.%2T,-:$L!(&IR/5O$\BU5)=q
XMK^!W@8I/\$6Q\O:\ 88:+>>%7* -3P_7>*G%(=5.QTIX#T6 *@"F+P*H:B45p
XM10HA<DJD0AMB=UA##+@!-6"/@0 C4 ;:C-\]%3!Q_;;?(LA/U*VT@4CGQ#RFo
XMC)7A%HU'7@H/ &O#G:AW^"$,D\/<%8NW[<H!$7$$V,.E-86X\!.M!-G50NS&n
XMZ<P#8^!#U"A3.$OQ1!%T 0ZFQS9?!2QV(Q7D?;Y'-IR<X W#^B[25$@NLZ&1m
XM<IFWZQ 4\$ZE38V-!RH1B^$#MR2%O +0AUDE0W5)KSCJN3E.*25B,@13RP=Kl
XMVCTA9(;L833 9;D4GUV]:*?T<P6_R" 6$*+/,ZS!D??GU*[FAB<A!\$$@UH8k
XM8(32!'98K-B6XHP<Z6T<%6CH!E  #O"NJT(+!Z(7"0("AE-)A8>%3+P 5C(&j
XM7@"0$9_$RFM86&'8<KZP\TTQC9<67@IWTGH*&8C"'(Y8 9>.I2@<RC#F[(Z,i
XM!5 A6OJBG_+2;< ;QDEQM)!UHG4&S_"@:CCB#K3B'C$OL0 +P8$M0 >6OW[3h
XM>BI233@!,4 &O(#R<0)$Q GX;%*F"-: 8APA3@"UZDL8@A@;8Q4PC)>Q,0[&g
XM+T %,.,30(VU<6!M+[4B4Z&.S OZL@;%7 FOQ46<@!CA$71@/*$-Z]BN>(0;f
XM.!EV36MX CHA] :;QW<"7G& B,4>0;8]OLD :>IBA,A=%0@IZ&)_A$5"@G6@e
XMQ/)VY$D/"P>',*,C72</T"M1-A*ACY["=/B8.FH-]YL38'61L0OP",:#)-> d
XM%Q",4?)HRG3+)1PS*HB3B.VHN&PZDA2NX> (K*$H:Z<(.%K8VT"?0 IN$(;'c
XM6 G^*)-"/C#\?#>Q2<&S'Z*GZ 1822  E1'FAPW!5]21-:QJTN:AE6IRP5>Lb
XM&OZ;5[P.CF@6$2V[X CMYNB\QO.8>FY #&,]Z7'IG"C3 Q5J  W"MAVL%1WMa
XM[54EG(@R6*,@92:"<M C"++#<_0;,^"+',@*.Z]CDHV)-0Q%I;CRT,2A/,+@z
XM+D7K0X@-L>6K73B$GR85?=$:3#&^F#MBXOH6)IK&V'A)2CF;8@8LKY,Y(8*Iy
XM1PDN?=0C!<.$W&Q.W,G>^11$A<WYW_ED4@[=>\5;(6?DR%6RD(<O(I?ER^)Gx
XM:SWG\O4^IVF<O1J5RPW<HW"5A0J)J4/#/ W0PH3_8EY \]'TKR(6/$-<)^$<w
XM]1<(X .A8E/<VM.I>H!S4]A8PAE0R5-.58E[UP(#&W03[?CF^JQZ['(:A$/Yv
XM&=36G5BY.-!2(1NPR#F?&D3*L:\(PL,=PY+3W!2<$+.I)MGIY J8-=6IHQ*+u
XM%83$*7N^!>Y";]K)\;JR".Z5H3UUYHXEG5 #@C$H;(8(%(V<U\4Q%H1 (*H#t
XM(JE+ 2R?X@8L)OZU9J,"E5B<05=W#M?A ,IY,Q<"S11[@%"#^5FX^:L<;Y\%s
XML[\<S*'ZNHU)"=WFH!7YS*X*#JOFI"MEI64Z/D6 $K*R?4$*3 $J4 7B"':Pr
XM PA..K>%X9@IB$#9"CYAJ\C<X&R1!%Z0NZK.K(%/YP0F(+7H+G760=9Y=;D!q
XM(H LGH<9Z%)PV4^;"3S0 W9@6V@HX^EX<#$<T4J]S8_2.',9*1B1=:0[R)>Gp
XM;D-&H'+MW#&<%"Y@S3D>MD%YM)I'B"-<Y\"(0R[:*VP!@=>&D@"R@,N%.@T=o
XM:D$C$49-<S#4,:@;V5P"$I!H9/S,%&X+)F2MO:3JVI+A.5[)J_^Y!6+M@QFUn
XM$/ #>(%=M)"Z=3S(3.0J=DUA6$\M9-&&BAY,^)+JY!,-WV-G.73"$MALM P\m
XMZ 3.)06F XE)@=^E#4V!\EJ\9$FW[G)%D^WI!!GY+WPPX/J@\0)3\V47I*S%l
XM<+DE"<_P(B4<@L#M.K8G:5P7"8&E0FM-33-%%<C.H%KPB&9HV(;&ZI<T4"B*k
XM-9C(\YB0*J8/IES]ZW)!0A>[N3H7PP%=&N=T@8#2=;KFAKQN A'E.K<N* "'j
XM NY^(M&O#"%C%=^%+/X:;8!TO"/G-;U$-"5;#2;B:,!O;#N)-M0D8<*3C))3i
XM<C\3Q Q=>]K0'> 6KD>Y:;.%X%JBPV 2D7(P\F6+L I6;^VHDUYP==NL532,h
XMIOOT%V@"2< )V+!!-%:IP.RI+_4/+CSNR(W']IH4BME^,@LW;KX3B,PUY?Y"g
XM88BEP6L#!AO<]?(Q>J\!,^<5-9T@25VOE$!0N+P]C+E-%*K=N_VP>30L#<*<f
XMR&EI0[.:VVP/SS[<ZM6NZ%S 964VMKX)+UW&6A"6/A,?G84&G(_]%0.VMPO e
XM >=C!H#@E= :RH004-=G*@'4&2V2 %HT^WX"O>Q(:@KD$(HF OCQ272N?*^)d
XM-O$"QL#+20!FJO(!\*_D M)  NA*O-J\1H4&\;2!*DOX2?I;&G$9UA; #7@ c
XM7P,4!TKL4ZM\D5+);0@)#F'8C(:B1+Y; T241EAO@%,^#![ 61O\'E"32GXGb
XMQ L2TR:"*20J$)N$FP43S@HE^!E0X6? !5!P CX'#OAW$4@B3W[K</U-**>"a
XM4C4/0-S*) !9FP">&EM"2%.!O*6&!K[$>?B3>P'J2ZE&\2(>P-] %8]>UN%4z
XMH8HN/BB_>)0C U'<C'.2!' R%!)>4>/]A(V?</X]!NP 3,(B4WR.ES(WD.VDy
XMA]"K8Y!;<M\PS1**P@,>=^!,*>\UA:RL*23QBRM&D>_%-143L4UQ1-E0/:1Qx
XMT'FG,F61;*C9\;:_#*]<ZMM3O; *[])BA'DGXY\;U:7&1=G$HZ6\1@@2M==Pw
XM*8,B38$Q FS69$D. B =$/-XI,Z7/%[BH+Y$- ]S6EG\#8<'NM!$Q8RJLYW5v
XM^@R1"517O!6)\8B^55G7$JQ!=!#/-NT^W!BB;!['D<"Q1%8:F1Q6W"]=PL!$u
XMPMA<9"[F*83S+AQN3J]4!C^7#8S6_LB+Z#1FVH25RR2 BM#XN8,^H9^',7?=t
XMWI%"%8\L-VGX^<,^XI_DS/DQ%0:Z]<<!N2X'8U0($FH5VJ+>)0'=*(TN/"[<s
XM.<V%6EF;"GP[B'\YN#G)U[6Q:S73&J#CD/H&T4%RGEL<<'FM"KFCMY/-]49+r
XMU5)BE-0-_+NF7<V[MNG-X3VLCCAB)2 '0X9# -VPFF^LU:@SSS<L4FS/C/H*q
XMUW$>VR$X7@@S61@5$_?:A#HZIYJYI[,2/C>#5'N>G:;)7VXN,1ZCMJS4Y8[\p
XMXYA%HBZ.J:L(U/FR"!$TJ[PJ-"+ EFS7=')0;-5/982F7"[58(39+-&;LR'Go
XMZMYMDW=#[CAABP[=%+#-,839A$SS(G,QNJ"'=Y07G]U>/( J Z<(!'1C%<TBn
XMN_Y4C&K2($9D;HYX=]C!QWF%5F((@2TP$P>>0MCHO(<%B"6A$[ $S^ =;" 5m
XMC8J_JEHY5.Y!#U*9-'2BU-"96)W,PM+&1KJ3"#9PH7B$G5(X]-0=QO2K5[7Kl
XMAD3"#8/G44Z[6OP\THN%V*%S6Y\+$AN[+?<H?)_OAO.W 9/9?I&<+A;PVI<Pk
XM*E7WL)3:Q1 U9VFD5O!5PGV3-8P:6\^8N%V]5;^ S54.8LAN-]!VF.&=Q>&1j
XM"YEU@(0_87)XGFAYA<J#LFW(UF<9N?.$5!5$96&:'"QD- 'X5O,8YP*^8',Hi
XM=I%,K%>& /&*<*<-GP2@!OBMWK7DYEQURYPQN1_:K'$AYDU>SQM[0V'L2HU#h
XM!11"3O@1\$IG%@_H%W!$W<%8".M%C'W80Z)"!"'Y%;A^%P?, %CTCLXCZ(0-g
XM08 *F "OI4,7W3G_>,BAVHU.UTFAH!T2YCIW'KD[EH70''AY&)@\;[@I=/E%f
XM)T_FYNV<I*A1 R8JA,!0Y(C[$+(?%:C(7-WLID=];[Z=>4CFOEV9:V5-3YUQe
XMU$\3$TNT,G '7),/'JOJ&NEFM]"@G^8PJO?/1+73ARN($2;BI0_(3C!A.TT'd
XMA/U.4KVG3Z Y5;[N9E.?*<9 MBSVM/XC('L18+G.CW5PCJFIZ_QZ=SH$6'TDc
XM7M>$?NW^>L0U[-]#O1T5ZMUN*NMPA=#SH4XH'I8-KWB=TH;W E2*A0.T>,&Wb
XM 1OJ-G6,CY^[@K#OY;E][^S#%>V*-+3XTZ419$B!MF[%B^NQY,@S=RL!<[3*a
XM@Z(*G%W!I$8P32C& )0:TX["Y+<+4J_RM8QQA5+T:A1'%X8/[)GS;H925E;)z
XMGC<]/:@S19O1;<M14;>/AR+TFP70UQ4]/R=H-UTA]&?$T0\]"Q87&A2(EUV#y
XMA0\NLS !"; 6*^4&_E*H5C@RG[% ^LTXR0\^7DE-;4@,#-"M[_B\OF($^] Ex
XMD'R>T13KS'YSU1=M:-M/@;Q]7K'V8@36Y-4'LP&3$:J+S2T4HEUO<\R+,P!Xw
XM^@SH";7+ 45L"Q],(??^RU%NX1Y;2:CZ%G#M-K=@)>GJ!6]]B\5Z7MO>W,G_v
XMQD$P^2]OT+QK1FGYY213S(@**EO;+7L.IY"C@O9ZJ]3LWR)EN5#D'N=#V\8Bu
XMB?.%&((+PA_@S)*-#M^8!$T0Y97<:10/;30C]).%TQ$%X@5TVGLV(^K^<CW[t
XMXZF#/7^O9#;R2N8'%_)GTE!?4^=U/5_)1P.[9(* ^K'KG.(_]1P!^#__ZW_\s
XMWX>;C-<J DZ "DB!Q( $EE,??@)>2P@4@2+@!( 8$B@">J,(O(3]O__S?^H3r
XM"/:_-PML3>,4($W%;M,"P?X+?2E ]$?N;' !.$9&01KS]JAQGY'QP?9:!)0[q
XMD$\[K0.I(4A.AZ8&>_B?69W%EK]?>B7PB@ P=/SCVJY,.+!AEW %:WG<?62Pp
XM1P.-(_;GA+9PY)]C#$#=Q]],''DNT!9(/*2QEO,$W+ YZMT@FR/LA@V[A"MPo
XMDSD2)HH.H$+J>,<H.Q*K.C<^+,8!A\5)8&N:WXE3=@E7V"D% J<890.OT#ZNn
XM3S$C Q-?]8:>0A%0@,HA W,#-0L2L?API(^M#E5. =)PD[1Q,V-YMI "1.KVm
XMV#U"DBX__EV/BLTBC;X<-M$>-*7'\"FA?,PWB\IINR1E7@V_(  ?#\V$$6F0l
XM@U&V4M8!!7IE%?@NVG]&Y?29]B*A?+*;:0N\F=[-F;; ]V:!K6G\.E5C+*LEk
XMS4_^-DW@0?R>CA\K ,<\YYU,].-'#W#45P%$KV=B-%&$JMX-]IFVP/> ],%/j
XMW$Q^A0F\2L@,+/@% M+'WIA'X"_ZS'<TG&D+?+:@ ?S$S>17/MBP>1'XBSX i
XM_CW0 'YRHVEJL,^T!7X%B)0,=+_TJY'T$LWJO4>?]R!2,E!%,WKA<C<(?"_Uh
XMM)*NI_'K5 TD@W<U"E585QTPR**]=G[#B9JK\I#QX!(K8*CA-WN*O@@(L6DZg
XM3X)U\T) -SF(P%B+;EIEE[ 6P)/5JP).&0GJ!01<<K#Q:J+/BS-(Q6@.O)KHf
XMLQ(:8A_U[]%GQU]Y&6&!(<[SN H@^F^X=_ 7?0"\X5LM>V?*+X<J+Y)8$R@Ze
XM<3-:Y>)$L+>[)7$KQAS4*-#W]7S4S%T&^(L^QH-+1#>MLDM8"^#A>!.!Z8&_d
XMZ#/?QSS&0^VAJ?B?44$2TV::,']TI\:!S/TQ ;E.6>&4"-Q:7Z(R]P[^H@^ c
XM'Q<M7M7<S,*4+[[?PSBXNEY@XM'BCYIECUU  S>S,#DT?'%P=;W %.VI\(P*b
XM$E1"3 2F\<!"ZT'@AWYPDT83D57L%4S'KU.U4.P4)?O&U1)>GBL@+<H<P1),a
XM7;Z0<P"5^%$%-:&4HE^G:CTS?QE((<%A)<)V@!Q7JEW2KDT>%1'(-T3"U<ZQz
XM0X]^PXO 7_29[U9Q..7,40%%V\3#&)QV"@6TFL519\HM$(,"@DM$*&USPMZ,y
XM*Y<P8@B^[0M\4YY$634!&1-9^K$3!*BD:;9R7*XE'J-7!>^!/Z$BX(F,$3CEx
XMU42?2PXVYL"KB3XOSB 5HY&@7D# BS,>$;"'TDR''"J<2&^ $KPD[HCXKAP!w
XM,UV%: _]/6KB@+TQC\!?H!.=X*T6#W,J(=LS[46RG6'4>'S\NYY7!J>=^K#4v
XMR'-:U0EE)6+:UZ]8X"_ZJ-&> 1.CU>Y\P8%O:.(1']<;1'LJ9 ^^SBS6"'<8u
XMFB1QM>L!$,/10H]^PXO 7_2I65C@BXK%#SXXA\*47!RE2Y-L*J1>-1BB48OYt
XM :'U:970Z=R@V^"T4XMO>JS1JP"B.SPQ?YKT*EZ^]^ACL5B9/ 6;&'73.R= s
XMAO+);J:MP"1U_^]__N\$_#\(* ).@ I(@<2 !)93'WX"7DL(%($BX 2 &!(Hr
XM GJC"+R$_;__\W_JF^T5N#<+;$WSF-4((%-$#8)ECZ#97H&%OA1PU(",?.E4q
XM^-FR<X*]%@'E#N2;%N8 :PZVG75NG#+;E(M@GVDK,/I-@E#0==T!D6=)Y, =p
XM, @-F"O  4NR:#*%06@@G*:2*)=L@?*R<*:MP"O (-POO1)X10 8.OZ).P;4o
XM>]OG)&0 :<.)8&]M9^%,6X&!B^R77%$P==L^5\6IJ ^*0L.9M@+7@17P9]<Vn
XM3* ":VH_38$B0*>3P$MH-3V0;QV&/)QI*W"V: MO8 4T2'?UMAK-*>%.JKQ!m
XM@*;*^1QA-VS@[T>\K[P<-B$SFY5B78J88VVPAG4;R[.%%  _B7UX7?S!7M>,l
XMW2>BG6(=W B2CZ]I(.DIR38CEI@#,F#>>2OAC[)@ B1F%) &T3IN VL(( .Dk
XM@  R)E49B+044@A7CV?T!LV_&<-#N[CX_>;B9'O, <BVC3BJZ0'IKU"QT>36j
XM[0(H;3259.GR,X#&6Z1-)$\ -("?E&\0<-SL!G?N1#K"*->E_32%D:3M+P.Mi
XMF+4$4T?Z/F0 /RG?(."XV0WNW(ETQ"[A"MSD]^*0*8PD;7\9:,6[A"MP$T?Zh
XM/F  #<A Y5NQVEGDPG46'\2X \'TP_JK!  #9$ &*M^-;-ESG?? 6D3>^P@Ig
XM&:A\-T"N\QY8B\A['Z="@Y;OF=G&2,.RE5D US$;9:MI&>O%+N$*.R4!\!,Mf
XM6KZM<%8@#<M69KU+<'/DU>52TF<(9@J@E \.R)H#(%LL9=D3URY =D%@6>%Ze
XM.*=D-HLC111*84<^>TE;8)/JBKIS=7T9N'41>P!B<)->]FVU74TH,GT !.P!d
XM$;$%-JFNJ#O2E#7T <=SSK!#%/45TR%6MAJXL$DSR6@:N:H4^:M2\Z1*T^IOc
XMV8^M\D2K\@9AE$7$+N$*?G2-U$KC$2/2+%'@-SZ%6N"]R@$7-BE&) Z_;-[Zb
XMFP0;%;"&P$RY[<03QX:&0#'MWL'B4<2\[NAW\K4"5"E<: &J="OV +PP)7?%a
XM"D@X:^J>\FB>0J2OKB\#MTDAX)@3O- [7<3J5*E3$B[T '0(^D,3>@:W+F(Ez
XM]#$"PBFS#>,B^Z?R>&U2:1@A$#Q<W!5GH <@/.C1;T@\I.$FO>S;:CO:!1=:y
XM0 M >"1KF)\S[!!%=S=Z!K=L:C115U4*%_*T\H<+"&]*FF:\(9'^;8-(="("x
XM*<^G^(L"I^0?3#AKZI[VV[?(G3N1CC#*+V"7< 5N\GO_BFWE46&S1[H_FAX6w
XMJ9XF/=4CM][O"N'&%G9 :'@#*Z!';HZ5\)S: %AL_QF5TP^$.Q#CYK\)'@AWv
XMP#U%"GJW__<__W<"_A\$% $G0 6D0&)  LNI#S\!KR4$BD 1< ) # D4 ;U1u
XM!%["_M__^3_U19@[4)Y.K,#6-!#C#HB\MSL0[H!.$/I2P%$;Y5?A I _I,F;t
XM-RAQIRTCXX/MM0@H=R"?=EH'4D.0G Y-#?8#X0[LAE%QO_1*X!4!8.CXGY6"s
XMV!:H[QT(IA^690?N@7 'RE.FT)M<Y<@_1R\IL#5-<+\#P=1X[!*N8"WG";BIr
XMG,\1=E^1.Q!,YTB8*#J "JGCG5W"%;C)'#$/<^/#8AQP6)P$MJ8I<,,#IQCEq
XM"-%77<"V$4:ZA$R\#K'X<.9&@< INX0K<!-X7L@V&S_JE+PCW%2KWJ!RR, 0p
XM<:1S S4+$K'X<*2/K0Y51#AML.CMR(LB#7(PRE;*.J! KZP"WT7[SZB</C> o
XM"Y1/=G,#O"*I^W__\W\GX/]!0!%P E1 "B0&)+"<^O 3\%I"H @4 2< Q)! n
XM$= ;1> E[/_]G_]37S:$5^8D[-<N79<-X97QL%AO-S? JZE_^Z2I"XC:_4*Hm
XMZMU@GQO2Y'B.^T!,"G0EXT'ZTS(@U&YH.#? *_@X5LDS?1D"4J K&0_2GY8Kl
XMWT9CV<6J& V!W  N" L;^%_MIRK[G?FD#4\TE/#.P3JOS  9T +^2K\9 E*@k
XM*WW8APM6C-V+:Q#S*"NR3GY5C)(\%E@/;T2Q=$+6\#Q(/YFH:+'D;H 5)X&4j
XMQ_K""?NI;NS#,O"V;<3188TE=P.L. FD/-873MA/=6,_)!SYHTWM,OW(=_^<i
XMG@T8I?EO@MD ;3#3NYD-<&@*E(&#KW1AB#GA[;(!.1!  VACP+O=U?=EX(XFh
XM0.^UDT!A%8LAY@2CI]!22FGS4H+5RN<H7L00<T*:)0II*35\(I?E,<4#0Z1 g
XM23ET.K=?;7FF0XMH#_7-]6 ()S%Y6@!QSSO(:$N+_ 7366XIR>?TT63^F^"!f
XM8J9W\T Y]<7!\ -+ECV"QD!QL+)Q8CE.K_9<0A#OM<X)@U];<X5S\UU80\6Ae
XM#NGM.X0'F8LA^JK/X!E&A&L[AA(".0#9MFD-%<=3T,KY("*0-#UD)6MJEKPId
XME2X;T/! N5]Z)?!^T&S3++*48ZYKQL[P6T:L@(8'2K9H%O=+KP1>$5!QQGNSc
XM:"FZ9L=@D-10T2:4S&73PYP* $OA/)H@/]A<M[Z<0LG;3B$,S]R;4NF[,Q/9b
XMV=[)P?HZ<+ .,A<YG+DWI=)W9^NUL[V3@_7UNF;L!F!9-SSN8M[.DC>ETG?Ga
XMQGJ<K&1-@4U> 5;8\P,S)R\.Y!16C CY9298<1(;J_UG5$[?&5$^V>V,++\Sz
XM&M?]K)\:'Y*4.<"RBR2^1_)V.Z.5#<8I-&Q-K_9<0G38M<X),0!O7_[S2D7!y
XMA4YPCALG5)_6O[$=PV'BC@%KJ!;YX,!+5OF^&J&BX$(G;*R-$ZI/Z]_8CN$Px
XM<<N -52+?/ ,P-N7_[Q247"!!36.?CJM3,<]"-U/@H=W<V?4*^VYA 1>$5!Qw
XMQCNR"Z%YAX"T@4>;A3MC(++1]TNO!%X14''^QG;43XT/25H:H<NRS1FP["*)v
XM[PP5FS5H/" _V(1;!/F'45%PH1/6AMR:?,4+XI 0,;D=R0188<\3_8+D'0+2u
XM!G1"#-@!$C]);,>I %:<A X[2*.IN<4,<*$39, .D/BQIS,B24LC=(7S:&INt
XM,0-<8,%JY_?-23K>FUP1QI(LU$A+&<SXKLT)THRA?+*;()6;F=[-"5*YG?H;s
XM<5Y!D8'*ZE4!D#F<]L $4G:V:0%:H'.TI?GP=A.D&6OU9, ,S/(MNZ=[8*".r
XMU'X+UU=M 5M"P[57U$1]\*B4T)VC!8;5=9Z.X[F]W(CSJHGZH*^_$=$A[W=Mq
XMQ@[XX1!E8YT.9$Q(3H$![>8#VW:2^X>3 K((&;@3I'+C 5,!/G4%*"@"OJ1Rp
XM:\^N-M@G2.5F$*Q#E[S7"5*Y55 V5QJ30#/2 JH4+F H+:!*TVH2T /Q4=J[o
XMZ02IW(CC(-("9A9U[LWR%1]'MNUS5;"[=:.,Q'>&4,!6!(3:K;3VZZM3&8CTn
XMW"@VJ).0K(2LKMAA@Q;H'"V ":1L;N00'O!DX)4#-[@+6"XR$LQ1U%P<#_?%m
XMK?]@/;RJ]O':.5H@-&S%<.T5TX\@$LZC2>WAO<KQ#!.D&<.(/5MFCMP/?2.Bl
XM@RH=3@MV^EK&>H&N9F) 7_WO8J,E]IK+<>6 &6G761Q")P$]0#U" [5*D'V2k
XM=H$<"1UC);G^Z[U2%H>D9=39(\MF#)@!+>"O", $2>*00FI-Q]\A*2H=U'G&j
XM[+G/<,Q:_G&AS5,^![ZMMG,.^@\$O#A!TGKH/GQS?S%@!K2 OR( $R2)V^FAi
XM\F"M!.#>]IV%OTR7#>7MG1H.V@+^"ML8'I:&EAFQ.D%+&<SXKLWRWP/"1MS,h
XM34CJ_M___-\)^'\04 2< !60 HD!"2RG/OP$O)80* )%P D ,210!/1&$7@)g
XM^W__Y__4Y[^-*^;(D6^7FPA]*>!03$!Y(Y*.^GZ%ANDE X;5"/+?2;]]2 %.f
XM5]Z(I*/6J8(:6H/B876=M[W7EKZ"=9:@#%7N:J]U3@#:(D 211_'/YJ*?&IPe
XM4RPB-=CZ:YT3_H60I*Q$DG(:2#0FLU2.P.PIW-<3UFT?O(6;-.U,OG;N<I?"d
XMWB"<WW%A?=T^N&U7R+B?=,*#__[*\Z%>W]H4294!=QZVEN:A#M%Z*"@"2EF*c
XM-$_F0:>6QCI#ZR$>&N8F+: ME,+>P"!+H4.XM2FRL".O]<EX_5^$+%;%: BPb
XMOP6=) 1/MOTT8HK3;&CT&"NEFK:<D6?HBQ+,R6$_P&)>@<MB.+%[*;'X<(3$a
XM^FP6;.Z,"A*4*:);Y?IL%D>TE*7'%&<RV8.OBX1EX$=%^M4?ET/#1+4_<%D*z
XM$"E6G@%'OOOG] #?7:%\L@OP\2Q)W?_[G_\[ ?\/ HJ $Z "4B Q(('EU(>?y
XM@-<2 D6@"#@!((8$BH#>* (O8?_O__R?^OPW##*N.7)@YM50/)9X,8>ERB)Rx
XM!/EO&)3T]^LLOT%X"\B K;;P@@#ASVE#_T)(4E8BF6P9,[@!9#)+Y0C,GL)]w
XM/6'=]L%MNT+&?: "\-U5*SX[+0)POWZ CV=AD'.$08'73<\>\@6#9$"]1X\Zv
XMLF/' +S0BBOGB)!^ !K@NZL')F\[A3"$T-DE]N<$*=!'.F.!T.@=3X5]*^XPu
XMT^AR7@V%5.[8L1:9Z::*@@R=^XV]2;,&A28/OV(:"#:RG9M<<@<%\-T54A[Kt
XM&CD&)]N>S=&<F2]"K)S1-H3&O$J917ZZ<_^<'LB@?+)[B,WT;C[$:=?B: ALs
XMF!O@U8?%'%SB[1[B'@BIC0S>[:YQ\/4?8OB(ZY&IKLN&X&+2C/*F@, EL8BDr
XMJRD0&^8&>'54FI4K-VHG,T$>!^YK:ZK.O#4V2*$J).6ZYB0@&:U JX"*GJ8-q
XM[5@TKRZ4J1"I-7AKVE I$1ASL^#QVTANS9/:=<KGP&F'*H9/3-5*+L9<[8^Op
XM9!S+H<KGG><V.*A%!W.Y>J<2$;.6LW%/V&/_@^!"E7(\)J3"F$39[!W* 2EHo
XM&MIP#;MPZ^E0;. !3X8.!:C&O^,U_[1B,F3 S,=@-/UJI,,HG^RN99:_EHUKn
XM!F:>ZD?^3?XV38=_8-YU_3 !(H9Q.BRKJ>( *2".!?"$0S,QB/NC9QY6Q4KQm
XMKF6,F(&9I_J1?T5:+9X:^4 6]VADJ):@4&-D8'46T&UG&$VKJ_"+AW$Z[)0+l
XM^YGHS$#&G6\;'H4%\+'YD4B18=Y"OK4<3[N"76:L526OW,9= J(%YI 01)SKk
XML&VC1ZINZ:'*T(RM64@X"2TSR+##WY VCLM(0 A\;'[XZ50H($P"E53S)F8\j
XM*%FH%H=NG(^O91\QLL&<<3<IH\EGFM$@#/:7[\ U*:-I-*1+_A9]-H?(J1#,i
XM%Q7&RDH?-O>XFZ##/J*/D*B49;KLAI.PIQ0)#4 (?S]+IM)-[VKYS(.X@-["h
XM$OB92,$M+H &J(_QH4'/1V=1'PR&3YR/S@*^[Z +@#9$/0$T@:F0 )! 1R,"g
XM<R$!L!#_LDZ,>!@M$. '?L  %0 _8( *@!\P0 7 #QB@ N '#% !"0 BAO& f
XM_Q<7Z/?+ YJE-8R _1SP6[,RG K'H7^<"O@! U0 _( !*@!^P  5 #]@@ I(e
XM ! QC ?\O[A OU\>T"RM803LYX!_S\D#G4L ,P &P \80 /@!PQ0 ? #!JB d
XM!! #6D -2 !@W(FOR?PI&,U _RS?Y1L$C( (N"9O<0LP LLA$^H)&C #8,#[c
XMF $P( 'X7?@! U0 _( !*B !Q  6, -80 U( (.X/X)Q0)D_!:,9Z)_ENWR#b
XM@!%PBT7$%9BWZW<Y9$+#.P-@0/\X%?!C#": \I$ @C'\@ $J( % Q#!^QO[Ba
XM OU^>4"SM(81@ 4:0DV@:C$]$^H),JA94-2! 4 B7].O1I[!RE$^V:4+9Z !z
XM10IZ-UQY!BLWKO?(5WR1AG$&_NS:KJD\@Y43%*&O94-##X341L8'O\@C,)!&y
XM'J\S Z0A766;9L&N6+GOXQFL? ^_1Q> -^#C6#T" VGD)5NZ< ;^[-I.O&9Bx
XM"-"%,] C0QY!PJ0Z/P"R<G>NB%B3NJ^B[8QNS,V1F36/:#$7@+4NM")Q@M2=w
XM=L45ZI$[Q\.;";IP!GJD8@V5!\@9FHELTTCGP FPAF[T/D0!'4 7A-L<]0\Jv
XM\%W$7WH*EQOAU7.T)$MUX(NN-.B+II>*3>2T>.^*$8#2F;5*WW7+RGBDMM/Vu
XM#3'N[XC9TZ%%V&-Q=%AGN(HCU0V",9_.WX$>-@3R*S?UHM(?I(81Q%L#@F]6t
XM="'(<4\O1AHLF\PL[ &0E;MS34IJ\$4J/DEL$2%^6+H0Y$J#CTBHT DYI,O7s
XM\6$Q1RJ.Z1?S]KRXTN C$BIT0@[QMS1<J!J!/_*AK208_XMJAGM_="]'UG]Zr
XMRV;B"O5(Q1HJ#]#BVQ57*)Y:\J1SBO7[!;$#AJD]]%Y3N"NR32/MD7M#!;X+q
XM"!$N=0+/8.6.Y/&5AM36&QCSZ?P=,7LZM BH:#MM _*+%QCW=U C#.%I\@IUp
XMO1(]LHX2\W?O%<+]YKC4L@%OW)Z4-2I"YW(0[%:J<4R%OUSA=I=1"S?X8SJTo
XM"'NY,MX)ZE@<76G0%\V+*O)IZ4'(+9I^-?X[E$]VX9"9WLUPB#.)FWO2D*DHn
XMN' 1IM+6M^E_YQ;,=R#Z^6R!#\2/0&3Y;I"96!O7]?\%BQ[<IO]=((HI9F)Mm
XM6-FK&A>R#4,@^O%#\N6*E3#U1U:P\(%+]SJK_7L-A\3BP[G1-/5:\YW/[R3Nl
XM24,6BQ_\04$G=2,=O:3 UC1E.6: BZF<;4R8^SG.<2';,(1A=9WUOKBY)PU9k
XM+'[P.9(9)U2QD0A#&YY!,)]KPNC*@X).& (%@+FOE6T8 EY(7=<9:,-(E3%Ij
XM?*X)(^C#85]*H<' M1T#WT][H3HI"R*?:\+HRH."3NI&1"C%+X643S50SQ0$i
XMU]&RACK>')*R(/*Y)HR@\S)R= ?@14%& RMA7W*%\(>&X5"VJ!OX63R+ #I[h
XM3^9(F$"\P1X.#6X&DRWV6!*$@B* SMZ3!P6=, 05!1<N(@:("/5K/&H &H9#g
XM@YO!9(L:P )N@#F!@B* SMX3T$1%P86+X'A,R :0>W%=VJ 3>3(\M*&_SY',f
XM.'BH*+AP$8L2%!FHX;SL^6&X%9TG&DIXYV!],V-YMN OM/SVV#U"0F]/W$NAe
XM4!)A:,.S@9EM3!B?PP(/"CHA!Q&QSO%.:? 1?UF_IT"!K6FRY!DK[#O91OV'd
XM(G4S8_G@)E*WQ^X1$B%1N#XX%047+B+(B\6'4^U@29!7@8-'"#"!(. $LCSFc
XM&GEI\2WS9?ZRW: 141_<1(J5MX9B<S#4%-[I8P2$4];BHVA)G@<4> )3P(:)b
XM%!@@OC>61 K#3K'7J9Q(2'T=;2!J,U.T:G>%5EFX/GA%L^:#J)B?&J=!<R3Ja
XM WF6%RGT Y[<?:,9'XN*4-8#)[B (&Z,%((:2 .PJ(1A_$0^N<MFP14\VRJAz
XM0B=U\^(F@R=UM%ZJUZF<P:E5A%ZU9PT(GA>!BF"G)(*[H^4,M4F;2DZ"<"6Py
XMT#U9E9*39Z.,]A#,-L>,[0V.1=-DP)'O_A%"Q)__D2K@D]3]O__YOQ/P_R"@x
XM"#@!*B %$@,26$Y]^ EX+2%0!(J $P!B2* (Z(TB\!+V__[/_ZDOX*==5/9 w
XM=.:W<K'\%@;6U( O]$\.PS,H(;$C:D0<8R;00*8%\07%RU2]+1OQ:FK %_K1v
XM.>C#A170R!LA)+_.<>#44I]OY6(7)<@IK,/J.A\A$5!Q]E+ ET!'H EX(?I)u
XMBW'_7@KX_!8&TL^ #P-D@ SPNS* @XJ4S[\E7*S"8;]M1@;$ !%1>S=6>* !t
XM.D"DU 8A;F3^DX\"/(5])Y\<Q-ZE&@2\I'$?W)4;M4L.-B*^Z 3]>>4(- &Os
XMI>QBONI!6& C)'9$C=@UQ17MBG5R-XJMD_A[>7< 3D$#F7;@7Y<KY*)DCG'!r
XMFB)B&180X[$S%/)DP1<?5BH8A#F2&1V:2)_P9X<T DLI=CM$A"#J[\9#$(%%q
XMA 4V(OY!(N\8>6*6YV_E8OFMD1 12?E;N3TML8M9MZY\7-4.+D=G6GY[.-6*p
XM\ I'H EX+64G?6RU$W,BO4'9P?-=;*7D/L-1+)U0Z9:&TM73>H)))_Y.PPQ o
XM<S%4TU*#/V*+\4WQG"A'*UM8 C\#:+Q%VD3R!% "2D!K* $)%3KQT@]2 N!6n
XM'P85'U8'OH\2X*/[,*CXL/08#;R/$O 2Y$X; (QDX 7D 6^8 $H $F@-R'A>m
XMD0=YI!,VEA1CE1^D!("-SH6O>@-YH W%#EMN+!RRL:08J_P@)2#2=2Y\U1N6l
XM80'!(1M+BK'*#U("ID!K0,;S:F<HY'NZL:08J_P@)<!K@0"7J -"H@Z8 B^Ik
XM!)3$SH6O>H,^'HKR1T3L_<@K]U6YNQH5NA@O;:- ]T%*P!5H#<AX7NGCH2A_j
XM1,0MUL56,C6\^RT17?#2-@IT'Z0$['#7UL9J0@F@ N^C!"2&SH6O>L/FQ2%Xi
XM4(JQR@]2 K1 [/R$6D"J]=5NF'L20 DH#6%##+P:%[I&7\>'U8'OHP2TF; Ah
XM!EZ-"UVCK^/#TF,T\#Y*0%@-&Y>_[K0CHA+P.9>RTS@-Y>UQ-:="!W)/ B@!g
XM%*%SX:O($ET^+#WFG#IA8TDQ5OE!2L#J<6UMK":4 (&9<GL'>.-U0R?MK?74f
XM  />1PG &R# M;6QFE "Q,#[* %JH#4@XWEE)>C.<0>^&P:'5% IQBH_2 FXe
XM%)T+7_4&>LPY=<+&DF*L\H.4 )W0AVE]N']0T(F7?I 2P$W"1J1K$%"@";R/d
XM$D ;&(P,: 'D@39D8.9YV37IJ3Z8+P *-('W40*\@FO0"@D5.O'2#U("9D3Gc
XMPE>1);I\6'VL<6! #]C[D==3OH\28!! @&MK8S6A!!"!]U$"K$/GPE>]8?/Bb
XMD(TEQ5BELO$@&'73GQ,'-O\C5<XSTS AYYF31[E-V+3-%P&6+3<A=1#0 U@Ua
XM ?F;RQ%^4E.AJG>):LZ3(ST@?PI&,T &-(L\Z0'Y4S":@?YY:U/DH]0L<)]Bz
XM,A@PF//D2 \P"/*D4[N'.= #8L",H)CEK0?0@%N;(N'"V&&KQSD)[$ H("3(y
XMV\O!*WC0P8'!G"='>H!!D">=.N_LRQXP VYMBB3(/ZQ&RX!LL:W<P_V$W4F4x
XM*:Y*1D1S)"IMR)%X!<6;PF:1_H@Y]BQAC$I(D#=N,ASV9?S5_/*H;H#/&I$Cw
XM]?L;42R=L-HA=366SSS(/JLM_>Q\-)C=TG/D2&CH 7H%?FRJ]8V@#=2T<GM:v
XMPDN!G,**%W(/_D8A\B0T] "] C\VE?M&T 9J6KD]+>&E)%(8]L[!.O?@;Q32u
XM)GID#W 0\&-3K6\XA#U+&*6:5FY/2X" &KVQ*EKNP=\H9-*&AA[@(.#'IG+?t
XM< A[EC!*-:W<GI;P4C5Z8U6TW(._-4^/[ $. GYL*B%@/DL8HYJ2$J'?'!P!s
XM,MP2NIF8M!MM6KD]+>&E:O3&JFBY!W^C$(I9WD)##W 0\&-330'R9MY>O>>^r
XMT.!33/B>1&?3'CB=ZSG;< V$AA[@(.#'IIH"Y,V\O7K/;;7!IYCP/8UL.MBTq
XM!T[G>LYPV)>AH0<X"/BQJ4I9BG1_#.Y 4X?[J<-[#J$# 3T@5(R+N]!?TC2Np
XMO3,.$Z&."R_QQ%P409 1&&)<P#'\77IP+0CH ;%A7-R%_I*F<>V="16L!4.,o
XM"R_QQ%P4R3XZM&%<P#'\77IP+0CH >(!E6P>^+&II@ JX2:M^<0?)WE4-ZS:n
XM Z=S/8?0@8 >8#D$V\^!'YOJ21U'N8XC- B@0M)>(=BX?-EETY2-!PF7.CY3m
XML3)]PV_F;1FE4&2BHDT.K=\3.D:Z?&(2*G[D:>4?/S;/AC;?:R TH.8T>G16l
XMQN\,G9K_L4\/%^O@-,[&JFBPR#T@4!10HS=618-%@V<)1!*1(@/P8$6#1?R9k
XMW_@4:@$N*01.L6P/#'^,!LJ@<.EAIZJV>47SRZ.5:B#I%8HWA<T"?'(JZC.<j
XM?UE.R("9C\%H^M5H)5 ^2 A(9AHF!"1S\BAM>/7PC5;"RN;IY9AGS.<7&) Si
XMN*8&I&SQ3,N7#WZ1668XC%M09*!4F*\4$Q1(L$Y''WRW?].G6'2-;#K,!S(Zh
XM(,U/D =D#B=T$]6 E"UH T0$?0.1@(]5^Q$!9PYWYADPI3V:B;[1QM4$Z!N(g
XM!-SR@<& E"UF1/X4C&: #,Q)$5 $@L<,S)^"T0R0@<*(V!M$(YL.\\&=?K8$f
XM*_"[D9:'ELAE&:*,D1<@O@.,:#1KA6+2KM7^KY("OZD=YA,4N@?S"<]9=:SYe
XM";$D[$,,1UN]5.#C*S:&'K0?P\]-%&@K>IC1<U.(G;N5@.![![AH".S+1$\Dd
XM/%K\^2UHW!4(_T8UB,8XQ YB\)[$M2ZT\F>_F7%4F \% 4@:LU @P6K2J2N(c
XM!SC)ZN@FW-1;5UN 8 A(Q@-\4B@6 6Z<QMF!YV*J5F*AN>"+QD18#+X.=F*:b
XMB%:CI&I:;#E2$9/0A@HGXF(GPWP@-F/_>,@>NX &)@<)J4)F9'D@71K[*!V<a
XM?D^! EO3",QBB >FTC'T5;F=;EQ?\\EP%$MO2'\B7].O1C+PZ3T@;"Q]9*!Nz
XMF&F80 9BRJ9J%QF##H70B1E] /RJ; &"(8WY1C(04_#6^FP6\).:"E6]2U3)y
XM0-W(GX*10YW:MW:U0ZC!1)@4\VC/8/I)!NI&_A2,9H ,:);\*1C-0/\\M6]Mx
XM/Y%+HC+?P2 9, , ]-2^M?T$FO3E.Y&4+M1UPNYQI"]16=V0[^!-)P[%;'54w
XMTD +$ QI+.@"GM7TPZH8;+TN[<);@$VR%UFU[E@AT@&'#/"7MM NTM%^:M"Kv
XM.=S(8)W(K_7E.REPF$/+/ZZ+^J7=/T+ LNQ+1E8(E \2L"S[DI&"QTS#!"S+u
XMOF2DX#$G3J.L80CT<#HS+918 [X1R[(O&5DA?F#>=?TP <NR+QE9(8J?9/]6t
XM:(!]R4C!@QY.9Z:%$FO Z(&AK@]\-7A"D%V\XS\\+8  ?#5X0I!==-*X.=,"s
XMSAN!=$"(*>-F#)HV8>2L 3$F#!LV9<B X&(FR1TT9>C,H?/&31F.4D#<"3-'r
XM 1:#<.JPB0C"S!LY"ADZA"A1X!D01IY(H2(EB!,0<.2\.2,G3)LY+EPZ>;.2q
XM3)@\<UB ".,&!,(R9\K@7-CP8<2)%2]FW-B1#!HY6$F:1.EUCLHT9,JPR0.Bp
XMSIR,+FV.U6FVYT 059PDP0)B3MPR3Z-BH8(FC5W+7NE(%E)&94239+2BH5K&o
XMCEBM=-"$2<@QB5NX(TN>-),2,\. <O3R'0*EBL(W==R$WBK<Y9DW9>R*82.0n
XMC,^]-5DF+ D"HD.!R>^F!E'Y#)H6<^"465O187+)0=BD!NX=1&K,F,. ./Y&m
XM8YLR+.ODKGD3J5*F3MF5VFJ-B2=<=6^,!,(;9K@'4AIRN!30?5YU-<<;% IDl
XM$DYLO/$&'%JED5!\2'DX6%D\3208"$F\\,1OP6D4!AQP,%=10"5!Y=*.6"CPk
XM@@)E./0&"'B T ((SIEAA@)_:73""UY@\<(<+U1Y @@^()F&DB#PP ,(3Y[@j
XMD@M#$ &""$DVR 4*#/F'D)9*BJ53=@O1<<=X7=DYI!EI8#2'"&-.P1B:6S;(i
XM5DI;<"3$FCH=RH>B&[%IDJ.0,NK&$&PEX09*7'0!0J)F+"JI&'*@U$5K?&(4h
XM0TU]EB$#2H!BX8(13)QI*:9<:"K"F5 H148=8W0&'!TQ)31@0F.41$<8 MG5g
XMVJ:T@<"<278Q2)&R9>!!1ZRSUBJ"I6+L*D(29[AQ4V<?B=A9>&$$JQ)(727;f
XM!AP1^<0MK;9*.H:XO=8'K+!U$!NP@P0FZ\:RS3J86V?39F>MP71DN^V8^'XKe
XM:1G\^OHO<9EFA!)X8\B1!AS&#FFP:7*PUE&J9<1 %T)#HMKJJ[3=ZZVE<H@;d
XM!(W0M98F7;F-H=\<:9@&'4FL^DF<1LX%39+(#B^)16KK.M69&U9K]5&;,JM*c
XM%U<:=>WJU_N)\<9V30?Y=!K)<5O$H&DFW;+<,F3\9IIR-D1G2'>V*8/<?X[Yb
XM]IEQMX I#'*ORG+=9TYA]59VA6&V:6[#7:B1F,Z0.-WB/A%PL0J/)RUVU38(a
XML<3:H0%":6+EX1+>N>F]>D/ '2PG&943?GD+8VR^^*Z.4\C25I-C++CE7+X0z
XM4N\OY&6'N$-@2&]N=@4]=-&Z.=A9VF.LG5UKRM,QQM<'@N\\K,?KSB6]<\QQy
XMAT;A[WMF]/-&]'U'+KS OOMDT(4T^,O3'TOXQRTH0,$EK2%"H>@BK^EE1T^ x
XM6]I\&"*6U61'/LQ1D+4:)B"]3.LGH[F#A$#BGCOLJ55V@9T+0  ")I"N.E<!w
XM@;D2LA!IE20L.!E05V(@ QQ01#5-Z9Y8=(2%)#2(:B4<TE;D<(8ZW.=@U<H3v
XM">4%D0,U;(F=,1O:(*2VF[ M*PALRP*C93TY$,UH?!E)&> @H+>P1W4684-Cu
XMZB &[GG/+@VLUT "@\(%'9&$<W@<UNZS0B-N16XR?!QF;!*C!;D!.@)QY/:Xt
XMV+V;Y($%+I&/<\)0K@0%I'?W:1\G.X.9.XB,#A'+4\PZ,A(R# LE*PP"(H]5s
XM%S^ZI PB LE8.C2&B80G2&FPB%8<$I%V10PGOQQ#,.78'R,D(2@% J9%W),'r
XM\0R3*S-T20WSF!N-((TK?#F;+N4FF2=(45A4PXEJA!.B/\JIEK+1DM,L*<%Xq
XMLFP^V.L*=:CF$BJ";70FT8K/QI@2.D!-0":3GOVTA\@[Y)*A@:30(,N026>Mp
XMK%4O.Z<\NPB73-G1DK#DT8Y^%*31$,E(6IH##G# I+4\*4I3JM(+KI0EYZC4o
XMAUX"TTS'5";=W312;;+I "&S'+%\*@E":$(7N"4HGZZ4+J 2%4/>8*I,"81En
XM4&W-L+!*FZ52[&:2>H.X7*@@)+Y!#&I0V[7RLI4.'<:AVT'B4-NP'+XD*R^Ym
XM(]1/P^""86$I@P$9B+@4&,CV$14CF>+K*VN6/KVN%*CFVDI?!P98>YU)@:A\l
XM@U;$,#"XJNZL:>W>6HTG*P.&,0F$?6JTXM,5',#@L4(U+%TQ(H<5@L E23!6k
XM&-9PP:YD*T@!DQQB[_G/I""DC13%@F/H^@8;0>XOL[5K?3I#RV3)@7H&$0Y"j
XM,V-;0R+QMT);5E$1"3%FN:$E6)#/<LTF1_$B%@5A($->-"(&OB Q*4MI2AL2i
XM.Q*4I  U@,P#<]LKW,ZXY*HW@0B.NH(9OZP%:6? WB';<"X0Y":^!8;<8?E2h
XMV8%(I@D51K <%)P&ZF &OW; RUHB.035P&&%.9",2$DJI),>R:9K,$\O6^HDg
XM*$F)2E;"4DIS#))>=NE+8>*IF?1*Y"!-Q%(_=/(A<<R?L<2W,1P-G*R:RF0=f
XM/[DMI4F#NUHSDHBH+ G)"L[$9%4QE*# 7"9)05YQ[&40-*\T+U@-XA#'0QC e
XM 'I%GD@,7/"W)@AAR"&)V)PMTV0CW]D.>:8#G_T,@AK\>7Z!5@@OUV"7&% :d
XM:3&@00X*>$ L))#17F9@H",WY"HKY,I_J:09%<*7"SOG,)'$CT.P+&M,8L&4c
XM(O+)(==@KCMT10PB0LIJCJG/@PU)1%JQM;"3+89V3222_^2FL#WKDH\0:"5Vb
XM 38J&6);RF"FSIBA6E=<.2GU!JDDWDP#(5DH!%AG&8NWQ4)N#)*RC-@V"&8Xa
XMYNK:I;I8/ZV6$5/C<,PJL@AC38X&[P]FJ/<T?[O$G-!QL(-._!_].K(O;J"Pz
XMFM<RO8 LF(A+Z-,',Z/LE'G&OFZL0WL@4NODR&1$7>F0@JRR+!GWJ$<T-FF1y
XM;HSJ#[FN23J%*9!G*F0Z&_W(.A63K'K:Y:=#.5EPX(LF&9TZ1T(GGF00F6D^x
XM%80F).$(0?#JEBTWAQP;W6:VHLV;92-GP67!IV[/.O2>OO6V]X5HAT'B5^3Pw
XM\%:''7ND=@EG!-,9O_AD3$D8,M;YXFL'0_Z']VF#A)[=D O_!:++ZN4*('*1v
XM-_3.?O+YIEW: "PXVB4/P*$(5R:8D#"LA"^>E8RF&*KB:5;D\["O0V-&(Q,Ru
XM7'XGD#EPR0[)'%0B]@TH \$-9 "#)8  !8&\I/0M[6<8I* Q0PH^DH8T0^Z$t
XM8>Q(<]^,7L=H(N[^/>&^"H [<QLN(GK<=[E(3BR,'XU@>SJR\T^QT4T5XA*9s
XM9TGE)#OBIQICURQB$3'>1$)Y,1("L1HEMFZ,-G_OTES451EOI7(YT6VGE$JOr
XM9F219$\>U!@F]"%:H1?R5H&!]1-(9!(/EE#GM2P'LQ<N,0=H4 =*@E@XEFCGq
XM(5) !R0U-G1#EC)CP&-)]V,R15-)*#Y0EV13MV0XIH20A64)P7.=809*L5]]p
XMAQ;*HA1J@1,7UE[RUAECL&ED1P5!( 5)H'8NP&57*(5;( 9/$0.><H=/(0-[o
XM. =UD!1AL(=B1@9R6#%X. >KPD(H(07]QU!K:'HJ\H6'E(@@X&F(0V400X:Tn
XM!7<BD(A_PXBTX8A7AD21:&1>B"&5^!0@0'V9R'6;V%R=^%5G HB"*(I20(H1m
XMJ(9LF(I@.$>WJ(EC*(MBX8F%R$+(B(NZ"(F]2(FS=XS">#"<6(QVAW=86(CBl
XMLHQ(Q(4UX8P,-@9, XO#6(:))RN11UAKH(0N86O(11'Z$3M;:$$2-"%=2(FFk
XMR(:V6"-LHQ'4$8;]-(ZT)4%_(1(,18];,0;6=6MGL!>286YV@5\ LE\-!HAQj
XM9%=QM!:^>'GQ\P)RT#L^-U)&*'0HA6,#R80OY81!5E/M%Q)3N%-5B'<#F84Qi
XM>8;ND884P8;4$8T&18PXL05!X(9P*(=TN)()P8>*N(>@>(C>DHB+B!)3P)+Wh
XM*(E^M(J=1FDZ.8TY0XN?V(>X^)3&,D4XV2#R88FNV&JQ2([5R&0QR93BXI7,g
XM*)76,I:LB(EF"9#46%JEY@+G2)0'Y@;!9A%IH </!)9PV15R696(TQ]EZ732f
XMR).I,R9-P!@G@%Z]-Y6F^(ZW@23R^$_T^)%%6%)#@H2N- =-8Y(^%E,I.7ZDe
XM"2$M*75D8H4)TC19"%@<PP5ST (RT 13T )$\ 138)LK\#<?U5%;@%1*Q51Pd
XM$YL0DE6A8BEL4"I=Y5%B1UK=DB\,P09C=4.C0X&"I94XDXW 94;8 QT3&"P'c
XM4EPB<S!S5$>4=$=SIIPXX9P@$ 1C91D)H11GLU&R%D[K-IWS^9ZK&9^2@A.8b
XM@@<OD ?@*33BB4;;N87M24^M8:!Y@#YX>7E$ )_KV']V46;"$1$:89P@  68a
XM$H3C5BWJY*&M5G+!EB,%:&JWF9N[V9N_.0?!664*)D& A5RL>3I0]'$<:A5Rz
XMP(^?$S"2H4#SU%$3M:'$QP8:45Z1- <SP8,/-"1_,3WRV$"R 44M:!I2]$8(y
XM]**ZR9N^"9Q_XV#*86U0RA(@0424<356@UYZJ9JRZ6MQ.IJV!@*^]D^7-YKBx
XMEEP+%4< Q6GN,21(%%&= 9'ZU9 DA*A.@679D2Z[9@;!T3T7.*A((1:"L5_Uw
XMY:C"%D(L!VZRIQ9D@!Y(XI]W)2Q2$Z=!T$]A8*8,Q:C[A30:9SYX-II!@!):v
XML2+9XA0U4@9:D4F!:JFT"FEF0 8P$%)8, 4O.!-RL!>H,20,V!E %(Y^IZ(+u
XM=HG[)Z.E*F%#(% =\6C-DR!#0!?_6'S[AT$",1'_\ZW.\P)H0 8N0QM:(8!#t
XM0ATK(DY&=7AC=ZI$-&,A&9HCF2"V9II*]X1-)["/F%-4^)J$@[!7!F5W*A_Ws
XMY(NU":8Q.J8T*IR,)H1'E51"F9QS8&O,*5584U4^XY]BXXF6$@8Z,P5#D 21r
XMQS( >J>8<@9Y1@9V@"7Q]3QGLHSWU!HVN[-T0;'3.F0S^X@K.Y_^L10NT#L^q
XM@ ?@>65!X+(PBTBM 9%-.[24J*^=09]C8EKF" (7&K+]EZ'Q%46=89NX&:8Rp
XM2J:(]$]]>AD V!@X"*1"*C":X1)MBD@351U^D1 :EZ8\J!7E5VV])+BN=TA5o
XM6DQ/@QY4&[-]%*T,Q2>%-P1$P00MH 5T*S(TDA'S>B 5<5W!%!;\1P?ZT14Un
XMXA<N<45F,!XRLA\0T;G>-"2LZ[I>IWU(Y!=U8!&0^7,G4W\E0:I<.UJV%+:Km
XMB@45X:KWU7&-*JN?-ZSA.@>W*J_4! =B5I',EZ["RJYX5JS'2AN2H:QMT"<1l
XMX:R6*KE%2V766JFK4D/:.KS=FBG@.IKC&BT[N*3TU1GHZ@;JNDHMTJ[O&J]2k
XM\+D:<2$?=Z_IM*W[.EW]^G,^\J\VIII]2K HR70UE2!]VII*UK#N<TII*RDJj
XMX<&'=$_*,B2SI[8P*J8S6J,D&C$=>YR! K)].K(K:[)M@;(7A1$J*RDL>R93i
XM^[*0J\.-Q:<B+$L2VB5Z("Y7(,(_VQ%ZX#]#0F7#$Z$'2J$N,#AH@L$BG+2'h
XM9@9[EW69TDH" <4;8;$J[+9-;$16#+9Q.K83_&L>++<6E01B#"T%9<)=@<)Lg
XMB[$URC**.DEMQ[']L;[4P7H*4D.9NFQK\4^2>\)FW+89BT@[^!A@^)S]QQ>1f
XM5"/MXJL5LH9UH)!MU5X2^* ')2W])VR!:*E(Y,<N(4O#>ZK%JZJLJKR+RKRQe
XM.B2SRKV09JNX6KW7>Q%:%ZSK^K_=:ZS(*K[DVZRX"ZWG)ZTHJKYFMJ([E*V^d
XMJ<"=$;_02[_DJESX>Z["[+_@&L"]3*\'W!_XBA.OS,">^<"@&<&_0L&H:<%(c
XM(GP*ZY(,BR;"!V7&I9Y4YA>CA)R$4P<TS,-S8"H#?9V98L>>,E#0F1(N\- [b
XMS! ]+ )'(&'^3+HK J@LHV75:3'769\*DLK#;,>F;#2ELY[#^441?5YMZ40\a
XMP9][,6?"US0@[:!^QR[NXF#TQ1<;72'R)-.0E4(0LBI-PS@4+6& V 8\\46Wz
XM6XX))-#1LJOC2RV2M" X06'[D=*]I1'[3)!R)7+J:2TX;6!88'I"8[UKL:FKy
XMW$>1M!Z?I]61<R!4PYJ R)Y'^D7K''0 >R2@"<]+!X7M7,^N277MK,_I^97Zx
XMRT1.=!L<S66@>=!NH-")I=A/1 =T\= NL-)N("Y3 5!=:+N8,2R@LS7K)AMYw
XMU<Y3L"PN!P6J\7DQ("Y<H (H\ 11D-IF%J*MW1DN(]M#$ 6UU-49<=HU9BE=v
XM@00>)%:V(MNT;=RE%]LHT-N_?=AKX5E^M;^?'=Q?FY>15P0U)H+J(L=+U$25u
XMO5T_BJ*B3:1Z"Q):MQ^+VQ002&N:QA6"RIEB,=46I!&>E;V3TKIK$1Q^ J>'t
XM1MP']I#4<QN*>FX84D7^9Q<ZC2 C 4D6 A+Z-P<A,S(BD=<0C(2 @70G&<^ s
XMK1&"O<$BL!90EA$B<A, />)AD\/4V69R!V=E4'>R4@1WI^)+>P9-*RY%X!QGr
XMAK7CPU@5:FH=L>,O8Q>2VA +AKUE$ =U4#06D9E(4ZAUBZ)6< .KP^,WT8*Cq
XMRD*XE1#Y>!->34(V47H.=1C^I%TZ,"9(, 5CX@:INBP@  ,N4 -I$.<ND -Tp
XMG@ ND0 HX (ID !AH -;T;G%@05\[@(LX.<), :"3DP#D5R'GNA_3@:"GA<8o
XM$3%[G@!E(.@FGA F<0=R$RL)D !F(.A=G4@48BV=CI&M(NHH$ ,L0 )_?@:"n
XMOI!GY7L)#C9[WN=_G@:"[H IL^N([@(K$ -_K@:"K@8'D7,O1!)AD4["_N=Km
XM(.@I$NT)P :F?MA=ETS+]$/%)$2S=H+=P[N&WN>2G@!M0.W0!^GFKNAPD.T(l
XMD>EQ(.A,GFR=CN+6+@>"?J>1].ER(^SG/@>"7M<4:+J87NZP+NL)8 >"SAR\k
XM-1\MB ?!0C)8AA&BQ4$$LX7DEY\*YA"[GO!_?@>"GL%^M>H:P3)CPB<\T@3@j
XM9)E3E.O:)7MYLEO",BG] 4'Q%7;)\1=9 3D5XAPWLLC%4VX@\3IE8 :MJAZ1i
XMP]XAQ&"H:S\'LZ;GP4*4X1>)]36$3@;;=9G7E9FKBQT$G"EG0!<F)!%1Q% ?h
XMP8%OFT)'G_2:P>63(8'YF1NM.VM1/D68J9X-LQEZ016UI%Z\BEB=+FP\3S34g
XMD=]4Q-CXQ*7\0>;"AD0CT!@"QEZ2X0)KWN9O+A]R3N>M..=IL.<D]Q]-FP"1f
XMO^/)YN-[/@,L0'UP0/HAJNT8KSFIH10RISK4M^<OD/88\0*N;P3-(4.H8];Ze
XM,2=3V1JZ/QM2L.=4<ORY7QF[[_J.J,ECUA''3Q>;:OS.C_Q[;K-"X(.H*015d
XM8 0O< ;0OT8S,?U(Y8/6SQ>M ?Y&0!>L Q=;DQM[?@>NO\3J,KFM4H)KL.=Qc
XMX/I%  \DF^^"Y2*$K%!Y0BX)$+G50N"@CXHY>1*'(/V%@Y&&#L8TL0,6H0Z4b
XM =W3(,3/2E!/UJT%>)';L!;NG1Q #1VE-60+9&5(/"!7J#WSP4-H!!.H%7)9a
XM$O @R,];W4 VD&(*&O7J#ZUAJGD,\$6$V-D10BEE(+30 ;]FL+)$$E0K(>XEz
XMC3@EF(6>H&@)0QR+8FD2_[0%FD 0>%E.@ KX)B3PL<Z$%2Q*)PM[F J5]>+Hy
XMSFE3@CJ."FZCC85_(LGP^C.-Y0RVHCBH5N9@(*N#_4G"U(WL=GF*@!+L-B!(x
XM#_I!WH)_*%:A$@_*A$^LA>&% OK#'?0*#<)<O [_A!FXG20D RE@A11!O1;!w
XM<" 33$TX4(-)P50(98H $V "1:"%> A!Y4(>7A&P#HUM4+!"%L><C,C,6(/>v
XMJ0W&&;=1XU*A'Y,?(L"VN1P">.*R4I!K#45 +10YQ14R\(0(A!JV8P86P(SWu
XMVQ09X5ED <>HW,)VX7Z0Q>SI='Y+/8R,X8)"H@U8\%#_S>7A$@[!$,Y :OA5t
XMR&OV?#F7LRH4TUT0#E2AYS&RX5%%PDD",PAW0@Y(*CG2NE;#\",B02"/=00<s
XM2!>JR.Z2(Y@APC ^%N-B8 R&:V<:C@=:AE,HS_1"#U2%]\PD8H:KXU90%4/Ar
XM#!)!+Y0!OI!BKEPS3'$JT:)(@:AB*1R1'+ #584G2HHSLRS&7G1"":#"%V*$q
XMJH+95IH4:$M0B838&A'X2,()R;A *PUC- [5!KC@P.I@/3,A!G4,/&#%VLR p
XM$A=4( 7EKK^00W#9\^H(*29HK+N&5B'42'SQ3D.Q+7%%FR@6"002T8AMHBBNo
XM-)Z5#/=B*H,,,L$"'8;6D&*L&!;+B= #4#'#IW':1&(#Q''($!U>+='WXYXBn
XM(4R T; '3D/U4@W;A E4-N/F&VH$E&%7=$[V" /A,(>0$)C(6S""ZTB C3&Jm
XM%4#=DQ!:&PQQ ])%J8&-GE>>1,9"\#]=H<7,"(_H$IZ2_F(#!JPUC+LSX ,'l
XMV%CL9:V![HVS\@$7*<E<1%;^"B0B03Q $@%;D8B"*;%(0!G:*!,Y#';@B_ANk
XM[9A!]4@;A")#\(E ,3K91_74&HJB#=N)8H,I0C2\>!^A(F+C/_&E)'R=JU@2j
XMLJ)>O&V'$2PJQI^@ LDBD.MHW^E,I$7]LQ:-BO-*6]U1+J*,C&(7C0^; 2NWi
XM 2URDC+C<@;?8?"+) 0PSKPS,!@?I,N)D(E1+#+&-. 8=2'4FA^2D828P--6h
XM)'R<N-",'<''K;%2 PTM9&U@-5?D--*+U @:0 !KO$D)XC7&QI<H%FKC3'0)g
XML$H>-@9!8C5X8RW9>?4'>\D'UK-KY V*60LHP_#I$S4Q$?L'$<0"0:![7$3Sf
XM52&GX1F"#FK@;^FW_M4Q+&,O@U2J(SZ<EMR8$B*12>"-> 3F:3U\4QS3P''Te
XM:<KQQ8" &-,<18=%B(X=83I61QV8$[%C1]".U.N?[$@1*1; HP,CA1H.#]"+d
XMXL#A3M-?$S+98E:"."1CSPB;K%25(.QW+4/)0=[H1;#X$_EF#OE(70G9^B.Lc
XMHP,R0"M@-H,6+9(B5Y$"78! 0HO< BLTI.2@6Q^B1!"-DT,,YZ.NA"PQP :Pb
XM@!D0+6D #F !-H &Z+A?R1WI&!VX-63OH8@7NQ#_^$*ZO!9LP(FPM,_8))DEa
XM&3%_FTQ $$N?-H.LQLGK(_GMN]0[#(@1U),;<"(+P8RX!+%F+*<>B\B$)T1Iz
XM+!3 XKG"V+T<8PQP\9$;%F)(%"1_2B[BI9;(2 U$<? -6 P(O>JDB0BBMSW:y
XMWLWY>^[A6_9+$,!2E$O';& @23SR-5D9(6IEP4*%3!,E^LJD4 4IYNYR8;E2x
XM3K0/K!C#S&5\Z@@1X2<TQ6 H!>;.,$Q+>* '< $PD"OC$PDH$BO@$JU-G2%?w
XML%7ZD7!R! .*C P#M0CFD&.:#$1Z!(S!U!FLIDL4$4M/O&4FN!7'& KU^)DEv
XM80=-N2"U((;4VP,!>XMBXH4%(1[<VTWH>2<H2!D5:R$0JB%+$#9)(4ADA#F1u
XMI_8#R<Q?'>(.V)8GT#E7P^><#[1//.PT$+ ',%L?,#_H!Y \CM09+/*"WOACt
XMG+."/(VEM^E  !_0"B9 *^P!'J 5>$ /T H]X'J"@!"@/7U ]^P#TG,%"!1)s
XM 3Y!@ K0"B] *Y2 L*<#) ,4@'I4@^?AF\XYOL;-J!J%&0ZE(#U94QZ%S/X\r
XM..B1ZOQ/( C"!BA.>$:V X>8LO9!,+J"#% !*F &O+:N*0(,:$+#F'<)0PK#q
XM&%<N*Z@QZ0\TP-+$ -=B-]33\K))!O2DA5 8,$+QX#/L"$;@@]+%KM:.C N%p
XM2*%3"7&&M\6FGB))Z?0\PN8FY(7:XA** ,&)#K(FNGT%&;%Z6AX]BAQR:]")o
XMAXAP&33*Q:0K8N$C'L$C4:P83?_,$EW4[P30)1-&GPP((V2&R?Q03BI3G#Q6n
XMBBNCD T-!$%JB2@4A:7P@9J"CGZ* -E5V"#)0@.<#8/B!&M!94#"V:HE<_1"m
XMNCB2A2Q%@!,0I%,IXLR:SND>@LBUF6-V+*^443L#P(S5O'0*[Q&:I0QIQM&Pl
XMV":U%&@@!W!2//.N+HT("("@=%)0F?RF2@VIUBM'5P!>9 HX&BU8)$$*1"'Bk
XM/FDHAKFHHMFU<B_ZZT#8%$V&%?+-SNQRV@-U%;@>M289@O#Y)F2.H3B8MH@@j
XMD@1?0*,];P!UH.2"1H/F>.E'<D,K](<.<662C18D)RSD?8[2DR/S]D^*  SIi
XMQ2[T+CSE$K25.4LG\RK<I*#A84PD3'^8(9*A"@ >"KDR<,PT_ MLP RT@%PYh
XM$[#&T\@#ML4E( '2@#(VB_Y:"?OA6&0H-"ILPE#^D2/)Z_.(&!)#'4S,\JDAg
XM.N=RN@1'9#;.QN,+,&IDO[0&>7,?-DG$V O;##,H.-O946"CP'%T#N<GE%.Bf
XM(9CB&E<K)O?AF! 1%Q"9\%2^X0(F (5A@2*@&%P4#! H+TI$M8#%8)N^J@31e
XM8Q=K1B$.0"6Y8(?7>PG&M%)=T8Q)^,Q#*%%45H^T_1UA<S/7X;J@9&>O4#T.d
XM'.-190_=DPF5#VP9 ?V03K":K^I=MT16JHW(H7_ J:5:" [GXYQ#QB=)>6:Fc
XM: .!4SBRDW<A9M"  3H+K*:<#H]]FJ<"!H:P0&D!.M"^F%<?GNH\O4 ,#@Z b
XMU/L9]SJ#Y]DGJF$ZU,VE&IBR@RN1(?DII>JOI554]@NW<5%K*ZV658037,M8a
XM=#UC<V"MEIZ@)]1N6L?T:<%!AS((EU #>$@+J"\N3)+VO/F''_2IK(A,+L%5z
XMQ0#KLQPD$9OJ07%M0=3-N3HZ&X1ZK261!;\T5U?SI:XK)$,<G&5$C(C4JA0&y
XMK&#8IXJ*0)02-!#,SIQ&\(T+H4V@F =HJ6:K1H"L</6VLJAOXELX*U<LJ?*%x
XM>CA5CL$Z+$1QY8 @(/B@,Z[C&RWKBM BJ@.M8M>U6NBH*F/P-2Y3>X!8V:"Dw
XM@ .3VC\>=BTP"#,@&5J#$7"HT<(WR@>]R3;H0#AI$.>L)N 'TT4]N&%%.#;Kv
XM D_ -RMKO19C1Y"C=S(\;M&:P!36R!=EL_M&:I+1-NL5H0S24Q!T]HW26<@Vu
XM!LP &F #YR4_8LM>.!+2TQGX M=R#Y$9@^(3@B(?Q98@8&R>2.O4$/:.FH$At
XMXL,#_02,]T^"[*E+,P>#<.4G),)!5IH7\Y8/K]#Z!"-'B>[)1$&.C2]VEE3*s
XMEB*U)2 ]$T^@?B(26SI$NI$JZFK#8J5AIS-!5A*"JWU3CL1=N$S-IN..Z!7Ar
XM.*ISOL W'7I%^*LSQ)"2HI':-M,51<Q79#EO:P;;,@3"V"O>1)#%>.6GXVE:q
XM34IG04 )N'$YCE? OA?BI/S287BW1*-<L-LX:RD:Q)1D-O 6&5(!FK>Y5JVOp
XMU:E)TAMF4K_Y3/9LRD23%!!["5;A81?H;,2;>%])P@(@Z/ 7(H)Y0"\K N/5o
XM6V'3?"H(Q&&T \$NS)W\0P9"5Y,"(L9DB/P7"9)LA&KK"0S2(8OB3Z7Y[YQFn
XM!8-"]V2,GHF?!<(@PL.3#TUDY_F\;R(W)E/URB(L0<G&"VP!1=[H_GL6CT/2m
XM:M"R">-DW!6K<<1ELM2>VG)K*9H&9*!^L9JT#8;K^Y;BP3RD:\V,T)"P-,+Vl
XM'V<J94C#Z"939VH[+D(:" OJ*>FB7;/16:KK&OA]UN*>U%RH /=R"\@9HC\Jk
XM<A#>L7L=3$//&P(["#ATI$-ERWH>> DNXP798(V#HA6DU(2K<"1#(!Z((C 0j
XM,HCJB!C:0HN*)"[:'-XLY=J544?$W=XLM'M[VGT("25594Y=X2#-K&Z]'$[Li
XM;R(RS9W'-2?MM]B@7M>4_KX7P(@D1=]2+ /#4G0U/\!]NZ_W_;Y^H(36'OW3h
XM&K"O98L64Q(-E-)!L7M?@%^0 WE&080 R/+IC(J:""L38<3PSM_)!?IO__4"g
XM.P#\>E^=X7<6 N/A/Q0FQ72G&<=^I^_[#6K%%00$)\1A*<!+=<A9>^!WO@!Df
XM0R']+Q< P-]77"3@+M1'L@3UT32<1I-.WTA!?Q^'^84L,</Z/HXU80;:@ KHe
XM*S18IWZ?"HP'@H2%V2\9V -_X!T@+OZ&P;BE;+<YT(7RQ! FY5I#+ 9%=/C2d
XMDGH@9:1^NJA1II<\'BR@:U2'XI4B! +YTEP)2$?@VE8X ^9%0<B'U GT+ B,c
XM75XF+N@A'#F@ 3_70;I6Z8;FN0'/RH:O5\*!(7QA(?RCR*8VTEKR)5EA@"Z@b
XM "'@(3#"[ $;,]>.AA5%S(@YT.RY"=_GGX0 E["(&S%^Z HF 0TOF%!81(]Ha
XM'Y;#Z88.-Q[AX"%?'O&EIYYP'^6$V.E9OX("/2TDC>:T%0-60U; LR!C]^$1z
XM T<KF0$[0YNU(++QA'4$.X8/6P-Q \:?F#C0Q&*\0-L(5\#%O:P_!$H%\8NCy
XMA:[" \:D9RQC9&7YV)RL@'-R3@9POD$# SZ?K'!S>XZX/8XYD  ,B@;$A.ZHx
XMZZDGEM&W5B(K4<2E,V"R%=,K1QS*D76Y<R %Q.-L&X'=0#U6Q?CXGC!54H))w
XMK=^F02\)P%((!"<B0Q[R/=X2D"CO&=M6X7330 LP%VS%VB+2<4P;%C)#: ,&v
XMR2';8U+2("A,DO##E<H@Y8:P*&&B7'V((2C #EZ%A+R2\VA+-G3.*5W9!9D,u
XMD4'R#(*D&T0IJS(QM__\L5%.?DC9^I:!A%@3/#)-UG^(!3/4WV0L$=784<[(t
XMDH)^=N29C(^?<!EPNO33,LA)A:!#>T!"4\3=^$GZ--.S+-B 0L[*UI0M]@6Os
XMW)9)2)/3"':Y-4"UE !?9,AB$QEI@1@'3$Y6?C#(4NAW5N,OH^5ZF#OG V%Vr
XMRC%R<R;FCF 4&;-\N*)BX9=)YCJ,7&$@4P .7G&B:&9+068[ QY( .PU4SC)q
XME2P$Q  XDE2E^?K4UUXR3("(5F@:[K"),*MTJH4.<^D-"1$&%+ID-X 'G$<"p
XM.*[E)V0D"+:78HZEI>JX'4EU@+7W)I$!:\ISQ^78)1@!6405;BK]6;Y;DSI\o
XMV?T33ZS%*F//9>X,H 8/LFVJ*])P)=U&ETJLJFSD:@>E4W/FV 7 8\#L!KI:n
XM CAU;AG5U3RZ!3;,F^6<SN!%T_7@\+)<]5@2Z*K3U<)*S]\9>5U-A)XHT_D-m
XMK($'_852;TXXP)]7+)HB27F>$?3.7;-\@CSZ7 _G/]/ >>25@XV,^N@L!'B5l
XMY]78RHB$8C47?M1NE.GEZ# TDH+FZ$RQI--8FJ!-K<$'?#J913;-)@=-2U-Zk
XM2<,),T";M/16%A='@(*XMR,-ZI3TD?TG:8*C@2TGZZ._!D):(P1IZW )*+VTj
XM?D7QA&]QXY_(Q1M$A[L'<G$)_LZ/L<P%>RV4FKT:9&7@0T!A0D5P!S1&T HVi
XM>4M@,CH0]M3-#FK"#"5N\.DZT3<TBIC^)XFZCR"-+"L>)/4&= D*5=C(#">Ih
XM@<0TR^C4HVQ/VR>?$$Q_VW:VE).:(ER8)3@U2$BJQ@BV93WC!*G6J]*<K+A\g
XMC&%,+P@FY6JW\CWQ 5?:/KD$%A*FJ?7^R]8*PDS? 1E@HW\-""K2:[KN(I9Gf
XML95I1D&IKO#!>'Z2:3+2K#5&N9.RQ+&"'SA0&2A0T),1ZD$L6-2>[+]R]#2\e
XM6JO!(>"JBK)+ZW2T"++KA PHC24-'JPL$"H42//GS"$H<(F,X.QM?,9G1]]*d
XM,"JFA6X%%=-V5DR[E4U+.M[HDFZ6+'G05LM'ZRFTKEED"'E97&Q44+>RAX^1c
XMW465$V]Y-N5 G4PIRI84-L"5KN<CNVCQ9;1 &DG;VP41J:I);76K.Q-+>\4Ib
XMQ=G L9&&:Y':,=>,.#48^K*?-LV+E&@-O D$T.$(C;7#1"25\&O:2Z<]P X,a
XMR)P4G1 2;HE]]'W2S^2\6\5",NSL^*<5,-[*;L6SYR_F$Q@B %G/?D$!>0'Iz
XM_4S7DHG+AE+@+6Z@+^7=F^-7A[:8A B-FR-73'NH.C85L!.+_NZ*$).I/41Dy
XM[UZS4:O!]B88 F&R$UE"X**S&P:VL,[01F&8?#S9(X9 [,=$W%7V8QPP%4EQx
XM"NAMB] +UX 8F,BF0M$V)TF1LZ+*:+(#LDARZ 4ZJI0H[40# 5, S%6(8U)0w
XMQPYML@C\6GO/:V#6FN';1%YI<4!<1($FQY)L<O-L.R,#BAY>7-,!8\]" 42Yv
XMH4:>"2O07!:;M-#><B3G+;*>G=^T5:$%%EQV[3+@H9N[=78SVZ6Y>PE;!F8Zu
XM8:QIU0[>"0%<Z1EQ8;M;3201X9+F@]\H%(XX9D#2%A?*^D;-TH?BPA'L15;At
XM!&)^)0CZA+5SMZN143@\A+>K8K4J6D#.DE%?@ @D@2FP!&"X#_\G,V$AR)'Ws
XMQ6C&]C/)X-$BC@1$B!*(Q,(VM50E?'>7PWI:P@'57V!\<*8%M"J20&*6$!; r
XM,2^@IP:31BUZ+="(K:YBM0D(A"&]#R_<HCZINYA0=122$!B>N&MMXSUOJEG"q
XM,..=$<?L>R,@0/7A8TW"R-=%!!;+;T P*84F2[9!>+[4/Q\BR;'OG =Z"G4$p
XM=Q:/#&,A#AHT*4$R+DE@VZB2(VI%DE]U[(%%$I6\<*>!AY?-=G@VQ@F@F:SUo
XMW^D];H?63/@)$\GB%!&0&4V4R311O!M*;W]"8JJ&)*5GP^">/%H89#; ?L+#n
XM3 AF3T3X/(S1(&:&4!%!;(:)S$6.0PY;<7EWGE+[QW:_MQ:+"4?(3%0)[P0Bm
XML)7\IEXBL+70Y&^ DR>!S^ 3= != -\8 I!-!*[%/*N#B7,WYR78F(80T140l
XMI>SY"_;\_K@P0Y80U&VH]D]LP@7@.%$;R9.V]1'C/FW0Y"9KEI#7F10LX2D;k
XMA$\9.NC"?!)0BD,N6Z;[C$KN&,&N#Y]?GK2'RW1- AS&"]&0MKN[',6I&$X@j
XM"CD(7[$H8V]?$(T^H14WXW,>Y;Q(K9$F'$0U"E9W%['XP8PRO[-(<O=[6ZC/i
XMQP"Z$CJ"6(ZZOP$*9GT2MI^V<GLBI06,)%_;H* I":)*U2N8])"6=(7L+3&.h
XM1V9/#6EP,<*HX-AD"5_3RX$0@U/ =4<PP6"Z3(+L3AG!H3/4;C"7V;/0J9-8g
XMG-TDY/3*WN)N!O3MH)0]LXO?$1;:J=.<[N2DG2[04-:.V=O-?0(;JJAM=Z'6f
XM;N1:A5:XJM_J_;X YB &7D!J?Y0\!Y90O7Y-7G*$?3II:.U8;LPC@CK:VWV#e
XM;];M6MQU>_L3@FP)* &2'0EE))'=! ^NG!VZE C*K.V!H1HBZE22#P;#)% Jd
XMZM"[RV %3>])$LRQ0:[K!AL+Q>(W"8$/@!^7\[1@^/* (P?B0K@<!"HOA V7c
XMGN#W715)CMXAX'F0W:B?2$V7H PK3@6H2A:OE[Z(;#0>I./L0L(X01H;EJW$b
XM=[5Q@:XAV\B&6.8GEO,%$7UF3Q%()R8A;V$!<P)1N/IAL X>B).16NG@T+'Ha
XM(!5+2&%DN""\/<=0/)A3[OF&Q_,3?:,ZBP9?)3A@3__)W2*?,=][DA</U]PJz
XM__<G#[[@WM[*\1D*$*D'Z@HC 8;0ML^ Q,<K525_18Y#=H 9O*=!#PPXGUR"y
XM!BY1P'->/#0,3+U;4">=?R%E;R*T"Z7 0&<0W[@):T 4)BM/"1W]%TEPE4D3x
XM1U.X_D?>4Y,9V/3GO8*">GV&J1(,(G$,.56[$PTUTA#L2J!YHYL>LK4+-M &w
XMS(@>38I?'?G5[ 'I?%>6SF#GZUNVKA%F <QI1T1G]<I$@HO;2HMII P4MT^Wv
XM"Z)(<UELDE%R<M"6PU8$%%NPO-6N\ BLHMS>,40,S=/KSZ*\E1Z 2S"OB'U#u
XM["]#@RB=SAW9,[6%PDAZ[,UF:<06VA>J+BX'AO-$X/.GGI)I4E ?SLB O&SVt
XMJ&C_H?IQ_W&@U[NB 3URZ(YZ'K9*(<T(]V' _I=!ARDM%I3"K*$.T$O/1'Q1s
XM;V3D$[CR7C4-$E%=@F0MH)?W&OF?ON3KBU84R2N^NR(#,P#0.'LK NT=/LY_r
XM&2>9@=%\$Q#)K;@1B/7HM]2/&+N^ZE/)&'#U3B:P4N6V#EA)ZZZA'BHFWP#7q
XM=3'M)V$E9[SY)I>:QES2BD$D(J8+0)"8NP&Z2*97)+Z9F=Q>\N541*A_:@B[p
XMYR+^IT%T_-M)[PTTWSO =#BRR>J5@?13 CH=SZR.ZN?47LW16<66/^PAIW9 o
XMH(8$%Q[?D+C[!Q1!C)R'J?@9/F:P"H^.]JU8'O2SVW<-R23C9EY,_L_8X?D/n
XMO6!-2 0_C>3.#QFNCT7_LH5K%2-^4)BK((2"< F5X4 :@57!6^S+"9%KBVISm
XM GP (C[<+QS@0K)=*1S+^]HF%H*\6!?\_HL+(%"MF)^_!:$+^;;PJ%+'8V:3l
XMP.&]",@*X @<5W)3+8-H2#;#_PR;%TL5U<T S"$0S'\,.'_H'V6'!P;T2U**k
XMMSH!U!'X=VGAGT>ZE*<^])]:<VHJL9[1\V)PGD 0< 62 !5  D^@"E"!\1-\j
XMR4P>: CD&&PY).I:\SBNB+B:E2J26'3Q,Y^#<E?XGYCZ;WV?W%!3$P)U"QBOi
XM8]G]!/E 9O) 0T!6--5#B$6Q[+K26I!H56_1B!1^U]_N0S772;#C)SM4YCC1h
XM/3(Z"C (6[.N=+*;X#2^STJUXUU!PL': P07BM2R^PGR@<SD@89 ]DJ_8' 7g
XM2 0%&(2M65<ZV4UP&M]GI=KQKI"1L, !ZBB&Z]\[FU"=@1R$U:/#>SSPD)!$f
XM/WXFQ?4C_+T$60F!FE-3Q2)/?>@_5?L<H(XR<?I>?)EN#\6Z.(T*8;LKE6[Oe
XMYI$>FHIEU2E*!OF0./]R)/_O_^\?+0QPA<'\[MG">(C9_U?G_M08$JF32RE8d
XM\RZ7FUSY=PP-@8'$D7"3_79IX:\E@9^[\SWE*K\"2"#B_X:_*FZ%.&&H-3^,c
XM+\\Y5>5R)JGH(>C ?PG0;0+S!U\X(_L#_N('.>-YVC!J0*0DQ,R+IP,[@.5@b
XM<F(MWW=>1##^(.#\RY'\O_^_?YIU8%N&8\< C_VZ1;$N>;.B>)R8;%$\3J",a
XM*!XG(FWJW_DT*H97A%X_+^,K/F\V"BJ*=0EDJXX+C95HWF#Q!633?K23D'8"z
XMT8$OT#0@FQBP84D O28'R&8&;-C6WF;+/EQ<EN2 ]QVSD9]*Z#4[4%)P&^JTy
XM)>ZX+,DAL-AQ#'2D$)2V/+4BH-Y\GKYE+< MX%AIVE;SN@ODFU=$L2[9.VI!x
XMM/2T2**@X)$\&=]#PJ0OD<JK[+&8*!XGEB(<Y0Q>,3#D2GC&'N">H:&$QB**w
XMQPFXV)3=QY52@4$^)/"+G^X,.:#Z+)'*J^RQF"@>)W<TTJX02^%-PB9D$0.5v
XMION@Q4$^)/"+G^X,-<#Z>-S*8'G+D>,-;>&P*SB8A6BIDH5:N((<<NK?^30Ju
XMAO%\?3: ^MKC5@;+:Z*;PGD97_'YV/ %B- GB!['R2^-*EFH!4,=RH0L%NAIt
XM;0V0:%YW(88AM\]4#XU.)'M[N)")#T2Q0"]40R(Y&\4%1)9(Y=V RWU= )$Es
XM4GDI<C1MU*G3L,B(0E<'-"#MF"__QC"E?HHG5.,+=6%FP9,$%Y[6X +J@ 8<r
XM6OM/$*>7R<M0K/!$OCZ1V^T).I,^<Q-L8RB=())<K 9=PD"PR=S##\ ,3'83q
XM,=,;_1Z;S+&L!(A\\@1>-^\>";[4W,'OL<D<&RJEAXI%"71?CG23C>&6PYZGp
XM8I,YMB/4 0WXR1-XW>0DYD4#363T,I_)- 2_FAN09;H3MD"RZ.36-N:<1&;Fo
XM$PWD<2N#Y3VIVL08+^Z&&4H:-D;X G[&!=0!#6@JM_878*$NH YH0/@G/KH+n
XMG2199@ E#+CV#?<;9JIS)^!'/[@+,9S,F2A#J3:?9Z*$K]+9&:S<Z@[;)PT0m
XM*8DA_:>R7LE$(M7F\_0MTF^NRD^V"!;XU,JM[K"=L0,%QVX!F\]CO^YG%U'?l
XM[+-S[R;[V;EW*+,2DHV:Z1/ZS9D1[<"H=G$'!7UV$;47ADT>>GZQY7[WTM&Wk
XMQCV[B*K$F(6Q[0_6K1SM'H+<&% O05J\X">JIJ&EK#I%R2 ?$O1"XT"8GFR8j
XM!7,8Z"?KQ%V@>*6_7RZ$\)CO;J#TMAZ?=[J#[^X^<)%2M'*UPP;>PB8/Y=23i
XM'#CF*>3?)E:"#E4S?>*0A*Z]2;IR Y?M"AA6S-;FX?!M*H/'FQHV:0#6-QADh
XMSAUO,D>.&BF =*1(&R@X=@O8?&KV8S\[*_MFGYV5#?7/SLH2::A4WRJ0'+DBg
XM5BJJ]MJ0>YDW&P5]=E:V-5QSI"B)&P7-WJ-J'\U"VOVX!ARMVC^_D#8I_I(Af
XMB"VU)3)4J"#2B$R4KS''GIV5C=S5,=39VL&R\7HC5_@)(FU1C89VLR4+7+B]e
XM]VM@L&R\=,_U;1=$9?$-4EMNB\NR\8R%3:IN9X8)7&8W8-#1;XL.MS3N3&RDd
XM9V=E;3XJR0.KHL^XTNA!B$7+,$,E>6!5$(@^@V!;E9WTC$%N;P&M1#.AT*\Mc
XM"V5;//74MPHD1P#\91WQ&*D_+/9-,BV6!ONQ",.BD(Q? Y87(H:AEO:V2Z<1b
XML'8R.PK,<$@V ^E08P$J"QSLPA6Q*<I$'TT**Q556[=+$/ME^=E96?#/%7-Ka
XMKP;/'U=A0'(DDO_'7Z+) Y&[.O(1Q*)F^@3+N;WY]38,\NJJ;@GG 9?B/B^Lz
XMP]HI3V;$PQ!,"58JJF;1?&-( BQ41<;1+3G<!@W$)[;\;>@HR7S+M88TC4HFy
XMU%%6-UHHMQ:D^E:!Y,@5:1<)R?+G^;\D1ZQ45!TB?$0O0,!&$DF 5J+) Y&[x
XM.KKTC=VQ825*H;-OMMV:['8+9<#SKK'4NYU#T%ME85Z"KQ7^MP([Q3G<.JKVw
XM]4*@M6%)X-\*[%Z8:",MKU_V6O'YDBP0F03^K<">AA-7?\VQ?RNP.4)>NO?9v
XM_D*U[U-7;04I1[OWFTW>OHEJ*T@YVKW7MLN"V]XND@[< '? $.#)4"9>O&97u
XM7;$SQTO8@+2QM%N1\WGN"0S_?1@ODO!1CCURR[_(^0L< 0KDE7:[!8Z5I,@!t
XMGD)FR=LW(7*5A7D)OLXAPH1;-A9YCL"^^=0>=TU5M?Z@KWL:"MA4D=OMZ< Zs
XMYE\$DDPTU$$[DW!($H+Q:(E'OR\*%SUP2*D(%A+CLH;/<C)RW&F288@O#S[5r
XM=6%+"'[8]+(?M/B=X*V[)^=),ZT0-^?S84<ZS2)B7)F6CP(@J*4*QM.L/^AKq
XMX:>/CZ6O^0'U]+"3^"$1C+M"8L()_1 AY;UC2<!<@H"?SX<=Z9!J,0M!<H-Rp
XMI@EMD_F.V"$1C'T+V3> ]=F=M 'W"3^E7F$'LW\'(_6'UQR(? *,79,).U$6o
XMZ!@1\9)-F>&V<:Z6Y 8N"QI@;&3QZ&4]1D2\9%-FN"VVFC@AX70I<T-R#J^+n
XMQ&%[$4.(#(=LD6S*#+>E^1,G))PN9:YF/W:;;0F=7IZU6;M@LMNLLP!A[58 m
XMT9&"-SA37)NMCGM4[9?FA99PJ:3)-+2],-%&6EZ_[&DDKJV*WN[1:7D-@I#Rl
XMGKN@I TCK[19Y2!SZJ+: $_2#T0F <YB%#EV?MNIYT5M< 0HD%?:K+.0;5,@k
XM"G@!GV0IM$ 76 $DP+E- =\V!(( %)@"X$GZJ:$9(2(L E6$#A@OO[6&(1 $j
XMH,!O,@-00*E'GB- /0;<(3$(_:&*3*;+@W3,9(=0T05:-E8-"O%O!384O3SMi
XM-D\=B'US_K)#%ZYJ:BTTFUA#Z](W]B6:<Q[[=;^K2(31.[T\>U>1Z/.8['<5h
XMB9Y7L'2-:I1:381RV@6_X(>&[&0PQ;VK2/0670-/5Z2FG;^?30C_KB+1YRGXg
XM.?^R6(85+UI:P[N: 5I+%>E0!06/0 #+4R;.A@>%NL\8IY! RW6-=%^.V)05f
XM+UJX'CP" 2Q/F3@;'I2D[5%H9GSIRXN&6)-S@6R+<PSDF>)=?0B<7>9!0!:(e
XM/8J"H].%X#">X_["3SY"KC<?O7-!%\1/)%*I.IX(;>Q+-.<\]NM^5Q^"(;S9d
XM=_4AVH3)?E<?@FN L)AD7; +O"%^<0D$( $S44Z[X!?\T)"=#*:X=_4AN 9<c
XM;"XZH&GH@&OI47BZ(C7M_/UL0OAW]2':!/;&=DU#!]R3@I_S&P=+:@WO:@:0b
XM,9:G3)P-#[):O/!"LK'(@P1<B8&@^Q"'):4R^'X3L N\(7ZD6LQ:]3;!\I2)a
XML^%!;ZO0A0$0F[ZX#AJ=G1J%Y2D39S.X0&SZXCJ6=:',$$V+($+J.E%<?QL$z
XML#QEXFQX$#E);QPGOS2J;:Z%&(H53E]<IYS>/6.\N%G9,E?7%+FMV!JMTSY,y
XM3S!Y;Q&SNJ)1K2!^&C^?V/*6)P&^JTCT%S#]9UJSMO3-VM)0;TL]N[:+NPJBx
XM=?'L%Q*70AT%M:4P^RJ?BIG-"Z.3S4:1VS*3GHF=_1O=(U5#\8<MK]A2R&(#w
XM5CN?V/(VP'.W?%9R,A<NA+>EZ-)WS(S5SB>V_!6QSR8$<)2CO<4GMGSKXMDOv
XMQ%K4YZM687K:0@%NO'6P^\PU#VH9M:<9VL@S<KL]1&*5ZQBFU]A3@&,/FAK@u
XML5^WF'FS8B;4BYDL9(N-2EH0&F$Q/BK+,R%F>F';9+XE 1CV^M/>6,3, -Z*t
XMM\T4602A$1;CXQ4;%&*F%5F:2.YG5H"--(=L0&B$Q?Z0WVJ I?DX4L[:6'$Ts
XM,QKY3YSL#%"@N5@&U3%#['B\L A"(RS>O.J:Z,\>NSRO-3>!MFYHZDNKQ<#8r
XM5 TD8+CGU0&?Y[(5)JB&B=:&VDD.' F8/?<MDM50@X#B;S90U'J_G$$@OS+Kq
XM2VVI&LC@W C*+0K(@!FP FJ <X-N\82/;'EA&>;2S>6/?Y\'"C07RX &!(IRp
XMBP(R0'/4 %_,VZ* I%?_93]4"8VPV!]\:<^KS1M!N44!&3 #G!MT&W.QTQ ?o
XMDM"U-TE7;N"R>SB]!4:UNQ&46Q2H <X-NOT3KI!E0]?>)%VY@<ON8?5<@=AWn
XM;=X(RBT*^&+>YMO2C^B(_39'/6B%'I)2F*G4!3W6IIPDL ^A/'&K2H#T$.5Qm
XMW![/FA:$1ECL#_-9XV39I@#TLL.#Q0+KO?8<"' ;]GQC;H@P:L3N5=?Y7$/$l
XMJ8RP(F\@OKQUS$E"6@.:Q<H65F6V(PGG%<.Y;7&.@1P$9$KFZ, T]A3@V'*.k
XM!GCLUXT7WNSF--F;T["]B=RU.?])=$YQ>&&_>^GH6^/PPFK/79OSGT1G*^X:j
XMHO]Q"<GZ&'!MSG\2G3>+.'',]P$RJ\D$/_F:B\;'J+C%G:R..$&IQLYAEB#1i
XMF5(6BKQA;.V15,0/S(1:S"M0[D[(_4(!;KR5"&UL.T<#//;KWA*1^\UNB<@=h
XMZK=$Y,Y"N6$$@X 1L"4B-ZN5\*&.@FZ)R'TH]N/YA;3[T4[2L<G77!RMVB<"g
XM9&;R-1='J_:K )F9?,W%T:K])$!F)E]S"8HLHWM[-#= ! ;+T7N/ZZ6Y7*K@f
XM;1)R$(+2EDE 7) +<\'>)E]S66E50%Q4 59,N?[J@+E4P=LDY" $I2UQQV4Ye
XM>N]QO3270M+18T@-&0&)W0R<@+40%C/HO=\6Y]Y/+U=D*B;72W,Y>TU[L7A&d
XM"+\E(C=D(0*)83&0$Z>UI5M%O!4!1.#HO<?6D!C(ZH7$8ELB<D,6(O %S$Y7c
XMA2Q50%OQ #S0M+ $1NT=(H ('+WWV!J^@-D!T=0KL5,N$(E:QM2%?.TPJU@=b
XM/9202=2Y=N=Q%PC7L94M  )&P):(W)'VH8& $<#5&T2VG!I#HH9 5!;/H'+#a
XM"#YYE A3;+3-,C#:_)BD$ ;)$0/Z3 +*$QBF2)WX9?KW!PM;14./EVL]/F\$z
XM1.XL/P("\B>C/^)#]^CYDG%YMD3D'G"K@^S+1A*,6%[MTB4A46KL*LY0:]5,y
XM)MW&QY$%Y6$!L>PPRXGEC('PO&DO%BF06$O-%)A\S:6)!N*>2;FFF[XD(9*Xx
XM":/]KTFRB( Q=_O;."$XO.0B'6E$+\L6&)<;#OG4R#GQ<"?IL@1OR6E _M@1w
XM1D!B__0LD%&7G[AL/RT58%S-\'R]-!<B@LR8%9]4^U6 +B1VRC75UTMSH;F=v
XMI,L2O"6G =73:1D!D9MTH 0B,@4F7W-A>Y1KNCT42<P0DH"(]PJ=I)OL &F<u
XM*4; EHC<=('\_X1KC 7^KKD@0.NEN0!RF'KT<$[HT?%J]F,WA]OP9IM#9C+9t
XMS2$S0:RCY\.'?/"9#D@>5J6XYI"9=JH;0+3WNHYVA&&!:.\UI$V*H1RWFHHNs
XM71"C[Z!H#ID)7 @HG:". ^Z9.!.:0EYG"B5YE*_8H&@.F8FXP8$Q<!F;%O"[r
XM T:25^QYR]GPE_%6-I(,5U/(:Z!Q]'(WJ\$48;)=)"3+K[A8DK4(Y;AU::68q
XM^?)A/(F8I"+RF9Q[YS^% <E744&>X!:1[)OS1S@K!-OV[2 G'IY#66DCD@VXp
XM_7=8(&\#DVF. A)L);(VJ4RHQA>7R'#^;@4JR \%$"F)(=T:7( 0" )+P+\@o
XMSU".6]_^XN:(RW%3AG>4(A 8V)L5"$+?9 L$H6_8WD2UGRX5PG8W7V5Y)@0"n
XM ]OO7CKZ#@J!P,!6^TJUXX9I\O(M9%N;D6-> 4<5?P=("[L@X 4" UOM*]6.m
XM&Z;)*^VE"4-$(59<4S P^"=9#77VTB -XMB&DH;/2DXF,ZYJQ_8^_'4.@1TDl
XM@[(>.)%J_[U:#71/:C.FGBXU$"]HA>A<G*.^$RG<]? >9I(#T8\)W!)%GEXFk
XMJ5'7JD%Q_XXASA0AHS,>N,OH<5+\5+\]WUET%*KB>M*0B+]OYLN$CRB-2#*Lj
XMQEF1-3;4G-? F]4!CN<%8I$<ZRZ\HQ3>,F)$Q)OE+2,FV9ALWC)BD@V4T>OGi
XMI>ZIZQ'OGD$ ;QDQIT\ID(1D@9TH*&\9,2)BOZ. @AA]:QQO&3$BPD8F!-XRh
XM8D2$%5\"]4U$C,99TA3.2]V[<?K%'5(8%[;BY[LTS2].@8 9H-:#('*#9"@"g
XMG-6EU0L],&UZXSLQ(>:JAO@5@,_DDL."D0S*>LHD!]1[K4@GIW94#&4&W !5f
XM2B](5TV="*=E"=0W$2'H9$G;[0Q4H"F<E[KW^LZ&Z6DN*$&;\ 4CT!3XEV8"e
XM 4. #NL!K:! (DQ??GT[3RO$@!R  VZ 5ECB0N HP( 6D /8Y0RX 3:@!:R4d
XM%J N)<BG? ,N(5,R1P?VF=;L^>?FG5Z>G7\Y8K+/OQR!,A-01C2&OUMXF"Y^c
XMF?XI[ORS 9A]E1=:DI3^.V^EY>S&\7<+CTI./TTXKYQ_.3(#:@!43/!_M_#$b
XM@!I@J?#+](_D-2"OG'\Y8BE4*0UPI4\IP?]=\6^I\,OT!P$TP(5>L4%Q_N6(a
XMI?@;KO0I)?B_6WC^!M(X?DMK^N-.V%R.9$GXGR:=$,J9,.&[M*;_9N +D=OMz
XM-8:_6WAB0 VX/E/@[%"!(B %FL#WZ80&SB7TB^D?YQPZ5Z"LHHSSFAXT">X+y
XM51,6"W!9^BO=UQR(PCM*B5)+L-/+LRB5$$QVE&(-(&R9?G/^8YX 4 NX(H6Ox
XM4LG%()4+ST24.K]U5.W3R:U]ZR4Q0VAHTIMDY67IK2FLAJ/M"*AD0D4GFXTBw
XMW9RX4*@@<FN3R(AQ9:R%^PU9-ZL-Y#XZ,"]66LYH'/@A//._W=IMC?\!5Q"Yv
XMH::&VWO?C:' :E^382!T[Y>6'[.'=EZ)4L*TIFZ+,R'V*_KP*%24[( KB-Q0u
XM4R'0#\@K4:KVC 0EIDM!U9!7$!TBLV:TD? #\DJ48@V2PM.X!ROKR*WL:[LLt
XM&_R;'W %X6ELB,,)K%8V,>40*SM!@UR<8@+2H5-ZW#7%_W:KPH#DI/8R&R8Rs
XM,-7LDWNK5/<$<OO,-3\2$Z#[#5DWJPWD/CHP+_R+5NAJT\;-Y>Y*)3G\2NI,r
XM,<#!+G0(A^-4,U1-O7#]5#\$WYX-GAV"!IH"9R<*5($D0 4:P]\M/,_M<K6 q
XM_OM]E.L<BU+G]X[EFV7ZS;F#WT-Z5L8$]<;A<1Q,P@Y@.>I&NP>6LROIU>S'p
XM=L2FX<TZXK%CLAWQV($R(+6BZ]+%6Y,H!(2!5@D]Q3EBT\"<ZFBH\,5'\<RBo
XM60 9*@QZ5PF"H+6/=NFNFU<<\=B) =Q'7- Q0+1<02IWWPH)00;H@!I0 Y""n
XM"V@#F:VQ..*QXVET@)\1%W0,$"U7D,K=MT)"R $ZH ;4 ,G2!C);8W'$8R=Nm
XMS@!72L< T7(%J=S=IZGCZK"1$XX59P+XP32 _Y"07RU"1-@OIXA0JI>N'V^$l
XMQX&0RV?WD(!4[DY>J\-&_L,&^%QHA54QU0;GBSX78:_-UR0*@30<L6DPD^H&k
XM!/"6-7(9VD>3>RL$/>6NCBLYU0:GJ_$TU6$C)YSYTQ7JW87#+<S<('$<!SA?j
XM-%"8Q"^JOT /TD=9!+<,QVX!F\]COV[B;BPYO4NQE>6=N!O+B6"RB;NQ-*,:i
XMUMIPC!]6M>9*72%>]Z2^ISCB;BS7P'[WTM&WQA%W8SD1>  >< %VP0=@U$;Zh
XM/DM^1\ #+L '0H%RY)!NG,<A$:E"X- 2=L0Q?EC5FBMUA7A-+$I4WH)47P(=g
XMC/.[J?RN%Q[@#>JT-HE_0I<WR@END6<#:14<PE(VA5+VI\(S]H#NUF:1R9:Zf
XM0KPV6N6; AR[!6R^&_VQB7L@LC9OEK@'(FL3ZHE[(+(V64A8PD!CR5N8*'2Ie
XM*\3KGB"-'U:UZGN*(^Z!R-KL=R\=?6L<<0]$UJ9+8%2[\+1<0".M @W:VF0*d
XMC.H#H4 Y<D@WSN.0B%0A<&@).SHDQI*W,%'H4E>(%\K# A2K::/,E, XOYO*c
XM[WKA =X(FQ]6M4B8A?C;03MPW^B/#6C?+*!5A2-@!(R $3 "1L (& $C8 2,b
XM@,CG!-X&%0 !7)4HW!TD,+5 @!-X E0 ! B!(L!50< 00 )%8 @L@2)@)D; a
XM"!@!(V $C( 1, )&P @8 2-@!(@X0)N%3*<+VU^$TE)3)RX#:/>HVC<#-FQKz
XM]\*)8BHH**#=HVK?#-BPK7W9'II'64Y'>=F?6A'@B$;PZA" W(EE\Z_U>R8 y
XM+=_:RA-%7+ \7KZ,M_)$X0@<6[WD 3@C8%P-'X4">070VAGACH9#R0OXN(UTx
XM" SKY3HMT,)%TMH?UP="@7+DRD@97[@-'>7<#&N,=!,N3]]"GK>AHQB$XS*Hw
XM+L\]$=QS@K*C 3H5>5"T8S>1<0KEY4,P^W=6C.T(SUPA+ @7C(I;4E7D0=%8v
XM )-[N4"DCTKFD%<06,HDA+54%<222S)GH@QE6DR$B0)C];4.D227!^5A@4X8u
XMB/21DI6-R25.H6@J7_>VRSD4@-SI)R!?7<Z_P@T(VB;#>L6 80=UI#!J*_,Mt
XM I [G8'+@Z+-M?[)_0AXW6D$_Z9TD8@D9@AFP)ASDEH2UGFKFOW8'<+AO-D.s
XMD5E-=H?(K%"F0R!S9Z/RY\7@O+9<ID,XG%ZX38%AKS_M::E#9%;ID)TR*T$=r
XM"5:<"5QFDJ;%[P"47 IA =9^<:31(3+K\+@0]R&>Z(7/0]T&!I^0NZMK*235q
XMH UCU_  *7L+#OBMSN'0&CJ$P_GD<@2_J'Y7\TP=F,:> AQ[T-@ C_VZ.X2*p
XM?K,=0D6'^@ZAHF?3+.P+7K'LM7(,--]'+X*BH!U"14,V,V##DD#J--CU45&\o
XM #+C@PQV5^F%0"_)P05@6.X9PJD5 5F[+W0NG/![&(80LGNTBS3@A-]3M =%n
XMAU#12P1WR-LW4?8FY13^0-NA_ :ID=\A5+2=$;TT4MZ^B;(W*>5\UVD-HK<Tm
XMYY4.H:(A2X,P WDF9\C;-U'V)N44_D#; 57T,CG?=<IO0[/B3& 6^H^S?4A2l
XMYY0&&R^@/P B)3&DM[_'75/R2[@3]^8A9I(<7$ )&U,V<GU@,LV!7I+K*!E-k
XM_Y2]21DQJZNZ19YE;U(N%.#&6_>6)&8(9L"8<Q+9XZH 52"BI+^'80@ANS<Dj
XM:D@4ON[#(W:*!5;U%USZQKY$+L &>.S7W2%$9]-T*;:RO'<(T8D33':'$)T"i
XMJDTTD,')4(2H_5VGEK(I=!2;+!.R0WU/<1U"=,KM>V*S33M_/YLSKL9U"-&)h
XM$_#+&!@T#7 ,R  7T$@KVMAI#1U"=-+%E6K'-QO#90)"M%5F\3OMHMU-*;,6g
XMQI*W\".<$!R,)6_1VBZ@.D80/84%B'M3(+T2!+_XZ:FNHJ:)$$W-AP$0B8@,f
XMLR+PR_07-IOJM(@$,B\%PCM*80-)X<VR :IILMD U;PZ?&>6$"H2<D6 V[7Ee
XM,FP@*?3"1!MI>?W6]=+1=U"P :IY3TS :N>C''OK7W/@=FVQ&-6\)P*>#5!-d
XM$[#:FS;*9,R;$24X77#K=<&6$=TU89.',NK!DSK?&T&=)4.BA@ WWAJGF$!2c
XM^$=I>^!$JOV'-#12NV(#7M'74+>!$1X:L4\PDZ>[L(NN45*Z3M>*S97#T9P2b
XM$8SS,B\/&T@*J/^0&"1=;/># W=WZ1N[8\-*E (=WRQT#/70<3;I>U><2E@^a
XMDD>^*0XZRGK?3 ;,0(2A]>8"#L0!N5L'\  +_8*T0@K\IJ[2"R>*@*Q\]YZ'z
XMBX#T($=N0RD;F?:I9&8+C)LI7 #YT-H/K2RBR$LA+IH YTX6 ;,-,#ON]!/Ry
XMVVTH90K^O;D28_.J_IFV- +\8F"D3^<I053 5MB2<*WWVX05&Z,+#$>[]TQ@x
XMM:]4.VZ8)J_D&S!B)E!QM'O_%'M6>#HCV8,VU36XMM*F0%MB<N-!, %,@7D7w
XMR$!J /=]-5D$S#; [+@3=5QI$VW; ZK;4,H"\B>[J5F20H_2#[0=6H,+*(LHv
XMT@V$"WG[)M(X@.#78@9L@SMPSY>G2?^5+QIAAMCQS:8MD:%"':<4FMMZNT=7u
XMDS+$#7I$UB)3\XD;D9/3T$K#'9=EXR4$VL2C6'Z#@&NF-N6'31Y:>QC<>0%St
XM<OU((2AM22-]6($64-=ILPP,"!TC._.RU99I0%PD@:"?DB$I<(.U?&++)XN s
XMV08V&[;/3H<!2JN[O*#+^5?/HPH;0BN\9F#:&"(P9TI#*ZT-Z,4+LU_ +>P.r
XMM_=^L_FP BV@KM-F&1BG#C5#YKZP.?])=%YIR$T$!($"+:"NTV89&!":A%"%q
XM#='4M"4<X!<#@_H:U7Q%ROA"DH+?J_T'^#3IYQ+3.(#@UV(&;(,[CG;O<T;/p
XMBG^?IU");R&:0>]](RVW)A207/*N4%[_!GI=Q8ASI6V+QB&^U5H:*MP61$'Po
XM";F[TNJ N%"H#(/(7S3J8I.:1<2X,M8B4_.)&Y&3T]!*^Y$BH EP[F01,-L n
XML^-./R&_W892IN#?VZ+?SJ_JGVE+5^J(8A*@"N6X=:6]-GEK;B?%;>@HE/2*m
XM0&Z?J1ZB[Z" CI"%#7#?E-_3(DFB%S;(-Z] 1\B205)^?JOV0E\ %5<MHZP'l
XM3J2RN[0VU#8H[J*>^T,7]O9%E=:&V@:5&>QZ*A$)-?"1*%U)W(2G8>J<@#I>k
X:[(-B$T9K>RB!2PZW00,E>F$CAC'#ZXP*/P)Zj
X i
Xend
/
echo x - man2.uue
sed '/^X/s///' > man2.uue << '/'
Xtable
X !"#$%&'()*+,-./0123456789:;<=>?
X@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_
Xbegin 644 man2.Z
XM'YV-9<:@>0,"#X@6(-K04#"G#!D0)UYXP?)BSHN+)T#X2$@#! \>$%^<4(#%z
XMQ1 B($0H!,$%11DW"<.,D4,0#LTQ9>;,>2-'!$D74["D5,C%C!006XH*:?D2y
XM9=$D;L*T*5/T: ^69I+8"<.F#E6C7:HB5<K4316L4*5^E=(%Q$\C3%*6)2(Bx
XM)9$R9M*X*0,B#(@Y>=J(></&9TFX<EV:K2NBBALR>/7R]0M8,&'#+HID&=J1w
XMAT(Z.>DPEE('9A,:F*% (?GTM-@T<_J"./.RC!RN+>#4D0/G3<.8,VO>S+E3v
XMC@N22>B @ T"\IR9:<0X7 YS")HP<%R R'$<2W(0UV-+?PFB3L.'= BF:0.'u
XM39FI;I3;?'/F=ILV>L^ 8!/&S9DZ8= V!PM_U2%07[%)$0051CPA17<D1?B"t
XM @$-5-!!P,U41AB@,31=1!-5=)%(&F4HQX:@>0121".5=-)0,FG((5]E@2!Cs
XMBOV!\!X<=.0!G%[IS8$&"'FYAU0300R1A!-4/#$%$EU@%A2,8]Q(8U9NB,'&r
XM&V.L,8=83Q6Y%F:(B5 5"FZ\L5<*F!4AE$HQGC@C"#7$( ,(=A"F QEIR*&#q
XMF(P-(2>.=-JY!)%IN)?::B4E 4(3<:)8!DEW),J&C8-.]JA,0/HVI)@@T'&=p
XM<F/DV) <=DP66Q@_-8$%27S.L08(<(0A!QUIX*JF=D&PL=-?9? E*E_.0<=Co
XM&FK&]H89X)'Q!ASD]?<0&F2,L65#$+[ZZH05$F000FW()*:'#X%(D448E1CNn
XM&*!^%%*+)J$$)[N)TJC8?K#10:"<#TD+PAURY,H7I&-T*B2>A-4Q56Q;(*DDm
XMDTY"*>6;ZXHI5E)F+*68%&&0P88<=U35%L9)6 P6F7&9N?%H >TV1QJILN%Cl
XML2\]Q.>)8Z07<$[_HD$>&_GF%ZK/;:"<V$MAL-PQ"#S]&W"*04RAI*. OI5Rk
XM660P1D2? >GL(]!SB&;UT6X4EE(5OVWI'Y$\A:N<&4W?W#5/7P?MG]$JO]13j
XM2E)LV"]+<[0@ \$&H\'%'# @:F2G@ O>Q)))8'$X#'B7=0=C5SRMZ>&.0RXYi
XMXG6!FIYLG _.:7R>3HYP5U.U2;&X];*DF,>,,9%O0F^4!MI#>;*>D^M4@HKUh
XMI;WOV6?M:NH'-JYK+SLT7W- 6W!>T\F=,]W SRN\8G(TU^>?L?O0L1U*/R1\g
XM5B8?Q?CXV5<<N^5^F1'HLSY&/35:8?/IAEBCGU]R58OZB:,(-BXLF(=GP]I4f
XMP5!W,"D\H0FA(@@=;N.&.9C!-HKCF73H<(=@P618)$F3',)U*<(Q<$C/L@V'e
XMA :8L+VG+X]IW. \-[GN?*=4,%G>ZA26$P)93V=IX)F_^ 7#AP!,8!F<0W>Nd
XMX+,/^@P$]DL"U?BC'^9$+R!IH!X9" 3"DK@JA&6X [[V8J/KW"9G&&1.N.  c
XMK8>H*3TD2: )@S0DH)'Q@M,1B*UD AKC"%"!!0R7CZ0SQC5,!XZ- L[-0,""b
XM/ZZ+7R21EB-E<L04-1(+>NE9&@Y4JM\DD"RSJPJ!0*DW4181*QI[2<B,0B0Ja
XMKNI$($@3'<#H$(=D*T(EF0(4#@(#%]1  =P2B+<P]$B_D2LD(4(7B392S*6Yz
XMBT4_>=&\B%@C(OIECI[*X)&2M*0F/2E*/YG2-/UV,5)&161H25_[9$+$FX'/y
XM2.(C _E2,@3Z:3-,]7H-ZOHBSW7*Z"%E\8L[017/>8J@GG#P41B>DX8TW!-]x
XM^63E&PF2O]R)[3!74TS2^.8W&$)1:E+,8  323!(&K AL9'CZ>@( @="<'1Cw
XML">KL(#-@Z7P-LS33PM!TP9MCBYLTK*5&^M !]W088E-?-Y'[V<&*BXG-E><v
XM7A"W^#R2U+2.DB%2L!ZBQS/VD21JQ$X;F8:Z./JL5=K:BQCMR)>N\M$VW7'!u
XM -EI3$RNJI 1G"2]W'-+;0%EERWHY2^#::%O 8<F<SBFN424+F:RTS<J>M=/t
XM( ."D_R$C#+X219#!0(7T,$OO<R!0V/@@AC4P*$R<,$-3@N"&;A !JQU[6K3s
XMH%EFP<2S?HE!#'IJVI[2  9MN&SW#)(X& @7!#XJ[G'U  +EEF2S,!D!%[A r
XM@AC4-I:=%8,<6*.4>MY'6CK@@@D2,-WJ3M<H/]'N3^)*V:!<=[INP ,/>I"Xq
XM\PIA"GF(3QCP$-[QEM>ZSV46?/'@@_KZERS4!; +W#!<$,3 P>G=;DG8RQ>Xp
XMO)<+;LC#?.NK%".XLK_D17!U0VR4\F8VP"S!<!X*S!(3@(#$2TDPB:5@XN/Zo
XMZ,$*5N^$)\L7-T7XLF:XL!OTL.$49TR\1<"#5-J3$QW,^+\S'D&*27!B%VP6n
XMOGI@L7B?+./S2D'*-2X)@T' 7!S_>,<EH:QFSKS@(*,8RT6V+Y*5S![W.-G+m
XM4/8RF*E;Y2MC.,L&YO*(]3SE*H^YS! NB8Y= "'"#A-<E-2<8B5RKA%EQ+%Cl
XMJ"1?GBF2:,IK79J6'7E"?<V59A-4#>,FQ+XY,2IINIQ'UB@Z\>D> /[$3:[6k
XMG/?\U"[VT=.>H!I?!('ST))%5 K^#'5 =_W.,LPOH7^A@_Z&O:YBJW-L>8L*j
XMYG2=HRA2K5XCE:L"-4V2 Z;TB5=MZ0.''5-H _4Q0J6.4:DSNBXF,"I3>4BZi
XMQ814\B30VZT,T%/_(KTL3I6+9_5B6L,XQK::\:T2#BL;IS/1JM+4U =CJU;Sh
XM^' T^A$+5'@BJ)ACI8=L-E?->4-.W' "Y90!#_DB4-.8\X94@>QIH(')R97Cg
XMK)QTYPENP(E21QZ;2N8<N;FSD:G*H)P$]@A:I[P13TC2U  5/5=#^F16&D*'f
XMIZ_%1F_X[F/B.M=,2]JNLK'CK! I;O?Q%9>X_"N$'7TA2"=JTLFTM+K"D*C(e
XM0M-%G^;[I6K4D!@.,2!E@!E?RN">G-'$#9N,2:):#:=$P3J5CX%#'% ELLN7d
XM1< 0K358QI*5 \I!9-C&&F.,P!.A'Y!IS$J@D!A//%NE(0Q:NE(2D)0$)A2!c
XMQD:IG&+D=[;?T/KK>G'ATISWE!>81PX5Z0UA7A"N1#G_5&)9J.39,!@\"/\Eb
XM<& ,% (6G[ZPX5+5OY2_A@63E^?J^VZ( V.B4 >4SZ<^4ED.LZ:0A"-T$P0Xa
XMDWBIDC6IQSTL8W._81- PC1R !ER0"!IX )EX ($HH#E1QC.\39]$C;P9U!6z
XM8!N#\1MM\ :0L4Y]MU"BD1)34#.RL3!S$"#"0A!/@8*V5A*X5GEF(P)]LS1Yy
XMD#O=DWXCU1J"]QJKTGYX,$'OP7@^\C)UMGB--T%J$GGI1RLT@7]MH!T@<$,Yx
XM0D@'1 9Q1%$LV#0!J'@Z,H5J(ALOXQ]&@E9N@04[]1X0"!-W@ :;-"2=Q!<Hw
XM9P:ED3/(4D&1%!NFUQ>T47[^LB6E<BF0 30VIU"#>%0@T(8E,W1.U1I!T'N_v
XM1X3-$1E[87(P\13IYP)C($I@12HYPA6_<HCJ%RH4]"4ET!NW(H@OT70$<1V/u
XM820G,H(I,H7:UT'GUQU.0%$&,B0P6'Y65 =L!#3342FBPH9QI1HDP43D@8K3t
XM(08^\A2F)Q;*."1ITA=R\!_P00<#LAPN1V>2<6Y\D7[=QQI9<7W0%SUO,'WIs
XM=WVV84H6"(YD=8[$ 8,@@ *0 2V/(31GJ'68=WKHA055=P8I0"#^<@=\9X]Pr
XMTSUJPA?.DT!P<WYO4"EK$U-B1P9SH /AM$L*A@13 &0_\5G-]5JL15JP15M8q
XMD  \H%9LY0,)< 02)$%/M!='F!#Y2!LD05Z*D0#CMX )9!-E8 ?(8AXZJ1,Pp
XMV),AH)'A\A@)P'IR,"O+PBR4X3/G=THOUS(I\A1.*2U5T9-#0 52P 0M0 0)o
XM4 5P0 9SDD#H^ 8&X2]Q4'_*@0(O.!4( @)QD (]208)<!?ND2()- :[<2+En
XMYX+ZZ"]G4)-*A9/*$9$]&0=IN99M^41O&9<Q-)<H9Y=JD9=C699GR9<M"0= m
XM27Y-]T2$*0>&J1R(21N"R'=NT),,<WPBDP!3$ :IDI0OZ)J9=&]J83[UTI-Xl
XMD !)AG+9:%'E09DYI527^1,B^1/.F$L@21)4 (8QE'X(QQ?W9Q\#)XU&A'6-k
XMV9D3^40XDP9P$$2$6(21U(T\%!]8&'+G*'@#5WCZ8G[)\R_@Z1>]$3;A,I4-j
XM!W;ZI1="DT!L"1K=(97[P25<D8F*:!MYH)#:A&_3$09FT$=*59[G&8O4H50_i
XM1#?JF 3L&'WOR ;4-X2LU ;FH1R$5$FX]W;:(B$4(DQU%Q.&A'>5UE@TNFDKh
XMTFF !R.&)&HPH9]5R)T/*7D!"GEKPQ_=J)U#*A5S0'GA8DB>-WSI=&QAP4H8g
XM@WEIL 9NH'ER$#;H1#+/HBO[,WJ,IATD\UE+2@>HAU%D0WR-87RA]Q6[I'UNf
XM&0:&5#5NFFUIP!A)< 8B!#V?10=(>2*$*@>;" +4"'8;^:0%^!)KP!A IR.Je
XMR1,$(BOF.6R.R:A/28![6A9NP#*N6)]B0%0I%TMO,(Y<Z6R/VJ7B9YJ'!5GKd
XM9RNT 8[P)W\I07^AT8?)V0+IT0(%6ALZ 7NA0JM,!W][HX-UL#AN0(=BD"L[c
XM<*JR5!Z_ 1EF$ ;+JAQRL*R_TZI/JH+U<I@DR*J?JA@I* +5&8Q)1!W*YT;,b
XM$J4#2C3K]*.&A*B,QQB0\J-/4:][P09%L4O&.&S!.J_V\A*=2*5M "@I006Ta
XMUS,<$DM;E5($04C.LA?A-E<UBG9"2A_<*2H/RQPB1$(R0ZW34:20$3//(C1*z
XMZIK;Z:0 ^C)A Y!NAJ)L@"M,ED0VI!R&5 9PD%)G1)7,,H=UR#1BH 9=LZ[]y
XM&(9R2(<'LA.[(73^XC,=@T%BHD3/F%3>"8$\IW+FF! "BJ(])16Y<X',@C-Ax
XM=Y[\0:;#IEWQ*BS&.DL&&3L!.SK!VHR, I_:E+2/\1(%(T2P]'+2LSL;.DEYw
XM&IQ8,'4DA:>182275!KN,:S]D:H^TSU$1W!8I$7X*2JH]'E507:;DK'A\1=Av
XM1RQX@:TU"X#<*A[U=[IZ02!%^G)+YAY:"P)<>I&Q,1!B-#I1RA=_Y *)%;>/u
XM2W4TT5.].P945R]6BP5(8!MX>%=W>;.$N[A\$5?/*69NAELGN9(.Y@(PX%"Nt
XMU;U]V0/R"'THF  ) &9900;_.G!^\4AOT),MVP9.)K5DX+O%FBB^>[YH$;]Bs
XMH;<<25;/TQ ]F0!5 J3"P;'Y1[_V^UGX.P?Z"QKG=[L726V*N[]-V@;K.\#=r
XM @+CA\ ]5;$3J+_]D29[V%9G&YA]V),*W)$)0 )D\ +6Z@)#HL!CH+]/L<+Kq
XMZ[_*XD0Y,2F*)F$)P,!LX+M.YL(OL!7&D76"!XHVG!5"[+LYS+,UL\,![,,Np
XM4+TND!<D$02,RF0I4BP!<RQGR'Q9L;O8F#ML\! GHIFPE!X$@:)-6RM"-[D3o
XM:%7],4COZ"5D]1-5H"VQ0I@Z$;V=11)30*ADX"/WQD,T@91"6+B/JT]*A58Dn
XMX;1R('1(R!>O2V=,EKQP1W>&]90VREC+%!,PP6GP(DU/":3>$SW\X2-/"2"7m
XM4BNT :7] 6M)\)1?T*%RD >=AZ5/P2=GD"MA^A02BDYGFGI&@281R2:W]CJAl
XM:A>PT1YAX,JP21V0X7W-#",P,09\8@9PNC6L/,VD3"OZ6*1>V<UF(!;QNTXPk
XM<2</&:G0',[4#!.RC,E-$R8\L09B\88]A8KLW%I:$\VMK%2U\HHS,,[U[*@Ej
XM$9U"6*;J<U?Q.S0/&RO2G >Q\<H+FM#]MLU<X1[?J;D;:X6QI!:S2]&MW+48i
XM'<OEW#0>"[?QN]$<F@;!K!S[BHG!G"I!6H3<Z(VQF)W%%J)/6:(.O09@!8CGh
XMP:Z@L7RQ]T36:KKUV7S/)]1"'0.=>[7DL8T2.G W31XHT#1JD**R <RYDI!*g
XMI4/.LQ5 \Q"QN#.Q 1NP(M#3;$O4^42V0A-W$!LXI*A\T87#UA!/Z%%K_:"Gf
XMQ .&NAMNL!%YS85'C4@F+<ZRQWA=,QV!W1U/$05B<<]9$0=BX1ZXB4!/]-);e
XMO&MSL\LCC9>)S1=;_4$$47.V$3"4E4"O1\8@&M5/6=58, 5Z ;59>:=N ,ODd
XM+"#<R*0UEP:0P8E4""0EVS8<PD44U=FK;$A=Y\/1(Q-E0"#;F-*_[;?";93%c
XM#<"Q MT&.M>,7,:US$K,H8#]F2@^<D!Z>"E%VH.[P31W !/.0IC?N$*[ G=^b
XMI4MS%Z.%14PH:!NAK$R7%A,NU#VF[&DP<N"J'%/Q01.7,IB#PJO.,WNH8AL,a
XMDP1"T 3@E$NOP^!>.;8T77K$C1;!#%!9\96/43G)G"9KTB:; 2<,?B<X!@(Oz
XM\*QN4!&3:W.TPA/G6LBVHAQW8N$(.%*1V+XR08=DQ!S(O;?H,;%[?=3:1QFVy
XM87-:&QO-QW1C\ *5+!;':R1"@L9>B 77D9M^H>(/P82)8BO#ED"PVX1],1BIx
XM@H70R,-_8=$\-7"#D:H.02 ?&BX'+A;;6D&G],[*XLT76@9L/!V]+1@85.$[w
XMCN'[.'OG-\E5CN%D/;<$@>0P![;$"C>[T1WPZ2.#GKE9]T1ZP2>E(KCUUR\Qv
XM=.(*&4/+XV\VB8?_N.K3,:I8:-5!VHE9\:6&8]ZQ <(D<89GCHR'F>22X=-Hu
XMKM6*I]KW2*RR%^E?RC;=LY6$2:8P/>V7WCW, <*SZW[@.$KD'>A&02!">R#,t
XMP14,:=&HZP9(>@9^[H;!<FZP<4G^8B5WI59_0>V[#G)H,-ZW'. $^= PQ!7Ts
XMD3L2BQ8"RJ;G3E8CBW*[^[O\3N22C@+F <LRDP)(W5'.P^]/L27![-!4Z,%*r
XM](@?"BGF?A0H&C;OGI<TD:IK.QFY)[!@2*@E[B]<=^)])7?6Y<G$1 9B,.!Zq
XMQTQ"[W<\&B]#<?0UT@0":A"04:IG0!O=LP4V@ ,PD/4=#A04P_19@>U$U:)Cp
XM@LQ2H,PO?FLQW@9''Z(X_@*^XJ=ND"<_2J!E(/54#\!:EP2^HLX7?+&/(O0Do
XM,1_<+40ZV1^'GHEVGQ^2C 7Q>_+(H1QS8(RC"E6!,1A ,P:(7P=3GQ_:,=>3n
XMP9[?>$GB!O:?5?.7M.YMZ )?A 6D+_89U/G>85L$4;E197"'Q-2EFZT#-X,Nm
XM8%&VS<5@;)YJ.YXFW*C.CM,;:AW8H1W<H=\?V=\;_,EE< 9!;KQ'O5@$KB[3l
XM7_U(?\J?MOVW@OF$QW3-,2=F,+P N"$1OAYM98BSTC#;#P)30 5;+TY30?WAk
XM/Q:SL_5EHGHI85'S9B?@I:BG^49>%7$##\EM]"$8-Q3 'QT8 XQA!9TF8F'^j
XMT)\<B7_S+_TM*%QAVMR?WVL"#M!X80%^T;52TVHJ?S@BAG! 3&8!GX@8X!!]i
XMQ$?TA@YR(M28^HLC[,]&N+\-=0&IG_RC J>$ZY@C-H0#\5*,X GZXPS(C+X"h
XM3/S;H_%:FXCHX2C\D*@27(]2"9(!H-P++J "4$ 3N!,.(5?P!"B5!6U9^N@"g
XM9,_LE0%F9H,H1A:T<:;G!:"@&Y?'7, ,8 Q%@$\HAQSA?F+6VM!3F<$-;J) f
XMT=%TA!YD:03!2L@&?@<(;Y"O %*7@@] 08? &-"&[J&"#B'[0#08U#U&1_()e
XM7/C"#YZ!#Y@%20(*F \D+.A,!RK8 AP"QT-]3.AFM3<VT *>PXD@#V%09\"Td
XM7"@TXD>]F%T#(8UUK9$#$Z;""-IE" <I79$PN#:,$4G@A?Z!0)0JY0 T\,-Rc
XM<G.'L!/./N1%K#1=G$-.,Z &+('NP 2,%>7BABU/ WTI%=563!7CR% X03SDb
XM@3_"RE ..2Q',6&0?+YG-4%LS\A2&V?@YQ"5>7/^PHYL:':"1*_1"O,T'3J%a
XM(RF%;D@]D"*80$B,4AA)1E@'.=E"PF!']$-54BJVT(-TAQ4T&7P%05!^V6$[z
XM,$&@!RZ^UF-)+->/THBR D<%U\-+['X\IK(0@<O"%_I,[.DL)BFTC);2PEI2y
XMRVQI+2C)>ZF6TW)=;HM)TBV\I0;X%N!R7(A+<[$QS>4JBIGNP5R<BY6Q+2! x
XMNB28IIA=)(Q]\2Z="L3\%R_#9BB,_/,K?B:^Q!FE@%_T"W_9,O]%R!"80"-Gw
XMQN)6O!!FYH>MEYQH8=Z,BIF+&</#6!VU*&)B@*#QB2DFPV@9%P-C\DQ5"#,+v
XMIGO<F$3C A:-6_0Q@M%Z"1DB0U^,S%(P 4DF=C490>,8"0UFC(N IL6PQBA3u
XM:):+@^&,GC$GKIG0V&9&(V(\C:FQ"=V9R]AEJL*>H3*C<3+.1M?(9VQC8.R,t
XM$H;1P*CH1TR>GA0<9371(%A!I8<%(8]!J!%<T O>B3T'COHA'$ *0>!Q'($@s
XM4/\$81KXCKXLUM0&K, QR( <&!GF!/34Q_M(>C#/K*@*8@(_RL>R01\[!G_,r
XM4F6AIU0% RD@,8^OVX\-LBS$ ?IX_A3=UELTN&)[T0"FB 40)/>@CSBE#$1(q
XMQ8#EC *#[(]E8<1)@0H9!T;D2_@!_"^CU ;&L 1L0[_2$7A@5?$3^T@<]E%3p
XMRU8Z@';92,:3B?P@?@M29(!'Z@0VZ +ZW_!9/6\$!?J%"10000 ), -CP$[,o
XM@([ CW)?S0J2PPMNQ <FZ20A%8T<DI?")KJF N4+C427O%9 $BUD1RO3!LY n
XM52"3,K)LG$E[E2;#A6OB"OSB:[R!J455'E9JVY$G0B? GZ*1$H) DDR4AP^Vm
XMV(!#80SI1ADI#;,"OOV+_B"+J(.UJ .4)9,L#_CSS$2 HU22D;(&3$J== Q]l
XMA$# E$BG#FS*\C,Z7LZGI"P%L:>,RE:%JT2 !!22>6 PQ)L3 2T>UC*D*C^Rk
XM9O4 TP("D( >0%81D/Q]-Z:3(AI"&9@5(=)'>DDZ$"1_2]:3'2J@#32$,8 Gj
XMR<:W$@$UDD\62>9Q)!%ECWR33BU(DH"L!P-D0-8KE]GFQY$_:\$E9@6+U)9Pi
XM\DMRL"# !'K #8 !.6 &W( <D#B<)8%@$E+#8)H6ALDPFZ4>P)=EX0<$-'DVh
XM--3(3B)7@7 H/#W&( 3>$4WK@E^02+1 TA4P1]PM>WITTDX:A4;H'K^C8N@Ig
XM)& &T,NLQQA.I6R0E(="04 0+=$O^X)RR)D[,W'X"_+8/IX>D%(.!S-A'DS*f
XMH8+('V4 &F< #="!?WB1, B_[!( :$ZLGZ3"-*'3W4)-"\6W!:)*D97LTD!8e
XM5F2 X\V'%Z@E?,1>X'&O9P2Y/.+W&\94'QH0)&$:/@]7)M.TID+$2G"@O5F[d
XM3(2RX, WHA6[83_Y'$C$+#2ELT!5.BM-B)$Y]+ TI:T@%F\@/_@0@C"M7L^Pc
XMZ)MBK()$*X:$<G1'WX%O)*',\07IH)$F@Q&"%K=B)3K!&=4&UL#-N(XTT7?Vb
XM"9R(!4: \3R>R--X@@ GX": 8!%@$E)@,R"!J+$\GP 0% )%X'E6%B10!(; a
XM$B@"*"%YBD_CJ>!4@O#L'C5B=X4UKG$]=AF4.I\H4C' @6$V(!5D&1M7LR9]z
XML4^OT5D8S:(,%)E"M+5/'Y&-<$<):E7AAYX$4/R@$X0&<ALA87!.Z+(@HM!"y
XMIOE<)#<#@$H*M' SUE=O0DV%24/ILCS0/N!G63B/XTL.A@T8=CP4Z ;->RF4x
XM!IF!.A5#H-JI4*%T@(42)"@P4O!6[<-<(Y0!"5 @HMTPA:1P=9PH5]P>H*$'w
XM;$D6LDH9!JS$!]N0;V[/%]N?EE*-P(8TI!_\A5*0GYCHAQX<YK1%%1\6T$B]v
XM82^4'[9Y*0A)R3DEVZBUQ0VXE@<:(K,(HH#2;\Q#U@=SPL;)BT0"*4&*A8,Tu
XM<+H0PF$.;%0A*KKZ@]8TU.@X<VA@!(VY@,34L"AIHU 6*E?@M0F7WU[4MMB=t
XMGVP-Y 6X 3S5A2C-(@3!"H[/Y+D\FR<(>)YD27I23R=@/4$ ]M2>0X![>D_Ps
XM&197*?(LG[USE,J@>Z$^_8*$>@CG"5J\3V$:/U^"_;QE^'/TX!.XT3]=P/]Tr
XMH>8/E9HZRR555N&X*J',-)DZ&VS:E;*"./6@=LX$BE!+2D*SF?EDIBT@;*T q
XM,;)3.(1YT*"52??44T+U)6:HT\@5KF]1=;0>^D3$:,G2IK5O056MX&9$9T3]p
XM0@Y+[4I@'@S&2@@I<S"D'?/J9"5"LDAA!E=PI)NNC$C28F?GF&E"=6^Q Y.Fo
XM$7MT(_J0[J2.X$*4PL0/(1.S'S.1J<23.P93+$=,*UB;A!YX[CTLTQ(I!3SDn
XM2V "SL+AL07\47 6U%.8#^G!Z\ ?)H"O?&HH7$YGZ-VPI0;$- 8B48$_6:/Xm
XMG",2%"IRH&S;J6(!Q]D*'U&D"F'5@C]OH!+^!H$2,'*3Y,(@'@LF)(ZF\6 Xl
XMTP7I$50H(& K,H4QS976()TR#S2XO,T"*O@9HK!'E!0?\0F% 7]B0%7]47X!k
XM ?&J!]-8@VI/00%%Z@5V"8;$5='H"GE60*-',,D;M%-MW,EZ 6: ##P8J!I7j
XM4T*^TA2=U87TE#/4?%YK;*5JP<>=ME885I1@JVQM+3: :HJ VUJ&>(2/F ')i
XM55'MP-S*4SZ@3 V<J^M__=0[IUNC3LKB&085.#VN89,K1-UGHPE1-0] '=%!h
XM>XH.TQH2$U2(Q)"%"E/LB2<\*A"5H*'75*5>,5GLP"'3BI"DD$T4ZTR./<IJg
XMS.&KN3S*,$%DUEN;:>&(#[('P$I=7T@B)23A@K(44-E3<#!7HY,.$,G-$,TNf
XMD;RXV/,R$K35ZVB3BK0E[IIY%18OYVUPQ(O4MM""=&$E+P-0\< G\N9NEG1He
XML=TI['PC&P(3Y$0LVZ\JMFH1"*<4BUX)7YA6':UK/E3I=))^24G 8@BP)(&6d
XMU]*]3M+!'(HQH,O. *7(6F@ 2TH Y-%\Z2_R*%V+)JA  3(M4,7-G@1=$X<-c
XMF %J5LJ,6#WF+]) "T@3SJ$OM8 6L%IJP&UTC/HKYO$<=MJ3'I&BT@L)@ P,b
XMVD++$O@ C5NSF<2=&%"^@ (*;:8K<2A !I"U$[>/8H!H,E]"@KSP@4%+:&N a
XMH:5Q</"&MCU*QP;T%ZT%#]I'DNH>D($'Y$ +Z+6_]E\-L#9@!Q) "Z@#K?;5z
XMWL84VO:(K?Z2E5=A"A0!*E %D@!*X(<#3.1!VF-[!B@MK&6V>L'MT0=(*V6Dy
XM+;6UMJ?$W/J?G=B2'"T)R+,Z(H;(MANG%X1MNWU$)RO23EI7"P(NK90YJ4DDx
XM2'8='X$"N@I9BZV) P7LV5,;Q'H$ 9NT-^ &]-O;V!%@P+,E;CU !A"($[<Lw
XM"42X4 ,\H0?0 (^K%T*N<6E)"0#AHME!:P-H0$> M7<B<=39BTM58%U, +D/v
XM" I:JC9+8AOM(WJWYDO*A"'0 Z).EKU- ([6].C;9.M@_"W)ZAZ:5M?N(T]+u
XM(%I=J16U&Q?4FMH!5KXD+=.U$PZFB<VV&RI#&87Y KKH:^S:!ASJ06/#CN@1t
XM/M=*PMNABQ;&U]$%NOJ+[BK:(>JAKNQ(HK*"Y2=H,8#G7]=AO)T@/N(,;8@#s
XMH7%< A[ "3QBZ&P@Y7#0QB9?( $-)QRE.S001ZBH7I"@EI2"OL*NE=4H4NR8r
XMHSB#?R;26H7W$@XCC!W\[-\Y@1C+J'B&)MVTZ X\F5[#ZU8\CEXSH^9$Z(6Bq
XMBBJ&IM^R8G-*EN^R-6FX P'N0LUW'<="3;*FBE(?U[[("8%+\2Q!SP>Q<A('p
XM28315])]3I+UY+AI%D%D3\3<5EN4X"_4+;KEAQ'V=X6Y^?8-YQSWY0\N3U3<o
XMPC*R1SS.X7-+XXJA)I _PFL#'WKM&KP*_MHMDL!Z+!)&T@\ F+*,7]B6\UX=n
XM<3M03</Y(B^?]G&;AK^@@G&C*&V2(KH7:LF4]:%IH(ENJ#U[T<":*8)RYA=Sm
XMA=;F2WW7%0KH(JI/6^S9OY""FY>#60+12E20G!RA)D:6&Z5%M.$A+"H]XA_,l
XMJ+@1 DS@"7C/+\!_M$ 1B"0J,*F8+?:0*&KL35DA:X.?I8"7*J-"*: MI3<5k
XMT.945%:[M& T"J"4H08#0OO7AJN4Z#D*64H,T$\A,'R7JB<* SA73I9<]&D4j
XM2,;+:*(B@\65/1>W!DNH&B:N=N %M(=49:$PG\15KH)B@VI@(]%6:<66B&X]i
XM0;C684AL7 ^:&)BX!ZW.XE-"46</Q<D:P8MS6D:WYE!7^<(=-)M_I FT89*@h
XM[]"0'(X=Q_2/@(I+LF%1W:USJ#?7 U^G0<PX8?&'Q7 O%E@XN'X!^C240;TKg
XM.[AI]%X+Q6](@A#8@:\X'N):,\>#FRBZ>Z\) :P1DO"Z@MU?\E)^7@6#A&.>f
XM<3FGE>Q$0SU8=$G>"B6,JC$Q4A;6<'>0X?\64VDK&DX(:X"VKN%/DY#W:X.#e
XMPS+D<3B!R*$Z4FQ_%2GAA&(TY%0E@PJQ.3G%Q&P/8PW\,4%$LF+0#R%Y]!A5d
XMR(,6')J+[%(M&=Z9Y)?03Y?J2G:9BG8F][:6G(A;E1A@#$Y 88!88L6"=ZQPc
XM2Z]0ASFD9&33JL*J"( *D(%6GE>.G&3E%A<ER06OXRFU8O636]4H%*L\F978b
XMJ2=":MMJ5GJ^,22^5M R"7F LE!^=,S"SP):VVOG+')2+I%0H08UR3R90..4a
XM[H%W) \%'#0N\5D0D4S3I!QO+!]E!'R&="W\.9>6$"1VIE:7=9'HILU+LL<'z
XM"9V%*COAS[F*S+*GP:Z-IY"3Q7+7JA6:BRCE!8/PNA811BY7+Z$.R-6_K F5y
XMBM4UR]57OMJ,T-NMVN!0V,BCHRR( 55L6ZUJ*RYY2%DB+;5OQTY+J$(N"W7@x
XM3I2%,_!@3FC+10TIX0B0(;?*#:VNQIT-)>[!?.  ?)V#4%;0Q;15+/3B'.&)w
XM9"K?H\H7&504*0Y[N:;*)-/,90!8L5/8A[?LLG]='&X7ZV 0HT/K2+*S("J7v
XM+>=NEO Z[X;2?FT!W=B3-D&8NFF#2TS,.U-P7/64[8C*-+0JFP/*Z$!$X!>Bu
XMF*CE$AI4(-/^>>BJL)+?@$YV*,1,8>1/(3!PES)<90Q4P+#-!A,->Z!HFB-_t
XMNK:GT*TE:E'@3Y^JFM0PJPQIKJ 7VL>*5@P2I$=85B0=*J2TP"+27U6X/NF7s
XMD ;NQ,"=TKZ2_'WI*\VD84*H!4#Y80XPR>B$MYY"K>H1[UFD1=F[)AOZ"!7,r
XM:#YNYI'?Q3D8-!>?*--%Y*TA/*+"G^E0;$BM6U.XB300G2L$@F=#;3P:J("&q
XM FM^?D7AX4CWV;0)66FQ\$9TV.HZ2>Z0U+H8/%4:C@V)J)L+2@]2IW+>$F5\p
XM('?0%#)0U*.02.?- ,8";UH&#H=A!6>A:![@> YN+Z"1\DN?N^E#T#B,@Y!5o
XM 5WR/%&"I*YNFN1 3 7#)]&40ZZ@%)8"<Y(SA1+=X@.OJC>CXC^YSC1IK6-#n
XMHA33!$$*%('Y%P2D !!\UMVA5^P$6!VDL5&VOM2B"R^A "00U]1T&T)SG9JNm
XM@6I'_1""])5^034O@0S6-_!G#1\-W+2%6J*6A32PJ@7.-6Y,;SG$EM6%H50@l
XM&,\:"&0D=(T.DD!^](-T>$C"PC)YZ(3HL/$JVFR;HV.K*94OK#,.(BW""6/8k
XM^5'9GP=*B8F:^ *@[$+?*.SXLU.9%72TAA8$' I'^UNV9) ,LR#@+F"^'' Gj
XM:B3/4 +:H60J!T<+ FQ'US$2(PCRU.SZUI[@EA?\F&&13G1+&+ E%54>4*P$i
XMXGL6 2@@FOH&3E \9"!(YDJ"TQ_J%2A2(G:@#BR8-HK(GL7?=@&!>W OAWX1h
XM!K)>#L !-"!:06VIO1WN1 [0 30@!SR*:4L2[+8 <@AZ&_T-!'MU5,8 X!;<g
XM!')133<WX+=--^)&W6F2<6>]&2 #(C=)X-JXV\$D#LI-M;<#YM;<38!S8P$Bf
XM,".")-<..76 0$SN@%"Y?7?FU@&U>W-3 08\O(RWHT67]0X$8&U;FJKJ @]8e
XM VI #  !UYVXRX8/H$YOP'IS;10TOD_WX"9D=:!H=0WC[;43->X0VW&#2Y1Md
XMJ_(Q6X"U-=X\@&K;B3"+,#.W"P@#82 &V( <4"> P.C>"Z7;?9MO7)($3D!Nc
XM(M!!ZB^(K)1CWS149+W?8K![:!]-N<:\@@NI7X]("#">">;6L,!50KZQHQ@_b
XM69J Z"@93GA/J&E3/P9<D@ 8S$>,IQ=M5]0W%R N08 DC"EL8"8H!X3 3(0Xa
XME\ EB?10Z1QKO4_B1]IZ?8\(Z(RLH:2/M,N&X+.PQ#U4J)E'LM\#:YNRIM!1z
XMA#FXJ1 ?5VS($X>H]3Y9IF/=)I@ + ,1"5B4'T/]*)SF7-I5R>(+Z21I:*H<y
XM--_Y#3$K*RTF!$(0X%N01%<-*P@\!A]12?]&Y,.=IQCD#CW&1U2N(1]W$A&Dx
XM5DTN:_J(E !8JQ4-=&V@G%T! G1 "Q!-@W: J5DU:[63UQ=P ;>\?WX!$+#+w
XM'Q$N[RRW7#M\@6'.RX5Y+G]$N_Q,:0<L5,R-^2Y_YIVEF3M:7,YH^F<Q'V18v
XM($B&'";GO,P(-Q((B@<+)9E^F#.VJ9"HXZ1"2'0';<[';04XSTU3;)N*NTM%u
XM$.JQS+L#/.&2#H9"?ANZ\-KX:JQ[G1\$5DO0"[I!/^@((=N!!^8UT!&Z0S_Ht
XM) $*+ @D(+YPG Y@>WKAHD<U [')-]@X]RI"XP2$;1<PQ,5EB[A^%B%$C#*1s
XM[L3' !&? QGAF:R 5^H$B$ +> )&H 48 4L$$5BZ&R#I7.*EMXA<@@1(PO .r
XMG6OC&/(%&=['O2/WEGE-( KI0J/N J(3P&,.H"$G!3_I@-)B,[VQ#==*Z!"_q
XMIOX>G[IRB.KX.^=*$BR !0:3#O]?+2T?*D2^!E-25-C)Q^65JC,!1H$%C,#Dp
XM)58=C0-+]:8A=;5/K&BPTY#1*;?S0\F)&W@=7=(NX1BD/42FF'2/(.20#W?%o
XM!L]Y._E#5!A^J/HE&*7'\XV,.A*[/;FGK560I(;"GVBLW)$'@0@TSV8-/K\ n
XM$T@"&7!T# &X$ 2.P!0PRI]+>AGUPX-&?^'S@ F:,I%N(X"(0:QE6;M/@,NSm
XMMTL4 #O9^AI/8[1+<XHCMXVJ[@!9$YS)_5X'"_,3X7*X\0/ :=VHURXZC7LLl
XM2G<@ZD8=;P'L]U[5^3K>8K/-3F3C<R)!V?^FS%ER"V]++ V=IZ;.^M/+3D;]k
XMKGJ[A<=F!4H6N2 GD&:S$,^*A0"IR/GK!0U7D*D$C]Q]$*[EJM\-0#$P0M<$j
XMIL!9<A+9*3:Q=1= !/YN21 "1IW-4@L 4Q*D %67[4;]PIK,1V'BB8"3P$(Hi
XMX!?MP:PDX<.P9SW46RH&*43OE%%S_#2CYW@I^=R.,R0= )*=XR-D*,,KT5TAh
XMFDK"7H_ON*^5$0A?0:D5/ ^&<P";H4XK-^8]O-DFT7V(Q(#LK74H+0B$@FTZg
XMI&U8[%9"_8CPEGGD5!]8G"DV48TC5]5PY^]!1VVI5!'.H*89%LH"22>OS=\6f
XMY-7S@N%=FCO>Z7G'X5ZA,(BA'9=JXG\YC\_+AXP28 4:<\]0>Z05W^*I.HQGe
XMZW^^!M!+164RHQ5\J -4W<:S^BO,UE' -F_!+H^0>!TW A/R.%OA(K>A9S%4d
XM'((3SD\R2BH.^FR5:Z->CVQ)EP<*19VM&X'^GBSHNU7?]HG^;S)4NCZQ2H/'c
XM*'Z=*APA0D6577723A88XA*'S\[08-1[K)%P'I1A/<A";J]S8H-(ATTGP*?Ib
XMH7"O>'-DMIM&Z->'88&P'<(!&%"Y%<8("T&*3,(<%E6RY#F::$)UI!OOXEW a
XMJU_XL D%<+P]X.YE91_(]3>>U]\VF\0A3H![]1&:TKFW+Z_^L$)SD)/W.%(Uz
XM;M.6D^R'>GO/33&%C7-4@T]4$+Z1TC^OW>NL^I+0ZE?\QZ\^;D#D@P"2'^MGy
XM/7FT]5[]Y%OWSH;R=SV8AQ[.K=DETA>4FP83$I9L<:]/J(G'.=89?LT&UPH?x
XMU,>0Z\ &F,589[-[UJ>) #9;T-1"'X$JHTT$T/<OK^WY_4439_<XC[.T_4ZKw
XMRG8XVKV+]:X8DL*MUZ@]I"Q9*[/D#QO2E[(Q&;_W:7Y332PHN3_F7+@_+M<=v
XMF_;&=:P.@QM;'27VS"DVXWPNZAZ&^^E']'PH6?0[,0?Q]&')(P,&PN@[N+"Qu
XMK7+&F$_R39ZM1Z2ES^([_L=?$"@@#(Q\_O!C>\""V %JL@R(7!F@ VR #+ !t
XM.V"#+0@AJ2[]6F0C SO@UFO]&I_RC?IWT NFGF=H2I@R$'R#1"(CSN,I^0A^s
XMQ7BH6!S&(@N*S3:59Y%0!K]]?R+?=Z>5;=Q/IISLGJ[K8>.NJV"W%)O_N]"Ir
XM[EC 6F65/$[W6B;32)VK3*QLB"]%SV/E.32\ S_WRR%+8?G? -TTPO=?R3]\q
XM ^\=Q;DFLS,<W]4;]>R( GH "P!RKTC3O\>13^MEWOIW%G. '[& D@G5>[R3p
XM&/FT7N;->!"P_LF^PK_U79_IJ_Q?)$8T95Y3L2>@!V2$IG$"R$!&H/_OZ#=Lo
XMD Y"'C1]6?<7/GX*=(>9WJQO>D[?Z;[G?@-UERXN>7$D):LGH [T )#! LY n
XM#WA ;Z 'R(&,X-.!NDLWZ99..8"!.X#Y6@#F\^E W:6;=## BT5<#Z@NO'BAm
XM7-Z@3XQ4/&RA :(V >B '; #2((*2 $)8(.= "&P-+:QUQ1Q&^H$^'2@[M)-l
XMND8P 2?&?&VP$U!/=,?N%_H]L0;0 !EP:4S B<D),N$9PASE8%Q8(NXX$0=9k
XMJ2_DH< 3"A8]XX10BB=\G95,!M*9"6 #/:L.]#(\;$Z6<H-< 4NY0:Z JO "j
XMGBH,M)'TT]C<X;9PIL#JQJQH)6_"ZJ;$Y'*2'#D[(/#GFR%6&8O=V<I:SI,Yi
XMB @@5CR/(BH+63)+<4'[),"-XZGV,MGHRU! '^E:+$0$$"OD"P[GYS%'0,D'h
XM*=-QS3)/1D)+].W,"W]D,UC.":4"ZC2$/ZX*8T.1,O>VP8[D!R<-2Q26" !Gg
XM%4V;?/"0^!*<-"PYH1F$L]8+&; Q*UJHV.\+-9/4LTWKI&%)68#:"LLORP:Hf
XMK7$PDK.X'%H:EJR &S?],HG"$@%(0'<LSM!<LM&"=!AY>IFAG6>>@'PVX=V+e
XMZW-ZARGY-Y=5JA9,\T0\X>L\?'MDC$H:'75>&N(E*,Y1CP"5F]K:VUW$TKL\d
XM8BB.D'S8H-3LAYR9F\6I^%$UBZ6Q&>FM)R^HD%&+I+$@4P1"RA#+<QT?=!IRc
XMNWL0K"."APFF_XG5'1?"_H%Z_=W>6!*"HB\9BAS2)4TWG""3:@0XJVC=5SXLb
XMI99$V)B.89-)-0*<5;3NFZ3W@E@B2V9)"/@D\D"3%)5,6 .D=5IP!:OT%S3$a
XM2VAO8HDLF26T5"-HDK4CK=."*UBEOZ A7D)[$TMDR2PQ 9]$'OJ&ZP>)&N(Ez
XM]*01P .F&TZ0236")ED[TOH0I Q;^5T)H ?X)/(0E,J/.BT_&N<9 S$7X)/(y
XM0]\HEO+A1!@EA0?H=WA+.@$^B:O1?KXPE_@<QZ-)BDHFK!V*4N")%?Z%?!NBx
XMDG'>EA0"?!)Y* +/ 3LH^:M$>WK2"'@!/ !PR0&95"-HTK 9 ;X*A52)$*H*w
XMB14/ %QRX'RWI#_AD\@#.*MH-B*$EA]0D=4*459YQD!L!.@ -^"3R,,46 .9v
XMZB&1UH<@9:I63QH!.H TU8@IL 8RE6A= Z3U(4B9JM63Q(!/(@\T25')A#5 u
XM6J<%5[!*?T%#O(3VUI=\$GF@2=:.M$X+KF"5_H*&> GMK2>- #/@D\C#%%@#t
XMF>K?:HB7T-Y^5P)  SZ)/("SBE9WHQK0$ /4AR=,(,09EEK2"' #/HD\T*1As
XM,P)\%0JI$KN!;RGG_8""/ +@D@/GNR5)IAI!?U".)^():Z$G10&?1![H#\KQr
XM1#QA+?2D$># :L046 .92LJPE=^5 (IMC: ">9X@</ZZ&]7:GE$*2RUI!.@!q
XMGT0>:)*U(ZT/0<JPE2+THR&?AB /AUC)CP#!RY*NV-]%4 E$.NR%O/"8F(7Ip
XM<:^;C@VTNZ+#*8?-Z\$)MZ*:'23W&HTZ&O"]GR?"E'"[K'3:75\3<!!%0.E0o
XM1.A!QZE.T[#WT'IT- $'401Z@,IXGN%G(#_!$:0[#O((TAT+>2B(.%4V@G2'n
XM;*BP12,CIX07H.6HCXACJEC$J<ZI*55*3D:K2E9^'<QYUH$S@G3'=. 7+: (m
XMMU,;%.->@):C/B+.M1;7WQIK;0.^$G'/C5KRA0?#6]?1-9JA!/4_ ]7NZN!&l
XM/,6Q<YO8!X\@W4%Q?)VQ$3U0@,@J%7M/\UB;3]N[072L5]B>DFEK<:(Y;7VAk
XM2A 'C?\3B("C&%^1I--W0I6M.[;=A0=SGG7@+/?D@4%*<'&;7>EPKKN!$:0[j
XMIA%>X GSWHS>HC.N,@TB@:K% _D)MH$3$62$]DQ4%R>"67#H3W,B!$Q/_5'+i
XMHQ?&D. PK$X$A.=;\>D\,I_ ,4,F\N>@'!EY*)R(=!8?,8_'$)=T  _HY/.Xh
XME%_R4FX+QZ>:@M7#JJWG _ 7.M:JX?&J-ZL$W\ +O!25P?)Q9?=06%]"#B("g
XMB%4^T 3@+W261WZXILLU6YDG6X07F)<JI&+&/JN,WX(AN(IPXE6%\*<O_\J&f
XMMT2S6RS)V,/&1GNK""CY(.5_>L8E6Z]Q$ ]2\G "\$^4GIDQ'(':D"T!H*DRe
XM9TZ,AJ>SX J;X\MAU=;S ?A;,M2$6,PU7F!>JC FA)]61<S<LJ/3V&QEX=4Cd
XM6H%!ZID/V98@X"K(^O9Q(IB%"G !) ,-].$HD1)LQX*-(<%A6)T(",^W_C//c
XM> HR+/O4T*P BO0R:ST1 D8Q1-<4"0)4 "AZ520H^*,%*.3-],F\>5C1E:U8b
XMA'K6/DZ$@)D=-A/\Z.[$H0) 4>VP&QZQ; @V2^_RZMG ><8U4'=3#ESL'>C;a
XMML2]J<]1M($3X6;F _ 7Q_IWO - 4U6U@J0QS=C387G(+*6B%P@B\C*%6?6Sz
XMP!NN"@")"EGS"TKP#;S 2U$9+!]7=I.\=>M4/L+0^Q"T44A(6/AO!(=A=2(@y
XM/-^*3^<1[L^&+?$"+T5EL'RQH:OYNB30:_%"[T/01B%G8P$NI@3?P N\%)7!x
XM\NU8DO-&:"_-(2-$B3YM*+\P JS5LN-@50 *)X$A<$F@@!1( E9@010!F=,]w
XMID 6: )"X G$A6?].&_P$TE;%JK*J_('1X*"?_F=TT_W=]5*/- >-DFN&%F0v
XMP5J,7YQP*ZI99;!\JR(V*,$W\ +90,[& I(\\:)J_3O> 2!1P6M;"'I(OLM/u
XM53QPS;*1*R1F"#8,.[4F&5UR?45*+]CJCIP<:'@Z([Z=L+]RG9PRD)\@L3W(t
XMQ)9X^M+CV4I!#DV/I<UREM;26^H$MF?W_)[ATY<>3V!J!U39"+*KW<,P=::?s
XM"J7L0#-%@.*%8DO3.<59ZX4,@%)VH)DB0/%"L:7IG!(+9XJ#-N=6]<T0JWP8r
XM7I'W9/,$OG"+AMO:Z(/+Z:VVJB,M CK8A-5K*#O]C2"CM#;ZX')ZJ\+5#C"-q
XM-);5U(J$PE>L#2U@H&+F3X,SE@@CQ6R&M@\[D$$X:[VX$S&4 ]E6UA8J]CM]p
XM[<AJEWR!J1GZ >T 21A!J6*'2:0?Q!/^,\_8VWE<F@F=#_J?@6IW?:2R9)3Go
XMUP2"@<@92(LA_ XU]^/[+YD'H C&";/KV^7Q1668I((95?"5XC<L8?K!^5P[n
XM?#L!L&1:77+;8'J8G3U)I!F()B3\+U<&7+Y\VPLYMS[DCO.H\YA.JZL(3(?4m
XM*F!'8@>P=5::#Q-6KZ'L]#>"C-+:<'$M@$75O(5Z93)&_JBWPJY.>]ZHP :*l
XM72=\(N:$8E=4I\*0H$J'G2H#^0D&'9_1)0YRT/$98)-#RXN@XS/ 9HV0RP%Xk
XM=&0U!V=S^@CE"3H^HTM,*2[]%&))QJ[)+SD,Z.2:W!:.SQ?@9WJ9+6\4$6 [j
XM%NQ9WL Z OEI!W_A/UO5D18!#;C%&GV_8-;B\I\=5VLY3YY+V[$WR\82JL$Zi
XMC^G<9N25/8*.SP";-8(4(]S:<3N*DH,2PLW#UQ7=XHIP]?(-"CH^ VQ.;-W-h
XM I@E*4:XM>-VR.5Q%1N@MK]@EKQU'?E6,@ #]#)#RPI38'2MP!W&%];[JMCGg
XM>U#G_-D _(Q%> QA2/%AX>6%+/R??5CI#=>+_.IHKO+:Y_EX1)MXU3HFL!'.f
XMQWTO_L 9'3JD*#DH(=P\[-P\QNQ*Q9Q0[()$2!-E@\T974N'_)0.6ZKE\K@Je
XM0NCAB9B3FAQPSD 9)_Z;Q!ZAG)_RB\>KSF,ZMYD;WF""L"7>@+]L&OOI9>0>d
XM2Y>:<H6/,$J$X4BJZ>/ $F.)A::I&'J4N8$-O:.\7TIP PKR7M2CTL87=J6'c
XM2PEN8%8WT\< J)[%MNIE>)@VF2G_V91?E5!Z(E5)"&XHR% P2(A6=E<;RF=@b
XM,]A\-U)"4+I 9<-'Q%@;.?HK'V%8RWFR5$Z!/-WH;,,FZ6BDCD-,+HD6I-@ a
XM'+@.&V23=+1V"IO3Q*N28O,5&'>F6IGD_A-.F5P2K=B7C<2K"N%/7R8"B!7Rz
XM^;@*!*LR266P?+[*]2%!VP M55">SB0G @%)I 9D&^"/;$X)0>D"E8WUMK?Ry
XM0J*J#):O@MX@-Z @%4.0ZGU?-24$)4*4E2J#Y5/ML421;9(%A01M0_9P PIRx
XM=G31WO=54T)0*C]*\ V\P$?(%># ==@@FZ2C^8A,BT5(B'E>$K/ZN,6'KE49w
XM+!]7OO?,HO75O(4ZA\@#REEW6V'-Y9Y3C:JT"7-(;3ZM,E@^U8X6PD#O0]!Bv
XM&99TH7^'MQ+@PQKKI6\-H9T[SCE)Q=DZK4:"J>?Q^0#\<<)#X.XS: ZD,6R4u
XM5/A: 34K$IM$7K;4J1U\:.4C#%S92)RV'8D1-=<, E-&X=\% 9WP'NKF?N@/t
XM_Z&<<4-[KASN<66P?%SY<0WD)^C#O=E!]N&(CD/+"Q^.Z&I$5I>Q(P0&V@;*s
XMX\.]V91Z"6+ #O0R/&Q.*.K "PXU^27/3RRADZN"2^Z/*Z JN&328VSN<%LXr
XM4_#G)Z>$)^!5,;Y1$CJ)329X"3D&,MDRH_3+=3>J 0TQ\ +HP+IX 71@7;@ q
XML>"^UG*>-"A!J?P0,YH@%C3K&7K&H;A<X0<;G1+*H<NK9\.F'N&-%6"C4X)?p
XM-[SU;-C4H^SAPQ&=7B H%D5AB0"IY#88'@(\-MG#AR.Z%7#0RH*AU0L$Q:(Ho
XM+!&@Q1.O5Y4/,"@VS( 64 /,\Y*@X>E,V-5IVIL 82 &0?6[MBJ9$L&IU%N)n
XM^\D]W<$QH/I=6Y5,"<J)$3S+'O7]J=!@FVC!?HFNJVG8^SI&> ']8W"RX!GYm
XM91*4R/P&\A,D00>9K')H>4%6:P1A7E# GSU0'A(TI5Z"&.!F P$/]#(\3)M4l
XM<G]< ?DS"50EKG-Y7(#(R,.]["C$2++QD^V"PCB/U$BQ;BC"S!7@#P2T"PKCk
XM/%(CQ9J7 ,XVQG!@56LHC/.(SQN0:L]$!8.$P!\T\*H64,= E71YH1L$>*G[j
XM:$[.X J%]2745A% !!3&><3G#4BU,XV<L:#@9;8JK**=,7P@.1"".*T. ?[Mi
XM89/,";:BIN&/][$+"N,\XO,&I-H7.C;SS2* K)8%N"12[(+".(^TR9]F$L*\h
XMH*+6R\D>9'4D@XH50,"5*Q%0&.>1-OG3A[^<'A8U2A$P@(!3#G=*5LL"Y@,5g
XM*R#,=D:MH3#.(VWRIP]_.3VL'1QF_=X3&'/ GSW<%6(8[0@[3[!G(X1#)*](f
XM1)O\J19-Y?+.0-=;8=<<%$8;B<9/H2IQG?75^!\G!/,5?X0$"7),=1[/G&T8e
XM\;$D8Q/EM\TSFD91/MD\05 %.<['?:L2UQDXF80P+RAJ!+?+0]GHD2B'.;!8d
XM*<O=_0)KZ()/( JX@/ X!*) +,8B)$2(*@4][$]G<+]4%MVC3Z.!@?P$43F(c
XM]D)">R:6"%0.HA\"AY87J!Q$N^%M=O;3SKBE9PL%1"-!RH/*0;3ZBH]I82KTb
XMY$_5XI99]D#E(-HI*S__T Y5DX8R/2Z?G.D$?-Z L@<J!]']@@/1D[./(.B a
XMRR=G.@&?<U6[9(SFD6((1$7X5_L]*+!00/28NZB+#?SV!]<$W[H'*@?12#!Gz
XME;P)&QOF\Q/!0'"4X:!R$(T$D]=W6"AZ;#[?)(:#RD$T$@P5E0(G,+?T!_PMy
XM&8_U9D<+WX<*]2HTY.C'(0*(5<:N*79C7U5V-RO5J!Q$(T%M(EK7SJC>NQ6Vx
XM#5P2EH::SKY&;:-\X5HHASGD;PJJ9QTX)X(\RC4)S1+)F0LYR*@\17!H>8'*w
XMN]*]0.6Y*%N9)T[,#=.#*+<-E >5@X8I19-[&1X.OD_AJN9/8\-7_&=3CI88v
XMOQH*C.Y![H%%WT\12%QA$+K@G!66AVW;R^;R52V@A=H0_KBW[FB"S7_H,XF2u
XM0[)*33,*<>4&H?(4(28X:[V0 :]J 1T?X*H^MAEA<#"P6DS( $B&Q/MM]D#Et
XM78E$$@G.*@->U0(*$\#U*)PAC2.>:RCZD &7+8=D%1F0/5!YB@!6K3R#<-9Zs
XM(0->E5!Z(FP%\/=]P250P8[:,,])  H$./6L)G#=9^<9,44U8=]0K[+PX5@_r
XME'J!("(O+&Q$-(<Y$M(4Y;/ &ZX* /D\WF(K_[>2>C/F57ZJUGJ"'CQKCPBNq
XM147WJJ' J':'DJF'_H-%DSO7$PTA!$&',(?4!J%*WWR*WS&+4 FNUNR@&@X>p
XMH2JVDF=-P/V @N[1J8ZWDG990.C8P1SHT&/J=?+&5(F)2Q6_&\(?+S]LQ<DVo
XMUQXQ$B6?_4=#Y$^VZ;.*R@T7[PS3/GD<GW-5W&FJ41[AM7-/-<!=-J^J'!+In
XM/:YIK 2)*XP*,N^8NH/+.9"56?@/-0#)D+C"\'5)0 UT+I07^Y2*.:G) :>*m
XMQ(;4EN(E[SK\<C[X#&F<&.#32+\V.4,:YSMKN7\'%72$-^L:Y [SU.108=BZl
XM%@ T52\#,K2[Y%7?\ZM?,&MWE/&L!X%1[9A#:LM."@66\+7>9-AP_A#0$<\!k
XM.TBW1<JW> 9\&25<X*E-%RY J:>+TH0E?*U(L14\0E5*GS24"5X"_Z*! FM6j
XMGNRRNA3$7W2FOZB"*V)&'C@.+)&</4#.*[1G8HE S0>"0\L+U'P@:@1J=M2 i
XMZ#QNU[V=0'C"88X*ZL?PM'GYD9%3 FH6"%/J)3@!*2 &N!E>$"]L($W,3[ Ph
XMI5Z"$5C*+]DI9 7JSWCHI[$Q$BSZESWXY2$R8B39H O%V3\Q8>!60!_1",@Bg
XM,8S1C(":L5D>T::B5> Y51QJW'.O6I41B);VZ$YU.H7!W_4 <PGK;[\CY^7@f
XM"IO=@!/P4X"*)V@G#N&HS\W#&K\G @%1'!'^,?1H7SA&4P7^(!N.@H Z/SE[e
XM@#YC+>?)GYP29F].:OR/L^++A#40L&(L3>Y#<:A==<.K[!=P11KCM"T!.Q16d
XMO@7W^@A1FH#D[ %^BI1Z5QQ<5E^TW@RL!@IB?9-H+ZW:1PLE\N6;]2D'.-[)c
XMY@F@LQ=F&"%\-UK5.'W*4Y0W&"J"QB$.1+#1:=/!%@H_^ .GI)(X?JH<0B#Pb
XMCWHN$8M./C-UR&FAK(%>F&'TD@DG4VLY3^8@(O#&. 0X3U+OR*\17"I)@<B[a
XM)JF6<LP'=]1&.B9))=SK(T1I I*S!_@I4NJ^6^QM7GZTJMHJ F9O3FK\CQ.Kz
XM/Q$ :*I A82"/WU9 IYF#H$&LAKQSU1!/SYD#]1\($ %.AN5*<&O&X2 19N"y
XMJV\6 :CY0/  =#8J4P(4X!#2.EN9)TZ,O,QS$H "'$(@\ _%I=-XPF&."KGYx
XME#AX1+<\>F$,P1F9HFN!$3'";Q[1^X\- S_W1P7&?N;7G#9L0_@$#Y@2P0G'w
XMAH12[W$TL+UA(2'?^WEQCD YM.C<HZH1LJ#063@2G"]8Q-->=!8;Y@/PQPE*v
XMN!JE.'36N1X15(@D27++NX'9A<^GDMM%?G/(WUQX(U'EUP9J)MBX5ED,B^[!u
XMA(';?<U9F0CXBV.G<Y%E&SI;'J\!'#$>9H'QRD:/) F'TIST87*'>=:"S"'$t
XM#O).1N.0M:#,@SYB#H?R@RX>368D?OX$>D10(:,J'3F5!%"S0+#7E6[ADZ#Ss
XM:X>_CB<,.CS!%8G-W?;9.(2C/GEM"&_QA,,<%7(S?MJH8'\ #9OM6C,<: ;'r
XM%6F,T[8$[)"S%QJCB$3;2"\0Q-C!'%(;K$;- D'0^0V\G#_J+2O9O'+=P8UXq
XMLV+"@LZ,^.P4[EUE*_-D)-#954W31#:C;DK!5@A-[WC-) X^]5K*A,B%E-.$p
XM>DRJ<"2.=Y3(_!:G4J<."?!(#N0GB)K1@$ @:D)[)I8(U(P&!,*L4*6^5'DRo
XM3Y!#TV-ILYREM?26.H'MV3V_9_CTI<>S?*)F-" 0_N.]<-1@$S6C 0E%>5 Sn
XM&A ([\^<S$]I:DXY1+ ["F<*_O1EZQ 09D6 @$TN#PHXB<B!NAY7]D#-:$ @m
XMS(H0-0<J&6RM%Z H4/@,L*FPJP1QB Y=&+#*-GXS?'FH.T7-:$ @_$?Y*5+Hl
XMB<\ F_NIK*-1H-$?Q#K1O38+C5&(&RC (=" 0"!J6,#FV+[8@)JUD5HH0KN9k
XM8\I1;\<L4#,:<+(1A"  Q"7[1JJ9A/I=<7T"OZ,$%0UG@TW:5HM03=3"#5')j
XMKD/-"Z+:^(U4L_X@1=%:B=O&:00F2*@_BJK-R?RLJ*P:JG38,9I H("3B!PDi
XM.W7UA6/D(Y(/:X_L?&%;C=>QKD[+3X6]0CI[0I=A#&$3#K)-6,@IP2:HLGHDh
XM&^;PF[ )4^HE- $S$!]Z&1XV)T-B*;>%9DH@EW);:*9N0(PLY9=<%9"XPJ@@g
XM>W@%/%481#^-S1UN"V<*_C2!V?PH/$>TR0-&0N,\XU ,FQ'@8=76%>E8WR>Vf
XMLI;S)!K T15L4S7^QZE]ZME"GUJA&#;K220=&^K9?G@)9T!SB<IR1"K=LJ/Ke
XMA$\$ )HJMK*6\^2Y(@*(53[ JGJVT*<61.J$_=P]A&+8[ 8N!Y)&\F3$/?@'d
XMS95)MC&&RQXV 4C= 1Q@:,L"&XBN"LLO@P <8&BW,08Y]B @NFJ<>I8]; *0c
XM.F@*2P38#I='F_RI_AWO2%QA$+I'FMVRATT  2N@(R@L7UG@CYNW7AL%M)Z!b
XM -2 BQ/)^*$ZR@VRXO\?Q!/^,\\H4O6(\^77;?1\80F#-M#U5M@=MRDZ99] a
XMZG2R)6_PF8\,3"UK;*4@ R!M[B>>K/F84'4]0_!8X!EK;"2N, C=Z'@]\%+Wz
XMF5I*S<5=TT\I\*9.(85MCS@LOM1 ?H)$"0X<9*)T'CFTO"!*Y[%&$*6"IBFRy
XMN@;BQ!EX4 6-.-X?N()%@PV4ARC-S_AH;.YPC)0++6Z9,4 10)3.HUX@*!9%x
XM88F \<.SQN]3T O79J$QBJ<P?GC6/FNPROXCZLW'A*JA$*)+\WO;+V1U#60Dw
XM+*^*!X!$957LMB>"SQN0NB<C^)RKXLZ&$X=F=@-RV64@\5:)^/9!_W,=N^JQv
XM 53D-?:C$(N#X,IW9^MSEE\'G_NC FF+_LX+6IP?,^JHNX1M(&M-@Z\5*4D=u
XM-.)X?^ *%LWG.#^6&%@'[D$F2@-W(:<$HC1P55GID,@4&7$$UH%[W*9H*/9Pt
XM*8$H#5P[/+W\9QIDQ*LUQA&E@9M!.&N]D 'S(^[9AJ:SW^FK# H<,V0B?X[$s
XMT<J*-"Z6'%EA_)AH]:PF; YDQ?\_B"?PA2$@NI[6?V;DJ<]5M*$$^+"6,!(6r
XM&F8E\72/5N;>'Q%I@'?QJE5[L)3#,Z"L-SM:"2119BNAH59WF0$V>5@H".0,q
XMC2?8GJJA@M/"3C;LIZ*RJXO#XGP*J2X6F9+-2Q+2H4),/H79HVVHYH/C$G3=p
XMC6HXKG,]HEXA*G)'UIS97G7:8X$ VS%F%\B2>;&(:XRLX9\O-!13WW-4Z=HAo
XMOP*J21F/&1C(3[#:Q[V#7.WCWD)."=4^[JFR>M15)Z"-"*'E1[2K?3?PC2A/n
XMM8][BE@-KM885^WCWJL22CPV[9/V6&2>DT!0FJ)QC^\!"651R$&H:M)0HEWMm
XMNX''2?S3]'_73AB$K0SD)UB/%.U!KD=[ET/+BWJT=VM$/0I/>&FL[]UY[/ _l
XM"[SAJ@ P2WNXE%"/%*TB5H.K-<;5(T7[JH3231)/J'KOSF._%Y0>W(XO:B1+k
XM<1:IAK=$4W"-S7(/D/J4/K$0V'J&ORFHGO6I!$Z3*=>\@P;Z#XFRJRH'SCD!j
XM =".G\=Z;@EMB$JFY%#R.C*ZK&1<BZ/C]1BP,0W&(@HUANM>\E0X61,@Y@G4i
XMAQG/XUB2L3F9)_5Y$[H,8XB>=9"5/8>6%\J^1LR'> A5!M4]S<@I0=DG!="*h
XM>889:!4"7 $/5(%A!EJ% /]'/SW%#-3D&$DV-HH("$J$*"O-AWB(4K:I@X-"g
XMYV= >=ZH\/9:50[2SKD)(%[5_ !_O$]*@ JW4KC%0Y1BZI"37[#3G[<PM*HJf
XM4 F5$Z<-_5&!#7"\K,8F7V!#R![*/J#@@1P4E A15IH/\1"EG)+/(BM4>X+Ze
XM@\KMHEA095\6SL(+X/^7 K;&!NK#*!N#<J* I6^A+'7P="@EU/*HH PM*T"!d
XMFGS<XD/7DM1("=^7>N$6#U$*%OI%(Z2C)=ZRD?"5CK.7 RY?OJGX^1 /40I#c
XMG77&+<R]H@3XL&[P$X$"UI9 4 $JD 4(!!78/47@E R!)H 2J(<P1!#/$ ](b
XMLS?X8R_2&.[S3P0@7E6AX>!&_,;WNUJVR@Y%\"440( 12 #I\D8>I(V/<K->a
XM# C=XWT.?.(!EO6X/ZIBE99RC0RPK$<#@N2ES@\[8(#!@# +)A$/S#"CYJM>z
XMPH @J1<2( #S1TF0!P,J4S3 8,!O"9+^* GR8$!EB@88 0^257YMD'.YYG=Oy
XMM_SK24 .-*QZ\R4%P&1IB JY9X!=@2#).I=35\O@K6D-#K I$"3G@'O@64(#x
XMSDH@"A3YKHB3 V!- ((T#2,P!1BN%@B2>B#L/"L?9KZH0) ,&\^BC3BGO_N(w
XMUB^!@ +6ED"H!FM+(*# $9 "9A=OF9X*M*O#44'34/,A'A8A9+JK8T-]R!WGv
XMT=JZ?.KU=Q]1$" "1$ *$(@IH 5ZDM2VB>KG4?9(G9>/Q_I\B(>JG78EBC= u
XMC10K]?J[CTA=#P$KT),Z6#RT")]%5@"PS2L;QI!16AOS(1ZVM:+3D !2]Y@#t
XM[H%G<3[G]'?[/!7( @E ++T1"-<1JS1;96E3.1XFKROV=_O\[N'UI8E+$(>,s
XM8-^.+Z[(31CO5(" F2Z&"WVV^];LCWK]W4<T!)H 6D*+A2BK-/YO]'^G<CQ,r
XM7E?L[];W_!IC;\-.<_S[*('P?S;@<</6?(T-+H[XFZ>QTOI2>V(^$20AM66Gq
XMN0I+R#W1&O$@T;.Z2YW ,_8VG%WM'B^BPHIMR5WS7.M+[6.XS[?S8T1!V]P3p
XM,2=5X+*ESDK]!O[=KV<:J;.A*M:ZJ^4D\1Q@DR^P(?"/<.W@1CSEZZX= U7Jo
XMYC9DIS_OI9!0$;;3=X_-N[]J\L"Y5@S.7_2<.<!RE$,)1@\%U;.VH=:7VF%(n
XM8. )=6RAG4V6Z=2X:YYK?:F=H=K0=E3)7L >X/\DBO^S 19P'ZA/&V !9L Bm
XMF($YT =LFX6G@*5OH?A@8Q2L"F6QQ^X]BTV^P-_0!\<='*T)' (-.%GPC/P0l
XM2<^:7>:&H'$(-'!N'A8-9%(B6.&-K+#!$QJBG6.3+Q!;H#PLP,6>*D]]"54 k
XM@&RH+/< N5P?'AI(:1"I$,8>;R-?HO0HQLA7,>Q@U8;8Y O$%KB8\*ZKWEI<j
XM]X Q9 %KP!CV@>P#2\B]!D0/!=6S<N7QFN_>.DG0.(W_&\6&7/F>/&]4N!02i
XM2K777:,KEF$)N=_1>R%;WNHVL!<8/N:34*I=J5 !*K 9D+C"< /T?'_5Y(&3h
XMZJ38WB);H<+S1H5+@6_,J(/#:60J>=7W9V0KXEV0?*HU.1/YH_\EM8S2R#I#g
XMQLA7,>Q@Q5WS7,= E;JY#?7]J?#W<]9QBP\7[6.Z5W_C,Q3*Q&%SHT/ $I5@f
XM]5!9(JVX UY(:,_$$@$'[L!#X-#R @[< 3=,SV 5/I]*0F.$4AXX< <\U5Z6e
XM"RUNF3% $0 '[@ 9\ -^P _X 3_PJH3231)/J!J?3R6A,4()JN?/2JA9&XDGd
XM5*U.UV@^$QI!M%4C-S3^HE@B !H#<. @5[+SR*'E124[C]7$C*>(=N,CMH"&c
XMXW"4IY+-S_@X\,#Y7H@!(:"7&1OW %SQ\!\&YWM!!H2 7F9LW(,,4,1J<+6^b
XMB4IV'D'%ND #,2 $A*@YZ'U2 A-04(-G3O$/@G"+^!QP4'(@\P95LO.X+M" a
XM# @!(6H.LF9PDQ*,@)8;$K>(SQ4;/*"7&5I6D )C8'X*.VT=TNQ#A4?]5ZEAz
XMV4+A5ZU3#L^X17SN7],/SO>(OL/$(UF175';![R<'K)/#44?P\NV=;*>C1#Xy
XM14<[R/RB$')H><$O"F$UZ2@"100+'<W4);8X^ T(_K)IO$ E[(XI#[_H:%/Jx
XM)8@!I=H6C@_\^<DIH8,!?Z%S:VVA\ -@3Z&B(&A6$M=1$5Y^@4+/'>MEMGRNw
XM3+G+JT?-6.@<8I!Y@_A%(23%U$*Y[J!^0>2)+BFF%C! +]\@?E$(6\ I)L4Sv
XM7B.<RR-0&[+EK;6%P@^ /86:;)Z3P YB2^='T/F-54'D4?4Q;<9"1U0:JTO)u
XMND\>)-)6/,O'K8I]KJ+<<;7>[@!6YO&+?^<84+WN^6Z.NDN8$I33<V(#E(UNt
XM$W;8A!HU85:(!6Q8 QX73SE0R$>A\"I!>#USB#SD<42:STMU>S=5^1YLQEY>s
XMIU0^<L6N(K$AM8%^KXKZKU+#LH7"KUKSXH[6M9[""Q1Z[CA.=ZPW9BL,2;_8r
XM;2YP:;#@C5:4TLAJ[VA"@PV=/M1?*3P)02AUI-EO=#1[K;D"J6+0PQ75J5CZq
XMO1FD*EU;?R)F9#?+"D[VHEBB!JP6[N\@\XNO.2LXM+S@%U_S/]X+(I) C.S&p
XM;G]%<PMH. @"!8; "QC__B(]]A_V2'GXQ=>,5&F0$:_6&!>L6 (8P.@YCE]\o
XM37T&!CP"*1ZXLUEQ9I(L]P"Y7!\VSTE@!U4+]R?H_$;76A N7P.NOPY8-/U%n
XM/>I:B5+W99)(8NUZ"GM;5@)K1E@WM2 S"$03: )$@ AD@2R !B*IN#QYE%.Im
XM?,U9T7-BP[3J@W6)2E(@ #93H, 0(&NKW*O:H_#X!"R;8M!L77 (1(%A\\?Sl
XM_!,)1//YB:S ?X>W[#UJ>W;UUX>=-LA)Q>NNEN-R?7C8"'CT0)[4W\9>ZM"^k
XMH'I6/6<RY9J$9HD:D R8@9E:+FIJT=. 9, ,Q 8.+2_XA1G@J>3!FD1D&H(Xj
XMM D_HSS\P@S4Y&8*>?R5-,T*>_8+G%1;UD%/1JLZTB) .^<FO9  VV5[+^07i
XM7G:Q^ZVEK6.L5TDB\"<'V8[\>^'':XR-Q[!?J\8; )BE;5",XQ=F@*>^A$M!h
XMBA%N[;@=#B[G0-8["AO &[EZ;N8Y">P@,F &:K(&U*[/C5J:L"/5"U/?ZJNPg
XM5^@1:2$5'V.]"GF7O.-U;^>*K$N.EX?,>AYM0.9TCSZ-!G!^U7J&1R@><Y4Mf
XMI)W<808W/;6PPY;J( HOXZ0ZC0]O+?72C3'\B")1Y!,#:EG-;Y4^-SCQTT9Me
XM*YFB7Q"5L+-"4%$>8(([>T*780QAMFS.039;/(Y#RPNSQ>.J24!@;>=PO,;Ud
XM>SP>BJP9'T#6-".G!+/%XXY/-34::E T6= 14A"BE=GB<=[G;# 8,YZ;L)EOc
XM%@%FB\?YA5,, 3E*3.%Q^G>\OU5<3%,\!WFW7>LJKM_C\4#?()O@<@DN("#Fb
XM7LU%FF<UQQL=TJ&,APV>,!W@K*\#472 /=S):-Q@P296#]=S*%IHDXM:-O2"a
XM(:$JMU<N!^!GO."%9.35"V:%6+#3P[O+XO6AOD^*6?GZB,!V2D)\41Z_T^I$z
XM8%336_O/Z!;B"V;+YLBUJQX;(MJZRQD:ST?<^;23*^QW02P_+,B<I:^U<(Z'y
XM5CJL_)ADM7>T"15#6E_-0T'  N>I,9/)!'>V"[ !$[H,8X@3$62$]DPL$2>"x
XM67!H>7$B!,R]V!)O8%8$++]P(B \W[)UI,.)69U!"FXR<DHX$41WX.=^AZ:(w
XMU>!JC7$G@ED,? B8$OQZ#44?>T@O,[2LT#?2&2O9$F] CP6L^,'O2YNM4RJDv
XM&2_49&WR0=NA:HI%;RWUT@WSRAPJ5\;K:-2,LBPJK_19SD!-9H([VP78@ E=u
XMAC'$B; #!_E$V(&%G!).A!U092<" 75^_AN/JYWB37+_"=^_9JZ7$DZ$'3"#t
XM5JJ:*F(UN%ICW(FP R*%HR"@Q9/D&LY(*0))3IN0G.]:?K5JO & IJJ %D*Ss
XMWW__/K%:O%AE+Y1Q!-3G]@,*BG:6?L'.U[]N[%$0$]S9+L &3.@RC"%&R$$>r
XM(<33EQ[/5@IR:'HL;9:SM);>4B>P/;OG]PR?OO1XEL\1HLIN$6N3#7/X38R0q
XM*?425J1XZ1/Y,RU,!;%PIN /G))*.,$&CJ!4$22WT1^/6;I_H1@23[67R<:1p
XM?LI3%*3GIEO$VH+D0ID5)YLG\(5;--SN1JM"-AQE!.4FM1Q!XFJK2E:WR0B6o
XM2,P#?)BR;Q8!(T2D<)01E)MH4W#US2)@A  IAZ("0!'+&$&YZ2F HO65?!?*n
XM&NB%^]SE)#F_)P6"RP@TXZEBATFD'\03_K//R:_;-71MHU"#.QGHRU 3HL]1m
XMC) _I,>*%.YDH"_C#-W@BQP>GT 4X&5=< A$ 2$:'I] %-@?77 (1 &.Y[AZl
XM9'X,2V@GO)YJR0N@UV?JI1NSZ\+R!9SA,K3OS,@).,')G9);=,;!BH_N_4@_k
XMD&Z,BEU%8@-1HD\#^0F.$,6U783V3"P1(T1Q(;@=Y?U2P@A17.CS7N1[.)<Hj
XM\7,7JQ=5SV%TDXC1'E/""%%<A#@)Z 6CDC[0 @ D*M?F4[6X998]1HCBZA[Di
XMT05TC^(Q4.8'%S82"211XN<B"1VD@W%["N31!1"D5U_?._?NZAZUFB8 ?ZBEh
XM0 I'^K/A_YD%&D2_D"CQL[PA*M.W/J\ZEPH"?OW @;)=+##AH29TWT"[;$B4g
XM^)D7GZUZH=9CR"HO&^MMSFO5NW(BTI;V74(;_!EK[$2)GZF.<@-'V@%OZ84 f
XMF%\^BT&P(NMAS6G#:AW9ESKM:0'KO<CN+@DC5B[?D81]]7VN<7/9H.47E%E#e
XMU8D2/X>*_MK6E(.YQW"?Y3%L?+^K9;-72F))O;$EG0"Z2);HXPFP3:+Y#/RNd
XM!' "E((0J.E,H"J<@ 0@!,Q]\&I))Z##J&LC4!5.0%2*'2?"#,0&T-HT2E4Mc
XMR@FG]@0H!>Z)!8) 53@!"6!Y03T.,5,2P GH+D] ME>%$Y  Z@EDZ$DG0"D0b
XM3'==%4Y  N@5M@$<]:03H!2(0!*@ DR@*IR OT2DJTB>6QZ_*P&< *5 !*+Pa
XM$:@*)^ O$>DS\+L2P E0"E=@21"!JG "$L 52'43C*=(,\7:DTZ 4@C>3J *z
XM5(43D ! 8&_[70G@!"B%)# $GH 3J HG( $D@2'P!)Q 3SH!2B$)# $G<&.Ey
XMP E( $E@"#P!)W!5?U<". '=I0I(@2E0%4Y  A@"+H,G_*X$< *4@D0'@E7Ax
XM!  E&&@C?U<68TF=K&<CA!'R.X7V3"P1(V21<&AY,4(6234QX^1XA%*>$;)(w
XM?AD[K:9ID!&OUC<Q0A9)#%VA<.,-O,!DU3=&4&X*HOCL#;S '9H]1L@BB:$Kv
XMU RH )8Q@G+37OU!/(%8\.8*RJ8+:H<MU6J9H=ZB,_YS&M#G)6W/%Y9,JUMTu
XMQJ.Q6D['P7[Q3-@\,)"?( T/,D)[)I8(&LXL.+2\H.$"YEYD=1D[0F"@;: \t
XM-#R=Q4?,@P9J\I7"PTIA!2SEE[R4VP)M8B5G"OZ@ 3R(!VJ%"L0]"V^ZB>-,s
XM @"S-&RN(!$P/9S'D\T3%D^2RV[1RL$Q#Z\ P&0[5<4V*R E\U 55."/F[=>r
XM&P6TGH5E'MJJ4C(/54'IX3PN^NP6EGFH.Z7AS$)A*:MBC^AHTPS-'C2<6:P q
XM0ZNPE%6Q1W2TR9\^_.7TL.H9G?![4J J%;4Z37L3( R$*X]/M<^;X9\O_N\3p
XMR>J=4L!ZU?KT0/%#COQHGT*Y=1VA,=]#6P*$@4*CV:$^C>/@1GR-=7!0Z%)Lo
XM8ZHU8SN($MZC?N'[\M]XW#V:G82BU/OI9=3-:$?8><+GXVGQ(7G)]S<"X?AOn
XM/%[PU$&)=K1JU 6?0!1P >%Q"$0!'YFJ<C;AM79N0W !0'<8&^8#\,<)L%^Km
XMQAL 2*AQ,>&U=FYC.:7Y\3OKE/ *OP.Y=QDE$A5?Y=>&,<W8HL]1B, JOS8@l
XM:?_M(P7VC\"M*K\V_(*&=U%<;*:?;)Y F_WIM"9T$D_00X\XV^>LV28!PUVTk
XMQ[T,7&%7N\=>H'ZX(E7PXK.O,@WB8 JAY0>M>04BJT07%%HSX=;NC\ $8DS'j
XMTI][V JOFJ$>RDQ2T&*1ST IU.OO8J]>HKUB $OJC2U)*1QP]35#$X"CO/-Hi
XM.FNR)EJE%[H#><D8!WR')H @<!N>%>:K9[$D8R<O\I(QH.._2@"V@XQX<3R%h
XMA:9 _&X(?YQ6TMX+._TRB;&#6&M%,G0'\I(Q.J._\J=N( % A5/A,LO4+M$2g
XM?3OS=@?RDC$ZX_STIRO #20 %3[R()88J6=P-&-O]Y0,!;3#+PK+NV1:$[H5f
XM0%IZDE( 1<-WE]2P>O+@" /_C<<+'EAT2J_TK[H#><D8H(A.Q9($, 1BD<N>e
XMXSDI)>\2O3!OV$KR(B\9@Z33*3*C!_Y2QF]!CT7I.'L4EP3T@![X5[SB/Q70d
XM\/@$H@"C"8]#( K$V_]EK1J>2^U)2H&D]U,H\)=R1\V;;I;LB0! /G^;C&")c
XM% (NX!'*@'_5'<A+QI! Z<R?T@'BA/SJ&=O@<YTP5P!H8-$IGX+#@P+=@;QDb
XM# D4['8)'2!.R*^>+?2IU0ES!8 &%IWR*3@\*- =R$O&R&(4>X8F !4^\A1'a
XM1^RJ1<54L955$1MF85[:3R\C]W0'\I(QLIB+]J=T("J93+R:*\:K2T!^_H($z
XMQ4V&RG6&S5-P>%"@.Y"7C"'#AN\NJ6'R/?P2XB0P?'>)2W ! 9% E ".!\$>y
XM(6FN2NMK#C%T-*!>FXB3I16>-[I-6?*2,608G0H5"6!Y3:U.F"O&JTM ?OZ"x
XM!,5-ALIUALU3<'A0H#N0EXPAP_# OTH RVMJ=<)<,5['[R4G2CI!KK4DI2##w
XM>)D_=0,)  FHUR;2+K]='K\R6*+M.IA+)?DNO\F)RZB_ET3M;3EP2$M/4@I6v
XM1F9"@03PIP*5O#%5; 40>>M4I'&DP\B+=]LT/#Z!*,!HPN,0B (#!]2-G9ZDu
XM%*Q,F=HE;B !0&4-E9)WR703QWL[@8AQUD2K]$*T>DA"1^-X<3S5'<A+QK Rt
XM>&!]N0';U)FTSU.P,F5JEPA.!\<\O(+BZ(A=M:B8JC.D3LL/6^D.Y"5CN "@s
XML;[<0 +PVBHDPM'>,[2I4O(N82LGK[+8U]7F595#:9"DMF_*DI>,X0+.S_I:r
XM 6X@ =@.,N(>_(/F@K-!IRLD06L6BT8OL.B4*7F7H  ;4 -R=DM2"BY@[_G3q
XM%> &$H#M("/3;8&<@2"9DG<)"C"U X>S9N#\ .;DF.B<N"8K=^0> J'EN@-Yp
XMR1A$'+CN$C>0 *#"J7"996J7A%J.IR7Z=N;5:QS$@T20\^@\ZMDIH5]PI2<Io
XM!2(N ]:7&T@ 4.%4N,PRM4M"+<?3$GT[\^HU#N)!%OK4$N$QY.$_IM@38[L#n
XM><D81'P&K"\WD "@PJEPF65JEZ  4RM=^W;FU6L<Q(/$6W<5*FBOOX ;?.[Cm
XMD)>,0<1IP/IR PD *IP*EUFF=HE@YGA:HF]G7KW&03P(V^!S(CR&T-UZUAW(l
XM2\98,&'@7R6 7\1/[CS;1]4!(VNR)EJE%[H#><D8"X9.Q9($,'NG0TK>)6SEk
XMY+GV"_*PQZ\8KT^+25/1WGK6'<A+QE@P96J7K  WD #PUJ9*R;L$ )HJMN)Dj
XMM?4SKH'=@;QDC 4#7*%  @C*C@XB>=4DO1=4^W[ "ZR)5F62A[^<'A9IZ4E*i
XM8<'(@/7E!A) 4'9T$,FK)NF] %4*?"]TF64*"E1X9@$#+E5Z.(_/N&1W!_*2h
XM,18,Q?:G*\ -) "HK*$TSC.N=HLJ)>\2%  #.-YTBX?=@;QDC#;SKQ+ +\(=g
XML*1(=$1BQ5:2%WG)& L&#ZPO,V";0O20T NV>AL:B3#QK[H#><D8O2^=^5,Zf
XMD ">0)+,;FR#SW7"7 &@@46G? H.#PIT!_*2,7I?L-LE=" !/($DF=T6^M3Je
XMA+D"0 .+3OD4'!X4Z [D)6.X@%JQOE: &P!*B8D,W'GNGI)W"0HPM5CH-AG!d
XMV- 9X4!/4@HNH#VLKQ7@!H 2=L @[L$_:"ZEC"76%PJP 3: X[&5Y$5>,H8+c
XMZ WK:P6X :"DCZH2UQ'G2>X_69$"CQ$U5TK>)2@ !G"\Z18/NP-YR1@N@";\b
XM*Z"DCYYQM1N_U=ZX28&PDR,:G0KQ%=V!O&0,WZ7/_*D;L$UK(%.EY%V2T/91a
XM!)I 'K>"Z7GIVK?)VL-?3@5T4T6D[D!>,H;OFI_^U TD *AP*EQFF=HE6J)Oz
XM9UX"82MYUAZ41>?1>=2S[D!>,H;OZJ=0P#;E!S GQSC?(RH"FJF1TDJ"X (>y
XM(6GI24H!M_PKVR2F<4^T>1;AB$I2(*#H%S1W#)"XL*6U'#0:\& R-YV0N#; x
XMT-Z @P8OLU7.;DE*P;,,WUU2PZ@ [G&R.+)6.#EZTY&3P/"% ECH+K3,^23'w
XMZEA+4@J>A6+[4S>0 *"RAMI4&B<E[Y+I%@^#<%)93(I*)JP=X2""%9XUBT7=v
XM@;QD#,^R0^-< J "JRAMZ9XP@$Z#<U;0P_YTC'E5_-J2E((+6%;KRPVDI3FOu
XM<1)(8/K[<#1CJ_;&1'M3\BYA*\DKB[&D3M:S$0*P.\C ;B&G!&"GRFX1G^MWt
XM#:M(07!\/I6$QA;0<!R.\@"[9IHE$D_^3 *C2B^SY9^L@@K\A3H8'W1VRH0Us
XM4!_&EJ?:RV1CG&)OGF6@6]L^XUE[)$7L[:=041!T<(7-;7EA53"]0! SOR'*r
XM:+NZ@MX@8 <<E%P9,+0BX!&6A4N!T4-5[;@=MXC/H04<U[^:LSL%=G$.\P$$q
XM'->_FK,[!79CPM !\:+.'#DOR+P9\\(,"!]F1( 08:0,G3%H0,@IT^8-G3(@p
XMS*1A4T:$ BPNBF"9*&=.1C-OWH@)(T>B""9OSH!XXX;.&XT</8)L$P9C&C<Eo
XM3[J  N4D%30@-W;\",)E&39L0(QYTX:H&S(@TLP!00<JB#MA\I#]B2:,'9!An
XM0) 12R=,SZIEY+R5HY6F'+5OZM Y&7=K5[M@W^PE:[9(V;Q(Z;@  >(I2#AOm
XMY P\D^:M&Q!AQCX.F:;E0)IGZK0I<S?@9S%E"+M1.X>.G*,ZWSBL V<M"!M:l
XMV\HI^K$E"Q!B!(<=V,8@<X$8&5_./-!@&;!B:'.-C<6JWKR3*YLU[!7LG9%9k
XM88,H@Z?,&,'707^5#G1.'39TQFZD4T<.TL2?<6%&$K4I))B 4KAP4A5ND#2'j
XM:&8)* 07*+!6!H(AL1&&3F*!P)EGQXTFE5 @G"0@@720D9<<&"(&PHD%!D9'i
XMBQN!L)H<9\3'DT_2G<3&0F%D!6.*,B(8WA&=X58B%B>VA :&YY4%@AK.@08"h
XM9IK)!Y8;/Z&F&FL#=3A:;8C19%Y:)_'X8VX]=0G45$,5A<9192B(Q4EXOJ" g
XM>VC\A <(+6BDAP)SQ'?""UY@\<(<+S1ZPD."@L ##R <>H)20Q#!DAXO5OC9f
XM1F.4T1E<I)$$@D%*CJ9'1RJV<:4<'BWT!ALFH33%2B+(H0>&6U#(FH1AP 9'e
XM'';D@6 7O$KHZUTGTI'&:D6:(4472AG!Q$3+AF'3$%"\T(1O53B1Q$I;N>&9d
XMLSS-4:L+UF+KJ1@V"7$436J)1-*Z[8JP;$D3%3%'0'" !!-?0695KFVS!D<3c
XM<7FI6^VU^GH*ATU0P/K1& /9"U(:#J5Q&AL;A4&&6NS1Y3!*^2X;ATU1U)&&b
XM13OL! =F<W@,DFX@["7&&X7B"_&R=-@TA44O#N@LM =*&]9G'_6$QE@XQU5Ha
XMN63X["YK=MAD15X[%QKS&S/S;/-.#L7ALD561\Q:'C9E4<8<QXWQHQBP\55Rz
XM;4IJ?')*N.HJ:4)EV/$"'73D$<-#@ M.N.$V2>&>J&]9J?&Z3)DXH!2[*MUAy
XM7'# >L9PKI8E$&ACA I'?I*/!%*A=YD!JZMV>0057X;! 1]?J+JATV,GK?I&x
XMJZ_&NA4;=B81YEAQS7D&&FRH53M)?W:>$^AV#@W2$&WUED-(F=F8&4@JUC72w
XM'';B>:>M4( 0@P)Z\NDGH'B10:BAB"K*J*.0%@K6I)6^<"E*F9J(_CK%FJK8v
XMI@QA<-5U/):9==U*@-=)EADFY*DRG,$-QY(@!5GC$!B-X3:G^X+&,JBT7@UHu
XM@73XPK] ."-I=0$$)DS""%V8MGW9) BE*\/I;'0?9\'!5.1!S%B"^!6H,6T\t
XM7"G/6-A IQIZ*B(3L0SWL/*&\^@.-#CZ4FMV%(:C0 @D**S*!]-P.B>RY@Q"s
XM(]IHSC"W(&5H0SOY3,&J4@<QX(T_5"$B&?:6,D^YP29/:!!@!&.[@12*)!B+r
XM#Q.1LC>50! LRW+("LDX$!Y,;B)2J(,<XR=&%L:Q:#)4'8+6Y4@1#)!"9FC#q
XM"^"0AC,LJE%]<N494.DJ2ZJN<3K44*A R<I9*BT[H(PEAHY"G\DII7),&M#0p
XMR#!,Y!DP9 J<BT_D4+R!U&4-;Y//>J3924JNQV.S"\GKEH.\+*[F+MV+B\:.o
XMXZ* R6%@;9B#;+;I,;P\* T\^61<W)# ^&AL)WP9TEPP**WC2(\,=1B#DF14n
XMR"7E4Z#12I#YS.>"*:1O?>W#R/L"5:C%!6Q^8#E4HEZ)/Q_@Q:,@X9^E,*4Im
XM4UJD< $CX&<Z2I8\Q!0Q+^C>!Q$X3;)9J0E%*15(MM"$( PA"4Z@PA.F@(0Nl
XM.!!7'84I2#2XK#$430H[%4AF7FC"#3)+6E)]X8EF* 4SNF$,:;3F>$+64S-Hk
XM"(T/NUI/TDH?J;X1KB@I951M"A([S$H'<Y&##J H@BGTZ0YUY:N6M,+6[KEUj
XM0U!SR#_'.DJEZ/6EBFW!0*B@$BKD[*^$'9I:06)7G(UFL@,R X9XQ%DL4(%Ri
XM34%)$D @6JF>Y#Q8 0J6!M(]FHXFJSW%:?=*ZY Q!4RA(HD/4!7:)I<(M7SGh
XM4XI%02 #]NU)HR#X$T?1 -+^C?1^_LM?1E3J/Y8*,"/+J@I4L/+4\THPE"0Yg
XM5@VEA0(N(24%I,S">275S3)B4I-6LDIN)UG&8\;6!;,U[$G$9!8!$^\DQKM2f
XM7MK@,?TL$%3H^@S.CM)0%S%4, 8EX]N.0Q3.6!4C"TND<98TDS&LX7.!F8_Te
XM0O6@$:OW*EDA,.I<U)':^'0TLLM+2'C:GVSB+$UFL<(-0( "(03&/V5(P8VQd
XM8J<@#!FQIC5+1VI$GGSJL9P@86)MX@.;']U!!TIQ@QF44A?JIH&Z+JC!FV?Pc
XM9J4@80I*(>8*8. "&<CY)&002!D2, (0."XU&J)=$A%SDCE01U(:([2A+^R>b
XM@0CT* AJ]*-M29+#/41C,I"TXP);:5 6"--*<Q%$DR:%DY3NN5:EK@]6E!E1a
XM4QICID[1BC*-A3"X0$:?IHP,?&""&$AZ"%P1 YT,6"8Y)(:0RG$1F;YBIO7(z
XM 59RT'26.%T&3_L (JH+=:&#,#/6/)L.#>716,/-:T=O6V/>!C4(3"!I(13Ey
XMQ;#2)%C4().3H( -8UD6&V+F:QE)F=Z%SB33[O"3%N,[QF#Y,E[,!J8T%"P/x
XMVJ[D/_EPEC%(F@H,;\&,WS865@9LD=QQM\9!P'%-IB$.+._XQ]&PD3*('%8Tw
XM+KF(4>ZC@'LJ*RIP@<<+S02Z@":W>EO/5Y1$S!,)G=< EVE68AB&%HSA6"J0v
XM=-%]/,>DPX8S;G"#DJ*$W@&% 4''.9$8T Y04%Y=6CV7.@A^H'6CSY$G-D?Qu
XM<%0L5!#P<S7RQ$+4N< %NA/=Z*=5W5GZ5"B_]S,L8Z$XWO))%#FL(>ZT_('Ft
XM:5EW'R?>5'=@/$C^OC$(U1P$DL^PC6BRAL#;H0<%.<@+0D,'28MVREFQ TTLs
XM+@93G<@.4/<Y:[)" CM(N@J-=W#.=A\LWP\(^'#' A2F$(,>T!():0A!IU)Yr
XM[+;HCK1FZ=RSZ!6\-NQ0W0/"?@AX/7T96!\%J6S"]W2P_39TWRXYHL_4>!+Hq
XMOY3__#]Q(O*W$3J (9CW<R!  DCP!$U0!)TW6B#0)ZLA%Z51:9F!<5C@/@D(p
XM!4% !4@@:46 76."0'(0'7 @$-R%!1P# B[0@M+Q&2TX&5?1>#%(&I(F0\SVo
XM$><T&%@P,"SH@@KQ@Y.A$$AQ@\4A:#NQ&%ZR@R @9CP8>HI7@T$HA7AG:P$Sn
XM.E (1/SG,?CT&7W"!GOD:J$!$C5(3#6X'G-0%+9W%:4F-V%@'<@QA@"B%5N8m
XM82>A@21@>" 0@GVR'GA03V3"'Y'U*H&#3P9!AX?Q%7>(721  B"(70YV CHGl
XM/QG(B"/PB'WH!JI1-SYU@J!C$0W#9,JG8RFPB'U( N*VAY#H'OQW)0NS&L4Ak
XMBNN58V-T.J58B:>8=87&AUV26Y[83\4Q%B@PBK5(![?H L34 GSF9VF@%"(Qj
XM47>247VH7>I%$]TE4O;3*.%E4BY!$Y)"*2L%0"W5C0'E*;B'14:Q%^UE2L(!i
XM2O\4@_,E!?6%=_AE65#5CD%G53Z@+A.!;%A1:D,0/)^30&-!3,I'$^F8%'EUh
XMCY+"CR)0!'A@&\0A5&/A.EP18+.(CG/R%K#E%&9!>F"1=#0!$L.#2!\!%CZ1g
XM(X_!%T?!(U*3D0BYD2!Q![=!. 6T(V_0:'5!;<ZV$] F&1ZY,4MG!VF 4&Z4f
XM=*Z!'& 4D7MWDLBA%AM!:AB3*@T&DR4HDTOC$TBV.K-H)U(D,KK7$QMR,VLFe
XM6]68;5B@&'FA%+-EC2H((:,#(\(A(.D3DZ,R1':AE$ A,OK$!CUV&K.Q)"Y0d
XM!><S!WDP9FUP'*&7%P@T%IIX(X$!-TM3.P*1!KW75PW3A9'%EEA$&#5"3.>Ac
XM(G/0.0@$%M9A)Q ID5-Y19^7318).^=HEY&S$693@7 Y$)RI/R>A'D61<Y9)b
XM$M"5)]<UC?#C'7MQC?5#4MMX8]_!%^3U/RX00.R8%XN17J-(G4*V!4D@!$W@a
XM5-)UC]@94 .R6_$XC_>57^<5GJMG%$@1 T)3%UGRDNKIA*R1*@$XGM1162B!z
XM3%+4)"Z!(7HD%V^0317V)B3"'NXA&%WXE *J)'$Q(E1Q$B.'4%PV1SSB:!-Hy
XMG.!!&4')G(N!H._Q$5^$B.6Q6(_Q&263'^&!?'5P<:!Q$D0Q9GR!6^D1%9HDx
XM=JSY$T2!35:"%%B&%.$A!.[QALDW.WLQ%BHI':6Q- UU$J]I)297!L<!H4N9w
XMH*KG&EPR$-Y'!J92,Q<4),@S'T- !5+ !"U !,<!&P$!AX^!@5CJ$7K).@.Av
XM$'>P25$:G-$XG!M5%6F@![$Q0-BHG(_"C7V:4N!87N(H0(4J4Z_2DF3!'G1Pu
XM'(%6%^PT'W8T%C7CIS[%.9X#.NN8J1=20NL67RXDA.5I7U&&GJ:TJ)<D A7Ct
XMJ&.RJ#@SJJ$*!1WI6F;Q$1$IJ0(1!FGZ()6*DA[A1J!:D=V#0-&QA&""19=Qs
XM&SUQ'<7C$%R"1:FQ@V!&B')Z')Q9<(*Q8,CS(%]"!EYI%@D48[SE$*NQ96KAr
XM%EVD(9?)/8K6!LKV'\SF8HLUJ5)C04P(8W=0%M[:J,\*%L3T6[.B&@&B BCPq
XM!%% )B[F ER L$,0!1[9(0S65T%2!W$B=K:C(4X)3*/!F1B1KJZV:%\QKJ0Up
XMK%E1KIITKC82%/Y7,$#BE#PR&M(SD*ZRF)]13QWR(R(3'V+A(W01'_HF9 ^;o
XML%&0KA?HL! KL;C:(;K'!A@+>5-2)6.B&C]F%D'&%S#1'W0(M6W@!N0#C=:En
XM@=0X!R2A0\CY7=HXJ%5QMKWQG.9E2F[+J/8QFN;FAU:ZH#X8%Q]20(_)B3BSm
XM?T7TJ7,+(ZPXN'&E+_2%JO685_HEMV6@0^H# T)C$ $S'R"JH/GD@S$  W@Ql
XM!BYPJU(4$/_(DIAJN>;F3\-E%D<Q%P'AE'\K9(%[N'LTKAT2H&)B4VE NLUSk
XM*@-DD!FI8V$;77E*ML5)'6F;C255%9MVJ- IG2I'MX^F3HJ',T$P!4<U6RBWj
XM-P]D2ODIJA.T+&(P!F2@6B;P+&X@!W5 0E( 0\KB*2V4!&\W+9315<MRGTE i
XM>L?BOA.T B=",S&PO_;K*?_+,S*PO[2*(?"8N.(K-&M 1DU8FDK2>W;1>HM7h
XM0#NJ))1Y&XX&MF:%5OT(%?9ZH9$;%@Y!O:;2(2IW'695-1-!!+N;8>27&2HBg
XM6&%Q0=]S)9J$,2V:869%6$8P*Z99;K0SAG&D)E4D9 '1,PSL*6E@$TF PS5Bf
XM7]>;O0K3E UC5FU@$TV0%_E'FBL<DJK#1S_C1S;A!%]R&U85O32<%V;U!F<,e
XMJ=2J1<?CD^BF',:$,F7,&C6!28'3,."W.H_6QC71Q&!B$T%,15:D$WK',*9+d
XM&E<!%H7RB]-D5G5@$PSR<E'+*B"! BI"$E2!4#^TNTBXO8W+-P+T:,N2OD(Ec
XM-(^&38?I=VE,REB1!U/ZQRW!PO:8REFR C(@4S30RA,Q!8^6.SJ17& X%K_Lb
XM(C, &F,!RZ0$58_FRS)%!_1WOW:,R"\#AGA!R=W3(2=2@&9@J[OLO;WL LV\a
XM+"Y@ ]LB'(X\%LU<%OFV/"!0 _ :.F8!S0;&F<2L&1EG1#?#%ULF,&,<K7[Wz
XM$R)9(W:+7"]#!FDW(*=&4.VKPM0!K2?Q!#\IM33I,4WS2=/6?^=62,>A20X2y
XM<.'K*6] EU*[T!S3T"8K,QEFTD+@O_@Y!X?SOK]2TP>L-'#($[V+S'O$2SP3x
XMP-''&[Z1' .1I9,)M0.E$P4\!SO=OJ&A?Z]<!K9\P35"O9$LM6&@D\Z:&P[1w
XMR"HV%I_\+#:#';1Q@C1FHL$BF21-<E8R%V9@!HS9.MM,B65-8;&HPL?5TO%!v
XM=D7C52TD45C@9%+RU$0MU?/QU%$=@6X1R/<,2FW@ A*-U5,U(&VP6C@6>*,1u
XMNWR!,T =II T()7]$5@QHI[M4V(=C*@)3D2+V1C2/2=2V42A%NK!%1QMT<0[t
XMMMA5MB?'!LDKJ/GSV]_8/\\[CL2=7N)W%W/$<,Y6D)OT3TH-QLLZL&;ANC+\s
XM%Y^:W*EU2PR\N/2HJG:;6PKQ'CM(,<X*@>.]2#I!:RWQ2:LVV+=Z(E/PV\U$r
XM'TK1!(7YVQHLPMA$31R*!1&V.3SLHB_Y:,3(0G9B!*51&R$2?IV:0+RT$7" q
XM(;4!0I%57!$R(+ RUVQG.?G;X:I54(O5+"(.H#L"*UFQO2P@&R@9?CO,'Y7)p
XM$\':A":S'G)R%C2L3]V\,%2!<N%A&8WGW$$]DELY4Q4MKI0A11MA'_BQ4!E=o
XML9^QP?$QL]<=PUU(+^%Q!30<>-1]%]9-T*:"U <]$%\>)D<$/EC.$^0WDC8^n
XM9DHN'MR!W5GN?\WA8^KQ(Z_KLP$R(+&'$$PD!@FQYOST%T8BMM*XIZ/)1(,!m
XMJ,D)7FR[Z/4$MXEJ2J-L:>8HZ:?1A*@AYD))PGM!K$11NA2YW8Q.501,VNS+l
XMO_!UV5(00Z0I$GC OMZIQW(UVW1YQILHNPZQO1+&%ZST.$RF(F;PAOA!?YT+k
XM S!PRGIUZ3(E \HNS(7E[ D\SEGY$\&^UC@#[9[KZ\B*!M$L0,[^3WH@--3>j
XMW:2:/BV)OWH0!F<WS@^=!.V^=O"^'A<1NOMLEO7-Z$L2,D%=[74Y'QLMHLMAi
XMQTL#2@0%!2V <E?R,C1F)T*@%L1N[)%*']F>36[.N_%Q(GC@[G09[QU/[U!Ph
XM'!8!NAT*-C*<8[0[QTR8E.IA'<(:/$2I(MH4),7!3\[R%A*Z$;(.K_3Q81FCg
XM>*0WO!.5Z-E5G+:!&_+DZ&J[O!>N],4=CM$YCDFO.\+W&<O],5DQ)E5_!M!Mf
XM)?-*?GE<45#5]7. ZCE-OP/,&BGM0FA/4/F+P.A.ABUH5C91*#&Y>+/BZ<>Ae
XMU%3B8_B*%WC%+GO,)>CMJ M1%UFA&V9 4SCS[<^$&V8UVS:!ZYHS%A0F=LWAd
XM*B2A.U+R]%?DR650[#T$ CT  C3 [&7_U5=OS]P:-!/QJG?!]:P/*<&L=U]_c
XM(J^OGZAL2F;/J"\PKXL"[L-,@M%1<0J=D?^$ KH*F&"!KZ>,3/1M]ACR(V]@b
XMP3Y8*!1W5D;F$%6<!+.UVJ$($XI,9NL* GX**RR6!Q]ALHWGY@;1HK4<^58?a
XMY'-2<A'N*KG+2KRK%C#O&^NE-Q2EBF,&,) F60-<HDXAAWGA?VH6Z @\T*BBz
XM7)0XP]N($T=)>G @N$&Z_($!HQZBFGH"I .FEQ$1.0R3O$H8=>%=/:G,E0)-y
XMQ=CK7D^OPH&O5K>_%IBM4USRB'&)MP[X^G!)1RB!>> $1ITGI?M^#:NY54',x
XM;N2X?Z*L>D*\BX$8@@1FDS$1!'?&UFL^=2+ 38$.N*,P'AV" X!!PWDZI:0Dw
XM8F# <&C,R\:Y 0OFYGY$;<!3TF4"UH *J.ALDAQH QIP;7' XE!+G%?<J@U\v
XMD%'Q!_]0%0Z3#KIV<6T3/:H[."^FC@W  <H.!M0ZLA<" R&"6'M@R]0$C A2u
XMJC"AD!@0*$> X32D $K>!L#@$S1!OA@R#S;,^EH!K J;$"R(/M*''Z16#K !t
XMT6XFU $R<,KZR/ Q=^Z!8Z@%AC<+*9[42AR#HW#$@%Y8^/B%"!@UHV_9F,(Ps
XM$%/$'U\HAJ5/3(P$%<'L'A<@G# R92S$ &YG$ZA D%@#O@$9+H[#,3K&82Y\r
XM0U4CWR$8VF('\6"O462!QP7HMS3Q$Q0?.G1)BS#SN9'NP<E<A5HB&)]!"DP!q
XM&3 #?AF0@S"&!#ZA#CK <';"2A)(#Y"=[*4:MECBPL ##QW*WPF9CB!VILF(p
XM4H@,T2$N&Q>Q%8(=\L@MUE T]$.HT&AV"FM03'/"5(R&CRC0> (#>6^C 9;Mo
XMC&K#$L'&RWB)P T+Q$3?,!I08D-4@W4BWTV!H[!+YLA2=',2"6S1M6M3Y68Bn
XM2'"**A$I:$26%B3NT+^@AB3)G?&=#G'F?,/!4''T 3:T!:+T9,A&;JJ'"R8_m
XM7 4S /$DWN@SAJ-A&E9#M;C71A2%H(97S)&E*>503UP>=XA*T9!>&3/Z, I#l
XM5?MZ+&? H 7&LS@84TQAG")FQOQ!J;R 3Q(#P0 !8ZI,G2E70QCSPH-K5M-#k
XMPO'!>2&B)@.$$8-HZ!0FQK5HK,H?6M,FVJ="X $W1!143^59 [=(:M01Y:/"j
XM)"*T6A)4H!\.!["EU^B#8$R+GM$U*IV]9DW.0ZBPC5@@"* HSH@=L9C6FA6Ai
XM\3=B*(LP)ZY(UF(,>2DUFBDT]>M*8XO+0,-10Q3'!74<CT,ZR5+AY#KNQL]Xh
XM%)Y645HL.0(I# <1-4_<6\MZ$&,)#AJ]LK4X\J#36QP>\+A50K5@G=3(A&F$g
XMKN@3!:-/M3C>"\I;4#'H6'RW'!C>RAD@Y) 51*-4KIG1Y,:"^U@H'<,-%))Pf
XMY_L*A[4Q8B. K@3&X=!XK*%O.!$C(-?ENRL %3Y#W_H,TZH)YH?[. ]?Y,YKe
XM22/J/7#%V?<A^4E6^$6PJ&%4D[X@1P!.PP$)_X^$02 P"8I6S%0C?V9F#J 9d
XME-!FEI&<41_-""7<F9.0 "3$&! #(6,-T*4^:8Z*P+,23_(+4"(006GM.%G,c
XMR M&S$4\,/(F%K @)7(!@))/2@CW,2C3"R]B4LHAGXR&V>@EE4*FQ )]<H(Tb
XMB$YICG"(Z> M@@0J#IFNJ'3 PO8RE6@I50J!X7 '6&4!,92QJ$F$@5[9*']'a
XM&8@9TXK#*(>1<T^NR.@H&+A24TZ0%'CVQAFA+" 8[8Y9D[8V['Z"4F,/)V@^z
XM7"BU]C:.T:G4E9"R4 "H:_D9;D^Z+(^.C,D<!2[DHAS.:"H*429:HDH)T9+6y
XM97JY/2UI1?"&@8 "ID 2. )(A0I(&2.) N:ELW!11* (, %SF2LEQ*1D _[2x
XM'-V>BRDK&:;#M#CS#PA03&DI!&K38-,*[)*V$ V3R60,YA&( E4@"2C, 2EDw
XM&F9)!)F]2SZV ,(S,O?E!/EC$BUE(A\PXAE"I,? 0)BR8DZ0W\%,I(70;#Q,v
XMTV@6#GVI*[= #6@!. !9.,WT@L;D%:];@*C#G=!,M)0T2>86B &=JP7<0F6Gu
XM-:5 RK0WNU C"!JJ*2$F7@]!$"GS]IS(=!&'1MA/R RM!$0^+8R5#_<DKB)Ht
XMIH$T1(Z]F0EKFUZ*=6F@/?S&4:C2IEK3.6E@HJW1)7Y(%OI#FH-I"XKQO32Ds
XM$)&X!]=BG#8RQ\U%4E$S= <0:8W [A6UR1ZW($5C5^L.Y%*<7"0@<SJZT$NKr
XMFW_Q;BH-QGE21A0G,U%F86OQA:B"!<?F6' XG',T#,XI"!740ELP#TU2_QA"q
XMCG 6IMK.$ KB"B)*+>M@!N[#!=LDGB-J.4 )UQ8P'\FI<E#!5? &.(@^X P,p
XMH(-'CZ/4 0NYG.Q#AOR#=4 0<@0LL7MZUYHX>%/-/K@3Z_#9$.)[9*"?:GW-o
XM0/U%0U:D>4I5+K(.^($-Z@?B!2O*4+PA+T#0#.K,8)\($%*&X;(E =K#^Y#)n
XM/)P"^U,IYJ67-T!FU@#-# 5T&.8$8C+58L=%9*!C4GJ8']3A@ZK6 BT4L?-!m
XM$#G-B$2X(JXY04ITQW4(,,&8'%INBJ' Q0LJ'\ V&D13!3)-1<F@32O2L])<l
XM84.+=[#"(]RWT& ?5D/X="T_(475E1LZ'/R/@PD1BD5G$@$[P20QF,M2"]IPk
XM>50\G?4\7XJ0X1%J:CO0D2,J9(#)F@ [N2':*"(L<**:4$Z I CT#'01.6+2j
XMDD :'6Q3"@4=4N_CNY0$C)"@[:MU[A+>(7@$0BS*HF'*#TFD<T1,D-9?"$X3i
XMLCBI!OX9Z:P6I0.!IL1JI9?: 1_H T9P#ZW':KF(WK,0T.%66%F;JI5])P$Bh
XM3.?>J6J1"XF:NHK8DQ=F3VUX 7@@#Y2[$(9,VR@HX:8(@?: 4W%ZJU[H+E6*g
XM7*&04,^T6$ZM%L[ .VUGH%&D,=DA_A+9Z&AI\B<4BHUQPOI.2VQHNA-V ,B1f
XM*">63?O<39%KRF4&#-.[0 7DT&U/@2WF/QUG>0JIC\%9R$%VK*?VF$W85(-Ye
XM/,?4Q9C3('$& &=9F&PGP7H<'4?C=DK0H=MM];.ZY%*.8@?& "_-'SWU?U:Zd
XM.1!4K5-&.E(+ZBTF#,.$F-:10GE[4&O5T2JGVO;:ER=<=9@046X$Z$._INHTc
XM-25%U9JN0EHQ$9*@VTD#;">E/C W$#?\&[#9$)NTQNDY=#CV?&&#0&2R;4!Lb
XMA;3J5O&8XG$1E72NT@?9I) (GURY9!,A")B!5^K?F Y;%5!E3BZP(:K0FLQ*a
XM'Q,!V .9&KRM*A865),(',,$;'T$ON1/+>I=X*PU@R>4,X4B4P)HJ\JL]NIRz
XMTD!IP2.W@MQYK?[-X%4[Q68KFZE&&A6U-0!Y"K[PRW"K9@4V2#6?R(#YIDQZy
XMZGT;#88%QX" K=$2%A2RZ0EPD:GJ((/B2B&#CDB(0V *C$FBT)(VJ3/1?AB+x
XM^_F4Y)H)>>A5&A44Z3C05-&1U,H 8F&O@<<Q!@=DRN>8C,A0$3%O-!#6%%#Cw
XMA%C.R$Q\4[^JU>MP$H -"B *-(]=C00LF *\TD_(HC7OO48.'[1;VZIFU5F?v
XM@8MN.*^"2N^*[4(>4RF?T*C_DS'2B275"8 G#>4?P)H],6Q>(JQ]X1]1(EK%u
XM J9 :#6F_6$CW 6I-$VNVC?[G/9!#!#9"P1*IH 5& +#Q"'D13]D,L)#A_HGt
XM*U:IJ8=/!HK0()E;L>H!PJ))-S#PL*"=6 JQ)3J>"C@PJ2#;.MFOL96W* <1s
XM>]F\"L94&IC19'T&5B$,ET.-4ZL%S^$LC>/P(1R4W[&O#U+&SJ3L*41/AVY3r
XMK+&H+&C4A0#7VJ=2*B 4CJ?$!Z^@%HZ&C1&P&G8FH0<Z)):.PE;:CA4H M&%q
XMI'42Q*-:8*]D4B\MV'-32EG3B%T6+ +/OA4+ZR&(!J=:=Z$2-]Z_(CO2&@^,p
XMZ*EKXJ86/3V5/POA6?FIW"@/G!6A"DP-T[1-+V[%(&2$WR(G3A8%F@-KX%-)o
XM6[1B076@9?&&X]8F7(&:=#.B36[AL\DEXG1;Y#!7]X8+W8=8@+R6VDQ8&.8Mn
XMSC"M=*!W_;^Y &[I;3,=7E(D-XW;D96(S .[#5-J =XBU(!P3 VN2NV;_] Km
XM?MLU<&*EUOOL"2!3*0V,U>$39@956AW;,S$M%I<0&+C9EL6GL&'DG@3U%78<l
XMU&S85D:0!ZU/?#8Z*(P@92RA 0U(2&9;M@8%TU->_9-3_%+HQ2DZY'Q 86BRk
XM=>X.L^ [@(?T\ G#XU-E#JLZ"IF $U"RHX]+# OU52QHVK1X>ZSU1.@148@Yj
XMW0 3N+/M2Z)QE5%H:8S&LR@#$85:W,!EP00PF;%5==*B!60'JJ#6L$E^,"M.i
XM )#LA8]HPIA7?]@E'<)'==,?\7T*V=Y]%_&" =8+[W9Y60,(*RQW*T#Y(!;8h
XMA5K8MN )>V%.P:D+I2&<"S$9>F;%&?H+W;BW8&**2Q@Q\8>ED?E0/GT1"G(\g
XMJ\&L/+'B-Q\"E(O8#YXS+'2%!2)HFH=9(:L4P<R06H21%7 9AP2\[:OP6@0Rf
XM)E?^R$1X HN7W4I6O('S%M0*<C2/M_0<VCO@QE8A')L(0W,G<#,4$ -L@.#Ue
XM& O3O[51LS(Q8I_%*#7_9 75DR#A[TC&'ZH-W%=MN(&5,1%:QLN@ U\C;-0,d
XMJH S= ;/**QV];(ZCC;ZZ03F#ODG67$.;$6S8D)O3[.XNQ'EX#6-LC"(\A75c
XML&28K$$<!;KZ5Q>KD+$/.>1!]%ZR,!WG (6Y)SS!K&2-B4!=N\:QE!DT8VS@b
XMC-J$-E8AVY@(;D,RR0V9P(GNAK.X(GK#K*R &U)NQ&670%$'^ H?,\Z;$KPAa
XMI_@G/$ =*D/$H2(4AS+<O:-MMI:5?(<%FL 3B)A-X#AD 3N,AVN<%N##1>!;z
XMN#EUDD!&0A@,'EAW5MPF9G46!J# U4UOB3+.@18@ YK %#A32X4+S '/Y=RXy
XM61'MP5OQJRT->#+C/L55X#T_;9S@'88K3_F"2UJH  X$Y*^CL_C$8..YNK("x
XMX(Q%TMC]GA+!<W-RRDFI8E)(3".MQLU:-:Z2WE@7DP!) AG($4Q(A2TKZ$E)w
XM+RQ/$ EWD XYT8%@47LG3P@/L#69QA-&'% EZ\48".X-4\U$@9 F>O /3JTYv
XMR\(PD>8)-%5P\L27/H5+B(5.RX;@0)\@A=O+3M"WK<O5,*)L; N&Q-PXDW\Bu
XMIQ*J?'B/Q5C(3$966G6Y)RX>'B_MG^A7BSHJ3)/4!26ZXJ8:MHPPB%7M\NA=t
XMSX,]&.1X4CU*&/:@AI-A>_@@?7H42'&&67#_\>C<O,KT%N1K"3L1_TVO*=OHs
XMLE/)0KN"MD9Y)%!;Z20^A(0YRGKTH?5F#$3KZZ*&-+45N*(IHUV$QW:]BAF8r
XMNVVWS\6]3KA;7X@--*P*^/..+G,%%+:B3'2>NO?[?@8CD 2,P!-H.V0Q*[Q9q
XM;"*Y_)V#LL%\H0@\ 2-@5KRO"%C+T)3GA2(U02<:259N5S+E,[ S_^NHI/)Op
XM@(J#Z-)(-![9E&6*58%VTD[V02#+#)J7XJR:>[ROE'3F5:8^A,KA #6'[RY8o
XM9H9G6BIB%BYGJ]F/@( 5@ -"<WJK*Y"93&B&L0-.9"4.$%UFP3+3-<12E1T"n
XM/B6(.2RA-:N ^4:EB-VLA<\4S(G#;M>87]IU#GHIK)-&M)N*@Z3GQ2)+7!G/m
XMKJXZ6U5BFWCR*I4-,V(JB3@6R YAV,U\ZH+$#7-5!NDS:(! 7^<HX*@S$$HOl
XMHNCXG'<KRWBZH6N\ @5\0LKP:2FWE B=7NK"30FUEI<2B@#XI$&,P%:@ W9@k
XMUKD]\"4$1EQ7-1HT ;6T.B&4N AS6<T,J]0;\8B#<12B5A@ S-K$O:6-SSL$j
XMV JI\%&_]2T0'#*P)?J)&',0:>/]@M[J4)1> &>(>8 3[+B1Z6E$9&E3*KV)i
XMB[ X 3DF):46&34M*9H,YPL3*IJM1 L,,W3AY ;I,B")IB^82,!#6 04X0OLh
XM/52$9I&NH6=T=(B6NE X:<'+'I<K >.!<OB1C#1%8L20"HN%I'$":A,29_9&g
XM5@49F@$R<#A"UT2P-_;*J&E)(3NG*A#&8++H)PE(:DJ=FA\S7\ #=H @M.&&f
XM0*E=LU!9KOV"*4TDBHC0QIA#;M0RZ5'3C@YBCC@."B!?XQ<"&^53S:M9 W[Ie
XM1V##>0399;5D_4^H%DWR+=^="'.8:R>:,X$"2V5<6)UX6IG>%6&5 R1O..H0d
XMM:*G56\V46IL"BU6DS8M?BK/NB(#8:DNY)^#N*W0$H,9'1_++#WH'I09BN-*c
XMVPYYFCGDL(]F)@K5B\M+K'0>>B,GU:\% HD) VN50XR6[^$L^M^5X!DUXUW-b
XMK!Z\6P03ODTZKQ@BQ]/;L1A5;V2%#;!R.3!1TM+IG@-[LE%@2[KH%TN,B:< a
XM"+B/M@%ISA:%, <8+X/N;?#C(_PI^M'TEI/0EM 3X6BGE[F0>G/-0%%I /$%z
XM9N7(]?:ZB-R3PZ9J%6J+Q-J% VSR'&,%.IP<Z"24%P:>Y%N%PU<$1#$N\9D.y
XMI?HZ'8YY(KPN5RUO.,[1'M3#[+'=*['P0]("6;#-8XQ'=HZ^8[=+V)_@.&R@x
XM<P@-O0UD,MII3@*=0Z4]E $AHLG9?CHPLX4*1*Z1Y1*=-JII7Q=J)X$T.U9(w
XMQB28TE$0.YL<5"-3)K?>UW80;\XI]5!S\J9_M@4,B! :'"[="0T.*W3RA0(!v
XM:=TE0GD5$$&D=N).D[![\<'WH@O)0.W$JO]K]Q0.MIL$E$U^^ +NY M80U6Xu
XM=\';><+-X% &T !E5P[/H6\HB/^9NHQOS]6\.3,X=(>>:\D 39L O^/0+CP.t
XM2\9Z,PJ]0_**IB<ZFNX[&_?FM4FY)@(!M]]HL#?K[Q? OP^:U&0;TGI :.X[s
XMV"+PH<<^'S/+? -$4CD0>R+P.(B&9B$^10GU:&* _8.--HLT),Z.,J*:=^WDr
XMKC5I715?V!G!/!\:T%:]1EQFSX'1>EZ:)UI6$_CKQ07KUQM:8A[(&^-$,V,(q
XM%!#_7!3! EM[3Q*=!*'X!LP$@66*N:I+=O ZS3U1P(E0PX8#0538 #>Z<J(Dp
XM*U \U)*"#<Y]Q+$PH\[BC-!+YE-CZ2J\N)];U>M0C/L&@MV3@)Z5Q56'"&>=o
XM!+!XL;/$X;A=/ $I))*8%Q<*8O_."VH!EEVXZT=:^,H<"HI6;2@ZFW_5D*W<n
XM4*#C-<[ZCDTL<AN(DAO?G5J&CDLM@MNW\X!NVX+-1F#I2$D:TI2#XU0/4<E3m
XMGZ00@>U@Q<PC%>V:"VU8U=&.[8((%C([5S$5YVFE5G%#D(NC?ZCN&H\)\^&Pl
XMP)R 0!2&2(\YP> 3-,SG?$RDT:J<H#>:!,P/=; +24THT!\> 8>:!34G<804k
XM#<FID$M?E\07+WG)\##=MW(A$E)#5&)>2 9?SP[U.ZV4C_?!I)-;5.-Q96@Dj
XM EQY'NB0)TV)U#$!DR9I(%RQ.=LW^#N'_,47>A@G<2X"0!+GW.+<.*[8JI]\i
XM9@X693X(,'+W'0082'M#3QB8KMQ^\V]9UESRI2-&,*'=OBI+IX;O1:IP;[2,h
XM("YH-TS:,YT:QF8(]--[ T^'X)<;Q$WP-@ PHF!I&E$O )\W]>WH?[8"5QQ-g
XM6RA'X3=*JL6W'E]I-+QAE,6'J09JJQ68" \X"%5)K2?Y&K4"3A\()("S2(%Of
XMT2%@WIBLI%D/:KA;UWT99&<P@H^G868T#_HI 4% 2L>?U$A$-3JBC739EF2/e
XMZ9>]0K^-%GL:J087"L(^?;.70CR@N,LM-BW#2-W'X%II)U-74 "V,"(#"S)7d
XMF;G9 93^W>,ES+7;:BO,3FJ$O\.")._>+1;DZQ\"3UZ2HX'H$.&,]/<35I!Mc
XML-'SP;XP]\9;[ !.%I1S$4R3+CYWHE7>FY%#":,IS90E%U GX\R;,>%_9E\.b
XM5Z&2 )X[02TFBJ=#_/;+I"D]!6*)-.Z]\;8FC5:3L&!]9PU_ K^KK_>^WZ=Ha
XM>PA1_EV]<Q#VGM^=^^LFZ' J+C1K#,0NC_2@:?"X\;7'-5U^@?Y[)A3P4<O!z
XMCT$K+-H<VWE=5";E?BKXUD$&VON I^Z*1S05(\<B"[^S^I RFZ-XE\H5SRGFy
XM@(L/\;@1].F$L6!IIWOG.P/^:L7/E!]/X!M,UZL*)OZ@N0$C?T:2? *P:::Ox
XM*H0:#*]_?A^6ES;+[#.I")!+NO@DE@\!IP^J,7G][N1KWY>?#U"-$<NUK0@Fw
XM^*2KV!<PQ_YP^=$0,'/$>U.H6X(1@W,UYJ+*@-DHBRCA&9T/*0(V(*5)#&S+v
XM LFSG5&8(R9]6+:,#\W.8GHM83GL[,F\Y5%WK==G'./^;@9W+R*KQ[:1I&1#u
XM)\Q#<1Z%[ZY]-9F80!)N[%>XXIW^?BUQ)[/W\E)FN.(AP-\@!4V:8<8X=(1Pt
XM^"2&^Q18?]^4A]@FI?7\-'N5JOK'H<!(<AIO ^/5"'>BUW8Y<K#E54(]7,>8s
XMQY=[ T67KD\J9RL)SADPY0!I&BTP=;>M]+L+H>\N9K?W(U"'/)K#8DF=)8D"r
XMK*F;>V5E?*]7258\[-XL\GMGTPUM[WN@'^O8_)[R.C6SDW-72\#GS/9^\""@q
XM?(1+('X5Z?<3/PD '(N/3>QMFD4B#=?C'GCX !9H;%1 (%OO[A;;0RKS5V[*p
XM)0OVWF:>A#[1'R13YH,/DDG:T*XY(&7<7-9[Y<&K&.&EL .GU(.G?:/+MD&Oo
XM!0C]$W9WTA:N-RFCM04VX)P+:KE0Y*KG>'>G=12JR9-I5_BH703,;3/PFG^9n
XMW4;=&($&P&%CVETM_%LV^U$]F<C,JKI80-QKHA&A7EBI)+'=RQ7# "2U8+\+m
XMM0# 244E&77:75$1"P02_6-NE 11>-EUW3*G*\!54*,4PP-G1@/;?:\$$> Fl
XM/ROER*8<QC94L0C?$^?F_YJ<0\3(2M O0\;);FGHV#TRS-RWD0T7<>/6EE=Kk
XM=53^*^+YETU+)5!M@CXH2Y9U^A]'DB#^.X=./.R(W?!.3F/FJ.BP*,"*!T$?j
XM(D-)GPQ!X,2;'Y)PASK>^)=2I+9FU+ YZ0(,)V4K2PF \JS^;J,#$L#:;_LQi
XMAT<H@3> !L(.A9?_+UL&U/\GM?_[?V#B.-'+!^ !9Y0GVS^>.9SK8:Z5&@7=h
XM>&CUOT?U]QH")1VVOUC,0)A?]6=%T."\ZX"S0?&*H)67GZ12EQH7QJ3#1E#Fg
XM4N+W-Q0^+=:AKCVGW 8H+>W9^0]GEER;-Z4#8O_W_]EPW_X?,#FU(9@X+"CMf
XMRCUYQ  $N07PMLR)Z, Z..+QK\_%&0I%!]2?%PA.8'(Y%(?^,;(9&OCM1!/He
XM(61$)X+B4.0XK\EET"6KXUGT$+N =PU"[T+9[+> S/FZ9N:Z2$MHL.AJ_E?Id
XM,?%X',/LB RV>T_YA*5'V86;2?$)8\'J;VB>P:B<T"WC2RZ"\6IB2JQ4?.PFc
XM[CO:E2.,A2W0@8* %$@"R3LK\PR9L@6D@,@ &7= K P(YSTJW@M9F81VM:SXb
XM,2U9,]Y"[Y+Q=ZM9'\7S&;M/[A;3VKB$+W4/QOO]9DM=+7PN3 3 , S#9)W0a
XM\_6[888G'+.&S=DI$(9ALD[H;'?>](5+^%)<T,246*GXV$W<=X2W)J;$30"Iz
XMC M-3+E6X1U0M^(W+FAB2MP$D,JXT,0%' 0'H$DL Y2*C]W$G)EGR!0NI3YLy
XMPM;AQC&A4V,8)IM/1K5[PLT\0Z;P!31 !H*9*P%+#P$LX1*^I*)="5C"$$3Px
XMC@>.%X &R  -*-57_^JA!54=.%BUYR(LR 8,@H#O-UN4N-((U28:OMWQP,&Jw
XM84 +Q=R5@6=,\02(/':&<M#$E%BI^-A-W'>T*_>\< EE$++NC6M(2[QP>'YBv
XMH8>+SZ3DA"@0AF'\)7ZCNPC&JS>J1^N%"IB*Y[O<P'_PI%L_D4SUN"P$!GJFu
XMB2FQ4O&QF]AW91-[V7JA L*];J6<),W0U6%&1;TL\YK7$#3-B>BPQ#9&':.&t
XMEPO ^@80-ZK%^'WLH7:D8!'>WTM&_TT:X%$=/7"P:A@@QOTCP3A=<RUR+HE0s
XMC0R7.!/A42<"#9 !&B#&JPSV G^'>G7"=SFN,[5 Y"LW:%#52/!,K#0"PK6Qr
XM./F'N+L!"06UELBRH6L^"_-1PS,X]5$"OF5X=$VWS</H&'A O1K$)L**,_F$q
XM.1!8;C9G\@D'H32Y.,[D$WJV^+V/H&E.1(<E!ME&8=.4 ID>U[(=5=-VB>5Ep
XM?"O7*DN=!*1P'71;U ?:#CHP8 2JGU#&BQ^L=#XAH: 7<\0;VFSJ( EMVM/Zo
XM%,W_.UK:Z\+26/GJ)Y0G0:+;<ZG:K5F[\YX5FT $O"6<PK"5]=Q>_822$8(.n
XM\1,!0(5'C0:G\R2L7=*Q?N@0X")GTF+O<8;F_QTM[7697TRE1C3NIEY6GK;Cm
XMXB[,QS,"KO^KH=)Q=UT>L]0%%TSRE[1KD"H]R[[33W,8P(6/.8L;P_S>)196l
XM=M^!#?8IH4"%YS>@'!.<XNT%[W;Y:#3XUKC_:!B%\\M)O16I=>9L]YZR#1#:k
XM.?G!2F<;!&$/YECPDN]L!=%$]JLU__(JY*M:GMT9*.03&UA&$5\MJDU"N\JCj
XMXRE)8$(CB&4M1=DJY!.;Z7UADQ4NP$38B:G,:'\=$E\ML9D5AS0%*$X9T%1Si
XMA.8.HJ4H6X5\8O,-^-0:<N9RE$JVP-GQ%'H 6<"?.P]_VL 6" ++0@L@"_A3h
XM2_Z$#\@#''2#GEYSD1>J Q'K"XT'B;'?(L;$%KYMD"F0!/ZT 1@P#F< #:@!g
XM-N &X( <0$L@S>& "#)@@]H$(C!9X0*EY Q$-(FGEL363C,W6G(G\ 13/8L?f
XM B_Y3@CF6+[S)/11*(G0WDH9#8;QEN3E."-)3.[B5UL?D9@HE!L X<FU<9/#e
XM#$OGBAA)4VN6A/POL]U[*@1O10@-BH6,U=_0H)AHF2-_IYC$KXNPR1O7D(Z%d
XM+1 $FL#!# +).RN#XM?VZD:AB0;+7J5:@V6O@EC*<ERF" U[TQ%<PTL54,#Vc
XMF!HF<7#L'>1H67$)7X*Z#EEJ]#4W0G -+P46RS'B"*[".Z!NQ>]N]0T27BP8b
XMWH_ F4$QT7HB>/4./LN-:TB9S/:8&B9Q<.P=Y,B903'1&JZXA"]!78<L-?J:a
XM&R&XAO<C<&903+3L.T' YU"T9[LP$;!NQT96OPBKA(W> 48."X.A&R&XAO<Cz
XMM-/,#8K7$A;P=R7^(RYDQ?.D *N;R,L;UY#Z1U+X3\0FP36\[6]BD36Q8'CSy
XMB*^/E3245H;@K7BHGQ1@_0E!P.>& 2*P5.ZCFB)2HT<F_ Z28=UC[4;W&)-!x
XM2*G_;.*7G:7 JTE*@N :7A&%L\U"$/"Y88 (+)4#6UWSB6[@3"%X*XJA,DE3w
XM;?+&-:1C82+?VB<2V[RQ&P"/."@/!(:C4X =F\[+X2 @"/C<,$ $ELI*7CR[v
XM*R,DI8WN(A@OP36\!"\/! 8;T4K0  \ZW;Y+A?J$:@FZH3F*^3Z'&F6S7]:0u
XMW\Z'BP@"/C<,$(&E<F:1B96!*;3,GL!CMYBL)=N\Q /(J WXDLOX.O(;!O\)t
XM0<#GA@$BL%1L1"M! P/!^J%#)L*C)*V<M#-X!H#\"1%PB4+P5J0,RP*QV(AYs
XMB0>041L8?(93 ,U+/(",VH O:5]@=B;5I([&(PBNX6U_(*"/BN40O!7O6P$&r
XM 7D@,(BASW! 942-VPC?$P(% 9_K:T  ]AD(>M0W!(M'PTJ%,W^  RT O7I>q
XMN" NS[J>Q#, Y$^(@!C@ ^P_6) "0: )Z(!U<2JCTY\0 3' ![AX8[X5*0.Np
XM71>&DT=L]!.1^2(G,FH#OH2WUI2/HB?Q# #Y$R(@!O@ ^Y^L;<2\Q /(J WHo
XM!")@!&" #E@7AG-&)VO)-B_Q #)J [ZD?>$D;1($?&X8( )+9>,:TC.+3,KYn
XM;D'G9:X,T!^0:N*,^5;4;*<-!.2!P. ;O$A>V'1Y>>,:TB7A(JXY4!B$C_5$m
XM!*$LA2&"$$V-N3FLBY9RD, $BH"FL+0ME13*"!S.(TC3N: /0<#GJI-Q\D&"l
XMKC-'=$0W: ^'(S6T0\JCTX,F12(=*4-EW.*61#I24^4I_^8)SX-+V-!RQ87:k
XMC5(@#'.!R/YP.%(J-+!<4[1?!!Z71#I29&BI\^ 2)IS%</HNZ4HBL,QV*C <j
XMCI1E!%@3,5>=G@N74 8AR:4)8CA]=S9#/>'!8Q#(+55+R7+XVZ#MT32<4^92i
XMHHN.ZXS <A4@,&E=F?,FG_3&CE&(;M"N.6/ _$#HFC,&S ]FKSECP/PP*E#1h
XM\T>% 34Z<[ZNK;6!51$G/ ^.7 (_:=><,6!^T"Y7%2L#0H@%EO4;6#Z83?C5g
XM![U<QN[NWT\&$8KY/J9Q_9:Z51BG48 %+A12Q@G18@J$81@__J.T->;@I_T#f
XMXA[,CTQ)U7_.F]*!%V %#L>?\Z9TX 58 5B-6;EUC:#5/#ARF7RI7G/&@/FQe
XMZEJR9KR%WB7C%3)]F/ \N(1M&-0AN"A1ERZ*YF<D(<5#;>7HM$!?]5\=,RP=d
XMXB\V5 \Q.;78F.O0[I[PQQ\Z::F(!T3;;XPQ7[&#Q'%( RZ@3K"3W$*POCIFc
XM6#JZ ]!P^-N \7BOK<:*)W4UO,;/Y)C^YD\*#T]@)9V'0J$1G5"#E2RV^ATCb
XM\8OTG''C 3$RP*[)5;?7(%*_K.AQTSW!N$\Q.#4 R;P;(28[0TH8_?2FV_KHa
XMYQR%\^NNS/51\5A]VN:%W?4\XQUT?_+&;P88.@FP-IU,,43;,%U G6 G=J2Zz
XM?4X#RUZ+?HV@3U"?*!/=H#W@(?2+M_H;^L6G%SE*9Y</U"(M Y[L#_AKBO:+y
XMP./*0J1EP-N$K0.!)ORI +E9(6)>BPYQS=?%N0Q"&G_X4$TBQ!W0[,0:(@8?x
XM* S"3&B>H19WF(?YG9^.A?^7_3+2SLU\F;%#[5RI14Q"!J-3"TJ-4\5&V*'Uw
XM^"EJNP]Z674P]NF"WB%[T.XH$)JF6/T-35,Z) 3*ZT5@KR^?VR#;?7I'>2]Mv
XM&/(/]93AO3&HXYH(@<.-< $PH!=G!!B@*WJ]"<QV*M!1[MO_"Q+^E#W(#53Qu
XM%GJ7FM0_1Y7YO"N]_BU>TX(!6X=?>N@-N'["Y CMULZ+5*VCP7K>UP<(6S<+t
XMT],NNI8BL-?#PQ-82>>A\=03ZV?!9&M6OPCY7*A+"\8^7= [9 _:*@="1R^Ks
XMOZ&C5X4&&[-BAY(NYI4EQ'[RSLK1RZLB?*/.(W^$LQ$R06<LV&V58Q.01.0(r
XM='44,#@;TJ@[>"2DY@N!#G3%!2X !GZ$LQ$R06<LV&V5PP7 0+QP&=PLT-51q
XMJ(YFI;K*:1$Y!&ZG#E.!,WS=P=BD"\795%%7U. 62W+8ALB#'RH^@%+#D#@Jp
XM+^S#N8/7,*7'V*<+>H?L09MP0&C"@=D)AR#<74;9JOB$PJJ\"<<U1?M%X'$1o
XM#CK 0=\338! FC3XYKN,BO]B(^RPX*.!@?J&,S*6$*B'>#RF97<99:OB$SH9n
XMEZ@#@E2TN9KM7RB(?B.6$@3+_-P.'[Y1K<.("A+^N.J@[+C 4ETJ&E"Y\]4Lm
XM,%#'AAT,*5]0#^0(#MCN/54ACZYP,RD8TNIO:!]9TV'5=2M$N^1+:S@Q43C(l
XMOH^\A*.P6DX+L^*0IF+G$]@JPC_&RL 8S7/0(=H<<ZW20"M5M3@XZ%*O*SZ2k
XM]-RJ,MW9'H^"GKXJCKV1A<(Q&1ZZP'@KD-Y35$MK[2%&!5L%<27R\JV'VO2Tj
XMEI4GS[%;#W]5RL6! E+ 4!9.4E\UF"NDK!K8LM47 :J!+:<73=(1H&DC-U?^i
XM1/%H5XZPCK+Z12@('0&:PHB^%B2N*=HO H\KJU^$@M 1H.FH=D_PUPUT!&A*h
XM< TO57!/^<[*=(25Y4\4CW;EGGW=#72$E;76<32WK;B6%C84D&QK%6(>P37Ig
XMX7'C&E+UTG*W!"[32U(0>\;W.M815I9N>^@= E"SAJ _'SH$P=T*>X',C+X<f
XMYD/#"<$UO%2!8H&MO.#M66F4!I'X="/G$GSIZLL"L!$.\3X(V*0A^I8U24> e
XMIE"W$"*F""3$QDYFH/[-^BBVG4;_&?3&;1FUN+P,J(%*\]>*<UPH6@JK#4/^d
XM;V^8BE;$2K01$M$17?BA2< EHSFZPLVD:!)PZ2*LO@C0).!2U9BC<M&T[^5:c
XMR^!V9!UI$G")&*JVBNR\_.2&#!AR>:TT";A$#+K,<4T$30(N/0P8^B<^P$>]b
XM5M2;%P9"K6]JL!!?OF5J.=L9!+A$#%:];Z^U>[G6PASP]2>VFHNV-3%:JV%Wa
XM&PQ::%")7SX/,2K<P.]LN['^KHS/&HK08#1<&#"&/KUJ.TE"+M\R;"C_X1+ z
XM'@<O,EH3@T/X>P.AUC<U6(@OA5$7#9[XH<(B.J(+/UQ.'$#*+@?F6'T1X')@y
XMSM*>K*L>;.6MR#$ R;P;\75I7&I/!)<3!] N0H'>;=?RJ3T)0=/&LMH[$<N?x
XMU0$]6K<*/R^2B!S9F64-0#+O1GQ=F .506,5NC 1$$AZERAC(GL.,S/B@=?1w
XM> 30@\%R6>"*'8J#F1GQP.MH/ +H33[LZ\ @6.))G):O?0T/@U6?LV=Q9$^#v
XM+U_0M+%<5H;9 S/W7SMQ6K[+>-?J<_8LCNQI\)42EP-SJ%FK6MO1N<$-A.)Zu
XMU^ISC>767XU'NAR8LRQDN7,6#(1EW8X-4<9$]AQF/I(#0D:,.,N-9CE3)HL#t
XMY;\0,Y+4X0)U2KK(6Y'#U]5S-S< R7R0J#*YA<R),B:RY[CZ493SD_4Z).,'s
XMS]]S&]/XFS_II=&TL=R^B">X)2,C"ANK=NP+R9(93F1,J6.K=0ABU^H)@S.Ar
XMN:H-=F(J'>+C1",4H@KW\CMVJ&5A^=('\02W9&1$86/5CGUA(;X<7@PNDETKq
XM<$M&SJ *?X-1'V@'"DU"CI"R)B%',5V3D"-&Y3A^H*>K2.-$/N46PKJ.- DYp
XM>GMB $2+Z!--((2#BG[]?.$LVU5X 7_!5CL"E(+AXOC'\,N%L+"M7D%(@<Q@o
XMX,)G0C4W24?(4BO,K>EO;[*_I:S&&$)8:W -.LW)S K>?DBR&M?XM$ZK93A"n
XMW5@B0>O@]SY-0HXTD@MP"38A-34E6MRRO.9[4]!KFD=J$G)4S322"W )-F'Km
XM0*"#\::#_YKFD9J$',D4/,#V90H>, -A'B.X )=@$U)34W)'B:W$I9;&1@3-l
XMSE5R ?^)MI8SEP-SEH4L=\Z"@;"LV[$ARIC(GL/,1W) R(@19[G1+&=B$.2Hk
XM_*LFU/'ZWYM5/DBAMJZGH0DTU>02VV$/KY*'1(=B)Z/&)+BL-)C**B6D(>*Cj
XM7?UA@VC"P6%%GPASNJ,\ZO0-3LB8[H@W'4T/4JA-Q@*5#4VEM] \RK]J,B2*i
XM]/6_-S*GU J&[=Y3O*'-(F7>T&9C.F]HLXS*G91&6M:[&.]H2 YS38G-6QY!h
XM<,/M5\WJ%Z$@L%E!<TW1?A%X7%G](A0$-HN$3,![H@F;CEDNXFQK%;)DM[U5g
XM?13)WOP.\3UW.6?B#6V6DSO'(6:/08+#@3'ZQB%SIJQ^$5Y "6+WX(I4R&S:f
XMD@6<P!!H-#>?=ZV'O: 69H#GFAJV>T\QT*5'V86;26&@8\'JBP &>O5B=U2^e
XMI->A!1 3!BKP)P(#3<!%W=PZKHG 0!V2$Z(/#-3D@[BAV1(P1&"/(VB:&'.1d
XM>6EK1T\_:<&YY=1N:C!A0"_I=6@!Q(2!$CVB3'3A1QW8A4BY#L1-JR\"ZD#<c
XM7-JL*,(NP$*W>4V%YS66KEY*U &,M8[JP"Y\>W+W[8GG$A18NC+0 "5[)$64b
XMAA=PM>MJX3/,1,!;PJF]T&?5:AM-P,O"(3F!QX,S)KQE R4NH Y@+ SQVDGPa
XM&7L\.&/"6S;2K1R.?]P6 74@;FH,%U 'HA8NL3H^^N?=!BFME\EP*:D#<3.]z
XM<!L74 <P%J&>*N9H-1ASWZ5"QS-MC>!)H KL0@RA(K:":$H=IL+S&DM7?]@&y
XM1!W 6.Y9*1 F$%<'TNM64!$WU3JS(@#;=_;TJ/CFCZ>> YG;(*7ULN*YGG]<x
XMBI#1FMRP50];I G,WRQX7F-IX>T$4%'*4*%G>??Y\!ZIQ!H4N3DL,)X58VGAw
XM&3&X)2-GT';OJ3J L9!R'8A:5E\$U(&HE5X\K[$$>YJW[_"([S=;*H0+R(S'v
XM82:W*]QPRKI7'<!8;\_RG6BLC0F'NEVU?&5E(B"!C\]I,;-O:"C$!/*-O5)2u
XM!Z)6JS*46X'F[=8C.?=<0!W 6*5Z(M2!J#59S)$/P-L/Z:P82W<D2E*-P!._t
XM"3U&',%R5@>BUK* A)ZK567+AI+0-88+:%&Q/MYI#!?0HNA=^RIY^"[OGX@Js
XMD%ZW@HI8HR%!9>&_V,AS!T*Y2+VQE"98[SJJ%IBX?:B7FO<6@> OK'2V0E.Kr
XMM6RB=]F 8/;]PA_L'%XGH@KL0E:D(E"<N<@+J*.>"%I/#E "IQS7&+]S0-0!q
XMC-4B%MN J .[$$/LW&N5K_7A^<"OP?\6Y[^@_W2Y#+=V%N^*SKZ(22P#PL6Xp
XMT,2>"^\@W >/_WY'0HD/2:D>JX>&C(-S3N_M72!<",A,)U $J !.W%T9H4.<o
XMA"P%.".3S_,*;"1O%#3QR18Q]F_RMJL3E-0!C-4B! -7J$P66]-9Q[-B+"W\n
XMFETPR=\'6T4T<  1+M;*:" [>R:IJC77(F<V<3HM*M;'.Q?0HNB=% CNH.LXm
XM>)'12HD>MPNH QCKIO91L5P'=N%]>Y+N2'6X@!85ZWV#BM@**N(X#&#!P!4Jl
XMD\6FBDSM;9S:)(M>E]7%0[AFP?/^CE01\$% ,QN\V00%B&^P2?1O->N:Y> 9k
XM+LP'(5O#"A)NZC5C(9@-7N3_\S*:QF#LTT6G$EWX091 !;T^NL+-I! E4 '"j
XMK;X(($J@ H3G^ZVP&)Y482"2X.ZK$B50 <(O85F^IFB_"#PNH@0J0'C-$CJXi
XM9"M4I_'D.9Y.]$&S(,X*>.J#>-_*,:@ X<>=FQ0*("Q'<'1A())"]R2,Y%+(h
XM!HA2M>2MHQU#E/L \T&@PTNPU;+USPT.\W-3(:V0.>[21*<0R1O.&"B6FFG8g
XMJJ>OU]"? "K2Q7/'-:W)H/T>3WT0]WG!^&O+O%:;"M)S'.H)N*PT "WX%XHTf
XM04?%GJU.Z.-96C#VZ:)3B2[\\"O [>@*-Y/B5[*"U1<!?L4I%Q!-9T &"B(De
XMN(;W([0 4 46_(K7>AOKR*_ 7?Y%8J\VJ+*X:T"%]+4@ 8/A+]C2VT^*X!I>d
XM$:6KM0*CF@P<QZ]DA1F "U5UX&#5!=Q5O8X/W#T(+CH4Y3, %RX!'NE7G#)Kc
XM"* S !>JZL#!JCV7W?9&?R*]X)+:D,.DQF.S\(6PJ>:["+,0EEB6FW^ FC4Lb
XM8DX5&UU%@G3T&$_#9+0+AT#TW[/Z"@R67_,%@FMXJ0*9HWT(1/^]Y423?WB$a
XM2$C9^)3@&M[V1QE.A!68%2IM<^R\V,AS3T,.@=MT)%D]$P2B<ML)D<HFHMSRz
XMM:_=5&\UNJ$GG)L.2!-<PTM9S^320*(GZ8]G5,P7\ L>S<C8.E&@ZFV:8+WKy
XMJ"$&^5X-@8SC?)*O;D,O)KB&5T2Q$TQU6'(6@C;_/P3C[8RW8+OWU!WPJ4=7x
XMN)F4.V!5K+X(N -699BRY9BHF+J<7+W^:5QJ3X0[,+_XEU>1&\3R1&/MLVQ7w
XM/V^9-I+9.6B,U:7>,<V56;D#2YVC1AQSQ2/O@%6!-Z]ZJ=-BQG!ZLC,1[1X[v
XM0TK<YH5_!ZR*P/'-E7G99&=8Z7SEX6RY CX5"_B[U)FL:#=S*[XCF^!UMEWWu
XMV<(:[)1,1*[$WTH5-! .AGFM,AQ58)&U4ZS71",4H@KW<I<,(W(9(H*%?^0+t
XM#(^N78<*>QL=N'QFQ&>.G>06>5;"LO..V?;I3;=%P.G"9VP 9(<?['< :@:?s
XM>G2%FTEAOP-0,U@5JR\"V.\ U Q6I4/.*23TI*Z J*!Y(2/F3Z I;*^V0 <*r
XM E(@"21O7,%^!Z!FL"J]PE.0@4EH5UV8",B6#64]2M;D< 8P:4UNV#[LW$X$q
XM]CL -</GO3U=% FE>[-P!40%S0L9,7\"36$7TTYGRQ40%37L(NQ^D9$E[[I<p
XM0$* U=X_J;AP!40%S0L9,7\"36%[U3 =PIE+CG!^^_8(E(!O/2WI\.I-;;%/o
XM+/P7&_7?6&CB\T_C+6JNP)FR^D5X 26(!9WTQLYG; !DAQ\!^V<=7>%F4@)Vn
XMA[#Z(B!@@S-S9-JR0L"V>!M5(;R-=12P:3\9/<LIPWMC4,<U$0)VAX *(L,Fm
XM((FW<%Y5@[OV*0&;,@X(J" R,,3.%5!O8[8SR<I4+5.I\8,*AM'/&02$@,\#l
XMMEC $/AJ)C2>(DJN:'=/&%YF%?*1GN-03P*[,9VH;P,S+)TK\M1M]YX*V'/ k
XM1R'E@#T'@+35%P$!>PX Z9KNJ/:)?>U=$M>?J(Z';7GZ&_YY&^LH8,\!'_7Vj
XM+-^);G5"!]8(';DV^; O(,EH#._(EP4>&;#G )#6&$('U@@=N<9!.>A2=T>Ji
XMX^DH#<"&8KX/YF,]NFSA!^PY *27Q0WP7!I#Z, :H2/7%O<$ZJ$[HR=_^X$ h
XMV&Z YQH>4/%619@N$RL7@I9<Q&I7KB&(:T4S9-9/J )3H @X@2) !:H,CO8Bg
XMBH^]60FU*]<PQ)N-Y^O1TY*UMU$:FB>/@,HRXM0"Z3=+9Q7&]\%\K.>[JFP0f
XMQR0%PASP41A"(603TJ10#DFGO7_*7$K\EH.>35; 8M$^1U^6]P@L<!L$:0O8e
XM4JL'1QP%QCY=^(P-@.SP8S%MA)]U=(6;25E,&Z%#6'T1L)@V C@S1^RA$)-"d
XM[<H]F_51]'E\:U1\!JD]$1;31J#]=?5G>&\,ZK@FPF+:",U1(+@ XN>JTIN<c
XM/*<& 2%01:96!A;%85H4=4$R/ G:&L&30!_="&+!PAD_J+"0(V=\<'R2Y.8#b
XM&@Y_&VS,%Y]7EEY4!SI++ZH- D*85VC'Q5G$V1'T94QZ0XH[H73@=&V'&[LTa
XM&>6A@4E!Q_NH#[0#!13""$@9"D4'JR\"H%!T2"_LH1"30A+ @3P0;E^TN^LEz
XM*!XP6Z5"E"[#RA,!"D6'V=9/KBG:+P*/"PHEJYQ;#C?;XME=96>%5GRE 6:Ky
XM5(C297E?BI  #N2!SI'NN0W-4ZE&G7RM#PN3\<L(ZLM!@$<<5!@,/BC9?9?/x
XM0XR*QWKND4Z#LR:W80K6ZJ?[&<J_E6J> ?ASEG0E,>'_^$,?'<5N?!R'>F+]w
XM+!@QT3VW(3(50L1$@3 ,XY=,.)@DCP40%_P^=XGS<P8!(<PKW!^4H,2<P @Hv
XM+N5WP1&5AC*4\2/)\Z%OC:BV5K ^@H3ZO0IZ)2/V1IQ;U(-&81W' 4XFL=_Xu
XM'A?"IO:\;Z/!9GBA]WB"!$^8NH6]+-CN/15Z<M+1%6XF)?14?3]8Z4(/UL=Zt
XMO]D)J;:[;D O:7]EH )_(H0>OA]#R,HD3!G>&X,ZKHD0>GX"95CJODO(#+T0s
XM4=9+O*<U^2".2?+]P&XEG)!JN^L&])+V5P9*/BB#685\> >'CP8&"GS1/P=Gr
XM W)UAS(->Z]1J?,?SZCX+S:Z"I54D%!'36[8JB?=/_ASBL\%@_EA.U H.OPKq
XMWM!F?Z/#7"QKXBC\\8<^!A7"N893O/W0NK;/9HM%+4STT7ZV[^O]T,/WLRR<p
XM^OZ4P0F0B'J^@O) 8)"L"H7FS6@?G:.'J%JPYW[.(*13,J!*^I7Y62UQE)]Ho
XM[.2\0^5(Z>#/NN,XU),5RZ_@%2[K^QGH7,B_GS9JC5H>J(L$%QV^->Z?!P+#n
XMZM%$3ISF[KF"E^[M_<RZNP;-UWMC.2[='L^D_>5H<#2L"2]BCT<'EAVUZN'Hm
XM0WVB3'3A1^BIXA0&*8>>*DYA8GKHJ>(4AE%!Y4V]K!@H\"VLW2OT5'$*<TW1l
XM?A%X7*&GBE.8I>Z[A SIN56S>(F!A#P0&.!5D@H]/R$/! 9&_$C[:VB(=Z&Gk
XMBE,8*#%J35M6R .! :Z7I3P0&'R7"K4/J^5,IE#FM1IVQLA8#]8=AY^(T%/%j
XM*0R4&+5]"\AN270\URH-? 6BB([HPH_0Y*^.KG S*:%)2EA]$1":#ILY&AA5i
XM,;>,AN:<.G2BFWB2C9@,E(5U%)K*PMNS?%85E-1D43(#9019:9NKT/*5E>\Kh
XM&!@>PP-5/#(T'39/@0N/WA/&K,D:E(AHT(V_C 6)&QB[Q-?Q"%S8M>*V" A-g
XM4@)O8]9D+5EI(<&$A NS8'TMS'PD(1J1.(+Y3HHL_[Z#R(.=UVZWP%]C5)G<f
XMXNO<W, (%8S<0XR*F;*HL.&Q P&0L&L9+*+/H,9Y4VO$2?Y>:CM73'-?ES-We
XM"MS2S8%+Q$ K[^7#0W1$%WY\1*3,>*V^"&"\3K?E)]JQY!N&^"6]#BV F(Q0d
XMK#P1/B+:Y:IB94 PT* ^O5W(*OR\\?=/!DHN+H2U!M>@TYR,1S)>VC/W&SG)c
XM&4N^@?;P2,9+>\C"&R:^+3_1CB7?0'L^R3J<[>O69E2_[6LE&"A>F \Q=BR]b
XM91\:3A[I=6@!Q 2(!KBBPTAJRAED4*.!@8*&<N.-1"76^J%(M$VOD(AJ)1C>a
XML\3Y$\C?% 8:_BQQ_@0*<WT!:H8U10FQN;BQO[**YXL;A'1*!E1)OS(_]PWOz
XM725:&3ZZY*+=7=O61Y(P+PP>'WJH?V2/]+OR"'TZMO$I!V<#=;U93.]40[M[y
XJ0J-A0QAC1'%PXK'D\BB9,E,@0%/8T#B.A A6P[43\5?[]-!S=!T5A)X x
X w
Xend
/
echo x - master
sed '/^X/s///' > master << '/'
X.CD "master \(en control the creation of shervers [IBM]"
X.SX "master \fIcount \fIuid \fIgid \fIcommand"
X.FL "\fR(none)"
X.EY "master 2 1 1 /bin/sherver port" "Start 2 shervers"
X.PP
XIf a machine is intended to be used as a server, its \fI/etc/rc\fR 
Xfile should
Xhave a command similar to the example above.  When the system is booted, 
X\fImaster\fR runs and forks off the required number of shervers (shell
Xservers), up to a maximum of four.
XThey run with the indicated uid and gid, and listen to the indicated port.  
XWhen an \fIrsh\fR is done
Xon a client machine, the command is given to one of the shervers for execution.
XWhen the sherver is done, it exits, \fImaster\fR, which is always running, 
Xsees this,
Xand creates a new sherver.  
XThus \fImaster\fR is analogous to \fIinit\fR, only it makes
Xnew shervers (usually) instead of new \fIlogin\fR programs.  
X\fIMaster\fR must run as root to be able to do setuid and setgid.
X
X
X.SP 1
/
echo x - mdb
sed '/^X/s///' > mdb << '/'
X.CD "mdb \(en Minix debugger [68000]"
X.SX "mdb \fIexecutable\fR"
X.FL "\fR(none)"
X.EY "mdb /usr/bin/ls" "Invoke the debugger on the \fIls\fR program"
X.PP
X.I Mdb
Xprovides a means of debugging
X.MX
Xprograms. 
XIt supports symbolic debugging. 
XThe argument,
X.I executable ,
Xis a 
X.MX
Xexecutable file. 
XIf no file is specified the default is \fIa.out\fR.
XA description of the commands is given in Chap. 9.
X
X
X
X.SP 1
/
echo x - megartc
sed '/^X/s///' > megartc << '/'
X.CD "megartc \(en set date from real time clock [Mega ST]"
X.SX "megartc [\(end]"
X.FL "\(end" "output some debugging information"
X.EY "megartc" "Set the date from the Mega ST real time clock"
X.PP
X.I Megartc
Xreads the current date and time from the battery powered real
Xtime clock in the Mega ST and sets the
X.MX 
Xtime accordingly.
X
X
X
/
echo x - mined
sed '/^X/s///' > mined << '/'
X.CD "mined \(en \*(M2 editor"
X.SX "mined\fR [\fIfile\fR]
X.FL "\fR(none)"
X.EX "mined /user/ast/book.3" "Edit an existing file"
X.EX "mined" "Call editor to create a new file"
X.EX "ls \(enl | mined" "Use \fImined\fR as a pager to inspect listing"
X.PP
X.I Mined
X(pronounced min-ed) is a simple full-screen editor.
XWhen editing a file, it holds the file in memory, thus speeding up
Xediting, but limiting the editor to files of up to about 35K.
XLarger files must first be cut into pieces by
X.I split .
XLines may be arbitrarily long.
XOutput from a command may be piped into
X.I mined
Xso it can be viewed without scrolling off the screen.
XSee also Chap. 9.
X
X
X
/
echo x - minimacros
sed '/^X/s///' > minimacros << '/'
X.de CD
X.ne 2
X.if t .ta 0.9i 1.15i 2.75i 3.25i 3.75i
X.if n .ta 11m 15m 40m
X.nr x 0 0
X.nr y 0 0
X.nr z 0 0
X.if n #\\$1
X.if n .br
X\\fBCommand:\&	\\$1\\fR
X.br
X..
X.de SX
X.if \\nx<=0 \\fBSyntax:\&	\\$1
X.if \\nx>0 \&	\\fB\\$1
X.nr x 1 1
X.br
X..
X.de FL
X.if \\ny<=0 \\fBFlags:\&	\\fB\\$1	\\fR\\$2
X.if \\ny>0 \& 	\\fB\\$1	\\fR\\$2
X.nr y 1 1
X.br
X..
X.de EX
X.br
X.nf
X.if \\nz<=0 \\fB\&Examples:	\\fR\\$1	\\fR# \\$2
X.if \\nz>0 \&	\\fR\\$1	\\fR# \\$2
X.nr z 1 1
X.br
X..
X.de EY
X.br
X.nf
X.if \\nz<=0 \\fB\&Example:	\\fR\\$1	\\fR# \\$2
X.if \\nz>0 \&	\\fR\\$1	\\fR# \\$2
X.nr z 1 1
X.br
X..
X
/
echo x - minix
sed '/^X/s///' > minix << '/'
X.CD "minix \(en \*(M2 bootstrap [AMIGA]"
X.SX "minix \fR [\fB\(ene \fRadr] [\fB\(enf \fRadr] [\fB\(enk \fRfile] [\fB\(enl \fRadr] [\fB\(enm \fRadr] [\fB\(enn \fRadr] [\fB\(enq \fRfreq]"
X.br
X.ti 1.45i
X[\fB\(enr \fRrate] [\fB\(ens \fRadr] [\fB\(ent \fRfreq] [\fB\(en?]"
X.FL "\(ene" "Kernel execute address (default: kernel destination address)"
X.FL "\(enf" "Font data e.g. $fc1234 (default: romfont)"
X.FL "\(enk" "Kernel image data file (default: \fIminix.img\fR)"
X.FL "\(enl" "Kernel image already loaded, at given address"
X.FL "\(enm" "Address of 256K memory chunk you want to include in list"
X.FL "\(enn" "Address of 256K memory chunk you want to exclude from list"
X.FL "\(enq" "Set keyboard repeat speed, default=15 Hz"
X.FL "\(enr" "Set diskette seek rate (default: 4000 \(*msec)"
X.FL "\(ens" "Kernel destination address (default: $000200)"
X.FL "\(ent" "Set clock freq (default: PAL=7093790 Hz, NTSC=7159090 Hz)"
X.FL "\(en?" "Display this message"
X.EX "minix" "Boot \*(M2 from the default \fIminix.img\fRfile"
X.EX "minix \(enm $300000" "Add a 256K RAM block at $300000 and boot"
X.EX "minix \(ent 7093700" "Set a slightly lower clock rate and then boot"
X.PP
XThe casual user will (should) probably never use most of these options,
Xbut they might be helpful for development purposes. 
XIf you do not know what you are doing, do not use these options; wait until you
Xhave become an expert.
X
X
X
/
echo x - mkdir
sed '/^X/s///' > mkdir << '/'
X############ NEXT ENTRY HAS NOT BEEN CHECKED #############
X.CD "mkdir \(en make a directory"
X.SX "mkdir [\fB\(enp\fR] [\fB\(enm \fImode\fR] \fIdirectory ..."
X.FL "\(enm" "Create directory with mode"
X.FL "\(enp" "Create missing intermediate directories"
X.EX "mkdir dir" "Create \fIdir\fP in the current directory"
X.EX "mkdir \(enp /user/ast/dir" "Create the \fI/user/ast\fP and \fI/user/ast/dir\fP"
X.PP
XThe specified directory or directories are created and initialized. If any
Xintermediate directory is missing and \fB(enp\fR is specified, the missing
Xcomponent will be created and no error displayed if directory already
Xexists. If the \fB\(enm\fR flag is used, this will be equivalent to a chmod
Xon the directory after its creation.
X
X
X
/
echo x - mkfifo
sed '/^X/s///' > mkfifo << '/'
X############ NEXT ENTRY HAS NOT BEEN CHECKED #############
X.CD "mkfifo \(en make a named pipe"
X.SX "mkfifo [\fB\(enm \fImode\fR] \fIfifo ..."
X.FL "\(enm" "Create fifo with specified mode"
X.EX "mkfifo pipe" "Create \fIpipe\fP in the current directory"
X.EX "mkfifo -m a+w systatus" "Create the \fIsystatus\fP writable by all"
X.PP
XThe specified fifo special files are created.
XIf the \fB\(enm\fR flag is used, this will be equivalent to a chmod
Xon the fifo special file after its creation.
X
X
X
/
echo x - mkfs
sed '/^X/s///' > mkfs << '/'
X.CD "mkfs \(en make a file system"
X.SX "mkfs \fR[\fB\(enLdot\fR] \fIspecial \fIprototype"
X.FL "\(enL" "Make a listing on standard output"
X.FL "\(enb" "Number of blocks in the file system"
X.FL "\(end" "Use mod time of \fImkfs\fR binary for all files"
X.FL "\(eni" "Number of i-nodes in the file system"
X.FL "\(eno" "Use a drive other than 0 or 1 (safety precaution)"
X.FL "\(ent" "Do not test if file system fits on the medium"
X.FL "\(en1" "Make a version 1 file system (for backward compatibility)"
X.EX "mkfs /dev/fd1 proto" "Make a file system on \fI/dev/fd1\fR"
X.EX "mkfs /dev/fd1 360" "Make empty 360 block file system"
X.EX "mkfs /dev/hd2 -b 20000 -i 4000" "Make file system on partition 2"
X.PP
X.I Mkfs
Xbuilds a file system and copies specified files to it.
XThe prototype file tells which directories and files to copy to it.
XIf the prototype file cannot be opened, and its name is just a string of
Xdigits, an empty file system will be made with the specified number of
Xblocks.
XThe number of blocks can also be specified with the \fB\(enb\fR flag.
XA sample prototype file follows.
XThe text following the \fI#\fR sign in the example below is comment.
XIn real prototype files, comments are not allowed.
X.SP 0.5
X.HS
X.nf
X.ta 0.20i 0.70i 1.10i 3i 3.5i 4i
X	boot			# boot block file (ignored)
X	360 63			# blocks and i-nodes
X	d--755 1 1		# root directory
X	   bin	d--755 \|2 1	# bin dir: mode (755), uid (2), gid (1)
X		sh	\|---755 2 1 /user/bin/shell	# shell has mode \fIrwxr-xr-x\fP
X		mv	-u-755 2 1 /user/bin/mv	# u = SETUID bit
X		login	-ug755 2 1 /user/bin/login	# SETUID and SETGID
X	   $			# end of \fI/bin\fP
X	   dev	d--755 2 1	# special files: tty (char), fd0 (block)
X		tty	c--777 2 1 4 0	# uid=2, gid=1, major=4, minor=0
X		fd0	b--644 2 1 2 0 360	# uid, gid, major, minor, blocks
X	   $			# end of \fI/dev\fP
X	   user	d--755 12 1	# user dir: mode (755), uid (12), gid (1)
X		ast	d--755 12 1	# \fI/user/ast\fP
X		$		# \fI/user/ast\fP is empty
X	   $			# end of \fI/user\fP
X	$			# end of root directory
X.HS
X.SP 0.5
X.fi
XThe first entry on each line (except the first 3 and the $ lines, which
Xterminate directories) is the name the file or directory will get on the
Xnew file system.  
XNext comes its mode, with the first character being
X\fB\(endbc\fR for regular files, directories, block special files and character 
Xspecial files, respectively.
XThe next two characters are used to specify the SETUID and SETGID bits, as
Xshown above.
XThe last three characters of the mode are the 
X.I rwx
Xprotection bits.
X.PP
XFollowing the mode are the uid and gid.
XFor special files, the major and minor devices are needed.
XThe size in blocks must also be specified for block special files (the
X.MX
Xblock size is 1K; this can only be changed by changing
X.I BLOCK_SIZE
Xand then recompiling the operating system).
X
X
X
/
echo x - mknod
sed '/^X/s///' > mknod << '/'
X.CD "mknod \(en create a special file"
X.SX "mknod \fIfile\fR [\fBb\fR] [\fBc\fR] \fImajor \fIminor \fR[\fIsize\fR]"
X.FL "\fR(none)"
X.EX "mknod /dev/plotter c 7 0" "Create special file for a plotter"
X.EX "mknod /dev/fd3 b 2 3 360" "Create a 360K device for diskette drive 3"
X.PP
X.I Mknod
Xcreates a special file named
X.I file ,
Xwith the indicated major and minor device numbers.
XThe second argument specifies a block or character file.
XBlock devices have a size, which must be specified in blocks.
XCharacter devices do not have a size so the fifth argument is omitted.
X
X
X
/
echo x - mkproto
sed '/^X/s///' > mkproto << '/'
X.CD "mkproto \(en create a \s-2MINIX\s0 prototype file"
X.SX "mkproto \fR[\fB\(enb \fIn\fR] [\fB\(end \fIstr\fR] [\fB\(eng \fIn\fR] [\fB\(eni \fIn\fR] [\fB\(enp \fInnn\fR] [\fB\(ens\fR] [\fB\(ent \fIroot\fR] [\fB\(enu \fIn\fR]"
X.FL "\(enb" "Number of blocks in the prototype is \fIn\fR"
X.FL "\(end" "Indent the prototype file using \fIstr\fR instead of tab"
X.FL "\(eng" "Use \fIn\fR as the gid for all files and directories"
X.FL "\(eni" "Number of i-nodes in the prototype is \fIn\fR"
X.FL "\(enp" "Use \fInnn\fR (3 octal digits) as the protection mode"
X.FL "\(ens" "Use the same uid, gid and mode as the source files have"
X.FL "\(ent" "Use the string \fIroot\fR as the path prefix for every file"
X.FL "\(enu" "Use \fIn\fR as the uid for all files and directories"
X.EX "mkproto \(enb360" "Make a 360K prototype of this directory"
X.EX "mkproto \(enu2 \(eng1 \(enp644" "Give all files uid 2, gid 1 and mode 644"
X.PP
X\fIMkproto\fR creates an \fImkfs\fR prototype file for the specified
Xsource-directory. 
XThe prototype file is either written to \fIstdout\fR or, if specified, 
Xthe proto-file.
X
X
X
/
echo x - modem
sed '/^X/s///' > modem << '/'
X.CD "modem \(en switch the modem and getty state"
X.SX "modem \fR[\fB\(eno\fR] [\fB\(eni \fInum\fR] \fBtty\fIn\fR"
X.FL "\(eno" "Turn getty off and set modem to dialout"
X.FL "\(eni" "Set line to dialin"
X.EX "modem \(eno tty1" "Set tty1 to dialout"
X.EX "modem \(eni2 tty1" "Set tty1 to dialin (2 rings)"
X.PP
XThe \fIgetty\fR program allows a terminal port to be used for both dialin and
Xdialout. 
XThis little program switches the getty state, and also sends
Xsome commands to the modem attached to the specified line.
XIf the \fB\(eno\fR flag is presnt, \fImodem\fR will put the 
Xgetty process (if any) connected to the specified line into 
XSUSPEND state, which means that it
Xwill not pay attention to that line until it is reset to RESTART state.
XAlso, \fImodem\fR will send some (Hayes) 
Xcommands to the attached modem to disable the auto-nanswer mode. 
XThe \fB\(eni\fR flag specifies the number of times the telephone has to 
Xring before the modem may answer the call (to give the operator a chance).
X
X
X
X.SP 1
/
echo x - mon_man
sed '/^X/s///' > mon_man << '/'
X   5  K    4034: 10 Dec 92 Kees J. Bot     Little monitor document
X(Message # 5: 4034 bytes, KEEP)
XReceived: from spanker.cs.vu.nl by top.cs.vu.nl id aa00984; 10 Dec 92 9:49 MET
XReceived: from hornet.cs.vu.nl by spanker.cs.vu.nl id aa00324;
X          10 Dec 92 9:49 MET
XDate:     Thu, 10 Dec 92 9:49:24 MET
XFrom:     "Kees J. Bot" <kjb@cs.vu.nl>
XTo:       ast@cs.vu.nl
XSubject:  Little monitor document
XMessage-ID:  <9212100949.aa16951@hornet.cs.vu.nl>
X
XI've written a small document on the monitor as you requested.  Below is
Xa shar file with the nroff source.  The command
X
X	nroff -ms mon.doc.ms | colcrt - > mon.doc
X
Xwill turn it into a flat file.  Only the page breaks are left to be
Xremoved.
X
X(I should be less vocal on the net, now someone sent his Minix questions
Xto me, but the praise still goes to you: "Tell Andy he did a superb job
Xputting this OS together."  Just passing it on. :-)
X--
X								Kees.
X_._. .._ _   ._ ._.. ___ _. __.   _ .... .   _.. ___ _ _ . _..   ._.. .. _. .
X: This is a shar archive.  Extract with sh, not csh.
X: This archive ends with exit, so do not worry about trailing junk.
X: --------------------------- cut here --------------------------
XPATH=/bin:/usr/bin:/usr/ucb
Xecho Extracting 'mon.doc.ms'
Xsed 's/^X//' > 'mon.doc.ms' << '+ END-OF-FILE ''mon.doc.ms'
XX.SH
XXDoing more with the Minix Boot Monitor.
XX.PP
XXThis text describes the menu interface of the Minix Boot Monitor, and
XXthe commands that may be used to customize it.
XX.LP
XXFirst of all, the monitor mode as distributed normally hides some of the
XXfunctionality, but shows you an explanation of the environment
XXvariables instead.  If you add -DEXTENDED_LIST to CFLAGS in the Makefile
XXand recompile, then you will no longer see the long explanation (you
XXshould know it by now), but you will see all the commands the monitor
XXknows about.
XX.SH
XXThe commands.
XX.PP
XXThe boot command has two functions, one is to load and start Minix, the
XXother is to boot a different operating system.  If the first partition
XXon your hard disk contains MS-DOS, then
XX.DS
XX.B
XXboot hd1
XX.R
XX.DE
XXwill boot MS-DOS.  (Not all operating systems like to be called this
XXway, some insist on being on the active partition.)
XX.LP
XXThe delay, ls, and other simple commands are not too difficult to
XXunderstand, just try them out.  The trap command may be used to execute
XXa function after a delay.  You can show a menu first and boot Minix
XXafter 5 seconds of inactivity like this:
XX.DS
XX.B
XXtrap 5000 boot; menu
XX.R
XX.DE
XX(This must be typed on one line, traps are cancelled when the prompt is
XXprinted.)
XX.SH
XXFunctions.
XX.PP
XXFunctions are used to bundle commands, or to build menu items.  The best
XXexample of a simple function is 'main', the function executed by the
XXmonitor on startup.  Main is by default defined as:
XX.DS
XX.B
XXmain() { menu }
XX.R
XX.DE
XXSo that's why you see a menu at the start.  The example with 'trap'
XXabove could be executed by main if you type:
XX.DS
XX.B
XXmain() { trap 5000 boot; menu }
XXsave
XX.R
XX.DE
XXThe save command will save the changed environment of the monitor to the
XXsecond half of the boot block, the "boot parameters sector".
XX.LP
XXFunctions may have one or two arguments, the first is a key to be
XXpressed from the menu to execute the function, the optional second
XXargument is the text that is to be displayed on the menu.  The single
XXargument functions should only be produced by construct, like this
XXone:
XX.DS
XX.B
XXAT(a) {label=AT;image=42:626;echo AT kernel selected;menu}
XX.R
XX.DE
XXIt invites you to choose one of many kernels on a special boot floppy.
XX.LP
XXThe two argument functions are used to customize the menu, once you
XXdefine one the default option disappears, so your first function will
XXprobably be one to start Minix.  Example:
XX.DS
XX.B
XXminix(=,Start Minix) { boot }
XXdos(d,Boot MS-DOS) { boot hd1 }
XXsave
XXmenu
XX.R
XX.DE
XXNow you can type '=' or 'd' to choose between Minix and DOS.
X+ END-OF-FILE mon.doc.ms
Xchmod 'u=rw,g=r,o=r' 'mon.doc.ms'
Xset `wc -c 'mon.doc.ms'`
Xcount=$1
Xcase $count in
X2542)	:;;
X*)	echo 'Bad character count in ''mon.doc.ms' >&2
X		echo 'Count should be 2542' >&2
Xesac
Xexit 0
/
echo x - more
sed '/^X/s///' > more << '/'
X.CD "more \(en pager"
X.SX "more\fR [\fB\(endf\&lpsu\fR]\fR [\fB\(en\fIn\fR] [\fB+\fIn\fR] [\fB+\fR/\fIpattern\fR] [\fIfile\fR] ..."
X.FL "\(end" "Display prompt message at each pause"
X.FL "\(enf" "Do not fold lines"
X.FL "\(enl" "Do not treat CTRL-L as form feed"
X.FL "\(enp" "Page mode.  Do not scroll"
X.FL "\(ens" "Suppress multiple blank lines"
X.FL "\(enu" "Use escape sequences for underlining"
X.EX "more file" "Display file on the screen"
X.EX "more \(enp file1 file2" "Display two files in page mode"
X.EX "more \(en10 file" "Use a 10 line window"
X.EX "more +/begin file" "Hunt for the string \fIbegin\fR"
X.PP
X\fIMore\fR is a pager that allows one to examine files.
XWhen \fImore\fR starts up, it displays a screenful of information from the
Xfirst file in its list, and then pauses for one of the following commands.
XIn this description, # represents an integer telling how many of something.
X.HS
X.nf
X.ta 0.5i 1.5i
X	<space>	\(en Display next page
X	<return>	\(en Display next line
X	CTRL-B	\(en Go backward half a screenful
X	CTRL-D	\(en Go forward half a screenful
X	CTRL-L	\(en Redisplay the screen
X	#<space>	\(en Go forward # lines
X	=	\(en Print current line number
X	.	\(en Repeat previous command
X	'	\(en (single quote) Go back to start of last search
X	!	\(en Escape to a shell
X	#/<expr>	\(en Go to #-th occurrence of <expr>
X	:f	\(en Display current file name and line number
X	#:n	\(en Skip forward # files
X	#:p	\(en Skip backward # files
X	b	\(en Go backward half a screenful
X	d	\(en Go forward half a screenful
X	#f	\(en Skip # screenfuls
X	h	\(en Display \fI/usr/lib/more.help\fR
X	#n	\(en Go to #-th occurence of last <expr>
X	q	\(en Quit \fImore\fR
X	Q	\(en Quit \fImore\fR
X	#s	\(en Skip # lines
X	v	\(en Try to execute \fI/usr/bin/vi\fR
X	#z	\(en Go forward # lines and set screen size to #
X.fi
X.HS
XFor the benefit of users who always want to use certain flags when calling
X\fImore\fR, the shell variable MORE can be set,
Xfor example, to MORE="\(ENp".
X
X
X
/
echo x - mount
sed '/^X/s///' > mount << '/'
X.CD "mount \(en mount a file system"
X.SX "/etc/mount \fIspecial \fIfile\fR [\fB\(enr\fR]"
X.FL "\(enr" "File system is mounted read-only"
X.EY "/etc/mount /dev/fd1 /user" "Mount diskette 1 on \fI/user\fP"
X.PP
XThe file system contained on the special file is mounted on \fIfile\fP.
XIn the example above, the root directory of the file system in drive 1
Xcan be accessed as
X.DI /user
Xafter the mount.
XWhen the file system is no longer needed, it must be unmounted before being
Xremoved from the drive.
X
X
X
/
echo x - mref
sed '/^X/s///' > mref << '/'
X.CD "mref \(en make listing and cross reference map of \s-2MINIX\s0"
X.SX "mref\fR [\fB\(endlmstx\fR] [\fB\(enp \fIn\fR] [\fB\(en\fIn\fR] \fIfile ..."
X.FL "\(end" "Do not produce definition file (global symbol table)"
X.FL "\(enl" "Do not produce listing"
X.FL "\(enm" "Multiple references on one line are cited only once"
X.FL "\(enp" "Set initial page number to \fIn\fR"
X.FL "\(ens" "Suppress line numbering between procedures"
X.FL "\(ent" "Generate output for \fItroff\fR"
X.FL "\(enx" "Do not produce the cross reference map"
X.FL "\(en\fIn" "Number of lines to print per page, default = 50"
X.EX "mref *.[\fIhc\fR]" "List and cross reference files \fI.h\fR and \fI.c\fR"
X.EX "mref \(en60 \(ent *.c" "Produce \fItroff\fR input at 60 lines/page"
X.EX "mref \(endx \(enp 100 *.c" "Listing only, first page is numbered 100"
X.PP
XIn default mode, 
X.I mref
Xproduces three output files: a numbered listing of the input files
X(on standard output), a global symbol table (on \fIsymbol.out\fR),
Xand a cross reference map to the global symbols (on \fIxref.out\fR).
XA global symbol in this context is one present in a #define, PUBLIC,
XPRIVATE, or SYMBOL statement (the latter being introduced to allow users
Xto explicitly declare certain symbols as global).
XAny of the three outputs can be suppressed, or alternatively, be made
Xsuitable for input to \fItroff\fR for typesetting.
X
X
X
/
echo x - mv
sed '/^X/s///' > mv << '/'
X############ NEXT ENTRY HAS NOT BEEN CHECKED #############
X.CD "mv \(en move or rename a file"
X.SX "mv [\fB\(enf\&i\fR] \fIfile1 file2"
X.SX "mv [\fB\(enf\&i\fR] \fIfile\fR ... \fIdirectory"
X.FL "\(enf" "Do not prompt before removing existing files"
X.FL "\(eni" "Prompt before removing existing files"
X.EX "mv oldname newname" "Move \fIoldname\fP to \fInewname\fP"
X.EX "mv file1 file2 /user/ast" "Move two files to \fI/user/ast\fP"
X.PP
X.I Mv
Xmoves one or more files from one place in the file system to another.
XIf the old path and new path are on the same device, it is done by renaming
Xotherwise by copying. If you're not superuser, the copy will destroy the
Xfile's owner, group and setuid/setgid bits.
X.I mv
Xwill prompt before removing non-writable files if \fBstdin\fR is a terminal
Xor the \fB\(eni\fR flag was specified.
X
X
X
/
echo x - ncheck
sed '/^X/s///' > ncheck << '/'
X.CD "ncheck \(en i-node to name converter"
X.SX "ncheck\fR [\fB\(eni\fI numbers\fR] [\fB\(ena\fR] [\fB\(ens\fR] \fIfile_system\fR"
X.FL "\(ena" "List all files, even . and .."
X.FL "\(eni" "Followed by a list of i-nodes"
X.FL "\(ens" "List only special and setuid files"
X.EX "ncheck \(en /dev/fd0" "List everything on \fI/dev/fd0\fR"
X.EX "ncheck \(eni 10,15 /dev/fd0" "List i-nodes 10 and 15 on \fI/dev/fd0\fR"
X.PP
X\fISometimes one knows about an i-node number and wants to find the file
Xname that goes with it.  This program makes that mapping.
XThe default is to list everything on the device, but the \fB\(eni\fR
Xflag restricts the list to specified i-nodes and the \fB\(ens\fR flag
Xrestricts it to special files and setuid files (to look for possible
Xsecurity violations).
/
echo x - nm
sed '/^X/s///' > nm << '/'
X.CD "nm \(en print name list"
X.SX "nm\fR [\fB\(endgnopru\fR]\fR [\fIfile\fR] ..."
X.FL "\(end" "Print the offsets in decimal instead of in hex"
X.FL "\(eng" "Print only external symbols"
X.FL "\(enn" "Sort numerically rather than alphabetically"
X.FL "\(eno" "Prepend file name to each line rather than only once"
X.FL "\(enp" "Do not sort, print in symbol-table order"
X.FL "\(enr" "Sort in reverse order"
X.FL "\(enu" "Print only undefined symbols"
X.EX "nm \(enn a.out" "Print all symbols in numerical order"
X.EX "nm \(endg a.out" "Print globals alphabetically in decimal"
X.PP
X\fINm\fR prints the symbol table of executable files when it is available.
XIf no file is given, the symbols in \fIa.out\fR are used.  
XThe format of the table 
Xis somewhat compatible with the one produced  by \fIasld\fR when used with 
Xthe \fB\(ens\fR option. The symbol table can be added with \fIast\fR.  
XAssembly language files do not have symbol tables.
X
X
X
/
echo x - nroff
sed '/^X/s///' > nroff << '/'
X.CD "nroff \(en text formatter"
X.SX "nroff\fR [\fB\(enbv\fR]\fR [\fB\(enm\fImacros\fR] [\fB\(enp\fIn\fR] [\fB\(en\fRn\fR] [\fB+\fRn\fR] [\fIfile\fR] ..."
X.FL "\(enb" "Output device can backspace"
X.FL "\(enm" "Use \fI/usr/lib/tmac/tmac.\fR macros"
X.FL "\(env" "Print \fInro\fR version number"
X.FL "\(mi\fIn\fR" "Last page to print"
X.FL "+\fIn\fR" "First page to print"
X.EX "nroff infile >outfile" "Format \fIinfile\fR"
X.EX "nroff +3 \(en5 infile >outfile" "Only output pages 3-5"
X.PP
X\fINroff\fR is a text formatter like \fIroff\fR, but more flexible.
XUnlike \fIroff\fR, it accepts parametrized macros, for example.
XThe commands are given in Chap. 9.
X
X
X
/
echo x - od
sed '/^X/s///' > od << '/'
X.CD "od \(en octal dump"
X.SX "od\fR [\fB\(enbcdhox\fR]\fR [\fIfile\fR] [ [\fB+\fR] \fIoffset\fR [\fB.\fR][\fBb\fR]\fR ]"
X.FL "\(enb" "Dump bytes in octal"
X.FL "\(enc" "Dump bytes as ASCII characters"
X.FL "\(end" "Dump words in decimal"
X.FL "\(enh" "Print addresses in hex (default is octal)"
X.FL "\(eno" "Dump words in octal (default)"
X.FL "\(env" "Verbose (list duplicate lines)"
X.FL "\(enx" "Dump words in hex"
X.EX "od \(enox file" "Dump \fIfile\fP in octal and hex"
X.EX "od \(end file +1000" "Dump \fIfile\fP starting at byte 01000"
X.EX "od \(enc file +10.b" "Dump \fIfile\fP starting at block 10"
X.PP
X.I Od
Xdumps a file in one or more formats.
XIf \fIfile\fP is missing, \fIstdin\fR is dumped.
XThe \fIoffset\fP argument tells
X.I od
Xto skip a certain number of bytes or blocks before starting.
XThe offset is in octal bytes, unless it is followed by a 
X\*(OQ.\*(CQ for decimal or \fBb\fP for blocks or both.
X
X
X
/
echo x - passwd
sed '/^X/s///' > passwd << '/'
X.CD "passwd \(en change a login password"
X.SX "passwd\fR [\fIname\fR]"
X.FL "\fR(none)"
X.EX "passwd" "Change current user's password"
X.EX "passwd ast" "Change ast's password (super\(enuser only)"
X.PP
X.I Passwd
Xis used to change your password.
XIt prompts for the old and new passwords.
XIt asks for the new password twice, to reduce the effect of a typing error.
XDo not forget to copy the modified password file back to the root file system,
Xor the changes will be lost when the system is rebooted.
X
X
X
/
echo x - paste
sed '/^X/s///' > paste << '/'
X.CD "paste \(en paste multiple files together"
X.SX "paste\fR [\fB\(ens\fR]\fR [\fB\(end\fI list\fR] \fIfile..."
X.FL "\(end" "Set delimiter used to separate columns to \fIlist\fR.
X.FL "\(ens" "Print files sequentially, file \fIk\fR on line \fIk\fR.
X.EX "paste file1 file2" "Print \fIfile1\fR in col 1, \fIfile2\fR in col 2"
X.EX "paste \(ens f1 f2" "Print \fIf1\fR on line 1 and \fIf2\fR on line 2"
X.EX "paste -d : file1 file2" "Print the lines separated by a colon"
X.PP
X\fIPaste\fR concatenates corresponding lines of the given input files
Xand writes them to standard output. The lines of the different files
Xare separated by the delimiters given with the option \(ens\fR. If
Xno list is given, a tab is substituted for every linefeed, except the last one.
XIf end-of-file is hit on an input file, subsequent lines are empty.
XSuppose a set of \fIk\fR files each has one word per line.  
XThen the \fIpaste\fR output will have \fIk\fR columns, 
Xwith the contents of file \fIj\fR in column \fIj\fR.  
XIf the \fB\(ens\fR flag is given, then the first
Xfile is on line 1, the second file on line 2, etc.  
XIn effect, \fB\(ens\fR turns the output sideways.
X.PP
XIf a list of delimiters is given, they are used in turn.  The C escape
Xsequences \\n, \\t, \\\\, and \\0 are used for linefeed, tab, backslash, and
Xthe null string, respectively.
/
echo x - patch
sed '/^X/s///' > patch << '/'
X.CD "patch \(en patches up a file from the original and a diff"
X.SX "patch\fR [\fB\(enNRbcdef\&lnop\fR]\fR [\fB\(enF\fIn\fR] [\fB\(enD \fIlabel\fR] [\fIfile \fR[\fIdifflist\fR]]"
X.FL "\(enD" "Mark changes with   #ifdef...#endif   next arg gives label"
X.FL "\(enF" "Sets the maximum fuzz factor to \fIn\fR"
X.FL "\(enN" "Ignore patches that are reversed or already applied"
X.FL "\(enR" "Reverse the patches"
X.FL "\(enb" "Next argument is backup extension, instead of using a tilde (\(ap)"
X.FL "\(enc" "Interpret the patch file as a context diff"
X.FL "\(end" "Cd to the next arg (assumed a dir) before doing anything"
X.FL "\(ene" "Interpret the patch file as an ed script"
X.FL "\(enf" "Forces \fIpatch\fR to do its work without asking any questions"
X.FL "\(enl" "Do matching loosely (e.g., all white space is equivalent)"
X.FL "\(enn" "Interpret the patch file as a normal diff"
X.FL "\(eno" "Next argument is the output file name"
X.FL "\(enp" "Sets the pathname strip count"
X.EX "patch file difflist" "Fix up \fIfile\fR"
X.EX "patch <difflist" "Patch multiple files"
X.PP
X\fIPatch\fR takes an original file and a diff listing and recreates the 
Xnew file.  It is functionally similar to 
X\fIfix\fR, but much more powerful.  Not only
Xcan it handle normal diffs, but also context diffs produced by \fIcdiff\fR.  In
Xaddition, it works even when the file being patched has other changes to it.
XIt deduces the type of \fIdifflist\fR itself (unless 
Xgiven \fB\(enc\fR, \fB\(ene\fR, or \fB\(enn\fR).
XThe normal usage is given in the example above.  In this case \fIpatch\fR will
Xmodify \fIfile\fR to incorporate all the patches.  
XThe original file will be saved to a file ending in a tilde (\(ap).
X.PP
XIf no input file is given, \fIpatch\fR reads \fIstdin\fR which may contain
Xthe concatenation of multiple diff listings.
XIn this way, all the files in a directory may be updated at once.
XSee Chap. 9 for more information.
X
X
X
/
echo x - pathchk
sed '/^X/s///' > pathchk << '/'
X############ NEXT ENTRY HAS NOT BEEN CHECKED #############
X.CD "pathchk \(en check pathname"
X.SX "pathchk [\fB\(enp\fR] \fIpath\fR ..."
X.FL "\(enp" "Check against POSIX rules"
X.EX "pathchk /usr/src/file.c" "Check the accessibility of \fIfile.c\fP"
X.EX "pathchk \(enp file" "Check posix compliance of \fIfile\fR"
X.PP
X.I Pathchk
Xverifies path names and display error if paths are too long, contain names
Xthat are too long, go thru a non-searchable directory or contain an
Xinvalid character in names. If the \fB\(enp\fR flag is specified, the POSIX
Xrules apply instead of the rules of the current file system.
X
X
X
X
/
echo x - pr
sed '/^X/s///' > pr << '/'
X.CD "pr \(en print a file"
X.SX "pr\fR [\fB\(enMfnt\fR]\fR [\fB\(enh \fIn\fR]  [\fB\(enl \fIn\fR]  [\fB\(enw \fIn\fR] [\fB\(en\fRcolumns\fR] [\fB+\fIpage\fR] [\fIfile\fR] ..."
X.FL "\(enM" "Use MINIX style line number"
X.FL "\(enf" "Do not fold long lines"
X.FL "\(enh" "Take next argument as page header"
X.FL "\(enl" "Sets page length in lines"
X.FL "\(enn" "Number the output lines"
X.FL "\(ent" "Do not print page header or trailer"
X.FL "\(enw" "Sets line length in characters"
X.EX "pr \(enw85 \(enl60 file" "Use 85 character line, 60 line page"
X.EX "pr \(en3 file" "List \fIfile\fP three columns to a page"
X.EX "pr +4 file" "Start printing with page 4"
X.PP
X.I Pr
Xformats one or more files for printing.
XIf no files are specified, \fIstdin\fR is printed.
XOptions are provided for setting the width and height of the page, the
Xnumber of columns to use (default 1), and the page to start with, among others.
X
X
X
/
echo x - prep
sed '/^X/s///' > prep << '/'
X.CD "prep \(en prepare a text file for statistical analysis"
X.SX "prep\fR [\fIfile\fR]"
X.FL "\fR(none)"
X.EY "prep infile >outfile" "Prepare \fIinfile\fR"
X.PP
X\fIPrep\fR strips off most of the troff commands from a text file and then
Xoutputs all the words, one word per line, in the order they occur in the file.
XThis file can then be sorted and compared to a dictionary (as a spelling
Xchecker), or used for statistical analyses.
X
X
X
/
echo x - pretty
sed '/^X/s///' > pretty << '/'
X.CD "pretty \(en \s-2MINIX\s0 pretty printer"
X.SX "pretty \fIfile ..."
X.FL "\fR(none)"
X.EY "pretty file1 file2" "Convert two files to \s-2MINIX\s0 layout"
X.PP
X\fIPretty\fR converts one or more C source files to 
X.MX 
Xformat by changing 
Xtheir layout.  Running this program does not affect the resulting binary
Xprograms.  Actually, \fIpretty\fR is a postprocessor for \fIindent\fR, which
Xmust be installed in \fI/bin\fR or \fI/usr/bin\fR.  Although the output is
Xnot bad, it is not entirely consistent with the book or even with itself.
X
X
X
/
echo x - printenv
sed '/^X/s///' > printenv << '/'
X.CD "printenv \(en print out the current environment"
X.SX "printenv"
X.FL "\fR(none)"
X.EY "printenv" "Print the environment"
X.PP
X\fIPrintenv\fR prints out the current environment strings, one per line.
X
X
X
/
echo x - printroot
sed '/^X/s///' > printroot << '/'
X.CD "printroot \(en print the name of the root device on standard output"
X.SX "printroot"
X.FL "\fR(none)"
X.EY "printroot" "Print the name of the root device"
X.PP
X.I Printroot 
Xis useful for initializing the \fI/etc/mtab\fR entry when the system is
Xbooted.
XIt figures out what the root device is by searching \fI/dev\fR until it
Xfinds a block special file with the right major/minor device numbers.
X
X
X
X.SP 1
/
echo x - ps
sed '/^X/s///' > ps << '/'
X.CD "ps \(en process status"
X.SX "ps [\(fB\(en\fR] [\(fBalxU\fR] [\(fBkernel mm fs\fR]"
X.FL "\(ena" "Print all processes with controlling terminals"
X.FL "\(enl" "Give long listing"
X.FL "\(enx" "Include processes without a terminal"
X.FL "\(enU" "Update (optional) name database"
X.EX "ps \(enaxl" "Print all processes and tasks in long format"
X.EX "ps \(enU /kernel /fs /mm" "Update database with given namelists"
X.PP
X\fIPs\fR prints the status of active processes.  Normally only the caller's own
Xprocesses are listed in short format (the PID, TTY, TIME and CMD fields as
Xexplained below).  The long listing contains:
X.HS
X.ta 0.5i 1.0i
X  F	Kernel flags:
X		001: free slot
X		002: no memory map
X		004: sending;
X		010: receiving
X		020: inform on pending signals
X		040: pending signals
X		100: being traced.
X.HS
X  S
X	State:
X		R: runnable
X		W: waiting (on a message)
X		S: sleeping (i.e.,suspended on MM or FS)
X		Z: zombie
X		T: stopped
X.HS
X  UID, PID, PPID, PGRP
X	The user, process, parent process and process group ID's.
X.HS
X  ADDR, SZ
X	Decimal address and size of the process in kilobytes.
X.HS
X  RECV
X	Process/task on which a receiving process is waiting or sleeping.
X.HS
X  TTY	
X	Controlling tty for the process.
X.HS
X  TIME
X	Process' cumulative (user + system) execution time.
X.HS
X  CMD	Command line arguments of the process.
X.HS
X.PP
XIf extra arguments (the kernel, mm and fs nonstripped executables) are
Xgiven, these are used to obtain the system addresses from (instead of the
Xdefault system executables).  This applies to the \fB\(enU\fR option also.  
XThis option creates \fI/etc/psdatabase\fR that contains system addresses and 
Xterminal names, after which \fIps\fR is faster and doesn't need the system 
Xexecutables anymore.
X.PP
XThe default system executables are \fI/usr/src/{kernel/kernel,mm/mm,fs/fs}\fR.
XIf the database is updated, an old psdatabase exists, and no paths are given to
Xps, it uses the paths that were previously stored in the database.  
XA \fIps \(enU\fR" in \fI/etc/rc\fR thus generally ensures an up-to-date 
Xdatabase.
X.PP
XThe files \fI/dev/{mem,kmem}\fR are used to read the system tables and command
Xline arguments from.  Terminal names in \fI/dev\fR are used to generate the 
Xmnemonic names in the TTY column, so \fIps\fR is independent of terminal naming
Xconventions.
X.PP
XWarning: \fIps\fR depends heavily on up-to-date system addresses and 
Xparameters.
XIt prints messages when they appear to be outdated.
/
echo x - pwd
sed '/^X/s///' > pwd << '/'
X.CD "pwd \(en print working directory"
X.SX "pwd"
X.FL "\fR(none)"
X.EY "pwd~~~~~" "Print the name of the working directory"
X.PP
XThe full path name of the current working directory is printed.
X
X
X
/
echo x - rcp
sed '/^X/s///' > rcp << '/'
X.CD "rcp \(en remote copy [IBM]"
X.SX "rcp\fR [\fImachine1!\fR]\fIfile1\fR [\fImachine2!\fR]\fIfile2"
X.FL "\fR(none)"
X.EX "rcp file mach1!/usr/ast/x" "Local \fIfile\fR to remote machine"
X.EX "rcp mach2!/usr/ast/x file" "Fetch remote file \fIx\fR"
X.PP
X\fIRcp\fR is not a program.  It is a shell script that does remote 
Xcopying.  It makes use of the programs \fIto\fR and \fIfrom\fR.
X
X
X
/
echo x - readall
sed '/^X/s///' > readall << '/'
X.CD "readall \(en read a device quickly to check for bad blocks"
X.SX "readall\fR [\fB\(enbt\fR] \fIfile"
X.FL "\(enb" "Produce shell script on \fIstdout\fR that calls \fIbadblocks\fR"
X.FL "\(ent" "Just print device size"
X.EX "readall /dev/hd0" "Read all of \fI/dev/hd0\fR"
X.EX "readall -b /dev/hd1 >s" "Generate shell script on \fIs\fR"
X.PP
X\fIReadall\fR reads all of the named device in large chunks.  
XIt reports about blocks that it cannot read.  
XUnlike \fIdiskcheck\fR, it does not attempt to write on
Xthe disk, making it safer to use when one is worried about a sick system.
XWhen the \fB\(enb\fR flag is given, the output is a shell script that
Xcalls the \fIbadblocks\fR program to marked all the bad blocks.
XWhenever installing 
X.MX ,
Xit is wise to run \fIreadall\fR with the \fB\(enb\fR flag first on all
Xthe hard disks.
X
X
X
/
echo x - readclock
sed '/^X/s///' > readclock << '/'
X.CD "readclock \(en read the real time clock [IBM PC/AT and AMIGA]"
X.SX "readclock"
X.FL "\fR(none)"
X.EY "date \`/usr/bin/readclock\` </dev/tty" "Useful in \fI/etc/rc\fR"
X.PP
X\fIReadclock\fR reads the AT's real time clock and prints the result in 
Xa form useful to date, namely, MMDDYYhhmmss.  
XIf the clock does not exist (e.g., on a
XPC), it outputs \*(OQ\(enq\*(CQ to query the user for the time.  
XThe example given above
Xcan be put in \fI/etc/rc\fR to load the real time when the system is booted.
X
X
X
/
echo x - readfs
sed '/^X/s///' > readfs << '/'
X.CD "readfs \(en read a \s-2MINIX\s0 file system"
X.SX "readfs\fR [\fB\(enil\fR] \fIblock_special\fR [\fIdir\fR]"
X.FL "\(eni" "Give information about the file, but do not extract files"
X.FL "\(enl" "List the files extracted on standard output"
X.EY "readfs \(enl /dev/fd0" "List contents of diskette"
X disk"
X.PP
X\fIReadfs\fR reads a diskette containing a 
X.MX
Xfile system.  It can
Xextract all the files from it, give a listing of them, or both.  The files
Xextracted can be put in a user-specified directory (default: current
Xdirectory).  If subdirectories are needed, they will be created automatically.
X
X
X
X.SP 1
/
echo x - recover
sed '/^X/s///' > recover << '/'
X.CD "recover \(en recover files that have been removed."
X.SX "recover \fIfile ..."
X.FL (none)
X.EX "rm x; recover x" "Unremove x"
X.EX "recover a b c" "Recover three files"
X.PP
XMINIX allows files that have been deleted (e.g., with \fIrm\fR) to be
Xrestored (in \fI/tmp\fR).
XThe trick is that when a file is unlinked, its i-node number is kept in
Xthe directory entry.
XAs long as the directory entry and disk blocks are not reused, the file
Xcan be recovered.
XThis program is actually just a little front end for \fIde\fR, which must be
Xinstalled and executable ast setuid root.
X
X
X
X.SP 1.6
/
echo x - ref
sed '/^X/s///' > ref << '/'
X.CD "ref \(en look up a reference in a \fItags\fR file"
X.SX "ref \fIfunction\fR"
X.FL "\fR(none)"
X.EY "ref func" "Find \fIfunc\fR"
X.PP
X\fIRef\fR looks up a function name in the \fIrefs\fR file in the current
Xdirectory.
XThis file is usually made by \fIctags\fR.
X
X
X
X.SP 1.6
/
echo x - rev
sed '/^X/s///' > rev << '/'
X.CD "rev \(en reverse the characters on each line of a file"
X.SX "rev\fR [\fIfile\fR] ..."
X.FL "\fR(none)"
X.EY "rev file" "Reverse each line"
X.PP
XEach file is copied to standard output with all the characters of each line
Xreversed, last one first and first one last.
X
X
X
X.SP 1.6
/
echo x - rm
sed '/^X/s///' > rm << '/'
X############ NEXT ENTRY HAS NOT BEEN CHECKED #############
X.CD "rm \(en remove a file"
X.SX "rm\fR [\fB\(enRf\&ir\fR] \fIname\fR ..."
X.FL "\(enf" "Forced remove: no questions asked"
X.FL "\(eni" "Interactive remove: ask before removing"
X.FL "\(enR" "Remove directories too"
X.FL "\(enr" "Same as \fB\(enR\fR"
X.EX "rm file" "Remove \fIfile\fR"
X.EX "rm \(eni *.c" "Remove \fI.c\fP files, asking about each"
X.PP
X.I Rm
Xremoves one or more files.
XIf a file has no write permission,
X.I rm
Xasks for permission (type \*(OQy\*(CQ or \*(OQn\*(CQ) unless \fB\(enf\fR
Xis specified.
XIf the file is a directory, it will be recursively descended and removed
Xif and only if the \fB\(enR\fR flag is present.
X
X
X
/
echo x - rmaker
sed '/^X/s///' > rmaker << '/'
X.CD "rmaker \(en a simple resource compiler [MACINTOSH]"
X.SX "rmaker \fIinputfile\fR \fIoutputfile\fR"
X.FL "\fR(none)"
X.EX "rmaker boot.r vol:dir:f" "Compile the resource described in \fIboot.r\fB
X.PP
XRmaker will produce a Macintosh resource file from a resource input
Xspecification. This is not a complete implementation of a resource
Xcompiler, and it only understands a relatively small number of resource
Xformats. The input syntax is similar to that of the well-known rmaker
Xapplication. 
X.PP
XThis is a partial list of the resource types it understands:
X.HS
X.ta 0.25i 1i
X.nf
X	'\fBSTR \fR'	Strings
X	'\fBBNDL\fR'	Bundles
X	'\fBFREF\fR'	File refs (for bundles)
X	'\fBHEXA\fR'	Hex data
X	'\fBCODE\fR'	Code
X	'\fBALRT\fR'	Alerts
X	'\fBDITL\fR'	Dialog item lists
X	'\fBDLOG\fR'	Dialogs
X	'\fBWIND\fR'	Window templates
X	'\fBMENU\fR'	Menus
X	'\fBICON\fR'	ICON
X	'\fBICN#\fR'	ICON lists
X	'\fBCURS\fR'	Cursors
X	'\fBPAT \fR'	Patterns
X.fi
X
X
X
/
echo x - rmdir
sed '/^X/s///' > rmdir << '/'
X.CD "rmdir \(en remove a directory"
X.SX "rmdir \fIdirectory ...
X.FL "\fR(none)"
X.EX "rmdir /user/ast/foobar" "Remove directory \fIfoobar\fP"
X.EX "rmdir /user/ast/f*" "Remove 0 or more directories"
X.PP
XThe specified directories are removed.
XOrdinary files are not removed.
XThe directories must be empty.
X
X
X
/
echo x - roff
sed '/^X/s///' > roff << '/'
X.CD "roff \(en text formatter"
X.SX "roff\fR [\fB\(enhs\fR]\fR [\fB+\fIn\fR] [\fB\(en\fIn\fR] \fIfile\fR ..."
X.FL "\(enh" "Expand tabs to spaces in output"
X.FL "\(ens" "Stop before each page; continue on DEL"
X.FL "+\fIn\fP" "Start printing with page \fIn\fP"
X.FL "\(en\fIn\fP" "Stop after page \fIn\fP"
X.EX "roff file" "Run off \fIfile\fP"
X.EX "roff +5 file" "Run off \fIfile\fP starting at page 5"
X.PP
X.I Roff
Xis a text formatter.
XIts input consists of the text to be output, intermixed with formatting commands.
XA formatting command is a line containing the control character followed by
Xa two character command name, and possibly one or more arguments.
XThe control character is initially \*(OQ.\*(CQ (dot).
XThe formatted output is produced on standard output.
X.PP
XThe formatting commands are listed below, with
X.I n
Xbeing a number,
X.I c
Xbeing a character, and
X.I t
Xbeing a title.
XA + before \fIn\fP means it may be signed, indicating a positive or negative
Xchange from the current value.
XInitial values for
X.I n ,
Xwhere relevant, are given in parentheses.
X.HS
X.ta 0.25i 1i
X.nf
X	\fB.ad\fP	Adjust right margin.
X	\fB.ar\fP	Arabic page numbers.
X	\fB.br\fP	Line break.  Subsequent text will begin on a new line.
X	\fB.bl\fP n	Insert \fIn\fP blank lines.
X	\fB.bp\fP +n	Begin new page and number it \fIn\fP. No \fIn\fP means +1.
X	\fB.cc\fP c	Control character is set to \fIc\fP.
X	\fB.ce\fP n	Center the next \fIn\fP input lines.
X	\fB.de\fP zz	Define a macro called \fIzz\fP. A line with \*(OQ..\*(CQ ends definition.
X	\fB.ds\fP	Double space the output. Same as \fB.ls 2\fP.
X	\fB.ef\fP t	Even page footer title is set to \fIt\fP.
X	\fB.eh\fP t	Even page header title is set to \fIt\fP.
X	\fB.fi\fP	Begin filling output lines as full as possible.
X	\fB.fo\fP t	Footer titles (even and odd) are set to \fIt\fP.
X	\fB.hc\fP c	The character \fIc\fP (e.g., %) tells \fIroff\fP where hyphens are permitted.
X	\fB.he\fP t	Header titles (even and odd) are set to \fIt\fP.
X	\fB.hx\fP	Header titles are suppressed.
X	\fB.hy\fP n	Hyphenation is done if \fIn\fP is 1, suppressed if it is 0. Default is 1.
X	\fB.ig\fP	Ignore input lines until a line beginning with \*(OQ..\*(CQ is found.
X	\fB.in\fP n	Indent \fIn\fP spaces from the left margin; force line break.
X	\fB.ix\fP n	Same as \fI.in\fP but continue filling output on current line.
X	\fB.li\fP n	Literal text on next \fIn\fP lines.  Copy to output unmodified.
X	\fB.ll\fP +n	Line length (including indent) is set to \fIn\fP (65).
X	\fB.ls\fP +n	Line spacing: \fIn\fP (1) is 1 for single spacing, 2 for double, etc.
X	\fB.m1\fP n	Insert \fIn\fP (2) blank lines between top of page and header.
X	\fB.m2\fP n	Insert \fIn\fP (2) blank lines between header and start of text.
X	\fB.m3\fP n	Insert \fIn\fP (1) blank lines between end of text and footer.
X	\fB.m4\fP n	Insert \fIn\fP (3) blank lines between footer and end of page.
X	\fB.na\fP	No adjustment of the right margin.
X	\fB.ne\fP n	Need \fIn\fP lines.  If fewer are left, go to next page.
X	\fB.nn\fP +n	The next \fIn\fP output lines are not numbered.
X	\fB.n1\fP	Number output lines in left margin starting at 1.
X	\fB.n2\fP n	Number output lines starting at \fIn\fP.  If 0, stop numbering.
X	\fB.ni\fP +n	Indent line numbers by \fIn\fP (0) spaces.
X	\fB.nf\fP	No more filling of lines.
X	\fB.nx\fP f	Switch input to file \fIf\fP.
X	\fB.of\fP t	Odd page footer title is set to \fIt\fP.
X	\fB.oh\fP t	Odd page header title is set to \fIt\fP.
X	\fB.pa\fP +n	Page adjust by \fIn\fP (1).  Same as .bp
X	\fB.pl\fP +n	Paper length is \fIn\fP (66) lines.
X	\fB.po\fP +n	Page offset.  Each line is started with \fIn\fP (0) spaces.
X	\fB.ro\fP	Page numbers are printed in Roman numerals.
X	\fB.sk\fP n	Skip \fIn\fP pages (i.e., make them blank), starting with next one.
X	\fB.sp\fP n	Insert \fIn\fP blank lines, except at top of page.
X	\fB.ss\fP	Single spacing.  Equivalent to .ls 1.
X	\fB.ta\fP	Set tab stops, e.g., .ta 9 17 25 33 41 49 57 65 73 (default).
X	\fB.tc\fP c	Tabs are expanded into \fIc\fP.  Default is space.
X	\fB.ti\fP n	Indent next line \fIn\fP spaces; then go back to previous indent.
X	\fB.tr\fP ab	Translate \fIa\fP into \fIb\fP on output.
X	\fB.ul\fP n	Underline the letters and numbers in the next \fIn\fP lines.
X.fi
X
X
X
/
echo x - rsh
sed '/^X/s///' > rsh << '/'
X.CD "rsh \(en remote shell for networking [IBM]"
X.SX "rsh [\fB\(enbei\fR] \fIport\fR"
X.FL "\(enb" "Start the rsh in the background"
X.FL "\(ene" "Keep \fIstderr\fR separate from \fIstdout\fR"
X.FL "\(eni" "Take input from the local process"
X.EX "rsh machine5 "ls \(enl /usr/bin"" "List remote \fIbin\fR directory"
X.EX "rsh abc cat /usr/doc/f >f" "Fetch remote file"
X.EX "rsh foobar" "Log onto remote machine"
X.PP
XThe remote shell command is the way to have a distant server carry out
Xa command over the Ethernet.  The port given as the first argument can be
Xany string of up to 6 characters, but it must match the port used by some
Xsherver.  The command will be executed and the results returned on \fIstdout\fR.
XUnless the \fB\(ene\fR flag is given, the remote 
X\fIstderr\fR and \fIstdout\fR are merged onto the
Xlocal \fIstdout\fR.  Giving 
X\fIrsh\fR with just a port and no argument is the standard way
Xto log onto a remote machine.
X
X
X
/
echo x - rz
sed '/^X/s///' > rz << '/'
X.CD "rz \(en receive a file using the zmodem protocol"
X.SX "rz\fR [\(en\fBabepqvy\fR]\fR [\fB\(ent \fItimeout\fR]
X.FL "\(ena" "CP/M to UNIX conventions"
X.FL "\(enb" "Binary file"
X.FL "\(ene" "Escape for all control characters"
X.FL "\(enp" "Protect file if it already exists"
X.FL "\(enq" "Quiet; opposite of verbose"
X.FL "\(ent" "Set \fItimeout\fR in tenths of a second"
X.FL "\(env" "Verbose; opposite of quiet"
X.FL "\(eny" "Yes, clobber existing files"
X.EX "rz </dev/tty1 >/dev/tty1" "Receive a file"
X.PP
X\fIRz\fR is a program that accepts a file sent from another computer using the
Xzmodem protocol.
XIt is a highly complex program.
XSee Chap 9 for more details.
X
X
X
X.SP 1
/
echo x - sed
sed '/^X/s///' > sed << '/'
X.CD "sed \(en stream editor"
X.SX "sed\fR [\fB\(enegn\fR]\fR [\fB\(enf \fIscript_file\fR]\fR [\fIedit_script\fR] [\fIfile\fR]"
X.FL "\(ene" "Accept multiple commands commands on the commands line"
X.FL "\(enf" "The following argument contains the edit script"
X.FL "\(eng" "Set the global flag on all substitute commands"
X.FL "\(enn" "Only output selected lines"
X.EX "sed \(enf script <file" "Run a sed script on \fIfile\fR"
X.EX "sed \(fm/pig/s//hog/g\(fm <file" "Replace \fIpig\fR by \fIhog\fR in the file"
X.PP
X\fISed\fR is a stream editor.
XIt takes an edit script either from its argument or a file, and performs
Xan edit session on a named file or \fIstdin\fR, producing output 
Xon \fIstdout\fR.
X
X
X
X.SP 1
/
echo x - settype
sed '/^X/s///' > settype << '/'
X.CD "settype \(en set type and/or creator of a Mac file [MACINTOSH]"
X.SX "settype \fR [\fB\(enc \fRcreator] [\fB\(ent \fRtype] \fIfile\fR"
X.FL "\(enc" "Set the creator flag"
X.FL "\(ent" "Set the type flag"
X.EX "settype vol:dir:f" "Show the type and creator flags of file \fIf\fR"
X.EX "settype -t TEXT vol:f" "Set the type of the file \fIf\fR to TEXT"
X.PP
X.I Settype
Xwill report or set the creator and/or type of the specified Macintosh file.
X
X
X
X.SP 2
/
echo x - sh
sed '/^X/s///' > sh << '/'
X.CD "sh \(en shell"
X.SX "sh\fR [\fIfile\fR]"
X.FL "\fR(none)"
X.EY "sh < script" "Run a shell script"
X.PP
X.I Sh
Xis the shell.
XIt permits redirection of input and output, pipes, magic characters, 
Xbackground processes, shell scripts and most of the other features of 
Xthe V7 (Bourne) shell.
XA few of the more common commands are listed below:
X.nf
X.ta 2i 2.5i 3i 
X.HS
X.in +0.25i
Xdate	# Regular command
Xsort <file	# Redirect \fIstdin\fR
Xsort <file1  >file2	# Redirect \fIstdin\fR and \fIstdout\fR
Xcc file.c  2>error	# Redirect \fIstderr\fR
Xa.out >f  2>&1	# Combine standard output and standard error
Xsort <file1  >>file2	# Append output to \fIfile2\fR
Xsort <file1  >file2 &	# Background job
X(ls \(enl; a.out) &	# Run two background commands sequentially
Xsort <file | wc	# Two-process pipeline
Xsort <f | uniq | wc	# Three-process pipeline
Xls \(enl *.c	# List all files ending in \fI.c\fR
Xls \(enl [\fIa-c\fR]*	# List all files beginning with \fIa\fR, \fIb\fR, or \fIc\fR
Xls \(enl ?	# List all one-character file names
Xls \\?	# List the file whose name is question mark
Xls \(fm???\(fm	# List the file whose name is three question marks
Xv=/usr/ast	# Set shell variable \fIv\fR
Xls \(enl $v	# Use shell variable \fIv\fR
XPS1=\(fmHi! \(fm	# Change the primary prompt to \fIHi!\fR
XPS2=\(fmMore: \(fm	# Change the secondary prompt to \fIMore:\fR 
Xls \(enl $HOME	# List the home directory
Xecho $PATH	# Echo the search path
Xif ... then ... else ... fi	# If statement
Xfor ... do ... done	# Iterate over argument list
Xwhile ... do ... done	# Repeat while condition holds
Xcase ... in ...  esac	# Select clause based on condition
Xecho $?	# Echo exit status of previous command
Xecho $$	# Echo shell's pid
Xecho $#	# Echo number of parameters (shell script)
Xecho $2	# Echo second parameter (shell script)
Xecho $*	# Echo all parameters (shell script)
X.in -0.25i
X.fi
X
X
X
/
echo x - shar
sed '/^X/s///' > shar << '/'
X.CD "shar \(en shell archiver"
X.SX "shar \fIfile ..."
X.FL "\fR(none)"
X.EX "shar *.c >s" "Collect C programs in shell archive"
X.EX "sh <s" "Extract files from a shell archive"
X.PP
XThe named files are collected together into a shell archive written onto
Xstandard output.
XThe individual files can be extracted by redirecting the shell archive into
Xthe shell.
XThe advantage of
X.I shar
Xover
X.I ar
Xis that \fIshar\fP archives can be read on almost any 
X.UX
Xsystem, whereas numerous, incompatible versions of
X.I ar
Xare in widespread use.
XExtracting the files from a shell archive requires that 
X.I sed
Xbe accessible.
X
X
X
/
echo x - sherver
sed '/^X/s///' > sherver << '/'
X.CD "sherver \(en shell server [IBM]"
X.SX "sherver \fIport"
X.FL "\fR(none)"
X.EY "sherver machine1" "Start a sherver listening to \fIport\fR"
X.PP
XThe \fIrsh\fR command does its remote execution by doing a remote 
Xprocedure call to some sherver.  
XThe sherver executes the command and then exits.  Usually a
Xmaster will be running to make a new one.  Because shervers get their input 
Xfrom a pipe, remote execution cannot handle signals and CTRL-D, because they
Xcannot be sent down a pipe.
X
X
X
/
echo x - size
sed '/^X/s///' > size << '/'
X.CD "size \(en print text, data, and bss size of a program"
X.SX "size\fR [\fIfile\fR] ..."
X.FL "\fR(none)"
X.EY "size file" "Print the size of \fIfile\fP"
X.PP
XThe text, data, bss, and total sizes for each argument are printed.
XIf no arguments are present, 
X.I a.out
Xis assumed.
XThe amount of memory available for combined stack and data segment growth
Xis printed in the column \*(OQstack.\*(CQ
XThis is the value manipulated by the 
X.I chmem
Xcommand.
XThe total amount of memory allocated to the program when it is loaded is
Xlisted under \*(OQmemory.\*(CQ
XThis value is just the sum of the other four columns.
X
X
X
/
echo x - sleep
sed '/^X/s///' > sleep << '/'
X.CD "sleep \(en suspend execution for a given number of seconds"
X.SX "sleep \fIseconds"
X.FL "\fR(none)"
X.EY "sleep 10" "Suspend execution for 10 sec."
X.PP
XThe caller is suspended for the indicated number of seconds.
XThis command is typically used in shell scripts.
X
X
X
/
echo x - sort
sed '/^X/s///' > sort << '/'
X.CD "sort \(en sort a file of ASCII lines"
X.SX "sort\fR [\fB\(enbcdf\&imnru\fR]\fR [\fB\(ent\fIc\fR]  [\fB\(eno \fIname\fR] [\fB+\fIpos1\fR] [\fB\(en\fIpos2\fR] \fIfile\fR ..."
X.FL "\(enb" "Skip leading blanks when making comparisons"
X.FL "\(enc" "Check to see if a file is sorted"
X.FL "\(end" "Dictionary order: ignore punctuation"
X.FL "\(enf" "Fold upper case onto lower case"
X.FL "\(eni" "Ignore nonASCII characters"
X.FL "\(enm" "Merge presorted files"
X.FL "\(enn" "Numeric sort order"
X.FL "\(eno" "Next argument is output file"
X.FL "\(enr" "Reverse the sort order"
X.FL "\(ent" "Following character is field separator"
X.FL "\(enu" "Unique mode (delete duplicate lines)"
X.EX "sort \(ennr file" "Sort keys numerically, reversed"
X.EX "sort +2 \(en4 file" "Sort using fields 2 and 3 as key"
X.EX "sort +2 \(ent: \(eno out" "Field separator is \fI:\fP"
X.EX "sort +.3 \(en.6" "Characters 3 through 5 form the key"
X.PP
X.I Sort
Xsorts one or more files.
XIf no files are specified, \fIstdin\fR is sorted.
XOutput is written on standard output, unless \fB\(eno\fP is specified.
XThe options \fB+\fIpos1 \fB\(en\fIpos2\fR use only fields \fIpos1\fR
Xup to but not including \fIpos2\fR as the sort key, where a field is a
Xstring of characters delimited by spaces and tabs, unless a different field
Xdelimiter is specified with \fB\(ent\fR.
XBoth \fIpos1\fR and \fIpos2\fR have the form \fIm.n\fR where \fIm\fR tells
Xthe number of fields and \fIn\fR tells the number of characters.
XEither \fIm\fR or \fIn\fR may be omitted.
X
X
X
/
echo x - spell
sed '/^X/s///' > spell << '/'
X.CD "spell \(en print all words in a file not present in the dictionary"
X.SX "spell \fIfile"
X.FL "\fR(none)"
X.EY "spell document" "Print the spelling errors on \fIstdout\fR"
X.PP
X\fISpell\fR is the 
X.MX
Xspelling checker.  
XIt is actually a short shell script.
XFirst, the program \fIprep\fR strips off the \fIroff\fR, 
X\fInroff\fR, and \fItroff\fR control lines,
Xand the punctuation, and lists each word on a separate line.  These words are
Xthen sorted.  The resulting output is then compared to the dictionary.  Words
Xpresent in the file but not present in the dictionary are listed.  The
Xdictionary must be located in \fI/usr/lib/dictionary\fR.
X
X
X
/
echo x - split
sed '/^X/s///' > split << '/'
X.CD "split \(en split a large file into several smaller files"
X.SX "split\fR [\fB\(en\fIn\fR]\fR [\fIfile \fR[\fIprefix\fR]\fR]"
X.FL "\(en\fIn\fP" "Number of lines per piece (default: 1000)"
X.EX "split \(en200 file" "Split \fIfile\fP into pieces of 200 lines each"
X.EX "split file z" "Split \fIfile\fP into \fIzaa\fP, \fIzab\fP, etc."
X.PP
X.I Split 
Xreads \fIfile\fP and writes it out in \fIn\fP-line pieces.
XBy default, the pieces are called \fIxaa\fP, \fIxab\fP, etc.
XThe optional second argument can be used to provide an alternative
Xprefix for the output file names.
X
X
X
/
echo x - strings
sed '/^X/s///' > strings << '/'
X.CD "strings \(en print all the strings in a binary file"
X.SX "strings\fR [\fB\(en\fR] [\fB\(eno\fR]\fR [\fB\(en\fIn\fR] \fIfile ..."
X.FL "\(en" "search whole file, not just data seg"
X.FL "\(eno" "Print octal offset of each string"
X.FL "\(en\fIn" "\fIn\fR is minimum length string (default = 4)"
X.EX "strings \(en5 a.out" "Print the strings > 4 chars in \fIa.out\fR"
X.EX "strings \(en /bin/sh" "Search entire shell file (text and data)"
X.PP
X\fIStrings\fR looks for sequences of ASCII characters followed by a zero 
Xbyte.
XThese are usually strings.  This program is typically used to help identify
Xunknown binary programs
X
X
X
X.SP 1.5
/
echo x - strip
sed '/^X/s///' > strip << '/'
X.CD "strip \(en remove symbol table from executable file"
X.SX "strip\fR [\fIfile\fR] ..."
X.FL "\fR(none)"
X.EY "strip a.out" "Remove symbols from \fIa.out\fR"
X.PP
XFor each file argument, \fIstrip\fR removes the symbol table.  
XStrip makes a copy of the file being stripped, so links are lost.
X
X
X
X.SP 1.5
/
echo x - stterm
sed '/^X/s///' > stterm << '/'
X.CD "stterm \(en turn system into a dumb terminal [68000]"
X.SX "stterm \fR[\fB\(ens \fIspeed\fR] [\fB\(enl \fIline\fR] [\fB\(ene \fIescapechar\fR]"
X.FL "\(ens" "Specify speed (default is 9600 baud)"
X.FL "\(enl" "Specify line (default is /dev/tty1)"
X.FL "\(ene" "Redefine escape character (default is tilde)"
X.EY "stterm \(ens 1200" "Talk to /dev/tty1 at 1200 baud"
X.PP
X.I Stterm
Xallows
X.MX
Xto talk to a terminal or modem over an RS232 line.
XIt starts two other programs, a reader and a writer.
XThe reader monitors the RS232 line and copies all characters to the
Xscreen, while the writer monitors the keyboard and copies all
Xcharacters to the RS232 line.
X.PP
XSince all characters are transferred to the RS232 line, a special
Xescape character is present to control the behaviour of
X.I stterm
Xitself.
XBy default the escape character is the \(ap character, but it can be
Xredefined using the \fB\(ene\fR flag.
XIf the escape character is followed by a period or a CTRL-D
Xcharacter, the program terminates. 
XIf the escape character is followed by an ! (exclamation mark)
Xa subshell is started. 
XTo transmit the escape character, enter it twice. 
XAn escape character followed by something other than CTRL-D, period,
Xexclamation mark, or another escape character is invalid and generates
Xan error message.
X
X
X
/
echo x - stty
sed '/^X/s///' > stty << '/'
X.CD "stty \(en set terminal parameters"
X.SX "stty\fR [\fIoption ...\fR]
X.FL "\fR(none)"
X.EX "stty \(enecho" "Suppress echoing of input"
X.EX "stty erase #" "Set the erase character to \fI#\fP"
X.PP
XWhen given no arguments,
X.I stty
Xprints the current terminal parameters.
XIt can also be used to set the parameters, as follows:
X.ta 0.25i 1i
X.HS
X	\fBcbreak\fP	\(en Enter \fIcbreak\fP mode; erase and kill disabled
X.br
X	\fBecho\fP	\(en Echo input on the terminal
X.br
X	\fBnl\fP	\(en Accept only line feed to end lines
X.br
X	\fBraw\fP	\(en Enter \fIraw\fP mode; no input processing at all
X.br
X	\fBtabs\fP	\(en Output tabs (do not expand to spaces)
X.br
X	\fBerase\fR c	\(en Set erase character (initially backspace)
X.br
X	\fBint\fR c	\(en Set interrupt (SIGINT) character (initially DEL)
X.br
X	\fBkill\fR c	\(en Set kill line character (initially @)
X.br
X	\fBquit\fR c	\(en Set quit (SIGQUIT) character (initially CTRL-\\)
X.br
X	\fBeven\fR	\(en Use even parity
X.br
X	\fBodd\fR	\(en Use odd parity
X.br
X	\fB[5-8]\fR	\(en Number of bits per character
X.br
X	\fB[110-9600]\fR	\(en Baud rate
X.br
X	\fBdefault\fR	\(en Set options back to original values
X.HS
XThe first five options may be prefixed by \fB\(en\fP as in \fB\(entabs\fP
Xto turn the option off.
XThe next four options each have a single character parameter separated by a
Xspace from the option.
XThe \fBdefault\fR option sets the mode and the four settable characters back
Xto the values they had when the system was booted.
XIt is useful when a rogue program has messed them up.
X
X
X
X.SP 2.0
/
echo x - su
sed '/^X/s///' > su << '/'
X.CD "su \(en temporarily log in as superuser or another user"
X.SX "su\fR [\fIname\fR]"
X.FL "\fR(none)"
X.EX "su~~~~" "Become superuser"
X.EX "su ast" "Become \fIast\fR"
X.PP
X.I Su
Xcan be used to temporarily login as another user.
XIt prompts for the superuser password.
XIf the correct password is entered,
X.I su
Xcreates a shell with the desired uid.
XIf no name is specified, \fIroot\fR is assumed.
XTo exit the temporary shell, type CTRL-D.
XWhen memory is tight, it is better to become superuser by logging out and
Xthen logging in again as \fIroot\fR, rather than using \fIsu\fR since the
Xlatter creates an extra shell in memory.
X
X
/
echo x - sum
sed '/^X/s///' > sum << '/'
X.CD "sum \(en compute the checksum and block count of a file"
X.SX "sum \fIfile"
X.FL "\fR(none)"
X.EX "sum /user/ast/xyz" "Checksum \fI/user/ast/xyz"
X.PP
X.I Sum
Xcomputes the checksum of one or more files.
XIt is most often used to see if a file copied from another machine has
Xbeen correctly received.
XThis program works best when both machines use the same checksum algorithm.
XSee also \fIcrc\fR.
X
X
X
X.SP 2
/
echo x - svc
sed '/^X/s///' > svc << '/'
X.CD "svc \(en shell version control system"
X.SX "ci\fR [\fB\(enlu\fR]\fR \fIfile"
X.SX "co\fR [\fB\(enl\fR]\fR [\fB\(enr \fIrev\fR] \fIfile"
X.SX "svc \fIfile"
X.FL "\(enl" "For \fIci\fR, checkin, checkout again, and lock file"
X.FL "\(enl" "For \fIco\fR, checkout file and then lock the archive"
X.FL "\(enu" "After checking in, do not delete the file"
X.FL "\(enr" "Check out revision \fIrev\fR instead most recent revision
X.EX "ci \(enu file" "Check in \fIfile\fR"
X.EX "co \(enl file" "Check out \fIfile\fR and lock archive"
X.EX "co \(enr 2 file" "Check out version 2"
X.PP
X\fISvc\fR is the Shell Version Control system, patterned on RCS.
XIt maintains a sequence of versions in archive files, so that new versions
Xcan be checked in (added to the archive), and old versions can be checked
Xout (made available).
XTo create an archive for \fIfile\fR, check it in with the \fB\(enu\fR flag.
XThis action will prompt for a log message and then create an archive called
X\fIfile,S\fR in the current directory, or in the subdirectory \fISVC\fR if 
Xit exists.  
XThe file will not be deleted, but will be made unwritable.
X.PP
XTo update the file, check it out with the \fB\(enl\fR flag.
XThen modify it, and check it back in, giving a new message when prompted.
XAfter this process has been repeated many times, the archive will contain
Xthe entire history.
XAny version can be checked out using the \fB\(enr\fR flag.
XTo get a printout of the history, use \fIsvclog\fR.
X
X
X
/
echo x - sync
sed '/^X/s///' > sync << '/'
X.CD "sync \(en flush the cache to disk"
X.SX "sync"
X.FL "\fR(none)"
X.EY "sync" "Write out all modified cache blocks"
X.PP
X.MX
Xmaintains a cache of recently used disk blocks.
XThe 
X.I sync
Xcommand writes any modified cache blocks back to the disk.
XThis is essential before stopping the system, and should be done before
Xrunning any
X.I a.out
Xprogram that might crash.
X
X
X
/
echo x - sz
sed '/^X/s///' > sz << '/'
X.CD "sz \(en send a file using the zmodem protocol"
X.SX "sz\fR [\fB\(enLNbdefnopqruvy+\fR]\fR [\fB\(enci \fIcommand\fR] [\fB\(enLl\fR n\fR] [\fB\(ent \fItimeout\fR]
X.FL "\(enL" "Use \fIn\fR-byte packets"
X.FL "\(enN" "Overwrite if source is newer/longer"
X.FL "\(enb" "Binary file"
X.FL "\(enc" "Send command for execution"
X.FL "\(end" "Convert dot to slash in names"
X.FL "\(ene" "Escape for all control characters"
X.FL "\(enf" "Send full path name"
X.FL "\(eni" "Send command and return immediately"
X.FL "\(enl" "Flow control every \fIn\fR packets"
X.FL "\(enn" "Overwrite destination if source is newer"
X.FL "\(eno" "Use old (16-bit) checksum"
X.FL "\(enp" "Protect file if it already exists"
X.FL "\(enq" "Quiet; opposite of verbose"
X.FL "\(enr" "Resume interrupt file transfer"
X.FL "\(ent" "Set \fItimeout\fR in tenths of a second"
X.FL "\(enu" "Unlink file after successful transmission"
X.FL "\(env" "Verbose; opposite of quiet"
X.FL "\(eny" "Yes, clobber existing files"
X.FL "\(en+" "Append to an existing file"
X.EY "sz file </dev/tty1 >/dev/tty1" "Send \fIfile\fR"
X.PP
XXMODEM, YMODEM, and ZMODEM are a family of protocols that are widely used
Xis the \s-2MS-DOS\s0 world for transferring information reliably from one
Xcomputer to another.  In all of these protocols, a series of bytes are sent
Xfrom one computer to the other, and then an acknowledgement is sent back
Xto confirm correct reception.  Checksums are used to detect errors so that
Xtransmission is reliable even in the face of noisy telephone lines.
X\fISz\fR is a program that sends a file sent from another computer using the
Xzmodem protocol.
XThe file can be received using \fIrz\fR.
XBoth are a highly complex programs.
XSee Chap. 9 for more information.
XFor an alternative, see \fIkermit\fR.
X
X
X
/
echo x - tail
sed '/^X/s///' > tail << '/'
X.CD "tail \(en print the last few lines of a file"
X.SX "tail\fR [\fB\(enc \fIn\fR] [\fB\(enf] [\fB\(enn \fIn\fR] [\fIfile\fR] ..."
X.FL "\(enc" "The count refers to characters"
X.FL "\(enf" "On FIFO or special file, keep reading after EOF"
X.FL "\(enn" "The count refers to lines"
X.EX "tail \(enn 6" "Print last 6 lines of \fIstdin\fR"
X.EX "tail \(enc 20 file" "Print the last 20 characters of \fIfile\fR"
X.EX "tail \(enn 1 file1 file2" "Print last line of two files"
X.EX "tail \(enn +8 file" "Print the tail starting with line 8"
X.PP
XThe last few lines of one or more files are printed.
XThe default count is 10 lines.
XThe default file is \fIstdin\fR.
XIf the value of \fIn\fR for the \fB\(enc\fR or \fB\(enn\fR flags starts with
Xa + sign, counting starts at the beginning, rather than the end of the file.
X
X
X
/
echo x - tar
sed '/^X/s///' > tar << '/'
X.CD "tar \(en tape archiver"
X.SX "tar\fR [\fBFcotvx\fR]\fR [\fBf\fR] \fItarfile \fIfile ...
X.FL "F" "Force tar to continue after an error"
X.FL "c" "Create a new archive; add named files"
X.FL "o" "Set uid/gid to original values on extraction"
X.FL "f" "Next argument is name of tarfile"
X.FL "t" "Print a table listing the archive's contents"
X.FL "v" "Verbose mode-tell what is going on as it happens"
X.FL "x" "The named files are extracted from the archive"
X.EX "tar c /dev/fd1 ." "Back up current directory to \fI/dev/fd1\fR"
X.EX "tar xv /dev/fd1 file1 file2" "Extract two files from the archive"
X.EX "tar cf \(en | (cd dest; tar xf \(en)" "Copy current directory to \fIdest\fR"
X.PP
X\fITar\fR is a POSIX-compatible archiver, except that it does not use tape.
XIt's primary advantage over
X.I ar
Xis that the 
X.I tar
Xformat is somewhat more standardized than the
X.I ar 
Xformat, making it theoretically possible to transport 
X.MX
Xfiles to another computer, but do not bet on it.
XIf the target machine runs
X.SY MS-DOS ,
Xtry
X.I doswrite .
X
X
X
/
echo x - tee
sed '/^X/s///' > tee << '/'
X.CD "tee \(en divert \fIstdin\fP to a file"
X.SX "tee\fR [\fB\(enai\fR] \fIfile\fR ..."
X.FL "\(ena" "Append to the files, rather than overwriting"
X.FL "\(eni" "Ignore interrupts"
X.EX "cat file1 file2 | tee x" "Save and display two files"
X.EX "pr file | tee x | lpr" "Save the output of \fIpr\fP on \fIx\fP"
X.PP
X.I Tee
Xcopies \fIstdin\fR to standard output.
XIt also makes copies on all the files listed as arguments.
X
X
X
/
echo x - term
sed '/^X/s///' > term << '/'
X.CD "term \(en turn PC into a dumb terminal [IBM]"
X.SX "term\fR [\fIbaudrate\fR]\fR [\fIparity\fR] [\fIbits_per_character\fR]"
X.FL "\fR(none)"
X.EX "term 2400" "Talk to modem at 2400 baud"
X.EX "term 1200 7 even" "1200 baud, 7 bits/char, even parity"
X.EX "term 8 9600" "9600 baud, 8 bits/char, no parity"
X.PP
X\fITerm\fR allows 
X.MX
Xto talk to a terminal or modem over RS232 
Xport 1.  The program first sets the baudrate, parity and character length, 
Xand then forks.
XThe parent sits in a loop copying from \fIstdin\fR (usually the console's
Xkeyboard), to the terminal or modem (\fI/dev/tty1\fR).  
XThe child sits in a loop
Xcopying from the terminal or modem (\fI/dev/tty1\fR) to standard output.  
XThus when
XRS232 port 1 is connected to a modem, every keystroke typed on the keyboard
Xis sent to the modem, and every character arriving from the modem is displayed.
XStandard input and output may be redirected, to provide a primitive file
Xtransfer program, with no checking.  To exit \fIterm\fR, 
Xhit the middle button on the numeric pad.
XImportant note: to use \fIterm\fR, it is essential that 
X\fI/etc/ttys\fR is configured so
Xthat there is no shell hanging on \fI/dev/tty1\fR.  
XIf there is, both the shell and
Xterm will try to read from \fI/dev/tty1\fR, and nothing will work.
X
X
X
X.SP 0.5
/
echo x - termcap
sed '/^X/s///' > termcap << '/'
X.CD "termcap \(en print the current termcap entry"
X.SX "termcap\fR [\fItype\fR]"
X.FL "\fR(none)"
X.EY "termcap" "Print the termcap entry"
X.PP
X\fITermcap\fR reads the /etc/termcap entry corresponding to the 
Xterminal type
Xsupplied as the argument.  If none is given, the current $TERM is used.
XIt then prints out all the parameters that apply.
X
X
X
X.SP 0.5
/
echo x - test
sed '/^X/s///' > test << '/'
X.CD "test \(en test for a condition"
X.SX "test \fIexpr"
X.FL "\fR(none)"
X.EY "test \(enr file" "See if file is readable"
X.PP
X\fITest\fR checks to see if files exist, are readable, etc. and returns
Xan exit status of zero if true and nonzero if false.  The legal operators are
X.sp
X.nf
X.ta 0.5i 1.5i
X	\(enr file	true if the file is readable
X	\(enw file	true if the file is writable
X	\(enx file	true if the file is executable
X	\(enf file	true if the file is not a directory
X	\(end file	true if the file is a directory
X	\(ens file	true if the file exists and has a size > 0
X	\(ent fd	true if file descriptor fd (default 1) is a terminal
X	\(enz s	true if the string s has zero length
X	\(enn s	true if the string s has nonzero length
X	s1 = s2	true if the strings s1 and s2 are identical
X	s1 != s2	true if the strings s1 and s2 are different
X	m \(eneq m	true if the integers m and n are numerically equal
X.fi
X
XThe operators \fB\(engt\fR, \fB\(enge\fR, \fB\(enne\fR, \fB\(enle\fR, and
X\fB\(enlt\fR may be used as well.
XThese operands may be combined with \fB\(ena\fR (Boolean and), 
X\fB\(eno\fR (Boolean or), !
X(negation).  
XThe priority of \fB\(ena\fR is higher than that of \fB\(eno\fR.  
XParentheses are permitted, but must be escaped to keep the shell from trying 
Xto interpret them.
X
X
X
/
echo x - time
sed '/^X/s///' > time << '/'
X.CD "time \(en report how long a command takes"
X.SX "time \fIcommand"
X.FL "\fR(none)"
X.EX "time a.out" "Report how long \fIa.out\fR takes"
X.EX "time ls \(enl *.c" "Report how long \fIls\fR takes"
X.PP
XThe command is executed and the real time, user time, and system time (in
Xhours, minutes, and seconds) are printed.
XShell scripts cannot be timed.
X
X
X
/
echo x - to
sed '/^X/s///' > to << '/'
X.CD "to \(en output half of a connection [IBM]"
X.SX "to \fIport"
X.FL "\fR(none)"
X.EY "cat f1 f2 | to mach4" "Send the catted files to port"
X.PP
X\fITo\fR and 
X\fIfrom\fR are used together to provide connection-oriented service.
XOn the sending machine, the last member of a pipeline is \fIto port\fR.  
XOn the
Xreceiving machine, the first member of a pipe line is \fIfrom port\fR.  The net
Xresult is that the output of the sending pipeline goes into the input of the
Xreceiving pipeline, making pipelines work across the network. As a simple
Xexample, consider:
X.HS
X.nf
X	on machine1:	cat f1 f2 | to Johnny
X	on machine2:	from Johnny | sort >x
X.fi
X.HS
XThe effect of these two commands is that the files f1 and f2 are concatenated,
Xtransferred to machine 2, and sorted there, with the output going to a file 
X\fIx\fR 
Xon machine 2.  The string \fIJohnny\fR is used by 
Xthe transaction system to identify
Xwhich sender goes with which receiver; any unique string can be used.
XMultiple transfers may take place simultaneously between different pairs
Xof machines on the same Ethernet.
X
X
X
/
echo x - tos
sed '/^X/s///' > tos << '/'
X.CD "tos \(en list, read and write \s-2TOS\s0 file systems [ATARI]"
X.SX "tos \(en[Radlrw] \fIdrive\fR [\fIfile\fR]"
X.FL "\(enR" "Recursively descend directories when listing them"
X.FL "\(ena" "Read or write ASCII file"
X.FL "\(end" "Directory list"
X.FL "\(enl" "Use long format for directory listing"
X.FL "\(enr" "Read a \s-2TOS\s0 file into \s-2MINIX\s0"
X.FL "\(enw" "Write a \s-2MINIX\s0" file to \s-2TOS\s0"
X.EX "tos \(endl 1" "List root directory on /dev/fd1"
X.EX "tos \(enr hd4 g/adv >adv" "Read file \fIg/adv\fR from \fI/dev/hd4\fR"
X.EX "tos \(enwa /dev/fd0 f" "Copy ASCII \fIstdin\fR to \fIf\fR on \fI/dev/fd0\fR"
X.PP
X.I Tos
Xknows about \s-2TOS\s0 file system structures on diskettes and hard disks.
XIt can list directories and read and write files.
XSlashes should be used in file names, even though \s-2TOS\s0 uses backslashes.
XThe drive can be specified as number (in which case it is appended to 
X\fI/dev/fd\fR),
Xas absolute path name (like \fI/dev/fd0\fR), or as suffix 
Xto \fI/dev/\fR (like \fIhd4\fR).
XASCII files have the final CTRL-Z stripped, and \fITOS\fR carriage return
Xplus line feed is mapped to
X.MX
Xline feed.
X.I Tos
Xmay be linked to
X.I tosdir ,
X.I tosread
Xand
X.I toswrite ,
Xin which case the \fB\(end\fR, \fB\(enr\fR, and \fB\(enw\fR flags are not
Xneeded.
X
X
X
/
echo x - touch
sed '/^X/s///' > touch << '/'
X.CD "touch \(en update a file's time of last modification"
X.SX "touch\fR [\fB\(enc\fR] \fIfile\fR ..."
X.FL "\(enc" "Do not create the file"
X.EY "touch *.h" "Make the \fI.h\fP files look recent"
X.PP
XThe time of last modification is set to the current time.
XThis command is mostly used to trick
X.I make
Xinto thinking that a file is more recent than it really is.
XIf the file being touched does not exist, it is created, unless the \fB\(enc\fR
Xflag is present.
X
X
X
/
echo x - tr
sed '/^X/s///' > tr << '/'
X.CD "tr \(en translate character codes"
X.SX "tr\fR [\fB\(encds\fR]\fR [\fIstring1\fR] [\fIstring2\fR]"
X.FL "\(enc" "Complement the set of characters in \fIstring1\fR"
X.FL "\(end" "Delete all characters specified in \fIstring1\fR"
X.FL "\(ens" "Squeeze all runs of characters in \fIstring1\fR to one character"
X.EX "tr \(fm[a\(enz]\(fm \(fm[A\(enZ]\(fm <x >y~~~~~" "Convert upper case to lower case"
X.EX "tr \(end \(fm0123456789\(fm <f1 >f2~~" "Delete all digits from \fIf1\fR"
X.PP
X.I Tr
Xperforms simple character translation.
XWhen no flag is specified, each character in 
X.I string1
Xis mapped onto the corresponding character in
X.I string2 .
X
X
X
/
echo x - transfer
sed '/^X/s///' > transfer << '/'
X.CD "transfer \(en read, write and format diskettes [AMIGA]"
X.SX "transfer \fR[\fB\(enf\fR] [\fB\(enr\fR] [\fB\(enw \fIfile\fR]"
X.FL "\(enf" "Format a diskette (9 sectors/track)"
X.FL "\(enr" "Read a file from a special diskette on \fIstdout\fR"
X.FL "\(enw" "Write \fIfile\fR to a diskette"
X.EX "transfer \(enf" "Format a diskette (9 sectors/track)"
X.EX "transfer \(enr" "Read a file from a special diskette"
X.EX "transfer \(enw /etc/passwd" "Write /etc/passwd to a special diskette"
X.PP
X.I Transfer
Xreads and writes a file from and to a special diskette, one file per diskette.
XThis diskette can only be used to transfer files from and to AmigaDOS,
Xbecause nobody else can read it. Besides reading and writing diskettes,
Xthe AmigaDOS version of
X.I transfer
Xcan also format diskettes using the \fB\(enf\fR option. 
XIf you already have
Xan AmigaDOS program which can read and write diskettes you might
Xalso use \fItos\fR to exchange files between
X.MX
Xand AmigaDOS.
X.PP
XA typical session to copy \fIminix.img\fR from
X.MX
Xto AmigaDOS might look like this:
X.HS
X.Cx "#	transfer  \(enw  minix.img"
X.HS
X\fIMinix.img\fR will be written to diskette. When \fItransfer\fR is ready you
Xcan log out, and reboot the Amiga. Hit CTRL-D to abort the
Xstartup-sequence and type
X.HS
X.Cx "1>	cd RAM:"
X.br
X.Cx "1>	transfer  \(enr"
X.HS
Xto read \fIminix.img\fR and type
X.HS
X.Cx "1>	copy minix.img DF0:"
X.HS
Xto copy \fIminix.img\fR onto an AmigaDOS diskette.
X.PP
XImportant note: when \fItransfer\fR tells you to insert a special diskette 
Xand hit return, \fIdo not\fR do so before the drive LED has gone out, 
Xto prevent the Amiga from crashing.
X
X
X
/
echo x - traverse
sed '/^X/s///' > traverse << '/'
X.CD "traverse \(en print directory tree under the named directory"
X.SX "traverse \fIdir"
X.FL "\fR(none)"
X.EY "traverse ." "Print tree starting at working dir"
X.PP
X\fITraverse\fR prints the tree structure starting at the named directory. 
XAll the subdirectories are listed, with the depth shown by indentation.
X
X
X
X.SP 1
/
echo x - treecmp
sed '/^X/s///' > treecmp << '/'
X.CD "treecmp \(en recursively list differences in two directory trees"
X.SX "treecmp\fR [\fB\(encv\fR] \fIolddir newdir"
X.FL "\(enc" "(changes) list the names of changed or new files"
X.FL "\(env" "(verbose) list all directories processed"
X.EY "treecmp \(env /usr/ast/V1 /usr/ast/V2" "Compare two trees"
X.PP
X\fITreecmp\fR recursively descends the directory tree of its second
Xargument and compares all files to those at the corresponding position in 
Xthe first argument.  
XIf the two trees are identical, i.e., all the corresponding
Xdirectories and files are the same, there is no output.  Otherwise, a list
Xof files missing from one of the trees or present in both but whose contents
Xare not identical in both are printed.
XWhen the \fB\(enc\fR flag is given, only files that are changed from the old
Xversion or are new (i.e., absent in the old version) are listed.
X
X
X
/
echo x - true
sed '/^X/s///' > true << '/'
X.CD "true \(en exit with the value true"
X.SX "true"
X.FL "\fR(none)"
X.EY "while true" "List the directory until DEL is hit"
X.br
X	do ls \(enl
X.br
X	done
X.PP
XThis command returns the value
X.I true .
XIt is used for shell programming.
XThe program is in reality not a program at all.
XIt is the null file.
X
X
X
X.SP 1.5
/
echo x - tset
sed '/^X/s///' > tset << '/'
X.CD "tset \(en set the $TERM variable"
X.SX "tset\fR [\fIdevice\fR]"
X.FL "\fR(none)"
X.EY "eval \`tset\`" "Set TERM"
X.PP
X\fITset\fR is used almost exclusively to set the shell variable TERM from
Xinside profiles.  If an argument is supplied, that is used as the value of
XTERM.  Otherwise it looks in \fI/etc/ttytype\fR.
X
X
X
X.SP 1.5
/
echo x - tsort
sed '/^X/s///' > tsort << '/'
X.CD "tsort \(en topological sort [IBM]"
X.SX "tsort \fIfile"
X.FL "\fR(none)"
X.EX "lorder *.s | tsort" "Give library ordering"
X.EX "ar cr libc.a \`lorder *.s | tsort\`" "Build library"
X.PP
X\fITsort\fR accepts a file of lines containing ordered pairs and builds a
Xtotal ordering from the partial orderings.
X
X
X
X.SP 1.5
/
echo x - ttt
sed '/^X/s///' > ttt << '/'
X.CD "ttt \(en tic tac toe"
X.SX "ttt"
X.FL "\fR(none)"
X.EY "ttt~~~" "Start the game"
X.PP
XThis program allows the user to engage in a game of tic tac toe (noughts and
Xcrosses) with the computer.
XThe program uses the alpha-beta algorithm, so the user had better be sharp.
X
X
X
/
echo x - tty
sed '/^X/s///' > tty << '/'
X.CD "tty \(en print the device name of this tty"
X.SX "tty \fR[\fB\(ens\fR]"
X.FL "\(ens" "Silent mode, only the exit status is affected."
X.EY "tty~~~" "Print the tty name"
X.PP
XPrint the name of the controlling tty. If the flag \fB\(ens\fR is given,
X\fItty\fR is equivalent to the call to \fIisatty()\fR.
X
X
X
/
echo x - umount
sed '/^X/s///' > umount << '/'
X.CD "umount \(en unmount a mounted file system"
X.SX "/etc/umount \fIspecial"
X.FL "\fR(none)"
X.EY "/etc/umount /dev/fd1" "Unmount diskette 1"
X.PP
XA mounted file system is unmounted after the cache has been flushed to disk.
XA diskette should never be removed while it is mounted.
XIf this happens, and is discovered before another diskette is inserted, the
Xoriginal one can be replaced without harm.
XAttempts to unmount a file system holding working directories or open files
Xwill be rejected with a \*(OQdevice busy\*(CQ message.
X
X
X
/
echo x - unexpand
sed '/^X/s///' > unexpand << '/'
X.CD "unexpand \(en convert spaces to tabs"
X.SX "unexpand\fR [\fB\(ena\fR]
X.FL "\(ena" "All spaces are unexpanded"
X.EY "unexpand oldfile >newfile" "Convert leading spaces to tabs"
X.PP
X\fIUnexpand\fR replaces spaces in the named files with tabs.
XIf no files are listed, \fIstdin\fR is given.
XThe \fB\(ena\fR flag is used to force all sequences of spaces to be
Xexpanded, instead of just leading spaces (the default).
X
X
X
/
echo x - uniq
sed '/^X/s///' > uniq << '/'
X.CD "uniq \(en delete consecutive identical lines in a file"
X.SX "uniq\fR [\fB\(encdu\fR]\fR [\fB\(en\fIn\fR] [\fB+\fIn\fR] [\fIinput [\fIoutput\fR]\fR]
X.FL "\(enc" "Give count of identical lines in the input"
X.FL "\(end" "Only duplicate lines are written to output"
X.FL "\(enu" "Only unique lines are written to output"
X.FL "\(en\fIn\fR" "Skip the first \fIn\fR columns when matching"
X.FL "+\fIn\fR" "Skip the first \fIn\fR fields when matching"
X.EX "uniq +2 file" "Ignore first 2 fields when comparing"
X.EX "uniq \(end inf outf" "Write duplicate lines to \fIoutf\fP"
X.PP
X.I Uniq
Xexamines a file for consecutive lines that are identical.
XAll but duplicate entries are deleted, and the file is written to output.
XThe +\fIn\fR option skips the first \fIn\fR fields, where a field is defined
Xas a run of characters separated by white space.
XThe \(en\fIn\fP option skips the first \fIn\fR spaces.
XFields are skipped first.
X
X
/
echo x - unshar
sed '/^X/s///' > unshar << '/'
X.CD "unshar \(en Remove files from a shell archive"
X.SX "unshar\fR [\fB\(enbtvx\fR] \fIsharfile \fImember ..."
X.FL "\(enb" "Unshar brutally, overwriting files if need be"
X.FL "\(ent" "Tell what is in the archive but do not extract"
X.FL "\(env" "Verbose mode"
X.FL "\(enx" "Extract only the members listed"
X.EX "unshar arch.sh" "Extract all members of the archive"
X.EX "unshar \(ent arch.sh" "List the contents of the archive"
X.EX "unshar \(enxf1 \(enxf2 arch.sh" "Extract \fIf1\fR and \fIf2\fR from \fIarch.sh\fR"
X.EX "uniq \(end inf outf" "Write duplicate lines to \fIoutf\fP"
X.PP
X.I Unshar
Xextracts members of a shell archive, the same as \fIsh\fR, except much faster.
XIt expects shell archives created with \fIshar.\fR
XIt also has options to list the contents of a shell archive, and to selectively
Xextract some members but not all.
X
X
X
/
echo x - update
sed '/^X/s///' > update << '/'
X.CD "update \(en periodically write the buffer cache to disk"
X.SX "/etc/update"
X.FL "\fR(none)"
X.EY "/etc/update &" "Start a process that flushes the cache"
X.PP
XWhen the system is booted,
X.I update
Xis started up in the background from 
X.I /etc/rc
Xto issue a 
X.SY SYNC
Xsystem call every 30 sec.
X
X
X
/
echo x - users
sed '/^X/s///' > users << '/'
X.CD "users \(en list the logged-in users"
X.SX "users"
X.FL "\fR(none)"
X.EY "users" "list the users"
X.PP
X\fIUsers\fR prints one line containing the names of all 
Xthe currently logged-in users.
X
X
X
/
echo x - uud
sed '/^X/s///' > uud << '/'
X.CD "uud \(en decode a binary file encoded with uue"
X.SX "uud\fR [\fB\(enn\fR]\fR [\fB\(ens \fIsrcdir\fR] [\fB\(ent \fIdstdir/\fR] \fIfile"
X.FL "\(enn" "Do not verify checksums"
X.FL "\(ens" "Name of directory where \fI.uue\fR file is"
X.FL "\(ent" "Name of directory where output goes"
X.EX "uud file.uue " "Re-create the original file"
X.EX "uud \(en <file.uue" "The \(en means use \fIstdin\fR"
X.PP
X\fIUud\fR decodes a file encoded with \fIuue\fR or
X.UX
X\fIuuencode\fR.
XThe decoded file is given the name that the original file had.  
XThe name information is part of the encoded file.
XMail headers and other junk before the encoded file are skipped.
X
X
X
/
echo x - uue
sed '/^X/s///' > uue << '/'
X.CD "uue \(en encode a binary file to ASCII (e.g., for mailing)"
X.SX "uue\fR [\fB\(en\fIn\fR] \fIfile\fR [\fB\(en\fR]"
X.FL "\(en\fIn\fR" "How many lines to put in each file"
X.EX "uue file" "Encode \fIfile\fR to \fIfile.uue\fR"
X.EX "uue file \(en >x" "Encode \fIfile\fR and write on \fIstdout\fR"
X.EX "uue \(en800 file" "Output on \fIfile.uaa\fR, \fIfile.uab\fR etc."
X.PP
X\fIUuencode\fR is a famous program that converts an arbitrary (usually binary)
Xfile to an encoding using only 64 ASCII characters.
X\fIUudecode\fR converts it back to the original file.
XThe \fIuue\fR and \fIuud\fR programs are the 
X.MX
Xversions of these programs, and are compatible with the \s-2UNIX\s0 ones.
XThe files produced can even be sent successfully over BITNET, which is 
Xnotorious for mangling files.
XIt is possible to have \fIuue\fR automatically split the encoded file up
Xinto small chunks.
XThe output files then get the suffixes \fI.uaa\fR, \fI.uab\fR, etc., instead
Xof \fI.uue\fR.
XWhen \fIuud\fR is given \fIfile.uaa\fR to decode, it automatically includes
Xthe subsequent pieces.
XThe encoding takes 3 bytes (24 bits) from the input file and renders it 
Xas 4 bytes in the output file.
X
X
X
X.SP 2
/
echo x - virecover
sed '/^X/s///' > virecover << '/'
X.CD "virecover \(en recover from a crash"
X.SX "virecover \fR[\fIfile\fR]"
X.FL "\fR(none)"
X.EY "virecover prog.c" "Recover \fIprog.c\fR
X.PP
X\fIVirecover\fR is used to recover an edit session after a crash.
XBoth \fIelvis\fR and \fIex\fR keep a scratch files in \fI/usr/tmp\fR.
XAfter an editor crash, this information is used to reconstruct the file.
XIf \fIvirecover\fR is called with no file name, it expects one of these
Xtemporary files on \fIstdin\fR.
X
X
X
X.SP 2
/
echo x - vol
sed '/^X/s///' > vol << '/'
X.CD "vol \(en split stdin into diskette-sized volumes"
X.SX "vol\fR [\fB\(enu\fR] \fIsize block_special"
X.FL "\(enu" "Unsave from diskettes"
X.EX "tar c \(en . | vol 360 /dev/fd0" "Prompt for disk every 360K"
X.EX "vol \(enu 360 /dev/fd0 | tar x \(en " "Restore a saved file system"
X.PP
XIt occasionally happens that a program generates an output stream intended
Xfor diskette but the stream is to large to fit on one diskette.  \fIVol\fP is a
Xprogram that accepts such a stream, and pauses every \fIn\fR 
Xblocks to request a new diskette to be inserted.  
XThis makes it possible to save arbitrarily long
Xstreams on a series of diskettes, as shown in the examples above.
X
X
X
/
echo x - wc
sed '/^X/s///' > wc << '/'
X.CD "wc \(en count characters, words, and lines in a file"
X.SX "wc\fR [\fB\(enclw\fR] \fIfile\fR ..."
X.FL "\(enc" "Print character count"
X.FL "\(enl" "Print line count"
X.FL "\(enw" "Print word count"
X.EX "wc file1 file2" "Print all three counts for both files"
X.EX "wc \(enl file" "Print line count only"
X.PP
X.I Wc
Xreads each argument and computes the number of characters, words and lines
Xit contains.
XA word is delimited by white space (space, tab, or line feed).
XIf no flags are present, all three counts are printed.
X
X
X
X.SP 0.6
/
echo x - weidertc
sed '/^X/s///' > weidertc << '/'
X.CD "weidertc \(en set date from Weide real time clock [ATARI]"
X.SX "weidertc [\(end]"
X.FL "\(end" "Output some debugging information"
X.EY "weidertc" "Set the date from the Weide real time clock"
X.PP
X.I Weidertc
Xreads the current date and time from a Weide real time clock (if present)
Xand sets the
X.MX
Xtime accordingly.
XThis program is usually called from
X.I /etc/rc .
X
X
X
X.SP 0.6
/
echo x - whatis
sed '/^X/s///' > whatis << '/'
X.CD "whatis \(en tell what the program does"
X.SX "whatis \fIname ..."
X.FL "\fR(none)"
X.EY "whatis head" "Gives a summary of what the \fIhead\fR program does"
X.PP
X\fIWhatis\fR searches the \fI/usr/etc/whatis\fR database for the arguments.
XFor each name, it prints the corresponding entry.
X
X
X
/
echo x - whatsnew
sed '/^X/s///' > whatsnew << '/'
X.CD "whatsnew \(en print a newly modified file, marking changes"
X.SX "whatsnew\fR [\fB\(en\fIn\fR] \fIfile.c file.c.cdif"
X.FL "\(en\fIn\fR" "Output line length"
X.EX "whatsnew file.c file.c.cdif~~~~~~" "Print \fIfile.c\fR with changes marked"
X.EX "whatsnew \(en70 file.c file.c.cdif" "Same as above, but with 70 col line"
X.PP
XIt commonly occurs that \fIcdif\fRs are posted to USENET.
XAfter installing a \fIcdif\fR file, it is sometimes desirable to print out
Xthe new file, with the changes marked on it.
X\fIWhatsnew\fR does precisely this, with the changes + and ! printed in the
Xright-hand margin.
X
X
X
X.SP 0.6
/
echo x - whereis
sed '/^X/s///' > whereis << '/'
X.CD "whereis \(en examine system directories for a given file"
X.SX "whereis \fIfile"
X.FL "\fR(none)"
X.EY "whereis stat.h" "Prints: \fI/usr/include/sys/stat.h\fR"
X.PP
X\fIWhereis\fR searches a fixed set of system 
Xdirectories, \fI/bin\fR, \fI/lib\fR, \fI/usr/bin\fR,
Xand others, and prints all occurrences of the argument name in any of them.
X
X
X
/
echo x - which
sed '/^X/s///' > which << '/'
X.CD "which \(en examine $PATH to see which file will be executed"
X.SX "which \fIname"
X.FL "\fR(none)"
X.EY "which a.out" "Tells which \fIa.out\fR will be executed"
X.PP
XThe $PATH shell variable controls the 
X.MX
Xsearch rules. 
XIf a command \fIa.out\fR is given, the shell first tries to find an 
Xexecutable file in the working directory.  
XIf that fails, it looks in various system directories, such as 
X\fI/bin\fR and \fI/usr/bin\fR.  
XThe\fR which\fR command makes the same search and gives the absolute
Xpath of the program that will be chosen, followed by other occurrences
Xof the file name along the path.
X
X
X
/
echo x - who
sed '/^X/s///' > who << '/'
X.CD "who \(en print list of currently logged in users"
X.SX "who\fR [\fIfile\fR]"
X.FL "\fR(none)"
X.EY "who   " "Print user names, terminals and times"
X.PP
X\fIWho\fR prints a list of currently logged in users.  For each one, 
Xthe user name, terminal, and login time is printed.  
XThis program gets its information from the file \fI/etc/utmp\fR, which 
Xis updated by init and login.  
XIf the file does not exist, neither of these will create it, and 
X\fIwho\fR will not work.  Note that if you decide to create an empty  
X\fI/usr/adm/wtmp\fR to enable the login accounting, it will grow forever and 
Xeventually fill up your disk unless you manually truncate it from time to time.
XIf an optional file name is provided, the logins in that file will be printed.
X
X
X
/
echo x - whoami
sed '/^X/s///' > whoami << '/'
X.CD "whoami \(en print current user name"
X.SX "whoami"
X.FL "\fR(none)"
X.EY "whoami" "Print user name"
X.PP
XIn case you forget who you are logged in as, \fIwhoami\fR will tell you.  If
Xyou use \fIsu\fR to become somebody else, 
X\fIwhoami\fR will give the current effective user.
X
X
X
/
echo x - width
sed '/^X/s///' > width << '/'
X.CD "width \(en force all the lines of a file to a given width"
X.SX "width\fR [\fB\(en\fIn\fR [ \fIinfile\fR [\fIoutfile\fR]\fR
X.FL "\(en\fIn\fR" "Outline line size"
X.EX "width \(en60 x y" "Copy \fIx\fR to \fIy\fR, force lines to 60 cols"
X.EX "width x" "Copy default (80) column lines to \fIstdout\fR"
X.PP
XThe input file is copied to the output file.
XAll lines are forced to a given size (default: 80 columns) by padding with
Xspaces or truncating.
XTabs are expanded to spaces.
X
X
X
/
echo x - write
sed '/^X/s///' > write << '/'
X.CD "write \(en send a message to a logged-in user"
X.SX "write\fR [\fB\(encv\fR] \fIuser\fR [\fItty\fR]
X.FL "\(enc" "Use cbreak mode"
X.FL "\(env" "Verbose mode"
X.EX "write ast" "Send a message to ast"
X.EX "write ast tty1" "Send a message to ast on tty1"
X.PP
X\fIWrite\fR lets a user send messages to another logged-in user.  
XLines typed by the user appear on the other user's screen a line at a time 
X(a character at a time in the case of cbreak mode).  
XThe file \fI/usr/adm/wtmp\fR is searched to determine which tty to send to. 
XIf the user is logged onto more than one terminal, the \fItty\fR argument
Xselects the terminal.  Type CTRL- D to terminate the command.
XUse ! as a shell escape.
/
