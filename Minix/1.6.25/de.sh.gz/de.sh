echo x - de.cd
sed '/^X/s///' > de.cd << '/'
Xecho x - Makefile.d
Xsed '/^X/s///' > Makefile.d << '/'
XX*** /home/top/ast/minix/1.5/commands/de/Makefile  crc=41297    261	Sat Apr 21 22:27:17 1990
XX--- /home/top/ast/minix/1.6.25/commands/de/Makefile  crc=38234    307	Sat Jan 30 20:12:15 1993
XX***************
XX*** 1,13 ****
XX! CFLAGS	= -F -D_MINIX -D_POSIX_SOURCE
XX! DEOBJ   = de.s de_stdin.s de_stdout.s de_diskio.s de_recover.s
XX  
XX! de:	$(DEOBJ)
XX! 	cc -i -T. $(DEOBJ) -o de
XX! 	chmem =30000 de
XX! 	echo "chmod  755  de; 	chown  bin  de; chgrp  bin   de"
XX  
XX! $(DEOBJ): de.h
XX  
XX  
XX! clean:	
XX! 	@rm -f *.bak *.s de
XX--- 1,18 ----
XX! # Makefile for de
XX  
XX! CC	= cc
XX! CFLAGS	= -m -O -D_MINIX -D_POSIX_SOURCE -D_POSIX_1_SOURCE=2
XX! O=o
XX  
XX! OBJS	= de.$O de_stdin.$O de_stdout.$O de_diskio.$O de_recover.$O
XX  
XX+ de:	$(OBJS)
XX+ 	@rm -rf de
XX+ 	@echo Start linking de
XX+ 	@$(CC) -i $(OBJS) -o de >/dev/null
XX+ 	@chmem =8192 de
XX  
XX! $(OBJS): de.h
XX! 
XX! clean:
XX! 	@rm -f *.bak *.o *.s de
X/
Xecho x - de.c.d
Xsed '/^X/s///' > de.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/de/de.c  crc=34427  24341	Sat Apr 21 22:27:17 1990
XX--- /home/top/ast/minix/1.6.25/commands/de/de.c  crc=10007  24323	Tue Dec 22 00:05:44 1992
XX***************
XX*** 13,25 ****
XX  #include <sys/types.h>
XX  #include <sys/dir.h>
XX  #include <sys/stat.h>
XX  #include <ctype.h>
XX  #include <fcntl.h>
XX  #include <limits.h>
XX  #include <signal.h>
XX  #include <string.h>
XX  #include <unistd.h>
XX- #include <stdio.h>
XX  
XX  #include <minix/type.h>
XX  #include "../../fs/const.h"
XX--- 13,29 ----
XX  #include <sys/types.h>
XX  #include <sys/dir.h>
XX  #include <sys/stat.h>
XX+ #include <sys/wait.h>
XX  #include <ctype.h>
XX+ #include <errno.h>
XX+ #undef ERROR			/* arrgghh, errno.h has this pollution */
XX  #include <fcntl.h>
XX  #include <limits.h>
XX  #include <signal.h>
XX+ #include <stdarg.h>
XX+ #include <stdlib.h>
XX  #include <string.h>
XX  #include <unistd.h>
XX  
XX  #include <minix/type.h>
XX  #include "../../fs/const.h"
XX***************
XX*** 27,36 ****
XX  
XX  #include "de.h"
XX  
XX! static char copyright[] = { "de  (c) Terrence W. Holm 1989" };
XX  
XX  
XX  
XX  /****************************************************************/
XX  /*								*/
XX  /*	main()							*/
XX--- 31,48 ----
XX  
XX  #include "de.h"
XX  
XX! static char copyright[] = "de  (c) Terrence W. Holm 1989";
XX  
XX  
XX+ _PROTOTYPE(void Push , (de_state *s ));
XX+ _PROTOTYPE(int Get_Base , (int *base ));
XX+ _PROTOTYPE(int Get_Filename , (de_state *s ));
XX+ _PROTOTYPE(int Get_Count , (char *units , unsigned long *result ));
XX+ _PROTOTYPE(void Exec_Shell , (void));
XX+ _PROTOTYPE(void Sigint , (int));
XX  
XX+ 
XX+ 
XX  /****************************************************************/
XX  /*								*/
XX  /*	main()							*/
XX***************
XX*** 46,52 ****
XX    char *argv[];
XX  
XX    {
XX!   de_state s;
XX    char *command_name = argv[0];
XX    int   recover = 0;
XX  
XX--- 58,67 ----
XX    char *argv[];
XX  
XX    {
XX!   static de_state s;		/* it is safer not to put it on the stack
XX! 				 * and some things probably now rely on zero
XX! 				 * initialization
XX! 				 */  
XX    char *command_name = argv[0];
XX    int   recover = 0;
XX  
XX***************
XX*** 202,208 ****
XX--- 217,226 ----
XX      Error( "Error seeking %s", s.device_name );
XX  
XX    if ( size % K != 0 )
XX+     {
XX      Warning( "Device size is not a multiple of 1024" );
XX+     Warning( "The (partial) last block will not be accessible" );
XX+     }
XX    }
XX  
XX  
XX***************
XX*** 247,253 ****
XX        }
XX  
XX      s.address = ( (long) s.first_data - s.inode_blocks ) * K
XX! 		      + (long) (inode - 1) * INODE_SIZE;
XX  
XX      Read_Block( &s, s.buffer );
XX  
XX--- 265,271 ----
XX        }
XX  
XX      s.address = ( (long) s.first_data - s.inode_blocks ) * K
XX! 		      + (long) (inode - 1) * s.inode_size;
XX  
XX      Read_Block( &s, s.buffer );
XX  
XX***************
XX*** 285,291 ****
XX  
XX      else if ( rc == REDRAW_POINTERS )
XX        {
XX!       s.offset = s.address & ~ K_MASK;
XX        Draw_Pointers( &s );
XX        }
XX  
XX--- 303,309 ----
XX  
XX      else if ( rc == REDRAW_POINTERS )
XX        {
XX!       s.offset = (unsigned) (s.address & ~ K_MASK);
XX        Draw_Pointers( &s );
XX        }
XX  
XX***************
XX*** 465,471 ****
XX      case 'g' :				/*  Goto block		*/
XX  
XX  		{
XX! 		unsigned block;
XX  
XX  		if ( Get_Count( "Block?", &block ) )
XX  		  {
XX--- 483,489 ----
XX      case 'g' :				/*  Goto block		*/
XX  
XX  		{
XX! 		unsigned long block;
XX  
XX  		if ( Get_Count( "Block?", &block ) )
XX  		  {
XX***************
XX*** 477,483 ****
XX  
XX  		  Push( s );
XX  
XX! 		  s->address = (long) block * K;
XX  
XX  		  return( REDRAW );
XX  		  }
XX--- 495,501 ----
XX  
XX  		  Push( s );
XX  
XX! 		  s->address = (off_t) block * K;
XX  
XX  		  return( REDRAW );
XX  		  }
XX***************
XX*** 489,496 ****
XX      case 'G' :				/*  Goto block indirect	*/
XX  
XX  		{
XX! 		unsigned block = *( (unsigned short *)
XX! 				    &s->buffer[ s->offset ] );
XX  
XX  		if ( s->mode != WORD )
XX  		  {
XX--- 507,513 ----
XX      case 'G' :				/*  Goto block indirect	*/
XX  
XX  		{
XX! 		unsigned block = *( (word_t *) &s->buffer[ s->offset ] );
XX  
XX  		if ( s->mode != WORD )
XX  		  {
XX***************
XX*** 526,532 ****
XX      case 'i' :				/*  Goto i-node		*/
XX  
XX  		{
XX! 		ino_t inode;
XX  
XX  		if ( Get_Count( "I-node?", &inode ) )
XX  		  {
XX--- 543,549 ----
XX      case 'i' :				/*  Goto i-node		*/
XX  
XX  		{
XX! 		unsigned long inode;
XX  
XX  		if ( Get_Count( "I-node?", &inode ) )
XX  		  {
XX***************
XX*** 539,546 ****
XX  		  Push( s );
XX  
XX  		  s->mode = WORD;
XX! 		  s->address = ( (long) s->first_data - s->inode_blocks ) * K
XX! 				  + (long) (inode - 1) * INODE_SIZE;
XX  
XX  		  return( REDRAW );
XX  		  }
XX--- 556,563 ----
XX  		  Push( s );
XX  
XX  		  s->mode = WORD;
XX! 		  s->address = (off_t) (s->first_data - s->inode_blocks) * K
XX! 				  + (off_t) (inode - 1) * s->inode_size;
XX  
XX  		  return( REDRAW );
XX  		  }
XX***************
XX*** 570,576 ****
XX  
XX  		  s->mode = WORD;
XX  		  s->address = ( (long) s->first_data - s->inode_blocks ) * K
XX! 				  + (long) (inode - 1) * INODE_SIZE;
XX  		  }
XX  
XX  		return( REDRAW );
XX--- 587,593 ----
XX  
XX  		  s->mode = WORD;
XX  		  s->address = ( (long) s->first_data - s->inode_blocks ) * K
XX! 				  + (long) (inode - 1) * s->inode_size;
XX  		  }
XX  
XX  		return( REDRAW );
XX***************
XX*** 717,723 ****
XX      case 's' :				/*  Store word		*/
XX  
XX  		{
XX! 		unsigned word;
XX  
XX  		if ( s->mode != WORD )
XX  		  {
XX--- 734,740 ----
XX      case 's' :				/*  Store word		*/
XX  
XX  		{
XX! 		unsigned long word;
XX  
XX  		if ( s->mode != WORD )
XX  		  {
XX***************
XX*** 733,739 ****
XX  
XX  		if ( Get_Count( "Store word?", &word ) )
XX  		  {
XX! 		  Write_Word( s, word );
XX  
XX  		  return( REDRAW );
XX  		  }
XX--- 750,761 ----
XX  
XX  		if ( Get_Count( "Store word?", &word ) )
XX  		  {
XX! 		  if ( word != (word_t) word )
XX! 		    {
XX! 		      Warning( "Word is more than 16 bits" );
XX! 		      return( REDRAW );
XX! 		    }
XX! 		  Write_Word( s, (word_t) word );
XX  
XX  		  return( REDRAW );
XX  		  }
XX***************
XX*** 787,798 ****
XX--- 809,822 ----
XX  				break;
XX  
XX  		  case 'm' :	{
XX+ 				/* Assume user knows if map mode is possible
XX  				char *tty = ttyname( 0 );
XX  
XX  				if ( tty == NULL  ||
XX  				    strcmp( tty, "/dev/tty0" ) != 0 )
XX  				  Warning( "Must be at console" );
XX  				else
XX+ 				*/
XX  				  s->mode = MAP;
XX  
XX  				break;
XX***************
XX*** 881,887 ****
XX  
XX  		  s->mode = WORD;
XX  		  s->address = ( (long) s->first_data - s->inode_blocks ) * K
XX! 				  + (long) (inode - 1) * INODE_SIZE;
XX  		  }
XX  
XX  		return( REDRAW );
XX--- 905,911 ----
XX  
XX  		  s->mode = WORD;
XX  		  s->address = ( (long) s->first_data - s->inode_blocks ) * K
XX! 				  + (long) (inode - 1) * s->inode_size;
XX  		  }
XX  
XX  		return( REDRAW );
XX***************
XX*** 892,898 ****
XX  
XX  		{
XX  		int  rc;
XX- 		off_t size;
XX  
XX  		if ( s->mode != WORD )
XX  		  {
XX--- 916,921 ----
XX***************
XX*** 912,918 ****
XX  		Erase_Prompt();
XX  		Draw_Prompt( "Recovering..." );
XX  
XX! 		if ( (size = Recover_Blocks( s )) == -1L )
XX  		  unlink( s->file_name );
XX  
XX  		/*  Force closure of output file.  */
XX--- 935,941 ----
XX  		Erase_Prompt();
XX  		Draw_Prompt( "Recovering..." );
XX  
XX! 		if ( Recover_Blocks( s ) == -1L )
XX  		  unlink( s->file_name );
XX  
XX  		/*  Force closure of output file.  */
XX***************
XX*** 1094,1100 ****
XX  
XX  int Get_Count( units, result )
XX    char *units;
XX!   int  *result;
XX  
XX    {
XX    char *number;
XX--- 1117,1123 ----
XX  
XX  int Get_Count( units, result )
XX    char *units;
XX!   unsigned long *result;
XX  
XX    {
XX    char *number;
XX***************
XX*** 1106,1112 ****
XX    if ( number == NULL  ||  number[0] == '\0' )
XX      return( 0 );
XX  
XX!   return( Str_Int( number, result ) );
XX    }
XX  
XX  
XX--- 1129,1137 ----
XX    if ( number == NULL  ||  number[0] == '\0' )
XX      return( 0 );
XX  
XX!   errno = 0;
XX!   *result = strtoul( number, (char **) NULL, 0 );
XX!   return( errno == 0 );
XX    }
XX  
XX  
XX***************
XX*** 1116,1186 ****
XX  
XX  /****************************************************************/
XX  /*								*/
XX- /*	Str_Int( string, &result )				*/
XX- /*								*/
XX- /*		Convert "string" to an int. Returns non-zero	*/
XX- /*		if successful. Format: [-][0][x]{0-9}*		*/
XX- /*								*/
XX- /****************************************************************/
XX- 
XX- 
XX- int Str_Int( str, result )
XX-   char *str;
XX-   int  *result;
XX- 
XX-   {
XX-   int negative = 0;
XX-   int base = 10;
XX-   int total = 0;
XX-   char c;
XX- 
XX-   while ( *str == ' ' )
XX-     ++str;
XX- 
XX-   if ( *str == '-' )
XX-     {
XX-     ++str;
XX-     negative = 1;
XX-     }
XX- 
XX-   if ( *str == '0' )
XX-     {
XX-     ++str;
XX-     base = 8;
XX-     }
XX- 
XX-   if ( *str == 'x'  ||  *str == 'X' )
XX-     {
XX-     ++str;
XX-     base = 16;
XX-     }
XX- 
XX-   if ( *str == '\0'  &&  base != 8 )
XX-     return( 0 );
XX- 
XX-   while ( (c = *str++) != '\0' )
XX-     {
XX-     if ( c >= '0'  &&  c <= '7' )
XX- 	total = total * base + c - '0';
XX-     else if ( isdigit( c )  &&  base >= 10 )
XX-         total = total * base + c - '0';
XX-     else if ( isxdigit( c )  &&  base == 16 )
XX-         total = total * base + c - 'A'  + 10;
XX-     else
XX- 	return( 0 );
XX-     }
XX- 
XX-   *result = negative ? -total : total;
XX-   return( 1 );
XX-   }
XX- 
XX- 
XX- 
XX- 
XX- 
XX- 
XX- /****************************************************************/
XX- /*								*/
XX  /*	In_Use( bit, map )					*/
XX  /*								*/
XX  /*		Is the bit set in the map?			*/
XX--- 1141,1146 ----
XX***************
XX*** 1189,1200 ****
XX  
XX  
XX  int In_Use( bit, map )
XX!   int bit;
XX!   unsigned *map;
XX  
XX    {
XX!   return( map[(unsigned) bit / (CHAR_BIT * sizeof(int))] &
XX! 	  (1 << ((unsigned) bit % (CHAR_BIT * sizeof(int)))) );
XX    }
XX  
XX  
XX--- 1149,1160 ----
XX  
XX  
XX  int In_Use( bit, map )
XX!   bit_t bit;
XX!   bitchunk_t *map;
XX  
XX    {
XX!   return( map[ (int) (bit / (CHAR_BIT * sizeof (bitchunk_t))) ] &
XX! 	  (1 << ((unsigned) bit % (CHAR_BIT * sizeof (bitchunk_t)))) );
XX    }
XX  
XX  
XX***************
XX*** 1224,1230 ****
XX--- 1184,1194 ----
XX    if ( fstat( s->device_d, &device_stat ) == -1 )
XX      Error( "Can not fstat(2) file system device" );
XX  
XX+ #ifdef S_IFLNK
XX+   if ( lstat( filename, &file_stat ) == -1 )
XX+ #else
XX    if ( stat( filename, &file_stat ) == -1 )
XX+ #endif
XX      {
XX      Warning( "Can not find file %s", filename );
XX      return( 0 );
XX***************
XX*** 1321,1328 ****
XX  /****************************************************************/
XX  
XX  
XX! void Sigint()
XX! 
XX    {
XX    Reset_Term();		/*  Restore terminal characteristics	*/
XX  
XX--- 1285,1292 ----
XX  /****************************************************************/
XX  
XX  
XX! void Sigint(n)
XX! int n;
XX    {
XX    Reset_Term();		/*  Restore terminal characteristics	*/
XX  
XX***************
XX*** 1338,1360 ****
XX  
XX  /****************************************************************/
XX  /*								*/
XX! /*	Error( text, arg1, arg2 )				*/
XX  /*								*/
XX  /*		Print an error message on stderr.		*/
XX  /*								*/
XX  /****************************************************************/
XX  
XX  
XX! void Error( text, arg1, arg2 )
XX    char *text;
XX!   char *arg1;
XX!   char *arg2;
XX  
XX    {
XX    Reset_Term();
XX  
XX    fprintf( stderr, "\nde: " );
XX!   fprintf( stderr, text, arg1, arg2 );
XX    fprintf( stderr, "\n" );
XX  
XX    exit( 1 );
XX--- 1302,1332 ----
XX  
XX  /****************************************************************/
XX  /*								*/
XX! /*	Error( text, ... )					*/
XX  /*								*/
XX  /*		Print an error message on stderr.		*/
XX  /*								*/
XX  /****************************************************************/
XX  
XX  
XX! #if __STDC__
XX! void Error( const char *text, ... )
XX! #else
XX! void Error( text )
XX    char *text;
XX! #endif  
XX  
XX    {
XX+   va_list argp;
XX+ 
XX    Reset_Term();
XX  
XX    fprintf( stderr, "\nde: " );
XX!   va_start( argp, text );
XX!   vfprintf( stderr, text, argp );
XX!   va_end( argp );
XX!   if ( errno != 0 )
XX!     fprintf( stderr, ": %s", strerror( errno ) );
XX    fprintf( stderr, "\n" );
XX  
XX    exit( 1 );
X/
Xecho x - de.h.d
Xsed '/^X/s///' > de.h.d << '/'
XX*** /home/top/ast/minix/1.5/commands/de/de.h  crc=59401   8178	Sat Apr 21 22:27:17 1990
XX--- /home/top/ast/minix/1.6.25/commands/de/de.h  crc=32399  10523	Tue Dec 22 00:05:45 1992
XX***************
XX*** 61,68 ****
XX  /*	fs/link.c and fs/open.c were changed for 'X'.		*/
XX  /*								*/
XX  /****************************************************************/
XX  
XX- 
XX  /*  General constants  */
XX  
XX  #define   MAX_STRING	60		/*  For all input lines	*/
XX--- 61,69 ----
XX  /*	fs/link.c and fs/open.c were changed for 'X'.		*/
XX  /*								*/
XX  /****************************************************************/
XX+ #undef printf
XX+ #include <stdio.h>
XX  
XX  /*  General constants  */
XX  
XX  #define   MAX_STRING	60		/*  For all input lines	*/
XX***************
XX*** 88,93 ****
XX--- 89,98 ----
XX  #define   SPLIT	   0x0B20
XX  #endif
XX  
XX+ #if (CHIP == SPARC)
XX+ #define   A_OUT    0x0301
XX+ #define   SPLIT    0x0B20
XX+ #endif
XX  
XX  /*  Each buffer is 1k.  In WORD mode 16 words (32 bytes) can be	*/
XX  /*  displayed at once. In BLOCK mode 1K bytes can be displayed.	*/
XX***************
XX*** 147,152 ****
XX--- 152,164 ----
XX  #define   BOX_BOT	'_'		/*  Filled lower half   */
XX  #endif
XX  
XX+ #if (CHIP == SPARC)
XX+ /*  Please change these.  */
XX+ #define   BOX_CLR	' '		/*  Empty box		*/
XX+ #define   BOX_ALL	'='		/*  Filled box		*/
XX+ #define   BOX_TOP	'-'		/*  Filled upper half	*/
XX+ #define   BOX_BOT	'_'		/*  Filled lower half   */
XX+ #endif
XX  
XX  /*  Move positions for the output display.  */
XX  
XX***************
XX*** 158,164 ****
XX  #define   INFO_LINE	 BLOCK_LINE
XX  #define   PROMPT_COLUMN	 0
XX  #define   PROMPT_LINE	 23
XX! #define   WARNING_COLUMN 10
XX  #define   WARNING_LINE   10
XX  
XX  
XX--- 170,176 ----
XX  #define   INFO_LINE	 BLOCK_LINE
XX  #define   PROMPT_COLUMN	 0
XX  #define   PROMPT_LINE	 23
XX! #define   WARNING_COLUMN 5
XX  #define   WARNING_LINE   10
XX  
XX  
XX***************
XX*** 177,207 ****
XX  #define   BLOCK    2
XX  #define   MAP	   3
XX  
XX  
XX  typedef  struct  de_state		/*  State of disk ed.	*/
XX    {
XX    /*  Information from super block  */
XX  
XX    unsigned inodes;			/*  Number of i-nodes	*/
XX!   unsigned zones;			/*  Total # of blocks	*/
XX    unsigned inode_maps;			/*  I-node map blocks	*/
XX    unsigned zone_maps;			/*  Zone map blocks	*/
XX    unsigned inode_blocks;		/*  I-node blocks	*/
XX    unsigned first_data;			/*  Total non-data blks	*/
XX  
XX!   unsigned inodes_in_map;		/*  Bits in i-node map	*/
XX!   unsigned zones_in_map;		/*  Bits in zone map	*/
XX  
XX    /*  Information from map blocks  */
XX  
XX!   char inode_map[ I_MAP_SLOTS * K ];
XX!   char zone_map[ ZMAP_SLOTS * K ];
XX  
XX    /*  Information for current block  */
XX  
XX    off_t address;			/*  Current address	*/
XX    off_t last_addr;			/*  For erasing ptrs	*/
XX!   unsigned block;			/*  Current block (1K)	*/
XX    unsigned offset;			/*  Offset within block	*/
XX  
XX    char buffer[ K ];
XX--- 189,233 ----
XX  #define   BLOCK    2
XX  #define   MAP	   3
XX  
XX+ typedef  unsigned int word_t;		/*  For most user i/o	*/
XX  
XX  typedef  struct  de_state		/*  State of disk ed.	*/
XX    {
XX    /*  Information from super block  */
XX+   /*  The types here are mostly promoted types for simplicity	*/
XX+   /*  and efficiency.						*/
XX  
XX    unsigned inodes;			/*  Number of i-nodes	*/
XX!   zone_t zones;				/*  Total # of blocks	*/
XX    unsigned inode_maps;			/*  I-node map blocks	*/
XX    unsigned zone_maps;			/*  Zone map blocks	*/
XX    unsigned inode_blocks;		/*  I-node blocks	*/
XX    unsigned first_data;			/*  Total non-data blks	*/
XX+   int magic;				/*  Magic number	*/
XX  
XX!   /* Numbers derived from the magic number */  
XX!   
XX!   unsigned char is_fs;			/*  Nonzero for good fs	*/
XX!   unsigned char v1;			/*  Nonzero for V1 fs	*/
XX!   unsigned inode_size;			/*  Size of disk inode	*/
XX!   unsigned nr_indirects;		/*  # indirect blocks	*/
XX!   unsigned zone_num_size;		/*  Size of disk z num	*/
XX  
XX+   /* Other derived numbers */  
XX+   
XX+   bit_t inodes_in_map;			/*  Bits in i-node map	*/
XX+   bit_t zones_in_map;			/*  Bits in zone map	*/
XX+ 
XX    /*  Information from map blocks  */
XX  
XX!   bitchunk_t inode_map[ I_MAP_SLOTS * K / sizeof (bitchunk_t) ];
XX!   bitchunk_t zone_map[ Z_MAP_SLOTS * K / sizeof (bitchunk_t) ];
XX  
XX    /*  Information for current block  */
XX  
XX    off_t address;			/*  Current address	*/
XX    off_t last_addr;			/*  For erasing ptrs	*/
XX!   zone_t block;				/*  Current block (1K)	*/
XX    unsigned offset;			/*  Offset within block	*/
XX  
XX    char buffer[ K ];
XX***************
XX*** 222,228 ****
XX    char *device_name;			/*  From command line	*/
XX    int   device_d;
XX    int   device_mode;			/*  O_RDONLY or O_RDWR	*/
XX!   unsigned device_size;			/*  Number of blocks	*/
XX  
XX    char  file_name[ MAX_STRING + 1 ];	/*  For 'w' and 'W'	*/
XX    FILE *file_f;
XX--- 248,254 ----
XX    char *device_name;			/*  From command line	*/
XX    int   device_d;
XX    int   device_mode;			/*  O_RDONLY or O_RDWR	*/
XX!   zone_t device_size;			/*  Number of blocks	*/
XX  
XX    char  file_name[ MAX_STRING + 1 ];	/*  For 'w' and 'W'	*/
XX    FILE *file_f;
XX***************
XX*** 234,323 ****
XX  
XX  /*  Forward references for external routines  */
XX  
XX- /*  libc.a  */
XX- 
XX- struct passwd *getpwuid();
XX- struct group *getgrgid();
XX- char *ctime();
XX- char *getenv();
XX- char *tgetstr();
XX- char *tgoto();
XX- char *ttyname();
XX- FILE *fopen();
XX- off_t lseek();
XX- 
XX- 
XX  /*  de.c  */
XX  
XX! void  main();
XX! int   Process();
XX  
XX! void  Push();
XX! int   Get_Filename();
XX! int   Get_Count();
XX! int   Str_Int();
XX! int   In_Use();
XX! ino_t Find_Inode();
XX! void  Exec_Shell();
XX! void  Sigint();
XX  void  Error();
XX  
XX  
XX  /*  de_stdin.c  */
XX  
XX! void  Save_Term();
XX! void  Set_Term();
XX! void  Reset_Term();
XX! int   Get_Char();
XX! char *Get_Line();
XX! int   Arrow_Esc();
XX  
XX- 
XX  /*  de_stdout.c  */
XX  
XX! int   Init_Termcap();
XX! void  Goto();
XX! void  Draw_Help_Screen();
XX! void  Wait_For_Key();
XX! void  Draw_Prompt();
XX! void  Erase_Prompt();
XX  
XX! void  Draw_Screen();
XX! void  Draw_Strings();
XX! void  Block_Type();
XX! void  Draw_Words();
XX! void  Draw_Info();
XX! void  Draw_Block();
XX! void  Draw_Map();
XX  
XX! void  Draw_Pointers();
XX! void  Draw_Offset();
XX! void  Word_Pointers();
XX! void  Block_Pointers();
XX! void  Map_Pointers();
XX  
XX! void  Print_Number();
XX! void  Print_Ascii();
XX  void  Warning();
XX  
XX  
XX  /*  de_diskio.c  */
XX  
XX! void  Read_Disk();
XX! void  Read_Block();
XX! void  Read_Super_Block();
XX! void  Read_Bit_Maps();
XX! off_t Search();
XX! void  Write_Word();
XX  
XX  
XX  /*  de_recover.c  */
XX  
XX! int   Path_Dir_File();
XX! char *File_Device();
XX! ino_t Find_Deleted_Entry();
XX! off_t Recover_Blocks();
XX  
XX  
XX  #undef    printf			/*  Because fs/const.h	*/
XX  					/*  defines it.		*/
XX--- 260,347 ----
XX  
XX  /*  Forward references for external routines  */
XX  
XX  /*  de.c  */
XX  
XX! _PROTOTYPE(void main , (int argc , char *argv []));
XX! _PROTOTYPE(int Process , (de_state *s , int c ));
XX  
XX! #if __STDC__
XX! void  Error( const char *text, ... );
XX! #else
XX  void  Error();
XX+ #endif
XX  
XX+ _PROTOTYPE(int In_Use , (bit_t bit , bitchunk_t *map ));
XX+ _PROTOTYPE(ino_t Find_Inode , (de_state *s , char *filename ));
XX  
XX+ 
XX  /*  de_stdin.c  */
XX  
XX! _PROTOTYPE(void Save_Term , (void));
XX! _PROTOTYPE(void Set_Term , (void));
XX! _PROTOTYPE(void Reset_Term , (void));
XX! _PROTOTYPE(int Get_Char , (void));
XX! _PROTOTYPE(char *Get_Line , (void));
XX! _PROTOTYPE(int Arrow_Esc , (int c ));
XX  
XX  /*  de_stdout.c  */
XX  
XX! _PROTOTYPE(int Init_Termcap , (void));
XX! _PROTOTYPE(void Draw_Help_Screen , (de_state *s ));
XX! _PROTOTYPE(void Wait_For_Key , (void));
XX! _PROTOTYPE(void Draw_Prompt , (char *string ));
XX! _PROTOTYPE(void Erase_Prompt , (void));
XX  
XX! _PROTOTYPE(void Draw_Screen , (de_state *s ));
XX! _PROTOTYPE(void Draw_Strings , (de_state *s ));
XX! _PROTOTYPE(void Draw_Pointers , (de_state *s ));
XX! _PROTOTYPE(void Print_Ascii , (int c ));
XX  
XX! _PROTOTYPE(void Goto , (int column , int line ));
XX! _PROTOTYPE(void Block_Type , (de_state *s ));
XX! _PROTOTYPE(void Draw_Words , (de_state *s ));
XX! _PROTOTYPE(void Draw_Info , (de_state *s ));
XX! _PROTOTYPE(void Draw_Block , (char *block ));
XX! _PROTOTYPE(void Draw_Map , (char *block , int max_bits ));
XX! _PROTOTYPE(void Draw_Offset , (de_state *s ));
XX! _PROTOTYPE(void Word_Pointers , (off_t old_addr , off_t new_addr ));
XX! _PROTOTYPE(void Block_Pointers , (off_t old_addr , off_t new_addr ));
XX! _PROTOTYPE(void Map_Pointers , (off_t old_addr , off_t new_addr ));
XX! _PROTOTYPE(void Print_Number , (word_t number , int output_base ));
XX! _PROTOTYPE(void Draw_Zone_Numbers , (de_state *s , struct inode *inode , int zindex , int zrow ));
XX  
XX! #if __STDC__
XX! void  Warning( const char *text, ... );
XX! #else
XX  void  Warning();
XX+ #endif
XX  
XX  
XX  /*  de_diskio.c  */
XX  
XX! _PROTOTYPE(void Read_Disk , (de_state *s , off_t block_addr , char *buffer ));
XX! _PROTOTYPE(void Read_Block , (de_state *s , char *buffer ));
XX! _PROTOTYPE(void Read_Super_Block , (de_state *s ));
XX! _PROTOTYPE(void Read_Bit_Maps , (de_state *s ));
XX! _PROTOTYPE(off_t Search , (de_state *s , char *string ));
XX! _PROTOTYPE(void Write_Word , (de_state *s , word_t word ));
XX  
XX  
XX  /*  de_recover.c  */
XX  
XX! _PROTOTYPE(int Path_Dir_File , (char *path_name , char **dir_name , char **file_name ));
XX! _PROTOTYPE(char *File_Device , (char *file_name ));
XX! _PROTOTYPE(ino_t Find_Deleted_Entry , (de_state *s , char *path_name ));
XX! _PROTOTYPE(off_t Recover_Blocks , (de_state *s ));
XX  
XX  
XX  #undef    printf			/*  Because fs/const.h	*/
XX  					/*  defines it.		*/
XX+ 
XX+ 
XX+ /*  Static functions are all pre-declared FORWARD but none are	*/
XX+ /*  declared static yet - this can wait until all functions are	*/
XX+ /*  declared with prototypes.					*/
XX+ 
XX+ #undef FORWARD
XX+ #define FORWARD /* static */
X/
Xecho x - de_diskio.c.d
Xsed '/^X/s///' > de_diskio.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/de/de_diskio.c  crc=01000   7518	Sat Apr 21 22:27:17 1990
XX--- /home/top/ast/minix/1.6.25/commands/de/de_diskio.c  crc=01466   8276	Tue Dec 22 00:05:45 1992
XX***************
XX*** 13,25 ****
XX  #include <sys/types.h>
XX  #include <unistd.h>
XX  #include <limits.h>
XX! #include <stdio.h>
XX  
XX  #include <minix/const.h>
XX  #include <minix/type.h>
XX  #include "../../fs/const.h"
XX  #include "../../fs/type.h"
XX  #include "../../fs/super.h"
XX  
XX  #include "de.h"
XX  
XX--- 13,26 ----
XX  #include <sys/types.h>
XX  #include <unistd.h>
XX  #include <limits.h>
XX! #include <string.h>
XX  
XX  #include <minix/const.h>
XX  #include <minix/type.h>
XX  #include "../../fs/const.h"
XX  #include "../../fs/type.h"
XX  #include "../../fs/super.h"
XX+ #include <minix/fslib.h>
XX  
XX  #include "de.h"
XX  
XX***************
XX*** 89,95 ****
XX  
XX    block_addr = s->address & K_MASK;
XX  
XX!   s->block  = (unsigned) (block_addr >> K_SHIFT);
XX    s->offset = (unsigned) (s->address - block_addr);
XX  
XX    Read_Disk( s, block_addr, buffer );
XX--- 90,96 ----
XX  
XX    block_addr = s->address & K_MASK;
XX  
XX!   s->block  = (zone_t) (block_addr >> K_SHIFT);
XX    s->offset = (unsigned) (s->address - block_addr);
XX  
XX    Read_Disk( s, block_addr, buffer );
XX***************
XX*** 114,130 ****
XX  
XX    {
XX    struct super_block *super = (struct super_block *) s->buffer;
XX  
XX    Read_Disk( s, (long) 1 * K, s->buffer );
XX  
XX    s->inodes = super->s_ninodes;
XX!   s->zones  = super->s_nzones;
XX  
XX!   s->inode_maps   = bitmapsize(1 + s->inodes);
XX!   s->zone_maps    = bitmapsize(s->zones);
XX  
XX!   s->inode_blocks = (s->inodes + INODES_PER_BLOCK - 1) / INODES_PER_BLOCK;
XX    s->first_data   = 2 + s->inode_maps + s->zone_maps + s->inode_blocks;
XX  
XX    s->inodes_in_map = s->inodes + 1;
XX    s->zones_in_map  = s->zones + 1 - s->first_data;
XX--- 115,192 ----
XX  
XX    {
XX    struct super_block *super = (struct super_block *) s->buffer;
XX+   unsigned inodes_per_block;
XX+   off_t size;
XX  
XX    Read_Disk( s, (long) 1 * K, s->buffer );
XX  
XX+   s->magic = super->s_magic;
XX+   if ( s->magic == SUPER_MAGIC )
XX+     {
XX+     s->is_fs = TRUE;
XX+     s->v1 = TRUE;
XX+     s->inode_size = V1_INODE_SIZE;
XX+     inodes_per_block = V1_INODES_PER_BLOCK;
XX+     s->nr_indirects = V1_INDIRECTS;
XX+     s->zone_num_size = V1_ZONE_NUM_SIZE;
XX+     s->zones = super->s_nzones;
XX+     }
XX+   else if ( s->magic == SUPER_V2 )
XX+     {
XX+     s->is_fs = TRUE;
XX+     s->v1 = FALSE;
XX+     s->inode_size = V2_INODE_SIZE;
XX+     inodes_per_block = V2_INODES_PER_BLOCK;
XX+     s->nr_indirects = V2_INDIRECTS;
XX+     s->zone_num_size = V2_ZONE_NUM_SIZE;
XX+     s->zones = super->s_zones;
XX+     }
XX+   else  
XX+     {
XX+     if ( super->s_magic == SUPER_REV )
XX+       Warning( "V1-bytes-swapped file system (?)" );
XX+     else if ( super->s_magic == SUPER_V2_REV )
XX+       Warning( "V2-bytes-swapped file system (?)" );
XX+     else  
XX+       Warning( "Not a Minix file system" );
XX+     Warning( "The file system features will not be available" );  
XX+     if ( (size = lseek( s->device_d, 0L, SEEK_END )) == -1 )
XX+       Error( "Error seeking %s", s->device_name );
XX+     s->zones = s->device_size = size / K;
XX+     return;
XX+     }
XX+ 
XX    s->inodes = super->s_ninodes;
XX!   s->inode_maps = bitmapsize( (bit_t) s->inodes + 1 );
XX!   if ( s->inode_maps != super->s_imap_blocks )
XX!     {
XX!     if ( s->inode_maps > super->s_imap_blocks )
XX!       Error( "Corrupted inode map count or inode count in super block" );
XX!     else  
XX!       Warning( "Count of inode map blocks in super block suspiciously high" );
XX!     s->inode_maps = super->s_imap_blocks;
XX!     }
XX  
XX!   s->zone_maps = bitmapsize( (bit_t) s->zones );
XX!   if ( s->zone_maps != super->s_zmap_blocks )
XX!     {
XX!     if ( s->zone_maps > super->s_zmap_blocks )
XX!       Error( "Corrupted zone map count or zone count in super block" );
XX!     else
XX!       Warning( "Count of zone map blocks in super block suspiciously high" );
XX!     s->zone_maps = super->s_zmap_blocks;
XX!     }
XX  
XX!   s->inode_blocks = (s->inodes + inodes_per_block - 1) / inodes_per_block;
XX    s->first_data   = 2 + s->inode_maps + s->zone_maps + s->inode_blocks;
XX+   if ( s->first_data != super->s_firstdatazone )
XX+   {
XX+     if ( s->first_data > super->s_firstdatazone )
XX+       Error( "Corrupted first data zone offset or inode count in super block" );
XX+     else
XX+       Warning( "First data zone in super block suspiciously high" );
XX+     s->first_data = super->s_firstdatazone;
XX+   }  
XX  
XX    s->inodes_in_map = s->inodes + 1;
XX    s->zones_in_map  = s->zones + 1 - s->first_data;
XX***************
XX*** 136,155 ****
XX  
XX    s->device_size = s->zones;
XX  
XX-   if ( s->inode_maps != super->s_imap_blocks )
XX-     Warning( "Corrupted inode map count in super block" );
XX- 
XX-   if ( s->zone_maps != super->s_zmap_blocks )
XX-     Warning( "Corrupted zone map count in super block" );
XX- 
XX-   if ( s->first_data != super->s_firstdatazone )
XX-     Warning( "Corrupted first data zone count in super block" );
XX- 
XX    if ( super->s_log_zone_size != 0 )
XX!     Warning( "Can not handle multiple blocks per zone" );
XX! 
XX!   if ( super->s_magic != SUPER_MAGIC )
XX!     Warning( "Corrupted magic number in super block" );
XX    }
XX  
XX  
XX--- 198,205 ----
XX  
XX    s->device_size = s->zones;
XX  
XX    if ( super->s_log_zone_size != 0 )
XX!     Error( "Can not handle multiple blocks per zone" );
XX    }
XX  
XX  
XX***************
XX*** 173,179 ****
XX    {
XX    int i;
XX  
XX!   if ( s->inode_maps > I_MAP_SLOTS  ||  s->zone_maps > ZMAP_SLOTS )
XX      {
XX      Warning( "Super block specifies too many bit map blocks" );
XX      return;
XX--- 223,229 ----
XX    {
XX    int i;
XX  
XX!   if ( s->inode_maps > I_MAP_SLOTS  ||  s->zone_maps > Z_MAP_SLOTS )
XX      {
XX      Warning( "Super block specifies too many bit map blocks" );
XX      return;
XX***************
XX*** 181,192 ****
XX  
XX    for ( i = 0;  i < s->inode_maps;  ++i )
XX      {
XX!     Read_Disk( s, (long) (2 + i) * K, &s->inode_map[ i * K ] );
XX      }
XX  
XX    for ( i = 0;  i < s->zone_maps;  ++i )
XX      {
XX!     Read_Disk( s, (long) (2 + s->inode_maps + i) * K, &s->zone_map[ i * K ] );
XX      }
XX    }
XX  
XX--- 231,244 ----
XX  
XX    for ( i = 0;  i < s->inode_maps;  ++i )
XX      {
XX!     Read_Disk( s, (long) (2 + i) * K,
XX! 	       (char *) &s->inode_map[ i * K / sizeof (bitchunk_t ) ] );
XX      }
XX  
XX    for ( i = 0;  i < s->zone_maps;  ++i )
XX      {
XX!     Read_Disk( s, (long) (2 + s->inode_maps + i) * K,
XX! 	       (char *) &s->zone_map[ i * K / sizeof (bitchunk_t ) ] );
XX      }
XX    }
XX  
XX***************
XX*** 277,283 ****
XX  
XX  void Write_Word( s, word )
XX    de_state *s;
XX!   unsigned word;
XX  
XX    {
XX    if ( s->address & 01 )
XX--- 329,335 ----
XX  
XX  void Write_Word( s, word )
XX    de_state *s;
XX!   word_t word;
XX  
XX    {
XX    if ( s->address & 01 )
XX***************
XX*** 286,326 ****
XX    if ( lseek( s->device_d, s->address, SEEK_SET ) == -1 )
XX      Error( "Error seeking %s", s->device_name );
XX  
XX!   if ( write( s->device_d, (char *) &word, 2 ) != 2 )
XX      Error( "Error writing %s", s->device_name );
XX    }
XX- 
XX- 
XX- 
XX- 
XX- 
XX- 
XX- /* The next routine is copied from fsck.c and mkfs.c...  (Re)define some
XX-  * things for consistency.  This sharing should be done better in a library
XX-  * library routine.  In the library routine, the shifts should be replaced
XX-  * by multiplications and divisions by MAP_BITS_PER_BLOCK since log2 of
XX-  * this is too painful to get right.
XX-  */
XX- #define BITMAPSHIFT	 13	/* = log2(MAP_BITS_PER_BLOCK) */
XX- #define bit_nr unsigned
XX- 
XX- /* Convert from bit count to a block count. The usual expression
XX-  *
XX-  *	(nr_bits + (1 << BITMAPSHIFT) - 1) >> BITMAPSHIFT
XX-  *
XX-  * doesn't work because of overflow.
XX-  *
XX-  * Other overflow bugs, such as the expression for N_ILIST overflowing when
XX-  * s_inodes is just over INODES_PER_BLOCK less than the maximum+1, are not
XX-  * fixed yet, because that number of inodes is silly.
XX-  */
XX- int bitmapsize(nr_bits)
XX- bit_nr nr_bits;
XX- {
XX- 	int nr_blocks;
XX- 
XX- 	nr_blocks = nr_bits >> BITMAPSHIFT;
XX- 	if ((nr_blocks << BITMAPSHIFT) < nr_bits)
XX- 		++nr_blocks;
XX- 	return(nr_blocks);
XX- }
XX--- 338,343 ----
XX    if ( lseek( s->device_d, s->address, SEEK_SET ) == -1 )
XX      Error( "Error seeking %s", s->device_name );
XX  
XX!   if ( write( s->device_d, (char *) &word, sizeof word ) != sizeof word )
XX      Error( "Error writing %s", s->device_name );
XX    }
X/
Xecho x - de_recover.c.d
Xsed '/^X/s///' > de_recover.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/de/de_recover.c  crc=44708  12358	Sat Apr 21 22:27:17 1990
XX--- /home/top/ast/minix/1.6.25/commands/de/de_recover.c  crc=07231  13124	Tue Dec 22 00:05:46 1992
XX***************
XX*** 19,36 ****
XX  #include <pwd.h>
XX  #include <string.h>
XX  #include <unistd.h>
XX- #include <stdio.h>
XX  
XX  #include <minix/type.h>
XX  #include <blocksize.h>
XX  #include "../../fs/const.h"
XX  #include "../../fs/type.h"
XX  
XX  #include "de.h"
XX  
XX  
XX  
XX  
XX  /****************************************************************/
XX  /*								*/
XX  /*	Path_Dir_File( path_name, dir_name, file_name )		*/
XX--- 19,42 ----
XX  #include <pwd.h>
XX  #include <string.h>
XX  #include <unistd.h>
XX  
XX+ #include <minix/const.h>
XX  #include <minix/type.h>
XX  #include <blocksize.h>
XX  #include "../../fs/const.h"
XX  #include "../../fs/type.h"
XX+ #include "../../fs/inode.h"
XX+ #include <minix/fslib.h>
XX  
XX  #include "de.h"
XX  
XX+ _PROTOTYPE(int Indirect, (de_state *s, zone_t block, off_t *size, int dblind));
XX+ _PROTOTYPE(int Data_Block, (de_state *s, zone_t block, off_t *file_size ));
XX+ _PROTOTYPE(int Free_Block, (de_state *s, zone_t block ));
XX  
XX  
XX  
XX+ 
XX  /****************************************************************/
XX  /*								*/
XX  /*	Path_Dir_File( path_name, dir_name, file_name )		*/
XX***************
XX*** 112,118 ****
XX    struct stat device_stat;
XX    int dev_d;
XX    struct direct entry;
XX!   static char device_name[ DIRSIZ + 1 ];
XX  
XX  
XX    if ( access( file_name, R_OK ) != 0 )
XX--- 118,124 ----
XX    struct stat device_stat;
XX    int dev_d;
XX    struct direct entry;
XX!   static char device_name[ NAME_MAX + 1 ];
XX  
XX  
XX    if ( access( file_name, R_OK ) != 0 )
XX***************
XX*** 146,152 ****
XX  
XX      strcpy( device_name, DEV );
XX      strcat( device_name, "/" );
XX!     strncat( device_name, entry.d_name, DIRSIZ );
XX  
XX      if ( stat( device_name, &device_stat ) == -1 )
XX        continue;
XX--- 152,158 ----
XX  
XX      strcpy( device_name, DEV );
XX      strcat( device_name, "/" );
XX!     strncat( device_name, entry.d_name, NAME_MAX );
XX  
XX      if ( stat( device_name, &device_stat ) == -1 )
XX        continue;
XX***************
XX*** 260,268 ****
XX  					      == sizeof(struct direct) )
XX      {
XX      if ( entry.d_ino == 0  &&
XX! 	strncmp( file_name, entry.d_name, DIRSIZ - sizeof(ino_t) ) == 0 )
XX        {
XX!       ino_t inode = *( (ino_t *) &entry.d_name[ DIRSIZ - sizeof(ino_t) ] );
XX  
XX        close( dir_d );
XX  
XX--- 266,274 ----
XX  					      == sizeof(struct direct) )
XX      {
XX      if ( entry.d_ino == 0  &&
XX! 	strncmp( file_name, entry.d_name, NAME_MAX - sizeof(ino_t) ) == 0 )
XX        {
XX!       ino_t inode = *( (ino_t *) &entry.d_name[ NAME_MAX - sizeof(ino_t) ] );
XX  
XX        close( dir_d );
XX  
XX***************
XX*** 325,334 ****
XX    de_state *s;
XX  
XX    {
XX!   d_inode *inode = (d_inode *) &s->buffer[ s->offset & ~ PAGE_MASK ];
XX!   int node = (s->address - (s->first_data - s->inode_blocks) * K) /
XX! 		INODE_SIZE + 1;
XX  
XX  
XX    if ( s->block < s->first_data - s->inode_blocks  ||
XX  	    s->block >= s->first_data )
XX--- 331,347 ----
XX    de_state *s;
XX  
XX    {
XX!   struct inode core_inode;
XX!   d1_inode *dip1;
XX!   d2_inode *dip2;
XX!   struct inode *inode = &core_inode;
XX!   bit_t node = (s->address - (s->first_data - s->inode_blocks) * K) /
XX! 		s->inode_size + 1;
XX  
XX+   dip1 = (d1_inode *) &s->buffer[ s->offset & ~ PAGE_MASK ];
XX+   dip2 = (d2_inode *) &s->buffer[ s->offset & ~ PAGE_MASK
XX+ 					    & ~ (V2_INODE_SIZE-1) ];
XX+   conv_inode( inode, dip1, dip2, READING, s->magic );
XX  
XX    if ( s->block < s->first_data - s->inode_blocks  ||
XX  	    s->block >= s->first_data )
XX***************
XX*** 374,382 ****
XX    int i;
XX  
XX  
XX!   /*  Up to 7 block pointers are stored in the i-node.  */
XX  
XX!   for ( i = 0;  i < NR_DZONE_NUM;  ++i )
XX      {
XX      if ( file_size == 0 )
XX  	return( inode->i_size );
XX--- 387,395 ----
XX    int i;
XX  
XX  
XX!   /*  Up to inode->i_ndzones pointers are stored in the i-node.  */
XX  
XX!   for ( i = 0;  i < inode->i_ndzones;  ++i )
XX      {
XX      if ( file_size == 0 )
XX  	return( inode->i_size );
XX***************
XX*** 389,406 ****
XX      return( inode->i_size );
XX  
XX  
XX!   /*  An indirect block can contain up to 512 more block pointers.  */
XX  
XX!   if ( ! Indirect( s, inode->i_zone[ NR_DZONE_NUM ], &file_size, 0 ) )
XX      return( -1L );
XX  
XX    if ( file_size == 0 )
XX      return( inode->i_size );
XX  
XX  
XX!   /*  A double indirect block can contain up to 512 indirect blocks.  */
XX  
XX!   if ( ! Indirect( s, inode->i_zone[ NR_DZONE_NUM+1 ], &file_size, 1 ) )
XX      return( -1L );
XX  
XX    if ( file_size == 0 )
XX--- 402,419 ----
XX      return( inode->i_size );
XX  
XX  
XX!   /*  An indirect block can contain up to inode->i_indirects more blk ptrs.  */
XX  
XX!   if ( ! Indirect( s, inode->i_zone[ inode->i_ndzones ], &file_size, 0 ) )
XX      return( -1L );
XX  
XX    if ( file_size == 0 )
XX      return( inode->i_size );
XX  
XX  
XX!   /*  A double indirect block can contain up to inode->i_indirects blk ptrs. */
XX  
XX!   if ( ! Indirect( s, inode->i_zone[ inode->i_ndzones+1 ], &file_size, 1 ) )
XX      return( -1L );
XX  
XX    if ( file_size == 0 )
XX***************
XX*** 408,413 ****
XX--- 421,429 ----
XX  
XX    Error( "Internal fault (file_size != 0)" );
XX    }
XX+ 
XX+   /* NOTREACHED */
XX+   return( -1L );
XX    }
XX  
XX  
XX***************
XX*** 419,426 ****
XX   *
XX   *  Recover all the blocks pointed to by the indirect block
XX   *  "block",  up to "file_size" bytes. If "double" is true,
XX!  *  then "block" is a double-indirect block pointing to 512
XX!  *  indirect blocks.
XX   *
XX   *  If a "hole" is encountered, then just seek ahead in the
XX   *  output file.
XX--- 435,442 ----
XX   *
XX   *  Recover all the blocks pointed to by the indirect block
XX   *  "block",  up to "file_size" bytes. If "double" is true,
XX!  *  then "block" is a double-indirect block pointing to
XX!  *  V*_INDIRECTS indirect blocks.
XX   *
XX   *  If a "hole" is encountered, then just seek ahead in the
XX   *  output file.
XX***************
XX*** 429,447 ****
XX  
XX  int Indirect( s, block, file_size, dblind )
XX    de_state *s;
XX!   zone_nr   block;
XX    off_t    *file_size;
XX    int       dblind;
XX  
XX    {
XX!   zone_nr indirect[ NR_INDIRECTS ];
XX    int  i;
XX  
XX    /*  Check for a "hole".  */
XX  
XX    if ( block == NO_ZONE )
XX      {
XX!     off_t skip = (off_t) NR_INDIRECTS * K;
XX  
XX      if ( *file_size < skip  ||  dblind )
XX        {
XX--- 445,468 ----
XX  
XX  int Indirect( s, block, file_size, dblind )
XX    de_state *s;
XX!   zone_t   block;
XX    off_t    *file_size;
XX    int       dblind;
XX  
XX    {
XX!   union
XX!     {
XX!     zone1_t ind1[ V1_INDIRECTS ];
XX!     zone_t  ind2[ V2_INDIRECTS ];
XX!     } indirect;
XX    int  i;
XX+   zone_t zone;
XX  
XX    /*  Check for a "hole".  */
XX  
XX    if ( block == NO_ZONE )
XX      {
XX!     off_t skip = (off_t) s->nr_indirects * K;
XX  
XX      if ( *file_size < skip  ||  dblind )
XX        {
XX***************
XX*** 466,486 ****
XX      return( 0 );
XX  
XX  
XX!   Read_Disk( s, (long) block << K_SHIFT, indirect );
XX  
XX!   for ( i = 0;  i < NR_INDIRECTS;  ++i )
XX      {
XX      if ( *file_size == 0 )
XX  	return( 1 );
XX  
XX      if ( dblind )
XX        {
XX!       if ( ! Indirect( s, indirect[ i ], file_size, 0 ) )
XX  	return( 0 );
XX        }
XX      else
XX        {
XX!       if ( ! Data_Block( s, indirect[ i ], file_size ) )
XX          return( 0 );
XX        }
XX      }
XX--- 487,508 ----
XX      return( 0 );
XX  
XX  
XX!   Read_Disk( s, (long) block << K_SHIFT, (char *) &indirect );
XX  
XX!   for ( i = 0;  i < s->nr_indirects;  ++i )
XX      {
XX      if ( *file_size == 0 )
XX  	return( 1 );
XX  
XX+     zone = (s->v1 ? indirect.ind1[ i ] : indirect.ind2[ i ]);
XX      if ( dblind )
XX        {
XX!       if ( ! Indirect( s, zone, file_size, 0 ) )
XX  	return( 0 );
XX        }
XX      else
XX        {
XX!       if ( ! Data_Block( s, zone, file_size ) )
XX          return( 0 );
XX        }
XX      }
XX***************
XX*** 508,514 ****
XX  
XX  int Data_Block( s, block, file_size )
XX    de_state *s;
XX!   zone_nr   block;
XX    off_t    *file_size;
XX  
XX    {
XX--- 530,536 ----
XX  
XX  int Data_Block( s, block, file_size )
XX    de_state *s;
XX!   zone_t   block;
XX    off_t    *file_size;
XX  
XX    {
XX***************
XX*** 545,551 ****
XX    Read_Disk( s, (long) block << K_SHIFT, buffer );
XX  
XX  
XX!   if ( fwrite( buffer, 1, (int) block_size, s->file_f ) != (int) block_size )
XX      {
XX      Warning( "Problem writing %s", s->file_name );
XX      return( 0 );
XX--- 567,574 ----
XX    Read_Disk( s, (long) block << K_SHIFT, buffer );
XX  
XX  
XX!   if ( fwrite( buffer, 1, (size_t) block_size, s->file_f )
XX!        != (size_t) block_size )
XX      {
XX      Warning( "Problem writing %s", s->file_name );
XX      return( 0 );
XX***************
XX*** 569,575 ****
XX  
XX  int Free_Block( s, block )
XX    de_state *s;
XX!   zone_nr  block;
XX  
XX    {
XX    if ( block < s->first_data  ||  block >= s->zones )
XX--- 592,598 ----
XX  
XX  int Free_Block( s, block )
XX    de_state *s;
XX!   zone_t  block;
XX  
XX    {
XX    if ( block < s->first_data  ||  block >= s->zones )
XX***************
XX*** 578,584 ****
XX      return( 0 );
XX      }
XX  
XX!   if ( In_Use( block - s->first_data + 1, s->zone_map ) )
XX      {
XX      Warning( "Encountered an \"in use\" data block" );
XX      return( 0 );
XX--- 601,607 ----
XX      return( 0 );
XX      }
XX  
XX!   if ( In_Use( (bit_t) (block - (s->first_data - 1)), s->zone_map ) )
XX      {
XX      Warning( "Encountered an \"in use\" data block" );
XX      return( 0 );
X/
Xecho x - de_stdin.c.d
Xsed '/^X/s///' > de_stdin.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/de/de_stdin.c  crc=49987   5000	Sat Apr 21 22:27:17 1990
XX--- /home/top/ast/minix/1.6.25/commands/de/de_stdin.c  crc=12902   5152	Mon Dec 21 21:53:02 1992
XX***************
XX*** 13,26 ****
XX--- 13,31 ----
XX  #include <sys/types.h>
XX  #include <sgtty.h>
XX  #include <signal.h>
XX+ #include <unistd.h>
XX  #include <stdio.h>
XX  
XX  #include "../../fs/const.h"
XX  
XX  #include "de.h"
XX  
XX+ FORWARD _PROTOTYPE(int Timed_Get_Char , (int time ));
XX+ FORWARD _PROTOTYPE(void Timed_Out , (int n));
XX  
XX  
XX+ 
XX+ 
XX  /****************************************************************/
XX  /*								*/
XX  /*	Save_Term()						*/
XX***************
XX*** 42,48 ****
XX  
XX  static struct sgttyb saved_mode;
XX  static struct tchars saved_chars;
XX- void Timed_Out();
XX  
XX  
XX  void Save_Term()
XX--- 47,52 ----
XX***************
XX*** 67,73 ****
XX  
XX    /*  No tab expansion, no echo, don't map ^M to ^J, cbreak mode  */
XX  
XX!   mode.sg_flags = mode.sg_flags & ~XTABS & ~ECHO & ~CRMOD  |  CBREAK;
XX  
XX  
XX    /*  Change the interrupt character to ^C  */
XX--- 71,77 ----
XX  
XX    /*  No tab expansion, no echo, don't map ^M to ^J, cbreak mode  */
XX  
XX!   mode.sg_flags = (mode.sg_flags & ~XTABS & ~ECHO & ~CRMOD)  |  CBREAK;
XX  
XX  
XX    /*  Change the interrupt character to ^C  */
XX***************
XX*** 239,244 ****
XX--- 243,251 ----
XX      }
XX  
XX    Error( "Internal fault (line buffer overflow)" );
XX+ 
XX+   /* NOTREACHED */
XX+   return( NULL );
XX    }
XX  
XX  
XX***************
XX*** 284,290 ****
XX    return( c );
XX    }
XX  
XX! void Timed_Out()
XX    {}
XX  
XX  
XX--- 291,298 ----
XX    return( c );
XX    }
XX  
XX! void Timed_Out(n)
XX! int n;
XX    {}
XX  
XX  
X/
Xecho x - de_stdout.c.d
Xsed '/^X/s///' > de_stdout.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/de/de_stdout.c  crc=10132  22552	Sat Apr 21 22:27:17 1990
XX--- /home/top/ast/minix/1.6.25/commands/de/de_stdout.c  crc=19014  25937	Tue Dec 22 00:05:47 1992
XX***************
XX*** 11,27 ****
XX  
XX  #include <minix/config.h>
XX  #include <sys/types.h>
XX  #include <ar.h>
XX  #include <fcntl.h>
XX  #include <limits.h>
XX  #include <grp.h>
XX  #include <pwd.h>
XX! #include <sys/stat.h>
XX! #include <stdio.h>
XX  
XX  #include <minix/type.h>
XX  #include "../../fs/const.h"
XX  #include "../../fs/type.h"
XX  
XX  #include "de.h"
XX  
XX--- 11,35 ----
XX  
XX  #include <minix/config.h>
XX  #include <sys/types.h>
XX+ #include <sys/stat.h>
XX  #include <ar.h>
XX  #include <fcntl.h>
XX  #include <limits.h>
XX  #include <grp.h>
XX  #include <pwd.h>
XX! #include <stdarg.h>
XX! #include <stdlib.h>
XX! #include <string.h>
XX! #include <termcap.h>
XX! #include <time.h>
XX! #include <unistd.h>
XX  
XX+ #include <minix/const.h>
XX  #include <minix/type.h>
XX  #include "../../fs/const.h"
XX  #include "../../fs/type.h"
XX+ #include "../../fs/inode.h"
XX+ #include <minix/fslib.h>
XX  
XX  #include "de.h"
XX  
XX***************
XX*** 47,54 ****
XX--- 55,75 ----
XX  char   Kleft  = 0;		/* (kl) - Left arrow key	*/
XX  char   Kright = 0;		/* (kr) - Right arrow key	*/
XX  
XX+ _PROTOTYPE(void Goto , (int column , int line ));
XX+ _PROTOTYPE(void Block_Type , (de_state *s ));
XX+ _PROTOTYPE(void Draw_Words , (de_state *s ));
XX+ _PROTOTYPE(void Draw_Info , (de_state *s ));
XX+ _PROTOTYPE(void Draw_Block , (char *block ));
XX+ _PROTOTYPE(void Draw_Map , (char *block , int max_bits ));
XX+ _PROTOTYPE(void Draw_Offset , (de_state *s ));
XX+ _PROTOTYPE(void Word_Pointers , (off_t old_addr , off_t new_addr ));
XX+ _PROTOTYPE(void Block_Pointers , (off_t old_addr , off_t new_addr ));
XX+ _PROTOTYPE(void Map_Pointers , (off_t old_addr , off_t new_addr ));
XX+ _PROTOTYPE(void Print_Number , (word_t number , int output_base ));
XX+ _PROTOTYPE(void Draw_Zone_Numbers , (de_state *s , struct inode *inode , int zindex , int zrow ));
XX  
XX  
XX+ 
XX  /****************************************************************/
XX  /*								*/
XX  /*	Init_Termcap()						*/
XX***************
XX*** 301,312 ****
XX  		  /*  of the i-node or zone bit maps.	    */
XX  
XX  		  if ( s->block == 2 + s->inode_maps - 1 )
XX! 		    max_bits = s->inodes_in_map - 8 * K * (s->inode_maps - 1)
XX! 				 - 8 * (s->offset & ~ MAP_MASK);
XX  
XX  		  else if ( s->block == 2 + s->inode_maps + s->zone_maps - 1 )
XX! 		    max_bits = s->zones_in_map - 8 * K * (s->zone_maps - 1)
XX! 				 - 8 * (s->offset & ~ MAP_MASK);
XX  
XX  		  if ( max_bits < 0 )
XX  		      max_bits = 0;
XX--- 322,337 ----
XX  		  /*  of the i-node or zone bit maps.	    */
XX  
XX  		  if ( s->block == 2 + s->inode_maps - 1 )
XX! 		    max_bits = (int)
XX! 			       (s->inodes_in_map
XX! 				- CHAR_BIT * K * (ino_t) (s->inode_maps - 1)
XX! 				- CHAR_BIT * (ino_t) (s->offset & ~ MAP_MASK));
XX  
XX  		  else if ( s->block == 2 + s->inode_maps + s->zone_maps - 1 )
XX! 		    max_bits = (int)
XX! 			       (s->zones_in_map
XX! 			        - CHAR_BIT * K * (zone_t) (s->zone_maps - 1)
XX! 				- CHAR_BIT * (zone_t) (s->offset & ~ MAP_MASK));
XX  
XX  		  if ( max_bits < 0 )
XX  		      max_bits = 0;
XX***************
XX*** 348,353 ****
XX--- 373,391 ----
XX    printf( "Device %s= %-14.14s  ",
XX  	     s->device_mode == O_RDONLY ? "" : "(w) ", s->device_name );
XX  
XX+   switch ( s->magic )
XX+     {
XX+     case SUPER_MAGIC :	printf( "V1 file system  ");
XX+ 			break;
XX+     case SUPER_REV :	printf( "V1-bytes-swapped file system (?)  ");
XX+ 			break;
XX+     case SUPER_V2 :	printf( "V2 file system  ");
XX+ 			break;
XX+     case SUPER_V2_REV :	printf( "V2-bytes-swapped file system (?)  ");
XX+ 			break;
XX+     default :		printf( "not a Minix file system  ");
XX+ 			break;
XX+     }
XX  
XX    len = strlen( s->file_name );
XX  
XX***************
XX*** 407,412 ****
XX--- 445,452 ----
XX  
XX    printf( "Block  = %5u of %-5u  ", s->block, s->zones );
XX  
XX+   if ( !s->is_fs )
XX+     return;
XX  
XX    if ( s->block == BOOT_BLOCK )
XX      printf( "Boot block" );
XX***************
XX*** 425,431 ****
XX  
XX    else
XX      printf( "Data block  (%sin use)",
XX! 	In_Use(s->block - s->first_data + 1, s->zone_map) ? "" : "not " );
XX    }
XX  
XX  
XX--- 465,472 ----
XX  
XX    else
XX      printf( "Data block  (%sin use)",
XX! 	In_Use( (bit_t) (s->block - (s->first_data - 1)), s->zone_map )
XX! 	? "" : "not " );
XX    }
XX  
XX  
XX***************
XX*** 456,465 ****
XX  
XX      printf( "%5d  ", addr );
XX  
XX!     Print_Number( *( (unsigned short *) &s->buffer[ addr ] ), s->output_base );
XX      }
XX  
XX!   Goto( BLOCK_COLUMN + 64, BLOCK_LINE + 6 );
XX    printf( "(base %d)", s->output_base );
XX    }
XX  
XX--- 497,506 ----
XX  
XX      printf( "%5d  ", addr );
XX  
XX!     Print_Number( *( (word_t *) &s->buffer[ addr ] ), s->output_base );
XX      }
XX  
XX!   Goto( BLOCK_COLUMN + 64, BLOCK_LINE  );
XX    printf( "(base %d)", s->output_base );
XX    }
XX  
XX***************
XX*** 492,546 ****
XX  				"magic number"  };
XX  
XX  
XX- char *inode_info[] =  {	"",
XX- 			"",
XX- 			"",
XX- 			"",
XX- 			"",
XX- 			"",
XX- 			"",
XX- 			"zone 0",
XX- 			"zone 1",
XX- 			"zone 2",
XX- 			"zone 3",
XX- 			"zone 4",
XX- 			"zone 5",
XX- 			"zone 6",
XX- 			"indirect",
XX- 			"double indirect"  };
XX- 
XX- 
XX- 
XX  void Draw_Info( s )
XX    de_state *s;
XX  
XX    {
XX    int i;
XX    int page = s->offset >> PAGE_SHIFT;
XX  
XX  
XX!   if ( s->block == SUPER_BLOCK  &&  page == 0 )
XX        for ( i = 0;  i < 9;  ++i )
XX   	{
XX  	Goto( INFO_COLUMN, INFO_LINE + i );
XX  	printf( "%s", super_block_info[ i ] );
XX  	}
XX  
XX!   else if ( s->block >= s->first_data - s->inode_blocks  &&
XX  	    s->block < s->first_data )
XX        {
XX!       d_inode *inode = (d_inode *) &s->buffer[ s->offset & ~ PAGE_MASK ];
XX        int special = 0;
XX        int m;
XX!       struct passwd *user = getpwuid( inode->i_uid );
XX!       struct group  *grp  = getgrgid( inode->i_gid );
XX  
XX!       for ( i = 0;  i < 16;  ++i )
XX!     	{
XX!     	Goto( INFO_COLUMN, INFO_LINE + i );
XX!     	printf( "%s", inode_info[ i ] );
XX!     	}
XX  
XX        Goto( INFO_COLUMN, INFO_LINE  );
XX  
XX        switch( inode->i_mode & S_IFMT )
XX--- 533,580 ----
XX  				"magic number"  };
XX  
XX  
XX  void Draw_Info( s )
XX    de_state *s;
XX  
XX    {
XX    int i;
XX    int page = s->offset >> PAGE_SHIFT;
XX+   dev_t dev;
XX  
XX  
XX!   if ( s->is_fs  &&  s->block == SUPER_BLOCK  &&  page == 0 )
XX        for ( i = 0;  i < 9;  ++i )
XX   	{
XX  	Goto( INFO_COLUMN, INFO_LINE + i );
XX  	printf( "%s", super_block_info[ i ] );
XX  	}
XX  
XX!   else if ( s->is_fs  &&  s->block >= s->first_data - s->inode_blocks  &&
XX  	    s->block < s->first_data )
XX        {
XX!       struct inode core_inode;
XX!       d1_inode *dip1;
XX!       d2_inode *dip2;
XX!       struct inode *inode = &core_inode;
XX        int special = 0;
XX        int m;
XX!       struct passwd *user;
XX!       struct group *grp;
XX  
XX!       dip1 = (d1_inode *) &s->buffer[ s->offset & ~ PAGE_MASK ];
XX!       dip2 = (d2_inode *) &s->buffer[ s->offset & ~ PAGE_MASK
XX! 						& ~ (V2_INODE_SIZE-1) ];
XX!       conv_inode( inode, dip1, dip2, READING, s->magic );
XX  
XX+       user = getpwuid( inode->i_uid );
XX+       grp  = getgrgid( inode->i_gid );
XX+ 
XX+       if ( s->magic != SUPER_MAGIC  &&  page & 1 )
XX+ 	{
XX+ 	Draw_Zone_Numbers( s, inode, 2, 0 );
XX+ 	return;
XX+ 	}
XX+ 
XX        Goto( INFO_COLUMN, INFO_LINE  );
XX  
XX        switch( inode->i_mode & S_IFMT )
XX***************
XX*** 562,591 ****
XX      	case S_IFIFO :  printf( "fifo  " );
XX  		    	break;
XX  #endif
XX      	default      :  printf( "unknown  " );
XX      	}
XX  
XX  
XX!       for ( m = 11;  m >= 0;  --m )
XX!     	putchar( (inode->i_mode & (1<<m)) ? "xwrxwrxwrtgu"[m] : '-' );
XX  
XX!       Goto( INFO_COLUMN, INFO_LINE + 1 );
XX!       printf( "user %s", user ? user->pw_name : "" );
XX  
XX!       Goto( INFO_COLUMN, INFO_LINE + 2 );
XX!       printf( "file size %lu", inode->i_size );
XX  
XX!       Goto( INFO_COLUMN, INFO_LINE + 4 );
XX!       printf( "%s", ctime( &inode->i_mtime ) );
XX  
XX!       Goto( INFO_COLUMN, INFO_LINE + 6 );
XX!       printf( "links %d, group %s", inode->i_nlinks, grp ? grp->gr_name : "" );
XX  
XX        if ( special )
XX  	{
XX!         Goto( INFO_COLUMN, INFO_LINE + 7 );
XX! 	printf( "major %d, minor %d", major( inode->i_zone[0] ),
XX! 				      minor( inode->i_zone[0] ) );
XX  	}
XX        }
XX  
XX--- 596,665 ----
XX      	case S_IFIFO :  printf( "fifo  " );
XX  		    	break;
XX  #endif
XX+ #ifdef S_IFLNK
XX+     	case S_IFLNK :  printf( "symlink  " );
XX+ 		    	break;
XX+ #endif
XX+ #ifdef S_IFSOCK
XX+     	case S_IFSOCK:  printf( "socket  " );
XX+ 		    	break;
XX+ #endif
XX      	default      :  printf( "unknown  " );
XX      	}
XX  
XX+ 	for ( m = 11;  m >= 0;  --m )
XX+ 	  putchar( (inode->i_mode & (1<<m)) ? "xwrxwrxwrtgu"[m] : '-' );
XX  
XX! 	if ( s->magic == SUPER_MAGIC )
XX! 	  {
XX! 	  /* V1 file system */
XX! 	  Goto( INFO_COLUMN, INFO_LINE + 1 );
XX! 	  printf( "user %s", user ? user->pw_name : "" );
XX  
XX! 	  Goto( INFO_COLUMN, INFO_LINE + 2 );
XX! 	  printf( "file size %lu", inode->i_size );
XX  
XX! 	  Goto( INFO_COLUMN, INFO_LINE + 4 );
XX! 	  printf( "m_time %s", ctime( &inode->i_mtime ) );
XX  
XX! 	  Goto( INFO_COLUMN, INFO_LINE + 6 );
XX! 	  printf( "links %d, group %s",
XX! 		  inode->i_nlinks, grp ? grp->gr_name : "" );
XX  
XX! 	  Draw_Zone_Numbers( s, inode, 0, 7 );
XX! 	  }
XX! 	else
XX! 	  {
XX! 	  /* V2 file system, even page. */
XX! 	  Goto( INFO_COLUMN, INFO_LINE + 1 );
XX! 	  printf( "links %d ", inode->i_nlinks);
XX  
XX+ 	  Goto( INFO_COLUMN, INFO_LINE + 2 );
XX+ 	  printf( "user %s", user ? user->pw_name : "" );
XX+ 
XX+ 	  Goto( INFO_COLUMN, INFO_LINE + 3 );
XX+ 	  printf( "group %s", grp ? grp->gr_name : "" );
XX+ 
XX+ 	  Goto( INFO_COLUMN, INFO_LINE + 4 );
XX+ 	  printf( "file size %lu", inode->i_size );
XX+ 
XX+ 	  Goto( INFO_COLUMN, INFO_LINE + 6 );
XX+ 	  printf( "a_time %s", ctime( &inode->i_atime ) );
XX+ 
XX+ 	  Goto( INFO_COLUMN, INFO_LINE + 8 );
XX+ 	  printf( "m_time %s", ctime( &inode->i_mtime ) );
XX+ 
XX+ 	  Goto( INFO_COLUMN, INFO_LINE + 10 );
XX+ 	  printf( "c_time %s", ctime( &inode->i_ctime ) );
XX+ 
XX+ 	  Draw_Zone_Numbers( s, inode, 0, 12 );
XX+ 	}
XX+ 
XX        if ( special )
XX  	{
XX! 	Goto( INFO_COLUMN, INFO_LINE + 7 );
XX! 	dev = (dev_t) inode->i_zone[0];
XX! 	printf( "major %d, minor %d", major(dev), minor(dev) );
XX  	}
XX        }
XX  
XX***************
XX*** 602,613 ****
XX  
XX        if ( s->block >= s->first_data  &&  page == 0 )
XX  	{
XX! 	int magic  = (s->buffer[1] << 8) | (s->buffer[0] & 0xff);
XX! 	int second = (s->buffer[3] << 8) | (s->buffer[2] & 0xff);
XX  
XX          /*  Is this block the start of an "ar" archive?  */
XX  
XX! 	if ( magic == ARMAG )
XX  	  {
XX            Goto( INFO_COLUMN, INFO_LINE );
XX  	  printf( "\"ar\" archive" );
XX--- 676,687 ----
XX  
XX        if ( s->block >= s->first_data  &&  page == 0 )
XX  	{
XX! 	unsigned magic  = ((s->buffer[1] & 0xff) << 8) | (s->buffer[0] & 0xff);
XX! 	unsigned second = ((s->buffer[3] & 0xff) << 8) | (s->buffer[2] & 0xff);
XX  
XX          /*  Is this block the start of an "ar" archive?  */
XX  
XX! 	if ( magic == (unsigned) ARMAG )
XX  	  {
XX            Goto( INFO_COLUMN, INFO_LINE );
XX  	  printf( "\"ar\" archive" );
XX***************
XX*** 615,628 ****
XX  
XX  	/*  Is this block the start of an executable file?  */
XX  
XX! 	else if ( magic == A_OUT )
XX  	  {
XX            Goto( INFO_COLUMN, INFO_LINE );
XX  	  printf( "executable" );
XX  
XX            Goto( INFO_COLUMN, INFO_LINE + 1 );
XX  
XX! 	  if ( second == SPLIT )
XX  	    printf( "separate I & D" );
XX  	  else
XX  	    printf( "combined I & D" );
XX--- 689,702 ----
XX  
XX  	/*  Is this block the start of an executable file?  */
XX  
XX! 	else if ( magic == (unsigned) A_OUT )
XX  	  {
XX            Goto( INFO_COLUMN, INFO_LINE );
XX  	  printf( "executable" );
XX  
XX            Goto( INFO_COLUMN, INFO_LINE + 1 );
XX  
XX! 	  if ( second == (unsigned) SPLIT )
XX  	    printf( "separate I & D" );
XX  	  else
XX  	    printf( "combined I & D" );
XX***************
XX*** 864,875 ****
XX  
XX    else if ( s->block < s->first_data )
XX      {
XX!     int node = (s->address - (2 + s->inode_maps + s->zone_maps) * K) /
XX! 		INODE_SIZE + 1;
XX  
XX      if ( node <= s->inodes )
XX! 	printf( "I-node %d of %d  (%sin use)       ", node, s->inodes,
XX! 	     In_Use(node, s->inode_map) ? "" : "not " );
XX      else
XX  	printf( "(padding)                             " );
XX      }
XX--- 938,950 ----
XX  
XX    else if ( s->block < s->first_data )
XX      {
XX!     bit_t node = (s->address - (2 + s->inode_maps + s->zone_maps) * K) /
XX! 		s->inode_size + 1;
XX  
XX      if ( node <= s->inodes )
XX! 	printf( "I-node %lu of %lu  (%sin use)       ",
XX! 		(unsigned long) node, (unsigned long) s->inodes,
XX! 		In_Use( node, s->inode_map ) ? "" : "not " );
XX      else
XX  	printf( "(padding)                             " );
XX      }
XX***************
XX*** 969,975 ****
XX  
XX  
XX  void Print_Number( number, output_base )
XX!   int number;
XX    int output_base;
XX  
XX    {
XX--- 1044,1050 ----
XX  
XX  
XX  void Print_Number( number, output_base )
XX!   word_t number;
XX    int output_base;
XX  
XX    {
XX***************
XX*** 1043,1061 ****
XX  /****************************************************************/
XX  
XX  
XX! void Warning( text, arg1, arg2 )
XX    char *text;
XX!   char *arg1;
XX!   char *arg2;
XX  
XX    {
XX    printf( "%c%s", BELL, Tclr_all );
XX  
XX    Goto( WARNING_COLUMN, WARNING_LINE );
XX  
XX    printf( "%s Warning: ", Treverse );
XX!   printf( text, arg1, arg2 );
XX    printf( " %s", Tnormal );
XX  
XX    sleep( 2 );
XX    }
XX--- 1118,1175 ----
XX  /****************************************************************/
XX  
XX  
XX! #if __STDC__
XX! void Warning( const char *text, ... )
XX! #else
XX! void Warning( text )
XX    char *text;
XX! #endif  
XX  
XX    {
XX+   va_list argp;
XX+   
XX    printf( "%c%s", BELL, Tclr_all );
XX  
XX    Goto( WARNING_COLUMN, WARNING_LINE );
XX  
XX    printf( "%s Warning: ", Treverse );
XX!   va_start( argp, text );
XX!   vprintf( text, argp );
XX!   va_end( argp );
XX    printf( " %s", Tnormal );
XX  
XX+   fflush(stdout);		/* why does everyone forget this? */
XX+ 
XX    sleep( 2 );
XX+   }
XX+ 
XX+ 
XX+ void Draw_Zone_Numbers( s, inode, zindex, zrow )
XX+   de_state *s;
XX+   struct inode *inode;
XX+   int zindex;
XX+   int zrow;
XX+ 
XX+   {
XX+   static char *plurals[] = { "", "double ", "triple " };
XX+   zone_t zone;
XX+ 
XX+   for ( ; zrow < 16;
XX+ 	++zindex, zrow += s->zone_num_size / sizeof (word_t) )
XX+     {
XX+     Goto( INFO_COLUMN, INFO_LINE + zrow );
XX+     if ( zindex < inode->i_ndzones )
XX+       printf( "zone %d", zindex );
XX+     else
XX+       printf( "%sindirect", plurals[ zindex - inode->i_ndzones ] );
XX+     if ( s->magic != SUPER_MAGIC )
XX+       {
XX+       zone = inode->i_zone[ zindex ];
XX+       if ( zone != (word_t) zone )
XX+ 	{
XX+ 	Goto( INFO_COLUMN + 16, INFO_LINE + zrow );
XX+ 	printf("%ld", (long) zone );
XX+ 	}
XX+       }
XX+     }
XX    }
X/
/
