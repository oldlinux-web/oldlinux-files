echo x - dis88.cd
sed '/^X/s///' > dis88.cd << '/'
Xecho x - Makefile.d
Xsed '/^X/s///' > Makefile.d << '/'
XX*** /home/top/ast/minix/1.5/commands/dis88/Makefile  crc=26224   1506	Sat Apr 21 22:27:17 1990
XX--- /home/top/ast/minix/1.6.25/commands/dis88/Makefile  crc=53400   1629	Sat Jan 30 20:12:15 1993
XX***************
XX*** 1,3 ****
XX--- 1,5 ----
XX+ # Makefile for dis
XX+ 
XX  # @(#) Makefile, Ver. 2.1 created 00:00:00 87/09/01
XX  # Makefile for 8088 symbolic disassembler
XX  
XX***************
XX*** 22,43 ****
XX  # the initialization  data in the lookup tables.  It should not
XX  # be necessary to alter the formats of the tables.
XX  
XX! OBJ = disrel.s dismain.s distabs.s dishand.s disfp.s
XX  
XX! dis88 : $(OBJ)
XX! 	cc -o dis88 $(OBJ)
XX  
XX  
XX! disrel.s : disrel.c
XX  
XX- dismain.s : dismain.c dis.h
XX  
XX- distabs.s : distabs.c dis.h
XX- 
XX- dishand.s : dishand.c dis.h
XX- 
XX- disfp.s : disfp.c dis.h
XX- 
XX- 
XX  clean:	
XX! 	@rm -f *.bak *.s dis88
XX--- 24,46 ----
XX  # the initialization  data in the lookup tables.  It should not
XX  # be necessary to alter the formats of the tables.
XX  
XX! CFLAGS =-O -wo
XX! O=o
XX! OBJ = disrel.$O dismain.$O distabs.$O dishand.$O disfp.$O
XX  
XX! dis88:	$(OBJ)
XX! 	@rm -rf dis88
XX! 	@echo Start linking dis88
XX! 	@cc -o dis88 $(OBJ) >/dev/null
XX! 	@chmem =10000 dis88
XX  
XX  
XX! disrel.$O:	disrel.c
XX! dismain.$O:	dismain.c dis.h
XX! distabs.$O:	distabs.c dis.h
XX! dishand.$O:	dishand.c dis.h
XX! disfp.$O:	disfp.c dis.h
XX  
XX  
XX  clean:	
XX! 	@rm -f *.bak *.o *.s core dis88
X/
Xecho x - dis.h.d
Xsed '/^X/s///' > dis.h.d << '/'
XX*** /home/top/ast/minix/1.5/commands/dis88/dis.h  crc=18153   7782	Sat Apr 21 22:27:17 1990
XX--- /home/top/ast/minix/1.6.25/commands/dis88/dis.h  crc=21510   5625	Mon Dec 21 18:56:24 1992
XX***************
XX*** 29,42 ****
XX  #include <fcntl.h>      /* System file-control definitions  */
XX  #include <unistd.h>
XX  #include <string.h>
XX  #include <stdio.h>      /* System standard I/O definitions  */
XX  
XX- #if i8086 || i8088      /* For CPU's with 16-bit integers   */
XX- #undef int
XX- #else                   /* Defaults (for 32-bit CPU types)  */
XX- #define int short
XX- #endif
XX- 
XX  #define MAXSYM 1500     /* Maximum entries in symbol table  */
XX  
XX  extern struct nlist     /* Array to hold the symbol table   */
XX--- 29,37 ----
XX  #include <fcntl.h>      /* System file-control definitions  */
XX  #include <unistd.h>
XX  #include <string.h>
XX+ #include <stdlib.h>
XX  #include <stdio.h>      /* System standard I/O definitions  */
XX  
XX  #define MAXSYM 1500     /* Maximum entries in symbol table  */
XX  
XX  extern struct nlist     /* Array to hold the symbol table   */
XX***************
XX*** 46,106 ****
XX     relo[MAXSYM];
XX  
XX  extern int symptr;      /* Index into the symtab[] array    */
XX- 
XX  extern int relptr;      /* Index into the relo[] array      */
XX  
XX  struct opcode           /* Format for opcode data records   */
XX!    {
XX!    char     *text;            /* Pointer to mnemonic text   */
XX!    void     (*func)();        /* Pointer to handler routine */
XX!    unsigned min;              /* Minimum # of object bytes  */
XX!    unsigned max;              /* Maximum # of object bytes  */
XX!    };
XX  
XX  extern struct opcode    /* Array to hold the opcode table   */
XX    optab[256];
XX  
XX-  /*
XX-    +---------------------------------------------
XX-    | The following  functions are the specialized
XX-    | handlers for each opcode group. They are, of
XX-    | course, highly MACHINE-SPECIFIC.  Each entry
XX-    | in the opcode[]  array contains a pointer to
XX-    | one of these  handlers.  The handlers in the
XX-    | first group are in  dishand.c;  those in the
XX-    | second group are in disfp.c.
XX-    +---------------------------------------------
XX-  */
XX- 
XX- extern void dfhand(),   /* Default handler routine          */
XX-             sbhand(),   /* Single-byte handler              */
XX-             aohand(),   /* Arithmetic-op handler            */
XX-             sjhand(),   /* Short-jump handler               */
XX-             imhand(),   /* Immediate-operand handler        */
XX-             mvhand(),   /* Simple move handler              */
XX-             mshand(),   /* Segreg-move handler              */
XX-             pohand(),   /* Pop memory/reg handler           */
XX-             cihand(),   /* Intersegment call handler        */
XX-             mihand(),   /* Immediate-move handler           */
XX-             mqhand(),   /* Quick-move handler               */
XX-             tqhand(),   /* Quick-test handler               */
XX-             rehand(),   /* Return handler                   */
XX-             mmhand(),   /* Move-to-memory handler           */
XX-             srhand(),   /* Shift and rotate handler         */
XX-             aahand(),   /* ASCII-adjust handler             */
XX-             iohand(),   /* Immediate port I/O handler       */
XX-             ljhand(),   /* Long-jump handler                */
XX-             mahand(),   /* Misc. arithmetic handler         */
XX-             mjhand();   /* Miscellaneous jump handler       */
XX- 
XX- extern void eshand(),   /* Bus-escape opcode handler        */
XX-             fphand(),   /* Floating-point handler           */
XX-             inhand();   /* Interrupt-opcode handler         */
XX- 
XX  extern char *REGS[];    /* Table of register names          */
XX- 
XX  extern char *REGS0[];   /* Mode 0 register name table       */
XX- 
XX  extern char *REGS1[];   /* Mode 1 register name table       */
XX  
XX  #define AL REGS[0]      /* CPU register manifests           */
XX--- 41,61 ----
XX     relo[MAXSYM];
XX  
XX  extern int symptr;      /* Index into the symtab[] array    */
XX  extern int relptr;      /* Index into the relo[] array      */
XX  
XX  struct opcode           /* Format for opcode data records   */
XX! {
XX!    char *text;          /* Pointer to mnemonic text   */
XX!    void (*func)();      /* Pointer to handler routine */
XX!    unsigned min;        /* Minimum # of object bytes  */
XX!    unsigned max;        /* Maximum # of object bytes  */
XX! };
XX  
XX  extern struct opcode    /* Array to hold the opcode table   */
XX    optab[256];
XX  
XX  extern char *REGS[];    /* Table of register names          */
XX  extern char *REGS0[];   /* Mode 0 register name table       */
XX  extern char *REGS1[];   /* Mode 1 register name table       */
XX  
XX  #define AL REGS[0]      /* CPU register manifests           */
XX***************
XX*** 129,139 ****
XX  #define BP_DI REGS0[3]
XX  
XX  extern int symrank[6][6];     /* Symbol type/rank matrix    */
XX- 
XX  extern unsigned long PC;      /* Current program counter    */
XX- 
XX  extern int segflg;      /* Flag: segment override in effect */
XX- 
XX  extern int objflg;      /* Flag: output object as a comment */
XX  
XX  #define OBJMAX 8        /* Size of the object code buffer   */
XX--- 84,91 ----
XX***************
XX*** 141,163 ****
XX  extern unsigned char    /* Internal buffer for object code  */
XX     objbuf[OBJMAX];
XX  
XX- extern void objini(),   /* Object-buffer init routine       */
XX-             objout();   /* Object-code output routine       */
XX- 
XX  extern int objptr;      /* Index into the objbuf[] array    */
XX  
XX- extern void badseq();   /* Bad-code-sequence function       */
XX- 
XX- extern char *getnam();  /* Symbol-name string function      */
XX- 
XX- extern char *lookup();  /* Symbol-table lookup function     */
XX- 
XX- extern int lookext();   /* Extern-definition lookup routine */
XX- 
XX- extern char *mtrans();  /* Interpreter for the mode byte    */
XX- 
XX- extern void mtrunc();   /* Mode string truncator function   */
XX- 
XX  extern char ADD[],      /* Opcode family mnemonic strings   */
XX              OR[],
XX              ADC[],
XX--- 93,100 ----
XX***************
XX*** 176,182 ****
XX              AMBIG[];
XX  
XX  extern char *OPFAM[];   /* Indexed mnemonic family table    */
XX- 
XX  extern struct exec HDR; /* Holds the object file's header   */
XX  
XX  #define LOOK_ABS 0      /* Arguments to lookup() function   */
XX--- 113,118 ----
XX***************
XX*** 187,210 ****
XX  #define TR_SEG 8
XX  
XX                          /* Macro for byte input primitive   */
XX! #define FETCH(p) \
XX!    ++PC; p = getchar() & 0xff; objbuf[objptr++] = p
XX  
XX- #ifdef OBSOLETE		/* Declarations to use if headers   */
XX- 			/* are inadequate.  sprintf() and   */
XX- 			/* strlen() may have the wrong type.*/
XX- extern int close();     /* System file-close primitive      */
XX- extern long lseek();    /* System file-position primitive   */
XX- extern int open();      /* System file-open primitive       */
XX- extern int read();      /* System file-read primitive       */
XX- extern char *strcat();  /* Library string-join function     */
XX- extern char *strcpy();  /* Library string-copy function     */
XX- extern int strlen();    /* Library string-length function   */
XX- #endif
XX  
XX! /* extern int sprintf();   /* Library string-output function   */
XX! /* extern int printf();    /* Library output-format function   */
XX! /* extern int fprintf();   /* Library file-output function     */
XX!  /* * * * * * * * * * *  END OF  dis.h  * * * * * * * * * * */
XX! 
XX  
XX--- 123,167 ----
XX  #define TR_SEG 8
XX  
XX                          /* Macro for byte input primitive   */
XX! #define FETCH(p)  ++PC; p = getchar() & 0xff; objbuf[objptr++] = p
XX  
XX  
XX! /* disfp.c */
XX! _PROTOTYPE(void eshand, (int j ));
XX! _PROTOTYPE(void fphand, (int j ));
XX! _PROTOTYPE(void inhand, (int j ));
XX  
XX+ /* dishand.c */
XX+ _PROTOTYPE(void objini, (int j ));
XX+ _PROTOTYPE(void objout, (void));
XX+ _PROTOTYPE(void badseq, (int j, int k ));
XX+ _PROTOTYPE(void dfhand, (int j ));
XX+ _PROTOTYPE(void sbhand, (int j ));
XX+ _PROTOTYPE(void aohand, (int j ));
XX+ _PROTOTYPE(void sjhand, (int j ));
XX+ _PROTOTYPE(void imhand, (int j ));
XX+ _PROTOTYPE(void mvhand, (int j ));
XX+ _PROTOTYPE(void mshand, (int j ));
XX+ _PROTOTYPE(void pohand, (int j ));
XX+ _PROTOTYPE(void cihand, (int j ));
XX+ _PROTOTYPE(void mihand, (int j ));
XX+ _PROTOTYPE(void mqhand, (int j ));
XX+ _PROTOTYPE(void tqhand, (int j ));
XX+ _PROTOTYPE(void rehand, (int j ));
XX+ _PROTOTYPE(void mmhand, (int j ));
XX+ _PROTOTYPE(void srhand, (int j ));
XX+ _PROTOTYPE(void aahand, (int j ));
XX+ _PROTOTYPE(void iohand, (int j ));
XX+ _PROTOTYPE(void ljhand, (int j ));
XX+ _PROTOTYPE(void mahand, (int j ));
XX+ _PROTOTYPE(void mjhand, (int j ));
XX+ 
XX+ /* dismain.c */
XX+ _PROTOTYPE(void main, (int argc, char **argv ));
XX+ 
XX+ /* distabs.c */
XX+ _PROTOTYPE(char *getnam, (int k ));
XX+ _PROTOTYPE(int lookext, (long off, long loc, char *buf ));
XX+ _PROTOTYPE(char *lookup, (long addr, int type, int kind, long ext ));
XX+ _PROTOTYPE(char *mtrans, (int c, int m, int type ));
XX+ _PROTOTYPE(void mtrunc, (char *a ));
X/
Xecho x - dismain.c.d
Xsed '/^X/s///' > dismain.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/dis88/dismain.c  crc=40674  17464	Sat Apr 21 22:27:18 1990
XX--- /home/top/ast/minix/1.6.25/commands/dis88/dismain.c  crc=57529  17926	Mon Dec 21 18:56:24 1992
XX***************
XX*** 1,5 ****
XX! static char *sccsid =
XX!    "@(#) dismain.c, Ver. 2.1 created 00:00:00 87/09/01";
XX  
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX--- 1,4 ----
XX! static char *sccsid =  "@(#) dismain.c, Ver. 2.1 created 00:00:00 87/09/01";
XX  
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX***************
XX*** 33,47 ****
XX  #include "dis.h"              /* Disassembler declarations  */
XX  
XX  extern char *release;         /* Contains release string    */
XX- 
XX  static char *IFILE = NULL;    /* Points to input file name  */
XX- 
XX  static char *OFILE = NULL;    /* Points to output file name */
XX- 
XX  static char *PRG;             /* Name of invoking program   */
XX- 
XX  static unsigned long zcount;  /* Consecutive "0" byte count */
XX- 
XX  int objflg = 0;               /* Flag: output object bytes  */
XX  
XX  #define unix 1
XX--- 32,41 ----
XX***************
XX*** 53,59 ****
XX  #else
XX  static int cpuid = 0;
XX  #endif
XX! 
XX   /* * * * * * * MISCELLANEOUS UTILITY FUNCTIONS * * * * * * */
XX  
XX  static void
XX--- 47,66 ----
XX  #else
XX  static int cpuid = 0;
XX  #endif
XX! 
XX! _PROTOTYPE(static void usage, (char *s ));
XX! _PROTOTYPE(static void fatal, (char *s, char *t ));
XX! _PROTOTYPE(static void zdump, (unsigned long beg ));
XX! _PROTOTYPE(static void prolog, (void));
XX! _PROTOTYPE(static void distext, (void));
XX! _PROTOTYPE(static void disdata, (void));
XX! _PROTOTYPE(static void disbss, (void));
XX! 
XX! _PROTOTYPE(static char *invoker, (char *s));
XX! _PROTOTYPE(static int objdump, (char *c));
XX! _PROTOTYPE(static char *getlab, (int type));
XX! _PROTOTYPE(static void prolog, (void));
XX! 
XX   /* * * * * * * MISCELLANEOUS UTILITY FUNCTIONS * * * * * * */
XX  
XX  static void
XX***************
XX*** 101,107 ****
XX  
XX     return (s);
XX  }
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This rather tricky routine supports the disdata() func- *
XX--- 108,114 ----
XX  
XX     return (s);
XX  }
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This rather tricky routine supports the disdata() func- *
XX***************
XX*** 173,179 ****
XX     return (retval);
XX  
XX  }/* * * * * * * * * *  END OF  objdump()  * * * * * * * * * */
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This  routine,  called  at the  beginning  of the input *
XX--- 180,186 ----
XX     return (retval);
XX  
XX  }/* * * * * * * * * *  END OF  objdump()  * * * * * * * * * */
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This  routine,  called  at the  beginning  of the input *
XX***************
XX*** 189,197 ****
XX  
XX  static char *
XX  getlab(type)
XX! 
XX!    register int type;
XX! 
XX  {/* * * * * * * * * *  START OF getlab()  * * * * * * * * * */
XX  
XX     register int k;
XX--- 196,202 ----
XX  
XX  static char *
XX  getlab(type)
XX! register int type;
XX  {/* * * * * * * * * *  START OF getlab()  * * * * * * * * * */
XX  
XX     register int k;
XX***************
XX*** 224,230 ****
XX     return (NULL);
XX  
XX  }/* * * * * * * * * * * END OF getlab() * * * * * * * * * * */
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This routine  performs a preliminary scan of the symbol *
XX--- 229,235 ----
XX     return (NULL);
XX  
XX  }/* * * * * * * * * * * END OF getlab() * * * * * * * * * * */
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This routine  performs a preliminary scan of the symbol *
XX***************
XX*** 310,316 ****
XX        putchar('\n');
XX  
XX  }/* * * * * * * * * * * END OF prolog() * * * * * * * * * * */
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This function is  responsible  for  disassembly  of the *
XX--- 315,321 ----
XX        putchar('\n');
XX  
XX  }/* * * * * * * * * * * END OF prolog() * * * * * * * * * * */
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This function is  responsible  for  disassembly  of the *
XX***************
XX*** 372,378 ****
XX        }
XX  
XX  }/* * * * * * * * * *  END OF  distext()  * * * * * * * * * */
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This  function  handles the object file's data segment. *
XX--- 377,383 ----
XX        }
XX  
XX  }/* * * * * * * * * *  END OF  distext()  * * * * * * * * * */
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This  function  handles the object file's data segment. *
XX***************
XX*** 433,439 ****
XX     objdump("");
XX  
XX  }/* * * * * * * * * *  END OF  disdata()  * * * * * * * * * */
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This  function  handles the object  file's bss segment. *
XX--- 438,444 ----
XX     objdump("");
XX  
XX  }/* * * * * * * * * *  END OF  disdata()  * * * * * * * * * */
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This  function  handles the object  file's bss segment. *
XX***************
XX*** 442,449 ****
XX    *                                                         *
XX    * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
XX  
XX! static void
XX! disbss()
XX  
XX  {/* * * * * * * * * *  START OF disbss()  * * * * * * * * * */
XX  
XX--- 447,453 ----
XX    *                                                         *
XX    * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
XX  
XX! static void disbss()
XX  
XX  {/* * * * * * * * * *  START OF disbss()  * * * * * * * * * */
XX  
XX***************
XX*** 478,484 ****
XX        zdump(beg);
XX  
XX  }/* * * * * * * * * * * END OF disbss() * * * * * * * * * * */
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This is the program  entry  point.  The command line is *
XX--- 482,488 ----
XX        zdump(beg);
XX  
XX  }/* * * * * * * * * * * END OF disbss() * * * * * * * * * * */
XX! 
XX   /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
XX    *                                                         *
XX    * This is the program  entry  point.  The command line is *
XX***************
XX*** 625,629 ****
XX     exit(0);
XX  
XX  }/* * * * * * * * * * *  END OF main()  * * * * * * * * * * */
XX- 
XX- 
XX--- 629,631 ----
X/
/
