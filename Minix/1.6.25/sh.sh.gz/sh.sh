echo x - sh.cd
sed '/^X/s///' > sh.cd << '/'
Xecho x - Makefile.d
Xsed '/^X/s///' > Makefile.d << '/'
XX*** /home/top/ast/minix/1.5/commands/sh/Makefile  crc=51562    171	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/sh/Makefile  crc=56783    263	Sat Mar 13 19:44:28 1993
XX***************
XX*** 1,10 ****
XX! CFLAGS=-F -D_POSIX_SOURCE
XX! l=/lib
XX  
XX! shobj = sh1.s sh2.s sh3.s sh4.s sh5.s sh6.s
XX! sh:	$(shobj) sh.h
XX! 	cc -i -o sh -T.  $(shobj)
XX! 	@chmem =18000 sh
XX  
XX! clean:	
XX! 	@rm -f *.bak *.s sh
XX--- 1,17 ----
XX! # Makefile for sh
XX  
XX! CFLAGS	= -O -D_MINIX -D_POSIX_SOURCE -m -wo
XX! O=o
XX  
XX! OBJ	= sh1.$O sh2.$O sh3.$O sh4.$O sh5.$O sh6.$O
XX! 
XX! sh:	$(OBJ)
XX! 	@rm -rf sh
XX! 	@echo Start linking sh
XX! 	@cc -o $@ $(OBJ) >/dev/null
XX! 	@chmem =21000 sh
XX! 
XX! $(OBJ):	sh.h
XX! 
XX! clean:
XX! 	@rm -f sh *.o *.s *.bak core
X/
Xecho x - sh.h.d
Xsed '/^X/s///' > sh.h.d << '/'
XX*** /home/top/ast/minix/1.5/commands/sh/sh.h  crc=11838   7794	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/sh/sh.h  crc=00974  10395	Mon Mar  1 12:39:57 1993
XX***************
XX*** 1,10 ****
XX  /* -------- sh.h -------- */
XX  /*
XX   * shell
XX   */
XX  
XX! #define NULL    0
XX! #define	LINELIM	1000
XX  #define	NPUSH	8	/* limit to input nesting */
XX  
XX  #define	NOFILE	20	/* Number of open files */
XX--- 1,20 ----
XX+ #include <stdlib.h>
XX+ #include <string.h>
XX+ #include <unistd.h>
XX+ #include <fcntl.h>
XX+ 
XX+ /* Need a way to have void used for ANSI, nothing for K&R. */
XX+ #ifndef _ANSI
XX+ #undef _VOID
XX+ #define _VOID
XX+ #endif
XX+ 
XX  /* -------- sh.h -------- */
XX  /*
XX   * shell
XX   */
XX  
XX! #define	LINELIM	2100
XX  #define	NPUSH	8	/* limit to input nesting */
XX  
XX  #define	NOFILE	20	/* Number of open files */
XX***************
XX*** 21,27 ****
XX--- 31,41 ----
XX  /*
XX   * library and system defintions
XX   */
XX+ #ifdef __STDC__
XX+ typedef void xint;	/* base type of jmp_buf, for not broken compilers */
XX+ #else
XX  typedef char * xint;	/* base type of jmp_buf, for broken compilers */
XX+ #endif
XX  
XX  /*
XX   * shell components
XX***************
XX*** 166,206 ****
XX  /*
XX   * other functions
XX   */
XX! int	(*inbuilt())();	/* find builtin command */
XX! char	*rexecve();
XX! char	*space();
XX! char	*getwd();
XX! char	*strsave();
XX! char	*evalstr();
XX! char	*putn();
XX! char	*itoa();
XX! char	*unquote();
XX! struct	var	*lookup();
XX! struct	wdblock	*add2args();
XX! struct	wdblock	*glob();
XX! char	**makenv();
XX! struct	ioword	*addio();
XX! char	**eval();
XX! int	setstatus();
XX! int	waitfor();
XX  
XX! void	onintr();	/* SIGINT handler */
XX  
XX  /*
XX   * error handling
XX   */
XX! void	leave();	/* abort shell (or fail in subshell) */
XX! void	fail();		/* fail but return to process next command */
XX! void	sig();		/* default signal handler */
XX  
XX- /*
XX-  * library functions and system calls
XX-  */
XX- long	lseek();
XX- char	*strncpy();
XX- int	strlen();
XX- extern int errno;
XX- 
XX  /* -------- var.h -------- */
XX  
XX  struct	var {
XX--- 180,231 ----
XX  /*
XX   * other functions
XX   */
XX! #ifdef __STDC__
XX! int (*inbuilt(char *s ))(void);
XX! #else
XX! int (*inbuilt())();
XX! #endif
XX! _PROTOTYPE(char *rexecve , (char *c , char **v , char **envp ));
XX! _PROTOTYPE(char *space , (int n ));
XX! _PROTOTYPE(char *strsave , (char *s , int a ));
XX! _PROTOTYPE(char *evalstr , (char *cp , int f ));
XX! _PROTOTYPE(char *putn , (int n ));
XX! _PROTOTYPE(char *itoa , (unsigned u , int n ));
XX! _PROTOTYPE(char *unquote , (char *as ));
XX! _PROTOTYPE(struct var *lookup , (char *n ));
XX! _PROTOTYPE(int rlookup , (char *n ));
XX! _PROTOTYPE(struct wdblock *glob , (char *cp , struct wdblock *wb ));
XX! _PROTOTYPE(int subgetc , (int ec , int quoted ));
XX! _PROTOTYPE(char **makenv , (void));
XX! _PROTOTYPE(char **eval , (char **ap , int f ));
XX! _PROTOTYPE(int setstatus , (int s ));
XX! _PROTOTYPE(int waitfor , (int lastpid , int canintr ));
XX  
XX! _PROTOTYPE(void onintr , (int s )); /* SIGINT handler */
XX  
XX+ _PROTOTYPE(int newenv , (int f ));
XX+ _PROTOTYPE(void quitenv , (void));
XX+ _PROTOTYPE(void err , (char *s ));
XX+ _PROTOTYPE(int anys , (char *s1 , char *s2 ));
XX+ _PROTOTYPE(int any , (int c , char *s ));
XX+ _PROTOTYPE(void next , (int f ));
XX+ _PROTOTYPE(void setdash , (void));
XX+ _PROTOTYPE(void onecommand , (void));
XX+ _PROTOTYPE(void runtrap , (int i ));
XX+ _PROTOTYPE(void xfree , (char *s ));
XX+ _PROTOTYPE(int letter , (int c ));
XX+ _PROTOTYPE(int digit , (int c ));
XX+ _PROTOTYPE(int letnum , (int c ));
XX+ _PROTOTYPE(int gmatch , (char *s , char *p ));
XX+ 
XX  /*
XX   * error handling
XX   */
XX! _PROTOTYPE(void leave , (void)); /* abort shell (or fail in subshell) */
XX! _PROTOTYPE(void fail , (void));	 /* fail but return to process next command */
XX! _PROTOTYPE(void warn , (char *s ));
XX! _PROTOTYPE(void sig , (int i ));	 /* default signal handler */
XX  
XX  /* -------- var.h -------- */
XX  
XX  struct	var {
XX***************
XX*** 223,239 ****
XX  Extern	struct	var	*shell;		/* shell to interpret command files */
XX  Extern	struct	var	*ifs;		/* field separators */
XX  
XX! struct	var	*lookup(/* char *s */);
XX! void	setval(/* struct var *, char * */);
XX! void	nameval(/* struct var *, char *val, *name */);
XX! void	export(/* struct var * */);
XX! void	ronly(/* struct var * */);
XX! int	isassign(/* char *s */);
XX! int	checkname(/* char *name */);
XX! int	assign(/* char *s, int copyflag */);
XX! void	putvlist(/* int key, int fd */);
XX! int	eqname(/* char *n1, char *n2 */);
XX  
XX  /* -------- io.h -------- */
XX  /* io buffer */
XX  struct iobuf {
XX--- 248,267 ----
XX  Extern	struct	var	*shell;		/* shell to interpret command files */
XX  Extern	struct	var	*ifs;		/* field separators */
XX  
XX! _PROTOTYPE(int yyparse , (void));
XX! _PROTOTYPE(struct var *lookup , (char *n ));
XX! _PROTOTYPE(void setval , (struct var *vp , char *val ));
XX! _PROTOTYPE(void nameval , (struct var *vp , char *val , char *name ));
XX! _PROTOTYPE(void export , (struct var *vp ));
XX! _PROTOTYPE(void ronly , (struct var *vp ));
XX! _PROTOTYPE(int isassign , (char *s ));
XX! _PROTOTYPE(int checkname , (char *cp ));
XX! _PROTOTYPE(int assign , (char *s , int cf ));
XX! _PROTOTYPE(void putvlist , (int f , int out ));
XX! _PROTOTYPE(int eqname , (char *n1 , char *n2 ));
XX  
XX+ _PROTOTYPE(int execute , (struct op *t , int *pin , int *pout , int act ));
XX+ 
XX  /* -------- io.h -------- */
XX  /* io buffer */
XX  struct iobuf {
XX***************
XX*** 258,264 ****
XX  
XX  /* an input generator's state */
XX  struct	io {
XX! 	int	(*iofn)();
XX  	struct	ioarg	*argp;
XX  	int	peekc;
XX  	char	prev;		/* previous character read by readc() */
XX--- 286,292 ----
XX  
XX  /* an input generator's state */
XX  struct	io {
XX! 	int	(*iofn)(_VOID);
XX  	struct	ioarg	*argp;
XX  	int	peekc;
XX  	char	prev;		/* previous character read by readc() */
XX***************
XX*** 278,316 ****
XX  /*
XX   * input generators for IO structure
XX   */
XX! int	nlchar();
XX! int	strchar();
XX! int	qstrchar();
XX! int	filechar();
XX! int	herechar();
XX! int	linechar();
XX! int	gravechar();
XX! int	qgravechar();
XX! int	dolchar();
XX! int	wdchar();
XX  
XX  /*
XX   * IO functions
XX   */
XX! int	eofc();
XX! int	getc();
XX! int	readc();
XX! void	unget();
XX! void	ioecho();
XX! void	prs();
XX! void	putc();
XX! void	prn();
XX! void	closef();
XX! void	closeall();
XX  
XX  /*
XX   * IO control
XX   */
XX! void	pushio(/* struct ioarg arg, int (*gen)() */);
XX! int	remap();
XX! int	openpipe();
XX! void	closepipe();
XX! struct io *setbase(/* struct io * */);
XX  
XX  extern	struct	ioarg	temparg;	/* temporary for PUSHIO */
XX  #define	PUSHIO(what,arg,gen) ((temparg.what = (arg)),pushio(&temparg,(gen)))
XX--- 306,350 ----
XX  /*
XX   * input generators for IO structure
XX   */
XX! _PROTOTYPE(int nlchar , (struct ioarg *ap ));
XX! _PROTOTYPE(int strchar , (struct ioarg *ap ));
XX! _PROTOTYPE(int qstrchar , (struct ioarg *ap ));
XX! _PROTOTYPE(int filechar , (struct ioarg *ap ));
XX! _PROTOTYPE(int herechar , (struct ioarg *ap ));
XX! _PROTOTYPE(int linechar , (struct ioarg *ap ));
XX! _PROTOTYPE(int gravechar , (struct ioarg *ap , struct io *iop ));
XX! _PROTOTYPE(int qgravechar , (struct ioarg *ap , struct io *iop ));
XX! _PROTOTYPE(int dolchar , (struct ioarg *ap ));
XX! _PROTOTYPE(int wdchar , (struct ioarg *ap ));
XX! _PROTOTYPE(void scraphere , (void));
XX! _PROTOTYPE(void freehere , (int area ));
XX! _PROTOTYPE(void gethere , (void));
XX! _PROTOTYPE(void markhere , (char *s , struct ioword *iop ));
XX! _PROTOTYPE(int herein , (char *hname , int xdoll ));
XX! _PROTOTYPE(int run , (struct ioarg *argp , int (*f)(_VOID)));
XX  
XX  /*
XX   * IO functions
XX   */
XX! _PROTOTYPE(int eofc , (void));
XX! _PROTOTYPE(int getc , (int ec ));
XX! _PROTOTYPE(int readc , (void));
XX! _PROTOTYPE(void unget , (int c ));
XX! _PROTOTYPE(void ioecho , (int c ));
XX! _PROTOTYPE(void prs , (char *s ));
XX! _PROTOTYPE(void putc , (int c ));
XX! _PROTOTYPE(void prn , (unsigned u ));
XX! _PROTOTYPE(void closef , (int i ));
XX! _PROTOTYPE(void closeall , (void));
XX  
XX  /*
XX   * IO control
XX   */
XX! _PROTOTYPE(void pushio , (struct ioarg *argp , int (*fn)(_VOID)));
XX! _PROTOTYPE(int remap , (int fd ));
XX! _PROTOTYPE(int openpipe , (int *pv ));
XX! _PROTOTYPE(void closepipe , (int *pv ));
XX! _PROTOTYPE(struct io *setbase , (struct io *ip ));
XX  
XX  extern	struct	ioarg	temparg;	/* temporary for PUSHIO */
XX  #define	PUSHIO(what,arg,gen) ((temparg.what = (arg)),pushio(&temparg,(gen)))
XX***************
XX*** 326,334 ****
XX  	char	*w_words[1];
XX  };
XX  
XX! struct	wdblock	*addword();
XX! struct	wdblock	*newword();
XX! char	**getwords();
XX  #endif
XX  
XX  /* -------- area.h -------- */
XX--- 360,368 ----
XX  	char	*w_words[1];
XX  };
XX  
XX! _PROTOTYPE(struct wdblock *addword , (char *wd , struct wdblock *wb ));
XX! _PROTOTYPE(struct wdblock *newword , (int nw ));
XX! _PROTOTYPE(char **getwords , (struct wdblock *wb ));
XX  #endif
XX  
XX  /* -------- area.h -------- */
XX***************
XX*** 336,350 ****
XX  /*
XX   * storage allocation
XX   */
XX! char	*getcell(/* unsigned size */);
XX! void	garbage();
XX! void	setarea(/* char *obj, int to */);
XX! int	getarea(/* char *obj */);
XX! void	freearea(/* int area */);
XX! void	freecell(/* char *obj */);
XX  
XX  Extern	int	areanum;	/* current allocation area */
XX  
XX  #define	NEW(type) (type *)getcell(sizeof(type))
XX  #define	DELETE(obj)	freecell((char *)obj)
XX- 
XX--- 370,383 ----
XX  /*
XX   * storage allocation
XX   */
XX! _PROTOTYPE(char *getcell , (unsigned nbytes ));
XX! _PROTOTYPE(void garbage , (void));
XX! _PROTOTYPE(void setarea , (char *cp , int a ));
XX! _PROTOTYPE(int getarea , (char *cp ));
XX! _PROTOTYPE(void freearea , (int a ));
XX! _PROTOTYPE(void freecell , (char *cp ));
XX  
XX  Extern	int	areanum;	/* current allocation area */
XX  
XX  #define	NEW(type) (type *)getcell(sizeof(type))
XX  #define	DELETE(obj)	freecell((char *)obj)
X/
Xecho x - sh1.c.d
Xsed '/^X/s///' > sh1.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/sh/sh1.c  crc=61106  14582	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/sh/sh1.c  crc=12010  14884	Wed Dec 23 01:03:53 1992
XX***************
XX*** 29,37 ****
XX  char	shellname[] = "/bin/sh";
XX  char	search[] = ":/bin:/usr/bin";
XX  
XX! void	(*qflag)() = SIG_IGN;
XX  
XX! main(argc, argv)
XX  int argc;
XX  register char **argv;
XX  {
XX--- 29,43 ----
XX  char	shellname[] = "/bin/sh";
XX  char	search[] = ":/bin:/usr/bin";
XX  
XX! _PROTOTYPE(void (*qflag), (int)) = SIG_IGN;
XX  
XX! _PROTOTYPE(int main, (int argc, char **argv ));
XX! _PROTOTYPE(int newfile, (char *s ));
XX! _PROTOTYPE(static char *findeq, (char *cp ));
XX! _PROTOTYPE(static char *cclass, (char *p, int sub ));
XX! _PROTOTYPE(void initarea, (void));
XX! 
XX! int main(argc, argv)
XX  int argc;
XX  register char **argv;
XX  {
XX***************
XX*** 79,84 ****
XX--- 85,91 ----
XX  #else
XX  		setval(prompt, "% ");
XX  #endif
XX+ 
XX  	if (geteuid() == 0) {
XX  		setval(prompt, "# ");
XX  		prompt->status &= ~EXPORT;
XX***************
XX*** 173,178 ****
XX--- 180,186 ----
XX  	}
XX  }
XX  
XX+ void
XX  setdash()
XX  {
XX  	register char *cp, c;
XX***************
XX*** 186,191 ****
XX--- 194,200 ----
XX  	setval(lookup("-"), m);
XX  }
XX  
XX+ int
XX  newfile(s)
XX  register char *s;
XX  {
XX***************
XX*** 204,209 ****
XX--- 213,219 ----
XX  	return(0);
XX  }
XX  
XX+ void
XX  onecommand()
XX  {
XX  	register i;
XX***************
XX*** 270,275 ****
XX--- 280,286 ----
XX  	/* NOTREACHED */
XX  }
XX  
XX+ void
XX  warn(s)
XX  register char *s;
XX  {
XX***************
XX*** 282,287 ****
XX--- 293,299 ----
XX  		leave();
XX  }
XX  
XX+ void
XX  err(s)
XX  char *s;
XX  {
XX***************
XX*** 296,302 ****
XX--- 308,316 ----
XX  	e.iop = e.iobase = iostack;
XX  }
XX  
XX+ int
XX  newenv(f)
XX+ int f;
XX  {
XX  	register struct env *ep;
XX  
XX***************
XX*** 316,321 ****
XX--- 330,336 ----
XX  	return(0);
XX  }
XX  
XX+ void
XX  quitenv()
XX  {
XX  	register struct env *ep;
XX***************
XX*** 360,366 ****
XX  
XX  char *
XX  putn(n)
XX! register n;
XX  {
XX  	return(itoa(n, -1));
XX  }
XX--- 375,381 ----
XX  
XX  char *
XX  putn(n)
XX! register int n;
XX  {
XX  	return(itoa(n, -1));
XX  }
XX***************
XX*** 368,373 ****
XX--- 383,389 ----
XX  char *
XX  itoa(u, n)
XX  register unsigned u;
XX+ int n;
XX  {
XX  	register char *cp;
XX  	static char s[20];
XX***************
XX*** 389,400 ****
XX  	return(cp);
XX  }
XX  
XX  next(f)
XX  {
XX  	PUSHIO(afile, f, filechar);
XX  }
XX  
XX! void onintr()
XX  {
XX  	signal(SIGINT, onintr);
XX  	intr = 1;
XX--- 405,420 ----
XX  	return(cp);
XX  }
XX  
XX+ void
XX  next(f)
XX+ int f;
XX  {
XX  	PUSHIO(afile, f, filechar);
XX  }
XX  
XX! void
XX! onintr(s)
XX! int s;				/* ANSI C requires a parameter */
XX  {
XX  	signal(SIGINT, onintr);
XX  	intr = 1;
XX***************
XX*** 410,427 ****
XX  	}
XX  }
XX  
XX  letter(c)
XX  register c;
XX  {
XX! 	return(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c == '_');
XX  }
XX  
XX  digit(c)
XX  register c;
XX  {
XX  	return(c >= '0' && c <= '9');
XX  }
XX  
XX  letnum(c)
XX  register c;
XX  {
XX--- 430,450 ----
XX  	}
XX  }
XX  
XX+ int
XX  letter(c)
XX  register c;
XX  {
XX! 	return((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_');
XX  }
XX  
XX+ int
XX  digit(c)
XX  register c;
XX  {
XX  	return(c >= '0' && c <= '9');
XX  }
XX  
XX+ int
XX  letnum(c)
XX  register c;
XX  {
XX***************
XX*** 442,447 ****
XX--- 465,471 ----
XX  char *
XX  strsave(s, a)
XX  register char *s;
XX+ int a;
XX  {
XX  	register char *cp, *xp;
XX  
XX***************
XX*** 454,459 ****
XX--- 478,484 ----
XX  	return("");
XX  }
XX  
XX+ void
XX  xfree(s)
XX  register char *s;
XX  {
XX***************
XX*** 463,476 ****
XX  /*
XX   * trap handling
XX   */
XX! void sig(i)
XX! register i;
XX  {
XX  	trapset = i;
XX  	signal(i, sig);
XX  }
XX  
XX! runtrap(i)
XX  {
XX  	char *trapstr;
XX  
XX--- 488,503 ----
XX  /*
XX   * trap handling
XX   */
XX! void
XX! sig(i)
XX! register int i;
XX  {
XX  	trapset = i;
XX  	signal(i, sig);
XX  }
XX  
XX! void runtrap(i)
XX! int i;
XX  {
XX  	char *trapstr;
XX  
XX***************
XX*** 484,491 ****
XX  /* -------- var.c -------- */
XX  /* #include "sh.h" */
XX  
XX- static	char	*findeq();
XX- 
XX  /*
XX   * Find the given name in the dictionary
XX   * and return its value.  If the name was
XX--- 511,516 ----
XX***************
XX*** 609,615 ****
XX  isassign(s)
XX  register char *s;
XX  {
XX! 	if (!letter(*s))
XX  		return(0);
XX  	for (; *s != '='; s++)
XX  		if (*s == 0 || !letnum(*s))
XX--- 634,640 ----
XX  isassign(s)
XX  register char *s;
XX  {
XX! 	if (!letter((int)*s))
XX  		return(0);
XX  	for (; *s != '='; s++)
XX  		if (*s == 0 || !letnum(*s))
XX***************
XX*** 693,706 ****
XX   * Match a pattern as in sh(1).
XX   */
XX  
XX- #define	NULL	0
XX  #define	CMASK	0377
XX  #define	QUOTE	0200
XX  #define	QMASK	(CMASK&~QUOTE)
XX  #define	NOT	'!'	/* might use ^ */
XX  
XX- static	char	*cclass();
XX- 
XX  int
XX  gmatch(s, p)
XX  register char *s, *p;
XX--- 718,728 ----
XX***************
XX*** 757,763 ****
XX  			p++;
XX  		} else
XX  			d = c;
XX! 		if (c == sub || c <= sub && sub <= d)
XX  			found = !not;
XX  	} while (*++p != ']');
XX  	return(found? p+1: (char *)NULL);
XX--- 779,785 ----
XX  			p++;
XX  		} else
XX  			d = c;
XX! 		if (c == sub || (c <= sub && sub <= d))
XX  			found = !not;
XX  	} while (*++p != ']');
XX  	return(found? p+1: (char *)NULL);
XX***************
XX*** 772,778 ****
XX  #define	ALIGN (sizeof(int)-1)
XX  
XX  /* #include "area.h" */
XX- #define	NULL	0
XX  
XX  struct region {
XX  	struct	region *next;
XX--- 794,799 ----
XX***************
XX*** 787,795 ****
XX  static	struct region *areabot;		/* bottom of area */
XX  static	struct region *areatop;		/* top of area */
XX  static	struct region *areanxt;		/* starting point of scan */
XX- char	*sbrk();
XX- char	*brk();
XX  
XX  initarea()
XX  {
XX  	while ((int)sbrk(0) & ALIGN)
XX--- 808,815 ----
XX  static	struct region *areabot;		/* bottom of area */
XX  static	struct region *areatop;		/* top of area */
XX  static	struct region *areanxt;		/* starting point of scan */
XX  
XX+ void
XX  initarea()
XX  {
XX  	while ((int)sbrk(0) & ALIGN)
X/
Xecho x - sh2.c.d
Xsed '/^X/s///' > sh2.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/sh/sh2.c  crc=57068  11665	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/sh/sh2.c  crc=19964  12605	Wed Dec 23 01:03:53 1992
XX***************
XX*** 42,69 ****
XX  #define	SYNTAXERR	zzerr()
XX  static	int	startl;
XX  static	int	peeksym;
XX- static	void	zzerr();
XX- static	void	word();
XX- static	char	**copyw();
XX- static	struct	op *block(), *namelist(), *list(), *newtp();
XX- static	struct	op *pipeline(), *andor(), *command();
XX- static	struct	op *nested(), *simple(), *c_list();
XX- static	struct	op *dogroup(), *thenpart(), *casepart(), *caselist();
XX- static	struct	op *elsepart();
XX- static	char	**wordlist(), **pattern();
XX- static	void	musthave();
XX- static	int	yylex();
XX- static	struct ioword *io();
XX- static	struct ioword **copyio();
XX- static	char	*tree();
XX- static	void	diag();
XX  static	int	nlseen;
XX  static	int	iounit = IODEFAULT;
XX- static	struct	op	*tp;
XX- struct	op	*newtp();
XX  
XX  static	YYSTYPE	yylval;
XX  
XX  int
XX  yyparse()
XX  {
XX--- 42,84 ----
XX  #define	SYNTAXERR	zzerr()
XX  static	int	startl;
XX  static	int	peeksym;
XX  static	int	nlseen;
XX  static	int	iounit = IODEFAULT;
XX  
XX  static	YYSTYPE	yylval;
XX  
XX+ _PROTOTYPE(static struct op *pipeline, (int cf ));
XX+ _PROTOTYPE(static struct op *andor, (void));
XX+ _PROTOTYPE(static struct op *c_list, (void));
XX+ _PROTOTYPE(static int synio, (int cf ));
XX+ _PROTOTYPE(static void musthave, (int c, int cf ));
XX+ _PROTOTYPE(static struct op *simple, (void));
XX+ _PROTOTYPE(static struct op *nested, (int type, int mark ));
XX+ _PROTOTYPE(static struct op *command, (int cf ));
XX+ _PROTOTYPE(static struct op *dogroup, (int onlydone ));
XX+ _PROTOTYPE(static struct op *thenpart, (void));
XX+ _PROTOTYPE(static struct op *elsepart, (void));
XX+ _PROTOTYPE(static struct op *caselist, (void));
XX+ _PROTOTYPE(static struct op *casepart, (void));
XX+ _PROTOTYPE(static char **pattern, (void));
XX+ _PROTOTYPE(static char **wordlist, (void));
XX+ _PROTOTYPE(static struct op *list, (struct op *t1, struct op *t2 ));
XX+ _PROTOTYPE(static struct op *block, (int type, struct op *t1, struct op *t2, char **wp ));
XX+ _PROTOTYPE(static struct op *newtp, (void));
XX+ _PROTOTYPE(static struct op *namelist, (struct op *t ));
XX+ _PROTOTYPE(static char **copyw, (void));
XX+ _PROTOTYPE(static void word, (char *cp ));
XX+ _PROTOTYPE(static struct ioword **copyio, (void));
XX+ _PROTOTYPE(static struct ioword *io, (int u, int f, char *cp ));
XX+ _PROTOTYPE(static void zzerr, (void));
XX+ _PROTOTYPE(void yyerror, (char *s ));
XX+ _PROTOTYPE(static int yylex, (int cf ));
XX+ _PROTOTYPE(int collect, (int c, int c1 ));
XX+ _PROTOTYPE(int dual, (int c ));
XX+ _PROTOTYPE(static void diag, (int ec ));
XX+ _PROTOTYPE(static char *tree, (unsigned size ));
XX+ _PROTOTYPE(void printf, (char *s ));
XX+ 
XX  int
XX  yyparse()
XX  {
XX***************
XX*** 126,132 ****
XX  	if (t != NULL) {
XX  		if((peeksym = yylex(0)) == '&')
XX  			t = block(TASYNC, t, NOBLOCK, NOWORDS);
XX! 		while ((c = yylex(0)) == ';' || c == '&' || multiline && c == '\n') {
XX  			if ((p = andor()) == NULL)
XX  				return(t);
XX  			if((peeksym = yylex(0)) == '&')
XX--- 141,147 ----
XX  	if (t != NULL) {
XX  		if((peeksym = yylex(0)) == '&')
XX  			t = block(TASYNC, t, NOBLOCK, NOWORDS);
XX! 		while ((c = yylex(0)) == ';' || c == '&' || (multiline && c == '\n')) {
XX  			if ((p = andor()) == NULL)
XX  				return(t);
XX  			if((peeksym = yylex(0)) == '&')
XX***************
XX*** 214,220 ****
XX  command(cf)
XX  int cf;
XX  {
XX- 	register struct ioword *io;
XX  	register struct op *t;
XX  	struct wdblock *iosave;
XX  	register int c;
XX--- 229,234 ----
XX***************
XX*** 253,259 ****
XX  		multiline++;
XX  		t->words = wordlist();
XX  		if ((c = yylex(0)) != '\n' && c != ';')
XX! 			SYNTAXERR;
XX  		t->left = dogroup(0);
XX  		multiline--;
XX  		break;
XX--- 267,273 ----
XX  		multiline++;
XX  		t->words = wordlist();
XX  		if ((c = yylex(0)) != '\n' && c != ';')
XX! 			peeksym = c;
XX  		t->left = dogroup(0);
XX  		multiline--;
XX  		break;
XX***************
XX*** 365,371 ****
XX  caselist()
XX  {
XX  	register struct op *t;
XX- 	register int c;
XX  
XX  	t = NULL;
XX  	while ((peeksym = yylex(CONTIN)) != ESAC)
XX--- 379,384 ----
XX***************
XX*** 377,383 ****
XX  casepart()
XX  {
XX  	register struct op *t;
XX- 	register int c;
XX  
XX  	t = newtp();
XX  	t->type = TPAT;
XX--- 390,395 ----
XX***************
XX*** 438,443 ****
XX--- 450,456 ----
XX  
XX  static struct op *
XX  block(type, t1, t2, wp)
XX+ int type;
XX  struct op *t1, *t2;
XX  char **wp;
XX  {
XX***************
XX*** 478,483 ****
XX--- 491,497 ----
XX  	0,
XX  };
XX  
XX+ int
XX  rlookup(n)
XX  register char *n;
XX  {
XX***************
XX*** 555,560 ****
XX--- 569,576 ----
XX  
XX  static struct ioword *
XX  io(u, f, cp)
XX+ int u;
XX+ int f;
XX  char *cp;
XX  {
XX  	register struct ioword *iop;
XX***************
XX*** 573,578 ****
XX--- 589,595 ----
XX  	yyerror("syntax error");
XX  }
XX  
XX+ void
XX  yyerror(s)
XX  char *s;
XX  {
XX***************
XX*** 775,780 ****
XX--- 792,798 ----
XX  
XX  /* VARARGS1 */
XX  /* ARGSUSED */
XX+ void 
XX  printf(s)	/* yyparse calls it */
XX  char *s;
XX  {
X/
Xecho x - sh3.c.d
Xsed '/^X/s///' > sh3.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/sh/sh3.c  crc=44130  18149	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/sh/sh3.c  crc=14204  19624	Wed Dec 23 01:03:54 1992
XX***************
XX*** 6,11 ****
XX--- 6,13 ----
XX  #include <stddef.h>
XX  #include <time.h>
XX  #include <sys/times.h>
XX+ #include <sys/stat.h>
XX+ #include <sys/wait.h>
XX  #undef NULL
XX  #include "sh.h"
XX  
XX***************
XX*** 36,47 ****
XX  };
XX  #define	NSIGNAL (sizeof(signame)/sizeof(signame[0]))
XX  
XX- static	struct	op *findcase();
XX- static	void	brkset();
XX- static	void	echo();
XX- static	int	forkexec();
XX- static	int	parent();
XX  
XX  int
XX  execute(t, pin, pout, act)
XX  register struct op *t;
XX--- 38,77 ----
XX  };
XX  #define	NSIGNAL (sizeof(signame)/sizeof(signame[0]))
XX  
XX  
XX+ _PROTOTYPE(static int forkexec, (struct op *t, int *pin, int *pout, int act, char **wp, int *pforked ));
XX+ _PROTOTYPE(static int parent, (void));
XX+ _PROTOTYPE(int iosetup, (struct ioword *iop, int pipein, int pipeout ));
XX+ _PROTOTYPE(static void echo, (char **wp ));
XX+ _PROTOTYPE(static struct op **find1case, (struct op *t, char *w ));
XX+ _PROTOTYPE(static struct op *findcase, (struct op *t, char *w ));
XX+ _PROTOTYPE(static void brkset, (struct brkcon *bc ));
XX+ _PROTOTYPE(int dolabel, (void));
XX+ _PROTOTYPE(int dochdir, (struct op *t ));
XX+ _PROTOTYPE(int doshift, (struct op *t ));
XX+ _PROTOTYPE(int dologin, (struct op *t ));
XX+ _PROTOTYPE(int doumask, (struct op *t ));
XX+ _PROTOTYPE(int doexec, (struct op *t ));
XX+ _PROTOTYPE(int dodot, (struct op *t ));
XX+ _PROTOTYPE(int dowait, (struct op *t ));
XX+ _PROTOTYPE(int doread, (struct op *t ));
XX+ _PROTOTYPE(int doeval, (struct op *t ));
XX+ _PROTOTYPE(int dotrap, (struct op *t ));
XX+ _PROTOTYPE(int getsig, (char *s ));
XX+ _PROTOTYPE(void setsig, (int n, void (*f)()));
XX+ _PROTOTYPE(int getn, (char *as ));
XX+ _PROTOTYPE(int dobreak, (struct op *t ));
XX+ _PROTOTYPE(int docontinue, (struct op *t ));
XX+ _PROTOTYPE(static int brkcontin, (char *cp, int val ));
XX+ _PROTOTYPE(int doexit, (struct op *t ));
XX+ _PROTOTYPE(int doexport, (struct op *t ));
XX+ _PROTOTYPE(int doreadonly, (struct op *t ));
XX+ _PROTOTYPE(static void rdexp, (char **wp, void (*f)(), int key));
XX+ _PROTOTYPE(static void badid, (char *s ));
XX+ _PROTOTYPE(int doset, (struct op *t ));
XX+ _PROTOTYPE(void varput, (char *s, int out ));
XX+ _PROTOTYPE(int dotimes, (void));
XX+ 
XX  int
XX  execute(t, pin, pout, act)
XX  register struct op *t;
XX***************
XX*** 211,217 ****
XX  int *pforked;
XX  {
XX  	int i, rv, (*shcom)();
XX- 	int doexec();
XX  	register int f;
XX  	char *cp;
XX  	struct ioword **iopp;
XX--- 241,246 ----
XX***************
XX*** 331,336 ****
XX--- 360,366 ----
XX   * 0< 1> are ignored as required
XX   * within pipelines.
XX   */
XX+ int
XX  iosetup(iop, pipein, pipeout)
XX  register struct ioword *iop;
XX  int pipein, pipeout;
XX***************
XX*** 351,357 ****
XX  			return(1);
XX  	}
XX  	if (iop->io_flag & IODUP) {
XX! 		if (cp[1] || !digit(*cp) && *cp != '-') {
XX  			prs(cp);
XX  			err(": illegal >& argument");
XX  			return(1);
XX--- 381,387 ----
XX  			return(1);
XX  	}
XX  	if (iop->io_flag & IODUP) {
XX! 		if (cp[1] || (!digit(*cp) && *cp != '-')) {
XX  			prs(cp);
XX  			err(": illegal >& argument");
XX  			return(1);
XX***************
XX*** 517,523 ****
XX  				intr = 0;
XX  		} else {
XX  			if (exstat == 0) exstat = rv;
XX! 			onintr();
XX  		}
XX  	return(rv);
XX  }
XX--- 547,553 ----
XX  				intr = 0;
XX  		} else {
XX  			if (exstat == 0) exstat = rv;
XX! 			onintr(0);
XX  		}
XX  	return(rv);
XX  }
XX***************
XX*** 543,549 ****
XX  	register int i;
XX  	register char *sp, *tp;
XX  	int eacces = 0, asis = 0;
XX- 	extern int errno;
XX  
XX  	sp = any('/', c)? "": path->value;
XX  	asis = *sp == '\0';
XX--- 573,578 ----
XX***************
XX*** 587,592 ****
XX--- 616,622 ----
XX   * Run the command produced by generator `f'
XX   * applied to stream `arg'.
XX   */
XX+ int
XX  run(argp, f)
XX  struct ioarg *argp;
XX  int (*f)();
XX***************
XX*** 629,643 ****
XX   * built-in commands: doX
XX   */
XX  
XX! static	void	rdexp();
XX! static	void	badid();
XX! static	int	brkcontin();
XX! 
XX  dolabel()
XX  {
XX  	return(0);
XX  }
XX  
XX  dochdir(t)
XX  register struct op *t;
XX  {
XX--- 659,671 ----
XX   * built-in commands: doX
XX   */
XX  
XX! int
XX  dolabel()
XX  {
XX  	return(0);
XX  }
XX  
XX+ int
XX  dochdir(t)
XX  register struct op *t;
XX  {
XX***************
XX*** 654,659 ****
XX--- 682,688 ----
XX  	return(1);
XX  }
XX  
XX+ int
XX  doshift(t)
XX  register struct op *t;
XX  {
XX***************
XX*** 674,679 ****
XX--- 703,709 ----
XX  /*
XX   * execute login and newgrp directly
XX   */
XX+ int
XX  dologin(t)
XX  struct op *t;
XX  {
XX***************
XX*** 688,693 ****
XX--- 718,724 ----
XX  	return(1);
XX  }
XX  
XX+ int
XX  doumask(t)
XX  register struct op *t;
XX  {
XX***************
XX*** 708,713 ****
XX--- 739,745 ----
XX  	return(0);
XX  }
XX  
XX+ int
XX  doexec(t)
XX  register struct op *t;
XX  {
XX***************
XX*** 729,734 ****
XX--- 761,767 ----
XX  	return(1);
XX  }
XX  
XX+ int
XX  dodot(t)
XX  struct op *t;
XX  {
XX***************
XX*** 758,763 ****
XX--- 791,797 ----
XX  	return(-1);
XX  }
XX  
XX+ int
XX  dowait(t)
XX  struct op *t;
XX  {
XX***************
XX*** 774,779 ****
XX--- 808,814 ----
XX  	return(0);
XX  }
XX  
XX+ int
XX  doread(t)
XX  struct op *t;
XX  {
XX***************
XX*** 789,795 ****
XX  		for (cp = e.linep; !nl && cp < elinep-1; cp++)
XX  			if ((nb = read(0, cp, sizeof(*cp))) != sizeof(*cp) ||
XX  			    (nl = (*cp == '\n')) ||
XX! 			    wp[1] && any(*cp, ifs->value))
XX  				break;
XX  		*cp = 0;
XX  		if (nb <= 0)
XX--- 824,830 ----
XX  		for (cp = e.linep; !nl && cp < elinep-1; cp++)
XX  			if ((nb = read(0, cp, sizeof(*cp))) != sizeof(*cp) ||
XX  			    (nl = (*cp == '\n')) ||
XX! 			    (wp[1] && any(*cp, ifs->value)))
XX  				break;
XX  		*cp = 0;
XX  		if (nb <= 0)
XX***************
XX*** 799,816 ****
XX  	return(nb <= 0);
XX  }
XX  
XX  doeval(t)
XX  register struct op *t;
XX  {
XX- 	int wdchar();
XX- 
XX  	return(RUN(awordlist, t->words+1, wdchar));
XX  }
XX  
XX  dotrap(t)
XX  register struct op *t;
XX  {
XX- 	register char *s;
XX  	register int  n, i;
XX  	register int  resetsig;
XX  
XX--- 834,850 ----
XX  	return(nb <= 0);
XX  }
XX  
XX+ int
XX  doeval(t)
XX  register struct op *t;
XX  {
XX  	return(RUN(awordlist, t->words+1, wdchar));
XX  }
XX  
XX+ int
XX  dotrap(t)
XX  register struct op *t;
XX  {
XX  	register int  n, i;
XX  	register int  resetsig;
XX  
XX***************
XX*** 849,854 ****
XX--- 883,889 ----
XX  	return(0);
XX  }
XX  
XX+ int
XX  getsig(s)
XX  char *s;
XX  {
XX***************
XX*** 861,869 ****
XX  	return(n);
XX  }
XX  
XX  setsig(n, f)
XX  register n;
XX! int (*f)();
XX  {
XX  	if (n == 0)
XX  		return;
XX--- 896,905 ----
XX  	return(n);
XX  }
XX  
XX+ void
XX  setsig(n, f)
XX  register n;
XX! _PROTOTYPE(void (*f), (int));
XX  {
XX  	if (n == 0)
XX  		return;
XX***************
XX*** 873,878 ****
XX--- 909,915 ----
XX  	}
XX  }
XX  
XX+ int
XX  getn(as)
XX  char *as;
XX  {
XX***************
XX*** 894,905 ****
XX--- 931,944 ----
XX  	return(n*m);
XX  }
XX  
XX+ int
XX  dobreak(t)
XX  struct op *t;
XX  {
XX  	return(brkcontin(t->words[1], 1));
XX  }
XX  
XX+ int
XX  docontinue(t)
XX  struct op *t;
XX  {
XX***************
XX*** 909,914 ****
XX--- 948,954 ----
XX  static int
XX  brkcontin(cp, val)
XX  register char *cp;
XX+ int val;
XX  {
XX  	register struct brkcon *bc;
XX  	register nl;
XX***************
XX*** 930,935 ****
XX--- 970,976 ----
XX  	/* NOTREACHED */
XX  }
XX  
XX+ int
XX  doexit(t)
XX  struct op *t;
XX  {
XX***************
XX*** 939,946 ****
XX--- 980,989 ----
XX  	if ((cp = t->words[1]) != NULL)
XX  		exstat = getn(cp);
XX  	leave();
XX+ 	/* NOTREACHED */
XX  }
XX  
XX+ int
XX  doexport(t)
XX  struct op *t;
XX  {
XX***************
XX*** 948,953 ****
XX--- 991,997 ----
XX  	return(0);
XX  }
XX  
XX+ int
XX  doreadonly(t)
XX  struct op *t;
XX  {
XX***************
XX*** 979,984 ****
XX--- 1023,1029 ----
XX  	err(": bad identifier");
XX  }
XX  
XX+ int
XX  doset(t)
XX  register struct op *t;
XX  {
XX***************
XX*** 1024,1031 ****
XX--- 1069,1078 ----
XX  	return(0);
XX  }
XX  
XX+ void
XX  varput(s, out)
XX  register char *s;
XX+ int out;
XX  {
XX  	if (letnum(*s)) {
XX  		write(out, s, strlen(s));
XX***************
XX*** 1037,1042 ****
XX--- 1084,1090 ----
XX  #define	SECS	60L
XX  #define	MINS	3600L
XX  
XX+ int
XX  dotimes()
XX  {
XX  	struct tms tbuf;
XX***************
XX*** 1051,1056 ****
XX--- 1099,1105 ----
XX  	prs("m");
XX  	prn((int)((tbuf.tms_cstime % MINS) / SECS));
XX  	prs("s\n");
XX+ 	return(0);
XX  }
XX  
XX  struct	builtin {
X/
Xecho x - sh4.c.d
Xsed '/^X/s///' > sh4.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/sh/sh4.c  crc=27955  12783	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/sh/sh4.c  crc=25062  13469	Wed Dec 23 01:03:54 1992
XX***************
XX*** 20,33 ****
XX   * glob
XX   */
XX  
XX! static	char	*blank();
XX! static	int	grave();
XX! static	int	expand();
XX! static	int	dollar();
XX  
XX  char **
XX  eval(ap, f)
XX  register char **ap;
XX  {
XX  	struct wdblock *wb;
XX  	char **wp;
XX--- 20,43 ----
XX   * glob
XX   */
XX  
XX! _PROTOTYPE(static int expand, (char *cp, struct wdblock **wbp, int f ));
XX! _PROTOTYPE(static char *blank, (int f ));
XX! _PROTOTYPE(static int dollar, (int quoted ));
XX! _PROTOTYPE(static int grave, (int quoted ));
XX! _PROTOTYPE(void globname, (char *we, char *pp ));
XX! _PROTOTYPE(static char *generate, (char *start1, char *end1, char *middle, char *end ));
XX! _PROTOTYPE(static int anyspcl, (struct wdblock *wb ));
XX! _PROTOTYPE(static int xstrcmp, (char *p1, char *p2 ));
XX! _PROTOTYPE(void glob0, (char *a0, unsigned int a1, int a2, int (*a3)(char *, char *)));
XX! _PROTOTYPE(void glob1, (char *base, char *lim ));
XX! _PROTOTYPE(void glob2, (char *i, char *j ));
XX! _PROTOTYPE(void glob3, (char *i, char *j, char *k ));
XX! _PROTOTYPE(char *memcopy, (char *ato, char *from, int nb ));
XX  
XX  char **
XX  eval(ap, f)
XX  register char **ap;
XX+ int f;
XX  {
XX  	struct wdblock *wb;
XX  	char **wp;
XX***************
XX*** 99,104 ****
XX--- 109,115 ----
XX  expand(cp, wbp, f)
XX  register char *cp;
XX  register struct wdblock **wbp;
XX+ int f;
XX  {
XX  	jmp_buf ev;
XX  
XX***************
XX*** 138,143 ****
XX--- 149,155 ----
XX   */
XX  static char *
XX  blank(f)
XX+ int f;
XX  {
XX  	register c, c1;
XX  	register char *sp;
XX***************
XX*** 180,187 ****
XX  	for (;;) {
XX  		c = subgetc('"', foundequals);
XX  		if (c == 0 ||
XX! 		    f & DOBLANK && any(c, ifs->value) ||
XX! 		    !INSUB() && any(c, "\"'")) {
XX  		        scanequals = 0;
XX  			unget(c);
XX  			if (any(c, "\"'"))
XX--- 192,199 ----
XX  	for (;;) {
XX  		c = subgetc('"', foundequals);
XX  		if (c == 0 ||
XX! 		    f & (DOBLANK && any(c, ifs->value)) ||
XX! 		    (!INSUB() && any(c, "\"'"))) {
XX  		        scanequals = 0;
XX  			unget(c);
XX  			if (any(c, "\"'"))
XX***************
XX*** 407,415 ****
XX  
XX  static	struct wdblock	*cl, *nl;
XX  static	char	spcl[] = "[?*";
XX- static	int	xstrcmp();
XX- static	char	*generate();
XX- static	int	anyspcl();
XX  
XX  struct wdblock *
XX  glob(cp, wb)
XX--- 419,424 ----
XX***************
XX*** 457,462 ****
XX--- 466,472 ----
XX  	return(wb);
XX  }
XX  
XX+ void
XX  globname(we, pp)
XX  char *we;
XX  register char *pp;
XX***************
XX*** 563,575 ****
XX  /* -------- word.c -------- */
XX  /* #include "sh.h" */
XX  /* #include "word.h" */
XX- char *memcpy();
XX  
XX  #define	NSTART	16	/* default number of words to allow for initially */
XX  
XX  struct wdblock *
XX  newword(nw)
XX! register nw;
XX  {
XX  	register struct wdblock *wb;
XX  
XX--- 573,584 ----
XX  /* -------- word.c -------- */
XX  /* #include "sh.h" */
XX  /* #include "word.h" */
XX  
XX  #define	NSTART	16	/* default number of words to allow for initially */
XX  
XX  struct wdblock *
XX  newword(nw)
XX! register int nw;
XX  {
XX  	register struct wdblock *wb;
XX  
XX***************
XX*** 591,597 ****
XX  		wb = newword(NSTART);
XX  	if ((nw = wb->w_nword) >= wb->w_bsize) {
XX  		wb2 = newword(nw * 2);
XX! 		memcpy((char *)wb2->w_words, (char *)wb->w_words, nw*sizeof(char *));
XX  		wb2->w_nword = nw;
XX  		DELETE(wb);
XX  		wb = wb2;
XX--- 600,606 ----
XX  		wb = newword(NSTART);
XX  	if ((nw = wb->w_nword) >= wb->w_bsize) {
XX  		wb2 = newword(nw * 2);
XX! 		memcopy((char *)wb2->w_words, (char *)wb->w_words, nw*sizeof(char *));
XX  		wb2->w_nword = nw;
XX  		DELETE(wb);
XX  		wb = wb2;
XX***************
XX*** 614,644 ****
XX  		return((char **)NULL);
XX  	}
XX  	wd = (char **) space(nb = sizeof(*wd) * wb->w_nword);
XX! 	memcpy((char *)wd, (char *)wb->w_words, nb);
XX  	DELETE(wb);	/* perhaps should done by caller */
XX  	return(wd);
XX  }
XX  
XX! int	(*func)();
XX  int	globv;
XX  
XX  glob0(a0, a1, a2, a3)
XX  char *a0;
XX  unsigned a1;
XX  int a2;
XX! int (*a3)();
XX  {
XX  	func = a3;
XX  	globv = a2;
XX  	glob1(a0, a0 + a1 * a2);
XX  }
XX  
XX  glob1(base, lim)
XX  char *base, *lim;
XX  {
XX  	register char *i, *j;
XX  	int v2;
XX- 	char **k;
XX  	char *lptr, *hptr;
XX  	int c;
XX  	unsigned n;
XX--- 623,654 ----
XX  		return((char **)NULL);
XX  	}
XX  	wd = (char **) space(nb = sizeof(*wd) * wb->w_nword);
XX! 	memcopy((char *)wd, (char *)wb->w_words, nb);
XX  	DELETE(wb);	/* perhaps should done by caller */
XX  	return(wd);
XX  }
XX  
XX! _PROTOTYPE(int (*func), (char *, char *));
XX  int	globv;
XX  
XX+ void
XX  glob0(a0, a1, a2, a3)
XX  char *a0;
XX  unsigned a1;
XX  int a2;
XX! _PROTOTYPE(int (*a3), (char *, char *));
XX  {
XX  	func = a3;
XX  	globv = a2;
XX  	glob1(a0, a0 + a1 * a2);
XX  }
XX  
XX+ void
XX  glob1(base, lim)
XX  char *base, *lim;
XX  {
XX  	register char *i, *j;
XX  	int v2;
XX  	char *lptr, *hptr;
XX  	int c;
XX  	unsigned n;
XX***************
XX*** 704,709 ****
XX--- 714,720 ----
XX  	}
XX  }
XX  
XX+ void
XX  glob2(i, j)
XX  char *i, *j;
XX  {
XX***************
XX*** 720,725 ****
XX--- 731,737 ----
XX  	} while(--m);
XX  }
XX  
XX+ void
XX  glob3(i, j, k)
XX  char *i, *j, *k;
XX  {
XX***************
XX*** 740,746 ****
XX  }
XX  
XX  char *
XX! memcpy(ato, from, nb)
XX  register char *ato, *from;
XX  register int nb;
XX  {
XX--- 752,758 ----
XX  }
XX  
XX  char *
XX! memcopy(ato, from, nb)
XX  register char *ato, *from;
XX  register int nb;
XX  {
X/
Xecho x - sh5.c.d
Xsed '/^X/s///' > sh5.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/sh/sh5.c  crc=50962  10861	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/sh/sh5.c  crc=20101  11073	Tue Jan 12 21:37:16 1993
XX***************
XX*** 18,23 ****
XX--- 18,28 ----
XX  
XX  struct ioarg temparg = {0, 0, 0, AFID_NOBUF, 0};
XX  
XX+ _PROTOTYPE(static void readhere, (char **name, char *s, int ec ));
XX+ _PROTOTYPE(void pushio, (struct ioarg *argp, int (*fn)()));
XX+ _PROTOTYPE(static int xxchar, (struct ioarg *ap ));
XX+ _PROTOTYPE(void tempname, (char *tname ));
XX+ 
XX  int
XX  getc(ec)
XX  register int ec;
XX***************
XX*** 32,38 ****
XX  		return(c);
XX  	}
XX  	c = readc();
XX!  	if (ec != '\'' && ec != '`' && e.iop->task != XGRAVE) {
XX  		if(c == '\\') {
XX  			c = readc();
XX  			if (c == '\n' && ec != '\"')
XX--- 37,43 ----
XX  		return(c);
XX  	}
XX  	c = readc();
XX!  	if (ec != '\'' && e.iop->task != XGRAVE) {
XX  		if(c == '\\') {
XX  			c = readc();
XX  			if (c == '\n' && ec != '\"')
XX***************
XX*** 45,50 ****
XX--- 50,56 ----
XX  
XX  void
XX  unget(c)
XX+ int c;
XX  {
XX  	if (e.iop >= e.iobase)
XX  		e.iop->peekc = c;
XX***************
XX*** 206,213 ****
XX   * Return the characters of a list of words,
XX   * producing a space between them.
XX   */
XX- static	int	xxchar();
XX- 
XX  int
XX  dolchar(ap)
XX  register struct ioarg *ap;
XX--- 212,217 ----
XX***************
XX*** 274,280 ****
XX  	register int i;
XX  	char c;
XX  	struct iobuf *bp = ap->afbuf;
XX- 	extern int errno;
XX  
XX  	if (ap->afid != AFID_NOBUF) {
XX  	  if ((i = ap->afid != bp->id) || bp->bufp == bp->ebufp) {
XX--- 278,283 ----
XX***************
XX*** 403,409 ****
XX  
XX  void
XX  closef(i)
XX! register i;
XX  {
XX  	if (i > 2)
XX  		close(i);
XX--- 406,412 ----
XX  
XX  void
XX  closef(i)
XX! register int i;
XX  {
XX  	if (i > 2)
XX  		close(i);
XX***************
XX*** 482,489 ****
XX  static	struct here *inhere;		/* list of hear docs while parsing */
XX  static	struct here *acthere;		/* list of active here documents */
XX  
XX! static	void readhere();
XX! 
XX  markhere(s, iop)
XX  register char *s;
XX  struct ioword *iop;
XX--- 485,491 ----
XX  static	struct here *inhere;		/* list of hear docs while parsing */
XX  static	struct here *acthere;		/* list of active here documents */
XX  
XX! void
XX  markhere(s, iop)
XX  register char *s;
XX  struct ioword *iop;
XX***************
XX*** 516,521 ****
XX--- 518,524 ----
XX  	h->h_dosub = iop->io_flag & IOXHERE;
XX  }
XX  
XX+ void
XX  gethere()
XX  {
XX  	register struct here *h, *hp;
XX***************
XX*** 536,541 ****
XX--- 539,545 ----
XX  readhere(name, s, ec)
XX  char **name;
XX  register char *s;
XX+ int ec;
XX  {
XX  	int tf;
XX  	char tname[30];
XX***************
XX*** 585,592 ****
XX--- 589,598 ----
XX   * open here temp file.
XX   * if unquoted here, expand here temp file into second temp file.
XX   */
XX+ int
XX  herein(hname, xdoll)
XX  char *hname;
XX+ int xdoll;
XX  {
XX  	register hf, tf;
XX  
XX***************
XX*** 621,626 ****
XX--- 627,633 ----
XX  		return (hf);
XX  }
XX  
XX+ void
XX  scraphere()
XX  {
XX  	register struct here *h;
XX***************
XX*** 633,638 ****
XX--- 640,646 ----
XX  }
XX  
XX  /* unlink here temp files before a freearea(area) */
XX+ void
XX  freehere(area)
XX  int area;
XX  {
XX***************
XX*** 640,646 ****
XX  
XX  	hl = NULL;
XX  	for (h = acthere; h != NULL; h = h->h_next)
XX! 		if (getarea(h) >= area) {
XX  			if (h->h_iop->io_name != NULL)
XX  				unlink(h->h_iop->io_name);
XX  			if (hl == NULL)
XX--- 648,654 ----
XX  
XX  	hl = NULL;
XX  	for (h = acthere; h != NULL; h = h->h_next)
XX! 		if (getarea((char *) h) >= area) {
XX  			if (h->h_iop->io_name != NULL)
XX  				unlink(h->h_iop->io_name);
XX  			if (hl == NULL)
XX***************
XX*** 651,656 ****
XX--- 659,665 ----
XX  			hl = h;
XX  }
XX  
XX+ void
XX  tempname(tname)
XX  char *tname;
XX  {
X/
/
