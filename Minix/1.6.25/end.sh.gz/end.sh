echo x - Makefile
sed '/^X/s///' > Makefile << '/'
XCFLAGS= -c -O -D_MINIX -D_POSIX_SOURCE
X
Xall:
X	@$(CC) $(CFLAGS) *.s
X
Xclean:	
X	@rm -f *.o *.bak
/
echo x - edata.s
sed '/^X/s///' > edata.s << '/'
X.sect .text
X.sect .rom
X.sect .data
X.sect .bss
X.define _edata
X.sect .data
X	.align 2
X_edata:
/
echo x - em_end.s
sed '/^X/s///' > em_end.s << '/'
X.sect .text
X.sect .rom
X.sect .data
X.sect .bss
X.define endtext,enddata,endbss,__end
X.sect .text
X	.align 2
X.sect .rom
X	.align 2
X.sect .data
X	.align 2
X.sect .bss
X	.align 2
X.sect .end ! only for declaration of _end, __end and endbss.
X
X	.sect .text
Xendtext:
X	.sect .data
Xenddata:
X	.sect .end
X__end:
Xendbss:
/
echo x - end.s
sed '/^X/s///' > end.s << '/'
X.sect .text
X.sect .rom
X.sect .data
X.sect .bss
X.define _end
X.sect .end ! only for declaration of _end, __end and endbss.
X_end:
/
echo x - etext.s
sed '/^X/s///' > etext.s << '/'
X.sect .text
X.sect .rom
X.sect .data
X.sect .bss
X.define _etext
X.sect .text
X	.align 2
X	.sect .text
X_etext:
/
