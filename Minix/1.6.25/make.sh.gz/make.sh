echo x - make.cd
sed '/^X/s///' > make.cd << '/'
Xecho x - Makefile.d
Xsed '/^X/s///' > Makefile.d << '/'
XX*** /home/top/ast/minix/1.5/commands/make/Makefile  crc=26665    218	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/make/Makefile  crc=52351    320	Sat Jan 30 20:12:17 1993
XX***************
XX*** 1,13 ****
XX! # Makefile for make!  (Minix PC)
XX  
XX! CFLAGS = -Dunix -DMINIXPC 
XX  
XX! OBJS =	check.s input.s macro.s main.s make.s reader.s rules.s
XX  
XX! make :	$(OBJS)
XX! 	$(CC) -i -o make $(OBJS)
XX   
XX! clean:	
XX! 	@rm -f *.s *.bak make core
XX  
XX! $(OBJS): h.h
XX--- 1,17 ----
XX! # Makefile for make
XX  
XX! CFLAGS = -O -Dunix -DMINIXPC -Dprintf=printk -Dfprintf=fprintk
XX! O=o
XX  
XX! OBJ =	check.$O input.$O macro.$O main.$O make.$O reader.$O rules.$O
XX  
XX! make :	$(OBJ)
XX! 	@rm -rf make
XX! 	@echo Start linking make
XX! 	@$(CC) -o make $(OBJ) >/dev/null
XX! 	@chmem =35000 make
XX   
XX! $(OBJ): h.h
XX  
XX! clean:
XX! 	@rm -f *.o *.s *.bak core make
X/
Xecho x - h.h.d
Xsed '/^X/s///' > h.h.d << '/'
XX*** /home/top/ast/minix/1.5/commands/make/h.h  crc=34584   9210	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/make/h.h  crc=35361   8579	Mon Dec 21 18:56:29 1992
XX***************
XX*** 23,30 ****
XX--- 23,33 ----
XX  #include <sys/types.h>
XX  #include <sys/stat.h>
XX  #include <errno.h>
XX+ #include <stdlib.h>
XX+ #include <string.h>
XX  #include <time.h>
XX  #include <utime.h>
XX+ #include <stdio.h>
XX  #endif
XX  
XX  #ifdef eon
XX***************
XX*** 48,62 ****
XX  #include <sys/types.h>
XX  #include <sys/stat.h>
XX  #include <osbind.h>
XX! #endif LATTICE
XX  
XX  #ifdef TURBO
XX  #include <tos.h>
XX  #include <errno.h>
XX  #include <string.h>
XX! #endif TURBO
XX  
XX! #endif tos
XX  
XX  #include <ctype.h>
XX  #include <stdio.h>
XX--- 51,65 ----
XX  #include <sys/types.h>
XX  #include <sys/stat.h>
XX  #include <osbind.h>
XX! #endif /* LATTICE */
XX  
XX  #ifdef TURBO
XX  #include <tos.h>
XX  #include <errno.h>
XX  #include <string.h>
XX! #endif /* TURBO */
XX  
XX! #endif /* tos */
XX  
XX  #include <ctype.h>
XX  #include <stdio.h>
XX***************
XX*** 234,341 ****
XX  #ifdef tos
XX  #ifdef LATTICE
XX  EXTERN int _mneed INIT(60000);    /* VERY important for TOS with LATTICE C*/
XX! #endif LATTICE
XX! #endif tos
XX  #ifdef eon
XX  #define MEMSPACE  (16384)
XX  EXTERN unsigned  memspace = MEMSPACE;
XX  #endif
XX  
XX! /* Defines function declarations for all functions */
XX  
XX! #ifdef __STDC__
XX! #define CONST const
XX! #define LINT_ARGS
XX! #else
XX! #define CONST /* */
XX! #endif
XX  
XX! #ifndef PARMS
XX! #ifdef  LINT_ARGS
XX! #define PARMS(x)   x
XX! #else
XX! #define PARMS(x)   ()
XX! #endif
XX! #endif
XX  
XX- /*
XX- :.,$s/(PARMS\(.*\));/PARMS\1;/
XX- */
XX- 
XX- extern time_t  time PARMS(( time_t *));
XX- extern char   *ctime PARMS (( CONST time_t *));
XX- extern char   *getenv PARMS (( CONST char *));
XX- extern char   *fgets PARMS (( char *, int, FILE *));
XX- extern char   *strchr PARMS (( CONST char *, int));
XX- extern char   *strrchr PARMS (( CONST char *, int));
XX- #ifndef __STDC__
XX- extern char   *malloc PARMS (( unsigned));
XX- extern char   *realloc PARMS (( char *, unsigned)); /* OS9 ? */
XX- #else
XX- extern void   *malloc PARMS (( unsigned));
XX- extern void   *realloc PARMS (( void *, unsigned)); /* OS9 ? */
XX- #endif
XX- 
XX- /* main.c */
XX- void           main PARMS (( int, char **));
XX- void           setoption PARMS ((char));
XX- void           usage PARMS (());
XX- void           fatal PARMS (( char *, char *, int));
XX  /* check.c */
XX! void           prt PARMS (());
XX! void           check PARMS (( struct name *));
XX! void           circh PARMS (());
XX! void           precious PARMS (());
XX  /* input.c */
XX! void           init PARMS (());
XX! void           strrealloc PARMS (( struct str *));
XX! struct name   *newname  PARMS (( char *));
XX! struct name   *testname PARMS (( char *));
XX! struct depend *newdep PARMS (( struct name *, struct depend *));
XX! struct cmd    *newcmd PARMS (( char *, struct cmd *));
XX! void           newline PARMS (( struct name *, struct depend *, struct cmd *, int));
XX! void           input PARMS (( FILE *));
XX  /* macro.c */
XX! struct macro  *getmp PARMS (( char *));
XX! char          *getmacro PARMS (( char *));
XX! struct macro  *setmacro PARMS (( char *, char *));
XX! void           setDFmacro PARMS (( char *, char *));
XX! void           doexp PARMS (( struct str *, char *));
XX! void           expand PARMS (( struct str *));
XX! /* make.c */
XX! int            dosh PARMS (( char *, char *));
XX! void           docmds1 PARMS (( struct name *, struct line *));
XX! void           docmds PARMS (( struct name *));
XX! #ifdef tos
XX! int            Tosexec PARMS (( char *));
XX! time_t         mstonix PARMS (( struct DOSTIME *));
XX! #endif
XX! #ifdef os9
XX! void           getmdate PARMS (( int, struct sgtbuf *));
XX! time_t         cnvtime PARMS (( struct sgtbuf *));
XX! void           time PARMS (( time_t *));
XX! #endif
XX! void           modtime PARMS (( struct name *));
XX! void           touch PARMS (( struct name *));
XX! int            make PARMS (( struct name *, int));
XX! void           make1 PARMS (( struct name *, struct line *, struct depend *,char *, char *));
XX! void           implmacros PARMS (( struct name *, struct line *, char **,char **));
XX! void           dbgprint PARMS (( int, struct name *, char *));
XX! /* reader.c */
XX! void           error PARMS (( char *, char *));
XX! bool           getline PARMS (( struct str *, FILE *));
XX! char          *gettok PARMS (( register char **));
XX! /* rules.c */
XX! bool           dyndep PARMS (( struct name  *, char **, char **));
XX! void           makerules PARMS (());
XX  
XX  
XX! /*
XX!  *	Return a pointer to the suffix of a name
XX!  */
XX! #define  suffix(name)   strrchr(name,(int)'.')
XX  
XX! EXTERN int _ctypech;
XX! #define mylower(x)  (islower(_ctypech=(x)) ? _ctypech :tolower(_ctypech))
XX! #define myupper(x)  (isupper(_ctypech=(x)) ? _ctypech :toupper(_ctypech))
XX  
XX--- 237,312 ----
XX  #ifdef tos
XX  #ifdef LATTICE
XX  EXTERN int _mneed INIT(60000);    /* VERY important for TOS with LATTICE C*/
XX! #endif /* LATTICE */
XX! #endif /* tos */
XX  #ifdef eon
XX  #define MEMSPACE  (16384)
XX  EXTERN unsigned  memspace = MEMSPACE;
XX  #endif
XX  
XX! #define  suffix(name)   strrchr(name,(int)'.')
XX  
XX! EXTERN int _ctypech;
XX! #define mylower(x)  (islower(_ctypech=(x)) ? _ctypech :tolower(_ctypech))
XX! #define myupper(x)  (isupper(_ctypech=(x)) ? _ctypech :toupper(_ctypech))
XX  
XX! /* Prototypes. */
XX! struct sgtbuf;
XX  
XX  /* check.c */
XX! _PROTOTYPE(void prt, (void));
XX! _PROTOTYPE(void check, (struct name *np ));
XX! _PROTOTYPE(void circh, (void));
XX! _PROTOTYPE(void precious, (void));
XX! 
XX  /* input.c */
XX! _PROTOTYPE(void init, (void));
XX! _PROTOTYPE(void strrealloc, (struct str *strs ));
XX! _PROTOTYPE(struct name *newname, (char *name ));
XX! _PROTOTYPE(struct name *testname, (char *name ));
XX! _PROTOTYPE(struct depend *newdep, (struct name *np, struct depend *dp ));
XX! _PROTOTYPE(struct cmd *newcmd, (char *str, struct cmd *cp ));
XX! _PROTOTYPE(void newline, (struct name *np, struct depend *dp, struct cmd *cp, 
XX! 								   int flag ));
XX! _PROTOTYPE(void input, (FILE *fd ));
XX! 
XX  /* macro.c */
XX! _PROTOTYPE(struct macro *getmp, (char *name ));
XX! _PROTOTYPE(char *getmacro, (char *name ));
XX! _PROTOTYPE(struct macro *setmacro, (char *name, char *val ));
XX! _PROTOTYPE(void setDFmacro, (char *name, char *val ));
XX! _PROTOTYPE(void doexp, (struct str *to, char *from ));
XX! _PROTOTYPE(void expand, (struct str *strs ));
XX  
XX+ /* main.c */
XX+ _PROTOTYPE(void main, (int argc, char **argv ));
XX+ _PROTOTYPE(void setoption, (char option ));
XX+ _PROTOTYPE(void usage, (void));
XX+ _PROTOTYPE(void fatal, (char *msg, char *a1, int a2 ));
XX  
XX! /* make.c */
XX! _PROTOTYPE(int dosh, (char *string, char *shell ));
XX! _PROTOTYPE(int makeold, (char *name ));
XX! _PROTOTYPE(void docmds1, (struct name *np, struct line *lp ));
XX! _PROTOTYPE(void docmds, (struct name *np ));
XX! _PROTOTYPE(int Tosexec, (char *string ));
XX! _PROTOTYPE(time_t mstonix, (unsigned int date, unsigned int time ));
XX! _PROTOTYPE(void getmdate, (int fd, struct sgtbuf *tbp ));
XX! _PROTOTYPE(time_t cnvtime, (struct sgtbuf *tbp ));
XX! _PROTOTYPE(void modtime, (struct name *np ));
XX! _PROTOTYPE(void touch, (struct name *np ));
XX! _PROTOTYPE(int make, (struct name *np, int level ));
XX! _PROTOTYPE(void make1, (struct name *np, struct line *lp, struct depend *qdp, 
XX! 					char *basename, char *inputname ));
XX! _PROTOTYPE(void implmacros, (struct name *np, struct line *lp, 
XX! 					char **pbasename, char **pinputname ));
XX! _PROTOTYPE(void dbgprint, (int level, struct name *np, char *comment ));
XX  
XX! /* reader.c */
XX! _PROTOTYPE(void error, (char *msg, char *a1 ));
XX! _PROTOTYPE(bool getline, (struct str *strs, FILE *fd ));
XX! _PROTOTYPE(char *gettok, (char **ptr ));
XX  
XX+ /* rules.c */
XX+ _PROTOTYPE(bool dyndep, (struct name *np, char **pbasename,char **pinputname));
XX+ _PROTOTYPE(void makerules, (void));
X/
Xecho x - input.c.d
Xsed '/^X/s///' > input.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/make/input.c  crc=60178  10416	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/make/input.c  crc=31139  10472	Mon Dec 21 18:56:29 1992
XX***************
XX*** 35,45 ****
XX       fatal("No memory for name",(char *)0,0);
XX    (*suffparray)->n_next = (struct name *)0;
XX  
XX!   if ((str1 = malloc(LZ1)) == (char *)0)
XX       fatal("No memory for str1",(char *)0,0);
XX    str1s.ptr = &str1;
XX    str1s.len = LZ1;
XX!   if ((str2 = malloc(LZ2)) == (char *)0)
XX       fatal("No memory for str2",(char *)0,0);
XX    str2s.ptr = &str2;
XX    str2s.len = LZ2;
XX--- 35,45 ----
XX       fatal("No memory for name",(char *)0,0);
XX    (*suffparray)->n_next = (struct name *)0;
XX  
XX!   if ((str1 = (char *) malloc(LZ1)) == ((char *)0))
XX       fatal("No memory for str1",(char *)0,0);
XX    str1s.ptr = &str1;
XX    str1s.len = LZ1;
XX!   if ((str2 = (char *) malloc(LZ2)) == (char *)0)
XX       fatal("No memory for str2",(char *)0,0);
XX    str2s.ptr = &str2;
XX    str2s.len = LZ2;
XX***************
XX*** 49,55 ****
XX  struct str *strs;
XX  {
XX    strs->len *= 2;
XX!   if( (*strs->ptr = realloc( *strs->ptr, strs->len)) == (char *) NULL)
XX         fatal("No memory for string reallocation",(char *)0,0);
XX  }
XX  
XX--- 49,55 ----
XX  struct str *strs;
XX  {
XX    strs->len *= 2;
XX!   if( (*strs->ptr = (char *) realloc( *strs->ptr, strs->len)) == (char *) NULL)
XX         fatal("No memory for string reallocation",(char *)0,0);
XX  }
XX  
XX***************
XX*** 84,90 ****
XX                                     == (struct name *)0)
XX             fatal("No memory for name",(char *)0,0);
XX          (*sp)->n_next = (struct name *)0;
XX!         if ((cp = malloc(strlen(suff)+1)) == (char *)0)
XX             fatal("No memory for name",(char *)0,0);
XX          strcpy(cp, suff);
XX          (*sp)->n_name = cp;
XX--- 84,90 ----
XX                                     == (struct name *)0)
XX             fatal("No memory for name",(char *)0,0);
XX          (*sp)->n_next = (struct name *)0;
XX!         if ((cp = (char *) malloc(strlen(suff)+1)) == (char *)0)
XX             fatal("No memory for name",(char *)0,0);
XX          strcpy(cp, suff);
XX          (*sp)->n_name = cp;
XX***************
XX*** 106,112 ****
XX    }
XX    rrp->n_next = rp;
XX    rp->n_next = (struct name *)0;
XX!   if ((cp = malloc(strlen(name)+1)) == (char *)0)
XX       fatal("No memory for name",(char *)0,0);
XX    strcpy(cp, name);
XX    rp->n_name = cp;
XX--- 106,112 ----
XX    }
XX    rrp->n_next = rp;
XX    rp->n_next = (struct name *)0;
XX!   if ((cp = (char *) malloc(strlen(name)+1)) == (char *)0)
XX       fatal("No memory for name",(char *)0,0);
XX    strcpy(cp, name);
XX    rp->n_name = cp;
XX***************
XX*** 196,202 ****
XX    if ((rp = (struct cmd *)malloc(sizeof (struct cmd))) == (struct cmd *)0)
XX  	fatal("No memory for command",(char *)0,0);
XX    rp->c_next = (struct cmd *)0;
XX!   if ((rcp = malloc(strlen(str)+1)) == (char *)0)
XX  	fatal("No memory for command",(char *)0,0);
XX    strcpy(rcp, str);
XX    rp->c_cmd = rcp;
XX--- 196,202 ----
XX    if ((rp = (struct cmd *)malloc(sizeof (struct cmd))) == (struct cmd *)0)
XX  	fatal("No memory for command",(char *)0,0);
XX    rp->c_next = (struct cmd *)0;
XX!   if ((rcp = (char *) malloc(strlen(str)+1)) == (char *)0)
XX  	fatal("No memory for command",(char *)0,0);
XX    strcpy(rcp, str);
XX    rp->c_cmd = rcp;
X/
Xecho x - macro.c.d
Xsed '/^X/s///' > macro.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/make/macro.c  crc=41367   4282	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/make/macro.c  crc=46068   4318	Mon Dec 21 18:56:30 1992
XX***************
XX*** 73,85 ****
XX  		macrohead = rp;
XX  		rp->m_flag = FALSE;
XX  
XX! 		if ((cp = malloc(strlen(name)+1)) == (char *)0)
XX  			fatal("No memory for macro",(char *)0,0);
XX  		strcpy(cp, name);
XX  		rp->m_name = cp;
XX  	}
XX  
XX! 	if ((cp = malloc(strlen(val)+1)) == (char *)0)
XX  		fatal("No memory for macro",(char *)0,0);
XX  	strcpy(cp, val);		/*  Copy in new value  */
XX  	rp->m_val = cp;
XX--- 73,85 ----
XX  		macrohead = rp;
XX  		rp->m_flag = FALSE;
XX  
XX! 		if ((cp = (char *) malloc(strlen(name)+1)) == (char *)0)
XX  			fatal("No memory for macro",(char *)0,0);
XX  		strcpy(cp, name);
XX  		rp->m_name = cp;
XX  	}
XX  
XX! 	if ((cp = (char *) malloc(strlen(val)+1)) == (char *)0)
XX  		fatal("No memory for macro",(char *)0,0);
XX  	strcpy(cp, val);		/*  Copy in new value  */
XX  	rp->m_val = cp;
XX***************
XX*** 113,119 ****
XX    }
XX    setmacro(filename,c+1);
XX    len = c - val + 1;
XX!   if((tmp = malloc(len + 1)) == (char *) 0)
XX       fatal("No memory for tmp",(char *)0,0);
XX    strncpy(tmp,val,len);
XX    tmp[len] = '\0';
XX--- 113,119 ----
XX    }
XX    setmacro(filename,c+1);
XX    len = c - val + 1;
XX!   if((tmp = (char *) malloc(len + 1)) == (char *) 0)
XX       fatal("No memory for tmp",(char *)0,0);
XX    strncpy(tmp,val,len);
XX    tmp[len] = '\0';
XX***************
XX*** 191,197 ****
XX  {
XX    char  *a;
XX  
XX!   if ((a = malloc(strlen(*strs->ptr)+1)) == (char *)0)
XX       fatal("No memory for temporary string",(char *)0,0);
XX    strcpy(a, *strs->ptr);
XX    strs->pos = 0;
XX--- 191,197 ----
XX  {
XX    char  *a;
XX  
XX!   if ((a = (char *) malloc(strlen(*strs->ptr)+1)) == (char *)0)
XX       fatal("No memory for temporary string",(char *)0,0);
XX    strcpy(a, *strs->ptr);
XX    strs->pos = 0;
X/
Xecho x - main.c.d
Xsed '/^X/s///' > main.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/make/main.c  crc=40310   7391	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/make/main.c  crc=15077   7428	Mon Dec 21 18:56:30 1992
XX***************
XX*** 47,55 ****
XX  static char *makefile;      /*  The make file  */
XX  static FILE *ifd;           /*  Input file desciptor  */
XX  static char *ptrmakeflags;
XX  static char  makeflags[] = "MAKEFLAGS=                    ";
XX-    /* there must be enough 'space' for all possible flags ! */
XX  
XX  
XX  void main(argc, argv)
XX  int    argc;
XX--- 47,57 ----
XX  static char *makefile;      /*  The make file  */
XX  static FILE *ifd;           /*  Input file desciptor  */
XX  static char *ptrmakeflags;
XX+ 
XX+ /* There must be enough 'space' for all possible flags ! */
XX  static char  makeflags[] = "MAKEFLAGS=                    ";
XX  
XX+ _PROTOTYPE(int putenv, (char *name ));
XX  
XX  void main(argc, argv)
XX  int    argc;
X/
Xecho x - make.c.d
Xsed '/^X/s///' > make.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/make/make.c  crc=27322  17183	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/make/make.c  crc=18578  17783	Sat Apr 10 19:37:24 1993
XX***************
XX*** 18,23 ****
XX--- 18,24 ----
XX   *   7 09.09.89 tos support added                                    PHH,RAL
XX   *   8 17.09.89 make1 arg. fixed, N_EXEC introduced                  RAL
XX   * ------------ Version 2.0 released ------------------------------- RAL
XX+  *     18.05.90 fixed -n bug with silent rules.  (Now echos them.)   PAN
XX   *
XX   *************************************************************************/
XX  
XX***************
XX*** 64,70 ****
XX--- 65,87 ----
XX  }
XX  
XX  
XX+ #ifdef unix
XX  /*
XX+  *    Make a file look very outdated after an error trying to make it.
XX+  *    This keeps hard links intact.  (kjb)
XX+  */
XX+ int makeold(name) char *name;
XX+ {
XX+   struct utimbuf a;
XX+ 
XX+   a.actime = a.modtime = 0;	/* The epoch */
XX+ 
XX+   return utime(name, &a);
XX+ }
XX+ #endif
XX+ 
XX+ 
XX+ /*
XX   *	Do commands to make a target
XX   */
XX  void docmds1(np, lp)
XX***************
XX*** 107,126 ****
XX  			ssilent = TRUE;
XX  		else		   /*  Specific ignore  */
XX  			signore = TRUE;
XX  		q++;		   /*  Not part of the command  */
XX  	}
XX  
XX  	for (p=q; *p; p++) {
XX  		if (*p == '\n' && p[1] != '\0') {
XX  			*p = ' ';
XX! 			if (!ssilent)
XX  				fputs("\\\n", stdout);
XX  		}
XX! 		else if (!ssilent)
XX  			putchar(*p);
XX  	}
XX! 	if (!ssilent)
XX! 		printf("\n");
XX  
XX  	if (domake || expmake) {	/*  Get the shell to execute it  */
XX  		if ((estat = dosh(q, shell)) != 0) {
XX--- 124,144 ----
XX  			ssilent = TRUE;
XX  		else		   /*  Specific ignore  */
XX  			signore = TRUE;
XX+ 		if (!domake) putchar(*q);  /* Show all characters. */
XX  		q++;		   /*  Not part of the command  */
XX  	}
XX  
XX  	for (p=q; *p; p++) {
XX  		if (*p == '\n' && p[1] != '\0') {
XX  			*p = ' ';
XX! 			if (!ssilent || !domake)
XX  				fputs("\\\n", stdout);
XX  		}
XX! 		else if (!ssilent || !domake)
XX  			putchar(*p);
XX  	}
XX! 	if (!ssilent || !domake)
XX! 		putchar('\n');
XX  
XX  	if (domake || expmake) {	/*  Get the shell to execute it  */
XX  		if ((estat = dosh(q, shell)) != 0) {
XX***************
XX*** 131,139 ****
XX  		    else {
XX  			fprintf(stderr,"%s: Error code %d\n", myname, estat);
XX  			if (!(np->n_flag & N_PREC))
XX  			    if (unlink(np->n_name) == 0)
XX  				fprintf(stderr,"%s: '%s' removed.\n", myname, np->n_name);
XX! 			if (!conterr) exit(estat);
XX  			np->n_flag |= N_ERROR;
XX  			return;
XX  		    }
XX--- 149,162 ----
XX  		    else {
XX  			fprintf(stderr,"%s: Error code %d\n", myname, estat);
XX  			if (!(np->n_flag & N_PREC))
XX+ #ifdef unix
XX+ 			    if (makeold(np->n_name) == 0)
XX+ 				fprintf(stderr,"%s: made '%s' look old.\n", myname, np->n_name);
XX+ #else
XX  			    if (unlink(np->n_name) == 0)
XX  				fprintf(stderr,"%s: '%s' removed.\n", myname, np->n_name);
XX! #endif
XX! 			if (!conterr) exit(estat != 0);
XX  			np->n_flag |= N_ERROR;
XX  			return;
XX  		    }
XX***************
XX*** 274,280 ****
XX            hour * 60L * 60L   +   min * 60   +    sec;
XX  	return (longtime);
XX  }
XX! #endif tos
XX  
XX  #ifdef os9
XX  /*
XX--- 297,303 ----
XX            hour * 60L * 60L   +   min * 60   +    sec;
XX  	return (longtime);
XX  }
XX! #endif /* tos */
XX  
XX  #ifdef os9
XX  /*
XX***************
XX*** 658,664 ****
XX    suff = suffix(q);
XX    while ( *q && (q < suff || !suff)) *p++ = *q++;
XX    *p = '\0';
XX!   if ((*pbasename = malloc(strlen(str2)+1)) == (char *)0 )
XX       fatal("No memory for basename",(char *)0,0);
XX    strcpy(*pbasename,str2);
XX    baselen = strlen(str2);
XX--- 681,687 ----
XX    suff = suffix(q);
XX    while ( *q && (q < suff || !suff)) *p++ = *q++;
XX    *p = '\0';
XX!   if ((*pbasename = (char *) malloc(strlen(str2)+1)) == (char *)0 )
XX       fatal("No memory for basename",(char *)0,0);
XX    strcpy(*pbasename,str2);
XX    baselen = strlen(str2);
XX***************
XX*** 708,713 ****
XX--- 731,737 ----
XX    }
XX    fputs(comment,stdout);
XX    putchar((int)'\n');
XX+   fflush(stdout);
XX    return;
XX  }
XX  
X/
Xecho x - rules.c.d
Xsed '/^X/s///' > rules.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/make/rules.c  crc=17164   9544	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/make/rules.c  crc=02180   9281	Mon Dec 21 18:56:31 1992
XX***************
XX*** 51,57 ****
XX    suff = suffix(q);
XX    while (*q && (q < suff || !suff)) *p++ = *q++;
XX    *p = '\0';
XX!   if ((*pbasename = malloc(strlen(str1)+1)) == (char *)0 )
XX       fatal("No memory for basename",(char *)0,0);
XX    strcpy(*pbasename,str1);
XX    if ( !suff) suff = p - str1 + *pbasename;  /* set suffix to nullstring */
XX--- 51,57 ----
XX    suff = suffix(q);
XX    while (*q && (q < suff || !suff)) *p++ = *q++;
XX    *p = '\0';
XX!   if ((*pbasename = (char *) malloc(strlen(str1)+1)) == (char *)0 )
XX       fatal("No memory for basename",(char *)0,0);
XX    strcpy(*pbasename,str1);
XX    if ( !suff) suff = p - str1 + *pbasename;  /* set suffix to nullstring */
XX***************
XX*** 198,217 ****
XX  
XX    setmacro("CC", "cc");
XX    setmacro("CFLAGS", "-O");
XX! #ifdef MINIXPC
XX    cp = newcmd("$(CC) -S $(CFLAGS) $<", (struct cmd *)0);
XX    np = newname(".c.s");
XX! #else
XX    cp = newcmd("$(CC) -c $(CFLAGS) $<", (struct cmd *)0);
XX    np = newname(".c.o");
XX- #endif MINIXPC
XX    newline(np, (struct depend *)0, cp, 0);
XX  
XX  #ifdef MINIXPC
XX    cp = newcmd("$(CC) $(CFLAGS) -i -o $@ $<", (struct cmd *)0);
XX  #else
XX    cp = newcmd("$(CC) $(CFLAGS) -o $@ $<", (struct cmd *)0);
XX! #endif MINIXPC
XX    np = newname(".c");
XX    newline(np, (struct depend *)0, cp, 0);
XX  
XX--- 198,217 ----
XX  
XX    setmacro("CC", "cc");
XX    setmacro("CFLAGS", "-O");
XX! 
XX    cp = newcmd("$(CC) -S $(CFLAGS) $<", (struct cmd *)0);
XX    np = newname(".c.s");
XX!   newline(np, (struct depend *)0, cp, 0);
XX! 
XX    cp = newcmd("$(CC) -c $(CFLAGS) $<", (struct cmd *)0);
XX    np = newname(".c.o");
XX    newline(np, (struct depend *)0, cp, 0);
XX  
XX  #ifdef MINIXPC
XX    cp = newcmd("$(CC) $(CFLAGS) -i -o $@ $<", (struct cmd *)0);
XX  #else
XX    cp = newcmd("$(CC) $(CFLAGS) -o $@ $<", (struct cmd *)0);
XX! #endif /* MINIXPC */
XX    np = newname(".c");
XX    newline(np, (struct depend *)0, cp, 0);
XX  
XX***************
XX*** 228,242 ****
XX    newline(np, (struct depend *)0, cp, 0);
XX  
XX    cp = newcmd("$(YACC) $(YFLAGS) $<", (struct cmd *)0);
XX- #ifdef MINIXPC
XX-   cp = newcmd("$(CC) $(CFLAGS) -S y.tab.c", cp);
XX-   cp = newcmd("mv y.tab.s $@", cp);
XX-   np = newname(".y.s");
XX- #else
XX    cp = newcmd("$(CC) $(CFLAGS) -c y.tab.c", cp);
XX    cp = newcmd("mv y.tab.o $@", cp);
XX    np = newname(".y.o");
XX- #endif MINIXPC
XX    cp = newcmd("rm y.tab.c", cp);
XX    newline(np, (struct depend *)0, cp, 0);
XX  
XX--- 228,236 ----
XX***************
XX*** 247,261 ****
XX    newline(np, (struct depend *)0, cp, 0);
XX  
XX    cp = newcmd("$(FLEX) $(FLEX_FLAGS) $<", (struct cmd *)0);
XX- #ifdef MINIXPC
XX-   cp = newcmd("$(CC) $(CFLAGS) -S lex.yy.s", cp);
XX-   cp = newcmd("mv lex.yy.s $@", cp);
XX-   np = newname(".l.s");
XX- #else
XX    cp = newcmd("$(CC) $(CFLAGS) -c lex.yy.c", cp);
XX    cp = newcmd("mv lex.yy.o $@", cp);
XX    np = newname(".l.o");
XX- #endif MINIXPC
XX    cp = newcmd("rm lex.yy.c", cp);
XX    newline(np, (struct depend *)0, cp, 0);
XX  
XX--- 241,249 ----
XX***************
XX*** 272,278 ****
XX    np = newname(".SUFFIXES");
XX    newline(np, dp, (struct cmd *)0, 0);
XX  
XX! #endif unix
XX  
XX  
XX  #ifdef os9
XX--- 260,266 ----
XX    np = newname(".SUFFIXES");
XX    newline(np, dp, (struct cmd *)0, 0);
XX  
XX! #endif /* unix */
XX  
XX  
XX  #ifdef os9
X/
/
