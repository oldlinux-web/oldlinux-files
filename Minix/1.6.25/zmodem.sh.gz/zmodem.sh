echo x - zmodem.cd
sed '/^X/s///' > zmodem.cd << '/'
Xecho x - Makefile.d
Xsed '/^X/s///' > Makefile.d << '/'
XX*** /home/top/ast/minix/1.5/commands/zmodem/Makefile  crc=32006    245	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/zmodem/Makefile  crc=39132    309	Sat Jan 30 20:12:17 1993
XX***************
XX*** 1,14 ****
XX  all: rz sz
XX  
XX! CFLAGS= -DV7 -D_MINIX -D_POSIX_SOURCE -DLCASE=0
XX  
XX  rz: rz.c rbsb.c zm.c zmodem.h
XX! 	$(CC) $(CFLAGS) -o rz rz.c
XX! 	chmem =10000 rz
XX  
XX  sz: sz.c rbsb.c zm.c zmodem.h
XX! 	$(CC) $(CFLAGS) -o sz sz.c
XX! 	chmem =10000 sz
XX  
XX  clean:	
XX! 	@rm -f *.bak *.s rz sz
XX--- 1,19 ----
XX+ # Makefile for zmodem
XX+ 
XX  all: rz sz
XX  
XX! CFLAGS= -m -DV7 -D_MINIX -D_POSIX_SOURCE -DLCASE=0 -O
XX! O=o
XX  
XX  rz: rz.c rbsb.c zm.c zmodem.h
XX! 	@rm -rf rz
XX! 	@cc $(CFLAGS) -o rz rz.c
XX! 	@chmem =10000 rz
XX  
XX  sz: sz.c rbsb.c zm.c zmodem.h
XX! 	@rm -rf sz
XX! 	@cc $(CFLAGS) -o sz sz.c
XX! 	@chmem =10000 sz
XX  
XX  clean:	
XX! 	@rm -f *.bak *.o *.s core rz sz
X/
Xecho x - rbsb.c.d
Xsed '/^X/s///' > rbsb.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/zmodem/rbsb.c  crc=38296   7041	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/zmodem/rbsb.c  crc=15538   7161	Sat Sep 19 21:04:46 1992
XX***************
XX*** 40,45 ****
XX--- 40,49 ----
XX  #include <string.h>
XX  #endif
XX  
XX+ #include "zmodem.h"
XX+ 
XX+ _PROTOTYPE(static unsigned getspeed , (int code ));
XX+ 
XX  #if HOWMANY  > 255
XX  Howmany must be 255 or less
XX  #endif
XX***************
XX*** 50,56 ****
XX   *  different line
XX   */
XX  int Fromcu;		/* Were called from cu or yam */
XX! from_cu()
XX  {
XX  	struct stat a, b;
XX  
XX--- 54,61 ----
XX   *  different line
XX   */
XX  int Fromcu;		/* Were called from cu or yam */
XX! 
XX! void from_cu()
XX  {
XX  	struct stat a, b;
XX  
XX***************
XX*** 58,64 ****
XX  	Fromcu = a.st_rdev != b.st_rdev;
XX  	return;
XX  }
XX! cucheck()
XX  {
XX  	if (Fromcu)
XX  		fprintf(stderr,"Please read the manual page BUGS chapter!\r\n");
XX--- 63,70 ----
XX  	Fromcu = a.st_rdev != b.st_rdev;
XX  	return;
XX  }
XX! 
XX! void cucheck()
XX  {
XX  	if (Fromcu)
XX  		fprintf(stderr,"Please read the manual page BUGS chapter!\r\n");
XX***************
XX*** 94,100 ****
XX  /*
XX   *  Return non 0 iff something to read from io descriptor f
XX   */
XX! rdchk(f)
XX  {
XX  	static long lf;
XX  
XX--- 100,106 ----
XX  /*
XX   *  Return non 0 iff something to read from io descriptor f
XX   */
XX! int rdchk(f)
XX  {
XX  	static long lf;
XX  
XX***************
XX*** 110,116 ****
XX  /*
XX   * Nonblocking I/O is a bit different in System V, Release 2
XX   */
XX! rdchk(f)
XX  {
XX  	int lf, savestat;
XX  
XX--- 116,122 ----
XX  /*
XX   * Nonblocking I/O is a bit different in System V, Release 2
XX   */
XX! int rdchk(f)
XX  {
XX  	int lf, savestat;
XX  
XX***************
XX*** 126,131 ****
XX--- 132,138 ----
XX  
XX  static unsigned
XX  getspeed(code)
XX+ int code;
XX  {
XX  	register n;
XX  
XX***************
XX*** 153,159 ****
XX   *  1: save old tty stat, set raw mode 
XX   *  0: restore original tty mode
XX   */
XX! mode(n)
XX  {
XX  	static did0 = FALSE;
XX  
XX--- 160,167 ----
XX   *  1: save old tty stat, set raw mode 
XX   *  0: restore original tty mode
XX   */
XX! int mode(n)
XX! int n;
XX  {
XX  	static did0 = FALSE;
XX  
XX***************
XX*** 323,329 ****
XX  	}
XX  }
XX  
XX! sendbrk()
XX  {
XX  #ifdef V7
XX  #ifdef TIOCSBRK
XX--- 331,337 ----
XX  	}
XX  }
XX  
XX! void sendbrk()
XX  {
XX  #ifdef V7
XX  #ifdef TIOCSBRK
X/
Xecho x - rz.c.d
Xsed '/^X/s///' > rz.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/zmodem/rz.c  crc=30006  31144	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/zmodem/rz.c  crc=36391  32546	Tue Dec 22 10:25:04 1992
XX***************
XX*** 64,89 ****
XX  #include <types.h>
XX  #include <stat.h>
XX  #define LOGFILE "rzlog.tmp"
XX- #include <stdio.h>
XX- #include <signal.h>
XX- #include <setjmp.h>
XX- #include <ctype.h>
XX- #include <errno.h>
XX  #define OS "VMS"
XX  #define BUFREAD
XX  extern int errno;
XX  #define SS_NORMAL SS$_NORMAL
XX  #else
XX  #define SS_NORMAL 0
XX  #define LOGFILE "/tmp/rzlog"
XX! #include <stdio.h>
XX! #include <signal.h>
XX! #include <setjmp.h>
XX  #include <ctype.h>
XX  #include <errno.h>
XX! extern int errno;
XX! FILE *popen();
XX! #endif
XX  
XX  #define OK 0
XX  #define FALSE 0
XX--- 64,89 ----
XX  #include <types.h>
XX  #include <stat.h>
XX  #define LOGFILE "rzlog.tmp"
XX  #define OS "VMS"
XX  #define BUFREAD
XX  extern int errno;
XX  #define SS_NORMAL SS$_NORMAL
XX  #else
XX+ /* Not vax11c */
XX  #define SS_NORMAL 0
XX  #define LOGFILE "/tmp/rzlog"
XX! #endif
XX! 
XX! #include <time.h>
XX  #include <ctype.h>
XX  #include <errno.h>
XX! #include <signal.h>
XX! #include <setjmp.h>
XX! #include <string.h>
XX! #include <stdlib.h>
XX! #include <unistd.h>
XX! #include <utime.h>
XX! #include <stdio.h>
XX  
XX  #define OK 0
XX  #define FALSE 0
XX***************
XX*** 91,98 ****
XX  #undef ERROR
XX  #define ERROR (-1)
XX  
XX- void bibi();
XX  
XX  /*
XX   * Max value for HOWMANY is 255.
XX   *   A larger value reduces system overhead but may evoke kernel bugs.
XX--- 91,131 ----
XX  #undef ERROR
XX  #define ERROR (-1)
XX  
XX  
XX+ _PROTOTYPE(long getfree , (void));
XX+ _PROTOTYPE(void alrm , (int sig ));
XX+ _PROTOTYPE(int main , (int argc , char *argv []));
XX+ _PROTOTYPE(int usage , (void));
XX+ _PROTOTYPE(int wcreceive , (int argc , char **argp ));
XX+ _PROTOTYPE(int wcrxpn , (char *rpn ));
XX+ _PROTOTYPE(int wcrx , (void));
XX+ _PROTOTYPE(int wcgetsec , (char *rxbuf , int maxtime ));
XX+ _PROTOTYPE(int readline , (int timeout ));
XX+ _PROTOTYPE(void purgeline , (void));
XX+ _PROTOTYPE(int procheader , (char *name ));
XX+ _PROTOTYPE(int make_dirs , (char *pathname ));
XX+ _PROTOTYPE(int makedir , (char *dpath , int dmode ));
XX+ _PROTOTYPE(int putsec , (char *buf , int n ));
XX+ _PROTOTYPE(void sendline , (int c ));
XX+ _PROTOTYPE(void flushmo , (void));
XX+ _PROTOTYPE(void uncaps , (char *s ));
XX+ _PROTOTYPE(int IsAnyLower , (char *s ));
XX+ _PROTOTYPE(char *substr , (char *s , char *t ));
XX+ void zperr();
XX+ _PROTOTYPE(void canit , (void));
XX+ _PROTOTYPE(void report , (int sct ));
XX+ _PROTOTYPE(void chkinvok , (char *s ));
XX+ _PROTOTYPE(void checkpath , (char *name ));
XX+ _PROTOTYPE(int tryz , (void));
XX+ _PROTOTYPE(int rzfiles , (void));
XX+ _PROTOTYPE(int rzfile , (void));
XX+ _PROTOTYPE(void zmputs , (char *s ));
XX+ _PROTOTYPE(int closeit , (void));
XX+ _PROTOTYPE(void ackbibi , (void));
XX+ _PROTOTYPE(void bttyout , (int c ));
XX+ _PROTOTYPE(int sys2 , (char *s ));
XX+ _PROTOTYPE(void exec2 , (char *s ));
XX+ 
XX  /*
XX   * Max value for HOWMANY is 255.
XX   *   A larger value reduces system overhead but may evoke kernel bugs.
XX***************
XX*** 134,140 ****
XX  
XX  #include "crctab.c"
XX  
XX- char *substr();
XX  FILE *fout;
XX  
XX  /*
XX--- 167,172 ----
XX***************
XX*** 221,233 ****
XX  	exit(128+n);
XX  }
XX  
XX! main(argc, argv)
XX  char *argv[];
XX  {
XX  	register char *cp;
XX  	register npats;
XX  	char *virgin, **patts;
XX- 	char *getenv();
XX  	int exitcode = 0;
XX  
XX  	Rxtimeout = 100;
XX--- 253,265 ----
XX  	exit(128+n);
XX  }
XX  
XX! int main(argc, argv)
XX! int argc;
XX  char *argv[];
XX  {
XX  	register char *cp;
XX  	register npats;
XX  	char *virgin, **patts;
XX  	int exitcode = 0;
XX  
XX  	Rxtimeout = 100;
XX***************
XX*** 339,345 ****
XX  }
XX  
XX  
XX! usage()
XX  {
XX  	cucheck();
XX  #ifdef vax11c
XX--- 371,377 ----
XX  }
XX  
XX  
XX! int usage()
XX  {
XX  	cucheck();
XX  #ifdef vax11c
XX***************
XX*** 366,372 ****
XX   *  Debugging information output interface routine
XX   */
XX  /* VARARGS1 */
XX! vfile(f, a, b, c)
XX  register char *f,*a,*b,*c;
XX  
XX  {
XX--- 398,404 ----
XX   *  Debugging information output interface routine
XX   */
XX  /* VARARGS1 */
XX! void vfile(f, a, b, c)
XX  register char *f,*a,*b,*c;
XX  
XX  {
XX***************
XX*** 383,389 ****
XX  char *rbmsg =
XX  "%s ready. To begin transfer, type \"%s file ...\" to your modem program\r\n\n";
XX  
XX! wcreceive(argc, argp)
XX  char **argp;
XX  {
XX  	register c;
XX--- 415,422 ----
XX  char *rbmsg =
XX  "%s ready. To begin transfer, type \"%s file ...\" to your modem program\r\n\n";
XX  
XX! int wcreceive(argc, argp)
XX! int argc;
XX  char **argp;
XX  {
XX  	register c;
XX***************
XX*** 447,453 ****
XX   * Length is indeterminate as long as less than Blklen
XX   * A null string represents no more files (YMODEM)
XX   */
XX! wcrxpn(rpn)
XX  char *rpn;	/* receive a pathname */
XX  {
XX  	register c;
XX--- 480,486 ----
XX   * Length is indeterminate as long as less than Blklen
XX   * A null string represents no more files (YMODEM)
XX   */
XX! int wcrxpn(rpn)
XX  char *rpn;	/* receive a pathname */
XX  {
XX  	register c;
XX***************
XX*** 481,491 ****
XX   * Jack M. Wierda and Roderick W. Hart
XX   */
XX  
XX! wcrx()
XX  {
XX  	register int sectnum, sectcurr;
XX  	register char sendchar;
XX- 	register char *p;
XX  	int cblklen;			/* bytes to dump this block */
XX  
XX  	Firstsec=TRUE;sectnum=0; Eofseen=FALSE;
XX--- 514,523 ----
XX   * Jack M. Wierda and Roderick W. Hart
XX   */
XX  
XX! int wcrx()
XX  {
XX  	register int sectnum, sectcurr;
XX  	register char sendchar;
XX  	int cblklen;			/* bytes to dump this block */
XX  
XX  	Firstsec=TRUE;sectnum=0; Eofseen=FALSE;
XX***************
XX*** 496,502 ****
XX  		Lleft=0;	/* Do read next time ... */
XX  		sectcurr=wcgetsec(secbuf, (sectnum&0177)?50:130);
XX  		report(sectcurr);
XX! 		if (sectcurr==(sectnum+1 &0377)) {
XX  			sectnum++;
XX  			cblklen = Bytesleft>Blklen ? Blklen:Bytesleft;
XX  			if (putsec(secbuf, cblklen)==ERROR)
XX--- 528,534 ----
XX  		Lleft=0;	/* Do read next time ... */
XX  		sectcurr=wcgetsec(secbuf, (sectnum&0177)?50:130);
XX  		report(sectcurr);
XX! 		if (sectcurr==((sectnum+1) &0377)) {
XX  			sectnum++;
XX  			cblklen = Bytesleft>Blklen ? Blklen:Bytesleft;
XX  			if (putsec(secbuf, cblklen)==ERROR)
XX***************
XX*** 535,541 ****
XX   *    (Caller must do that when he is good and ready to get next sector)
XX   */
XX  
XX! wcgetsec(rxbuf, maxtime)
XX  char *rxbuf;
XX  int maxtime;
XX  {
XX--- 567,573 ----
XX   *    (Caller must do that when he is good and ready to get next sector)
XX   */
XX  
XX! int wcgetsec(rxbuf, maxtime)
XX  char *rxbuf;
XX  int maxtime;
XX  {
XX***************
XX*** 636,642 ****
XX   *
XX   * timeout is in tenths of seconds
XX   */
XX! readline(timeout)
XX  int timeout;
XX  {
XX  	register n;
XX--- 668,674 ----
XX   *
XX   * timeout is in tenths of seconds
XX   */
XX! int readline(timeout)
XX  int timeout;
XX  {
XX  	register n;
XX***************
XX*** 683,689 ****
XX  /*
XX   * Purge the modem input queue of all characters
XX   */
XX! purgeline()
XX  {
XX  	Lleft = 0;
XX  #ifdef USG
XX--- 715,721 ----
XX  /*
XX   * Purge the modem input queue of all characters
XX   */
XX! void purgeline()
XX  {
XX  	Lleft = 0;
XX  #ifdef USG
XX***************
XX*** 698,707 ****
XX  /*
XX   * Process incoming file information header
XX   */
XX! procheader(name)
XX  char *name;
XX  {
XX! 	register char *openmode, *p, **pp;
XX  
XX  	/* set default parameters and overrides */
XX  	openmode = "w";
XX--- 730,739 ----
XX  /*
XX   * Process incoming file information header
XX   */
XX! int procheader(name)
XX  char *name;
XX  {
XX! 	register char *openmode, *p;
XX  
XX  	/* set default parameters and overrides */
XX  	openmode = "w";
XX***************
XX*** 814,820 ****
XX   * it's because some required directory was not present, and if
XX   * so, create all required dirs.
XX   */
XX! make_dirs(pathname)
XX  register char *pathname;
XX  {
XX  	register char *p;		/* Points into path */
XX--- 846,852 ----
XX   * it's because some required directory was not present, and if
XX   * so, create all required dirs.
XX   */
XX! int make_dirs(pathname)
XX  register char *pathname;
XX  {
XX  	register char *p;		/* Points into path */
XX***************
XX*** 833,839 ****
XX  		if (p[-1] == '.' && (p == pathname+1 || p[-2] == '/'))
XX  			continue;
XX  		*p = 0;				/* Truncate the path there */
XX! 		if ( !mkdir(pathname, 0777)) {	/* Try to create it as a dir */
XX  			vfile("Made directory %s\n", pathname);
XX  			madeone++;		/* Remember if we made one */
XX  			*p = '/';
XX--- 865,871 ----
XX  		if (p[-1] == '.' && (p == pathname+1 || p[-2] == '/'))
XX  			continue;
XX  		*p = 0;				/* Truncate the path there */
XX! 		if ( !makedir(pathname, 0777)) {	/* Try to create it as a dir */
XX  			vfile("Made directory %s\n", pathname);
XX  			madeone++;		/* Remember if we made one */
XX  			*p = '/';
XX***************
XX*** 843,849 ****
XX  		if (errno == EEXIST)		/* Directory already exists */
XX  			continue;
XX  		/*
XX! 		 * Some other error in the mkdir.  We return to the caller.
XX  		 */
XX  		break;
XX  	}
XX--- 875,881 ----
XX  		if (errno == EEXIST)		/* Directory already exists */
XX  			continue;
XX  		/*
XX! 		 * Some other error in the makedir.  We return to the caller.
XX  		 */
XX  		break;
XX  	}
XX***************
XX*** 858,864 ****
XX  /*
XX   * Make a directory.  Compatible with the mkdir() system call on 4.2BSD.
XX   */
XX! mkdir(dpath, dmode)
XX  char *dpath;
XX  int dmode;
XX  {
XX--- 890,896 ----
XX  /*
XX   * Make a directory.  Compatible with the mkdir() system call on 4.2BSD.
XX   */
XX! int makedir(dpath, dmode)
XX  char *dpath;
XX  int dmode;
XX  {
XX***************
XX*** 909,917 ****
XX   *  If not in binary mode, carriage returns, and all characters
XX   *  starting with CPMEOF are discarded.
XX   */
XX! putsec(buf, n)
XX  char *buf;
XX! register n;
XX  {
XX  	register char *p;
XX  
XX--- 941,949 ----
XX   *  If not in binary mode, carriage returns, and all characters
XX   *  starting with CPMEOF are discarded.
XX   */
XX! int putsec(buf, n)
XX  char *buf;
XX! register int n;
XX  {
XX  	register char *p;
XX  
XX***************
XX*** 940,946 ****
XX  /*
XX   *  Send a character to modem.  Small is beautiful.
XX   */
XX! sendline(c)
XX  {
XX  	char d;
XX  
XX--- 972,979 ----
XX  /*
XX   *  Send a character to modem.  Small is beautiful.
XX   */
XX! void sendline(c)
XX! int c;
XX  {
XX  	char d;
XX  
XX***************
XX*** 950,956 ****
XX  	write(1, &d, 1);
XX  }
XX  
XX! flushmo() {}
XX  #endif
XX  
XX  
XX--- 983,989 ----
XX  	write(1, &d, 1);
XX  }
XX  
XX! void flushmo() {}
XX  #endif
XX  
XX  
XX***************
XX*** 958,964 ****
XX  
XX  
XX  /* make string s lower case */
XX! uncaps(s)
XX  register char *s;
XX  {
XX  	for ( ; *s; ++s)
XX--- 991,997 ----
XX  
XX  
XX  /* make string s lower case */
XX! void uncaps(s)
XX  register char *s;
XX  {
XX  	for ( ; *s; ++s)
XX***************
XX*** 968,974 ****
XX  /*
XX   * IsAnyLower returns TRUE if string s has lower case letters.
XX   */
XX! IsAnyLower(s)
XX  register char *s;
XX  {
XX  	for ( ; *s; ++s)
XX--- 1001,1007 ----
XX  /*
XX   * IsAnyLower returns TRUE if string s has lower case letters.
XX   */
XX! int IsAnyLower(s)
XX  register char *s;
XX  {
XX  	for ( ; *s; ++s)
XX***************
XX*** 1003,1009 ****
XX   * Log an error
XX   */
XX  /*VARARGS1*/
XX! zperr(s,p,u)
XX  char *s, *p, *u;
XX  {
XX  	if (Verbose <= 0)
XX--- 1036,1042 ----
XX   * Log an error
XX   */
XX  /*VARARGS1*/
XX! void zperr(s,p,u)
XX  char *s, *p, *u;
XX  {
XX  	if (Verbose <= 0)
XX***************
XX*** 1014,1020 ****
XX  }
XX  
XX  /* send cancel string to get the other end to shut up */
XX! canit()
XX  {
XX  	static char canistr[] = {
XX  	 24,24,24,24,24,24,24,24,24,24,8,8,8,8,8,8,8,8,8,8,0
XX--- 1047,1053 ----
XX  }
XX  
XX  /* send cancel string to get the other end to shut up */
XX! void canit()
XX  {
XX  	static char canistr[] = {
XX  	 24,24,24,24,24,24,24,24,24,24,8,8,8,8,8,8,8,8,8,8,0
XX***************
XX*** 1031,1037 ****
XX  }
XX  
XX  
XX! report(sct)
XX  int sct;
XX  {
XX  	if (Verbose>1)
XX--- 1064,1070 ----
XX  }
XX  
XX  
XX! void report(sct)
XX  int sct;
XX  {
XX  	if (Verbose>1)
XX***************
XX*** 1044,1050 ****
XX   * If called as [-][dir/../]rzCOMMAND set the pipe flag
XX   * If called as rb use YMODEM protocol
XX   */
XX! chkinvok(s)
XX  char *s;
XX  {
XX  	register char *p;
XX--- 1077,1083 ----
XX   * If called as [-][dir/../]rzCOMMAND set the pipe flag
XX   * If called as rb use YMODEM protocol
XX   */
XX! void chkinvok(s)
XX  char *s;
XX  {
XX  	register char *p;
XX***************
XX*** 1073,1079 ****
XX  /*
XX   * Totalitarian Communist pathname processing
XX   */
XX! checkpath(name)
XX  char *name;
XX  {
XX  	if (Restricted) {
XX--- 1106,1112 ----
XX  /*
XX   * Totalitarian Communist pathname processing
XX   */
XX! void checkpath(name)
XX  char *name;
XX  {
XX  	if (Restricted) {
XX***************
XX*** 1098,1104 ****
XX   *  Return ZFILE if Zmodem filename received, -1 on error,
XX   *   ZCOMPL if transaction finished,  else 0
XX   */
XX! tryz()
XX  {
XX  	register c, n;
XX  	register cmdzack1flg;
XX--- 1131,1137 ----
XX   *  Return ZFILE if Zmodem filename received, -1 on error,
XX   *   ZCOMPL if transaction finished,  else 0
XX   */
XX! int tryz()
XX  {
XX  	register c, n;
XX  	register cmdzack1flg;
XX***************
XX*** 1194,1200 ****
XX  /*
XX   * Receive 1 or more files with ZMODEM protocol
XX   */
XX! rzfiles()
XX  {
XX  	register c;
XX  
XX--- 1227,1233 ----
XX  /*
XX   * Receive 1 or more files with ZMODEM protocol
XX   */
XX! int rzfiles()
XX  {
XX  	register c;
XX  
XX***************
XX*** 1223,1229 ****
XX   * Receive a file with ZMODEM protocol
XX   *  Assumes file name frame is in secbuf
XX   */
XX! rzfile()
XX  {
XX  	register c, n;
XX  	long rxbytes;
XX--- 1256,1262 ----
XX   * Receive a file with ZMODEM protocol
XX   *  Assumes file name frame is in secbuf
XX   */
XX! int rzfile()
XX  {
XX  	register c, n;
XX  	long rxbytes;
XX***************
XX*** 1403,1409 ****
XX   * Send a string to the modem, processing for \336 (sleep 1 sec)
XX   *   and \335 (break signal)
XX   */
XX! zmputs(s)
XX  char *s;
XX  {
XX  	register c;
XX--- 1436,1442 ----
XX   * Send a string to the modem, processing for \336 (sleep 1 sec)
XX   *   and \335 (break signal)
XX   */
XX! void zmputs(s)
XX  char *s;
XX  {
XX  	register c;
XX***************
XX*** 1423,1431 ****
XX  /*
XX   * Close the receive dataset, return OK or ERROR
XX   */
XX! closeit()
XX  {
XX! 	time_t time(), q;
XX  
XX  #ifndef vax11c
XX  	if (Topipe) {
XX--- 1456,1464 ----
XX  /*
XX   * Close the receive dataset, return OK or ERROR
XX   */
XX! int closeit()
XX  {
XX! 	time_t q;
XX  
XX  #ifndef vax11c
XX  	if (Topipe) {
XX***************
XX*** 1443,1449 ****
XX  	if (Modtime) {
XX  		timep[0] = time(&q);
XX  		timep[1] = Modtime;
XX! 		utime(Pathname, timep);
XX  	}
XX  #endif
XX  	if ((Filemode&S_IFMT) == S_IFREG)
XX--- 1476,1482 ----
XX  	if (Modtime) {
XX  		timep[0] = time(&q);
XX  		timep[1] = Modtime;
XX! 		utime(Pathname, (struct utimbuf *) timep);
XX  	}
XX  #endif
XX  	if ((Filemode&S_IFMT) == S_IFREG)
XX***************
XX*** 1454,1460 ****
XX  /*
XX   * Ack a ZFIN packet, let byegones be byegones
XX   */
XX! ackbibi()
XX  {
XX  	register n;
XX  
XX--- 1487,1493 ----
XX  /*
XX   * Ack a ZFIN packet, let byegones be byegones
XX   */
XX! void ackbibi()
XX  {
XX  	register n;
XX  
XX***************
XX*** 1483,1489 ****
XX  /*
XX   * Local console output simulation
XX   */
XX! bttyout(c)
XX  {
XX  	if (Verbose || Fromcu)
XX  		putc(c, stderr);
XX--- 1516,1523 ----
XX  /*
XX   * Local console output simulation
XX   */
XX! void bttyout(c)
XX! int c;
XX  {
XX  	if (Verbose || Fromcu)
XX  		putc(c, stderr);
XX***************
XX*** 1493,1499 ****
XX  /*
XX   * Strip leading ! if present, do shell escape. 
XX   */
XX! sys2(s)
XX  register char *s;
XX  {
XX  	if (*s == '!')
XX--- 1527,1533 ----
XX  /*
XX   * Strip leading ! if present, do shell escape. 
XX   */
XX! int sys2(s)
XX  register char *s;
XX  {
XX  	if (*s == '!')
XX***************
XX*** 1503,1509 ****
XX  /*
XX   * Strip leading ! if present, do exec.
XX   */
XX! exec2(s)
XX  register char *s;
XX  {
XX  	if (*s == '!')
XX--- 1537,1543 ----
XX  /*
XX   * Strip leading ! if present, do exec.
XX   */
XX! void exec2(s)
XX  register char *s;
XX  {
XX  	if (*s == '!')
X/
Xecho x - sz.c.d
Xsed '/^X/s///' > sz.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/zmodem/sz.c  crc=37692  36259	Sat Apr 21 22:27:23 1990
XX--- /home/top/ast/minix/1.6.25/commands/zmodem/sz.c  crc=07010  37699	Tue Dec 22 10:25:05 1992
XX***************
XX*** 57,64 ****
XX   */
XX  
XX  
XX- char *substr(), *getenv();
XX- 
XX  #include <sys/types.h>
XX  
XX  #ifdef vax11c
XX--- 57,62 ----
XX***************
XX*** 67,77 ****
XX  #include <types.h>
XX  #include <stat.h>
XX  #define LOGFILE "szlog.tmp"
XX- #include <stdio.h>
XX- #include <signal.h>
XX- #include <setjmp.h>
XX- #include <ctype.h>
XX- #include <errno.h>
XX  #define OS "VMS"
XX  #define READCHECK
XX  #define BUFWRITE
XX--- 65,70 ----
XX***************
XX*** 83,105 ****
XX  
XX  #else	/* vax11c */
XX  
XX- void bibi();
XX  
XX- 
XX  #define SS_NORMAL 0
XX  #define LOGFILE "/tmp/szlog"
XX- #include <stdio.h>
XX- #include <signal.h>
XX- #include <setjmp.h>
XX- #include <ctype.h>
XX- #include <errno.h>
XX- extern int errno;
XX  
XX! #define sendline(c) putchar(c & 0377)
XX  #define xsendline(c) putchar(c)
XX  
XX  #endif
XX  
XX  #define PATHLEN 256
XX  #define OK 0
XX  #define FALSE 0
XX--- 76,101 ----
XX  
XX  #else	/* vax11c */
XX  
XX  
XX  #define SS_NORMAL 0
XX  #define LOGFILE "/tmp/szlog"
XX  
XX! #define sendline(c) putchar((c) & 0377)
XX  #define xsendline(c) putchar(c)
XX  
XX  #endif
XX  
XX+ #include <signal.h>
XX+ #include <setjmp.h>
XX+ #include <ctype.h>
XX+ #include <errno.h>
XX+ #include <stdlib.h>
XX+ #include <string.h>
XX+ #include <stdlib.h>
XX+ #include <unistd.h>
XX+ #include <utime.h>
XX+ #include <stdio.h>
XX+ 
XX  #define PATHLEN 256
XX  #define OK 0
XX  #define FALSE 0
XX***************
XX*** 224,229 ****
XX--- 220,256 ----
XX  jmp_buf tohere;		/* For the interrupt on RX timeout */
XX  jmp_buf intrjmp;	/* For the interrupt on RX CAN */
XX  
XX+ _PROTOTYPE(void onintr , (int sig ));
XX+ _PROTOTYPE(int main , (int argc , char *argv []));
XX+ _PROTOTYPE(int wcsend , (int argc , char *argp []));
XX+ _PROTOTYPE(int wcs , (char *oname ));
XX+ _PROTOTYPE(int wctxpn , (char *name ));
XX+ _PROTOTYPE(int getnak , (void));
XX+ _PROTOTYPE(int wctx , (long flen ));
XX+ _PROTOTYPE(int wcputsec , (char *buf , int sectnum , int cseclen ));
XX+ _PROTOTYPE(int filbuf , (char *buf , int count ));
XX+ _PROTOTYPE(int zfilbuf , (void));
XX+ _PROTOTYPE(int fooseek , (FILE *fptr , long pos , int whence ));
XX+ _PROTOTYPE(void alrm , (int sig ));
XX+ _PROTOTYPE(int readline , (int timeout ));
XX+ _PROTOTYPE(void flushmo , (void));
XX+ _PROTOTYPE(void purgeline , (void));
XX+ _PROTOTYPE(void canit , (void));
XX+ void zperr();
XX+ _PROTOTYPE(char *substr , (char *s , char *t ));
XX+ _PROTOTYPE(int usage , (void));
XX+ _PROTOTYPE(int getzrxinit , (void));
XX+ _PROTOTYPE(int sendzsinit , (void));
XX+ _PROTOTYPE(int zsendfile , (char *buf , int blen ));
XX+ _PROTOTYPE(int zsendfdata , (void));
XX+ _PROTOTYPE(int getinsync , (int flag ));
XX+ _PROTOTYPE(void saybibi , (void));
XX+ _PROTOTYPE(void bttyout , (int c ));
XX+ _PROTOTYPE(int zsendcmd , (char *buf , int blen ));
XX+ _PROTOTYPE(void chkinvok , (char *s ));
XX+ _PROTOTYPE(void countem , (int argc , char **argv ));
XX+ _PROTOTYPE(void chartest , (int m ));
XX+ 
XX  /* called by signal interrupt or terminate to clean things up */
XX  void bibi(n)
XX  int n;
XX***************
XX*** 252,258 ****
XX  #include "zm.c"
XX  
XX  
XX! main(argc, argv)
XX  char *argv[];
XX  {
XX  	register char *cp;
XX--- 279,286 ----
XX  #include "zm.c"
XX  
XX  
XX! int main(argc, argv)
XX! int argc;
XX  char *argv[];
XX  {
XX  	register char *cp;
XX***************
XX*** 462,471 ****
XX  	/*NOTREACHED*/
XX  }
XX  
XX! wcsend(argc, argp)
XX  char *argp[];
XX  {
XX! 	register n;
XX  
XX  	Crcflg=FALSE;
XX  	firstsec=TRUE;
XX--- 490,500 ----
XX  	/*NOTREACHED*/
XX  }
XX  
XX! int wcsend(argc, argp)
XX! int argc;
XX  char *argp[];
XX  {
XX! 	register int n;
XX  
XX  	Crcflg=FALSE;
XX  	firstsec=TRUE;
XX***************
XX*** 501,507 ****
XX  	return OK;
XX  }
XX  
XX! wcs(oname)
XX  char *oname;
XX  {
XX  	register c;
XX--- 530,536 ----
XX  	return OK;
XX  }
XX  
XX! int wcs(oname)
XX  char *oname;
XX  {
XX  	register c;
XX***************
XX*** 564,570 ****
XX   *  as provided by the Unix fstat call.
XX   *  N.B.: modifies the passed name, may extend it!
XX   */
XX! wctxpn(name)
XX  char *name;
XX  {
XX  	register char *p, *q;
XX--- 593,599 ----
XX   *  as provided by the Unix fstat call.
XX   *  N.B.: modifies the passed name, may extend it!
XX   */
XX! int wctxpn(name)
XX  char *name;
XX  {
XX  	register char *p, *q;
XX***************
XX*** 630,636 ****
XX  	return OK;
XX  }
XX  
XX! getnak()
XX  {
XX  	register firstch;
XX  
XX--- 659,665 ----
XX  	return OK;
XX  }
XX  
XX! int getnak()
XX  {
XX  	register firstch;
XX  
XX***************
XX*** 666,672 ****
XX  }
XX  
XX  
XX! wctx(flen)
XX  long flen;
XX  {
XX  	register int thisblklen;
XX--- 695,701 ----
XX  }
XX  
XX  
XX! int wctx(flen)
XX  long flen;
XX  {
XX  	register int thisblklen;
XX***************
XX*** 714,720 ****
XX  		return OK;
XX  }
XX  
XX! wcputsec(buf, sectnum, cseclen)
XX  char *buf;
XX  int sectnum;
XX  int cseclen;	/* data length of this sector to send */
XX--- 743,749 ----
XX  		return OK;
XX  }
XX  
XX! int wcputsec(buf, sectnum, cseclen)
XX  char *buf;
XX  int sectnum;
XX  int cseclen;	/* data length of this sector to send */
XX***************
XX*** 793,800 ****
XX  }
XX  
XX  /* fill buf with count chars padding with ^Z for CPM */
XX! filbuf(buf, count)
XX  register char *buf;
XX  {
XX  	register c, m;
XX  
XX--- 822,830 ----
XX  }
XX  
XX  /* fill buf with count chars padding with ^Z for CPM */
XX! int filbuf(buf, count)
XX  register char *buf;
XX+ int count;
XX  {
XX  	register c, m;
XX  
XX***************
XX*** 830,836 ****
XX  }
XX  
XX  /* Fill buffer with blklen chars */
XX! zfilbuf()
XX  {
XX  	int n;
XX  
XX--- 860,866 ----
XX  }
XX  
XX  /* Fill buffer with blklen chars */
XX! int zfilbuf()
XX  {
XX  	int n;
XX  
XX***************
XX*** 858,864 ****
XX  }
XX  
XX  #ifdef TXBSIZE
XX! fooseek(fptr, pos, whence)
XX  FILE *fptr;
XX  long pos;
XX  {
XX--- 888,894 ----
XX  }
XX  
XX  #ifdef TXBSIZE
XX! int fooseek(fptr, pos, whence)
XX  FILE *fptr;
XX  long pos;
XX  {
XX***************
XX*** 919,926 ****
XX  
XX  
XX  /* VARARGS1 */
XX! vfile(f, a, b, c)
XX! register char *f;
XX  {
XX  	if (Verbose > 2) {
XX  		fprintf(stderr, f, a, b, c);
XX--- 949,956 ----
XX  
XX  
XX  /* VARARGS1 */
XX! void vfile(f, a, b, c)
XX! register char *f,*a,*b,*c;
XX  {
XX  	if (Verbose > 2) {
XX  		fprintf(stderr, f, a, b, c);
XX***************
XX*** 941,947 ****
XX   * readline(timeout) reads character(s) from file descriptor 0
XX   * timeout is in tenths of seconds
XX   */
XX! readline(timeout)
XX  {
XX  	register int c;
XX  	static char byt[1];
XX--- 971,978 ----
XX   * readline(timeout) reads character(s) from file descriptor 0
XX   * timeout is in tenths of seconds
XX   */
XX! int readline(timeout)
XX! int timeout;
XX  {
XX  	register int c;
XX  	static char byt[1];
XX***************
XX*** 967,979 ****
XX  	return (byt[0]&0377);
XX  }
XX  
XX! flushmo()
XX  {
XX  	fflush(stdout);
XX  }
XX  
XX  
XX! purgeline()
XX  {
XX  #ifdef USG
XX  	ioctl(iofd, TCFLSH, 0);
XX--- 998,1010 ----
XX  	return (byt[0]&0377);
XX  }
XX  
XX! void flushmo()
XX  {
XX  	fflush(stdout);
XX  }
XX  
XX  
XX! void purgeline()
XX  {
XX  #ifdef USG
XX  	ioctl(iofd, TCFLSH, 0);
XX***************
XX*** 984,990 ****
XX  #endif
XX  
XX  /* send cancel string to get the other end to shut up */
XX! canit()
XX  {
XX  	static char canistr[] = {
XX  	 24,24,24,24,24,24,24,24,24,24,8,8,8,8,8,8,8,8,8,8,0
XX--- 1015,1021 ----
XX  #endif
XX  
XX  /* send cancel string to get the other end to shut up */
XX! void canit()
XX  {
XX  	static char canistr[] = {
XX  	 24,24,24,24,24,24,24,24,24,24,8,8,8,8,8,8,8,8,8,8,0
XX***************
XX*** 1004,1010 ****
XX   * Log an error
XX   */
XX  /*VARARGS1*/
XX! zperr(s,p,u)
XX  char *s, *p, *u;
XX  {
XX  	if (Verbose <= 0)
XX--- 1035,1041 ----
XX   * Log an error
XX   */
XX  /*VARARGS1*/
XX! void zperr(s,p,u)
XX  char *s, *p, *u;
XX  {
XX  	if (Verbose <= 0)
XX***************
XX*** 1084,1090 ****
XX  	""
XX  };
XX  
XX! usage()
XX  {
XX  	char **pp;
XX  
XX--- 1115,1121 ----
XX  	""
XX  };
XX  
XX! int usage()
XX  {
XX  	char **pp;
XX  
XX***************
XX*** 1100,1106 ****
XX  /*
XX   * Get the receiver's init parameters
XX   */
XX! getzrxinit()
XX  {
XX  	register n;
XX  	struct stat f;
XX--- 1131,1137 ----
XX  /*
XX   * Get the receiver's init parameters
XX   */
XX! int getzrxinit()
XX  {
XX  	register n;
XX  	struct stat f;
XX***************
XX*** 1205,1211 ****
XX  }
XX  
XX  /* Send send-init information */
XX! sendzsinit()
XX  {
XX  	register c;
XX  
XX--- 1236,1242 ----
XX  }
XX  
XX  /* Send send-init information */
XX! int sendzsinit()
XX  {
XX  	register c;
XX  
XX***************
XX*** 1235,1242 ****
XX  }
XX  
XX  /* Send file name and related info */
XX! zsendfile(buf, blen)
XX  char *buf;
XX  {
XX  	register c;
XX  	register UNSL long crc;
XX--- 1266,1274 ----
XX  }
XX  
XX  /* Send file name and related info */
XX! int zsendfile(buf, blen)
XX  char *buf;
XX+ int blen;
XX  {
XX  	register c;
XX  	register UNSL long crc;
XX***************
XX*** 1294,1303 ****
XX  }
XX  
XX  /* Send the data in the file */
XX! zsendfdata()
XX  {
XX  	register c, e, n;
XX! 	register newcnt;
XX  	register long tcount = 0;
XX  	int junkcount;		/* Counts garbage chars received by TX */
XX  	static int tleft = 6;	/* Counter for test mode */
XX--- 1326,1335 ----
XX  }
XX  
XX  /* Send the data in the file */
XX! int zsendfdata()
XX  {
XX  	register c, e, n;
XX! 	register int newcnt;
XX  	register long tcount = 0;
XX  	int junkcount;		/* Counts garbage chars received by TX */
XX  	static int tleft = 6;	/* Counter for test mode */
XX***************
XX*** 1498,1506 ****
XX  /*
XX   * Respond to receiver's complaint, get back in sync with receiver
XX   */
XX! getinsync(flag)
XX  {
XX! 	register c;
XX  
XX  	for (;;) {
XX  		if (Test) {
XX--- 1530,1539 ----
XX  /*
XX   * Respond to receiver's complaint, get back in sync with receiver
XX   */
XX! int getinsync(flag)
XX! int flag;
XX  {
XX! 	register int c;
XX  
XX  	for (;;) {
XX  		if (Test) {
XX***************
XX*** 1550,1556 ****
XX  
XX  
XX  /* Say "bibi" to the receiver, try to do it cleanly */
XX! saybibi()
XX  {
XX  	for (;;) {
XX  		stohdr(0L);		/* CAF Was zsbhdr - minor change */
XX--- 1583,1589 ----
XX  
XX  
XX  /* Say "bibi" to the receiver, try to do it cleanly */
XX! void saybibi()
XX  {
XX  	for (;;) {
XX  		stohdr(0L);		/* CAF Was zsbhdr - minor change */
XX***************
XX*** 1566,1580 ****
XX  }
XX  
XX  /* Local screen character display function */
XX! bttyout(c)
XX  {
XX  	if (Verbose)
XX  		putc(c, stderr);
XX  }
XX  
XX  /* Send command and related info */
XX! zsendcmd(buf, blen)
XX  char *buf;
XX  {
XX  	register c;
XX  	long cmdnum;
XX--- 1599,1615 ----
XX  }
XX  
XX  /* Local screen character display function */
XX! void bttyout(c)
XX! int c;
XX  {
XX  	if (Verbose)
XX  		putc(c, stderr);
XX  }
XX  
XX  /* Send command and related info */
XX! int zsendcmd(buf, blen)
XX  char *buf;
XX+ int blen;
XX  {
XX  	register c;
XX  	long cmdnum;
XX***************
XX*** 1628,1634 ****
XX  /*
XX   * If called as sb use YMODEM protocol
XX   */
XX! chkinvok(s)
XX  char *s;
XX  {
XX  #ifdef vax11c
XX--- 1663,1669 ----
XX  /*
XX   * If called as sb use YMODEM protocol
XX   */
XX! void chkinvok(s)
XX  char *s;
XX  {
XX  #ifdef vax11c
XX***************
XX*** 1655,1661 ****
XX  #endif
XX  }
XX  
XX! countem(argc, argv)
XX  register char **argv;
XX  {
XX  	register c;
XX--- 1690,1697 ----
XX  #endif
XX  }
XX  
XX! void countem(argc, argv)
XX! int argc;
XX  register char **argv;
XX  {
XX  	register c;
XX***************
XX*** 1681,1689 ****
XX  		  Filesleft, Totalleft);
XX  }
XX  
XX! chartest(m)
XX  {
XX! 	register n;
XX  
XX  	mode(m);
XX  	printf("\r\n\nCharacter Transparency Test Mode %d\r\n", m);
XX--- 1717,1726 ----
XX  		  Filesleft, Totalleft);
XX  }
XX  
XX! void chartest(m)
XX! int m;
XX  {
XX! 	register int n;
XX  
XX  	mode(m);
XX  	printf("\r\n\nCharacter Transparency Test Mode %d\r\n", m);
X/
Xecho x - zm.c.d
Xsed '/^X/s///' > zm.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/zmodem/zm.c  crc=33776  14905	Sat Apr 21 22:27:23 1990
XX--- /home/top/ast/minix/1.6.25/commands/zmodem/zm.c  crc=25265  15116	Sat Sep 19 21:04:46 1992
XX***************
XX*** 15,22 ****
XX  
XX  #ifndef CANFDX
XX  #include "zmodem.h"
XX- int Rxtimeout = 100;		/* Tenths of seconds to wait for something */
XX  #endif
XX  
XX  #ifndef UNSL
XX  #define UNSL
XX--- 15,22 ----
XX  
XX  #ifndef CANFDX
XX  #include "zmodem.h"
XX  #endif
XX+ int Rxtimeout = 100;		/* Tenths of seconds to wait for something */
XX  
XX  #ifndef UNSL
XX  #define UNSL
XX***************
XX*** 73,79 ****
XX  static char badcrc[] = "Bad CRC";
XX  
XX  /* Send ZMODEM binary header hdr of type type */
XX! zsbhdr(type, hdr)
XX  register char *hdr;
XX  {
XX  	register int n;
XX--- 73,80 ----
XX  static char badcrc[] = "Bad CRC";
XX  
XX  /* Send ZMODEM binary header hdr of type type */
XX! void zsbhdr(type, hdr)
XX! int type;
XX  register char *hdr;
XX  {
XX  	register int n;
XX***************
XX*** 105,112 ****
XX  
XX  
XX  /* Send ZMODEM binary header hdr of type type */
XX! zsbh32(hdr, type)
XX  register char *hdr;
XX  {
XX  	register int n;
XX  	register UNSL long crc;
XX--- 106,114 ----
XX  
XX  
XX  /* Send ZMODEM binary header hdr of type type */
XX! void zsbh32(hdr, type)
XX  register char *hdr;
XX+ int type;
XX  {
XX  	register int n;
XX  	register UNSL long crc;
XX***************
XX*** 126,132 ****
XX  }
XX  
XX  /* Send ZMODEM HEX header hdr of type type */
XX! zshhdr(type, hdr)
XX  register char *hdr;
XX  {
XX  	register int n;
XX--- 128,135 ----
XX  }
XX  
XX  /* Send ZMODEM HEX header hdr of type type */
XX! void zshhdr(type, hdr)
XX! int type;
XX  register char *hdr;
XX  {
XX  	register int n;
XX***************
XX*** 158,169 ****
XX   * Send binary array buf of length length, with ending ZDLE sequence frameend
XX   */
XX  static char *Zendnames[] = { "ZCRCE", "ZCRCG", "ZCRCQ", "ZCRCW"};
XX! zsdata(buf, length, frameend)
XX  register char *buf;
XX  {
XX  	register unsigned short crc;
XX  
XX! 	vfile("zsdata: %d %s", length, Zendnames[frameend-ZCRCE&3]);
XX  	if (Crc32t)
XX  		zsda32(buf, length, frameend);
XX  	else {
XX--- 161,175 ----
XX   * Send binary array buf of length length, with ending ZDLE sequence frameend
XX   */
XX  static char *Zendnames[] = { "ZCRCE", "ZCRCG", "ZCRCQ", "ZCRCW"};
XX! 
XX! void zsdata(buf, length, frameend)
XX  register char *buf;
XX+ int length;
XX+ int frameend;
XX  {
XX  	register unsigned short crc;
XX  
XX! 	vfile("zsdata: %d %s", length, Zendnames[(frameend-ZCRCE)&3]);
XX  	if (Crc32t)
XX  		zsda32(buf, length, frameend);
XX  	else {
XX***************
XX*** 182,189 ****
XX  	}
XX  }
XX  
XX! zsda32(buf, length, frameend)
XX  register char *buf;
XX  {
XX  	register int c;
XX  	register UNSL long crc;
XX--- 188,197 ----
XX  	}
XX  }
XX  
XX! void zsda32(buf, length, frameend)
XX  register char *buf;
XX+ int length;
XX+ int frameend;
XX  {
XX  	register int c;
XX  	register UNSL long crc;
XX***************
XX*** 211,218 ****
XX   *  and CRC.  Returns the ending character or error code.
XX   *  NB: On errors may store length+1 bytes!
XX   */
XX! zrdata(buf, length)
XX  register char *buf;
XX  {
XX  	register int c;
XX  	register unsigned short crc;
XX--- 219,227 ----
XX   *  and CRC.  Returns the ending character or error code.
XX   *  NB: On errors may store length+1 bytes!
XX   */
XX! int zrdata(buf, length)
XX  register char *buf;
XX+ int length;
XX  {
XX  	register int c;
XX  	register unsigned short crc;
XX***************
XX*** 244,250 ****
XX  				}
XX  				Rxcount = length - (end - buf);
XX  				vfile("zrdata: %d  %s", Rxcount,
XX! 				 Zendnames[d-GOTCRCE&3]);
XX  				return d;
XX  			case GOTCAN:
XX  				zperr("Sender Canceled");
XX--- 253,259 ----
XX  				}
XX  				Rxcount = length - (end - buf);
XX  				vfile("zrdata: %d  %s", Rxcount,
XX! 				 Zendnames[(d-GOTCRCE)&3]);
XX  				return d;
XX  			case GOTCAN:
XX  				zperr("Sender Canceled");
XX***************
XX*** 264,271 ****
XX  	return ERROR;
XX  }
XX  
XX! zrdat32(buf, length)
XX  register char *buf;
XX  {
XX  	register int c;
XX  	register UNSL long crc;
XX--- 273,281 ----
XX  	return ERROR;
XX  }
XX  
XX! int zrdat32(buf, length)
XX  register char *buf;
XX+ int length;
XX  {
XX  	register int c;
XX  	register UNSL long crc;
XX***************
XX*** 301,307 ****
XX  				}
XX  				Rxcount = length - (end - buf);
XX  				vfile("zrdat32: %d %s", Rxcount,
XX! 				 Zendnames[d-GOTCRCE&3]);
XX  				return d;
XX  			case GOTCAN:
XX  				zperr("Sender Canceled");
XX--- 311,317 ----
XX  				}
XX  				Rxcount = length - (end - buf);
XX  				vfile("zrdat32: %d %s", Rxcount,
XX! 				 Zendnames[(d-GOTCRCE)&3]);
XX  				return d;
XX  			case GOTCAN:
XX  				zperr("Sender Canceled");
XX***************
XX*** 332,339 ****
XX   *   Otherwise return negative on error.
XX   *   Return ERROR instantly if ZCRCW sequence, for fast error recovery.
XX   */
XX! zgethdr(hdr, eflag)
XX  char *hdr;
XX  {
XX  	register int c, n, cancount;
XX  
XX--- 342,350 ----
XX   *   Otherwise return negative on error.
XX   *   Return ERROR instantly if ZCRCW sequence, for fast error recovery.
XX   */
XX! int zgethdr(hdr, eflag)
XX  char *hdr;
XX+ int eflag;
XX  {
XX  	register int c, n, cancount;
XX  
XX***************
XX*** 450,456 ****
XX  }
XX  
XX  /* Receive a binary style header (type and position) */
XX! zrbhdr(hdr)
XX  register char *hdr;
XX  {
XX  	register int c, n;
XX--- 461,467 ----
XX  }
XX  
XX  /* Receive a binary style header (type and position) */
XX! int zrbhdr(hdr)
XX  register char *hdr;
XX  {
XX  	register int c, n;
XX***************
XX*** 485,491 ****
XX  }
XX  
XX  /* Receive a binary style header (type and position) with 32 bit FCS */
XX! zrbhdr32(hdr)
XX  register char *hdr;
XX  {
XX  	register int c, n;
XX--- 496,502 ----
XX  }
XX  
XX  /* Receive a binary style header (type and position) with 32 bit FCS */
XX! int zrbhdr32(hdr)
XX  register char *hdr;
XX  {
XX  	register int c, n;
XX***************
XX*** 529,535 ****
XX  
XX  
XX  /* Receive a hex style header (type and position) */
XX! zrhhdr(hdr)
XX  char *hdr;
XX  {
XX  	register int c;
XX--- 540,546 ----
XX  
XX  
XX  /* Receive a hex style header (type and position) */
XX! int zrhhdr(hdr)
XX  char *hdr;
XX  {
XX  	register int c;
XX***************
XX*** 574,580 ****
XX  }
XX  
XX  /* Send a byte as two hex digits */
XX! zputhex(c)
XX  register int c;
XX  {
XX  	static char	digits[]	= "0123456789abcdef";
XX--- 585,591 ----
XX  }
XX  
XX  /* Send a byte as two hex digits */
XX! void zputhex(c)
XX  register int c;
XX  {
XX  	static char	digits[]	= "0123456789abcdef";
XX***************
XX*** 589,595 ****
XX   * Send character c with ZMODEM escape sequence encoding.
XX   *  Escape XON, XOFF. Escape CR following @ (Telenet net escape)
XX   */
XX! zsendline(c)
XX  {
XX  
XX  	/* Quick check for non control characters */
XX--- 600,607 ----
XX   * Send character c with ZMODEM escape sequence encoding.
XX   *  Escape XON, XOFF. Escape CR following @ (Telenet net escape)
XX   */
XX! void zsendline(c)
XX! int c;
XX  {
XX  
XX  	/* Quick check for non control characters */
XX***************
XX*** 628,634 ****
XX  }
XX  
XX  /* Decode two lower case hex digits into an 8 bit byte value */
XX! zgethex()
XX  {
XX  	register int c;
XX  
XX--- 640,646 ----
XX  }
XX  
XX  /* Decode two lower case hex digits into an 8 bit byte value */
XX! int zgethex()
XX  {
XX  	register int c;
XX  
XX***************
XX*** 637,643 ****
XX  		vfile("zgethex: %02X", c);
XX  	return c;
XX  }
XX! zgeth1()
XX  {
XX  	register int c, n;
XX  
XX--- 649,655 ----
XX  		vfile("zgethex: %02X", c);
XX  	return c;
XX  }
XX! int zgeth1()
XX  {
XX  	register int c, n;
XX  
XX***************
XX*** 663,669 ****
XX   * Read a byte, checking for ZMODEM escape encoding
XX   *  including CAN*5 which represents a quick abort
XX   */
XX! zdlread()
XX  {
XX  	register int c;
XX  
XX--- 675,681 ----
XX   * Read a byte, checking for ZMODEM escape encoding
XX   *  including CAN*5 which represents a quick abort
XX   */
XX! int zdlread()
XX  {
XX  	register int c;
XX  
XX***************
XX*** 728,734 ****
XX   * Read a character from the modem line with timeout.
XX   *  Eat parity, XON and XOFF characters.
XX   */
XX! noxrd7()
XX  {
XX  	register int c;
XX  
XX--- 740,746 ----
XX   * Read a character from the modem line with timeout.
XX   *  Eat parity, XON and XOFF characters.
XX   */
XX! int noxrd7()
XX  {
XX  	register int c;
XX  
XX***************
XX*** 751,757 ****
XX  }
XX  
XX  /* Store long integer pos in Txhdr */
XX! stohdr(pos)
XX  long pos;
XX  {
XX  	Txhdr[ZP0] = pos;
XX--- 763,769 ----
XX  }
XX  
XX  /* Store long integer pos in Txhdr */
XX! void stohdr(pos)
XX  long pos;
XX  {
XX  	Txhdr[ZP0] = pos;
X/
Xecho x - zmodem.h.d
Xsed '/^X/s///' > zmodem.h.d << '/'
XX*** /home/top/ast/minix/1.5/commands/zmodem/zmodem.h  crc=30420   5487	Sat Apr 21 22:27:23 1990
XX--- /home/top/ast/minix/1.6.25/commands/zmodem/zmodem.h  crc=50786   6687	Sat Sep 19 21:04:47 1992
XX***************
XX*** 102,109 ****
XX  /* Parameters for ZCOMMAND frame ZF0 (otherwise 0) */
XX  #define ZCACK1	1	/* Acknowledge, then do command */
XX  
XX- long rclhdr();
XX- 
XX  /* Globals used by ZMODEM functions */
XX  extern Rxframeind;	/* ZBIN ZBIN32, or ZHEX type of frame received */
XX  extern Rxtype;		/* Type of header received */
XX--- 102,107 ----
XX***************
XX*** 119,123 ****
XX--- 117,161 ----
XX  extern Crc32;		/* Display flag indicating 32 bit CRC being received */
XX  extern Znulls;		/* Number of nulls to send at beginning of ZDATA hdr */
XX  extern char Attn[ZATTNLEN+1];	/* Attention string rx sends to tx on err */
XX+ 
XX+ /* crctab.c */
XX+ 
XX+ _PROTOTYPE(long UPDC32 , (int b , long c ));
XX+ 
XX+ /* rbsb.c */
XX+ 
XX+ _PROTOTYPE(void from_cu , (void));
XX+ _PROTOTYPE(void cucheck , (void));
XX+ _PROTOTYPE(int rdchk , (int f ));
XX+ _PROTOTYPE(int rdchk , (int f ));
XX+ _PROTOTYPE(int mode , (int n ));
XX+ _PROTOTYPE(void sendbrk , (void));
XX+ 
XX+ /* zm.c */
XX+ 
XX+ _PROTOTYPE(void zsbhdr , (int type , char *hdr ));
XX+ _PROTOTYPE(void zsbh32 , (char *hdr , int type ));
XX+ _PROTOTYPE(void zshhdr , (int type , char *hdr ));
XX+ _PROTOTYPE(void zsdata , (char *buf , int length , int frameend ));
XX+ _PROTOTYPE(void zsda32 , (char *buf , int length , int frameend ));
XX+ _PROTOTYPE(int zrdata , (char *buf , int length ));
XX+ _PROTOTYPE(int zrdat32 , (char *buf , int length ));
XX+ _PROTOTYPE(int zgethdr , (char *hdr , int eflag ));
XX+ _PROTOTYPE(int zrbhdr , (char *hdr ));
XX+ _PROTOTYPE(int zrbhdr32 , (char *hdr ));
XX+ _PROTOTYPE(int zrhhdr , (char *hdr ));
XX+ _PROTOTYPE(void zputhex , (int c ));
XX+ _PROTOTYPE(void zsendline , (int c ));
XX+ _PROTOTYPE(int zgethex , (void));
XX+ _PROTOTYPE(int zgeth1 , (void));
XX+ _PROTOTYPE(int zdlread , (void));
XX+ _PROTOTYPE(int noxrd7 , (void));
XX+ _PROTOTYPE(void stohdr , (long pos ));
XX+ _PROTOTYPE(long rclhdr , (char *hdr ));
XX+ 
XX+ /* rz.c sz.c */
XX+ 
XX+ void vfile();
XX+ _PROTOTYPE(void bibi , (int n ));
XX  
XX  /* End of ZMODEM.H */
X/
/
