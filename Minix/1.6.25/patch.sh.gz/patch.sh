echo x - patch.cd
sed '/^X/s///' > patch.cd << '/'
Xecho x - Makefile.d
Xsed '/^X/s///' > Makefile.d << '/'
XX*** /home/top/ast/minix/1.5/commands/patch/Makefile  crc=23131    425	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/patch/Makefile  crc=10331    543	Tue Feb  2 00:03:02 1993
XX***************
XX*** 1,15 ****
XX! CFLAGS=-DCHARSPRINTF			# patch for old compiler
XX! obj = patch.s pch.s inp.s util.s version.s
XX  
XX! patch: $(obj)
XX! 	cc -i -o patch $(obj)
XX  
XX! patch.s: config.h common.h patch.c inp.h pch.h util.h version.h
XX! pch.s: config.h common.h pch.c pch.h util.h
XX! inp.s: config.h common.h inp.c inp.h util.h
XX! util.s: config.h common.h util.c util.h
XX! version.s: config.h common.h version.c version.h patchlevel.h util.h
XX  
XX  
XX  clean:	
XX! 	@rm -f *.bak *.s patch
XX--- 1,21 ----
XX! # Makefile for patch
XX  
XX! CFLAGS= -O -DVOIDSIG -wo -D_MINIX -D_POSIX_SOURCE -DSMALL -m
XX! O=o
XX  
XX! OBJ = patch.$O pch.$O inp.$O util.$O version.$O
XX  
XX+ patch: $(OBJ)
XX+ 	@rm -rf patch
XX+ 	@echo Start linking patch
XX+ 	@cc -i -s -o patch $(OBJ) >/dev/null
XX  
XX+ patch.$O:	config.h common.h patch.c inp.h pch.h util.h version.h
XX+ pch.$O:		config.h common.h pch.c pch.h util.h
XX+ inp.$O:		config.h common.h inp.c inp.h util.h
XX+ util.$O:	config.h common.h util.c util.h
XX+ version.$O:	config.h common.h version.c version.h patchlevel.h util.h
XX+ 
XX+ 
XX  clean:	
XX! 	@rm -f *.bak *.o *.s core patch
X/
Xecho x - common.h.d
Xsed '/^X/s///' > common.h.d << '/'
XX*** /home/top/ast/minix/1.5/commands/patch/common.h  crc=16318   3962	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/patch/common.h  crc=50037   4021	Mon Feb  1 23:59:19 1993
XX***************
XX*** 15,20 ****
XX--- 15,26 ----
XX  #define DEBUGGING
XX  
XX  #include "config.h"
XX+ #include <sys/types.h>
XX+ #include <fcntl.h>
XX+ #include <stdlib.h>
XX+ #include <string.h>
XX+ #include <unistd.h>
XX+ #include <stdio.h>
XX  
XX  /* shut lint up about the following when return value ignored */
XX  
XX***************
XX*** 77,83 ****
XX  
XX  /* typedefs */
XX  
XX! typedef char bool;
XX  typedef long LINENUM;			/* must be signed */
XX  typedef unsigned MEM;			/* what to feed malloc */
XX  
XX--- 83,89 ----
XX  
XX  /* typedefs */
XX  
XX! typedef int bool;
XX  typedef long LINENUM;			/* must be signed */
XX  typedef unsigned MEM;			/* what to feed malloc */
XX  
XX***************
XX*** 114,119 ****
XX--- 120,128 ----
XX  EXT char TMPINNAME[] INIT("/tmp/patchiXXXXXX");	/* might want /usr/tmp here */
XX  EXT char TMPREJNAME[] INIT("/tmp/patchrXXXXXX");
XX  EXT char TMPPATNAME[] INIT("/tmp/patchpXXXXXX");
XX+ #ifdef SMALL
XX+ EXT char TMPSTRNAME[] INIT("/tmp/patchsXXXXXX");
XX+ #endif
XX  EXT bool toutkeep INIT(FALSE);
XX  EXT bool trejkeep INIT(FALSE);
XX  
XX***************
XX*** 144,158 ****
XX  
XX  EXT char *revision INIT(Nullch);	/* prerequisite revision, if any */
XX  
XX! char *malloc();
XX! char *realloc();
XX! char *strcpy();
XX! char *strcat();
XX! long atol();
XX! long lseek();
XX! char *mktemp();
XX! #ifdef CHARSPRINTF
XX! char *sprintf();
XX! #else
XX! int sprintf();
XX! #endif
XX--- 153,156 ----
XX  
XX  EXT char *revision INIT(Nullch);	/* prerequisite revision, if any */
XX  
XX! _PROTOTYPE(void my_exit , (int status ));
X/
Xecho x - inp.c.d
Xsed '/^X/s///' > inp.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/patch/inp.c  crc=39182   8134	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/patch/inp.c  crc=46594   8197	Mon Feb  1 23:59:20 1993
XX***************
XX*** 45,51 ****
XX--- 45,53 ----
XX  	i_ptr = Null(char **);
XX      }
XX      else {
XX+ #ifndef SMALL
XX  	using_plan_a = TRUE;		/* maybe the next one is smaller */
XX+ #endif
XX  	Close(tifd);
XX  	tifd = -1;
XX  	free(tibuf[0]);
XX***************
XX*** 62,68 ****
XX--- 64,72 ----
XX  scan_input(filename)
XX  char *filename;
XX  {
XX+ #ifndef SMALL
XX      if (!plan_a(filename))
XX+ #endif
XX  	plan_b(filename);
XX      if (verbose) {
XX  	say3("Patching file %s using Plan %s...\n", filename,
XX***************
XX*** 70,75 ****
XX--- 74,80 ----
XX      }
XX  }
XX  
XX+ #ifndef SMALL
XX  /* Try keeping everything in memory. */
XX  
XX  bool
XX***************
XX*** 193,198 ****
XX--- 198,204 ----
XX      }
XX      return TRUE;			/* plan a will work */
XX  }
XX+ #endif
XX  
XX  /* Keep (virtually) nothing in memory. */
XX  
X/
Xecho x - inp.h.d
Xsed '/^X/s///' > inp.h.d << '/'
XX*** /home/top/ast/minix/1.5/commands/patch/inp.h  crc=42843    473	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/patch/inp.h  crc=17957    630	Mon Aug 31 00:51:59 1992
XX***************
XX*** 10,18 ****
XX  EXT LINENUM last_frozen_line INIT(0);	/* how many input lines have been */
XX  					/* irretractibly output */
XX  
XX! bool rev_in_string();
XX! void scan_input();
XX! bool plan_a();			/* returns false if insufficient memory */
XX! void plan_b();
XX! char *ifetch();
XX! 
XX--- 10,18 ----
XX  EXT LINENUM last_frozen_line INIT(0);	/* how many input lines have been */
XX  					/* irretractibly output */
XX  
XX! _PROTOTYPE(bool rev_in_string , (char *string ));
XX! _PROTOTYPE(void scan_input , (char *filename ));
XX! _PROTOTYPE(bool plan_a , (char *filename )); 
XX! _PROTOTYPE(void plan_b , (char *filename ));
XX! _PROTOTYPE(char *ifetch , (Reg1 LINENUM line , int whichbuf ));
XX! _PROTOTYPE(void re_input , (void));
X/
Xecho x - patch.c.d
Xsed '/^X/s///' > patch.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/patch/patch.c  crc=64308  19018	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/patch/patch.c  crc=62253  19649	Mon Feb  1 23:59:21 1993
XX***************
XX*** 86,91 ****
XX--- 86,96 ----
XX   * Initial revision
XX   * 
XX   */
XX+ /*
XX+  * 1992-01-15
XX+  * Modified by Saeko & Kouichi Hirabayashi to fit small memory (64K+64K)
XX+  * system by adding "#if[n]def SMALL" parts.
XX+  */
XX  
XX  #include "INTERN.h"
XX  #include "common.h"
XX***************
XX*** 97,120 ****
XX  
XX  /* procedures */
XX  
XX! void reinitialize_almost_everything();
XX! void get_some_switches();
XX! LINENUM locate_hunk();
XX! void abort_hunk();
XX! void apply_hunk();
XX! void init_output();
XX! void init_reject();
XX! void copy_till();
XX! void spew_output();
XX! void dump_line();
XX! bool patch_match();
XX! bool similar();
XX! void re_input();
XX! void my_exit();
XX  
XX  /* Apply a set of diffs as appropriate. */
XX  
XX! main(argc,argv)
XX  int argc;
XX  char **argv;
XX  {
XX--- 102,124 ----
XX  
XX  /* procedures */
XX  
XX! _PROTOTYPE(int main , (int argc , char **argv ));
XX! _PROTOTYPE(void reinitialize_almost_everything , (void));
XX! _PROTOTYPE(void get_some_switches , (void));
XX! _PROTOTYPE(LINENUM locate_hunk , (LINENUM fuzz ));
XX! _PROTOTYPE(void abort_hunk , (void));
XX! _PROTOTYPE(void apply_hunk , (LINENUM where ));
XX! _PROTOTYPE(void init_output , (char *name ));
XX! _PROTOTYPE(void init_reject , (char *name ));
XX! _PROTOTYPE(void copy_till , (Reg1 LINENUM lastline ));
XX! _PROTOTYPE(void spew_output , (void));
XX! _PROTOTYPE(void dump_line , (LINENUM line ));
XX! _PROTOTYPE(bool patch_match , (LINENUM base , LINENUM offset , LINENUM fuzz ));
XX! _PROTOTYPE(bool similar , (Reg1 char *a , Reg2 char *b , Reg3 int len ));
XX  
XX  /* Apply a set of diffs as appropriate. */
XX  
XX! int main(argc,argv)
XX  int argc;
XX  char **argv;
XX  {
XX***************
XX*** 134,139 ****
XX--- 138,146 ----
XX      Mktemp(TMPINNAME);
XX      Mktemp(TMPREJNAME);
XX      Mktemp(TMPPATNAME);
XX+ #ifdef SMALL
XX+     Mktemp(TMPSTRNAME);
XX+ #endif
XX  
XX      /* parse switches */
XX      Argc = argc;
XX***************
XX*** 291,297 ****
XX  		Strcpy(rejname, outname);
XX  #ifndef FLEXFILENAMES
XX  		{
XX- 		    char *rindex();
XX  		    char *s = rindex(rejname,'/');
XX  
XX  		    if (!s)
XX--- 298,303 ----
XX***************
XX*** 317,322 ****
XX--- 323,331 ----
XX  	}
XX  	set_signals(1);
XX      }
XX+ #ifdef SMALL
XX+     Fclose(sfp);
XX+ #endif
XX      my_exit(failtotal);
XX  }
XX  
XX***************
XX*** 820,824 ****
XX--- 829,836 ----
XX  	Unlink(TMPREJNAME);
XX      }
XX      Unlink(TMPPATNAME);
XX+ #ifdef SMALL
XX+     Unlink(TMPSTRNAME);
XX+ #endif
XX      exit(status);
XX  }
X/
Xecho x - pch.c.d
Xsed '/^X/s///' > pch.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/patch/pch.c  crc=64812  28639	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/patch/pch.c  crc=34046  31784	Mon Feb  1 23:59:22 1993
XX***************
XX*** 46,52 ****
XX--- 46,56 ----
XX  static LINENUM p_max;			/* max allowed value of p_end */
XX  static LINENUM p_context = 3;		/* # of context lines */
XX  static LINENUM p_input_line = 0;	/* current line # from patch file */
XX+ #ifdef SMALL
XX+ static long *p_line = Null(long *);	/* the text of the hunk */
XX+ #else
XX  static char **p_line = Null(char**);	/* the text of the hunk */
XX+ #endif
XX  static short *p_len = Null(short*);	/* length of each line */
XX  static char *p_char = Nullch;		/* +, -, and ! */
XX  static int hunkmax = INITHUNKMAX;	/* size of above arrays to begin with */
XX***************
XX*** 103,110 ****
XX--- 107,122 ----
XX  set_hunkmax()
XX  {
XX  #ifndef lint
XX+ #ifdef SMALL
XX+     if (p_line == Null(long*))
XX+ #else
XX      if (p_line == Null(char**))
XX+ #endif
XX+ #ifdef SMALL
XX+ 	p_line = (long *) malloc((MEM)hunkmax * sizeof(long));
XX+ #else
XX  	p_line = (char**) malloc((MEM)hunkmax * sizeof(char *));
XX+ #endif
XX      if (p_len == Null(short*))
XX  	p_len  = (short*) malloc((MEM)hunkmax * sizeof(short));
XX  #endif
XX***************
XX*** 123,135 ****
XX--- 135,159 ----
XX       * since p_len can move into p_line's old space, and p_char can move into
XX       * p_len's old space.  Not on PDP-11's however.  But it doesn't matter.
XX       */
XX+ #ifdef SMALL
XX+     assert(p_line != Null(long*) && p_len != Null(short*) && p_char != Nullch);
XX+ #else
XX      assert(p_line != Null(char**) && p_len != Null(short*) && p_char != Nullch);
XX+ #endif
XX  #ifndef lint
XX+ #ifdef SMALL
XX+     p_line = (long*) realloc((char*)p_line, (MEM)hunkmax * sizeof(long));
XX+ #else
XX      p_line = (char**) realloc((char*)p_line, (MEM)hunkmax * sizeof(char *));
XX+ #endif
XX      p_len  = (short*) realloc((char*)p_len,  (MEM)hunkmax * sizeof(short));
XX      p_char = (char*)  realloc((char*)p_char, (MEM)hunkmax * sizeof(char));
XX  #endif
XX+ #ifdef SMALL
XX+     if (p_line != Null(long*) && p_len != Null(short*) && p_char != Nullch)
XX+ #else
XX      if (p_line != Null(char**) && p_len != Null(short*) && p_char != Nullch)
XX+ #endif
XX  	return;
XX      if (!using_plan_a)
XX  	fatal1("patch: out of memory (grow_hunkmax)\n");
XX***************
XX*** 419,430 ****
XX--- 443,463 ----
XX      while (p_end >= 0) {
XX  	if (p_end == p_efake)
XX  	    p_end = p_bfake;		/* don't free twice */
XX+ #ifndef SMALL
XX  	else
XX  	    free(p_line[p_end]);
XX+ #endif
XX  	p_end--;
XX      }
XX      assert(p_end == -1);
XX      p_efake = -1;
XX+ #ifdef SMALL
XX+     if (sfp != Nullfp)
XX+ 	Fclose(sfp);
XX+     sfp = fopen(TMPSTRNAME, "w");
XX+     if (sfp == Nullfp)
XX+ 	fatal2("patch: can't create %s.\n", TMPSTRNAME);
XX+ #endif
XX  
XX      p_max = hunkmax;			/* gets reduced when --- found */
XX      if (diff_type == CONTEXT_DIFF || diff_type == NEW_CONTEXT_DIFF) {
XX***************
XX*** 473,480 ****
XX--- 506,518 ----
XX  #ifdef zilog
XX  	    p_line[(short)p_end] = Nullch;
XX  #else
XX+ #ifdef SMALL
XX+ 	    p_line[p_end] = -1L;
XX+ 	    p_len[p_end] = 0;
XX+ #else
XX  	    p_line[p_end] = Nullch;
XX  #endif
XX+ #endif
XX  	    switch (*buf) {
XX  	    case '*':
XX  		if (strnEQ(buf, "********", 8)) {
XX***************
XX*** 494,504 ****
XX--- 532,546 ----
XX  		    fatal3("Unexpected *** at line %ld: %s", p_input_line, buf);
XX  		}
XX  		context = 0;
XX+ #ifdef SMALL
XX+ 		p_line[p_end] = saveStr(buf, p_len+p_end);
XX+ #else
XX  		p_line[p_end] = savestr(buf);
XX  		if (out_of_mem) {
XX  		    p_end--;
XX  		    return FALSE;
XX  		}
XX+ #endif
XX  		for (s=buf; *s && !isdigit(*s); s++) ;
XX  		if (!*s)
XX  		    goto malformed;
XX***************
XX*** 559,569 ****
XX--- 601,615 ----
XX  		    repl_beginning = p_end;
XX  		    repl_backtrack_position = ftell(pfp);
XX  		    repl_patch_line = p_input_line;
XX+ #ifdef SMALL
XX+ 		    p_line[p_end] = saveStr(buf, p_len+p_end);
XX+ #else
XX  		    p_line[p_end] = savestr(buf);
XX  		    if (out_of_mem) {
XX  			p_end--;
XX  			return FALSE;
XX  		    }
XX+ #endif
XX  		    p_char[p_end] = '=';
XX  		    for (s=buf; *s && !isdigit(*s); s++) ;
XX  		    if (!*s)
XX***************
XX*** 608,618 ****
XX--- 654,668 ----
XX  			p_context = context;
XX  		    context = -1000;
XX  		}
XX+ #ifdef SMALL
XX+ 		p_line[p_end] = saveStr(buf+2, p_len+p_end);
XX+ #else
XX  		p_line[p_end] = savestr(buf+2);
XX  		if (out_of_mem) {
XX  		    p_end--;
XX  		    return FALSE;
XX  		}
XX+ #endif
XX  		break;
XX  	    case '\t': case '\n':	/* assume the 2 spaces got eaten */
XX  		if (repl_beginning && repl_could_be_missing &&
XX***************
XX*** 620,630 ****
XX--- 670,684 ----
XX  		    repl_missing = TRUE;
XX  		    goto hunk_done;
XX  		}
XX+ #ifdef SMALL
XX+ 		p_line[p_end] = saveStr(buf, p_len+p_end);
XX+ #else
XX  		p_line[p_end] = savestr(buf);
XX  		if (out_of_mem) {
XX  		    p_end--;
XX  		    return FALSE;
XX  		}
XX+ #endif
XX  		if (p_end != p_ptrn_lines + 1) {
XX  		    ptrn_spaces_eaten |= (repl_beginning != 0);
XX  		    context++;
XX***************
XX*** 642,652 ****
XX--- 696,710 ----
XX  		context++;
XX  		if (!repl_beginning)
XX  		    ptrn_copiable++;
XX+ #ifdef SMALL
XX+ 		p_line[p_end] = saveStr(buf+2, p_len+p_end);
XX+ #else
XX  		p_line[p_end] = savestr(buf+2);
XX  		if (out_of_mem) {
XX  		    p_end--;
XX  		    return FALSE;
XX  		}
XX+ #endif
XX  		break;
XX  	    default:
XX  		if (repl_beginning && repl_could_be_missing) {
XX***************
XX*** 657,666 ****
XX--- 715,726 ----
XX  	    }
XX  	    /* set up p_len for strncmp() so we don't have to */
XX  	    /* assume null termination */
XX+ #ifndef SMALL
XX  	    if (p_line[p_end])
XX  		p_len[p_end] = strlen(p_line[p_end]);
XX  	    else
XX  		p_len[p_end] = 0;
XX+ #endif
XX  	}
XX  	
XX      hunk_done:
XX***************
XX*** 671,678 ****
XX--- 731,740 ----
XX  	    
XX  	    /* reset state back to just after --- */
XX  	    p_input_line = repl_patch_line;
XX+ #ifndef SMALL
XX  	    for (p_end--; p_end > repl_beginning; p_end--)
XX  		free(p_line[p_end]);
XX+ #endif
XX  	    Fseek(pfp, repl_backtrack_position, 0);
XX  	    
XX  	    /* redundant 'new' context lines were omitted - set */
XX***************
XX*** 761,771 ****
XX--- 823,837 ----
XX  	p_newfirst = min;
XX  	p_repl_lines = max - min + 1;
XX  	Sprintf(buf, "*** %ld,%ld\n", p_first, p_first + p_ptrn_lines - 1);
XX+ #ifdef SMALL
XX+ 	p_line[0] = saveStr(buf, p_len);
XX+ #else
XX  	p_line[0] = savestr(buf);
XX  	if (out_of_mem) {
XX  	    p_end = -1;
XX  	    return FALSE;
XX  	}
XX+ #endif
XX  	p_char[0] = '*';
XX  	for (i=1; i<=p_ptrn_lines; i++) {
XX  	    ret = pgets(buf, sizeof buf, pfp);
XX***************
XX*** 775,786 ****
XX--- 841,858 ----
XX  		  p_input_line);
XX  	    if (*buf != '<')
XX  		fatal2("< expected at line %ld of patch.\n", p_input_line);
XX+ #ifdef SMALL
XX+ 	    p_line[i] = saveStr(buf+2, p_len+i);
XX+ #else
XX  	    p_line[i] = savestr(buf+2);
XX  	    if (out_of_mem) {
XX  		p_end = i-1;
XX  		return FALSE;
XX  	    }
XX+ #endif
XX+ #ifndef SMALL
XX  	    p_len[i] = strlen(p_line[i]);
XX+ #endif
XX  	    p_char[i] = '-';
XX  	}
XX  	if (hunk_type == 'c') {
XX***************
XX*** 793,803 ****
XX--- 865,879 ----
XX  		fatal2("--- expected at line %ld of patch.\n", p_input_line);
XX  	}
XX  	Sprintf(buf, "--- %ld,%ld\n", min, max);
XX+ #ifdef SMALL
XX+ 	p_line[i] = saveStr(buf, p_len+i);
XX+ #else
XX  	p_line[i] = savestr(buf);
XX  	if (out_of_mem) {
XX  	    p_end = i-1;
XX  	    return FALSE;
XX  	}
XX+ #endif
XX  	p_char[i] = '=';
XX  	for (i++; i<=p_end; i++) {
XX  	    ret = pgets(buf, sizeof buf, pfp);
XX***************
XX*** 807,824 ****
XX--- 883,910 ----
XX  		    p_input_line);
XX  	    if (*buf != '>')
XX  		fatal2("> expected at line %ld of patch.\n", p_input_line);
XX+ #ifdef SMALL
XX+ 	    p_line[i] = saveStr(buf+2, p_len+i);
XX+ #else
XX  	    p_line[i] = savestr(buf+2);
XX  	    if (out_of_mem) {
XX  		p_end = i-1;
XX  		return FALSE;
XX  	    }
XX+ #endif
XX+ #ifndef SMALL
XX  	    p_len[i] = strlen(p_line[i]);
XX+ #endif
XX  	    p_char[i] = '+';
XX  	}
XX      }
XX      if (reverse)			/* backwards patch? */
XX  	if (!pch_swap())
XX  	    say1("Not enough memory to swap next hunk!\n");
XX+ #ifdef SMALL
XX+     Fclose(sfp);
XX+     sfp = fopen(TMPSTRNAME, "r");
XX+ #endif
XX  #ifdef DEBUGGING
XX      if (debug & 2) {
XX  	int i;
XX***************
XX*** 829,835 ****
XX--- 915,925 ----
XX  		special = '^';
XX  	    else
XX  		special = ' ';
XX+ #ifdef SMALL
XX+ 	    fprintf(stderr, "%3d %c %c %s", i, p_char[i], special, pfetch(i));
XX+ #else
XX  	    fprintf(stderr, "%3d %c %c %s", i, p_char[i], special, p_line[i]);
XX+ #endif
XX  	    Fflush(stderr);
XX  	}
XX      }
XX***************
XX*** 839,844 ****
XX--- 929,938 ----
XX      return TRUE;
XX  
XX  malformed:
XX+ #ifdef SMALL
XX+     Fclose(sfp);
XX+     sfp = Nullfp;
XX+ #endif
XX      fatal3("Malformed patch at line %ld: %s", p_input_line, buf);
XX  		/* about as informative as "Syntax error" in C */
XX      return FALSE;	/* for lint */
XX***************
XX*** 875,881 ****
XX--- 969,979 ----
XX  bool
XX  pch_swap()
XX  {
XX+ #ifdef SMALL
XX+     long *tp_line;		/* the text of the hunk */
XX+ #else
XX      char **tp_line;		/* the text of the hunk */
XX+ #endif
XX      short *tp_len;		/* length of each line */
XX      char *tp_char;		/* +, -, and ! */
XX      Reg1 LINENUM i;
XX***************
XX*** 892,904 ****
XX--- 990,1014 ----
XX      tp_line = p_line;
XX      tp_len = p_len;
XX      tp_char = p_char;
XX+ #ifdef SMALL
XX+     p_line = Null(long*);	/* force set_hunkmax to allocate again */
XX+ #else
XX      p_line = Null(char**);	/* force set_hunkmax to allocate again */
XX+ #endif
XX      p_len = Null(short*);
XX      p_char = Nullch;
XX      set_hunkmax();
XX+ #ifdef SMALL
XX+     if (p_line == Null(long*) || p_len == Null(short*) || p_char == Nullch) {
XX+ #else
XX      if (p_line == Null(char**) || p_len == Null(short*) || p_char == Nullch) {
XX+ #endif
XX  #ifndef lint
XX+ #ifdef SMALL
XX+ 	if (p_line == Null(long*))
XX+ #else
XX  	if (p_line == Null(char**))
XX+ #endif
XX  	    free((char*)p_line);
XX  	p_line = tp_line;
XX  	if (p_len == Null(short*))
XX***************
XX*** 942,958 ****
XX--- 1052,1076 ----
XX      }
XX      assert(p_char[0] == '=');
XX      p_char[0] = '*';
XX+ #ifdef SMALL
XX+     strEdit(p_line[0], '*', '-');
XX+ #else
XX      for (s=p_line[0]; *s; s++)
XX  	if (*s == '-')
XX  	    *s = '*';
XX+ #endif
XX  
XX      /* now turn the old into the new */
XX  
XX      assert(tp_char[0] == '*');
XX      tp_char[0] = '=';
XX+ #ifdef SMALL
XX+     strEdit(tp_line[0], '-', '*');
XX+ #else
XX      for (s=tp_line[0]; *s; s++)
XX  	if (*s == '*')
XX  	    *s = '-';
XX+ #endif
XX      for (i=0; n <= p_end; i++,n++) {
XX  	p_line[n] = tp_line[i];
XX  	p_char[n] = tp_char[i];
XX***************
XX*** 965,971 ****
XX--- 1083,1093 ----
XX      p_ptrn_lines = p_repl_lines;
XX      p_repl_lines = i;
XX  #ifndef lint
XX+ #ifdef SMALL
XX+     if (tp_line == Null(long*))
XX+ #else
XX      if (tp_line == Null(char**))
XX+ #endif
XX  	free((char*)tp_line);
XX      if (tp_len == Null(short*))
XX  	free((char*)tp_len);
XX***************
XX*** 1043,1054 ****
XX--- 1165,1233 ----
XX  
XX  /* Return a pointer to a particular patch line. */
XX  
XX+ #ifdef SMALL
XX+ long
XX+ saveStr(str, plen)
XX+ char *str;
XX+ short *plen;
XX+ {
XX+     long pos, ftell();
XX+     int len;
XX+ 
XX+     pos = ftell(sfp);
XX+     len = strlen(str);
XX+     fwrite(str, sizeof(char), len+1, sfp);
XX+     *plen = len;
XX+     return pos;
XX+ }
XX+ 
XX  char *
XX  pfetch(line)
XX  LINENUM line;
XX  {
XX+     static char *s, strbuf[BUFSIZ];
XX+     int i, c;
XX+ 
XX+     if (p_line[line] == -1L)
XX+ 	return Nullch;
XX+     else {
XX+ 	Fseek(sfp, p_line[line], 0);
XX+ 	for (i = 0, s = strbuf;
XX+ 		i < BUFSIZ && (c = fgetc(sfp)) != EOF && c; i++)
XX+ 	    *s++ = c;
XX+ 	if (i == BUFSIZ)
XX+ 		fatal2("too long line (%.40s ..\n", strbuf);
XX+     }
XX+     *s = '\0';
XX+     return strbuf;
XX+ }
XX+ 
XX+ void
XX+ strEdit(pos, to, from)
XX+ long pos;
XX+ int to, from;
XX+ {
XX+     static char *s, strbuf[BUFSIZ];
XX+     int i, c;
XX+ 
XX+     if (pos != -1L) {
XX+ 	for (i = 0, s = strbuf;
XX+ 		i < BUFSIZ && (c = fgetc(sfp)) != EOF && c; i++)
XX+ 	    *s++ = c;
XX+ 	for (s = strbuf; *s; s++)
XX+ 	    if (*s == from)
XX+ 		*s = to;
XX+ 	fwrite(strbuf, sizeof(char), i+1, sfp);
XX+     }
XX+ }
XX+ #else
XX+ char *
XX+ pfetch(line)
XX+ LINENUM line;
XX+ {
XX      return p_line[line];
XX  }
XX+ #endif
XX  
XX  /* Return where in the patch file this hunk began, for error messages. */
XX  
XX***************
XX*** 1067,1073 ****
XX      Reg2 long beginning_of_this_line;
XX      Reg3 bool this_line_is_command = FALSE;
XX      Reg4 FILE *pipefp;
XX-     FILE *popen();
XX  
XX      if (!skip_rest_of_patch) {
XX  	Unlink(TMPOUTNAME);
XX--- 1246,1251 ----
X/
Xecho x - pch.h.d
Xsed '/^X/s///' > pch.h.d << '/'
XX*** /home/top/ast/minix/1.5/commands/patch/pch.h  crc=52303    780	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/patch/pch.h  crc=33270   1514	Mon Feb  1 23:59:22 1993
XX***************
XX*** 10,36 ****
XX   */
XX  
XX  EXT FILE *pfp INIT(Nullfp);		/* patch file pointer */
XX  
XX! void re_patch();
XX! void open_patch_file();
XX! void set_hunkmax();
XX! void grow_hunkmax();
XX! bool there_is_another_patch();
XX! int intuit_diff_type();
XX! void next_intuit_at();
XX! void skip_to();
XX! bool another_hunk();
XX! bool pch_swap();
XX! char *pfetch();
XX! short pch_line_len();
XX! LINENUM pch_first();
XX! LINENUM pch_ptrn_lines();
XX! LINENUM pch_newfirst();
XX! LINENUM pch_repl_lines();
XX! LINENUM pch_end();
XX! LINENUM pch_context();
XX! LINENUM pch_hunk_beg();
XX! char pch_char();
XX! char *pfetch();
XX! char *pgets();
XX! void do_ed_script();
XX--- 10,42 ----
XX   */
XX  
XX  EXT FILE *pfp INIT(Nullfp);		/* patch file pointer */
XX+ #ifdef SMALL
XX+ EXT FILE *sfp INIT(Nullfp);		/* string file pointer */
XX+ #endif
XX  
XX! _PROTOTYPE(void re_patch , (void));
XX! _PROTOTYPE(void open_patch_file , (char *filename ));
XX! _PROTOTYPE(void set_hunkmax , (void));
XX! _PROTOTYPE(void grow_hunkmax , (void));
XX! _PROTOTYPE(bool there_is_another_patch , (void));
XX! _PROTOTYPE(int intuit_diff_type , (void));
XX! _PROTOTYPE(void next_intuit_at , (long file_pos , long file_line ));
XX! _PROTOTYPE(void skip_to , (long file_pos , long file_line ));
XX! _PROTOTYPE(bool another_hunk , (void));
XX! _PROTOTYPE(char *pgets , (char *bf , int sz , FILE *fp ));
XX! _PROTOTYPE(bool pch_swap , (void));
XX! _PROTOTYPE(LINENUM pch_first , (void));
XX! _PROTOTYPE(LINENUM pch_ptrn_lines , (void));
XX! _PROTOTYPE(LINENUM pch_newfirst , (void));
XX! _PROTOTYPE(LINENUM pch_repl_lines , (void));
XX! _PROTOTYPE(LINENUM pch_end , (void));
XX! _PROTOTYPE(LINENUM pch_context , (void));
XX! _PROTOTYPE(short pch_line_len , (LINENUM line ));
XX! _PROTOTYPE(char pch_char , (LINENUM line ));
XX! _PROTOTYPE(char *pfetch , (LINENUM line ));
XX! _PROTOTYPE(LINENUM pch_hunk_beg , (void));
XX! _PROTOTYPE(void do_ed_script , (void));
XX! #ifdef SMALL
XX! _PROTOTYPE(long saveStr , (char *string , short *length ));
XX! _PROTOTYPE(void strEdit , (long pos , int from , int to ));
XX! #endif
X/
Xecho x - util.c.d
Xsed '/^X/s///' > util.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/patch/util.c  crc=47722   7348	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/patch/util.c  crc=26810   7307	Mon Feb  1 23:59:23 1993
XX***************
XX*** 25,31 ****
XX  	if (fromfd < 0)
XX  	    fatal2("patch: internal error, can't reopen %s\n", from);
XX  	while ((i=read(fromfd, buf, sizeof buf)) > 0)
XX! 	    if (write(1, buf, i) != 1)
XX  		fatal1("patch: write failed\n");
XX  	Close(fromfd);
XX  	return 0;
XX--- 25,31 ----
XX  	if (fromfd < 0)
XX  	    fatal2("patch: internal error, can't reopen %s\n", from);
XX  	while ((i=read(fromfd, buf, sizeof buf)) > 0)
XX! 	    if (write(1, buf, i) != i)
XX  		fatal1("patch: write failed\n");
XX  	Close(fromfd);
XX  	return 0;
XX***************
XX*** 173,180 ****
XX  char *pat;
XX  long arg1,arg2,arg3;
XX  {
XX-     void my_exit();
XX- 
XX      say(pat, arg1, arg2, arg3);
XX      my_exit(1);
XX  }
XX--- 173,178 ----
XX***************
XX*** 231,237 ****
XX  set_signals(reset)
XX  int reset;
XX  {
XX-     void my_exit();
XX  #ifndef lint
XX  #ifdef VOIDSIG
XX      static void (*hupval)(),(*intval)();
XX--- 229,234 ----
X/
Xecho x - util.h.d
Xsed '/^X/s///' > util.h.d << '/'
XX*** /home/top/ast/minix/1.5/commands/patch/util.h  crc=49418   1972	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/patch/util.h  crc=23661   2234	Mon Aug 31 00:52:00 1992
XX***************
XX*** 62,74 ****
XX  
XX  EXT char serrbuf[BUFSIZ];		/* buffer for stderr */
XX  
XX! char *fetchname();
XX! int move_file();
XX! void copy_file();
XX  void say();
XX  void fatal();
XX  void ask();
XX! char *savestr();
XX! void set_signals();
XX! void ignore_signals();
XX! void makedirs();
XX--- 62,74 ----
XX  
XX  EXT char serrbuf[BUFSIZ];		/* buffer for stderr */
XX  
XX! _PROTOTYPE(int move_file , (char *from , char *to ));
XX! _PROTOTYPE(void copy_file , (char *from , char *to ));
XX! _PROTOTYPE(char *savestr , (Reg1 char *s ));
XX  void say();
XX  void fatal();
XX  void ask();
XX! _PROTOTYPE(void set_signals , (int reset ));
XX! _PROTOTYPE(void ignore_signals , (void));
XX! _PROTOTYPE(void makedirs , (Reg1 char *filename , bool striplast ));
XX! _PROTOTYPE(char *fetchname , (char *at , int strip_leading , int assume_exists ));
X/
Xecho x - version.h.d
Xsed '/^X/s///' > version.h.d << '/'
XX*** /home/top/ast/minix/1.5/commands/patch/version.h  crc=57737    185	Sat Apr 21 22:27:22 1990
XX--- /home/top/ast/minix/1.6.25/commands/patch/version.h  crc=31244    204	Mon Aug 31 00:52:01 1992
XX***************
XX*** 6,9 ****
XX   * 
XX   */
XX  
XX! void version();
XX--- 6,9 ----
XX   * 
XX   */
XX  
XX! _PROTOTYPE(void version , (void));
X/
/
