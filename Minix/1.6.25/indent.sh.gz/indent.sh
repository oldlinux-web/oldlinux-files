echo x - proto.h
sed '/^X/s///' > proto.h << '/'
X/* _PROTOTYPE(   void diag, (int level,char *msg, int a, int b)    ); */
Xvoid diag();			/* HACK.  should be varargs */
X
X_PROTOTYPE(   void set_profile, (void )    );
X_PROTOTYPE(   void scan_profile, (FILE *f)    );
X_PROTOTYPE(   int eqin, (char *s1,char *s2)    );
X_PROTOTYPE(   void set_defaults, (void )    );
X_PROTOTYPE(   void set_option, (char *arg)    );
X_PROTOTYPE(   void pr_comment, (void )    );
X_PROTOTYPE(   void main, (int argc,char * *argv)    );
X_PROTOTYPE(   void bakcopy, (void )    );
X_PROTOTYPE(   void dump_line, (void )    );
X_PROTOTYPE(   int code_target, (void )    );
X_PROTOTYPE(   int label_target, (void )    );
X_PROTOTYPE(   void fill_buffer, (void )    );
X_PROTOTYPE(   int pad_output, (int current,int target)    );
X_PROTOTYPE(   int count_spaces, (int current,char *buffer)    );
X_PROTOTYPE(   void writefdef, (struct fstate *f,int nm)    );
X_PROTOTYPE(   char *chfont, (struct fstate *of,struct fstate *nf,char *s)    );
X_PROTOTYPE(   void parsefont, (struct fstate *f,char *s0)    );
X_PROTOTYPE(   int lexi, (void )    );
X_PROTOTYPE(   void addkey, (char *key,int val)    );
X_PROTOTYPE(   void makext, (char *newname,char *newext)    );
X_PROTOTYPE(   void parse, (int tk)    );
X_PROTOTYPE(   void reduce, (void )    );
X
/
echo x - indent.cd
sed '/^X/s///' > indent.cd << '/'
Xecho x - Makefile.d
Xsed '/^X/s///' > Makefile.d << '/'
XX*** /home/top/ast/minix/1.5/commands/indent/Makefile  crc=53488    245	Sat Apr 21 22:27:18 1990
XX--- /home/top/ast/minix/1.6.25/commands/indent/Makefile  crc=29620    313	Sat Jan 30 20:12:16 1993
XX***************
XX*** 1,15 ****
XX! # makefile for the 'indent' command
XX  
XX! CFLAGS = -F -T. -Dlint
XX  
XX! OBJS = indent.s io.s lexi.s parse.s comment.s args.s
XX  
XX! indent: ${OBJS}
XX! 	$(CC) -i -T. -o indent ${OBJS}
XX! 	chmem =60000 indent
XX  
XX! $(OBJS): globs.h codes.h
XX  
XX! 
XX! clean:	
XX! 	@rm -f *.bak *.s indent
XX--- 1,17 ----
XX! # Makefile for indent
XX  
XX! CFLAGS= -c -O -D_MINIX -D_POSIX_SOURCE
XX! O=o
XX  
XX! OBJ = args.$O comment.$O lexi.$O indent.$O parse.$O io.$O
XX  
XX! indent: ${OBJ}
XX! 	@rm -rf indent
XX! 	@echo Start linking indent
XX! 	@$(CC) -o indent -i ${OBJ} >/dev/null
XX! 	@chmem =60000 indent
XX  
XX! $(OBJ): globs.h codes.h
XX  
XX! clean:
XX! 	@rm -f *.bak *.o *.s core indent
X/
Xecho x - args.c.d
Xsed '/^X/s///' > args.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/indent/args.c  crc=31427   8076	Sat Apr 21 22:27:18 1990
XX--- /home/top/ast/minix/1.6.25/commands/indent/args.c  crc=49927   8081	Sun Aug 23 12:04:01 1992
XX***************
XX*** 24,36 ****
XX   */
XX  
XX  #define PUBLIC extern
XX- #include "globs.h"
XX  #include <sys/types.h>
XX  #include <ctype.h>
XX  
XX- extern char *getenv(), *index();
XX- extern char *malloc();
XX- 
XX  /* profile types */
XX  #define	PRO_SPECIAL	1		/* special case */
XX  #define	PRO_BOOL	2		/* boolean */
XX--- 24,36 ----
XX   */
XX  
XX  #define PUBLIC extern
XX  #include <sys/types.h>
XX  #include <ctype.h>
XX+ #include <string.h>
XX+ #include <stdlib.h>
XX+ #include "globs.h"
XX+ #include "proto.h"
XX  
XX  /* profile types */
XX  #define	PRO_SPECIAL	1		/* special case */
XX  #define	PRO_BOOL	2		/* boolean */
XX***************
XX*** 135,141 ****
XX   * set_profile reads $HOME/.indent.pro and ./.indent.pro and handles
XX   * arguments given in these files.
XX   */
XX! set_profile()
XX  {
XX     register FILE  *f;
XX     char            fname[BUFSIZ];
XX--- 135,141 ----
XX   * set_profile reads $HOME/.indent.pro and ./.indent.pro and handles
XX   * arguments given in these files.
XX   */
XX! void set_profile()
XX  {
XX     register FILE  *f;
XX     char            fname[BUFSIZ];
XX***************
XX*** 154,160 ****
XX     }
XX  }
XX  
XX! scan_profile(f)
XX     register FILE  *f;
XX  {
XX     register int    i;
XX--- 154,160 ----
XX     }
XX  }
XX  
XX! void scan_profile(f)
XX     register FILE  *f;
XX  {
XX     register int    i;
XX***************
XX*** 163,169 ****
XX  
XX     while (1)
XX     {
XX!       for (p = buf; (i = getc(f)) != EOF && (*p = i) > ' '; ++p);
XX        if (p != buf)
XX        {
XX  	 *p++ = 0;
XX--- 163,169 ----
XX  
XX     while (1)
XX     {
XX!       for (p = buf; (i = getc(f)) != EOF && (*p = (char)i) > ' '; ++p);
XX        if (p != buf)
XX        {
XX  	 *p++ = 0;
XX***************
XX*** 177,183 ****
XX  
XX  char           *param_start;
XX  
XX! eqin(s1, s2)
XX     register char  *s1;
XX     register char  *s2;
XX  {
XX--- 177,183 ----
XX  
XX  char           *param_start;
XX  
XX! int eqin(s1, s2)
XX     register char  *s1;
XX     register char  *s2;
XX  {
XX***************
XX*** 193,199 ****
XX  /*
XX   * Set the defaults.
XX   */
XX! set_defaults()
XX  {
XX     register struct pro *p;
XX  
XX--- 193,199 ----
XX  /*
XX   * Set the defaults.
XX   */
XX! void set_defaults()
XX  {
XX     register struct pro *p;
XX  
XX***************
XX*** 205,215 ****
XX  	 *p->p_obj = p->p_default;
XX  }
XX  
XX! set_option(arg)
XX     register char  *arg;
XX  {
XX     register struct pro *p;
XX-    extern int      atoi();
XX  
XX     arg++;				/* ignore leading "-" */
XX     for (p = pro; p->p_name; p++)
XX--- 205,214 ----
XX  	 *p->p_obj = p->p_default;
XX  }
XX  
XX! void set_option(arg)
XX     register char  *arg;
XX  {
XX     register struct pro *p;
XX  
XX     arg++;				/* ignore leading "-" */
XX     for (p = pro; p->p_name; p++)
X/
Xecho x - comment.c.d
Xsed '/^X/s///' > comment.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/indent/comment.c  crc=64413  12931	Sat Apr 21 22:27:18 1990
XX--- /home/top/ast/minix/1.6.25/commands/indent/comment.c  crc=64345  13006	Thu Jul 16 23:17:10 1992
XX***************
XX*** 44,71 ****
XX  
XX  
XX  #define PUBLIC extern
XX  #include "globs.h"
XX  
XX  
XX! pr_comment()
XX  {
XX     int             now_col;		/* column we are in now */
XX     int             adj_max_col;		/* Adjusted max_col for when we
XX! 					   decide to spill comments
XX! 					   over the right margin */
XX     char           *last_bl;		/* points to the last blank in
XX! 					   the output buffer */
XX     char           *t_ptr;		/* used for moving string */
XX     int             unix_comment;	/* tri-state variable used to
XX! 					   decide if it is a unix-style
XX! 					   comment. 0 means only blanks
XX! 					   since /*, 1 means regular
XX! 					   style comment, 2 means unix
XX! 					   style comment */
XX     int             break_delim = del_on_bl;
XX     int             l_just_saw_decl = ps.just_saw_decl;
XX!    /* int         ps.last_nl = 0;	/* true iff the last
XX!       significant thing weve seen is a newline */
XX     int             one_liner = 1;	/* true iff this comment is a
XX  					   one-liner */
XX     adj_max_col = max_col;
XX--- 44,82 ----
XX  
XX  
XX  #define PUBLIC extern
XX+ #include <stdlib.h>
XX  #include "globs.h"
XX+ #include "proto.h"
XX  
XX  
XX! void pr_comment()
XX  {
XX     int             now_col;		/* column we are in now */
XX+ 
XX     int             adj_max_col;		/* Adjusted max_col for when we
XX! 					 * decide to spill comments
XX! 					 *  over the right margin
XX! 					 */
XX! 
XX     char           *last_bl;		/* points to the last blank in
XX! 					 * the output buffer 
XX! 					 */
XX! 
XX     char           *t_ptr;		/* used for moving string */
XX+ 
XX     int             unix_comment;	/* tri-state variable used to
XX! 					 * decide if it is a unix-style
XX! 					 * comment. 0 means only blanks
XX! 					 * since / *, 1 means regular
XX! 					 * style comment, 2 means unix
XX! 					 * style comment 
XX! 					 */
XX! 
XX     int             break_delim = del_on_bl;
XX     int             l_just_saw_decl = ps.just_saw_decl;
XX!    /* int         ps.last_nl = 0; */	/* true iff the last
XX! 				      	   sig thing we have seen is a nl */
XX! 
XX     int             one_liner = 1;	/* true iff this comment is a
XX  					   one-liner */
XX     adj_max_col = max_col;
XX***************
XX*** 94,100 ****
XX        if (*buf_ptr == '-' || *buf_ptr == '*')
XX        {
XX  	 ps.box_com = true;		/* a comment with a '-' or '*'
XX! 					   immediately after the /* is
XX  					   assumed to be a boxed
XX  					   comment */
XX  	 break_delim = 0;
XX--- 105,111 ----
XX        if (*buf_ptr == '-' || *buf_ptr == '*')
XX        {
XX  	 ps.box_com = true;		/* a comment with a '-' or '*'
XX! 					   immediately after the / * is
XX  					   assumed to be a boxed
XX  					   comment */
XX  	 break_delim = 0;
XX***************
XX*** 139,145 ****
XX  	 buf_ptr++;
XX     }
XX     ps.comment_delta = 0;
XX!    *e_com++ = '/';			/* put '/*' into buffer */
XX     *e_com++ = '*';
XX     if (*buf_ptr != ' ' && !ps.box_com)
XX        *e_com++ = ' ';
XX--- 150,156 ----
XX  	 buf_ptr++;
XX     }
XX     ps.comment_delta = 0;
XX!    *e_com++ = '/';			/* put '/ *' into buffer */
XX     *e_com++ = '*';
XX     if (*buf_ptr != ' ' && !ps.box_com)
XX        *e_com++ = ' ';
X/
Xecho x - globs.h.d
Xsed '/^X/s///' > globs.h.d << '/'
XX*** /home/top/ast/minix/1.5/commands/indent/globs.h  crc=03534  11920	Sat Apr 21 22:27:18 1990
XX--- /home/top/ast/minix/1.6.25/commands/indent/globs.h  crc=22637  11898	Thu Jul 16 23:17:11 1992
XX***************
XX*** 166,172 ****
XX     char            size;
XX     int             allcaps;
XX  };
XX- char           *chfont();
XX  
XX  PUBLIC struct fstate
XX                  keywordf,		/* keyword font */
XX--- 166,171 ----
XX***************
XX*** 192,198 ****
XX  					   "boxed" comment. In that
XX  					   case, the first non-blank
XX  					   char should be lined up with
XX! 					   the / in /* */
XX     int             comment_delta, n_comment_delta;
XX     int             cast_mask;		/* indicates which close parens
XX  					   close off casts */
XX--- 191,197 ----
XX  					   "boxed" comment. In that
XX  					   case, the first non-blank
XX  					   char should be lined up with
XX! 					   the / in / *     */
XX     int             comment_delta, n_comment_delta;
XX     int             cast_mask;		/* indicates which close parens
XX  					   close off casts */
XX***************
XX*** 293,299 ****
XX     int             its_a_keyword;
XX     int             sizeof_keyword;
XX     int             dumped_decl_indent;
XX!    long            case_indent;		/* The distance to indent case
XX  					   labels from the switch
XX  					   statement */
XX     int             in_par_decl;
XX--- 292,298 ----
XX     int             its_a_keyword;
XX     int             sizeof_keyword;
XX     int             dumped_decl_indent;
XX!    int            case_indent;		/* The distance to indent case
XX  					   labels from the switch
XX  					   statement */
XX     int             in_par_decl;
X/
Xecho x - indent.c.d
Xsed '/^X/s///' > indent.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/indent/indent.c  crc=37707  38344	Sat Apr 21 22:27:18 1990
XX--- /home/top/ast/minix/1.6.25/commands/indent/indent.c  crc=56075  38517	Sun Aug 23 12:04:02 1992
XX***************
XX*** 18,39 ****
XX   * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
XX   */
XX  
XX  #define	PUBLIC
XX  #define NAME_SIZE 14
XX  
XX  #include "globs.h"
XX  #include "codes.h"
XX! #include <ctype.h>
XX  
XX- extern char *malloc();
XX- 
XX  char           *in_name = "Standard Input";	/* will always point to
XX  						   name of input file */
XX  char           *out_name = "Standard Output";	/* will always point to
XX  						   name of output file */
XX  char            bakfile[60];
XX  
XX! main(argc, argv)
XX     int             argc;
XX     char          **argv;
XX  {
XX--- 18,46 ----
XX   * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
XX   */
XX  
XX+ /* ported to MINIX by: Robert R. Hall <hall@pnet01.cts.com>  */
XX+ 
XX  #define	PUBLIC
XX  #define NAME_SIZE 14
XX  
XX+ #include <ctype.h>
XX+ #include <string.h>
XX+ #include <sys/types.h>
XX+ #include <fcntl.h>
XX+ #include <unistd.h>
XX+ #include <stdlib.h>
XX+ #include <stdio.h>
XX  #include "globs.h"
XX  #include "codes.h"
XX! #include "proto.h"
XX  
XX  char           *in_name = "Standard Input";	/* will always point to
XX  						   name of input file */
XX  char           *out_name = "Standard Output";	/* will always point to
XX  						   name of output file */
XX  char            bakfile[60];
XX  
XX! void main(argc, argv)
XX     int             argc;
XX     char          **argv;
XX  {
XX***************
XX*** 371,380 ****
XX  	    if (flushed_nl)		/* if we flushed a newline,
XX  					   make sure it is put back */
XX  	       force_nl = true;
XX! 	    if (type_code == sp_paren && *token == 'i'
XX! 		&& last_else && ps.else_if
XX! 		|| type_code == sp_nparen && *token == 'e'
XX! 		&& e_code != s_code && e_code[-1] == '}')
XX  	       force_nl = false;
XX  
XX  	    if (sc_end == 0)
XX--- 378,387 ----
XX  	    if (flushed_nl)		/* if we flushed a newline,
XX  					   make sure it is put back */
XX  	       force_nl = true;
XX! 	    if ((type_code == sp_paren && *token == 'i'
XX! 		    && last_else && ps.else_if)
XX! 		|| (type_code == sp_nparen && *token == 'e'
XX! 		    && e_code != s_code && e_code[-1] == '}'))
XX  	       force_nl = false;
XX  
XX  	    if (sc_end == 0)
XX***************
XX*** 668,674 ****
XX  	 break;
XX  
XX        case binary_op:			/* any binary operation */
XX-    do_binary:
XX  	 if (ps.want_blank)
XX  	    *e_code++ = ' ';
XX  	 {
XX--- 675,680 ----
XX***************
XX*** 1214,1220 ****
XX  		  *sc_end++ = ' ';
XX  		  --line_no;
XX  	       }
XX! 	       bcopy(s_lab + com_start, sc_end, com_end - com_start);
XX  	       sc_end += com_end - com_start;
XX  	       if (sc_end >= &save_com[sc_size])
XX  		  abort();
XX--- 1220,1226 ----
XX  		  *sc_end++ = ' ';
XX  		  --line_no;
XX  	       }
XX! 	       memcpy(sc_end, s_lab + com_start, com_end - com_start);
XX  	       sc_end += com_end - com_start;
XX  	       if (sc_end >= &save_com[sc_size])
XX  		  abort();
XX***************
XX*** 1284,1292 ****
XX  					   newline character will cause
XX  					   the line to be printed */
XX  
XX!       case comment:			/* we have gotten a /*  this is
XX  					   a biggie */
XX-    proc_comment:
XX  	 if (flushed_nl)
XX  	 {				/* we should force a broken
XX  					   line here */
XX--- 1290,1297 ----
XX  					   newline character will cause
XX  					   the line to be printed */
XX  
XX!       case comment:			/* we have gotten a / *  this is
XX  					   a biggie */
XX  	 if (flushed_nl)
XX  	 {				/* we should force a broken
XX  					   line here */
XX***************
XX*** 1305,1318 ****
XX        if (type_code != comment && type_code != newline && type_code != preesc)
XX  	 ps.last_token = type_code;
XX     }					/* end of main while (1) loop */
XX! };
XX  
XX  /*
XX   * copy input file to backup file if in_name is /blah/blah/blah/file, then
XX   * backup file will be ".Bfile" then make the backup file the input and
XX   * original input file the output
XX   */
XX! bakcopy()
XX  {
XX     int             n, bakchn;
XX     char            buff[8 * 1024];
XX--- 1310,1323 ----
XX        if (type_code != comment && type_code != newline && type_code != preesc)
XX  	 ps.last_token = type_code;
XX     }					/* end of main while (1) loop */
XX! }
XX  
XX  /*
XX   * copy input file to backup file if in_name is /blah/blah/blah/file, then
XX   * backup file will be ".Bfile" then make the backup file the input and
XX   * original input file the output
XX   */
XX! void bakcopy()
XX  {
XX     int             n, bakchn;
XX     char            buff[8 * 1024];
X/
Xecho x - io.c.d
Xsed '/^X/s///' > io.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/indent/io.c  crc=55584  15223	Sat Apr 21 22:27:19 1990
XX--- /home/top/ast/minix/1.6.25/commands/indent/io.c  crc=60378  15368	Sun Aug 23 12:04:03 1992
XX***************
XX*** 19,32 ****
XX   */
XX  
XX  #define PUBLIC extern
XX- #include "globs.h"
XX  #include <ctype.h>
XX  
XX  
XX  int             comment_open;
XX  static          paren_target;
XX  
XX! dump_line()
XX  {					/* dump_line is the routine
XX  					   that actually effects the
XX  					   printing of the new source.
XX--- 19,35 ----
XX   */
XX  
XX  #define PUBLIC extern
XX  #include <ctype.h>
XX+ #include <string.h>
XX+ #include <stdlib.h>
XX+ #include "globs.h"
XX+ #include "proto.h"
XX  
XX  
XX  int             comment_open;
XX  static          paren_target;
XX  
XX! void dump_line()
XX  {					/* dump_line is the routine
XX  					   that actually effects the
XX  					   printing of the new source.
XX***************
XX*** 267,275 ****
XX     paren_target = -ps.paren_indents[ps.paren_level - 1];
XX     not_first_line = 1;
XX     return;
XX! };
XX  
XX! code_target()
XX  {
XX     register        target_col = ps.ind_size * ps.ind_level + 1;
XX  
XX--- 270,278 ----
XX     paren_target = -ps.paren_indents[ps.paren_level - 1];
XX     not_first_line = 1;
XX     return;
XX! }
XX  
XX! int code_target()
XX  {
XX     register        target_col = ps.ind_size * ps.ind_level + 1;
XX  
XX***************
XX*** 295,301 ****
XX     return target_col;
XX  }
XX  
XX! label_target()
XX  {
XX     return
XX        ps.pcase ? (int) (case_ind * ps.ind_size) + 1
XX--- 298,304 ----
XX     return target_col;
XX  }
XX  
XX! int label_target()
XX  {
XX     return
XX        ps.pcase ? (int) (case_ind * ps.ind_size) + 1
XX***************
XX*** 319,325 ****
XX   * buffer from temporary buffer
XX   *
XX   */
XX! int
XX  fill_buffer()
XX  {					/* this routine reads stuff
XX  					   from the input */
XX--- 322,328 ----
XX   * buffer from temporary buffer
XX   *
XX   */
XX! void
XX  fill_buffer()
XX  {					/* this routine reads stuff
XX  					   from the input */
XX***************
XX*** 348,354 ****
XX  	 had_eof = true;
XX  	 break;
XX        }
XX!       *p++ = i;
XX        if (i == '\n')
XX  	 break;
XX     }
XX--- 351,357 ----
XX  	 had_eof = true;
XX  	 break;
XX        }
XX!       *p++ = (char)i;
XX        if (i == '\n')
XX  	 break;
XX     }
XX***************
XX*** 408,414 ****
XX        while (*p++ != '\n');
XX     }
XX     return;
XX! };
XX  
XX  /*
XX   * Copyright (C) 1976 by the Board of Trustees of the University of Illinois
XX--- 411,417 ----
XX        while (*p++ != '\n');
XX     }
XX     return;
XX! }
XX  
XX  /*
XX   * Copyright (C) 1976 by the Board of Trustees of the University of Illinois
XX***************
XX*** 438,444 ****
XX   * HISTORY: initial coding 	November 1976	D A Willcox of CAC
XX   *
XX   */
XX! pad_output(current, target)		/* writes tabs and blanks (if
XX  					   necessary) to get the
XX  					   current output position up
XX  					   to the target column */
XX--- 441,447 ----
XX   * HISTORY: initial coding 	November 1976	D A Willcox of CAC
XX   *
XX   */
XX! int pad_output(current, target)		/* writes tabs and blanks (if
XX  					   necessary) to get the
XX  					   current output position up
XX  					   to the target column */
XX***************
XX*** 464,470 ****
XX  	 putc(' ', output);		/* pad with final blanks */
XX     }
XX     return (target);
XX! };
XX  
XX  /*
XX   * Copyright (C) 1976 by the Board of Trustees of the University of Illinois
XX--- 467,473 ----
XX  	 putc(' ', output);		/* pad with final blanks */
XX     }
XX     return (target);
XX! }
XX  
XX  /*
XX   * Copyright (C) 1976 by the Board of Trustees of the University of Illinois
XX***************
XX*** 524,534 ****
XX        }					/* end of switch */
XX     }					/* end of for loop */
XX     return (cur);
XX! };
XX  
XX  int             found_err;
XX! diag(level, msg, a, b)
XX  char *msg;
XX  {
XX     if (level)
XX        found_err = 1;
XX--- 527,539 ----
XX        }					/* end of switch */
XX     }					/* end of for loop */
XX     return (cur);
XX! }
XX  
XX  int             found_err;
XX! void diag(level, msg, a, b)
XX! int level;
XX  char *msg;
XX+ int a, b;
XX  {
XX     if (level)
XX        found_err = 1;
XX***************
XX*** 545,552 ****
XX     }
XX  }
XX  
XX! writefdef(f, nm)
XX     register struct fstate *f;
XX  {
XX     fprintf(output, ".ds f%c %s\n.nr s%c %d\n",
XX  	   nm, f->font, nm, f->size);
XX--- 550,558 ----
XX     }
XX  }
XX  
XX! void writefdef(f, nm)
XX     register struct fstate *f;
XX+    int nm;
XX  {
XX     fprintf(output, ".ds f%c %s\n.nr s%c %d\n",
XX  	   nm, f->font, nm, f->size);
XX***************
XX*** 577,600 ****
XX        if (nf->size < of->size)
XX        {
XX  	 *s++ = '-';
XX! 	 *s++ = '0' + of->size - nf->size;
XX        } else
XX        {
XX  	 *s++ = '+';
XX! 	 *s++ = '0' + nf->size - of->size;
XX        }
XX     }
XX     return s;
XX  }
XX  
XX  
XX! parsefont(f, s0)
XX     register struct fstate *f;
XX     char           *s0;
XX  {
XX     register char  *s = s0;
XX     int             sizedelta = 0;
XX!    bzero(f, sizeof *f);
XX     while (*s)
XX     {
XX        if (isdigit(*s))
XX--- 583,606 ----
XX        if (nf->size < of->size)
XX        {
XX  	 *s++ = '-';
XX! 	 *s++ = (char)'0' + of->size - nf->size;
XX        } else
XX        {
XX  	 *s++ = '+';
XX! 	 *s++ = (char)'0' + nf->size - of->size;
XX        }
XX     }
XX     return s;
XX  }
XX  
XX  
XX! void parsefont(f, s0)
XX     register struct fstate *f;
XX     char           *s0;
XX  {
XX     register char  *s = s0;
XX     int             sizedelta = 0;
XX!    memset(f, '\0', sizeof *f);
XX     while (*s)
XX     {
XX        if (isdigit(*s))
X/
Xecho x - lexi.c.d
Xsed '/^X/s///' > lexi.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/indent/lexi.c  crc=53666  14234	Sat Apr 21 22:27:19 1990
XX--- /home/top/ast/minix/1.6.25/commands/indent/lexi.c  crc=64804  14293	Sun Aug 23 12:04:04 1992
XX***************
XX*** 25,33 ****
XX   */
XX  
XX  #define PUBLIC extern
XX  #include "globs.h"
XX  #include "codes.h"
XX! #include "ctype.h"
XX  
XX  #define alphanum 1
XX  #define opchar 3
XX--- 25,35 ----
XX   */
XX  
XX  #define PUBLIC extern
XX+ #include <ctype.h>
XX+ #include <string.h>
XX  #include "globs.h"
XX  #include "codes.h"
XX! #include "proto.h"
XX  
XX  #define alphanum 1
XX  #define opchar 3
XX***************
XX*** 131,137 ****
XX     }
XX  
XX     /* Scan an alphanumeric token */
XX!    if (chartype[*buf_ptr] == alphanum || buf_ptr[0] == '.' && isdigit(buf_ptr[1]))
XX     {
XX        /* we have a character or number */
XX        register char  *j;		/* used for searching thru list
XX--- 133,139 ----
XX     }
XX  
XX     /* Scan an alphanumeric token */
XX!    if (chartype[*buf_ptr] == alphanum || (buf_ptr[0] == '.' && isdigit(buf_ptr[1])))
XX     {
XX        /* we have a character or number */
XX        register char  *j;		/* used for searching thru list
XX***************
XX*** 140,146 ****
XX  					reserved words */
XX        register struct templ *p;
XX  
XX!       if (isdigit(*buf_ptr) || buf_ptr[0] == '.' && isdigit(buf_ptr[1]))
XX        {
XX  	 int             seendot = 0, seenexp = 0;
XX  	 if (*buf_ptr == '0' &&
XX--- 142,148 ----
XX  					reserved words */
XX        register struct templ *p;
XX  
XX!       if (isdigit(*buf_ptr) || (buf_ptr[0] == '.' && isdigit(buf_ptr[1])))
XX        {
XX  	 int             seendot = 0, seenexp = 0;
XX  	 if (*buf_ptr == '0' &&
XX***************
XX*** 543,555 ****
XX     ps.last_u_d = unary_delim;
XX     *tok = '\0';				/* null terminate the token */
XX     return (code);
XX! };
XX  
XX  /*
XX   * Add the given keyword to the keyword table, using val as the keyword type
XX   */
XX! addkey(key, val)
XX     char           *key;
XX  {
XX     register struct templ *p = specials;
XX     while (p->rwd)
XX--- 545,558 ----
XX     ps.last_u_d = unary_delim;
XX     *tok = '\0';				/* null terminate the token */
XX     return (code);
XX! }
XX  
XX  /*
XX   * Add the given keyword to the keyword table, using val as the keyword type
XX   */
XX! void addkey(key, val)
XX     char           *key;
XX+    int val;
XX  {
XX     register struct templ *p = specials;
XX     while (p->rwd)
X/
Xecho x - parse.c.d
Xsed '/^X/s///' > parse.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/indent/parse.c  crc=32379   8566	Sat Apr 21 22:27:19 1990
XX--- /home/top/ast/minix/1.6.25/commands/indent/parse.c  crc=25075   8595	Thu Jul 16 23:17:12 1992
XX***************
XX*** 21,31 ****
XX  #define PUBLIC	extern
XX  #include "./globs.h"
XX  #include "./codes.h"
XX  
XX  
XX  
XX  
XX! parse(tk)
XX     int             tk;			/* the code for the construct
XX  					   scanned */
XX  {
XX--- 21,32 ----
XX  #define PUBLIC	extern
XX  #include "./globs.h"
XX  #include "./codes.h"
XX+ #include "proto.h"
XX  
XX  
XX  
XX  
XX! void parse(tk)
XX     int             tk;			/* the code for the construct
XX  					   scanned */
XX  {
XX***************
XX*** 234,240 ****
XX  /*----------------------------------------------*\
XX  |   REDUCTION PHASE				    |
XX  \*----------------------------------------------*/
XX! reduce()
XX  {
XX  
XX     register int    i;
XX--- 235,241 ----
XX  /*----------------------------------------------*\
XX  |   REDUCTION PHASE				    |
XX  \*----------------------------------------------*/
XX! void reduce()
XX  {
XX  
XX     register int    i;
X/
/
