echo x - Makefile.ansi
sed '/^X/s///' > Makefile.ansi << '/'
Xl=`pwd`
Xibm=__sigreturn.o _sendrec.o brksize.o peekpoke.o portio.o setjmp.o
X
Xall:	
X	cd $l/ansi;	     make -k;	aal r ../libc.A *.o
X	cd $l/curses;	     make -k;	aal r ../libcurses.A *.o
X	cd $l/em;	     make -k;	aal r ../libe.A *.o
X	cd $l/end;	     make -k;	aal r ../end.A *.o
X	cd $l/float;	     make -k;	aal r ../libfp.A *.o
X	cd $l/ibm;	     make -k;	aal r ../libc.A $(ibm)
X	cd $l/math;	     make -k;	aal r ../libc.A *.o
X	cd $l/other;	     make -k;	aal r ../libc.A *.o
X	cd $l/posix;	     make -k;	aal r ../libc.A *.o
X	cd $l/syscall; 	     make -k;	aal r ../libc.A *.o
X	cd $l/rts;	     make -k;	aal r ../libd.A fphook.o
X	cd $l/stdio;	     make -k;	aal r ../libc.A *.o
X	cd $l/string;	     make -k;	aal r ../libc.A *.o
X
X
Xclean:
X	@rm -rf *.A
X	@cd $l/ansi;	  make -k clean
X	@cd $l/posix;	  make -k clean
X	@cd $l/other;	  make -k clean
X	@cd $l/stdio;	  make -k clean
X	@cd $l/float;	  make -k clean
X	@cd $l/string;    make -k clean
X	@cd $l/ibm;	  make -k clean
X	@cd $l/end;	  make -k clean
X	@cd $l/rts;	  make -k clean
X	@cd $l/math;	  make -k clean
X	@cd $l/em;	  make -k clean
X	@cd $l/syscall;	  make -k clean
/
echo x - Makefile.kr
sed '/^X/s///' > Makefile.kr << '/'
Xl=`pwd`
Xibm=__sigreturn.s _sendrec.s brksize.s peekpoke.s portio.s setjmp.s
X
Xall:	
X	cp /usr/lib/libc.a .
X	cd $l/ansi;	     make signal.s; ar r ../libc.a signal.s
X	cd $l/curses;	     make -k;	ar r ../libcurses.a *.s
X#	cd $l/em;	     make -k;	ar r ../libe.a *.s
X#	cd $l/end;	     make -k;	ar r ../end.a *.s
X#	cd $l/float;	     make -k;	ar r ../libfp.a *.s
X	cd $l/ibm;	     make -k;	ar r ../libc.a $(ibm)
X#	cd $l/math;	     make -k;	ar r ../libc.a *.s
X	cd $l/other;	     make -k;	ar r ../libc.a *.s
X	cd $l/posix;	     make -k;	ar r ../libc.a *.s
X	cd $l/syscall; 	     make -k;	ar r ../libc.a *.s
X#	cd $l/rts;	     make -k;	ar r ../libd.a fphook.s
X#	cd $l/stdio;	     make -k;	ar r ../libc.a *.s
X#	cd $l/string;	     make -k;	ar r ../libc.a *.s
X
X
Xclean:
X	@rm -rf *.a
X	@cd $l/ansi;	  make -k clean
X	@cd $l/posix;	  make -k clean
X	@cd $l/other;	  make -k clean
X	@cd $l/stdio;	  make -k clean
X	@cd $l/float;	  make -k clean
X	@cd $l/string;    make -k clean
X	@cd $l/ibm;	  make -k clean
X	@cd $l/end;	  make -k clean
X	@cd $l/rts;	  make -k clean
X	@cd $l/math;	  make -k clean
X	@cd $l/em;	  make -k clean
X	@cd $l/syscall;	  make -k clean
/
