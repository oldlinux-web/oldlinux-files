echo x - loc_incl.h
sed '/^X/s///' > loc_incl.h << '/'
X/*
X * loc_incl.h - local include file for stdio library
X */
X/* $Header: loc_incl.h,v 1.5 91/06/10 17:07:18 ceriel Exp $ */
X
X#include	<stdio.h>
X
X#define	io_testflag(p,x)	((p)->_flags & (x))
X
X#include	<stdarg.h>
X
X#ifdef _ANSI
Xint _doprnt(const char *format, va_list ap, FILE *stream);
Xint _doscan(FILE * stream, const char *format, va_list ap);
Xchar *_i_compute(unsigned long val, int base, char *s, int nrdigits);
Xchar *_f_print(va_list *ap, int flags, char *s, char c, int precision);
Xvoid __cleanup(void);
X
XFILE *popen(const char *command, const char *type);
XFILE *fdopen(int fd, const char *mode);
X
X#ifndef	NOFLOAT
Xchar *_ecvt(long double value, int ndigit, int *decpt, int *sign);
Xchar *_fcvt(long double value, int ndigit, int *decpt, int *sign);
X#endif	/* NOFLOAT */
X#endif
X
X#define	FL_LJUST	0x0001		/* left-justify field */
X#define	FL_SIGN		0x0002		/* sign in signed conversions */
X#define	FL_SPACE	0x0004		/* space in signed conversions */
X#define	FL_ALT		0x0008		/* alternate form */
X#define	FL_ZEROFILL	0x0010		/* fill with zero's */
X#define	FL_SHORT	0x0020		/* optional h */
X#define	FL_LONG		0x0040		/* optional l */
X#define	FL_LONGDOUBLE	0x0080		/* optional L */
X#define	FL_WIDTHSPEC	0x0100		/* field width is specified */
X#define	FL_PRECSPEC	0x0200		/* precision is specified */
X#define FL_SIGNEDCONV	0x0400		/* may contain a sign */
X#define	FL_NOASSIGN	0x0800		/* do not assign (in scanf) */
X#define	FL_NOMORE	0x1000		/* all flags collected */
/
