echo x - bawk.cd
sed '/^X/s///' > bawk.cd << '/'
Xecho x - Makefile.d
Xsed '/^X/s///' > Makefile.d << '/'
XX*** /home/top/ast/minix/1.5/commands/bawk/Makefile  crc=63691    424	Sat Apr 21 22:27:17 1990
XX--- /home/top/ast/minix/1.6.25/commands/bawk/Makefile  crc=49040    474	Sat Jan 30 20:12:15 1993
XX***************
XX*** 1,28 ****
XX! #
XX! #       Makefile for BAWK		(MINIX)
XX! #
XX! #   			Makefile @(#)1.1        
XX! #
XX  
XX  OPSYS   = MINIX
XX  
XX! CFLAGS  = -D$(OPSYS)
XX  
XX- OBJ     = bawk.s bawkact.s bawksym.s bawkpat.s bawkdo.s
XX- 
XX  bawk:       $(OBJ)
XX! 	    @echo Start linking BAWK
XX! 	    @cc -i -o bawk $(OBJ)
XX  
XX! bawk.s:     bawk.h bawk.c
XX  
XX- bawkact.s:  bawk.h bawkact.c
XX- 
XX- bawkpat.s:  bawk.h bawkpat.c
XX- 
XX- bawksym.s:  bawk.h bawksym.c
XX- 
XX- bawkdo.s:   bawk.h bawkdo.c
XX- 
XX  clean:	
XX! 	@rm -f *.bak *.s bawk
XX--- 1,22 ----
XX! # Makefile for bawk - pattern matching language
XX  
XX  OPSYS   = MINIX
XX+ CFLAGS  = -D$(OPSYS) -wo
XX+ O=o
XX  
XX! OBJ     = bawk.$O bawkact.$O bawksym.$O bawkpat.$O bawkdo.$O
XX  
XX  bawk:       $(OBJ)
XX! 	    @rm -rf bawk
XX! 	    @echo Start linking bawk
XX! 	    @cc -i -o bawk $(OBJ) >/dev/null
XX! 	    @chmem =20000 bawk
XX  
XX! bawk.$O:     bawk.h bawk.c
XX! bawkact.$O:  bawk.h bawkact.c
XX! bawkpat.$O:  bawk.h bawkpat.c
XX! bawksym.$O:  bawk.h bawksym.c
XX! bawkdo.$O:   bawk.h bawkdo.c
XX  
XX  clean:	
XX! 	@rm -f *.bak *.o *.s core bawk
X/
Xecho x - bawk.c.d
Xsed '/^X/s///' > bawk.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/bawk/bawk.c  crc=55470  19264	Sat Apr 21 22:55:09 1990
XX--- /home/top/ast/minix/1.6.25/commands/bawk/bawk.c  crc=03480  19229	Thu Jul 16 12:19:14 1992
XX***************
XX*** 36,42 ****
XX          Stacktop = Stackbtm + MAXSTACKSZ;
XX          Nextvar = Vartab;
XX  
XX!         strcpy( Fieldsep, " \t" );
XX          strcpy( Recordsep, "\n" );
XX  
XX          /*
XX--- 36,44 ----
XX          Stacktop = Stackbtm + MAXSTACKSZ;
XX          Nextvar = Vartab;
XX  
XX!         addvar("FS")->vclass=1;
XX!         findvar("FS")->vptr=" \t";
XX! 
XX          strcpy( Recordsep, "\n" );
XX  
XX          /*
XX***************
XX*** 58,68 ****
XX                          ++Debug;
XX                          break;
XX  #endif
XX- 		case 'F':
XX- 			Fieldsep[0] = *(argv[0] + 1);
XX- 			Fieldsep[1] = '\0';
XX- 			break;
XX- 
XX  		case 'f':
XX  			argv++ ; argc-- ;
XX  			if ( gotrules || argc <= 0 ) usage();
XX--- 60,65 ----
XX***************
XX*** 303,309 ****
XX                  /*
XX                   * Parse the input line.
XX                   */
XX!                 Fieldcount = parse( Linebuf, Fields, Fieldsep );
XX  #ifdef DEBUG
XX                  if ( Debug>1 )
XX                  {
XX--- 300,306 ----
XX                  /*
XX                   * Parse the input line.
XX                   */
XX!                 Fieldcount = parse( Linebuf, Fields, findvar("FS")->vptr );
XX  #ifdef DEBUG
XX                  if ( Debug>1 )
XX                  {
X/
Xecho x - bawk.h.d
Xsed '/^X/s///' > bawk.h.d << '/'
XX*** /home/top/ast/minix/1.5/commands/bawk/bawk.h  crc=31975   7027	Sat Apr 21 22:27:17 1990
XX--- /home/top/ast/minix/1.6.25/commands/bawk/bawk.h  crc=58279   6944	Thu Jul 16 12:19:14 1992
XX***************
XX*** 129,135 ****
XX  #define T_END           'E'
XX  #define T_NF            'f'
XX  #define T_NR            '#'
XX- #define T_FS            ' '
XX  #define T_RS            '\n'
XX  #define T_FILENAME      'z'
XX  
XX--- 129,134 ----
XX***************
XX*** 180,186 ****
XX  EXTERN DATUM Value;     /* and its value */
XX  EXTERN char Saw_break;  /* set when break stmt seen */
XX  EXTERN char Where;      /* indicates whether C stmt is a PATTERN or ACTION */
XX- EXTERN char Fieldsep[20];        /* field seperator */
XX  EXTERN char Recordsep[20];       /* record seperator */
XX  EXTERN char *Beginact;  /* BEGINning of input actions */
XX  EXTERN char *Endact;    /* END of input actions */
XX--- 179,184 ----
X/
Xecho x - bawkdo.c.d
Xsed '/^X/s///' > bawkdo.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/bawk/bawkdo.c  crc=22665  21743	Sat Apr 21 22:55:10 1990
XX--- /home/top/ast/minix/1.6.25/commands/bawk/bawkdo.c  crc=20146  21523	Thu Jul 16 12:19:15 1992
XX***************
XX*** 362,368 ****
XX                           * We're processing a pattern right now - perform a
XX                           * match of the regular expression agains input line.
XX                           */
XX!                         unparse( Fields, Fieldcount, Linebuf, Fieldsep );
XX                          pushint( (INT)match( Linebuf, Value.dptr ) );
XX                  }
XX                  else
XX--- 362,368 ----
XX                           * We're processing a pattern right now - perform a
XX                           * match of the regular expression agains input line.
XX                           */
XX!                         unparse( Fields, Fieldcount, Linebuf, findvar("FS")->vptr );
XX                          pushint( (INT)match( Linebuf, Value.dptr ) );
XX                  }
XX                  else
XX***************
XX*** 377,387 ****
XX                  pushint( (INT)Recordcount );
XX                  getoken();
XX                  break;
XX-         case T_FS:                         /* multiple separators allowed */
XX-                 data.dptr = Fieldsep;
XX-                 push( 1, ACTUAL, BYTE, &data ); /* string input, not char */
XX-                 getoken();
XX-                 break;
XX          case T_RS:
XX                  Recordsep[1] = 0;      /* multiple separators not allowed */
XX                  data.dptr = Recordsep;
XX--- 377,382 ----
XX***************
XX*** 413,419 ****
XX                           * Reconstitute the line buffer in case any of the
XX                           * fields have been changed.
XX                           */
XX!                         unparse( Fields, Fieldcount, Linebuf, Fieldsep );
XX                          data.dptr = Linebuf;
XX                  }
XX                  /*
XX--- 408,414 ----
XX                           * Reconstitute the line buffer in case any of the
XX                           * fields have been changed.
XX                           */
XX!                         unparse( Fields, Fieldcount, Linebuf, findvar("FS")->vptr );
XX                          data.dptr = Linebuf;
XX                  }
XX                  /*
X/
Xecho x - bawksym.c.d
Xsed '/^X/s///' > bawksym.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/bawk/bawksym.c  crc=06630  14677	Sat Apr 21 22:55:11 1990
XX--- /home/top/ast/minix/1.6.25/commands/bawk/bawksym.c  crc=36829  15120	Thu Jul 16 12:19:15 1992
XX***************
XX*** 17,22 ****
XX--- 17,24 ----
XX  #define F_TOLOWER       8
XX  #define F_MATCH         9
XX  #define F_NEXTFILE      10
XX+ #define F_ATOI          11
XX+ #define F_ITOA          12
XX  
XX  isfunction( s )
XX  char *s;
XX***************
XX*** 46,51 ****
XX--- 48,57 ----
XX                  return F_MATCH;
XX          if ( !strcmp( s, "nextfile" ) )
XX                  return F_NEXTFILE;
XX+         if ( !strcmp( s, "atoi" ) )
XX+                 return F_ATOI;
XX+         if ( !strcmp( s, "itoa" ) )
XX+                 return F_ITOA;
XX          return 0;
XX  }
XX  
XX***************
XX*** 73,80 ****
XX                  return T_NF;
XX          if ( !strcmp( s, "NR" ) )
XX                  return T_NR;
XX-         if ( !strcmp( s, "FS" ) )
XX-                 return T_FS;
XX          if ( !strcmp( s, "RS" ) )
XX                  return T_RS;
XX          if ( !strcmp( s, "FILENAME" ) )
XX--- 79,84 ----
XX***************
XX*** 147,153 ****
XX                  while ( Fieldcount )
XX                          free( Fields[ --Fieldcount ] );
XX                  pushint( (INT)getline() );
XX!                 Fieldcount = parse( Linebuf, Fields, Fieldsep );
XX                  break;
XX          case F_STRLEN:  /* calculate length of string argument */
XX                  pushint( (INT)strlen( args[0].dptr ) );
XX--- 151,157 ----
XX                  while ( Fieldcount )
XX                          free( Fields[ --Fieldcount ] );
XX                  pushint( (INT)getline() );
XX!                 Fieldcount = parse( Linebuf, Fields, findvar("FS")->vptr );
XX                  break;
XX          case F_STRLEN:  /* calculate length of string argument */
XX                  pushint( (INT)strlen( args[0].dptr ) );
XX***************
XX*** 169,174 ****
XX--- 173,184 ----
XX                  break;
XX          case F_NEXTFILE:/* close current input file and process next file */
XX                  pushint( (INT)endfile() );
XX+                 break;
XX+         case F_ATOI:    /* convert a string to an int (not automatic in bawk) */
XX+                 pushint( (INT)atoi( args[0].dptr ) );
XX+                 break;
XX+         case F_ITOA:    /* convert an int to a string (for symmetry) */
XX+                 pushint( (INT)itoa( args[0].ival ) );
XX                  break;
XX          default:        /* oops! */
XX                  error( "bad function call", ACT_ERROR );
X/
/
