echo x - Makefile
sed '/^X/s///' > Makefile << '/'
Xall:	
X	
X
X
Xclean:	
X	@rm -rf *.o *.bak
X
/
echo x - access.s
sed '/^X/s///' > access.s << '/'
X.define	_access
X.extern	__access
X.align 2
X_access: 
Xj __access
/
echo x - alarm.s
sed '/^X/s///' > alarm.s << '/'
X.define	_alarm
X.extern	__alarm
X.align 2
X_alarm: 
Xj __alarm
/
echo x - brk.s
sed '/^X/s///' > brk.s << '/'
X.define	_brk
X.extern	__brk
X.align 2
X_brk: 
Xj __brk
/
echo x - chdir.s
sed '/^X/s///' > chdir.s << '/'
X.define	_chdir
X.extern	__chdir
X.align 2
X_chdir: 
Xj __chdir
/
echo x - chmod.s
sed '/^X/s///' > chmod.s << '/'
X.define	_chmod
X.extern	__chmod
X.align 2
X_chmod: 
Xj __chmod
/
echo x - chown.s
sed '/^X/s///' > chown.s << '/'
X.define	_chown
X.extern	__chown
X.align 2
X_chown: 
Xj __chown
/
echo x - chroot.s
sed '/^X/s///' > chroot.s << '/'
X.define	_chroot
X.extern	__chroot
X.align 2
X_chroot: 
Xj __chroot
/
echo x - close.s
sed '/^X/s///' > close.s << '/'
X.define	_close
X.extern	__close
X.align 2
X_close: 
Xj __close
/
echo x - creat.s
sed '/^X/s///' > creat.s << '/'
X.define	_creat
X.extern	__creat
X.align 2
X_creat: 
Xj __creat
/
echo x - dup.s
sed '/^X/s///' > dup.s << '/'
X.define	_dup
X.extern	__dup
X.align 2
X_dup: 
Xj __dup
/
echo x - dup2.s
sed '/^X/s///' > dup2.s << '/'
X.define	_dup2
X.extern	__dup2
X.align 2
X_dup2: 
Xj __dup2
/
echo x - execl.s
sed '/^X/s///' > execl.s << '/'
X.define	_execl
X.extern	__execl
X.align 2
X_execl: 
Xj __execl
/
echo x - execle.s
sed '/^X/s///' > execle.s << '/'
X.define	_execle
X.extern	__execle
X.align 2
X_execle: 
Xj __execle
/
echo x - execv.s
sed '/^X/s///' > execv.s << '/'
X.define	_execv
X.extern	__execv
X.align 2
X_execv: 
Xj __execv
/
echo x - execve.s
sed '/^X/s///' > execve.s << '/'
X.define	_execve
X.extern	__execve
X.align 2
X_execve: 
Xj __execve
/
echo x - fcntl.s
sed '/^X/s///' > fcntl.s << '/'
X.define	_fcntl
X.extern	__fcntl
X.align 2
X_fcntl: 
Xj __fcntl
/
echo x - fork.s
sed '/^X/s///' > fork.s << '/'
X.define	_fork
X.extern	__fork
X.align 2
X_fork: 
Xj __fork
/
echo x - fpathconf.s
sed '/^X/s///' > fpathconf.s << '/'
X.define	_fpathconf
X.extern	__fpathconf
X.align 2
X_fpathconf: 
Xj __fpathconf
/
echo x - fstat.s
sed '/^X/s///' > fstat.s << '/'
X.define	_fstat
X.extern	__fstat
X.align 2
X_fstat: 
Xj __fstat
/
echo x - getcwd.s
sed '/^X/s///' > getcwd.s << '/'
X.define	_getcwd
X.extern	__getcwd
X.align 2
X_getcwd: 
Xj __getcwd
/
echo x - getegid.s
sed '/^X/s///' > getegid.s << '/'
X.define	_getegid
X.extern	__getegid
X.align 2
X_getegid: 
Xj __getegid
/
echo x - geteuid.s
sed '/^X/s///' > geteuid.s << '/'
X.define	_geteuid
X.extern	__geteuid
X.align 2
X_geteuid: 
Xj __geteuid
/
echo x - getgid.s
sed '/^X/s///' > getgid.s << '/'
X.define	_getgid
X.extern	__getgid
X.align 2
X_getgid: 
Xj __getgid
/
echo x - getgroups.s
sed '/^X/s///' > getgroups.s << '/'
X.define	_getgroups
X.extern	__getgroups
X.align 2
X_getgroups: 
Xj __getgroups
/
echo x - getpid.s
sed '/^X/s///' > getpid.s << '/'
X.define	_getpid
X.extern	__getpid
X.align 2
X_getpid: 
Xj __getpid
/
echo x - getppid.s
sed '/^X/s///' > getppid.s << '/'
X.define	_getppid
X.extern	__getppid
X.align 2
X_getppid: 
Xj __getppid
/
echo x - getuid.s
sed '/^X/s///' > getuid.s << '/'
X.define	_getuid
X.extern	__getuid
X.align 2
X_getuid: 
Xj __getuid
/
echo x - gtty.s
sed '/^X/s///' > gtty.s << '/'
X.define	_gtty
X.extern	__gtty
X.align 2
X_gtty: 
Xj __gtty
/
echo x - ioctl.s
sed '/^X/s///' > ioctl.s << '/'
X.define	_ioctl
X.extern	__ioctl
X.align 2
X_ioctl: 
Xj __ioctl
/
echo x - isatty.s
sed '/^X/s///' > isatty.s << '/'
X.define	_isatty
X.extern	__isatty
X.align 2
X_isatty: 
Xj __isatty
/
echo x - kill.s
sed '/^X/s///' > kill.s << '/'
X.define	_kill
X.extern	__kill
X.align 2
X_kill: 
Xj __kill
/
echo x - link.s
sed '/^X/s///' > link.s << '/'
X.define	_link
X.extern	__link
X.align 2
X_link: 
Xj __link
/
echo x - lseek.s
sed '/^X/s///' > lseek.s << '/'
X.define	_lseek
X.extern	__lseek
X.align 2
X_lseek: 
Xj __lseek
/
echo x - mkdir.s
sed '/^X/s///' > mkdir.s << '/'
X.define	_mkdir
X.extern	__mkdir
X.align 2
X_mkdir: 
Xj __mkdir
/
echo x - mkfifo.s
sed '/^X/s///' > mkfifo.s << '/'
X.define	_mkfifo
X.extern	__mkfifo
X.align 2
X_mkfifo: 
Xj __mkfifo
/
echo x - mknod.s
sed '/^X/s///' > mknod.s << '/'
X.define	_mknod
X.extern	__mknod
X.align 2
X_mknod: 
Xj __mknod
/
echo x - mknod4.s
sed '/^X/s///' > mknod4.s << '/'
X.define	_mknod4
X.extern	__mknod4
X.align 2
X_mknod4: 
Xj __mknod4
/
echo x - mktemp.s
sed '/^X/s///' > mktemp.s << '/'
X.define	_mktemp
X.extern	__mktemp
X.align 2
X_mktemp: 
Xj __mktemp
/
echo x - mount.s
sed '/^X/s///' > mount.s << '/'
X.define	_mount
X.extern	__mount
X.align 2
X_mount: 
Xj __mount
/
echo x - open.s
sed '/^X/s///' > open.s << '/'
X.define	_open
X.extern	__open
X.align 2
X_open: 
Xj __open
/
echo x - pathconf.s
sed '/^X/s///' > pathconf.s << '/'
X.define	_pathconf
X.extern	__pathconf
X.align 2
X_pathconf: 
Xj __pathconf
/
echo x - pause.s
sed '/^X/s///' > pause.s << '/'
X.define	_pause
X.extern	__pause
X.align 2
X_pause: 
Xj __pause
/
echo x - pipe.s
sed '/^X/s///' > pipe.s << '/'
X.define	_pipe
X.extern	__pipe
X.align 2
X_pipe: 
Xj __pipe
/
echo x - ptrace.s
sed '/^X/s///' > ptrace.s << '/'
X.define	_ptrace
X.extern	__ptrace
X.align 2
X_ptrace: 
Xj __ptrace
/
echo x - read.s
sed '/^X/s///' > read.s << '/'
X.define	_read
X.extern	__read
X.align 2
X_read: 
Xj __read
/
echo x - rename.s
sed '/^X/s///' > rename.s << '/'
X.define	_rename
X.extern	__rename
X.align 2
X_rename: 
Xj __rename
/
echo x - rmdir.s
sed '/^X/s///' > rmdir.s << '/'
X.define	_rmdir
X.extern	__rmdir
X.align 2
X_rmdir: 
Xj __rmdir
/
echo x - sbrk.s
sed '/^X/s///' > sbrk.s << '/'
X.define	_sbrk
X.extern	__sbrk
X.align 2
X_sbrk: 
Xj __sbrk
/
echo x - setgid.s
sed '/^X/s///' > setgid.s << '/'
X.define	_setgid
X.extern	__setgid
X.align 2
X_setgid: 
Xj __setgid
/
echo x - setuid.s
sed '/^X/s///' > setuid.s << '/'
X.define	_setuid
X.extern	__setuid
X.align 2
X_setuid: 
Xj __setuid
/
echo x - sigaction.s
sed '/^X/s///' > sigaction.s << '/'
X.define	_sigaction
X.extern	__sigaction
X.align 2
X_sigaction: 
Xj __sigaction
/
echo x - sigaddset.s
sed '/^X/s///' > sigaddset.s << '/'
X.define	_sigaddset
X.extern	__sigaddset
X.align 2
X_sigaddset: 
Xj __sigaddset
/
echo x - sigdelset.s
sed '/^X/s///' > sigdelset.s << '/'
X.define	_sigdelset
X.extern	__sigdelset
X.align 2
X_sigdelset: 
Xj __sigdelset
/
echo x - sigemptyset.s
sed '/^X/s///' > sigemptyset.s << '/'
X.define	_sigemptyset
X.extern	__sigemptyset
X.align 2
X_sigemptyset: 
Xj __sigemptyset
/
echo x - sigfillset.s
sed '/^X/s///' > sigfillset.s << '/'
X.define	_sigfillset
X.extern	__sigfillset
X.align 2
X_sigfillset: 
Xj __sigfillset
/
echo x - sigismember.s
sed '/^X/s///' > sigismember.s << '/'
X.define	_sigismember
X.extern	__sigismember
X.align 2
X_sigismember: 
Xj __sigismember
/
echo x - sigpending.s
sed '/^X/s///' > sigpending.s << '/'
X.define	_sigpending
X.extern	__sigpending
X.align 2
X_sigpending: 
Xj __sigpending
/
echo x - sigprocmask.s
sed '/^X/s///' > sigprocmask.s << '/'
X.define	_sigprocmask
X.extern	__sigprocmask
X.align 2
X_sigprocmask: 
Xj __sigprocmask
/
echo x - sigreturn.s
sed '/^X/s///' > sigreturn.s << '/'
X.define	_sigreturn
X.extern	__sigreturn
X.align 2
X_sigreturn: 
Xj __sigreturn
/
echo x - sigsuspend.s
sed '/^X/s///' > sigsuspend.s << '/'
X.define	_sigsuspend
X.extern	__sigsuspend
X.align 2
X_sigsuspend: 
Xj __sigsuspend
/
echo x - sleep.s
sed '/^X/s///' > sleep.s << '/'
X.define	_sleep
X.extern	__sleep
X.align 2
X_sleep: 
Xj __sleep
/
echo x - stat.s
sed '/^X/s///' > stat.s << '/'
X.define	_stat
X.extern	__stat
X.align 2
X_stat: 
Xj __stat
/
echo x - stime.s
sed '/^X/s///' > stime.s << '/'
X.define	_stime
X.extern	__stime
X.align 2
X_stime: 
Xj __stime
/
echo x - stty.s
sed '/^X/s///' > stty.s << '/'
X.define	_stty
X.extern	__stty
X.align 2
X_stty: 
Xj __stty
/
echo x - sync.s
sed '/^X/s///' > sync.s << '/'
X.define	_sync
X.extern	__sync
X.align 2
X_sync: 
Xj __sync
/
echo x - time.s
sed '/^X/s///' > time.s << '/'
X.define	_time
X.extern	__time
X.align 2
X_time: 
Xj __time
/
echo x - times.s
sed '/^X/s///' > times.s << '/'
X.define	_times
X.extern	__times
X.align 2
X_times: 
Xj __times
/
echo x - umask.s
sed '/^X/s///' > umask.s << '/'
X.define	_umask
X.extern	__umask
X.align 2
X_umask: 
Xj __umask
/
echo x - umount.s
sed '/^X/s///' > umount.s << '/'
X.define	_umount
X.extern	__umount
X.align 2
X_umount: 
Xj __umount
/
echo x - uname.s
sed '/^X/s///' > uname.s << '/'
X.define	_uname
X.extern	__uname
X.align 2
X_uname: 
Xj __uname
/
echo x - unlink.s
sed '/^X/s///' > unlink.s << '/'
X.define	_unlink
X.extern	__unlink
X.align 2
X_unlink: 
Xj __unlink
/
echo x - utime.s
sed '/^X/s///' > utime.s << '/'
X.define	_utime
X.extern	__utime
X.align 2
X_utime: 
Xj __utime
/
echo x - wait.s
sed '/^X/s///' > wait.s << '/'
X.define	_wait
X.extern	__wait
X.align 2
X_wait: 
Xj __wait
/
echo x - waitpid.s
sed '/^X/s///' > waitpid.s << '/'
X.define	_waitpid
X.extern	__waitpid
X.align 2
X_waitpid: 
Xj __waitpid
/
echo x - write.s
sed '/^X/s///' > write.s << '/'
X.define	_write
X.extern	__write
X.align 2
X_write: 
Xj __write
/
