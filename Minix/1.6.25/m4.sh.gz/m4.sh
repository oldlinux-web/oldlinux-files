echo x - m4.cd
sed '/^X/s///' > m4.cd << '/'
Xecho x - Makefile.d
Xsed '/^X/s///' > Makefile.d << '/'
XX*** /home/top/ast/minix/1.5/commands/m4/Makefile  crc=60000    407	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/m4/Makefile  crc=54941    537	Sat Jan 30 20:12:16 1993
XX***************
XX*** 1,14 ****
XX  #	-DEXTENDED	#if you like to get paste & spaste macros.
XX  #	-DVOID 		#if your C compiler does NOT support void.
XX  #	-DGETOPT	#if you STILL do not have getopt in your library.
XX  #	-DDUFFCP	#if you do not have fast memcpy in your library.
XX  #
XX! CFLAGS = -DEXTENDED
XX! OBJS =  main.s eval.s serv.s look.s misc.s expr.s
XX  INCL =  mdef.h extr.h patchlevel.h
XX- m4: $(OBJS) $(INCL)
XX- 	cc -o m4 $(OBJS)
XX  
XX  
XX  clean:	
XX! 	@rm -f *.bak *.s m4
XX--- 1,23 ----
XX+ # Makefile for M4
XX+ 
XX  #	-DEXTENDED	#if you like to get paste & spaste macros.
XX  #	-DVOID 		#if your C compiler does NOT support void.
XX  #	-DGETOPT	#if you STILL do not have getopt in your library.
XX  #	-DDUFFCP	#if you do not have fast memcpy in your library.
XX  #
XX! 
XX! CFLAGS = -DEXTENDED -O -D_POSIX_SOURCE -D_MINIX
XX! O=o
XX! 
XX! OBJ =  main.$O eval.$O serv.$O look.$O misc.$O expr.$O
XX  INCL =  mdef.h extr.h patchlevel.h
XX  
XX+ m4: $(OBJ) $(INCL)
XX+ 	@rm -rf m4
XX+ 	@echo Start linking m4
XX+ 	@cc -o m4 $(OBJ) >/dev/null
XX+ 	@chmem =8192 m4
XX  
XX+ 
XX  clean:	
XX! 	@rm -f *.o *.s m4 core *bak
X/
Xecho x - eval.c.d
Xsed '/^X/s///' > eval.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/m4/eval.c  crc=47166   5707	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/m4/eval.c  crc=35996   5641	Thu Aug 27 20:38:45 1992
XX***************
XX*** 7,16 ****
XX  #include "mdef.h"
XX  #include "extr.h"
XX  
XX- extern ndptr lookup();
XX- extern char *strsave();
XX- extern char *mktemp();
XX- 
XX  /*
XX   * eval - evaluate built-in macros.
XX   *	  argc - number of elements in argv.
XX--- 7,12 ----
XX***************
XX*** 31,37 ****
XX   *
XX   */
XX  
XX! eval (argv, argc, td)
XX  register char *argv[];
XX  register int argc;
XX  register int  td;
XX--- 27,33 ----
XX   *
XX   */
XX  
XX! void eval (argv, argc, td)
XX  register char *argv[];
XX  register int argc;
XX  register int  td;
X/
Xecho x - expr.c.d
Xsed '/^X/s///' > expr.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/m4/expr.c  crc=23659  11531	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/m4/expr.c  crc=19816  11689	Thu Aug 27 20:38:46 1992
XX***************
XX*** 1,4 ****
XX- 
XX  /*
XX   *      expression evaluator: performs a standard recursive
XX   *      descent parse to evaluate any expression permissible
XX--- 1,3 ----
XX***************
XX*** 44,49 ****
XX--- 43,50 ----
XX   *                      Bob Harper
XX   */
XX   
XX+ #include "mdef.h"
XX+ 
XX  #define TRUE    1
XX  #define FALSE   0
XX  #define EOS     (char) 0
XX***************
XX*** 73,79 ****
XX  #define ungetch()       nxtch--
XX  #define getch()         *nxtch++
XX   
XX! expr(expbuf)
XX  char *expbuf;
XX  {
XX          register int rval;
XX--- 74,80 ----
XX  #define ungetch()       nxtch--
XX  #define getch()         *nxtch++
XX   
XX! int expr(expbuf)
XX  char *expbuf;
XX  {
XX          register int rval;
XX***************
XX*** 85,97 ****
XX          if (skipws() == EOS)
XX                  return(rval);
XX          experr("Ill-formed expression");
XX  }
XX   
XX  /*
XX   * query : lor | lor '?' query ':' query
XX   *
XX   */
XX! query()
XX  {
XX          register int bool, true_val, false_val;
XX   
XX--- 86,100 ----
XX          if (skipws() == EOS)
XX                  return(rval);
XX          experr("Ill-formed expression");
XX+ 	/* NOTREACHED */
XX+ 	return(0);
XX  }
XX   
XX  /*
XX   * query : lor | lor '?' query ':' query
XX   *
XX   */
XX! int query()
XX  {
XX          register int bool, true_val, false_val;
XX   
XX***************
XX*** 113,119 ****
XX   * lor : land { '||' land }
XX   *
XX   */
XX! lor()
XX  {
XX          register int c, vl, vr;
XX   
XX--- 116,122 ----
XX   * lor : land { '||' land }
XX   *
XX   */
XX! int lor()
XX  {
XX          register int c, vl, vr;
XX   
XX***************
XX*** 133,139 ****
XX   * land : bor { '&&' bor }
XX   *
XX   */
XX! land()
XX  {
XX          register int c, vl, vr;
XX   
XX--- 136,142 ----
XX   * land : bor { '&&' bor }
XX   *
XX   */
XX! int land()
XX  {
XX          register int c, vl, vr;
XX   
XX***************
XX*** 153,159 ****
XX   * bor : bxor { '|' bxor }
XX   *
XX   */
XX! bor()
XX  {
XX          register int vl, vr, c;
XX   
XX--- 156,162 ----
XX   * bor : bxor { '|' bxor }
XX   *
XX   */
XX! int bor()
XX  {
XX          register int vl, vr, c;
XX   
XX***************
XX*** 174,180 ****
XX   * bxor : band { '^' band }
XX   *
XX   */
XX! bxor()
XX  {
XX          register int vl, vr;
XX   
XX--- 177,183 ----
XX   * bxor : band { '^' band }
XX   *
XX   */
XX! int bxor()
XX  {
XX          register int vl, vr;
XX   
XX***************
XX*** 192,198 ****
XX   * band : eql { '&' eql }
XX   *
XX   */
XX! band()
XX  {
XX          register int vl, vr, c;
XX   
XX--- 195,201 ----
XX   * band : eql { '&' eql }
XX   *
XX   */
XX! int band()
XX  {
XX          register int vl, vr, c;
XX   
XX***************
XX*** 213,219 ****
XX   * eql : relat { eqrel relat }
XX   *
XX   */
XX! eql()
XX  {
XX          register int vl, vr, rel;
XX   
XX--- 216,222 ----
XX   * eql : relat { eqrel relat }
XX   *
XX   */
XX! int eql()
XX  {
XX          register int vl, vr, rel;
XX   
XX***************
XX*** 238,244 ****
XX   * relat : shift { rel shift }
XX   *
XX   */
XX! relat()
XX  {
XX          register int vl, vr, rel;
XX   
XX--- 241,247 ----
XX   * relat : shift { rel shift }
XX   *
XX   */
XX! int relat()
XX  {
XX          register int vl, vr, rel;
XX   
XX***************
XX*** 269,275 ****
XX   * shift : primary { shop primary }
XX   *
XX   */
XX! shift()
XX  {
XX          register int vl, vr, c;
XX   
XX--- 272,278 ----
XX   * shift : primary { shop primary }
XX   *
XX   */
XX! int shift()
XX  {
XX          register int vl, vr, c;
XX   
XX***************
XX*** 293,299 ****
XX   * primary : term { addop term }
XX   *
XX   */
XX! primary()
XX  {
XX          register int c, vl, vr;
XX   
XX--- 296,302 ----
XX   * primary : term { addop term }
XX   *
XX   */
XX! int primary()
XX  {
XX          register int c, vl, vr;
XX   
XX***************
XX*** 314,320 ****
XX   * <term> := <unary> { <mulop> <unary> }
XX   *
XX   */
XX! term()
XX  {
XX          register int c, vl, vr;
XX   
XX--- 317,323 ----
XX   * <term> := <unary> { <mulop> <unary> }
XX   *
XX   */
XX! int term()
XX  {
XX          register int c, vl, vr;
XX   
XX***************
XX*** 342,348 ****
XX   * unary : factor | unop unary
XX   *
XX   */
XX! unary()
XX  {
XX          register int val, c;
XX   
XX--- 345,351 ----
XX   * unary : factor | unop unary
XX   *
XX   */
XX! int unary()
XX  {
XX          register int val, c;
XX   
XX***************
XX*** 367,373 ****
XX   * factor : constant | '(' query ')'
XX   *
XX   */
XX! factor()
XX  {
XX          register int val;
XX   
XX--- 370,376 ----
XX   * factor : constant | '(' query ')'
XX   *
XX   */
XX! int factor()
XX  {
XX          register int val;
XX   
XX***************
XX*** 386,392 ****
XX   * constant: num | 'char'
XX   *
XX   */
XX! constant()
XX  {
XX          /*
XX           * Note: constant() handles multi-byte constants
XX--- 389,395 ----
XX   * constant: num | 'char'
XX   *
XX   */
XX! int constant()
XX  {
XX          /*
XX           * Note: constant() handles multi-byte constants
XX***************
XX*** 451,457 ****
XX   * num : digit | num digit
XX   *
XX   */
XX! num()
XX  {
XX          register int rval, c, base;
XX          int ndig;
XX--- 454,460 ----
XX   * num : digit | num digit
XX   *
XX   */
XX! int num()
XX  {
XX          register int rval, c, base;
XX          int ndig;
XX***************
XX*** 469,481 ****
XX          if (ndig)
XX                  return(rval);
XX          experr("Bad constant");
XX  }
XX   
XX  /*
XX   * eqlrel : '=' | '==' | '!='
XX   *
XX   */
XX! geteql()
XX  {
XX          register int c1, c2;
XX   
XX--- 472,486 ----
XX          if (ndig)
XX                  return(rval);
XX          experr("Bad constant");
XX+ 	/* NOTREACHED */
XX+ 	return(0);
XX  }
XX   
XX  /*
XX   * eqlrel : '=' | '==' | '!='
XX   *
XX   */
XX! int geteql()
XX  {
XX          register int c1, c2;
XX   
XX***************
XX*** 507,513 ****
XX   * rel : '<' | '>' | '<=' | '>='
XX   *
XX   */
XX! getrel()
XX  {
XX          register int c1, c2;
XX   
XX--- 512,518 ----
XX   * rel : '<' | '>' | '<=' | '>='
XX   *
XX   */
XX! int getrel()
XX  {
XX          register int c1, c2;
XX   
XX***************
XX*** 538,544 ****
XX  /*
XX   * Skip over any white space and return terminating char.
XX   */
XX! skipws()
XX  {
XX          register char c;
XX   
XX--- 543,549 ----
XX  /*
XX   * Skip over any white space and return terminating char.
XX   */
XX! int skipws()
XX  {
XX          register char c;
XX   
XX***************
XX*** 551,557 ****
XX   * Error handler - resets environment to eval(), prints an error,
XX   * and returns FALSE.
XX   */
XX! experr(msg)
XX  char *msg;
XX  {
XX          printf("mp: %s\n",msg);
XX--- 556,562 ----
XX   * Error handler - resets environment to eval(), prints an error,
XX   * and returns FALSE.
XX   */
XX! int experr(msg)
XX  char *msg;
XX  {
XX          printf("mp: %s\n",msg);
X/
Xecho x - look.c.d
Xsed '/^X/s///' > look.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/m4/look.c  crc=48850   1640	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/m4/look.c  crc=28377   1606	Thu Aug 27 20:38:47 1992
XX***************
XX*** 7,20 ****
XX  #include "mdef.h"
XX  #include "extr.h"
XX  
XX- extern char *strsave();
XX- extern char *malloc();
XX- 
XX  /*
XX   *  hash - compute hash value using the proverbial
XX   *	   hashing function. Taken from K&R.
XX   */
XX! hash (name)
XX  register char *name;
XX  {
XX  	register int h = 0;
XX--- 7,17 ----
XX  #include "mdef.h"
XX  #include "extr.h"
XX  
XX  /*
XX   *  hash - compute hash value using the proverbial
XX   *	   hashing function. Taken from K&R.
XX   */
XX! int hash (name)
XX  register char *name;
XX  {
XX  	register int h = 0;
XX***************
XX*** 64,70 ****
XX   * remhash - remove an entry from the hashtable
XX   *
XX   */
XX! remhash(name, all)
XX  char *name;
XX  int all;
XX  {
XX--- 61,67 ----
XX   * remhash - remove an entry from the hashtable
XX   *
XX   */
XX! void remhash(name, all)
XX  char *name;
XX  int all;
XX  {
XX***************
XX*** 100,106 ****
XX   * freent - free a hashtable information block
XX   *
XX   */
XX! freent(p)
XX  ndptr p;
XX  {
XX  	if (!(p->type & STATIC)) {
XX--- 97,103 ----
XX   * freent - free a hashtable information block
XX   *
XX   */
XX! void freent(p)
XX  ndptr p;
XX  {
XX  	if (!(p->type & STATIC)) {
X/
Xecho x - main.c.d
Xsed '/^X/s///' > main.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/m4/main.c  crc=34463  11085	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/m4/main.c  crc=56489  10981	Thu Aug 27 22:29:18 1992
XX***************
XX*** 166,182 ****
XX  
XX  #define MAXKEYS	(sizeof(keywrds)/sizeof(struct keyblk))
XX  
XX- extern ndptr lookup();
XX- extern ndptr addent();
XX- extern int onintr();
XX- 
XX- extern char *malloc();
XX- extern char *mktemp();
XX- 
XX  extern int optind;
XX  extern char *optarg;
XX  
XX! main(argc,argv)
XX  char *argv[];
XX  {
XX  	register int c;
XX--- 166,176 ----
XX  
XX  #define MAXKEYS	(sizeof(keywrds)/sizeof(struct keyblk))
XX  
XX  extern int optind;
XX  extern char *optarg;
XX  
XX! int main(argc,argv)
XX! int argc;
XX  char *argv[];
XX  {
XX  	register int c;
XX***************
XX*** 244,256 ****
XX  	exit(0);
XX  }
XX  
XX- ndptr inspect();	/* forward ... */
XX- 
XX  /*
XX   * macro - the work horse..
XX   *
XX   */
XX! macro() {
XX  	char token[MAXTOK];
XX  	register char *s;
XX  	register int t, l;
XX--- 238,248 ----
XX  	exit(0);
XX  }
XX  
XX  /*
XX   * macro - the work horse..
XX   *
XX   */
XX! void macro() {
XX  	char token[MAXTOK];
XX  	register char *s;
XX  	register int t, l;
XX***************
XX*** 355,363 ****
XX  					error("m4: internal stack overflow");
XX  
XX  				if (CALTYP == MACRTYPE)
XX! 					expand(mstack+fp+1, sp-fp);
XX  				else
XX! 					eval(mstack+fp+1, sp-fp, CALTYP);
XX  
XX  				ep = PREVEP;	/* flush strspace */
XX  				sp = PREVSP;	/* previous sp..  */
XX--- 347,355 ----
XX  					error("m4: internal stack overflow");
XX  
XX  				if (CALTYP == MACRTYPE)
XX! 					expand((char**)mstack+fp+1,(int)sp-fp);
XX  				else
XX! 					eval((char**)mstack+fp+1,sp-fp,CALTYP);
XX  
XX  				ep = PREVEP;	/* flush strspace */
XX  				sp = PREVSP;	/* previous sp..  */
XX***************
XX*** 415,421 ****
XX   * does not know anything about demand-zero pages.
XX   *
XX   */
XX! initm4()
XX  {
XX  	register int i;
XX  
XX--- 407,413 ----
XX   * does not know anything about demand-zero pages.
XX   *
XX   */
XX! void initm4()
XX  {
XX  	register int i;
XX  
XX***************
XX*** 435,441 ****
XX   * to at least install the keywords (i.e. malloc won't fail).
XX   *
XX   */
XX! initkwds() {
XX  	register int i;
XX  	register int h;
XX  	register ndptr p;
XX--- 427,433 ----
XX   * to at least install the keywords (i.e. malloc won't fail).
XX   *
XX   */
XX! void initkwds() {
XX  	register int i;
XX  	register int h;
XX  	register ndptr p;
X/
Xecho x - mdef.h.d
Xsed '/^X/s///' > mdef.h.d << '/'
XX*** /home/top/ast/minix/1.5/commands/m4/mdef.h  crc=53236   4711	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/m4/mdef.h  crc=43751   7171	Mon Dec 21 18:56:28 1992
XX***************
XX*** 21,29 ****
XX  
XX  #else 
XX  
XX! #include <stdio.h>
XX  #include <ctype.h>
XX  #include <signal.h>
XX  
XX  #endif
XX  
XX--- 21,33 ----
XX  
XX  #else 
XX  
XX! #include <sys/types.h>
XX  #include <ctype.h>
XX  #include <signal.h>
XX+ #include <string.h>
XX+ #include <stdlib.h>
XX+ #include <unistd.h>
XX+ #include <stdio.h>
XX  
XX  #endif
XX  
XX***************
XX*** 192,194 ****
XX--- 196,275 ----
XX  #define PREVEP	(mstack[fp+3].sstr)
XX  #define PREVSP	(fp-3)
XX  #define PREVFP	(mstack[fp-2].sfra)
XX+ 
XX+ /* function prototypes */
XX+ 
XX+ /* eval.c */
XX+ 
XX+ _PROTOTYPE(void eval, (char *argv [], int argc, int td ));
XX+ 
XX+ /* expr.c */
XX+ 
XX+ _PROTOTYPE(int expr, (char *expbuf ));
XX+ _PROTOTYPE(int query, (void));
XX+ _PROTOTYPE(int lor, (void));
XX+ _PROTOTYPE(int land, (void));
XX+ _PROTOTYPE(int bor, (void));
XX+ _PROTOTYPE(int bxor, (void));
XX+ _PROTOTYPE(int band, (void));
XX+ _PROTOTYPE(int eql, (void));
XX+ _PROTOTYPE(int relat, (void));
XX+ _PROTOTYPE(int shift, (void));
XX+ _PROTOTYPE(int primary, (void));
XX+ _PROTOTYPE(int term, (void));
XX+ _PROTOTYPE(int unary, (void));
XX+ _PROTOTYPE(int factor, (void));
XX+ _PROTOTYPE(int constant, (void));
XX+ _PROTOTYPE(int num, (void));
XX+ _PROTOTYPE(int geteql, (void));
XX+ _PROTOTYPE(int getrel, (void));
XX+ _PROTOTYPE(int skipws, (void));
XX+ _PROTOTYPE(int experr, (char *msg ));
XX+ 
XX+ /* look.c */
XX+ 
XX+ _PROTOTYPE(int hash, (char *name ));
XX+ _PROTOTYPE(ndptr lookup, (char *name ));
XX+ _PROTOTYPE(ndptr addent, (char *name ));
XX+ _PROTOTYPE(void remhash, (char *name, int all ));
XX+ _PROTOTYPE(void freent, (ndptr p ));
XX+ 
XX+ /* main.c */
XX+ 
XX+ _PROTOTYPE(int main, (int argc, char *argv []));
XX+ _PROTOTYPE(void macro, (void));
XX+ _PROTOTYPE(ndptr inspect, (char *tp ));
XX+ _PROTOTYPE(void initm4, (void));
XX+ _PROTOTYPE(void initkwds, (void));
XX+ 
XX+ /* misc.c */
XX+ 
XX+ _PROTOTYPE(int indx, (char *s1, char *s2 ));
XX+ _PROTOTYPE(void putback, (int c ));
XX+ _PROTOTYPE(void pbstr, (char *s ));
XX+ _PROTOTYPE(void pbnum, (int n ));
XX+ _PROTOTYPE(void chrsave, (int c ));
XX+ _PROTOTYPE(void getdiv, (int ind ));
XX+ _PROTOTYPE(void error, (char *s ));
XX+ _PROTOTYPE(void onintr, (int s ));
XX+ _PROTOTYPE(void killdiv, (void));
XX+ _PROTOTYPE(char *strsave, (char *s ));
XX+ _PROTOTYPE(void usage, (void));
XX+ _PROTOTYPE(int getopt, (int argc, char *argv [], char *optstring ));
XX+ 
XX+ /* serv.c */
XX+ 
XX+ _PROTOTYPE(void expand, (char *argv [], int argc ));
XX+ _PROTOTYPE(void dodefine, (char *name, char *defn ));
XX+ _PROTOTYPE(void dodefn, (char *name ));
XX+ _PROTOTYPE(void dopushdef, (char *name, char *defn ));
XX+ _PROTOTYPE(void dodump, (char *argv [], int argc ));
XX+ _PROTOTYPE(void doifelse, (char *argv [], int argc ));
XX+ _PROTOTYPE(int doincl, (char *ifile ));
XX+ _PROTOTYPE(int dopaste, (char *pfile ));
XX+ _PROTOTYPE(void dochq, (char *argv [], int argc ));
XX+ _PROTOTYPE(void dochc, (char *argv [], int argc ));
XX+ _PROTOTYPE(void dodiv, (int n ));
XX+ _PROTOTYPE(void doundiv, (char *argv [], int argc ));
XX+ _PROTOTYPE(void dosub, (char *argv [], int argc ));
XX+ _PROTOTYPE(void map, (char *dest, char *src, char *from, char *to ));
X/
Xecho x - misc.c.d
Xsed '/^X/s///' > misc.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/m4/misc.c  crc=38118   5005	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/m4/misc.c  crc=19176   5064	Mon Dec 21 18:56:28 1992
XX***************
XX*** 7,19 ****
XX  #include "mdef.h"
XX  #include "extr.h" 
XX   
XX- extern char *malloc();
XX-  
XX  /*
XX   * indx - find the index of second str in the
XX   *        first str.
XX   */
XX! indx(s1, s2)
XX  char *s1;
XX  char *s2;
XX  {
XX--- 7,17 ----
XX  #include "mdef.h"
XX  #include "extr.h" 
XX   
XX  /*
XX   * indx - find the index of second str in the
XX   *        first str.
XX   */
XX! int indx(s1, s2)
XX  char *s1;
XX  char *s2;
XX  {
XX***************
XX*** 34,40 ****
XX   *  putback - push character back onto input
XX   *
XX   */
XX! putback (c)
XX  char c;
XX  {
XX          if (bp < endpbb)
XX--- 32,38 ----
XX   *  putback - push character back onto input
XX   *
XX   */
XX! void putback (c)
XX  char c;
XX  {
XX          if (bp < endpbb)
XX***************
XX*** 49,55 ****
XX   *          performance.
XX   *
XX   */
XX! pbstr(s)
XX  register char *s;
XX  {
XX          register char *es;
XX--- 47,53 ----
XX   *          performance.
XX   *
XX   */
XX! void pbstr(s)
XX  register char *s;
XX  {
XX          register char *es;
XX***************
XX*** 72,78 ****
XX   *  pbnum - convert number to string, push back on input.
XX   *
XX   */
XX! pbnum (n)
XX  int n;
XX  {
XX          register int num;
XX--- 70,76 ----
XX   *  pbnum - convert number to string, push back on input.
XX   *
XX   */
XX! void pbnum (n)
XX  int n;
XX  {
XX          register int num;
XX***************
XX*** 90,96 ****
XX   *  chrsave - put single char on string space
XX   *
XX   */
XX! chrsave (c)
XX  char c;
XX  {
XX  /***        if (sp < 0)
XX--- 88,94 ----
XX   *  chrsave - put single char on string space
XX   *
XX   */
XX! void chrsave (c)
XX  char c;
XX  {
XX  /***        if (sp < 0)
XX***************
XX*** 105,111 ****
XX   * getdiv - read in a diversion file, and
XX   *          trash it.
XX   */
XX! getdiv(ind) {
XX          register int c;
XX          register FILE *dfil;
XX   
XX--- 103,111 ----
XX   * getdiv - read in a diversion file, and
XX   *          trash it.
XX   */
XX! void getdiv(ind)
XX! int ind;
XX! {
XX          register int c;
XX          register FILE *dfil;
XX   
XX***************
XX*** 133,139 ****
XX   * Very fatal error. Close all files
XX   * and die hard.
XX   */
XX! error(s)
XX  char *s;
XX  {
XX          killdiv();
XX--- 133,139 ----
XX   * Very fatal error. Close all files
XX   * and die hard.
XX   */
XX! void error(s)
XX  char *s;
XX  {
XX          killdiv();
XX***************
XX*** 146,152 ****
XX   */
XX  static char *msg = "\ninterrupted.";
XX   
XX! onintr() {
XX          error(msg);
XX  }
XX   
XX--- 146,154 ----
XX   */
XX  static char *msg = "\ninterrupted.";
XX   
XX! void onintr(s) 
XX! int s;				/* ANSI requires the parameter */
XX! {
XX          error(msg);
XX  }
XX   
XX***************
XX*** 154,160 ****
XX   * killdiv - get rid of the diversion files
XX   *
XX   */
XX! killdiv() {
XX          register int n;
XX   
XX          for (n = 0; n < MAXOUT; n++)
XX--- 156,162 ----
XX   * killdiv - get rid of the diversion files
XX   *
XX   */
XX! void killdiv() {
XX          register int n;
XX   
XX          for (n = 0; n < MAXOUT; n++)
XX***************
XX*** 179,190 ****
XX  	register int n;
XX          char *p;
XX  
XX!         if ((p = malloc (n = strlen(s)+1)) != NULL)
XX!                 (void) memcpy(p, s, n);
XX          return (p);
XX  }
XX   
XX! usage() {
XX          fprintf(stderr, "Usage: m4 [-Dname[=val]] [-Uname]\n");
XX          exit(1);
XX  }
XX--- 181,193 ----
XX  	register int n;
XX          char *p;
XX  
XX! 	n = strlen(s)+1;
XX! 	p = (char *) malloc(n);
XX!         if (p != NULL) (void) memcpy(p, s, n);
XX          return (p);
XX  }
XX   
XX! void usage() {
XX          fprintf(stderr, "Usage: m4 [-Dname[=val]] [-Uname]\n");
XX          exit(1);
XX  }
XX***************
XX*** 203,210 ****
XX  
XX  static char	*scan = NULL;	/* Private scan pointer. */
XX  
XX- extern char	*index();
XX- 
XX  int
XX  getopt(argc, argv, optstring)
XX  int argc;
XX--- 206,211 ----
XX***************
XX*** 265,271 ****
XX  
XX  #define COPYBYTE 	*to++ = *from++
XX  
XX! memcpy(to, from, count)
XX  register char *from, *to;
XX  register int count;
XX  {
XX--- 266,272 ----
XX  
XX  #define COPYBYTE 	*to++ = *from++
XX  
XX! void memcpy(to, from, count)
XX  register char *from, *to;
XX  register int count;
XX  {
X/
Xecho x - serv.c.d
Xsed '/^X/s///' > serv.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/m4/serv.c  crc=02122  11554	Sat Apr 21 22:27:20 1990
XX--- /home/top/ast/minix/1.6.25/commands/m4/serv.c  crc=13547  11549	Thu Aug 27 20:38:49 1992
XX***************
XX*** 7,23 ****
XX  #include "mdef.h"
XX  #include "extr.h" 
XX  
XX- extern ndptr lookup();
XX- extern ndptr addent();
XX- extern char  *strsave();
XX-  
XX  char *dumpfmt = "`%s'\t`%s'\n"; /* format string for dumpdef   */
XX   
XX  /*
XX   * expand - user-defined macro expansion
XX   *
XX   */
XX! expand(argv, argc)
XX  register char *argv[];
XX  register int argc;
XX  {
XX--- 7,19 ----
XX  #include "mdef.h"
XX  #include "extr.h" 
XX  
XX  char *dumpfmt = "`%s'\t`%s'\n"; /* format string for dumpdef   */
XX   
XX  /*
XX   * expand - user-defined macro expansion
XX   *
XX   */
XX! void expand(argv, argc)
XX  register char *argv[];
XX  register int argc;
XX  {
XX***************
XX*** 76,82 ****
XX   * dodefine - install definition in the table
XX   *
XX   */
XX! dodefine(name, defn)
XX  register char *name;
XX  register char *defn;
XX  {
XX--- 72,78 ----
XX   * dodefine - install definition in the table
XX   *
XX   */
XX! void dodefine(name, defn)
XX  register char *name;
XX  register char *defn;
XX  {
XX***************
XX*** 102,108 ****
XX   *      the given name.
XX   */
XX   
XX! dodefn(name)
XX  char *name;
XX  {
XX          register ndptr p;
XX--- 98,104 ----
XX   *      the given name.
XX   */
XX   
XX! void dodefn(name)
XX  char *name;
XX  {
XX          register ndptr p;
XX***************
XX*** 121,127 ****
XX   *      hash bucket, it hides a previous definition from
XX   *      lookup.
XX   */
XX! dopushdef(name, defn)
XX  register char *name;
XX  register char *defn;
XX  {
XX--- 117,123 ----
XX   *      hash bucket, it hides a previous definition from
XX   *      lookup.
XX   */
XX! void dopushdef(name, defn)
XX  register char *name;
XX  register char *defn;
XX  {
XX***************
XX*** 145,151 ****
XX   *      hash table is dumped.
XX   *
XX   */
XX! dodump(argv, argc)
XX  register char *argv[];
XX  register int argc;
XX  {
XX--- 141,147 ----
XX   *      hash table is dumped.
XX   *
XX   */
XX! void dodump(argv, argc)
XX  register char *argv[];
XX  register int argc;
XX  {
XX***************
XX*** 170,176 ****
XX   * doifelse - select one of two alternatives - loop.
XX   *
XX   */
XX! doifelse(argv,argc)
XX  register char *argv[];
XX  register int argc;
XX  {
XX--- 166,172 ----
XX   * doifelse - select one of two alternatives - loop.
XX   *
XX   */
XX! void doifelse(argv,argc)
XX  register char *argv[];
XX  register int argc;
XX  {
XX***************
XX*** 192,198 ****
XX   * doinclude - include a given file.
XX   *
XX   */
XX! doincl(ifile)
XX  char *ifile;
XX  {
XX          if (ilevel+1 == MAXINP)
XX--- 188,194 ----
XX   * doinclude - include a given file.
XX   *
XX   */
XX! int doincl(ifile)
XX  char *ifile;
XX  {
XX          if (ilevel+1 == MAXINP)
XX***************
XX*** 210,216 ****
XX   * dopaste - include a given file without any
XX   *           macro processing.
XX   */
XX! dopaste(pfile)
XX  char *pfile;
XX  {
XX          FILE *pf;
XX--- 206,212 ----
XX   * dopaste - include a given file without any
XX   *           macro processing.
XX   */
XX! int dopaste(pfile)
XX  char *pfile;
XX  {
XX          FILE *pf;
XX***************
XX*** 231,237 ****
XX   * dochq - change quote characters
XX   *
XX   */
XX! dochq(argv, argc)
XX  register char *argv[];
XX  register int argc;
XX  {
XX--- 227,233 ----
XX   * dochq - change quote characters
XX   *
XX   */
XX! void dochq(argv, argc)
XX  register char *argv[];
XX  register int argc;
XX  {
XX***************
XX*** 255,261 ****
XX   * dochc - change comment characters
XX   *
XX   */
XX! dochc(argv, argc)
XX  register char *argv[];
XX  register int argc;
XX  {
XX--- 251,257 ----
XX   * dochc - change comment characters
XX   *
XX   */
XX! void dochc(argv, argc)
XX  register char *argv[];
XX  register int argc;
XX  {
XX***************
XX*** 279,285 ****
XX   * dodivert - divert the output to a temporary file
XX   *
XX   */
XX! dodiv(n)
XX  register int n;
XX  {
XX          if (n < 0 || n >= MAXOUT)
XX--- 275,281 ----
XX   * dodivert - divert the output to a temporary file
XX   *
XX   */
XX! void dodiv(n)
XX  register int n;
XX  {
XX          if (n < 0 || n >= MAXOUT)
XX***************
XX*** 297,303 ****
XX   * doundivert - undivert a specified output, or all
XX   *              other outputs, in numerical order.
XX   */
XX! doundiv(argv, argc)
XX  register char *argv[];
XX  register int argc;
XX  {
XX--- 293,299 ----
XX   * doundivert - undivert a specified output, or all
XX   *              other outputs, in numerical order.
XX   */
XX! void doundiv(argv, argc)
XX  register char *argv[];
XX  register int argc;
XX  {
XX***************
XX*** 322,328 ****
XX   * dosub - select substring
XX   *
XX   */
XX! dosub (argv, argc)
XX  register char *argv[];
XX  register int  argc;
XX  {
XX--- 318,324 ----
XX   * dosub - select substring
XX   *
XX   */
XX! void dosub (argv, argc)
XX  register char *argv[];
XX  register int  argc;
XX  {
XX***************
XX*** 375,381 ****
XX   *
XX   */
XX       
XX! map(dest,src,from,to)
XX  register char *dest;
XX  register char *src;
XX  register char *from;
XX--- 371,377 ----
XX   *
XX   */
XX       
XX! void map(dest,src,from,to)
XX  register char *dest;
XX  register char *src;
XX  register char *from;
X/
/
