echo x - kermit.cd
sed '/^X/s///' > kermit.cd << '/'
Xecho x - Makefile.d
Xsed '/^X/s///' > Makefile.d << '/'
XX*** /home/top/ast/minix/1.5/commands/kermit/Makefile  crc=15361   1974	Sat Apr 21 22:27:19 1990
XX--- /home/top/ast/minix/1.6.25/commands/kermit/Makefile  crc=49408   1978	Sat Jan 30 20:12:16 1993
XX***************
XX*** 1,7 ****
XX  # CKUMNX.MAK, Version 2.11, 29 January 1988
XX  #
XX  # -- Makefile to build C-Kermit for Minix.  This is a separate file
XX! # because Minix uses .s instead of .o for its object files. This
XX  # means that not one line of the file is the same as the standard
XX  # Unix makefile, so it seems silly to clutter the common file.
XX  
XX--- 1,9 ----
XX+ # Makefile for kermit
XX+ 
XX  # CKUMNX.MAK, Version 2.11, 29 January 1988
XX  #
XX  # -- Makefile to build C-Kermit for Minix.  This is a separate file
XX! # because Minix uses .o instead of .o for its object files. This
XX  # means that not one line of the file is the same as the standard
XX  # Unix makefile, so it seems silly to clutter the common file.
XX  
XX***************
XX*** 9,43 ****
XX  #
XX  #  Compile and Link variables:
XX  #
XX! LNKFLAGS= -i -T.
XX! CC= cc
XX! CC2= cc
XX! CFLAGS=-DV7 -DMINIX -i -D_MINIX -D_POSIX_SOURCE
XX  #
XX  ###########################################################################
XX  #
XX  # Dependencies Section:
XX  #
XX  
XX! wermit: ckcmai.s ckucmd.s ckuusr.s ckuus2.s ckuus3.s ckcpro.s ckcfns.s \
XX! 		 ckcfn2.s ckucon.s ckutio.s ckufio.s ckudia.s ckuscr.s
XX! 	$(CC2) $(LNKFLAGS) -o wermit ckcmai.s ckutio.s \
XX! 		 ckufio.s ckcfns.s \
XX! 		 ckcfn2.s ckcpro.s ckucmd.s ckuus2.s ckuus3.s ckuusr.s \
XX! 		 ckucon.s ckudia.s ckuscr.s
XX  
XX! ckcmai.s: ckcmai.c ckcker.h ckcdeb.h ckcsym.h
XX  
XX- ckuusr.s: ckuusr.c ckucmd.h ckcker.h ckuusr.h ckcdeb.h
XX- 
XX- ckuus2.s: ckuus2.c ckucmd.h ckcker.h ckuusr.h ckcdeb.h
XX- 
XX- ckuus3.s: ckuus3.c ckucmd.h ckcker.h ckuusr.h ckcdeb.h
XX- 
XX- ckucmd.s: ckucmd.c ckucmd.h ckcdeb.h
XX- 
XX- ckcpro.s: ckcpro.c ckcker.h ckcdeb.h
XX- 
XX  # I'm using the distributed copy of ckcpro.c.  Unfortunately
XX  # wart won't compile.  If you need to change ckcpro.w, you'll have
XX  # to find a way to reduce the number of strings in ckwart.c
XX--- 11,43 ----
XX  #
XX  #  Compile and Link variables:
XX  #
XX! CC=exec cc
XX! LNKFLAGS=-i
XX! CFLAGS=-DV7 -DMINIX -O -wo
XX! O=s
XX  #
XX  ###########################################################################
XX  #
XX  # Dependencies Section:
XX  #
XX  
XX! kermit: ckcmai.$O ckucmd.$O ckuusr.$O ckuus2.$O ckuus3.$O ckcpro.$O ckcfns.$O \
XX! 		 ckcfn2.$O ckucon.$O ckutio.$O ckufio.$O ckudia.$O ckuscr.$O
XX! 	@rm -rf kermit
XX! 	@echo Start linking kermit
XX! 	@$(CC) $(LNKFLAGS) -o kermit ckcmai.$O ckutio.$O \
XX! 		 ckufio.$O ckcfns.$O \
XX! 		 ckcfn2.$O ckcpro.$O ckucmd.$O ckuus2.$O ckuus3.$O ckuusr.$O \
XX! 		 ckucon.$O ckudia.$O ckuscr.$O >/dev/null
XX! 	@chmem =65000 kermit
XX  
XX! ckcmai.$O: ckcmai.c ckcker.h ckcdeb.h ckcsym.h
XX! ckuusr.$O: ckuusr.c ckucmd.h ckcker.h ckuusr.h ckcdeb.h
XX! ckuus2.$O: ckuus2.c ckucmd.h ckcker.h ckuusr.h ckcdeb.h
XX! ckuus3.$O: ckuus3.c ckucmd.h ckcker.h ckuusr.h ckcdeb.h
XX! ckucmd.$O: ckucmd.c ckucmd.h ckcdeb.h
XX! ckcpro.$O: ckcpro.c ckcker.h ckcdeb.h
XX  
XX  # I'm using the distributed copy of ckcpro.c.  Unfortunately
XX  # wart won't compile.  If you need to change ckcpro.w, you'll have
XX  # to find a way to reduce the number of strings in ckwart.c
XX***************
XX*** 45,73 ****
XX  # ckcpro.c: ckcpro.w wart
XX  #	./wart ckcpro.w ckcpro.c
XX  
XX! ckcfns.s: ckcfns.c ckcker.h ckcdeb.h ckcsym.h
XX  
XX! ckcfn2.s: ckcfn2.c ckcker.h ckcdeb.h ckcsym.h
XX  
XX! ckufio.s: ckufio.c ckcker.h ckcdeb.h
XX  
XX- ckutio.s: ckutio.c ckcdeb.h
XX- 
XX- ckucon.s: ckucon.c ckcker.h ckcdeb.h
XX- 
XX- wart: ckwart.s
XX- 	$(CC) $(LNKFLAGS) -o wart ckwart.s
XX- 
XX- ckwart.s: ckwart.c
XX- 
XX- ckudia.s: ckudia.c ckcker.h ckcdeb.h ckucmd.h
XX- 
XX- ckuscr.s: ckuscr.c ckcker.h ckcdeb.h
XX- 
XX  #Clean up intermediate and object files
XX  clean:
XX! 	@rm -f *.s *.bak wermit
XX  
XX- #Run Lint on this mess for the BSD version.
XX- lint:
XX- 	-lint -x -DBSD4 -DDEBUG -DTLOG ck[cu]*.[hc] > ck.lint.bsd4
XX--- 45,64 ----
XX  # ckcpro.c: ckcpro.w wart
XX  #	./wart ckcpro.w ckcpro.c
XX  
XX! ckcfns.$O: ckcfns.c ckcker.h ckcdeb.h ckcsym.h
XX! ckcfn2.$O: ckcfn2.c ckcker.h ckcdeb.h ckcsym.h
XX! ckufio.$O: ckufio.c ckcker.h ckcdeb.h
XX! ckutio.$O: ckutio.c ckcdeb.h
XX! ckucon.$O: ckucon.c ckcker.h ckcdeb.h
XX  
XX! wart: ckwart.$O
XX! 	$(CC) $(LNKFLAGS) -o wart ckwart.$O
XX  
XX! ckwart.$O: ckwart.c
XX! ckudia.$O: ckudia.c ckcker.h ckcdeb.h ckucmd.h
XX! ckuscr.$O: ckuscr.c ckcker.h ckcdeb.h
XX  
XX  #Clean up intermediate and object files
XX  clean:
XX! 	@rm -f *.o *.s *.bak core kermit
XX  
X/
Xecho x - ckucon.c.d
Xsed '/^X/s///' > ckucon.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/kermit/ckucon.c  crc=20124   7921	Sat Apr 21 22:27:19 1990
XX--- /home/top/ast/minix/1.6.25/commands/kermit/ckucon.c  crc=55256   7944	Thu Jul 16 23:17:16 1992
XX***************
XX*** 19,24 ****
XX--- 19,25 ----
XX   interpreter, to allow sending/receiving without breaking connection.
XX  */
XX  
XX+ #include <sys/types.h>
XX  #include <stdio.h>
XX  #include <ctype.h>			/* Character types */
XX  #include "ckcdeb.h"
X/
Xecho x - ckudia.c.d
Xsed '/^X/s///' > ckudia.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/kermit/ckudia.c  crc=06319  26786	Sat Apr 21 22:27:19 1990
XX--- /home/top/ast/minix/1.6.25/commands/kermit/ckudia.c  crc=41374  26809	Thu Jul 16 23:17:16 1992
XX***************
XX*** 113,118 ****
XX--- 113,119 ----
XX   * PHRASE THAT WOULD PRESUMABLY NEVER BE A PART OF A VALID AUTODIAL SEQUENCE
XX   * (E.G., "QUIT" and "quit"). -- DS
XX   */
XX+ #include <sys/types.h>
XX  #include "ckcdeb.h"
XX  #include <stdio.h>
XX  #include <ctype.h>
X/
Xecho x - ckuscr.c.d
Xsed '/^X/s///' > ckuscr.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/kermit/ckuscr.c  crc=55500   9477	Sat Apr 21 22:27:19 1990
XX--- /home/top/ast/minix/1.6.25/commands/kermit/ckuscr.c  crc=57577   9500	Thu Jul 16 23:17:17 1992
XX***************
XX*** 26,31 ****
XX--- 26,32 ----
XX   copyright notice is retained. 
XX  */
XX  
XX+ #include <sys/types.h>
XX  #include "ckcdeb.h"
XX  #include <stdio.h>
XX  #include <ctype.h>
X/
Xecho x - ckuusr.c.d
Xsed '/^X/s///' > ckuusr.c.d << '/'
XX*** /home/top/ast/minix/1.5/commands/kermit/ckuusr.c  crc=01620  34256	Sat Apr 21 22:27:19 1990
XX--- /home/top/ast/minix/1.6.25/commands/kermit/ckuusr.c  crc=62275  34279	Thu Jul 16 23:17:20 1992
XX***************
XX*** 71,76 ****
XX--- 71,77 ----
XX  
XX  /* Includes */
XX   
XX+ #include <sys/types.h>
XX  #include "ckcdeb.h"
XX  #include <stdio.h>
XX  #include <ctype.h>
X/
/
