echo x - Makefile
sed '/^X/s///' > Makefile << '/'
X.s.o:
X	$(CC) $(CFLAGS) $<
X
XCC=exec cc
XCFLAGS= -c -O
X
X
Xall:	
X	@$(CC) $(CFLAGS) *.s
X
X
Xclean:	
X	@rm -rf *.o *.bak
X
/
echo x - access.s
sed '/^X/s///' > access.s << '/'
X.sect .text
X.extern	__access
X.define	_access
X.align 2
X
X_access:
X	jmp	__access
/
echo x - alarm.s
sed '/^X/s///' > alarm.s << '/'
X.sect .text
X.extern	__alarm
X.define	_alarm
X.align 2
X
X_alarm:
X	jmp	__alarm
/
echo x - brk.s
sed '/^X/s///' > brk.s << '/'
X.sect .text
X.extern	__brk
X.define	_brk
X.align 2
X
X_brk:
X	jmp	__brk
/
echo x - chdir.s
sed '/^X/s///' > chdir.s << '/'
X.sect .text
X.extern	__chdir
X.define	_chdir
X.align 2
X
X_chdir:
X	jmp	__chdir
/
echo x - chmod.s
sed '/^X/s///' > chmod.s << '/'
X.sect .text
X.extern	__chmod
X.define	_chmod
X.align 2
X
X_chmod:
X	jmp	__chmod
/
echo x - chown.s
sed '/^X/s///' > chown.s << '/'
X.sect .text
X.extern	__chown
X.define	_chown
X.align 2
X
X_chown:
X	jmp	__chown
/
echo x - chroot.s
sed '/^X/s///' > chroot.s << '/'
X.sect .text
X.extern	__chroot
X.define	_chroot
X.align 2
X
X_chroot:
X	jmp	__chroot
/
echo x - close.s
sed '/^X/s///' > close.s << '/'
X.sect .text
X.extern	__close
X.define	_close
X.align 2
X
X_close:
X	jmp	__close
/
echo x - creat.s
sed '/^X/s///' > creat.s << '/'
X.sect .text
X.extern	__creat
X.define	_creat
X.align 2
X
X_creat:
X	jmp	__creat
/
echo x - dup.s
sed '/^X/s///' > dup.s << '/'
X.sect .text
X.extern	__dup
X.define	_dup
X.align 2
X
X_dup:
X	jmp	__dup
/
echo x - dup2.s
sed '/^X/s///' > dup2.s << '/'
X.sect .text
X.extern	__dup2
X.define	_dup2
X.align 2
X
X_dup2:
X	jmp	__dup2
/
echo x - execl.s
sed '/^X/s///' > execl.s << '/'
X.sect .text
X.extern	__execl
X.define	_execl
X.align 2
X
X_execl:
X	jmp	__execl
/
echo x - execle.s
sed '/^X/s///' > execle.s << '/'
X.sect .text
X.extern	__execle
X.define	_execle
X.align 2
X
X_execle:
X	jmp	__execle
/
echo x - execv.s
sed '/^X/s///' > execv.s << '/'
X.sect .text
X.extern	__execv
X.define	_execv
X.align 2
X
X_execv:
X	jmp	__execv
/
echo x - execve.s
sed '/^X/s///' > execve.s << '/'
X.sect .text
X.extern	__execve
X.define	_execve
X.align 2
X
X_execve:
X	jmp	__execve
/
echo x - fcntl.s
sed '/^X/s///' > fcntl.s << '/'
X.sect .text
X.extern	__fcntl
X.define	_fcntl
X.align 2
X
X_fcntl:
X	jmp	__fcntl
/
echo x - fork.s
sed '/^X/s///' > fork.s << '/'
X.sect .text
X.extern	__fork
X.define	_fork
X.align 2
X
X_fork:
X	jmp	__fork
/
echo x - fpathconf.s
sed '/^X/s///' > fpathconf.s << '/'
X.sect .text
X.extern	__fpathconf
X.define	_fpathconf
X.align 2
X
X_fpathconf:
X	jmp	__fpathconf
/
echo x - fstat.s
sed '/^X/s///' > fstat.s << '/'
X.sect .text
X.extern	__fstat
X.define	_fstat
X.align 2
X
X_fstat:
X	jmp	__fstat
/
echo x - getcwd.s
sed '/^X/s///' > getcwd.s << '/'
X.sect .text
X.extern	__getcwd
X.define	_getcwd
X.align 2
X
X_getcwd:
X	jmp	__getcwd
/
echo x - getegid.s
sed '/^X/s///' > getegid.s << '/'
X.sect .text
X.extern	__getegid
X.define	_getegid
X.align 2
X
X_getegid:
X	jmp	__getegid
/
echo x - geteuid.s
sed '/^X/s///' > geteuid.s << '/'
X.sect .text
X.extern	__geteuid
X.define	_geteuid
X.align 2
X
X_geteuid:
X	jmp	__geteuid
/
echo x - getgid.s
sed '/^X/s///' > getgid.s << '/'
X.sect .text
X.extern	__getgid
X.define	_getgid
X.align 2
X
X_getgid:
X	jmp	__getgid
/
echo x - getgroups.s
sed '/^X/s///' > getgroups.s << '/'
X.sect .text
X.extern	__getgroups
X.define	_getgroups
X.align 2
X
X_getgroups:
X	jmp	__getgroups
/
echo x - getpid.s
sed '/^X/s///' > getpid.s << '/'
X.sect .text
X.extern	__getpid
X.define	_getpid
X.align 2
X
X_getpid:
X	jmp	__getpid
/
echo x - getppid.s
sed '/^X/s///' > getppid.s << '/'
X.sect .text
X.extern	__getppid
X.define	_getppid
X.align 2
X
X_getppid:
X	jmp	__getppid
/
echo x - getuid.s
sed '/^X/s///' > getuid.s << '/'
X.sect .text
X.extern	__getuid
X.define	_getuid
X.align 2
X
X_getuid:
X	jmp	__getuid
/
echo x - gtty.s
sed '/^X/s///' > gtty.s << '/'
X.sect .text
X.extern	__gtty
X.define	_gtty
X.align 2
X
X_gtty:
X	jmp	__gtty
/
echo x - ioctl.s
sed '/^X/s///' > ioctl.s << '/'
X.sect .text
X.extern	__ioctl
X.define	_ioctl
X.align 2
X
X_ioctl:
X	jmp	__ioctl
/
echo x - isatty.s
sed '/^X/s///' > isatty.s << '/'
X.sect .text
X.extern	__isatty
X.define	_isatty
X.align 2
X
X_isatty:
X	jmp	__isatty
/
echo x - kill.s
sed '/^X/s///' > kill.s << '/'
X.sect .text
X.extern	__kill
X.define	_kill
X.align 2
X
X_kill:
X	jmp	__kill
/
echo x - link.s
sed '/^X/s///' > link.s << '/'
X.sect .text
X.extern	__link
X.define	_link
X.align 2
X
X_link:
X	jmp	__link
/
echo x - lseek.s
sed '/^X/s///' > lseek.s << '/'
X.sect .text
X.extern	__lseek
X.define	_lseek
X.align 2
X
X_lseek:
X	jmp	__lseek
/
echo x - mkdir.s
sed '/^X/s///' > mkdir.s << '/'
X.sect .text
X.extern	__mkdir
X.define	_mkdir
X.align 2
X
X_mkdir:
X	jmp	__mkdir
/
echo x - mkfifo.s
sed '/^X/s///' > mkfifo.s << '/'
X.sect .text
X.extern	__mkfifo
X.define	_mkfifo
X.align 2
X
X_mkfifo:
X	jmp	__mkfifo
/
echo x - mknod.s
sed '/^X/s///' > mknod.s << '/'
X.sect .text
X.extern	__mknod
X.define	_mknod
X.align 2
X
X_mknod:
X	jmp	__mknod
/
echo x - mknod4.s
sed '/^X/s///' > mknod4.s << '/'
X.sect .text
X.extern	__mknod4
X.define	_mknod4
X.align 2
X
X_mknod4:
X	jmp	__mknod4
/
echo x - mktemp.s
sed '/^X/s///' > mktemp.s << '/'
X.sect .text
X.extern	__mktemp
X.define	_mktemp
X.align 2
X
X_mktemp:
X	jmp	__mktemp
/
echo x - mount.s
sed '/^X/s///' > mount.s << '/'
X.sect .text
X.extern	__mount
X.define	_mount
X.align 2
X
X_mount:
X	jmp	__mount
/
echo x - open.s
sed '/^X/s///' > open.s << '/'
X.sect .text
X.extern	__open
X.define	_open
X.align 2
X
X_open:
X	jmp	__open
/
echo x - pathconf.s
sed '/^X/s///' > pathconf.s << '/'
X.sect .text
X.extern	__pathconf
X.define	_pathconf
X.align 2
X
X_pathconf:
X	jmp	__pathconf
/
echo x - pause.s
sed '/^X/s///' > pause.s << '/'
X.sect .text
X.extern	__pause
X.define	_pause
X.align 2
X
X_pause:
X	jmp	__pause
/
echo x - pipe.s
sed '/^X/s///' > pipe.s << '/'
X.sect .text
X.extern	__pipe
X.define	_pipe
X.align 2
X
X_pipe:
X	jmp	__pipe
/
echo x - ptrace.s
sed '/^X/s///' > ptrace.s << '/'
X.sect .text
X.extern	__ptrace
X.define	_ptrace
X.align 2
X
X_ptrace:
X	jmp	__ptrace
/
echo x - read.s
sed '/^X/s///' > read.s << '/'
X.sect .text
X.extern	__read
X.define	_read
X.align 2
X
X_read:
X	jmp	__read
/
echo x - rename.s
sed '/^X/s///' > rename.s << '/'
X.sect .text
X.extern	__rename
X.define	_rename
X.align 2
X
X_rename:
X	jmp	__rename
/
echo x - rmdir.s
sed '/^X/s///' > rmdir.s << '/'
X.sect .text
X.extern	__rmdir
X.define	_rmdir
X.align 2
X
X_rmdir:
X	jmp	__rmdir
/
echo x - sbrk.s
sed '/^X/s///' > sbrk.s << '/'
X.sect .text
X.extern	__sbrk
X.define	_sbrk
X.align 2
X
X_sbrk:
X	jmp	__sbrk
/
echo x - setgid.s
sed '/^X/s///' > setgid.s << '/'
X.sect .text
X.extern	__setgid
X.define	_setgid
X.align 2
X
X_setgid:
X	jmp	__setgid
/
echo x - setuid.s
sed '/^X/s///' > setuid.s << '/'
X.sect .text
X.extern	__setuid
X.define	_setuid
X.align 2
X
X_setuid:
X	jmp	__setuid
/
echo x - sigaction.s
sed '/^X/s///' > sigaction.s << '/'
X.sect .text
X.extern	__sigaction
X.define	_sigaction
X.align 2
X
X_sigaction:
X	jmp	__sigaction
/
echo x - sigaddset.s
sed '/^X/s///' > sigaddset.s << '/'
X.sect .text
X.extern	__sigaddset
X.define	_sigaddset
X.align 2
X
X_sigaddset:
X	jmp	__sigaddset
/
echo x - sigdelset.s
sed '/^X/s///' > sigdelset.s << '/'
X.sect .text
X.extern	__sigdelset
X.define	_sigdelset
X.align 2
X
X_sigdelset:
X	jmp	__sigdelset
/
echo x - sigemptyset.s
sed '/^X/s///' > sigemptyset.s << '/'
X.sect .text
X.extern	__sigemptyset
X.define	_sigemptyset
X.align 2
X
X_sigemptyset:
X	jmp	__sigemptyset
/
echo x - sigfillset.s
sed '/^X/s///' > sigfillset.s << '/'
X.sect .text
X.extern	__sigfillset
X.define	_sigfillset
X.align 2
X
X_sigfillset:
X	jmp	__sigfillset
/
echo x - sigismember.s
sed '/^X/s///' > sigismember.s << '/'
X.sect .text
X.extern	__sigismember
X.define	_sigismember
X.align 2
X
X_sigismember:
X	jmp	__sigismember
/
echo x - sigpending.s
sed '/^X/s///' > sigpending.s << '/'
X.sect .text
X.extern	__sigpending
X.define	_sigpending
X.align 2
X
X_sigpending:
X	jmp	__sigpending
/
echo x - sigprocmask.s
sed '/^X/s///' > sigprocmask.s << '/'
X.sect .text
X.extern	__sigprocmask
X.define	_sigprocmask
X.align 2
X
X_sigprocmask:
X	jmp	__sigprocmask
/
echo x - sigreturn.s
sed '/^X/s///' > sigreturn.s << '/'
X.sect .text
X.extern	__sigreturn
X.define	_sigreturn
X.align 2
X
X_sigreturn:
X	jmp	__sigreturn
/
echo x - sigsuspend.s
sed '/^X/s///' > sigsuspend.s << '/'
X.sect .text
X.extern	__sigsuspend
X.define	_sigsuspend
X.align 2
X
X_sigsuspend:
X	jmp	__sigsuspend
/
echo x - sleep.s
sed '/^X/s///' > sleep.s << '/'
X.sect .text
X.extern	__sleep
X.define	_sleep
X.align 2
X
X_sleep:
X	jmp	__sleep
/
echo x - stat.s
sed '/^X/s///' > stat.s << '/'
X.sect .text
X.extern	__stat
X.define	_stat
X.align 2
X
X_stat:
X	jmp	__stat
/
echo x - stime.s
sed '/^X/s///' > stime.s << '/'
X.sect .text
X.extern	__stime
X.define	_stime
X.align 2
X
X_stime:
X	jmp	__stime
/
echo x - stty.s
sed '/^X/s///' > stty.s << '/'
X.sect .text
X.extern	__stty
X.define	_stty
X.align 2
X
X_stty:
X	jmp	__stty
/
echo x - sync.s
sed '/^X/s///' > sync.s << '/'
X.sect .text
X.extern	__sync
X.define	_sync
X.align 2
X
X_sync:
X	jmp	__sync
/
echo x - time.s
sed '/^X/s///' > time.s << '/'
X.sect .text
X.extern	__time
X.define	_time
X.align 2
X
X_time:
X	jmp	__time
/
echo x - times.s
sed '/^X/s///' > times.s << '/'
X.sect .text
X.extern	__times
X.define	_times
X.align 2
X
X_times:
X	jmp	__times
/
echo x - umask.s
sed '/^X/s///' > umask.s << '/'
X.sect .text
X.extern	__umask
X.define	_umask
X.align 2
X
X_umask:
X	jmp	__umask
/
echo x - umount.s
sed '/^X/s///' > umount.s << '/'
X.sect .text
X.extern	__umount
X.define	_umount
X.align 2
X
X_umount:
X	jmp	__umount
/
echo x - uname.s
sed '/^X/s///' > uname.s << '/'
X.sect .text
X.extern	__uname
X.define	_uname
X.align 2
X
X_uname:
X	jmp	__uname
/
echo x - unlink.s
sed '/^X/s///' > unlink.s << '/'
X.sect .text
X.extern	__unlink
X.define	_unlink
X.align 2
X
X_unlink:
X	jmp	__unlink
/
echo x - utime.s
sed '/^X/s///' > utime.s << '/'
X.sect .text
X.extern	__utime
X.define	_utime
X.align 2
X
X_utime:
X	jmp	__utime
/
echo x - wait.s
sed '/^X/s///' > wait.s << '/'
X.sect .text
X.extern	__wait
X.define	_wait
X.align 2
X
X_wait:
X	jmp	__wait
/
echo x - waitpid.s
sed '/^X/s///' > waitpid.s << '/'
X.sect .text
X.extern	__waitpid
X.define	_waitpid
X.align 2
X
X_waitpid:
X	jmp	__waitpid
/
echo x - write.s
sed '/^X/s///' > write.s << '/'
X.sect .text
X.extern	__write
X.define	_write
X.align 2
X
X_write:
X	jmp	__write
/
