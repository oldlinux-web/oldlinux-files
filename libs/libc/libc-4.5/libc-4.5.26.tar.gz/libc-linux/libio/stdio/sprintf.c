#undef HAVE_GNU_LD
#define HAVE_GNU_LD
#include <gnu-stabs.h>
#undef sprintf
symbol_alias (_IO_sprintf, sprintf);
