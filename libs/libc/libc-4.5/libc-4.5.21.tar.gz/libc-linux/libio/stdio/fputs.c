#undef HAVE_GNU_LD
#define HAVE_GNU_LD
#include <gnu-stabs.h>
#undef fputs
symbol_alias (_IO_fputs, fputs);
