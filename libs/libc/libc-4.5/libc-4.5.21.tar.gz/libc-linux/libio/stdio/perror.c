#undef HAVE_GNU_LD
#define HAVE_GNU_LD
#include <gnu-stabs.h>
#undef perror
symbol_alias (_IO_perror, perror);
