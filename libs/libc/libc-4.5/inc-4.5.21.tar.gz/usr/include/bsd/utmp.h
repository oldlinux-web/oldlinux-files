#ifndef _BSD_UTMP_H
#define _BSD_UTMP_H

#include_next <utmp.h>
#include_next <paths.h>

#define UT_LINESIZE	sizeof(((struct utmp *)NULL)->ut_line)
#ifndef UT_NAMESIZE
#define UT_NAMESIZE	sizeof(((struct utmp *)NULL)->ut_user)
#endif
#define UT_HOSTSIZE	sizeof(((struct utmp *)NULL)->ut_host)

struct lastlog {
	long ll_time;
	char ll_line[12];
	char ll_host[16];
};

#endif /* _BSD_UTMP_H */
