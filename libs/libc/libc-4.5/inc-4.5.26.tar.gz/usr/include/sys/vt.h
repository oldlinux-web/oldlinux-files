#ifndef _SYS_VT_H
#define _SYS_VT_H

#include <linux/vt.h>

#endif /* _SYS_VT_H */
