$set 8 #RpcErrList

$ #1 Original Message:(RPC: Success)
# RPC: Succ�s

$ #2 Original Message:(RPC: Can't encode arguments)
# RPC: Ne peut pas coder les arguments

$ #3 Original Message:(RPC: Can't decode result)
# RPC: Ne peur pas d�coder le r�sultat

$ #4 Original Message:(RPC: Unable to send)
# RPC: Incapacit� d'envoyer

$ #5 Original Message:(RPC: Unable to receive)
# RPC: Incapacit� de recevoir

$ #6 Original Message:(RPC: Timed out)
# RPC: Dur�e expir�e

$ #7 Original Message:(RPC: Incompatible versions of RPC)
# RPC: Versions de RPC incompatibles

$ #8 Original Message:(RPC: Authentication error)
# RPC: Erreur d'autentification

$ #9 Original Message:(RPC: Program unavailable)
# RPC: Programme non disponible

$ #10 Original Message:(RPC: Program/version mismatch)
# RPC: Le programme ou la version est incompatible

$ #11 Original Message:(RPC: Procedure unavailable)
# RPC: Proc�dure non disponible

$ #12 Original Message:(RPC: Server can't decode arguments)
# RPC: Le serveur ne peut d�coder les arguments

$ #13 Original Message:(RPC: Remote system error)
# RPC: Erreur du syst�me distant

$ #14 Original Message:(RPC: Unknown host)
# RPC: H�te inconnu

$ #15 Original Message:(RPC: Port mapper failure)
# RPC: Echec de la redirection du port

$ #16 Original Message:(RPC: Program not registered)
# RPC: Programme non enregistr�

$ #17 Original Message:(RPC: Failed (unspecified error))
# RPC: Echec (erreur non sp�cifi�e)

$ #18 Original Message:(RPC: Unknown protocol)
# RPC: Protocole inconnu

$ #Unknown Original Message:(RPC: (unknown error code))
# RPC: (code d'erreur inconnu)
