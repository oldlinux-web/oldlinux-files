#ifndef NO_JUMP_TABLE
void * ___brk_addr = 0;
#endif
