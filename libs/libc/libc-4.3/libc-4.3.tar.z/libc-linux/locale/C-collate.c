#include <ansidecl.h>
#include <localeinfo.h>
#include <stddef.h>


CONST struct collate_info __collate_C = { 0, NULL, NULL, NULL };
CONST struct collate_info *_collate_info = &__collate_C;
