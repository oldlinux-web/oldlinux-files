#include <stdio.h>

main ()
{
  printf ("%5.2f\n", 10.0);
  printf ("%6.2f\n", 10.0);
  printf ("%5.2f\n", 11.0);
  printf ("%6.2f\n", 11.0);
  printf ("%5.2f\n", - 10.0);
  printf ("%6.2f\n", - 10.0);
}
