#include "stdio.h"
#include "libioP.h"

void
rewind(fp)
     _IO_FILE* fp;
{
  CHECK_FILE(fp, );
#ifdef _LIBPTHREAD
  flockfile (fp);
#endif
  _IO_rewind(fp);
#ifdef _LIBPTHREAD
  funlockfile (fp);
#endif
}

#ifndef _LIBPTHREAD
#ifdef __ELF__
#pragma weak rewind
#endif
#endif
