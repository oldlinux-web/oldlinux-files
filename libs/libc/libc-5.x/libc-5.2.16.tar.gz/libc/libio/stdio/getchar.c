#include "libioP.h"
#include "stdio.h"

#undef getchar

int
getchar ()
{
#ifdef _LIBPTHREAD
  int ret;
  flockfile (stdin);
  ret = _IO_getc(stdin);
  funlockfile (stdin);
  return ret;
#else
  return _IO_getc (stdin);
#endif
}

#ifndef _LIBPTHREAD
#ifdef __ELF__
#pragma weak getchar
#endif
#endif
