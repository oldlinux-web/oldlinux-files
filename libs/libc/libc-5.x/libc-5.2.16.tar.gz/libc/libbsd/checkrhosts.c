

/* This is not functional.  Oh well. */
int _check_rhosts_file;
