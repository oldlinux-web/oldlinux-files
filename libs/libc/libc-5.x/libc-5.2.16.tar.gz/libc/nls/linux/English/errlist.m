$set 1 #ErrorList

$ #0 Original Message:(Unknown error)
# Unknown error

$ #1 Original Message:(Operation not permitted)
# Operation not permitted

$ #2 Original Message:(No such file or directory)
# No such file or directory

$ #3 Original Message:(No such process)
# No such process

$ #4 Original Message:(Interrupted system call)
# Interrupted system call

$ #5 Original Message:(I/O error)
# I/O error

$ #6 Original Message:(No such device or address)
# No such device or address

$ #7 Original Message:(Arg list too long)
# Arg list too long

$ #8 Original Message:(Exec format error)
# Exec format error

$ #9 Original Message:(Bad file number)
# Bad file number

$ #10 Original Message:(No child processes)
# No child processes

$ #11 Original Message:(Try again)
# Try again

$ #12 Original Message:(Out of memory)
# Out of memory

$ #13 Original Message:(Permission denied)
# Permission denied

$ #14 Original Message:(Bad address)
# Bad address

$ #15 Original Message:(Block device required)
# Block device required

$ #16 Original Message:(Device or resource busy)
# Device or resource busy

$ #17 Original Message:(File exists)
# File exists

$ #18 Original Message:(Cross-device link)
# Cross-device link

$ #19 Original Message:(No such device)
# No such device

$ #20 Original Message:(Not a directory)
# Not a directory

$ #21 Original Message:(Is a directory)
# Is a directory

$ #22 Original Message:(Invalid argument)
# Invalid argument

$ #23 Original Message:(File table overflow)
# File table overflow

$ #24 Original Message:(Too many open files)
# Too many open files

$ #25 Original Message:(Not a typewriter)
# Not a typewriter

$ #26 Original Message:(Text file busy)
# Text file busy

$ #27 Original Message:(File too large)
# File too large

$ #28 Original Message:(No space left on device)
# No space left on device

$ #29 Original Message:(Illegal seek)
# Illegal seek

$ #30 Original Message:(Read-only file system)
# Read-only file system

$ #31 Original Message:(Too many links)
# Too many links

$ #32 Original Message:(Broken pipe)
# Broken pipe

$ #33 Original Message:(Math argument out of domain of func)
# Math argument out of domain of func

$ #34 Original Message:(Math result not representable)
# Math result not representable

$ #35 Original Message:(Resource deadlock would occur)
# Resource deadlock would occur

$ #36 Original Message:(File name too long)
# File name too long

$ #37 Original Message:(No record locks available)
# No record locks available

$ #38 Original Message:(Function not implemented)
# Function not implemented

$ #39 Original Message:(Directory not empty)
# Directory not empty

$ #40 Original Message:(Too many symbolic links encountered)
# Too many symbolic links encountered

$ #41 Original Message:(Operation would block)
# Operation would block

$ #42 Original Message:(No message of desired type)
# No message of desired type

$ #43 Original Message:(Identifier removed)
# Identifier removed

$ #44 Original Message:(Channel number out of range)
# Channel number out of range

$ #45 Original Message:(Level 2 not synchronized)
# Level 2 not synchronized

$ #46 Original Message:(Level 3 halted)
# Level 3 halted

$ #47 Original Message:(Level 3 reset)
# Level 3 reset

$ #48 Original Message:(Link number out of range)
# Link number out of range

$ #49 Original Message:(Protocol driver not attached)
# Protocol driver not attached

$ #50 Original Message:(No CSI structure available)
# No CSI structure available

$ #51 Original Message:(Level 2 halted)
# Level 2 halted

$ #52 Original Message:(Invalid exchange)
# Invalid exchange

$ #53 Original Message:(Invalid request descriptor)
# Invalid request descriptor

$ #54 Original Message:(Exchange full)
# Exchange full

$ #55 Original Message:(No anode)
# No anode

$ #56 Original Message:(Invalid request code)
# Invalid request code

$ #57 Original Message:(Invalid slot)
# Invalid slot

$ #58 Original Message:(File locking deadlock error)
# File locking deadlock error

$ #59 Original Message:(Bad font file format)
# Bad font file format

$ #60 Original Message:(Device not a stream)
# Device not a stream

$ #61 Original Message:(No data available)
# No data available

$ #62 Original Message:(Timer expired)
# Timer expired

$ #63 Original Message:(Out of streams resources)
# Out of streams resources

$ #64 Original Message:(Machine is not on the network)
# Machine is not on the network

$ #65 Original Message:(Package not installed)
# Package not installed

$ #66 Original Message:(Object is remote)
# Object is remote

$ #67 Original Message:(Link has been severed)
# Link has been severed

$ #68 Original Message:(Advertise error)
# Advertise error

$ #69 Original Message:(Srmount error)
# Srmount error

$ #70 Original Message:(Communication error on send)
# Communication error on send

$ #71 Original Message:(Protocol error)
# Protocol error

$ #72 Original Message:(Multihop attempted)
# Multihop attempted

$ #73 Original Message:(RFS specific error)
# RFS specific error

$ #74 Original Message:(Not a data message)
# Not a data message

$ #75 Original Message:(Value too large for defined data type)
# Value too large for defined data type

$ #76 Original Message:(Name not unique on network)
# Name not unique on network

$ #77 Original Message:(File descriptor in bad state)
# File descriptor in bad state

$ #78 Original Message:(Remote address changed)
# Remote address changed

$ #79 Original Message:(Can not access a needed shared library)
# Can not access a needed shared library

$ #80 Original Message:(Accessing a corrupted shared library)
# Accessing a corrupted shared library

$ #81 Original Message:(.lib section in a.out corrupted)
# .lib section in a.out corrupted

$ #82 Original Message:(Attempting to link in too many shared libraries)
# Attempting to link in too many shared libraries

$ #83 Original Message:(Cannot exec a shared library directly)
# Cannot exec a shared library directly

$ #84 Original Message:(Illegal byte sequence)
# Illegal byte sequence

$ #85 Original Message:(Interrupted system call should be restarted)
# Interrupted system call should be restarted

$ #86 Original Message:(Streams pipe error)
# Streams pipe error

$ #87 Original Message:(Too many users)
# Too many users

$ #88 Original Message:(Socket operation on non-socket)
# Socket operation on non-socket

$ #89 Original Message:(Destination address required)
# Destination address required

$ #90 Original Message:(Message too long)
# Message too long

$ #91 Original Message:(Protocol wrong type for socket)
# Protocol wrong type for socket

$ #92 Original Message:(Protocol not available)
# Protocol not available

$ #93 Original Message:(Protocol not supported)
# Protocol not supported

$ #94 Original Message:(Socket type not supported)
# Socket type not supported

$ #95 Original Message:(Operation not supported on transport endpoint)
# Operation not supported on transport endpoint

$ #96 Original Message:(Protocol family not supported)
# Protocol family not supported

$ #97 Original Message:(Address family not supported by protocol)
# Address family not supported by protocol

$ #98 Original Message:(Address already in use)
# Address already in use

$ #99 Original Message:(Cannot assign requested address)
# Cannot assign requested address

$ #100 Original Message:(Network is down)
# Network is down

$ #101 Original Message:(Network is unreachable)
# Network is unreachable

$ #102 Original Message:(Network dropped connection because of reset)
# Network dropped connection because of reset

$ #103 Original Message:(Software caused connection abort)
# Software caused connection abort

$ #104 Original Message:(Connection reset by peer)
# Connection reset by peer

$ #105 Original Message:(No buffer space available)
# No buffer space available

$ #106 Original Message:(Transport endpoint is already connected)
# Transport endpoint is already connected

$ #107 Original Message:(Transport endpoint is not connected)
# Transport endpoint is not connected

$ #108 Original Message:(Cannot send after transport endpoint shutdown)
# Cannot send after transport endpoint shutdown

$ #109 Original Message:(Too many references: cannot splice)
# Too many references: cannot splice

$ #110 Original Message:(Connection timed out)
# Connection timed out

$ #111 Original Message:(Connection refused)
# Connection refused

$ #112 Original Message:(Host is down)
# Host is down

$ #113 Original Message:(No route to host)
# No route to host

$ #114 Original Message:(Operation already in progress)
# Operation already in progress

$ #115 Original Message:(Operation now in progress)
# Operation now in progress

$ #116 Original Message:(Stale NFS file handle)
# Stale NFS file handle

$ #117 Original Message:(Structure needs cleaning)
# Structure needs cleaning

$ #118 Original Message:(Not a XENIX named type file)
# Not a XENIX named type file

$ #119 Original Message:(No XENIX semaphores available)
# No XENIX semaphores available

$ #120 Original Message:(Is a named type file)
# Is a named type file

$ #121 Original Message:(Remote I/O error)
# Remote I/O error
