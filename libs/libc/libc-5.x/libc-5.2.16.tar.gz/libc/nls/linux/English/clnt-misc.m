$set 9 #ClntMisc

$ #Errno Original Message:(; errno = %s)
# ; errno = %s

$ #LowHigh Original Message:(; low version = %lu, high version = %lu)
# ; low version = %lu, high version = %lu)

$ #Why Original Message:(; why = )
# ; why = 

$ #UnknownAuth Original Message:((unknown authentication error - %d))
# (unknown authentication error - %d)
