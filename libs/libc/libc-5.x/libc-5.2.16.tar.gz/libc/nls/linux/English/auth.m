$set 7 #AuthList

$ #1 Original Message:(Authentication OK)
# Authentication OK

$ #2 Original Message:(Invalid client credential)
# Invalid client credential

$ #3 Original Message:(Server rejected credential)
# Server rejected credential

$ #4 Original Message:(Invalid client verifier)
# Invalid client verifier

$ #5 Original Message:(Server rejected verifier)
# Server rejected verifier

$ #6 Original Message:(Client credential too weak)
# Client credential too weak

$ #7 Original Message:(Invalid server verifier)
# Invalid server verifier

$ #8 Original Message:(Failed (unspecified error))
# Failed (unspecified error)
