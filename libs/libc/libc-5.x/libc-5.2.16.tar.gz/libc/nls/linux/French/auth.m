$set 7 #AuthList

$ #1 Original Message:(Authentication OK)
# Authentication r�ussie

$ #2 Original Message:(Invalid client credential)
# L'identit� du client est inconnue

$ #3 Original Message:(Server rejected credential)
# Le serveur a rejet� l'identit�

$ #4 Original Message:(Invalid client verifier)
# Le v�rificateur du client est invalide

$ #5 Original Message:(Server rejected verifier)
# Le serveur a rejet� le v�rificateur

$ #6 Original Message:(Client credential too weak)
# L'identit� du client est trop faible

$ #7 Original Message:(Invalid server verifier)
# Le v�rificateur du serveur est invalide

$ #8 Original Message:(Failed (unspecified error))
# Echec (erreur non sp�cifi�e)
