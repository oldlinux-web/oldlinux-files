$set 3  #SignalList

$ #0 Original Message:(Unknown signal)
# Signal inconnu

$ #1 Original Message:(Hangup)
# Raccrochage

$ #2 Original Message:(Interrupt)
# Interruption

$ #3 Original Message:(Quit)
# Sortie

$ #4 Original Message:(Illegal instruction)
# Instruction ill�gale

$ #5 Original Message:(Trace/breakpoint trap)
# Trace/Point d'arr�t

$ #6 Original Message:(IOT trap/Abort)
# Pi�ge IOT ou abandon

$ #7 Original Message:(Unused signal)
# Signal non utilis�

$ #8 Original Message:(Floating point exception)
# Exception num�rique

$ #9 Original Message:(Killed)
# Tu�

$ #10 Original Message:(User defined signal 1)
# Signal utilisateur 1

$ #11 Original Message:(Segmentation fault)
# Faute de segmentation

$ #12 Original Message:(User defined signal 2)
# Signal utilisateur 2

$ #13 Original Message:(Broken pipe)
# Tuyau rompu

$ #14 Original Message:(Alarm clock)
# Alarme

$ #15 Original Message:(Terminated)
# Termin�

$ #16 Original Message:(Stack fault)
# Faute de la pile

$ #17 Original Message:(Child exited)
# Un enfant a termin�

$ #18 Original Message:(Continued)
# Continue

$ #19 Original Message:(Stopped (signal))
# Stopp� (signal)

$ #20 Original Message:(Stopped)
# Stopp�

$ #21 Original Message:(Stopped (tty input))
# Stopp� (entr�e sur terminal)

$ #22 Original Message:(Stopped (tty output))
# Stopp� (sortie sur le terminal)

$ #23 Original Message:(Urgent condition)
# Condition urgent

$ #24 Original Message:(CPU time limit exceeded)
# La limite du temps processeur a �t� d�pass�e

$ #25 Original Message:(File size limit exceeded)
# La limite de taille des fichiers a �t� d�pass�e

$ #26 Original Message:(Virtual time alarm)
# Alarme du temps virtuel

$ #27 Original Message:(Profile signal)
# Signal de profil

$ #28 Original Message:(Window size changed)
# La taille de la fen�tre a chang�

$ #29 Original Message:(Possible I/O)
# E/S possible

$ #30 Original Message:(Unused signal)
# Signal non utilis�

$ #31 Original Message:(Unused signal)
# Signal non utilis�
