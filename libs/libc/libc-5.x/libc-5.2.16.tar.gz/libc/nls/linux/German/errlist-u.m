$set 2 #UnknownError

$ #1 Original Message:(Unknown error 000000000000000000000)
# unbekannter Fehler 000000000000000000000

$ #2 Original Message:(Unknown error %d)
# unbekannter Fehler %d
