
/* Here we define the magic numbers that this dynamic loader should accept */

#define MAGIC1 EM_386
#define MAGIC2 EM_486
/* Used for error messages */
#define ELF_TARGET "386/486"
