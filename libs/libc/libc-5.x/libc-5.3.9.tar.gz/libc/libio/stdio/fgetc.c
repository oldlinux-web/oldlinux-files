#include "libioP.h"
#include "stdio.h"

int
fgetc(fp)
     FILE *fp;
{
#ifdef _LIBPTHREAD
  int ret;
  CHECK_FILE(fp, EOF);
  flockfile (fp);
  ret = _IO_getc(fp);
  funlockfile (fp);
  return ret;
#else
  CHECK_FILE(fp, EOF);
  return _IO_getc(fp);
#endif
}

#ifndef _LIBPTHREAD
#ifdef __ELF__
#pragma weak fgetc
#endif
#endif
