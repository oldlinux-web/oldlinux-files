#include "libioP.h"
#include "stdio.h"

#undef putc

int
putc(c, stream)
     int c;
     FILE *stream;
{
#ifdef _LIBPTHREAD
  int ret;
  flockfile (stream);
  ret = _IO_putc(c, stream);
  funlockfile (stream);
  return ret;
#else
  return _IO_putc(c, stream);
#endif
}

#ifndef _LIBPTHREAD
#ifdef __ELF__
#pragma weak putc
#endif
#endif
