$set 5 #HerrorList

$ #1 Original Message:(Error 0)
# Error 0

$ #2 Original Message:(Unknown host)
# Unknown host

$ #3 Original Message:(Host name lookup failure)
# Host name lookup failure

$ #4 Original Message:(Unknown server error)
# Unknown server error

$ #5 Original Message:(No address associated with name)
# No address associated with name

