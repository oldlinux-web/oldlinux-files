$set 6 #Getopt

$ #Ambiguous Original Message:(%s: option `%s' is ambiguous\n)
# %s: l'option `%s' est ambigue\n

$ #NoArgumentsAllowed1 Original Message:(%s: option `--%s' doesn't allow an argument\n)
# %s: l'option `--%s' n'accepte pas d'arguments\n

$ #NoArgumentsAllowed2 Original Message:(%s: option `%c%s' doesn't allow an argument\n)
# %s: l'option `%c%s' n'accepte pas d'arguments\n

$ #RequiresArgument1 Original Message:(%s: option `%s' requires an argument\n)
# %s: l'option `%s' demande un argument\n

$ #RequiresArgument2 Original Message:(%s: option requires an argument -- %c\n)
# %s: l'option demande un argument -- %c\n

$ #Unrecognized1 Original Message:(%s: unrecognized option `--%s'\n)
# %s: option non reconnue `--%s'\n

$ #Unrecognized2 Original Message:(%s: unrecognized option `%c%s'\n)
# %s: option non reconnue `%c%s'\n

$ #Illegal Original Message:(%s: illegal option -- %c\n)
# %s: option ill�gale -- %c\n
