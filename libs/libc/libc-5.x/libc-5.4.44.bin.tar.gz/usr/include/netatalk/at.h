#ifndef __NETATALK_AT_H
#define __NETATALK_AT_H 1

#include <asm/types.h>
#include <sys/socket.h>
#include <linux/atalk.h>

#endif
