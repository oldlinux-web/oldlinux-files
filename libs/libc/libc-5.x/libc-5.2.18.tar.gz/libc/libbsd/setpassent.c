/* setpassent.c - vacuous setpassent for BSD - rick sladkey */

void setpassent(int i)
{
}
