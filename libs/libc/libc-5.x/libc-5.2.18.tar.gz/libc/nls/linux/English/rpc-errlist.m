$set 8 #RpcErrList

$ #1 Original Message:(RPC: Success)
# RPC: Success

$ #2 Original Message:(RPC: Can't encode arguments)
# RPC: Can't encode arguments

$ #3 Original Message:(RPC: Can't decode result)
# RPC: Can't decode result

$ #4 Original Message:(RPC: Unable to send)
# RPC: Unable to send

$ #5 Original Message:(RPC: Unable to receive)
# RPC: Unable to receive

$ #6 Original Message:(RPC: Timed out)
# RPC: Timed out

$ #7 Original Message:(RPC: Incompatible versions of RPC)
# RPC: Incompatible versions of RPC

$ #8 Original Message:(RPC: Authentication error)
# RPC: Authentication error

$ #9 Original Message:(RPC: Program unavailable)
# RPC: Program unavailable

$ #10 Original Message:(RPC: Program/version mismatch)
# RPC: Program/version mismatch

$ #11 Original Message:(RPC: Procedure unavailable)
# RPC: Procedure unavailable

$ #12 Original Message:(RPC: Server can't decode arguments)
# RPC: Server can't decode arguments

$ #13 Original Message:(RPC: Remote system error)
# RPC: Remote system error

$ #14 Original Message:(RPC: Unknown host)
# RPC: Unknown host

$ #15 Original Message:(RPC: Port mapper failure)
# RPC: Port mapper failure

$ #16 Original Message:(RPC: Program not registered)
# RPC: Program not registered

$ #17 Original Message:(RPC: Failed (unspecified error))
# RPC: Failed (unspecified error)

$ #18 Original Message:(RPC: Unknown protocol)
# RPC: Unknown protocol

$ #Unknown Original Message:(RPC: (unknown error code))
# RPC: (unknown error code)
