$set 11 #NetMisc

$ #AllPortsInUse Original Message:(All ports in use)
# Tous les ports sont utilis�s

$ #ConnectTo Original Message:(connect to address)
# connect� � l'adresse

$ #Trying Original Message:(Trying %s...\n)
# Essaye %s...\n

$ #SettingUpStderr Original Message:(write: setting up stderr)
# �criture: installation de stderr

$ #Accept Original Message:(accept)
# accept�

$ #Getsockname Original Message:(getsockname)
# getsockname

$ #ProtocolFailure Original Message:(socket: protocol failure in circuit setup.)
# socket: �chec du protocole lors de l'installation du circuit

$ #RcmdSocket Original Message:(rcmd: socket)
# rcmd: socket

$ #RexecSocket Original Message:(rexec: socket)
# rexec: socket

$ #NetrcWrongPasswordMode Original Message:(Error - .netrc file not correct mode.\nRemove password or correct mode.)
# Error - Fichier .netrc dans un mode incorrect.\nSupprimez le mot de passe ou corrigez le mode.

$ #UnknownNetrcOption Original Message:(Unknown .netrc option)
# Option dans .netrc inconnue

$ #ResolvIncorrectFormat Original Message:(resolv+: %s: \"%s\" command incorrectly formatted.\n)
# X-resolv+: %s: commande "%s" incorrectement format�e.\n

$ #ResolvInvalid Original Message:(resolv+: \"%s\" is an invalid keyword\n)
# X-resolv+: "%s" est un mot cl� invalide\n

$ #ResolvValid Original Message:(resolv+: valid keywords are: %s, %s and %s\n)
# X-resolv+: Les mots cl�s valides sont : %s, %s et %s\n

$ #Unrecognized Original Message:(resolv+: search order not specified or unrecognized keyword, host resolution will fail.\n)
# X-resolv+: L'odre de recherche n'est pas sp�cifi� ou mot cl� non reconnu, la r�solution de l'h�te va �chouer.\n

$ #PossibleSpoof Original Message:(gethostbyaddr: %s != %u.%u.%u.%u, possible spoof attempt)
# gethostbyaddr: %s != %u.%u.%u.%u, tentative possible de plaisanterie
