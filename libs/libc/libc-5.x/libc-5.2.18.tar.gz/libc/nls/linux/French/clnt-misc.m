$set 9 #ClntMisc

$ #Errno Original Message:(; errno = %s)
# ; errno = %s

$ #LowHigh Original Message:(; low version = %lu, high version = %lu)
# ; version basse = %lu, version haute = %lu)

$ #Why Original Message:(; why = )
# ; pourquoi = 

$ #UnknownAuth Original Message:((unknown authentication error - %d))
# (erreur d'authentification inconnue - %d)
