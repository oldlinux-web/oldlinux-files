#include "libioP.h"
#include "stdio.h"
#undef putchar

int
putchar(c)
     int c;
{
#ifdef _LIBPTHREAD
  int ret;
  flockfile (stdout);
  ret = _IO_putc(c, stdout);
  funlockfile (stdout);
  return ret;
#else
  return _IO_putc(c, stdout);
#endif
}

#ifndef _LIBPTHREAD
#ifdef __ELF__
#pragma weak  putchar
#endif
#endif
