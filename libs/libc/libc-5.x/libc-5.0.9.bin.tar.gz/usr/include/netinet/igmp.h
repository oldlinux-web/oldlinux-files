/*
 *	There is more to this for better BSD compatibility than we do, but
 *	its the start!
 *
 *	The constants etc are from smilie@poodle.mpx.com.au (Anthony Rumble)
 */

#ifndef _NETINET_IGMP_H
#define _NETINET_IGMP_H
#include <linux/igmp.h>

struct igmp {
        unsigned char  igmp_type;      /* version & type of IGMP message  */
        unsigned char  igmp_code;      /* unused, should be zero          */
        unsigned short igmp_cksum;     /* IP-style checksum               */
        struct in_addr igmp_group;     /* group address being reported    */
};                                     /*  (zero for queries)             */

#define IGMP_MINLEN                  8

#define IGMP_DVMRP                     0x13    /* for experimental multicast */+                                               /*  routing protocol */
#define IGMP_MAX_HOST_REPORT_DELAY     10      /* max delay for response to */
                                               /*  query (in seconds) */
#endif 