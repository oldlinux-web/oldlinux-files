#undef __SVR4_ABI_L1__
#include <huge_val.h>

const unsigned char __huge_val [8] = __HUGE_VAL_bytes;
