$set 9 #ClntMisc

$ #Errno Original Message:(; errno = %s)
# ; Errno = %s

$ #LowHigh Original Message:(; low version = %lu, high version = %lu)
# ; niedrige Version = %lu, hohe Version = %lu)

$ #Why Original Message:(; why = )
# ; warum = 

$ #UnknownAuth Original Message:((unknown authentication error - %d))
# (unbekannter Authentifizierungsfehler - %d)
