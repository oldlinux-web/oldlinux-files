$ #0 Original Message:(gencat catfile msgfile...)
# gencat catfile msgfile...
$ #1 Original Message:(Use: gencat [-new] [-or] [-lang C|C++|ANSIC] catfile msgfile [-h <header-file>]...\n)
# Usar: gencat [-new] [-or] [-lang C|C++|ANSIC] catfile msgfile [-h <header-file>]...\n
$ #2 Original Message:(-lang)
# -lang
$ #3 Original Message:(C)
# C
$ #4 Original Message:(C++)
# C++
$ #5 Original Message:(ANSIC)
# ANSIC
$ #6 Original Message:(gencat: Unrecognized language: %s\n)
# gencat: Unrecognized language: %s\n
$ #7 Original Message:(-h)
# -h
$ #8 Original Message:(gencat: Can't write to a header before reading something.\n)
# gencat: Can't write to a header before reading something.\n
$ #9 Original Message:(-new)
# -new
$ #10 Original Message:(gencat: You must specify -new before the catalog file name\n)
# gencat: You must specify -new before the catalog file name\n
$ #11 Original Message:(-or)
# -or
$ #12 Original Message:(gencat: Unable to create a new %s.\n)
# gencat: Unable to create a new %s.\n
$ #13 Original Message:(gencat: Unable to create %s.\n)
# gencat: Unable to create %s.\n
$ #14 Original Message:(gencat: Unable to truncate %s.\n)
# gencat: Unable to truncate %s.\n
$ #15 Original Message:(gencat: Unable to read %s\n)
# gencat: Unable to read %s\n
$ #16 Original Message:(gencat: Unable to create header file %s.\n)
# gencat: Unable to create header file %s.\n
$ #17 Original Message:(/tmp/gencat.%d)
# /tmp/gencat.%d
$ #18 Original Message:(gencat: Unable to open temporary file: %s\n)
# gencat: Unable to open temporary file: %s\n
$ #19 Original Message:(gencat: Unable to read header file: %s\n)
# gencat: Unable to read header file: %s\n
$ #20 Original Message:(gencat: Unable to seek in tempfile: %s\n)
# gencat: Unable to seek in tempfile: %s\n
$ #21 Original Message:(gencat: Unable to seek in tempfile: %s\n)
# gencat: Unable to seek in tempfile: %s\n
$ #22 Original Message:(gencat: Unable to truncate header file: %s\n)
# gencat: Unable to truncate header file: %s\n
$ #23 Original Message:(gencat: Error writing to header file: %s\n)
# gencat: Error writing to header file: %s\n
