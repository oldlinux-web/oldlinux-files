$set 3  #SignalList

$ #0 Original Message:(Unknown signal)
# Se�al desconocida

$ #1 Original Message:(Hangup)
# Se�al de Hangup

$ #2 Original Message:(Interrupt)
# Interrupci�n

$ #3 Original Message:(Quit)
# Se�al de abandonar

$ #4 Original Message:(Illegal instruction)
# Instrucci�n ilegal

$ #5 Original Message:(Trace/breakpoint trap)
# Trace/breakpoint trap

$ #6 Original Message:(IOT trap/Abort)
# IOT trap/Abort

$ #7 Original Message:(Bus Error)
# Error de bus

$ #8 Original Message:(Floating point exception)
# Excepci�n de coma flotante

$ #9 Original Message:(Killed)
# Killed

$ #10 Original Message:(User defined signal 1)
# Se�al 1 definida por el usuario

$ #11 Original Message:(Segmentation fault)
# Fallo de segmentaci�n

$ #12 Original Message:(User defined signal 2)
# Se�al 2 definida por el usuario

$ #13 Original Message:(Broken pipe)
# Tuber�a (pipe) rota

$ #14 Original Message:(Alarm clock)
# Alarm clock

$ #15 Original Message:(Terminated)
# Se�al de acabado

$ #16 Original Message:(Stack fault)
# Fallo de pila

$ #17 Original Message:(Child exited)
# El hijo ha acabado

$ #18 Original Message:(Continued)
# Continued

$ #19 Original Message:(Stopped (signal))
# Parado (se�al)

$ #20 Original Message:(Stopped)
# Parado 

$ #21 Original Message:(Stopped (tty input))
# Parado (entrada por tty)

$ #22 Original Message:(Stopped (tty output))
# Parado (salida por tty)

$ #23 Original Message:(Urgent condition)
# Condici�n urgente

$ #24 Original Message:(CPU time limit exceeded)
# Tiempo permitido de CPU superado

$ #25 Original Message:(File size limit exceeded)
# L�mite de tama�o de fichero superado

$ #26 Original Message:(Virtual time alarm)
# Alarma de tiempo virtual

$ #27 Original Message:(Profile signal)
# Profile signal

$ #28 Original Message:(Window size changed)
# Tama�o de ventana cambiado

$ #29 Original Message:(Possible I/O)
# Posible entrada/salida

$ #30 Original Message:(Power failure)
# Fallo de alimentaci�n

$ #31 Original Message:(Unused signal)
# Se�al no usada
