$set 9 #ClntMisc

$ #Errno Original Message:(; errno = %s)
# ; errno = %s

$ #LowHigh Original Message:(; low version = %lu, high version = %lu)
# ; version inferior= %lu, version superior= %lu)

$ #Why Original Message:(; why = )
# ; por qu� = 

$ #UnknownAuth Original Message:((unknown authentication error - %d))
# (error de autenticaci�n desconocido - %d)
