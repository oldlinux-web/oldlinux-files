$set 7 #AuthList

$ #1 Original Message:(Authentication OK)
# Authentifizierung erfolgreich

$ #2 Original Message:(Invalid client credential)
# Client Best�tigung ung�ltig

$ #3 Original Message:(Server rejected credential)
# Server: Best�tigung zur�ckgewiesen

$ #4 Original Message:(Invalid client verifier)
# Client �berpr�fung ung�ltig

$ #5 Original Message:(Server rejected verifier)
# Server: �berpr�fung zur�ckgewiesen

$ #6 Original Message:(Client credential too weak)
# Client Best�tigung zu unsicher

$ #7 Original Message:(Invalid server verifier)
# Server �berpr�fung ung�ltig

$ #8 Original Message:(Failed (unspecified error))
# Fehlgeschlagen (nicht spezifizierter Fehler)

