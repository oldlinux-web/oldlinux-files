$set 9 #ClntMisc

$ #Errno Original Message:(; errno = %s)
# ; fejlnummer = %s

$ #LowHigh Original Message:(; low version = %lu, high version = %lu)
# ; subversionsnummer = %lu, hovedversionsnummer = %lu)

$ #Why Original Message:(; why = )
# ; hvorfor = 

$ #UnknownAuth Original Message:((unknown authentication error - %d))
# (ukendt autentifikationsfejl - %d)
