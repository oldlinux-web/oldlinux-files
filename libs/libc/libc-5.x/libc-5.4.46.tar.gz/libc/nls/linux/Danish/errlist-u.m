$set 2 #UnknownError

$ #1 Original Message:(Unknown error 000000000000000000000)
# Ukendt fejl 000000000000000000000

$ #2 Original Message:(Unknown error %d)
# Ukendt fejl %d
