$set 1 #ErrorList

$ #0 Original Message:(Unknown error)
# ukendt fejl

$ #1 Original Message:(Operation not permitted)
# operation ikke tilladt

$ #2 Original Message:(No such file or directory)
# fil eller katalog findes ikke

$ #3 Original Message:(No such process)
# proces findes ikke

$ #4 Original Message:(Interrupted system call)
# afbrudt systemkald

$ #5 Original Message:(I/O error)
# l�se/skrive fejl

$ #6 Original Message:(No such device or address)
# enhed eller adresse findes ikke 

$ #7 Original Message:(Arg list too long)
# parameterliste er for lang

$ #8 Original Message:(Exec format error)
# udf�rbart format er fejlbeh�ftet

$ #9 Original Message:(Bad file number)
# ubrugeligt filnummer

$ #10 Original Message:(No child processes)
# ingen barneprocesor

$ #11 Original Message:(Try again)
# pr�v igen...

$ #12 Original Message:(Out of memory)
# utilstr�kkelig hukommelsesplads

$ #13 Original Message:(Permission denied)
# adgang n�gtet 

$ #14 Original Message:(Bad address)
# ugyldig adresse

$ #15 Original Message:(Block device required)
# blok orienteret enhed kr�ves

$ #16 Original Message:(Device or resource busy)
# enhed eller resourse er optaget

$ #17 Original Message:(File exists)
# fil eksisterer

$ #18 Original Message:(Cross-device link)
# enhedsoverskridende links er ikke tilladt

$ #19 Original Message:(No such device)
# enhed findes ikke

$ #20 Original Message:(Not a directory)
# det er ikke et katalog

$ #21 Original Message:(Is a directory)
# det er et katalog

$ #22 Original Message:(Invalid argument)
# ugyldig parameter

$ #23 Original Message:(File table overflow)
# filtabel er fyldt

$ #24 Original Message:(Too many open files)
# for mange �bne filer

$ #25 Original Message:(Not a typewriter)
# enheden er ikke en terminal

$ #26 Original Message:(Text file busy)
# programmet bliver �ndret eller udf�rt

$ #27 Original Message:(File too large)
# fil er for stor

$ #28 Original Message:(No space left on device)
# ingen lagerplads tilbage p� enheden

$ #29 Original Message:(Illegal seek)
# ugyldig s�gning

$ #30 Original Message:(Read-only file system)
# filsystemet kan kun l�ses

$ #31 Original Message:(Too many links)
# for mange links

$ #32 Original Message:(Broken pipe)
# dataoverf�rsel afbrudt

$ #33 Original Message:(Math argument out of domain of func)
# argument til matematisk funktion er uden for definitionsomr�de

$ #34 Original Message:(Math result not representable)
# resultat af matematisk funktion er ikke representativ

$ #35 Original Message:(Resource deadlock would occur)
# resurce vil g� i bagl�s

$ #36 Original Message:(File name too long)
# filnavn er for langt

$ #37 Original Message:(No record locks available)
# ingen l�s for datapost tilg�ngelig

$ #38 Original Message:(Function not implemented)
# funktion er ikke implementeret

$ #39 Original Message:(Directory not empty)
# katalog er ikke tomt

$ #40 Original Message:(Too many symbolic links encountered)
# for mange symbolske links fundet

$ #41 Original Message:(Operation would block)
# operation kan blokere 

$ #42 Original Message:(No message of desired type)
# meddelelse af �nskede type findes ikke

$ #43 Original Message:(Identifier removed)
# kendetegn (en semafor) er fjernet

$ #44 Original Message:(Channel number out of range)
# kanalnummer er ude af v�rdim�ngden

$ #45 Original Message:(Level 2 not synchronized)
# niveau 2 er ikke synkroniseret

$ #46 Original Message:(Level 3 halted)
# niveau 3 stoppet

$ #47 Original Message:(Level 3 reset)
# niveau 3 nulstillet

$ #48 Original Message:(Link number out of range)
# link nummer er ude af v�rdim�ngden

$ #49 Original Message:(Protocol driver not attached)
# protokol driver er ikke tilknyttet

$ #50 Original Message:(No CSI structure available)
# ingen CSI struktur tilg�ngelig

$ #51 Original Message:(Level 2 halted)
# niveau 2 stoppet

$ #52 Original Message:(Invalid exchange)
# ugyldig uveksling

$ #53 Original Message:(Invalid request descriptor)
# Ugyldig anmodningsbeskrivelse

$ #54 Original Message:(Exchange full)
# udveksling overfyldt

$ #55 Original Message:(No anode)
# ingen anode

$ #56 Original Message:(Invalid request code)
# Ugyldig anmodningskode

$ #57 Original Message:(Invalid slot)
# ugyldigt slot

$ #58 Original Message:(File locking deadlock error)
# Fejl: fill�s sidder fast

$ #59 Original Message:(Bad font file format)
# Ugyldig fontfil format

$ #60 Original Message:(Device not a stream)
# enhed er ikke en stream

$ #61 Original Message:(No data available)
# Ingen data tilg�nglig

$ #62 Original Message:(Timer expired)
# timer er udl�bet 

$ #63 Original Message:(Out of streams resources)
# ingen streams til disposition

$ #64 Original Message:(Machine is not on the network)
# maskine er ikke tilsluttet netv�rket

$ #65 Original Message:(Package not installed)
# pakke er ikke installeret

$ #66 Original Message:(Object is remote)
# objekt er p� en fjern datamat

$ #67 Original Message:(Link has been severed)
# link er blevet afbrudt

$ #68 Original Message:(Advertise error)
# averteringsfejl

$ #69 Original Message:(Srmount error)
# Srmount fejl

$ #70 Original Message:(Communication error on send)
# kommunikationsfejl ved sending

$ #71 Original Message:(Protocol error)
# protokol fejl

$ #72 Original Message:(Multihop attempted)
# multihop fors�gt

$ #73 Original Message:(RFS specific error)
# RFS specifik fejl

$ #74 Original Message:(Not a data message)
# ingen data meddelse

$ #75 Original Message:(Value too large for defined data type)
# v�rdi er for stor til den definerede data type

$ #76 Original Message:(Name not unique on network)
# navn er ikke unikt p� netv�rket

$ #77 Original Message:(File descriptor in bad state)
# filtilgangsnummeret er i en ugyldig tilstand

$ #78 Original Message:(Remote address changed)
# fjern adresse er �ndret

$ #79 Original Message:(Can not access a needed shared library)
# ingen tilgang til n�dvendigt 'shared-library' 

$ #80 Original Message:(Accessing a corrupted shared library)
# tilgang til et defekt 'shared-library'

$ #81 Original Message:(.lib section in a.out corrupted)
# .lib sektionen i a.out defekt

$ #82 Original Message:(Attempting to link in too many shared libraries)
# fors�ger sammenk�dning af for mange 'shared-libraries'

$ #83 Original Message:(Cannot exec a shared library directly)
# kan ikke udf�re et 'shared-library' direkte

$ #84 Original Message:(Illegal byte sequence)
# ugyldig byte sekvens

$ #85 Original Message:(Interrupted system call should be restarted)
# afbrudt systemkald skal genstartes

$ #86 Original Message:(Streams pipe error)
# streams kanal fejl

$ #87 Original Message:(Too many users)
# for mange brugere

$ #88 Original Message:(Socket operation on non-socket)
# socket operation p� en ikke-socket

$ #89 Original Message:(Destination address required)
# m�ladresse n�dvendig

$ #90 Original Message:(Message too long)
# meddelse er for lang

$ #91 Original Message:(Protocol wrong type for socket)
# fejlagtig protokoltype til en socket

$ #92 Original Message:(Protocol not available)
# protokol er ikke tilg�ngelig

$ #93 Original Message:(Protocol not supported)
# protokol er ikke underst�ttet

$ #94 Original Message:(Socket type not supported)
# socket type er ikke underst�ttet

$ #95 Original Message:(Operation not supported on transport endpoint)
# operation er ikke underst�ttet p� transportendepunktet

$ #96 Original Message:(Protocol family not supported)
# protokol familie er ikke underst�ttet

$ #97 Original Message:(Address family not supported by protocol)
# adresse familie er ikke underst�ttet af protokol

$ #98 Original Message:(Address already in use)
# adresse er allerede i brug

$ #99 Original Message:(Cannot assign requested address)
# den �nskede addresse kan ikke benyttes

$ #100 Original Message:(Network is down)
# netv�rk er nede

$ #101 Original Message:(Network is unreachable)
# netv�rk kan ikke n�s

$ #102 Original Message:(Network dropped connection because of reset)
# netv�rk forbindelse afbrudt p� grund af nulstilling

$ #103 Original Message:(Software caused connection abort)
# software for�rsaget afbrydelse af forbindelse 

$ #104 Original Message:(Connection reset by peer)
# forbindelse nulstillet af komminikationspartner 
 
$ #105 Original Message:(No buffer space available)
# ingen buffer lager tilg�ngelig

$ #106 Original Message:(Transport endpoint is already connected)
# transportendepunket er allerede forbundet

$ #107 Original Message:(Transport endpoint is not connected)
# transportendepunktet er ikke forbundet 

$ #108 Original Message:(Cannot send after transport endpoint shutdown)
# kan ikke sende efter nedkobling af transportendepunktet

$ #109 Original Message:(Too many references: cannot splice)
# for mange referenser: kan ikke splejse

$ #110 Original Message:(Connection timed out)
# forbindelse afbrudt p� grund af tidsoverskridelse

$ #111 Original Message:(Connection refused)
# forbindelse n�gtet

$ #112 Original Message:(Host is down)
# datamat er nede

$ #113 Original Message:(No route to host)
# rute til datamat er ukendt

$ #114 Original Message:(Operation already in progress)
# operation er allerede i gang

$ #115 Original Message:(Operation now in progress)
# operation er nu i gang

$ #116 Original Message:(Stale NFS file handle)
# for�ldet NFS filtilgangsnummer

$ #117 Original Message:(Structure needs cleaning)
# struktur beh�ver reng�ring

$ #118 Original Message:(Not a XENIX named type file)
# ikke et filnavn af XENIX typen

$ #119 Original Message:(No XENIX semaphores available)
# ingen XENIX semafor tilg�ngelig

$ #120 Original Message:(Is a named type file)
# er en navngivet filtype 

$ #121 Original Message:(Remote I/O error)
# I/O fejl p� fjern datamat
