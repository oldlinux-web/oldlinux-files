$set 5 #HerrorList

$ #1 Original Message:(Error 0)
# Fejl 0

$ #2 Original Message:(Unknown host)
# Ukendt datamat

$ #3 Original Message:(Host name lookup failure)
# Fejl ved opslag af datamatnavn

$ #4 Original Message:(Unknown server error)
# Fejl: ukendt server

$ #5 Original Message:(No address associated with name)
# Ingen adresse associeret med navn er fundet

