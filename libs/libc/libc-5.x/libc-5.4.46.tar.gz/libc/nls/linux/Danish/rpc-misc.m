$set 10 #RpcMisc

$ #OutOfMemory Original Message:(out of memory)
# Utilstr�kkelig hukommelsesplads

$ #CannotRegister Original Message:(Cannot register service)
# Tjenesten kan ikke registreres

$ #FatalMarshall Original Message:(auth_none.c - Fatal marshalling problem)
# auth_none.c - fatalt opstillingsproblem

$ #FatalHeader Original Message:(clnt_raw.c - Fatal header serialization error.)
# clnt_raw.c - fatal header serialisationsfejl

$ #Hostname Original Message:(get_myaddress: gethostbyname)
# get_myaddress: gethostbyname

$ #Socket Original Message:(get_myaddress: socket)
# get_myaddress: socket

$ #Iface Original Message:(get_myaddress: ioctl (get interface configuration))
# get_myaddress: ioctl (henter gr�ndsefladekonfiguration)

$ #Ioctl Original Message:(get_myaddress: ioctl)
# get_myaddress: ioctl

$ #Getmaps Original Message:(pmap_getmaps rpc problem)
# pmap_getmaps rpc problem

$ #BConfig Original Message:(broadcast: ioctl (get interface configuration))
# udsendelse: ioctl (henter gr�ndsefladekonfiguration)

$ #BFlags Original Message:(broadcast: ioctl (get interface flags))
# udsendelse: ioctl (henter gr�ndseflade flag)

$ #CantCreateBSocket Original Message:(Cannot create socket for broadcast rpc)
# kan ikke skabe socket for udsendelse af rpc

$ #CantSetBOption Original Message:(Cannot set socket option SO_BROADCAST)
# kan ikke s�tte socket valgmulighed SO_BROADCAST

$ #CantSendBPacket Original Message:(Cannot send broadcast packet)
# kan ikke sende udsendelsespakke

$ #BSelectProblem Original Message:(Broadcast select problem)
# udsendelsesvalgproblem

$ #CantReceiveBReply Original Message:(Cannot receive reply to broadcast)
# kan ikke modtage svar p� udsendelse

$ #BDesProblem Original Message:(Broadcast deserialization problem)
# udsendelsesdeserialisationsproblem

$ #BadAuthLen Original Message:(bad auth_len gid %d str %d auth %d\n)
# ugyldig auth_len gid %d str %d auth %d\n

$ #SelectFailed Original Message:(svc_run: - select failed)
# svc_run: - udv�lgelse er sl�et fejl

$ #CantReassignProc Original Message:(can't reassign procedure number %d\n)
# kan ikke gentildele procedurenummer %d\n

$ #CantCreateServer Original Message:(couldn't create an rpc server)
# Kan ikke oprette en rpc server 

$ #CantRegisterProg Original Message:(couldn't register prog %d vers %d\n)
# kan ikke registere programm %d, version %d\n

$ #TroubleReplying Original Message:(trouble replying to prog %d\n)
# har vanskeligt ved at svare program %d

$ #NeverRegisteredProg Original Message:(never registered prog %d\n)
# program %d er aldrig registreret\n

$ #TcpSocketCreateProblem Original Message:(svc_tcp.c - tcp socket creation problem)
# svc_tcp.c - problem ved skabelse af tcp socket

$ #CantGetNameListen Original Message:(svctcp_.c - cannot getsockname or listen)
# svctcp_.c - getsockname eller listen er ikke mulig

$ #UdpSocketCreateProblem Original Message:(svcudp_create: socket creation problem)
# svcudp_create: problem ved skabelse af socket

$ #UdpCantGetName Original Message:(svcudp_create - cannot getsockname)
# svcudp_create - getsockname er ikke mulig

$ #CacheAlreadyEnabled Original Message:(enablecache: cache already enabled)
# enablecache: cache er allerede sl�et til 

$ #CantAllocateCache Original Message:(enablecache: could not allocate cache)
# enablecache: kan ikke allokere Cache 

$ #CantAllocateCacheData Original Message:(enablecache: could not allocate cache data)
# enablecache: kan ikke allokere Cache data 

$ #CantAllocateCacheFifo Original Message:(enablecache: could not allocate cache fifo)
# enablecache: kan ikke allokere FIFO buffer

$ #VictimNotFound Original Message:(cache_set: victim not found)
# cache_set: offer er ikke fundet

$ #VictimAllocFailed Original Message:(cache_set: victim alloc failed)
# cache_set: offer kan ikke allokeres

$ #CantAllocateRpcBuffer Original Message:(cache_set: could not allocate new rpc_buffer)
# cache_set: kan ikke allokere ny rpc_buffer 
