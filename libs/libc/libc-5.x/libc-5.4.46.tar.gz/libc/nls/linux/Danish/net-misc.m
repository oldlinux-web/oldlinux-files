$set 11 #NetMisc

$ #AllPortsInUse Original Message:(All ports in use)
# alle porte er optaget

$ #ConnectTo Original Message:(connect to address)
# forbindelse til addresse

$ #Trying Original Message:(Trying %s...\n)
# fors�ger %s...\n

$ #SettingUpStderr Original Message:(write: setting up stderr)
# Write: ops�tning af standardfejl

$ #Accept Original Message:(accept)
# accepteret

$ #Getsockname Original Message:(getsockname)
# getsockname

$ #ProtocolFailure Original Message:(socket: protocol failure in circuit setup.)
# Socket: protocol fejl i kredsl�bsops�tningen.

$ #RcmdSocket Original Message:(rcmd: socket)
# rcmd: socket

$ #RexecSocket Original Message:(rexec: socket)
# rexec: socket

$ #NetrcWrongPasswordMode Original Message:(Error - .netrc file not correct mode.\nRemove password or correct mode.)
# Fejl - .netrc-filen har ikke de rigtige tilgangsrettigheder.\nFjern kodeord eller koriger tilgangsrettigheder

$ #UnknownNetrcOption Original Message:(Unknown .netrc option)
# ukendt .netrc valgmulighed

$ #ResolvIncorrectFormat Original Message:(resolv+: %s: \"%s\" command incorrectly formatted.\n)
# resolv+: %s: "%s" kommando er forkert formateret.\n

$ #ResolvInvalid Original Message:(resolv+: \"%s\" is an invalid keyword\n)
# resolv+: "%s" er et ugyldigt n�gleord\n

$ #ResolvValid Original Message:(resolv+: valid keywords are: %s, %s and %s\n)
# resolv+: gyldige n�gleord er: %s, %s og %s\n

$ #Unrecognized Original Message:(resolv+: search order not specified or unrecognized keyword, host resolution will fail.\n)
# resolv+: s�georden ikke specificeret eller ukendt n�gleord,datamat opsporing vil sl� fejl.

$ #PossibleSpoof Original Message:(gethostbyaddr: %s != %u.%u.%u.%u, possible spoof attempt)
# gethostbyaddr: %s != %u.%u.%u.%u, muligvis fors�g p� snyderi 

$ #SelectSetup Original Message:(rcmd: select (setting up stderr): )
# rcmd: select (ops�tning af standardfejl):

$ #RcmdProtocolError Original Message:(select: protocol failure in circuit setup)
# select: protokol fejl i kredsl�bsinstillingen

$ #RhostLstat Original Message:(.rhosts lstat failed)
# .rhosts lstat er sl�et fejl

$ #RhostNotRegular Original Message:(.rhosts not regular file)
# .rhosts er ikke en regul�r fil

$ #BadRhostsOwner Original Message:(bad .rhosts owner)
# ugyldig .rhosts ejer

$ #RhostFstatFailed Original Message:(.rhosts fstat failed)
# .rhosts fstat er sl�et fejl

$ #RhostWritable Original Message:(.rhosts writeable by other than owner)
# .rhosts kan skrives af andre end ejeren

$ #Name Original Message:(Name)
# Navn

$ #Password Original Message:(Password)
# Kodeord

$ #AskedForGot Original Message:(gethostby*.getanswer: asked for \"%s\", got \"%s\")
# gethostby*.getanswer: eftersp�rger "%s", modtaget "%s"

$ #AskedForGotCNAME Original Message:(gethostby*.getanswer: asked for \"%s\", got CNAME for \"%s\")
# gethostby*.getanswer: eftersp�rger "%s", modtaget CNAME for "%s"

$ #AskedForType Original Message:(gethostby*.getanswer: asked for type %d(%s), got %d(%s))
# gethostby*.getanswer: eftersp�rger type for %d(%s), modtaget %d(%s)

