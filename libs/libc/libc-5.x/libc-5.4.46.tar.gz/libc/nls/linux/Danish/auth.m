$set 7 #AuthList

$ #1 Original Message:(Authentication OK)
# Autentifikation OK

$ #2 Original Message:(Invalid client credential)
# Ugyldig client akkreditiv

$ #3 Original Message:(Server rejected credential)
# Server afviser akkreditiv

$ #4 Original Message:(Invalid client verifier)
# Ugyldig client versificering

$ #5 Original Message:(Server rejected verifier)
# Server afviser versificering

$ #6 Original Message:(Client credential too weak)
# Client akkreditiv er for svagt

$ #7 Original Message:(Invalid server verifier)
# Ugyldig server versificering

$ #8 Original Message:(Failed (unspecified error))
# Fiasko (uspecificeret fejl)
