$set 3  #SignalList

$ #0 Original Message:(Unknown signal)
# Ukendt signal

$ #1 Original Message:(Hangup)
# Forbindelse afbrudt

$ #2 Original Message:(Interrupt)
# Afbrydelse

$ #3 Original Message:(Quit)
# Afslutning

$ #4 Original Message:(Illegal instruction)
# Ugyldig instruktion

$ #5 Original Message:(Trace/breakpoint trap)
# Efterspore/afbrydelsespunkt f�lde

$ #6 Original Message:(IOT trap/Abort)
# Inddata/Uddate f�lde/afbrydelse

$ #7 Original Message:(Bus Error)
# Bus fejl

$ #8 Original Message:(Floating point exception)
# Flydendekomma undtagelse

$ #9 Original Message:(Killed)
# Dr�bt

$ #10 Original Message:(User defined signal 1)
# Brugerdefineret signal 1

$ #11 Original Message:(Segmentation fault)
# Segmentfejl

$ #12 Original Message:(User defined signal 2)
# Brugerdefineret signal 2

$ #13 Original Message:(Broken pipe)
# Dataoverf�rsel afbrudt

$ #14 Original Message:(Alarm clock)
# Alarmur

$ #15 Original Message:(Terminated)
# Termineret

$ #16 Original Message:(Stack fault)
# Stakfejl

$ #17 Original Message:(Child exited)
# Barneproces afsluttet

$ #18 Original Message:(Continued)
# Fortsat

$ #19 Original Message:(Stopped (signal))
# Standset (signal)

$ #20 Original Message:(Stopped)
# Standset

$ #21 Original Message:(Stopped (tty input))
# Standset (tty inddata)

$ #22 Original Message:(Stopped (tty output))
# Standset (tty uddata)

$ #23 Original Message:(Urgent condition)
# Presserende tilstand

$ #24 Original Message:(CPU time limit exceeded)
# Processortidsgr�nsen overskredet

$ #25 Original Message:(File size limit exceeded)
# Filst�rrelsesgr�nsen overskredet

$ #26 Original Message:(Virtual time alarm)
# Virtuelt alarmur

$ #27 Original Message:(Profile signal)
# Profil signal

$ #28 Original Message:(Window size changed)
# Vinduest�relse �ndret

$ #29 Original Message:(Possible I/O)
# Muligvis I/O

$ #30 Original Message:(Power Failure)
# St�mforsyningsfejl

$ #31 Original Message:(Unused signal)
# Ubrugt signal
