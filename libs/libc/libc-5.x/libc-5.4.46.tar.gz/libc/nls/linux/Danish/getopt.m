$set 6 #Getopt

$ #Ambiguous Original Message:(%s: option `%s' is ambiguous\n)
# %s: valgmulighed `%s' er flertydig\n

$ #NoArgumentsAllowed1 Original Message:(%s: option `--%s' doesn't allow an argument\n)
# %s: valgmulighed `--%s' tillader ikke argumenter

$ #NoArgumentsAllowed2 Original Message:(%s: option `%c%s' doesn't allow an argument\n)
# %s: valgmulighed `%c%s' tillader ikke argumenter

$ #RequiresArgument1 Original Message:(%s: option `%s' requires an argument\n)
# %s: valgmulighed `%s' kr�ver et argument\n

$ #RequiresArgument2 Original Message:(%s: option requires an argument -- %c\n)
# %s: valgmulighed kr�ver et argument -- %c\n

$ #Unrecognized1 Original Message:(%s: unrecognized option `--%s'\n)
# %s: ukendt valgmulighed `--%s'\n

$ #Unrecognized2 Original Message:(%s: unrecognized option `%c%s'\n)
# %s: ukendt valgmulighed `%c%s'\n

$ #Illegal Original Message:(%s: illegal option -- %c\n)
# %s: ugyldig valgmulighed -- %c\n
