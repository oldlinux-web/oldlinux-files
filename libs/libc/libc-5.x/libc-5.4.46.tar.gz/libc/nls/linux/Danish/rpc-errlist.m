$set 8 #RpcErrList

$ #1 Original Message:(RPC: Success)
# RPC: Success

$ #2 Original Message:(RPC: Can't encode arguments)
# RPC: kan ikke indkode argumenter

$ #3 Original Message:(RPC: Can't decode result)
# RPC: kan ikke dekode resultatet

$ #4 Original Message:(RPC: Unable to send)
# RPC: kan ikke sende

$ #5 Original Message:(RPC: Unable to receive)
# RPC: kan ikke modtage

$ #6 Original Message:(RPC: Timed out)
# RPC: tiden er l�bet ud

$ #7 Original Message:(RPC: Incompatible versions of RPC)
# RPC: inkompatiebel RPC version

$ #8 Original Message:(RPC: Authentication error)
# RPC: autentifikationsfejl

$ #9 Original Message:(RPC: Program unavailable)
# RPC: program er ikke tilg�ngelig

$ #10 Original Message:(RPC: Program/version mismatch)
# RPC: program/version passer ikke sammen

$ #11 Original Message:(RPC: Procedure unavailable)
# RPC: procedure er ikke tilg�ngelig

$ #12 Original Message:(RPC: Server can't decode arguments)
# RPC: server kan ikke dekode argumenter

$ #13 Original Message:(RPC: Remote system error)
# RPC: fejl p� det fjerne system

$ #14 Original Message:(RPC: Unknown host)
# RPC: ukendt datamat 

$ #15 Original Message:(RPC: Port mapper failure)
# RPC: portmapper fejl

$ #16 Original Message:(RPC: Program not registered)
# RPC: program er ikke registreret

$ #17 Original Message:(RPC: Failed (unspecified error))
# RPC: Fejl (uspecifiseret fejl)

$ #18 Original Message:(RPC: Unknown protocol)
# RPC: ukendt protokol

$ #Unknown Original Message:(RPC: (unknown error code))
# RPC: (ukendt fejlkode)
