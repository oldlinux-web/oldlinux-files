#include "libioP.h"
#include "stdio.h"

int
fputc(c, fp)
     int c;
     FILE *fp;
{
#ifdef _LIBPTHREAD
  int ret;
  CHECK_FILE(fp, EOF);
  flockfile (fp);
  ret = _IO_putc(c, fp);
  funlockfile (fp);
  return ret;
#else
  CHECK_FILE(fp, EOF);
  return _IO_putc(c, fp);
#endif
}

#ifndef _LIBPTHREAD
#ifdef __ELF__
#pragma weak fputc
#endif
#endif
