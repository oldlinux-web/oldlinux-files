#include "libioP.h"
#include "stdio.h"

void
clearerr(fp)
     FILE* fp;
{
  CHECK_FILE(fp, /*nothing*/);
#ifdef _LIBPTHREAD
  flockfile (fp);
#endif
  _IO_clearerr(fp);
#ifdef _LIBPTHREAD
  funlockfile (fp);
#endif
}

#ifndef _LIBPTHREAD
#ifdef __ELF__
#pragma weak clearerr
#endif
#endif
