/* setpassent.c - vacuous setpassent for BSD - rick sladkey */

void setpassent __P((int));

void setpassent(int i)
{
}
