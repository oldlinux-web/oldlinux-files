#include <errno.h>
#include <linux/utsname.h>
#include <sys/syscall.h>

int
__old__uname (struct old_utsname *buf)
{
	register int res;

	__asm__("int $0x80"
		:"=a" (res)
		:"0" (SYS_olduname),"b" (buf));
	if (res>=0)
		return res;
	errno = -res;
	return -1;
}
