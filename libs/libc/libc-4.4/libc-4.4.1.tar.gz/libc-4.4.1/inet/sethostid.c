int fd;

    fd = socket(AF_INET, SOCK_RAW, 0);
	ifreq.ifr_addr = id;
	    return((ioctl(fd, SIOCSIFADDR, &ifr));


